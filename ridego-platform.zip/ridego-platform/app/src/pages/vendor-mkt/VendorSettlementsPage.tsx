import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ApiError } from '../../lib/api';
import { getVendorSettlements, type SettlementRow, type SettlementsResponse } from '../../lib/api-vendor-marketplace';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { formatDateTime, formatMoney, ToneBadge, useRequestGuard, type Tone } from './vendor-mkt-shared';
import { brand } from '../../lib/brand';
import { DATA_CARD_CLASS } from '../../components/ui/Zone';

const ENTRY_LABEL: Record<string, string> = {
  commission: 'Platform commission',
  advance_held: 'Advance held by platform (earlier bookings)',
  lead_fee_retained: 'Lead fee set off from the customer advance held by ' + brand().name + '',
  lead_fee: 'Lead fee payable to ' + brand().name,
  cancellation_compensation: 'Compensation for a cancelled trip',
  commission_reversal: 'Commission reversed',
};

const STATUS_LABEL: Record<string, string> = { pending: 'Pending', settled: 'Settled' };
const STATUS_TONE: Record<string, Tone> = { pending: 'warning', settled: 'success' };

const TILE_SKELETONS = ['commission', 'advance', 'pending', 'settled'];
const ROW_SKELETONS = ['row-a', 'row-b', 'row-c', 'row-d', 'row-e'];

// TRACE: ledger row → turns an entry_type code into a readable label → string.
//        Preconditions: none. Postconditions: known codes use fixed wording. Edge cases: unknown code → underscores
//        replaced by spaces and capitalised; empty → "Ledger entry".
function entryLabel(type: string): string {
  if (ENTRY_LABEL[type]) return ENTRY_LABEL[type];
  if (!type) return 'Ledger entry';
  const spaced = type.replace(/_/g, ' ');
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

// TRACE: summary tiles → formats a possibly negative net amount → "-₹1,200" or "₹1,200".
//        Preconditions: n finite. Postconditions: minus sign precedes the currency symbol. Edge cases: zero → "₹0".
function signedMoney(n: number): string {
  return n < 0 ? `-${formatMoney(Math.abs(n))}` : formatMoney(n);
}

// TRACE: route /app/vendor/settlements → loads the vendor's ledger summary + one page of ledger rows, renders four summary
//        tiles and a paginated table → paging refetches. Preconditions: vendor session. Postconditions: stale responses
//        dropped; status and direction shown as text, never colour alone. Edge cases: not a vendor (message), failure
//        (retry), empty ledger (empty state, zero tiles), last/first page (paging buttons disabled), page beyond range
//        after a shrink (clamped back to the last page).
export function VendorSettlementsPage() {
  const guard = useRequestGuard();
  const [page, setPage] = useState(1);
  const [data, setData] = useState<SettlementsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notVendor, setNotVendor] = useState(false);

  // TRACE: mount / page change → GET settlements for the page → stores it. Preconditions: page >= 1.
  //        Postconditions: newest response wins. Edge cases: 403/not_a_vendor, other failure (error + retry), page past
  //        the end (moves to the last page).
  const load = useCallback(
    async (p: number) => {
      const id = guard.begin();
      setLoading(true);
      setError(null);
      try {
        const res = await getVendorSettlements(p);
        if (!guard.isCurrent(id)) return;
        const lastPage = Math.max(1, Math.ceil(res.total / res.per_page));
        if (p > lastPage) {
          setPage(lastPage);
          return;
        }
        setData(res);
      } catch (err) {
        if (!guard.isCurrent(id)) return;
        if (err instanceof ApiError && (err.status === 403 || err.code === 'not_a_vendor')) setNotVendor(true);
        else setError(err instanceof ApiError ? err.message : 'Could not load your settlements. Please try again.');
      } finally {
        if (guard.isCurrent(id)) setLoading(false);
      }
    },
    [guard]
  );

  // TRACE: mount / page change → loads that page → void.
  useEffect(() => {
    void load(page);
  }, [load, page]);

  // TRACE: retry button → reloads the current page → void.
  const retry = useCallback(() => {
    void load(page);
  }, [load, page]);

  // TRACE: Previous click → goes back one page (not below 1) → void.
  const prev = () => setPage((p) => Math.max(1, p - 1));
  // TRACE: Next click → goes forward one page → void. Edge cases: button disabled on the last page.
  const next = () => setPage((p) => p + 1);

  if (notVendor) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <div className="rounded-2xl border border-ink-100 bg-ink-50/60 p-10">
          <h1 className="text-xl font-bold text-ink-900">Vendor access required</h1>
          <p className="mt-2 text-ink-600">Settlements are only available to registered driver-partners.</p>
          <div className="mt-6">
            <Link to="/vendor/dashboard">
              <Button>Go to vendor dashboard</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const totalPages = data ? Math.max(1, Math.ceil(data.total / data.per_page)) : 1;

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-10 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Settlements</h1>
          <p className="text-sm text-ink-600">Your lead fee for each trip is calculated under your accepted commercial terms. The customer advance {brand().name} collects from the client is set against it, and any balance is settled after the trip. You collect the ride balance from clients yourself.</p>
        </div>
        <Link to="/vendor/dashboard">
          <Button variant="secondary" size="sm">
            Back to dashboard
          </Button>
        </Link>
      </div>

      {loading && !data && (
        <div className="mt-6 space-y-6" aria-busy="true" aria-label="Loading settlements">
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {TILE_SKELETONS.map((k) => (
              <Skeleton key={k} className="h-24 w-full rounded-xl" />
            ))}
          </div>
          {ROW_SKELETONS.map((k) => (
            <Skeleton key={k} className="h-10 w-full" />
          ))}
        </div>
      )}

      {error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={retry} />
        </div>
      )}

      {!error && data && (
        <>
          <div className="mt-6 grid grid-cols-2 gap-3 lg:grid-cols-4">
            <SummaryTile label="Commission" value={formatMoney(data.summary.commission)} hint="On the estimated fare of completed trips" />
            <SummaryTile label="Lead fees" value={formatMoney(data.summary.fee_total)} hint={`Set off from advances: ${formatMoney(data.summary.fee_retained)}; still to pay: ${formatMoney(data.summary.fee_outstanding)}`} />
            <SummaryTile label="Pending net" value={signedMoney(data.summary.pending_net)} hint="Credits minus debits, not yet settled" />
            <SummaryTile label="Settled net" value={signedMoney(data.summary.settled_net)} hint="Credits minus debits, settled" />
          </div>

          <div className="mt-8" aria-busy={loading}>
            <h2 className="text-lg font-semibold text-ink-900">Ledger</h2>
            {data.rows.length === 0 ? (
              <div className="mt-4">
                <EmptyState title="No ledger entries yet" description="Entries appear here after your trips are completed and settled." />
              </div>
            ) : (
              <>
                <div className={`mt-4 overflow-x-auto ${DATA_CARD_CLASS}`}>
                  <table className="min-w-full divide-y divide-ink-100 text-sm">
                    <caption className="sr-only">Ledger entries, newest first, page {data.page} of {totalPages}</caption>
                    <thead className="bg-ink-50 text-left text-xs font-semibold uppercase tracking-wide text-ink-600">
                      <tr>
                        <th scope="col" className="px-4 py-3">Date</th>
                        <th scope="col" className="px-4 py-3">Booking</th>
                        <th scope="col" className="px-4 py-3">Entry</th>
                        <th scope="col" className="px-4 py-3">Direction</th>
                        <th scope="col" className="px-4 py-3 text-right">Amount</th>
                        <th scope="col" className="px-4 py-3">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-ink-100 bg-white">
                      {data.rows.map((r) => (
                        <LedgerRow key={r.id} row={r} />
                      ))}
                    </tbody>
                  </table>
                </div>
                <div className="mt-4 flex items-center justify-between gap-3">
                  <p className="text-sm text-ink-600">
                    Page {data.page} of {totalPages} &middot; {data.total} entr{data.total === 1 ? 'y' : 'ies'}
                  </p>
                  <div className="flex gap-2">
                    <Button variant="secondary" size="sm" onClick={prev} disabled={loading || page <= 1}>
                      Previous
                    </Button>
                    <Button variant="secondary" size="sm" onClick={next} disabled={loading || page >= totalPages}>
                      Next
                    </Button>
                  </div>
                </div>
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
}

// TRACE: settlements page → renders one summary tile with label, value and explanatory hint → tile.
//        Preconditions: value already formatted. Postconditions: text contrast AA on white. Edge cases: none.
function SummaryTile({ label, value, hint }: { label: string; value: string; hint: string }) {
  return (
    <div className={`${DATA_CARD_CLASS} p-4`}>
      <p className="text-xs font-medium uppercase tracking-wide text-ink-600">{label}</p>
      <p className="mt-2 text-xl font-bold text-ink-900 sm:text-2xl">{value}</p>
      <p className="mt-1 text-xs text-ink-600">{hint}</p>
    </div>
  );
}

// TRACE: ledger table → renders one row: date, booking link, readable entry label, direction as text + arrow, signed
//        amount, status badge → table row. Preconditions: row from the API. Postconditions: debit amounts carry a minus
//        sign and the word "Debit", credits a plus sign and "Credit" (never colour alone); settled date appended to
//        settled status. Edge cases: no booking number (dash, no link), unknown status (raw text, neutral badge).
function LedgerRow({ row }: { row: SettlementRow }) {
  const credit = row.direction === 'credit';
  return (
    <tr>
      <td className="whitespace-nowrap px-4 py-3 text-ink-700">{formatDateTime(row.created_at)}</td>
      <td className="whitespace-nowrap px-4 py-3">
        {row.booking_number ? (
          <Link
            to={`/app/vendor/bookings/${row.booking_id}`}
            className="rounded font-medium text-brand-700 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
          >
            #{row.booking_number}
          </Link>
        ) : (
          <span className="text-ink-600">—</span>
        )}
      </td>
      <td className="px-4 py-3 text-ink-900">{entryLabel(row.entry_type)}</td>
      <td className="whitespace-nowrap px-4 py-3 text-ink-700">
        <span aria-hidden="true">{credit ? '↓ ' : '↑ '}</span>
        {credit ? 'Credit' : 'Debit'}
      </td>
      <td className="whitespace-nowrap px-4 py-3 text-right font-medium text-ink-900">
        {credit ? '+' : '-'}
        {formatMoney(row.amount)}
      </td>
      <td className="whitespace-nowrap px-4 py-3">
        <ToneBadge tone={STATUS_TONE[row.status] ?? 'neutral'}>{STATUS_LABEL[row.status] ?? row.status}</ToneBadge>
        {row.settled_at && <span className="ml-2 text-xs text-ink-600">{formatDateTime(row.settled_at)}</span>}
      </td>
    </tr>
  );
}
