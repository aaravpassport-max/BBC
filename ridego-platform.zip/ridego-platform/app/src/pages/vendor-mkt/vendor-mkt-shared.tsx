import { useCallback, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';

export const INPUT_CLASS =
  'w-full rounded-lg border border-ink-200 bg-white px-3 py-2 text-sm text-ink-900 shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30 disabled:bg-ink-50 disabled:text-ink-500';

export const LINK_BUTTON_CLASS =
  'rounded-md text-sm font-medium text-brand-700 hover:text-brand-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 disabled:opacity-60';

export type Tone = 'success' | 'warning' | 'danger' | 'brand' | 'neutral';

const TONE_CLASSES: Record<Tone, string> = {
  success: 'bg-success-50 text-success-600 border-success-500/30',
  warning: 'bg-warning-50 text-warning-600 border-warning-500/30',
  danger: 'bg-danger-50 text-danger-600 border-danger-500/30',
  brand: 'bg-brand-50 text-brand-700 border-brand-200',
  neutral: 'bg-ink-100 text-ink-700 border-ink-200',
};

const TONE_GLYPH: Record<Tone, string> = {
  success: '✓',
  warning: '!',
  danger: '✕',
  brand: '•',
  neutral: '–',
};

// TRACE: any table/card → formats a rupee amount with Indian grouping → string like "₹12,500.50".
//        Preconditions: n is a number. Postconditions: always two-decimals-max text. Edge cases: NaN/Infinity → "₹0".
export function formatMoney(n: number): string {
  const safe = Number.isFinite(n) ? n : 0;
  return `₹${safe.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

// TRACE: any date display → parses a WordPress 'YYYY-MM-DD HH:MM:SS' (or ISO) string → readable local date-time.
//        Preconditions: value may be empty. Postconditions: never throws. Edge cases: empty → '—'; unparseable →
//        the raw text; date-only input (no time) → date without time.
export function formatDateTime(value: string | null | undefined): string {
  if (!value) return '—';
  const d = new Date(value.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return value;
  const dateOnly = !/[T ]\d{2}:\d{2}/.test(value);
  return d.toLocaleString('en-IN', dateOnly ? { dateStyle: 'medium' } : { dateStyle: 'medium', timeStyle: 'short' });
}

// TRACE: any badge caller → renders a labelled pill whose meaning is carried by a glyph plus text, never colour alone.
//        Preconditions: label non-empty. Postconditions: glyph is aria-hidden, label read by screen readers.
//        Edge cases: unknown tone falls back to the neutral style.
export function ToneBadge({ tone, children }: { tone: Tone; children: ReactNode }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-0.5 text-xs font-medium ${TONE_CLASSES[tone] ?? TONE_CLASSES.neutral}`}
    >
      <span aria-hidden="true">{TONE_GLYPH[tone] ?? TONE_GLYPH.neutral}</span>
      {children}
    </span>
  );
}

// TRACE: any form → wraps a control with a visible label, optional hint and optional error → labelled field block.
//        Preconditions: htmlFor matches the control id. Postconditions: hint/error ids are stable (`${htmlFor}-hint`,
//        `${htmlFor}-error`) for aria-describedby. Edge cases: no hint/error (just label + control).
export function FormField({
  label,
  htmlFor,
  hint,
  error,
  required,
  children,
}: {
  label: string;
  htmlFor: string;
  hint?: string;
  error?: string | null;
  /** Shows a required-field indicator next to the label. Purely visual/assistive — the actual
   *  validation still lives in the form's submit handler; this just tells the user up front
   *  which of the fields on a long form (e.g. the 22-field driver form) they can't skip. */
  required?: boolean;
  children: ReactNode;
}) {
  return (
    <div>
      <label htmlFor={htmlFor} className="block text-sm font-medium text-ink-800">
        {label}
        {required && (
          <>
            <span aria-hidden="true" className="ml-0.5 text-danger-600">*</span>
            <span className="sr-only"> (required)</span>
          </>
        )}
      </label>
      <div className="mt-1">{children}</div>
      {hint && (
        <p id={`${htmlFor}-hint`} className="mt-1 text-xs text-ink-500">
          {hint}
        </p>
      )}
      {error && (
        <p id={`${htmlFor}-error`} role="alert" className="mt-1 text-xs font-medium text-danger-600">
          {error}
        </p>
      )}
    </div>
  );
}

// TRACE: async loaders → issues a monotonically increasing request id and reports whether an id is still the latest →
//        stale responses can be dropped. Preconditions: called inside a component. Postconditions: after unmount every
//        id reports stale (no state set on an unmounted page). Edge cases: overlapping loads (only the newest wins),
//        React StrictMode double-mount (the second mount's loads stay valid).
export function useRequestGuard() {
  const counter = useRef(0);
  const mounted = useRef(true);

  // TRACE: mount → marks the hook mounted; cleanup marks it unmounted so late responses are dropped → void.
  //        Edge cases: StrictMode remount (flag set true again).
  useEffect(() => {
    mounted.current = true;
    return () => {
      mounted.current = false;
    };
  }, []);

  // TRACE: loader start → bumps the counter → returns the id for this request.
  //        Preconditions: none. Postconditions: previous ids become stale. Edge cases: none.
  const begin = useCallback((): number => {
    counter.current += 1;
    return counter.current;
  }, []);

  // TRACE: loader settle → compares id with the latest and the mounted flag → boolean.
  //        Preconditions: id came from begin(). Postconditions: pure read. Edge cases: unmounted (false), superseded (false).
  const isCurrent = useCallback((id: number): boolean => mounted.current && counter.current === id, []);

  return useMemo(() => ({ begin, isCurrent }), [begin, isCurrent]);
}

// TRACE: pages with a BottomSheet → tracks the sheet's target, open flag and a nonce → stable show/hide callbacks.
//        Preconditions: none. Postconditions: hide() keeps the target so content stays during the close animation;
//        show() bumps the nonce so a fresh form mounts (key) even if the same target is reopened quickly.
//        Edge cases: hide before show (no-op), show while open (retargets).
export function useSheet<T>() {
  const [target, setTarget] = useState<T | null>(null);
  const [open, setOpen] = useState(false);
  const [nonce, setNonce] = useState(0);

  // TRACE: opener button → stores the target, opens the sheet → void. Edge cases: reopened rapidly (new nonce).
  const show = useCallback((t: T) => {
    setTarget(t);
    setNonce((n) => n + 1);
    setOpen(true);
  }, []);

  // TRACE: sheet close (Escape, backdrop, button, success) → closes the sheet → void. Edge: already closed (no-op).
  const hide = useCallback(() => setOpen(false), []);

  return { target, open, nonce, show, hide };
}

// TRACE: rating forms/tables → renders a read-only 5-star row with a text alternative → stars.
//        Preconditions: value 0..5. Postconditions: aria-label states the value. Edge cases: fractional (rounded for
//        filled stars), out-of-range (clamped).
export function StarsDisplay({ value }: { value: number }) {
  const v = Math.max(0, Math.min(5, value));
  const filled = Math.round(v);
  return (
    <span className="inline-flex items-center gap-0.5" role="img" aria-label={`${v.toFixed(1)} out of 5`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <svg
          key={n}
          className={`h-3.5 w-3.5 ${n <= filled ? 'text-warning-500' : 'text-ink-200'}`}
          viewBox="0 0 20 20"
          fill="currentColor"
          aria-hidden="true"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.957a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.367 2.447a1 1 0 00-.364 1.118l1.287 3.957c.3.922-.755 1.688-1.538 1.118l-3.367-2.447a1 1 0 00-1.176 0l-3.367 2.447c-.783.57-1.838-.196-1.538-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.063 9.384c-.783-.57-.38-1.81.588-1.81h4.163a1 1 0 00.95-.69l1.286-3.957z" />
        </svg>
      ))}
    </span>
  );
}

// TRACE: rating form → renders a labelled radio group of 1-5 stars → calls onChange with the chosen score.
//        Preconditions: name unique within the page. Postconditions: keyboard operable (native radios), the selected
//        value announced with its number. Edge cases: value 0 (nothing selected), disabled while submitting.
export function StarInput({
  name,
  legend,
  value,
  onChange,
  disabled,
}: {
  name: string;
  legend: string;
  value: number;
  onChange: (score: number) => void;
  disabled?: boolean;
}) {
  return (
    <fieldset disabled={disabled} className="min-w-0">
      <legend className="text-sm font-medium text-ink-800">{legend}</legend>
      <div className="mt-1 flex items-center gap-1">
        {[1, 2, 3, 4, 5].map((n) => (
          <StarChoice key={n} name={name} score={n} selected={value === n} filled={n <= value} onChange={onChange} />
        ))}
        <span className="ml-2 text-xs text-ink-500" aria-hidden="true">
          {value > 0 ? `${value}/5` : 'Not rated'}
        </span>
      </div>
    </fieldset>
  );
}

// TRACE: StarInput → renders one radio star → onChange(score) when chosen.
//        Preconditions: score 1..5. Postconditions: visible focus ring on the star while the radio has focus.
//        Edge cases: fieldset disabled (radio inert).
function StarChoice({
  name,
  score,
  selected,
  filled,
  onChange,
}: {
  name: string;
  score: number;
  selected: boolean;
  filled: boolean;
  onChange: (score: number) => void;
}) {
  // TRACE: radio change → forwards the score → void. Preconditions: none. Postconditions: parent state updated. Edge: none.
  const handleChange = () => onChange(score);
  return (
    <label className="relative cursor-pointer rounded-md p-1 has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-brand-600">
      <input type="radio" name={name} value={score} checked={selected} onChange={handleChange} className="sr-only" />
      <span className="sr-only">{`${score} star${score === 1 ? '' : 's'}`}</span>
      <svg className={`h-7 w-7 ${filled ? 'text-warning-500' : 'text-ink-300'}`} viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.957a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.367 2.447a1 1 0 00-.364 1.118l1.287 3.957c.3.922-.755 1.688-1.538 1.118l-3.367-2.447a1 1 0 00-1.176 0l-3.367 2.447c-.783.57-1.838-.196-1.538-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.063 9.384c-.783-.57-.38-1.81.588-1.81h4.163a1 1 0 00.95-.69l1.286-3.957z" />
      </svg>
    </label>
  );
}

// TRACE: ConfirmDriverForm → renders one selectable driver/vehicle as a radio row; unavailable entries are disabled and
//        show the reason as text, type mismatches get a labelled badge → onPick(id) when chosen.
//        Preconditions: group unique per list. Postconditions: reason text linked with aria-describedby; focus ring shows
//        on the row while the radio is focused. Edge cases: unavailable without a reason (generic text), preferred flag.
export function OptionRow({
  group,
  id,
  title,
  detail,
  preferred,
  available,
  reason,
  mismatch,
  selected,
  onPick,
}: {
  group: string;
  id: number;
  title: string;
  detail: string;
  preferred: boolean;
  available: boolean;
  reason: string;
  mismatch?: boolean;
  selected: boolean;
  onPick: (id: number) => void;
}) {
  const inputId = `${group}-${id}`;
  // TRACE: radio change → reports the chosen id → void. Edge cases: disabled radio never fires.
  const change = () => onPick(id);
  return (
    <li>
      <label
        htmlFor={inputId}
        className={`flex cursor-pointer items-start gap-3 rounded-lg border p-3 has-[:focus-visible]:outline has-[:focus-visible]:outline-2 has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-brand-600 ${
          available ? (selected ? 'border-brand-500 bg-brand-50' : 'border-ink-200 hover:bg-ink-50') : 'cursor-not-allowed border-ink-100 bg-ink-50'
        }`}
      >
        <input
          id={inputId}
          type="radio"
          name={group}
          checked={selected}
          onChange={change}
          disabled={!available}
          aria-describedby={!available ? `${inputId}-reason` : undefined}
          className="mt-1 h-4 w-4 border-ink-300 text-brand-600"
        />
        <span className="min-w-0 flex-1">
          <span className={`block text-sm font-semibold ${available ? 'text-ink-900' : 'text-ink-500'}`}>{title}</span>
          {detail && <span className="block text-xs text-ink-600">{detail}</span>}
          <span className="mt-1 flex flex-wrap gap-1.5">
            {preferred && available && <ToneBadge tone="brand">Near pickup</ToneBadge>}
            {mismatch && <ToneBadge tone="warning">Different vehicle type</ToneBadge>}
            {!available && <ToneBadge tone="danger">Unavailable</ToneBadge>}
          </span>
          {!available && (
            <span id={`${inputId}-reason`} className="mt-1 block text-xs text-danger-600">
              {reason || 'Not available for this trip.'}
            </span>
          )}
        </span>
      </label>
    </li>
  );
}
