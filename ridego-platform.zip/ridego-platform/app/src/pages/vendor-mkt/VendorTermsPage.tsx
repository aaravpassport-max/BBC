import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ApiError } from '../../lib/api';
import { acceptVendorTerms, getVendorTerms, type VendorTermsResponse } from '../../lib/api-leadfee';
import { Skeleton } from '../../components/ui/Skeleton';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Button } from '../../components/ui/Button';
import { brand } from '../../lib/brand';
import { DATA_CARD_CLASS } from '../../components/ui/Zone';

const SAMPLE_NOTE = 'The lead fee is calculated from the expected booking amount of each trip and shown on the lead before you accept it.';

// TRACE: vendor opens Commercial terms → GET /app/vendor/commercial-terms → shows the rules that currently apply to this vendor (their own rule first, else the platform rule), whether they have accepted them (version and time) and their acceptance history;
//        "Accept these terms" → POST accept (idempotent) → reload. Preconditions: signed-in vendor. Postconditions: acceptance recorded with version and time; later changes to the terms ask for acceptance again when the platform requires it.
//        Edge cases: load failure (retry), no terms (message), already accepted (no button), double click (button disabled while saving), server refusal (message shown).
export function VendorTermsPage() {
  const [data, setData] = useState<VendorTermsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      setData(await getVendorTerms());
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Could not load your commercial terms. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // TRACE: Accept clicked → POST accept → success message and reload; failure message, state unchanged.
  async function accept() {
    setBusy(true);
    setMsg(null);
    try {
      const r = await acceptVendorTerms();
      setMsg({ ok: true, text: r.message ?? 'Your acceptance has been recorded.' });
      await load();
    } catch (e) {
      setMsg({ ok: false, text: e instanceof ApiError ? e.message : 'Could not record your acceptance. Please try again.' });
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6 sm:py-10 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Commercial terms</h1>
          <p className="text-sm text-ink-600">How the lead fee for bookings arranged through {brand().name} is calculated for you. {SAMPLE_NOTE}</p>
        </div>
        <Link to="/vendor/dashboard">
          <Button variant="secondary" size="sm">Back to dashboard</Button>
        </Link>
      </div>

      {loading && (
        <div className="mt-6 space-y-3" aria-busy="true" aria-label="Loading commercial terms">
          <Skeleton className="h-24 w-full rounded-xl" />
          <Skeleton className="h-24 w-full rounded-xl" />
        </div>
      )}
      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}
      {msg && (
        <div role={msg.ok ? 'status' : 'alert'} className={`mt-4 rounded-lg border px-3.5 py-2.5 text-sm ${msg.ok ? 'border-success-200 bg-success-50 text-success-800' : 'border-danger-500/30 bg-danger-50 text-danger-600'}`}>
          {msg.text}
        </div>
      )}

      {!loading && !error && data && (
        <div className="mt-6 space-y-5">
          {!data.enabled && <p className="rounded-lg border border-ink-100 bg-ink-50 p-3 text-sm text-ink-700">No lead fee is being charged right now.</p>}
          <section className={`${DATA_CARD_CLASS} p-5`} aria-label="Your terms">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-ink-500">Terms that apply to you</h2>
            {data.terms.length === 0 && <p className="mt-3 text-sm text-ink-500">There are no commercial terms to show right now.</p>}
            <ul className="mt-3 space-y-3">
              {data.terms.map((t) => (
                <li key={t.id} className="rounded-lg border border-ink-100 p-3 text-sm">
                  <p className="font-semibold text-ink-900">{t.scope === 'vendor' ? 'Your agreed terms' : `${brand().name} standard terms`} <span className="font-normal text-ink-500">v{t.version}</span></p>
                  <p className="mt-1 text-ink-700">{t.description}</p>
                  <p className="mt-1 text-xs text-ink-500">From {t.effective_from}{t.effective_until ? ` until ${t.effective_until}` : ''}</p>
                </li>
              ))}
            </ul>
            <p className="mt-3 text-xs text-ink-500">
              {data.offset_advance
                ? 'The customer advance the client pays is set against your lead fee; you pay only the balance after the trip.'
                : 'The lead fee is settled after the trip.'}
            </p>
            {data.terms.length > 0 && (
              <div className="mt-4">
                {data.acceptance.accepted ? (
                  <p className="text-sm font-medium text-success-700">You accepted version {data.acceptance.version} on {data.acceptance.accepted_at}.</p>
                ) : (
                  <>
                    <p className="mb-2 text-sm text-ink-700">{data.require_acceptance ? 'Please accept these terms to keep receiving leads.' : 'Accepting confirms you agree to these terms.'}</p>
                    <Button onClick={() => void accept()} loading={busy} disabled={busy}>Accept these terms</Button>
                  </>
                )}
              </div>
            )}
          </section>

          <section className={`${DATA_CARD_CLASS} p-5`} aria-label="Acceptance history">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-ink-500">Your acceptance history</h2>
            {data.history.length === 0 && <p className="mt-3 text-sm text-ink-500">You have not accepted any terms yet.</p>}
            <ul className="mt-3 space-y-1 text-sm text-ink-700">
              {data.history.map((h) => (
                <li key={`${h.terms_id}-${h.accepted_at}`}>Version {h.terms_version} accepted on {h.accepted_at} ({h.source === 'lead_accept' ? 'on accepting a lead' : h.source})</li>
              ))}
            </ul>
          </section>
        </div>
      )}
    </div>
  );
}
