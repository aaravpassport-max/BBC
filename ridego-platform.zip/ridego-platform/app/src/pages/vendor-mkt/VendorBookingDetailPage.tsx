import { useCallback, useEffect, useState, type ChangeEvent, type FormEvent } from 'react';
import { Link, useParams } from 'react-router-dom';
import { advanceVendorTrip, ApiError } from '../../lib/api';
import {
  getBookingOptions,
  getVendorBookingDetail,
  rateClient,
  recordCollection,
  replaceAssignment,
  type BookingAssignment,
  type SelectionOptions,
  type VendorBookingDetail,
} from '../../lib/api-vendor-marketplace';
import { useToast } from '../../context/ToastContext';
import RideMoneyCard from '../../components/RideMoneyCard';
import { LeadFeeCard } from '../../components/LeadFeeCard';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import {
  FormField,
  formatDateTime,
  formatMoney,
  INPUT_CLASS,
  OptionRow,
  StarInput,
  ToneBadge,
  useRequestGuard,
  useSheet,
  type Tone,
} from './vendor-mkt-shared';
import { brand } from '../../lib/brand';
import { DATA_CARD_CLASS } from '../../components/ui/Zone';

type AdvanceStatus = 'driver_en_route' | 'trip_started' | 'completed';

const NEXT_STATUS: Record<string, AdvanceStatus> = {
  vendor_assigned: 'driver_en_route',
  driver_en_route: 'trip_started',
  trip_started: 'completed',
};

const NEXT_STATUS_LABEL: Record<string, string> = {
  vendor_assigned: "Mark 'Driver en route'",
  driver_en_route: 'Verify pickup OTP & start trip',
  trip_started: 'Mark trip completed',
};

const COMMITTED = ['vendor_assigned', 'driver_en_route', 'trip_started'];

const STATUS_TONE: Record<string, Tone> = {
  vendor_assigned: 'brand',
  driver_en_route: 'brand',
  trip_started: 'brand',
  completed: 'success',
  cancelled: 'danger',
  pending: 'warning',
};

const RATING_CATEGORIES: { key: string; label: string }[] = [
  { key: 'communication', label: 'Communication' },
  { key: 'reliability', label: 'Reliability' },
  { key: 'payment_behaviour', label: 'Payment behaviour' },
];

const DETAIL_SKELETONS = ['trip', 'assignment', 'timeline'];

// TRACE: any catch in this page → picks the message to show → string. Preconditions: none.
//        Postconditions: ApiError.message preserved verbatim. Edge cases: non-ApiError → fallback text.
function messageOf(err: unknown, fallback: string): string {
  return err instanceof ApiError ? err.message : fallback;
}

// TRACE: route /app/vendor/bookings/:id → loads the booking detail and renders trip info, balance to collect, timeline,
//        customer card (only when the API returned one), assignment card with the add/change sheet, status advance
//        buttons with pickup OTP, and the rate-the-customer form → every mutation re-fetches the detail.
//        Preconditions: vendor session, numeric :id. Postconditions: stale responses dropped. Edge cases: invalid id or
//        booking of another vendor (not-found state), load failure (retry), customer null (card hidden), assignment
//        null/needs_details (Add driver & vehicle), trip not active (no change/advance buttons), already rated (form hidden).
export function VendorBookingDetailPage() {
  const params = useParams();
  const bookingId = Number(params.id);
  const guard = useRequestGuard();
  const [detail, setDetail] = useState<VendorBookingDetail | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notFound, setNotFound] = useState(false);
  const assignSheet = useSheet<true>();

  // TRACE: mount / id change / after a mutation → GET the booking detail → stores it.
  //        Preconditions: silent keeps content on screen. Postconditions: newest response wins. Edge cases: bad id (not
  //        found), 404 (not found), other failure (error + retry), stale/unmounted (ignored).
  const load = useCallback(
    async (silent: boolean) => {
      if (!Number.isInteger(bookingId) || bookingId <= 0) {
        setNotFound(true);
        setLoading(false);
        return;
      }
      const id = guard.begin();
      if (!silent) setLoading(true);
      setError(null);
      try {
        const res = await getVendorBookingDetail(bookingId);
        if (!guard.isCurrent(id)) return;
        setDetail(res);
        setNotFound(false);
      } catch (err) {
        if (!guard.isCurrent(id)) return;
        if (err instanceof ApiError && err.status === 404) setNotFound(true);
        else setError(messageOf(err, 'Could not load this booking. Please try again.'));
      } finally {
        if (guard.isCurrent(id)) setLoading(false);
      }
    },
    [bookingId, guard]
  );

  // TRACE: mount / id change → runs the first load → void.
  useEffect(() => {
    void load(false);
  }, [load]);

  // TRACE: retry button → reloads with the spinner → void.
  const retry = useCallback(() => {
    void load(false);
  }, [load]);

  // TRACE: any child mutation succeeded → re-fetches the detail without the spinner → void.
  const reload = useCallback(() => {
    void load(true);
  }, [load]);

  // TRACE: assignment sheet saved → closes the sheet, reloads → void.
  const assignSaved = useCallback(() => {
    assignSheet.hide();
    reload();
  }, [assignSheet, reload]);

  // TRACE: assignment button → opens the add/change sheet → void.
  const openAssign = useCallback(() => assignSheet.show(true), [assignSheet]);

  if (notFound) {
    return (
      <div className="mx-auto max-w-xl px-4 py-16">
        <EmptyState
          title="Booking not found"
          description="This booking does not exist or is not assigned to you."
          action={
            <Link to="/vendor/trips">
              <Button>Back to trip history</Button>
            </Link>
          }
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6 sm:py-10 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">{detail ? `Booking #${detail.booking_number}` : 'Booking'}</h1>
          {detail && (
            <p className="mt-1">
              <ToneBadge tone={STATUS_TONE[detail.status] ?? 'neutral'}>{detail.status_label || detail.status}</ToneBadge>
            </p>
          )}
        </div>
        <Link to="/vendor/trips">
          <Button variant="secondary" size="sm">
            Back to trips
          </Button>
        </Link>
      </div>

      {loading && (
        <div className="mt-6 space-y-4" aria-busy="true" aria-label="Loading booking">
          {DETAIL_SKELETONS.map((k) => (
            <Skeleton key={k} className="h-32 w-full rounded-xl" />
          ))}
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={retry} />
        </div>
      )}

      {!loading && !error && detail && (
        <div className="mt-6 grid gap-4 lg:grid-cols-2">
          <TripInfoCard detail={detail} />
          <BalanceCard detail={detail} onRecorded={reload} />
          <AssignmentCard detail={detail} onOpen={openAssign} />
          {NEXT_STATUS[detail.status] && <StatusActions detail={detail} onAdvanced={reload} />}
          <TimelineCard detail={detail} />
          {detail.customer && <CustomerCard customer={detail.customer} />}
          {detail.status === 'completed' && !detail.rating.vendor_rated && <RateClientForm bookingId={detail.id} onRated={reload} />}
        </div>
      )}

      <BottomSheet open={assignSheet.open} title={detail?.assignment && !detail.assignment.needs_details ? 'Change driver & vehicle' : 'Add driver & vehicle'} onClose={assignSheet.hide}>
        {assignSheet.target && detail && (
          <AssignForm key={assignSheet.nonce} bookingId={detail.id} current={detail.assignment} onSaved={assignSaved} onCancel={assignSheet.hide} />
        )}
      </BottomSheet>
    </div>
  );
}

// TRACE: booking detail → renders the trip facts (route, date/time, type, passengers, requests) → card. Money lives in the collection card.
//        Preconditions: detail loaded. Postconditions: only fields the API returned are shown. Edge cases: no special
//        requests (row omitted).
function TripInfoCard({ detail }: { detail: VendorBookingDetail }) {
  const rows: { label: string; value: string }[] = [
    { label: 'Route', value: `${detail.pickup_city} → ${detail.drop_city}` },
    { label: 'Journey', value: `${detail.journey_date} at ${detail.journey_time}` },
    { label: 'Trip type', value: detail.trip_type.replace(/_/g, ' ') },
    { label: 'Passengers', value: String(detail.passengers) },
  ];
  if (detail.passenger_male !== null || detail.passenger_female !== null || detail.passenger_children !== null) {
    const parts = [
      detail.passenger_female ? `${detail.passenger_female} female` : null,
      detail.passenger_male ? `${detail.passenger_male} male` : null,
      detail.passenger_children ? `${detail.passenger_children} child${detail.passenger_children === 1 ? '' : 'ren'}` : null,
    ].filter(Boolean);
    if (parts.length) rows.push({ label: 'Passenger composition', value: parts.join(', ') });
  }
  if (detail.special_requests) rows.push({ label: 'Special requests', value: detail.special_requests });
  if (detail.passenger_notes) rows.push({ label: 'Passenger/safety notes', value: detail.passenger_notes });
  return (
    <section aria-labelledby="trip-heading" className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
      <h2 id="trip-heading" className="flex items-center gap-2 text-base font-semibold text-ink-900">
        Trip information
        {detail.is_safety_sensitive && (
          <span className="rounded-full bg-warning-50 px-2.5 py-1 text-xs font-semibold text-warning-700" title="Female-only or includes children.">
            🛡 Safety-sensitive
          </span>
        )}
      </h2>
      <dl className="mt-3 space-y-2 text-sm">
        {rows.map((r) => (
          <div key={r.label} className="flex justify-between gap-4">
            <dt className="text-ink-600">{r.label}</dt>
            <dd className="text-right font-medium capitalize text-ink-900">{r.value}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}

// TRACE: booking detail → the vendor's collection card. Shows estimated ride fare, booking amount RideGo already collected, what the vendor collects from the client,
//        what was reported collected so far, the history, the vendor-bills-the-client notice, and (while collectable) a form to record a collection → card.
//        Preconditions: detail loaded → Postconditions: numbers come from the server (never recomputed here); the form shows only for a committed/completed booking with an outstanding balance.
//        Edge cases: nothing payable (fare fully paid through RideGo → states so), cancelled trip (no form), collection history empty (section omitted).
function BalanceCard({ detail, onRecorded }: { detail: VendorBookingDetail; onRecorded: () => void }) {
  const canRecord = ['vendor_assigned', 'driver_en_route', 'trip_started', 'completed'].includes(detail.status) && (detail.vendor_outstanding ?? 0) > 0.004;
  return (
    <section aria-labelledby="balance-heading" className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
      <h2 id="balance-heading" className="text-base font-semibold text-ink-900">
        Ride payment — collect from the client
      </h2>
      <p className="mt-2 text-sm text-ink-600">
        {brand().name} collected only the customer advance. You bill the client for the ride and collect the remaining amount directly.
      </p>
      <div className="mt-3">
        <RideMoneyCard money={detail} audience="vendor" notice={detail.vendor_notice} />
      </div>
      <div className="mt-3">
        <LeadFeeCard fee={detail.lead_fee} audience="vendor" />
      </div>
      {detail.collection_history.length > 0 && (
        <div className="mt-4">
          <h3 className="text-sm font-semibold text-ink-900">Collections you recorded</h3>
          <ul className="mt-2 divide-y divide-ink-100 text-sm">
            {detail.collection_history.map((h) => (
              <li key={h.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                <span className="text-ink-700">
                  {formatDateTime(h.created_at)} · {h.method.replace(/_/g, ' ')}
                  {h.reference ? ` · ${h.reference}` : ''}
                </span>
                <span className="font-semibold text-ink-900">{formatMoney(h.amount)}</span>
              </li>
            ))}
          </ul>
        </div>
      )}
      {canRecord && <CollectionForm detail={detail} onRecorded={onRecorded} />}
    </section>
  );
}

// TRACE: form submit → validates amount > 0 and ≤ outstanding and a method → POST /vendor/bookings/:id/collect → toast, clears the form, onRecorded reloads the detail.
//        Preconditions: not already saving → Postconditions: fields kept on failure with the server message inline and in a toast; a second click while saving is ignored.
//        Edge cases: empty/zero/negative amount, amount above the outstanding balance (blocked client-side, server also refuses), no method chosen, server error.
function CollectionForm({ detail, onRecorded }: { detail: VendorBookingDetail; onRecorded: () => void }) {
  const toast = useToast();
  const outstanding = detail.vendor_outstanding ?? 0;
  const [amount, setAmount] = useState('');
  const [method, setMethod] = useState(detail.collection_methods[0] ?? 'cash');
  const [reference, setReference] = useState('');
  const [invoice, setInvoice] = useState(detail.vendor_invoice_number ?? '');
  const [note, setNote] = useState('');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    const n = Number(amount);
    if (!Number.isFinite(n) || n <= 0) {
      setFormError('Enter the amount you collected from the client.');
      return;
    }
    if (n > outstanding + 0.004) {
      setFormError(`That is more than the remaining ${formatMoney(outstanding)}.`);
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      const res = await recordCollection(detail.id, { amount: n, method, reference: reference.trim(), note: note.trim(), invoice_number: invoice.trim() });
      toast.show(res.message || 'Collection recorded.', 'success');
      setAmount('');
      setReference('');
      setNote('');
      onRecorded();
    } catch (err) {
      const msg = messageOf(err, 'Could not record the collection.');
      setFormError(msg);
      toast.show(msg, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="mt-4 space-y-3 border-t border-ink-100 pt-4" noValidate>
      <h3 className="text-sm font-semibold text-ink-900">Record an amount collected from the client</h3>
      <div className="grid gap-3 sm:grid-cols-2">
        <FormField label="Amount collected (₹)" htmlFor="col-amount">
          <input id="col-amount" inputMode="decimal" value={amount} onChange={(e: ChangeEvent<HTMLInputElement>) => setAmount(e.target.value)} disabled={saving} className={INPUT_CLASS} placeholder={String(outstanding)} />
        </FormField>
        <FormField label="How was it paid?" htmlFor="col-method">
          <select id="col-method" value={method} onChange={(e: ChangeEvent<HTMLSelectElement>) => setMethod(e.target.value)} disabled={saving} className={INPUT_CLASS}>
            {detail.collection_methods.map((m) => (
              <option key={m} value={m}>
                {m.replace(/_/g, ' ')}
              </option>
            ))}
          </select>
        </FormField>
        <FormField label="Payment reference (optional)" htmlFor="col-ref">
          <input id="col-ref" value={reference} onChange={(e: ChangeEvent<HTMLInputElement>) => setReference(e.target.value)} disabled={saving} maxLength={120} className={INPUT_CLASS} />
        </FormField>
        <FormField label="Your invoice number (optional)" htmlFor="col-inv" hint="The ride invoice or receipt you issued to the client.">
          <input id="col-inv" value={invoice} onChange={(e: ChangeEvent<HTMLInputElement>) => setInvoice(e.target.value)} disabled={saving} maxLength={60} className={INPUT_CLASS} />
        </FormField>
      </div>
      <FormField label="Note (optional)" htmlFor="col-note">
        <input id="col-note" value={note} onChange={(e: ChangeEvent<HTMLInputElement>) => setNote(e.target.value)} disabled={saving} maxLength={300} className={INPUT_CLASS} />
      </FormField>
      {formError && (
        <p role="alert" className="text-sm font-medium text-danger-600">
          {formError}
        </p>
      )}
      <Button type="submit" loading={saving}>
        Record collection
      </Button>
    </form>
  );
}

// TRACE: booking detail → shows the timeline steps with done/pending as text plus glyph and time → card.
//        Preconditions: detail.timeline from the API. Postconditions: state is never colour-only. Edge cases: empty
//        timeline (message), step without a timestamp (time omitted).
function TimelineCard({ detail }: { detail: VendorBookingDetail }) {
  return (
    <section aria-labelledby="timeline-heading" className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
      <h2 id="timeline-heading" className="text-base font-semibold text-ink-900">
        Timeline
      </h2>
      {detail.timeline.length === 0 ? (
        <p className="mt-2 text-sm text-ink-600">No timeline events yet.</p>
      ) : (
        <ol className="mt-3 space-y-3">
          {detail.timeline.map((t) => (
            <li key={t.key} className="flex items-start gap-3">
              <span
                aria-hidden="true"
                className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-xs font-bold ${
                  t.done ? 'bg-success-50 text-success-600' : 'bg-ink-100 text-ink-500'
                }`}
              >
                {t.done ? '✓' : '○'}
              </span>
              <div className="text-sm">
                <p className="font-medium text-ink-900">
                  {t.label}
                  <span className="ml-2 text-xs font-normal text-ink-600">{t.done ? '(done)' : '(not yet)'}</span>
                </p>
                {t.at && <p className="text-xs text-ink-600">{formatDateTime(t.at)}</p>}
              </div>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}

// TRACE: booking detail → renders the customer's name, phone (tap to call) and pickup/drop addresses → card. Rendered
//        only when the API returned a customer (booking committed and not cancelled).
//        Preconditions: customer object. Postconditions: nothing beyond the API fields is shown. Edge cases: missing
//        phone/addresses (rows omitted).
function CustomerCard({ customer }: { customer: NonNullable<VendorBookingDetail['customer']> }) {
  return (
    <section aria-labelledby="customer-heading" className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
      <h2 id="customer-heading" className="text-base font-semibold text-ink-900">
        Customer
      </h2>
      <dl className="mt-3 space-y-2 text-sm">
        <div className="flex justify-between gap-4">
          <dt className="text-ink-600">Name</dt>
          <dd className="text-right font-medium text-ink-900">{customer.name || '—'}</dd>
        </div>
        {customer.phone && (
          <div className="flex justify-between gap-4">
            <dt className="text-ink-600">Phone</dt>
            <dd className="text-right font-medium">
              <a href={`tel:${customer.phone}`} className="rounded text-brand-700 underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600">
                {customer.phone}
              </a>
            </dd>
          </div>
        )}
        {customer.pickup_address && (
          <div>
            <dt className="text-ink-600">Pickup address</dt>
            <dd className="font-medium text-ink-900">{customer.pickup_address}</dd>
          </div>
        )}
        {customer.drop_address && (
          <div>
            <dt className="text-ink-600">Drop address</dt>
            <dd className="font-medium text-ink-900">{customer.drop_address}</dd>
          </div>
        )}
      </dl>
    </section>
  );
}

// TRACE: booking detail → shows the assigned driver/vehicle and the button to add or change them → card.
//        Preconditions: detail loaded. Postconditions: the button appears only while the trip is assigned/active
//        (vendor_assigned, driver_en_route, trip_started); label is "Add driver & vehicle" when details are missing,
//        else "Change driver/vehicle". Edge cases: no assignment row (prompts to add), trip completed/cancelled (no button).
function AssignmentCard({ detail, onOpen }: { detail: VendorBookingDetail; onOpen: () => void }) {
  const a: BookingAssignment | null = detail.assignment;
  const canEdit = COMMITTED.includes(detail.status);
  const missing = !a || a.needs_details;
  return (
    <section aria-labelledby="assign-heading" className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
      <h2 id="assign-heading" className="text-base font-semibold text-ink-900">
        Driver & vehicle
      </h2>
      {a && (a.driver_name || a.vehicle_registration) ? (
        <dl className="mt-3 space-y-2 text-sm">
          <div className="flex justify-between gap-4">
            <dt className="text-ink-600">Driver</dt>
            <dd className="text-right font-medium text-ink-900">{a.driver_name || 'Not added yet'}</dd>
          </div>
          {a.driver_phone && (
            <div className="flex justify-between gap-4">
              <dt className="text-ink-600">Driver phone</dt>
              <dd className="text-right font-medium text-ink-900">{a.driver_phone}</dd>
            </div>
          )}
          <div className="flex justify-between gap-4">
            <dt className="text-ink-600">Vehicle</dt>
            <dd className="text-right font-medium text-ink-900">{[a.vehicle_model, a.vehicle_registration].filter(Boolean).join(' · ') || 'Not added yet'}</dd>
          </div>
        </dl>
      ) : (
        <p className="mt-2 text-sm text-ink-600">No driver or vehicle has been added for this trip yet.</p>
      )}
      {missing && canEdit && <p className="mt-2 text-sm text-warning-600">The customer needs these details before pickup.</p>}
      {canEdit && (
        <div className="mt-3">
          <Button variant={missing ? 'primary' : 'secondary'} size="sm" onClick={onOpen}>
            {missing ? 'Add driver & vehicle' : 'Change driver/vehicle'}
          </Button>
        </div>
      )}
    </section>
  );
}

// TRACE: assignment sheet → loads options for this booking (own assignment excluded from conflicts), picks driver and
//        vehicle, requires a reason when changing an existing assignment, POSTs replace-assignment → onSaved().
//        Preconditions: booking is assigned to this vendor. Postconditions: options load once (stale ignored); unavailable
//        entries are disabled with the reason shown; selection and reason kept on failure; submit disabled while
//        pending. Edge cases: load failure (retry), no vehicles/drivers (empty state with link), vehicle without a
//        registration (disabled), missing selection or reason (inline message), server refusal (nothing changed,
//        unavailable entity) inline + toast.
function AssignForm({ bookingId, current, onSaved, onCancel }: { bookingId: number; current: BookingAssignment | null; onSaved: () => void; onCancel: () => void }) {
  const toast = useToast();
  const guard = useRequestGuard();
  const changing = current !== null && !current.needs_details;
  const [options, setOptions] = useState<SelectionOptions | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [driverId, setDriverId] = useState(0);
  const [vehicleId, setVehicleId] = useState(0);
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // TRACE: mount / retry → GET options → stores them. Preconditions: none. Postconditions: newest response wins.
  //        Edge cases: failure (error + retry), stale (ignored).
  const load = useCallback(async () => {
    const id = guard.begin();
    setLoading(true);
    setLoadError(null);
    try {
      const res = await getBookingOptions(bookingId);
      if (guard.isCurrent(id)) setOptions(res);
    } catch (err) {
      if (guard.isCurrent(id)) setLoadError(messageOf(err, 'Could not load your drivers and vehicles.'));
    } finally {
      if (guard.isCurrent(id)) setLoading(false);
    }
  }, [bookingId, guard]);

  // TRACE: mount → loads the options → void.
  useEffect(() => {
    void load();
  }, [load]);

  // TRACE: retry button → reloads options → void.
  const retry = () => {
    void load();
  };
  // TRACE: driver radio → stores id → void.
  const pickDriver = (id: number) => setDriverId(id);
  // TRACE: vehicle radio → stores id → void.
  const pickVehicle = (id: number) => setVehicleId(id);
  // TRACE: reason input → stores text → void.
  const changeReason = (e: ChangeEvent<HTMLTextAreaElement>) => setReason(e.target.value);

  // TRACE: form submit → validates choice (+ reason when changing) → POST replace-assignment → toast + onSaved.
  //        Preconditions: not already saving. Postconditions: inputs kept on failure. Edge cases: nothing chosen, reason
  //        empty while changing, server refusal.
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    if (!driverId || !vehicleId) {
      setFormError('Choose both a driver and a vehicle.');
      return;
    }
    if (changing && reason.trim() === '') {
      setFormError('Tell us why you are changing the driver or vehicle.');
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      const res = await replaceAssignment(bookingId, { driver_id: driverId, vehicle_id: vehicleId, reason: reason.trim() });
      toast.show(res.message, 'success');
      onSaved();
    } catch (err) {
      const msg = messageOf(err, 'Could not save the driver and vehicle.');
      setFormError(msg);
      toast.show(msg, 'error');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="space-y-3" aria-busy="true" aria-label="Loading drivers and vehicles">
        <Skeleton className="h-16 w-full rounded-xl" />
        <Skeleton className="h-16 w-full rounded-xl" />
      </div>
    );
  }
  if (loadError) return <ErrorBanner message={loadError} onRetry={retry} />;
  if (!options || (options.drivers.length === 0 && options.vehicles.length === 0)) {
    return (
      <EmptyState
        title="No active drivers or vehicles"
        description="Add or reactivate a driver and a vehicle in My fleet first."
        action={
          <Link to="/vendor/fleet">
            <Button variant="secondary">Open My fleet</Button>
          </Link>
        }
      />
    );
  }

  return (
    <form onSubmit={submit} className="space-y-5" noValidate>
      <fieldset disabled={saving} className="min-w-0">
        <legend className="text-sm font-semibold text-ink-900">Driver</legend>
        {options.drivers.length === 0 ? (
          <p className="mt-2 text-sm text-ink-600">You have no active drivers. Add one in My fleet.</p>
        ) : (
          <ul className="mt-2 space-y-2">
            {options.drivers.map((d) => (
              <OptionRow
                key={d.id}
                group="assign-driver"
                id={d.id}
                title={d.name}
                detail={[d.mobile, d.rating > 0 ? `Rating ${d.rating.toFixed(1)}` : ''].filter(Boolean).join(' · ')}
                preferred={d.preferred}
                available={d.available}
                reason={d.reason}
                selected={driverId === d.id}
                onPick={pickDriver}
              />
            ))}
          </ul>
        )}
      </fieldset>
      <fieldset disabled={saving} className="min-w-0">
        <legend className="text-sm font-semibold text-ink-900">Vehicle</legend>
        {options.vehicles.length === 0 ? (
          <p className="mt-2 text-sm text-ink-600">You have no active vehicles. Add one in My fleet.</p>
        ) : (
          <ul className="mt-2 space-y-2">
            {options.vehicles.map((v) => (
              <OptionRow
                key={v.id}
                group="assign-vehicle"
                id={v.id}
                title={v.registration_number || 'Registration number missing'}
                detail={[v.make_model, `${v.seating_capacity} seats`].filter(Boolean).join(' · ')}
                preferred={v.preferred}
                available={v.available && v.registration_number !== ''}
                reason={v.registration_number === '' ? 'Add the registration number in My fleet first.' : v.reason}
                mismatch={v.type_mismatch}
                selected={vehicleId === v.id}
                onPick={pickVehicle}
              />
            ))}
          </ul>
        )}
      </fieldset>
      {changing && (
        <FormField label="Reason for the change" htmlFor="assign-reason" hint={`The customer and ${brand().name} are told about the change.`}>
          <textarea id="assign-reason" rows={3} maxLength={255} value={reason} onChange={changeReason} disabled={saving} required className={INPUT_CLASS} />
        </FormField>
      )}
      {formError && (
        <p role="alert" className="text-sm font-medium text-danger-600">
          {formError}
        </p>
      )}
      <div className="flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
        <Button type="button" variant="secondary" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit" loading={saving} disabled={!driverId || !vehicleId}>
          {changing ? 'Change driver & vehicle' : 'Save driver & vehicle'}
        </Button>
      </div>
    </form>
  );
}

// TRACE: booking detail → shows the next-status button for an active trip (en route → start with pickup OTP → complete)
//        and calls the same advance endpoint as the trip history page → onAdvanced().
//        Preconditions: detail.status is in NEXT_STATUS. Postconditions: OTP required (input labelled) before starting the
//        trip; button disabled while pending; OTP cleared after success and kept after failure. Edge cases: wrong OTP or
//        rule violation (server message inline + toast), completing the trip (balance reminder in the description).
function StatusActions({ detail, onAdvanced }: { detail: VendorBookingDetail; onAdvanced: () => void }) {
  const toast = useToast();
  const [otp, setOtp] = useState('');
  const [pending, setPending] = useState(false);
  const [actionError, setActionError] = useState<string | null>(null);
  const next = NEXT_STATUS[detail.status];
  const needsOtp = detail.status === 'driver_en_route';

  // TRACE: OTP input change → stores the digits text → void.
  const changeOtp = (e: ChangeEvent<HTMLInputElement>) => setOtp(e.target.value);

  // TRACE: button click → POST advance with the OTP when required → toast, clear OTP, reload. Preconditions: next status
  //        exists, not already pending. Postconditions: button spinner while pending. Edge cases: missing OTP (inline
  //        message), server error (inline + toast, OTP kept).
  const advance = async (e: FormEvent) => {
    e.preventDefault();
    if (!next || pending) return;
    if (needsOtp && otp.trim() === '') {
      setActionError('Enter the pickup OTP the customer gives you.');
      return;
    }
    setPending(true);
    setActionError(null);
    try {
      const res = await advanceVendorTrip(detail.id, next, otp.trim());
      toast.show(res.message || 'Trip updated.', 'success');
      setOtp('');
      onAdvanced();
    } catch (err) {
      const msg = messageOf(err, 'Could not update this trip.');
      setActionError(msg);
      toast.show(msg, 'error');
    } finally {
      setPending(false);
    }
  };

  return (
    <section aria-labelledby="advance-heading" className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
      <h2 id="advance-heading" className="text-base font-semibold text-ink-900">
        Trip progress
      </h2>
      <form onSubmit={advance} className="mt-3 space-y-3" noValidate>
        {needsOtp && (
          <FormField label="Pickup OTP" htmlFor="pickup-otp" hint="Ask the customer for the OTP shown in their booking.">
            <input id="pickup-otp" type="text" inputMode="numeric" autoComplete="one-time-code" value={otp} onChange={changeOtp} disabled={pending} className={`${INPUT_CLASS} sm:max-w-[10rem]`} />
          </FormField>
        )}
        {actionError && (
          <p role="alert" className="text-sm font-medium text-danger-600">
            {actionError}
          </p>
        )}
        <Button type="submit" loading={pending}>
          {NEXT_STATUS_LABEL[detail.status]}
        </Button>
      </form>
    </section>
  );
}

// TRACE: booking detail (completed, not yet rated by this vendor) → collects 1-5 stars for communication, reliability and
//        payment behaviour plus an optional review → POST rate-client → onRated(). Preconditions: trip completed.
//        Postconditions: at least one category must be rated; submit disabled while pending; scores/review kept on
//        failure and reset after success (the form then disappears because the API reports vendor_rated).
//        Edge cases: no score chosen (inline message), unrated categories are simply omitted, server refusal
//        (already rated, not completed) inline + toast.
function RateClientForm({ bookingId, onRated }: { bookingId: number; onRated: () => void }) {
  const toast = useToast();
  const [scores, setScores] = useState<Record<string, number>>({});
  const [review, setReview] = useState('');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // TRACE: star choice in one category → stores the score → void.
  const setScore = (key: string, score: number) => setScores((prev) => ({ ...prev, [key]: score }));
  // TRACE: review textarea change → stores text → void.
  const changeReview = (e: ChangeEvent<HTMLTextAreaElement>) => setReview(e.target.value);

  // TRACE: form submit → requires at least one score → POST rate-client with the chosen scores → toast, reset, onRated.
  //        Preconditions: not already saving. Postconditions: inputs kept on failure. Edge cases: no scores, server error.
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    if (Object.keys(scores).length === 0) {
      setFormError('Rate at least one category.');
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      const res = await rateClient(bookingId, scores, review.trim());
      toast.show(res.message || 'Thanks for rating the customer.', 'success');
      setScores({});
      setReview('');
      onRated();
    } catch (err) {
      const msg = messageOf(err, 'Could not save your rating.');
      setFormError(msg);
      toast.show(msg, 'error');
    } finally {
      setSaving(false);
    }
  };

  return (
    <section aria-labelledby="rate-heading" className={`${DATA_CARD_CLASS} p-4 sm:p-5 lg:col-span-2`}>
      <h2 id="rate-heading" className="text-base font-semibold text-ink-900">
        Rate the customer
      </h2>
      <form onSubmit={submit} className="mt-3 space-y-4" noValidate>
        <div className="grid gap-4 sm:grid-cols-3">
          {RATING_CATEGORIES.map((c) => (
            <CategoryRating key={c.key} categoryKey={c.key} label={c.label} value={scores[c.key] ?? 0} disabled={saving} onScore={setScore} />
          ))}
        </div>
        <FormField label="Comments (optional)" htmlFor="rate-review">
          <textarea id="rate-review" rows={3} maxLength={1000} value={review} onChange={changeReview} disabled={saving} className={INPUT_CLASS} />
        </FormField>
        {formError && (
          <p role="alert" className="text-sm font-medium text-danger-600">
            {formError}
          </p>
        )}
        <Button type="submit" loading={saving}>
          Submit rating
        </Button>
      </form>
    </section>
  );
}

// TRACE: RateClientForm → renders one category's star input bound to the category key → onScore(key, score).
//        Preconditions: unique categoryKey. Postconditions: radio group name is unique per category. Edge cases: value 0.
function CategoryRating({
  categoryKey,
  label,
  value,
  disabled,
  onScore,
}: {
  categoryKey: string;
  label: string;
  value: number;
  disabled: boolean;
  onScore: (key: string, score: number) => void;
}) {
  // TRACE: star radio change → reports the score for this category → void.
  const change = (score: number) => onScore(categoryKey, score);
  return <StarInput name={`rate-${categoryKey}`} legend={label} value={value} onChange={change} disabled={disabled} />;
}
