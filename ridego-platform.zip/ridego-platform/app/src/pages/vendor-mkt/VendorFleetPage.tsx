import { useCallback, useEffect, useRef, useState, type ChangeEvent, type FormEvent, type KeyboardEvent } from 'react';
import { DOC_TYPE_LABELS, docNeedsExpiry, docIsPhoto } from '../../lib/doc-types';
import { Link } from 'react-router-dom';
import { ApiError, fetchVendorDocFileUrl, getCities, getVehicles } from '../../lib/api';
import {
  createBranch,
  createFleetDriver,
  createFleetVehicle,
  createUnavailability,
  deleteBranch,
  deleteFleetDriver,
  deleteFleetVehicle,
  deleteUnavailability,
  getFleetDocs,
  getVendorFleet,
  listUnavailability,
  setVendorType,
  updateBranch,
  updateFleetDriver,
  updateFleetVehicle,
  uploadFleetDoc,
  type DocValidity,
  type DriverInput,
  type EntityKind,
  type FleetDoc,
  type FleetDriver,
  type FleetOverview,
  type FleetVehicle,
  type LiveStatus,
  type UnavailabilityBlock,
  type VehicleInput,
  type VendorBranch,
} from '../../lib/api-vendor-marketplace';
import { createDriverLogin } from '../../lib/api-team';
import type { City, Vehicle } from '../../types/api';
import { useToast } from '../../context/ToastContext';
import { BottomSheet } from '../../components/ui/BottomSheet';
import { Button } from '../../components/ui/Button';
import { ConfirmDialog } from '../../components/ui/ConfirmDialog';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import {
  FormField,
  formatDateTime,
  INPUT_CLASS,
  LINK_BUTTON_CLASS,
  ToneBadge,
  useRequestGuard,
  useSheet,
  type Tone,
} from './vendor-mkt-shared';
import { DATA_CARD_CLASS } from '../../components/ui/Zone';

type TabKey = 'vehicles' | 'drivers' | 'branches' | 'availability';

interface DeleteTarget {
  kind: 'vehicle' | 'driver' | 'branch' | 'block';
  id: number;
  label: string;
}

interface DocsTarget {
  kind: EntityKind;
  id: number;
  label: string;
}

interface Catalog {
  vehicleTypes: Vehicle[];
  cities: City[];
}

interface Notice {
  tone: 'success' | 'warning';
  text: string;
}

const STATUS_TONE: Record<string, Tone> = { active: 'success', inactive: 'neutral', maintenance: 'warning' };
const STATUS_LABEL: Record<string, string> = { active: 'Active', inactive: 'Inactive', maintenance: 'Under maintenance' };
const LIVE_TONE: Record<LiveStatus, Tone> = { available: 'success', on_trip: 'brand', unavailable: 'warning' };
const LIVE_LABEL: Record<LiveStatus, string> = {
  available: 'Available now',
  on_trip: 'On a trip',
  unavailable: 'Unavailable now',
};
const VALIDITY_TONE: Record<DocValidity, Tone> = { valid: 'success', expiring_soon: 'warning', expired: 'danger', no_expiry: 'neutral' };
const VALIDITY_LABEL: Record<DocValidity, string> = {
  valid: 'Valid',
  expiring_soon: 'Expiring soon',
  expired: 'Expired',
  no_expiry: 'No expiry date',
};
const REVIEW_TONE: Record<string, Tone> = { verified: 'success', pending: 'warning', rejected: 'danger' };
const REVIEW_LABEL: Record<string, string> = { verified: 'Approved', pending: 'Pending review', rejected: 'Rejected' };
const DOC_LABEL = DOC_TYPE_LABELS;
const FLEET_SKELETONS = ['fleet-a', 'fleet-b', 'fleet-c'];
const FALLBACK_MAX_MB = 5;

// TRACE: any error catch → turns an unknown thrown value into the message to show → string.
//        Preconditions: none. Postconditions: ApiError text is preserved verbatim. Edge cases: non-ApiError → fallback.
function messageOf(err: unknown, fallback: string): string {
  return err instanceof ApiError ? err.message : fallback;
}

// TRACE: forms → strips a plate to A-Z0-9 upper-case the way the server does → normalised text.
//        Preconditions: none. Postconditions: only letters/digits. Edge cases: empty input → ''.
function normalisePlate(value: string): string {
  return value.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
}

// TRACE: entity name lookups → builds the label used in confirm dialogs and headings for a vehicle.
//        Preconditions: vehicle row. Postconditions: registration when present, else the make/model, else "vehicle #id".
//        Edge cases: individual vendor's auto-created vehicle with a blank plate.
function vehicleLabel(v: FleetVehicle): string {
  return v.registration_number || v.make_model || `vehicle #${v.id}`;
}

// TRACE: fleet page route /app/vendor/fleet → loads fleet + catalogs, renders tabs (Vehicles/Drivers/Branches/
//        Availability), CRUD sheets, document panels, delete confirmations, upgrade flow for individual vendors →
//        every mutation re-fetches server state. Preconditions: vendor session. Postconditions: stale loads ignored;
//        sheets restore focus on close. Edge cases: not a vendor (message), load failure (retry), empty fleet, individual
//        vendor (no add/delete/branches; upgrade card), delete resulting in deactivation (notice shows server text).
export function VendorFleetPage() {
  const toast = useToast();
  const guard = useRequestGuard();
  const [overview, setOverview] = useState<FleetOverview | null>(null);
  const [catalog, setCatalog] = useState<Catalog>({ vehicleTypes: [], cities: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notVendor, setNotVendor] = useState(false);
  const [version, setVersion] = useState(0);
  const [tab, setTab] = useState<TabKey>('vehicles');
  const [notice, setNotice] = useState<Notice | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<DeleteTarget | null>(null);
  const [deleting, setDeleting] = useState(false);
  const deletingRef = useRef(false);
  const upgradingRef = useRef(false);
  const [deleteError, setDeleteError] = useState<string | null>(null);
  const [upgradeOpen, setUpgradeOpen] = useState(false);
  const [upgrading, setUpgrading] = useState(false);
  const [upgradeError, setUpgradeError] = useState<string | null>(null);
  const vehicleSheet = useSheet<FleetVehicle | 'new'>();
  const driverSheet = useSheet<FleetDriver | 'new'>();
  const branchSheet = useSheet<VendorBranch | 'new'>();
  const docsSheet = useSheet<DocsTarget>();
  const loginSheet = useSheet<FleetDriver>();

  // TRACE: mount / after every mutation → fetches fleet, vehicle types and cities in parallel → stores them.
  //        Preconditions: silent=true keeps existing content on screen. Postconditions: only the newest request writes
  //        state. Edge cases: not_a_vendor/403 (notVendor), other failure (error text + retry), unmounted (ignored).
  const load = useCallback(
    async (silent: boolean) => {
      const id = guard.begin();
      if (!silent) setLoading(true);
      setError(null);
      try {
        const [fleet, vehicleTypes, cities] = await Promise.all([getVendorFleet(), getVehicles(), getCities()]);
        if (!guard.isCurrent(id)) return;
        setOverview(fleet);
        setCatalog({ vehicleTypes, cities });
        setNotVendor(false);
        setVersion((v) => v + 1);
      } catch (err) {
        if (!guard.isCurrent(id)) return;
        if (err instanceof ApiError && (err.status === 403 || err.code === 'not_a_vendor')) {
          setNotVendor(true);
        } else {
          setError(messageOf(err, 'Could not load your fleet. Please try again.'));
        }
      } finally {
        if (guard.isCurrent(id)) setLoading(false);
      }
    },
    [guard]
  );

  // TRACE: mount → runs the first load with the spinner → void. Edge cases: unmount mid-request (ignored by the guard).
  useEffect(() => {
    void load(false);
  }, [load]);

  // TRACE: retry button on the error banner → reloads with the spinner → void. Edge cases: repeated clicks (latest wins).
  const retry = useCallback(() => {
    void load(false);
  }, [load]);

  // TRACE: sheet form saved → closes the sheet and re-fetches the fleet → void.
  //        Preconditions: mutation already succeeded. Postconditions: list shows server state. Edge cases: none.
  const afterSave = useCallback(
    (hide: () => void) => {
      hide();
      void load(true);
    },
    [load]
  );

  // TRACE: vehicle form success → closes vehicle sheet, reloads → void.
  const vehicleSaved = useCallback(() => afterSave(vehicleSheet.hide), [afterSave, vehicleSheet.hide]);
  // TRACE: driver form success → closes driver sheet, reloads → void.
  const driverSaved = useCallback(() => afterSave(driverSheet.hide), [afterSave, driverSheet.hide]);
  // TRACE: branch form success → closes branch sheet, reloads → void.
  const branchSaved = useCallback(() => afterSave(branchSheet.hide), [afterSave, branchSheet.hide]);

  // TRACE: Delete button on any row → stores the delete target and clears earlier dialog errors → opens the dialog.
  //        Preconditions: fleet vendor. Postconditions: dialog names the item. Edge cases: none.
  const askDelete = useCallback((target: DeleteTarget) => {
    setDeleteError(null);
    setDeleteTarget(target);
  }, []);

  // TRACE: dialog Cancel/Escape → closes the delete dialog unless a delete is in flight → void.
  //        Edge cases: pending request (ignored so the result is not lost).
  const cancelDelete = useCallback(() => {
    if (!deletingRef.current) setDeleteTarget(null);
  }, []);

  // TRACE: dialog Confirm → calls the matching DELETE endpoint → shows the server message (incl. "deactivated instead
  //        of deleted") as toast + persistent notice → re-fetches. Preconditions: deleteTarget set. Postconditions:
  //        button disabled while pending (no double submit); dialog stays open with the error on failure.
  //        Edge cases: deactivation result (warning notice), API failure (inline error, nothing changes).
  const confirmDelete = useCallback(async () => {
    if (!deleteTarget || deletingRef.current) return;
    deletingRef.current = true;
    setDeleting(true);
    setDeleteError(null);
    try {
      let message: string;
      let deactivated = false;
      if (deleteTarget.kind === 'vehicle') {
        const r = await deleteFleetVehicle(deleteTarget.id);
        message = r.message;
        deactivated = r.mode === 'deactivated';
      } else if (deleteTarget.kind === 'driver') {
        const r = await deleteFleetDriver(deleteTarget.id);
        message = r.message;
        deactivated = r.mode === 'deactivated';
      } else if (deleteTarget.kind === 'branch') {
        message = (await deleteBranch(deleteTarget.id)).message;
      } else {
        message = (await deleteUnavailability(deleteTarget.id)).message;
      }
      setNotice({ tone: deactivated ? 'warning' : 'success', text: `${deleteTarget.label}: ${message}` });
      toast.show(message, deactivated ? 'info' : 'success');
      setDeleteTarget(null);
      await load(true);
    } catch (err) {
      setDeleteError(messageOf(err, 'Could not delete. Please try again.'));
    } finally {
      deletingRef.current = false;
      setDeleting(false);
    }
  }, [deleteTarget, load, toast]);

  // TRACE: "Upgrade to fleet" button → opens the confirm dialog with a cleared error → void. Edge cases: none.
  const openUpgrade = useCallback(() => {
    setUpgradeError(null);
    setUpgradeOpen(true);
  }, []);

  // TRACE: upgrade dialog Cancel/Escape → closes it unless the request is in flight → void.
  const closeUpgrade = useCallback(() => {
    if (!upgradingRef.current) setUpgradeOpen(false);
  }, []);

  // TRACE: upgrade dialog Confirm → POST /vendor/type {type:'fleet'} → toast + reload so the page switches to fleet mode.
  //        Preconditions: individual vendor. Postconditions: button disabled while pending. Edge cases: impersonation
  //        block or server refusal (inline error, dialog stays open).
  const confirmUpgrade = useCallback(async () => {
    if (upgradingRef.current) return;
    upgradingRef.current = true;
    setUpgrading(true);
    setUpgradeError(null);
    try {
      const r = await setVendorType('fleet');
      toast.show(r.message, 'success');
      setUpgradeOpen(false);
      await load(true);
    } catch (err) {
      setUpgradeError(messageOf(err, 'Could not upgrade your account. Please try again.'));
    } finally {
      upgradingRef.current = false;
      setUpgrading(false);
    }
  }, [load, toast]);

  // TRACE: notice dismiss button → clears the notice → void.
  const dismissNotice = useCallback(() => setNotice(null), []);

  // TRACE: row "Documents" buttons → opens the docs sheet for that entity → void. Edge cases: none.
  const openDocs = docsSheet.show;

  const isFleet = overview?.vendor_type === 'fleet';
  const tabs: { key: TabKey; label: string }[] = [
    { key: 'vehicles', label: 'Vehicles' },
    { key: 'drivers', label: 'Drivers' },
    ...(isFleet ? [{ key: 'branches' as TabKey, label: 'Branches' }] : []),
    { key: 'availability', label: 'Availability' },
  ];
  const activeTab: TabKey = tabs.some((t) => t.key === tab) ? tab : 'vehicles';

  if (notVendor) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <div className="rounded-2xl border border-ink-100 bg-ink-50/60 p-10">
          <h1 className="text-xl font-bold text-ink-900">Vendor access required</h1>
          <p className="mt-2 text-ink-600">The fleet page is only available to registered driver-partners.</p>
          <div className="mt-6">
            <Link to="/vendor/dashboard">
              <Button>Go to vendor dashboard</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-10 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">{isFleet ? 'My fleet' : 'My vehicle & driver'}</h1>
          <p className="text-sm text-ink-600">
            {isFleet ? 'Vehicles, drivers, documents and the times they are not available.' : 'Your vehicle, driver profile, documents and the times you are not available.'}
          </p>
        </div>
        <Link to="/vendor/dashboard">
          <Button variant="secondary" size="sm">
            Back to dashboard
          </Button>
        </Link>
      </div>

      {loading && (
        <div className="mt-6 space-y-3" aria-busy="true" aria-label="Loading your fleet">
          <Skeleton className="h-10 w-full rounded-lg" />
          {FLEET_SKELETONS.map((k) => (
            <Skeleton key={k} className="h-24 w-full rounded-xl" />
          ))}
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={retry} />
        </div>
      )}

      {!loading && !error && overview && (
        <>
          {notice && (
            <div
              role="status"
              className={`mt-6 flex items-start justify-between gap-3 rounded-lg border px-4 py-3 text-sm ${
                notice.tone === 'warning'
                  ? 'border-warning-500/30 bg-warning-50 text-warning-600'
                  : 'border-success-500/30 bg-success-50 text-success-600'
              }`}
            >
              <span>{notice.text}</span>
              <button
                type="button"
                onClick={dismissNotice}
                aria-label="Dismiss notice"
                className="shrink-0 rounded-md p-1 hover:bg-white/60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
              >
                <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          )}

          {overview && overview.drivers.some((d) => d.status === 'active' && !d.profile_complete) && (
            <div role="alert" className="rounded-xl border border-warning-500/30 bg-warning-50 p-4 text-sm text-warning-700">
              {overview.drivers.filter((d) => d.status === 'active' && !d.profile_complete).length} driver profile(s) are incomplete. Complete them in the Drivers tab so you can accept trips, and so the driver can be traced if anything goes wrong on a trip.
            </div>
          )}

          {!isFleet && <UpgradeCard onUpgrade={openUpgrade} />}

          <FleetTabs tabs={tabs} active={activeTab} onChange={setTab} />

          <div id="fleet-panel" role="tabpanel" aria-labelledby={`fleet-tab-${activeTab}`} className="mt-6">
            {activeTab === 'vehicles' && (
              <VehiclesPanel
                overview={overview}
                catalog={catalog}
                isFleet={isFleet}
                onAdd={vehicleSheet.show}
                onEdit={vehicleSheet.show}
                onDocs={openDocs}
                onDelete={askDelete}
              />
            )}
            {activeTab === 'drivers' && (
              <DriversPanel
                overview={overview}
                isFleet={isFleet}
                onAdd={driverSheet.show}
                onEdit={driverSheet.show}
                onDocs={openDocs}
                onLogin={loginSheet.show}
                onDelete={askDelete}
              />
            )}
            {activeTab === 'branches' && isFleet && (
              <BranchesPanel overview={overview} onAdd={branchSheet.show} onEdit={branchSheet.show} onDelete={askDelete} />
            )}
            {activeTab === 'availability' && <AvailabilityPanel overview={overview} version={version} onDelete={askDelete} />}
          </div>
        </>
      )}

      <BottomSheet open={vehicleSheet.open} title={vehicleSheet.target && vehicleSheet.target !== 'new' ? 'Edit vehicle' : 'Add vehicle'} onClose={vehicleSheet.hide}>
        {vehicleSheet.target && overview && (
          <VehicleForm
            key={vehicleSheet.nonce}
            initial={vehicleSheet.target === 'new' ? null : vehicleSheet.target}
            vehicleTypes={catalog.vehicleTypes}
            branches={overview.branches}
            showBranch={isFleet}
            onSaved={vehicleSaved}
            onCancel={vehicleSheet.hide}
          />
        )}
      </BottomSheet>

      <BottomSheet open={driverSheet.open} title={driverSheet.target && driverSheet.target !== 'new' ? 'Edit driver' : 'Add driver'} onClose={driverSheet.hide}>
        {driverSheet.target && overview && (
          <DriverForm
            key={driverSheet.nonce}
            initial={driverSheet.target === 'new' ? null : driverSheet.target}
            branches={overview.branches}
            showBranch={isFleet}
            onSaved={driverSaved}
            onCancel={driverSheet.hide}
          />
        )}
      </BottomSheet>

      <BottomSheet open={branchSheet.open} title={branchSheet.target && branchSheet.target !== 'new' ? 'Edit branch' : 'Add branch'} onClose={branchSheet.hide}>
        {branchSheet.target && (
          <BranchForm
            key={branchSheet.nonce}
            initial={branchSheet.target === 'new' ? null : branchSheet.target}
            cities={catalog.cities}
            onSaved={branchSaved}
            onCancel={branchSheet.hide}
          />
        )}
      </BottomSheet>

      <BottomSheet open={docsSheet.open} title={docsSheet.target ? `Documents: ${docsSheet.target.label}` : 'Documents'} onClose={docsSheet.hide}>
        {docsSheet.target && <DocsPanel key={docsSheet.nonce} kind={docsSheet.target.kind} entityId={docsSheet.target.id} />}
      </BottomSheet>

      <BottomSheet open={loginSheet.open} title={loginSheet.target ? `Login for ${loginSheet.target.name}` : 'Driver login'} onClose={loginSheet.hide}>
        {loginSheet.target && <DriverLoginForm key={loginSheet.nonce} driver={loginSheet.target} onSaved={driverSaved} onCancel={loginSheet.hide} hide={loginSheet.hide} />}
      </BottomSheet>

      <ConfirmDialog
        open={deleteTarget !== null}
        title={deleteTarget ? `Delete ${deleteTarget.label}?` : 'Delete?'}
        description={
          deleteTarget?.kind === 'vehicle' || deleteTarget?.kind === 'driver'
            ? 'If it already has trip history it is deactivated instead of deleted, so past bookings keep their details.'
            : deleteTarget?.kind === 'branch'
              ? 'Vehicles and drivers at this branch are kept and simply lose their branch.'
              : 'The time will become bookable again.'
        }
        confirmLabel="Delete"
        confirmVariant="danger"
        loading={deleting}
        onConfirm={confirmDelete}
        onCancel={cancelDelete}
      >
        {deleteError && (
          <p role="alert" className="mt-3 text-sm font-medium text-danger-600">
            {deleteError}
          </p>
        )}
      </ConfirmDialog>

      <ConfirmDialog
        open={upgradeOpen}
        title="Upgrade to a fleet account?"
        description="You will be able to add more vehicles and drivers and branches. Your current vehicle and driver stay as they are. You can switch back later only while you have one active vehicle and one active driver."
        confirmLabel="Upgrade to fleet"
        loading={upgrading}
        onConfirm={confirmUpgrade}
        onCancel={closeUpgrade}
      >
        {upgradeError && (
          <p role="alert" className="mt-3 text-sm font-medium text-danger-600">
            {upgradeError}
          </p>
        )}
      </ConfirmDialog>
    </div>
  );
}

// TRACE: fleet page for an individual vendor → explains the difference and offers the upgrade button → card.
//        Preconditions: vendor_type individual. Postconditions: button calls onUpgrade only (dialog lives in the page).
//        Edge cases: none.
function UpgradeCard({ onUpgrade }: { onUpgrade: () => void }) {
  return (
    <section aria-labelledby="upgrade-heading" className="mt-6 rounded-xl border border-brand-200 bg-brand-50 p-4 sm:p-5">
      <h2 id="upgrade-heading" className="text-base font-semibold text-ink-900">
        Upgrade to fleet
      </h2>
      <p className="mt-1 text-sm text-ink-700">
        Your account is an individual account: one vehicle and one driver, used automatically when you show interest in a
        lead. A fleet account lets you register several vehicles and drivers, add branches, and choose the right driver and
        vehicle for each trip.
      </p>
      <div className="mt-3">
        <Button size="sm" onClick={onUpgrade}>
          Upgrade to fleet
        </Button>
      </div>
    </section>
  );
}

// TRACE: fleet page → renders the tab strip with roving tabindex and Left/Right/Home/End keys → onChange(key).
//        Preconditions: tabs non-empty, active is one of them. Postconditions: exactly one tab is tabbable and
//        aria-selected. Edge cases: arrow at either end wraps.
function FleetTabs({ tabs, active, onChange }: { tabs: { key: TabKey; label: string }[]; active: TabKey; onChange: (k: TabKey) => void }) {
  const refs = useRef<Record<string, HTMLButtonElement | null>>({});

  // TRACE: tab mount → returns the ref callback that stores that tab's button for keyboard focus → void.
  //        Preconditions: key unique. Postconditions: refs map stays current (cleared on unmount by null). Edge cases: none.
  const register = (key: string) => (el: HTMLButtonElement | null) => {
    refs.current[key] = el;
  };

  // TRACE: keydown on a tab → moves selection and focus by arrow/Home/End → void. Edge cases: other keys ignored.
  const onKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    const idx = tabs.findIndex((t) => t.key === active);
    let next = idx;
    if (e.key === 'ArrowRight') next = (idx + 1) % tabs.length;
    else if (e.key === 'ArrowLeft') next = (idx - 1 + tabs.length) % tabs.length;
    else if (e.key === 'Home') next = 0;
    else if (e.key === 'End') next = tabs.length - 1;
    else return;
    e.preventDefault();
    onChange(tabs[next].key);
    refs.current[tabs[next].key]?.focus();
  };

  return (
    <div className="mt-6 flex gap-1 overflow-x-auto border-b border-ink-100" role="tablist" aria-label="Fleet sections" onKeyDown={onKeyDown}>
      {tabs.map((t) => (
        <FleetTab
          key={t.key}
          tabKey={t.key}
          label={t.label}
          selected={active === t.key}
          onSelect={onChange}
          register={register(t.key)}
        />
      ))}
    </div>
  );
}

// TRACE: FleetTabs → renders one tab button → onSelect(key) on click.
//        Preconditions: unique tabKey. Postconditions: visible focus ring, tabbable only when selected.
//        Edge cases: none.
function FleetTab({
  tabKey,
  label,
  selected,
  onSelect,
  register,
}: {
  tabKey: TabKey;
  label: string;
  selected: boolean;
  onSelect: (k: TabKey) => void;
  register: (el: HTMLButtonElement | null) => void;
}) {
  // TRACE: click → selects this tab → void. Edge cases: none.
  const click = () => onSelect(tabKey);
  return (
    <button
      ref={register}
      id={`fleet-tab-${tabKey}`}
      type="button"
      role="tab"
      aria-selected={selected}
      aria-controls="fleet-panel"
      tabIndex={selected ? 0 : -1}
      onClick={click}
      className={`shrink-0 whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 ${
        selected ? 'border-brand-600 text-brand-700' : 'border-transparent text-ink-600 hover:text-ink-900'
      }`}
    >
      {label}
    </button>
  );
}

// TRACE: vehicles tab → lists vehicles with status + live status and row actions; header offers "Add vehicle" for
//        fleet vendors only → panel. Preconditions: overview loaded. Postconditions: individual vendors see edit and
//        documents only. Edge cases: empty list (empty state), unknown type/branch (dash).
function VehiclesPanel({
  overview,
  catalog,
  isFleet,
  onAdd,
  onEdit,
  onDocs,
  onDelete,
}: {
  overview: FleetOverview;
  catalog: Catalog;
  isFleet: boolean;
  onAdd: (t: 'new') => void;
  onEdit: (v: FleetVehicle) => void;
  onDocs: (d: DocsTarget) => void;
  onDelete: (d: DeleteTarget) => void;
}) {
  // TRACE: "Add vehicle" click → opens the create sheet → void.
  const add = () => onAdd('new');
  return (
    <div>
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-semibold text-ink-900">Vehicles</h2>
        {isFleet && (
          <Button size="sm" onClick={add}>
            Add vehicle
          </Button>
        )}
      </div>
      {overview.vehicles.length === 0 ? (
        <div className="mt-4">
          <EmptyState
            title="No vehicles yet"
            description={isFleet ? 'Add your first vehicle to start choosing vehicles for leads.' : 'Your vehicle will appear here once your account is set up.'}
          />
        </div>
      ) : (
        <ul className="mt-4 space-y-3">
          {overview.vehicles.map((v) => (
            <VehicleRow
              key={v.id}
              vehicle={v}
              typeName={catalog.vehicleTypes.find((t) => t.id === v.vehicle_type_id)?.name ?? ''}
              branchName={overview.branches.find((b) => b.id === v.branch_id)?.name ?? ''}
              isFleet={isFleet}
              onEdit={onEdit}
              onDocs={onDocs}
              onDelete={onDelete}
            />
          ))}
        </ul>
      )}
    </div>
  );
}

// TRACE: VehiclesPanel → renders one vehicle card with badges and action buttons → callbacks with the vehicle.
//        Preconditions: vehicle row. Postconditions: every action button names the vehicle for screen readers.
//        Edge cases: blank plate (individual vendor not yet set up: prompts to add it), no branch/type (omitted).
function VehicleRow({
  vehicle,
  typeName,
  branchName,
  isFleet,
  onEdit,
  onDocs,
  onDelete,
}: {
  vehicle: FleetVehicle;
  typeName: string;
  branchName: string;
  isFleet: boolean;
  onEdit: (v: FleetVehicle) => void;
  onDocs: (d: DocsTarget) => void;
  onDelete: (d: DeleteTarget) => void;
}) {
  const label = vehicleLabel(vehicle);
  // TRACE: Edit click → hands the vehicle to the parent → void.
  const edit = () => onEdit(vehicle);
  // TRACE: Documents click → opens the document panel for this vehicle → void.
  const docs = () => onDocs({ kind: 'vehicle', id: vehicle.id, label });
  // TRACE: Delete click → asks the parent to confirm deleting this vehicle → void.
  const del = () => onDelete({ kind: 'vehicle', id: vehicle.id, label: `vehicle ${label}` });
  return (
    <li className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <p className="font-semibold text-ink-900">{vehicle.registration_number || 'Registration number missing'}</p>
          <p className="text-sm text-ink-600">
            {[vehicle.make_model, typeName, `${vehicle.seating_capacity} seats`, branchName && `Branch: ${branchName}`].filter(Boolean).join(' · ')}
          </p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <ToneBadge tone={STATUS_TONE[vehicle.status] ?? 'neutral'}>{STATUS_LABEL[vehicle.status] ?? vehicle.status}</ToneBadge>
          <ToneBadge tone={LIVE_TONE[vehicle.live_status]}>{LIVE_LABEL[vehicle.live_status]}</ToneBadge>
        </div>
      </div>
      {!vehicle.registration_number && (
        <p className="mt-2 text-sm text-warning-600">Add the registration number so clients can identify your vehicle.</p>
      )}
      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 border-t border-ink-100 pt-3">
        <button type="button" onClick={edit} className={LINK_BUTTON_CLASS} aria-label={`Edit vehicle ${label}`}>
          Edit
        </button>
        <button type="button" onClick={docs} className={LINK_BUTTON_CLASS} aria-label={`Documents for vehicle ${label}`}>
          Documents
        </button>
        {isFleet && (
          <button
            type="button"
            onClick={del}
            className="rounded-md text-sm font-medium text-danger-600 hover:text-danger-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-danger-600"
            aria-label={`Delete vehicle ${label}`}
          >
            Delete
          </button>
        )}
      </div>
    </li>
  );
}

// TRACE: drivers tab → lists drivers with licence expiry, status and live status; "Add driver" for fleet vendors only.
//        Preconditions: overview loaded. Postconditions: individual vendors get edit + documents only.
//        Edge cases: empty list (empty state), licence expired (danger badge), missing expiry (text).
function DriversPanel({
  overview,
  isFleet,
  onAdd,
  onEdit,
  onDocs,
  onLogin,
  onDelete,
}: {
  overview: FleetOverview;
  isFleet: boolean;
  onAdd: (t: 'new') => void;
  onEdit: (d: FleetDriver) => void;
  onDocs: (d: DocsTarget) => void;
  onLogin: (d: FleetDriver) => void;
  onDelete: (d: DeleteTarget) => void;
}) {
  // TRACE: "Add driver" click → opens the create sheet → void.
  const add = () => onAdd('new');
  return (
    <div>
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-semibold text-ink-900">Drivers</h2>
        {isFleet && (
          <Button size="sm" onClick={add}>
            Add driver
          </Button>
        )}
      </div>
      {overview.drivers.length === 0 ? (
        <div className="mt-4">
          <EmptyState
            title="No drivers yet"
            description={isFleet ? 'Add your first driver to start choosing drivers for leads.' : 'Your driver profile will appear here once your account is set up.'}
          />
        </div>
      ) : (
        <ul className="mt-4 space-y-3">
          {overview.drivers.map((d) => (
            <DriverRow
              key={d.id}
              driver={d}
              branchName={overview.branches.find((b) => b.id === d.branch_id)?.name ?? ''}
              isFleet={isFleet}
              onEdit={onEdit}
              onDocs={onDocs}
              onLogin={onLogin}
              onDelete={onDelete}
            />
          ))}
        </ul>
      )}
    </div>
  );
}

// TRACE: DriversPanel → renders one driver card → callbacks with the driver.
//        Preconditions: driver row. Postconditions: action buttons name the driver. Edge cases: licence expiry in the
//        past shows an Expired badge; no expiry shows nothing invented.
function DriverRow({
  driver,
  branchName,
  isFleet,
  onEdit,
  onDocs,
  onLogin,
  onDelete,
}: {
  driver: FleetDriver;
  branchName: string;
  isFleet: boolean;
  onEdit: (d: FleetDriver) => void;
  onDocs: (d: DocsTarget) => void;
  onLogin: (d: FleetDriver) => void;
  onDelete: (d: DeleteTarget) => void;
}) {
  const today = new Date().toISOString().slice(0, 10);
  const licenceExpired = driver.license_expiry !== null && driver.license_expiry.slice(0, 10) < today;
  // TRACE: Edit click → hands the driver to the parent → void.
  const edit = () => onEdit(driver);
  // TRACE: Documents click → opens the document panel for this driver → void.
  const docs = () => onDocs({ kind: 'driver', id: driver.id, label: driver.name });
  // TRACE: "Create login" click → opens the login sheet for this driver → void.
  const login = () => onLogin(driver);
  const hasLogin = Boolean(driver.user_id);
  // TRACE: Delete click → asks the parent to confirm deleting this driver → void.
  const del = () => onDelete({ kind: 'driver', id: driver.id, label: `driver ${driver.name}` });
  return (
    <li className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <p className="font-semibold text-ink-900">{driver.name}</p>
          <p className="text-sm text-ink-600">
            {[driver.mobile, driver.license_number && `Licence ${driver.license_number}`, `${driver.experience_years} yrs experience`, branchName && `Branch: ${branchName}`]
              .filter(Boolean)
              .join(' · ')}
          </p>
          {driver.license_expiry && (
            <p className="text-sm text-ink-600">Licence expires {formatDateTime(driver.license_expiry)}</p>
          )}
        </div>
        <div className="flex flex-wrap gap-1.5">
          <ToneBadge tone={STATUS_TONE[driver.status] ?? 'neutral'}>{STATUS_LABEL[driver.status] ?? driver.status}</ToneBadge>
          <ToneBadge tone={LIVE_TONE[driver.live_status]}>{LIVE_LABEL[driver.live_status]}</ToneBadge>
          {licenceExpired && <ToneBadge tone="danger">Licence expired</ToneBadge>}
          {!driver.profile_complete && <ToneBadge tone="warning">Incomplete profile</ToneBadge>}
        </div>
      </div>
      {!driver.profile_complete && driver.profile_missing.length > 0 && (
        <p className="mt-2 text-sm text-warning-700">
          Missing for safety tracking: {driver.profile_missing.join(', ')}. This driver cannot be assigned to a trip until these are added.
        </p>
      )}
      <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 border-t border-ink-100 pt-3">
        <button type="button" onClick={edit} className={LINK_BUTTON_CLASS} aria-label={`Edit driver ${driver.name}`}>
          Edit
        </button>
        <button type="button" onClick={docs} className={LINK_BUTTON_CLASS} aria-label={`Documents for driver ${driver.name}`}>
          Documents
        </button>
        {isFleet && !hasLogin && (
          <button type="button" onClick={login} className={LINK_BUTTON_CLASS} aria-label={`Create a login for driver ${driver.name}`}>
            Create login
          </button>
        )}
        {isFleet && hasLogin && <span className="text-sm text-ink-600">Has a login</span>}
        {isFleet && (
          <button
            type="button"
            onClick={del}
            className="rounded-md text-sm font-medium text-danger-600 hover:text-danger-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-danger-600"
            aria-label={`Delete driver ${driver.name}`}
          >
            Delete
          </button>
        )}
      </div>
    </li>
  );
}

// TRACE: branches tab (fleet vendors) → lists branches with city, primary flag and status; add/edit/delete.
//        Preconditions: fleet vendor. Postconditions: deleting names the branch. Edge cases: no branches (empty state).
function BranchesPanel({
  overview,
  onAdd,
  onEdit,
  onDelete,
}: {
  overview: FleetOverview;
  onAdd: (t: 'new') => void;
  onEdit: (b: VendorBranch) => void;
  onDelete: (d: DeleteTarget) => void;
}) {
  // TRACE: "Add branch" click → opens the create sheet → void.
  const add = () => onAdd('new');
  return (
    <div>
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-semibold text-ink-900">Branches</h2>
        <Button size="sm" onClick={add}>
          Add branch
        </Button>
      </div>
      {overview.branches.length === 0 ? (
        <div className="mt-4">
          <EmptyState title="No branches yet" description="Branches help you place vehicles and drivers close to the pickup city." />
        </div>
      ) : (
        <ul className="mt-4 space-y-3">
          {overview.branches.map((b) => (
            <BranchRow key={b.id} branch={b} onEdit={onEdit} onDelete={onDelete} />
          ))}
        </ul>
      )}
    </div>
  );
}

// TRACE: BranchesPanel → renders one branch card → callbacks with the branch.
//        Preconditions: branch row. Postconditions: buttons name the branch. Edge cases: no address (omitted).
function BranchRow({ branch, onEdit, onDelete }: { branch: VendorBranch; onEdit: (b: VendorBranch) => void; onDelete: (d: DeleteTarget) => void }) {
  // TRACE: Edit click → hands the branch to the parent → void.
  const edit = () => onEdit(branch);
  // TRACE: Delete click → asks the parent to confirm deleting this branch → void.
  const del = () => onDelete({ kind: 'branch', id: branch.id, label: `branch ${branch.name}` });
  return (
    <li className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <p className="font-semibold text-ink-900">{branch.name}</p>
          <p className="text-sm text-ink-600">{[branch.city_name, branch.address].filter(Boolean).join(' · ')}</p>
        </div>
        <div className="flex flex-wrap gap-1.5">
          {branch.is_primary && <ToneBadge tone="brand">Primary</ToneBadge>}
          <ToneBadge tone={STATUS_TONE[branch.status] ?? 'neutral'}>{STATUS_LABEL[branch.status] ?? branch.status}</ToneBadge>
        </div>
      </div>
      <div className="mt-3 flex gap-4 border-t border-ink-100 pt-3">
        <button type="button" onClick={edit} className={LINK_BUTTON_CLASS} aria-label={`Edit branch ${branch.name}`}>
          Edit
        </button>
        <button
          type="button"
          onClick={del}
          className="rounded-md text-sm font-medium text-danger-600 hover:text-danger-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-danger-600"
          aria-label={`Delete branch ${branch.name}`}
        >
          Delete
        </button>
      </div>
    </li>
  );
}

// TRACE: availability tab → loads upcoming unavailability blocks, lists them, opens the add-block sheet, shows the
//        conflicts warning returned by the API → panel. Preconditions: overview loaded; `version` changes after every
//        fleet reload so blocks re-fetch (a deleted vehicle's blocks disappear). Postconditions: stale loads ignored.
//        Edge cases: no blocks (empty state), load failure (retry), no vehicles or drivers (add disabled), conflicts
//        returned (warning lists the booking numbers, block still saved).
function AvailabilityPanel({ overview, version, onDelete }: { overview: FleetOverview; version: number; onDelete: (d: DeleteTarget) => void }) {
  const guard = useRequestGuard();
  const [blocks, setBlocks] = useState<UnavailabilityBlock[] | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [conflicts, setConflicts] = useState<{ label: string; bookings: string[] } | null>(null);
  const sheet = useSheet<true>();
  const hideSheet = sheet.hide;

  // TRACE: mount / version change / after add → GET blocks from today → stores them.
  //        Preconditions: none. Postconditions: newest response wins. Edge cases: failure (error + retry), stale (ignored).
  const load = useCallback(async () => {
    const id = guard.begin();
    setLoading(true);
    setError(null);
    try {
      const rows = await listUnavailability(new Date().toISOString().slice(0, 10));
      if (guard.isCurrent(id)) setBlocks(rows);
    } catch (err) {
      if (guard.isCurrent(id)) setError(messageOf(err, 'Could not load unavailability. Please try again.'));
    } finally {
      if (guard.isCurrent(id)) setLoading(false);
    }
  }, [guard]);

  // TRACE: mount / fleet version change → (re)loads the unavailability blocks → void. Edge cases: stale response ignored.
  useEffect(() => {
    void load();
  }, [load, version]);

  // TRACE: add-block success → closes the sheet, remembers conflicts for the warning, reloads blocks → void.
  //        Edge cases: no conflicts (warning cleared).
  const saved = useCallback(
    (label: string, bookings: string[]) => {
      hideSheet();
      setConflicts(bookings.length > 0 ? { label, bookings } : null);
      void load();
    },
    [load, hideSheet]
  );

  // TRACE: "Add unavailability" click → opens the sheet → void.
  const add = () => sheet.show(true);
  // TRACE: warning dismiss → clears it → void.
  const dismissConflicts = () => setConflicts(null);

  // TRACE: block rows / form / warning → builds a display name for a vehicle or driver id → "vehicle KA01AB1234".
  //        Preconditions: overview loaded. Postconditions: never empty. Edge cases: id no longer in the fleet → "vehicle #id".
  const nameOf = (kind: EntityKind, id: number): string => {
    if (kind === 'vehicle') {
      const v = overview.vehicles.find((x) => x.id === id);
      return v ? `vehicle ${vehicleLabel(v)}` : `vehicle #${id}`;
    }
    const d = overview.drivers.find((x) => x.id === id);
    return d ? `driver ${d.name}` : `driver #${id}`;
  };
  const canAdd = overview.vehicles.length > 0 || overview.drivers.length > 0;

  return (
    <div>
      <div className="flex items-center justify-between gap-3">
        <h2 className="text-lg font-semibold text-ink-900">Unavailability</h2>
        <Button size="sm" onClick={add} disabled={!canAdd}>
          Add unavailability
        </Button>
      </div>
      <p className="mt-1 text-sm text-ink-600">Block out times when a vehicle or driver cannot take trips, such as servicing or leave.</p>

      {conflicts && (
        <div role="alert" className="mt-4 flex items-start justify-between gap-3 rounded-lg border border-warning-500/30 bg-warning-50 px-4 py-3 text-sm text-warning-600">
          <span>
            Saved, but {conflicts.label} is already assigned to {conflicts.bookings.length === 1 ? 'booking' : 'bookings'}{' '}
            {conflicts.bookings.join(', ')} during this time. Change the driver or vehicle on {conflicts.bookings.length === 1 ? 'that trip' : 'those trips'}.
          </span>
          <button
            type="button"
            onClick={dismissConflicts}
            aria-label="Dismiss conflict warning"
            className="shrink-0 rounded-md p-1 hover:bg-white/60 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
          >
            <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      )}

      <div className="mt-4">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading unavailability">
            <Skeleton className="h-16 w-full rounded-xl" />
            <Skeleton className="h-16 w-full rounded-xl" />
          </div>
        )}
        {!loading && error && <ErrorBanner message={error} onRetry={load} />}
        {!loading && !error && blocks && blocks.length === 0 && (
          <EmptyState title="Nothing blocked" description="Vehicles and drivers are open for any trip they are free for." />
        )}
        {!loading && !error && blocks && blocks.length > 0 && (
          <ul className="space-y-3">
            {blocks.map((b) => (
              <BlockRow key={b.id} block={b} name={nameOf(b.entity_type, b.entity_id)} onDelete={onDelete} />
            ))}
          </ul>
        )}
      </div>

      <BottomSheet open={sheet.open} title="Add unavailability" onClose={sheet.hide}>
        {sheet.target && <BlockForm key={sheet.nonce} overview={overview} nameOf={nameOf} onSaved={saved} onCancel={sheet.hide} />}
      </BottomSheet>
    </div>
  );
}

// TRACE: AvailabilityPanel → renders one block row with the time window and remove button → onDelete(target).
//        Preconditions: block + display name. Postconditions: remove button names the entity and window.
//        Edge cases: no reason (omitted).
function BlockRow({ block, name, onDelete }: { block: UnavailabilityBlock; name: string; onDelete: (d: DeleteTarget) => void }) {
  const span = `${formatDateTime(block.starts_at)} to ${formatDateTime(block.ends_at)}`;
  // TRACE: Remove click → asks the parent to confirm removing this block → void.
  const del = () => onDelete({ kind: 'block', id: block.id, label: `unavailability for ${name} (${span})` });
  return (
    <li className={`flex flex-wrap items-start justify-between gap-3 p-4 ${DATA_CARD_CLASS}`}>
      <div>
        <p className="font-semibold capitalize text-ink-900">{name}</p>
        <p className="text-sm text-ink-600">{span}</p>
        {block.reason && <p className="text-sm text-ink-600">Reason: {block.reason}</p>}
      </div>
      <button
        type="button"
        onClick={del}
        className="rounded-md text-sm font-medium text-danger-600 hover:text-danger-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-danger-600"
        aria-label={`Remove unavailability for ${name}, ${span}`}
      >
        Remove
      </button>
    </li>
  );
}

// TRACE: add-block sheet → collects entity, start, end, reason → POST → onSaved(label, conflicts).
//        Preconditions: overview has at least one entity. Postconditions: input kept on failure (inline error), form
//        unmounts on success; submit disabled while pending. Edge cases: end not after start (client message), no entity
//        of the chosen kind (select empty, message), server error (inline text).
function BlockForm({
  overview,
  nameOf,
  onSaved,
  onCancel,
}: {
  overview: FleetOverview;
  nameOf: (k: EntityKind, id: number) => string;
  onSaved: (label: string, conflicts: string[]) => void;
  onCancel: () => void;
}) {
  const toast = useToast();
  const initialKind: EntityKind = overview.vehicles.length > 0 ? 'vehicle' : 'driver';
  const [kind, setKind] = useState<EntityKind>(initialKind);
  const [entityId, setEntityId] = useState<number>(initialKind === 'vehicle' ? (overview.vehicles[0]?.id ?? 0) : (overview.drivers[0]?.id ?? 0));
  const [startsAt, setStartsAt] = useState('');
  const [endsAt, setEndsAt] = useState('');
  const [reason, setReason] = useState('');
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const options = kind === 'vehicle' ? overview.vehicles.map((v) => ({ id: v.id, label: vehicleLabel(v) })) : overview.drivers.map((d) => ({ id: d.id, label: d.name }));

  // TRACE: kind select change → switches list and selects its first entity → void. Edge cases: empty list (id 0).
  const changeKind = (e: ChangeEvent<HTMLSelectElement>) => {
    const next: EntityKind = e.target.value === 'driver' ? 'driver' : 'vehicle';
    setKind(next);
    setEntityId(next === 'vehicle' ? (overview.vehicles[0]?.id ?? 0) : (overview.drivers[0]?.id ?? 0));
  };
  // TRACE: entity select change → stores the numeric id → void.
  const changeEntity = (e: ChangeEvent<HTMLSelectElement>) => setEntityId(Number(e.target.value));
  // TRACE: start input change → stores value → void.
  const changeStart = (e: ChangeEvent<HTMLInputElement>) => setStartsAt(e.target.value);
  // TRACE: end input change → stores value → void.
  const changeEnd = (e: ChangeEvent<HTMLInputElement>) => setEndsAt(e.target.value);
  // TRACE: reason input change → stores value → void.
  const changeReason = (e: ChangeEvent<HTMLInputElement>) => setReason(e.target.value);

  // TRACE: form submit → validates, POSTs, toasts result → onSaved with conflicts. Preconditions: not already saving.
  //        Postconditions: on failure fields stay filled and the message shows inline. Edge cases: missing fields,
  //        end <= start, API failure.
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    if (!entityId) {
      setFormError(`Choose a ${kind}.`);
      return;
    }
    if (!startsAt || !endsAt) {
      setFormError('Enter both a start and an end date and time.');
      return;
    }
    if (new Date(endsAt).getTime() <= new Date(startsAt).getTime()) {
      setFormError('The end must be after the start.');
      return;
    }
    setSaving(true);
    setFormError(null);
    try {
      const res = await createUnavailability({ entity_type: kind, entity_id: entityId, starts_at: startsAt, ends_at: endsAt, reason: reason.trim() });
      toast.show(res.message, 'success');
      onSaved(nameOf(kind, entityId), res.conflicts);
    } catch (err) {
      setFormError(messageOf(err, 'Could not save. Please try again.'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <FormField label="Applies to" htmlFor="block-kind">
        <select id="block-kind" value={kind} onChange={changeKind} className={INPUT_CLASS} disabled={saving}>
          {overview.vehicles.length > 0 && <option value="vehicle">Vehicle</option>}
          {overview.drivers.length > 0 && <option value="driver">Driver</option>}
        </select>
      </FormField>
      <FormField label={kind === 'vehicle' ? 'Vehicle' : 'Driver'} htmlFor="block-entity">
        <select id="block-entity" value={entityId} onChange={changeEntity} className={INPUT_CLASS} disabled={saving}>
          {options.map((o) => (
            <option key={o.id} value={o.id}>
              {o.label}
            </option>
          ))}
        </select>
      </FormField>
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Starts" htmlFor="block-start">
          <input id="block-start" type="datetime-local" value={startsAt} onChange={changeStart} className={INPUT_CLASS} disabled={saving} />
        </FormField>
        <FormField label="Ends" htmlFor="block-end">
          <input id="block-end" type="datetime-local" value={endsAt} onChange={changeEnd} className={INPUT_CLASS} disabled={saving} />
        </FormField>
      </div>
      <FormField label="Reason (optional)" htmlFor="block-reason">
        <input id="block-reason" type="text" maxLength={255} value={reason} onChange={changeReason} className={INPUT_CLASS} disabled={saving} />
      </FormField>
      {formError && (
        <p role="alert" className="text-sm font-medium text-danger-600">
          {formError}
        </p>
      )}
      <FormActions saving={saving} submitLabel="Save unavailability" onCancel={onCancel} />
    </form>
  );
}

// TRACE: every sheet form → renders the Cancel + Submit buttons row → submit button shows a spinner and is disabled while
//        saving. Preconditions: rendered inside a <form>. Postconditions: Cancel stays enabled so the sheet can close.
//        Edge cases: none.
function FormActions({ saving, submitLabel, onCancel }: { saving: boolean; submitLabel: string; onCancel: () => void }) {
  return (
    <div className="flex flex-col-reverse gap-2 pt-2 sm:flex-row sm:justify-end">
      <Button type="button" variant="secondary" onClick={onCancel}>
        Cancel
      </Button>
      <Button type="submit" loading={saving}>
        {submitLabel}
      </Button>
    </div>
  );
}

// TRACE: driver login sheet → email + optional password → POST /vendor/drivers/{id}/login → toast, reload the fleet, close.
//        Preconditions: fleet vendor, driver without a login. Postconditions: the driver row shows "Has a login" after the reload;
//        no password is ever displayed; with no password the driver gets an email link to set one. Edge cases: invalid email or
//        password under 10 characters (inline message, no request), duplicate email (server text), double submit (ignored).
function DriverLoginForm({ driver, onSaved, onCancel, hide }: { driver: FleetDriver; onSaved: () => void; onCancel: () => void; hide: () => void }) {
  const toast = useToast();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  // TRACE: submit → validates → POST → toast + refresh + close. Edge: failure keeps the values and shows the server message.
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    if (!/^\S+@\S+\.\S+$/.test(email.trim())) { setError('Enter a valid email address.'); return; }
    if (password !== '' && password.length < 10) { setError('Password must be at least 10 characters, or leave it blank to email the driver a link.'); return; }
    setSaving(true); setError(null);
    try {
      await createDriverLogin(driver.id, { email: email.trim(), password });
      toast.show(`Login created for ${driver.name}.`, 'success');
      hide();
      onSaved();
    } catch (err) {
      setError(messageOf(err, 'Could not create the login.'));
      setSaving(false);
    }
  };
  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <FormField label="Driver email *" htmlFor="dl-email"><input id="dl-email" type="email" className={INPUT_CLASS} value={email} onChange={(e) => setEmail(e.target.value)} disabled={saving} autoComplete="off" /></FormField>
      <FormField label="Password (optional)" htmlFor="dl-pw" hint="Leave blank to email the driver a link to set their own password."><input id="dl-pw" type="password" className={INPUT_CLASS} value={password} onChange={(e) => setPassword(e.target.value)} disabled={saving} autoComplete="new-password" /></FormField>
      {error && <p role="alert" className="text-sm font-medium text-danger-600">{error}</p>}
      <FormActions saving={saving} submitLabel="Create login" onCancel={onCancel} />
    </form>
  );
}

// TRACE: vehicle sheet → collects plate, model, type, seats, status, branch → create or update → onSaved().
//        Preconditions: initial null = create. Postconditions: plate normalised client-side the same way as the server;
//        input kept on failure; success toast includes any server warning. Edge cases: missing/short/long plate,
//        seats outside 1-60, server refusal (duplicate plate, individual vendor) shown inline.
function VehicleForm({
  initial,
  vehicleTypes,
  branches,
  showBranch,
  onSaved,
  onCancel,
}: {
  initial: FleetVehicle | null;
  vehicleTypes: Vehicle[];
  branches: VendorBranch[];
  showBranch: boolean;
  onSaved: () => void;
  onCancel: () => void;
}) {
  const toast = useToast();
  const [plate, setPlate] = useState(initial?.registration_number ?? '');
  const [model, setModel] = useState(initial?.make_model ?? '');
  const [typeId, setTypeId] = useState(String(initial?.vehicle_type_id ?? 0));
  const [seats, setSeats] = useState(String(initial?.seating_capacity ?? 4));
  const [status, setStatus] = useState<FleetVehicle['status']>(initial?.status ?? 'active');
  const [branchId, setBranchId] = useState(String(initial?.branch_id ?? 0));
  const [errors, setErrors] = useState<{ plate?: string; seats?: string }>({});
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // TRACE: plate input change → stores raw text → void.
  const changePlate = (e: ChangeEvent<HTMLInputElement>) => setPlate(e.target.value);
  // TRACE: model input change → stores raw text → void.
  const changeModel = (e: ChangeEvent<HTMLInputElement>) => setModel(e.target.value);
  // TRACE: type select change → stores the id text → void.
  const changeType = (e: ChangeEvent<HTMLSelectElement>) => setTypeId(e.target.value);
  // TRACE: seats input change → stores raw text → void.
  const changeSeats = (e: ChangeEvent<HTMLInputElement>) => setSeats(e.target.value);
  // TRACE: status select change → stores the status → void. Edge cases: unknown value (falls back to active).
  const changeStatus = (e: ChangeEvent<HTMLSelectElement>) => {
    const v = e.target.value;
    setStatus(v === 'inactive' || v === 'maintenance' ? v : 'active');
  };
  // TRACE: branch select change → stores the id text → void.
  const changeBranch = (e: ChangeEvent<HTMLSelectElement>) => setBranchId(e.target.value);

  // TRACE: form submit → validates plate (5-15 letters/digits) and seats (1-60) → POST/PUT → toast + onSaved.
  //        Preconditions: not already saving. Postconditions: fields stay filled on failure. Edge cases: invalid input
  //        (field errors, no request), server error (inline), warning in the response (info toast).
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    const clean = normalisePlate(plate);
    const seatNum = Number(seats);
    const next: { plate?: string; seats?: string } = {};
    if (clean.length < 5 || clean.length > 15) next.plate = 'Enter a valid registration number (for example MH12AB1234).';
    if (!Number.isInteger(seatNum) || seatNum < 1 || seatNum > 60) next.seats = 'Seating capacity must be between 1 and 60.';
    setErrors(next);
    if (next.plate || next.seats) return;
    const input: VehicleInput = {
      registration_number: clean,
      make_model: model.trim(),
      vehicle_type_id: Number(typeId),
      seating_capacity: seatNum,
      status,
      ...(showBranch ? { branch_id: Number(branchId) } : {}),
    };
    setSaving(true);
    setFormError(null);
    try {
      const res = initial ? await updateFleetVehicle(initial.id, input, initial.lock_version) : await createFleetVehicle(input);
      toast.show(res.message, 'success');
      if (res.warning) toast.show(res.warning, 'info');
      onSaved();
    } catch (err) {
      // A 409 means someone else (the owner, or another staff login on the same vendor) saved a
      // change to this vehicle while this form was open. Deliberately does NOT auto-close the form
      // (that would discard this message before the user can read it) — they see the conflict text
      // and can cancel to reopen the form with the current values, or resubmit if they still want
      // their own version to win.
      setFormError(messageOf(err, 'Could not save the vehicle. Please try again.'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <FormField label="Registration number" htmlFor="veh-plate" hint="Letters and digits only, for example MH12AB1234." error={errors.plate}>
        <input
          id="veh-plate"
          type="text"
          value={plate}
          onChange={changePlate}
          autoCapitalize="characters"
          aria-invalid={errors.plate ? true : undefined}
          aria-describedby={errors.plate ? 'veh-plate-error' : 'veh-plate-hint'}
          className={INPUT_CLASS}
          disabled={saving}
        />
      </FormField>
      <FormField label="Make and model" htmlFor="veh-model">
        <input id="veh-model" type="text" value={model} onChange={changeModel} className={INPUT_CLASS} disabled={saving} />
      </FormField>
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Vehicle type" htmlFor="veh-type">
          <select id="veh-type" value={typeId} onChange={changeType} className={INPUT_CLASS} disabled={saving}>
            <option value="0">Not specified</option>
            {vehicleTypes.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}
              </option>
            ))}
          </select>
        </FormField>
        <FormField label="Seats" htmlFor="veh-seats" error={errors.seats}>
          <input
            id="veh-seats"
            type="number"
            inputMode="numeric"
            min={1}
            max={60}
            value={seats}
            onChange={changeSeats}
            aria-invalid={errors.seats ? true : undefined}
            aria-describedby={errors.seats ? 'veh-seats-error' : undefined}
            className={INPUT_CLASS}
            disabled={saving}
          />
        </FormField>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Status" htmlFor="veh-status">
          <select id="veh-status" value={status} onChange={changeStatus} className={INPUT_CLASS} disabled={saving}>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
            <option value="maintenance">Under maintenance</option>
          </select>
        </FormField>
        {showBranch && (
          <FormField label="Branch" htmlFor="veh-branch">
            <select id="veh-branch" value={branchId} onChange={changeBranch} className={INPUT_CLASS} disabled={saving}>
              <option value="0">No branch</option>
              {branches.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>
          </FormField>
        )}
      </div>
      {formError && (
        <p role="alert" className="text-sm font-medium text-danger-600">
          {formError}
        </p>
      )}
      <FormActions saving={saving} submitLabel={initial ? 'Save vehicle' : 'Add vehicle'} onCancel={onCancel} />
    </form>
  );
}

// TRACE: constant → every optional/required driver-profile key the form round-trips to the API. Pure.
const DRIVER_EXTRA_KEYS = ['alt_mobile', 'date_of_birth', 'blood_group', 'address', 'city', 'pincode', 'license_class', 'badge_number', 'emergency_contact_name', 'emergency_contact_phone', 'emergency_contact_relation', 'id_proof_type', 'id_proof_number', 'police_verification_status', 'police_verification_date'];
// TRACE: constant → [key, label] pairs that must be non-blank before submit (mirrors ridego_driver_required_fields in fleet.php). Pure.
const DRIVER_REQUIRED_EXTRA: Array<[string, string]> = [['date_of_birth', 'Date of birth'], ['license_class', 'Licence class'], ['address', 'Home address'], ['city', 'City'], ['emergency_contact_name', 'Emergency contact name'], ['emergency_contact_phone', 'Emergency contact phone'], ['emergency_contact_relation', 'Emergency contact relation'], ['id_proof_type', 'ID proof type'], ['id_proof_number', 'ID proof number']];

// TRACE: driver sheet → collects name, mobile, licence, expiry, experience, service area, status, branch → create or
//        update → onSaved(). Preconditions: initial null = create. Postconditions: input kept on failure.
//        Edge cases: blank name, mobile not 10-13 digits, experience outside 0-70, expiry left blank (sent as blank so
//        the server clears it), server refusal shown inline.
function DriverForm({
  initial,
  branches,
  showBranch,
  onSaved,
  onCancel,
}: {
  initial: FleetDriver | null;
  branches: VendorBranch[];
  showBranch: boolean;
  onSaved: () => void;
  onCancel: () => void;
}) {
  const toast = useToast();
  const [name, setName] = useState(initial?.name ?? '');
  const [mobile, setMobile] = useState(initial?.mobile ?? '');
  const [licence, setLicence] = useState(initial?.license_number ?? '');
  const [expiry, setExpiry] = useState(initial?.license_expiry?.slice(0, 10) ?? '');
  const [experience, setExperience] = useState(String(initial?.experience_years ?? 0));
  const [area, setArea] = useState(initial?.service_area_note ?? '');
  const [status, setStatus] = useState<FleetDriver['status']>(initial?.status ?? 'active');
  const [branchId, setBranchId] = useState(String(initial?.branch_id ?? 0));
  const [errors, setErrors] = useState<{ name?: string; mobile?: string; experience?: string; extra?: string }>({});
  const [ex, setEx] = useState<Record<string, string>>(() => {
    const src = (initial ?? {}) as unknown as Record<string, unknown>;
    const o: Record<string, string> = {};
    for (const k of DRIVER_EXTRA_KEYS) o[k] = typeof src[k] === 'string' ? (src[k] as string).slice(0, k.includes('date') ? 10 : 255) : '';
    if (o.police_verification_status === '') o.police_verification_status = 'none';
    return o;
  });
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  // TRACE: any extra-profile input change → stores value under its key → void.
  const setExtra = (k: string) => (e: ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const v = e.target.value;
    setEx((prev) => ({ ...prev, [k]: v }));
  };

  // TRACE: name input change → stores text → void.
  const changeName = (e: ChangeEvent<HTMLInputElement>) => setName(e.target.value);
  // TRACE: mobile input change → stores text → void.
  const changeMobile = (e: ChangeEvent<HTMLInputElement>) => setMobile(e.target.value);
  // TRACE: licence input change → stores text → void.
  const changeLicence = (e: ChangeEvent<HTMLInputElement>) => setLicence(e.target.value);
  // TRACE: expiry input change → stores date text → void.
  const changeExpiry = (e: ChangeEvent<HTMLInputElement>) => setExpiry(e.target.value);
  // TRACE: experience input change → stores text → void.
  const changeExperience = (e: ChangeEvent<HTMLInputElement>) => setExperience(e.target.value);
  // TRACE: service area input change → stores text → void.
  const changeArea = (e: ChangeEvent<HTMLInputElement>) => setArea(e.target.value);
  // TRACE: status select change → stores status → void. Edge cases: unknown value → inactive.
  const changeStatus = (e: ChangeEvent<HTMLSelectElement>) => setStatus(e.target.value === 'active' ? 'active' : 'inactive');
  // TRACE: branch select change → stores id text → void.
  const changeBranch = (e: ChangeEvent<HTMLSelectElement>) => setBranchId(e.target.value);

  // TRACE: form submit → validates → POST/PUT → toast + onSaved. Preconditions: not already saving.
  //        Postconditions: inputs kept on failure. Edge cases: invalid fields (errors, no request), server error, warning.
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    const digits = mobile.replace(/\D/g, '');
    const exp = Number(experience);
    const next: { name?: string; mobile?: string; experience?: string; extra?: string } = {};
    if (name.trim() === '') next.name = 'Driver name is required.';
    if (digits.length < 10 || digits.length > 13) next.mobile = 'Enter a valid mobile number (10 to 13 digits).';
    if (!Number.isInteger(exp) || exp < 0 || exp > 70) next.experience = 'Experience must be between 0 and 70 years.';
    const missing = DRIVER_REQUIRED_EXTRA.filter(([k]) => (ex[k] ?? '').trim() === '').map(([, label]) => label);
    if (licence.trim() === '') missing.push('Licence number');
    if (expiry === '') missing.push('Licence expiry');
    if (missing.length > 0) next.extra = `Required for driver tracking: ${missing.join(', ')}.`;
    setErrors(next);
    if (next.name || next.mobile || next.experience || next.extra) return;
    const input: DriverInput = {
      ...(ex as DriverInput),
      name: name.trim(),
      mobile: digits,
      license_number: licence.trim(),
      license_expiry: expiry,
      experience_years: exp,
      service_area_note: area.trim(),
      status,
      ...(showBranch ? { branch_id: Number(branchId) } : {}),
    };
    setSaving(true);
    setFormError(null);
    try {
      const res = initial ? await updateFleetDriver(initial.id, input, initial.lock_version) : await createFleetDriver(input);
      toast.show(res.message, 'success');
      if (res.warning) toast.show(res.warning, 'info');
      onSaved();
    } catch (err) {
      // See the matching comment in the vehicle form above — a 409 conflict deliberately keeps this
      // form open with its message rather than auto-closing it.
      setFormError(messageOf(err, 'Could not save the driver. Please try again.'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <p className="text-xs text-ink-500">
        Fields marked <span aria-hidden="true" className="font-semibold text-danger-600">*</span> are required.
      </p>
      <FormField label="Full name" htmlFor="drv-name" error={errors.name} required>
        <input id="drv-name" type="text" value={name} onChange={changeName} aria-invalid={errors.name ? true : undefined} aria-describedby={errors.name ? 'drv-name-error' : undefined} className={INPUT_CLASS} disabled={saving} />
      </FormField>
      <FormField label="Mobile number" htmlFor="drv-mobile" error={errors.mobile} required>
        <input id="drv-mobile" type="tel" inputMode="tel" value={mobile} onChange={changeMobile} aria-invalid={errors.mobile ? true : undefined} aria-describedby={errors.mobile ? 'drv-mobile-error' : undefined} className={INPUT_CLASS} disabled={saving} />
      </FormField>
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Licence number" htmlFor="drv-licence" required>
          <input id="drv-licence" type="text" value={licence} onChange={changeLicence} className={INPUT_CLASS} disabled={saving} />
        </FormField>
        <FormField label="Licence expiry" htmlFor="drv-expiry" required>
          <input id="drv-expiry" type="date" value={expiry} onChange={changeExpiry} className={INPUT_CLASS} disabled={saving} />
        </FormField>
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Years of experience" htmlFor="drv-exp" error={errors.experience} required>
          <input id="drv-exp" type="number" inputMode="numeric" min={0} max={70} value={experience} onChange={changeExperience} aria-invalid={errors.experience ? true : undefined} aria-describedby={errors.experience ? 'drv-exp-error' : undefined} className={INPUT_CLASS} disabled={saving} />
        </FormField>
        <FormField label="Status" htmlFor="drv-status">
          <select id="drv-status" value={status} onChange={changeStatus} className={INPUT_CLASS} disabled={saving}>
            <option value="active">Active</option>
            <option value="inactive">Inactive</option>
          </select>
        </FormField>
      </div>
      <fieldset className={`space-y-4 p-4 ${DATA_CARD_CLASS}`}>
        <legend className="px-1 text-sm font-semibold text-ink-900">Identity and safety details (required so the driver can be traced)</legend>
        <div className="grid gap-4 sm:grid-cols-2">
          <FormField label="Date of birth" htmlFor="drv-dob" required>
            <input id="drv-dob" type="date" value={ex.date_of_birth} onChange={setExtra('date_of_birth')} className={INPUT_CLASS} disabled={saving} />
          </FormField>
          <FormField label="Blood group (optional)" htmlFor="drv-blood">
            <select id="drv-blood" value={ex.blood_group} onChange={setExtra('blood_group')} className={INPUT_CLASS} disabled={saving}>
              <option value="">Not stated</option>
              {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map((b) => (
                <option key={b} value={b}>{b}</option>
              ))}
            </select>
          </FormField>
          <FormField label="Alternate mobile (optional)" htmlFor="drv-alt">
            <input id="drv-alt" type="tel" inputMode="tel" value={ex.alt_mobile} onChange={setExtra('alt_mobile')} className={INPUT_CLASS} disabled={saving} />
          </FormField>
          <FormField label="Licence class" htmlFor="drv-class" required>
            <select id="drv-class" value={ex.license_class} onChange={setExtra('license_class')} className={INPUT_CLASS} disabled={saving}>
              <option value="">Select class</option>
              {['LMV', 'LMV-TR', 'HMV', 'HPMV', 'MCWG'].map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </FormField>
        </div>
        <FormField label="Home address" htmlFor="drv-address" required>
          <input id="drv-address" type="text" maxLength={255} value={ex.address} onChange={setExtra('address')} className={INPUT_CLASS} disabled={saving} />
        </FormField>
        <div className="grid gap-4 sm:grid-cols-2">
          <FormField label="City" htmlFor="drv-city" required>
            <input id="drv-city" type="text" maxLength={100} value={ex.city} onChange={setExtra('city')} className={INPUT_CLASS} disabled={saving} />
          </FormField>
          <FormField label="Pincode (optional)" htmlFor="drv-pin">
            <input id="drv-pin" type="text" inputMode="numeric" maxLength={6} value={ex.pincode} onChange={setExtra('pincode')} className={INPUT_CLASS} disabled={saving} />
          </FormField>
          <FormField label="ID proof type" htmlFor="drv-idtype" required>
            <select id="drv-idtype" value={ex.id_proof_type} onChange={setExtra('id_proof_type')} className={INPUT_CLASS} disabled={saving}>
              <option value="">Select ID type</option>
              <option value="aadhaar">Aadhaar</option>
              <option value="voter_id">Voter ID</option>
              <option value="passport">Passport</option>
              <option value="pan">PAN</option>
            </select>
          </FormField>
          <FormField label="ID proof number" htmlFor="drv-idnum" required>
            <input id="drv-idnum" type="text" maxLength={30} value={ex.id_proof_number} onChange={setExtra('id_proof_number')} className={INPUT_CLASS} disabled={saving} />
          </FormField>
          <FormField label="Emergency contact name" htmlFor="drv-ecname" required>
            <input id="drv-ecname" type="text" maxLength={150} value={ex.emergency_contact_name} onChange={setExtra('emergency_contact_name')} className={INPUT_CLASS} disabled={saving} />
          </FormField>
          <FormField label="Emergency contact phone" htmlFor="drv-ecphone" required>
            <input id="drv-ecphone" type="tel" inputMode="tel" value={ex.emergency_contact_phone} onChange={setExtra('emergency_contact_phone')} className={INPUT_CLASS} disabled={saving} />
          </FormField>
          <FormField label="Emergency contact relation" htmlFor="drv-ecrel" required>
            <input id="drv-ecrel" type="text" maxLength={40} placeholder="e.g. Spouse, Father" value={ex.emergency_contact_relation} onChange={setExtra('emergency_contact_relation')} className={INPUT_CLASS} disabled={saving} />
          </FormField>
          <FormField label="Badge number (optional)" htmlFor="drv-badge">
            <input id="drv-badge" type="text" maxLength={40} value={ex.badge_number} onChange={setExtra('badge_number')} className={INPUT_CLASS} disabled={saving} />
          </FormField>
          <FormField label="Police verification (optional)" htmlFor="drv-pv">
            <select id="drv-pv" value={ex.police_verification_status} onChange={setExtra('police_verification_status')} className={INPUT_CLASS} disabled={saving}>
              <option value="none">Not done</option>
              <option value="pending">Pending</option>
              <option value="verified">Verified</option>
            </select>
          </FormField>
          <FormField label="Verification date (optional)" htmlFor="drv-pvd">
            <input id="drv-pvd" type="date" value={ex.police_verification_date} onChange={setExtra('police_verification_date')} className={INPUT_CLASS} disabled={saving} />
          </FormField>
        </div>
        {errors.extra && (
          <p role="alert" className="text-sm font-medium text-danger-600">
            {errors.extra}
          </p>
        )}
      </fieldset>
      <FormField label="Service area note (optional)" htmlFor="drv-area">
        <input id="drv-area" type="text" maxLength={255} value={area} onChange={changeArea} className={INPUT_CLASS} disabled={saving} />
      </FormField>
      {showBranch && (
        <FormField label="Branch" htmlFor="drv-branch">
          <select id="drv-branch" value={branchId} onChange={changeBranch} className={INPUT_CLASS} disabled={saving}>
            <option value="0">No branch</option>
            {branches.map((b) => (
              <option key={b.id} value={b.id}>
                {b.name}
              </option>
            ))}
          </select>
        </FormField>
      )}
      {formError && (
        <p role="alert" className="text-sm font-medium text-danger-600">
          {formError}
        </p>
      )}
      <FormActions saving={saving} submitLabel={initial ? 'Save driver' : 'Add driver'} onCancel={onCancel} />
    </form>
  );
}

// TRACE: branch sheet → collects name, address, city, primary flag, status → create or update → onSaved().
//        Preconditions: initial null = create. Postconditions: input kept on failure. Edge cases: blank name, no city
//        chosen, city list empty (message), server refusal inline.
function BranchForm({ initial, cities, onSaved, onCancel }: { initial: VendorBranch | null; cities: City[]; onSaved: () => void; onCancel: () => void }) {
  const toast = useToast();
  const [name, setName] = useState(initial?.name ?? '');
  const [address, setAddress] = useState(initial?.address ?? '');
  const [cityId, setCityId] = useState(String(initial?.city_id ?? 0));
  const [primary, setPrimary] = useState(initial?.is_primary ?? false);
  const [status, setStatus] = useState<'active' | 'inactive'>(initial?.status ?? 'active');
  const [errors, setErrors] = useState<{ name?: string; city?: string }>({});
  const [saving, setSaving] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // TRACE: name input change → stores text → void.
  const changeName = (e: ChangeEvent<HTMLInputElement>) => setName(e.target.value);
  // TRACE: address input change → stores text → void.
  const changeAddress = (e: ChangeEvent<HTMLTextAreaElement>) => setAddress(e.target.value);
  // TRACE: city select change → stores id text → void.
  const changeCity = (e: ChangeEvent<HTMLSelectElement>) => setCityId(e.target.value);
  // TRACE: primary checkbox change → stores boolean → void.
  const changePrimary = (e: ChangeEvent<HTMLInputElement>) => setPrimary(e.target.checked);
  // TRACE: status select change → stores status → void. Edge cases: unknown value → active.
  const changeStatus = (e: ChangeEvent<HTMLSelectElement>) => setStatus(e.target.value === 'inactive' ? 'inactive' : 'active');

  // TRACE: form submit → validates → POST/PUT → toast + onSaved. Preconditions: not already saving.
  //        Postconditions: inputs kept on failure. Edge cases: blank name, no city, server error.
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    const next: { name?: string; city?: string } = {};
    if (name.trim() === '') next.name = 'Branch name is required.';
    if (Number(cityId) <= 0) next.city = 'Choose a city.';
    setErrors(next);
    if (next.name || next.city) return;
    const input = { name: name.trim(), address: address.trim(), city_id: Number(cityId), is_primary: primary, status };
    setSaving(true);
    setFormError(null);
    try {
      const res = initial ? await updateBranch(initial.id, input) : await createBranch(input);
      toast.show(res.message, 'success');
      onSaved();
    } catch (err) {
      setFormError(messageOf(err, 'Could not save the branch. Please try again.'));
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={submit} className="space-y-4" noValidate>
      <FormField label="Branch name" htmlFor="br-name" error={errors.name}>
        <input id="br-name" type="text" value={name} onChange={changeName} aria-invalid={errors.name ? true : undefined} aria-describedby={errors.name ? 'br-name-error' : undefined} className={INPUT_CLASS} disabled={saving} />
      </FormField>
      <FormField label="City" htmlFor="br-city" error={errors.city}>
        <select id="br-city" value={cityId} onChange={changeCity} aria-invalid={errors.city ? true : undefined} aria-describedby={errors.city ? 'br-city-error' : undefined} className={INPUT_CLASS} disabled={saving}>
          <option value="0">Choose a city</option>
          {cities.map((c) => (
            <option key={c.id} value={c.id}>
              {c.name}
            </option>
          ))}
        </select>
      </FormField>
      <FormField label="Address" htmlFor="br-address">
        <textarea id="br-address" rows={3} value={address} onChange={changeAddress} className={INPUT_CLASS} disabled={saving} />
      </FormField>
      <FormField label="Status" htmlFor="br-status">
        <select id="br-status" value={status} onChange={changeStatus} className={INPUT_CLASS} disabled={saving}>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
      </FormField>
      <div className="flex items-center gap-2">
        <input id="br-primary" type="checkbox" checked={primary} onChange={changePrimary} disabled={saving} className="h-4 w-4 rounded border-ink-300 text-brand-600 focus:ring-2 focus:ring-brand-500/30" />
        <label htmlFor="br-primary" className="text-sm text-ink-800">
          This is my primary branch
        </label>
      </div>
      {formError && (
        <p role="alert" className="text-sm font-medium text-danger-600">
          {formError}
        </p>
      )}
      <FormActions saving={saving} submitLabel={initial ? 'Save branch' : 'Add branch'} onCancel={onCancel} />
    </form>
  );
}

// TRACE: document sheet → loads the entity's documents and allowed types, renders one row per type with validity badges,
//        View, and an upload form (file + expiry) → panel. Preconditions: entity id belongs to the vendor.
//        Postconditions: after each upload the list is re-fetched; stale loads ignored. Edge cases: loading, failure
//        (retry), no allowed types (empty state), document with no expiry date.
function DocsPanel({ kind, entityId }: { kind: EntityKind; entityId: number }) {
  const guard = useRequestGuard();
  const [docs, setDocs] = useState<FleetDoc[]>([]);
  const [docTypes, setDocTypes] = useState<string[]>([]);
  const [maxUploadMb, setMaxUploadMb] = useState<number | undefined>(undefined);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // TRACE: mount / after upload → GET docs for this entity → stores docs + allowed types.
  //        Preconditions: none. Postconditions: newest response wins. Edge cases: failure (error + retry).
  const load = useCallback(async () => {
    const id = guard.begin();
    setLoading(true);
    setError(null);
    try {
      const res = await getFleetDocs(kind, entityId);
      if (!guard.isCurrent(id)) return;
      setDocs(res.docs);
      setDocTypes(res.doc_types);
      setMaxUploadMb(res.max_upload_mb);
    } catch (err) {
      if (guard.isCurrent(id)) setError(messageOf(err, 'Could not load documents. Please try again.'));
    } finally {
      if (guard.isCurrent(id)) setLoading(false);
    }
  }, [guard, kind, entityId]);

  // TRACE: mount → loads the documents → void. Edge cases: stale response ignored.
  useEffect(() => {
    void load();
  }, [load]);

  if (loading) {
    return (
      <div className="space-y-3" aria-busy="true" aria-label="Loading documents">
        <Skeleton className="h-24 w-full rounded-xl" />
        <Skeleton className="h-24 w-full rounded-xl" />
      </div>
    );
  }
  if (error) return <ErrorBanner message={error} onRetry={load} />;
  if (docTypes.length === 0) return <EmptyState title="No documents required" description="There are no document types for this item." />;
  return (
    <ul className="space-y-3">
      {docTypes.map((t) => (
        <DocTypeRow key={t} kind={kind} entityId={entityId} docType={t} doc={[...docs].filter((d) => d.doc_type === t).sort((a, b) => b.id - a.id)[0] ?? null} maxUploadMb={maxUploadMb} onUploaded={load} />
      ))}
    </ul>
  );
}

// TRACE: DocsPanel → renders one document type: newest document with validity + review badges and View, plus an upload
//        form (file up to 5MB, optional expiry) → calls onUploaded() after a successful upload.
//        Preconditions: docType allowed for the entity. Postconditions: file input resets after success; upload button
//        disabled while pending; failures keep the chosen file and show the message. Edge cases: no file chosen, file
//        over 5MB, unsupported type, View failing (inline message), unmount while the blob URL is alive (revoked).
function DocTypeRow({ kind, entityId, docType, doc, maxUploadMb, onUploaded }: { kind: EntityKind; entityId: number; docType: string; doc: FleetDoc | null; maxUploadMb?: number; onUploaded: () => void }) {
  const toast = useToast();
  const maxMb = maxUploadMb && maxUploadMb > 0 ? maxUploadMb : FALLBACK_MAX_MB;
  const maxBytes = maxMb * 1024 * 1024;
  const [file, setFile] = useState<File | null>(null);
  const [expiry, setExpiry] = useState('');
  const [inputKey, setInputKey] = useState(0);
  const [uploading, setUploading] = useState(false);
  const [viewing, setViewing] = useState(false);
  const [rowError, setRowError] = useState<string | null>(null);
  const blobUrls = useRef<{ url: string; timer: number }[]>([]);
  const idBase = `doc-${kind}-${entityId}-${docType}`;

  // TRACE: unmount → clears pending revoke timers and revokes any blob URLs opened from this row → no leaked object URLs.
  //        Edge cases: nothing opened (no-op).
  useEffect(() => {
    const held = blobUrls.current;
    return () => {
      held.forEach((h) => {
        window.clearTimeout(h.timer);
        URL.revokeObjectURL(h.url);
      });
    };
  }, []);

  // TRACE: file input change → stores the chosen file → void. Edge cases: dialog cancelled (null).
  const changeFile = (e: ChangeEvent<HTMLInputElement>) => setFile(e.target.files?.[0] ?? null);
  // TRACE: expiry input change → stores the date text → void.
  const changeExpiry = (e: ChangeEvent<HTMLInputElement>) => setExpiry(e.target.value);

  // TRACE: View click → downloads the document as a blob and opens it in a new tab → void.
  //        Preconditions: doc exists. Postconditions: blob URL revoked after 60s or on unmount. Edge cases: failure → inline message.
  const view = async () => {
    if (!doc || viewing) return;
    setViewing(true);
    setRowError(null);
    try {
      const url = await fetchVendorDocFileUrl(doc.id);
      window.open(url, '_blank', 'noreferrer');
      const timer = window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
      blobUrls.current.push({ url, timer });
    } catch (err) {
      setRowError(messageOf(err, 'Could not open this document. Please try again.'));
    } finally {
      setViewing(false);
    }
  };

  // TRACE: form submit → validates the file → multipart upload → toast, reset inputs, reload docs.
  //        Preconditions: not already uploading. Postconditions: inputs cleared only on success. Edge cases: no file,
  //        file over 5MB, server rejection (inline message with the ApiError text).
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (uploading) return;
    if (!file) {
      setRowError('Choose a file to upload.');
      return;
    }
    if (file.size > maxBytes) {
      setRowError(`The file must be under ${maxMb}MB.`);
      return;
    }
    setUploading(true);
    setRowError(null);
    try {
      await uploadFleetDoc({ entity: kind, entityId, docType, file, expiryDate: docNeedsExpiry(docType) ? expiry : '' });
      toast.show(`${DOC_LABEL[docType] ?? docType} uploaded.`, 'success');
      setFile(null);
      setExpiry('');
      setInputKey((k) => k + 1);
      onUploaded();
    } catch (err) {
      setRowError(messageOf(err, 'Upload failed. Please try again.'));
    } finally {
      setUploading(false);
    }
  };

  return (
    <li className={`${DATA_CARD_CLASS} p-4`}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div>
          <p className="font-semibold text-ink-900">{DOC_LABEL[docType] ?? docType}</p>
          {doc ? (
            <p className="text-xs text-ink-600">
              Uploaded {formatDateTime(doc.uploaded_at)}
              {doc.expiry_date ? ` · Expires ${formatDateTime(doc.expiry_date)}` : ''}
            </p>
          ) : (
            <p className="text-xs text-ink-600">Not uploaded yet</p>
          )}
        </div>
        {doc && (
          <div className="flex flex-wrap items-center gap-1.5">
            <ToneBadge tone={VALIDITY_TONE[doc.validity]}>{VALIDITY_LABEL[doc.validity]}</ToneBadge>
            <ToneBadge tone={REVIEW_TONE[doc.status] ?? 'neutral'}>{REVIEW_LABEL[doc.status] ?? doc.status}</ToneBadge>
            <button type="button" onClick={view} disabled={viewing} className={LINK_BUTTON_CLASS} aria-label={`View ${DOC_LABEL[docType] ?? docType}`}>
              {viewing ? 'Opening…' : 'View'}
            </button>
          </div>
        )}
      </div>
      <form onSubmit={submit} className="mt-3 space-y-3" noValidate>
        <FormField label={doc ? 'Replace file' : 'File'} htmlFor={`${idBase}-file`} hint={`JPG, PNG, WebP or PDF, up to ${maxMb}MB.`}>
          <input
            key={inputKey}
            id={`${idBase}-file`}
            type="file"
            accept={docIsPhoto(docType) ? 'image/jpeg,image/png,image/webp' : 'image/jpeg,image/png,image/webp,application/pdf'}
            onChange={changeFile}
            disabled={uploading}
            className="block w-full text-sm text-ink-700 file:mr-3 file:rounded-md file:border-0 file:bg-ink-100 file:px-3 file:py-1.5 file:text-sm file:font-medium file:text-ink-700 hover:file:bg-ink-200"
          />
        </FormField>
        {docNeedsExpiry(docType) && (
          <FormField label="Expiry date (optional)" htmlFor={`${idBase}-expiry`}>
            <input id={`${idBase}-expiry`} type="date" value={expiry} onChange={changeExpiry} disabled={uploading} className={INPUT_CLASS} />
          </FormField>
        )}
        {rowError && (
          <p role="alert" className="text-sm font-medium text-danger-600">
            {rowError}
          </p>
        )}
        <Button type="submit" size="sm" loading={uploading}>
          {doc ? 'Re-upload' : 'Upload'}
        </Button>
      </form>
    </li>
  );
}
