import { useCallback, useEffect, useState, type ChangeEvent } from 'react';
import { Link } from 'react-router-dom';
import { ApiError } from '../../lib/api';
import {
  getVendorPerformance,
  type CategoryScore,
  type PerformanceEntity,
  type PerformancePoint,
  type VendorPerformance,
} from '../../lib/api-vendor-marketplace';
import { Button } from '../../components/ui/Button';
import { EmptyState } from '../../components/ui/EmptyState';
import { ErrorBanner } from '../../components/ui/ErrorBanner';
import { Skeleton } from '../../components/ui/Skeleton';
import { FormField, INPUT_CLASS, StarsDisplay, useRequestGuard } from './vendor-mkt-shared';
import { DATA_CARD_CLASS } from '../../components/ui/Zone';

type MetricKey = 'bookings_completed' | 'completion_rate' | 'on_time_pct' | 'avg_rating' | 'cancellation_rate';

interface MetricDef {
  key: MetricKey;
  label: string;
  max: number | null;
  suffix: string;
  decimals: number;
}

const METRICS: MetricDef[] = [
  { key: 'bookings_completed', label: 'Completed trips', max: null, suffix: '', decimals: 0 },
  { key: 'completion_rate', label: 'Completion rate', max: 100, suffix: '%', decimals: 1 },
  { key: 'on_time_pct', label: 'On-time arrivals', max: 100, suffix: '%', decimals: 1 },
  { key: 'avg_rating', label: 'Average rating', max: 5, suffix: '/5', decimals: 2 },
  { key: 'cancellation_rate', label: 'Cancellation rate', max: 100, suffix: '%', decimals: 1 },
];

const CATEGORY_LABEL: Record<string, string> = {
  overall: 'Overall',
  service_quality: 'Service quality',
  communication: 'Communication',
  reliability: 'Reliability',
  vehicle_quality: 'Vehicle quality',
  behaviour: 'Behaviour',
  punctuality: 'Punctuality',
  driving: 'Driving',
  cleanliness: 'Cleanliness',
};

const PAGE_SKELETONS = ['tiles', 'trend', 'categories'];

// TRACE: any metric display → formats a nullable number with its unit → text. Preconditions: def describes the metric.
//        Postconditions: never invents a number. Edge cases: null (no data) → "No data".
function formatMetric(value: number | null, def: MetricDef): string {
  if (value === null) return 'No data';
  return `${value.toFixed(def.decimals)}${def.suffix}`;
}

// TRACE: any metric read → picks one metric's value out of a snapshot → number or null. Preconditions: point exists.
//        Postconditions: null stays null (never coerced to 0). Edge cases: none.
function metricValue(point: PerformancePoint, key: MetricKey): number | null {
  return point[key];
}

// TRACE: category rows → readable name for a rating category key → string. Edge cases: unknown key → words capitalised.
function categoryLabel(key: string): string {
  if (CATEGORY_LABEL[key]) return CATEGORY_LABEL[key];
  const spaced = key.replace(/_/g, ' ');
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

// TRACE: any entity → true when there is nothing to show (no monthly snapshots and no rated categories) → boolean.
//        Edge cases: none.
function isEmptyEntity(e: PerformanceEntity): boolean {
  return e.trend.length === 0 && e.categories.length === 0;
}

// TRACE: route /app/vendor/performance → loads the vendor performance payload; shows the latest-month tiles, the trend
//        bars with a metric picker, the category breakdown and (fleet vendors) per-driver and per-vehicle tables with
//        expandable detail → nothing is invented, missing values read "No data". Preconditions: vendor session.
//        Postconditions: stale responses dropped. Edge cases: not a vendor (message), failure (retry), no data at all
//        (empty state), individual vendor (no driver/vehicle tables), entity without data (row says so).
export function VendorPerformancePage() {
  const guard = useRequestGuard();
  const [data, setData] = useState<VendorPerformance | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notVendor, setNotVendor] = useState(false);

  // TRACE: mount / retry → GET performance → stores it. Preconditions: none. Postconditions: newest response wins.
  //        Edge cases: 403/not_a_vendor, other failure (error + retry), stale (ignored).
  const load = useCallback(async () => {
    const id = guard.begin();
    setLoading(true);
    setError(null);
    try {
      const res = await getVendorPerformance();
      if (guard.isCurrent(id)) setData(res);
    } catch (err) {
      if (!guard.isCurrent(id)) return;
      if (err instanceof ApiError && (err.status === 403 || err.code === 'not_a_vendor')) setNotVendor(true);
      else setError(err instanceof ApiError ? err.message : 'Could not load your performance. Please try again.');
    } finally {
      if (guard.isCurrent(id)) setLoading(false);
    }
  }, [guard]);

  // TRACE: mount → runs the first load → void.
  useEffect(() => {
    void load();
  }, [load]);

  if (notVendor) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <div className="rounded-2xl border border-ink-100 bg-ink-50/60 p-10">
          <h1 className="text-xl font-bold text-ink-900">Vendor access required</h1>
          <p className="mt-2 text-ink-600">Performance is only available to registered driver-partners.</p>
          <div className="mt-6">
            <Link to="/vendor/dashboard">
              <Button>Go to vendor dashboard</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 sm:py-10 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Performance</h1>
          <p className="text-sm text-ink-600">How your trips, ratings and punctuality look month by month.</p>
        </div>
        <Link to="/vendor/dashboard">
          <Button variant="secondary" size="sm">
            Back to dashboard
          </Button>
        </Link>
      </div>

      {loading && (
        <div className="mt-6 space-y-4" aria-busy="true" aria-label="Loading performance">
          {PAGE_SKELETONS.map((k) => (
            <Skeleton key={k} className="h-40 w-full rounded-xl" />
          ))}
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {!loading && !error && data && isEmptyEntity(data.vendor) && (
        <div className="mt-6">
          <EmptyState
            title="No performance data yet"
            description="Monthly figures and ratings appear here after you complete trips and customers rate them."
          />
        </div>
      )}

      {!loading && !error && data && !isEmptyEntity(data.vendor) && (
        <div className="mt-6 space-y-8">
          <section aria-labelledby="overview-heading">
            <h2 id="overview-heading" className="text-lg font-semibold text-ink-900">
              Your account
            </h2>
            <div className="mt-3">
              <EntityDetail entity={data.vendor} idPrefix="vendor" />
            </div>
          </section>

          {data.vendor_type === 'fleet' && (
            <>
              <section aria-labelledby="drivers-heading">
                <h2 id="drivers-heading" className="text-lg font-semibold text-ink-900">
                  Drivers
                </h2>
                {data.drivers.length === 0 ? (
                  <div className="mt-3">
                    <EmptyState title="No drivers" description="Add drivers in My fleet to see how each one performs." />
                  </div>
                ) : (
                  <EntityTable
                    caption="Driver performance, latest month"
                    nameHeader="Driver"
                    rows={data.drivers.map((d) => ({ id: d.id, name: d.name, rating: d.rating, entity: d }))}
                    idPrefix="driver"
                  />
                )}
              </section>

              <section aria-labelledby="vehicles-heading">
                <h2 id="vehicles-heading" className="text-lg font-semibold text-ink-900">
                  Vehicles
                </h2>
                {data.vehicles.length === 0 ? (
                  <div className="mt-3">
                    <EmptyState title="No vehicles" description="Add vehicles in My fleet to see how each one performs." />
                  </div>
                ) : (
                  <EntityTable
                    caption="Vehicle performance, latest month"
                    nameHeader="Vehicle"
                    rows={data.vehicles.map((v) => ({ id: v.id, name: v.label || `Vehicle #${v.id}`, rating: null, entity: v }))}
                    idPrefix="vehicle"
                  />
                )}
              </section>
            </>
          )}
        </div>
      )}
    </div>
  );
}

// TRACE: performance page → renders the latest-month tiles, trend bars and category breakdown for one entity → block.
//        Preconditions: entity from the API. Postconditions: metric picker state is local to this block.
//        Edge cases: no snapshots (tiles and trend replaced by a sentence), no categories (sentence), null metrics
//        read "No data".
function EntityDetail({ entity, idPrefix }: { entity: PerformanceEntity; idPrefix: string }) {
  const latest = entity.trend.length > 0 ? entity.trend[entity.trend.length - 1] : null;
  return (
    <div className="space-y-6">
      {latest ? (
        <div>
          <p className="text-sm text-ink-600">Latest month: {latest.period}</p>
          <div className="mt-2 grid grid-cols-2 gap-3 lg:grid-cols-4">
            {METRICS.slice(0, 4).map((m) => (
              <div key={m.key} className={`${DATA_CARD_CLASS} p-4`}>
                <p className="text-xs font-medium uppercase tracking-wide text-ink-600">{m.label}</p>
                <p className="mt-2 text-xl font-bold text-ink-900">{formatMetric(metricValue(latest, m.key), m)}</p>
              </div>
            ))}
          </div>
          <p className="mt-2 text-xs text-ink-600">
            Complaints in {latest.period}: {latest.complaint_count} &middot; Cancelled trips: {latest.bookings_cancelled}
            {latest.response_time_avg_secs !== null ? ` · Average response time: ${latest.response_time_avg_secs}s` : ''}
          </p>
        </div>
      ) : (
        <p className="text-sm text-ink-600">No monthly snapshots yet.</p>
      )}
      <TrendChart points={entity.trend} idPrefix={idPrefix} />
      <CategoryBars categories={entity.categories} />
    </div>
  );
}

// TRACE: EntityDetail → renders the last months as vertical bars for the chosen metric, each with its value and month as
//        visible text → chart. Preconditions: points oldest first. Postconditions: bars scale to 100 (percent), 5
//        (rating) or the largest count; the list is the accessible representation (value text on every bar).
//        Edge cases: no points (sentence), null value (empty slot labelled "No data", no bar), all-zero counts (bars at
//        zero height, values still shown).
function TrendChart({ points, idPrefix }: { points: PerformancePoint[]; idPrefix: string }) {
  const [metricKey, setMetricKey] = useState<MetricKey>('bookings_completed');
  const def = METRICS.find((m) => m.key === metricKey) ?? METRICS[0];

  // TRACE: metric select change → stores the chosen metric key (unknown values fall back to completed trips) → void.
  const changeMetric = (e: ChangeEvent<HTMLSelectElement>) => {
    const found = METRICS.find((m) => m.key === e.target.value);
    setMetricKey(found ? found.key : 'bookings_completed');
  };

  if (points.length === 0) return null;
  const values = points.map((p) => metricValue(p, def.key));
  const numeric = values.filter((v): v is number => v !== null);
  const scaleMax = def.max ?? Math.max(1, ...numeric);

  return (
    <div className={`${DATA_CARD_CLASS} p-4`}>
      <div className="flex flex-wrap items-end justify-between gap-3">
        <h3 className="text-base font-semibold text-ink-900">Trend, last {points.length} month{points.length === 1 ? '' : 's'}</h3>
        <div className="w-full sm:w-56">
          <FormField label="Show" htmlFor={`${idPrefix}-metric`}>
            <select id={`${idPrefix}-metric`} value={metricKey} onChange={changeMetric} className={INPUT_CLASS}>
              {METRICS.map((m) => (
                <option key={m.key} value={m.key}>
                  {m.label}
                </option>
              ))}
            </select>
          </FormField>
        </div>
      </div>
      <ol className="mt-4 flex items-end gap-2 sm:gap-4" aria-label={`${def.label} by month`}>
        {points.map((p) => {
          const v = metricValue(p, def.key);
          const pct = v === null ? 0 : Math.max(0, Math.min(100, (v / scaleMax) * 100));
          return (
            <li key={p.period} className="flex min-w-0 flex-1 flex-col items-center">
              <span className="text-xs font-semibold text-ink-900">{v === null ? 'No data' : formatMetric(v, def)}</span>
              <div className="mt-1 flex h-32 w-full items-end rounded-md bg-ink-50">
                {v !== null && <div className="w-full rounded-md bg-brand-600" style={{ height: `${pct}%` }} aria-hidden="true" />}
              </div>
              <span className="mt-1 text-xs text-ink-600">{p.period}</span>
            </li>
          );
        })}
      </ol>
    </div>
  );
}

// TRACE: EntityDetail → renders each rating category as a labelled horizontal bar out of 5 with the number of ratings →
//        list. Preconditions: categories from the API. Postconditions: score text is shown next to the bar (not colour
//        alone). Edge cases: no ratings (sentence), single rating (singular wording).
function CategoryBars({ categories }: { categories: CategoryScore[] }) {
  return (
    <div className={`${DATA_CARD_CLASS} p-4`}>
      <h3 className="text-base font-semibold text-ink-900">Ratings by category (last 12 months)</h3>
      {categories.length === 0 ? (
        <p className="mt-2 text-sm text-ink-600">No ratings yet.</p>
      ) : (
        <ul className="mt-3 space-y-3">
          {categories.map((c) => (
            <li key={c.category}>
              <div className="flex items-baseline justify-between gap-3 text-sm">
                <span className="font-medium text-ink-900">{categoryLabel(c.category)}</span>
                <span className="text-ink-700">
                  {c.avg.toFixed(2)} / 5 &middot; {c.count} rating{c.count === 1 ? '' : 's'}
                </span>
              </div>
              <div className="mt-1 h-2 w-full rounded-full bg-ink-100" aria-hidden="true">
                <div className="h-2 rounded-full bg-brand-600" style={{ width: `${Math.max(0, Math.min(100, (c.avg / 5) * 100))}%` }} />
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

// TRACE: performance page (fleet) → renders a table of entities with their latest-month metrics; each row expands to the
//        full trend and category breakdown → table. Preconditions: rows non-empty. Postconditions: expansion is a real
//        button with aria-expanded/aria-controls. Edge cases: entity without snapshots (cells read "No data"),
//        driver's overall rating shown as stars when present.
function EntityTable({
  caption,
  nameHeader,
  rows,
  idPrefix,
}: {
  caption: string;
  nameHeader: string;
  rows: { id: number; name: string; rating: number | null; entity: PerformanceEntity }[];
  idPrefix: string;
}) {
  return (
    <div className={`mt-3 overflow-x-auto ${DATA_CARD_CLASS}`}>
      <table className="min-w-full divide-y divide-ink-100 text-sm">
        <caption className="sr-only">{caption}</caption>
        <thead className="bg-ink-50 text-left text-xs font-semibold uppercase tracking-wide text-ink-600">
          <tr>
            <th scope="col" className="px-4 py-3">{nameHeader}</th>
            <th scope="col" className="px-4 py-3">Rating</th>
            <th scope="col" className="px-4 py-3 text-right">Completed</th>
            <th scope="col" className="px-4 py-3 text-right">Completion</th>
            <th scope="col" className="px-4 py-3 text-right">On time</th>
            <th scope="col" className="px-4 py-3 text-right">Complaints</th>
            <th scope="col" className="px-4 py-3"><span className="sr-only">Details</span></th>
          </tr>
        </thead>
        {rows.map((r) => (
          <EntityTableRow key={r.id} row={r} idPrefix={idPrefix} />
        ))}
      </table>
    </div>
  );
}

// TRACE: EntityTable → renders one entity row (latest-month cells) plus its expandable detail row → tbody.
//        Preconditions: row from the API. Postconditions: toggle button names the entity. Edge cases: no snapshot (dashes
//        replaced by "No data"), no rating (text "No rating").
function EntityTableRow({ row, idPrefix }: { row: { id: number; name: string; rating: number | null; entity: PerformanceEntity }; idPrefix: string }) {
  const [open, setOpen] = useState(false);
  const latest = row.entity.trend.length > 0 ? row.entity.trend[row.entity.trend.length - 1] : null;
  const panelId = `${idPrefix}-${row.id}-detail`;
  // TRACE: table cell → formats one latest-month metric for this entity → text. Preconditions: none.
  //        Postconditions: never invents a value. Edge cases: no snapshot → "No data", null metric → "No data".
  const cell = (key: MetricKey): string => {
    if (!latest) return 'No data';
    const def = METRICS.find((m) => m.key === key) ?? METRICS[0];
    return formatMetric(metricValue(latest, key), def);
  };

  // TRACE: Details button → toggles the expanded detail row → void.
  const toggle = () => setOpen((o) => !o);

  return (
    <tbody className="divide-y divide-ink-100 bg-white">
      <tr>
        <th scope="row" className="px-4 py-3 text-left font-medium text-ink-900">{row.name}</th>
        <td className="whitespace-nowrap px-4 py-3">
          {row.rating !== null && row.rating > 0 ? (
            <span className="inline-flex items-center gap-1">
              <StarsDisplay value={row.rating} />
            </span>
          ) : (
            <span className="text-ink-600">No rating</span>
          )}
        </td>
        <td className="whitespace-nowrap px-4 py-3 text-right text-ink-900">{cell('bookings_completed')}</td>
        <td className="whitespace-nowrap px-4 py-3 text-right text-ink-900">{cell('completion_rate')}</td>
        <td className="whitespace-nowrap px-4 py-3 text-right text-ink-900">{cell('on_time_pct')}</td>
        <td className="whitespace-nowrap px-4 py-3 text-right text-ink-900">{latest ? latest.complaint_count : 'No data'}</td>
        <td className="whitespace-nowrap px-4 py-3 text-right">
          <button
            type="button"
            onClick={toggle}
            aria-expanded={open}
            aria-controls={panelId}
            className="rounded-md text-sm font-medium text-brand-700 hover:text-brand-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
          >
            {open ? 'Hide' : 'Show'} details<span className="sr-only"> for {row.name}</span>
          </button>
        </td>
      </tr>
      {open && (
        <tr id={panelId}>
          <td colSpan={7} className="bg-ink-50/60 px-4 py-4">
            {isEmptyEntity(row.entity) ? (
              <p className="text-sm text-ink-600">No performance data for {row.name} yet.</p>
            ) : (
              <EntityDetail entity={row.entity} idPrefix={`${idPrefix}-${row.id}`} />
            )}
          </td>
        </tr>
      )}
    </tbody>
  );
}
