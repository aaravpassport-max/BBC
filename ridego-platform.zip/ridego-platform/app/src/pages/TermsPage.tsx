import { useEffect, useState } from 'react';
import { ApiError, getPlatformNotices, type PlatformNotices } from '../lib/api';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { Skeleton } from '../components/ui/Skeleton';

// TRACE: route /app/terms → loads the admin-editable booking/payment wording from the server and renders the marketplace terms: RideGo facilitates bookings and collects
//        only the booking amount; the vendor/driver provides the ride, bills the client and collects the balance. → page element.
//        Preconditions: none (public) → Postconditions: notices shown, or a retry banner if the request fails → Edge cases: loading (skeleton), error (retry), stale response after unmount ignored.
export function TermsPage() {
  const [n, setN] = useState<PlatformNotices | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let live = true;
    setError(null);
    getPlatformNotices()
      .then((r) => {
        if (live) setN(r);
      })
      .catch((e: unknown) => {
        if (live) setError(e instanceof ApiError ? e.message : 'Could not load the terms. Please try again.');
      });
    return () => {
      live = false;
    };
  }, [tick]);

  return (
    <div className="mx-auto max-w-3xl px-4 py-10">
      <h1 className="text-3xl font-bold text-ink-900">Booking &amp; payment terms</h1>
      <p className="mt-2 text-sm text-ink-600">How bookings, payments and invoices work on this platform.</p>
      {error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={() => setTick((t) => t + 1)} />
        </div>
      )}
      {!n && !error && <Skeleton className="mt-6 h-48 w-full" />}
      {n && (
        <div className="mt-6 space-y-6 text-sm leading-relaxed text-ink-800">
          <section>
            <h2 className="text-lg font-semibold text-ink-900">What the platform does</h2>
            <p className="mt-2">{n.client}</p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-ink-900">{n.booking_amount_label}</h2>
            <p className="mt-2">{n.booking_amount_note}</p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-ink-900">Receipts and invoices</h2>
            <p className="mt-2">{n.receipt}</p>
          </section>
          <section>
            <h2 className="text-lg font-semibold text-ink-900">For vendors and drivers</h2>
            <p className="mt-2">{n.vendor}</p>
          </section>
        </div>
      )}
    </div>
  );
}
