import { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { getVendorBookings, advanceVendorTrip, ApiError } from '../lib/api';
import type { VendorBooking } from '../types/api';
import { Skeleton } from '../components/ui/Skeleton';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { EmptyState } from '../components/ui/EmptyState';
import { Button } from '../components/ui/Button';
import { brand } from '../lib/brand';

// ROOT-CAUSE FIX (vendor-app audit): maps each in-progress status to the
// next status the vendor can move it to, matching the transition map
// enforced server-side by ridego_vendor_advance_trip().
const NEXT_STATUS: Record<string, 'driver_en_route' | 'trip_started' | 'completed'> = {
  vendor_assigned: 'driver_en_route',
  driver_en_route: 'trip_started',
  trip_started: 'completed',
};

const NEXT_STATUS_LABEL: Record<string, string> = {
  vendor_assigned: "Mark 'Driver en route'",
  driver_en_route: 'Verify pickup OTP & start trip',
  trip_started: 'Mark trip completed',
};

const TRIP_SKELETONS = ['trip-a', 'trip-b', 'trip-c', 'trip-d', 'trip-e'];

const TABS: { key: string; label: string }[] = [
  { key: '', label: 'All' },
  { key: 'pending', label: 'Pending' },
  { key: 'confirmed', label: 'Confirmed' },
  { key: 'completed', label: 'Completed' },
  { key: 'cancelled', label: 'Cancelled' },
];

const statusStyles: Record<string, string> = {
  pending: 'bg-warning-50 text-warning-600',
  confirmed: 'bg-brand-50 text-brand-700',
  assigned: 'bg-brand-50 text-brand-700',
  vendor_assigned: 'bg-brand-50 text-brand-700',
  driver_en_route: 'bg-brand-50 text-brand-700',
  trip_started: 'bg-brand-50 text-brand-700',
  completed: 'bg-success-50 text-success-600',
  cancelled: 'bg-danger-50 text-danger-600',
};

// TRACE: any money cell → formats a number as ₹ with Indian grouping and no decimals → string.
//        n finite → pure → NaN renders '₹NaN' (callers pass API numbers only).
function currency(n: number) {
  return `₹${n.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

// TRACE: a booking's client rating → renders five stars, filled up to `value` → JSX with an aria-label.
//        value 0..5 → pure render → 0 shows all empty stars; the label states the rating so colour is not the only signal.
function StarDisplay({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-0.5" aria-label={`Rated ${value} out of 5`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <svg
          key={n}
          className={`h-3.5 w-3.5 ${n <= value ? 'text-warning-500' : 'text-ink-200'}`}
          viewBox="0 0 20 20"
          fill="currentColor"
          aria-hidden="true"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.957a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.367 2.447a1 1 0 00-.364 1.118l1.287 3.957c.3.922-.755 1.688-1.538 1.118l-3.367-2.447a1 1 0 00-1.176 0l-3.367 2.447c-.783.57-1.838-.196-1.538-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.063 9.384c-.783-.57-.38-1.81.588-1.81h4.163a1 1 0 00.95-.69l1.286-3.957z" />
        </svg>
      ))}
    </div>
  );
}

// TRACE: route /app/vendor/trips → lists the vendor's trips by status with paging, trip advance buttons with pickup OTP, and a
//        link from every row to its detail page /app/vendor/bookings/:id → unchanged behaviour otherwise.
//        Preconditions: vendor session. Postconditions: each row's route title and a "View details" link go to the
//        booking detail. Edge cases: non-vendor (access message), load failure (retry), empty list (empty state), advance
//        failure (inline per-row message).
export function VendorTripsPage() {
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [rows, setRows] = useState<VendorBooking[] | null>(null);
  const [total, setTotal] = useState(0);
  const [perPage, setPerPage] = useState(20);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notVendor, setNotVendor] = useState(false);
  const [advancingId, setAdvancingId] = useState<number | null>(null);
  const [otpInputs, setOtpInputs] = useState<Record<number, string>>({});
  const [advanceError, setAdvanceError] = useState<Record<number, string>>({});

  // TRACE: status/page change or retry → GET the vendor's bookings and keeps only the LATEST request's result (request id ref)
  //        → sets rows/total/per_page, or notVendor / error. Preconditions: none → postconditions: loading false after the latest
  //        request settles; a slower earlier response can never overwrite a newer one → edge cases: not_a_vendor, API failure, stale response.
  const loadSeq = useRef(0);
  const load = useCallback(async (s: string, p: number) => {
    const seq = ++loadSeq.current;
    setLoading(true);
    setError(null);
    setNotVendor(false);
    try {
      const res = await getVendorBookings({ status: s || undefined, page: p });
      if (seq !== loadSeq.current) return;
      setRows(res.rows);
      setTotal(res.total);
      setPerPage(res.per_page);
    } catch (err) {
      if (seq !== loadSeq.current) return;
      if (err instanceof ApiError && err.code === 'not_a_vendor') {
        setNotVendor(true);
      } else {
        setError(err instanceof ApiError ? err.message : 'Could not load your trip history. Please try again.');
      }
    } finally {
      if (seq === loadSeq.current) setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(status, page);
  }, [status, page, load]);

  // TRACE: status filter click → sets the filter and resets to page 1 → the effect reloads.
  //        s a status key or '' → status/page state updated → repeated click on the same filter is a no-op reload.
  function changeStatus(s: string) {
    setStatus(s);
    setPage(1);
  }

  // TRACE: Advance button → POSTs the next status (with the pickup OTP for trip_started) → reloads the list on success, else shows the
  //        server message under that row. b has a NEXT_STATUS entry → advancingId set while pending (button disabled, no double submit)
  //        → edge cases: no next status (ignored), wrong OTP / illegal transition (row error), network failure (row error).
  async function handleAdvance(b: VendorBooking) {
    const nextStatus = NEXT_STATUS[b.status];
    if (!nextStatus) return;
    setAdvancingId(b.id);
    setAdvanceError((prev) => ({ ...prev, [b.id]: '' }));
    try {
      await advanceVendorTrip(b.id, nextStatus, otpInputs[b.id] ?? '');
      await load(status, page);
    } catch (err) {
      setAdvanceError((prev) => ({
        ...prev,
        [b.id]: err instanceof ApiError ? err.message : 'Could not update this trip.',
      }));
    } finally {
      setAdvancingId(null);
    }
  }

  if (notVendor) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <div className="rounded-2xl border border-ink-100 bg-ink-50/60 p-10">
          <h1 className="text-xl font-bold text-ink-900">Vendor access required</h1>
          <p className="mt-2 text-ink-500">This page is only available to registered driver-partners.</p>
          <div className="mt-6">
            <Link to="/vendor/dashboard">
              <Button>Go to vendor dashboard</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const canPrev = page > 1;
  const canNext = page * perPage < total;

  return (
    <div className="min-h-full bg-ink-50">
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Trip history</h1>
          <p className="text-sm text-ink-500">Every trip you've accepted, with the estimated fare, what you collect from the client, and ratings.</p>
        </div>
        <Link to="/vendor/dashboard">
          <Button variant="secondary" size="sm">
            Back to dashboard
          </Button>
        </Link>
      </div>

      <div className="mt-6 flex gap-1 overflow-x-auto border-b border-ink-100" role="tablist" aria-label="Trip status filter">
        {TABS.map((tab) => (
          <button
            key={tab.key}
            role="tab"
            aria-selected={status === tab.key}
            onClick={() => changeStatus(tab.key)}
            className={`shrink-0 whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 ${
              status === tab.key
                ? 'border-brand-600 text-brand-700'
                : 'border-transparent text-ink-500 hover:text-ink-800'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      <div className="mt-6">
        {loading && (
          <div className="space-y-3" aria-busy="true" aria-label="Loading trip history">
            {TRIP_SKELETONS.map((k) => (
              <div key={k} className="rounded-lg bg-white p-4 shadow-xs ring-1 ring-inset ring-ink-100 sm:p-5">
                <div className="flex items-center justify-between">
                  <Skeleton className="h-4 w-40" />
                  <Skeleton className="h-5 w-20 rounded-full" />
                </div>
                <Skeleton className="mt-3 h-3 w-64" />
                <Skeleton className="mt-2 h-3 w-32" />
              </div>
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={() => load(status, page)} />}

        {!loading && !error && rows && rows.length === 0 && (
          <EmptyState
            title="No trips found"
            description="Trips you've accepted will show up here once they're recorded."
          />
        )}

        {!loading && !error && rows && rows.length > 0 && (
          <>
            <ul className="space-y-3">
              {rows.map((b) => (
                <li
                  key={b.id}
                  className="rounded-lg bg-white p-4 shadow-xs ring-1 ring-inset ring-ink-100 transition hover:ring-brand-200 sm:p-5"
                >
                  <div className="flex flex-wrap items-start justify-between gap-2">
                    <div>
                      <p className="font-semibold text-ink-900">
                        <Link
                          to={`/app/vendor/bookings/${b.id}`}
                          className="rounded hover:text-brand-700 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
                          aria-label={`View booking ${b.booking_number}, ${b.pickup_city} to ${b.drop_city}`}
                        >
                          {b.pickup_city} → {b.drop_city}
                        </Link>
                      </p>
                      <p className="mt-0.5 text-sm text-ink-500">
                        {b.journey_date} at {b.journey_time} &middot; {b.vehicle_name || 'Vehicle TBD'}
                      </p>
                    </div>
                    <span
                      className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold ${
                        statusStyles[b.status] ?? 'bg-ink-100 text-ink-600'
                      }`}
                    >
                      {b.status_label}
                    </span>
                  </div>

                  <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-ink-100 pt-3">
                    <div className="text-sm text-ink-500">
                      #{b.booking_number} &middot; <span className="font-semibold text-ink-800">{currency(b.total_fare)}</span> <span className="text-xs">est. ride fare</span>
                      {' '}&middot; <span className="capitalize">{b.payment_status}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      {b.rating != null && <StarDisplay value={b.rating} />}
                      <Link
                        to={`/app/vendor/bookings/${b.id}`}
                        className="rounded text-sm font-medium text-brand-700 hover:underline focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
                        aria-label={`View details for booking ${b.booking_number}`}
                      >
                        View details
                      </Link>
                    </div>
                  </div>

                  {/* ROOT-CAUSE FIX (vendor-app audit): show what's left for
                      the vendor/driver to collect from the client in
                      cash/UPI at drop-off — previously never surfaced here. */}
                  {b.balance_due > 0 && !['completed', 'cancelled'].includes(b.status) && (
                    <div className="mt-2 rounded-lg bg-warning-50 px-3 py-2 text-sm text-warning-700">
                      Collect <span className="font-semibold">{currency(b.balance_due)}</span> from the client and bill them directly
                      {b.token_amount > 0 ? ` (₹${b.token_amount.toLocaleString('en-IN')} booking amount already paid to ${brand().name})` : ''}
                    </div>
                  )}

                  {/* ROOT-CAUSE FIX (vendor-app audit): trip status
                      transitions + pickup OTP verification, previously
                      entirely absent from the vendor app (read-only after
                      assignment). */}
                  {NEXT_STATUS[b.status] && (
                    <div className="mt-3 flex flex-wrap items-center gap-2 border-t border-ink-100 pt-3">
                      {b.status === 'driver_en_route' && (
                        <input
                          type="text"
                          inputMode="numeric"
                          placeholder="Pickup OTP"
                          value={otpInputs[b.id] ?? ''}
                          onChange={(e) =>
                            setOtpInputs((prev) => ({ ...prev, [b.id]: e.target.value }))
                          }
                          className="w-32 rounded-lg border border-ink-200 px-3 py-1.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
                        />
                      )}
                      <Button
                        size="sm"
                        onClick={() => handleAdvance(b)}
                        loading={advancingId === b.id}
                        disabled={
                          advancingId !== null && advancingId !== b.id
                            ? true
                            : b.status === 'driver_en_route' && !otpInputs[b.id]
                        }
                      >
                        {NEXT_STATUS_LABEL[b.status]}
                      </Button>
                      {advanceError[b.id] && (
                        <span className="text-sm text-danger-600">{advanceError[b.id]}</span>
                      )}
                    </div>
                  )}
                </li>
              ))}
            </ul>

            <div className="mt-6 flex items-center justify-between">
              <p className="text-sm text-ink-500">
                Page {page} of {Math.max(1, Math.ceil(total / perPage))} &middot; {total} trip{total === 1 ? '' : 's'}
              </p>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" disabled={!canPrev} onClick={() => setPage((p) => Math.max(1, p - 1))}>
                  Previous
                </Button>
                <Button variant="secondary" size="sm" disabled={!canNext} onClick={() => setPage((p) => p + 1)}>
                  Next
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
    </div>
  );
}
