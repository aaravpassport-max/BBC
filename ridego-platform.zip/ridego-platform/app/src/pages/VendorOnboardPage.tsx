import { useState, type FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/Button';
import { vendorOnboard, ApiError } from '../lib/api';
import { SHOWCASE_CARD_CLASS } from '../components/ui/Zone';

const inputClasses =
  'mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30';
const labelClasses = 'block text-sm font-medium text-ink-700';

export function VendorOnboardPage() {
  const { user, isVendor, refresh } = useAuth();
  const navigate = useNavigate();

  const [ownerName, setOwnerName] = useState(user?.name ?? '');
  const [city, setCity] = useState('');
  const [phone, setPhone] = useState(user?.phone ?? '');
  const [businessName, setBusinessName] = useState('');
  const [businessType, setBusinessType] = useState('');
  const [totalVehicles, setTotalVehicles] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (isVendor) {
    return (
      <div className="mx-auto flex min-h-[calc(100vh-64px)] max-w-md flex-col justify-center px-4 py-12">
        <div className={`p-8 text-center ${SHOWCASE_CARD_CLASS}`}>
          <h1 className="text-xl font-bold text-ink-900">You're already a vendor</h1>
          <p className="mt-2 text-sm text-ink-600">
            Your account already has a vendor profile. Head to your dashboard to manage leads and trips.
          </p>
          <div className="mt-6">
            <Link to="/vendor/dashboard">
              <Button>Go to vendor dashboard</Button>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);

    if (!ownerName.trim()) {
      setError('Please enter your name.');
      return;
    }
    if (!city.trim()) {
      setError('Please enter your city.');
      return;
    }
    if (!phone.trim()) {
      setError('Please enter your phone number.');
      return;
    }

    setSubmitting(true);
    try {
      await vendorOnboard({
        owner_name: ownerName.trim(),
        city: city.trim(),
        phone: phone.trim(),
        business_name: businessName.trim() || undefined,
        business_type: businessType.trim() || undefined,
        total_vehicles: totalVehicles ? Number(totalVehicles) : undefined,
      });
      await refresh();
      navigate('/vendor/dashboard', { replace: true });
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not create your vendor profile. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="mx-auto flex max-w-md flex-col justify-center px-4 py-12">
      <div className={`p-8 ${SHOWCASE_CARD_CLASS}`}>
        <h1 className="text-2xl font-bold text-ink-900">Become a vendor</h1>
        <p className="mt-1 text-sm text-ink-500">
          Add a vendor profile to your existing account to start receiving ride leads.
        </p>

        <form className="mt-6 space-y-4" onSubmit={handleSubmit} noValidate>
          {error && (
            <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
              {error}
            </div>
          )}

          <div>
            <label htmlFor="onboard-owner-name" className={labelClasses}>
              Your full name
            </label>
            <input
              id="onboard-owner-name"
              required
              value={ownerName}
              onChange={(e) => setOwnerName(e.target.value)}
              autoComplete="name"
              className={inputClasses}
            />
          </div>

          <div>
            <label htmlFor="onboard-city" className={labelClasses}>
              City
            </label>
            <input
              id="onboard-city"
              required
              value={city}
              onChange={(e) => setCity(e.target.value)}
              autoComplete="address-level2"
              className={inputClasses}
            />
          </div>

          <div>
            <label htmlFor="onboard-phone" className={labelClasses}>
              Phone number
            </label>
            <input
              id="onboard-phone"
              type="tel"
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              autoComplete="tel"
              className={inputClasses}
            />
          </div>

          <div>
            <label htmlFor="onboard-business-name" className={labelClasses}>
              Business / fleet name <span className="font-normal text-ink-400">(optional)</span>
            </label>
            <input
              id="onboard-business-name"
              value={businessName}
              onChange={(e) => setBusinessName(e.target.value)}
              className={inputClasses}
            />
          </div>

          <div>
            <label htmlFor="onboard-business-type" className={labelClasses}>
              Business type <span className="font-normal text-ink-400">(optional)</span>
            </label>
            <input
              id="onboard-business-type"
              value={businessType}
              onChange={(e) => setBusinessType(e.target.value)}
              placeholder="e.g. Individual, Fleet owner"
              className={inputClasses}
            />
          </div>

          <div>
            <label htmlFor="onboard-total-vehicles" className={labelClasses}>
              Total vehicles <span className="font-normal text-ink-400">(optional)</span>
            </label>
            <input
              id="onboard-total-vehicles"
              type="number"
              min={0}
              value={totalVehicles}
              onChange={(e) => setTotalVehicles(e.target.value)}
              className={inputClasses}
            />
          </div>

          <Button type="submit" fullWidth loading={submitting} size="lg">
            Create vendor profile
          </Button>
        </form>
      </div>
    </div>
  );
}
