import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { getVendorDocs, uploadVendorDoc, fetchVendorDocFileUrl, ApiError } from '../lib/api';
import type { VendorDoc, VendorDocsResponse } from '../types/api';
import { Skeleton } from '../components/ui/Skeleton';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { EmptyState } from '../components/ui/EmptyState';
import { Button } from '../components/ui/Button';
import { docTypeLabel, docNeedsExpiry, docIsPhoto } from '../lib/doc-types';
import { DATA_CARD_CLASS } from '../components/ui/Zone';


// Matches the MySQL DATETIME format the server sends back for
// uploaded_at (see includes/vendor.php's current_time('mysql')), so the
// optimistic row doesn't flash a raw "2026-09-16T20:42:45.239Z" ISO
// string before a reload replaces it with the server's own formatting.
// Module-scoped (not nested in a component) since it's used both by the
// page's own optimistic-update handler and by the separate upload-row
// component further down this file.
function formatLikeServerDatetime(date: Date): string {
  const pad = (n: number) => String(n).padStart(2, '0');
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(
    date.getMinutes()
  )}:${pad(date.getSeconds())}`;
}

// ROOT-CAUSE FIX (vendor-app audit): the backend (includes/vendor.php)
// only ever writes doc/kyc status as 'pending' | 'verified' | 'rejected'
// — it never emits 'approved'. These three helpers used to special-case
// 'approved' (which never occurs), so a genuinely verified document fell
// through to the default branch and rendered as a plain grey badge with
// the raw word "verified" instead of a green "Approved" badge. Matching
// on the real value the server sends fixes this without touching the
// backend's status vocabulary.
function statusBadgeClasses(status: string): string {
  switch (status) {
    case 'verified':
      return 'bg-success-50 text-success-600 border-success-500/30';
    case 'pending':
      return 'bg-warning-50 text-warning-600 border-warning-500/30';
    case 'rejected':
      return 'bg-danger-50 text-danger-600 border-danger-500/30';
    default:
      return 'bg-ink-100 text-ink-600 border-ink-200';
  }
}

function statusLabel(status: string | null): string {
  if (!status) return 'Not uploaded';
  switch (status) {
    case 'verified':
      return 'Approved';
    case 'pending':
      return 'Pending review';
    case 'rejected':
      return 'Rejected';
    default:
      return status;
  }
}

function kycBannerClasses(status: string): string {
  switch (status) {
    case 'verified':
      return 'border-success-500/30 bg-success-50 text-success-600';
    case 'pending':
      return 'border-warning-500/30 bg-warning-50 text-warning-600';
    case 'rejected':
      return 'border-danger-500/30 bg-danger-50 text-danger-600';
    default:
      return 'border-ink-200 bg-ink-50 text-ink-600';
  }
}

export function VendorKycPage() {
  const [data, setData] = useState<VendorDocsResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notVendor, setNotVendor] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    setNotVendor(false);
    try {
      const res = await getVendorDocs();
      setData(res);
    } catch (err) {
      if (err instanceof ApiError && (err.status === 403 || err.code === 'not_a_vendor')) {
        setNotVendor(true);
      } else {
        setError(err instanceof ApiError ? err.message : 'Could not load your documents. Please try again.');
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  function handleDocUploaded(doc: VendorDoc) {
    setData((prev) => {
      if (!prev) return prev;
      const existingIndex = prev.docs.findIndex((d) => d.doc_type === doc.doc_type);
      const nextDocs =
        existingIndex >= 0
          ? prev.docs.map((d, i) => (i === existingIndex ? doc : d))
          : [...prev.docs, doc];
      return { ...prev, docs: nextDocs };
    });
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">KYC documents</h1>
      <p className="text-sm text-ink-500">Upload the documents required to verify your vendor account.</p>

      {loading && (
        <div className="mt-6 space-y-4" aria-busy="true" aria-label="Loading documents">
          <Skeleton className="h-10 w-full rounded-lg" />
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-28 w-full rounded-xl" />
          ))}
        </div>
      )}

      {!loading && notVendor && (
        <div className="mt-6">
          <EmptyState
            title="Vendor registration required"
            description="This page is only for registered driver-partners. Register your vendor profile to start uploading KYC documents."
            action={
              <Link to="/vendor/register">
                <Button>Register as a vendor</Button>
              </Link>
            }
          />
        </div>
      )}

      {!loading && !notVendor && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {!loading && !notVendor && !error && data && (
        <>
          <div role="status" className={`mt-6 rounded-lg border px-4 py-3 text-sm font-medium ${kycBannerClasses(data.kyc_status)}`}>
            KYC status: {statusLabel(data.kyc_status) || data.kyc_status}
          </div>

          <div className="mt-6 space-y-4">
            {data.required_types.map((docType) => {
              const doc = data.docs.find((d) => d.doc_type === docType) ?? null;
              return (
                <DocRow key={docType} docType={docType} doc={doc} onUploaded={handleDocUploaded} />
              );
            })}
          </div>
        </>
      )}
    </div>
  );
}

function DocRow({
  docType,
  doc,
  onUploaded,
}: {
  docType: string;
  doc: VendorDoc | null;
  onUploaded: (doc: VendorDoc) => void;
}) {
  const [file, setFile] = useState<File | null>(null);
  const [expiryDate, setExpiryDate] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [rowError, setRowError] = useState<string | null>(null);
  const [viewLoading, setViewLoading] = useState(false);

  async function handleView() {
    if (!doc) return;
    setRowError(null);
    setViewLoading(true);
    try {
      const objectUrl = await fetchVendorDocFileUrl(doc.id);
      window.open(objectUrl, '_blank', 'noreferrer');
      // Give the new tab time to load the blob before revoking it.
      window.setTimeout(() => URL.revokeObjectURL(objectUrl), 60_000);
    } catch (err) {
      setRowError(err instanceof ApiError ? err.message : 'Could not open this document. Please try again.');
    } finally {
      setViewLoading(false);
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!file) {
      setRowError('Please choose a file to upload.');
      return;
    }
    setRowError(null);
    setSubmitting(true);
    try {
      const res = await uploadVendorDoc({ doc_type: docType, file, expiry_date: docNeedsExpiry(docType) ? expiryDate : '' });
      onUploaded({
        id: res.doc_id,
        doc_type: docType,
        status: 'pending',
        expiry_date: docNeedsExpiry(docType) && expiryDate ? expiryDate : null,
        uploaded_at: formatLikeServerDatetime(new Date()),
      });
      setFile(null);
      setExpiryDate('');
    } catch (err) {
      setRowError(err instanceof ApiError ? err.message : 'Upload failed. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className={`${DATA_CARD_CLASS} p-5`}>
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <p className="font-semibold text-ink-900">{docTypeLabel(docType)}</p>
          {doc?.uploaded_at && <p className="text-xs text-ink-400">Uploaded {doc.uploaded_at}</p>}
        </div>
        <div className="flex items-center gap-3">
          <span
            className={`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-medium ${statusBadgeClasses(
              doc?.status ?? ''
            )}`}
          >
            {statusLabel(doc?.status ?? null)}
          </span>
          {doc && (
            <button
              type="button"
              onClick={handleView}
              disabled={viewLoading}
              className="text-sm font-medium text-brand-600 hover:text-brand-700 disabled:opacity-60"
            >
              {viewLoading ? 'Opening…' : 'View'}
            </button>
          )}
        </div>
      </div>

      {rowError && (
        <div className="mt-3">
          <ErrorBanner message={rowError} />
        </div>
      )}

      <form className="mt-4 flex flex-wrap items-end gap-3" onSubmit={handleSubmit}>
        <div className="flex-1 min-w-[160px]">
          <label className="block text-xs font-medium text-ink-600" htmlFor={`file-${docType}`}>
            {doc ? 'Replace file' : 'File'}
          </label>
          <input
            id={`file-${docType}`}
            type="file"
            accept={docIsPhoto(docType) ? 'image/jpeg,image/png,image/webp' : 'image/*,application/pdf'}
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            className="mt-1 block w-full text-sm text-ink-700 file:mr-3 file:rounded-md file:border-0 file:bg-ink-100 file:px-3 file:py-1.5 file:text-sm file:font-medium file:text-ink-700 hover:file:bg-ink-200"
          />
        </div>
        {docNeedsExpiry(docType) && (
        <div className="min-w-[140px]">
          <label className="block text-xs font-medium text-ink-600" htmlFor={`expiry-${docType}`}>
            Expiry date (optional)
          </label>
          <input
            id={`expiry-${docType}`}
            type="date"
            value={expiryDate}
            onChange={(e) => setExpiryDate(e.target.value)}
            className="mt-1 w-full rounded-lg border border-ink-200 px-3 py-1.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>
        )}
        <Button type="submit" size="sm" loading={submitting}>
          {doc ? 'Re-upload' : 'Upload'}
        </Button>
      </form>
    </div>
  );
}
