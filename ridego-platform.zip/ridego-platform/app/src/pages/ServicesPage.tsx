import { Link, useNavigate } from 'react-router-dom';
import { Button } from '../components/ui/Button';
import { brand } from '../lib/brand';
import { SHOWCASE_CARD_CLASS } from '../components/ui/Zone';

interface ServiceSection {
  tripType: string;
  title: string;
  summary: string;
  whatItIs: string;
  whenToUse: string;
  pricing: string;
}

const SERVICES: ServiceSection[] = [
  {
    tripType: 'one_way',
    title: 'One-way trips',
    summary: 'Point-to-point outstation travel — pay only for the distance you actually cover.',
    whatItIs:
      'A one-way trip takes you from one city to another without the return leg — you drop the vehicle at your destination and the driver-partner heads back on their own.',
    whenToUse:
      'Best for one-directional travel such as flying out from a different city, moving for a job, or any trip where you don\'t need the same cab back.',
    pricing:
      'Fares are calculated upfront from your pickup and drop cities and the vehicle you choose, so you see an estimated fare before you confirm — no meter, no surprise return-leg charge.',
  },
  {
    tripType: 'round_trip',
    title: 'Round trips',
    summary: 'The same driver-partner and vehicle for your entire out-and-back journey.',
    whatItIs:
      'A round trip books your vehicle for both the outbound and return journey, with your return date included at the time of booking.',
    whenToUse:
      'Ideal for multi-day outstation travel — weekend getaways, family functions, or business trips — where you want the same driver and vehicle waiting for the return leg.',
    pricing:
      'The upfront fare accounts for the full out-and-back distance across both legs, so the estimated cost is clear before booking rather than settled trip-by-trip.',
  },
  {
    tripType: 'local',
    title: 'Local trips',
    summary: 'Short in-city rides for errands, airport drops, or getting around town.',
    whatItIs:
      'A local trip covers travel within a single city — like an airport pickup/drop or a short cross-town ride — rather than an outstation journey between cities.',
    whenToUse:
      'Use this when your pickup and drop are both in the same city and you just need a reliable ride from A to B.',
    pricing:
      'Priced by route and vehicle type for the city you\'re in, with the fare shown upfront before you confirm the booking.',
  },
  {
    // Root-cause fix: the backend has exactly one hours-based pricing
    // concept (trip_type 'local', in includes/pricing.php) — 'hourly'
    // was never real and silently mispriced as a one-way trip.
    tripType: 'local',
    title: 'Hourly rentals',
    summary: 'Keep a vehicle and driver on call for a block of hours, for multi-stop plans.',
    whatItIs:
      'An hourly rental keeps a vehicle and driver-partner at your disposal for a set number of hours, so you can make several stops without booking separate trips.',
    whenToUse:
      'Great for a day of sightseeing, multiple meetings around a city, wedding-day logistics, or any plan with several stops and waiting time in between.',
    pricing:
      'Priced against the number of hours you book upfront, with your fare shown before confirming — so waiting time between stops is already accounted for.',
  },
];

export function ServicesPage() {
  const navigate = useNavigate();

  function startBooking(tripType: string) {
    navigate('/search', { state: { tripType } });
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Our services</h1>
        <p className="max-w-2xl text-sm text-ink-500">
          Whichever way you need to travel, {brand().name} matches you with a verified driver-partner and shows you a
          transparent, upfront fare before you book. Here's a rundown of the trip types we support.
        </p>
      </div>

      <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2">
        {SERVICES.map((s) => (
          <div key={s.tripType} className={`flex flex-col p-5 sm:p-6 ${SHOWCASE_CARD_CLASS}`}>
            <h2 className="text-lg font-semibold text-ink-900">{s.title}</h2>
            <p className="mt-1 text-sm text-ink-500">{s.summary}</p>

            <div className="mt-4 space-y-3 text-sm text-ink-600">
              <p>
                <span className="font-semibold text-ink-800">What it is: </span>
                {s.whatItIs}
              </p>
              <p>
                <span className="font-semibold text-ink-800">When to use it: </span>
                {s.whenToUse}
              </p>
              <p>
                <span className="font-semibold text-ink-800">Pricing: </span>
                {s.pricing}
              </p>
            </div>

            <div className="mt-5">
              <Button variant="secondary" size="sm" onClick={() => startBooking(s.tripType)}>
                Book a {s.title.toLowerCase().replace(/s$/, '')}
              </Button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-10 flex flex-col items-center justify-between gap-4 rounded-2xl bg-brand-50 p-8 text-center sm:flex-row sm:text-left">
        <div>
          <h2 className="text-lg font-bold text-ink-900">Not sure which one fits your trip?</h2>
          <p className="mt-1 text-sm text-ink-600">
            Search live fares across cities and vehicle types, or head straight to booking.
          </p>
        </div>
        <div className="flex flex-col gap-2 sm:flex-row">
          <Link to="/search">
            <Button variant="secondary">Compare fares</Button>
          </Link>
          <Link to="/book">
            <Button>Book a ride</Button>
          </Link>
        </div>
      </div>
    </div>
  );
}
