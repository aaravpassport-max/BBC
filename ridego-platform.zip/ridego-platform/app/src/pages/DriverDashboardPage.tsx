import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { ApiError } from '../lib/api';
import {
  fetchDriverDocUrl,
  getDriverEarnings,
  getDriverMe,
  getDriverTripHistory,
  uploadDriverOwnDoc,
  type DriverEarnings,
  type DriverMe,
  type DriverTripHistoryRow,
} from '../lib/api-team';
import { inr } from '../lib/api-admin-crm';
import { docIsPhoto, docNeedsExpiry, docTypeLabel } from '../lib/doc-types';
import { useToast } from '../context/ToastContext';
import { Button } from '../components/ui/Button';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { Skeleton } from '../components/ui/Skeleton';
import { EmptyState } from '../components/ui/EmptyState';
import { FormField, INPUT_CLASS } from './vendor-mkt/vendor-mkt-shared';
import { DATA_CARD_CLASS } from '../components/ui/Zone';

const FALLBACK_MAX_MB = 5;

const STATUS_LABELS: Record<string, string> = {
  confirmed: 'Confirmed',
  vendor_assigned: 'Vendor Assigned',
  driver_en_route: 'En route to pickup',
  trip_started: 'Trip in progress',
  completed: 'Completed',
  cancelled: 'Cancelled',
  no_show: 'No-show',
  expired: 'Expired',
};

const TABS = ['Trips', 'History', 'Earnings', 'Documents'] as const;
type Tab = (typeof TABS)[number];

// TRACE: route /app/driver → the driver's own workspace, now a real trip-execution surface rather
//        than only a profile+doc-upload screen (RG-012/RG-013 gap): a Trips tab linking each assigned
//        trip to its full detail+action page (DriverTripDetailPage), a History tab for past trips
//        (backend RG-012's status endpoints existed with no way to review them afterward), an
//        Earnings/wallet tab reading the ledger the vendor records against this driver, and the
//        existing Documents tab unchanged. Preconditions: signed-in driver linked to a fleet driver
//        row (server 403 otherwise). Each tab loads its own data lazily on first visit so a driver
//        who only ever opens Trips never pays for the History/Earnings requests.
export function DriverDashboardPage() {
  const [tab, setTab] = useState<Tab>('Trips');
  const [data, setData] = useState<DriverMe | null>(null);
  const [error, setError] = useState<string | null>(null);
  const load = useCallback(async () => {
    setError(null);
    try { setData(await getDriverMe()); } catch (e) { setError(e instanceof ApiError ? e.message : 'Could not load your details.'); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  if (error) return <div className="mx-auto max-w-3xl px-4 py-8"><ErrorBanner message={error} onRetry={load} /></div>;
  if (!data) return <div className="mx-auto max-w-3xl space-y-3 px-4 py-8"><Skeleton className="h-10 w-1/2" /><Skeleton className="h-32 w-full rounded-xl" /></div>;

  return (
    <div className="mx-auto max-w-3xl px-4 py-8 sm:px-6">
      <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Hello, {data.profile.name}</h1>
      <p className="mt-1 text-sm text-ink-600">Mobile {data.profile.mobile} · Licence {data.profile.license_number || 'not on file'}{data.profile.license_expiry ? ` (expires ${data.profile.license_expiry.slice(0, 10)})` : ''}</p>

      <div role="tablist" aria-label="Driver workspace" className="mt-6 flex flex-wrap gap-2 border-b border-ink-100">
        {TABS.map((t) => (
          <button
            key={t}
            role="tab"
            type="button"
            aria-selected={tab === t}
            onClick={() => setTab(t)}
            className={`-mb-px border-b-2 px-3 py-2 text-sm font-semibold ${tab === t ? 'border-brand-600 text-brand-700' : 'border-transparent text-ink-500 hover:text-ink-800'}`}
          >
            {t}
          </button>
        ))}
      </div>

      {tab === 'Trips' && (
        <section className="mt-6" aria-label="My upcoming trips">
          {data.trips.length === 0 ? <div className="mt-3"><EmptyState title="No trips assigned" description="Trips your fleet owner assigns to you will appear here." /></div> : (
            <ul className="mt-3 space-y-3">{data.trips.map((t) => (
              <li key={t.id}>
                <Link to={`/app/driver/trips/${t.id}`} className={`block ${DATA_CARD_CLASS} p-4 transition hover:border-brand-300 hover:bg-brand-50/40`}>
                  <div className="flex items-center justify-between gap-2">
                    <p className="font-semibold text-ink-900">{t.booking_number} · {t.pickup_city} → {t.drop_city}</p>
                    <span className="shrink-0 rounded-full bg-brand-50 px-2.5 py-0.5 text-xs font-semibold text-brand-700">{STATUS_LABELS[t.status] ?? t.status}</span>
                  </div>
                  <p className="text-sm text-ink-600">{t.journey_date} {t.journey_time.slice(0, 5)} · {t.pickup_address}</p>
                </Link>
              </li>
            ))}</ul>
          )}
        </section>
      )}

      {tab === 'History' && <DriverHistoryTab />}
      {tab === 'Earnings' && <DriverEarningsTab />}

      {tab === 'Documents' && (
        <section className="mt-6" aria-label="My documents">
          <ul className="mt-3 space-y-3">{data.doc_types.map((t) => <DriverDocRow key={t} docType={t} doc={data.docs.find((d) => d.doc_type === t) ?? null} maxUploadMb={data.max_upload_mb} onUploaded={load} />)}</ul>
        </section>
      )}
    </div>
  );
}

// TRACE: History tab first shown → GET /driver/trips/history → past trips list. Edge: load failure (retry), empty (empty state).
function DriverHistoryTab() {
  const [rows, setRows] = useState<DriverTripHistoryRow[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const load = useCallback(async () => {
    setError(null);
    try { setRows((await getDriverTripHistory()).rows); } catch (e) { setError(e instanceof ApiError ? e.message : 'Could not load your trip history.'); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  if (error) return <div className="mt-6"><ErrorBanner message={error} onRetry={load} /></div>;
  if (!rows) return <div className="mt-6 space-y-3"><Skeleton className="h-20 w-full rounded-xl" /><Skeleton className="h-20 w-full rounded-xl" /></div>;
  if (rows.length === 0) return <div className="mt-6"><EmptyState title="No past trips yet" description="Completed, cancelled and no-show trips will appear here." /></div>;
  return (
    <section className="mt-6" aria-label="My trip history">
      <ul className="space-y-3">{rows.map((t) => (
        <li key={t.id}>
          <Link to={`/app/driver/trips/${t.id}`} className={`block ${DATA_CARD_CLASS} p-4 transition hover:border-brand-300 hover:bg-brand-50/40`}>
            <div className="flex items-center justify-between gap-2">
              <p className="font-semibold text-ink-900">{t.booking_number} · {t.pickup_city} → {t.drop_city}</p>
              <span className="shrink-0 rounded-full bg-ink-100 px-2.5 py-0.5 text-xs font-semibold text-ink-700">{STATUS_LABELS[t.status] ?? t.status}</span>
            </div>
            <p className="text-sm text-ink-600">{t.journey_date} {t.journey_time.slice(0, 5)}</p>
          </Link>
        </li>
      ))}</ul>
    </section>
  );
}

// TRACE: Earnings tab first shown → GET /driver/earnings → running balance + ledger rows recorded by the vendor.
//        Edge: load failure (retry), empty ledger (empty state — not an error; a new driver has no entries yet).
function DriverEarningsTab() {
  const [data, setData] = useState<DriverEarnings | null>(null);
  const [error, setError] = useState<string | null>(null);
  const load = useCallback(async () => {
    setError(null);
    try { setData(await getDriverEarnings()); } catch (e) { setError(e instanceof ApiError ? e.message : 'Could not load your earnings.'); }
  }, []);
  useEffect(() => { void load(); }, [load]);
  if (error) return <div className="mt-6"><ErrorBanner message={error} onRetry={load} /></div>;
  if (!data) return <div className="mt-6 space-y-3"><Skeleton className="h-16 w-full rounded-xl" /><Skeleton className="h-16 w-full rounded-xl" /></div>;
  return (
    <section className="mt-6" aria-label="My earnings">
      <div className={`${DATA_CARD_CLASS} bg-brand-50/40 p-5`}>
        <p className="text-sm font-medium text-ink-600">Wallet balance</p>
        <p className="text-2xl font-bold text-ink-900">{inr(data.balance)}</p>
        <p className="mt-1 text-xs text-ink-500">Recorded by your fleet owner — payouts, bonuses and deductions.</p>
      </div>
      {data.rows.length === 0 ? (
        <div className="mt-4"><EmptyState title="No entries yet" description="Payouts and adjustments your fleet owner records will appear here." /></div>
      ) : (
        <ul className="mt-4 space-y-2">{data.rows.map((r) => (
          <li key={r.id} className={`flex items-center justify-between gap-3 ${DATA_CARD_CLASS} p-3`}>
            <div>
              <p className="text-sm font-medium capitalize text-ink-900">{r.entry_type.replace(/_/g, ' ')}</p>
              <p className="text-xs text-ink-500">{r.created_at} · {r.recorded_by}{r.note ? ` · ${r.note}` : ''}</p>
            </div>
            <span className={`text-sm font-semibold ${r.amount < 0 ? 'text-danger-600' : 'text-success-600'}`}>{r.amount < 0 ? '−' : '+'}{inr(Math.abs(r.amount))}</span>
          </li>
        ))}</ul>
      )}
    </section>
  );
}

// TRACE: one document row → shows status/validity, View (blob in new tab), and an upload form; expiry input only for types that
//        have an expiry; photo accepts images only. Postconditions: inputs reset after success, file kept on failure.
//        Edge cases: no file (message), file > 5MB (message), server rejection (message), unmount revokes blob URLs.
function DriverDocRow({ docType, doc, maxUploadMb, onUploaded }: { docType: string; doc: DriverMe['docs'][number] | null; maxUploadMb?: number; onUploaded: () => void }) {
  const toast = useToast();
  const maxMb = maxUploadMb && maxUploadMb > 0 ? maxUploadMb : FALLBACK_MAX_MB;
  const maxBytes = maxMb * 1024 * 1024;
  const [file, setFile] = useState<File | null>(null);
  const [expiry, setExpiry] = useState('');
  const [key, setKey] = useState(0);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const urls = useRef<string[]>([]);
  useEffect(() => { const held = urls.current; return () => held.forEach((u) => URL.revokeObjectURL(u)); }, []);
  // TRACE: View click → fetches the file as a blob → opens a tab. Edge: failure → inline message.
  const view = async () => {
    if (!doc) return;
    try { const u = await fetchDriverDocUrl(doc.id); urls.current.push(u); window.open(u, '_blank', 'noreferrer'); }
    catch (e) { setErr(e instanceof ApiError ? e.message : 'Could not open this document.'); }
  };
  // TRACE: submit → validates → multipart upload → toast, reset, reload. Edge: see component trace.
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    if (!file) { setErr('Choose a file to upload.'); return; }
    if (file.size > maxBytes) { setErr(`The file must be under ${maxMb}MB.`); return; }
    setSaving(true); setErr(null);
    try { await uploadDriverOwnDoc(docType, file, docNeedsExpiry(docType) ? expiry : ''); toast.show(`${docTypeLabel(docType)} uploaded.`, 'success'); setFile(null); setExpiry(''); setKey((k) => k + 1); onUploaded(); }
    catch (e2) { setErr(e2 instanceof ApiError ? e2.message : 'Upload failed. Please try again.'); }
    finally { setSaving(false); }
  };
  const id = `drv-${docType}`;
  return (
    <li className={`${DATA_CARD_CLASS} p-4`}>
      <div className="flex flex-wrap items-start justify-between gap-2">
        <div><p className="font-semibold text-ink-900">{docTypeLabel(docType)}</p><p className="text-xs text-ink-600">{doc ? `Uploaded ${doc.uploaded_at}${doc.expiry_date ? ` · Expires ${doc.expiry_date.slice(0, 10)}` : ''} · ${doc.status === 'verified' ? 'Approved' : doc.status === 'rejected' ? 'Rejected' : 'Pending review'}` : 'Not uploaded yet'}</p></div>
        {doc && <button type="button" onClick={view} className="text-sm font-medium text-brand-700 hover:text-brand-800" aria-label={`View ${docTypeLabel(docType)}`}>View</button>}
      </div>
      <form onSubmit={submit} className="mt-3 space-y-3" noValidate>
        <FormField label={doc ? 'Replace file' : 'File'} htmlFor={`${id}-file`} hint={docIsPhoto(docType) ? `JPG, PNG or WebP, up to ${maxMb}MB.` : `JPG, PNG, WebP or PDF, up to ${maxMb}MB.`}>
          <input key={key} id={`${id}-file`} type="file" accept={docIsPhoto(docType) ? 'image/jpeg,image/png,image/webp' : 'image/jpeg,image/png,image/webp,application/pdf'} onChange={(e) => setFile(e.target.files?.[0] ?? null)} disabled={saving} className="block w-full text-sm" />
        </FormField>
        {docNeedsExpiry(docType) && <FormField label="Expiry date (optional)" htmlFor={`${id}-exp`}><input id={`${id}-exp`} type="date" className={INPUT_CLASS} value={expiry} onChange={(e) => setExpiry(e.target.value)} disabled={saving} /></FormField>}
        {err && <p role="alert" className="text-sm font-medium text-danger-600">{err}</p>}
        <Button type="submit" size="sm" loading={saving}>{doc ? 'Re-upload' : 'Upload'}</Button>
      </form>
    </li>
  );
}
