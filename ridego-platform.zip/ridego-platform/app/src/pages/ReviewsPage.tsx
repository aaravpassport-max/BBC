import { useCallback, useEffect, useState } from 'react';
import { getReviews, ApiError } from '../lib/api';
import type { AppReview } from '../types/api';
import { Skeleton } from '../components/ui/Skeleton';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { EmptyState } from '../components/ui/EmptyState';
import { Button } from '../components/ui/Button';
import { DATA_CARD_CLASS } from '../components/ui/Zone';

function StarDisplay({ value }: { value: number }) {
  return (
    <div className="flex items-center gap-0.5" aria-label={`Rated ${value} out of 5`}>
      {[1, 2, 3, 4, 5].map((n) => (
        <svg
          key={n}
          className={`h-4 w-4 ${n <= value ? 'text-warning-500' : 'text-ink-200'}`}
          viewBox="0 0 20 20"
          fill="currentColor"
          aria-hidden="true"
        >
          <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.957a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.367 2.447a1 1 0 00-.364 1.118l1.287 3.957c.3.922-.755 1.688-1.538 1.118l-3.367-2.447a1 1 0 00-1.176 0l-3.367 2.447c-.783.57-1.838-.196-1.538-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.063 9.384c-.783-.57-.38-1.81.588-1.81h4.163a1 1 0 00.95-.69l1.286-3.957z" />
        </svg>
      ))}
    </div>
  );
}

function formatDate(dateStr: string): string {
  const d = new Date(dateStr.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return dateStr;
  return d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
}

export function ReviewsPage() {
  const [page, setPage] = useState(1);
  const [rows, setRows] = useState<AppReview[] | null>(null);
  const [total, setTotal] = useState(0);
  const [perPage, setPerPage] = useState(20);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async (p: number) => {
    setLoading(true);
    setError(null);
    try {
      const res = await getReviews({ page: p });
      setRows(res.rows);
      setTotal(res.total);
      setPerPage(res.per_page);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load reviews. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load(page);
  }, [page, load]);

  const canPrev = page > 1;
  const canNext = page * perPage < total;

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Rider reviews</h1>
        <p className="text-sm text-ink-500">Genuine feedback from riders who've completed a trip with us.</p>
      </div>

      <div className="mt-6">
        {loading && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2" aria-busy="true" aria-label="Loading reviews">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className={`${DATA_CARD_CLASS} p-4 sm:p-5`}>
                <div className="flex items-center justify-between">
                  <Skeleton className="h-4 w-28" />
                  <Skeleton className="h-4 w-20" />
                </div>
                <Skeleton className="mt-3 h-3 w-full" />
                <Skeleton className="mt-2 h-3 w-3/4" />
              </div>
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={() => load(page)} />}

        {!loading && !error && rows && rows.length === 0 && (
          <EmptyState
            title="No reviews yet"
            description="Be the first to complete a trip and leave one!"
          />
        )}

        {!loading && !error && rows && rows.length > 0 && (
          <>
            <ul className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {rows.map((r) => (
                <li
                  key={r.id}
                  className={`flex flex-col ${DATA_CARD_CLASS} p-4 transition hover:shadow-sm sm:p-5`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <p className="font-semibold text-ink-900">{r.client_name}</p>
                    <StarDisplay value={r.rating} />
                  </div>

                  {r.review && <p className="mt-2 text-sm text-ink-600">&ldquo;{r.review}&rdquo;</p>}

                  <div className="mt-auto pt-3 text-xs text-ink-500">
                    <p>
                      {r.pickup_city} → {r.drop_city}
                    </p>
                    <p className="mt-0.5">
                      {r.vendor_name ? `Vendor: ${r.vendor_name} · ` : ''}
                      {formatDate(r.journey_date)}
                    </p>
                  </div>
                </li>
              ))}
            </ul>

            <div className="mt-6 flex items-center justify-between">
              <p className="text-sm text-ink-500">
                Page {page} of {Math.max(1, Math.ceil(total / perPage))} &middot; {total} review{total === 1 ? '' : 's'}
              </p>
              <div className="flex gap-2">
                <Button variant="secondary" size="sm" disabled={!canPrev} onClick={() => setPage((p) => Math.max(1, p - 1))}>
                  Previous
                </Button>
                <Button variant="secondary" size="sm" disabled={!canNext} onClick={() => setPage((p) => p + 1)}>
                  Next
                </Button>
              </div>
            </div>
          </>
        )}
      </div>
    </div>
  );
}
