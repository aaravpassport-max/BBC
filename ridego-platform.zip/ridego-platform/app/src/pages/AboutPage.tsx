import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getHome, ApiError } from '../lib/api';
import type { HomeResponse } from '../types/api';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { Skeleton } from '../components/ui/Skeleton';
import { Button } from '../components/ui/Button';
import { brand } from '../lib/brand';
import { DataCard } from '../components/ui/Zone';

const VALUES = [
  {
    title: 'Upfront pricing',
    description:
      'We show you an estimated fare before you book, calculated from your route, vehicle and trip type. You pay a small booking amount to us and the rest directly to your vendor/driver, who bills you for the ride.',
  },
  {
    title: 'Verified partners',
    description:
      'Every driver-partner goes through a KYC verification process before they can accept ride leads on the platform, so you know who you\'re riding with.',
  },
  {
    title: 'Always-on support',
    description:
      'Our support team is reachable by phone and WhatsApp before, during and after your trip — whether that\'s a question about your booking or something that needs attention on the road.',
  },
  {
    title: 'Pan-India coverage',
    description:
      'From outstation one-way and round trips to local hourly rentals, our network of driver-partners spans routes and cities across the country.',
  },
];

export function AboutPage() {
  const [data, setData] = useState<HomeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  function load() {
    setLoading(true);
    setError(null);
    getHome()
      .then(setData)
      .catch((err) => setError(err instanceof ApiError ? err.message : 'Could not load this page. Please try again.'))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  const platformName = data?.platform_name || brand().name;

  return (
    <div className="min-h-full bg-white">
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">
          About {loading ? '' : platformName}
        </h1>
        {loading ? (
          <Skeleton className="mt-1 h-4 w-64" />
        ) : (
          <p className="text-sm text-ink-500">{data?.platform_tagline || 'A cab marketplace built on trust.'}</p>
        )}
      </div>

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      <div className="mt-8 space-y-4 text-sm leading-relaxed text-ink-600 sm:text-base">
        <p>
          {platformName} connects riders who need an outstation, local or hourly cab with verified driver-partners
          across India. Instead of haggling over price or waiting for a callback, you get a transparent fare
          up front, a confirmed booking, and a real person to call if anything needs attention along the way.
        </p>
        <p>
          Behind every booking is a network of driver-partners who go through a document verification process
          before they can accept trips, and who build a public rating from riders they've completed trips with —
          so trust isn't just a promise, it's something you can see on every booking.
        </p>
        <p>
          We built {platformName} because booking an intercity or local cab shouldn't mean uncertainty about the
          price, the vehicle, or who's driving. Whether you're travelling for business, a family trip, or booking
          an hourly rental around town, our goal is the same: a fair price, a verified partner, and support that
          picks up when you call.
        </p>
      </div>

      <div className="mt-10">
        <h2 className="text-lg font-semibold text-ink-900">What we stand for</h2>
        <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
          {VALUES.map((v) => (
            <DataCard key={v.title} className="p-5">
              <h3 className="font-semibold text-ink-900">{v.title}</h3>
              <p className="mt-1.5 text-sm text-ink-500">{v.description}</p>
            </DataCard>
          ))}
        </div>
      </div>

      <DataCard className="mt-10 p-5 sm:p-6">
        <h2 className="text-lg font-semibold text-ink-900">Get in touch</h2>
        <p className="mt-1 text-sm text-ink-500">
          Questions about a booking, becoming a driver-partner, or anything else — we're happy to help.
        </p>

        {loading && (
          <div className="mt-4 flex flex-col gap-2 sm:flex-row" aria-busy="true" aria-label="Loading contact details">
            <Skeleton className="h-10 w-40 rounded-lg" />
            <Skeleton className="h-10 w-44 rounded-lg" />
          </div>
        )}

        {!loading && !error && data && (
          <div className="mt-4 flex flex-wrap gap-2">
            {data.support_phone && (
              <a href={`tel:${data.support_phone}`}>
                <Button variant="secondary" size="sm">
                  Call {data.support_phone}
                </Button>
              </a>
            )}
            {data.support_whatsapp && (
              <a href={`https://wa.me/${data.support_whatsapp.replace(/[^\d]/g, '')}`} target="_blank" rel="noreferrer">
                <Button variant="secondary" size="sm">
                  WhatsApp us
                </Button>
              </a>
            )}
            <Link to="/help">
              <Button variant="ghost" size="sm">
                Visit help &amp; support
              </Button>
            </Link>
          </div>
        )}
      </DataCard>

      <div className="mt-10 flex flex-col items-center justify-between gap-4 rounded-2xl bg-brand-50 p-8 text-center shadow-sm transition hover:shadow-lg sm:flex-row sm:text-left">
        <div>
          <h2 className="text-lg font-bold text-ink-900">Want to drive with us?</h2>
          <p className="mt-1 text-sm text-ink-600">Register as a driver-partner and start receiving ride leads.</p>
        </div>
        <Link to="/vendor/register">
          <Button>Become a partner</Button>
        </Link>
      </div>
    </div>
    </div>
  );
}
