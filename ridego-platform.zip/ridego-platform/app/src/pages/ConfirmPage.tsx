import { useCallback, useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { useLocation, useNavigate, useSearchParams } from 'react-router-dom';
import { ApiError, lookupBooking, submitPaymentProof } from '../lib/api';
import type { BookingLookupResponse } from '../types/api';
import { Button } from '../components/ui/Button';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { Skeleton } from '../components/ui/Skeleton';
import { SuccessDialog } from '../components/ui/SuccessDialog';
import { brand } from '../lib/brand';
import { DATA_CARD_CLASS, SHOWCASE_CARD_CLASS } from '../components/ui/Zone';
import { useAuth } from '../context/AuthContext';

const inputClasses =
  'w-full rounded-lg border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30';
const labelClasses = 'block text-sm font-medium text-ink-700';

function currency(sym: string, n: number) {
  return `${sym}${n.toLocaleString('en-IN', { maximumFractionDigits: 0 })}`;
}

function formatCountdown(seconds: number) {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  const s = Math.floor(seconds % 60);
  return [h, m, s].map((n) => String(n).padStart(2, '0')).join(':');
}

const STATUS_BANNER: Record<string, { label: string; tone: string }> = {
  pending: { label: 'Booking received', tone: 'bg-ink-100 text-ink-700' },
  pending_payment: { label: 'Awaiting booking amount', tone: 'bg-warning-50 text-warning-600' },
  payment_rejected: { label: 'Payment could not be verified', tone: 'bg-danger-50 text-danger-600' },
  confirmed: { label: 'Booking confirmed', tone: 'bg-success-50 text-success-600' },
  assigned: { label: 'Driver assigned', tone: 'bg-success-50 text-success-600' },
  completed: { label: 'Trip completed', tone: 'bg-success-50 text-success-600' },
  cancelled: { label: 'Booking cancelled', tone: 'bg-danger-50 text-danger-600' },
  expired: { label: 'Booking expired', tone: 'bg-danger-50 text-danger-600' },
};

export function ConfirmPage() {
  const [params] = useSearchParams();
  const location = useLocation();
  const bookingNumber = params.get('booking') ?? '';
  const promoAdjusted = params.get('promo_adjusted') === '1';
  const promoReason = params.get('promo_reason');
  const statePhone = (location.state as { phone?: string } | null)?.phone;

  const [phone, setPhone] = useState(statePhone ?? params.get('phone') ?? '');
  const [phoneInput, setPhoneInput] = useState('');
  const [data, setData] = useState<BookingLookupResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [secondsLeft, setSecondsLeft] = useState<number | null>(null);

  // ROOT-CAUSE FIX (screen jump during payment-proof submit): this used
  // to be the ONLY way to refresh the booking, and it unconditionally
  // flipped `loading` — which the render below used to unmount the
  // entire ConfirmContent card stack in favor of a couple of short
  // Skeleton blocks. Payment-proof submission called this same
  // `load()` on success (via onProofSubmitted) purely to pick up the
  // booking's new status, which briefly replaced the whole page with a
  // much shorter skeleton and then swapped back in the real (different
  // height) content the instant the request resolved — a full-page
  // reflow the user experienced as a jump, even though nothing actually
  // scrolled. `silent` lets a background refresh update `data` in place
  // without ever showing the skeleton or unmounting the card the user
  // is looking at; only the true first load (no `data` yet) still shows
  // it, via the `!data` guard at the call site below.
  const load = useCallback((p: string, opts?: { silent?: boolean }) => {
    if (!bookingNumber) return;
    if (!opts?.silent) setLoading(true);
    setError(null);
    lookupBooking({ booking: bookingNumber, phone: p || undefined })
      .then((res) => {
        setData(res);
        setSecondsLeft(res.seconds_left);
      })
      .catch((err) => {
        if (opts?.silent) return; // background refresh failing shouldn't blank out content already on screen
        setError(
          err instanceof ApiError
            ? 'Booking not found. Please double-check your booking number and phone number.'
            : 'Could not load your booking. Please try again.'
        );
      })
      .finally(() => {
        if (!opts?.silent) setLoading(false);
      });
  }, [bookingNumber]);

  useEffect(() => {
    if (phone) load(phone);
  }, [phone, load]);

  // Countdown ticker
  useEffect(() => {
    if (secondsLeft == null || secondsLeft <= 0) return;
    const t = setInterval(() => {
      setSecondsLeft((s) => (s == null ? s : Math.max(0, s - 1)));
    }, 1000);
    return () => clearInterval(t);
  }, [secondsLeft != null && secondsLeft > 0]); // eslint-disable-line react-hooks/exhaustive-deps

  function handlePhoneSubmit(e: FormEvent) {
    e.preventDefault();
    const clean = phoneInput.replace(/\D/g, '');
    if (clean.length < 10) {
      setError('Enter a valid phone number.');
      return;
    }
    setPhone(phoneInput);
  }

  if (!bookingNumber) {
    return (
      <div className="mx-auto max-w-lg px-4 py-16 text-center">
        <ErrorBanner message="No booking number was provided. Please use the link from your booking confirmation." />
      </div>
    );
  }

  if (!phone) {
    return (
      <div className="mx-auto flex min-h-[calc(100vh-64px)] max-w-md flex-col justify-center px-4 py-12">
        <div className={`${SHOWCASE_CARD_CLASS} p-8`}>
          <h1 className="text-xl font-bold text-ink-900">View your booking</h1>
          <p className="mt-1 text-sm text-ink-500">
            Enter the phone number used for booking <span className="font-semibold text-ink-700">#{bookingNumber}</span> to view its status.
          </p>
          <form onSubmit={handlePhoneSubmit} noValidate className="mt-5 space-y-4">
            {error && (
              <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
                {error}
              </div>
            )}
            <div>
              <label htmlFor="lookup-phone" className={labelClasses}>
                Phone number
              </label>
              <input
                id="lookup-phone"
                type="tel"
                required
                autoFocus
                value={phoneInput}
                onChange={(e) => setPhoneInput(e.target.value)}
                className={`mt-1.5 ${inputClasses}`}
              />
            </div>
            <Button type="submit" fullWidth size="lg">
              View booking
            </Button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      {promoAdjusted && (
        <div role="alert" className="mb-6 rounded-lg border border-warning-500/40 bg-warning-50 px-4 py-3 text-sm text-warning-600">
          <p className="font-semibold">Your promo code could not be applied.</p>
          <p className="mt-0.5">
            {promoReason || 'It was no longer available when your booking was confirmed, so your total may differ from the estimate shown earlier.'}
          </p>
        </div>
      )}

      {loading && !data && (
        <div className="space-y-4">
          <Skeleton className="h-16 w-full rounded-xl" />
          <Skeleton className="h-48 w-full rounded-xl" />
        </div>
      )}

      {!data && !loading && error && <ErrorBanner message={error} onRetry={() => load(phone)} />}

      {data && (
        <ConfirmContent
          data={data}
          secondsLeft={secondsLeft}
          phone={phone}
          onProofSubmitted={() => load(phone, { silent: true })}
        />
      )}
    </div>
  );
}

function ConfirmContent({
  data,
  secondsLeft,
  phone,
  onProofSubmitted,
}: {
  data: BookingLookupResponse;
  secondsLeft: number | null;
  phone: string;
  onProofSubmitted: () => void;
}) {
  const { booking, payment_details, needs_payment, is_confirmed, is_expired } = data;
  const banner = STATUS_BANNER[booking.status] ?? { label: booking.status_label, tone: 'bg-ink-100 text-ink-700' };
  const sym = '₹';

  const canSubmitProof = booking.status === 'pending_payment' || booking.status === 'payment_rejected';

  return (
    <div className="space-y-6">
      {/* Status banner */}
      <div className={`flex flex-col gap-2 rounded-xl p-5 sm:flex-row sm:items-center sm:justify-between ${banner.tone}`}>
        <div>
          <p className="text-lg font-bold">{banner.label}</p>
          <p className="text-sm opacity-90">
            Booking #{booking.booking_number} &middot; {booking.pickup_city} → {booking.drop_city}
          </p>
        </div>
        {needs_payment && secondsLeft != null && secondsLeft > 0 && (
          <div className="rounded-lg bg-white/70 px-4 py-2 text-center">
            <p className="text-xs font-medium uppercase tracking-wide">Time left to pay</p>
            <p className="font-mono text-xl font-bold">{formatCountdown(secondsLeft)}</p>
          </div>
        )}
        {needs_payment && secondsLeft === 0 && (
          <p className="text-sm font-semibold">Payment window has closed. Please contact support.</p>
        )}
      </div>

      {is_expired && (
        <ErrorBanner message="This booking has expired because payment wasn't completed in time. Please make a new booking." />
      )}

      {booking.payment_rejection_reason && (
        <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-4 py-3 text-sm text-danger-600">
          <p className="font-semibold">Your payment proof was rejected</p>
          <p className="mt-0.5">{booking.payment_rejection_reason}</p>
        </div>
      )}

      {/* Pickup OTP + driver */}
      {is_confirmed && booking.vendor_name && (
        <div className="rounded-xl border border-brand-200 bg-brand-50 p-5">
          <p className="text-sm font-semibold text-brand-800">Your driver-partner</p>
          <p className="mt-1 text-lg font-bold text-ink-900">{booking.vendor_name}</p>
          <div className="mt-2 flex flex-wrap gap-3 text-sm">
            {booking.vendor_phone && (
              <a href={`tel:${booking.vendor_phone}`} className="font-medium text-brand-700 hover:text-brand-800">
                Call {booking.vendor_phone}
              </a>
            )}
            {booking.vendor_whatsapp && (
              <a
                href={`https://wa.me/${booking.vendor_whatsapp.replace(/\D/g, '')}`}
                target="_blank"
                rel="noreferrer"
                className="font-medium text-success-600 hover:text-success-700"
              >
                WhatsApp
              </a>
            )}
          </div>
          {booking.otp_pickup && (
            <div className="mt-4 rounded-lg border-2 border-dashed border-brand-400 bg-white p-4 text-center">
              <p className="text-xs font-semibold uppercase tracking-wide text-brand-700">Share this OTP with your driver at pickup</p>
              <p className="mt-1 font-mono text-4xl font-extrabold tracking-widest text-ink-900">{booking.otp_pickup}</p>
            </div>
          )}
        </div>
      )}

      {/* Trip summary */}
      <div className={`${DATA_CARD_CLASS} p-5`}>
        <h2 className="text-base font-semibold text-ink-900">Trip summary</h2>
        <dl className="mt-3 grid grid-cols-1 gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
          <Row label="Pickup" value={`${booking.pickup_city}${booking.pickup_address ? ` — ${booking.pickup_address}` : ''}`} />
          <Row label="Drop" value={`${booking.drop_city}${booking.drop_address ? ` — ${booking.drop_address}` : ''}`} />
          <Row label="Date & time" value={`${booking.journey_date} at ${booking.journey_time}`} />
          <Row label="Vehicle" value={booking.vehicle_name || '—'} />
          <Row label="Passengers" value={String(booking.passengers)} />
          <Row label="Trip type" value={booking.trip_type} />
        </dl>
      </div>

      {/* Fare breakdown */}
      <div className={`${DATA_CARD_CLASS} p-5`}>
        <h2 className="text-base font-semibold text-ink-900">Fare breakdown</h2>
        <dl className="mt-3 space-y-1.5 text-sm">
          <FareRow label="Base fare" value={booking.base_fare} sym={sym} />
          {booking.toll_charges > 0 && <FareRow label="Toll charges" value={booking.toll_charges} sym={sym} />}
          {booking.parking_charges > 0 && <FareRow label="Parking charges" value={booking.parking_charges} sym={sym} />}
          {booking.driver_allowance > 0 && <FareRow label="Driver allowance" value={booking.driver_allowance} sym={sym} />}
          {booking.gst_amount > 0 && <FareRow label="GST" value={booking.gst_amount} sym={sym} />}
          {booking.discount_amount > 0 && (
            <FareRow label={`Discount${booking.promo_code ? ` (${booking.promo_code})` : ''}`} value={-booking.discount_amount} sym={sym} tone="text-success-600" />
          )}
          <div className="mt-2 flex items-center justify-between border-t border-ink-100 pt-2 font-semibold text-ink-900">
            <span>Estimated ride fare</span>
            <span>{currency(sym, booking.total_fare)}</span>
          </div>
          {payment_details.is_token_payment && (
            <>
              <div className="flex items-center justify-between text-brand-700">
                <span>{payment_details.token_label || 'Booking amount'} — paid to {brand().name} to confirm</span>
                <span className="font-semibold">{currency(sym, payment_details.token_amount)}</span>
              </div>
              <div className="flex items-center justify-between text-ink-500">
                <span>Remaining ride fare — payable directly to your vendor/driver</span>
                <span>{currency(sym, payment_details.remaining_amount)}</span>
              </div>
            </>
          )}
        </dl>
        {payment_details.disclaimer && (
          <p className="mt-3 rounded-lg bg-ink-50 p-3 text-xs leading-relaxed text-ink-600">{payment_details.disclaimer}</p>
        )}
      </div>

      {/* Payment instructions */}
      {needs_payment && (
        <div className={`${DATA_CARD_CLASS} p-5`}>
          <h2 className="text-base font-semibold text-ink-900">Booking amount payment</h2>
          {payment_details.is_token_payment ? (
            <>
              <p className="mt-1 text-sm text-ink-500">
                Pay {currency(sym, payment_details.amount)} now to {brand().name} as your {(payment_details.token_label || 'Booking amount').toLowerCase()} using one of the options below, then submit your proof. This is not an extra charge — it is part of the estimated ride fare of {currency(sym, booking.total_fare)}.
              </p>
              {payment_details.token_instructions && (
                <p className="mt-2 rounded-lg bg-brand-50 p-3 text-xs text-brand-800">{payment_details.token_instructions}</p>
              )}
              <p className="mt-2 text-xs text-ink-500">
                The remaining {currency(sym, payment_details.remaining_amount)} is payable directly to your assigned vendor/driver, who bills you for the ride. {brand().name} does not collect it.
              </p>
            </>
          ) : (
            <p className="mt-1 text-sm text-ink-500">
              Pay {currency(sym, payment_details.amount)} using one of the options below, then submit your proof.
            </p>
          )}
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
            {payment_details.upi_id && (
              <div className="rounded-lg border border-ink-100 p-4">
                <p className="text-xs font-semibold uppercase tracking-wide text-ink-500">UPI</p>
                <p className="mt-1 font-mono text-sm font-semibold text-ink-900">{payment_details.upi_id}</p>
                {payment_details.upi_qr_url && (
                  <img src={payment_details.upi_qr_url} alt="UPI QR code" className="mt-3 h-40 w-40 rounded-lg border border-ink-100 object-contain" />
                )}
              </div>
            )}
            {payment_details.bank_account && (
              <div className="rounded-lg border border-ink-100 p-4 text-sm">
                <p className="text-xs font-semibold uppercase tracking-wide text-ink-500">Bank transfer</p>
                <dl className="mt-1.5 space-y-1">
                  {payment_details.bank_holder && <Row label="Account holder" value={payment_details.bank_holder} compact />}
                  {payment_details.bank_name && <Row label="Bank" value={payment_details.bank_name} compact />}
                  {payment_details.bank_account && <Row label="Account no." value={payment_details.bank_account} compact />}
                  {payment_details.bank_ifsc && <Row label="IFSC" value={payment_details.bank_ifsc} compact />}
                </dl>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Proof upload */}
      {canSubmitProof && <ProofUploadForm bookingId={booking.id} phone={phone} onSubmitted={onProofSubmitted} />}
    </div>
  );
}

function Row({ label, value, compact }: { label: string; value: string; compact?: boolean }) {
  return (
    <div className={compact ? 'flex justify-between gap-3' : undefined}>
      <dt className={compact ? 'text-ink-500' : 'text-xs font-medium uppercase tracking-wide text-ink-400'}>{label}</dt>
      <dd className={compact ? 'font-medium text-ink-900' : 'text-ink-800'}>{value}</dd>
    </div>
  );
}

function FareRow({ label, value, sym, tone }: { label: string; value: number; sym: string; tone?: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-ink-500">{label}</span>
      <span className={`font-medium ${tone ?? 'text-ink-800'}`}>{currency(sym, value)}</span>
    </div>
  );
}

/**
 * Stages of the post-submit experience, once the payment proof upload
 * itself has succeeded. `idle` is the normal form. `success` is the
 * "Payment Proof Submitted Successfully" popup (Fix #2). `logging-in`
 * only happens when the submission created a brand-new guest account
 * (see ridego_app_api_submit_payment_proof()'s `account_created` flag)
 * — it shows the transitional message with the real 10-second
 * countdown before the redirect to the dashboard (Fix #3). A client
 * who already had an account (or was already logged in) never sees
 * `logging-in` — there is no account to "create", so the popup's
 * Continue button just closes it and the page stays put.
 */
type ProofStage = 'idle' | 'success' | 'logging-in';

const ACCOUNT_REDIRECT_SECONDS = 10;

function ProofUploadForm({ bookingId, phone, onSubmitted }: { bookingId: number; phone: string; onSubmitted: () => void }) {
  const navigate = useNavigate();
  const { applyAuthState } = useAuth();
  const [file, setFile] = useState<File | null>(null);
  const [utr, setUtr] = useState('');
  const [paymentApp, setPaymentApp] = useState('');
  const [amount, setAmount] = useState('');
  const [paymentTime, setPaymentTime] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [stage, setStage] = useState<ProofStage>('idle');
  const [accountCreated, setAccountCreated] = useState(false);
  const [redirectSeconds, setRedirectSeconds] = useState(ACCOUNT_REDIRECT_SECONDS);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const canSubmit = useMemo(() => !!file && utr.trim().length >= 6 && !submitting, [file, utr, submitting]);

  // Real countdown (not a fixed timeout with no visible progress) for
  // the account-creation/login stage — ticks once a second and fires
  // the redirect itself when it reaches zero, same pattern as the
  // booking's own payment-window countdown above on this page.
  useEffect(() => {
    if (stage !== 'logging-in') return;
    if (redirectSeconds <= 0) {
      navigate('/app/dashboard');
      return;
    }
    const t = setTimeout(() => setRedirectSeconds((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [stage, redirectSeconds, navigate]);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!file) {
      setError('Please attach a screenshot or receipt.');
      return;
    }
    if (utr.trim().length < 6) {
      setError('Enter a valid UTR / transaction ID (at least 6 characters).');
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      const res = await submitPaymentProof(bookingId, {
        proof_file: file,
        utr: utr.trim(),
        payment_app: paymentApp,
        amount,
        payment_time: paymentTime,
        client_phone: phone,
      });
      setFile(null);
      setUtr('');
      setPaymentApp('');
      setAmount('');
      setPaymentTime('');
      if (fileInputRef.current) fileInputRef.current.value = '';
      onSubmitted();
      if (res.account_created && res.auth) {
        // Reuses the exact login/register session-apply path (see
        // AuthContext's applyAuthState doc comment) — this is a real
        // auto-login off the real account the backend just created,
        // not a cosmetic message with nothing behind it.
        applyAuthState(res.auth);
        setAccountCreated(true);
      } else {
        setAccountCreated(false);
      }
      setStage('success');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not submit payment proof. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  function handleSuccessContinue() {
    if (accountCreated) {
      setStage('logging-in');
      setRedirectSeconds(ACCOUNT_REDIRECT_SECONDS);
    } else {
      setStage('idle');
    }
  }

  return (
    <div className={`${DATA_CARD_CLASS} p-5`}>
      <h2 className="text-base font-semibold text-ink-900">Submit booking amount payment proof</h2>
      <p className="mt-1 text-sm text-ink-500">Upload a screenshot of your payment along with the transaction details.</p>

      {/* Root-cause fix (screen jump during submit): this error banner is
          the only conditional block left inside the form now — success
          is a portaled popup (SuccessDialog) instead of an inline banner,
          so it can no longer push the fields below it down the page the
          moment the request resolves. The fields themselves are disabled
          in place (not remounted or resized) while `submitting` is true,
          and the submit button shows its own inline spinner (Button's
          `loading` prop) rather than the page reflowing around a
          separately-inserted spinner element. */}
      <form onSubmit={handleSubmit} noValidate className="mt-4 space-y-4">
        {error && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {error}
          </div>
        )}

        <div>
          <label htmlFor="proof-file" className={labelClasses}>
            Payment screenshot / receipt
          </label>
          <input
            id="proof-file"
            ref={fileInputRef}
            type="file"
            accept="image/png,image/jpeg,image/webp,application/pdf"
            required
            onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            disabled={submitting}
            className="mt-1.5 block w-full text-sm text-ink-700 file:mr-3 file:rounded-lg file:border-0 file:bg-brand-50 file:px-3.5 file:py-2 file:text-sm file:font-medium file:text-brand-700 hover:file:bg-brand-100"
          />
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label htmlFor="utr" className={labelClasses}>
              UTR / Transaction ID
            </label>
            <input
              id="utr"
              required
              minLength={6}
              value={utr}
              onChange={(e) => setUtr(e.target.value)}
              disabled={submitting}
              className={`mt-1.5 ${inputClasses}`}
            />
          </div>
          <div>
            <label htmlFor="payment-app" className={labelClasses}>
              Paid via (app)
            </label>
            <input
              id="payment-app"
              placeholder="e.g. Google Pay, PhonePe"
              value={paymentApp}
              onChange={(e) => setPaymentApp(e.target.value)}
              disabled={submitting}
              className={`mt-1.5 ${inputClasses}`}
            />
          </div>
          <div>
            <label htmlFor="amount" className={labelClasses}>
              Amount paid
            </label>
            <input
              id="amount"
              type="number"
              min={0}
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              disabled={submitting}
              className={`mt-1.5 ${inputClasses}`}
            />
          </div>
          <div>
            <label htmlFor="payment-time" className={labelClasses}>
              Payment time
            </label>
            <input
              id="payment-time"
              type="datetime-local"
              value={paymentTime}
              onChange={(e) => setPaymentTime(e.target.value)}
              disabled={submitting}
              className={`mt-1.5 ${inputClasses}`}
            />
          </div>
        </div>

        <Button type="submit" loading={submitting} disabled={!canSubmit} fullWidth size="lg">
          Submit payment proof
        </Button>
      </form>

      <SuccessDialog
        open={stage === 'success'}
        title="Payment Proof Submitted Successfully"
        description="Your payment proof has been submitted successfully. Our team will now verify your payment details and booking information. You will receive a call from our team shortly."
        actionLabel="Continue"
        onAction={handleSuccessContinue}
      />

      <SuccessDialog
        open={stage === 'logging-in'}
        title="Creating your account…"
        description="We've set up an account for you so you can track this booking and future ones from your dashboard. Logging you in automatically."
        hideAction
      >
        <p className="text-sm font-medium text-ink-700">
          Redirecting to your dashboard in <span className="font-mono font-bold text-brand-700">{redirectSeconds}</span>s…
        </p>
      </SuccessDialog>
    </div>
  );
}
