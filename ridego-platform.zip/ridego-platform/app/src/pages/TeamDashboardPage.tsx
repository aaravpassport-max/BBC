import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ApiError } from '../lib/api';
import { getMyTasks, getTeamDashboard, setMyTaskStatus, type Task, type TeamDashboard } from '../lib/api-team';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { Button } from '../components/ui/Button';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { Skeleton } from '../components/ui/Skeleton';
import { EmptyState } from '../components/ui/EmptyState';
import { DATA_CARD_CLASS } from '../components/ui/Zone';

const MODULE_LINKS: { module: string; cap: string; to: string; label: string }[] = [
  { module: 'bookings', cap: 'ridego_manage_bookings', to: '/admin/bookings', label: 'Bookings' },
  { module: 'new_booking', cap: 'ridego_create_admin_booking', to: '/admin/bookings/new', label: 'New booking' },
  { module: 'clients', cap: 'ridego_manage_clients', to: '/admin/clients', label: 'Clients' },
  { module: 'vendors', cap: 'ridego_manage_vendors', to: '/admin/vendors', label: 'Vendors' },
  { module: 'inquiries', cap: 'ridego_manage_enquiries', to: '/admin/enquiries', label: 'Enquiries' },
  { module: 'payments', cap: 'ridego_view_financial', to: '/admin/financial', label: 'Payments' },
  { module: 'reports', cap: 'ridego_view_reports', to: '/admin/reports', label: 'Reports' },
  { module: 'communication', cap: 'ridego_send_bulk_message', to: '/admin/notifications', label: 'Communication' },
];

// TRACE: route /app/team → the workspace for Regional Managers and Staff: their access, assigned regions, booking counts
//        (regional managers, region-scoped by the server), shortcuts to ONLY the modules they were granted, and their tasks.
//        Preconditions: signed-in team member (server 403 otherwise). Postconditions: task status changes persist via POST and the
//        list updates from the server response. Edge cases: no modules granted (explanatory empty state), no region assigned
//        (warning), no tasks (empty state), load failure (retry), status update failure (toast, list unchanged).
export function TeamDashboardPage() {
  const { user } = useAuth();
  const toast = useToast();
  const [data, setData] = useState<TeamDashboard | null>(null);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<number | null>(null);

  // TRACE: mount/retry → GET dashboard and tasks → state. Edge: failure → error text.
  const load = useCallback(async () => {
    setError(null);
    try { const [d, t] = await Promise.all([getTeamDashboard(), getMyTasks()]); setData(d); setTasks(t.tasks); }
    catch (e) { setError(e instanceof ApiError ? e.message : 'Could not load your workspace.'); }
  }, []);
  useEffect(() => { void load(); }, [load]);

  // TRACE: task status select → POST status → replaces that task with the server copy. Edge: failure → toast, no change.
  const changeStatus = async (t: Task, status: string) => {
    if (busy) return;
    setBusy(t.id);
    try { const r = await setMyTaskStatus(t.id, status); setTasks((l) => l.map((x) => (x.id === t.id ? r.task : x))); toast.show('Task updated.', 'success'); }
    catch (e) { toast.show(e instanceof ApiError ? e.message : 'Could not update the task.', 'error'); }
    finally { setBusy(null); }
  };

  if (error) return <div className="mx-auto max-w-4xl px-4 py-8"><ErrorBanner message={error} onRetry={load} /></div>;
  if (!data) return <div className="mx-auto max-w-4xl space-y-3 px-4 py-8"><Skeleton className="h-10 w-1/2" /><Skeleton className="h-32 w-full rounded-xl" /></div>;
  const links = MODULE_LINKS.filter((l) => user?.admin_caps?.includes(l.cap) && (!user.region_limited || l.to === '/admin/bookings'));
  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">{data.is_regional_manager ? 'Regional workspace' : 'Staff workspace'}</h1>
      <p className="mt-1 text-sm text-ink-600">Welcome, {data.name}.{data.is_regional_manager && data.regions && data.regions.length > 0 ? ` Your regions: ${data.regions.join(', ')}.` : ''}{data.region_scope === 'all' ? ' You have access to all regions.' : ''}</p>
      {data.no_region && <div role="alert" className="mt-4 rounded-lg border border-warning-500/30 bg-warning-50 p-3 text-sm text-warning-600">No region is assigned to you yet, so no bookings are visible. Ask an administrator to assign one.</div>}

      {data.counts && (
        <section aria-label="Bookings in your region" className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-5">
          {([['total', 'Bookings'], ['today', 'Trips today'], ['awaiting_payment', 'Awaiting payment'], ['needs_vendor', 'Need a vendor'], ['active_trips', 'Active trips']] as const).map(([k, label]) => (
            <div key={k} className={`${DATA_CARD_CLASS} p-3`}><p className="text-2xl font-bold text-ink-900">{data.counts?.[k] ?? 0}</p><p className="text-xs text-ink-600">{label}</p></div>
          ))}
        </section>
      )}

      <section className="mt-8" aria-label="Your access">
        <h2 className="text-lg font-semibold text-ink-900">Your tools</h2>
        {links.length === 0 ? <div className="mt-3"><EmptyState title="No modules enabled" description="An administrator has not granted you access to any module yet. You can still see your tasks below." /></div> : (
          <div className="mt-3 flex flex-wrap gap-2">{links.map((l) => <Link key={l.to} to={l.to}><Button variant="secondary" size="sm">{l.label}</Button></Link>)}</div>
        )}
      </section>

      {data.recent && data.recent.length > 0 && (
        <section className="mt-8" aria-label="Recent bookings">
          <h2 className="text-lg font-semibold text-ink-900">Latest bookings in your region</h2>
          <ul className={`mt-3 divide-y divide-ink-100 ${DATA_CARD_CLASS}`}>
            {data.recent.map((b) => (
              <li key={b.id}><Link to={`/app/admin/bookings/${b.id}`} className="flex flex-wrap items-center justify-between gap-2 p-3 hover:bg-ink-50">
                <span className="font-medium text-ink-900">{b.booking_number}</span><span className="text-sm text-ink-600">{b.pickup_city} → {b.drop_city} · {b.journey_date}</span><span className="rounded-full bg-ink-100 px-2 py-0.5 text-xs">{b.status.replace(/_/g, ' ')}</span>
              </Link></li>
            ))}
          </ul>
        </section>
      )}

      <section className="mt-8" aria-label="My tasks">
        <h2 className="text-lg font-semibold text-ink-900">My tasks ({data.tasks.open} open, {data.tasks.in_progress} in progress, {data.tasks.done} done)</h2>
        {tasks.length === 0 ? <div className="mt-3"><EmptyState title="No tasks assigned" description="Tasks assigned to you by an administrator appear here." /></div> : (
          <ul className="mt-3 space-y-3">
            {tasks.map((t) => (
              <li key={t.id} className={`flex flex-wrap items-start justify-between gap-3 ${DATA_CARD_CLASS} p-4`}>
                <div><p className="font-semibold text-ink-900">{t.title}</p><p className="text-sm text-ink-600">{t.priority} priority{t.due_date ? ` · due ${t.due_date}` : ''}</p>{t.description && <p className="mt-1 text-sm text-ink-700">{t.description}</p>}</div>
                <div><label htmlFor={`ts-${t.id}`} className="sr-only">Status of {t.title}</label>
                  <select id={`ts-${t.id}`} value={t.status} disabled={busy === t.id} onChange={(e) => changeStatus(t, e.target.value)} className="rounded-lg border border-ink-200 px-3 py-1.5 text-sm">
                    <option value="open">Open</option><option value="in_progress">In progress</option><option value="done">Done</option>
                  </select></div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
