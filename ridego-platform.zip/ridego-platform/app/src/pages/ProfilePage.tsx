import { useCallback, useEffect, useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { changePassword, getProfile, setNonce, updateProfile, ApiError } from '../lib/api';
import type { ProfileResponse } from '../types/api';
import { Skeleton } from '../components/ui/Skeleton';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { Button } from '../components/ui/Button';
import { DataCard, ShowcaseCard } from '../components/ui/Zone';

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

export function ProfilePage() {
  const { refresh, isVendor } = useAuth();
  const [profile, setProfile] = useState<ProfileResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getProfile();
      setProfile(res);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load your profile. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Account settings</h1>
          <p className="text-sm text-ink-500">Manage your account details and password.</p>
        </div>
        <Link to="/transactions">
          <Button variant="secondary" size="sm">
            Transaction history
          </Button>
        </Link>
      </div>

      {!loading && !error && !isVendor && (
        <ShowcaseCard className="mt-6 flex flex-col items-start justify-between gap-3 bg-brand-50 p-5 sm:flex-row sm:items-center">
          <div>
            <h2 className="font-semibold text-ink-900">Become a vendor</h2>
            <p className="mt-1 text-sm text-ink-600">
              Add a vendor profile to your account and start receiving ride leads.
            </p>
          </div>
          <Link to="/vendor/onboard">
            <Button size="sm">Get started</Button>
          </Link>
        </ShowcaseCard>
      )}

      {loading && (
        <div className="mt-6 space-y-4" aria-busy="true" aria-label="Loading profile">
          <Skeleton className="h-48 w-full rounded-xl" />
          <Skeleton className="h-48 w-full rounded-xl" />
        </div>
      )}

      {!loading && error && (
        <div className="mt-6">
          <ErrorBanner message={error} onRetry={load} />
        </div>
      )}

      {!loading && !error && profile && (
        <div className="mt-6 space-y-6">
          <AccountDetailsCard
            profile={profile}
            onSaved={(next) => {
              setProfile(next);
              refresh().catch(() => {});
            }}
          />
          <ChangePasswordCard />
        </div>
      )}
    </div>
  );
}

function AccountDetailsCard({
  profile,
  onSaved,
}: {
  profile: ProfileResponse;
  onSaved: (next: ProfileResponse) => void;
}) {
  const [name, setName] = useState(profile.name);
  const [email, setEmail] = useState(profile.email);
  const [phone, setPhone] = useState(profile.phone);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (!name.trim()) {
      setError('Please enter your name.');
      return;
    }
    if (!isValidEmail(email)) {
      setError('Please enter a valid email address.');
      return;
    }
    if (!phone.trim()) {
      setError('Please enter your phone number.');
      return;
    }

    setSubmitting(true);
    try {
      await updateProfile({ name, email, phone });
      const canonical = await getProfile();
      setName(canonical.name);
      setEmail(canonical.email);
      setPhone(canonical.phone);
      setSuccess('Your account details have been updated.');
      onSaved(canonical);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not update your details. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <DataCard className="p-6">
      <h2 className="text-lg font-semibold text-ink-900">Account details</h2>

      <form className="mt-4 space-y-4" onSubmit={handleSubmit} noValidate>
        {error && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {error}
          </div>
        )}
        {success && (
          <div role="status" className="rounded-lg border border-success-500/30 bg-success-50 px-3 py-2 text-sm text-success-600">
            {success}
          </div>
        )}

        <div>
          <label htmlFor="profile-name" className="block text-sm font-medium text-ink-700">
            Name
          </label>
          <input
            id="profile-name"
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            autoComplete="name"
            className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>

        <div>
          <label htmlFor="profile-email" className="block text-sm font-medium text-ink-700">
            Email
          </label>
          <input
            id="profile-email"
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            autoComplete="email"
            className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>

        <div>
          <label htmlFor="profile-phone" className="block text-sm font-medium text-ink-700">
            Phone
          </label>
          <input
            id="profile-phone"
            type="tel"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            autoComplete="tel"
            className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>

        <Button type="submit" loading={submitting}>
          Save details
        </Button>
      </form>
    </DataCard>
  );
}

function ChangePasswordCard() {
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setSuccess(null);

    if (newPassword.length < 8) {
      setError('New password must be at least 8 characters.');
      return;
    }
    if (newPassword !== confirmPassword) {
      setError('New password and confirmation do not match.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await changePassword({ current_password: currentPassword, new_password: newPassword });
      if (res.nonce) {
        setNonce(res.nonce);
      }
      setSuccess(res.message ?? 'Your password has been changed.');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmPassword('');
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not change your password. Please try again.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <DataCard className="p-6">
      <h2 className="text-lg font-semibold text-ink-900">Change password</h2>

      <form className="mt-4 space-y-4" onSubmit={handleSubmit} noValidate>
        {error && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {error}
          </div>
        )}
        {success && (
          <div role="status" className="rounded-lg border border-success-500/30 bg-success-50 px-3 py-2 text-sm text-success-600">
            {success}
          </div>
        )}

        <div>
          <label htmlFor="current-password" className="block text-sm font-medium text-ink-700">
            Current password
          </label>
          <input
            id="current-password"
            type="password"
            autoComplete="current-password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
            className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>

        <div>
          <label htmlFor="new-password" className="block text-sm font-medium text-ink-700">
            New password
          </label>
          <input
            id="new-password"
            type="password"
            autoComplete="new-password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>

        <div>
          <label htmlFor="confirm-password" className="block text-sm font-medium text-ink-700">
            Confirm new password
          </label>
          <input
            id="confirm-password"
            type="password"
            autoComplete="new-password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
          />
        </div>

        <Button type="submit" loading={submitting}>
          Change password
        </Button>
      </form>
    </DataCard>
  );
}
