import { useCallback, useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { ApiError, getFare, getVehicles } from '../lib/api';
import type { FareResponse, Vehicle } from '../types/api';
import { Button } from '../components/ui/Button';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { EmptyState } from '../components/ui/EmptyState';
import { SkeletonCard } from '../components/ui/Skeleton';
import { brand, heightStyle, fitClass } from '../lib/brand';
import { DATA_CARD_CLASS, SHOWCASE_CARD_CLASS } from '../components/ui/Zone';

interface SearchPrefillState {
  tripType: string;
  pickup: string;
  drop: string;
  date: string;
}

interface VehicleResult {
  vehicle: Vehicle;
  fare: FareResponse | null;
}

export function SearchResultsPage() {
  const location = useLocation();
  const navigate = useNavigate();
  const prefill = (location.state as SearchPrefillState | null) ?? null;
  const hasPrefill = Boolean(prefill?.pickup && prefill?.drop && prefill?.date);

  const [results, setResults] = useState<VehicleResult[] | null>(null);
  const [loading, setLoading] = useState(hasPrefill);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!prefill || !hasPrefill) return;
    setLoading(true);
    setError(null);
    try {
      const vehicles = await getVehicles();
      const fareResults = await Promise.allSettled(
        vehicles.map((v) =>
          getFare({
            trip_type: prefill.tripType,
            pickup_city: prefill.pickup,
            drop_city: prefill.drop,
            vehicle_type_id: v.id,
            journey_date: prefill.date,
            journey_time: '08:00',
            distance_km: 0,
            duration_minutes: 0,
            hours_required: 4,
            return_date: '',
            passengers: 1,
            promo_code: '',
          })
        )
      );
      const combined: VehicleResult[] = vehicles.map((v, i) => {
        const r = fareResults[i];
        return { vehicle: v, fare: r.status === 'fulfilled' ? r.value : null };
      });
      combined.sort((a, b) => {
        const af = a.fare?.fare.total_fare;
        const bf = b.fare?.fare.total_fare;
        if (af == null && bf == null) return 0;
        if (af == null) return 1;
        if (bf == null) return -1;
        return af - bf;
      });
      setResults(combined);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not load vehicle options. Please try again.');
    } finally {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefill?.tripType, prefill?.pickup, prefill?.drop, prefill?.date]);

  useEffect(() => {
    load();
  }, [load]);

  if (!hasPrefill) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 sm:px-6 lg:px-8">
        <EmptyState
          title="Search for a route first"
          description="Head back to the home page and enter a pickup city, drop city and travel date to compare vehicle types and fares."
          action={
            <Link to="/">
              <Button>Go to home page</Button>
            </Link>
          }
        />
      </div>
    );
  }

  const tripTypeLabel =
    prefill?.tripType === 'round_trip' ? 'Round trip' : prefill?.tripType === 'local' ? 'Local / hourly rental' : 'One way';

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8">
      <div className={`${DATA_CARD_CLASS} bg-ink-50/60 p-5`}>
        <h1 className="text-xl font-bold text-ink-900 sm:text-2xl">
          {prefill?.pickup} → {prefill?.drop}
        </h1>
        <p className="mt-1 text-sm text-ink-500">
          {tripTypeLabel} &middot; {prefill?.date}
        </p>
      </div>

      <div className="mt-8">
        {loading && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3" aria-busy="true" aria-label="Loading vehicle options">
            {Array.from({ length: 4 }).map((_, i) => (
              <SkeletonCard key={i} />
            ))}
          </div>
        )}

        {!loading && error && <ErrorBanner message={error} onRetry={load} />}

        {!loading && !error && results && results.length === 0 && (
          <EmptyState
            title="No vehicle types available"
            description="We couldn't find any vehicle types to show fares for right now. Please try again later."
          />
        )}

        {!loading && !error && results && results.length > 0 && (
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {results.map(({ vehicle, fare }) => (
              <div
                key={vehicle.id}
                className={`flex flex-col overflow-hidden ${SHOWCASE_CARD_CLASS}`}
              >
                <div
                  className="flex items-center justify-center bg-ink-100"
                  style={heightStyle(brand().vehicle_card_height, 144)}
                >
                  {vehicle.image_url ? (
                    <img
                      src={vehicle.image_url}
                      alt={vehicle.name}
                      className={'h-full w-full ' + fitClass(brand().vehicle_card_fit)}
                      loading="lazy"
                    />
                  ) : (
                    <svg
                      className="h-12 w-12 text-ink-300"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="1.5"
                      aria-hidden="true"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" d="M8 17l4-11 4 11M9.5 13h5M3 21h18" />
                    </svg>
                  )}
                </div>
                <div className="flex flex-1 flex-col p-4">
                  <p className="font-semibold text-ink-900">{vehicle.name}</p>
                  <p className="mt-1 text-sm text-ink-500">{vehicle.seating_capacity} seats</p>
                  <p className="mt-3 text-sm text-ink-600">
                    {fare ? (
                      <>
                        <span className="text-xs uppercase tracking-wide text-ink-400">Estimated fare</span>
                        <br />
                        <span className="text-xl font-bold text-brand-700">
                          {fare.sym}
                          {fare.fare.total_fare.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                        </span>
                      </>
                    ) : (
                      <span className="text-sm font-medium text-ink-400">Fare unavailable</span>
                    )}
                  </p>
                  <div className="mt-auto flex items-center justify-between gap-2 pt-4">
                    <Link
                      to={`/app/vehicles/${vehicle.slug}`}
                      state={prefill}
                      className="text-sm font-medium text-brand-700 hover:text-brand-800"
                    >
                      View details
                    </Link>
                    <Button
                      size="sm"
                      onClick={() =>
                        navigate('/book', {
                          state: {
                            tripType: prefill?.tripType,
                            pickup: prefill?.pickup,
                            drop: prefill?.drop,
                            vehicleId: vehicle.id,
                            date: prefill?.date,
                          },
                        })
                      }
                    >
                      Book this vehicle
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
