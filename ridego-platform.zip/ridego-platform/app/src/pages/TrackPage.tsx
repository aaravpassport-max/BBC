import { useCallback, useEffect, useRef, useState, type FormEvent } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ApiError, lookupBooking } from '../lib/api';
import type { BookingLookupResponse } from '../types/api';
import { Button } from '../components/ui/Button';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { Skeleton } from '../components/ui/Skeleton';
import { DATA_CARD_CLASS } from '../components/ui/Zone';

const inputClasses =
  'mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30';
const labelClasses = 'block text-sm font-medium text-ink-700';

const TERMINAL_STATUSES = ['completed', 'cancelled', 'expired'];

const STATUS_TONE: Record<string, string> = {
  pending: 'bg-ink-100 text-ink-700',
  pending_payment: 'bg-warning-50 text-warning-600',
  payment_rejected: 'bg-danger-50 text-danger-600',
  confirmed: 'bg-success-50 text-success-600',
  assigned: 'bg-success-50 text-success-600',
  completed: 'bg-success-50 text-success-600',
  cancelled: 'bg-danger-50 text-danger-600',
  expired: 'bg-danger-50 text-danger-600',
};

export function TrackPage() {
  const [params, setParams] = useSearchParams();
  const [bookingNumber, setBookingNumber] = useState(params.get('booking') ?? '');
  const [phone, setPhone] = useState(params.get('phone') ?? '');
  const [submitted, setSubmitted] = useState(!!(params.get('booking') && params.get('phone')));

  const [data, setData] = useState<BookingLookupResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const [error, setError] = useState<string | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const load = useCallback((bn: string, ph: string, silent = false) => {
    if (!silent) setLoading(true);
    else setRefreshing(true);
    setError(null);
    lookupBooking({ booking: bn, phone: ph })
      .then((res) => {
        setData(res);
        setLastUpdated(new Date());
      })
      .catch((err) =>
        setError(
          err instanceof ApiError
            ? 'Booking not found. Please double-check the booking number and phone number.'
            : 'Could not load booking status. Please try again.'
        )
      )
      .finally(() => {
        setLoading(false);
        setRefreshing(false);
      });
  }, []);

  useEffect(() => {
    if (!submitted || !bookingNumber || !phone) return;
    load(bookingNumber, phone);
  }, [submitted, bookingNumber, phone, load]);

  // Poll every 20s while status is non-terminal.
  useEffect(() => {
    if (pollRef.current) {
      clearInterval(pollRef.current);
      pollRef.current = null;
    }
    if (!submitted || !data || TERMINAL_STATUSES.includes(data.booking.status)) return;
    pollRef.current = setInterval(() => load(bookingNumber, phone, true), 20000);
    return () => {
      if (pollRef.current) clearInterval(pollRef.current);
    };
  }, [submitted, data, bookingNumber, phone, load]);

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    const bn = bookingNumber.trim().toUpperCase();
    const ph = phone.trim();
    if (!bn || ph.replace(/\D/g, '').length < 10) {
      setError('Enter a valid booking number and phone number.');
      return;
    }
    setBookingNumber(bn);
    setParams({ booking: bn, phone: ph });
    setSubmitted(true);
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Track your booking</h1>
      <p className="mt-1 text-sm text-ink-500">Enter your booking number and phone to see live status.</p>

      <form onSubmit={handleSubmit} noValidate className={`mt-6 grid grid-cols-1 gap-4 p-5 sm:grid-cols-[1fr_1fr_auto] sm:items-end ${DATA_CARD_CLASS}`}>
        <div>
          <label htmlFor="track-booking" className={labelClasses}>
            Booking number
          </label>
          <input
            id="track-booking"
            required
            placeholder="RG-XXXXXX"
            value={bookingNumber}
            onChange={(e) => setBookingNumber(e.target.value)}
            className={inputClasses}
          />
        </div>
        <div>
          <label htmlFor="track-phone" className={labelClasses}>
            Phone number
          </label>
          <input id="track-phone" type="tel" required value={phone} onChange={(e) => setPhone(e.target.value)} className={inputClasses} />
        </div>
        <Button type="submit" loading={loading}>
          Track
        </Button>
      </form>

      <div className="mt-6">
        {loading && !data && (
          <div className="space-y-3">
            <Skeleton className="h-16 w-full rounded-xl" />
            <Skeleton className="h-32 w-full rounded-xl" />
          </div>
        )}

        {error && <ErrorBanner message={error} onRetry={submitted ? () => load(bookingNumber, phone) : undefined} />}

        {!error && data && (
          <div className="space-y-4">
            <div className={`rounded-xl p-5 ${STATUS_TONE[data.booking.status] ?? 'bg-ink-100 text-ink-700'}`}>
              <div className="flex items-center gap-2">
                <p className="text-lg font-bold">{data.booking.status_label}</p>
                {refreshing && (
                  <span
                    className="h-2 w-2 shrink-0 animate-pulse rounded-full bg-current opacity-70"
                    aria-hidden="true"
                  />
                )}
              </div>
              <p className="text-sm opacity-90">
                #{data.booking.booking_number} &middot; {data.booking.pickup_city} → {data.booking.drop_city}
              </p>
              <p className="mt-1 text-xs opacity-80">
                {data.booking.journey_date} at {data.booking.journey_time}
              </p>
            </div>

            {data.booking.vendor_name && (
              <div className="rounded-xl border border-brand-200 bg-brand-50 p-5">
                <p className="text-sm font-semibold text-brand-800">Your driver-partner</p>
                <p className="mt-1 text-lg font-bold text-ink-900">{data.booking.vendor_name}</p>
                <div className="mt-2 flex flex-wrap gap-3 text-sm">
                  {data.booking.vendor_phone && (
                    <a
                      href={`tel:${data.booking.vendor_phone}`}
                      className="inline-flex min-h-[40px] items-center rounded-lg px-3 font-medium text-brand-700 hover:bg-brand-100 hover:text-brand-800"
                    >
                      Call {data.booking.vendor_phone}
                    </a>
                  )}
                  {data.booking.vendor_whatsapp && (
                    <a
                      href={`https://wa.me/${data.booking.vendor_whatsapp.replace(/\D/g, '')}`}
                      target="_blank"
                      rel="noreferrer"
                      className="inline-flex min-h-[40px] items-center rounded-lg px-3 font-medium text-success-600 hover:bg-success-50 hover:text-success-700"
                    >
                      WhatsApp
                    </a>
                  )}
                </div>
              </div>
            )}

            {!TERMINAL_STATUSES.includes(data.booking.status) && (
              <p className="text-xs text-ink-400">
                {lastUpdated ? `Last updated ${lastUpdated.toLocaleTimeString()}` : ''} &middot; auto-refreshes every 20 seconds
              </p>
            )}

            <a href={`/app/confirm?booking=${encodeURIComponent(data.booking.booking_number)}&phone=${encodeURIComponent(phone)}`} className="inline-block text-sm font-semibold text-brand-600 hover:text-brand-700">
              View full booking & payment details →
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
