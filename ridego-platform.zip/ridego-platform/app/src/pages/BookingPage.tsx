import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react';
import { useBlocker, useLocation, useNavigate } from 'react-router-dom';
import {
  ApiError,
  createBooking,
  getCities,
  getFare,
  getMapsConfig,
  getVehicles,
  sendOtp,
  verifyOtp,
} from '../lib/api';
import type { City, FareResponse, TripType, Vehicle } from '../types/api';
import { useAuth } from '../context/AuthContext';
import { Button } from '../components/ui/Button';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { Skeleton, SkeletonCard } from '../components/ui/Skeleton';
import { OtpInput } from '../components/booking/OtpInput';
import { BookingModalShell } from '../components/booking/BookingModalShell';
import { ConfirmDialog } from '../components/ui/ConfirmDialog';
import { SuccessDialog } from '../components/ui/SuccessDialog';
import { LocationPicker, type LocationValue } from '../components/booking/LocationPicker';
import { brand } from '../lib/brand';

/**
 * Root-cause fix: this used to list 'local' AND 'hourly' as two
 * separate tabs, but the backend (ridego_calculate_fare()'s switch in
 * includes/pricing.php) only ever recognized 'local' — there is no
 * 'hourly' trip_type anywhere in the schema or pricing engine. Picking
 * "Rental (hourly)" silently fell through to the one_way per-km
 * formula, completely ignoring the hours the customer actually
 * entered, and charging/quoting the wrong fare. There is exactly one
 * hours-based backend concept (ridego_calculate_local_fare(), driven
 * by hours_required and the vehicle's local packages), so there is now
 * exactly one tab for it.
 */
const TRIP_TYPES: { value: TripType; label: string }[] = [
  { value: 'one_way', label: 'One way' },
  { value: 'round_trip', label: 'Round trip' },
  { value: 'local', label: 'Local / hourly rental' },
];

const PAYMENT_METHODS: { value: string; label: string; description: string }[] = [
  { value: 'upi', label: 'UPI', description: 'Pay the booking amount via UPI to confirm your trip.' },
  { value: 'bank_transfer', label: 'Bank transfer', description: 'Pay the booking amount via NEFT/IMPS to confirm your trip.' },
];

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

/**
 * Root-cause fix: the wizard held every field (trip details, chosen
 * vehicle, contact info, current step) only in React component state,
 * with no persistence at all. A refresh (accidental F5, a crashed tab
 * reopened, a phone rotating and remounting the page) or the browser's
 * native back/forward-cache eviction wiped the in-progress booking back
 * to a blank step 0 with no warning — distinct from (and not covered
 * by) the useBlocker above, which only intercepts in-app react-router
 * navigation and does nothing for a hard reload or an external
 * navigation the SPA never sees.
 *
 * Persisting a snapshot of the form to sessionStorage on every change,
 * and rehydrating it (via lazy useState initializers, so there's no
 * flash of a blank step 0 before the saved step applies) on mount,
 * makes a reload/remount resume exactly where the user left off.
 * sessionStorage (not localStorage) is deliberate: the draft should
 * survive within this tab/session but not leak into a brand new
 * session on another day or device. A short TTL guards against
 * resuming a stale draft against reference data (cities, vehicles,
 * fares) that may have changed since. OTP verification state,
 * submission state, and anything fare-derived are intentionally
 * excluded — those must always be re-established live, never restored
 * from disk, since fares and OTP trust are time-sensitive/security
 * sensitive.
 */
const BOOKING_DRAFT_KEY = 'ridego_booking_draft_v1';
const BOOKING_DRAFT_TTL_MS = 2 * 60 * 60 * 1000; // 2 hours

interface BookingDraft {
  savedAt: number;
  step?: number;
  tripType?: TripType;
  pickupCity?: string;
  pickupLocation?: LocationValue;
  dropCity?: string;
  dropLocation?: LocationValue;
  journeyDate?: string;
  journeyTime?: string;
  returnDate?: string;
  returnTime?: string;
  hoursRequired?: number;
  passengers?: number;
  luggageCount?: number;
  vehicleId?: number | '';
  promoCode?: string;
  paymentMethod?: string;
  name?: string;
  phone?: string;
  email?: string;
  altPhone?: string;
  passengerTotal?: string;
  passengerMale?: string;
  passengerFemale?: string;
  passengerChildren?: string;
  passengerNotes?: string;
}

function loadBookingDraft(): BookingDraft | null {
  try {
    const raw = sessionStorage.getItem(BOOKING_DRAFT_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as BookingDraft;
    if (!parsed || typeof parsed.savedAt !== 'number') return null;
    if (Date.now() - parsed.savedAt > BOOKING_DRAFT_TTL_MS) {
      sessionStorage.removeItem(BOOKING_DRAFT_KEY);
      return null;
    }
    return parsed;
  } catch {
    // Corrupt/unavailable storage (private browsing, quota, etc.) —
    // treat exactly like "no draft" rather than breaking the page.
    return null;
  }
}

function saveBookingDraft(draft: Omit<BookingDraft, 'savedAt'>) {
  try {
    sessionStorage.setItem(BOOKING_DRAFT_KEY, JSON.stringify({ ...draft, savedAt: Date.now() }));
  } catch {
    // Best-effort — a full/blocked sessionStorage should never break booking.
  }
}

function clearBookingDraft() {
  try {
    sessionStorage.removeItem(BOOKING_DRAFT_KEY);
  } catch {
    // ignore
  }
}

const inputClasses =
  'w-full rounded-lg border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30 disabled:bg-ink-50 disabled:text-ink-400';
const labelClasses = 'block text-sm font-medium text-ink-700';

interface PrefillState {
  tripType?: string;
  pickup?: string;
  drop?: string;
  vehicleId?: number;
  date?: string;
}

/**
 * Mobile-first transformation, Phase 3 (step wizard) + Phase 4 (modal
 * flow, all viewports): this page used to be one long scroll of five
 * sections — on a phone that meant a lot of blind scrolling before
 * finding out a required field further down was still empty, and on
 * desktop the whole thing was a single dense page.
 *
 * Phase 3 introduced an explicit step wizard on mobile only (one
 * section visible at a time, sticky Back/Next footer, a step
 * indicator), leaving desktop as a single scroll.
 *
 * Phase 4 replaces that mobile-only wizard with a real modal on EVERY
 * viewport (BookingModalShell): full-screen on mobile, a centered
 * dialog on desktop — same header (title + close + progress bar), same
 * scrollable body showing only the current step, same sticky footer,
 * on both. `stepBody` below (the actual field markup) is identical on
 * every viewport; only BookingModalShell's own chrome shape (full
 * screen vs. centered card) responds to viewport width, and that
 * responsiveness lives entirely inside that component now — this page
 * no longer branches on viewport at all.
 */
/**
 * Passenger & Safety Information step: placed right after Contact
 * details and before Verify/OTP. By this point the wizard knows who is
 * booking (step 3) but nothing yet about who is actually riding — and
 * this data needs to be known and visible to whoever assigns a
 * vendor/driver BEFORE that assignment happens, so it must be captured
 * before the booking is finalized (the OTP/Verify step that follows).
 * Putting it any earlier (e.g. before Vehicle/Payment) would ask a
 * safety question before the person has even committed to booking a
 * specific vehicle, which reads as more invasive with no benefit — the
 * assignment this data feeds into only ever happens after the booking
 * exists.
 */
const STEP_LABELS = ['Trip', 'Vehicle', 'Payment', 'Contact', 'Safety', 'Verify'] as const;
const SAFETY_STEP = 4;

interface BookingPageProps {
  /**
   * Embedded mode — used by RoutePage's "Book this route" popup so the
   * booking form opens in place, with no react-router navigation (no URL
   * change), instead of the normal full /app/book route. When set, this
   * prefill is used instead of location.state, and onEmbeddedClose is
   * called wherever the standalone page would otherwise navigate away
   * (close button, backdrop/Escape, back-gesture blocker).
   */
  embeddedPrefill?: PrefillState;
  onEmbeddedClose?: () => void;
}

export function BookingPage({ embeddedPrefill, onEmbeddedClose }: BookingPageProps = {}) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuth();
  const embedded = !!onEmbeddedClose;
  const prefill = embedded ? (embeddedPrefill ?? null) : ((location.state as PrefillState | null) ?? null);

  // Reference data — origin and destination are separate lists (a city can
  // be pickup-only, drop-only, both, or neither) rather than one shared
  // list reused for both selects; deliberately NOT cross-filtered by
  // which routes exist between them, so any supported origin can be
  // paired with any supported destination — the backend's fare/route
  // resolution (ridego_resolve_route_distance, includes/pricing.php)
  // already estimates a fare for any pair, falling back to a distance
  // estimate when no explicit route row exists yet.
  const [originCities, setOriginCities] = useState<City[] | null>(null);
  const [destinationCities, setDestinationCities] = useState<City[] | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[] | null>(null);
  const [refError, setRefError] = useState<string | null>(null);
  const [refLoading, setRefLoading] = useState(true);
  // Google Maps key for the pickup/drop autocomplete + pin map — null
  // until GET /app/maps-config resolves, and stays null forever if no
  // key is configured (LocationPicker then falls back to a plain
  // address text field with no map, same as before this feature).
  const [mapsApiKey, setMapsApiKey] = useState<string | null>(null);

  // Rehydration source for every lazy initializer below — read exactly
  // once per mount (a fresh mount is exactly when a draft should apply;
  // a live tab that already has state should never have it clobbered by
  // a stale storage read later). A saved draft takes precedence over a
  // fresh `prefill` from the URL, since resuming an in-progress booking
  // is more likely intended than re-applying a stale query-string
  // prefill from the same or an earlier navigation.
  const [draft] = useState<BookingDraft | null>(() => loadBookingDraft());

  // Trip details
  const [tripType, setTripType] = useState<TripType>(draft?.tripType ?? ((prefill?.tripType as TripType) || 'one_way'));
  const [pickupCity, setPickupCity] = useState(draft?.pickupCity ?? prefill?.pickup ?? '');
  const [pickupLocation, setPickupLocation] = useState<LocationValue>(
    draft?.pickupLocation ?? { address: '', lat: null, lng: null }
  );
  const [dropCity, setDropCity] = useState(draft?.dropCity ?? prefill?.drop ?? '');
  const [dropLocation, setDropLocation] = useState<LocationValue>(
    draft?.dropLocation ?? { address: '', lat: null, lng: null }
  );
  const [journeyDate, setJourneyDate] = useState(draft?.journeyDate ?? prefill?.date ?? todayStr());
  const [journeyTime, setJourneyTime] = useState(draft?.journeyTime ?? '09:00');
  const [returnDate, setReturnDate] = useState(draft?.returnDate ?? '');
  const [returnTime, setReturnTime] = useState(draft?.returnTime ?? '');
  const [hoursRequired, setHoursRequired] = useState(draft?.hoursRequired ?? 4);
  const [passengers, setPassengers] = useState(draft?.passengers ?? 1);
  const [luggageCount, setLuggageCount] = useState(draft?.luggageCount ?? 0);

  // Vehicle & fare
  const [vehicleId, setVehicleId] = useState<number | ''>(draft?.vehicleId ?? prefill?.vehicleId ?? '');
  const [promoCode, setPromoCode] = useState(draft?.promoCode ?? '');
  const [fares, setFares] = useState<Record<number, FareResponse | 'loading' | 'error'>>({});
  const [paymentMethod, setPaymentMethod] = useState(draft?.paymentMethod ?? 'upi');

  // Contact
  const [name, setName] = useState(draft?.name ?? user?.name ?? '');
  const [phone, setPhone] = useState(draft?.phone ?? user?.phone ?? '');
  const [email, setEmail] = useState(draft?.email ?? user?.email ?? '');
  const [altPhone, setAltPhone] = useState(draft?.altPhone ?? '');
  const [phoneTouched, setPhoneTouched] = useState(false);

  // Passenger & Safety Information — kept as raw strings (not numbers) so
  // the fields can be genuinely empty while the user is filling the step,
  // rather than forcing a 0 the moment they clear the box. Total is the
  // only one that gates progress; male/female/children are validated
  // against it (see passengerCountsValid below) but are all optional on
  // their own — a rider can leave them blank and give only the total.
  const [passengerTotal, setPassengerTotal] = useState(draft?.passengerTotal ?? String(draft?.passengers ?? passengers ?? 1));
  const [passengerMale, setPassengerMale] = useState(draft?.passengerMale ?? '');
  const [passengerFemale, setPassengerFemale] = useState(draft?.passengerFemale ?? '');
  const [passengerChildren, setPassengerChildren] = useState(draft?.passengerChildren ?? '');
  const [passengerNotes, setPassengerNotes] = useState(draft?.passengerNotes ?? '');

  // OTP
  const [otpTrusted, setOtpTrusted] = useState(false);
  const [otpSent, setOtpSent] = useState(false);
  const [otpSending, setOtpSending] = useState(false);
  const [otpVerifying, setOtpVerifying] = useState(false);
  const [otpVerified, setOtpVerified] = useState(false);
  const [otpValue, setOtpValue] = useState('');
  const [otpError, setOtpError] = useState<string | null>(null);
  const [otpMessage, setOtpMessage] = useState<string | null>(null);
  const [resendCooldown, setResendCooldown] = useState(0);

  // Independent Email OTP Verification — mirrors every phone-OTP state
  // field above exactly, but for the email channel (channel: 'email' on
  // the shared /app/otp/send and /app/otp/verify endpoints). Kept as its
  // own set of state rather than parameterizing the phone one so each
  // channel's step in the wizard can be shown, verified, and gated on
  // its own, independently of the other's admin toggle or state.
  const [emailOtpTrusted, setEmailOtpTrusted] = useState(false);
  const [emailOtpSent, setEmailOtpSent] = useState(false);
  const [emailOtpSending, setEmailOtpSending] = useState(false);
  const [emailOtpVerifying, setEmailOtpVerifying] = useState(false);
  const [emailOtpVerified, setEmailOtpVerified] = useState(false);
  const [emailOtpValue, setEmailOtpValue] = useState('');
  const [emailOtpError, setEmailOtpError] = useState<string | null>(null);
  const [emailOtpMessage, setEmailOtpMessage] = useState<string | null>(null);
  const [emailResendCooldown, setEmailResendCooldown] = useState(0);

  // Submit
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [formError, setFormError] = useState<string | null>(null);

  // Step wizard (now driving the modal on every viewport — see the
  // Phase 4 doc comment above STEP_LABELS).
  const [step, setStep] = useState(draft?.step ?? 0);

  // Set right before the post-submit navigate() call so the nav-blocker
  // below never mistakes "booking just succeeded, navigating to the
  // confirmation page" for "user is trying to leave and lose progress".
  const bookingCompletedRef = useRef(false);

  // Booking-submitted success confirmation (Fix #1) — the booking is
  // already created by the time this is shown; only the navigation to
  // the payment-proof step (ConfirmPage) waits on the user dismissing
  // it, via pendingConfirmNav holding where to go next.
  const [bookingSuccessOpen, setBookingSuccessOpen] = useState(false);
  const [pendingConfirmNav, setPendingConfirmNav] = useState<{ url: string; phone: string } | null>(null);

  function proceedToConfirm() {
    if (!pendingConfirmNav) return;
    setBookingSuccessOpen(false);
    navigate(pendingConfirmNav.url, { state: { phone: pendingConfirmNav.phone } });
  }

  function loadReference() {
    setRefLoading(true);
    setRefError(null);
    // Maps config is fetched independently of cities/vehicles and never
    // blocks the booking form from loading/working — if it fails or no
    // key is configured, address fields just fall back to plain text
    // (see LocationPicker), instead of surfacing as a form-load error.
    getMapsConfig()
      .then((cfg) => setMapsApiKey(cfg.google_maps_key))
      .catch(() => setMapsApiKey(null));

    Promise.all([getCities('origin'), getCities('destination'), getVehicles()])
      .then(([origins, destinations, v]) => {
        setOriginCities(origins);
        setDestinationCities(destinations);
        setVehicles(v);
      })
      .catch((err) =>
        setRefError(err instanceof ApiError ? err.message : 'Could not load booking options. Please try again.')
      )
      .finally(() => setRefLoading(false));
  }

  useEffect(loadReference, []);

  // Countdown for resend
  useEffect(() => {
    if (resendCooldown <= 0) return;
    const t = setInterval(() => setResendCooldown((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [resendCooldown]);

  useEffect(() => {
    if (emailResendCooldown <= 0) return;
    const t = setInterval(() => setEmailResendCooldown((s) => Math.max(0, s - 1)), 1000);
    return () => clearInterval(t);
  }, [emailResendCooldown]);

  // Reset OTP trust/state whenever phone changes
  useEffect(() => {
    setOtpTrusted(false);
    setOtpSent(false);
    setOtpVerified(false);
    setOtpValue('');
    setOtpError(null);
    setOtpMessage(null);
  }, [phone]);

  // Reset email OTP trust/state whenever email changes — independent of
  // the phone effect above, since the two channels verify independently.
  useEffect(() => {
    setEmailOtpTrusted(false);
    setEmailOtpSent(false);
    setEmailOtpVerified(false);
    setEmailOtpValue('');
    setEmailOtpError(null);
    setEmailOtpMessage(null);
  }, [email]);

  const selectableVehicles = vehicles ?? [];

  function fareRequestFor(vId: number) {
    return {
      trip_type: tripType,
      pickup_city: pickupCity,
      drop_city: tripType === 'local' ? pickupCity : dropCity,
      vehicle_type_id: vId,
      journey_date: journeyDate,
      journey_time: journeyTime,
      distance_km: 0,
      duration_minutes: 0,
      hours_required: hoursRequired,
      return_date: returnDate,
      passengers,
      promo_code: promoCode,
    };
  }

  function fetchFareFor(vId: number) {
    if (!pickupCity || (tripType !== 'local' && !dropCity)) return;
    setFares((prev) => ({ ...prev, [vId]: 'loading' }));
    getFare(fareRequestFor(vId))
      .then((res) => setFares((prev) => ({ ...prev, [vId]: res })))
      .catch(() => setFares((prev) => ({ ...prev, [vId]: 'error' })));
  }

  // Re-fetch fares for all vehicles whenever trip parameters change.
  useEffect(() => {
    if (!vehicles || vehicles.length === 0) return;
    if (!pickupCity || (tripType !== 'local' && !dropCity)) return;
    const t = setTimeout(() => {
      vehicles.forEach((v) => fetchFareFor(v.id));
    }, 350);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [vehicles, tripType, pickupCity, dropCity, journeyDate, journeyTime, hoursRequired, returnDate, passengers, promoCode]);

  // Looked up so the pickup/drop map can center on the chosen city
  // instead of defaulting to a country-wide view — pure lookups against
  // already-loaded reference data, not extra requests.
  const pickupCityInfo = originCities?.find((c) => c.name === pickupCity) ?? null;
  const dropCityInfo = destinationCities?.find((c) => c.name === dropCity) ?? null;

  const selectedFare = vehicleId ? fares[vehicleId] : undefined;
  const totalFare =
    selectedFare && typeof selectedFare === 'object' ? selectedFare.fare.total_fare : undefined;

  const tripDetailsValid = useMemo(() => {
    if (!pickupCity) return false;
    if (tripType !== 'local' && !dropCity) return false;
    if (tripType !== 'local' && pickupCity === dropCity) return false;
    if (!journeyDate || !journeyTime) return false;
    if (tripType === 'round_trip' && !returnDate) return false;
    if (tripType === 'local' && (!hoursRequired || hoursRequired < 1)) return false;
    return true;
  }, [pickupCity, dropCity, tripType, journeyDate, journeyTime, returnDate, hoursRequired]);

  const phoneDigitsValid = /^[0-9]{10,15}$/.test(phone.replace(/\D/g, ''));
  const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
  const contactValid = name.trim().length > 1 && phoneDigitsValid;
  // TRACE: phone field render → an inline error once the user has interacted with the field and left it invalid → string|null.
  //        Preconditions: none. Postconditions: pure derivation, no state of its own beyond phoneTouched.
  //        Edge cases: empty field after touch ("required"), non-empty but wrong length/non-digits ("valid mobile number").
  const phoneError = !phoneTouched
    ? null
    : phone.trim() === ''
      ? 'Phone number is required.'
      : !phoneDigitsValid
        ? 'Enter a valid mobile number (10 to 15 digits).'
        : null;

  // Passenger & Safety Information validation: total must be a sane
  // positive number, and male+female+children (each defaulting to 0 when
  // left blank) must not exceed it — "not exceed" rather than "must
  // equal" so a rider who only fills in what they know (e.g. just "2
  // female") isn't blocked for leaving the rest blank, while a
  // combination that's actually inconsistent (breakdown bigger than the
  // total) is still a clear, caught error.
  const passengerTotalNum = passengerTotal.trim() === '' ? NaN : Number(passengerTotal);
  const passengerMaleNum = passengerMale.trim() === '' ? 0 : Number(passengerMale);
  const passengerFemaleNum = passengerFemale.trim() === '' ? 0 : Number(passengerFemale);
  const passengerChildrenNum = passengerChildren.trim() === '' ? 0 : Number(passengerChildren);
  const passengerTotalValid = Number.isFinite(passengerTotalNum) && passengerTotalNum >= 1 && passengerTotalNum <= 50;
  const passengerBreakdownValid =
    Number.isFinite(passengerMaleNum) &&
    passengerMaleNum >= 0 &&
    Number.isFinite(passengerFemaleNum) &&
    passengerFemaleNum >= 0 &&
    Number.isFinite(passengerChildrenNum) &&
    passengerChildrenNum >= 0 &&
    (!passengerTotalValid || passengerMaleNum + passengerFemaleNum + passengerChildrenNum <= passengerTotalNum);
  const passengerSafetyValid = passengerTotalValid && passengerBreakdownValid;
  const passengerSafetyError = !passengerTotalValid
    ? 'Enter a valid total number of passengers (1 to 50).'
    : !passengerBreakdownValid
      ? 'Male, female and children counts cannot add up to more than the total passengers.'
      : null;

  // Whether the mobile wizard may advance past each step — reuses the
  // exact same validity booleans the submit handler already checks, so
  // the wizard can never let mobile users reach a step the desktop form
  // would also reject on submit.
  // Root-cause fix: this used to be a bare `otpVerified`, so the wizard
  // (and the submit handler below) always demanded a verified OTP even
  // when the admin has "Require OTP to confirm booking" turned off —
  // otp_enabled now comes from the branding payload the app already
  // loads on every page (see includes/branding.php's ridego_branding_public()),
  // the same setting the backend now actually checks (ridego_booking_requires_otp()
  // in includes/helpers.php), so the two sides agree.
  const otpRequired = brand().otp_enabled;
  // Independent Email OTP Verification toggle — read separately from the
  // phone one, so the wizard's OTP step reflects whichever combination of
  // the two admin settings is currently on (see brand.ts/branding.php).
  const emailOtpRequired = brand().email_otp_enabled;
  const stepValid = [
    tripDetailsValid,
    Boolean(vehicleId),
    true,
    contactValid && (!emailOtpRequired || emailValid),
    passengerSafetyValid,
    (otpRequired ? otpVerified : true) && (emailOtpRequired ? emailOtpVerified : true),
  ];

  // Now applies on every viewport — the modal shows one step at a time
  // everywhere (there's no more separate "desktop shows everything at
  // once" mode; see the Phase 4 doc comment above STEP_LABELS).
  function stepSectionClass(i: number) {
    return step === i ? 'block' : 'hidden';
  }

  // Whether the user has entered anything worth warning about before
  // discarding — closing an untouched modal should just close it.
  const hasProgress = Boolean(
    pickupCity ||
      dropCity ||
      pickupLocation.address ||
      dropLocation.address ||
      vehicleId ||
      promoCode ||
      (name && name !== (user?.name ?? '')) ||
      (phone && phone !== (user?.phone ?? '')) ||
      altPhone ||
      otpSent ||
      emailOtpSent
  );

  // Keep the persisted draft in sync with the live form so a refresh or
  // remount (see loadBookingDraft's doc comment above) resumes exactly
  // here. Deliberately excludes OTP/submission state — see that comment
  // for why those must always be re-established live. Runs after every
  // relevant field changes; a plain effect (no debounce) is fine here
  // since sessionStorage writes are synchronous and local, and the
  // fields already share timers with the fare-refetch effect above.
  useEffect(() => {
    if (bookingCompletedRef.current) return;
    if (!hasProgress) {
      clearBookingDraft();
      return;
    }
    saveBookingDraft({
      step,
      tripType,
      pickupCity,
      pickupLocation,
      dropCity,
      dropLocation,
      journeyDate,
      journeyTime,
      returnDate,
      returnTime,
      hoursRequired,
      passengers,
      luggageCount,
      vehicleId,
      promoCode,
      paymentMethod,
      name,
      phone,
      email,
      altPhone,
      passengerTotal,
      passengerMale,
      passengerFemale,
      passengerChildren,
      passengerNotes,
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    step,
    tripType,
    pickupCity,
    pickupLocation,
    dropCity,
    dropLocation,
    journeyDate,
    journeyTime,
    returnDate,
    returnTime,
    hoursRequired,
    passengers,
    luggageCount,
    vehicleId,
    promoCode,
    paymentMethod,
    name,
    phone,
    email,
    altPhone,
    passengerTotal,
    passengerMale,
    passengerFemale,
    passengerChildren,
    passengerNotes,
    hasProgress,
  ]);

  // Single mechanism for every way the modal can be dismissed — the
  // header's close (X) button, a backdrop click on desktop, the
  // browser/device back gesture, and any other in-app navigation away
  // from this page (both go through react-router) are all caught here.
  // Only once there's real progress to lose; a booking that just
  // succeeded is excluded via bookingCompletedRef so the confirm-page
  // redirect itself is never blocked.
  const blocker = useBlocker(
    ({ currentLocation, nextLocation }) =>
      !embedded && hasProgress && !bookingCompletedRef.current && currentLocation.pathname !== nextLocation.pathname
  );

  function requestClose() {
    if (embedded) {
      onEmbeddedClose?.();
      return;
    }
    // location.key is 'default' only for the very first entry in this
    // browser session's history (i.e. there's nothing to go back to,
    // e.g. someone opened /app/book directly) — fall back to the home
    // tab instead of navigating past the app's own history.
    if (location.key && location.key !== 'default') {
      navigate(-1);
    } else {
      navigate('/');
    }
  }

  // On mobile the page itself never scrolls (BookingModalShell's body is
  // its own independent scroll container), so scrolling `window` on step
  // change — which worked when the wizard was inline on the page — would
  // now do nothing. On desktop there's no step wizard at all (the whole
  // form is always on screen), so this ref is only ever attached inside
  // the mobile modal branch.
  const modalBodyRef = useRef<HTMLDivElement>(null);

  function scrollStepIntoView() {
    if (modalBodyRef.current) {
      modalBodyRef.current.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  function goNext() {
    if (!stepValid[step]) return;
    setStep((s) => Math.min(STEP_LABELS.length - 1, s + 1));
    scrollStepIntoView();
  }

  function goBack() {
    setStep((s) => Math.max(0, s - 1));
    scrollStepIntoView();
  }

  async function handleSendOtp() {
    setOtpError(null);
    setOtpMessage(null);
    if (!contactValid) {
      setPhoneTouched(true);
      setOtpError('Enter a valid name and phone number first.');
      return;
    }
    setOtpSending(true);
    try {
      const res = await sendOtp({ phone, purpose: 'booking' });
      if (res.trusted) {
        setOtpTrusted(true);
        setOtpVerified(true);
        setOtpMessage(res.message);
      } else {
        setOtpSent(true);
        setOtpMessage(res.message || 'OTP sent. It should arrive within a minute.');
        setResendCooldown(30);
      }
    } catch (err) {
      if (err instanceof ApiError) {
        setOtpError(err.message);
        if (err.data?.retry_after) setResendCooldown(err.data.retry_after);
      } else {
        setOtpError('Could not send OTP. Please try again.');
      }
    } finally {
      setOtpSending(false);
    }
  }

  async function handleVerifyOtp() {
    setOtpError(null);
    if (otpValue.length !== 6) {
      setOtpError('Enter the 6-digit code.');
      return;
    }
    setOtpVerifying(true);
    try {
      await verifyOtp({ phone, otp: otpValue, purpose: 'booking' });
      setOtpVerified(true);
      setOtpMessage('Phone verified.');
    } catch (err) {
      if (err instanceof ApiError) {
        const remaining = err.data?.remaining_attempts;
        setOtpError(
          remaining != null ? `${err.message} (${remaining} attempt${remaining === 1 ? '' : 's'} left)` : err.message
        );
      } else {
        setOtpError('Could not verify OTP. Please try again.');
      }
    } finally {
      setOtpVerifying(false);
    }
  }

  async function handleSendEmailOtp() {
    setEmailOtpError(null);
    setEmailOtpMessage(null);
    if (!emailValid) {
      setEmailOtpError('Enter a valid email address first.');
      return;
    }
    setEmailOtpSending(true);
    try {
      const res = await sendOtp({ channel: 'email', email, purpose: 'booking' });
      if (res.trusted) {
        setEmailOtpTrusted(true);
        setEmailOtpVerified(true);
        setEmailOtpMessage(res.message);
      } else {
        setEmailOtpSent(true);
        setEmailOtpMessage(res.message || 'OTP sent. It should arrive within a minute.');
        setEmailResendCooldown(30);
      }
    } catch (err) {
      if (err instanceof ApiError) {
        setEmailOtpError(err.message);
        if (err.data?.retry_after) setEmailResendCooldown(err.data.retry_after);
      } else {
        setEmailOtpError('Could not send OTP. Please try again.');
      }
    } finally {
      setEmailOtpSending(false);
    }
  }

  async function handleVerifyEmailOtp() {
    setEmailOtpError(null);
    if (emailOtpValue.length !== 6) {
      setEmailOtpError('Enter the 6-digit code.');
      return;
    }
    setEmailOtpVerifying(true);
    try {
      await verifyOtp({ channel: 'email', email, otp: emailOtpValue, purpose: 'booking' });
      setEmailOtpVerified(true);
      setEmailOtpMessage('Email verified.');
    } catch (err) {
      if (err instanceof ApiError) {
        const remaining = err.data?.remaining_attempts;
        setEmailOtpError(
          remaining != null ? `${err.message} (${remaining} attempt${remaining === 1 ? '' : 's'} left)` : err.message
        );
      } else {
        setEmailOtpError('Could not verify OTP. Please try again.');
      }
    } finally {
      setEmailOtpVerifying(false);
    }
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setFormError(null);
    setSubmitError(null);

    if (!tripDetailsValid) {
      setFormError('Please complete the trip details above.');
      return;
    }
    if (!vehicleId) {
      setFormError('Please select a vehicle.');
      return;
    }
    if (!contactValid) {
      setFormError('Please provide a valid name and phone number.');
      return;
    }
    if (!passengerSafetyValid) {
      setFormError(passengerSafetyError || 'Please complete the passenger & safety information above.');
      return;
    }
    if (otpRequired && !otpVerified) {
      setFormError('Please verify your phone number with the OTP sent to it.');
      return;
    }
    if (emailOtpRequired && !emailValid) {
      setFormError('Please provide a valid email address.');
      return;
    }
    if (emailOtpRequired && !emailOtpVerified) {
      setFormError('Please verify your email address with the OTP sent to it.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await createBooking({
        client_name: name,
        client_phone: phone,
        client_email: email,
        client_alt_phone: altPhone,
        trip_type: tripType,
        pickup_city: pickupCity,
        pickup_address: pickupLocation.address,
        pickup_lat: pickupLocation.lat ?? 0,
        pickup_lng: pickupLocation.lng ?? 0,
        drop_city: tripType === 'local' ? pickupCity : dropCity,
        drop_address: dropLocation.address,
        drop_lat: dropLocation.lat ?? 0,
        drop_lng: dropLocation.lng ?? 0,
        journey_date: journeyDate,
        journey_time: journeyTime,
        return_date: returnDate,
        return_time: returnTime,
        hours_required: hoursRequired,
        passengers,
        luggage_count: luggageCount,
        vehicle_type_id: Number(vehicleId),
        special_requests: '',
        flight_number: '',
        corporate_company: '',
        corporate_gst: '',
        corporate_emp_id: '',
        promo_code: promoCode,
        payment_method: paymentMethod,
        distance_km: 0,
        duration_minutes: 0,
        passenger_total: passengerTotalNum,
        passenger_male: passengerMaleNum,
        passenger_female: passengerFemaleNum,
        passenger_children: passengerChildrenNum,
        passenger_notes: passengerNotes,
        otp_value: !otpRequired || otpTrusted ? undefined : otpValue,
        email_otp_value: !emailOtpRequired || emailOtpTrusted ? undefined : emailOtpValue,
      });

      const qs = new URLSearchParams({ booking: res.booking_number, phone });
      if (res.promo_adjusted) {
        qs.set('promo_adjusted', '1');
        if (res.promo_adjusted_reason) qs.set('promo_reason', res.promo_adjusted_reason);
      }
      bookingCompletedRef.current = true;
      clearBookingDraft();
      setPendingConfirmNav({ url: `/app/confirm?${qs.toString()}`, phone });
      setBookingSuccessOpen(true);
    } catch (err) {
      if (err instanceof ApiError) {
        if (err.data?.need_otp) {
          setOtpVerified(false);
          setOtpError(err.message);
          setFormError('Your phone needs to be verified again before this booking can be confirmed.');
        } else if (err.data?.need_email_otp) {
          setEmailOtpVerified(false);
          setEmailOtpError(err.message);
          setFormError('Your email needs to be verified again before this booking can be confirmed.');
        } else {
          setSubmitError(err.message);
        }
      } else {
        setSubmitError('Could not create your booking. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  }

  // The actual field markup for every step — identical whether it ends
  // up inside the desktop single-scroll form or the mobile modal's
  // scrollable body. Only the chrome around it (page header vs. modal
  // header/progress bar, inline submit vs. sticky modal footer) differs
  // between the two render paths below.
  const stepBody = (
    <>
      {/* Trip type */}
          <section className={stepSectionClass(0)}>
            <div className="flex gap-1 overflow-x-auto rounded-lg bg-ink-50 p-1" role="tablist" aria-label="Trip type">
              {TRIP_TYPES.map((t) => (
                <button
                  key={t.value}
                  type="button"
                  role="tab"
                  aria-selected={tripType === t.value}
                  onClick={() => {
                    setTripType(t.value);
                    setStep(0);
                  }}
                  className={`flex-1 shrink-0 rounded-md px-3 py-2 text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 ${
                    tripType === t.value ? 'bg-white text-brand-700 shadow-xs' : 'text-ink-500 hover:text-ink-800'
                  }`}
                >
                  {t.label}
                </button>
              ))}
            </div>
          </section>

          {/* Trip details */}
          <section className={`rounded-lg bg-white p-5 shadow-xs ring-1 ring-inset ring-ink-100 ${stepSectionClass(0)}`}>
            <h2 className="text-base font-semibold text-ink-900">Trip details</h2>
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="pickup-city" className={labelClasses}>
                  Pickup city
                </label>
                <select
                  id="pickup-city"
                  value={pickupCity}
                  onChange={(e) => setPickupCity(e.target.value)}
                  className={`mt-1.5 ${inputClasses}`}
                >
                  <option value="">Select city</option>
                  {originCities?.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
              {tripType !== 'local' && (
                <div>
                  <label htmlFor="drop-city" className={labelClasses}>
                    Drop city
                  </label>
                  <select
                    id="drop-city"
                    value={dropCity}
                    onChange={(e) => setDropCity(e.target.value)}
                    className={`mt-1.5 ${inputClasses}`}
                  >
                    <option value="">Select city</option>
                    {destinationCities?.map((c) => (
                      <option key={c.id} value={c.name}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                </div>
              )}

              <LocationPicker
                id="pickup-address"
                label="Pickup address (optional)"
                value={pickupLocation}
                onChange={setPickupLocation}
                apiKey={mapsApiKey}
                placeholder="e.g. Terminal 2, Airport Road"
                cityBias={pickupCityInfo && pickupCityInfo.lat != null && pickupCityInfo.lng != null ? { lat: pickupCityInfo.lat, lng: pickupCityInfo.lng } : null}
              />
              {tripType !== 'local' && (
                <LocationPicker
                  id="drop-address"
                  label="Drop address (optional)"
                  value={dropLocation}
                  onChange={setDropLocation}
                  apiKey={mapsApiKey}
                  cityBias={dropCityInfo && dropCityInfo.lat != null && dropCityInfo.lng != null ? { lat: dropCityInfo.lat, lng: dropCityInfo.lng } : null}
                />
              )}

              <div>
                <label htmlFor="journey-date" className={labelClasses}>
                  Journey date
                </label>
                <input
                  id="journey-date"
                  type="date"
                  min={todayStr()}
                  value={journeyDate}
                  onChange={(e) => setJourneyDate(e.target.value)}
                  className={`mt-1.5 ${inputClasses}`}
                />
              </div>
              <div>
                <label htmlFor="journey-time" className={labelClasses}>
                  Journey time
                </label>
                <input
                  id="journey-time"
                  type="time"
                  value={journeyTime}
                  onChange={(e) => setJourneyTime(e.target.value)}
                  className={`mt-1.5 ${inputClasses}`}
                />
              </div>

              {tripType === 'round_trip' && (
                <>
                  <div>
                    <label htmlFor="return-date" className={labelClasses}>
                      Return date
                    </label>
                    <input
                      id="return-date"
                      type="date"
                      min={journeyDate || todayStr()}
                      value={returnDate}
                      onChange={(e) => setReturnDate(e.target.value)}
                      className={`mt-1.5 ${inputClasses}`}
                    />
                  </div>
                  <div>
                    <label htmlFor="return-time" className={labelClasses}>
                      Return time
                    </label>
                    <input
                      id="return-time"
                      type="time"
                      value={returnTime}
                      onChange={(e) => setReturnTime(e.target.value)}
                      className={`mt-1.5 ${inputClasses}`}
                    />
                  </div>
                </>
              )}

              {tripType === 'local' && (
                <div>
                  <label htmlFor="hours-required" className={labelClasses}>
                    Hours required
                  </label>
                  <input
                    id="hours-required"
                    type="number"
                    min={1}
                    max={24}
                    value={hoursRequired}
                    onChange={(e) => setHoursRequired(Number(e.target.value))}
                    className={`mt-1.5 ${inputClasses}`}
                  />
                </div>
              )}

              <div>
                <label htmlFor="passengers" className={labelClasses}>
                  Passengers
                </label>
                <input
                  id="passengers"
                  type="number"
                  min={1}
                  max={50}
                  value={passengers}
                  onChange={(e) => setPassengers(Number(e.target.value))}
                  className={`mt-1.5 ${inputClasses}`}
                />
              </div>
              <div>
                <label htmlFor="luggage" className={labelClasses}>
                  Luggage (bags)
                </label>
                <input
                  id="luggage"
                  type="number"
                  min={0}
                  value={luggageCount}
                  onChange={(e) => setLuggageCount(Number(e.target.value))}
                  className={`mt-1.5 ${inputClasses}`}
                />
              </div>
            </div>
          </section>

          {/* Vehicle selection */}
          <section className={`rounded-lg bg-white p-5 shadow-xs ring-1 ring-inset ring-ink-100 ${stepSectionClass(1)}`}>
            <h2 className="text-base font-semibold text-ink-900">Choose a vehicle</h2>
            {!tripDetailsValid && (
              <p className="mt-2 text-sm text-ink-500">Complete the trip details above to see live fares.</p>
            )}
            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {selectableVehicles.length === 0 && <SkeletonCard />}
              {selectableVehicles.map((v) => {
                const fareState = fares[v.id];
                const selected = vehicleId === v.id;
                return (
                  <button
                    key={v.id}
                    type="button"
                    disabled={!tripDetailsValid}
                    onClick={() => setVehicleId(v.id)}
                    className={`flex items-center gap-3 rounded-xl border p-4 text-left transition disabled:cursor-not-allowed disabled:opacity-50 ${
                      selected ? 'border-brand-500 bg-brand-50 ring-2 ring-brand-500/30' : 'border-ink-100 hover:border-ink-200'
                    }`}
                  >
                    <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-lg bg-ink-100">
                      {v.image_url ? (
                        <img src={v.image_url} alt="" className="h-full w-full rounded-lg object-cover" />
                      ) : (
                        <svg className="h-7 w-7 text-ink-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
                          <path strokeLinecap="round" strokeLinejoin="round" d="M8 17l4-11 4 11M9.5 13h5M3 21h18" />
                        </svg>
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-ink-900">{v.name}</p>
                      <p className="text-xs text-ink-500">{v.seating_capacity} seats</p>
                      <p className="mt-1 text-sm font-semibold text-ink-800">
                        {fareState === 'loading' && <Skeleton className="h-4 w-16" />}
                        {fareState === 'error' && <span className="text-danger-600">Fare unavailable</span>}
                        {fareState && typeof fareState === 'object' && (
                          <>
                            {fareState.sym}
                            {fareState.fare.total_fare.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                          </>
                        )}
                        {!fareState && '—'}
                      </p>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* Promo & payment */}
          <section className={`rounded-lg bg-white p-5 shadow-xs ring-1 ring-inset ring-ink-100 ${stepSectionClass(2)}`}>
            <h2 className="text-base font-semibold text-ink-900">Promo & booking amount</h2>
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="promo" className={labelClasses}>
                  Promo code (optional)
                </label>
                <input
                  id="promo"
                  value={promoCode}
                  onChange={(e) => setPromoCode(e.target.value.toUpperCase())}
                  className={`mt-1.5 ${inputClasses}`}
                  placeholder="e.g. WELCOME50"
                />
                {selectedFare && typeof selectedFare === 'object' && selectedFare.promo_error && (
                  <p className="mt-1 text-xs text-danger-600">{selectedFare.promo_error}</p>
                )}
              </div>
              {totalFare != null && (
                <div className="flex flex-col justify-end">
                  <p className="text-xs font-medium uppercase tracking-wide text-ink-400">Estimated ride fare</p>
                  <p className="text-2xl font-bold text-ink-900">₹{totalFare.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</p>
                </div>
              )}
            </div>

            {selectedFare && typeof selectedFare === 'object' && (
              <div className="mt-3 rounded-lg border border-brand-100 bg-brand-50 p-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-brand-800">
                    {selectedFare.fare.token_label || 'Booking amount'} — pay to {brand().name} now
                  </span>
                  <span className="font-semibold text-brand-800">
                    ₹{(selectedFare.fare.token_amount ?? 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                  </span>
                </div>
                <div className="mt-1 flex items-center justify-between text-ink-600">
                  <span>Remaining ride fare — payable directly to your vendor/driver</span>
                  <span>₹{(selectedFare.fare.remaining_amount ?? 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                </div>
                {(selectedFare.fare.token_amount ?? 0) <= 0 && (
                  <p className="mt-1.5 text-xs text-ink-600">No booking amount is due for this ride, so nothing is paid to {brand().name} online.</p>
                )}
                {selectedFare.fare.token_instructions && (
                  <p className="mt-1.5 text-xs text-ink-600">{selectedFare.fare.token_instructions}</p>
                )}
                {selectedFare.fare.disclaimer && (
                  <p className="mt-1.5 text-xs text-ink-600">{selectedFare.fare.disclaimer}</p>
                )}
              </div>
            )}

            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {PAYMENT_METHODS.map((pm) => (
                <label
                  key={pm.value}
                  className={`cursor-pointer rounded-lg border p-3.5 transition ${
                    paymentMethod === pm.value ? 'border-brand-500 bg-brand-50' : 'border-ink-200 hover:bg-ink-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="payment-method"
                    value={pm.value}
                    checked={paymentMethod === pm.value}
                    onChange={() => setPaymentMethod(pm.value)}
                    className="sr-only"
                  />
                  <span className="block text-sm font-semibold text-ink-900">{pm.label}</span>
                  <span className="block text-xs text-ink-500">{pm.description}</span>
                </label>
              ))}
            </div>
          </section>

          {/* Contact details */}
          <section className={`rounded-lg bg-white p-5 shadow-xs ring-1 ring-inset ring-ink-100 ${stepSectionClass(3)}`}>
            <h2 className="text-base font-semibold text-ink-900">Contact details</h2>
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="client-name" className={labelClasses}>
                  Full name
                </label>
                <input
                  id="client-name"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  autoComplete="name"
                  className={`mt-1.5 ${inputClasses}`}
                />
              </div>
              <div>
                <label htmlFor="client-phone" className={labelClasses}>
                  Phone number
                </label>
                <input
                  id="client-phone"
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  onBlur={() => setPhoneTouched(true)}
                  autoComplete="tel"
                  aria-invalid={phoneError ? true : undefined}
                  aria-describedby={phoneError ? 'client-phone-error' : undefined}
                  className={`mt-1.5 ${inputClasses} ${phoneError ? 'border-danger-500 focus:border-danger-500 focus:ring-danger-500/30' : ''}`}
                />
                {phoneError && (
                  <p id="client-phone-error" role="alert" className="mt-1 text-xs font-medium text-danger-600">
                    {phoneError}
                  </p>
                )}
              </div>
              <div>
                <label htmlFor="client-email" className={labelClasses}>
                  Email (optional)
                </label>
                <input
                  id="client-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                  className={`mt-1.5 ${inputClasses}`}
                />
              </div>
              <div>
                <label htmlFor="alt-phone" className={labelClasses}>
                  Alternate phone (optional)
                </label>
                <input
                  id="alt-phone"
                  type="tel"
                  value={altPhone}
                  onChange={(e) => setAltPhone(e.target.value)}
                  className={`mt-1.5 ${inputClasses}`}
                />
              </div>
            </div>
          </section>

          {/* Passenger & Safety Information — see the doc comment above
              STEP_LABELS for why this sits here, right after Contact and
              before Verify. */}
          <section className={`rounded-lg bg-white p-5 shadow-xs ring-1 ring-inset ring-ink-100 ${stepSectionClass(SAFETY_STEP)}`}>
            <h2 className="text-base font-semibold text-ink-900">Passenger & safety information</h2>
            <p className="mt-1 text-sm text-ink-500">
              This helps us match you with the right driver and vehicle for a safe, comfortable ride — it's never shared beyond what's needed for that.
            </p>
            <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
              <div>
                <label htmlFor="passenger-total" className={labelClasses}>
                  Total passengers
                </label>
                <input
                  id="passenger-total"
                  type="number"
                  inputMode="numeric"
                  min={1}
                  max={50}
                  value={passengerTotal}
                  onChange={(e) => setPassengerTotal(e.target.value)}
                  className={`mt-1.5 ${inputClasses}`}
                />
              </div>
              <div />
              <div>
                <label htmlFor="passenger-male" className={labelClasses}>
                  Male passengers
                </label>
                <input
                  id="passenger-male"
                  type="number"
                  inputMode="numeric"
                  min={0}
                  max={50}
                  value={passengerMale}
                  onChange={(e) => setPassengerMale(e.target.value)}
                  className={`mt-1.5 ${inputClasses}`}
                />
              </div>
              <div>
                <label htmlFor="passenger-female" className={labelClasses}>
                  Female passengers
                </label>
                <input
                  id="passenger-female"
                  type="number"
                  inputMode="numeric"
                  min={0}
                  max={50}
                  value={passengerFemale}
                  onChange={(e) => setPassengerFemale(e.target.value)}
                  className={`mt-1.5 ${inputClasses}`}
                />
              </div>
              <div>
                <label htmlFor="passenger-children" className={labelClasses}>
                  Children
                </label>
                <input
                  id="passenger-children"
                  type="number"
                  inputMode="numeric"
                  min={0}
                  max={50}
                  value={passengerChildren}
                  onChange={(e) => setPassengerChildren(e.target.value)}
                  className={`mt-1.5 ${inputClasses}`}
                />
              </div>
              <div className="sm:col-span-2">
                <label htmlFor="passenger-notes" className={labelClasses}>
                  Anything else the driver/vendor should know? (optional)
                </label>
                <textarea
                  id="passenger-notes"
                  rows={3}
                  value={passengerNotes}
                  onChange={(e) => setPassengerNotes(e.target.value)}
                  placeholder="e.g. traveling with an infant, wheelchair access needed"
                  className={`mt-1.5 ${inputClasses}`}
                />
              </div>
            </div>
            {passengerSafetyError && (passengerTotal.trim() !== '' || passengerMale.trim() !== '' || passengerFemale.trim() !== '' || passengerChildren.trim() !== '') && (
              <p role="alert" className="mt-3 text-xs font-medium text-danger-600">
                {passengerSafetyError}
              </p>
            )}
          </section>

          {/* OTP verification — phone and email are independent admin toggles
              (otp_enabled / email_otp_enabled), so this step shows whichever
              of the two blocks below is actually required: neither (step is
              skipped entirely via the message below), either one alone, or
              both, each with its own code entry and its own "Confirm
              booking" gate (see stepValid above). */}
          <section className={`rounded-lg bg-white p-5 shadow-xs ring-1 ring-inset ring-ink-100 ${stepSectionClass(SAFETY_STEP + 1)}`}>
            <h2 className="text-base font-semibold text-ink-900">Verify your details</h2>
            {!otpRequired && !emailOtpRequired ? (
              <p className="mt-1 text-sm text-ink-500">
                Verification isn't required for this booking. You're all set — continue to place your booking.
              </p>
            ) : (
              <div className="mt-4 space-y-6">
                {otpRequired && (
                  <div className={emailOtpRequired ? 'border-b border-ink-100 pb-6' : ''}>
                    <h3 className="text-sm font-semibold text-ink-800">Phone number</h3>
                    <p className="mt-1 text-sm text-ink-500">
                      We'll send a one-time code to confirm your number before your booking is placed.
                    </p>

                    {otpError && (
                      <div role="alert" className="mt-3 rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
                        {otpError}
                      </div>
                    )}
                    {otpMessage && !otpError && (
                      <div role="status" className="mt-3 rounded-lg border border-success-500/30 bg-success-50 px-3 py-2 text-sm text-success-600">
                        {otpMessage}
                      </div>
                    )}

                    {otpVerified ? (
                      <div className="mt-3 flex items-center gap-2 text-sm font-medium text-success-600">
                        <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                          <path fillRule="evenodd" d="M16.704 5.29a1 1 0 010 1.42l-7.25 7.25a1 1 0 01-1.42 0l-3.25-3.25a1 1 0 111.42-1.42l2.54 2.54 6.54-6.54a1 1 0 011.42 0z" clipRule="evenodd" />
                        </svg>
                        Phone verified
                      </div>
                    ) : (
                      <div className="mt-3">
                        {!otpSent ? (
                          <Button type="button" onClick={handleSendOtp} loading={otpSending} disabled={!contactValid}>
                            Send OTP
                          </Button>
                        ) : (
                          <div className="space-y-3">
                            <OtpInput value={otpValue} onChange={setOtpValue} disabled={otpVerifying} />
                            <div className="flex flex-wrap items-center gap-3">
                              <Button type="button" onClick={handleVerifyOtp} loading={otpVerifying} disabled={otpValue.length !== 6}>
                                Verify code
                              </Button>
                              <button
                                type="button"
                                onClick={handleSendOtp}
                                disabled={resendCooldown > 0 || otpSending}
                                className="text-sm font-medium text-brand-600 hover:text-brand-700 disabled:cursor-not-allowed disabled:text-ink-400"
                              >
                                {resendCooldown > 0 ? `Resend code in ${resendCooldown}s` : 'Resend code'}
                              </button>
                            </div>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                )}

                {emailOtpRequired && (
                  <div>
                    <h3 className="text-sm font-semibold text-ink-800">Email address</h3>
                    <p className="mt-1 text-sm text-ink-500">
                      We'll send a one-time code to confirm your email address before your booking is placed.
                    </p>

                    {!emailValid ? (
                      <p className="mt-3 text-sm text-ink-500">Enter a valid email address above to continue.</p>
                    ) : (
                      <>
                        {emailOtpError && (
                          <div role="alert" className="mt-3 rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
                            {emailOtpError}
                          </div>
                        )}
                        {emailOtpMessage && !emailOtpError && (
                          <div role="status" className="mt-3 rounded-lg border border-success-500/30 bg-success-50 px-3 py-2 text-sm text-success-600">
                            {emailOtpMessage}
                          </div>
                        )}

                        {emailOtpVerified ? (
                          <div className="mt-3 flex items-center gap-2 text-sm font-medium text-success-600">
                            <svg className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                              <path fillRule="evenodd" d="M16.704 5.29a1 1 0 010 1.42l-7.25 7.25a1 1 0 01-1.42 0l-3.25-3.25a1 1 0 111.42-1.42l2.54 2.54 6.54-6.54a1 1 0 011.42 0z" clipRule="evenodd" />
                            </svg>
                            Email verified
                          </div>
                        ) : (
                          <div className="mt-3">
                            {!emailOtpSent ? (
                              <Button type="button" onClick={handleSendEmailOtp} loading={emailOtpSending} disabled={!emailValid}>
                                Send OTP
                              </Button>
                            ) : (
                              <div className="space-y-3">
                                <OtpInput value={emailOtpValue} onChange={setEmailOtpValue} disabled={emailOtpVerifying} />
                                <div className="flex flex-wrap items-center gap-3">
                                  <Button type="button" onClick={handleVerifyEmailOtp} loading={emailOtpVerifying} disabled={emailOtpValue.length !== 6}>
                                    Verify code
                                  </Button>
                                  <button
                                    type="button"
                                    onClick={handleSendEmailOtp}
                                    disabled={emailResendCooldown > 0 || emailOtpSending}
                                    className="text-sm font-medium text-brand-600 hover:text-brand-700 disabled:cursor-not-allowed disabled:text-ink-400"
                                  >
                                    {emailResendCooldown > 0 ? `Resend code in ${emailResendCooldown}s` : 'Resend code'}
                                  </button>
                                </div>
                              </div>
                            )}
                          </div>
                        )}
                      </>
                    )}
                  </div>
                )}
              </div>
            )}
          </section>

      <div className={stepSectionClass(SAFETY_STEP + 1)}>
        {formError && <ErrorBanner message={formError} />}
        {submitError && <ErrorBanner message={submitError} onRetry={() => setSubmitError(null)} />}
      </div>
    </>
  );

  const referenceLoadingBlock = refLoading && (
    <div className="mt-6 space-y-4">
      <Skeleton className="h-11 w-full rounded-lg" />
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
        <Skeleton className="h-11 w-full" />
        <Skeleton className="h-11 w-full" />
      </div>
    </div>
  );

  const referenceErrorBlock = !refLoading && refError && <ErrorBanner message={refError} onRetry={loadReference} />;

  // The step wizard opens inside a modal on every viewport — full-screen
  // on mobile, a centered dialog on desktop (BookingModalShell itself is
  // responsive; see its own doc comment). Same chrome, same step body,
  // on both.
  return (
    <>
      <BookingModalShell
        title="Book a ride"
        step={step}
        totalSteps={STEP_LABELS.length}
        stepLabel={STEP_LABELS[step]}
        onRequestClose={requestClose}
        bodyRef={modalBodyRef}
        reserveBottomNav={embedded}
        footer={
          !refLoading && !refError ? (
            <div className="flex items-center gap-3">
              {step > 0 && (
                <Button type="button" variant="secondary" onClick={goBack}>
                  Back
                </Button>
              )}
              {step < STEP_LABELS.length - 1 ? (
                /* Root-cause fix: this used to be a plain ternary with no
                   `key`, so React treated this "Next" button and the
                   "Confirm booking" button below as the SAME element at
                   the same tree position and patched one DOM node into
                   the other in place (mutating `type` from "button" to
                   "submit") whenever goNext() advanced onto the final
                   (Verify) step. That mutation happened synchronously
                   during the very click that was only meant to advance
                   the step — and because the browser resolves a
                   <button>'s click activation behavior against its
                   CURRENT type/form attributes at the end of the event's
                   dispatch (after React's synchronous commit), the
                   already-in-flight click ended up ALSO activating the
                   freshly-mutated submit button, submitting the booking
                   form one click early. Every transition onto the Verify
                   step triggered this phantom submit; it was invisible
                   whenever otpRequired/emailOtpRequired still blocked
                   handleSubmit (it just set a formError no one saw,
                   since the very next render already showed the Verify
                   step normally), but with BOTH OTP toggles off there is
                   nothing to block it, so the booking was created and
                   the app navigated to /app/confirm immediately — the
                   Verify step's "verification isn't required" screen,
                   and the deliberate extra click to actually confirm,
                   were skipped entirely. Distinct `key`s force React to
                   unmount the old node and mount a genuinely new one
                   instead of mutating in place, so a click can only ever
                   activate the button that was actually on screen when
                   the click began. */
                <Button key="next" type="button" fullWidth onClick={goNext} disabled={!stepValid[step]}>
                  Next
                </Button>
              ) : (
                <Button key="confirm" type="submit" form="booking-form" fullWidth loading={submitting}>
                  Confirm booking
                </Button>
              )}
            </div>
          ) : undefined
        }
      >
        {referenceLoadingBlock}
        {referenceErrorBlock}
        {!refLoading && !refError && (
          <form id="booking-form" onSubmit={handleSubmit} noValidate className="space-y-8">
            {stepBody}
          </form>
        )}
      </BookingModalShell>

      {/* Single confirmation for every way the modal can be dismissed
          with progress on the page — see the useBlocker call above. */}
      <ConfirmDialog
        open={blocker.state === 'blocked'}
        title="Discard this booking?"
        description="You'll lose the trip details you've entered so far if you leave now."
        confirmLabel="Discard"
        cancelLabel="Keep editing"
        confirmVariant="danger"
        onConfirm={() => {
          // Explicit discard — the user chose to lose this progress, so
          // a later reload of /app/book should not silently resurrect
          // the very draft they just discarded.
          clearBookingDraft();
          if (blocker.state === 'blocked') blocker.proceed();
        }}
        onCancel={() => blocker.state === 'blocked' && blocker.reset()}
      />

      <SuccessDialog
        open={bookingSuccessOpen}
        title="Booking request submitted!"
        description={
          <>
            Your booking request has been submitted successfully. Our team will proceed with your booking once the
            booking amount is paid — you'll do that on the next screen.
          </>
        }
        actionLabel="Continue to payment"
        onAction={proceedToConfirm}
      />
    </>
  );
}
