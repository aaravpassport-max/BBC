import { useEffect, useState } from 'react';
import { getHome, ApiError } from '../lib/api';
import type { HomeResponse } from '../types/api';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { Skeleton } from '../components/ui/Skeleton';
import { brand } from '../lib/brand';
import { DATA_CARD_CLASS } from '../components/ui/Zone';

interface FaqItem {
  question: string;
  answer: string;
}

interface FaqGroup {
  title: string;
  items: FaqItem[];
}

const FAQ_GROUPS: FaqGroup[] = [
  {
    title: 'Booking a ride',
    items: [
      {
        question: 'How do I book a ride?',
        answer:
          'Go to "Book a ride", enter your pickup and drop locations, choose a trip type (one-way, round trip or hourly rental), pick a date and time, and select a vehicle. You\'ll see an estimated fare and the booking amount to pay before you confirm; the vendor/driver bills you the final ride amount. Once you submit the booking, you\'ll get a booking number you can use to track or manage the trip at any time.',
      },
      {
        question: 'Do I need an account to book?',
        answer:
          'No. You can book as a guest using your name and phone number — you\'ll verify your phone with an OTP (one-time password) before the booking is confirmed. Creating an account is optional, but it lets you see all your trips together under "My Trips" and skip re-entering your details next time.',
      },
      {
        question: 'How does OTP verification work for guest bookings?',
        answer:
          'When you book without logging in, we send a one-time code by SMS to the phone number you provide, to confirm it\'s really yours and to protect you from someone else booking (or cancelling) a trip using your number. Enter the code on the booking screen to complete your booking. If you don\'t receive it, you can request the code again after a short wait.',
      },
    ],
  },
  {
    title: 'Payments',
    items: [
      {
        question: 'What payment methods are supported?',
        answer:
          brand().name + ' collects only a booking amount online, by UPI or bank transfer. After booking you\'ll see the payment details (UPI ID or bank account), and you submit your payment reference (UTR) and a screenshot as proof so our team can confirm it. The remaining ride fare, the final bill and any other applicable charges are paid directly to your vendor/driver, who issues your ride invoice.',
      },
      {
        question: 'When do I need to pay?',
        answer:
          'You pay the booking amount shown at checkout within the confirmation window on your booking screen to keep your booking. The rest of the ride fare is settled directly with your vendor/driver during or after the trip, in the way they accept.',
      },
      {
        question: 'What if my payment isn\'t recognized?',
        answer:
          'If your UPI or bank transfer proof is rejected, you\'ll see the reason on your booking status (for example, an amount or reference mismatch) and you can resubmit the correct proof. If you\'re unsure, contact support with your booking number and payment reference and we\'ll help sort it out.',
      },
    ],
  },
  {
    title: 'Tracking & managing your booking',
    items: [
      {
        question: 'How do I track my booking?',
        answer:
          'Use the "Track" page and enter your booking number (and phone number, if asked) to see live status, driver and vehicle details once assigned, and payment status — no account required.',
      },
      {
        question: 'How do I cancel a booking?',
        answer:
          'If you have an account, open "My Trips", find the booking and select "Cancel booking". You\'ll be asked for an optional reason, which helps us improve. Bookings that are already completed or already cancelled can\'t be cancelled again. Only the booking amount paid to ' + brand().name + ' can be refunded, and whether it is refundable depends on the cancellation policy: it is refunded if ' + brand().name + ' could not arrange your ride, and is non-refundable once a vendor/driver has been arranged. Anything agreed with your vendor/driver directly is settled with them.',
      },
      {
        question: 'Can I edit my booking after confirming it?',
        answer:
          'Trip details like route, date and vehicle can\'t be edited directly once a booking is placed. If your plans change, the safest options are to cancel and rebook, or contact support so we can help adjust the trip with your driver-partner where possible.',
      },
      {
        question: 'How do I rate my trip?',
        answer:
          'Once a trip is marked completed, open "My Trips" and you\'ll see a "Rate this trip" option on that booking. You can leave a star rating and an optional written review — this can only be submitted once per trip and helps other riders and keeps our driver-partner network accountable.',
      },
    ],
  },
  {
    title: 'Becoming a driver-partner',
    items: [
      {
        question: 'How do I become a vendor / driver-partner?',
        answer:
          'Select "Become a partner" (or register with the vendor option checked) to create a vendor profile. You\'ll then need to upload your KYC documents from the vendor KYC page for verification. Once approved, you\'ll start receiving ride leads matching your vehicle type and coverage area on your vendor dashboard, which you can accept to take on trips.',
      },
      {
        question: 'How do leads and my wallet work?',
        answer:
          'As a verified vendor, new ride leads appear on your dashboard with a countdown to accept them. Accepting a lead confirms the trip and the lead fee shown on it (calculated under the commercial terms you have accepted; see Commercial terms in your vendor menu). ' + brand().name + ' collects only the customer advance from the client; it is set against your lead fee and any balance of the lead fee is settled after the trip. You bill the client for the ride, collect the remaining amount directly and issue the ride invoice or receipt. You record what you collect on each trip so the client and ' + brand().name + ' can see the balance. If a client cancels after you were arranged, the advance they forfeited is either kept by ' + brand().name + ' as the lead fee or paid to you as compensation, depending on the situation; the decision is shown on the booking and in Settlements. Your dashboard also tracks your rating and total accepted leads.',
      },
    ],
  },
];

function FaqAccordionItem({ item, defaultOpen = false }: { item: FaqItem; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-ink-100 last:border-b-0">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="flex w-full items-center justify-between gap-4 py-4 text-left text-sm font-semibold text-ink-900 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 sm:text-base"
      >
        <span>{item.question}</span>
        <svg
          className={`h-5 w-5 shrink-0 text-ink-400 transition-transform ${open ? 'rotate-180' : ''}`}
          viewBox="0 0 20 20"
          fill="currentColor"
          aria-hidden="true"
        >
          <path fillRule="evenodd" d="M5.23 7.21a.75.75 0 011.06.02L10 11.168l3.71-3.938a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z" clipRule="evenodd" />
        </svg>
      </button>
      {open && <p className="pb-4 text-sm text-ink-600">{item.answer}</p>}
    </div>
  );
}

export function HelpPage() {
  const [data, setData] = useState<HomeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  function load() {
    setLoading(true);
    setError(null);
    getHome()
      .then(setData)
      .catch((err) => setError(err instanceof ApiError ? err.message : 'Could not load support details. Please try again.'))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-ink-900 sm:text-3xl">Help &amp; support</h1>
        <p className="text-sm text-ink-500">
          Answers to common questions about booking, payments, cancellations and driving with us.
        </p>
      </div>

      <div className={`mt-8 p-5 sm:p-6 ${DATA_CARD_CLASS}`}>
        <h2 className="text-lg font-semibold text-ink-900">Contact support</h2>
        <p className="mt-1 text-sm text-ink-500">
          Have an urgent issue with an active booking, or a question the FAQs below don't answer? Reach our team
          directly.
        </p>

        {loading && (
          <div className="mt-4 flex flex-col gap-2 sm:flex-row" aria-busy="true" aria-label="Loading contact details">
            <Skeleton className="h-10 w-40 rounded-lg" />
            <Skeleton className="h-10 w-44 rounded-lg" />
          </div>
        )}

        {!loading && error && (
          <div className="mt-4">
            <ErrorBanner message={error} onRetry={load} />
          </div>
        )}

        {!loading && !error && data && (
          <div className="mt-4 flex flex-col gap-2 sm:flex-row">
            {brand().support_phone && (
              <a
                href={`tel:${brand().support_phone}`}
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-ink-200 bg-white px-4 py-2.5 text-sm font-medium text-ink-800 shadow-xs transition hover:bg-ink-50"
              >
                <svg className="h-4 w-4 text-brand-600" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                  <path d="M2 3.5A1.5 1.5 0 013.5 2h1.148a1.5 1.5 0 011.465 1.175l.716 3.223a1.5 1.5 0 01-.836 1.66l-1.05.525a11.037 11.037 0 006.14 6.14l.525-1.05a1.5 1.5 0 011.66-.836l3.223.716A1.5 1.5 0 0118 15.352V16.5a1.5 1.5 0 01-1.5 1.5H15c-1.149 0-2.263-.15-3.326-.43A13.022 13.022 0 012.43 8.326 12.87 12.87 0 012 5V3.5z" />
                </svg>
                Call {brand().support_phone}
              </a>
            )}
            {brand().support_whatsapp && (
              <a
                href={`https://wa.me/${brand().support_whatsapp.replace(/[^\d]/g, '')}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-ink-200 bg-white px-4 py-2.5 text-sm font-medium text-ink-800 shadow-xs transition hover:bg-ink-50"
              >
                <svg className="h-4 w-4 text-success-600" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.45 1.32 4.95L2.05 22l5.25-1.38a9.9 9.9 0 004.74 1.2h.01c5.46 0 9.91-4.45 9.91-9.91C21.96 6.45 17.5 2 12.04 2zm5.83 14.1c-.24.68-1.4 1.32-1.93 1.4-.5.08-1.13.11-1.82-.11-.42-.13-.96-.31-1.65-.6-2.9-1.25-4.8-4.18-4.94-4.37-.15-.19-1.18-1.57-1.18-3 0-1.42.75-2.12 1.02-2.41.27-.29.58-.36.78-.36.19 0 .39 0 .56.01.18.01.42-.07.65.5.24.58.82 2 .89 2.14.07.15.12.32.02.51-.1.19-.15.31-.29.48-.15.17-.31.38-.44.5-.15.15-.3.31-.13.6.17.29.76 1.25 1.63 2.02 1.12.99 2.06 1.3 2.35 1.45.29.15.46.12.63-.07.17-.19.72-.84.91-1.13.19-.29.38-.24.63-.14.26.1 1.65.78 1.93.92.29.15.48.22.55.34.08.13.08.75-.16 1.43z" />
                </svg>
                WhatsApp {brand().support_whatsapp}
              </a>
            )}
            {brand().support_email && (
              <a
                href={`mailto:${brand().support_email}`}
                className="inline-flex items-center justify-center gap-2 rounded-lg border border-ink-200 bg-white px-4 py-2.5 text-sm font-medium text-ink-800 shadow-xs transition hover:bg-ink-50"
              >
                Email {brand().support_email}
              </a>
            )}
          </div>
        )}
        {brand().business_hours && <p className="mt-3 whitespace-pre-line text-sm text-ink-500">{brand().business_hours}</p>}
      </div>

      <div className="mt-10">
        {FAQ_GROUPS.map((group) => (
          <div key={group.title} className="mb-8">
            <h2 className="text-lg font-semibold text-ink-900">{group.title}</h2>
            <div className={`mt-2 px-4 sm:px-5 ${DATA_CARD_CLASS}`}>
              {group.items.map((item) => (
                <FaqAccordionItem key={item.question} item={item} />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
