import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getHome, getReviews, getPopularRoutes, getPartners, ApiError } from '../lib/api';
import type { HomeResponse, AppReview, PopularRoute, Partner } from '../types/api';
import { FareSearchWidget } from '../components/home/FareSearchWidget';
import { Skeleton, SkeletonCard } from '../components/ui/Skeleton';
import { ErrorBanner } from '../components/ui/ErrorBanner';
import { Button } from '../components/ui/Button';
import { brand, fitClass, heightStyle } from '../lib/brand';
import { useAuth } from '../context/AuthContext';
import { userKind } from '../lib/roles';
import { getClientHome, type ClientHomeResponse } from '../lib/api-client-dashboard';
import { Eyebrow, iconTileTone } from '../components/ui/Zone';

// ---------------------------------------------------------------------------
// Icons — small inline SVGs, matching the style already used across this app
// (no external icon package is installed).
// ---------------------------------------------------------------------------

function BadgeCheckIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 12l2 2 4-4" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 3l2.2 1.3 2.5.1 1.3 2.2 2.2 1.3-.1 2.5 1.3 2.2-1.3 2.2.1 2.5-2.2 1.3-1.3 2.2-2.5-.1L12 21l-2.2-1.3-2.5-.1-1.3-2.2-2.2-1.3.1-2.5L2.6 11.6 3.9 9.4l-.1-2.5 2.2-1.3L7.3 3.4l2.5.1L12 3z" />
    </svg>
  );
}
function MapPinIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 21s7-6.5 7-12a7 7 0 10-14 0c0 5.5 7 12 7 12z" />
      <circle cx="12" cy="9" r="2.5" />
    </svg>
  );
}
function LaptopIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <rect x="4" y="4" width="16" height="11" rx="1.5" />
      <path strokeLinecap="round" d="M2 19h20" />
    </svg>
  );
}
function CarIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 16l1.2-5.4A2 2 0 017.15 9h9.7a2 2 0 011.95 1.6L20 16" />
      <rect x="2.5" y="16" width="19" height="4" rx="1.5" />
      <circle cx="7" cy="20" r="1.5" />
      <circle cx="17" cy="20" r="1.5" />
    </svg>
  );
}
function UsersIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <circle cx="9" cy="8" r="3" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M3.5 19a5.5 5.5 0 0111 0" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M16 8.5a2.75 2.75 0 110 5.5M17.5 19a5 5 0 00-3.3-4.7" />
    </svg>
  );
}
function SearchIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <circle cx="11" cy="11" r="7" />
      <path strokeLinecap="round" d="M21 21l-4.3-4.3" />
    </svg>
  );
}
function ListIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" />
    </svg>
  );
}
function RouteIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <circle cx="5" cy="6" r="2" />
      <circle cx="19" cy="18" r="2" />
      <path strokeLinecap="round" d="M5 8v3a4 4 0 004 4h6a4 4 0 014 3" strokeDasharray="2 3" />
    </svg>
  );
}
function DocumentIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M7 3h7l4 4v13a1 1 0 01-1 1H7a1 1 0 01-1-1V4a1 1 0 011-1z" />
      <path strokeLinecap="round" d="M9 12h6M9 16h6" />
    </svg>
  );
}
function ChatIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 5h16v11H8l-4 4V5z" />
    </svg>
  );
}
function ArrowRightIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 12h16M13 5l7 7-7 7" />
    </svg>
  );
}
function ChevronDownIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M6 9l6 6 6-6" />
    </svg>
  );
}
function AirplaneIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 21l1.5-6 7-4-1-1.7-7 2-3-4.8-1.6.5 1.6 5-4 1-2-1.3-1.3.5 1.5 2.6 2.7.8z" />
    </svg>
  );
}
function BriefcaseIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <rect x="3" y="7" width="18" height="12" rx="1.5" />
      <path strokeLinecap="round" d="M8 7V5a1 1 0 011-1h6a1 1 0 011 1v2" />
    </svg>
  );
}
function GroupIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <circle cx="8" cy="8" r="2.5" />
      <circle cx="16" cy="8" r="2.5" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 19a5 5 0 0110 0M11 19a5 5 0 0110 0" />
    </svg>
  );
}
function RepeatIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 9a5 5 0 018-3.9M20 15a5 5 0 01-8 3.9M4 5v4h4M20 19v-4h-4" />
    </svg>
  );
}
function StarRow({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5 text-warning-500" aria-label={`${rating} out of 5 stars`}>
      {Array.from({ length: 5 }).map((_, i) => (
        <svg key={i} viewBox="0 0 20 20" fill={i < rating ? 'currentColor' : 'none'} stroke="currentColor" strokeWidth="1.2" className="h-4 w-4" aria-hidden="true">
          <path d="M10 1.6l2.6 5.3 5.8.8-4.2 4.1 1 5.8L10 14.8l-5.2 2.8 1-5.8-4.2-4.1 5.8-.8L10 1.6z" strokeLinejoin="round" />
        </svg>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Section 2 — "What is RideGo?"
// ---------------------------------------------------------------------------

const WHAT_IS_CARDS = [
  {
    icon: LaptopIcon,
    title: 'Technology Platform',
    description: 'We connect you with participating cab partners through our platform.',
    tone: 'bg-brand-50 text-brand-600',
  },
  {
    icon: CarIcon,
    title: 'Wide Ride Options',
    description: 'Choose from a range of vehicle options for your journey.',
    tone: 'bg-warning-50 text-warning-600',
  },
  {
    icon: UsersIcon,
    title: 'Partner Network',
    description: 'Work with independent cab vendors and drivers across India.',
    tone: 'bg-success-50 text-success-600',
  },
];

function WhatIsRideGoSection() {
  return (
    <section className="relative overflow-hidden bg-white py-16">
      <div className="pointer-events-none absolute -left-20 top-0 h-72 w-72 rounded-full bg-brand-200/70 blur-3xl" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <Eyebrow icon={LaptopIcon}>What is {brand().name}?</Eyebrow>
      <h2 className="mt-3 text-2xl font-bold tracking-tight text-ink-900 sm:text-3xl">A technology platform for your outstation travel needs</h2>
      <p className="mt-4 max-w-3xl text-[15px] leading-relaxed text-ink-600">
        {brand().name} is a technology-enabled platform that helps you find and connect with participating cab
        partners and drivers for outstation journeys. We bring together multiple transportation partners on one
        platform so you can explore ride options, compare and book the one that suits your needs.
      </p>

      <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-3">
        {WHAT_IS_CARDS.map((c) => (
          <div
            key={c.title}
            className="group rounded-xl bg-white p-5 shadow-card-rest ring-1 ring-inset ring-ink-100 transition-all duration-200 hover:-translate-y-1 hover:shadow-card-hover hover:ring-brand-200"
          >
            <span className={`inline-flex h-11 w-11 items-center justify-center rounded-xl ring-1 ring-inset ring-black/5 transition-transform duration-200 group-hover:scale-105 ${c.tone}`}>
              <c.icon className="h-5 w-5" />
            </span>
            <h3 className="mt-3.5 font-semibold text-ink-900">{c.title}</h3>
            <p className="mt-1.5 text-sm leading-relaxed text-ink-500">{c.description}</p>
          </div>
        ))}
      </div>

      {/* Platform-model disclaimer — appearance 1 of 3 required across the page */}
      <p className="mt-6 max-w-3xl border-t border-ink-100 pt-4 text-xs leading-relaxed text-ink-500">
        {brand().name} does not own or operate the vehicles listed on the platform. Actual transportation services
        are provided by the respective participating transportation partner.
      </p>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Section 3 — "How the RideGo Platform Works" (platform model, 4 steps)
// ---------------------------------------------------------------------------

const PLATFORM_STEPS = [
  { icon: SearchIcon, title: 'Tell Us Your Trip', description: 'Enter your pickup, drop, travel date and other requirements.' },
  { icon: CarIcon, title: 'Find Ride Options', description: 'Get available ride options from participating cab partners.' },
  { icon: ListIcon, title: 'Choose Your Ride', description: 'Compare vehicles and select the option that suits your journey.' },
  { icon: BadgeCheckIcon, title: 'Travel With Your Driver', description: 'Once your booking is confirmed and a driver-partner is assigned, they handle your travel service.' },
];

function HowPlatformWorksSection() {
  return (
    <section id="how-it-works" className="bg-brand-50 py-16">
      <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
        <Eyebrow icon={ListIcon}>How it works</Eyebrow>
        <h2 className="mt-2 text-2xl font-bold text-ink-900 sm:text-3xl">How the {brand().name} Platform Works</h2>
        <p className="mt-2 text-ink-500">Book your outstation ride in a few simple steps.</p>

        <div className="mt-10 grid grid-cols-1 gap-8 text-left sm:grid-cols-2 lg:grid-cols-4">
          {PLATFORM_STEPS.map((step, i) => (
            <div key={step.title} className="group relative">
              {i < PLATFORM_STEPS.length - 1 && (
                <div className="absolute left-6 top-6 hidden h-px w-full bg-gradient-to-r from-brand-300 to-transparent lg:block" aria-hidden="true" />
              )}
              <div className="relative z-10 flex h-12 w-12 items-center justify-center rounded-full bg-brand-600 text-white shadow-[0_8px_16px_-4px_rgba(0,0,0,0.25),0_2px_4px_rgba(0,0,0,0.15)] ring-4 ring-white transition-transform duration-200 group-hover:-translate-y-0.5">
                <step.icon className="h-5 w-5" />
              </div>
              <h3 className="mt-4 text-base font-semibold text-ink-900">
                <span className="mr-1 text-brand-500">{i + 1}.</span> {step.title}
              </h3>
              <p className="mt-1.5 text-sm leading-relaxed text-ink-500">{step.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Section 4 — "Popular Outstation Routes" — real origin→destination pairs from
// published route marketing pages, real starting fares. Never fabricated.
// ---------------------------------------------------------------------------

function PopularRoutesSection() {
  const [rows, setRows] = useState<PopularRoute[] | null>(null);

  useEffect(() => {
    let live = true;
    getPopularRoutes()
      .then((r) => { if (live) setRows(r); })
      .catch(() => { if (live) setRows([]); });
    return () => { live = false; };
  }, []);

  return (
    <section id="popular-routes" className="relative overflow-hidden bg-white py-16">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_1px_1px,theme(colors.ink.100)_1px,transparent_0)] bg-[length:24px_24px] opacity-40" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div className="flex items-end justify-between">
        <div>
          <Eyebrow icon={RouteIcon}>Popular routes</Eyebrow>
          <h2 className="mt-2 text-2xl font-bold text-ink-900 sm:text-3xl">Popular Outstation Routes</h2>
          <p className="mt-1 text-ink-500">Explore frequently booked routes across India.</p>
        </div>
      </div>

      {rows === null && (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="aspect-[4/3] w-full rounded-xl" />)}
        </div>
      )}

      {rows !== null && rows.length === 0 && (
        <p className="mt-6 rounded-xl border border-dashed border-ink-200 bg-ink-50/60 p-8 text-center text-sm text-ink-500">
          Popular routes will appear here once route pages are published.
        </p>
      )}

      {rows !== null && rows.length > 0 && (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {rows.map((r) => (
            <Link
              key={r.slug}
              to={`/routes/${r.slug}`}
              className="group relative overflow-hidden rounded-2xl border border-ink-100 bg-white shadow-card-rest transition-all duration-300 hover:-translate-y-1.5 hover:border-brand-200 hover:shadow-card-hover"
            >
              <div className="relative overflow-hidden">
                {r.image_url ? (
                  <img
                    src={r.image_url}
                    alt={`${r.from_city} to ${r.to_city}`}
                    loading="lazy"
                    className="block aspect-[4/3] w-full object-cover transition duration-300 group-hover:scale-105"
                  />
                ) : (
                  <div className="flex aspect-[4/3] w-full items-center justify-center bg-gradient-to-br from-brand-50 to-ink-100">
                    <RouteIcon className="h-6 w-6 text-brand-400" />
                  </div>
                )}
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/25 via-transparent to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" aria-hidden="true" />
              </div>
              <div className="p-3">
                <p className="flex items-center gap-1 text-sm font-semibold text-ink-900">
                  {r.from_city} <ArrowRightIcon className="h-3 w-3 shrink-0 text-ink-400 transition-transform duration-200 group-hover:translate-x-0.5 group-hover:text-brand-500" /> {r.to_city}
                </p>
                {r.starting_fare != null && (
                  <p className="mt-1 text-xs font-semibold text-brand-700">From ₹{r.starting_fare.toLocaleString('en-IN')}</p>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Section 6 — "One Platform. Multiple Ride Partners." (decorative diagram)
// ---------------------------------------------------------------------------

const PLATFORM_BENEFITS = [
  'More ride options',
  'Multiple vehicle categories',
  'Wide outstation coverage',
  'Easy comparison and booking',
  'Journey coordination support',
];

function OnePlatformSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-brand-900 via-brand-950 to-ink-950 py-16 text-white">
      <div className="pointer-events-none absolute -right-32 top-0 h-96 w-96 rounded-full bg-brand-500/20 blur-3xl" aria-hidden="true" />
      <div className="pointer-events-none absolute -bottom-24 left-1/3 h-72 w-72 rounded-full bg-accent-500/10 blur-3xl" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 items-center gap-10 lg:grid-cols-2">
          <div>
            <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-brand-200 shadow-[inset_0_1px_0_rgba(255,255,255,0.15)] ring-1 ring-inset ring-white/15">
              <LaptopIcon className="h-3.5 w-3.5" /> One platform, multiple ride partners
            </span>
            <h2 className="mt-3 text-2xl font-bold tracking-tight sm:text-3xl">One Platform. Multiple Ride Partners.</h2>
            <p className="mt-3 max-w-md leading-relaxed text-ink-300">
              {brand().name} brings customers and independent cab partners together, giving you more choices, better
              comparisons and a simpler booking experience for outstation travel.
            </p>
            <ul className="mt-6 space-y-2.5">
              {PLATFORM_BENEFITS.map((b) => (
                <li key={b} className="flex items-start gap-2.5 text-sm text-ink-200">
                  <span className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand-500/15 ring-1 ring-inset ring-brand-400/30">
                    <BadgeCheckIcon className="h-3.5 w-3.5 text-brand-300" />
                  </span>
                  {b}
                </li>
              ))}
            </ul>
          </div>

          {/* Decorative, non-factual flow diagram — Customer → Platform → Partners → Journey.
              Appearance 2 of 3 of the required platform-model distinction. Nodes now carry
              layered depth (ambient + contact shadow, inset ring) and the connectors read as
              a directional dotted flow line with a small traveling dot rather than a bare
              arrow glyph. */}
          <div className="flex flex-col items-center gap-4 sm:flex-row sm:justify-center sm:gap-3">
            <div className="group flex flex-col items-center gap-2.5">
              <span className="flex h-16 w-16 items-center justify-center rounded-full bg-white text-ink-900 shadow-[0_12px_24px_-8px_rgba(0,0,0,0.45),inset_0_1px_0_rgba(255,255,255,0.8)] ring-1 ring-inset ring-black/5 transition-transform duration-300 group-hover:-translate-y-1">
                <UsersIcon className="h-7 w-7" />
              </span>
              <span className="text-xs font-medium text-ink-300">You</span>
            </div>

            <div className="flex h-8 w-8 items-center justify-center sm:h-5 sm:w-10" aria-hidden="true">
              <div className="relative h-8 w-px bg-gradient-to-b from-white/10 via-white/40 to-white/10 sm:h-px sm:w-full sm:bg-gradient-to-r">
                <span className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-brand-300 shadow-[0_0_8px_2px_rgba(89,176,255,0.6)]" />
              </div>
            </div>

            <div className="group flex flex-col items-center gap-2.5">
              <span className="flex h-20 w-20 items-center justify-center rounded-full bg-brand-600 text-white shadow-[0_16px_32px_-10px_rgba(26,110,245,0.6),inset_0_1px_0_rgba(255,255,255,0.25)] ring-4 ring-white/10 transition-transform duration-300 group-hover:-translate-y-1">
                <LaptopIcon className="h-8 w-8" />
              </span>
              <span className="max-w-[7rem] text-center text-xs font-medium text-ink-300">{brand().name} Technology Platform</span>
            </div>

            <div className="flex h-8 w-8 items-center justify-center sm:h-5 sm:w-10" aria-hidden="true">
              <div className="relative h-8 w-px bg-gradient-to-b from-white/10 via-white/40 to-white/10 sm:h-px sm:w-full sm:bg-gradient-to-r">
                <span className="absolute left-1/2 top-1/2 h-1.5 w-1.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-brand-300 shadow-[0_0_8px_2px_rgba(89,176,255,0.6)]" />
              </div>
            </div>

            <div className="group flex flex-col items-center gap-2.5">
              <span className="flex h-16 w-16 items-center justify-center rounded-full bg-white text-ink-900 shadow-[0_12px_24px_-8px_rgba(0,0,0,0.45),inset_0_1px_0_rgba(255,255,255,0.8)] ring-1 ring-inset ring-black/5 transition-transform duration-300 group-hover:-translate-y-1">
                <CarIcon className="h-7 w-7" />
              </span>
              <span className="max-w-[7rem] text-center text-xs font-medium text-ink-300">Cab Partners &amp; Drivers</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Section 7 — "Outstation Trips Made Easy" full-bleed banner. The former
// "Find the right ride for your trip type" card grid that used to sit below
// this banner was removed — it was a near-exact duplicate of the "For Every
// Kind of Outstation Journey" section further down the page (same trip
// types, same layout), so it was cut rather than kept as redundant content.
// ---------------------------------------------------------------------------

// This is the "second hero" — a full-bleed, visually prominent mid-page banner
// (matching the treatment the pre-rebuild homepage used, set from Settings →
// Branding & business → "Second hero image"). It falls back to a brand-color
// gradient rather than any stock photo when no image has been uploaded, and it
// embeds the first few rows of the SAME real "Popular Outstation Routes" data
// source used in Section 4 — no second, diverging route dataset.
function TripCategoriesSection() {
  const [rows, setRows] = useState<PopularRoute[] | null>(null);

  useEffect(() => {
    let live = true;
    getPopularRoutes()
      .then((r) => { if (live) setRows(r); })
      .catch(() => { if (live) setRows([]); });
    return () => { live = false; };
  }, []);

  const featured = (rows ?? []).slice(0, 4);
  const hasBannerImage = !!brand().hero_secondary_image_url;

  return (
    <section className="bg-ink-950 text-white">
      <div
        className="relative overflow-hidden pt-6"
        style={{ minHeight: heightStyle(brand().hero_secondary_height, 420).height }}
      >
        {hasBannerImage ? (
          <div
            className={
              'absolute inset-0 ' +
              (brand().hero_secondary_fit === 'contain'
                ? 'bg-contain bg-center bg-no-repeat'
                : brand().hero_secondary_fit === 'fill'
                  ? 'bg-[100%_100%] bg-center'
                  : 'bg-cover bg-center')
            }
            style={{ backgroundImage: `url(${brand().hero_secondary_image_url})` }}
          />
        ) : (
          <div className="absolute inset-0 bg-gradient-to-br from-brand-900 via-ink-950 to-ink-900" />
        )}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-ink-950/95 via-ink-950/70 to-ink-950/20" />
        {/* Bottom-to-top legibility gradient so the featured-route cards and CTA
            row sit on solid contrast even when the banner photo is bright at
            that edge, matching the hero's overlay treatment. */}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink-950/90 via-ink-950/10 to-transparent" />

        <div className="relative flex h-full items-center">
          <div className="mx-auto w-full max-w-7xl px-4 py-14 sm:px-6 lg:px-8">
            <h2 className="max-w-xl text-3xl font-bold tracking-tight [text-wrap:balance] sm:text-4xl">Outstation trips made easy</h2>
            <p className="mt-3 max-w-md leading-relaxed text-brand-100">
              Plan weekend getaways, family trips or business travel with verified driver-partners and comfortable
              cars, across multiple outstation routes.
            </p>
            <div className="mt-5 flex flex-wrap gap-2.5 text-sm text-brand-100">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 shadow-[inset_0_1px_0_rgba(255,255,255,0.15)] ring-1 ring-inset ring-white/15 backdrop-blur-sm"><RepeatIcon className="h-4 w-4 text-brand-200" /> One-way &amp; round trips</span>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 shadow-[inset_0_1px_0_rgba(255,255,255,0.15)] ring-1 ring-inset ring-white/15 backdrop-blur-sm"><BadgeCheckIcon className="h-4 w-4 text-brand-200" /> Verified driver-partners</span>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1.5 shadow-[inset_0_1px_0_rgba(255,255,255,0.15)] ring-1 ring-inset ring-white/15 backdrop-blur-sm"><MapPinIcon className="h-4 w-4 text-brand-200" /> Pan-India coverage</span>
            </div>

            {featured.length > 0 && (
              <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-4">
                {featured.map((r) => (
                  <Link
                    key={r.slug}
                    to={`/routes/${r.slug}`}
                    className="group overflow-hidden rounded-2xl bg-white/10 shadow-lg shadow-black/20 ring-1 ring-white/15 backdrop-blur-sm transition hover:-translate-y-1 hover:bg-white/15 hover:shadow-xl hover:ring-white/30"
                  >
                    {r.image_url ? (
                      <img
                        src={r.image_url}
                        alt={`${r.from_city} to ${r.to_city}`}
                        loading="lazy"
                        className="block aspect-[4/3] w-full object-cover transition duration-300 group-hover:scale-105"
                      />
                    ) : (
                      <div className="flex aspect-[4/3] w-full items-center justify-center bg-gradient-to-br from-brand-700/60 via-brand-900/60 to-ink-900/60">
                        <RouteIcon className="h-7 w-7 text-brand-200" />
                      </div>
                    )}
                    <div className="p-3">
                      <p className="flex items-center gap-1 text-xs font-semibold text-white">
                        {r.from_city} <ArrowRightIcon className="h-3 w-3 shrink-0 text-brand-200" /> {r.to_city}
                      </p>
                      {r.starting_fare != null && (
                        <p className="mt-1 text-[11px] font-semibold text-brand-200">From ₹{r.starting_fare.toLocaleString('en-IN')}</p>
                      )}
                    </div>
                  </Link>
                ))}
              </div>
            )}

            <div className="mt-7 flex flex-wrap gap-3">
              <a href="#popular-routes">
                <Button size="lg">Explore all routes &rarr;</Button>
              </a>
              <Link to="/book">
                <Button size="lg" variant="secondary">Book an outstation cab</Button>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Section 8 — "Why Use RideGo?" (decorative marketing cards)
// ---------------------------------------------------------------------------

const WHY_RIDEGO = [
  { icon: SearchIcon, title: 'Easy Ride Discovery', description: 'Find available ride options for your outstation trip in a few taps.' },
  { icon: CarIcon, title: 'Multiple Vehicle Options', description: 'Compare vehicles from participating partners.' },
  { icon: MapPinIcon, title: 'Wide Route Coverage', description: 'Find options for popular and lesser-known outstation routes.' },
  { icon: UsersIcon, title: 'Partner-Based Network', description: 'Independent cab vendors and drivers, matched to your journey.' },
  { icon: DocumentIcon, title: 'Journey Coordination', description: 'Clear trip details and pricing before you book.' },
  { icon: ChatIcon, title: 'Customer Support', description: 'Get assistance with your booking and journey.' },
];

function WhyRideGoSection() {
  return (
    <section className="relative overflow-hidden bg-white py-16">
      <div className="pointer-events-none absolute -right-24 bottom-0 h-80 w-80 rounded-full bg-accent-200/70 blur-3xl" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Eyebrow icon={BadgeCheckIcon} tone="accent">Why {brand().name}</Eyebrow>
        <h2 className="mt-3 text-2xl font-bold tracking-tight text-ink-900 sm:text-3xl">Why {brand().name} is Different</h2>
        <p className="mt-1.5 text-ink-500">A simpler, more open way to find outstation rides.</p>
        <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {WHY_RIDEGO.map((v, i) => (
            <div
              key={v.title}
              className="group rounded-xl border border-ink-100 bg-white p-5 shadow-card-rest transition-all duration-200 hover:-translate-y-1 hover:border-brand-200 hover:shadow-card-hover"
            >
              <span className={`inline-flex h-10 w-10 items-center justify-center rounded-2xl ring-1 ring-inset ring-black/5 transition-transform duration-200 group-hover:scale-105 ${iconTileTone(i)}`}>
                <v.icon className="h-5 w-5" />
              </span>
              <h3 className="mt-3 font-semibold text-ink-900">{v.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-ink-500">{v.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Section 9 — booking journey timeline (customer's click-by-click journey —
// distinct in framing from section 3's platform-model steps).
// ---------------------------------------------------------------------------

const BOOKING_JOURNEY = [
  { title: 'Search', description: 'Enter your trip details and see available ride options.' },
  { title: 'Compare', description: 'Compare vehicles from participating cab partners.' },
  { title: 'Choose', description: 'Pick the ride option that fits your journey.' },
  { title: 'Confirm', description: 'Confirm your booking and complete the booking amount payment, if applicable.' },
  { title: 'Travel', description: 'Once a driver-partner is assigned and their details are shared, travel with them for a smooth trip.' },
];

function BookingJourneySection() {
  return (
    <section className="bg-brand-50 py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <h2 className="text-2xl font-bold text-ink-900 sm:text-3xl">Your Booking Journey</h2>
      <p className="mt-1 text-ink-500">Search, compare and book — here's exactly what happens at each step.</p>
      <div className="mt-8 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-5">
        {BOOKING_JOURNEY.map((step, i) => (
          <div key={step.title} className="relative">
            {i < BOOKING_JOURNEY.length - 1 && (
              <div className="absolute left-5 top-11 hidden h-px w-full bg-brand-200 lg:block" aria-hidden="true" />
            )}
            <div className="relative flex h-11 w-11 items-center justify-center rounded-full bg-brand-600 text-lg font-bold text-white shadow-lg">
              {i + 1}
            </div>
            <h3 className="mt-4 text-lg font-semibold text-ink-900">{step.title}</h3>
            <p className="mt-1.5 text-sm text-ink-500">{step.description}</p>
          </div>
        ))}
      </div>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Section 10 — "For Every Kind of Outstation Journey" — icon cards, not
// fabricated stock photography (RideGo has no real per-category photo library).
// ---------------------------------------------------------------------------

const JOURNEY_KINDS = [
  { icon: ArrowRightIcon, label: 'One-way trips', description: 'Plan a trip to your destination without a return.' },
  { icon: RepeatIcon, label: 'Round trips', description: 'Plan a return journey with ease.' },
  { icon: UsersIcon, label: 'Family travel', description: 'Comfortable vehicle options for family trips.' },
  { icon: AirplaneIcon, label: 'Airport transfers', description: 'Pick up or drop off in time for your flight.' },
  { icon: BriefcaseIcon, label: 'Business travel', description: 'Reliable travel for work-related trips.' },
  { icon: GroupIcon, label: 'Group travel', description: 'Larger vehicle options for groups and events.' },
];

function JourneyKindsSection() {
  return (
    <section className="bg-white py-16">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <div className="flex items-end justify-between">
        <div>
          <h2 className="text-2xl font-bold text-ink-900 sm:text-3xl">For Every Kind of Outstation Journey</h2>
          <p className="mt-1 text-ink-500">Find the right ride for your travel need.</p>
        </div>
      </div>
      <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {JOURNEY_KINDS.map((j, i) => (
          <div
            key={j.label}
            className="group flex flex-col items-center rounded-xl bg-white p-5 text-center shadow-card-rest ring-1 ring-inset ring-ink-100 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-card-hover hover:ring-brand-200"
          >
            <span className={`flex h-12 w-12 items-center justify-center rounded-2xl ring-1 ring-inset ring-black/5 transition-transform duration-200 group-hover:scale-105 ${iconTileTone(i)}`}>
              <j.icon className="h-6 w-6" />
            </span>
            <p className="mt-3 text-sm font-semibold text-ink-900">{j.label}</p>
            <p className="mt-1 text-xs leading-relaxed text-ink-500">{j.description}</p>
          </div>
        ))}
      </div>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Section 11 — "Meet the Partners Behind Your Ride" — real, active +
// KYC-verified vendor records only, via /app/partners.
// ---------------------------------------------------------------------------

function PartnersSection() {
  const [rows, setRows] = useState<Partner[] | null>(null);

  useEffect(() => {
    let live = true;
    getPartners()
      .then((r) => { if (live) setRows(r); })
      .catch(() => { if (live) setRows([]); });
    return () => { live = false; };
  }, []);

  return (
    <section className="relative overflow-hidden bg-accent-50 py-16">
      <div className="pointer-events-none absolute -right-24 top-10 h-72 w-72 rounded-full bg-accent-300/60 blur-3xl" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <Eyebrow icon={UsersIcon} tone="accent">Our network</Eyebrow>
        <h2 className="mt-2 text-2xl font-bold text-ink-900 sm:text-3xl">Meet the Partners Behind Your Ride</h2>
        <p className="mt-1 max-w-2xl text-ink-500">
          Rides are fulfilled by independent cab vendors and drivers who are part of the {brand().name} partner
          network. You can choose from a variety of vehicles and partners based on your journey requirements.
        </p>

        {rows === null && (
          <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-3">
            {Array.from({ length: 3 }).map((_, i) => <SkeletonCard key={i} />)}
          </div>
        )}

        {rows !== null && rows.length === 0 && (
          <p className="mt-8 rounded-xl border border-dashed border-ink-200 bg-white p-8 text-center text-sm text-ink-500">
            Partner profiles will be featured here as our network of participating cab partners grows.
          </p>
        )}

        {rows !== null && rows.length > 0 && (
          <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-3">
            {rows.map((p) => (
              <div key={p.name + p.city} className="group rounded-2xl bg-white p-5 shadow-card-rest ring-1 ring-inset ring-ink-100/60 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-card-hover">
                <div className="flex items-center gap-3">
                  <span className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-brand-100 text-sm font-bold text-brand-700 shadow-inner ring-1 ring-inset ring-brand-200/60 transition-transform duration-200 group-hover:scale-105">
                    {p.name.slice(0, 2).toUpperCase()}
                  </span>
                  <div className="min-w-0">
                    <p className="truncate font-semibold text-ink-900">{p.name}</p>
                    <p className="truncate text-xs text-ink-500">{p.city}</p>
                  </div>
                </div>
                {p.vehicle_types.length > 0 && (
                  <p className="mt-3 border-t border-ink-50 pt-3 text-xs text-ink-500">{p.vehicle_types.join(' · ')}</p>
                )}
                {(p.rating != null || p.total_rides_completed != null) && (
                  <p className="mt-2 flex items-center gap-1.5 text-xs text-ink-600">
                    {p.rating != null && <span className="font-semibold text-warning-600">★ {p.rating}</span>}
                    {p.total_ratings != null && <span>({p.total_ratings})</span>}
                    {p.total_rides_completed != null && <span>· {p.total_rides_completed}+ trips</span>}
                  </p>
                )}
              </div>
            ))}
          </div>
        )}
        <p className="mt-6 text-xs text-ink-500">
          Independent transportation partners are onboarded, KYC-verified and managed by {brand().name}'s admin team.
        </p>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Section 12 — Reviews. Real data only (unchanged data source), restyled.
// ---------------------------------------------------------------------------

function ReviewsSection() {
  const [rows, setRows] = useState<AppReview[] | null>(null);

  useEffect(() => {
    let live = true;
    getReviews({ page: 1 })
      .then((r) => { if (live) setRows(r.rows); })
      .catch(() => { if (live) setRows([]); });
    return () => { live = false; };
  }, []);

  if (rows === null) {
    return (
      <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-3">
        {Array.from({ length: 3 }).map((_, i) => <SkeletonCard key={i} />)}
      </div>
    );
  }

  if (rows.length === 0) {
    return (
      <div className="mt-8 rounded-2xl border border-dashed border-ink-200 bg-ink-50/60 p-10 text-center">
        <p className="font-semibold text-ink-800">Customer reviews will be featured here soon</p>
        <p className="mt-1 text-sm text-ink-500">Every review shown here comes from a real, completed trip — nothing is written for us.</p>
      </div>
    );
  }

  return (
    <div className="mt-8 grid grid-cols-1 gap-5 sm:grid-cols-3">
      {rows.slice(0, 3).map((r) => (
        <div key={r.id} className="group relative flex flex-col overflow-hidden rounded-2xl bg-white p-5 shadow-card-rest ring-1 ring-inset ring-ink-100/60 transition-all duration-300 hover:-translate-y-1.5 hover:shadow-card-hover">
          <span className="pointer-events-none absolute -right-1 -top-3 select-none font-serif text-6xl leading-none text-brand-50" aria-hidden="true">&rdquo;</span>
          <StarRow rating={r.rating} />
          <p className="relative mt-3 flex-1 text-sm leading-relaxed text-ink-700">&ldquo;{r.review}&rdquo;</p>
          <div className="mt-4 flex items-center gap-3 border-t border-ink-50 pt-3">
            <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-brand-100 text-sm font-bold text-brand-700 ring-1 ring-inset ring-brand-200/60">
              {r.client_name.slice(0, 2).toUpperCase()}
            </span>
            <div className="min-w-0">
              <p className="truncate text-sm font-semibold text-ink-900">{r.client_name}</p>
              <p className="truncate text-xs text-ink-500">{r.pickup_city}{r.drop_city ? ` → ${r.drop_city}` : ''}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Section 13 — FAQ (accordion pattern from RoutePage.tsx)
// ---------------------------------------------------------------------------

const FAQS = [
  { q: 'What is RideGo?', a: `${brand().name} is a technology platform that connects you with participating cab partners and drivers for outstation travel — it does not own or operate the vehicles listed on the platform.` },
  { q: 'Do you own the cabs or drivers?', a: `No. Vehicles and drivers on ${brand().name} are provided by independent, participating transportation partners, not by ${brand().name} itself.` },
  { q: 'How does the booking process work?', a: 'Tell us your trip, compare available vehicle options and fares, choose the one that fits and confirm your booking — the platform then assigns a verified driver-partner to your trip and shares their details once assigned.' },
  { q: 'How is the payment/advance handled?', a: 'Where a booking amount applies, it is paid securely online after you submit your trip details; any remaining fare is settled directly with the driver-partner at the end of the trip.' },
  { q: 'Who provides the vehicle and driver?', a: 'The vehicle and driver are provided by the participating transportation partner matched to your booking, not by RideGo directly.' },
  { q: 'Can I book a one-way or round trip?', a: 'Yes — one-way, round trip and other outstation trip types are available depending on route and partner availability.' },
  { q: 'What if I need to cancel my booking?', a: 'You can cancel free of charge any time before a driver-partner has been assigned to your trip. Once one is assigned, a portion of the booking amount may be retained. Manage cancellations from My Trips or by contacting support.' },
  { q: 'How can I contact support?', a: `Reach ${brand().name} support any time via the phone number or WhatsApp number listed in the footer.` },
];

function FaqSection() {
  return (
    <section id="faq" className="relative overflow-hidden bg-ink-50 py-16">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-ink-200 to-transparent" aria-hidden="true" />
      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
      <Eyebrow icon={ChatIcon}>Support</Eyebrow>
      <h2 className="mt-3 text-2xl font-bold tracking-tight text-ink-900 sm:text-3xl">Frequently Asked Questions</h2>
      <p className="mt-1.5 text-ink-500">Answers to common questions about booking outstation rides through {brand().name}.</p>
      <div className="mt-8 grid grid-cols-1 gap-3 sm:grid-cols-2">
        {FAQS.map((f, i) => (
          <details key={i} className="group rounded-xl bg-white p-4 shadow-card-rest ring-1 ring-inset ring-ink-100 transition-all duration-200 open:shadow-card-hover open:ring-brand-200 hover:-translate-y-0.5 hover:shadow-card-hover hover:ring-brand-200">
            <summary className="flex cursor-pointer list-none items-center justify-between gap-3 font-medium text-ink-900">
              {f.q}
              <ChevronDownIcon className="h-4 w-4 shrink-0 text-ink-400 transition-transform group-open:rotate-180" />
            </summary>
            <p className="mt-2 text-sm text-ink-600">{f.a}</p>
          </details>
        ))}
      </div>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Section 14 — "Your RideGo Travel Hub" — real PWA install prompt, never fake
// App Store / Google Play badges (no native app exists — this is a PWA).
// ---------------------------------------------------------------------------

function TravelHubCard() {
  const [installEvent, setInstallEvent] = useState<{ prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> } | null>(null);
  const [installed, setInstalled] = useState(false);

  useEffect(() => {
    function onPrompt(e: Event) {
      e.preventDefault();
      setInstallEvent(e as unknown as { prompt: () => Promise<void>; userChoice: Promise<{ outcome: string }> });
    }
    function onInstalled() { setInstalled(true); }
    window.addEventListener('beforeinstallprompt', onPrompt);
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onPrompt);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  async function install() {
    if (!installEvent) return;
    await installEvent.prompt();
    await installEvent.userChoice;
    setInstallEvent(null);
  }

  return (
    <section className="bg-brand-50 py-14">
      <div className="mx-auto flex max-w-7xl flex-col items-center gap-8 px-4 sm:px-6 lg:flex-row lg:justify-between lg:px-8">
        <div className="text-center lg:text-left">
          <h2 className="text-2xl font-bold text-ink-900 sm:text-3xl">Your {brand().name} Travel Hub</h2>
          <p className="mt-2 max-w-md text-ink-600">
            {installed
              ? 'You’re all set — open it any time from your home screen.'
              : 'Book outstation rides, manage bookings and more — add RideGo to your home screen for quick access.'}
          </p>
          <ul className="mt-4 flex flex-col gap-1.5 text-sm text-ink-600 lg:items-start">
            <li className="flex items-center gap-2"><SearchIcon className="h-4 w-4 text-brand-600" /> Search and book rides</li>
            <li className="flex items-center gap-2"><ListIcon className="h-4 w-4 text-brand-600" /> Manage your bookings</li>
            <li className="flex items-center gap-2"><CarIcon className="h-4 w-4 text-brand-600" /> Get driver details</li>
            <li className="flex items-center gap-2"><ChatIcon className="h-4 w-4 text-brand-600" /> Receive trip updates</li>
          </ul>
        </div>
        <div className="flex shrink-0 items-center gap-4">
          <div className="hidden h-24 w-24 items-center justify-center rounded-2xl bg-white shadow-xl sm:flex">
            <span className="text-3xl font-extrabold text-brand-600">{brand().name.slice(0, 1)}</span>
          </div>
          {installEvent && !installed ? (
            <Button size="lg" onClick={install}>Add {brand().name} to your Home Screen</Button>
          ) : (
            <p className="max-w-[14rem] text-sm text-ink-500">
              On mobile, use your browser menu → &ldquo;Add to Home Screen&rdquo;.
            </p>
          )}
        </div>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Client welcome banner (unchanged) — a real logged-in client's own name and
// next trip, shown above the marketing hero instead of it.
// ---------------------------------------------------------------------------

function ClientWelcomeBanner({ name }: { name: string }) {
  const [data, setData] = useState<ClientHomeResponse | null>(null);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let live = true;
    getClientHome()
      .then((d) => { if (live) setData(d); })
      .catch(() => { if (live) setFailed(true); });
    return () => { live = false; };
  }, []);

  if (failed) return null;

  const firstName = name.split(' ')[0] || name;

  return (
    <section className="bg-gradient-to-br from-brand-800 via-brand-700 to-brand-900 text-white">
      <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <h1 className="text-3xl font-extrabold tracking-tight sm:text-4xl">Welcome back, {firstName}.</h1>

        {data?.next_trip ? (
          <div className="mt-6 flex flex-wrap items-center justify-between gap-4 rounded-xl bg-white/10 p-5 ring-1 ring-white/20">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wide text-brand-200">Your next trip</p>
              <p className="mt-1 text-lg font-semibold">
                {data.next_trip.pickup_city} → {data.next_trip.drop_city}
              </p>
              <p className="text-sm text-brand-100">
                {data.next_trip.journey_date} · {data.next_trip.journey_time} · {data.next_trip.status_label}
              </p>
            </div>
            <Link to={`/app/dashboard/trips/${data.next_trip.id}`}>
              <Button variant="secondary" size="sm">View trip</Button>
            </Link>
          </div>
        ) : (
          <p className="mt-4 max-w-lg text-lg text-brand-100">
            No upcoming trips yet — search below to book your next ride.
          </p>
        )}

        {data && data.attention.length > 0 && (
          <div className="mt-4 space-y-2">
            {data.attention.map((a) => (
              <Link
                key={`${a.booking_id}-${a.code}`}
                to={`/app/dashboard/trips/${a.booking_id}`}
                className="flex items-center gap-2 rounded-lg bg-warning-50 px-4 py-2 text-sm font-medium text-warning-700 hover:bg-warning-100"
              >
                {a.message} — {a.booking_number}
              </Link>
            ))}
          </div>
        )}

        <div className="mt-6 flex flex-wrap gap-3">
          <Link to="/dashboard/trips">
            <Button variant="secondary" size="sm">My trips</Button>
          </Link>
          <Link to="/dashboard">
            <Button variant="secondary" size="sm">My dashboard</Button>
          </Link>
        </div>
      </div>
    </section>
  );
}

// ---------------------------------------------------------------------------
// Page
// ---------------------------------------------------------------------------

export function HomePage() {
  const { user, isLoggedIn } = useAuth();
  const [data, setData] = useState<HomeResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const showClientWelcome = isLoggedIn && userKind(user) === 'client';

  function load() {
    setLoading(true);
    setError(null);
    getHome()
      .then(setData)
      .catch((err) => setError(err instanceof ApiError ? err.message : 'Could not load the homepage. Please try again.'))
      .finally(() => setLoading(false));
  }

  useEffect(load, []);

  return (
    <div>
      {showClientWelcome && user && <ClientWelcomeBanner name={user.name} />}

      {/* Section 1 — Hero (modified: copy + trust indicators; the booking widget
          itself is untouched, wired to real cities/vehicles data). */}
      <section
        id="hero"
        className="relative overflow-hidden bg-gradient-to-br from-brand-800 via-brand-700 to-brand-900 bg-cover bg-center text-white"
        style={brand().hero_image_url ? { backgroundImage: `url(${brand().hero_image_url})` } : undefined}
      >
        {brand().hero_overlay !== 'none' && (
          <div
            className={
              'pointer-events-none absolute inset-0 bg-gradient-to-br ' +
              (brand().hero_overlay === 'light'
                ? 'from-brand-900/45 via-brand-800/35 to-brand-950/50'
                : brand().hero_overlay === 'strong'
                  ? 'from-brand-900/95 via-brand-800/90 to-brand-950/95'
                  : 'from-brand-900/85 via-brand-800/75 to-brand-950/90')
            }
          />
        )}
        {/* Bottom-to-top legibility gradient — always present regardless of the
            configured overlay tone, so text and trust badges stay readable over
            any hero photo without relying solely on the flat tint above. */}
        <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-brand-950/80 via-brand-950/10 to-transparent" />
        <div className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-brand-500/30 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 -left-16 h-80 w-80 rounded-full bg-accent-500/20 blur-3xl" />
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(255,255,255,0.08),transparent_60%)]" />

        <div
          className={
            'relative mx-auto grid max-w-7xl gap-10 px-4 py-16 sm:px-6 lg:items-center lg:py-24 lg:px-8 ' +
            (brand().hero_show_text !== 'hide' ? 'lg:grid-cols-2' : 'justify-items-center')
          }
        >
          {brand().hero_show_text !== 'hide' && (
            <div>
              <p className="inline-flex items-center rounded-full bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-brand-100 shadow-[inset_0_1px_0_rgba(255,255,255,0.2)] ring-1 ring-white/20">
                {loading ? 'Loading…' : data?.platform_tagline || 'A technology platform for outstation travel'}
              </p>
              <h1 className="mt-4 text-4xl font-extrabold tracking-tight [text-wrap:balance] sm:text-5xl">
                Find the Right Ride for Your <span className="text-brand-200">Outstation Journey</span>
              </h1>
              <p className="mt-4 max-w-lg text-lg leading-relaxed text-brand-100">
                {brand().name} is a technology-enabled platform that helps you find and connect with participating
                cab partners and drivers for outstation travel across India.
              </p>

              {/* 3 trust/value indicators — approved wording, now raised as small
                  glass tiles with depth so they read as trust badges rather than
                  plain inline text. */}
              <div className="mt-7 grid grid-cols-1 gap-3 sm:grid-cols-3 sm:gap-3">
                <span className="inline-flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2.5 text-sm font-medium text-brand-100 shadow-[0_4px_12px_-4px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.15)] ring-1 ring-inset ring-white/15 backdrop-blur-sm transition hover:bg-white/15">
                  <MapPinIcon className="h-4 w-4 shrink-0 text-brand-200" /> Wide Route Coverage
                </span>
                <span className="inline-flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2.5 text-sm font-medium text-brand-100 shadow-[0_4px_12px_-4px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.15)] ring-1 ring-inset ring-white/15 backdrop-blur-sm transition hover:bg-white/15">
                  <CarIcon className="h-4 w-4 shrink-0 text-brand-200" /> Multiple Vehicle Options
                </span>
                <span className="inline-flex items-center gap-2 rounded-xl bg-white/10 px-3 py-2.5 text-sm font-medium text-brand-100 shadow-[0_4px_12px_-4px_rgba(0,0,0,0.3),inset_0_1px_0_rgba(255,255,255,0.15)] ring-1 ring-inset ring-white/15 backdrop-blur-sm transition hover:bg-white/15">
                  <SearchIcon className="h-4 w-4 shrink-0 text-brand-200" /> Simple Ride Discovery
                </span>
              </div>
            </div>
          )}

          <div className={brand().hero_show_text === 'hide' ? 'w-full max-w-xl' : undefined}>
            {loading ? (
              <div className="rounded-2xl bg-white p-6 shadow-xl">
                <Skeleton className="mb-4 h-9 w-full rounded-lg" />
                <div className="grid grid-cols-2 gap-3">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
                <Skeleton className="mt-3 h-11 w-full" />
              </div>
            ) : error ? (
              <div className="rounded-2xl bg-white p-6 shadow-xl">
                <ErrorBanner message={error} onRetry={load} />
              </div>
            ) : (
              <div className="rounded-2xl bg-white p-2 shadow-[0_24px_48px_-12px_rgba(0,0,0,0.35),0_8px_16px_-8px_rgba(0,0,0,0.2)] ring-1 ring-black/5">
                <FareSearchWidget
                  cities={data?.popular_cities ?? []}
                  originCities={data?.origin_cities}
                  destinationCities={data?.destination_cities}
                  vehicles={data?.vehicles ?? []}
                />
              </div>
            )}
          </div>
        </div>
      </section>

      {/* Section 2 — What is RideGo? (new) */}
      <WhatIsRideGoSection />

      {/* Section 3 — How the platform works (new) */}
      <HowPlatformWorksSection />

      {/* Section 4 — Popular outstation routes (renamed + real route-pair data) */}
      <PopularRoutesSection />

      {/* Section 5 — Vehicle options from participating partners (modified wording,
          same real vehicle grid/data already wired up). */}
      <section className="relative overflow-hidden bg-ink-50 py-16">
        <div className="pointer-events-none absolute -left-24 top-1/2 h-72 w-72 -translate-y-1/2 rounded-full bg-brand-200/70 blur-3xl" aria-hidden="true" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <Eyebrow icon={CarIcon}>Vehicle options</Eyebrow>
              <h2 className="mt-2 text-2xl font-bold text-ink-900 sm:text-3xl">Vehicle Options From Participating Partners</h2>
              <p className="mt-1 text-ink-500">Vehicle options available through participating partners.</p>
            </div>
            <Link to="/services" className="group text-sm font-semibold text-brand-700 transition hover:text-brand-800">
              View all vehicle types <span className="inline-block transition-transform duration-200 group-hover:translate-x-0.5">&rarr;</span>
            </Link>
          </div>

          <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {loading && Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)}

            {!loading && error && (
              <div className="col-span-full">
                <ErrorBanner message={error} onRetry={load} />
              </div>
            )}

            {!loading &&
              !error &&
              (data?.vehicles ?? []).map((v) => (
                <Link
                  key={v.id}
                  to={`/app/vehicles/${v.slug}`}
                  className="group flex flex-col overflow-hidden rounded-2xl border border-ink-100 bg-white shadow-card-rest transition-all duration-300 hover:-translate-y-1.5 hover:border-brand-200 hover:shadow-card-hover"
                >
                  <div className="flex aspect-[3/2] w-full items-center justify-center overflow-hidden bg-gradient-to-b from-ink-50 to-white p-4 transition-transform duration-300 group-hover:scale-105">
                    {v.image_url ? (
                      <img
                        src={v.image_url}
                        alt={v.name}
                        loading="lazy"
                        className={'block aspect-[3/2] w-full ' + fitClass(brand().vehicle_card_fit)}
                      />
                    ) : (
                      <svg className="h-12 w-12 text-ink-300" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" aria-hidden="true">
                        <path strokeLinecap="round" strokeLinejoin="round" d="M8 17l4-11 4 11M9.5 13h5M3 21h18" />
                      </svg>
                    )}
                  </div>
                  <div className="flex flex-1 flex-col border-t border-ink-100 p-4">
                    <p className="font-semibold text-ink-900 transition-colors group-hover:text-brand-700">{v.name}</p>
                    <p className="mt-1 flex items-center gap-1.5 text-sm text-ink-500">
                      <UsersIcon className="h-3.5 w-3.5 text-ink-400" /> {v.seating_capacity} seats
                    </p>
                    <p className="mt-auto pt-3 text-sm text-ink-600">
                      {v.base_fare != null ? (
                        <>
                          Starting at <span className="font-bold text-ink-900">₹{v.base_fare.toLocaleString('en-IN')}</span>
                        </>
                      ) : (
                        'Fare on request'
                      )}
                    </p>
                  </div>
                </Link>
              ))}

            {!loading && !error && (data?.vehicles ?? []).length === 0 && (
              <p className="col-span-full text-sm text-ink-500">No vehicle options to show yet.</p>
            )}
          </div>
        </div>
      </section>

      {/* Section 6 — One platform, multiple ride partners (new). Kept apart from
          the "Outstation trips made easy" banner (moved below, next to the
          Journey Kinds section) — the two dark, full-width sections read as
          one merged block when stacked directly on top of each other, so each
          now gets its own light-toned neighbor instead. */}
      <OnePlatformSection />

      {/* Section 8 — Why RideGo is different (new/replace) */}
      <WhyRideGoSection />

      {/* Section 9 — Booking journey timeline (modified, distinct framing from section 3) */}
      <BookingJourneySection />

      {/* Section 7 — Outstation trips made easy / trip-category tabs (new).
          Relocated here, right before "For every kind of outstation journey" —
          the trip-type banner now leads directly into the journey-kind cards
          it introduces, and it sits between brand-50 (above) and white (below)
          so it no longer touches the other dark "One Platform" section. */}
      <TripCategoriesSection />

      {/* Section 10 — For every kind of outstation journey (new, icon cards) */}
      <JourneyKindsSection />

      {/* Section 11 — Meet the partners behind your ride (new, real vendor data) */}
      <PartnersSection />

      {/* Section 12 — Reviews (modified — real data only) */}
      <section className="relative overflow-hidden bg-brand-50 py-16">
        <div className="pointer-events-none absolute -left-20 bottom-0 h-72 w-72 rounded-full bg-brand-200/80 blur-3xl" aria-hidden="true" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex items-end justify-between">
          <div>
            <Eyebrow icon={BadgeCheckIcon}>Customer stories</Eyebrow>
            <h2 className="mt-2 text-2xl font-bold text-ink-900 sm:text-3xl">What Our Customers Say</h2>
            <p className="mt-1 text-ink-500">Real reviews from travellers who have booked rides through {brand().name}.</p>
          </div>
          <Link to="/reviews" className="group hidden text-sm font-semibold text-brand-700 transition hover:text-brand-800 sm:inline-block">
            View all reviews <span className="inline-block transition-transform duration-200 group-hover:translate-x-0.5">&rarr;</span>
          </Link>
        </div>
        <ReviewsSection />
        </div>
      </section>

      {/* Section 13 — FAQ (new) */}
      <FaqSection />

      {/* Section 14 — App/device section, renamed (real PWA prompt, not fake store badges) */}
      <TravelHubCard />

      {/* Section 15 — Final CTA */}
      <section className="relative overflow-hidden bg-gradient-to-br from-ink-950 via-ink-900 to-brand-950 py-20 text-white">
        <div className="pointer-events-none absolute -right-24 -top-24 h-96 w-96 rounded-full bg-brand-500/25 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-32 -left-20 h-80 w-80 rounded-full bg-accent-500/10 blur-3xl" />
        <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top_left,rgba(255,255,255,0.06),transparent_55%)]" />
        <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center justify-between gap-8 rounded-3xl border border-white/10 bg-white/[0.03] px-6 py-10 text-center shadow-[inset_0_1px_0_rgba(255,255,255,0.08)] backdrop-blur-sm sm:px-10 lg:flex-row lg:text-left">
            <div>
              <span className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-wide text-brand-200 ring-1 ring-inset ring-white/15">
                <MapPinIcon className="h-3.5 w-3.5" /> Ready when you are
              </span>
              <h2 className="mt-3 text-2xl font-bold tracking-tight [text-wrap:balance] sm:text-3xl">Tell Us Where You're Going.</h2>
              <p className="mt-2 max-w-lg leading-relaxed text-ink-300">
                Explore available ride options and connect with participating transportation partners for your next
                outstation journey.
              </p>
            </div>
            <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
              <a href="#hero" className="w-full sm:w-auto">
                <Button size="lg" fullWidth className="shadow-[0_16px_32px_-8px_rgba(26,110,245,0.5)] transition-transform duration-200 hover:-translate-y-0.5">Find a Ride &rarr;</Button>
              </a>
              <a href="#popular-routes" className="w-full sm:w-auto">
                <Button variant="secondary" size="lg" fullWidth className="border-white/20 bg-white/10 text-white transition-transform duration-200 hover:-translate-y-0.5 hover:bg-white/15">Explore Routes &rarr;</Button>
              </a>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
