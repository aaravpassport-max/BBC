import { useEffect, useRef, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Button } from './Button';
import { useLatest } from '../../lib/useLatest';

interface ConfirmDialogProps {
  open: boolean;
  title: string;
  description?: ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  confirmVariant?: 'primary' | 'danger';
  loading?: boolean;
  confirmDisabled?: boolean;
  onConfirm: () => void;
  onCancel: () => void;
  children?: ReactNode;
}

const FOCUSABLE = 'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])';

export function ConfirmDialog({
  open,
  title,
  description,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  confirmVariant = 'primary',
  loading = false,
  confirmDisabled = false,
  onConfirm,
  onCancel,
  children,
}: ConfirmDialogProps) {
  const dialogRef = useRef<HTMLDivElement>(null);
  const previouslyFocused = useRef<HTMLElement | null>(null);
  // ROOT-CAUSE FIX (platform-wide popup typing bug): the effect below used to depend on `onCancel`. Callers pass inline arrows, so every keystroke in a form inside this dialog re-rendered the parent, re-ran the effect, restored focus to the opener and then focused the first control again: the cursor jumped and a space press hit a button and closed the popup. The callback now lives in a ref and the effect depends on `open` only.
  const onCancelRef = useLatest(onCancel);

  useEffect(() => {
    if (!open) return;
    previouslyFocused.current = document.activeElement as HTMLElement;
    const node = dialogRef.current;
    const focusable = node?.querySelectorAll<HTMLElement>(FOCUSABLE);
    focusable?.[0]?.focus({ preventScroll: true });

    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        onCancelRef.current();
        return;
      }
      if (e.key !== 'Tab' || !node) return;
      const items = Array.from(node.querySelectorAll<HTMLElement>(FOCUSABLE));
      if (items.length === 0) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      previouslyFocused.current?.focus();
    };
  }, [open, onCancelRef]);

  if (!open) return null;

  // ROOT-CAUSE FIX: this used to render inline (not portaled), so its
  // DOM node stayed wherever ConfirmDialog sits in the component tree —
  // typically early in <body>. Any OTHER portaled full-screen overlay
  // (e.g. BookingModalShell, or BottomSheet) appends itself to the END
  // of <body> via createPortal, so with both at the same z-50, plain
  // DOM order made the later-mounted portal paint on top, hiding this
  // dialog entirely (found live: the mobile booking modal's "discard
  // progress?" confirmation rendered fully in the DOM/accessibility
  // tree — screen readers would announce it — but was not visible on
  // screen, sitting behind the modal it was meant to interrupt).
  // Portaling to document.body, same as BottomSheet already does,
  // makes stacking order depend on mount order at the same level
  // instead of wherever the triggering component happens to live in
  // the tree — and since ConfirmDialog only ever mounts once `open` is
  // true (i.e. after whatever it's confirming-over), it now reliably
  // paints on top of it.
  return createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/50 p-4" role="presentation">
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="confirm-dialog-title"
        className="w-full max-w-md rounded-xl bg-white p-6 shadow-xl"
      >
        <h2 id="confirm-dialog-title" className="text-lg font-semibold text-ink-900">
          {title}
        </h2>
        {description && <div className="mt-2 text-sm text-ink-600">{description}</div>}
        {children && <div className="mt-4">{children}</div>}
        <div className="mt-6 flex flex-col-reverse gap-2 sm:flex-row sm:justify-end">
          <Button variant="secondary" onClick={onCancel} disabled={loading}>
            {cancelLabel}
          </Button>
          <Button
            variant={confirmVariant === 'danger' ? 'danger' : 'primary'}
            onClick={onConfirm}
            loading={loading}
            disabled={confirmDisabled}
          >
            {confirmLabel}
          </Button>
        </div>
      </div>
    </div>,
    document.body
  );
}
