import { Button } from './Button';

interface PaginationProps {
  page: number;
  pageCount: number;
  totalItems: number;
  pageSize: number;
  onPageChange: (page: number) => void;
}

/**
 * Root-cause fix (Master Issue Register: admin list screens with no
 * search/filter/pagination): several admin list screens loaded their
 * FULL dataset in one request and rendered every row with no way to
 * narrow or page through it — usable at a handful of rows, unusable
 * once real data volume (80+ cities, dozens of team members/regions)
 * accumulated. Rather than re-solve pagination differently per screen,
 * this is the one shared control every affected screen renders against
 * its own already-filtered, already-loaded array (client-side paging —
 * these lists are already fetched whole; there is no need for a second
 * network round-trip just to turn a page). Hidden entirely when
 * everything fits on one page, so it never adds visual noise to a
 * screen with few rows.
 */
export function Pagination({ page, pageCount, totalItems, pageSize, onPageChange }: PaginationProps) {
  if (pageCount <= 1) return null;
  const start = (page - 1) * pageSize + 1;
  const end = Math.min(totalItems, page * pageSize);
  return (
    <nav aria-label="Pagination" className="mt-4 flex flex-wrap items-center justify-between gap-3 text-sm text-ink-600">
      <p>
        Showing {start}&ndash;{end} of {totalItems}
      </p>
      <div className="flex items-center gap-2">
        <Button type="button" size="sm" variant="secondary" onClick={() => onPageChange(page - 1)} disabled={page <= 1}>
          Previous
        </Button>
        <span aria-current="page" className="px-1">
          Page {page} of {pageCount}
        </span>
        <Button type="button" size="sm" variant="secondary" onClick={() => onPageChange(page + 1)} disabled={page >= pageCount}>
          Next
        </Button>
      </div>
    </nav>
  );
}

/** Slices `items` to the given page (1-indexed), clamping page into range. */
export function paginate<T>(items: T[], page: number, pageSize: number): { pageItems: T[]; pageCount: number; page: number } {
  const pageCount = Math.max(1, Math.ceil(items.length / pageSize));
  const clamped = Math.min(Math.max(1, page), pageCount);
  const startIdx = (clamped - 1) * pageSize;
  return { pageItems: items.slice(startIdx, startIdx + pageSize), pageCount, page: clamped };
}
