import type { ReactNode, HTMLAttributes, ComponentType } from 'react';

/**
 * Shared "section zone" + card vocabulary, extracted from the HomePage /
 * RoutePage visual system so every page references one definition instead of
 * repeating the same className strings.
 *
 * Zones: alternating section-level backgrounds so no two stacked sections
 * share the same tint. Cards: two shadow/radius treatments by content role —
 * DataCard for dense/info panels, ShowcaseCard for presentational content.
 */

export type ZoneTone = 'white' | 'brand-50' | 'ink-50' | 'accent-50' | 'dark';

const ZONE_CLASSES: Record<ZoneTone, string> = {
  white: 'bg-white',
  'brand-50': 'bg-brand-50',
  'ink-50': 'bg-ink-50',
  'accent-50': 'bg-accent-50',
  dark: 'bg-gradient-to-br from-brand-900 via-brand-950 to-ink-950 text-white',
};

/** Cycle through the light tones for pages that just need N alternating panels. */
export const ZONE_CYCLE: ZoneTone[] = ['white', 'ink-50', 'brand-50', 'accent-50'];

export function zoneTone(index: number): ZoneTone {
  return ZONE_CYCLE[index % ZONE_CYCLE.length];
}

interface SectionZoneProps extends HTMLAttributes<HTMLElement> {
  tone: ZoneTone;
  children: ReactNode;
  /** Set false to render the raw section without the standard max-width container. */
  contained?: boolean;
}

export function SectionZone({ tone, children, className = '', contained = true, ...rest }: SectionZoneProps) {
  return (
    <section className={`${ZONE_CLASSES[tone]} ${className}`} {...rest}>
      {contained ? <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">{children}</div> : children}
    </section>
  );
}

/** Dense/info panel treatment: tight radius, inset ring, clearly visible resting shadow. */
export const DATA_CARD_CLASS = 'rounded-lg bg-white shadow-card-rest ring-1 ring-inset ring-ink-100';

export function DataCard({ children, className = '', ...rest }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={`${DATA_CARD_CLASS} ${className}`} {...rest}>
      {children}
    </div>
  );
}

/** Showcase/interactive treatment: generous radius, clearly raised at rest, deeper on hover. */
export const SHOWCASE_CARD_CLASS =
  'rounded-2xl bg-white shadow-card-rest ring-1 ring-ink-100/60 transition hover:-translate-y-1 hover:shadow-card-hover';

export function ShowcaseCard({ children, className = '', ...rest }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={`${SHOWCASE_CARD_CLASS} ${className}`} {...rest}>
      {children}
    </div>
  );
}

/**
 * Small rounded "eyebrow" label used above section headings — a tinted pill
 * badge (optional leading icon) instead of plain uppercase text, using only
 * the project's existing brand/accent tint tokens.
 */
export type EyebrowTone = 'brand' | 'accent';

const EYEBROW_TONE_CLASSES: Record<EyebrowTone, string> = {
  brand: 'bg-brand-50 text-brand-700 ring-brand-100',
  accent: 'bg-accent-50 text-accent-700 ring-accent-200/70',
};

interface EyebrowProps {
  children: ReactNode;
  icon?: ComponentType<{ className?: string }>;
  tone?: EyebrowTone;
  className?: string;
}

export function Eyebrow({ children, icon: Icon, tone = 'brand', className = '' }: EyebrowProps) {
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold uppercase tracking-wide ring-1 ring-inset ${EYEBROW_TONE_CLASSES[tone]} ${className}`}
    >
      {Icon && <Icon className="h-3.5 w-3.5" />}
      {children}
    </span>
  );
}

/**
 * Cycles through the project's own accent/brand/ink tint pairs so an icon
 * grid reads as distinct colorful tiles rather than one flat repeated tone —
 * no new hex values, just existing tokens in rotation.
 */
export const ICON_TILE_TONES = [
  'bg-gradient-to-br from-brand-500 to-brand-700 text-white shadow-tile-rest ring-1 ring-inset ring-white/20',
  'bg-gradient-to-br from-accent-400 to-accent-600 text-white shadow-tile-rest ring-1 ring-inset ring-white/20',
  'bg-gradient-to-br from-success-500 to-success-600 text-white shadow-tile-rest ring-1 ring-inset ring-white/20',
  'bg-gradient-to-br from-warning-500 to-warning-600 text-white shadow-tile-rest ring-1 ring-inset ring-white/20',
  'bg-gradient-to-br from-ink-700 to-ink-900 text-white shadow-tile-rest ring-1 ring-inset ring-white/10',
  'bg-gradient-to-br from-brand-600 to-brand-800 text-white shadow-tile-rest ring-1 ring-inset ring-white/20',
];

export function iconTileTone(index: number): string {
  return ICON_TILE_TONES[index % ICON_TILE_TONES.length];
}
