export function ErrorBanner({
  message,
  onRetry,
}: {
  message: string;
  onRetry?: () => void;
}) {
  return (
    <div
      role="alert"
      className="flex flex-col gap-3 rounded-lg border border-danger-500/30 bg-danger-50 p-4 text-sm text-danger-600 sm:flex-row sm:items-center sm:justify-between"
    >
      <div className="flex items-start gap-2">
        <svg className="mt-0.5 h-5 w-5 shrink-0" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
          <path
            fillRule="evenodd"
            d="M8.257 3.099c.765-1.36 2.72-1.36 3.486 0l6.28 11.18c.75 1.334-.213 2.98-1.743 2.98H3.72c-1.53 0-2.493-1.646-1.743-2.98l6.28-11.18zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-7a1 1 0 00-1 1v3a1 1 0 002 0V7a1 1 0 00-1-1z"
            clipRule="evenodd"
          />
        </svg>
        <span>{message}</span>
      </div>
      {onRetry && (
        <button
          type="button"
          onClick={onRetry}
          className="shrink-0 self-start rounded-md border border-danger-500/40 bg-white px-3 py-1.5 text-sm font-medium text-danger-600 shadow-xs transition hover:bg-danger-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-danger-500 sm:self-auto"
        >
          Try again
        </button>
      )}
    </div>
  );
}
