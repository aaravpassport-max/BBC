import { useEffect, useRef, useState, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { useLatest } from '../../lib/useLatest';

/**
 * Mobile-first transformation, Phase 2: the app's first reusable bottom
 * sheet — the audit found zero bottom-sheet/drawer primitives existed
 * anywhere (ConfirmDialog was the only modal-like component, and it's a
 * desktop-centered dialog). Per brief item 12, this is for filters,
 * sort options, and action/context menus — ConfirmDialog stays as-is for
 * yes/no confirmations, which read better as a centered dialog even on
 * mobile.
 *
 * Behavior:
 * - Slides up from the bottom on mobile, becomes a centered dialog at
 *   `lg` (a bottom sheet reads as an odd, oversized dropdown on a wide
 *   desktop viewport).
 * - Backdrop click, Escape, and a close button all dismiss it.
 * - Real focus trap (same pattern as ConfirmDialog) and focus restore.
 * - Background scroll is locked while open.
 * - Internal content scrolls independently once it exceeds the sheet's
 *   max height, so a long list (e.g. a sort-options list) never pushes
 *   the close affordance off-screen.
 * - Respects `prefers-reduced-motion` via Tailwind's built-in
 *   `motion-reduce:` variant — the sheet still opens/closes, just
 *   without the slide/fade.
 */

interface BottomSheetProps {
  open: boolean;
  title?: string;
  onClose: () => void;
  children: ReactNode;
}

const FOCUSABLE = 'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])';

export function BottomSheet({ open, title, onClose, children }: BottomSheetProps) {
  const sheetRef = useRef<HTMLDivElement>(null);
  const previouslyFocused = useRef<HTMLElement | null>(null);
  const [mounted, setMounted] = useState(false);
  const [entered, setEntered] = useState(false);
  // ROOT-CAUSE FIX: see ConfirmDialog. The focus/keydown effect must not depend on the onClose prop, which is a fresh inline arrow on every parent render.
  const onCloseRef = useLatest(onClose);

  useEffect(() => {
    if (open) {
      setMounted(true);
      const raf = requestAnimationFrame(() => setEntered(true));
      return () => cancelAnimationFrame(raf);
    }
    setEntered(false);
    const t = window.setTimeout(() => setMounted(false), 220);
    return () => window.clearTimeout(t);
  }, [open]);

  useEffect(() => {
    // `sheetRef` is only attached once `mounted` flips true and the dialog
    // actually renders (it's `null` before that, per the early return
    // below) — this effect must depend on `mounted` too, or it fires once
    // on the render where `open` first becomes true, closes over
    // `sheetRef.current === null`, and the Tab handler it installs then
    // traps nothing for the sheet's whole lifetime. Found live: opening
    // Header's mobile drawer let Tab walk straight through to the page
    // behind it instead of cycling the sheet's own controls.
    if (!open || !mounted) return;
    previouslyFocused.current = document.activeElement as HTMLElement;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const node = sheetRef.current;
    const focusable = node?.querySelectorAll<HTMLElement>(FOCUSABLE);
    // preventScroll: without it, focusing an element far down the sheet's
    // (possibly long) content list makes the browser scroll it into view —
    // which, because this sheet is position:fixed, visually scrolls the
    // underlying page instead and leaves the sheet's own header clipped
    // above the viewport. Found during this phase's live verification.
    focusable?.[0]?.focus({ preventScroll: true });

    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        onCloseRef.current();
        return;
      }
      if (e.key !== 'Tab' || !node) return;
      const items = Array.from(node.querySelectorAll<HTMLElement>(FOCUSABLE));
      if (items.length === 0) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.body.style.overflow = prevOverflow;
      previouslyFocused.current?.focus();
    };
  }, [open, mounted, onCloseRef]);

  if (!mounted) return null;

  // Rendered via portal, not inline: BottomSheet is used from Header,
  // which is itself `position: sticky` — and a sticky ancestor becomes
  // the containing block for a `position: fixed` descendant in current
  // browser implementations, so an inline fixed sheet was being pinned
  // to the header's own small box instead of the viewport (found live,
  // via a getBoundingClientRect check, during this phase's verification
  // pass: the sheet's outer container measured 64px tall — the header's
  // height — instead of the full viewport). Portaling to document.body
  // sidesteps any future ancestor from doing the same.
  return createPortal(
    <div className="fixed inset-0 z-50 flex items-end justify-center lg:items-center" role="presentation">
      <div
        className={`absolute inset-0 bg-ink-950/50 transition-opacity duration-200 motion-reduce:transition-none ${
          entered ? 'opacity-100' : 'opacity-0'
        }`}
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        ref={sheetRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby={title ? 'bottom-sheet-title' : undefined}
        className={`relative flex max-h-[85vh] w-full flex-col rounded-t-2xl bg-white shadow-xl transition-transform duration-200 motion-reduce:transition-none lg:max-h-[80vh] lg:w-full lg:max-w-md lg:rounded-2xl ${
          entered ? 'translate-y-0' : 'translate-y-full lg:translate-y-4 lg:opacity-0'
        }`}
        style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
      >
        <div className="flex items-center justify-center pt-2.5 lg:hidden">
          <span className="h-1 w-10 rounded-full bg-ink-200" aria-hidden="true" />
        </div>
        <div className="flex items-center justify-between px-5 pb-2 pt-3 lg:pt-5">
          {title ? (
            <h2 id="bottom-sheet-title" className="text-base font-semibold text-ink-900">
              {title}
            </h2>
          ) : (
            <span />
          )}
          <button
            type="button"
            onClick={onClose}
            aria-label="Close"
            className="rounded-full p-1.5 text-ink-500 hover:bg-ink-50 hover:text-ink-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
          >
            <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="flex-1 overflow-y-auto px-5 pb-5">{children}</div>
      </div>
    </div>,
    document.body
  );
}
