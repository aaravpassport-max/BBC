import { useEffect, useRef, type ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Button } from './Button';

interface SuccessDialogProps {
  open: boolean;
  title: string;
  description?: ReactNode;
  /** Extra content below the description — e.g. a countdown line. */
  children?: ReactNode;
  actionLabel?: string;
  onAction?: () => void;
  /** Hides the action button entirely (used for the transient auto-login/countdown stage, which redirects on its own). */
  hideAction?: boolean;
}

/**
 * Success/confirmation popup, styled to match ConfirmDialog (same
 * overlay, card, shadow and portal-to-body pattern — see that
 * component's doc comment for why it must be portaled) but for
 * "this succeeded" moments rather than a yes/no confirmation: booking
 * submitted, payment proof submitted, and the auto-login/countdown
 * step in between payment-proof success and the dashboard redirect.
 * One shared component so all three stages of the flow look and feel
 * like the same product moment.
 */
export function SuccessDialog({ open, title, description, children, actionLabel = 'Continue', onAction, hideAction }: SuccessDialogProps) {
  const dialogRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    dialogRef.current?.focus({ preventScroll: true });
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape' && onAction) onAction();
    }
    document.addEventListener('keydown', onKeyDown);
    return () => document.removeEventListener('keydown', onKeyDown);
  }, [open, onAction]);

  if (!open) return null;

  return createPortal(
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-ink-950/50 p-4" role="presentation">
      <div
        ref={dialogRef}
        tabIndex={-1}
        role="alertdialog"
        aria-modal="true"
        aria-labelledby="success-dialog-title"
        className="w-full max-w-md rounded-xl bg-white p-6 text-center shadow-xl outline-none"
      >
        <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-success-50">
          <svg className="h-8 w-8 text-success-600" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
            <path
              fillRule="evenodd"
              d="M16.704 5.29a1 1 0 010 1.42l-7.25 7.25a1 1 0 01-1.42 0l-3.25-3.25a1 1 0 111.42-1.42l2.54 2.54 6.54-6.54a1 1 0 011.42 0z"
              clipRule="evenodd"
            />
          </svg>
        </div>
        <h2 id="success-dialog-title" className="mt-4 text-lg font-bold text-ink-900">
          {title}
        </h2>
        {description && <div className="mt-2 text-sm leading-relaxed text-ink-600">{description}</div>}
        {children && <div className="mt-4">{children}</div>}
        {!hideAction && (
          <div className="mt-6">
            <Button fullWidth size="lg" onClick={onAction}>
              {actionLabel}
            </Button>
          </div>
        )}
      </div>
    </div>,
    document.body
  );
}
