import { useToast, type ToastVariant } from '../../context/ToastContext';

const VARIANT_STYLES: Record<ToastVariant, string> = {
  success: 'border-success-500/30 bg-white text-ink-900',
  error: 'border-danger-500/30 bg-white text-ink-900',
  info: 'border-ink-200 bg-white text-ink-900',
};

const VARIANT_DOT: Record<ToastVariant, string> = {
  success: 'bg-success-500',
  error: 'bg-danger-500',
  info: 'bg-brand-500',
};

/**
 * Mounted once in AppLayout. Positioned above the mobile bottom nav
 * (bottom-20) and above the desktop footer edge, centered on mobile and
 * bottom-right on wider screens — the conventional split between an
 * app-like toast placement and a desktop "snackbar" placement.
 */
export function ToastViewport() {
  const { toasts, dismiss } = useToast();
  if (toasts.length === 0) return null;

  return (
    <div
      className="pointer-events-none fixed inset-x-0 bottom-[calc(4.5rem+env(safe-area-inset-bottom,0px))] z-50 flex flex-col items-center gap-2 px-4 lg:bottom-6 lg:items-end lg:px-6"
      aria-live="polite"
      aria-atomic="true"
    >
      {toasts.map((t) => (
        <div
          key={t.id}
          role="status"
          className={`pointer-events-auto flex w-full max-w-sm items-start gap-2.5 rounded-xl border px-4 py-3 shadow-lg ${VARIANT_STYLES[t.variant]}`}
        >
          <span className={`mt-1.5 h-2 w-2 flex-shrink-0 rounded-full ${VARIANT_DOT[t.variant]}`} aria-hidden="true" />
          <p className="flex-1 text-sm font-medium">{t.message}</p>
          <button
            type="button"
            onClick={() => dismiss(t.id)}
            aria-label="Dismiss"
            className="flex-shrink-0 rounded p-0.5 text-ink-400 hover:text-ink-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
          >
            <svg className="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      ))}
    </div>
  );
}
