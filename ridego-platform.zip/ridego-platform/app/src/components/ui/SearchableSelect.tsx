import { useEffect, useId, useMemo, useRef, useState } from 'react';

export interface SearchableSelectOption {
  value: string;
  label: string;
  /** Extra text searched but not necessarily shown as the main label (e.g. phone, city). */
  searchText?: string;
  description?: string;
  disabled?: boolean;
}

interface SearchableSelectProps {
  id?: string;
  value: string;
  onChange: (value: string) => void;
  options: SearchableSelectOption[];
  placeholder?: string;
  emptyOptionLabel?: string;
  disabled?: boolean;
  'aria-label'?: string;
}

/**
 * Root-cause fix (Master Issue Register): the admin booking desk's vendor
 * picker was a plain <select> rendering all ~494 vendors as a flat,
 * unsearchable option list — the only way to find one was scrolling and
 * reading every name. A native <select> has no search affordance at all,
 * so the fix is a real combobox: a text input filters the option list
 * live (by label AND any extra searchText, e.g. phone/city), arrow
 * keys/Enter/Escape work, and the value contract stays identical to a
 * <select> (a plain string value + onChange(value)) so it drops into any
 * existing "" = unset / string id pattern without changing callers'
 * state shape. Built generically (not vendor-specific) so the same
 * defect elsewhere — any long, unsearchable admin <select> — can reuse
 * it directly rather than re-solving this per screen.
 */
export function SearchableSelect({
  id,
  value,
  onChange,
  options,
  placeholder = 'Search…',
  emptyOptionLabel = 'None',
  disabled,
  'aria-label': ariaLabel,
}: SearchableSelectProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [highlight, setHighlight] = useState(0);
  const rootRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  const listboxId = useId();

  const selected = options.find((o) => o.value === value) ?? null;

  // Keep the visible text in sync with the selected option whenever the
  // dropdown is closed (so a parent-driven value change, e.g. resetting
  // the form, is reflected without fighting the user's own typing while open).
  useEffect(() => {
    if (!open) setQuery(selected ? selected.label : '');
  }, [selected, open]);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q || (selected && query === selected.label)) return options;
    return options.filter((o) => `${o.label} ${o.searchText ?? ''}`.toLowerCase().includes(q));
  }, [options, query, selected]);

  useEffect(() => {
    if (!open) return;
    function onDocClick(e: MouseEvent) {
      if (rootRef.current && !rootRef.current.contains(e.target as Node)) {
        setOpen(false);
        setQuery(selected ? selected.label : '');
      }
    }
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, [open, selected]);

  function choose(opt: SearchableSelectOption | null) {
    onChange(opt ? opt.value : '');
    setOpen(false);
    setQuery(opt ? opt.label : '');
    inputRef.current?.blur();
  }

  function onKeyDown(e: React.KeyboardEvent) {
    if (disabled) return;
    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (!open) { setOpen(true); return; }
      setHighlight((h) => Math.min(filtered.length - 1, h + 1));
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setHighlight((h) => Math.max(0, h - 1));
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (open && filtered[highlight]) choose(filtered[highlight]);
    } else if (e.key === 'Escape') {
      setOpen(false);
      setQuery(selected ? selected.label : '');
    }
  }

  return (
    <div ref={rootRef} className="relative">
      <input
        ref={inputRef}
        id={id}
        role="combobox"
        aria-expanded={open}
        aria-controls={listboxId}
        aria-autocomplete="list"
        aria-label={ariaLabel}
        className="w-full rounded-lg border border-ink-200 bg-white px-3.5 py-2.5 text-sm text-ink-900 shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30 disabled:bg-ink-50 disabled:text-ink-400"
        placeholder={placeholder}
        value={query}
        disabled={disabled}
        onFocus={() => { setOpen(true); setHighlight(0); }}
        onChange={(e) => { setQuery(e.target.value); setOpen(true); setHighlight(0); }}
        onKeyDown={onKeyDown}
        autoComplete="off"
      />
      {open && !disabled && (
        <ul
          id={listboxId}
          role="listbox"
          className="absolute z-20 mt-1 max-h-64 w-full overflow-y-auto rounded-lg border border-ink-200 bg-white py-1 shadow-lg"
        >
          <li role="option" aria-selected={!value}>
            <button
              type="button"
              className={`block w-full px-3 py-2 text-left text-sm hover:bg-brand-50 ${!value ? 'font-semibold text-brand-700' : 'text-ink-700'}`}
              onClick={() => choose(null)}
            >
              {emptyOptionLabel}
            </button>
          </li>
          {filtered.length === 0 && <li className="px-3 py-2 text-sm text-ink-500">No matches.</li>}
          {filtered.map((o, i) => (
            <li key={o.value} role="option" aria-selected={o.value === value}>
              <button
                type="button"
                disabled={o.disabled}
                className={`block w-full px-3 py-2 text-left text-sm disabled:cursor-not-allowed disabled:text-ink-300 ${
                  i === highlight ? 'bg-brand-50' : 'hover:bg-brand-50'
                } ${o.value === value ? 'font-semibold text-brand-700' : 'text-ink-800'}`}
                onMouseEnter={() => setHighlight(i)}
                onClick={() => !o.disabled && choose(o)}
              >
                {o.label}
                {o.description && <span className="block text-xs text-ink-500">{o.description}</span>}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
