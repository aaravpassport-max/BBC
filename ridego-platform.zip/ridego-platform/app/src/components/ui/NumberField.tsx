import { useEffect, useState, type InputHTMLAttributes } from 'react';

type Props = Omit<InputHTMLAttributes<HTMLInputElement>, 'value' | 'onChange' | 'type'> & {
  value: number;
  onValue: (n: number) => void;
  integer?: boolean;
};

// TRACE: numeric form field → keeps the text the user is typing in local state and reports the parsed number upward →
//        input never snaps to "0" while editing. Preconditions: value is the parent's number. Postconditions: clearing the field
//        shows an empty box (placeholder 0) and reports 0; typing "5" after clearing gives "5" not "05"; an external change of
//        value (form reset, edit of another row) refreshes the text. Edge cases: "1." and "-" mid-typing (kept as typed, reported
//        as the parsed prefix or 0), integer mode truncates decimals in the reported value only.
export function NumberField({ value, onValue, integer = false, placeholder = '0', ...rest }: Props) {
  const parse = (t: string) => {
    const n = integer ? parseInt(t, 10) : parseFloat(t);
    return Number.isFinite(n) ? n : 0;
  };
  const [draft, setDraft] = useState(value === 0 ? '' : String(value));
  useEffect(() => {
    setDraft((d) => (parse(d) === value ? d : value === 0 ? '' : String(value)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);
  return (
    <input
      {...rest}
      type="number"
      inputMode={integer ? 'numeric' : 'decimal'}
      placeholder={placeholder}
      value={draft}
      onChange={(e) => {
        setDraft(e.target.value);
        onValue(parse(e.target.value));
      }}
    />
  );
}
