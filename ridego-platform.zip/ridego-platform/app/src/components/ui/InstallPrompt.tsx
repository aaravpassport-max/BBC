import { useEffect, useState } from 'react';
import { brand } from '../../lib/brand';

/**
 * Mobile-first transformation, Phase 4: a lightweight "Add to Home
 * Screen" prompt. Chrome/Android fires `beforeinstallprompt` and, by
 * default, shows its own generic mini-infobar — this instead defers
 * that browser prompt (`event.preventDefault()`) and surfaces it as a
 * small on-brand banner the user can dismiss, matching the rest of the
 * app's own UI language instead of a bare browser chrome element.
 *
 * Dismissal is remembered for the session only (a plain module-level
 * flag, not localStorage — see the workspace rule against relying on
 * browser storage for anything that must be read back reliably): if the
 * user dismisses it, it won't re-appear until they reload, which is
 * enough to avoid nagging without pretending to remember across visits
 * on a rule this app doesn't otherwise need to guarantee.
 */

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

let dismissedThisSession = false;

export function InstallPrompt() {
  const [deferredEvent, setDeferredEvent] = useState<BeforeInstallPromptEvent | null>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (dismissedThisSession) return;
    function onBeforeInstallPrompt(e: Event) {
      e.preventDefault();
      setDeferredEvent(e as BeforeInstallPromptEvent);
      setVisible(true);
    }
    window.addEventListener('beforeinstallprompt', onBeforeInstallPrompt);
    function onInstalled() {
      setVisible(false);
      setDeferredEvent(null);
    }
    window.addEventListener('appinstalled', onInstalled);
    return () => {
      window.removeEventListener('beforeinstallprompt', onBeforeInstallPrompt);
      window.removeEventListener('appinstalled', onInstalled);
    };
  }, []);

  function dismiss() {
    dismissedThisSession = true;
    setVisible(false);
  }

  async function install() {
    if (!deferredEvent) return;
    await deferredEvent.prompt();
    await deferredEvent.userChoice;
    setVisible(false);
    setDeferredEvent(null);
  }

  if (!visible || !deferredEvent) return null;

  return (
    <div
      role="region"
      aria-label={`Install ${brand().name}`}
      className="fixed inset-x-0 bottom-16 z-30 mx-auto flex max-w-md items-center gap-3 border-t border-brand-100 bg-white px-4 py-3 shadow-lg lg:bottom-4 lg:left-4 lg:right-auto lg:rounded-xl lg:border"
      style={{ paddingBottom: 'max(0.75rem, env(safe-area-inset-bottom, 0px))' }}
    >
      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-lg bg-brand-600 text-sm font-bold text-white">
        R
      </span>
      <div className="min-w-0 flex-1">
        <p className="text-sm font-semibold text-ink-900">Install {brand().name}</p>
        <p className="text-xs text-ink-500">Add it to your home screen for quicker access.</p>
      </div>
      <button
        type="button"
        onClick={dismiss}
        className="rounded-md px-2 py-1.5 text-xs font-medium text-ink-500 hover:bg-ink-50"
      >
        Not now
      </button>
      <button
        type="button"
        onClick={install}
        className="shrink-0 rounded-lg bg-brand-600 px-3 py-1.5 text-xs font-semibold text-white hover:bg-brand-700"
      >
        Install
      </button>
    </div>
  );
}
