import { useState, type FormEvent, type ReactElement } from 'react';
import { useNavigate } from 'react-router-dom';
import type { City, FareResponse, Vehicle } from '../../types/api';
import { getFare, ApiError } from '../../lib/api';
import { Button } from '../ui/Button';

function PinIcon({ className }: { className?: string }): ReactElement {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 21s-6.5-5.7-6.5-11a6.5 6.5 0 0113 0c0 5.3-6.5 11-6.5 11z" />
      <circle cx="12" cy="10" r="2.2" />
    </svg>
  );
}
function CarFieldIcon({ className }: { className?: string }): ReactElement {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M5 11l1.5-4.5A2 2 0 018.4 5h7.2a2 2 0 011.9 1.5L19 11m-14 0h14m-14 0a1.5 1.5 0 00-1.5 1.5V16a1 1 0 001 1h1a1 1 0 001-1v-1h11v1a1 1 0 001 1h1a1 1 0 001-1v-3.5A1.5 1.5 0 0019 11" />
    </svg>
  );
}
function CalendarFieldIcon({ className }: { className?: string }): ReactElement {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <rect x="4" y="5.5" width="16" height="15" rx="2" />
      <path strokeLinecap="round" d="M8 3.5v4M16 3.5v4M4 10h16" />
    </svg>
  );
}
function ChevronRightIcon({ className }: { className?: string }): ReactElement {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
    </svg>
  );
}
function CompareIcon({ className }: { className?: string }): ReactElement {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M7 4v13M7 17l-3-3M7 17l3-3M17 20V7M17 7l3 3M17 7l-3 3" />
    </svg>
  );
}
function InfoIcon({ className }: { className?: string }): ReactElement {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <circle cx="12" cy="12" r="9" />
      <path strokeLinecap="round" d="M12 11v5M12 8h.01" />
    </svg>
  );
}
function SwapIcon({ className }: { className?: string }): ReactElement {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.75" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M7 16V4m0 0L3 8m4-4l4 4m6 4v12m0 0l4-4m-4 4l-4-4" />
    </svg>
  );
}

/**
 * Root-cause fix: 'hourly' was never a trip_type the backend pricing
 * engine recognized (see includes/pricing.php's ridego_calculate_fare()
 * switch) — only 'local' is. Sending 'hourly' silently fell through to
 * one_way per-km pricing. Using the real backend value here directly.
 */
const TRIP_TYPES: { value: string; label: string }[] = [
  { value: 'one_way', label: 'One way' },
  { value: 'round_trip', label: 'Round trip' },
  { value: 'local', label: 'Hourly rental' },
];

function todayStr() {
  return new Date().toISOString().slice(0, 10);
}

// TRACE: HomePage passes role-specific city lists → widget renders pickup options from originCities and drop
//        options from destinationCities (each falls back to `cities` when the API omits it) → selects list exactly
//        the cities enabled for that role. Edge cases: empty list renders only the placeholder option.
export function FareSearchWidget({
  cities,
  originCities,
  destinationCities,
  vehicles,
  initialVehicleId,
  initialPickup,
  initialDrop,
  embedded,
  layout,
  onSubmitOverride,
}: {
  cities: City[];
  originCities?: City[];
  destinationCities?: City[];
  vehicles: Vehicle[];
  /** Preselects the vehicle dropdown (e.g. when this widget is embedded on
   * that vehicle's own detail page) without changing behavior anywhere the
   * prop is omitted, such as the home page's widget. */
  initialVehicleId?: number;
  /** Preselects pickup/drop city (e.g. a route landing page pre-filling its
   * own real origin/destination) without changing behavior anywhere the
   * prop is omitted, such as the home page's widget. Matched against the
   * real city name string the <select> already uses. */
  initialPickup?: string;
  initialDrop?: string;
  /** When true, the widget renders without its own outer card chrome
   * (background/padding/shadow) so a parent panel — e.g. the Vehicle
   * Details page's booking-engine card — can own that chrome instead.
   * Optional and defaults to false, so HomePage's usage is unaffected. */
  embedded?: boolean;
  /** 'inline' renders the same real pickup/drop/trip-type/date fields as a
   * single horizontal row with a swap control, for panels that overlap a
   * hero image (route landing pages). It does not duplicate any logic —
   * same state, same real city/vehicle data — it only rearranges markup
   * and, since there is no vehicle field in that compact row, its submit
   * goes straight to the search/compare results (same as the "compare all
   * vehicle types" action below) instead of calling getFare. Optional;
   * omitted (or 'card') keeps the existing stacked layout untouched. */
  layout?: 'card' | 'inline';
  /** When provided, the widget's own submit/"Book this route" action calls
   * this with the real form values instead of navigating away — used when
   * the widget is embedded inside a page (e.g. a route landing page) that
   * owns an in-place booking modal. Omitted (the default) preserves the
   * existing navigate-to-/app/search or /app/book behavior everywhere else
   * (HomePage, VehicleDetailPage). */
  onSubmitOverride?: (params: { tripType: string; pickup: string; drop: string; date: string }) => void;
}) {
  const pickupOptions = originCities ?? cities;
  const dropOptions = destinationCities ?? cities;
  const navigate = useNavigate();
  const [tripType, setTripType] = useState('one_way');
  const [pickup, setPickup] = useState(initialPickup ?? '');
  const [drop, setDrop] = useState(initialDrop ?? '');
  const [vehicleId, setVehicleId] = useState<number | ''>(initialVehicleId ?? '');
  const [date, setDate] = useState(todayStr());
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<FareResponse | null>(null);

  function swapCities() {
    setPickup(drop);
    setDrop(pickup);
  }

  const labelClassesShared = 'block text-[11px] font-semibold uppercase tracking-wide text-ink-500';

  if (layout === 'inline') {
    const inlineInputClasses =
      'h-11 w-full rounded-[10px] border border-ink-200 bg-white pl-9 pr-3 text-[13px] text-ink-900 shadow-xs transition-colors focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30';
    return (
      <div>
        <div className="flex flex-col gap-3 lg:flex-row lg:items-end">
          <div className="flex flex-1 flex-col gap-3 sm:flex-row sm:items-center">
            <div className="flex-1">
              <label htmlFor="il-pickup" className={labelClassesShared}>
                From
              </label>
              <div className="relative mt-1">
                <PinIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-brand-500" />
                <select id="il-pickup" value={pickup} onChange={(e) => setPickup(e.target.value)} className={inlineInputClasses}>
                  <option value="">Select city</option>
                  {pickupOptions.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
            <button
              type="button"
              onClick={swapCities}
              aria-label="Swap pickup and drop cities"
              className="mx-auto flex h-8 w-8 shrink-0 items-center justify-center rounded-full border border-ink-200 bg-white text-brand-600 shadow-xs hover:bg-brand-50 sm:mt-5"
            >
              <SwapIcon className="h-4 w-4" />
            </button>
            <div className="flex-1">
              <label htmlFor="il-drop" className={labelClassesShared}>
                To
              </label>
              <div className="relative mt-1">
                <PinIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-brand-500" />
                <select id="il-drop" value={drop} onChange={(e) => setDrop(e.target.value)} className={inlineInputClasses}>
                  <option value="">Select city</option>
                  {dropOptions.map((c) => (
                    <option key={c.id} value={c.name}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          <div className="flex flex-1 flex-col gap-3 sm:flex-row sm:items-center">
            <div className="flex-1">
              <label htmlFor="il-trip-type" className={labelClassesShared}>
                Trip type
              </label>
              <select
                id="il-trip-type"
                value={tripType}
                onChange={(e) => setTripType(e.target.value)}
                className="mt-1 h-11 w-full rounded-[10px] border border-ink-200 bg-white px-3 text-[13px] text-ink-900 shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
              >
                {TRIP_TYPES.map((t) => (
                  <option key={t.value} value={t.value}>
                    {t.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex-1">
              <label htmlFor="il-date" className={labelClassesShared}>
                Travel date
              </label>
              <div className="relative mt-1">
                <CalendarFieldIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-brand-500" />
                <input
                  id="il-date"
                  type="date"
                  min={todayStr()}
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  className={inlineInputClasses}
                />
              </div>
            </div>
            <Button
              type="button"
              disabled={!pickup || !drop}
              onClick={() =>
                onSubmitOverride
                  ? onSubmitOverride({ tripType, pickup, drop, date })
                  : navigate('/search', { state: { tripType, pickup, drop, date } })
              }
              className="h-11 shrink-0 gap-1.5 whitespace-nowrap rounded-[10px] px-5 text-sm font-bold"
            >
              Book this route <ChevronRightIcon className="h-4 w-4" />
            </Button>
          </div>
        </div>
        <p className="mt-3 flex items-start gap-1.5 text-xs text-ink-500">
          <InfoIcon className="mt-0.5 h-3.5 w-3.5 shrink-0 text-ink-400" />
          Actual travel time and fare may vary based on real-time traffic and road conditions.
        </p>
      </div>
    );
  }

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    setResult(null);

    if (!pickup || !drop || !vehicleId) {
      setError('Please choose a pickup city, drop city and vehicle.');
      return;
    }
    if (pickup === drop) {
      setError('Pickup and drop city cannot be the same.');
      return;
    }

    setSubmitting(true);
    try {
      const res = await getFare({
        trip_type: tripType,
        pickup_city: pickup,
        drop_city: drop,
        vehicle_type_id: Number(vehicleId),
        journey_date: date,
        journey_time: '08:00',
        distance_km: 0,
        duration_minutes: 0,
        hours_required: 4,
        return_date: '',
        passengers: 1,
        promo_code: '',
      });
      setResult(res);
    } catch (err) {
      setError(err instanceof ApiError ? err.message : 'Could not calculate a fare estimate right now.');
    } finally {
      setSubmitting(false);
    }
  }

  const inputClasses =
    'h-12 w-full rounded-[10px] border border-ink-200 bg-white px-3 text-[13px] text-ink-900 shadow-xs transition-colors focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30';
  const labelClasses = 'block text-[11px] font-semibold uppercase tracking-wide text-ink-500';

  return (
    <div className={embedded ? '' : 'rounded-2xl bg-white p-5 shadow-xl sm:p-6'}>
      <div className="mb-3 flex gap-1 rounded-[10px] bg-ink-50 p-1" role="tablist" aria-label="Trip type">
        {TRIP_TYPES.map((t) => (
          <button
            key={t.value}
            type="button"
            role="tab"
            aria-selected={tripType === t.value}
            onClick={() => setTripType(t.value)}
            className={`h-11 flex-1 rounded-lg text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 ${
              tripType === t.value ? 'bg-brand-600 text-white shadow-xs' : 'bg-transparent text-ink-600 hover:text-ink-800'
            }`}
          >
            {t.label}
          </button>
        ))}
      </div>

      <form onSubmit={handleSubmit} noValidate className="space-y-3">
        {error && (
          <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3 py-2 text-sm text-danger-600">
            {error}
          </div>
        )}

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <label htmlFor="pickup-city" className={labelClasses}>
              Pickup city
            </label>
            <div className="relative mt-1">
              <PinIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-brand-500" />
              <select
                id="pickup-city"
                value={pickup}
                onChange={(e) => setPickup(e.target.value)}
                className={`${inputClasses} pl-9`}
              >
                <option value="">Select city</option>
                {pickupOptions.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label htmlFor="drop-city" className={labelClasses}>
              Drop city
            </label>
            <div className="relative mt-1">
              <PinIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-brand-500" />
              <select
                id="drop-city"
                value={drop}
                onChange={(e) => setDrop(e.target.value)}
                className={`${inputClasses} pl-9`}
              >
                <option value="">Select city</option>
                {dropOptions.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          <div>
            <label htmlFor="vehicle" className={labelClasses}>
              Vehicle
            </label>
            <div className="relative mt-1">
              <CarFieldIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-brand-500" />
              <select
                id="vehicle"
                value={vehicleId}
                onChange={(e) => setVehicleId(e.target.value ? Number(e.target.value) : '')}
                className={`${inputClasses} pl-9`}
              >
                <option value="">Select vehicle</option>
                {vehicles.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name} ({v.seating_capacity} seats)
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <label htmlFor="journey-date" className={labelClasses}>
              Journey date
            </label>
            <div className="relative mt-1">
              <CalendarFieldIcon className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-brand-500" />
              <input
                id="journey-date"
                type="date"
                min={todayStr()}
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className={`${inputClasses} pl-9`}
              />
            </div>
          </div>
        </div>

        <Button type="submit" fullWidth loading={submitting} className="h-[50px] justify-center gap-1.5 rounded-[10px] text-sm font-bold">
          Get fare estimate {!submitting && <ChevronRightIcon className="h-4 w-4" />}
        </Button>

        <button
          type="button"
          disabled={!pickup || !drop || !date}
          onClick={() => navigate('/search', { state: { tripType, pickup, drop, date } })}
          className="flex w-full items-center justify-between gap-2 rounded-lg border border-brand-100 bg-brand-50/60 px-3.5 py-2.5 text-sm font-medium text-brand-700 hover:bg-brand-50 disabled:cursor-not-allowed disabled:border-ink-100 disabled:bg-transparent disabled:text-ink-300"
        >
          <span className="flex items-center gap-2"><CompareIcon className="h-4 w-4" /> Or compare all vehicle types</span>
          <ChevronRightIcon className="h-4 w-4" />
        </button>
      </form>

      {result && (
        <div className="mt-4 rounded-xl border border-brand-100 bg-brand-50 p-4">
          <div className="flex flex-wrap items-start justify-between gap-3">
            <div>
              <p className="flex items-center gap-1 text-xs font-medium uppercase tracking-wide text-brand-700">
                Estimated fare <InfoIcon className="h-3.5 w-3.5" />
              </p>
              <p className="mt-1 text-3xl font-bold text-brand-800">
                {result.sym}
                {result.fare.total_fare.toLocaleString('en-IN', { maximumFractionDigits: 0 })}
              </p>
              {typeof result.fare.discount === 'number' && result.fare.discount > 0 && (
                <p className="mt-1 text-sm text-success-600">
                  Includes a {result.sym}
                  {result.fare.discount.toLocaleString('en-IN')} discount
                </p>
              )}
              {result.promo_error && <p className="mt-1 text-sm text-danger-600">{result.promo_error}</p>}
            </div>
            <p className="max-w-[12rem] text-xs text-brand-700/80">Final fare may vary slightly based on exact distance and route.</p>
          </div>
          <Button
            type="button"
            fullWidth
            className="mt-3 justify-center gap-1.5"
            onClick={() =>
              navigate('/book', {
                state: { tripType, pickup, drop, vehicleId: vehicleId || undefined, date },
              })
            }
          >
            Continue to book <ChevronRightIcon className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  );
}
