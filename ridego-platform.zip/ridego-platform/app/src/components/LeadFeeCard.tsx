import { useState } from 'react';
import type { LeadFeeView } from '../types/api';
import { ApiError } from '../lib/api';
import { adjustBookingLeadFee, setForfeitDecision } from '../lib/api-leadfee';
import { brand } from '../lib/brand';
import { Button } from './ui/Button';

const money = (n: number | undefined | null) => {
  const v = n ?? 0;
  return `₹${v.toLocaleString('en-IN', { minimumFractionDigits: Number.isInteger(v) ? 0 : 2, maximumFractionDigits: 2 })}`;
};

// TRACE: booking's lead_fee view (admin or vendor API only) → card showing expected booking amount, formula, terms version, lead fee, customer advance, amount applied from the advance, payable to the platform, any excess advance, status; estimate is labelled as an estimate until the vendor is assigned.
//        Admin (bookingId + onChanged given, canAdjust true) also gets Recalculate and Waive with a mandatory reason → POST /app/admin/bookings/{id}/lead-fee → onChanged() reloads the booking so the card shows the server's new figures.
//        Preconditions: lead fee view from the server. Postconditions: nothing shown for legacy bookings (applies=false). Edge cases: waived/cancelled (amount shown as ₹0 by the server), empty reason (blocked with a message), server refusal (message shown, card unchanged), double click (buttons disabled while busy).
export function LeadFeeCard({ fee, audience, bookingId, canAdjust, onChanged }: { fee?: LeadFeeView; audience: 'admin' | 'vendor'; bookingId?: number; canAdjust?: boolean; onChanged?: () => void }) {
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  if (!fee || !fee.applies) return null;

  // TRACE: "Keep with platform" / "Compensate vendor" clicked on a cancelled booking → requires a reason → posts the decision → shows the server message and asks the parent to reload.
  async function decide(to: 'platform' | 'vendor') {
    if (!bookingId) return;
    if (!reason.trim()) {
      setMsg({ ok: false, text: 'Enter a reason first. It is kept in the audit log.' });
      return;
    }
    setBusy(true);
    setMsg(null);
    try {
      const r = await setForfeitDecision(bookingId, to, reason.trim());
      setMsg({ ok: true, text: r.message ?? 'Done.' });
      setReason('');
      onChanged?.();
    } catch (e) {
      setMsg({ ok: false, text: e instanceof ApiError ? e.message : 'That action failed. Please try again.' });
    } finally {
      setBusy(false);
    }
  }

  // TRACE: Recalculate/Waive clicked → requires a reason → posts → shows the server message and asks the parent to reload.
  async function act(action: 'recalculate' | 'waive') {
    if (!bookingId) return;
    if (!reason.trim()) {
      setMsg({ ok: false, text: 'Enter a reason first. It is kept in the audit log.' });
      return;
    }
    setBusy(true);
    setMsg(null);
    try {
      const r = await adjustBookingLeadFee(bookingId, action, reason.trim());
      setMsg({ ok: true, text: r.message ?? 'Done.' });
      setReason('');
      onChanged?.();
    } catch (e) {
      setMsg({ ok: false, text: e instanceof ApiError ? e.message : 'That action failed. Please try again.' });
    } finally {
      setBusy(false);
    }
  }

  const rows: [string, string][] = [
    ['Expected booking amount', money(fee.base_amount)],
    ['Calculation', fee.method_label || '—'],
    ['Terms version', fee.terms_version ? `v${fee.terms_version}` : '—'],
    [fee.is_estimate ? 'Lead fee (estimate)' : 'Lead fee', money(fee.amount)],
    ['Customer advance received', money(fee.customer_advance_received)],
    ['Set off from advance', money(fee.applied_from_advance)],
    [`Payable to ${brand().name}`, money(fee.payable_to_ridego)],
  ];
  if (fee.excess_advance_owed_to_vendor > 0) rows.push(['Excess advance owed to vendor', money(fee.excess_advance_owed_to_vendor)]);

  return (
    <section className="rounded-xl border border-ink-100 p-4 shadow-xs" aria-label="Vendor lead fee">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h3 className="text-sm font-semibold uppercase tracking-wide text-ink-500">Vendor lead fee</h3>
        <span className="rounded-full bg-ink-100 px-2.5 py-0.5 text-xs font-semibold text-ink-700">{fee.status_label}</span>
      </div>
      {fee.formula && <p className="mt-2 text-sm text-ink-600">{fee.formula}</p>}
      <dl className="mt-3 grid grid-cols-2 gap-x-3 gap-y-1.5 text-sm">
        {rows.map(([k, v]) => (
          <div key={k} className="contents">
            <dt className="text-ink-500">{k}</dt>
            <dd className="text-right font-semibold text-ink-900">{v}</dd>
          </div>
        ))}
      </dl>
      {audience === 'vendor' && (
        <p className="mt-3 text-xs text-ink-500">The lead fee is billed under the commercial terms you accepted. Your customer advance credit is applied first.</p>
      )}
      {fee.forfeit_amount > 0 && (
        <div className="mt-3 rounded-lg bg-warning-50 p-3 text-sm text-warning-800" data-testid="forfeit-note">
          <p className="font-semibold">Advance forfeited on cancellation: {money(fee.forfeit_amount)}</p>
          <p>
            {fee.forfeit_to === ''
              ? 'Decision needed: keep it with the platform as the lead fee, or compensate the vendor.'
              : fee.forfeit_to === 'vendor'
              ? fee.forfeit_paid
                ? 'Paid to the vendor as compensation.'
                : 'To be paid to the vendor as compensation when the ledger is settled.'
              : `Kept by ${brand().name} as the lead fee.`}
            {fee.forfeit_reason ? ` Reason: ${fee.forfeit_reason}` : ''}
          </p>
        </div>
      )}
      {audience === 'admin' && canAdjust && bookingId && fee.forfeit_amount > 0 && !fee.forfeit_paid && (
        <div className="mt-3 border-t border-ink-100 pt-3">
          <label htmlFor={`ff-reason-${bookingId}`} className="block text-sm font-medium text-ink-800">
            Reason for the decision
          </label>
          <input id={`ff-reason-${bookingId}`} type="text" value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Required. Recorded in the audit log" className="mt-1 w-full rounded-lg border border-ink-200 px-3 py-2 text-sm" />
          <div className="mt-2 flex flex-wrap gap-2">
            <Button size="sm" variant="secondary" disabled={busy || fee.forfeit_to === 'platform'} onClick={() => void decide('platform')}>
              Keep with {brand().name}
            </Button>
            <Button size="sm" variant="secondary" disabled={busy || fee.forfeit_to === 'vendor'} onClick={() => void decide('vendor')}>
              Compensate the vendor
            </Button>
          </div>
        </div>
      )}
      {audience === 'admin' && canAdjust && bookingId && fee.status !== 'cancelled' && (
        <div className="mt-4 border-t border-ink-100 pt-3">
          <label htmlFor={`lf-reason-${bookingId}`} className="block text-sm font-medium text-ink-800">
            Reason for change
          </label>
          <input
            id={`lf-reason-${bookingId}`}
            type="text"
            value={reason}
            onChange={(e) => setReason(e.target.value)}
            placeholder="Required. Recorded in the audit log"
            className="mt-1 w-full rounded-lg border border-ink-200 px-3 py-2 text-sm"
          />
          <div className="mt-2 flex flex-wrap gap-2">
            <Button size="sm" variant="secondary" disabled={busy} loading={busy} onClick={() => void act('recalculate')}>
              Recalculate from current terms
            </Button>
            <Button size="sm" variant="danger" disabled={busy} onClick={() => void act('waive')} aria-label="Waive the lead fee for this booking">
              Waive lead fee
            </Button>
          </div>
        </div>
      )}
      {msg && (
        <p role={msg.ok ? 'status' : 'alert'} className={`mt-2 text-sm ${msg.ok ? 'text-success-700' : 'text-danger-600'}`}>
          {msg.text}
        </p>
      )}
    </section>
  );
}
