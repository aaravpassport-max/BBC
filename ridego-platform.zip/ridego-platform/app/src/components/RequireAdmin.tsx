import type { ReactNode } from 'react';
import { Link, Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { hasAdminCap } from '../lib/permissions';

interface RequireAdminProps {
  children: ReactNode;
  /**
   * The specific ridego_* capability this screen's REST routes
   * actually require server-side (see each includes/app-admin-*-api.php
   * file's own permission_callback). When provided, a user who holds
   * this granular capability — even without full WP admin/is_admin —
   * is let through, matching what the server already allows them to
   * do. Omit for a screen with no single well-defined capability
   * (falls back to the coarser is_admin check alone).
   */
  capability?: string;
}

export function RequireAdmin({ children, capability }: RequireAdminProps) {
  const { isLoggedIn, user } = useAuth();
  const location = useLocation();

  if (!isLoggedIn) {
    return <Navigate to="/login" replace state={{ from: location }} />;
  }

  const authorized = capability ? user?.is_admin || hasAdminCap(user, capability) : user?.is_admin;

  if (!authorized) {
    return (
      <div className="mx-auto max-w-xl px-4 py-20 text-center">
        <div className="rounded-2xl border border-ink-100 bg-ink-50/60 p-10">
          <h1 className="text-xl font-bold text-ink-900">Not authorized</h1>
          <p className="mt-2 text-ink-500">
            You don't have permission to access this section. If you believe this is a mistake, contact your
            administrator.
          </p>
          <div className="mt-6">
            <Link to="/" className="text-sm font-medium text-brand-700 hover:text-brand-800">
              Go back home
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
