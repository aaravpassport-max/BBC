import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ApiError } from '../../lib/api';
import { remindClient, remindVendors, resendLeads, type MutationResult } from '../../lib/api-admin-command';
import { useToast } from '../../context/ToastContext';
import { useAuth } from '../../context/AuthContext';
import { hasAdminCap } from '../../lib/permissions';

interface Props {
  bookingId: number;
  bookingNumber: string;
  status: string;
  paymentStatus?: string;
  hasVendor: boolean;
  clientPhone?: string;
  vendorPhone?: string;
  vendorName?: string;
  /** Which section of the command centre the card sits in; the bookings list omits it and gets the generic set. */
  section?: 'new_leads' | 'awaiting_vendor_response' | 'driver_pending' | 'ready_for_assignment' | 'other';
  onDone: () => void;
}

const UNPAID = ['pending', 'pending_payment', 'payment_pending', 'payment_rejected', 'proof_submitted'];
const OPEN = ['confirmed', 'no_vendor'];

// TRACE: phone string → digits-only wa.me number (10 digits get the India prefix 91) → string. Pure. Empty in → empty out.
function waNumber(phone: string): string {
  const d = phone.replace(/\D/g, '');
  return d.length === 10 ? `91${d}` : d;
}

// TRACE: one booking's status + caps → renders only the actions that make sense for it (send/resend leads, remind vendors,
//        remind client, compare/assign, call, WhatsApp) → each API action runs once at a time (busy key blocks double click),
//        shows a success/error toast and calls onDone so the parent reloads. Preconditions: admin user in AuthContext.
//        Postconditions: no action is rendered when the user lacks its capability. Edge cases: assigned bookings get no lead
//        actions; paid bookings get no payment reminder; missing phone hides call/WhatsApp; network/400 errors show the
//        server message and leave state unchanged.
export function BookingQuickActions({ bookingId, bookingNumber, status, paymentStatus, hasVendor, clientPhone, vendorPhone, vendorName, section = 'other', onDone }: Props) {
  const toast = useToast();
  const { user } = useAuth();
  const [busy, setBusy] = useState<string | null>(null);
  const canLead = Boolean(user?.is_admin || hasAdminCap(user, 'ridego_reassign_lead'));
  const canCompare = Boolean(user?.is_admin || hasAdminCap(user, 'ridego_compare_vendor_responses'));
  const canRemindClient = Boolean(user?.is_admin || hasAdminCap(user, 'ridego_manage_bookings'));
  const open = !hasVendor && OPEN.includes(status);
  const unpaid = UNPAID.includes(status) || (paymentStatus ? UNPAID.includes(paymentStatus) : false);

  // TRACE: action click → runs fn once → toast + onDone on success; ApiError message toast on failure → busy cleared either way.
  async function run(key: string, fn: () => Promise<MutationResult>) {
    if (busy) return;
    setBusy(key);
    try {
      const res = await fn();
      toast.show(res.message ?? 'Done.', 'success');
      onDone();
    } catch (err) {
      toast.show(err instanceof ApiError ? err.message : 'That action failed. Please try again.', 'error');
    } finally {
      setBusy(null);
    }
  }

  const cls =
    'rounded-md border border-ink-200 bg-white px-2.5 py-1 text-xs font-semibold text-ink-800 hover:bg-ink-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600 disabled:opacity-50';
  const showCompare = canCompare && (open || section === 'ready_for_assignment' || section === 'driver_pending');
  const showSend = canLead && open && (section === 'new_leads' || section === 'awaiting_vendor_response' || section === 'other');
  const showRemindVendors = canLead && open && (section === 'awaiting_vendor_response' || section === 'other');
  const showRemindDriver = canLead && open && section === 'driver_pending';
  const showRemindClient = canRemindClient && unpaid && status !== 'cancelled' && status !== 'completed';

  return (
    <div className="flex flex-wrap gap-2" role="group" aria-label={`Quick actions for ${bookingNumber}`}>
      {showCompare && (
        <Link className={cls} to={`/app/admin/bookings/${bookingId}/compare`}>
          {section === 'ready_for_assignment' ? 'Assign' : 'Compare'}
        </Link>
      )}
      {showSend && (
        <button type="button" className={cls} disabled={busy !== null} onClick={() => void run('send', () => resendLeads(bookingId))}>
          {section === 'new_leads' ? 'Send leads' : 'Resend leads'}
        </button>
      )}
      {showRemindVendors && (
        <button type="button" className={cls} disabled={busy !== null} onClick={() => void run('rv', () => remindVendors(bookingId, 'response'))}>
          Remind vendors
        </button>
      )}
      {showRemindDriver && (
        <button type="button" className={cls} disabled={busy !== null} onClick={() => void run('rd', () => remindVendors(bookingId, 'driver'))}>
          Remind for driver
        </button>
      )}
      {showRemindClient && (
        <button type="button" className={cls} disabled={busy !== null} onClick={() => void run('rc', () => remindClient(bookingId))}>
          Remind client
        </button>
      )}
      {clientPhone && (
        <>
          <a className={cls} href={`tel:${clientPhone}`} aria-label={`Call client for ${bookingNumber}`}>Call client</a>
          <a className={cls} href={`https://wa.me/${waNumber(clientPhone)}`} target="_blank" rel="noreferrer" aria-label={`WhatsApp client for ${bookingNumber}`}>WhatsApp</a>
        </>
      )}
      {vendorPhone && (
        <a className={cls} href={`tel:${vendorPhone}`} aria-label={`Call vendor ${vendorName ?? ''} for ${bookingNumber}`}>Call vendor</a>
      )}
    </div>
  );
}
