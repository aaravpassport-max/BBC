import { useCallback, useEffect, useState } from 'react';
import { ApiError } from '../../lib/api';
import { getBrandingFields, saveBranding, uploadBrandingImage, type BrandingField } from '../../lib/api-leadfee';
import { refreshBootstrapBranding } from '../../lib/brand';
import { Skeleton } from '../ui/Skeleton';
import { ErrorBanner } from '../ui/ErrorBanner';
import { Button } from '../ui/Button';

const inputCls =
  'w-full rounded-lg border border-ink-200 px-3 py-2 text-sm text-ink-900 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600';

// TRACE: Settings → Branding & business tab mounts → GET /app/admin/branding, renders one card per group with a labelled input per field (logo and favicon get a file picker + preview), Save posts only changed fields
//        → server validates all-or-nothing → success banner, onSaved() so the parent settings form reloads its copy of shared keys (platform_name, support_phone…), and refreshBootstrapBranding()
//        so window.__RIDEGO__.branding — the single in-memory object every brand() call in this tab reads, injected once at first page load — is overwritten with the fresh values immediately,
//        without needing a full browser reload before other client-routed screens (e.g. a vehicle's own page) pick up the change.
//        Preconditions: settings capability. Postconditions: the saved values are what every screen, email, SMS and receipt reads, in this tab immediately and everywhere else on next load. Edge cases: load failure (retry), invalid field (message names the field), oversize/wrong-type image (server message), double click (buttons disabled while busy).
export function BrandingPanel({ onSaved }: { onSaved: () => void }) {
  const [fields, setFields] = useState<BrandingField[]>([]);
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState<string | null>(null);
  const [msg, setMsg] = useState<string | null>(null);
  const [saveErr, setSaveErr] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await getBrandingFields();
      setFields(res.fields);
      setValues(Object.fromEntries(res.fields.map((f) => [f.key, f.value])));
    } catch (e) {
      setError(e instanceof ApiError ? e.message : 'Could not load branding. Please try again.');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  // TRACE: Save clicked → sends only fields whose value differs from what was loaded → on success reloads and calls onSaved; on failure shows the server message and keeps the typed values.
  async function save() {
    const changed: Record<string, string> = {};
    for (const f of fields) if ((values[f.key] ?? '') !== f.value) changed[f.key] = values[f.key] ?? '';
    if (Object.keys(changed).length === 0) {
      setMsg('Nothing to save: no branding values were changed.');
      return;
    }
    setBusy('save');
    setMsg(null);
    setSaveErr(null);
    try {
      const res = await saveBranding(changed);
      setMsg(res.message ?? 'Branding saved.');
      await load();
      await refreshBootstrapBranding();
      onSaved();
    } catch (e) {
      setSaveErr(e instanceof ApiError ? e.message : 'Could not save branding. Please try again.');
    } finally {
      setBusy(null);
    }
  }

  // TRACE: image chosen for logo_url/favicon_url/hero_image_url/hero_secondary_image_url → multipart
  //        upload → on success the returned URL is stored server-side already and put into the field;
  //        on failure the server reason is shown and the field is unchanged.
  async function upload(field: 'logo_url' | 'favicon_url' | 'hero_image_url' | 'hero_secondary_image_url', file: File | undefined) {
    if (!file) return;
    setBusy(field);
    setMsg(null);
    setSaveErr(null);
    try {
      const res = await uploadBrandingImage(field, file);
      setMsg('Image uploaded and saved.');
      setValues((v) => ({ ...v, [field]: res.url }));
      setFields((fs) => fs.map((f) => (f.key === field ? { ...f, value: res.url } : f)));
      await refreshBootstrapBranding();
      onSaved();
    } catch (e) {
      setSaveErr(e instanceof ApiError ? e.message : 'Could not upload the image. Please try again.');
    } finally {
      setBusy(null);
    }
  }

  if (loading) {
    return (
      <div className="space-y-3" aria-busy="true" aria-label="Loading branding">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-14 w-full rounded-xl" />
        ))}
      </div>
    );
  }
  if (error) return <ErrorBanner message={error} onRetry={load} />;

  const groups = Array.from(new Set(fields.map((f) => f.group)));
  return (
    <div className="space-y-5">
      <div className="rounded-lg border border-brand-200 bg-brand-50 px-3.5 py-2.5 text-sm text-brand-800">
        These details are the single source for the site header and footer, page title, favicon, emails, SMS, WhatsApp messages, receipts and legal pages. Change them here and every screen follows.
      </div>
      {msg && (
        <div role="status" className="rounded-lg border border-success-200 bg-success-50 px-3.5 py-2.5 text-sm text-success-800">
          {msg}
        </div>
      )}
      {saveErr && (
        <div role="alert" className="rounded-lg border border-danger-500/30 bg-danger-50 px-3.5 py-2.5 text-sm text-danger-600">
          {saveErr}
        </div>
      )}
      {groups.map((g) => (
        <div key={g} className="rounded-xl border border-ink-100 p-5 shadow-xs">
          <h3 className="mb-3 text-sm font-semibold uppercase tracking-wide text-ink-500">{g}</h3>
          <div className="space-y-4">
            {fields
              .filter((f) => f.group === g)
              .map((f) => {
                const id = `brand-${f.key}`;
                const IMAGE_FIELDS = ['logo_url', 'favicon_url', 'hero_image_url', 'hero_secondary_image_url'];
                const isImage = IMAGE_FIELDS.includes(f.key);
                const uploadLabel: Record<string, string> = {
                  logo_url: 'logo',
                  favicon_url: 'favicon',
                  hero_image_url: 'hero image',
                  hero_secondary_image_url: 'second hero image',
                };
                return (
                  <div key={f.key}>
                    <label htmlFor={id} className="mb-1 block text-sm font-medium text-ink-800">
                      {f.label}
                    </label>
                    {f.kind === 'textarea' ? (
                      <textarea id={id} rows={3} value={values[f.key] ?? ''} onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))} className={inputCls} />
                    ) : f.kind === 'select' ? (
                      <select id={id} value={values[f.key] ?? ''} onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))} className={inputCls}>
                        <option value="">
                          {(f.options ?? {})[f.effective] ? `Default (${(f.options ?? {})[f.effective]})` : 'Default'}
                        </option>
                        {Object.entries(f.options ?? {}).map(([val, label]) => (
                          <option key={val} value={val}>
                            {label}
                          </option>
                        ))}
                      </select>
                    ) : f.kind === 'number' ? (
                      <div className="flex items-center gap-2">
                        <input
                          id={id}
                          type="number"
                          inputMode="numeric"
                          min={f.min ?? undefined}
                          max={f.max ?? undefined}
                          step={1}
                          value={values[f.key] ?? ''}
                          onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                          placeholder={`Default: ${f.effective}`}
                          className={inputCls}
                        />
                        <span className="shrink-0 text-sm text-ink-500">px</span>
                      </div>
                    ) : (
                      <input
                        id={id}
                        type={f.kind === 'email' ? 'email' : f.kind === 'phone' ? 'tel' : f.kind === 'url' ? 'url' : 'text'}
                        value={values[f.key] ?? ''}
                        onChange={(e) => setValues((v) => ({ ...v, [f.key]: e.target.value }))}
                        placeholder={f.effective && f.effective !== (values[f.key] ?? '') ? f.effective : ''}
                        className={inputCls}
                      />
                    )}
                    {isImage && (
                      <div className="mt-2 flex flex-wrap items-center gap-3">
                        {values[f.key] ? (
                          <img
                            src={values[f.key]}
                            alt={`${f.label} preview`}
                            className={
                              f.key === 'hero_image_url' || f.key === 'hero_secondary_image_url'
                                ? 'h-20 w-full max-w-sm rounded border border-ink-100 bg-white object-cover'
                                : 'h-10 max-w-[10rem] rounded border border-ink-100 bg-white object-contain p-1'
                            }
                          />
                        ) : (
                          <span className="text-xs text-ink-400">No image set</span>
                        )}
                        <label className="cursor-pointer rounded-lg border border-ink-200 px-3 py-1.5 text-sm font-medium text-ink-800 hover:bg-ink-50 focus-within:outline focus-within:outline-2 focus-within:outline-brand-600">
                          {busy === f.key ? 'Uploading…' : `Upload ${uploadLabel[f.key] ?? 'image'}`}
                          <input
                            type="file"
                            accept={
                              f.key === 'hero_image_url' || f.key === 'hero_secondary_image_url'
                                ? 'image/png,image/jpeg,image/webp'
                                : 'image/png,image/jpeg,image/gif,image/webp,image/x-icon'
                            }
                            className="sr-only"
                            disabled={busy !== null}
                            aria-label={`Upload ${f.label}`}
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              e.target.value = '';
                              void upload(f.key as 'logo_url' | 'favicon_url' | 'hero_image_url' | 'hero_secondary_image_url', file);
                            }}
                          />
                        </label>
                      </div>
                    )}
                    {f.help && <p className="mt-1 text-xs text-ink-500">{f.help}</p>}
                  </div>
                );
              })}
          </div>
        </div>
      ))}
      <Button onClick={save} loading={busy === 'save'} disabled={busy !== null}>
        Save branding
      </Button>
    </div>
  );
}
