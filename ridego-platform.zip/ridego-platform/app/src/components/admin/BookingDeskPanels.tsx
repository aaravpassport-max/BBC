import { useState, type FormEvent } from 'react';
import { Link } from 'react-router-dom';
import {
  addBookingNote,
  deleteBookingNote,
  editAdminBooking,
  editBookingNote,
  errMessage,
  inr,
  METHOD_LABELS,
  recordBookingPayment,
  recordVendorCollectionAdmin,
  recordBookingRefund,
  SOURCE_LABELS,
} from '../../lib/api-admin-crm';
import { BottomSheet } from '../ui/BottomSheet';
import { Button } from '../ui/Button';
import { ConfirmDialog } from '../ui/ConfirmDialog';
import { useToast } from '../../context/ToastContext';
import { FormField, INPUT_CLASS } from '../../pages/vendor-mkt/vendor-mkt-shared';
import { hasAdminCap } from '../../lib/permissions';
import type { AdminBookingDetail, AppUser } from '../../types/api';
import { brand } from '../../lib/brand';

interface EditForm {
  client_name: string;
  client_phone: string;
  client_email: string;
  passengers: string;
  journey_date: string;
  journey_time: string;
  pickup_city: string;
  pickup_address: string;
  drop_city: string;
  drop_address: string;
  special_requests: string;
  booking_source: string;
  adjustment: string;
  adjustment_reason: string;
}

// TRACE: booking → the form's starting values, copied from THAT booking object. Pure. Edge cases: null return_date/optional strings become ''.
function editFormFrom(b: AdminBookingDetail): EditForm {
  return {
    client_name: b.client_name, client_phone: b.client_phone, client_email: b.client_email, passengers: String(b.passengers),
    journey_date: b.journey_date, journey_time: (b.journey_time || '').slice(0, 5), pickup_city: b.pickup_city, pickup_address: b.pickup_address,
    drop_city: b.drop_city, drop_address: b.drop_address, special_requests: b.special_requests, booking_source: b.booking_source || 'online',
    adjustment: '', adjustment_reason: '',
  };
}

/**
 * Back-office panels shown on the admin booking detail page: summary bar, edit/reschedule, payments ledger with record payment/refund, and notes.
 * TRACE: rendered with the loaded booking + an onChanged callback → each action calls its REST endpoint (edit, payments, refund, notes) → on success toasts the
 *        server message and calls onChanged so the page refetches the booking (ledger, totals, notes and status all come back from the server, nothing is
 *        patched locally). Preconditions: user holds the matching capability (buttons hidden otherwise; server re-checks). Postconditions: a failed call shows
 *        the server message inline and leaves the sheet open with the typed values. Edge cases: locked trip (edit disabled with explanation), cancelled booking
 *        (no payments), double submit (buttons loading), overpayment (server refuses, message shown), refund larger than paid (server refuses).
 */
export function BookingDeskPanels({ booking, user, onChanged }: { booking: AdminBookingDetail; user: AppUser | null; onChanged: () => void }) {
  const toast = useToast();
  const can = (cap: string) => !!user?.is_admin || hasAdminCap(user, cap);
  const canEdit = can('ridego_edit_booking_details');
  const canPay = can('ridego_record_payments');

  const [editOpen, setEditOpen] = useState(false);
  const [form, setForm] = useState<EditForm>(() => editFormFrom(booking));
  const [saving, setSaving] = useState(false);
  const [editError, setEditError] = useState<string | null>(null);

  const [payKind, setPayKind] = useState<'payment' | 'refund' | 'vendor' | null>(null);
  const [payAmount, setPayAmount] = useState('');
  const [payMethod, setPayMethod] = useState('upi');
  const [payInvoice, setPayInvoice] = useState('');
  const [payRef, setPayRef] = useState('');
  const [payNote, setPayNote] = useState('');
  const [payBusy, setPayBusy] = useState(false);
  const [payError, setPayError] = useState<string | null>(null);

  const [note, setNote] = useState('');
  const [visibility, setVisibility] = useState<'internal' | 'client'>('internal');
  const [noteBusy, setNoteBusy] = useState(false);
  const [noteError, setNoteError] = useState<string | null>(null);
  const [editingNoteId, setEditingNoteId] = useState<number | null>(null);
  const [editNoteText, setEditNoteText] = useState('');
  const [editNoteBusy, setEditNoteBusy] = useState(false);
  const [editNoteError, setEditNoteError] = useState<string | null>(null);
  const [deleteNoteId, setDeleteNoteId] = useState<number | null>(null);
  const [deleteNoteBusy, setDeleteNoteBusy] = useState(false);

  // Net booking amount RideGo holds: payment rows minus refunds. Vendor-collection rows are informational ride money and never counted here.
  const paid = (booking.payments ?? []).reduce((sum, p) => (p.entry_type === 'refund' ? sum - Number(p.amount) : p.entry_type === 'payment' ? sum + Number(p.amount) : sum), 0);
  const pendingBookingAmount = booking.booking_amount_pending ?? 0;
  const vendorOutstanding = booking.vendor_outstanding ?? 0;
  const closed = ['cancelled', 'expired'].includes(booking.status);

  // TRACE: "Edit / reschedule" click → form reset from the CURRENT booking (so unsaved values from an earlier open are discarded) → sheet opens.
  const openEdit = () => {
    setForm(editFormFrom(booking));
    setEditError(null);
    setEditOpen(true);
  };

  // TRACE: edit submit → builds a body of ONLY changed fields (+ fare adjustment if entered) → PUT edit → toast + refetch; failure → inline message, values kept.
  //        A no-change submit is refused client-side. Adjustment needs a reason (server also enforces).
  const submitEdit = async (e: FormEvent) => {
    e.preventDefault();
    if (saving) return;
    const base = editFormFrom(booking);
    const body: Record<string, unknown> = {};
    (Object.keys(base) as (keyof EditForm)[]).forEach((k) => {
      if (k === 'adjustment' || k === 'adjustment_reason') return;
      if (form[k] !== base[k]) body[k] = k === 'passengers' ? Number(form[k]) || 1 : form[k];
    });
    if (form.adjustment.trim() !== '') {
      if (form.adjustment_reason.trim() === '') return setEditError('Give a reason for the price adjustment.');
      body.fare = { adjustment: Number(form.adjustment), adjustment_reason: form.adjustment_reason.trim() };
    }
    if (Object.keys(body).length === 0) return setEditError('Nothing has been changed.');
    setSaving(true);
    setEditError(null);
    try {
      const res = await editAdminBooking(booking.id, body);
      toast.show(res.message || 'Booking updated.', 'success');
      setEditOpen(false);
      onChanged();
    } catch (err) {
      setEditError(errMessage(err, 'Could not update the booking. Please try again.'));
    } finally {
      setSaving(false);
    }
  };

  // TRACE: "Record booking amount"/"Record refund"/"Record vendor collection" click → clears the small form and remembers which kind → sheet opens.
  //        Booking amount defaults to the pending booking amount; vendor collection defaults to the vendor's outstanding ride balance.
  const openPay = (kind: 'payment' | 'refund' | 'vendor') => {
    setPayKind(kind);
    setPayAmount(kind === 'payment' && pendingBookingAmount > 0 ? String(pendingBookingAmount) : kind === 'vendor' && vendorOutstanding > 0 ? String(vendorOutstanding) : '');
    setPayMethod(kind === 'vendor' ? 'cash' : 'upi');
    setPayInvoice('');
    setPayRef('');
    setPayNote('');
    setPayError(null);
  };

  // TRACE: ledger submit → amount > 0 check → POST payments or refund → toast + refetch (totals, status and receipt notification are server-side). Errors inline.
  const submitPay = async (e: FormEvent) => {
    e.preventDefault();
    if (payBusy || !payKind) return;
    const amt = Number(payAmount);
    if (!(amt > 0)) return setPayError('Enter an amount greater than zero.');
    setPayBusy(true);
    setPayError(null);
    try {
      const body = { amount: amt, method: payMethod, reference: payRef.trim(), note: payNote.trim() };
      const res =
        payKind === 'payment'
          ? await recordBookingPayment(booking.id, body)
          : payKind === 'vendor'
            ? await recordVendorCollectionAdmin(booking.id, { ...body, vendor_invoice: payInvoice.trim() })
            : await recordBookingRefund(booking.id, body);
      toast.show(res.message || 'Saved.', 'success');
      setPayKind(null);
      onChanged();
    } catch (err) {
      setPayError(errMessage(err, 'Could not save. Please try again.'));
    } finally {
      setPayBusy(false);
    }
  };

  // TRACE: note submit → non-empty check → POST note with the chosen visibility → clears the box, toast, refetch. Client-visible notes appear in the client's trip page.
  const submitNote = async (e: FormEvent) => {
    e.preventDefault();
    if (noteBusy) return;
    if (note.trim() === '') return setNoteError('Write a note first.');
    setNoteBusy(true);
    setNoteError(null);
    try {
      const res = await addBookingNote(booking.id, note.trim(), visibility);
      toast.show(res.message || 'Note added.', 'success');
      setNote('');
      onChanged();
    } catch (err) {
      setNoteError(errMessage(err, 'Could not add the note. Please try again.'));
    } finally {
      setNoteBusy(false);
    }
  };

  // TRACE: Edit clicked on a note → opens inline editor pre-filled with that note's current text.
  const startEditNote = (n: { id: number; note: string }) => {
    setEditingNoteId(n.id);
    setEditNoteText(n.note);
    setEditNoteError(null);
  };

  // TRACE: edit submit → non-empty check → POST the updated text → toast, refetch, close editor. Errors inline, editor stays open so the text isn't lost.
  const submitEditNote = async (e: FormEvent) => {
    e.preventDefault();
    if (editNoteBusy || editingNoteId === null) return;
    if (editNoteText.trim() === '') return setEditNoteError('Write the note first.');
    setEditNoteBusy(true);
    setEditNoteError(null);
    try {
      const res = await editBookingNote(booking.id, editingNoteId, editNoteText.trim());
      toast.show(res.message || 'Note updated.', 'success');
      setEditingNoteId(null);
      onChanged();
    } catch (err) {
      setEditNoteError(errMessage(err, 'Could not save the note. Please try again.'));
    } finally {
      setEditNoteBusy(false);
    }
  };

  // TRACE: confirmed delete → DELETE the note (soft delete server-side) → toast, refetch, close confirm dialog. Errors surface as a toast since the confirm dialog is already closing.
  const confirmDeleteNote = async () => {
    if (deleteNoteBusy || deleteNoteId === null) return;
    setDeleteNoteBusy(true);
    try {
      const res = await deleteBookingNote(booking.id, deleteNoteId);
      toast.show(res.message || 'Note deleted.', 'success');
      setDeleteNoteId(null);
      onChanged();
    } catch (err) {
      toast.show(errMessage(err, 'Could not delete the note. Please try again.'), 'error');
    } finally {
      setDeleteNoteBusy(false);
    }
  };

  const set = (k: keyof EditForm) => (e: { target: { value: string } }) => setForm((f) => ({ ...f, [k]: e.target.value }));

  return (
    <div className="mt-4 space-y-4">
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 rounded-xl border border-ink-100 bg-white p-4 text-sm shadow-xs">
        <span className="text-ink-600">
          Source: <strong className="text-ink-900">{SOURCE_LABELS[booking.booking_source ?? 'online'] ?? booking.booking_source}</strong>
        </span>
        {booking.created_by_name && <span className="text-ink-600">Created by <strong className="text-ink-900">{booking.created_by_name}</strong></span>}
        {!!booking.reschedule_count && (
          <span className="text-ink-600">
            Rescheduled {booking.reschedule_count}× {booking.rescheduled_from ? `(originally ${booking.rescheduled_from})` : ''}
          </span>
        )}
        {!!booking.client_profile_id && (
          <Link to={`/app/admin/clients/${booking.client_profile_id}`} className="font-medium text-brand-700 hover:underline">
            Client profile
          </Link>
        )}
        <Link to={`/app/admin/bookings/${booking.id}/invoice`} className="font-medium text-brand-700 hover:underline">
          {booking.invoice_number ? `Booking receipt ${booking.invoice_number}` : 'Booking receipt'}
        </Link>
        {canEdit && (
          <span className="ml-auto">
            {booking.editable ? (
              <Button size="sm" variant="secondary" onClick={openEdit}>Edit / reschedule</Button>
            ) : (
              <span className="text-ink-500">Editing is closed for {booking.status.replace(/_/g, ' ')} bookings.</span>
            )}
          </span>
        )}
      </div>
      {canEdit && booking.editable && booking.trip_locked && (
        <p className="text-sm text-warning-700">The trip has started, so route, date, vehicle and price are locked. Contact details and notes can still be changed.</p>
      )}

      <section className="rounded-xl border border-ink-100 bg-white p-4 shadow-xs sm:p-5" aria-label="Booking amount">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-base font-bold text-ink-900">Booking amount (collected by {brand().name})</h3>
          {canPay && !closed && (
            <div className="flex gap-2">
              <Button size="sm" onClick={() => openPay('payment')} disabled={pendingBookingAmount <= 0}>Record booking amount</Button>
              <Button size="sm" variant="secondary" onClick={() => openPay('refund')} disabled={paid <= 0}>Record refund</Button>
            </div>
          )}
        </div>
        <p className="mt-1 text-xs text-ink-500">{brand().name} collects only this amount. The vendor/driver bills and collects the rest of the ride directly.</p>
        <dl className="mt-3 grid grid-cols-3 gap-3 text-sm">
          <div><dt className="text-ink-500">Booking amount</dt><dd className="font-semibold text-ink-900">{inr(booking.booking_amount ?? booking.token_amount)}</dd></div>
          <div><dt className="text-ink-500">Received</dt><dd className="font-semibold text-ink-900">{inr(paid)}</dd></div>
          <div><dt className="text-ink-500">Pending</dt><dd className="font-semibold text-ink-900">{inr(pendingBookingAmount)}</dd></div>
        </dl>
        {(booking.payments ?? []).filter((p) => p.entry_type !== 'vendor_collection').length === 0 ? (
          <p className="mt-3 text-sm text-ink-500">No booking amount recorded yet.</p>
        ) : (
          <ul className="mt-3 divide-y divide-ink-100 text-sm">
            {(booking.payments ?? []).filter((p) => p.entry_type !== 'vendor_collection').map((p) => (
              <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                <span className="text-ink-700">
                  <strong className={p.entry_type === 'refund' ? 'text-danger-600' : 'text-success-700'}>
                    {p.entry_type === 'refund' ? 'Refund' : 'Booking amount received'} {inr(p.amount)}
                  </strong>{' '}
                  via {METHOD_LABELS[p.method] ?? p.method}
                  {p.reference ? ` · ref ${p.reference}` : ''}
                  {p.note ? ` · ${p.note}` : ''}
                </span>
                <span className="text-xs text-ink-500">{p.created_at}{p.recorded_by ? ` · ${p.recorded_by}` : ''}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="rounded-xl border border-ink-100 bg-white p-4 shadow-xs sm:p-5" aria-label="Ride balance with vendor or driver">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-base font-bold text-ink-900">Ride balance (vendor/driver collects)</h3>
          {canPay && !closed && booking.vendor_id ? (
            <Button size="sm" variant="secondary" onClick={() => openPay('vendor')} disabled={vendorOutstanding <= 0}>Record vendor collection</Button>
          ) : null}
        </div>
        <p className="mt-1 text-xs text-ink-500">Informational only — this money never passes through {brand().name}. Normally the vendor records it from their own dashboard.</p>
        <dl className="mt-3 grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
          <div><dt className="text-ink-500">Estimated ride fare</dt><dd className="font-semibold text-ink-900">{inr(booking.total_fare)}</dd></div>
          <div><dt className="text-ink-500">Payable to vendor/driver</dt><dd className="font-semibold text-ink-900">{inr(booking.payable_to_vendor ?? booking.balance_due)}</dd></div>
          <div><dt className="text-ink-500">Reported collected</dt><dd className="font-semibold text-ink-900">{inr(booking.vendor_collected ?? 0)}</dd></div>
          <div><dt className="text-ink-500">Remaining</dt><dd className="font-semibold text-ink-900">{inr(vendorOutstanding)}</dd></div>
        </dl>
        {!booking.vendor_id && <p className="mt-2 text-xs text-ink-500">No vendor is assigned yet.</p>}
        {(booking.payments ?? []).filter((p) => p.entry_type === 'vendor_collection').length > 0 && (
          <ul className="mt-3 divide-y divide-ink-100 text-sm">
            {(booking.payments ?? []).filter((p) => p.entry_type === 'vendor_collection').map((p) => (
              <li key={p.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                <span className="text-ink-700">
                  <strong className="text-ink-900">Collected by vendor/driver {inr(p.amount)}</strong> via {METHOD_LABELS[p.method] ?? p.method}
                  {p.reference ? ` · ref ${p.reference}` : ''}
                  {p.note ? ` · ${p.note}` : ''}
                </span>
                <span className="text-xs text-ink-500">{p.created_at}{p.recorded_by ? ` · ${p.recorded_by}` : ''}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="rounded-xl border border-ink-100 bg-white p-4 shadow-xs sm:p-5" aria-label="Booking notes">
        <h3 className="text-base font-bold text-ink-900">Notes</h3>
        {(booking.notes ?? []).length === 0 ? (
          <p className="mt-2 text-sm text-ink-500">No notes yet.</p>
        ) : (
          <ul className="mt-3 space-y-2">
            {(booking.notes ?? []).map((n) =>
              editingNoteId === n.id ? (
                <li key={n.id} className="rounded-lg bg-ink-50 p-3 text-sm">
                  <form onSubmit={submitEditNote} className="space-y-2" noValidate>
                    <textarea
                      aria-label="Edit note"
                      rows={2}
                      className={INPUT_CLASS}
                      value={editNoteText}
                      onChange={(e) => setEditNoteText(e.target.value)}
                      disabled={editNoteBusy}
                      autoFocus
                    />
                    <div className="flex items-center gap-2">
                      <Button type="submit" size="sm" loading={editNoteBusy}>Save</Button>
                      <Button type="button" size="sm" variant="secondary" disabled={editNoteBusy} onClick={() => setEditingNoteId(null)}>Cancel</Button>
                    </div>
                    {editNoteError && <div role="alert" className="text-sm font-medium text-danger-600">{editNoteError}</div>}
                  </form>
                </li>
              ) : (
                <li key={n.id} className="rounded-lg bg-ink-50 p-3 text-sm">
                  <p className="text-ink-900 whitespace-pre-wrap">{n.note}</p>
                  <div className="mt-1 flex flex-wrap items-center justify-between gap-2">
                    <p className="text-xs text-ink-500">
                      {n.author} · {n.created_at} · {n.visibility === 'client' ? 'Visible to client' : 'Internal only'}{n.edited ? ' · edited' : ''}
                    </p>
                    <div className="flex gap-2">
                      <button type="button" className="text-xs font-medium text-brand-700 hover:underline" onClick={() => startEditNote(n)}>Edit</button>
                      <button type="button" className="text-xs font-medium text-danger-600 hover:underline" onClick={() => setDeleteNoteId(n.id)}>Delete</button>
                    </div>
                  </div>
                </li>
              ),
            )}
          </ul>
        )}
        <form onSubmit={submitNote} className="mt-4 space-y-3" noValidate>
          <FormField label="Add a note" htmlFor="desk-note">
            <textarea id="desk-note" rows={2} className={INPUT_CLASS} value={note} onChange={(e) => setNote(e.target.value)} disabled={noteBusy} />
          </FormField>
          <div className="flex flex-wrap items-center gap-3">
            <select aria-label="Note visibility" className={`${INPUT_CLASS} max-w-xs`} value={visibility} onChange={(e) => setVisibility(e.target.value as 'internal' | 'client')} disabled={noteBusy}>
              <option value="internal">Internal only (client cannot see)</option>
              <option value="client">Visible to the client</option>
            </select>
            <Button type="submit" size="sm" loading={noteBusy}>Add note</Button>
          </div>
          {noteError && <div role="alert" className="text-sm font-medium text-danger-600">{noteError}</div>}
        </form>
      </section>

      <BottomSheet open={editOpen} title={`Edit ${booking.booking_number}`} onClose={() => (saving ? undefined : setEditOpen(false))}>
        <form onSubmit={submitEdit} className="space-y-4" noValidate>
          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Client name" htmlFor="eb-name"><input id="eb-name" className={INPUT_CLASS} value={form.client_name} onChange={set('client_name')} disabled={saving} /></FormField>
            <FormField label="Client mobile" htmlFor="eb-phone"><input id="eb-phone" type="tel" className={INPUT_CLASS} value={form.client_phone} onChange={set('client_phone')} disabled={saving} /></FormField>
          </div>
          <FormField label="Client email" htmlFor="eb-email"><input id="eb-email" type="email" className={INPUT_CLASS} value={form.client_email} onChange={set('client_email')} disabled={saving} /></FormField>
          <div className="grid gap-4 sm:grid-cols-3">
            <FormField label="Journey date" htmlFor="eb-date"><input id="eb-date" type="date" className={INPUT_CLASS} value={form.journey_date} onChange={set('journey_date')} disabled={saving || !!booking.trip_locked} /></FormField>
            <FormField label="Pickup time" htmlFor="eb-time"><input id="eb-time" type="time" className={INPUT_CLASS} value={form.journey_time} onChange={set('journey_time')} disabled={saving || !!booking.trip_locked} /></FormField>
            <FormField label="Passengers" htmlFor="eb-pax"><input id="eb-pax" type="number" min={1} className={INPUT_CLASS} value={form.passengers} onChange={set('passengers')} disabled={saving} /></FormField>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <FormField label="Pickup city" htmlFor="eb-pc"><input id="eb-pc" className={INPUT_CLASS} value={form.pickup_city} onChange={set('pickup_city')} disabled={saving || !!booking.trip_locked} /></FormField>
            <FormField label="Drop city" htmlFor="eb-dc"><input id="eb-dc" className={INPUT_CLASS} value={form.drop_city} onChange={set('drop_city')} disabled={saving || !!booking.trip_locked} /></FormField>
            <FormField label="Pickup address" htmlFor="eb-pa"><input id="eb-pa" className={INPUT_CLASS} value={form.pickup_address} onChange={set('pickup_address')} disabled={saving} /></FormField>
            <FormField label="Drop address" htmlFor="eb-da"><input id="eb-da" className={INPUT_CLASS} value={form.drop_address} onChange={set('drop_address')} disabled={saving} /></FormField>
          </div>
          <FormField label="Special requirements" htmlFor="eb-sr"><textarea id="eb-sr" rows={2} className={INPUT_CLASS} value={form.special_requests} onChange={set('special_requests')} disabled={saving} /></FormField>
          <FormField label="Booking source" htmlFor="eb-src">
            <select id="eb-src" className={INPUT_CLASS} value={form.booking_source} onChange={set('booking_source')} disabled={saving}>
              {Object.entries(SOURCE_LABELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
            </select>
          </FormField>
          {!booking.trip_locked && (
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField label="Price adjustment in rupees (optional, negative to reduce)" htmlFor="eb-adj"><input id="eb-adj" type="number" className={INPUT_CLASS} value={form.adjustment} onChange={set('adjustment')} disabled={saving} /></FormField>
              <FormField label="Reason for adjustment" htmlFor="eb-adjr"><input id="eb-adjr" className={INPUT_CLASS} value={form.adjustment_reason} onChange={set('adjustment_reason')} disabled={saving} /></FormField>
            </div>
          )}
          <p className="text-xs text-ink-500">Changing the date or time notifies the client and the assigned vendor. Changing the route or vehicle re-prices the trip.</p>
          {editError && <div role="alert" className="text-sm font-medium text-danger-600">{editError}</div>}
          <div className="flex gap-3">
            <Button type="submit" loading={saving} fullWidth>Save changes</Button>
            <Button type="button" variant="secondary" onClick={() => setEditOpen(false)} disabled={saving} fullWidth>Cancel</Button>
          </div>
        </form>
      </BottomSheet>

      <BottomSheet open={payKind !== null} title={payKind === 'refund' ? 'Record refund' : payKind === 'vendor' ? 'Record vendor collection' : 'Record booking amount'} onClose={() => (payBusy ? undefined : setPayKind(null))}>
        <form onSubmit={submitPay} className="space-y-4" noValidate>
          <FormField label="Amount in rupees" htmlFor="pay-amt"><input id="pay-amt" type="number" min={0} step="0.01" className={INPUT_CLASS} value={payAmount} onChange={(e) => setPayAmount(e.target.value)} disabled={payBusy} /></FormField>
          <FormField label="Method" htmlFor="pay-method">
            <select id="pay-method" className={INPUT_CLASS} value={payMethod} onChange={(e) => setPayMethod(e.target.value)} disabled={payBusy}>
              {Object.entries(METHOD_LABELS).map(([k, l]) => <option key={k} value={k}>{l}</option>)}
            </select>
          </FormField>
          <FormField label="Reference / UTR (optional)" htmlFor="pay-ref"><input id="pay-ref" className={INPUT_CLASS} value={payRef} onChange={(e) => setPayRef(e.target.value)} disabled={payBusy} /></FormField>
          <FormField label="Note (optional)" htmlFor="pay-note"><input id="pay-note" className={INPUT_CLASS} value={payNote} onChange={(e) => setPayNote(e.target.value)} disabled={payBusy} /></FormField>
          {payKind === 'vendor' && <FormField label="Vendor invoice number (optional)" htmlFor="pay-inv"><input id="pay-inv" className={INPUT_CLASS} value={payInvoice} onChange={(e) => setPayInvoice(e.target.value)} disabled={payBusy} /></FormField>}
          {payError && <div role="alert" className="text-sm font-medium text-danger-600">{payError}</div>}
          <div className="flex gap-3">
            <Button type="submit" loading={payBusy} fullWidth>{payKind === 'refund' ? 'Record refund' : payKind === 'vendor' ? 'Record vendor collection' : 'Record booking amount'}</Button>
            <Button type="button" variant="secondary" onClick={() => setPayKind(null)} disabled={payBusy} fullWidth>Cancel</Button>
          </div>
        </form>
      </BottomSheet>

      <ConfirmDialog
        open={deleteNoteId !== null}
        title="Delete this note?"
        description="This removes it from the notes list. If it was visible to the client, it will no longer show on their trip page."
        confirmLabel="Delete"
        confirmVariant="danger"
        loading={deleteNoteBusy}
        onConfirm={() => void confirmDeleteNote()}
        onCancel={() => setDeleteNoteId(null)}
      />
    </div>
  );
}
