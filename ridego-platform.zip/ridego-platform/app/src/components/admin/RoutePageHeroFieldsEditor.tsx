import { useRef, useState } from 'react';
import type { RoutePageHeroFields } from '../../types/api';
import { uploadRoutePageHeroImage, ApiError } from '../../lib/api';

/**
 * Shared field set for the Route Page hero settings — used both for the
 * GLOBAL default (AdminRoutePageSettingsPage) and, per route, as an
 * override section inside AdminRoutePagesPage's edit modal. Same fields,
 * same sanitization rules as the backend (includes/route-pages.php,
 * ridego_route_page_hero_fields()); this component only handles the
 * form/upload UI, never invents a value on its own.
 *
 * When `isOverride` is true, each field/section shows a "Use global
 * default" reset (clearing that field back to '' / null so the backend
 * falls back to the global default), and a section header calling out
 * that this OVERRIDES the default.
 */

const HEIGHT_PRESETS: { value: string; label: string; px: number }[] = [
  { value: 'compact', label: 'Compact (280px)', px: 280 },
  { value: 'standard', label: 'Standard (360px)', px: 360 },
  { value: 'large', label: 'Large (460px)', px: 460 },
];

function isPreset(v: string) {
  return HEIGHT_PRESETS.some((p) => p.value === v);
}

interface Props {
  value: RoutePageHeroFields;
  onChange: (patch: Partial<RoutePageHeroFields>) => void;
  isOverride?: boolean;
}

function HeightControl({
  label,
  value,
  onChange,
  clear,
  isOverride,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  clear?: () => void;
  isOverride?: boolean;
}) {
  const customMode = value !== '' && !isPreset(value);
  return (
    <div>
      <div className="flex items-center justify-between">
        <label className="block text-sm font-medium text-ink-700">{label}</label>
        {isOverride && value !== '' && (
          <button type="button" onClick={clear} className="text-xs font-medium text-brand-600 hover:underline">
            Use global default
          </button>
        )}
      </div>
      <div className="mt-1.5 flex flex-wrap gap-2">
        {HEIGHT_PRESETS.map((p) => (
          <button
            key={p.value}
            type="button"
            onClick={() => onChange(p.value)}
            className={`rounded-lg border px-3 py-1.5 text-xs font-medium ${
              value === p.value ? 'border-brand-500 bg-brand-50 text-brand-700' : 'border-ink-200 text-ink-600 hover:bg-ink-50'
            }`}
          >
            {p.label}
          </button>
        ))}
        <button
          type="button"
          onClick={() => onChange(customMode ? value : '400')}
          className={`rounded-lg border px-3 py-1.5 text-xs font-medium ${
            customMode ? 'border-brand-500 bg-brand-50 text-brand-700' : 'border-ink-200 text-ink-600 hover:bg-ink-50'
          }`}
        >
          Custom
        </button>
        {customMode && (
          <input
            type="number"
            min={100}
            max={900}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            className="w-24 rounded-lg border border-ink-200 px-2.5 py-1.5 text-xs shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            placeholder="px"
          />
        )}
      </div>
    </div>
  );
}

function ImageUploadField({
  label,
  url,
  onUploaded,
  onClear,
  isOverride,
  variant,
}: {
  label: string;
  url: string;
  onUploaded: (url: string) => void;
  onClear?: () => void;
  isOverride?: boolean;
  variant: 'desktop' | 'mobile' | 'card';
}) {
  const [uploading, setUploading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  async function handleFile(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setErr(null);
    try {
      const res = await uploadRoutePageHeroImage(file, variant);
      onUploaded(res.url);
    } catch (e2) {
      setErr(e2 instanceof ApiError ? e2.message : 'Upload failed.');
    } finally {
      setUploading(false);
      if (fileRef.current) fileRef.current.value = '';
    }
  }

  return (
    <div>
      <div className="flex items-center justify-between">
        <label className="block text-sm font-medium text-ink-700">{label}</label>
        {isOverride && url && (
          <button type="button" onClick={onClear} className="text-xs font-medium text-brand-600 hover:underline">
            Use global default
          </button>
        )}
      </div>
      <div className="mt-1.5 flex items-center gap-3">
        {url ? (
          <img src={url} alt="" className="h-14 w-24 rounded-lg border border-ink-200 object-cover" />
        ) : (
          <div className="flex h-14 w-24 items-center justify-center rounded-lg border border-dashed border-ink-200 text-[10px] text-ink-400">None</div>
        )}
        <input ref={fileRef} type="file" accept="image/png,image/jpeg,image/webp" onChange={handleFile} disabled={uploading} className="text-xs" />
        {uploading && <span className="text-xs text-ink-400">Uploading…</span>}
      </div>
      {err && <p className="mt-1 text-xs text-danger-600">{err}</p>}
    </div>
  );
}

export function RoutePageHeroFieldsEditor({ value, onChange, isOverride }: Props) {
  const clearField = (field: keyof RoutePageHeroFields) => onChange({ [field]: field === 'hero_overlay_enabled' ? null : '' } as Partial<RoutePageHeroFields>);

  return (
    <div className="space-y-4 rounded-xl border border-ink-100 bg-ink-50/40 p-4">
      <div className="rounded-lg border border-brand-200 bg-brand-50/40 p-3">
        <p className="text-sm font-semibold text-ink-800">Home Page route card image</p>
        <p className="mt-0.5 text-xs text-ink-500">
          Used specifically for this route's small card thumbnail on the Home Page's "Popular Outstation Routes" section.
          This is separate from the hero banner image below — the hero image is styled/overlaid for full-bleed display and
          looks wrong shrunk down to a card. Leave blank to fall back to the destination city's photo.
        </p>
        <div className="mt-2">
          <ImageUploadField
            label="Card image"
            url={value.card_image_url}
            onUploaded={(url) => onChange({ card_image_url: url })}
            onClear={() => clearField('card_image_url')}
            isOverride={isOverride}
            variant="card"
          />
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between">
          <p className="text-sm font-semibold text-ink-800">Hero mode</p>
          {isOverride && value.hero_mode !== '' && (
            <button type="button" onClick={() => clearField('hero_mode')} className="text-xs font-medium text-brand-600 hover:underline">
              Use global default
            </button>
          )}
        </div>
        <div className="mt-1.5 flex gap-2">
          {(['standard', 'image'] as const).map((m) => (
            <button
              key={m}
              type="button"
              onClick={() => onChange({ hero_mode: m })}
              className={`rounded-lg border px-3.5 py-1.5 text-sm font-medium capitalize ${
                value.hero_mode === m ? 'border-brand-500 bg-brand-50 text-brand-700' : 'border-ink-200 text-ink-600 hover:bg-ink-50'
              }`}
            >
              {m}
            </button>
          ))}
        </div>
      </div>

      {value.hero_mode === 'image' ? (
        <>
          <ImageUploadField
            label="Desktop hero image (full-bleed hero banner on this route's own page — not used on the Home Page card)"
            url={value.hero_image_desktop_url}
            onUploaded={(url) => onChange({ hero_image_desktop_url: url })}
            onClear={() => clearField('hero_image_desktop_url')}
            isOverride={isOverride}
            variant="desktop"
          />
          <ImageUploadField
            label="Mobile hero image (falls back to desktop image if left blank)"
            url={value.hero_image_mobile_url}
            onUploaded={(url) => onChange({ hero_image_mobile_url: url })}
            onClear={() => clearField('hero_image_mobile_url')}
            isOverride={isOverride}
            variant="mobile"
          />
          <label className="flex items-center gap-2 text-sm text-ink-700">
            <input
              type="checkbox"
              checked={!!value.hero_overlay_enabled}
              onChange={(e) => onChange({ hero_overlay_enabled: e.target.checked })}
              className="h-4 w-4 rounded border-ink-300"
            />
            Overlay heading/content on image (off by default — heading, subheading and background color are otherwise completely suppressed)
          </label>
        </>
      ) : null}

      {(value.hero_mode !== 'image' || value.hero_overlay_enabled) && (
        <>
          <div>
            <div className="flex items-center justify-between">
              <label className="block text-sm font-medium text-ink-700">Heading</label>
              {isOverride && value.hero_heading && (
                <button type="button" onClick={() => clearField('hero_heading')} className="text-xs font-medium text-brand-600 hover:underline">
                  Use global default
                </button>
              )}
            </div>
            <input
              type="text"
              value={value.hero_heading}
              onChange={(e) => onChange({ hero_heading: e.target.value })}
              maxLength={200}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          <div>
            <div className="flex items-center justify-between">
              <label className="block text-sm font-medium text-ink-700">Subheading / supporting text</label>
              {isOverride && value.hero_subheading && (
                <button type="button" onClick={() => clearField('hero_subheading')} className="text-xs font-medium text-brand-600 hover:underline">
                  Use global default
                </button>
              )}
            </div>
            <textarea
              value={value.hero_subheading}
              onChange={(e) => onChange({ hero_subheading: e.target.value })}
              maxLength={320}
              rows={2}
              className="mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30"
            />
          </div>
          {value.hero_mode !== 'image' && (
            <div>
              <div className="flex items-center justify-between">
                <label className="block text-sm font-medium text-ink-700">Background color</label>
                {isOverride && value.hero_bg_color && (
                  <button type="button" onClick={() => clearField('hero_bg_color')} className="text-xs font-medium text-brand-600 hover:underline">
                    Use global default
                  </button>
                )}
              </div>
              <div className="mt-1.5 flex items-center gap-2">
                <input
                  type="color"
                  value={value.hero_bg_color || '#0f1116'}
                  onChange={(e) => onChange({ hero_bg_color: e.target.value })}
                  className="h-9 w-14 rounded border border-ink-200"
                />
                <span className="text-xs text-ink-500">{value.hero_bg_color || 'Not set — uses the city-photo/gradient background'}</span>
              </div>
            </div>
          )}
        </>
      )}

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
        <HeightControl
          label="Hero height — desktop"
          value={value.hero_height_desktop}
          onChange={(v) => onChange({ hero_height_desktop: v })}
          clear={() => clearField('hero_height_desktop')}
          isOverride={isOverride}
        />
        <HeightControl
          label="Hero height — mobile"
          value={value.hero_height_mobile}
          onChange={(v) => onChange({ hero_height_mobile: v })}
          clear={() => clearField('hero_height_mobile')}
          isOverride={isOverride}
        />
      </div>
    </div>
  );
}
