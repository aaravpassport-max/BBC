import { useState, type ChangeEvent } from 'react';
import { Link } from 'react-router-dom';
import { checkClientDuplicate, SOURCE_LABELS, type ClientInput, type ClientSummary } from '../../lib/api-admin-crm';
import { FormField, INPUT_CLASS } from '../../pages/vendor-mkt/vendor-mkt-shared';

export const EMPTY_CLIENT: Required<Pick<ClientInput, 'name' | 'phone' | 'alt_phone' | 'email' | 'address' | 'city' | 'company_name' | 'gst_number' | 'notes' | 'tags'>> & {
  client_type: 'individual' | 'corporate';
  source: string;
} = { name: '', phone: '', alt_phone: '', email: '', address: '', city: '', company_name: '', gst_number: '', notes: '', tags: '', client_type: 'individual', source: 'phone' };

export type ClientFormValues = typeof EMPTY_CLIENT;
export type ClientFormErrors = Partial<Record<keyof ClientFormValues, string>>;

// TRACE: client form submit / booking-desk "next" → validates the fields the server also requires → { field: message } (empty object = valid).
//        Rules mirror ridego_client_validate: name required, mobile 10-13 digits, alt phone blank or 10-13, email shape, GST blank or 15 chars,
//        corporate needs a company name. Pure. Edge cases: whitespace-only name, digits with +91/spaces/dashes.
export function validateClientForm(v: ClientFormValues): ClientFormErrors {
  const e: ClientFormErrors = {};
  const digits = v.phone.replace(/\D/g, '');
  const alt = v.alt_phone.replace(/\D/g, '');
  if (v.name.trim() === '') e.name = 'Enter the client name.';
  if (digits.length < 10 || digits.length > 13) e.phone = 'Enter a valid mobile number (10 to 13 digits).';
  if (alt !== '' && (alt.length < 10 || alt.length > 13)) e.alt_phone = 'Enter a valid alternate number or leave it blank.';
  if (v.email.trim() !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v.email.trim())) e.email = 'Enter a valid email address or leave it blank.';
  const gst = v.gst_number.replace(/[^A-Za-z0-9]/g, '');
  if (gst !== '' && gst.length !== 15) e.gst_number = 'A GST number has 15 characters.';
  if (v.client_type === 'corporate' && v.company_name.trim() === '') e.company_name = 'Enter the company name for a corporate client.';
  return e;
}

/**
 * Shared client fields used by the Clients page, the profile editor and the booking desk's "new client" step.
 * TRACE: mount/blur of mobile or email → POST check-duplicate (debounced by blur) → shows every existing profile with the same mobile/email
 *        and, when onUseExisting is supplied, a "Use this client" button; the server ALSO refuses duplicates, this is only early feedback.
 *        Preconditions: values controlled by the parent. Postconditions: parent state updated via onChange(patch). Edge cases: lookup failure is silent
 *        (server check remains the authority), the profile being edited is excluded from matches.
 */
export function ClientFields({
  values,
  errors,
  onChange,
  excludeId,
  onUseExisting,
  disabled,
  idPrefix = 'cl',
  showSource = true,
}: {
  values: ClientFormValues;
  errors: ClientFormErrors;
  onChange: (patch: Partial<ClientFormValues>) => void;
  excludeId?: number;
  onUseExisting?: (c: ClientSummary) => void;
  disabled?: boolean;
  idPrefix?: string;
  showSource?: boolean;
}) {
  const [matches, setMatches] = useState<ClientSummary[]>([]);
  const set = (k: keyof ClientFormValues) => (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => onChange({ [k]: e.target.value } as Partial<ClientFormValues>);

  // TRACE: blur of mobile/email → asks the server for matching profiles → sets the warning list. Edge cases: too-short input skips the call.
  const lookup = async () => {
    const digits = values.phone.replace(/\D/g, '');
    if (digits.length < 10 && values.email.trim() === '') {
      setMatches([]);
      return;
    }
    try {
      const r = await checkClientDuplicate({ phone: digits.length >= 10 ? values.phone : '', email: values.email, exclude_id: excludeId });
      setMatches(r.matches);
    } catch {
      setMatches([]);
    }
  };

  const id = (s: string) => `${idPrefix}-${s}`;
  return (
    <div className="space-y-4">
      {matches.length > 0 && (
        <div role="alert" className="rounded-xl border border-warning-500/30 bg-warning-50 p-3 text-sm text-warning-700">
          <p className="font-semibold">A client with this mobile number or email already exists.</p>
          <ul className="mt-2 space-y-2">
            {matches.map((m) => (
              <li key={m.id} className="flex flex-wrap items-center justify-between gap-2">
                <span>
                  {m.name} · {m.phone}
                  {m.email ? ` · ${m.email}` : ''}
                </span>
                <span className="flex gap-3">
                  <Link to={`/app/admin/clients/${m.id}`} className="font-medium text-brand-700 underline" target="_blank" rel="noreferrer">
                    Open profile
                  </Link>
                  {onUseExisting && (
                    <button type="button" onClick={() => onUseExisting(m)} className="font-medium text-brand-700 underline">
                      Use this client
                    </button>
                  )}
                </span>
              </li>
            ))}
          </ul>
        </div>
      )}
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Client type" htmlFor={id('type')}>
          <select id={id('type')} value={values.client_type} onChange={set('client_type')} className={INPUT_CLASS} disabled={disabled}>
            <option value="individual">Individual</option>
            <option value="corporate">Corporate</option>
          </select>
        </FormField>
        {showSource && (
          <FormField label="How did they reach us?" htmlFor={id('source')}>
            <select id={id('source')} value={values.source} onChange={set('source')} className={INPUT_CLASS} disabled={disabled}>
              {Object.entries(SOURCE_LABELS)
                .filter(([k]) => k !== 'online')
                .map(([k, label]) => (
                  <option key={k} value={k}>
                    {label}
                  </option>
                ))}
            </select>
          </FormField>
        )}
      </div>
      <FormField label="Full name" htmlFor={id('name')} error={errors.name}>
        <input id={id('name')} type="text" value={values.name} onChange={set('name')} className={INPUT_CLASS} disabled={disabled} autoComplete="off" aria-invalid={errors.name ? true : undefined} />
      </FormField>
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="Mobile number" htmlFor={id('phone')} error={errors.phone}>
          <input id={id('phone')} type="tel" inputMode="tel" value={values.phone} onChange={set('phone')} onBlur={lookup} className={INPUT_CLASS} disabled={disabled} autoComplete="off" aria-invalid={errors.phone ? true : undefined} />
        </FormField>
        <FormField label="Alternate contact (optional)" htmlFor={id('alt')} error={errors.alt_phone}>
          <input id={id('alt')} type="tel" inputMode="tel" value={values.alt_phone} onChange={set('alt_phone')} className={INPUT_CLASS} disabled={disabled} autoComplete="off" />
        </FormField>
      </div>
      <FormField label="Email (optional)" htmlFor={id('email')} error={errors.email}>
        <input id={id('email')} type="email" value={values.email} onChange={set('email')} onBlur={lookup} className={INPUT_CLASS} disabled={disabled} autoComplete="off" />
      </FormField>
      {values.client_type === 'corporate' && (
        <div className="grid gap-4 sm:grid-cols-2">
          <FormField label="Company name" htmlFor={id('company')} error={errors.company_name}>
            <input id={id('company')} type="text" value={values.company_name} onChange={set('company_name')} className={INPUT_CLASS} disabled={disabled} />
          </FormField>
          <FormField label="GST number (optional)" htmlFor={id('gst')} error={errors.gst_number}>
            <input id={id('gst')} type="text" maxLength={15} value={values.gst_number} onChange={set('gst_number')} className={INPUT_CLASS} disabled={disabled} />
          </FormField>
        </div>
      )}
      <div className="grid gap-4 sm:grid-cols-2">
        <FormField label="City (optional)" htmlFor={id('city')}>
          <input id={id('city')} type="text" value={values.city} onChange={set('city')} className={INPUT_CLASS} disabled={disabled} />
        </FormField>
        <FormField label="Tags (optional)" htmlFor={id('tags')} hint="Comma separated, e.g. vip, repeat">
          <input id={id('tags')} type="text" value={values.tags} onChange={set('tags')} className={INPUT_CLASS} disabled={disabled} />
        </FormField>
      </div>
      <FormField label="Address (optional)" htmlFor={id('address')}>
        <textarea id={id('address')} rows={2} value={values.address} onChange={set('address')} className={INPUT_CLASS} disabled={disabled} />
      </FormField>
      <FormField label="Internal notes (never shown to the client)" htmlFor={id('notes')}>
        <textarea id={id('notes')} rows={3} value={values.notes} onChange={set('notes')} className={INPUT_CLASS} disabled={disabled} />
      </FormField>
    </div>
  );
}
