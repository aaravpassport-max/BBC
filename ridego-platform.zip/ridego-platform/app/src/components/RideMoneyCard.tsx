import type { ReactNode } from 'react';
import type { CollectionStatus, RideMoney } from '../types/api';
import { brand } from '../lib/brand';

const money = (n: number | undefined | null, sym = '₹') =>
  `${sym}${(n ?? 0).toLocaleString('en-IN', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;

const STATUS_LABEL: Record<CollectionStatus, string> = {
  none: 'Nothing to collect',
  pending: 'Awaiting collection by vendor/driver',
  partly_collected: 'Partly collected by vendor/driver',
  settled: 'Fully collected by vendor/driver',
};

const STATUS_TONE: Record<CollectionStatus, string> = {
  none: 'bg-ink-100 text-ink-700',
  pending: 'bg-warning-50 text-warning-700',
  partly_collected: 'bg-brand-50 text-brand-700',
  settled: 'bg-success-50 text-success-700',
};

// TRACE: collection_status value → human label used by every screen → string. Pure. Edge cases: undefined/unknown → '—'.
export function collectionStatusLabel(s?: string): string {
  return s && s in STATUS_LABEL ? STATUS_LABEL[s as CollectionStatus] : '—';
}

// TRACE: collection_status → small coloured badge (text always present, colour is never the only signal) → element. Edge cases: undefined → renders nothing.
export function CollectionBadge({ status }: { status?: CollectionStatus }) {
  if (!status) return null;
  return (
    <span className={`inline-flex rounded-full px-2 py-0.5 text-xs font-medium ${STATUS_TONE[status]}`}>
      {STATUS_LABEL[status]}
    </span>
  );
}

interface Props {
  money: RideMoney;
  /** Who is looking: changes only the wording of the ride-balance rows. */
  audience: 'client' | 'vendor' | 'admin';
  sym?: string;
  /** Legal/disclaimer copy shown under the numbers (admin-editable on the server). */
  notice?: string;
  children?: ReactNode;
}

// TRACE: RideMoney (server-calculated) + audience → card showing estimated ride fare, booking amount paid to RideGo, ride balance payable to the vendor/driver,
//        vendor-reported collections and status, plus the disclaimer → element. Pure render; no state.
//        Edge cases: legacy booking (platform_model false) → shows the plain fare/paid/balance split; missing fields → 0; notice absent → not rendered.
export default function RideMoneyCard({ money: m, audience, sym = '₹', notice, children }: Props) {
  const legacy = m.platform_model === false;
  const balanceLabel =
    audience === 'vendor' ? 'You collect from the client' : audience === 'client' ? 'Payable to your vendor/driver' : 'Payable to vendor/driver';
  const rows: { label: string; value: string; strong?: boolean }[] = legacy
    ? [
        { label: 'Total fare', value: money(m.estimated_ride_fare, sym), strong: true },
        { label: 'Paid online', value: money(m.booking_amount_paid, sym) },
        { label: 'Balance', value: money(m.payable_to_vendor, sym) },
      ]
    : [
        { label: 'Estimated ride fare (billed by vendor/driver)', value: money(m.estimated_ride_fare, sym), strong: true },
        { label: audience === 'client' ? 'Booking amount paid to ' + brand().name : 'Customer advance paid to ' + brand().name, value: money(m.booking_amount_paid, sym) },
        ...(m.booking_amount_pending ? [{ label: 'Booking amount still to pay', value: money(m.booking_amount_pending, sym) }] : []),
        { label: balanceLabel, value: money(m.payable_to_vendor, sym), strong: true },
        { label: 'Reported as collected by vendor/driver', value: money(m.vendor_collected, sym) },
        { label: 'Remaining with vendor/driver', value: money(m.vendor_outstanding, sym), strong: true },
      ];
  return (
    <div>
      <dl className="space-y-2 text-sm">
        {rows.map((r) => (
          <div key={r.label} className="flex items-start justify-between gap-4">
            <dt className="text-ink-600">{r.label}</dt>
            <dd className={r.strong ? 'font-semibold text-ink-900' : 'text-ink-900'}>{r.value}</dd>
          </div>
        ))}
      </dl>
      {!legacy && m.collection_status && (
        <p className="mt-3">
          <CollectionBadge status={m.collection_status} />
          {m.vendor_invoice_number ? <span className="ml-2 text-xs text-ink-600">Vendor invoice {m.vendor_invoice_number}</span> : null}
        </p>
      )}
      {children}
      {notice && <p className="mt-3 rounded-lg bg-ink-50 p-3 text-xs leading-relaxed text-ink-600">{notice}</p>}
    </div>
  );
}
