import { useEffect, useRef, useState, type ReactNode } from 'react';
import { useLatest } from '../../lib/useLatest';
import type { RefObject } from 'react';
import { createPortal } from 'react-dom';

/**
 * Step-aware modal chrome for the booking flow — used on BOTH mobile and
 * desktop, per the brief: a header with close + step progress, a
 * scrollable body showing only the current step, and a sticky action
 * footer.
 *
 * Responsive by itself (no separate mobile/desktop components): full
 * screen with no visible backdrop below `lg` — the natural "app" pattern
 * on a phone, where the modal IS the whole screen — and a centered,
 * backdrop-dimmed card at `lg` and up (`max-w-xl`, rounded corners,
 * capped height with its own internal scroll) — the natural desktop
 * modal pattern, where the booking flow becomes a focused dialog over
 * a dimmed background page instead of taking over the whole browser
 * window. Same field markup, same step logic, same footer either way —
 * only this chrome's shape changes.
 *
 * Distinct from BottomSheet (components/ui/BottomSheet.tsx) — that one
 * is a partial-height sheet for filters/menus that still shows page
 * content behind it even on mobile.
 *
 * Same accessibility/behavior conventions as BottomSheet: portal to
 * document.body (so a `position: sticky` ancestor can't become its
 * containing block and shrink it), a real focus trap, background
 * scroll lock, Escape-to-close (routed through onRequestClose so the
 * caller can show a discard confirmation instead of closing outright),
 * a backdrop click that also goes through onRequestClose (desktop
 * only — there's no visible backdrop to click on mobile), and a
 * `prefers-reduced-motion`-safe transition.
 */
interface BookingModalShellProps {
  title: string;
  step: number;
  totalSteps: number;
  stepLabel: string;
  onRequestClose: () => void;
  footer?: ReactNode;
  children: ReactNode;
  /** Ref to the scrollable body — lets the caller scroll back to the top
   *  on step change (a plain `window.scrollTo` does nothing here since
   *  the modal's body, not the window, is what scrolls). */
  bodyRef?: RefObject<HTMLDivElement | null>;
  /**
   * The public Route Page keeps its shared MobileBottomNav visible (at an
   * elevated z-index — see MobileBottomNav's `elevated` prop) even while
   * this modal is open, instead of letting the modal's full-screen mobile
   * layout cover it. When true, the mobile-only dialog shrinks by the
   * nav's height (+ safe-area inset) instead of taking the full viewport,
   * so the nav has its own clear strip below the modal and never overlaps
   * the modal's own footer/content. No-op at `lg`, where the nav is
   * hidden and the dialog is already a centered, non-full-height card.
   */
  reserveBottomNav?: boolean;
}

const FOCUSABLE = 'a[href], button:not([disabled]), textarea, input, select, [tabindex]:not([tabindex="-1"])';

export function BookingModalShell({
  title,
  step,
  totalSteps,
  stepLabel,
  onRequestClose,
  footer,
  children,
  bodyRef,
  reserveBottomNav = false,
}: BookingModalShellProps) {
  const shellRef = useRef<HTMLDivElement>(null);
  const previouslyFocused = useRef<HTMLElement | null>(null);
  const [entered, setEntered] = useState(false);
  // The keydown effect below runs once; it must call the newest onRequestClose, not the one from the first render.
  const onRequestCloseRef = useLatest(onRequestClose);

  useEffect(() => {
    const raf = requestAnimationFrame(() => setEntered(true));
    return () => cancelAnimationFrame(raf);
  }, []);

  useEffect(() => {
    previouslyFocused.current = document.activeElement as HTMLElement;
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        onRequestCloseRef.current();
        return;
      }
      if (e.key !== 'Tab') return;
      const node = shellRef.current;
      if (!node) return;
      const items = Array.from(node.querySelectorAll<HTMLElement>(FOCUSABLE));
      if (items.length === 0) return;
      const first = items[0];
      const last = items[items.length - 1];
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault();
        last.focus();
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault();
        first.focus();
      }
    }
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('keydown', onKeyDown);
      document.body.style.overflow = prevOverflow;
      previouslyFocused.current?.focus();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const progressPct = totalSteps > 1 ? Math.round((step / (totalSteps - 1)) * 100) : 100;

  return createPortal(
    <div className="fixed inset-0 z-50 lg:flex lg:items-center lg:justify-center lg:p-4">
      {/* Backdrop — only visible/interactive at `lg`. On mobile the modal
          itself covers the full viewport, so there's nothing behind it
          to dim or click. */}
      <div
        className={`hidden bg-ink-950/50 transition-opacity duration-200 motion-reduce:transition-none lg:block lg:absolute lg:inset-0 ${
          entered ? 'opacity-100' : 'opacity-0'
        }`}
        onClick={onRequestClose}
        aria-hidden="true"
      />

      <div
        ref={shellRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="booking-modal-title"
        className={`relative flex w-full flex-col bg-white transition-opacity duration-200 motion-reduce:transition-none lg:h-auto lg:max-h-[85vh] lg:w-full lg:max-w-xl lg:rounded-2xl lg:shadow-xl ${
          reserveBottomNav ? 'h-[calc(100%-4rem-env(safe-area-inset-bottom,0px))]' : 'h-full'
        } ${entered ? 'opacity-100' : 'opacity-0'}`}
      >
        <div className="shrink-0 border-b border-ink-100 px-4 pt-[max(0.75rem,env(safe-area-inset-top,0px))] lg:rounded-t-2xl lg:px-6 lg:pt-5">
          <div className="flex items-center justify-between py-3 lg:py-0 lg:pb-4">
            <div>
              <h2 id="booking-modal-title" className="text-base font-semibold text-ink-900 lg:text-lg">
                {title}
              </h2>
              <p className="text-xs text-ink-500">
                Step {step + 1} of {totalSteps} &middot; {stepLabel}
              </p>
            </div>
            <button
              type="button"
              onClick={onRequestClose}
              aria-label="Close booking form"
              className="rounded-full p-2 text-ink-500 hover:bg-ink-50 hover:text-ink-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
            >
              <svg className="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
                <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <div
            className="mb-3 h-1.5 w-full overflow-hidden rounded-full bg-ink-100 lg:mb-5"
            role="progressbar"
            aria-valuenow={progressPct}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label="Booking progress"
          >
            <div
              className="h-full rounded-full bg-brand-600 transition-[width] duration-300 motion-reduce:transition-none"
              style={{ width: `${progressPct}%` }}
            />
          </div>
        </div>

        <div
          ref={bodyRef}
          className={`min-h-0 flex-1 overflow-y-auto overscroll-contain px-4 py-5 transition-transform duration-200 motion-reduce:transition-none lg:px-6 ${
            entered ? 'translate-y-0' : 'translate-y-2'
          }`}
        >
          {children}
        </div>

        {footer && (
          <div
            className="shrink-0 border-t border-ink-100 bg-white/95 px-4 py-3 backdrop-blur lg:rounded-b-2xl lg:px-6"
            style={{ paddingBottom: 'max(0.75rem, env(safe-area-inset-bottom, 0px))' }}
          >
            {footer}
          </div>
        )}
      </div>
    </div>,
    document.body
  );
}
