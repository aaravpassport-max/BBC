import { useEffect, useRef, useState } from 'react';
import { useGoogleMapsLoader } from '../../hooks/useGoogleMapsLoader';

/* eslint-disable @typescript-eslint/no-explicit-any -- the Google Maps
   JS SDK types (@types/google.maps) aren't installed in this project;
   rather than add a new dependency for one component, every access to
   `window.google.maps.*` here is narrowly typed as `any` and contained
   to this file. Nothing outside this file touches the Maps SDK
   directly. */

export interface LocationValue {
  address: string;
  lat: number | null;
  lng: number | null;
}

interface LocationPickerProps {
  id: string;
  label: string;
  value: LocationValue;
  onChange: (value: LocationValue) => void;
  apiKey: string | null;
  placeholder?: string;
  /** Biases autocomplete results and the map's initial center toward this city, when known. */
  cityBias?: { lat: number; lng: number } | null;
  required?: boolean;
}

const DEFAULT_CENTER = { lat: 22.9734, lng: 78.6569 }; // geographic center of India — used only until a real location is picked

/**
 * Address input with Google Places autocomplete, plus a small map with a
 * draggable pin for fine-tuning the exact spot (e.g. a specific gate at a
 * large apartment complex, or an exact point on a highway an address
 * alone can't pin down). Picking a suggestion OR dragging the pin both
 * update the same `value` — this is the one place lat/lng actually gets
 * captured; everywhere else in the booking flow just carries whatever
 * this component last reported.
 *
 * Falls back to a plain text input (no map) when no API key is
 * configured yet — the field still works for the free-text address the
 * backend has always accepted, it just doesn't capture lat/lng.
 */
export function LocationPicker({
  id,
  label,
  value,
  onChange,
  apiKey,
  placeholder,
  cityBias,
  required,
}: LocationPickerProps) {
  const { status } = useGoogleMapsLoader(apiKey);
  const inputRef = useRef<HTMLInputElement>(null);
  const mapDivRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const markerRef = useRef<any>(null);
  const autocompleteRef = useRef<any>(null);
  const geocoderRef = useRef<any>(null);
  const [mapReady, setMapReady] = useState(false);
  const onChangeRef = useRef(onChange);
  onChangeRef.current = onChange;

  // Set up autocomplete + map once the SDK has loaded.
  useEffect(() => {
    if (status !== 'loaded' || !inputRef.current || !mapDivRef.current) return;
    const g = (window as any).google;
    if (!g?.maps?.places) return;

    const center = value.lat != null && value.lng != null ? { lat: value.lat, lng: value.lng } : cityBias || DEFAULT_CENTER;
    const zoom = value.lat != null && value.lng != null ? 15 : cityBias ? 12 : 5;

    const map = new g.maps.Map(mapDivRef.current, {
      center,
      zoom,
      disableDefaultUI: true,
      zoomControl: true,
      gestureHandling: 'greedy',
    });
    mapRef.current = map;

    const marker = new g.maps.Marker({
      position: center,
      map,
      draggable: true,
    });
    markerRef.current = marker;

    geocoderRef.current = new g.maps.Geocoder();

    const autocomplete = new g.maps.places.Autocomplete(inputRef.current, {
      fields: ['formatted_address', 'geometry', 'name'],
      componentRestrictions: { country: 'in' },
    });
    if (cityBias) {
      const bounds = new g.maps.Circle({ center: cityBias, radius: 60000 }).getBounds();
      if (bounds) autocomplete.setBounds(bounds);
    }
    autocompleteRef.current = autocomplete;

    autocomplete.addListener('place_changed', () => {
      const place = autocomplete.getPlace();
      const loc = place?.geometry?.location;
      if (!loc) return; // user hit Enter without picking a suggestion — keep whatever free-text they typed
      const lat = loc.lat();
      const lng = loc.lng();
      map.panTo({ lat, lng });
      map.setZoom(16);
      marker.setPosition({ lat, lng });
      onChangeRef.current({
        address: place.formatted_address || place.name || inputRef.current?.value || '',
        lat,
        lng,
      });
    });

    marker.addListener('dragend', () => {
      const pos = marker.getPosition();
      if (!pos) return;
      const lat = pos.lat();
      const lng = pos.lng();
      // Reverse-geocode so the address text stays in sync with the pin —
      // if it fails (rate limit, no result), keep the coordinates but
      // leave whatever address text was already there rather than
      // showing a blank/broken field.
      geocoderRef.current?.geocode({ location: { lat, lng } }, (results: any, status: string) => {
        const address = status === 'OK' && results?.[0] ? results[0].formatted_address : inputRef.current?.value || '';
        onChangeRef.current({ address, lat, lng });
      });
    });

    setMapReady(true);

    return () => {
      g.maps.event.clearInstanceListeners(marker);
      g.maps.event.clearInstanceListeners(autocomplete);
      mapRef.current = null;
      markerRef.current = null;
      autocompleteRef.current = null;
      setMapReady(false);
    };
    // Intentionally only re-run when the SDK finishes loading — re-binding
    // on every keystroke (`value` changing) would tear down and recreate
    // the autocomplete/map on every render, breaking typing entirely.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [status]);

  // Keep the pin in sync if `value` changes from outside this component
  // (e.g. the caller resets the form) rather than from the map/autocomplete themselves.
  useEffect(() => {
    if (!mapReady || !markerRef.current || !mapRef.current) return;
    if (value.lat == null || value.lng == null) return;
    const current = markerRef.current.getPosition();
    if (current && Math.abs(current.lat() - value.lat) < 1e-7 && Math.abs(current.lng() - value.lng) < 1e-7) return;
    markerRef.current.setPosition({ lat: value.lat, lng: value.lng });
    mapRef.current.panTo({ lat: value.lat, lng: value.lng });
  }, [mapReady, value.lat, value.lng]);

  const inputClasses =
    'mt-1.5 w-full rounded-lg border border-ink-200 px-3.5 py-2.5 text-sm shadow-xs focus:border-brand-500 focus:outline-none focus:ring-2 focus:ring-brand-500/30';

  return (
    <div>
      <label htmlFor={id} className="block text-sm font-medium text-ink-700">
        {label}
      </label>
      <input
        ref={inputRef}
        id={id}
        type="text"
        value={value.address}
        onChange={(e) => onChangeRef.current({ address: e.target.value, lat: null, lng: null })}
        placeholder={placeholder}
        required={required}
        autoComplete="off"
        className={inputClasses}
      />
      {apiKey && (
        <div
          ref={mapDivRef}
          className="mt-2 h-40 w-full overflow-hidden rounded-lg border border-ink-100 bg-ink-50"
          aria-label={`${label} map — drag the pin to set the exact spot`}
        />
      )}
      {apiKey && status === 'error' && (
        <p className="mt-1 text-xs text-danger-600">Couldn&apos;t load the map. You can still type the address directly.</p>
      )}
      {apiKey && mapReady && (
        <p className="mt-1 text-xs text-ink-400">Drag the pin to fine-tune the exact spot.</p>
      )}
    </div>
  );
}
