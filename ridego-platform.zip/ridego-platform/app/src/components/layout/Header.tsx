import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useToast } from '../../context/ToastContext';
import { Button } from '../ui/Button';
import { BottomSheet } from '../ui/BottomSheet';
import { getNotifications } from '../../lib/api';
import { hasAdminCap, isAnyAdmin } from '../../lib/permissions';
import { brand } from '../../lib/brand';
import { userKind, roleHome } from '../../lib/roles';
import { AdminMegaNav } from './AdminMegaNav';

const navItems = [
  { to: '/', label: 'Home', end: true },
  { to: '/book', label: 'Book a ride' },
  { to: '/track', label: 'Track' },
  { to: '/dashboard', label: 'Dashboard' },
  { to: '/my-trips', label: 'My Trips' },
  { to: '/vendor/dashboard', label: 'Vendor' },
  { to: '/profile', label: 'Profile' },
  { to: '/help', label: 'Help' },
];

/**
 * Mobile-first transformation, Phase 2: the mobile drawer (opened via the
 * hamburger below) used to repeat every entry in `navItems` — but Home,
 * Book, Track, My Trips, and Profile now live one tap away in
 * MobileBottomNav (Phase 1), permanently visible on every mobile screen.
 * Repeating them here was pure duplication, so the drawer's own link list
 * is trimmed to what the bottom nav does NOT cover: secondary/utility
 * links (Vendor dashboard entry point for a still-logged-out visitor,
 * Help) plus, for a signed-in user, the admin screens and notifications
 * that don't fit in a 5-tab bottom bar.
 */
const MOBILE_DRAWER_LINKS = navItems.filter((item) => item.to === '/vendor/dashboard' || item.to === '/help');

/**
 * Each entry's `capability` is the exact ridego_* capability that
 * screen's REST routes require server-side (see the matching
 * includes/app-admin-*-api.php permission_callback and
 * router.tsx's RequireAdmin `capability` prop for the same route) —
 * root-cause fix for the caveat flagged since Waves 17-21: this used
 * to gate every link on the coarser is_admin flag alone, hiding the
 * whole admin nav from the granular ridego_manager/ridego_admin
 * roles even where the server already allows them through.
 */
const ADMIN_NAV_LINKS = [
  { to: '/admin/command-centre', label: 'Command centre', capability: 'ridego_view_command_centre', group: 'Command centre' },
  { to: '/admin', label: 'Dashboard', capability: 'ridego_view_reports', group: 'Reports & performance' },
  { to: '/admin/bookings', label: 'Bookings', capability: 'ridego_manage_bookings', group: 'Bookings' },
  { to: '/admin/bookings/needs-attention', label: 'Needs attention', capability: 'ridego_manage_bookings', group: 'Bookings' },
  { to: '/admin/bookings/new', label: 'New booking', capability: 'ridego_create_admin_booking', group: 'Bookings' },
  { to: '/admin/clients', label: 'Clients', capability: 'ridego_manage_clients', group: 'Clients' },
  { to: '/admin/enquiries', label: 'Enquiries', capability: 'ridego_manage_enquiries', group: 'Clients' },
  { to: '/admin/vendors', label: 'Vendors', capability: 'ridego_manage_vendors', group: 'Vendors' },
  { to: '/admin/fleet/document-expiry', label: 'Document expiry', capability: 'ridego_view_fleets', group: 'Vendors' },
  { to: '/admin/leads', label: 'Leads', capability: 'ridego_manage_bookings', group: 'Leads & matching' },
  { to: '/admin/financial', label: 'Financial', capability: 'ridego_view_financial', group: 'Finance' },
  { to: '/admin/pricing', label: 'Pricing', capability: 'ridego_manage_pricing', group: 'Pricing & cities' },
  { to: '/admin/cities', label: 'Cities', capability: 'ridego_manage_pricing', group: 'Pricing & cities' },
  { to: '/admin/route-pages', label: 'Route pages', capability: 'ridego_manage_pricing', group: 'Pricing & cities' },
  { to: '/admin/promo', label: 'Promo', capability: 'ridego_manage_promo_codes', group: 'Promotions & plans' },
  { to: '/admin/surge', label: 'Surge', capability: 'ridego_manage_pricing', group: 'Pricing & cities' },
  { to: '/admin/subscriptions', label: 'Subscriptions', capability: 'ridego_manage_subscriptions', group: 'Promotions & plans' },
  { to: '/admin/complaints', label: 'Complaints', capability: 'ridego_manage_complaints', group: 'Support' },
  { to: '/admin/reports', label: 'Reports', capability: 'ridego_view_reports', group: 'Reports & performance' },
  { to: '/admin/reports/marketplace', label: 'Marketplace report', capability: 'ridego_view_reports', group: 'Reports & performance' },
  { to: '/admin/commission', label: 'Commission', capability: 'ridego_manage_commission_models', group: 'Finance' },
  { to: '/admin/lead-fee', label: 'Lead fee', capability: 'ridego_manage_settings', group: 'Finance' },
  { to: '/admin/ledger', label: 'Ledger', capability: 'ridego_view_ledger', group: 'Finance' },
  { to: '/admin/performance', label: 'Performance', capability: 'ridego_view_performance_data', group: 'Reports & performance' },
  { to: '/admin/matching', label: 'Matching', capability: 'ridego_manage_automatic_assignment', group: 'Leads & matching' },
  { to: '/admin/notifications', label: 'Notifications', capability: 'ridego_send_bulk_message', group: 'Communication' },
  { to: '/admin/team', label: 'Team & access', capability: '__full_admin_only__', group: 'System' },
  { to: '/admin/audit-log', label: 'Audit log', capability: 'ridego_view_audit_log', group: 'Audit' },
  // Tools is gated on manage_options only (same as the old wp-admin page),
  // not one of the granular ridego_* capabilities the server ever hands
  // out via admin_caps — so it deliberately has no `capability` fallback
  // here and only ever shows for a full WP administrator (user.is_admin),
  // matching the REST route's own manage_options-only gate.
  { to: '/admin/tools', label: 'Tools', capability: '__full_admin_only__', group: 'System' },
  { to: '/admin/settings', label: 'Settings', capability: 'ridego_manage_settings', group: 'System' },
] as const;

// TRACE: filtered admin links → groups them by their `group` label preserving first-seen order → array of [label, links].
//        Pure; empty input → empty output; a group with no visible links never appears.
function groupAdminLinks<T extends { group: string }>(links: readonly T[]): [string, T[]][] {
  const out: [string, T[]][] = [];
  for (const l of links) {
    const hit = out.find((g) => g[0] === l.group);
    if (hit) hit[1].push(l);
    else out.push([l.group, [l]]);
  }
  return out;
}

// TRACE: user kind + user → primary nav items for the role → array. Team and driver accounts get their own home plus
//        profile/help only (they must not see client "Book a ride"/vendor entry points). Others keep the public nav.
function primaryItems(kind: ReturnType<typeof userKind>, home: string) {
  if (kind === 'regional_manager' || kind === 'staff' || kind === 'driver') {
    return [{ to: home, label: kind === 'driver' ? 'My work' : 'My workspace', end: true }, { to: '/profile', label: 'Profile' }, { to: '/help', label: 'Help' }];
  }
  return navItems;
}

// TRACE: user → admin nav links the user may see → array. Region-limited managers only ever see the
//        bookings family (Bookings + Needs attention — both pass ridego_region_rest_guard() server-side).
function visibleAdminLinks(user: ReturnType<typeof useAuth>['user']) {
  const links = ADMIN_NAV_LINKS.filter((l) => user?.is_admin || hasAdminCap(user, l.capability));
  return user?.region_limited ? links.filter((l) => l.to === '/admin/bookings' || l.to === '/admin/bookings/needs-attention') : links;
}

function BellIcon({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
    </svg>
  );
}

export function Header() {
  const { isLoggedIn, user, logout, loading } = useAuth();
  const kind = userKind(user);
  const items = primaryItems(kind, roleHome(user));
  const drawerItems = kind === 'regional_manager' || kind === 'staff' || kind === 'driver' ? items.filter((i) => i.to !== roleHome(user)) : MOBILE_DRAWER_LINKS;
  const { show: showToast } = useToast();
  const navigate = useNavigate();
  const [menuOpen, setMenuOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);
  // Desktop admin links collapse into a dropdown rather than a flat row —
  // with up to 11 admin screens plus the 7 public nav items, a flat row
  // doesn't fit even at a wide desktop width and each link's label was
  // wrapping mid-word (e.g. "Book" / "a ride") inside a squeezed flex
  // item. Found during this session's visual QA pass.
  const [adminMenuOpen, setAdminMenuOpen] = useState(false);
  const adminMenuRef = useRef<HTMLDivElement>(null);
  const location = useLocation();
  // Enterprise mega-header: on any /app/admin/* screen, the flat "Admin"
  // dropdown below is replaced by AdminMegaNav's two-row tab + sub-nav
  // layout rendered under the top bar, so it doesn't need to duplicate
  // itself in the dropdown while already on an admin page.
  const onAdminSection = location.pathname.startsWith('/admin');

  useEffect(() => {
    if (!adminMenuOpen) return;
    function onClickOutside(e: MouseEvent) {
      if (adminMenuRef.current && !adminMenuRef.current.contains(e.target as Node)) {
        setAdminMenuOpen(false);
      }
    }
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') setAdminMenuOpen(false);
    }
    document.addEventListener('mousedown', onClickOutside);
    document.addEventListener('keydown', onKeyDown);
    return () => {
      document.removeEventListener('mousedown', onClickOutside);
      document.removeEventListener('keydown', onKeyDown);
    };
  }, [adminMenuOpen]);

  async function handleLogout() {
    await logout();
    setMenuOpen(false);
    navigate('/');
    showToast("You've been logged out.", 'success');
  }

  // Keep the notifications badge fresh with a lightweight poll, matching the
  // interval-polling idiom used for vendor leads in VendorDashboardPage.tsx.
  useEffect(() => {
    if (!isLoggedIn) {
      setUnreadCount(0);
      return;
    }
    getNotifications({ page: 1 })
      .then((res) => setUnreadCount(res.unread_count))
      .catch(() => {});
    const id = window.setInterval(() => {
      getNotifications({ page: 1 })
        .then((res) => setUnreadCount(res.unread_count))
        .catch(() => {});
    }, 20000);
    return () => window.clearInterval(id);
  }, [isLoggedIn]);

  return (
    <header className="sticky top-0 z-40 border-b border-ink-100 bg-white/90 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2 font-extrabold text-ink-900">
          {brand().logo_url ? (
            <img src={brand().logo_url} alt={brand().name} className="h-9 max-w-[9rem] object-contain" />
          ) : (
            <span className="text-lg tracking-tight">{brand().name}</span>
          )}
        </Link>

        <nav className="hidden items-center gap-1 lg:flex" aria-label="Primary">
          {items.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) =>
                `rounded-md px-3 py-2 text-sm font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 ${
                  isActive ? 'bg-brand-50 text-brand-700' : 'text-ink-600 hover:bg-ink-50 hover:text-ink-900'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="hidden items-center gap-3 lg:flex">
          {isLoggedIn ? (
            <>
              {(() => {
                if (onAdminSection) return null;
                const links = visibleAdminLinks(user);
                if (links.length === 0) return null;
                return (
                  <div className="relative" ref={adminMenuRef}>
                    <button
                      type="button"
                      onClick={() => setAdminMenuOpen((v) => !v)}
                      aria-expanded={adminMenuOpen}
                      aria-haspopup="true"
                      className="flex items-center gap-1 whitespace-nowrap rounded-md px-3 py-2 text-sm font-medium text-ink-600 hover:bg-ink-50 hover:text-ink-900 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
                    >
                      Admin
                      <svg
                        className={`h-4 w-4 transition-transform ${adminMenuOpen ? 'rotate-180' : ''}`}
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        aria-hidden="true"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" d="M6 9l6 6 6-6" />
                      </svg>
                    </button>
                    {adminMenuOpen && (
                      <div className="absolute right-0 top-full z-50 mt-1 max-h-[80vh] w-60 overflow-y-auto rounded-lg border border-ink-100 bg-white py-1.5 shadow-lg">
                        {groupAdminLinks(links).map(([group, gl]) => (
                          <div key={group} role="group" aria-label={group}>
                            <p className="px-4 pb-1 pt-2 text-[11px] font-semibold uppercase tracking-wide text-ink-400">{group}</p>
                            {gl.map((l) => (
                              <Link
                                key={l.to}
                                to={l.to}
                                onClick={() => setAdminMenuOpen(false)}
                                className="block px-4 py-1.5 text-sm font-medium text-ink-600 hover:bg-ink-50 hover:text-ink-900"
                              >
                                {l.label}
                              </Link>
                            ))}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                );
              })()}
              <Link
                to="/notifications"
                className="relative rounded-md p-2 text-ink-600 hover:bg-ink-50 hover:text-ink-900 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600"
                aria-label={unreadCount > 0 ? `Notifications, ${unreadCount} unread` : 'Notifications'}
              >
                <BellIcon className="h-5 w-5" />
                {unreadCount > 0 && (
                  <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-danger-600 px-1 text-[10px] font-semibold leading-none text-white">
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </Link>
              <span className="text-sm text-ink-600">
                Hi, <span className="font-semibold text-ink-900">{user?.name?.split(' ')[0]}</span>
              </span>
              <Button variant="secondary" size="sm" onClick={handleLogout} loading={loading}>
                Log out
              </Button>
            </>
          ) : (
            <>
              <Link to="/login" className="text-sm font-medium text-ink-600 hover:text-ink-900">
                Log in
              </Link>
              <Button size="sm" onClick={() => navigate('/register')}>
                Sign up
              </Button>
            </>
          )}
        </div>

        <button
          type="button"
          className="rounded-md p-2.5 text-ink-700 hover:bg-ink-50 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 lg:hidden"
          aria-label={menuOpen ? 'Close menu' : 'Open menu'}
          aria-expanded={menuOpen}
          onClick={() => setMenuOpen((v) => !v)}
        >
          {menuOpen ? (
            <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          ) : (
            <svg className="h-6 w-6" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h16" />
            </svg>
          )}
        </button>
      </div>

      {isLoggedIn && onAdminSection && isAnyAdmin(user) && <AdminMegaNav user={user} />}

      <BottomSheet open={menuOpen} title="Menu" onClose={() => setMenuOpen(false)}>
        <nav className="flex flex-col gap-1" aria-label="Secondary mobile">
          {drawerItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              onClick={() => setMenuOpen(false)}
              className={({ isActive }) =>
                `rounded-md px-3 py-2.5 text-sm font-medium ${
                  isActive ? 'bg-brand-50 text-brand-700' : 'text-ink-700 hover:bg-ink-50'
                }`
              }
            >
              {item.label}
            </NavLink>
          ))}
        </nav>
        <div className="mt-3 flex flex-col gap-2 border-t border-ink-100 pt-3">
          {isLoggedIn ? (
            <>
              {groupAdminLinks(visibleAdminLinks(user)).map(([group, gl]) => (
                <div key={group} role="group" aria-label={group}>
                  <p className="px-3 pb-1 pt-2 text-[11px] font-semibold uppercase tracking-wide text-ink-400">{group}</p>
                  {gl.map((l) => (
                    <Link
                      key={l.to}
                      to={l.to}
                      onClick={() => setMenuOpen(false)}
                      className="block rounded-md px-3 py-2.5 text-sm font-medium text-ink-700 hover:bg-ink-50"
                    >
                      {l.label}
                    </Link>
                  ))}
                </div>
              ))}
              <Link
                to="/notifications"
                onClick={() => setMenuOpen(false)}
                className="flex items-center justify-between rounded-md px-3 py-2.5 text-sm font-medium text-ink-700 hover:bg-ink-50"
              >
                <span className="flex items-center gap-2">
                  <BellIcon className="h-5 w-5" />
                  Notifications
                </span>
                {unreadCount > 0 && (
                  <span className="flex h-5 min-w-5 items-center justify-center rounded-full bg-danger-600 px-1.5 text-xs font-semibold leading-none text-white">
                    {unreadCount > 99 ? '99+' : unreadCount}
                  </span>
                )}
              </Link>
              <span className="px-3 text-sm text-ink-600">
                Signed in as <span className="font-semibold text-ink-900">{user?.name}</span>
              </span>
              <Button variant="secondary" size="sm" onClick={handleLogout} loading={loading}>
                Log out
              </Button>
            </>
          ) : (
            <>
              <Link
                to="/login"
                onClick={() => setMenuOpen(false)}
                className="rounded-md px-3 py-2.5 text-sm font-medium text-ink-700 hover:bg-ink-50"
              >
                Log in
              </Link>
              <Link to="/register" onClick={() => setMenuOpen(false)}>
                <Button size="sm" fullWidth>
                  Sign up
                </Button>
              </Link>
            </>
          )}
        </div>
      </BottomSheet>
    </header>
  );
}
