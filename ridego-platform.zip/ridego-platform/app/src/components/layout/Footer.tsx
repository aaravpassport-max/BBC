import { Link } from 'react-router-dom';
import { brand } from '../../lib/brand';

const SOCIAL_LABELS: { key: 'facebook' | 'instagram' | 'twitter' | 'youtube' | 'linkedin'; label: string }[] = [
  { key: 'facebook', label: 'Facebook' },
  { key: 'instagram', label: 'Instagram' },
  { key: 'twitter', label: 'X (Twitter)' },
  { key: 'youtube', label: 'YouTube' },
  { key: 'linkedin', label: 'LinkedIn' },
];

// TRACE: every page render → reads the central branding (window.__RIDEGO__.branding, saved in Settings → Branding & business) → renders logo or name, tagline, address, hours, phone, WhatsApp, email, social links, legal info, footer note and copyright.
//        Preconditions: none (missing values simply hide their line). Postconditions: no hard-coded company text; copyright shows the value saved in Settings with {year}/{brand} expanded by the server. Edge cases: no logo (name as text), no contact details (Support column shows only the Help link), invalid social URL never reaches here (server-validated).
// Five columns: Brand (with the platform-model disclaimer repeated inline, matching
// the same wording used on the Home page's "What is RideGo?" and "One platform,
// multiple ride partners" sections), Quick links, For travellers, For partners,
// Company/Support — every link goes to a real page that exists in this app; a
// feature with no real destination yet (e.g. a public privacy-policy page) is
// simply omitted rather than linked as a dead page.
export function Footer() {
  const b = brand();
  const wa = b.support_whatsapp.replace(/[^\d]/g, '');
  const socials = SOCIAL_LABELS.filter((s) => b.social[s.key]);
  return (
    <footer className="border-t border-ink-100 bg-ink-950 text-ink-300">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-14 sm:px-6 md:grid-cols-2 lg:grid-cols-5 lg:px-8">
        <div className="lg:col-span-1">
          <div className="flex items-center gap-2 font-extrabold text-white">
            {b.logo_url ? (
              <img src={b.logo_url} alt={b.name} className="h-9 max-w-[10rem] object-contain" />
            ) : (
              <span className="text-lg">{b.name}</span>
            )}
          </div>
          <p className="mt-3 max-w-xs text-sm text-ink-400">
            {b.tagline || 'A technology platform connecting you with participating cab partners for your outstation journeys.'}
          </p>
          {b.address && <p className="mt-3 max-w-xs whitespace-pre-line text-sm text-ink-400">{b.address}</p>}
          {socials.length > 0 && (
            <div className="mt-4 flex flex-wrap gap-x-3 gap-y-1 text-sm">
              {socials.map((s) => (
                <a key={s.key} href={b.social[s.key]} target="_blank" rel="noreferrer noopener" className="inline-block py-1.5 hover:text-white">{s.label}</a>
              ))}
            </div>
          )}
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wide text-ink-100">Quick links</h3>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link to="/" className="inline-block py-1.5 hover:text-white">Home</Link></li>
            <li><Link to="/#popular-routes" className="inline-block py-1.5 hover:text-white">Popular routes</Link></li>
            <li><Link to="/services" className="inline-block py-1.5 hover:text-white">Vehicle options</Link></li>
            <li><Link to="/#how-it-works" className="inline-block py-1.5 hover:text-white">How it works</Link></li>
            <li><Link to="/#faq" className="inline-block py-1.5 hover:text-white">FAQs</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wide text-ink-100">For travellers</h3>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link to="/book" className="inline-block py-1.5 hover:text-white">Find a ride</Link></li>
            <li><Link to="/track" className="inline-block py-1.5 hover:text-white">Track a booking</Link></li>
            <li><Link to="/my-trips" className="inline-block py-1.5 hover:text-white">My trips</Link></li>
            <li><Link to="/reviews" className="inline-block py-1.5 hover:text-white">Reviews</Link></li>
            <li><Link to="/help" className="inline-block py-1.5 hover:text-white">Help &amp; support</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wide text-ink-100">For partners</h3>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link to="/vendor/register" className="inline-block py-1.5 hover:text-white">Partner with us</Link></li>
            <li><Link to="/login" className="inline-block py-1.5 hover:text-white">Partner login</Link></li>
            <li><Link to="/vendor/dashboard" className="inline-block py-1.5 hover:text-white">Partner dashboard</Link></li>
            <li><Link to="/terms" className="inline-block py-1.5 hover:text-white">Partner guidelines</Link></li>
          </ul>
        </div>

        <div>
          <h3 className="text-sm font-semibold uppercase tracking-wide text-ink-100">Company</h3>
          <ul className="mt-3 space-y-2 text-sm">
            <li><Link to="/about" className="inline-block py-1.5 hover:text-white">About {b.name}</Link></li>
            <li><Link to="/terms" className="inline-block py-1.5 hover:text-white">Terms &amp; conditions</Link></li>
            {b.support_phone && <li><a href={`tel:${b.support_phone}`} className="inline-block py-1.5 hover:text-white">Call: {b.support_phone}</a></li>}
            {wa && <li><a href={`https://wa.me/${wa}`} target="_blank" rel="noreferrer" className="inline-block py-1.5 hover:text-white">WhatsApp: {b.support_whatsapp}</a></li>}
            {b.support_email && <li><a href={`mailto:${b.support_email}`} className="inline-block py-1.5 hover:text-white">{b.support_email}</a></li>}
          </ul>
        </div>
      </div>
      <div className="border-t border-ink-800 px-4 py-6 text-center text-xs text-ink-500">
        <p className="mx-auto mb-2 max-w-3xl">
          {b.name} is a technology-enabled marketplace/platform that facilitates connections between customers and
          participating transportation partners. {b.name} does not own or operate the vehicles listed on the
          platform. Transportation services are provided by the respective participating partner.
        </p>
        {b.legal_info && <p className="mb-1 whitespace-pre-line">{b.legal_info}</p>}
        {b.footer_note && <p className="mb-1 whitespace-pre-line">{b.footer_note}</p>}
        <p>{b.copyright}</p>
      </div>
    </footer>
  );
}
