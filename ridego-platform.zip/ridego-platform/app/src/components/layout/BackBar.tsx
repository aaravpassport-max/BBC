import { Link, useLocation, useNavigate } from 'react-router-dom';

// Routes that are the home of a role (no meaningful "back").
const ROOTS = new Set([
  '/', '/login', '/register', '/dashboard', '/vendor/dashboard', '/admin',
  '/admin/command-centre', '/team', '/driver', '/vendor/register',
]);
// Pages that already render their own contextual Back control in the page header.
const OWN_BACK: RegExp[] = [
  /^\/app\/book$/, /^\/app\/dashboard\/trips\/[^/]+$/, /^\/app\/vendor\/(fleet|trips|commercial-terms|settlements|performance)$/,
  /^\/app\/vendor\/bookings\/[^/]+$/, /^\/app\/admin\/vendors\/(new|[^/]+)$/, /^\/app\/admin\/clients\/[^/]+$/,
  /^\/app\/admin\/bookings\/(new|[^/]+|[^/]+\/invoice|[^/]+\/compare)$/,
];

// TRACE: pathname → the logical parent route (role home for section pages, list page for detail pages) → string.
//        Preconditions: pathname starts with /app. Postconditions: never returns the pathname itself.
//        Edge cases: unknown paths fall back to /app; trailing slash trimmed.
export function parentPath(pathname: string): string {
  const p = pathname.replace(/\/+$/, '');
  if (p.startsWith('/vendor/')) return '/vendor/dashboard';
  if (p.startsWith('/dashboard/')) return p.split('/').length > 4 ? p.split('/').slice(0, -1).join('/') : '/dashboard';
  if (p.startsWith('/admin/')) {
    const parts = p.split('/');
    return parts.length > 4 ? parts.slice(0, -1).join('/') : '/admin';
  }
  if (p.startsWith('/team/')) return '/team';
  if (p.startsWith('/driver/')) return '/driver';
  return '/';
}

// TRACE: route change → renders a "Back" control above page content unless the route is a role home or has its own
//        back control; click → history back when the user arrived from inside the app, else the logical parent.
//        Preconditions: inside Router. Postconditions: exactly one Back control per sub-page.
//        Edge cases: deep-link/refresh (location.key==='default') uses parent link, never leaves the app.
export function BackBar() {
  const { pathname, key } = useLocation();
  const navigate = useNavigate();
  const p = pathname.replace(/\/+$/, '') || '/';
  if (ROOTS.has(p) || OWN_BACK.some((r) => r.test(p))) return null;
  const parent = parentPath(p);
  const onClick = (e: React.MouseEvent) => {
    if (key !== 'default') {
      e.preventDefault();
      navigate(-1);
    }
  };
  return (
    <div className="mx-auto w-full max-w-7xl px-4 pt-4 sm:px-6 lg:px-8">
      <Link
        to={parent}
        onClick={onClick}
        aria-label="Go back"
        className="inline-flex min-h-[44px] items-center gap-1 rounded-md px-2 text-sm font-medium text-brand-700 hover:text-brand-800 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600"
      >
        <span aria-hidden="true">←</span> Back
      </Link>
    </div>
  );
}
