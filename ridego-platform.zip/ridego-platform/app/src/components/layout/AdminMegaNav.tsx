import { useMemo, useState, useRef, useEffect } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import type { AppUser } from '../../types/api';
import { hasAdminCap } from '../../lib/permissions';

/**
 * Enterprise mega-header admin nav. Real RideGo admin sections only —
 * every `to` below is a route that already exists in router.tsx and a
 * page that already exists in pages/admin/. Grouped into 7 primary tabs
 * based on the same `group` taxonomy Header.tsx's old ADMIN_NAV_LINKS
 * used, just re-shaped from a single dropdown list into two rows
 * (primary tabs + a mega sub-nav row for whichever tab is active)
 * instead of one flat/collapsed menu.
 *
 * `capability` mirrors router.tsx's RequireAdmin `capability` prop and
 * each includes/app-admin-*-api.php permission_callback exactly — see
 * Header.tsx's original comment on ADMIN_NAV_LINKS for why this must
 * stay the granular ridego_* capability, not the coarser is_admin flag.
 */
export interface AdminNavLink {
  to: string;
  label: string;
  capability: string;
  icon: string;
}

export interface AdminNavTab {
  id: string;
  label: string;
  icon: string;
  /** Extra path prefixes (detail/sub-pages with no nav link of their own) that still belong to this tab for active-state purposes. */
  extraPrefixes?: string[];
  links: AdminNavLink[];
}

export const ADMIN_NAV_TABS: AdminNavTab[] = [
  {
    id: 'overview',
    label: 'Overview',
    icon: 'home',
    links: [
      { to: '/admin', label: 'Dashboard', capability: 'ridego_view_reports', icon: 'grid' },
      { to: '/admin/command-centre', label: 'Command centre', capability: 'ridego_view_command_centre', icon: 'radar' },
      { to: '/admin/reports', label: 'Reports', capability: 'ridego_view_reports', icon: 'bar-chart' },
      { to: '/admin/reports/marketplace', label: 'Marketplace report', capability: 'ridego_view_reports', icon: 'pie-chart' },
      { to: '/admin/performance', label: 'Performance', capability: 'ridego_view_performance_data', icon: 'trending-up' },
    ],
  },
  {
    id: 'bookings',
    label: 'Bookings',
    icon: 'calendar',
    extraPrefixes: ['/admin/clients/', '/admin/bookings/'],
    links: [
      { to: '/admin/bookings', label: 'Bookings', capability: 'ridego_manage_bookings', icon: 'calendar' },
      { to: '/admin/bookings/needs-attention', label: 'Needs attention', capability: 'ridego_manage_bookings', icon: 'alert' },
      { to: '/admin/bookings/new', label: 'New booking', capability: 'ridego_create_admin_booking', icon: 'plus-circle' },
      { to: '/admin/clients', label: 'Clients', capability: 'ridego_manage_clients', icon: 'users' },
      { to: '/admin/enquiries', label: 'Enquiries', capability: 'ridego_manage_enquiries', icon: 'inbox' },
    ],
  },
  {
    id: 'vendors',
    label: 'Vendors & Fleet',
    icon: 'truck',
    extraPrefixes: ['/admin/vendors/'],
    links: [
      { to: '/admin/vendors', label: 'Vendors', capability: 'ridego_manage_vendors', icon: 'truck' },
      { to: '/admin/fleet/document-expiry', label: 'Document expiry', capability: 'ridego_view_fleets', icon: 'file-warning' },
    ],
  },
  {
    id: 'leads-support',
    label: 'Leads & Support',
    icon: 'headset',
    links: [
      { to: '/admin/leads', label: 'Leads', capability: 'ridego_manage_bookings', icon: 'target' },
      { to: '/admin/matching', label: 'Matching', capability: 'ridego_manage_automatic_assignment', icon: 'shuffle' },
      { to: '/admin/complaints', label: 'Complaints', capability: 'ridego_manage_complaints', icon: 'flag' },
      { to: '/admin/notifications', label: 'Notifications', capability: 'ridego_send_bulk_message', icon: 'megaphone' },
    ],
  },
  {
    id: 'financial',
    label: 'Financial',
    icon: 'wallet',
    links: [
      { to: '/admin/financial', label: 'Financial', capability: 'ridego_view_financial', icon: 'wallet' },
      { to: '/admin/commission', label: 'Commission', capability: 'ridego_manage_commission_models', icon: 'percent' },
      { to: '/admin/lead-fee', label: 'Lead fee', capability: 'ridego_manage_settings', icon: 'tag' },
      { to: '/admin/ledger', label: 'Ledger', capability: 'ridego_view_ledger', icon: 'book' },
    ],
  },
  {
    id: 'marketing-pricing',
    label: 'Routes & Marketing',
    icon: 'map',
    links: [
      { to: '/admin/pricing', label: 'Pricing', capability: 'ridego_manage_pricing', icon: 'dollar' },
      { to: '/admin/cities', label: 'Cities', capability: 'ridego_manage_pricing', icon: 'map-pin' },
      { to: '/admin/route-pages', label: 'Route pages', capability: 'ridego_manage_pricing', icon: 'route' },
      { to: '/admin/promo', label: 'Promo', capability: 'ridego_manage_promo_codes', icon: 'gift' },
      { to: '/admin/surge', label: 'Surge', capability: 'ridego_manage_pricing', icon: 'zap' },
      { to: '/admin/subscriptions', label: 'Subscriptions', capability: 'ridego_manage_subscriptions', icon: 'repeat' },
    ],
  },
  {
    id: 'system',
    label: 'System',
    icon: 'settings',
    links: [
      { to: '/admin/team', label: 'Team & access', capability: '__full_admin_only__', icon: 'shield' },
      { to: '/admin/audit-log', label: 'Audit log', capability: 'ridego_view_audit_log', icon: 'clipboard' },
      { to: '/admin/tools', label: 'Tools', capability: '__full_admin_only__', icon: 'tool' },
      { to: '/admin/settings', label: 'Settings', capability: 'ridego_manage_settings', icon: 'settings' },
    ],
  },
];

const ICONS: Record<string, string> = {
  home: 'M3 12l9-9 9 9M5 10v10h14V10',
  grid: 'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',
  radar: 'M12 12l6-3M12 3v2M12 12a9 9 0 11-6.36 2.64',
  'bar-chart': 'M4 20V10M12 20V4M20 20v-7',
  'pie-chart': 'M12 2v10l7 5A10 10 0 1012 2z',
  'trending-up': 'M3 17l6-6 4 4 8-8M15 7h6v6',
  calendar: 'M7 3v4M17 3v4M3 9h18M5 5h14a2 2 0 012 2v12a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2z',
  alert: 'M12 9v4m0 4h.01M10.29 3.86L1.82 18a1 1 0 00.86 1.5h18.64a1 1 0 00.86-1.5L13.71 3.86a1 1 0 00-1.72 0z',
  'plus-circle': 'M12 8v8M8 12h8M12 22a10 10 0 100-20 10 10 0 000 20z',
  users: 'M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M9 11a4 4 0 100-8 4 4 0 000 8zM23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75',
  inbox: 'M22 12h-6l-2 3h-4l-2-3H2M5.45 5.11L2 12v6a2 2 0 002 2h16a2 2 0 002-2v-6l-3.45-6.89A2 2 0 0016.76 4H7.24a2 2 0 00-1.79 1.11z',
  truck: 'M1 3h15v13H1zM16 8h4l3 3v5h-7V8zM5.5 21a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM18.5 21a2.5 2.5 0 100-5 2.5 2.5 0 000 5z',
  'file-warning': 'M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8zM14 2v6h6M12 13v3m0 3h.01',
  target: 'M12 22a10 10 0 100-20 10 10 0 000 20zM12 18a6 6 0 100-12 6 6 0 000 12zM12 14a2 2 0 100-4 2 2 0 000 4z',
  shuffle: 'M16 3h5v5M4 20L21 3M21 16v5h-5M15 15l6 6M4 4l5 5',
  flag: 'M4 15s1-1 4-1 5 2 8 2 4-1 4-1V3s-1 1-4 1-5-2-8-2-4 1-4 1zM4 22V15',
  megaphone: 'M3 11l18-5v12L3 14v-3zM11 15v4a2 2 0 01-4 0v-5',
  wallet: 'M21 12V7H5a2 2 0 010-4h14v4M3 5v14a2 2 0 002 2h16v-5M18 12a2 2 0 100 4 2 2 0 000-4z',
  percent: 'M19 5L5 19M6.5 9a2.5 2.5 0 100-5 2.5 2.5 0 000 5zM17.5 20a2.5 2.5 0 100-5 2.5 2.5 0 000 5z',
  tag: 'M20.59 13.41L11 3.83A2 2 0 009.61 3H4a1 1 0 00-1 1v5.61c0 .53.21 1.04.59 1.41l9.58 9.58a2 2 0 002.82 0l4.6-4.6a2 2 0 000-2.82zM7 7h.01',
  book: 'M4 19.5A2.5 2.5 0 016.5 17H20M4 4.5A2.5 2.5 0 016.5 2H20v20H6.5A2.5 2.5 0 014 19.5v-15z',
  map: 'M9 20l-6 3V6l6-3m0 17l6 3m-6-3V3m6 17l6-3V3l-6 3m0 14V3',
  dollar: 'M12 1v22M17 5H9.5a3.5 3.5 0 000 7h5a3.5 3.5 0 010 7H6',
  'map-pin': 'M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z M12 13a3 3 0 100-6 3 3 0 000 6z',
  route: 'M6 19a2 2 0 100-4 2 2 0 000 4zM18 9a2 2 0 100-4 2 2 0 000 4zM6 15V9a2 2 0 012-2h6a2 2 0 002-2',
  gift: 'M20 12v10H4V12M2 7h20v5H2zM12 22V7M12 7H7.5a2.5 2.5 0 010-5C11 2 12 7 12 7zM12 7h4.5a2.5 2.5 0 000-5C13 2 12 7 12 7z',
  zap: 'M13 2L3 14h9l-1 8 10-12h-9l1-8z',
  repeat: 'M17 1l4 4-4 4M3 11V9a4 4 0 014-4h14M7 23l-4-4 4-4M21 13v2a4 4 0 01-4 4H3',
  shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
  clipboard: 'M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2M9 12h6M9 16h6',
  tool: 'M14.7 6.3a4 4 0 11-5.4 5.4L2 19l3 3 7.3-7.3a4 4 0 015.4-5.4z',
  settings: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09a1.65 1.65 0 00-1-1.51 1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09a1.65 1.65 0 001.51-1 1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 114 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z',
  search: 'M11 19a8 8 0 100-16 8 8 0 000 16zM21 21l-4.35-4.35',
  chevronDown: 'M6 9l6 6 6-6',
};

function Icon({ name, className }: { name: string; className?: string }) {
  const d = ICONS[name] ?? ICONS.grid;
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
      <path d={d} />
    </svg>
  );
}

function tabIsVisible(tab: AdminNavTab, user: AppUser | null | undefined, regionLimited: boolean | undefined) {
  return visibleLinksForTab(tab, user, regionLimited).length > 0;
}

function visibleLinksForTab(tab: AdminNavTab, user: AppUser | null | undefined, regionLimited: boolean | undefined) {
  const links = tab.links.filter((l) => user?.is_admin || hasAdminCap(user, l.capability));
  if (!regionLimited) return links;
  return links.filter((l) => l.to === '/admin/bookings' || l.to === '/admin/bookings/needs-attention');
}

function activeTabId(pathname: string, tabs: AdminNavTab[]): string | null {
  let best: { id: string; len: number } | null = null;
  for (const tab of tabs) {
    const prefixes = [...tab.links.map((l) => l.to), ...(tab.extraPrefixes ?? [])];
    for (const p of prefixes) {
      if (pathname === p || pathname.startsWith(p.endsWith('/') ? p : p + '/') || (p.endsWith('/') && pathname.startsWith(p))) {
        if (!best || p.length > best.len) best = { id: tab.id, len: p.length };
      }
    }
  }
  return best?.id ?? null;
}

interface AdminMegaNavProps {
  user: AppUser | null | undefined;
}

export function AdminMegaNav({ user }: AdminMegaNavProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const regionLimited = user?.region_limited;
  const visibleTabs = useMemo(() => ADMIN_NAV_TABS.filter((t) => tabIsVisible(t, user, regionLimited)), [user, regionLimited]);
  const currentTabId = activeTabId(location.pathname, visibleTabs) ?? visibleTabs[0]?.id ?? null;
  const [openTabId, setOpenTabId] = useState<string | null>(currentTabId);
  const [query, setQuery] = useState('');
  const [mobileOpen, setMobileOpen] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setOpenTabId(currentTabId);
  }, [currentTabId]);

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (searchRef.current && !searchRef.current.contains(e.target as Node)) setQuery('');
    }
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  const openTab = visibleTabs.find((t) => t.id === openTabId) ?? visibleTabs[0] ?? null;
  const subLinks = openTab ? visibleLinksForTab(openTab, user, regionLimited) : [];

  const searchResults = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];
    const all: { link: AdminNavLink; tabLabel: string }[] = [];
    for (const tab of visibleTabs) {
      for (const link of visibleLinksForTab(tab, user, regionLimited)) {
        if (link.label.toLowerCase().includes(q)) all.push({ link, tabLabel: tab.label });
      }
    }
    return all.slice(0, 8);
  }, [query, visibleTabs, user, regionLimited]);

  if (visibleTabs.length === 0) return null;

  return (
    <div className="border-b border-ink-100 bg-white" aria-label="Admin navigation">
      {/* Primary tab row */}
      <div className="mx-auto flex max-w-[1600px] items-center gap-1 overflow-x-auto px-4 py-1.5 sm:px-6 lg:px-8">
        {visibleTabs.map((tab) => {
          const isActive = tab.id === (openTabId ?? currentTabId);
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setOpenTabId(tab.id)}
              aria-current={isActive ? 'true' : undefined}
              className={`flex shrink-0 items-center gap-2 rounded-lg px-3.5 py-2 text-sm font-semibold transition-colors ${
                isActive
                  ? 'bg-brand-50 text-brand-700 shadow-sm ring-1 ring-inset ring-brand-100'
                  : 'text-ink-600 hover:bg-ink-50 hover:text-ink-900'
              }`}
            >
              <Icon name={tab.icon} className="h-4 w-4" />
              {tab.label}
            </button>
          );
        })}

        <div className="ml-auto flex shrink-0 items-center gap-2 pl-2">
          <div className="relative hidden sm:block" ref={searchRef}>
            <Icon name="search" className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && searchResults[0]) {
                  navigate(searchResults[0].link.to);
                  setQuery('');
                }
              }}
              placeholder="Find a page…"
              aria-label="Find an admin page"
              className="w-40 rounded-lg border border-ink-200 bg-ink-50/60 py-1.5 pl-8 pr-2 text-sm text-ink-800 placeholder:text-ink-400 focus:w-56 focus:border-brand-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-brand-100 transition-all"
            />
            {query.trim() && (
              <div className="absolute right-0 top-full z-50 mt-1 w-64 overflow-hidden rounded-lg border border-ink-100 bg-white py-1 shadow-lg">
                {searchResults.length === 0 ? (
                  <p className="px-3 py-2 text-sm text-ink-400">No matching page</p>
                ) : (
                  searchResults.map(({ link, tabLabel }) => (
                    <Link
                      key={link.to}
                      to={link.to}
                      onClick={() => setQuery('')}
                      className="flex items-center justify-between px-3 py-2 text-sm text-ink-700 hover:bg-ink-50"
                    >
                      <span className="flex items-center gap-2">
                        <Icon name={link.icon} className="h-4 w-4 text-ink-400" />
                        {link.label}
                      </span>
                      <span className="text-[11px] text-ink-400">{tabLabel}</span>
                    </Link>
                  ))
                )}
              </div>
            )}
          </div>

          {/* Mobile/tablet collapse: dropdown of the active tab's sub-links */}
          <button
            type="button"
            onClick={() => setMobileOpen((v) => !v)}
            aria-expanded={mobileOpen}
            className="flex items-center gap-1 rounded-lg border border-ink-200 px-2.5 py-1.5 text-sm font-medium text-ink-600 hover:bg-ink-50 lg:hidden"
          >
            Sections
            <Icon name="chevronDown" className={`h-3.5 w-3.5 transition-transform ${mobileOpen ? 'rotate-180' : ''}`} />
          </button>
        </div>
      </div>

      {/* Second row: mega sub-nav for the active tab, columns by category — desktop/tablet */}
      {openTab && subLinks.length > 0 && (
        <div className="hidden border-t border-ink-100 bg-ink-50/40 lg:block">
          <div className="mx-auto max-w-[1600px] px-4 py-4 sm:px-6 lg:px-8">
            <p className="mb-2 text-[11px] font-bold uppercase tracking-wider text-ink-400">{openTab.label}</p>
            <div className="flex flex-wrap gap-x-8 gap-y-2">
              {subLinks.map((link) => (
                <NavLink
                  key={link.to}
                  to={link.to}
                  end={link.to === '/admin'}
                  className={({ isActive }) =>
                    `flex items-center gap-2 rounded-md px-2 py-1.5 text-sm font-medium transition-colors ${
                      isActive ? 'bg-brand-100/70 text-brand-800' : 'text-ink-600 hover:bg-white hover:text-ink-900 hover:shadow-xs'
                    }`
                  }
                >
                  <Icon name={link.icon} className="h-4 w-4" />
                  {link.label}
                </NavLink>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tablet/mobile: same sub-nav, collapsed behind the "Sections" toggle */}
      {mobileOpen && openTab && subLinks.length > 0 && (
        <div className="border-t border-ink-100 bg-ink-50/40 px-4 py-3 lg:hidden">
          <p className="mb-2 text-[11px] font-bold uppercase tracking-wider text-ink-400">{openTab.label}</p>
          <div className="flex flex-col gap-1">
            {subLinks.map((link) => (
              <NavLink
                key={link.to}
                to={link.to}
                end={link.to === '/admin'}
                onClick={() => setMobileOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-2 rounded-md px-2 py-2 text-sm font-medium ${
                    isActive ? 'bg-brand-100/70 text-brand-800' : 'text-ink-600 hover:bg-white'
                  }`
                }
              >
                <Icon name={link.icon} className="h-4 w-4" />
                {link.label}
              </NavLink>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
