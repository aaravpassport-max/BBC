import type { ReactElement } from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { userKind } from '../../lib/roles';

/**
 * Mobile-first transformation, Phase 1: a real Android-style bottom tab
 * bar, replacing "shrink the desktop nav" with a deliberate, role-aware
 * navigation model (per the transformation brief's item 10 — a customer,
 * a vendor, and an admin should not see the same destinations). Desktop
 * keeps its existing top nav (Header.tsx) untouched; this bar only
 * renders below the `lg` breakpoint, matching the cutover point Header
 * already uses for its own mobile drawer.
 *
 * Deliberately capped at 5 destinations per role — the brief warns
 * against overcrowding a bottom nav. Secondary/full-admin functionality
 * (there are 22 admin screens alone) stays reachable through the
 * existing hamburger drawer in Header.tsx rather than being crammed in
 * here.
 */

interface TabDef {
  to: string;
  label: string;
  end?: boolean;
  icon: (className: string) => ReactElement;
}

function HomeIcon(c: string) {
  return (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M3 11.5 12 4l9 7.5M5 10v9a1 1 0 001 1h4v-6h4v6h4a1 1 0 001-1v-9" />
    </svg>
  );
}
function CarIcon(c: string) {
  return (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M8 17l4-11 4 11M9.5 13h5M3 21h18" />
    </svg>
  );
}
function PinIcon(c: string) {
  return (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 21s-7-6.2-7-11.5A7 7 0 0112 2a7 7 0 017 7.5C19 14.8 12 21 12 21z" />
      <circle cx="12" cy="9.5" r="2.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
function ListIcon(c: string) {
  return (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01" />
    </svg>
  );
}
function UserIcon(c: string) {
  return (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <circle cx="12" cy="8" r="4" strokeLinecap="round" strokeLinejoin="round" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 20c0-3.5 3.5-6 8-6s8 2.5 8 6" />
    </svg>
  );
}
function GridIcon(c: string) {
  return (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <rect x="3" y="3" width="8" height="8" rx="1.5" />
      <rect x="13" y="3" width="8" height="8" rx="1.5" />
      <rect x="3" y="13" width="8" height="8" rx="1.5" />
      <rect x="13" y="13" width="8" height="8" rx="1.5" />
    </svg>
  );
}
function BuildingIcon(c: string) {
  return (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 21V6a1 1 0 011-1h6a1 1 0 011 1v15M15 21v-9a1 1 0 011-1h4a1 1 0 011 1v9M4 21h16M8 9h.01M8 13h.01M8 17h.01" />
    </svg>
  );
}
function ChartIcon(c: string) {
  return (
    <svg className={c} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" aria-hidden="true">
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 20V10M10 20V4M16 20v-7M4 20h16" />
    </svg>
  );
}

const CUSTOMER_TABS: TabDef[] = [
  { to: '/', label: 'Home', end: true, icon: HomeIcon },
  { to: '/book', label: 'Book', icon: CarIcon },
  { to: '/track', label: 'Track', icon: PinIcon },
  { to: '/dashboard', label: 'Trips', icon: ListIcon },
  { to: '/profile', label: 'Profile', icon: UserIcon },
];

const VENDOR_TABS: TabDef[] = [
  { to: '/vendor/dashboard', label: 'Dashboard', icon: GridIcon },
  { to: '/vendor/trips', label: 'Trips', icon: ListIcon },
  { to: '/vendor/fleet', label: 'Fleet', icon: CarIcon },
  { to: '/vendor/kyc', label: 'KYC', icon: BuildingIcon },
  { to: '/profile', label: 'Profile', icon: UserIcon },
];

const ADMIN_TABS: TabDef[] = [
  { to: '/admin', label: 'Dashboard', end: true, icon: GridIcon },
  { to: '/admin/command-centre', label: 'Command', icon: ChartIcon },
  { to: '/admin/bookings', label: 'Bookings', icon: CarIcon },
  { to: '/admin/vendors', label: 'Vendors', icon: BuildingIcon },
  { to: '/profile', label: 'Profile', icon: UserIcon },
];

const TEAM_TABS: TabDef[] = [
  { to: '/team', label: 'Workspace', end: true, icon: GridIcon },
  { to: '/admin/bookings', label: 'Bookings', icon: CarIcon },
  { to: '/notifications', label: 'Alerts', icon: ListIcon },
  { to: '/profile', label: 'Profile', icon: UserIcon },
];

const DRIVER_TABS: TabDef[] = [
  { to: '/driver', label: 'My work', end: true, icon: GridIcon },
  { to: '/notifications', label: 'Alerts', icon: ListIcon },
  { to: '/profile', label: 'Profile', icon: UserIcon },
];

interface MobileBottomNavProps {
  /**
   * The public Route Page (app/src/pages/RoutePage.tsx) renders this nav
   * itself since it sits outside AppLayout, and stacks its own booking
   * modal at z-50 (BookingModalShell) above the page content. Bumping
   * the nav to z-[60] there keeps it visible/clickable above that modal
   * (and its backdrop) instead of being covered by it, without changing
   * the nav's normal z-40 stacking inside AppLayout everywhere else.
   */
  elevated?: boolean;
}

export function MobileBottomNav({ elevated = false }: MobileBottomNavProps = {}) {
  const { isLoggedIn, isVendor, user } = useAuth();
  const isAdmin = Boolean(user?.is_admin || (user?.admin_caps && user.admin_caps.length > 0));

  const vendorTabs = user?.vendor_type === 'individual' ? VENDOR_TABS.map((t) => (t.to === '/vendor/fleet' ? { ...t, label: 'My vehicle' } : t)) : VENDOR_TABS;
  const kind = userKind(user);
  const teamTabs = kind === 'staff' && !user?.admin_caps?.includes('ridego_manage_bookings') ? TEAM_TABS.filter((t) => t.to !== '/admin/bookings') : TEAM_TABS;
  const tabs = kind === 'regional_manager' || kind === 'staff' ? teamTabs : kind === 'driver' ? DRIVER_TABS : isAdmin ? ADMIN_TABS : isVendor && isLoggedIn ? vendorTabs : CUSTOMER_TABS;

  return (
    <nav
      className={`fixed inset-x-0 bottom-0 ${elevated ? 'z-[60]' : 'z-40'} border-t border-ink-100 bg-white/95 backdrop-blur lg:hidden`}
      style={{ paddingBottom: 'env(safe-area-inset-bottom, 0px)' }}
      aria-label="Primary"
    >
      <div className="mx-auto flex h-16 max-w-md items-stretch justify-between px-1">
        {tabs.map((tab) => (
          <NavLink
            key={tab.to}
            to={tab.to}
            end={tab.end}
            className={({ isActive }) =>
              `flex min-w-0 flex-1 flex-col items-center justify-center gap-0.5 rounded-lg px-1 py-1.5 text-[11px] font-medium transition-colors focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 ${
                isActive ? 'text-brand-700' : 'text-ink-500'
              }`
            }
          >
            {({ isActive }) => (
              <>
                {tab.icon(`h-6 w-6 ${isActive ? 'text-brand-700' : 'text-ink-500'}`)}
                <span className="truncate">{tab.label}</span>
              </>
            )}
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
