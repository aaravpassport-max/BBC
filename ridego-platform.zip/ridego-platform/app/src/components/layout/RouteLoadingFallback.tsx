import { Skeleton } from '../ui/Skeleton';

/**
 * Shown inside AppLayout's <Suspense> boundary while a lazy-loaded
 * route's chunk downloads (see router.tsx). Reuses the same
 * animate-pulse Skeleton primitive every page already uses for its own
 * in-page data loading, so a route change and an in-page fetch look
 * like the same kind of "loading", not two different loading languages.
 */
export function RouteLoadingFallback() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6 lg:px-8" aria-busy="true" aria-label="Loading page">
      <Skeleton className="mb-6 h-8 w-1/3" />
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <div key={i} className="rounded-xl border border-ink-100 bg-white p-5 shadow-xs">
            <Skeleton className="mb-3 h-32 w-full rounded-lg" />
            <Skeleton className="mb-2 h-4 w-3/4" />
            <Skeleton className="h-3 w-1/2" />
          </div>
        ))}
      </div>
    </div>
  );
}
