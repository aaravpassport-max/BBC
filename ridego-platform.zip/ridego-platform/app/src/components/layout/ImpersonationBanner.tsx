import { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { apiRequest } from '../../lib/api';
import { roleLabel } from '../../lib/roles';
import { Button } from '../ui/Button';

// TRACE: AppLayout renders it on every route → when auth.impersonation is set, shows a sticky banner naming the
//        role being viewed, the admin behind it and a live countdown; "Exit view-as" POSTs /impersonate/stop and then
//        does a FULL page load to /app/admin so the nonce and cookies belong to the real admin again.
//        Preconditions: AuthProvider mounted. Postconditions: while exiting the button is disabled (no double POST);
//        on failure the banner stays and shows the error. Edge cases: not impersonating (renders null), countdown
//        reaching 0 (label says the session expired and Exit remains available), stop request failing (error shown).
export function ImpersonationBanner() {
  const { impersonation } = useAuth();
  const [secondsLeft, setSecondsLeft] = useState<number>(impersonation?.seconds_left ?? 0);
  const [exiting, setExiting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // TRACE: effect on impersonation.seconds_left → resets and ticks a 1s interval → interval cleared on unmount/change
  //        (no runaway timer). Edge case: value changes on /auth/me refresh (restarts from the new value).
  useEffect(() => {
    setSecondsLeft(impersonation?.seconds_left ?? 0);
    if (!impersonation) return undefined;
    const id = window.setInterval(() => setSecondsLeft((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => window.clearInterval(id);
  }, [impersonation]);

  // TRACE: click Exit → POST /impersonate/stop → on success window.location.assign('/admin') (full reload).
  //        Edge cases: repeated click while exiting (ignored), network/API failure (error message, button re-enabled).
  const exit = async () => {
    if (exiting) return;
    setExiting(true);
    setError(null);
    try {
      await apiRequest('/impersonate/stop', { method: 'POST', body: {} });
      window.location.assign('/admin');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not end the view-as session.');
      setExiting(false);
    }
  };

  if (!impersonation) return null;
  const mm = String(Math.floor(secondsLeft / 60)).padStart(2, '0');
  const ss = String(secondsLeft % 60).padStart(2, '0');

  return (
    <div role="status" className="sticky top-0 z-50 border-b border-amber-300 bg-amber-100 px-4 py-2 text-sm text-amber-900">
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-2">
        <p>
          <strong>Viewing as: {roleLabel(impersonation.target_role)}</strong> — signed in as admin {impersonation.admin_name}.{' '}
          {secondsLeft > 0 ? `Session ends in ${mm}:${ss}.` : 'The session has expired.'} Password and profile changes are disabled.
        </p>
        <div className="flex items-center gap-3">
          {error && <span className="text-danger-600">{error}</span>}
          <Button size="sm" variant="secondary" onClick={exit} loading={exiting} disabled={exiting} aria-label="Exit view-as session and return to the admin account">
            Return to Admin
          </Button>
        </div>
      </div>
    </div>
  );
}
