import { Suspense } from 'react';
import { Outlet, ScrollRestoration } from 'react-router-dom';
import { Header } from './Header';
import { ImpersonationBanner } from './ImpersonationBanner';
import { BackBar } from './BackBar';
import { Footer } from './Footer';
import { MobileBottomNav } from './MobileBottomNav';
import { RouteLoadingFallback } from './RouteLoadingFallback';
import { ToastViewport } from '../ui/ToastViewport';
import { InstallPrompt } from '../ui/InstallPrompt';

export function AppLayout() {
  return (
    <div className="flex min-h-screen flex-col bg-white text-ink-900">
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:absolute focus:left-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-brand-600 focus:px-4 focus:py-2 focus:text-white"
      >
        Skip to content
      </a>
      <ImpersonationBanner />
      <Header />
      {/*
        Mobile-first transformation, Phase 1: the bottom nav is fixed and
        sits below every route's content, so the content column needs
        matching bottom padding on mobile (removed again at `lg`, where
        the bottom nav itself is hidden) or the last few lines of every
        page would render underneath it. The extra `env(safe-area-inset-
        bottom)` term accounts for gesture-nav Android devices — see
        MobileBottomNav's own inline padding for the matching value on
        the nav bar itself.
      */}
      <main
        id="main-content"
        className="flex-1 pb-[calc(4rem+env(safe-area-inset-bottom,0px))] lg:pb-0"
      >
        <BackBar />
        <Suspense fallback={<RouteLoadingFallback />}>
          <Outlet />
        </Suspense>
      </main>
      <Footer />
      <MobileBottomNav />
      <ToastViewport />
      <InstallPrompt />
      <ScrollRestoration />
    </div>
  );
}
