import type { AppUser } from '../types/api';

export type UserKind = 'admin' | 'regional_manager' | 'staff' | 'driver' | 'vendor' | 'client' | 'guest';

// TRACE: signed-in user → which experience they get (dashboard, nav, home) → UserKind. Pure.
//        Precedence: team/driver roles first (they may hold admin caps through modules but are NOT admins), then
//        administrators/any admin-capability holder, then vendor, then client. Edge cases: null user → 'guest'.
export function userKind(user: AppUser | null | undefined): UserKind {
  if (!user) return 'guest';
  const r = user.roles ?? [];
  if (user.is_admin) return 'admin';
  if (r.includes('ridego_regional_manager')) return 'regional_manager';
  if (r.includes('ridego_staff')) return 'staff';
  if (r.includes('ridego_driver')) return 'driver';
  if ((user.admin_caps?.length ?? 0) > 0) return 'admin';
  if (user.is_vendor) return 'vendor';
  return 'client';
}

// TRACE: user → the path they should land on after sign-in / "home" → string. Pure.
export function roleHome(user: AppUser | null | undefined): string {
  switch (userKind(user)) {
    case 'admin':
      return '/admin';
    case 'regional_manager':
    case 'staff':
      return '/team';
    case 'driver':
      return '/driver';
    case 'vendor':
      return '/vendor/dashboard';
    default:
      return '/';
  }
}

// TRACE: role key from the server ('regional_manager', 'fleet_vendor'...) → human label → string. Pure.
export function roleLabel(key: string): string {
  const map: Record<string, string> = {
    regional_manager: 'Regional Manager', staff: 'Staff member', driver: 'Driver', vendor: 'Vendor', client: 'Client',
    fleet_vendor: 'Fleet Vendor', individual_vendor: 'Individual Vendor',
  };
  return map[key] ?? key;
}
