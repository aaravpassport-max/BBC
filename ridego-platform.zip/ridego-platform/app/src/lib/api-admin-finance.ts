import { apiRequest } from './api';

/* Typed client for the admin marketplace endpoints in includes/app-admin-marketplace-api.php
   that cover commission, ledger, performance, matching, impersonation, marketplace reports
   and the vendor fleet/type controls. Every function throws ApiError on a non-2xx response. */

export interface ActionResult {
  success?: boolean;
  message?: string;
}

// ---------------------------------------------------------------------------
// Commission
// ---------------------------------------------------------------------------

export type CommissionType = 'fixed' | 'percentage' | 'hybrid' | 'monthly';
export type CommissionRefundMode = 'none' | 'reverse';

export interface CommissionModel {
  id: number | string;
  name: string;
  type: CommissionType;
  fixed_amount: number | string;
  percentage: number | string;
  min_amount: number | string;
  monthly_fee: number | string;
  refund_adjustment: CommissionRefundMode;
  is_active: number | string | boolean;
  is_default: number | string | boolean;
  created_at?: string;
  updated_at?: string;
}

export interface CommissionModelsResponse {
  rows: CommissionModel[];
  types: Record<string, string>;
  refund_modes: CommissionRefundMode[];
}

export interface CommissionModelInput {
  name: string;
  type: CommissionType;
  fixed_amount: number;
  percentage: number;
  min_amount: number;
  monthly_fee: number;
  refund_adjustment: CommissionRefundMode;
  is_default: boolean;
  is_active: boolean;
}

// TRACE: commission page load → GET /admin/commission/models → models + type labels + refund modes.
//        Preconditions: cap ridego_manage_commission_models → postconditions: read-only → edge cases: empty rows, ApiError thrown.
export function getCommissionModels(): Promise<CommissionModelsResponse> {
  return apiRequest<CommissionModelsResponse>('/admin/commission/models');
}

// TRACE: create sheet submit → POST /admin/commission/models → { success, id } or validation message (ApiError).
//        Preconditions: input validated client-side → postconditions: one new model row (default flag cleared elsewhere) →
//        edge cases: server validation failure surfaces as ApiError.message.
export function createCommissionModel(body: CommissionModelInput): Promise<ActionResult & { id?: number }> {
  return apiRequest<ActionResult & { id?: number }>('/admin/commission/models', { method: 'POST', body });
}

// TRACE: edit sheet submit → PUT /admin/commission/models/:id → { success, message }.
//        Preconditions: model exists → postconditions: row updated; completed bookings keep their snapshot →
//        edge cases: unknown id or invalid input surfaces as ApiError.message.
export function updateCommissionModel(id: number, body: CommissionModelInput): Promise<ActionResult> {
  return apiRequest<ActionResult>(`/admin/commission/models/${id}`, { method: 'PUT', body });
}

// TRACE: assign panel submit → POST /admin/commission/assign {vendor_id, model_id} → { success, message }.
//        Preconditions: vendor exists, model active → postconditions: future completions use the model →
//        edge cases: inactive/unknown model or vendor surfaces as ApiError.message.
export function assignCommissionModel(vendorId: number, modelId: number): Promise<ActionResult> {
  return apiRequest<ActionResult>('/admin/commission/assign', { method: 'POST', body: { vendor_id: vendorId, model_id: modelId } });
}

// ---------------------------------------------------------------------------
// Ledger
// ---------------------------------------------------------------------------

export type LedgerStatus = 'pending' | 'settled';

export interface LedgerRow {
  id: number | string;
  booking_id: number | string;
  vendor_id: number | string | null;
  entry_type: string;
  amount: number | string;
  direction: 'credit' | 'debit';
  status: LedgerStatus;
  notes?: string;
  created_at: string;
  settled_at?: string | null;
  booking_number: string | null;
  business_name: string | null;
}

export interface LedgerSummary {
  commission: number;
  advance_held: number;
  fee_retained: number;
  fee_outstanding?: number;
  fee_total?: number;
  compensation?: number;
  reversals: number;
  pending_net: number;
  settled_net: number;
}

export interface LedgerPlatformNet {
  gross_commission: number;
  reversals: number;
  net: number;
}

export interface LedgerResponse {
  rows: LedgerRow[];
  total: number;
  page: number;
  per_page: number;
  summary: LedgerSummary;
  platform: LedgerPlatformNet;
}

export interface LedgerQuery {
  vendor_id?: number;
  status?: LedgerStatus | '';
  page?: number;
  from?: string;
  to?: string;
}

export interface SettleResponse extends ActionResult {
  net?: number;
}

// TRACE: ledger page filters change → GET /admin/ledger with only the supplied filters → rows + summary + platform net.
//        Preconditions: cap ridego_view_ledger → postconditions: read-only → edge cases: empty filters omitted, no rows.
export function getLedger(q: LedgerQuery = {}): Promise<LedgerResponse> {
  const qs = new URLSearchParams();
  if (q.vendor_id) qs.set('vendor_id', String(q.vendor_id));
  if (q.status) qs.set('status', q.status);
  if (q.page && q.page > 1) qs.set('page', String(q.page));
  if (q.from) qs.set('from', q.from);
  if (q.to) qs.set('to', q.to);
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return apiRequest<LedgerResponse>(`/admin/ledger${suffix}`);
}

// TRACE: settle confirm → POST /admin/ledger/settle {booking_id} → { success, net, message }.
//        Preconditions: cap ridego_settle_ledger, booking has pending rows → postconditions: rows settled or nothing changed →
//        edge cases: nothing pending / wallet shortfall surfaces as ApiError.message.
export function settleLedgerBooking(bookingId: number): Promise<SettleResponse> {
  return apiRequest<SettleResponse>('/admin/ledger/settle', { method: 'POST', body: { booking_id: bookingId } });
}

// ---------------------------------------------------------------------------
// Performance
// ---------------------------------------------------------------------------

export interface PerformanceSnapshot {
  period: string;
  bookings_completed: number;
  bookings_cancelled: number;
  response_time_avg_secs: number | null;
  completion_rate: number | null;
  cancellation_rate: number | null;
  avg_rating: number | null;
  on_time_pct: number | null;
  complaint_count: number;
}

/** Raw snapshot row joined with the vendor: the list endpoint returns DB values, so numbers may arrive as strings. */
export interface PerformanceListRow {
  entity_id: number | string;
  period: string;
  business_name: string;
  vendor_type: string | null;
  bookings_completed: number | string;
  bookings_cancelled: number | string;
  response_time_avg_secs: number | string | null;
  completion_rate: number | string | null;
  cancellation_rate: number | string | null;
  avg_rating: number | string | null;
  on_time_pct: number | string | null;
  complaint_count: number | string;
}

export interface PerformanceListResponse {
  rows: PerformanceListRow[];
}

export interface CategoryScore {
  avg: number;
  count: number;
}

export interface PerformanceEntity {
  trend: PerformanceSnapshot[];
  categories: Record<string, CategoryScore> | [];
}

export interface PerformanceDriver extends PerformanceEntity {
  id: number;
  name: string;
  rating: number;
}

export interface PerformanceVehicle extends PerformanceEntity {
  id: number;
  label: string;
}

export interface PerformanceDetail {
  vendor_type: string;
  vendor: PerformanceEntity;
  drivers: PerformanceDriver[];
  vehicles: PerformanceVehicle[];
}

// TRACE: performance list load → GET /admin/performance → latest-period snapshot per vendor (max 200).
//        Preconditions: cap ridego_view_performance_data → postconditions: read-only → edge cases: no snapshots (empty rows).
export function getPerformanceList(): Promise<PerformanceListResponse> {
  return apiRequest<PerformanceListResponse>('/admin/performance');
}

// TRACE: drill-down open → GET /admin/performance?vendor_id=N → trend, category breakdown, per-driver/vehicle detail.
//        Preconditions: vendor exists → postconditions: read-only → edge cases: 404 unknown vendor, empty trend.
export function getVendorPerformance(vendorId: number): Promise<PerformanceDetail> {
  return apiRequest<PerformanceDetail>(`/admin/performance?vendor_id=${vendorId}`);
}

// ---------------------------------------------------------------------------
// Matching
// ---------------------------------------------------------------------------

export type MatchingFlagKey = 'automatic_vendor_assignment' | 'automatic_driver_selection' | 'performance_based_matching' | 'automatic_reassignment';

export interface MatchingProfile {
  id: number;
  name: string;
  version: number;
  is_active: boolean;
  weights: Record<string, number>;
  created_at: string;
}

export interface MatchingRecommendation {
  id: number | string;
  booking_id: number | string;
  booking_number: string | null;
  recommended_vendor_id: number | string;
  vendor_name: string | null;
  score: number | string;
  was_followed: number | string | null;
  override_reason: string;
  created_at: string;
}

export interface MatchingResponse {
  flags: Record<MatchingFlagKey, boolean>;
  profile: MatchingProfile;
  profiles: MatchingProfile[];
  factors: string[];
  recent: MatchingRecommendation[];
  auto_assign_min_score: number;
}

export interface MatchingFlagsInput extends Partial<Record<MatchingFlagKey, boolean>> {
  auto_assign_min_score?: number;
}

export interface MatchingBacktestResponse {
  samples: number;
  agreement_pct: number;
  agreed_good_pct: number;
  disagreements: number;
  disagreements_actual_bad_pct: number;
}

// TRACE: matching page load → GET /admin/matching → flags, active weight profile, factor list, recent outcomes.
//        Preconditions: cap ridego_manage_automatic_assignment → postconditions: read-only → edge cases: no profile seeded (id 0 defaults).
export function getMatching(): Promise<MatchingResponse> {
  return apiRequest<MatchingResponse>('/admin/matching');
}

// TRACE: flag confirm → POST /admin/matching/flags with only the changed keys → refreshed matching payload.
//        Preconditions: operator confirmed → postconditions: settings written + audited → edge cases: min score clamped 0..100 server-side.
export function saveMatchingFlags(body: MatchingFlagsInput): Promise<MatchingResponse> {
  return apiRequest<MatchingResponse>('/admin/matching/flags', { method: 'POST', body });
}

// TRACE: save-as-new-version → POST /admin/matching/profile {name, weights} → { success, profile_id }.
//        Preconditions: weights non-negative with sum > 0 → postconditions: new normalised INACTIVE version (activate it
//        separately after back-testing) → edge cases: invalid weights surface as ApiError.message.
export function saveMatchingProfile(name: string, weights: Record<string, number>): Promise<ActionResult & { profile_id?: number }> {
  return apiRequest<ActionResult & { profile_id?: number }>('/admin/matching/profile', { method: 'POST', body: { name, weights } });
}

// TRACE: back-test click → POST /admin/matching/backtest {weights} or {profile_id} → replay summary over completed bookings.
//        Preconditions: none → postconditions: read-only replay → edge cases: zero samples, unknown profile (404 ApiError).
export function backtestMatching(input: { weights: Record<string, number> } | { profile_id: number }): Promise<MatchingBacktestResponse> {
  return apiRequest<MatchingBacktestResponse>('/admin/matching/backtest', { method: 'POST', body: input });
}

// TRACE: "Activate" click on a stored profile → POST /admin/matching/profile/:id/activate → { success, message }.
//        Preconditions: profile exists → postconditions: it becomes the only active profile → edge cases: unknown id (ApiError).
export function activateMatchingProfile(profileId: number): Promise<ActionResult> {
  return apiRequest<ActionResult>(`/admin/matching/profile/${profileId}/activate`, { method: 'POST' });
}

// ---------------------------------------------------------------------------
// Impersonation
// ---------------------------------------------------------------------------

export interface ImpersonateResponse extends ActionResult {
  expires_at?: string;
  target?: { user_id: number; role: string; name: string };
}

// TRACE: view-as confirm → POST /admin/impersonate {user_id} → { success, expires_at, target }.
//        Preconditions: cap ridego_impersonate, target is a client/vendor account → postconditions: signed session cookie set →
//        edge cases: self, admin target, unknown user surface as ApiError.message.
export function startImpersonation(userId: number): Promise<ImpersonateResponse> {
  return apiRequest<ImpersonateResponse>('/admin/impersonate', { method: 'POST', body: { user_id: userId } });
}

// ---------------------------------------------------------------------------
// Marketplace report
// ---------------------------------------------------------------------------

export interface MarketplaceReport {
  from: string;
  to: string;
  funnel: { bookings: number; with_leads: number; with_interest: number; assigned: number; completed: number };
  avg_minutes_to_interest: number | null;
  cancellations: { who: string; n: number | string }[];
  commission_by_vendor: { vendor_id: number | string; business_name: string; commission: number | string | null; bookings: number | string }[];
  volume_by_vendor_type: { vendor_type: string; bookings: number | string }[];
}

// TRACE: reports page filter change → GET /admin/reports/marketplace?from&to → funnel + breakdowns.
//        Preconditions: cap ridego_view_reports → postconditions: read-only → edge cases: blank dates (server defaults to last 30 days), empty range.
export function getMarketplaceReport(from?: string, to?: string): Promise<MarketplaceReport> {
  const qs = new URLSearchParams();
  if (from) qs.set('from', from);
  if (to) qs.set('to', to);
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return apiRequest<MarketplaceReport>(`/admin/reports/marketplace${suffix}`);
}

// ---------------------------------------------------------------------------
// Vendor fleet and type
// ---------------------------------------------------------------------------

export interface FleetVehicle {
  id: number | string;
  branch_id: number | string | null;
  make_model: string;
  registration_number: string;
  seating_capacity: number | string;
  status: string;
}

export interface FleetDriver {
  id: number | string;
  name: string;
  mobile: string;
  license_number: string;
  license_expiry: string | null;
  experience_years: number | string;
  rating: number | string;
  status: string;
  profile_complete?: boolean;
  profile_missing?: string[];
  [extra: string]: unknown;
}

export interface FleetBranch {
  id: number | string;
  name: string;
  address: string | null;
  city_name: string | null;
  is_primary: number | string;
  status: string;
}

export type DocValidity = 'valid' | 'expiring_soon' | 'expired' | 'no_expiry';

export interface FleetDoc {
  id: number | string;
  doc_type: string;
  status: string;
  expiry_date: string | null;
  vehicle_id: number | string | null;
  driver_id: number | string | null;
  validity: DocValidity;
}

export interface VendorFleet {
  vendor_type: string;
  vehicles: FleetVehicle[];
  drivers: FleetDriver[];
  branches: FleetBranch[];
  docs: FleetDoc[];
}

// TRACE: vendor detail fleet panel → GET /admin/vendors/:id/fleet → type, vehicles, drivers, branches, docs.
//        Preconditions: cap ridego_view_fleets → postconditions: read-only → edge cases: 404 unknown vendor, empty lists.
export function getVendorFleet(vendorId: number): Promise<VendorFleet> {
  return apiRequest<VendorFleet>(`/admin/vendors/${vendorId}/fleet`);
}

// TRACE: change-type confirm → POST /admin/vendors/:id/type {type} → { success, message }.
//        Preconditions: cap ridego_manage_vendors → postconditions: vendor_type updated, no fleet row deleted →
//        edge cases: fleet→individual with several active vehicles/drivers refused (ApiError.message verbatim).
export function setVendorType(vendorId: number, type: 'fleet' | 'individual'): Promise<ActionResult> {
  return apiRequest<ActionResult>(`/admin/vendors/${vendorId}/type`, { method: 'POST', body: { type } });
}

export type FleetEntityKind = 'vehicles' | 'drivers';

// TRACE: admin fleet override save → POST (create) or PUT (update when entityId given) /admin/vendors/:id/fleet/{vehicles|drivers}[/:eid] →
//        { success, message }. Preconditions: cap ridego_manage_fleet_vehicles → postconditions: row created/updated for that vendor, audit-logged →
//        edge cases: validation/duplicate-plate/individual-limit refusals come back as ApiError.message verbatim.
export function saveVendorFleetEntity(vendorId: number, kind: FleetEntityKind, body: Record<string, unknown>, entityId?: number | string): Promise<ActionResult> {
  const path = `/admin/vendors/${vendorId}/fleet/${kind}${entityId ? `/${entityId}` : ''}`;
  return apiRequest<ActionResult>(path, { method: entityId ? 'PUT' : 'POST', body });
}

// TRACE: admin fleet override delete → DELETE /admin/vendors/:id/fleet/{vehicles|drivers}/:eid → { success, message }.
//        Preconditions: cap ridego_manage_fleet_vehicles → edge cases: entity on a live trip refused by the server (message verbatim).
export function deleteVendorFleetEntity(vendorId: number, kind: FleetEntityKind, entityId: number | string): Promise<ActionResult> {
  return apiRequest<ActionResult>(`/admin/vendors/${vendorId}/fleet/${kind}/${entityId}`, { method: 'DELETE' });
}
