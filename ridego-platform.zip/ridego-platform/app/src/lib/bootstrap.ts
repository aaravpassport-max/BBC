import type { AuthState } from '../types/api';

export interface RideGoBootstrap {
  apiUrl: string;
  siteUrl: string;
  appUrl: string;
  currencySymbol: string;
  branding?: Record<string, unknown>;
  auth: AuthState;
}

declare global {
  interface Window {
    __RIDEGO__?: RideGoBootstrap;
  }
}

// Sensible dev defaults so `npm run dev` never crashes when the PHP shell
// (includes/app-shell.php) isn't there to inject window.__RIDEGO__.
const DEV_DEFAULTS: RideGoBootstrap = {
  apiUrl: 'http://localhost/wp-json/ridego/v1/app',
  siteUrl: 'http://localhost/',
  appUrl: 'http://localhost/app/',
  currencySymbol: '₹',
  auth: {
    logged_in: false,
    nonce: '',
  },
};

export function getBootstrap(): RideGoBootstrap {
  if (typeof window !== 'undefined' && window.__RIDEGO__) {
    return window.__RIDEGO__;
  }
  if (typeof window !== 'undefined') {
    // eslint-disable-next-line no-console
    console.warn(
      '[RideGo] window.__RIDEGO__ not found — falling back to dev defaults. ' +
        'This is expected under `npm run dev`; the WordPress shell injects the real values in production.'
    );
  }
  return DEV_DEFAULTS;
}
