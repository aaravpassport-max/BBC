import { apiRequest, apiUrl, getNonce, ApiError } from './api';

/* Typed client for includes/app-team-api.php: team members, regions, tasks, team dashboard, driver logins and the
   "view as" directory. Every function throws ApiError on a non-2xx response. */

export interface TeamModule { key: string; label: string; description: string }
export interface TeamMember {
  id: number; name: string; email: string; phone: string; role: 'ridego_regional_manager' | 'ridego_staff'; active: boolean;
  modules: string[]; region_ids: number[]; region_scope: 'assigned' | 'all';
}
export interface Region {
  id: number; name: string; region_type: string; states: string[]; cities: string[]; status: 'active' | 'inactive'; resolved_cities: string[];
}
export interface TeamListResponse { members: TeamMember[]; modules: TeamModule[]; regions: Region[] }
export interface TeamMemberInput {
  name: string; email?: string; phone: string; password?: string; role?: string; modules: string[]; region_ids: number[];
  region_scope: 'assigned' | 'all'; active?: boolean;
}
export interface Task {
  id: number; title: string; description: string; assigned_to: number; assigned_name: string; status: 'open' | 'in_progress' | 'done';
  priority: 'low' | 'normal' | 'high'; due_date: string | null; booking_id: number | null; created_at: string;
}
export interface TaskInput { title: string; description: string; assigned_to: number; priority: string; due_date: string; status?: string }
export interface DirectoryUser { id: number; name: string; email: string; role: string; label: string }
export interface TeamDashboard {
  role: string; name: string; modules: string[]; is_regional_manager: boolean; tasks: { open: number; in_progress: number; done: number };
  regions?: string[]; region_scope?: 'assigned' | 'all'; no_region?: boolean;
  counts?: { total: number; awaiting_payment: number; needs_vendor: number; active_trips: number; today: number };
  recent?: { id: number; booking_number: string; pickup_city: string; drop_city: string; journey_date: string; status: string }[];
}
export interface DriverTripSummary {
  id: number; booking_number: string; trip_type: string; pickup_city: string; drop_city: string; pickup_address: string;
  drop_address?: string; journey_date: string; journey_time: string; status: string; passengers?: number;
  driver_en_route_at: string | null; driver_arrived_at: string | null; trip_started_at: string | null;
  client_name?: string; client_phone?: string;
}
export interface DriverMe {
  profile: { id: number; name: string; mobile: string; license_number: string; license_expiry: string | null; status: string };
  doc_types: string[];
  docs: { id: number; doc_type: string; status: string; expiry_date: string | null; validity: string; uploaded_at: string }[];
  trips: DriverTripSummary[];
  /** The server's real enforced ceiling (min of plugin policy and PHP's upload_max_filesize/post_max_size),
   *  in whole/fractional MB — always use this over any hardcoded client-side limit so the UI hint and the
   *  actual server behavior can never drift apart again. */
  max_upload_mb: number;
}
export interface DriverTripDetail {
  id: number; booking_number: string; trip_type: string; status: string; pickup_city: string; drop_city: string;
  pickup_address: string; drop_address: string; journey_date: string; journey_time: string; passengers: number;
  luggage_count: number; client_name: string; client_phone: string | null; special_requests: string;
  driver_en_route_at: string | null; driver_arrived_at: string | null; trip_started_at: string | null;
  trip_ended_at: string | null; no_show_reason: string | null; is_current_assignment: boolean;
}
export interface DriverTripHistoryRow {
  id: number; booking_number: string; trip_type: string; pickup_city: string; drop_city: string;
  journey_date: string; journey_time: string; status: string; trip_ended_at: string | null;
}
export interface DriverEarningsRow {
  id: number; booking_id: number | null; entry_type: string; amount: number; note: string | null; recorded_by: string; created_at: string;
}
export interface DriverEarnings { balance: number; rows: DriverEarningsRow[] }

// TRACE: admin Team & access → GET /admin/team → { members, modules, regions }. Edge cases: 403 for non-administrators.
export const getTeam = () => apiRequest<TeamListResponse>('/admin/team');
// TRACE: create form submit → POST /admin/team → { member }. Edge cases: 409 duplicate email, 400 validation.
export const createTeamMember = (b: TeamMemberInput) => apiRequest<{ member: TeamMember }>('/admin/team', { method: 'POST', body: b });
// TRACE: edit form submit → PUT /admin/team/{id} → { member }.
export const updateTeamMember = (id: number, b: TeamMemberInput) => apiRequest<{ member: TeamMember }>(`/admin/team/${id}`, { method: 'PUT', body: b });
// TRACE: "Send password reset" → POST /admin/team/{id}/reset-password → { ok }.
export const resetTeamPassword = (id: number) => apiRequest<{ ok: boolean }>(`/admin/team/${id}/reset-password`, { method: 'POST', body: {} });

export const getRegions = () => apiRequest<{ regions: Region[]; states: string[]; cities: { name: string; state: string }[] }>('/admin/regions');
export const saveRegion = (id: number | null, b: { name: string; region_type: string; states: string[]; cities: string[]; status: string }) =>
  apiRequest<{ region: Region }>(id ? `/admin/regions/${id}` : '/admin/regions', { method: id ? 'PUT' : 'POST', body: b });
export const deleteRegion = (id: number) => apiRequest<{ ok: boolean }>(`/admin/regions/${id}/delete`, { method: 'POST', body: {} });

export const getDirectory = (role: string, q: string) =>
  apiRequest<{ users: DirectoryUser[] }>(`/admin/users?role=${encodeURIComponent(role)}&q=${encodeURIComponent(q)}`);

export const getAdminTasks = () => apiRequest<{ tasks: Task[] }>('/admin/tasks');
export const createTask = (b: TaskInput) => apiRequest<{ task: Task }>('/admin/tasks', { method: 'POST', body: b });
export const updateTask = (id: number, b: TaskInput) => apiRequest<{ task: Task }>(`/admin/tasks/${id}`, { method: 'PUT', body: b });
export const getTeamDashboard = () => apiRequest<TeamDashboard>('/team/dashboard');
export const getMyTasks = () => apiRequest<{ tasks: Task[] }>('/team/tasks');
export const setMyTaskStatus = (id: number, status: string) => apiRequest<{ task: Task }>(`/team/tasks/${id}/status`, { method: 'POST', body: { status } });

// TRACE: vendor "Create driver login" → POST /vendor/drivers/{id}/login → { ok, user_id }. Edge cases: 409 exists, 400 invalid.
export const createDriverLogin = (driverId: number, b: { email: string; password: string }) =>
  apiRequest<{ ok: boolean; user_id: number }>(`/vendor/drivers/${driverId}/login`, { method: 'POST', body: b });

export const getDriverMe = () => apiRequest<DriverMe>('/driver/me');

// TRACE: driver document upload → multipart POST /driver/docs → { success, doc_id }. Edge cases: server rejection surfaces the
//        message; non-JSON body yields a generic ApiError; network failure rejects.
export async function uploadDriverOwnDoc(docType: string, file: File, expiryDate: string): Promise<{ success: boolean }> {
  const form = new FormData();
  form.set('doc_type', docType);
  form.set('file', file);
  if (expiryDate) form.set('expiry_date', expiryDate);
  const res = await fetch(apiUrl('/driver/docs'), { method: 'POST', credentials: 'include', headers: { 'X-WP-Nonce': getNonce() }, body: form });
  let payload: unknown = null;
  try { payload = await res.json(); } catch { payload = null; }
  if (!res.ok) {
    const e = payload as { code?: string; message?: string; data?: { status: number } } | null;
    throw new ApiError({ code: e?.code ?? 'unknown_error', message: e?.message ?? `Upload failed with status ${res.status}`, data: e?.data ?? { status: res.status } });
  }
  return payload as { success: boolean };
}

// TRACE: driver "View" → GET /driver/docs/{id}/file → blob object URL (caller revokes). Edge cases: 404 → ApiError.
export async function fetchDriverDocUrl(id: number): Promise<string> {
  const res = await fetch(apiUrl(`/driver/docs/${id}/file`), { credentials: 'include', headers: { 'X-WP-Nonce': getNonce() } });
  if (!res.ok) throw new ApiError({ code: 'not_found', message: 'Could not open this document.', data: { status: res.status } });
  return URL.createObjectURL(await res.blob());
}

// TRACE: driver trip detail page → GET /driver/trips/{id} → full trip record (current or past assignment). Edge: 404 not assigned/owned.
export const getDriverTrip = (id: number) => apiRequest<DriverTripDetail>(`/driver/trips/${id}`);
// TRACE: driver trip history tab → GET /driver/trips/history → past trips (completed/cancelled/no_show/expired), newest first.
export const getDriverTripHistory = () => apiRequest<{ rows: DriverTripHistoryRow[] }>('/driver/trips/history');
// TRACE: driver "Mark en route" → POST /driver/trips/{id}/en-route → { success, message }. Edge: 409 wrong starting status.
export const driverTripEnRoute = (id: number) => apiRequest<{ success: boolean; message: string }>(`/driver/trips/${id}/en-route`, { method: 'POST', body: {} });
// TRACE: driver "Mark arrived" → POST /driver/trips/{id}/arrived → { success, message }. Edge: 409 wrong status/already arrived.
export const driverTripArrived = (id: number) => apiRequest<{ success: boolean; message: string }>(`/driver/trips/${id}/arrived`, { method: 'POST', body: {} });
// TRACE: driver "Start trip" (OTP from client) → POST /driver/trips/{id}/start { otp } → { success, message }. Edge: 400 wrong OTP, 409 not arrived.
export const driverTripStart = (id: number, otp: string) => apiRequest<{ success: boolean; message: string }>(`/driver/trips/${id}/start`, { method: 'POST', body: { otp } });
// TRACE: driver "Report no-show" → POST /driver/trips/{id}/no-show { reason } → { success, message }. Edge: 400 blank reason, 409 not arrived.
export const driverTripNoShow = (id: number, reason: string) => apiRequest<{ success: boolean; message: string }>(`/driver/trips/${id}/no-show`, { method: 'POST', body: { reason } });
// TRACE: driver earnings/wallet screen → GET /driver/earnings → { balance, rows }.
export const getDriverEarnings = () => apiRequest<DriverEarnings>('/driver/earnings');
