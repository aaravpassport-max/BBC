import { ApiError, apiRequest } from './api';
import type { RideMoney } from '../types/api';

export type TripTab = 'upcoming' | 'ongoing' | 'completed' | 'cancelled';

export const TRIP_TABS: { key: TripTab; label: string }[] = [
  { key: 'upcoming', label: 'Upcoming' },
  { key: 'ongoing', label: 'Ongoing' },
  { key: 'completed', label: 'Completed' },
  { key: 'cancelled', label: 'Cancelled' },
];

export interface AttentionItem {
  code: 'payment_pending' | 'payment_rejected' | 'refund_due' | 'rating_due' | string;
  message: string;
}

export interface HomeAttentionItem extends AttentionItem {
  booking_id: number;
  booking_number: string;
}

export interface ClientTrip extends RideMoney {
  id: number;
  booking_number: string;
  status: string;
  status_label: string;
  group: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string;
  journey_time: string;
  trip_type: string;
  total_fare: number;
  advance_paid: number;
  balance_due: number;
  payment_status: string;
  rating: number | null;
  attention: AttentionItem[];
  created_at: string;
}

export interface ClientHomeResponse {
  counts: Record<TripTab, number>;
  next_trip: ClientTrip | null;
  attention: HomeAttentionItem[];
  recent: ClientTrip[];
  open_complaints: number;
}

export interface ClientTripsResponse {
  tab: TripTab;
  rows: ClientTrip[];
  total: number;
  page: number;
  per_page: number;
}

export interface TimelineStep {
  key: string;
  label: string;
  done: boolean;
  at: string | null;
}

export interface TripAssignment {
  driver_name: string;
  driver_phone: string | null;
  vehicle_model: string;
  vehicle_registration: string;
}

export interface TripComplaintSummary {
  complaint_id: string;
  category: string;
  status: string;
  created_at: string;
}

export interface ClientTripDetail extends ClientTrip {
  pickup_address: string;
  drop_address: string;
  passengers: number;
  special_requests: string;
  vendor_name: string | null;
  assignment: TripAssignment | null;
  otp: string | null;
  timeline: TimelineStep[];
  rating_state: { client_rated: boolean; vendor_rated: boolean };
  rating_categories: { vendor: string[]; driver: string[] };
  complaints: TripComplaintSummary[];
  can_cancel: boolean;
  platform_notice?: string;
  vendor_phone?: string | null;
}

export interface InvoiceLine {
  label: string;
  amount: number;
}

export interface ClientInvoice {
  invoice_number: string;
  booking_number: string;
  issued_on: string;
  client_name: string;
  route: string;
  journey_date: string;
  lines: InvoiceLine[];
  total: number;
  paid_online: number;
  balance_due: number;
  status: string;
  document_type?: 'booking_receipt';
  receipt_number?: string;
  estimate_lines?: InvoiceLine[];
  estimated_ride_fare?: number;
  booking_amount?: number;
  booking_amount_pending?: number;
  ride?: {
    vendor_name: string;
    vendor_phone: string;
    payable_to_vendor: number;
    vendor_collected: number;
    vendor_outstanding: number;
    collection_status: string;
    vendor_invoice_number: string;
  };
  disclaimer?: string;
}

export interface RatePayload {
  vendor: Record<string, number>;
  driver: Record<string, number>;
  review: string;
}

export interface ClientComplaint {
  complaint_id: string;
  booking_id: number;
  booking_number: string | null;
  category: string;
  description: string;
  status: string;
  resolution: string | null;
  created_at: string;
}

export interface ClientSupportResponse {
  rows: ClientComplaint[];
}

export interface SupportCreatePayload {
  booking_id: number;
  category: string;
  description: string;
}

export interface ClientAddress {
  id: string;
  label: string;
  address: string;
  city: string;
}

export interface ClientAddressesResponse {
  rows: ClientAddress[];
}

export interface ActionResult {
  success?: boolean;
  message?: string;
}

export const COMPLAINT_CATEGORIES: { value: string; label: string }[] = [
  { value: 'driver_misconduct', label: 'Driver behaviour' },
  { value: 'vehicle_condition', label: 'Vehicle condition' },
  { value: 'late_arrival', label: 'Late arrival' },
  { value: 'overcharge', label: 'Overcharge or billing' },
  { value: 'payment_dispute', label: 'Payment problem' },
  { value: 'safety', label: 'Safety concern' },
  { value: 'other', label: 'Something else' },
];

// TRACE: tab key → GET /client/home → parsed home payload.
//        none → resolves counts/next trip/attention/recent → ApiError on failure (401, network).
export function getClientHome(): Promise<ClientHomeResponse> {
  return apiRequest<ClientHomeResponse>('/client/home');
}

// TRACE: tab + page → GET /client/trips → one page of that tab's trips.
//        tab valid, page >= 1 → rows + total → server falls back to upcoming for an unknown tab.
export function getClientTrips(tab: TripTab, page: number): Promise<ClientTripsResponse> {
  return apiRequest<ClientTripsResponse>(`/client/trips?tab=${encodeURIComponent(tab)}&page=${page}`);
}

// TRACE: booking id → GET /client/trips/:id → full trip detail.
//        id numeric → detail → 404 for a trip that is not the caller's (ApiError).
export function getClientTrip(id: number): Promise<ClientTripDetail> {
  return apiRequest<ClientTripDetail>(`/client/trips/${id}`);
}

// TRACE: booking id → GET /client/trips/:id/invoice → invoice JSON.
//        id numeric → invoice → 400 while payment is still pending (ApiError with human message).
export function getClientInvoice(id: number): Promise<ClientInvoice> {
  return apiRequest<ClientInvoice>(`/client/trips/${id}/invoice`);
}

// TRACE: booking id + category scores + review → POST /client/trips/:id/rate → result.
//        trip completed and unrated → rating stored → duplicate/not-completed rejected with ApiError.
export function rateClientTrip(id: number, payload: RatePayload): Promise<ActionResult> {
  return apiRequest<ActionResult>(`/client/trips/${id}/rate`, { method: 'POST', body: payload });
}

// TRACE: booking id + reason → POST /bookings/:id/cancel (existing endpoint) → result.
//        booking owned by caller → cancelled → ApiError for a non-cancellable booking.
export function cancelClientTrip(id: number, reason: string): Promise<ActionResult> {
  return apiRequest<ActionResult>(`/bookings/${id}/cancel`, { method: 'POST', body: { reason } });
}

// TRACE: none → GET /client/support → caller's complaints (max 50).
//        logged in → rows → empty list when none.
export function getClientSupport(): Promise<ClientSupportResponse> {
  return apiRequest<ClientSupportResponse>('/client/support');
}

// TRACE: booking id + category + description → POST /client/support → result.
//        booking owned → complaint filed → ApiError for missing fields or foreign booking.
export function createClientComplaint(payload: SupportCreatePayload): Promise<ActionResult> {
  return apiRequest<ActionResult>('/client/support', { method: 'POST', body: payload });
}

// TRACE: none → GET /client/addresses → saved addresses.
//        logged in → rows → empty list when none.
export function getClientAddresses(): Promise<ClientAddressesResponse> {
  return apiRequest<ClientAddressesResponse>('/client/addresses');
}

// TRACE: label/address/city → POST /client/addresses → updated list.
//        label + address non-empty, under 10 saved → stored → ApiError at the limit or on blank input.
export function saveClientAddress(input: { label: string; address: string; city: string }): Promise<ClientAddressesResponse> {
  return apiRequest<ClientAddressesResponse>('/client/addresses', { method: 'POST', body: input });
}

// TRACE: address id → DELETE /client/addresses/:id → updated list.
//        id is the 8-hex server id → removed → ApiError 404 for an unknown id.
export function deleteClientAddress(id: string): Promise<ClientAddressesResponse> {
  return apiRequest<ClientAddressesResponse>(`/client/addresses/${encodeURIComponent(id)}`, { method: 'DELETE' });
}

// TRACE: number → formatted rupee string.
//        finite number → "₹1,234" style text → non-finite input renders as ₹0.
export function formatMoney(n: number): string {
  const safe = Number.isFinite(n) ? n : 0;
  return `₹${safe.toLocaleString('en-IN', { maximumFractionDigits: 2 })}`;
}

// TRACE: 'YYYY-MM-DD' (or datetime) string → human date.
//        parsable → "20 Sep 2026" → empty or unparsable input returns the raw text (or a dash).
export function formatDate(value: string | null | undefined): string {
  if (!value) return '—';
  const d = new Date(value.length === 10 ? `${value}T00:00:00` : value.replace(' ', 'T'));
  if (Number.isNaN(d.getTime())) return value;
  return d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

// TRACE: 'HH:MM:SS' → 'HH:MM'.
//        time string → trimmed to hours and minutes → empty input returns an empty string.
export function formatTime(value: string | null | undefined): string {
  return value ? value.slice(0, 5) : '';
}

// TRACE: snake_case status/category text → Title case words.
//        any string → readable label → empty input returns an empty string.
export function humanize(value: string): string {
  const spaced = value.replace(/_/g, ' ').trim();
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

// TRACE: booking status group → Tailwind badge classes.
//        group string → classes with AA contrast → unknown group gets the neutral style.
export function statusClasses(group: string): string {
  if (group === 'completed') return 'bg-success-50 text-success-600';
  if (group === 'cancelled') return 'bg-danger-50 text-danger-600';
  if (group === 'ongoing') return 'bg-brand-50 text-brand-700';
  if (group === 'upcoming') return 'bg-warning-50 text-warning-600';
  return 'bg-ink-100 text-ink-700';
}

// TRACE: attention code → short badge label.
//        code string → label → unknown codes are humanized.
export function attentionLabel(code: string): string {
  if (code === 'payment_pending') return 'Booking amount pending';
  if (code === 'payment_rejected') return 'Payment rejected';
  if (code === 'refund_due') return 'Refund due';
  if (code === 'rating_due') return 'Rate your trip';
  return humanize(code);
}

// TRACE: any thrown value → user-facing message.
//        ApiError → its own message → anything else (network, programming error) gets the fallback text.
export function errorMessage(err: unknown, fallback: string): string {
  return err instanceof ApiError && err.message ? err.message : fallback;
}
