import { useRef } from 'react';

// TRACE: any callback prop that changes identity on every parent render (inline arrow functions) → returns a stable ref whose .current is always the newest value → ref.
//        Purpose: effects that install listeners or move focus (modals, sheets) must depend on open/closed state only. If they depend on a callback prop, every keystroke inside the popup re-renders the parent, the effect cleanup runs (focus is thrown back to the opener) and the effect runs again (focus jumps to the first control), so typing loses the cursor and a space press lands on a button and closes the popup.
//        Preconditions: none. Postconditions: reading ref.current inside an event handler gives the latest callback. Edge cases: first render (value assigned immediately), undefined callback (stored as is).
export function useLatest<T>(value: T) {
  const ref = useRef(value);
  ref.current = value;
  return ref;
}
