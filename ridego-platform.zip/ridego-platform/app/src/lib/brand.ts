import { getBootstrap } from './bootstrap';

export interface Branding {
  otp_enabled: boolean;
  email_otp_enabled: boolean;
  name: string;
  tagline: string;
  legal_name: string;
  logo_url: string;
  favicon_url: string;
  hero_image_url: string;
  hero_headline: string;
  hero_subtext: string;
  hero_show_text: string;
  hero_overlay: string;
  hero_secondary_image_url: string;
  hero_secondary_height: string;
  hero_secondary_fit: string;
  vehicle_card_height: string;
  vehicle_card_fit: string;
  vehicle_detail_height: string;
  vehicle_detail_fit: string;
  support_phone: string;
  support_whatsapp: string;
  support_email: string;
  address: string;
  website_url: string;
  business_hours: string;
  social: { facebook: string; instagram: string; twitter: string; youtube: string; linkedin: string };
  copyright: string;
  legal_info: string;
  gstin: string;
  footer_note: string;
  email_signature: string;
}

// The only fallback used when the server sent no branding (npm run dev without WordPress). Production always gets the saved Settings → Branding & business values.
const DEV_BRANDING: Branding = {
  otp_enabled: true,
  email_otp_enabled: false,
  name: 'RideGo',
  tagline: '',
  legal_name: 'RideGo',
  logo_url: '',
  favicon_url: '',
  hero_image_url: '',
  hero_headline: '',
  hero_subtext: '',
  hero_show_text: 'show',
  hero_overlay: 'medium',
  hero_secondary_image_url: '',
  hero_secondary_height: '320',
  hero_secondary_fit: 'cover',
  vehicle_card_height: '144',
  vehicle_card_fit: 'contain',
  vehicle_detail_height: '440',
  vehicle_detail_fit: 'cover',
  support_phone: '',
  support_whatsapp: '',
  support_email: '',
  address: '',
  website_url: '',
  business_hours: '',
  social: { facebook: '', instagram: '', twitter: '', youtube: '', linkedin: '' },
  copyright: '',
  legal_info: '',
  gstin: '',
  footer_note: '',
  email_signature: '',
};

// TRACE: any screen needing brand or business details → returns the branding injected by the WordPress shell (window.__RIDEGO__.branding), with every missing field falling back to '' (name falls back to the dev default) → Branding. Pure read; never throws.
export function brand(): Branding {
  const b = (getBootstrap() as { branding?: Partial<Branding> }).branding;
  if (!b) return DEV_BRANDING;
  return { ...DEV_BRANDING, ...b, name: b.name || DEV_BRANDING.name, social: { ...DEV_BRANDING.social, ...(b.social ?? {}) } };
}

// TRACE: a saved pixel-height string + its fallback → an exact `{ height: 'Npx' }` inline style → object. Blank/non-numeric/zero-or-negative value → the fallback, so an un-configured or bad install keeps a sane box height. This gives real per-pixel control (not a fixed preset) since the admin now types an exact number.
export function heightStyle(value: string, fallbackPx: number): { height: string } {
  const n = parseInt(value, 10);
  return { height: `${Number.isFinite(n) && n > 0 ? n : fallbackPx}px` };
}

// TRACE: a saved "cover"/"contain"/"fill" image-fit option → the matching object-fit Tailwind class → string. Unknown/blank value → object-contain (the safest default: never crops, never stretches).
export function fitClass(value: string): string {
  return value === 'cover' ? 'object-cover' : value === 'fill' ? 'object-fill' : 'object-contain';
}

// ROOT-CAUSE FIX: this is a single-page app — window.__RIDEGO__.branding is
// injected exactly once, by the server, into the first HTML document the
// browser loads. Every later screen the visitor reaches by clicking through
// the app (client-side routing, no full navigation) reads that SAME
// in-memory object via brand()/getBootstrap(), which never re-fetches
// anything on its own. So after Settings → Branding & business saves a
// change, any other already-open or client-routed-to screen kept showing
// the value that was true when THIS TAB first loaded — not what was just
// saved — until the visitor did a full browser reload of that exact page.
// That is exactly the bug reported: the home page (which the visitor had
// just force-reloaded) reflected a change, while the vehicle detail page
// (reached by clicking through, not reloading) did not.
// TRACE: a branding save/upload just succeeded → re-fetches the public
//        GET /app/branding payload and overwrites window.__RIDEGO__.branding
//        in place → void. Every later brand() call in this tab — on any
//        page, reached any way, no reload required — now returns the fresh
//        values immediately. Edge cases: refetch failure is swallowed (the
//        save itself already succeeded; the tab simply falls back to
//        needing a manual reload, same as before this fix existed).
export async function refreshBootstrapBranding(): Promise<void> {
  try {
    const res = await fetch(`${getBootstrap().apiUrl}/branding`, { credentials: 'include' });
    if (!res.ok) return;
    const fresh = (await res.json()) as Record<string, unknown>;
    if (typeof window !== 'undefined' && window.__RIDEGO__) {
      window.__RIDEGO__.branding = fresh;
    }
  } catch {
    // Best-effort only — see TRACE above.
  }
}
