import { apiRequest, apiUrl, getNonce, ApiError } from './api';
import type { RideMoney, LeadFeeView } from '../types/api';

/* ------------------------------------------------------------------ */
/* Shared primitives                                                   */
/* ------------------------------------------------------------------ */

export type VendorType = 'individual' | 'fleet';
export type EntityKind = 'vehicle' | 'driver';
export type LiveStatus = 'available' | 'on_trip' | 'unavailable';
export type DocValidity = 'valid' | 'expiring_soon' | 'expired' | 'no_expiry';

export interface MutationResult {
  success: boolean;
  message: string;
  warning?: string;
}

export interface CreateResult extends MutationResult {
  id: number;
}

export interface DeleteResult extends MutationResult {
  mode: 'deleted' | 'deactivated';
}

// TRACE: any normaliser → coerces a WordPress row value (numeric columns arrive as strings) → finite number.
//        Preconditions: none. Postconditions: never NaN. Edge cases: null/undefined/'' → fallback; junk text → fallback.
function num(value: unknown, fallback = 0): number {
  if (value === null || value === undefined || value === '') return fallback;
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

// TRACE: any normaliser → coerces a nullable numeric column → number or null.
//        Preconditions: none. Postconditions: null stays null. Edge cases: '' and junk → null.
function numOrNull(value: unknown): number | null {
  if (value === null || value === undefined || value === '') return null;
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

// TRACE: any normaliser → coerces a nullable text column → string ('' when absent).
//        Preconditions: none. Postconditions: always a string. Edge cases: null/undefined → ''.
function str(value: unknown): string {
  return value === null || value === undefined ? '' : String(value);
}

/* ------------------------------------------------------------------ */
/* Fleet                                                               */
/* ------------------------------------------------------------------ */

export interface FleetVehicle {
  id: number;
  branch_id: number | null;
  vehicle_type_id: number;
  make_model: string;
  registration_number: string;
  seating_capacity: number;
  status: 'active' | 'inactive' | 'maintenance';
  live_status: LiveStatus;
  /** Server-maintained atomic counter — send back as expectedLockVersion on the next edit for optimistic locking. */
  lock_version: number;
}

export interface FleetDriver {
  id: number;
  branch_id: number | null;
  name: string;
  mobile: string;
  license_number: string;
  license_expiry: string | null;
  /** Server-maintained atomic counter — send back as expectedLockVersion on the next edit for optimistic locking. */
  lock_version: number;
  experience_years: number;
  service_area_note: string;
  rating: number;
  status: 'active' | 'inactive';
  live_status: LiveStatus;
  alt_mobile: string;
  date_of_birth: string;
  blood_group: string;
  address: string;
  city: string;
  pincode: string;
  license_class: string;
  badge_number: string;
  emergency_contact_name: string;
  emergency_contact_phone: string;
  emergency_contact_relation: string;
  id_proof_type: string;
  id_proof_number: string;
  police_verification_status: string;
  police_verification_date: string;
  profile_missing: string[];
  profile_complete: boolean;
  /** WordPress user id of the driver's own login, or null when none exists. */
  user_id?: number | string | null;
}

export interface VendorBranch {
  id: number;
  name: string;
  address: string;
  city_id: number;
  city_name: string;
  is_primary: boolean;
  status: 'active' | 'inactive';
}

export interface FleetOverview {
  vendor_type: VendorType;
  vehicles: FleetVehicle[];
  drivers: FleetDriver[];
  branches: VendorBranch[];
}

export interface VehicleInput {
  make_model?: string;
  registration_number?: string;
  vehicle_type_id?: number;
  seating_capacity?: number;
  status?: FleetVehicle['status'];
  branch_id?: number;
}

export interface DriverInput {
  name?: string;
  mobile?: string;
  license_number?: string;
  license_expiry?: string;
  experience_years?: number;
  service_area_note?: string;
  status?: FleetDriver['status'];
  branch_id?: number;
  alt_mobile?: string;
  date_of_birth?: string;
  blood_group?: string;
  address?: string;
  city?: string;
  pincode?: string;
  license_class?: string;
  badge_number?: string;
  emergency_contact_name?: string;
  emergency_contact_phone?: string;
  emergency_contact_relation?: string;
  id_proof_type?: string;
  id_proof_number?: string;
  police_verification_status?: string;
  police_verification_date?: string;
}

export interface BranchInput {
  name: string;
  address: string;
  city_id: number;
  is_primary: boolean;
  status: 'active' | 'inactive';
}

export interface UnavailabilityBlock {
  id: number;
  entity_type: EntityKind;
  entity_id: number;
  starts_at: string;
  ends_at: string;
  reason: string;
}

export interface UnavailabilityInput {
  entity_type: EntityKind;
  entity_id: number;
  starts_at: string;
  ends_at: string;
  reason: string;
}

export interface UnavailabilityResult extends CreateResult {
  conflicts: string[];
}

export interface FleetDoc {
  id: number;
  doc_type: string;
  status: string;
  expiry_date: string | null;
  uploaded_at: string;
  validity: DocValidity;
}

export interface FleetDocsResponse {
  docs: FleetDoc[];
  doc_types: string[];
  /** The server's real enforced ceiling (min of plugin policy and PHP's upload_max_filesize/post_max_size),
   *  in whole/fractional MB — always use this over any hardcoded client-side limit. */
  max_upload_mb: number;
}

// TRACE: getVendorFleet → maps one raw vehicle row (string numerics) → typed FleetVehicle.
//        Preconditions: raw is an object. Postconditions: numbers are numbers, branch null when unset.
//        Edge cases: missing live_status → 'unavailable'; unknown status text → 'inactive'.
function toVehicle(raw: Record<string, unknown>): FleetVehicle {
  const st = str(raw.status);
  const live = str(raw.live_status);
  return {
    id: num(raw.id),
    branch_id: numOrNull(raw.branch_id),
    vehicle_type_id: num(raw.vehicle_type_id),
    make_model: str(raw.make_model),
    registration_number: str(raw.registration_number),
    seating_capacity: num(raw.seating_capacity, 4),
    status: st === 'active' || st === 'maintenance' ? st : 'inactive',
    live_status: live === 'available' || live === 'on_trip' ? live : 'unavailable',
    lock_version: num(raw.lock_version, 1),
  };
}

// TRACE: getVendorFleet → maps one raw driver row → typed FleetDriver.
//        Preconditions: raw is an object. Postconditions: numbers are numbers, empty expiry is null.
//        Edge cases: missing live_status → 'unavailable'; unknown status text → 'inactive'.
function toDriver(raw: Record<string, unknown>): FleetDriver {
  const live = str(raw.live_status);
  return {
    id: num(raw.id),
    branch_id: numOrNull(raw.branch_id),
    name: str(raw.name),
    mobile: str(raw.mobile),
    license_number: str(raw.license_number),
    license_expiry: str(raw.license_expiry) === '' ? null : str(raw.license_expiry),
    lock_version: num(raw.lock_version, 1),
    experience_years: num(raw.experience_years),
    service_area_note: str(raw.service_area_note),
    rating: num(raw.rating),
    status: str(raw.status) === 'active' ? 'active' : 'inactive',
    live_status: live === 'available' || live === 'on_trip' ? live : 'unavailable',
    alt_mobile: str(raw.alt_mobile) === '0000-00-00' ? '' : str(raw.alt_mobile),
    date_of_birth: str(raw.date_of_birth) === '0000-00-00' ? '' : str(raw.date_of_birth),
    blood_group: str(raw.blood_group) === '0000-00-00' ? '' : str(raw.blood_group),
    address: str(raw.address) === '0000-00-00' ? '' : str(raw.address),
    city: str(raw.city) === '0000-00-00' ? '' : str(raw.city),
    pincode: str(raw.pincode) === '0000-00-00' ? '' : str(raw.pincode),
    license_class: str(raw.license_class) === '0000-00-00' ? '' : str(raw.license_class),
    badge_number: str(raw.badge_number) === '0000-00-00' ? '' : str(raw.badge_number),
    emergency_contact_name: str(raw.emergency_contact_name) === '0000-00-00' ? '' : str(raw.emergency_contact_name),
    emergency_contact_phone: str(raw.emergency_contact_phone) === '0000-00-00' ? '' : str(raw.emergency_contact_phone),
    emergency_contact_relation: str(raw.emergency_contact_relation) === '0000-00-00' ? '' : str(raw.emergency_contact_relation),
    id_proof_type: str(raw.id_proof_type) === '0000-00-00' ? '' : str(raw.id_proof_type),
    id_proof_number: str(raw.id_proof_number) === '0000-00-00' ? '' : str(raw.id_proof_number),
    police_verification_status: str(raw.police_verification_status) === '0000-00-00' ? '' : str(raw.police_verification_status),
    police_verification_date: str(raw.police_verification_date) === '0000-00-00' ? '' : str(raw.police_verification_date),
    profile_missing: Array.isArray(raw.profile_missing) ? raw.profile_missing.map((x) => str(x)) : [],
    profile_complete: raw.profile_complete === true || raw.profile_complete === 1,
    user_id: raw.user_id ? Number(raw.user_id) : null,
  };
}

// TRACE: getVendorFleet / listBranches → maps one raw branch row → typed VendorBranch.
//        Preconditions: raw is an object. Postconditions: is_primary boolean. Edge cases: missing city name → ''.
function toBranch(raw: Record<string, unknown>): VendorBranch {
  return {
    id: num(raw.id),
    name: str(raw.name),
    address: str(raw.address),
    city_id: num(raw.city_id),
    city_name: str(raw.city_name),
    is_primary: num(raw.is_primary) === 1,
    status: str(raw.status) === 'inactive' ? 'inactive' : 'active',
  };
}

// TRACE: fleet screen load → GET /vendor/fleet → typed overview (vendor type, vehicles, drivers, branches).
//        Preconditions: vendor session. Postconditions: all ids numeric. Edge cases: empty arrays, API error (ApiError).
export async function getVendorFleet(): Promise<FleetOverview> {
  const raw = await apiRequest<{
    vendor_type: string;
    vehicles: Record<string, unknown>[];
    drivers: Record<string, unknown>[];
    branches: Record<string, unknown>[];
  }>('/vendor/fleet');
  return {
    vendor_type: raw.vendor_type === 'fleet' ? 'fleet' : 'individual',
    vehicles: (raw.vehicles ?? []).map(toVehicle),
    drivers: (raw.drivers ?? []).map(toDriver),
    branches: (raw.branches ?? []).map(toBranch),
  };
}

// TRACE: vehicle form submit → POST /vendor/fleet/vehicles → CreateResult. Edge cases: individual vendor, duplicate
//        plate, bad plate (ApiError with server message).
export function createFleetVehicle(input: VehicleInput): Promise<CreateResult> {
  return apiRequest<CreateResult>('/vendor/fleet/vehicles', { method: 'POST', body: input });
}

// TRACE: vehicle form submit (edit) → PUT /vendor/fleet/vehicles/:id (+ optional expectedLockVersion for
//        optimistic locking) → MutationResult (may carry warning). Edge cases: not owner, nothing to
//        update (ApiError); someone else changed this vehicle since the form loaded — thrown as
//        ApiError with status 409 and data.current_lock_version, so the caller can refetch and either
//        show the new values or let the user retry with them.
export function updateFleetVehicle(id: number, input: VehicleInput, expectedLockVersion?: number): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/vendor/fleet/vehicles/${id}`, { method: 'PUT', body: { ...input, expected_lock_version: expectedLockVersion } });
}

// TRACE: confirm delete vehicle → DELETE /vendor/fleet/vehicles/:id → DeleteResult with mode deleted|deactivated.
//        Edge cases: individual vendor refused, not owner (ApiError).
export function deleteFleetVehicle(id: number): Promise<DeleteResult> {
  return apiRequest<DeleteResult>(`/vendor/fleet/vehicles/${id}`, { method: 'DELETE' });
}

// TRACE: driver form submit → POST /vendor/fleet/drivers → CreateResult. Edge cases: individual vendor, bad mobile.
export function createFleetDriver(input: DriverInput): Promise<CreateResult> {
  return apiRequest<CreateResult>('/vendor/fleet/drivers', { method: 'POST', body: input });
}

// TRACE: driver form submit (edit) → PUT /vendor/fleet/drivers/:id (+ optional expectedLockVersion) →
//        MutationResult (may carry warning). Edge cases: someone else changed this driver since the
//        form loaded — ApiError status 409, data.current_lock_version (see updateFleetVehicle above).
export function updateFleetDriver(id: number, input: DriverInput, expectedLockVersion?: number): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/vendor/fleet/drivers/${id}`, { method: 'PUT', body: { ...input, expected_lock_version: expectedLockVersion } });
}

// TRACE: confirm delete driver → DELETE /vendor/fleet/drivers/:id → DeleteResult with mode deleted|deactivated.
export function deleteFleetDriver(id: number): Promise<DeleteResult> {
  return apiRequest<DeleteResult>(`/vendor/fleet/drivers/${id}`, { method: 'DELETE' });
}

// TRACE: availability tab load → GET /vendor/fleet/unavailability (optional from date) → blocks array.
//        Edge cases: none → [].
export async function listUnavailability(from?: string): Promise<UnavailabilityBlock[]> {
  const qs = from ? `?from=${encodeURIComponent(from)}` : '';
  const raw = await apiRequest<{ rows: Record<string, unknown>[] }>(`/vendor/fleet/unavailability${qs}`);
  return (raw.rows ?? []).map((r) => ({
    id: num(r.id),
    entity_type: str(r.entity_type) === 'driver' ? 'driver' : 'vehicle',
    entity_id: num(r.entity_id),
    starts_at: str(r.starts_at),
    ends_at: str(r.ends_at),
    reason: str(r.reason),
  }));
}

// TRACE: add-block form → POST /vendor/fleet/unavailability → result carrying conflicts (booking numbers overlapped).
//        Edge cases: end before start, bad datetime, foreign entity (ApiError); missing conflicts → [].
export async function createUnavailability(input: UnavailabilityInput): Promise<UnavailabilityResult> {
  const res = await apiRequest<UnavailabilityResult>('/vendor/fleet/unavailability', { method: 'POST', body: input });
  return { ...res, conflicts: Array.isArray(res.conflicts) ? res.conflicts : [] };
}

// TRACE: confirm remove block → DELETE /vendor/fleet/unavailability/:id → MutationResult. Edge: not found (ApiError).
export function deleteUnavailability(id: number): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/vendor/fleet/unavailability/${id}`, { method: 'DELETE' });
}

// TRACE: document panel open → GET /vendor/fleet/docs for one entity → docs with validity + allowed doc types.
//        Edge cases: no docs → [].
export async function getFleetDocs(entity: EntityKind, entityId: number): Promise<FleetDocsResponse> {
  const raw = await apiRequest<{ docs: Record<string, unknown>[]; doc_types: string[]; max_upload_mb?: number }>(
    `/vendor/fleet/docs?entity_type=${entity}&entity_id=${entityId}`
  );
  return {
    max_upload_mb: typeof raw.max_upload_mb === 'number' && raw.max_upload_mb > 0 ? raw.max_upload_mb : 5,
    docs: (raw.docs ?? []).map((d) => {
      const v = str(d.validity);
      return {
        id: num(d.id),
        doc_type: str(d.doc_type),
        status: str(d.status),
        expiry_date: str(d.expiry_date) === '' ? null : str(d.expiry_date),
        uploaded_at: str(d.uploaded_at),
        validity: v === 'valid' || v === 'expiring_soon' || v === 'expired' ? v : 'no_expiry',
      };
    }),
    doc_types: raw.doc_types ?? [],
  };
}

// TRACE: document upload form → multipart POST /vendor/docs with vehicle_id or driver_id, doc_type, file and optional
//        expiry_date → {success, doc_id}. api.ts keeps its multipart helper private and its upload helper has no
//        entity scope, so this sends the same request with the same nonce header and error shape.
//        Edge cases: server rejection (ApiError with message), non-JSON response (generic ApiError), network failure (rejects).
export async function uploadFleetDoc(input: {
  entity: EntityKind;
  entityId: number;
  docType: string;
  file: File;
  expiryDate: string;
}): Promise<{ success: boolean; doc_id: number }> {
  const form = new FormData();
  form.set('doc_type', input.docType);
  form.set('file', input.file);
  form.set(input.entity === 'vehicle' ? 'vehicle_id' : 'driver_id', String(input.entityId));
  if (input.expiryDate) form.set('expiry_date', input.expiryDate);
  const res = await fetch(apiUrl('/vendor/docs'), {
    method: 'POST',
    credentials: 'include',
    headers: { 'X-WP-Nonce': getNonce() },
    body: form,
  });
  let payload: unknown = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }
  if (!res.ok) {
    const err = payload as { code?: string; message?: string; data?: { status: number } } | null;
    throw new ApiError({
      code: err?.code ?? 'unknown_error',
      message: err?.message ?? `Upload failed with status ${res.status}`,
      data: err?.data ?? { status: res.status },
    });
  }
  return payload as { success: boolean; doc_id: number };
}

// TRACE: branches tab → POST /vendor/branches → CreateResult. Edge cases: individual vendor, unknown city (ApiError).
export function createBranch(input: BranchInput): Promise<CreateResult> {
  return apiRequest<CreateResult>('/vendor/branches', { method: 'POST', body: input });
}

// TRACE: branches tab edit → PUT /vendor/branches/:id → CreateResult. Edge cases: not owner (ApiError).
export function updateBranch(id: number, input: BranchInput): Promise<CreateResult> {
  return apiRequest<CreateResult>(`/vendor/branches/${id}`, { method: 'PUT', body: input });
}

// TRACE: confirm delete branch → DELETE /vendor/branches/:id → MutationResult (vehicles/drivers detached server-side).
export function deleteBranch(id: number): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/vendor/branches/${id}`, { method: 'DELETE' });
}

// TRACE: "Upgrade to fleet" confirm → POST /vendor/type {type} → MutationResult. Edge cases: impersonation block,
//        already that type (success no-op), fleet→individual refused while >1 active entity (ApiError).
export function setVendorType(type: VendorType): Promise<MutationResult> {
  return apiRequest<MutationResult>('/vendor/type', { method: 'POST', body: { type } });
}

/* ------------------------------------------------------------------ */
/* Leads                                                               */
/* ------------------------------------------------------------------ */

export type InterestStatus = 'pending' | 'viewed' | 'interested' | 'driver_confirmed' | 'declined' | 'expired' | 'not_selected' | 'cancelled';

export interface MarketplaceLead {
  id: number;
  booking_id: number;
  booking_number: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string;
  journey_time: string;
  total_fare: number;
  fee_amount: number;
  lead_fee_formula: string;
  expires_at: string;
  interest_status: InterestStatus;
  lead_mode: 'compare' | 'instant';
  driver_name: string;
  vehicle_registration: string;
}

export interface InterestResult extends MutationResult {
  needs_driver?: boolean;
}

export interface OptionVehicle {
  id: number;
  make_model: string;
  registration_number: string;
  seating_capacity: number;
  preferred: boolean;
  available: boolean;
  reason: string;
  type_mismatch: boolean;
}

export interface OptionDriver {
  id: number;
  name: string;
  mobile: string;
  rating: number;
  preferred: boolean;
  available: boolean;
  reason: string;
}

export interface SelectionOptions {
  vehicles: OptionVehicle[];
  drivers: OptionDriver[];
  window: { date: string; time: string; duration_minutes: number };
}

// TRACE: dashboard load/poll → GET /vendor/leads?status=sent → leads including interest_status, lead_mode, and the
//        confirmed driver/vehicle. Edge cases: none → []; missing interest_status → 'pending'.
export async function getMarketplaceLeads(): Promise<MarketplaceLead[]> {
  const raw = await apiRequest<Record<string, unknown>[]>('/vendor/leads?status=sent');
  return (raw ?? []).map((l) => {
    const st = str(l.interest_status);
    const known: InterestStatus[] = ['viewed', 'interested', 'driver_confirmed', 'declined', 'expired', 'not_selected', 'cancelled'];
    return {
      id: num(l.id),
      booking_id: num(l.booking_id),
      booking_number: str(l.booking_number),
      pickup_city: str(l.pickup_city),
      drop_city: str(l.drop_city),
      journey_date: str(l.journey_date),
      journey_time: str(l.journey_time),
      total_fare: num(l.total_fare),
      fee_amount: num(l.fee_amount),
      lead_fee_formula: str((l.lead_fee as { formula?: unknown } | undefined)?.formula),
      expires_at: str(l.expires_at),
      interest_status: (known as string[]).includes(st) ? (st as InterestStatus) : 'pending',
      lead_mode: str(l.lead_mode) === 'instant' ? 'instant' : 'compare',
      driver_name: str(l.driver_name),
      vehicle_registration: str(l.vehicle_registration),
    };
  });
}

// TRACE: lead card/sheet first opened → POST /vendor/leads/:id/viewed → success. Edge: lead gone (ApiError, ignored by caller).
export function markLeadViewed(id: number): Promise<{ success: boolean }> {
  return apiRequest<{ success: boolean }>(`/vendor/leads/${id}/viewed`, { method: 'POST', body: {} });
}

// TRACE: "I'm interested" → POST /vendor/leads/:id/interest → InterestResult (needs_driver). Edge cases: expired,
//        closed, booking taken, repeated tap (idempotent success).
export function showLeadInterest(id: number): Promise<InterestResult> {
  return apiRequest<InterestResult>(`/vendor/leads/${id}/interest`, { method: 'POST', body: {} });
}

// TRACE: confirm sheet submit → POST /vendor/leads/:id/confirm {driver_id, vehicle_id} → MutationResult.
//        Edge cases: unavailable entity (ApiError with reason), not interested yet, lead closed.
export function confirmLeadDriver(id: number, input: { driver_id: number; vehicle_id: number }): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/vendor/leads/${id}/confirm`, { method: 'POST', body: input });
}

// TRACE: "Decline" → POST /vendor/leads/:id/decline {reason} → MutationResult. Edge: reason optional, lead closed (ApiError).
export function declineLead(id: number, reason: string): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/vendor/leads/${id}/decline`, { method: 'POST', body: { reason } });
}

// TRACE: shared options loader → maps the raw selection payload (vehicles/drivers with availability) → SelectionOptions.
//        Edge cases: missing arrays → []; type_mismatch absent → false.
function toOptions(raw: {
  vehicles?: Record<string, unknown>[];
  drivers?: Record<string, unknown>[];
  window?: Record<string, unknown>;
}): SelectionOptions {
  return {
    vehicles: (raw.vehicles ?? []).map((v) => ({
      id: num(v.id),
      make_model: str(v.make_model),
      registration_number: str(v.registration_number),
      seating_capacity: num(v.seating_capacity),
      preferred: Boolean(v.preferred),
      available: Boolean(v.available),
      reason: str(v.reason),
      type_mismatch: Boolean(v.type_mismatch),
    })),
    drivers: (raw.drivers ?? []).map((d) => ({
      id: num(d.id),
      name: str(d.name),
      mobile: str(d.mobile),
      rating: num(d.rating),
      preferred: Boolean(d.preferred),
      available: Boolean(d.available),
      reason: str(d.reason),
    })),
    window: {
      date: str(raw.window?.date),
      time: str(raw.window?.time),
      duration_minutes: num(raw.window?.duration_minutes),
    },
  };
}

// TRACE: confirm sheet open → GET /vendor/leads/:id/options → SelectionOptions. Edge: lead not the vendor's (ApiError 404).
export async function getLeadOptions(id: number): Promise<SelectionOptions> {
  return toOptions(await apiRequest(`/vendor/leads/${id}/options`));
}

/* ------------------------------------------------------------------ */
/* Bookings                                                            */
/* ------------------------------------------------------------------ */

export interface TimelineStep {
  key: string;
  label: string;
  done: boolean;
  at: string | null;
}

export interface BookingAssignment {
  driver_name: string;
  driver_phone: string;
  vehicle_model: string;
  vehicle_registration: string;
  needs_details: boolean;
}

export interface BookingCustomer {
  name: string;
  phone: string;
  pickup_address: string;
  drop_address: string;
}

export interface VendorCollectionRow {
  id: number;
  amount: number;
  method: string;
  reference: string;
  note: string;
  recorded_by: string;
  created_at: string;
}

export interface VendorBookingDetail extends RideMoney {
  lead_fee?: LeadFeeView;
  id: number;
  booking_number: string;
  status: string;
  status_label: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string;
  journey_time: string;
  trip_type: string;
  passengers: number;
  total_fare: number;
  advance_paid: number;
  balance_due: number;
  special_requests: string;
  passenger_male: number | null;
  passenger_female: number | null;
  passenger_children: number | null;
  passenger_notes: string;
  /** Female-only or includes children — surfaced so the vendor knows before accepting/arranging the ride. */
  is_safety_sensitive: boolean;
  assignment: BookingAssignment | null;
  rating: { client_rated: boolean; vendor_rated: boolean };
  timeline: TimelineStep[];
  customer: BookingCustomer | null;
  /** Admin-editable reminder that the vendor bills the client and issues the ride invoice. */
  vendor_notice: string;
  collection_methods: string[];
  collection_history: VendorCollectionRow[];
}

// TRACE: booking detail load → GET /vendor/bookings/:id → typed detail. Edge cases: not this vendor's booking (ApiError
//        404); customer null before commitment; assignment null; missing timeline → [].
export async function getVendorBookingDetail(id: number): Promise<VendorBookingDetail> {
  const raw = await apiRequest<Record<string, unknown>>(`/vendor/bookings/${id}`);
  const a = raw.assignment as Record<string, unknown> | null;
  const c = raw.customer as Record<string, unknown> | null;
  const r = (raw.rating ?? {}) as Record<string, unknown>;
  return {
    id: num(raw.id),
    booking_number: str(raw.booking_number),
    status: str(raw.status),
    status_label: str(raw.status_label),
    pickup_city: str(raw.pickup_city),
    drop_city: str(raw.drop_city),
    journey_date: str(raw.journey_date),
    journey_time: str(raw.journey_time),
    trip_type: str(raw.trip_type),
    passengers: num(raw.passengers),
    total_fare: num(raw.total_fare),
    advance_paid: num(raw.advance_paid),
    balance_due: num(raw.balance_due),
    platform_model: Boolean(raw.platform_model),
    lead_fee: raw.lead_fee as LeadFeeView | undefined,
    estimated_ride_fare: num(raw.estimated_ride_fare),
    booking_amount: num(raw.booking_amount),
    booking_amount_paid: num(raw.booking_amount_paid),
    booking_amount_pending: num(raw.booking_amount_pending),
    payable_to_vendor: num(raw.payable_to_vendor),
    vendor_collected: num(raw.vendor_collected),
    vendor_outstanding: num(raw.vendor_outstanding),
    collection_status: (str(raw.collection_status) || 'none') as VendorBookingDetail['collection_status'],
    vendor_invoice_number: str(raw.vendor_invoice_number),
    vendor_collected_at: str(raw.vendor_collected_at) || null,
    vendor_notice: str(raw.vendor_notice),
    collection_methods: ((raw.collection_methods as string[] | undefined) ?? []).map((m) => String(m)),
    collection_history: ((raw.collection_history as Record<string, unknown>[] | undefined) ?? []).map((h) => ({
      id: num(h.id),
      amount: num(h.amount),
      method: str(h.method),
      reference: str(h.reference),
      note: str(h.note),
      recorded_by: str(h.recorded_by),
      created_at: str(h.created_at),
    })),
    special_requests: str(raw.special_requests),
    passenger_male: raw.passenger_male == null ? null : num(raw.passenger_male),
    passenger_female: raw.passenger_female == null ? null : num(raw.passenger_female),
    passenger_children: raw.passenger_children == null ? null : num(raw.passenger_children),
    passenger_notes: str(raw.passenger_notes),
    is_safety_sensitive: Boolean(raw.is_safety_sensitive),
    assignment: a
      ? {
          driver_name: str(a.driver_name),
          driver_phone: str(a.driver_phone),
          vehicle_model: str(a.vehicle_model),
          vehicle_registration: str(a.vehicle_registration),
          needs_details: Boolean(a.needs_details),
        }
      : null,
    rating: { client_rated: Boolean(r.client_rated), vendor_rated: Boolean(r.vendor_rated) },
    timeline: ((raw.timeline as Record<string, unknown>[] | undefined) ?? []).map((t) => ({
      key: str(t.key),
      label: str(t.label),
      done: Boolean(t.done),
      at: str(t.at) === '' ? null : str(t.at),
    })),
    customer: c
      ? { name: str(c.name), phone: str(c.phone), pickup_address: str(c.pickup_address), drop_address: str(c.drop_address) }
      : null,
  };
}

// TRACE: change-assignment sheet open → GET /vendor/bookings/:id/options → SelectionOptions (own booking excluded from
//        conflicts). Edge: booking not the vendor's (ApiError 404).
export async function getBookingOptions(id: number): Promise<SelectionOptions> {
  return toOptions(await apiRequest(`/vendor/bookings/${id}/options`));
}

// TRACE: change-assignment submit → POST /vendor/bookings/:id/replace-assignment → MutationResult (+mode filled|replaced).
//        Edge cases: nothing changed, unavailable entity, wrong status (ApiError with reason).
export function replaceAssignment(
  id: number,
  input: { driver_id: number; vehicle_id: number; reason: string }
): Promise<MutationResult & { mode?: 'filled' | 'replaced' }> {
  return apiRequest(`/vendor/bookings/${id}/replace-assignment`, { method: 'POST', body: input });
}

// TRACE: record-collection submit → POST /vendor/bookings/:id/collect {amount, method, reference, note, invoice_number} → MutationResult.
//        Edge cases: over-collection, cancelled booking, zero amount, wrong status, not the vendor's booking (ApiError with reason).
export function recordCollection(
  id: number,
  input: { amount: number; method: string; reference: string; note: string; invoice_number: string }
): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/vendor/bookings/${id}/collect`, { method: 'POST', body: input });
}

// TRACE: rate-customer submit → POST /vendor/bookings/:id/rate-client {scores, review} → MutationResult.
//        Edge cases: not completed, already rated, no valid score (ApiError).
export function rateClient(id: number, scores: Record<string, number>, review: string): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/vendor/bookings/${id}/rate-client`, { method: 'POST', body: { scores, review } });
}

/* ------------------------------------------------------------------ */
/* Settlements                                                         */
/* ------------------------------------------------------------------ */

export interface SettlementSummary {
  commission: number;
  advance_held: number;
  fee_retained: number;
  fee_outstanding: number;
  fee_total: number;
  reversals: number;
  pending_net: number;
  settled_net: number;
}

export interface SettlementRow {
  id: number;
  booking_id: number;
  booking_number: string;
  entry_type: string;
  amount: number;
  direction: 'credit' | 'debit';
  status: string;
  settled_at: string | null;
  created_at: string;
}

export interface SettlementsResponse {
  summary: SettlementSummary;
  rows: SettlementRow[];
  total: number;
  page: number;
  per_page: number;
}

// TRACE: settlements page load/paging → GET /vendor/settlements?page → typed summary + ledger rows. Edge cases: no rows
//        (zero summary, []), missing booking number → ''.
export async function getVendorSettlements(page: number): Promise<SettlementsResponse> {
  const raw = await apiRequest<{
    summary: Record<string, unknown>;
    rows: Record<string, unknown>[];
    total: number;
    page: number;
    per_page: number;
  }>(`/vendor/settlements?page=${page}`);
  const s = raw.summary ?? {};
  return {
    summary: {
      commission: num(s.commission),
      advance_held: num(s.advance_held),
      fee_retained: num(s.fee_retained),
      fee_outstanding: num(s.fee_outstanding),
      fee_total: num(s.fee_total),
      reversals: num(s.reversals),
      pending_net: num(s.pending_net),
      settled_net: num(s.settled_net),
    },
    rows: (raw.rows ?? []).map((r) => ({
      id: num(r.id),
      booking_id: num(r.booking_id),
      booking_number: str(r.booking_number),
      entry_type: str(r.entry_type),
      amount: num(r.amount),
      direction: str(r.direction) === 'credit' ? 'credit' : 'debit',
      status: str(r.status),
      settled_at: str(r.settled_at) === '' ? null : str(r.settled_at),
      created_at: str(r.created_at),
    })),
    total: num(raw.total),
    page: num(raw.page, 1),
    per_page: num(raw.per_page, 30),
  };
}

/* ------------------------------------------------------------------ */
/* Performance                                                         */
/* ------------------------------------------------------------------ */

export interface PerformancePoint {
  period: string;
  bookings_completed: number;
  bookings_cancelled: number;
  response_time_avg_secs: number | null;
  completion_rate: number | null;
  cancellation_rate: number | null;
  avg_rating: number | null;
  on_time_pct: number | null;
  complaint_count: number;
}

export interface CategoryScore {
  category: string;
  avg: number;
  count: number;
}

export interface PerformanceEntity {
  trend: PerformancePoint[];
  categories: CategoryScore[];
}

export interface PerformanceDriver extends PerformanceEntity {
  id: number;
  name: string;
  rating: number;
}

export interface PerformanceVehicle extends PerformanceEntity {
  id: number;
  label: string;
}

export interface VendorPerformance {
  vendor_type: VendorType;
  vendor: PerformanceEntity;
  drivers: PerformanceDriver[];
  vehicles: PerformanceVehicle[];
}

// TRACE: performance loader → maps one raw {trend, categories} block → PerformanceEntity. Preconditions: raw may be
//        undefined. Postconditions: null metrics stay null (never coerced to 0). Edge cases: categories arrives as
//        [] when PHP had no keys (array not object) → no categories; missing trend → [].
function toEntity(raw: { trend?: Record<string, unknown>[]; categories?: unknown } | undefined): PerformanceEntity {
  const cats = raw?.categories && !Array.isArray(raw.categories) ? (raw.categories as Record<string, { avg: number; count: number }>) : {};
  return {
    trend: (raw?.trend ?? []).map((t) => ({
      period: str(t.period),
      bookings_completed: num(t.bookings_completed),
      bookings_cancelled: num(t.bookings_cancelled),
      response_time_avg_secs: numOrNull(t.response_time_avg_secs),
      completion_rate: numOrNull(t.completion_rate),
      cancellation_rate: numOrNull(t.cancellation_rate),
      avg_rating: numOrNull(t.avg_rating),
      on_time_pct: numOrNull(t.on_time_pct),
      complaint_count: num(t.complaint_count),
    })),
    categories: Object.keys(cats).map((k) => ({ category: k, avg: num(cats[k].avg), count: num(cats[k].count) })),
  };
}

// TRACE: performance page load → GET /vendor/performance → typed payload. Edge cases: empty array payload from PHP
//        when vendor missing (treated as no data), no drivers/vehicles → [].
export async function getVendorPerformance(): Promise<VendorPerformance> {
  const raw = await apiRequest<Record<string, unknown>>('/vendor/performance');
  const drivers = (raw.drivers as Record<string, unknown>[] | undefined) ?? [];
  const vehicles = (raw.vehicles as Record<string, unknown>[] | undefined) ?? [];
  return {
    vendor_type: raw.vendor_type === 'fleet' ? 'fleet' : 'individual',
    vendor: toEntity(raw.vendor as { trend?: Record<string, unknown>[]; categories?: unknown } | undefined),
    drivers: drivers.map((d) => ({
      ...toEntity(d as { trend?: Record<string, unknown>[]; categories?: unknown }),
      id: num(d.id),
      name: str(d.name),
      rating: num(d.rating),
    })),
    vehicles: vehicles.map((v) => ({
      ...toEntity(v as { trend?: Record<string, unknown>[]; categories?: unknown }),
      id: num(v.id),
      label: str(v.label),
    })),
  };
}
