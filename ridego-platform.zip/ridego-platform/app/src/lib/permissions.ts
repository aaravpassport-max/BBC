import type { AppUser } from '../types/api';

/**
 * Root-cause fix for the caveat flagged since Waves 17-21: nav links
 * and route guards used to check only the coarse `is_admin` flag
 * (WordPress's manage_options), which is false for the granular
 * ridego_manager/ridego_admin roles even though the server already
 * grants them specific ridego_* capabilities. This checks the real,
 * granular capability the backend reports in `admin_caps` — a full
 * WP administrator holds every one of these directly (see the
 * $super_caps grant in includes/roles.php's ridego_register_roles()),
 * so `is_admin` users still pass every check here without needing a
 * separate bypass.
 */
export function hasAdminCap(user: AppUser | null | undefined, capability: string): boolean {
  if (!user) return false;
  return Boolean(user.admin_caps?.includes(capability));
}

/** True if the user holds at least one RideGo admin capability (i.e. should see the admin nav at all). */
export function isAnyAdmin(user: AppUser | null | undefined): boolean {
  if (!user) return false;
  return user.is_admin || (user.admin_caps?.length ?? 0) > 0;
}
