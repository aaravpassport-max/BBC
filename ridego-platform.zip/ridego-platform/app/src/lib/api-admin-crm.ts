import { apiRequest } from './api';
import { ApiError } from '../types/api';

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

export type ClientType = 'individual' | 'corporate';

export interface ClientSummary {
  id: number;
  name: string;
  phone: string;
  email: string;
  alt_phone: string;
  client_type: ClientType;
  company_name: string;
  status: 'active' | 'blocked' | 'merged';
  merged_into: number | null;
  merged_at: string | null;
}

export interface ClientRow extends ClientSummary {
  city: string;
  source: string;
  tags: string;
  created_at: string;
  bookings: number;
  completed: number;
  cancelled: number;
  billed: number;
  last_trip: string | null;
}

export interface ClientListResponse {
  rows: ClientRow[];
  total: number;
  page: number;
  per_page: number;
}

export interface ClientProfile extends ClientSummary {
  wp_user_id: number;
  city: string;
  address: string;
  gst_number: string;
  notes: string;
  tags: string;
  source: string;
  created_at: string;
  updated_at: string;
}

export interface ClientStats {
  bookings: number;
  completed: number;
  cancelled: number;
  active: number;
  billed: number;
  paid: number;
  outstanding: number;
  last_trip: string | null;
}

export interface ClientBookingRow {
  id: number;
  booking_number: string;
  trip_type: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string;
  journey_time: string;
  status: string;
  payment_status: string;
  total_fare: number | string;
  advance_paid: number | string;
  balance_due: number | string;
  booking_source: string;
  created_at: string;
}

export interface LedgerRow {
  id: number;
  booking_id?: number;
  booking_number?: string;
  entry_type: string;
  amount: number | string;
  method: string;
  reference: string;
  note: string;
  created_at: string;
  recorded_by?: string;
}

export interface Enquiry {
  id: number;
  client_id: number;
  name: string;
  phone: string;
  email: string;
  source: string;
  trip_type: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string | null;
  passengers: number;
  vehicle_type_id: number;
  message: string;
  quoted_amount: number | string | null;
  status: 'new' | 'contacted' | 'quoted' | 'converted' | 'lost';
  follow_up_date: string | null;
  lost_reason: string;
  converted_booking_id: number | null;
  created_at: string;
  overdue?: boolean;
}

export interface ClientDetailResponse {
  client: ClientProfile;
  stats: ClientStats;
  bookings: ClientBookingRow[];
  payments: LedgerRow[];
  enquiries: Enquiry[];
  complaints: { id: number; complaint_id: string; category: string; status: string; priority: string; created_at: string; booking_number: string }[];
}

export interface ClientInput {
  name?: string;
  phone?: string;
  alt_phone?: string;
  email?: string;
  address?: string;
  city?: string;
  company_name?: string;
  gst_number?: string;
  notes?: string;
  tags?: string;
  client_type?: ClientType;
  source?: string;
  allow_email_duplicate?: boolean;
}

export interface EnquiryListResponse {
  rows: Enquiry[];
  total: number;
  page: number;
  per_page: number;
  counts: Record<string, number>;
}

export interface FormOptions {
  vehicle_types: { id: number; name: string; seats: number }[];
  cities: string[];
  trip_types: string[];
  sources: string[];
  payment_methods: string[];
  vendors: { id: number; name: string; phone: string; city: string; vendor_type: string }[];
  advance_hours: number;
}

export interface FareOverrides {
  base_fare?: number | string;
  toll_charges?: number | string;
  parking_charges?: number | string;
  driver_allowance?: number | string;
  extras?: number | string;
  discount_amount?: number | string;
  discount_percent?: number | string;
  gst_mode?: 'auto' | 'none' | 'custom';
  gst_amount?: number | string;
  adjustment?: number | string;
  adjustment_reason?: string;
  /** Override of the booking amount RideGo collects (a reason is required when it differs from the default). */
  booking_amount?: number | string;
  booking_amount_reason?: string;
}

export interface FareBreakdown {
  base_fare: number;
  toll_charges: number;
  parking_charges: number;
  driver_allowance: number;
  extras: number;
  subtotal: number;
  discount_amount: number;
  gst_mode: string;
  gst_percent: number;
  gst_amount: number;
  adjustment: number;
  adjustment_reason: string;
  total_fare: number;
  booking_amount: number;
  booking_amount_default: number;
  booking_amount_reason: string;
  payable_to_vendor: number;
  auto_total: number;
  overridden: boolean;
  distance_km: number;
  duration_minutes: number;
  inclusions: string[];
  exclusions: string[];
}

export interface PassengerInput {
  name: string;
  phone?: string;
  age?: number | null;
}

export interface TripInput {
  trip_type: string;
  pickup_city: string;
  pickup_address?: string;
  drop_city?: string;
  drop_address?: string;
  stops?: string[];
  journey_date: string;
  journey_time: string;
  return_date?: string;
  return_time?: string;
  hours_required?: number;
  vehicle_type_id: number;
  passengers: number;
  luggage_count?: number;
  passenger_details?: PassengerInput[];
  special_requests?: string;
  flight_number?: string;
  allow_past?: boolean;
}

export interface CreateBookingInput extends TripInput {
  client_id?: number;
  new_client?: ClientInput;
  booking_source: string;
  fare?: FareOverrides;
  payment: { mode: 'collect_later' | 'awaiting_payment' | 'received' | 'waived'; amount?: number | string; method?: string; reference?: string; note?: string; reason?: string };
  vendor_id?: number;
  driver_id?: number;
  vehicle_id?: number;
  internal_note?: string;
  client_note?: string;
  enquiry_id?: number;
  confirm_duplicate?: boolean;
  allow_email_duplicate?: boolean;
}

export interface QuoteResponse {
  success: boolean;
  fare: FareBreakdown;
  warnings: string[];
  lead_fee_estimate?: { amount: number; formula: string; source: string; enabled: boolean };
}

export interface CreateBookingResponse {
  success: boolean;
  message: string;
  booking_id: number;
  booking_number: string;
  status: string;
  total_fare: number;
  advance_paid: number;
  balance_due: number;
  booking_amount?: number;
  payable_to_vendor?: number;
  client_id: number;
  client_created: boolean;
  warnings: string[];
}

export interface AssignOptions {
  vendor_type: string;
  drivers: { id: number; name: string; mobile: string; profile_complete: boolean; profile_missing: string[] }[];
  vehicles: { id: number; label: string; registration_number: string; vehicle_type_id: number }[];
}

export interface BookingNote {
  id: number;
  visibility: 'internal' | 'client';
  note: string;
  author: string;
  created_at: string;
  updated_at: string | null;
  edited: boolean;
}

export interface InvoiceData {
  document_type?: 'booking_receipt';
  receipt_number?: string;
  estimate_lines?: { label: string; amount: number }[];
  estimated_ride_fare?: number;
  booking_amount?: number;
  booking_amount_pending?: number;
  ride?: { vendor_name: string; vendor_phone: string; payable_to_vendor: number; vendor_collected: number; vendor_outstanding: number; collection_status: string; vendor_invoice_number: string };
  disclaimer?: string;
  invoice_number: string;
  booking_number: string;
  issued_on: string;
  client_name: string;
  client_phone: string;
  client_email: string;
  client_company: string;
  client_gst: string;
  route: string;
  journey_date: string;
  journey_time: string;
  trip_type: string;
  lines: { label: string; amount: number }[];
  total: number;
  paid: number;
  balance_due: number;
  status: string;
  payment_status: string;
  payments: LedgerRow[];
  company: { name: string; address: string; gstin: string; footer: string; phone: string; email: string };
}

export interface ActionResult {
  success: boolean;
  message: string;
  id?: number;
  rescheduled?: boolean;
  changes?: string[];
}

// ---------------------------------------------------------------------------
// Clients
// ---------------------------------------------------------------------------

// TRACE: clients list screen → GET /admin/clients with the filter/sort/page params that are set → ClientListResponse.
export function listClients(p: { q?: string; type?: string; status?: string; source?: string; sort?: string; order?: string; page?: number }): Promise<ClientListResponse> {
  const qs = new URLSearchParams();
  Object.entries(p).forEach(([k, v]) => {
    if (v !== undefined && v !== '') qs.set(k, String(v));
  });
  return apiRequest<ClientListResponse>(`/admin/clients${qs.toString() ? `?${qs}` : ''}`);
}

// TRACE: booking-desk client picker → GET /admin/clients/lookup?q= → up to 10 rows.
export function lookupClients(q: string): Promise<{ rows: ClientRow[] }> {
  return apiRequest(`/admin/clients/lookup?q=${encodeURIComponent(q)}`);
}

// TRACE: Merge click on a client's own page → POST /admin/clients/:id/merge {into} → the client at :id (the duplicate/junk profile) is retired into `into` (the profile to keep).
export function mergeClient(id: number, into: number): Promise<ActionResult> {
  return apiRequest(`/admin/clients/${id}/merge`, { method: 'POST', body: { into } });
}

// TRACE: client form blur → POST /admin/clients/check-duplicate → matching profiles (warn before saving).
export function checkClientDuplicate(body: { phone?: string; email?: string; exclude_id?: number }): Promise<{ matches: ClientSummary[] }> {
  return apiRequest('/admin/clients/check-duplicate', { method: 'POST', body });
}

// TRACE: New client form → POST /admin/clients → {success,id} or ApiError 409 with data.duplicate.
export function createClient(body: ClientInput): Promise<ActionResult> {
  return apiRequest('/admin/clients', { method: 'POST', body });
}

// TRACE: client profile → GET /admin/clients/:id → profile + stats + history.
export function getClientDetail(id: number): Promise<ClientDetailResponse> {
  return apiRequest(`/admin/clients/${id}`);
}

// TRACE: Edit client → PUT /admin/clients/:id → {success,message}.
export function updateClient(id: number, body: ClientInput): Promise<ActionResult> {
  return apiRequest(`/admin/clients/${id}`, { method: 'PUT', body });
}

// TRACE: Block/Unblock → POST /admin/clients/:id/status {status, reason}.
export function setClientStatus(id: number, status: 'active' | 'blocked', reason: string): Promise<ActionResult> {
  return apiRequest(`/admin/clients/${id}/status`, { method: 'POST', body: { status, reason } });
}

// ---------------------------------------------------------------------------
// Enquiries
// ---------------------------------------------------------------------------

// TRACE: enquiries screen → GET /admin/enquiries with filters → list + per-status counts.
export function listEnquiries(p: { status?: string; q?: string; overdue?: boolean; page?: number }): Promise<EnquiryListResponse> {
  const qs = new URLSearchParams();
  if (p.status) qs.set('status', p.status);
  if (p.q) qs.set('q', p.q);
  if (p.overdue) qs.set('overdue', '1');
  if (p.page) qs.set('page', String(p.page));
  return apiRequest(`/admin/enquiries${qs.toString() ? `?${qs}` : ''}`);
}

// TRACE: New enquiry → POST /admin/enquiries.
export function createEnquiry(body: Record<string, unknown>): Promise<ActionResult> {
  return apiRequest('/admin/enquiries', { method: 'POST', body });
}

// TRACE: Update enquiry (status, quote, follow-up) → PUT /admin/enquiries/:id.
export function updateEnquiry(id: number, body: Record<string, unknown>): Promise<ActionResult> {
  return apiRequest(`/admin/enquiries/${id}`, { method: 'PUT', body });
}

export interface EnquiryPrefill {
  enquiry_id: number;
  client: ClientSummary | null;
  new_client: { name: string; phone: string; email: string };
  trip: { trip_type: string; pickup_city: string; drop_city: string; journey_date: string; passengers: number; vehicle_type_id: number; special_requests: string };
  source: string;
  quoted_amount: number | null;
  status: string;
}

// TRACE: Convert to booking → GET /admin/enquiries/:id/prefill → data used to prefill the booking desk.
export function getEnquiryPrefill(id: number): Promise<EnquiryPrefill> {
  return apiRequest(`/admin/enquiries/${id}/prefill`);
}

// ---------------------------------------------------------------------------
// Booking desk
// ---------------------------------------------------------------------------

// TRACE: booking desk mount → GET /admin/bookings/form-options → select data.
export function getFormOptions(): Promise<FormOptions> {
  return apiRequest('/admin/bookings/form-options');
}

// TRACE: pricing step → POST /admin/bookings/quote → priced preview (never writes).
export function quoteBooking(body: Record<string, unknown>): Promise<QuoteResponse> {
  return apiRequest('/admin/bookings/quote', { method: 'POST', body });
}

// TRACE: Review → Create → POST /admin/bookings/create → booking number and totals.
export function createAdminBooking(body: CreateBookingInput): Promise<CreateBookingResponse> {
  return apiRequest('/admin/bookings/create', { method: 'POST', body });
}

// TRACE: edit/reschedule sheet → POST /admin/bookings/:id/edit with only the changed fields.
export function editAdminBooking(id: number, body: Record<string, unknown>): Promise<ActionResult> {
  return apiRequest(`/admin/bookings/${id}/edit`, { method: 'POST', body });
}

// TRACE: Record payment → POST /admin/bookings/:id/payments.
export function recordBookingPayment(id: number, body: { amount: number; method: string; reference?: string; note?: string }): Promise<ActionResult> {
  return apiRequest(`/admin/bookings/${id}/payments`, { method: 'POST', body });
}

// TRACE: Record vendor collection (admin, on the vendor's behalf) → POST /admin/bookings/:id/vendor-collection. Informational ledger row; never counted as RideGo money.
export function recordVendorCollectionAdmin(id: number, body: { amount: number; method: string; reference?: string; note?: string; vendor_invoice?: string }): Promise<ActionResult> {
  return apiRequest(`/admin/bookings/${id}/vendor-collection`, { method: 'POST', body });
}

// TRACE: Record refund → POST /admin/bookings/:id/refund.
export function recordBookingRefund(id: number, body: { amount: number; method: string; reference?: string; note?: string }): Promise<ActionResult> {
  return apiRequest(`/admin/bookings/${id}/refund`, { method: 'POST', body });
}

// TRACE: booking notes panel → GET /admin/bookings/:id/notes.
export function getBookingNotes(id: number): Promise<{ rows: BookingNote[] }> {
  return apiRequest(`/admin/bookings/${id}/notes`);
}

// TRACE: Add note → POST /admin/bookings/:id/notes {note, visibility}.
export function addBookingNote(id: number, note: string, visibility: 'internal' | 'client'): Promise<ActionResult> {
  return apiRequest(`/admin/bookings/${id}/notes`, { method: 'POST', body: { note, visibility } });
}

// TRACE: Edit note → POST /admin/bookings/:id/notes/:note_id {note}.
export function editBookingNote(id: number, noteId: number, note: string): Promise<ActionResult> {
  return apiRequest(`/admin/bookings/${id}/notes/${noteId}`, { method: 'POST', body: { note } });
}

// TRACE: Delete note (soft delete) → DELETE /admin/bookings/:id/notes/:note_id.
export function deleteBookingNote(id: number, noteId: number): Promise<ActionResult> {
  return apiRequest(`/admin/bookings/${id}/notes/${noteId}`, { method: 'DELETE' });
}

// TRACE: invoice page → GET /admin/bookings/:id/invoice.
export function getAdminInvoice(id: number): Promise<InvoiceData> {
  return apiRequest(`/admin/bookings/${id}/invoice`);
}

// TRACE: vendor selected on the booking desk → GET /admin/vendors/:id/assign-options → drivers and vehicles to pick.
export function getAssignOptions(vendorId: number): Promise<AssignOptions> {
  return apiRequest(`/admin/vendors/${vendorId}/assign-options`);
}

// ---------------------------------------------------------------------------
// Shared display helpers
// ---------------------------------------------------------------------------

export const SOURCE_LABELS: Record<string, string> = {
  online: 'Online',
  admin: 'Admin created',
  phone: 'Phone',
  whatsapp: 'WhatsApp',
  walk_in: 'Walk-in',
  email: 'Email',
  corporate: 'Corporate',
  referral: 'Referral',
  offline: 'Offline',
  manual: 'Manual',
};

export const TRIP_TYPE_LABELS: Record<string, string> = {
  one_way: 'One way',
  round_trip: 'Round trip',
  local: 'Local / hourly',
  airport_pickup: 'Airport pickup',
  airport_drop: 'Airport drop',
  outstation: 'Outstation',
};

export const METHOD_LABELS: Record<string, string> = {
  cash: 'Cash',
  upi: 'UPI',
  bank_transfer: 'Bank transfer',
  card: 'Card',
  cheque: 'Cheque',
  razorpay: 'Razorpay',
  other: 'Other',
};

// TRACE: any money display → formats a number/string as ₹ with Indian grouping and 2 decimals → string. Pure. Non-numeric → ₹0.00.
export function inr(n: number | string | null | undefined): string {
  const v = Number(n ?? 0);
  return `₹${(Number.isFinite(v) ? v : 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

// TRACE: any catch block → readable message from an ApiError (server text verbatim) or the fallback → string. Pure.
export function errMessage(err: unknown, fallback: string): string {
  return err instanceof ApiError && err.message ? err.message : fallback;
}

// TRACE: catch block → the existing profile/booking the server named in a 409, or null → { id, name?, phone?, booking_number? } | null. Pure.
export function duplicateOf(err: unknown): { id: number; name?: string; phone?: string; booking_number?: string } | null {
  if (err instanceof ApiError) {
    const d = (err.data as unknown as { duplicate?: { id: number; name?: string; phone?: string; booking_number?: string } | null } | undefined)?.duplicate;
    return d ?? null;
  }
  return null;
}
