import { apiRequest, apiUrl, getNonce, ApiError } from './api';

/* Typed client for includes/app-admin-lead-fee-api.php (lead-fee configuration, preview, vendor commercial terms)
   and includes/branding.php (Branding & business information). Every function throws ApiError on a non-2xx response. */

export type LeadFeeMethod = 'fixed' | 'percentage' | 'higher_of' | 'percentage_min' | 'percentage_min_max' | 'none';

export interface LeadFeeOptions {
  enabled: boolean;
  offset_advance: boolean;
  cap_at_amount: boolean;
  require_acceptance: boolean;
  customer_advance_enabled: boolean;
}

export interface LeadFeeRule {
  id: number;
  root_id: number;
  version: number;
  scope: 'global' | 'vendor';
  vendor_id: number | null;
  vendor_name: string;
  services: string[];
  method: LeadFeeMethod;
  method_label: string;
  percentage: number;
  fixed_amount: number;
  min_amount: number;
  max_amount: number;
  effective_from: string;
  effective_until: string | null;
  status: 'active' | 'inactive';
  state: 'current' | 'scheduled' | 'expired' | 'inactive';
  notes: string;
  description: string;
  is_latest: boolean;
  created_at: string;
}

export interface LeadFeeVendorRow {
  id: number;
  name: string;
  accepted: boolean;
  accepted_at: string | null;
  terms_version: number | null;
  terms_id: number | null;
}

export interface LeadFeeConfig {
  options: LeadFeeOptions;
  cancel_forfeit_default: 'platform' | 'vendor' | 'admin';
  methods: Record<string, string>;
  services: Record<string, string>;
  rules: LeadFeeRule[];
  vendors: LeadFeeVendorRow[];
}

export interface LeadFeeRuleInput {
  id?: number;
  scope: 'global' | 'vendor';
  vendor_ids?: number[];
  services: string[];
  method: LeadFeeMethod;
  percentage: number | string;
  fixed_amount: number | string;
  min_amount: number | string;
  max_amount: number | string;
  effective_from: string;
  effective_until: string;
  status: 'active' | 'inactive';
  notes: string;
}

export interface LeadFeePreview {
  fee: number;
  amount: number;
  pct_fee?: number;
  min_fee?: number;
  max_fee?: number;
  capped?: boolean;
  formula: string;
  description: string;
}

export interface LeadFeeAction {
  success?: boolean;
  message?: string;
}

export interface PendingForfeitRow {
  booking_id: number;
  client_name: string;
  client_phone: string;
  vendor_id: number;
  vendor_name: string;
  pickup_city: string;
  drop_city: string;
  amount: number;
  created_at: string;
  days_waiting: number;
}

// TRACE: Lead-fee screen mount → GET /app/admin/lead-fee → switches, methods, services, rules and vendors. Throws ApiError.
export function getLeadFeeConfig(): Promise<LeadFeeConfig> {
  return apiRequest<LeadFeeConfig>('/admin/lead-fee');
}

// TRACE: Lead-fee screen mount → GET /app/admin/lead-fee/pending-forfeits → cancelled, vendor-arranged bookings with a forfeited advance still undecided ('admin' default). Throws ApiError.
export function getPendingForfeits(): Promise<{ rows: PendingForfeitRow[]; count: number }> {
  return apiRequest('/admin/lead-fee/pending-forfeits');
}

// TRACE: switch toggled → POST /app/admin/lead-fee/options with only the changed keys → saved options.
export function saveLeadFeeOptions(body: Partial<LeadFeeOptions> & { cancel_forfeit_default?: 'platform' | 'vendor' | 'admin' }): Promise<LeadFeeAction & { options?: LeadFeeOptions }> {
  return apiRequest('/admin/lead-fee/options', { method: 'POST', body });
}

// TRACE: rule form submit → POST /app/admin/lead-fee/terms (id present = new version of that rule) → result message.
export function saveLeadFeeRule(body: LeadFeeRuleInput): Promise<LeadFeeAction> {
  return apiRequest('/admin/lead-fee/terms', { method: 'POST', body });
}

// TRACE: deactivate clicked → POST /app/admin/lead-fee/terms/{id}/deactivate → result message. Server refuses the only global default.
export function deactivateLeadFeeRule(id: number): Promise<LeadFeeAction> {
  return apiRequest(`/admin/lead-fee/terms/${id}/deactivate`, { method: 'POST', body: {} });
}

export interface LeadFeeAcceptance {
  id: number;
  vendor_id: number;
  vendor_name: string;
  terms_id: number;
  terms_version: number;
  source: string;
  accepted_at: string;
}

export interface LeadFeeHistory {
  versions: LeadFeeRule[];
  acceptances: LeadFeeAcceptance[];
}

// TRACE: history opened → GET /app/admin/lead-fee/terms/{id}/history → every version of that rule plus acceptance records.
export function getLeadFeeHistory(id: number): Promise<LeadFeeHistory> {
  return apiRequest(`/admin/lead-fee/terms/${id}/history`);
}

// TRACE: form value or amount changed → POST /app/admin/lead-fee/preview → the server's own calculation (no maths is duplicated in the browser).
export function previewLeadFee(body: {
  amount: number;
  method?: LeadFeeMethod;
  percentage?: number | string;
  fixed_amount?: number | string;
  min_amount?: number | string;
  max_amount?: number | string;
  vendor_id?: number;
  service?: string;
}): Promise<LeadFeePreview> {
  return apiRequest('/admin/lead-fee/preview', { method: 'POST', body });
}

// TRACE: "record acceptance" → POST /app/admin/lead-fee/accept {vendor_id} → result message.
export function adminRecordAcceptance(vendorId: number): Promise<LeadFeeAction> {
  return apiRequest('/admin/lead-fee/accept', { method: 'POST', body: { vendor_id: vendorId } });
}

// TRACE: admin booking Lead fee card → POST /app/admin/bookings/{id}/lead-fee {action, reason} → result message.
export function adjustBookingLeadFee(bookingId: number, action: 'recalculate' | 'waive', reason: string): Promise<LeadFeeAction> {
  return apiRequest(`/admin/bookings/${bookingId}/lead-fee`, { method: 'POST', body: { action, reason } });
}

// TRACE: decision buttons on a cancelled booking → POST /admin/bookings/{id}/forfeit {to, reason} → message; server refuses once compensation is paid.
export function setForfeitDecision(bookingId: number, to: 'platform' | 'vendor', reason: string): Promise<LeadFeeAction> {
  return apiRequest(`/admin/bookings/${bookingId}/forfeit`, { method: 'POST', body: { to, reason } });
}

export interface VendorTermsResponse {
  enabled: boolean;
  require_acceptance: boolean;
  offset_advance: boolean;
  acceptance: { accepted: boolean; accepted_at: string | null; version: number | null; terms_id: number | null };
  terms: LeadFeeRule[];
  history: { terms_id: number; terms_version: number; source: string; accepted_at: string }[];
}

// TRACE: vendor terms page mount → GET /app/vendor/commercial-terms → applicable rules, acceptance state and history.
export function getVendorTerms(): Promise<VendorTermsResponse> {
  return apiRequest('/vendor/commercial-terms');
}

// TRACE: vendor clicks accept → POST /app/vendor/commercial-terms/accept → message; idempotent.
export function acceptVendorTerms(): Promise<LeadFeeAction> {
  return apiRequest('/vendor/commercial-terms/accept', { method: 'POST', body: {} });
}

// ---------------- Branding ----------------

export interface BrandingField {
  key: string;
  kind: 'text' | 'url' | 'phone' | 'email' | 'textarea' | 'select' | 'number';
  group: string;
  label: string;
  help: string;
  value: string;
  effective: string;
  options: Record<string, string> | null;
  min: number | null;
  max: number | null;
}

// TRACE: branding tab mount → GET /app/admin/branding → every field with saved and effective value.
export function getBrandingFields(): Promise<{ fields: BrandingField[] }> {
  return apiRequest('/admin/branding');
}

// TRACE: save clicked → POST /app/admin/branding {values} → all-or-nothing save; 400 carries the offending field.
export function saveBranding(values: Record<string, string>): Promise<LeadFeeAction> {
  return apiRequest('/admin/branding', { method: 'POST', body: { values } });
}

// TRACE: logo/favicon file chosen → multipart POST /app/admin/branding/upload {file, field} → stored URL. Throws ApiError with the server's reason.
export async function uploadBrandingImage(field: 'logo_url' | 'favicon_url' | 'hero_image_url' | 'hero_secondary_image_url', file: File): Promise<{ url: string }> {
  const form = new FormData();
  form.set('field', field);
  form.set('file', file);
  const res = await fetch(apiUrl('/admin/branding/upload'), { method: 'POST', credentials: 'include', headers: { 'X-WP-Nonce': getNonce() }, body: form });
  let payload: unknown = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }
  if (!res.ok) {
    const err = payload as { code?: string; message?: string; data?: { status: number } } | null;
    throw new ApiError({ code: err?.code ?? 'unknown_error', message: err?.message ?? `Upload failed with status ${res.status}`, data: err?.data ?? { status: res.status } });
  }
  return payload as { url: string };
}
