import { getBootstrap } from './bootstrap';
import {
  ApiError,
  type AcceptLeadResponse,
  type AdminActionResponse,
  type AdminBookingCancelResponse,
  type AdminBookingDetail,
  type AdminBookingsResponse,
  type AdminBookingVendorPickerResponse,
  type AdminCitiesResponse,
  type AdminCityCreateResponse,
  type AdminCityInput,
  type AdminCityToggleResponse,
  type AdminCreateResponse,
  type AdminFinancialOverview,
  type AdminWalletLedgerResponse,
  type AdminWalletReconciliationResponse,
  type AdminWalletReconcileResponse,
  type AdminWalletMutationResponse,
  type AdminWalletHistoryResponse,
  type AdminComplaintsResponse,
  type AdminComplaintUpdateResponse,
  type AdminComplaintBulkStatusResponse,
  type AdminSubscriptionPlansResponse,
  type AdminSubscriptionPlanInput,
  type AdminSubscriptionPlanCreateResponse,
  type AdminActionResponse as AdminSubscriptionActionResponse,
  type AdminActiveSubscriptionsResponse,
  type AdminSubscriptionCancelResponse,
  type AdminAuditLogResponse,
  type AdminLeadsResponse,
  type AdminKycRejectRequest,
  type AdminDashboardOverview,
  type AdminSettingsResponse,
  type AdminSettingsSaveRequest,
  type AdminSettingsSaveResponse,
  type AdminToolsResponse,
  type AdminToolActionResponse,
  type AdminNotificationStatsResponse,
  type AdminNotificationQueueResponse,
  type AdminNotificationDeadLetterResponse,
  type AdminNotificationBroadcastResponse,
  type AdminNotificationActionResponse,
  type AdminPricingVehicleInput,
  type AdminPricingVehiclesResponse,
  type AdminPricingVehicleToggleResponse,
  type AdminPromoInput,
  type AdminPromoResponse,
  type AdminPromoToggleResponse,
  type AdminReportsDailyResponse,
  type AdminReportsTopRoutesResponse,
  type AdminReportsTripTypesResponse,
  type AdminReportSummary,
  type AdminRouteInput,
  type AdminRoutesResponse,
  type AdminRouteVehiclePricingInput,
  type AdminSurgeInput,
  type AdminSurgeResponse,
  type AdminVendorCreateRequest,
  type AdminVendorCreateResponse,
  type AdminVendorDetail,
  type AdminVendorPerformanceResponse,
  type AdminVendorsResponse,
  type AdminVendorStatusRequest,
  type AdminZoneInput,
  type AdminZonesResponse,
  type AuthState,
  type Booking,
  type BookingLookupResponse,
  type CancelBookingResponse,
  type ChangePasswordRequest,
  type ChangePasswordResponse,
  type City,
  type MapsConfig,
  type CreateBookingRequest,
  type CreateBookingResponse,
  type FareRequest,
  type FareResponse,
  type HomeResponse,
  type PopularRoute,
  type Partner,
  type LoginRequest,
  type MarkNotificationReadResponse,
  type NotificationsResponse,
  type OtpSendRequest,
  type OtpSendResponse,
  type OtpVerifyRequest,
  type OtpVerifyResponse,
  type PaymentProofRequest,
  type PaymentProofResponse,
  type ProfileResponse,
  type RateBookingResponse,
  type RegisterRequest,
  type ReviewsResponse,
  type RoutePagesResponse,
  type EligibleRoutesResponse,
  type RoutePageGenerateResponse,
  type RoutePageUpdateInput,
  type RoutePageUpdateResponse,
  type RoutePageStatus,
  type RoutePageStatusResponse,
  type RoutePageDeleteResponse,
  type RoutePageContent,
  type RoutePagesIndexResponse,
  type RoutePageHeroFields,
  type TransactionsResponse,
  type UpdateProfileRequest,
  type UpdateProfileResponse,
  type UploadVendorDocResponse,
  type Vehicle,
  type VendorBookingsResponse,
  type VendorDocsResponse,
  type VendorLead,
  type VendorMe,
  type VendorOnboardRequest,
  type VendorOnboardResponse,
  type WpRestError,
} from '../types/api';

let currentNonce: string = getBootstrap().auth.nonce ?? '';

export function setNonce(nonce: string) {
  currentNonce = nonce;
}

export function getNonce() {
  return currentNonce;
}

function apiBase(): string {
  return getBootstrap().apiUrl.replace(/\/$/, '');
}

/**
 * Joins an API base URL with a path/query suffix, correctly whether the
 * base is a plain pretty-permalink REST URL ("https://site/wp-json/ridego/v1/app")
 * or the query-string form ("https://site/?rest_route=/ridego/v1/app") that
 * ridego_app_bootstrap_payload() now always sends (see its own doc comment —
 * the pretty-permalink /wp-json/... form was found, on at least one real
 * deployment, to be intercepted by a hosting/proxy layer in front of
 * WordPress before it ever reached PHP, while the query-string form always
 * reaches WordPress's own front controller directly). Every call site in
 * this file builds its own "?param=value" suffix assuming it's the FIRST
 * query string on the URL; when the base already has "?rest_route=..." in
 * it, that suffix must be joined with "&" instead of starting a second "?",
 * or the URL is malformed and the second query string is silently dropped
 * by the browser. This is the one place that distinction is handled, so
 * none of the ~20 call sites elsewhere in this file need to know or care
 * which form the base is in.
 */
function joinApiUrl(base: string, suffix: string): string {
  if (!suffix) { return base; }
  // NOTE: an earlier version of this only checked suffix.startsWith('?'),
  // which matches a suffix that IS a bare query string but silently
  // misses the far more common real shape, "/path?query" (the "?" partway
  // through, not at the start) -- almost every real call site in this
  // file builds a path exactly that way, e.g.
  // `/notifications${qs.toString() ? '?' + qs : ''}`. That gap let a
  // second "?" reach the URL untouched whenever base already had its own
  // "?rest_route=..." query string, and a browser silently drops
  // everything from a URL's second "?" onward -- caught for real when
  // /notifications?page=1 came back 404 during testing against a live
  // WordPress instance, because the "?page=1" was lost entirely rather
  // than becoming "&page=1". This version finds the "?" wherever it
  // falls in suffix, not just at position 0.
  if (base.includes('?')) {
    const qIndex = suffix.indexOf('?');
    if (qIndex !== -1) {
      const pathPart = suffix.slice(0, qIndex);
      const queryPart = suffix.slice(qIndex + 1);
      return queryPart ? `${base}${pathPart}&${queryPart}` : `${base}${pathPart}`;
    }
  }
  return `${base}${suffix}`;
}

/** Public helper for building URLs to non-JSON (streamed) REST endpoints. */
export function apiUrl(path: string): string {
  return joinApiUrl(apiBase(), path);
}

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  body?: unknown;
  /** Set true to retry once after refreshing the nonce on a 401/403. */
  _retried?: boolean;
  /**
   * Override the base URL. Defaults to apiBase() (".../ridego/v1/app").
   * A few endpoints — the pre-existing partner-facing reports routes in
   * includes/rest-api.php — are registered at the namespace root
   * (".../ridego/v1/reports/...", no "/") rather than under "/",
   * so admin-reports calls that reuse those existing routes pass
   * rootApiBase() here instead of duplicating them under "/".
   */
  _base?: string;
}

/** Root of the 'ridego/v1' REST namespace, one level up from apiBase()'s '/'. */
function rootApiBase(): string {
  return apiBase().replace(/\/app$/, '');
}

// TRACE: any marketplace api module → generic JSON request against the '/ridego/v1/app' base with cookie auth,
//        X-WP-Nonce, JSON body for POST/PUT/PATCH, stale-nonce retry once on 401/403 for non-GET → resolves the
//        parsed body or throws ApiError. Edge cases: non-JSON body (null payload), network failure (rejects).
export async function apiRequest<T>(path: string, opts: Omit<RequestOptions, '_retried' | '_base'> = {}): Promise<T> {
  return request<T>(path, opts);
}

async function request<T>(path: string, opts: RequestOptions = {}): Promise<T> {
  const method = opts.method ?? 'GET';
  const headers: Record<string, string> = {};
  // ROOT-CAUSE FIX: WordPress's cookie-based REST authentication (see
  // core's rest_cookie_check_errors()) requires the X-WP-Nonce header on
  // EVERY request method when a login cookie is present, not just
  // state-changing ones — this was found by testing against a real local
  // WordPress instance: without this header, WordPress silently treats a
  // fully logged-in visitor as anonymous for that one request, no error
  // is thrown, current_user_can()/is_user_logged_in() inside the REST
  // callback just come back false as if the visitor were a guest. Only
  // sending it for POST (the previous code) meant every GET request —
  // every admin dashboard listing, and the /auth/me self-heal check
  // added alongside this fix — silently never authenticated at all,
  // which is what was actually causing a genuinely logged-in admin to
  // keep seeing a logged-out/"not authorized" app. currentNonce always
  // holds a valid nonce (a real wp_create_nonce('wp_rest') value even
  // for a logged-out visitor, from ridego_app_api_current_user_payload()
  // — see includes/app-api.php), so sending it is always safe and never
  // itself grants any access a request wouldn't otherwise have.
  headers['X-WP-Nonce'] = currentNonce;
  if (method !== 'GET' && method !== 'DELETE') {
    headers['Content-Type'] = 'application/json';
  }

  const base = opts._base ?? apiBase();
  const res = await fetch(joinApiUrl(base, path), {
    method,
    credentials: 'include',
    headers,
    body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
  });

  let payload: unknown = null;
  try {
    payload = await res.json();
  } catch {
    // no JSON body
  }

  if (!res.ok) {
    const err = (payload as WpRestError) ?? {
      code: 'unknown_error',
      message: `Request failed with status ${res.status}`,
      data: { status: res.status },
    };

    // Stale-nonce recovery: refresh /auth/me once and retry the original call.
    const looksLikeStaleNonce =
      (res.status === 401 || res.status === 403) &&
      !opts._retried &&
      method !== 'GET';
    if (looksLikeStaleNonce) {
      try {
        const me = await authMe();
        setNonce(me.nonce);
        return request<T>(path, { ...opts, _retried: true });
      } catch {
        // fall through to throwing the original error
      }
    }

    throw new ApiError(err);
  }

  return payload as T;
}

interface FormRequestOptions {
  body: FormData;
  _retried?: boolean;
}

/**
 * Same stale-nonce-retry / error-shape behavior as request(), but for a
 * multipart/form-data POST — the browser must set its own Content-Type
 * (with the multipart boundary), so we deliberately don't set one here.
 */
async function requestForm<T>(path: string, opts: FormRequestOptions): Promise<T> {
  const headers: Record<string, string> = { 'X-WP-Nonce': currentNonce };

  const res = await fetch(joinApiUrl(apiBase(), path), {
    method: 'POST',
    credentials: 'include',
    headers,
    body: opts.body,
  });

  let payload: unknown = null;
  try {
    payload = await res.json();
  } catch {
    // no JSON body
  }

  if (!res.ok) {
    const err = (payload as WpRestError) ?? {
      code: 'unknown_error',
      message: `Request failed with status ${res.status}`,
      data: { status: res.status },
    };

    const looksLikeStaleNonce = (res.status === 401 || res.status === 403) && !opts._retried;
    if (looksLikeStaleNonce) {
      try {
        const me = await authMe();
        setNonce(me.nonce);
        return requestForm<T>(path, { ...opts, _retried: true });
      } catch {
        // fall through to throwing the original error
      }
    }

    throw new ApiError(err);
  }

  return payload as T;
}

// ---------------------------------------------------------------------------
// Auth
// ---------------------------------------------------------------------------

export function authMe(): Promise<AuthState> {
  return request<AuthState>('/auth/me');
}

export function authLogin(body: LoginRequest): Promise<AuthState> {
  return request<AuthState>('/auth/login', { method: 'POST', body });
}

export function authRegister(body: RegisterRequest): Promise<AuthState> {
  return request<AuthState>('/auth/register', { method: 'POST', body });
}

export function authLogout(): Promise<AuthState> {
  return request<AuthState>('/auth/logout', { method: 'POST', body: {} });
}

// ---------------------------------------------------------------------------
// Public content
// ---------------------------------------------------------------------------

// The Footer renders on every route (support phone/WhatsApp) and several
// pages (Home, About, Help) independently fetch the same /home payload for
// their own content, so a naive implementation fires two identical GET
// /home requests on first paint of those pages. Cache + de-dupe the
// in-flight promise so concurrent callers share one network request.
let homeRequest: Promise<HomeResponse> | null = null;

export function getHome(): Promise<HomeResponse> {
  if (!homeRequest) {
    homeRequest = request<HomeResponse>('/home').catch((err) => {
      homeRequest = null;
      throw err;
    });
  }
  return homeRequest;
}

export function getCities(role?: 'origin' | 'destination'): Promise<City[]> {
  return request<City[]>(role ? `/cities?role=${role}` : '/cities');
}

export function getPopularRoutes(): Promise<PopularRoute[]> {
  return request<PopularRoute[]>('/popular-routes');
}

export function getPartners(): Promise<Partner[]> {
  return request<Partner[]>('/partners');
}

export function getMapsConfig(): Promise<MapsConfig> {
  return request<MapsConfig>('/maps-config');
}

export function getVehicles(): Promise<Vehicle[]> {
  return request<Vehicle[]>('/vehicles');
}

export function getFare(body: FareRequest): Promise<FareResponse> {
  return request<FareResponse>('/fare', { method: 'POST', body });
}

// ---------------------------------------------------------------------------
// Bookings (customer)
// ---------------------------------------------------------------------------

export function getMyBookings(params: { status?: string; page?: number } = {}): Promise<Booking[]> {
  const qs = new URLSearchParams();
  if (params.status) qs.set('status', params.status);
  if (params.page) qs.set('page', String(params.page));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<Booking[]>(`/bookings${suffix}`);
}

export function cancelBooking(id: number, reason: string): Promise<CancelBookingResponse> {
  return request<CancelBookingResponse>(`/bookings/${id}/cancel`, {
    method: 'POST',
    body: { reason },
  });
}

export function rateBooking(id: number, score: number, review: string, scores?: Record<string, number>): Promise<RateBookingResponse> {
  return request<RateBookingResponse>(`/bookings/${id}/rate`, {
    method: 'POST',
    body: scores && Object.keys(scores).length > 0 ? { score, review, scores } : { score, review },
  });
}

export function createBooking(body: CreateBookingRequest): Promise<CreateBookingResponse> {
  return request<CreateBookingResponse>('/bookings', { method: 'POST', body });
}

export function lookupBooking(params: { booking: string; phone?: string }): Promise<BookingLookupResponse> {
  const qs = new URLSearchParams();
  qs.set('booking', params.booking);
  if (params.phone) qs.set('phone', params.phone);
  return request<BookingLookupResponse>(`/bookings/lookup?${qs.toString()}`);
}

export function submitPaymentProof(id: number, body: PaymentProofRequest): Promise<PaymentProofResponse> {
  const form = new FormData();
  form.set('proof_file', body.proof_file);
  form.set('utr', body.utr);
  form.set('payment_app', body.payment_app);
  form.set('amount', body.amount);
  form.set('payment_time', body.payment_time);
  form.set('client_phone', body.client_phone);
  return requestForm<PaymentProofResponse>(`/bookings/${id}/payment-proof`, { body: form });
}

// ---------------------------------------------------------------------------
// OTP
// ---------------------------------------------------------------------------

export function sendOtp(body: OtpSendRequest): Promise<OtpSendResponse> {
  return request<OtpSendResponse>('/otp/send', { method: 'POST', body });
}

export function verifyOtp(body: OtpVerifyRequest): Promise<OtpVerifyResponse> {
  return request<OtpVerifyResponse>('/otp/verify', { method: 'POST', body });
}

// ---------------------------------------------------------------------------
// Vendor
// ---------------------------------------------------------------------------

export function getVendorMe(): Promise<VendorMe> {
  return request<VendorMe>('/vendor/me');
}

export function getVendorLeads(status = 'sent'): Promise<VendorLead[]> {
  return request<VendorLead[]>(`/vendor/leads?status=${encodeURIComponent(status)}`);
}

export function acceptLead(id: number): Promise<AcceptLeadResponse> {
  return request<AcceptLeadResponse>(`/vendor/leads/${id}/accept`, {
    method: 'POST',
    body: {},
  });
}

// ROOT-CAUSE FIX (vendor-app audit): ridego_reject_lead() has always
// existed server-side (with cascade-to-next-vendor) but had no client
// call — the dashboard only offered Accept.
export function rejectLead(id: number, reason = ''): Promise<{ success: boolean; message: string }> {
  return request<{ success: boolean; message: string }>(`/vendor/leads/${id}/reject`, {
    method: 'POST',
    body: { reason },
  });
}

export function getVendorBookings(params: { status?: string; page?: number } = {}): Promise<VendorBookingsResponse> {
  const qs = new URLSearchParams();
  if (params.status) qs.set('status', params.status);
  if (params.page) qs.set('page', String(params.page));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<VendorBookingsResponse>(`/vendor/bookings${suffix}`);
}

// ROOT-CAUSE FIX (vendor-app audit): lets a vendor advance their own
// assigned trip (driver_en_route → trip_started with pickup OTP →
// completed) — the app was previously read-only after assignment.
export function advanceVendorTrip(
  bookingId: number,
  status: 'driver_en_route' | 'trip_started' | 'completed',
  otp = ''
): Promise<{ success: boolean; message: string; status: string }> {
  return request<{ success: boolean; message: string; status: string }>(`/vendor/bookings/${bookingId}/advance`, {
    method: 'POST',
    body: { status, otp },
  });
}

// ---------------------------------------------------------------------------
// Vendor KYC docs
// ---------------------------------------------------------------------------

export function getVendorDocs(): Promise<VendorDocsResponse> {
  return request<VendorDocsResponse>('/vendor/docs');
}

export function uploadVendorDoc(body: {
  doc_type: string;
  file: File;
  expiry_date?: string;
}): Promise<UploadVendorDocResponse> {
  const form = new FormData();
  form.set('doc_type', body.doc_type);
  form.set('file', body.file);
  if (body.expiry_date) form.set('expiry_date', body.expiry_date);
  return requestForm<UploadVendorDocResponse>('/vendor/docs', { body: form });
}

export function vendorDocFileUrl(id: number): string {
  return apiUrl(`/vendor/docs/${id}/file`);
}

/**
 * Fetches an uploaded KYC document as a blob and hands back a local
 * object URL, instead of a plain URL a viewer could navigate to directly.
 *
 * Plain navigation (a bare `<a href>`) can't attach the X-WP-Nonce header,
 * and WordPress's cookie-based REST auth (see the note on request() above)
 * treats a nonce-less request as anonymous even for a logged-in vendor, so
 * a real browser navigation to vendorDocFileUrl() 401s every time despite
 * the visitor being signed in. Fetching it with credentials + the nonce
 * header (like every other authenticated call in this file) and opening
 * the resulting blob URL actually works.
 */
export async function fetchVendorDocFileUrl(id: number): Promise<string> {
  const res = await fetch(apiUrl(`/vendor/docs/${id}/file`), {
    method: 'GET',
    credentials: 'include',
    headers: { 'X-WP-Nonce': currentNonce },
  });
  if (!res.ok) {
    let err: WpRestError | null = null;
    try {
      err = (await res.json()) as WpRestError;
    } catch {
      // no JSON body
    }
    throw new ApiError(
      err ?? { code: 'unknown_error', message: `Request failed with status ${res.status}`, data: { status: res.status } }
    );
  }
  const blob = await res.blob();
  return URL.createObjectURL(blob);
}

// ---------------------------------------------------------------------------
// Profile / account settings
// ---------------------------------------------------------------------------

export function getProfile(): Promise<ProfileResponse> {
  return request<ProfileResponse>('/profile');
}

export function updateProfile(body: UpdateProfileRequest): Promise<UpdateProfileResponse> {
  return request<UpdateProfileResponse>('/profile', { method: 'POST', body });
}

export function changePassword(body: ChangePasswordRequest): Promise<ChangePasswordResponse> {
  return request<ChangePasswordResponse>('/profile/password', { method: 'POST', body });
}

// ---------------------------------------------------------------------------
// Notifications
// ---------------------------------------------------------------------------

export function getNotifications(params: { page?: number; unreadOnly?: boolean } = {}): Promise<NotificationsResponse> {
  const qs = new URLSearchParams();
  if (params.page) qs.set('page', String(params.page));
  if (params.unreadOnly) qs.set('unread_only', '1');
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<NotificationsResponse>(`/notifications${suffix}`);
}

export function markNotificationRead(id: number): Promise<MarkNotificationReadResponse> {
  return request<MarkNotificationReadResponse>(`/notifications/${id}/read`, { method: 'POST', body: {} });
}

export function markAllNotificationsRead(): Promise<MarkNotificationReadResponse> {
  return request<MarkNotificationReadResponse>('/notifications/read-all', { method: 'POST', body: {} });
}

// ---------------------------------------------------------------------------
// Transactions
// ---------------------------------------------------------------------------

export function getTransactions(params: { page?: number } = {}): Promise<TransactionsResponse> {
  const qs = new URLSearchParams();
  if (params.page) qs.set('page', String(params.page));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<TransactionsResponse>(`/transactions${suffix}`);
}

// ---------------------------------------------------------------------------
// Reviews (public)
// ---------------------------------------------------------------------------

export function getReviews(params: { page?: number; vehicle_type_id?: number } = {}): Promise<ReviewsResponse> {
  const qs = new URLSearchParams();
  if (params.page) qs.set('page', String(params.page));
  if (params.vehicle_type_id) qs.set('vehicle_type_id', String(params.vehicle_type_id));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<ReviewsResponse>(`/reviews${suffix}`);
}

// ---------------------------------------------------------------------------
// Vendor onboarding (existing customer becoming a vendor)
// ---------------------------------------------------------------------------

export function vendorOnboard(body: VendorOnboardRequest): Promise<VendorOnboardResponse> {
  return request<VendorOnboardResponse>('/vendor/onboard', { method: 'POST', body });
}

// ---------------------------------------------------------------------------
// Admin: vendor management + KYC
// ---------------------------------------------------------------------------

export function getAdminVendors(
  params: { status?: string; kyc?: string; city?: string; vendor_type?: string; expiring?: number; search?: string; page?: number } = {}
): Promise<AdminVendorsResponse> {
  const qs = new URLSearchParams();
  if (params.status) qs.set('status', params.status);
  if (params.kyc) qs.set('kyc', params.kyc);
  if (params.city) qs.set('city', params.city);
  if (params.vendor_type) qs.set('vendor_type', params.vendor_type);
  if (params.expiring) qs.set('expiring', String(params.expiring));
  if (params.search) qs.set('search', params.search);
  if (params.page) qs.set('page', String(params.page));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<AdminVendorsResponse>(`/admin/vendors${suffix}`);
}

export function createAdminVendor(body: AdminVendorCreateRequest): Promise<AdminVendorCreateResponse> {
  return request<AdminVendorCreateResponse>('/admin/vendors', { method: 'POST', body });
}

export function getAdminVendorDetail(id: number): Promise<AdminVendorDetail> {
  return request<AdminVendorDetail>(`/admin/vendors/${id}`);
}

// force=true re-submits after the caller has shown the missing_docs list from a 409 and the admin
// chose to approve anyway (see ridego_approve_kyc()'s doc comment in includes/vendor.php for why this
// override exists rather than an absolute block).
export function approveVendorKyc(id: number, force = false): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/vendors/${id}/kyc/approve`, { method: 'POST', body: { force } });
}

export function rejectVendorKyc(id: number, body: AdminKycRejectRequest): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/vendors/${id}/kyc/reject`, { method: 'POST', body });
}

export interface AdminVendorsBulkResponse {
  success: boolean;
  message: string;
  succeeded: number;
  skipped: string[];
}

export function bulkVendorAction(action: 'approve_kyc' | 'suspend', ids: number[]): Promise<AdminVendorsBulkResponse> {
  return request<AdminVendorsBulkResponse>('/admin/vendors/bulk', { method: 'POST', body: { action, ids } });
}

export function setVendorStatus(id: number, body: AdminVendorStatusRequest): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/vendors/${id}/status`, { method: 'POST', body });
}

export function saveVendorNotes(id: number, notesAdmin: string): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/vendors/${id}/notes`, { method: 'POST', body: { notes_admin: notesAdmin } });
}

/**
 * Builds the admin-ajax.php "view document" URL for a vendor's KYC
 * upload — same round-trip pattern as getBookingProofFileUrl (see
 * that function's comment for why this goes through admin-ajax.php
 * instead of a REST route).
 */
export async function getVendorDocumentUrl(path: string): Promise<string> {
  const { nonce } = await getAdminReportsExportNonce();
  return `${window.location.origin}/wp-admin/admin-ajax.php?action=ridego_serve_file&path=${encodeURIComponent(
    path
  )}&nonce=${encodeURIComponent(nonce)}`;
}

// ---------------------------------------------------------------------------
// Admin: booking management
// ---------------------------------------------------------------------------

export function getAdminBookings(
  params: {
    status?: string;
    trip_type?: string;
    vendor_id?: number;
    date_from?: string;
    date_to?: string;
    search?: string;
    source?: string;
    payment_status?: string;
    client_id?: number;
    page?: number;
  } = {}
): Promise<AdminBookingsResponse> {
  const qs = new URLSearchParams();
  if (params.status) qs.set('status', params.status);
  if (params.trip_type) qs.set('trip_type', params.trip_type);
  if (params.vendor_id) qs.set('vendor_id', String(params.vendor_id));
  if (params.date_from) qs.set('date_from', params.date_from);
  if (params.date_to) qs.set('date_to', params.date_to);
  if (params.search) qs.set('search', params.search);
  if (params.source) qs.set('source', params.source);
  if (params.payment_status) qs.set('payment_status', params.payment_status);
  if (params.client_id) qs.set('client_id', String(params.client_id));
  if (params.page) qs.set('page', String(params.page));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<AdminBookingsResponse>(`/admin/bookings${suffix}`);
}

export function getAdminBookingDetail(id: number): Promise<AdminBookingDetail> {
  return request<AdminBookingDetail>(`/admin/bookings/${id}`);
}

export function verifyBookingPayment(id: number): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/bookings/${id}/verify-payment`, { method: 'POST', body: {} });
}

export function rejectBookingPayment(id: number, reason: string): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/bookings/${id}/reject-payment`, { method: 'POST', body: { reason } });
}

export function cancelBookingAsAdmin(id: number, reason: string): Promise<AdminBookingCancelResponse> {
  return request<AdminBookingCancelResponse>(`/admin/bookings/${id}/cancel`, { method: 'POST', body: { reason } });
}

export function completeBookingAsAdmin(id: number): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/bookings/${id}/complete`, { method: 'POST', body: {} });
}

/** Token Amount / Advance Payment, spec item 3: RideGo could not arrange the
 *  requested vehicle/booking — marks the booking "Booking Not Arranged ->
 *  Token Refund Due" and triggers the client's token refund. Only valid
 *  before a vendor has been assigned. */
export function markBookingNotArranged(id: number, reason: string): Promise<AdminActionResponse & { refund_amount: number }> {
  return request<AdminActionResponse & { refund_amount: number }>(`/admin/bookings/${id}/mark-not-arranged`, {
    method: 'POST',
    body: { reason },
  });
}

export function assignBookingVendor(id: number, vendorId: number): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/bookings/${id}/assign-vendor`, {
    method: 'POST',
    body: { vendor_id: vendorId },
  });
}

// TRACE: booking detail status dropdown → POST /admin/bookings/:id/status (+ optional expectedLockVersion
//        for optimistic locking) → AdminActionResponse. Edge cases: someone else changed this booking
//        since the page loaded — thrown as an ApiError with status 409 and data.current_lock_version, so
//        the caller can prompt a refresh instead of silently overwriting the other change.
export function setBookingStatus(id: number, status: string, expectedLockVersion?: number): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/bookings/${id}/status`, { method: 'POST', body: { status, expected_lock_version: expectedLockVersion } });
}

export function saveBookingNote(id: number, note: string): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/bookings/${id}/note`, { method: 'POST', body: { note } });
}

export function resendBookingConfirmation(id: number): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/bookings/${id}/resend-confirmation`, { method: 'POST', body: {} });
}

export interface AdminBookingTimelineEntry {
  source: 'audit' | 'note' | 'payment';
  at: string;
  label: string;
  detail: string;
  by: string;
  severity: string;
}

export interface AdminBookingTimelineResponse {
  booking_id: number;
  booking_number: string;
  entries: AdminBookingTimelineEntry[];
  count: number;
}

export function getBookingTimeline(id: number): Promise<AdminBookingTimelineResponse> {
  return request<AdminBookingTimelineResponse>(`/admin/bookings/${id}/timeline`);
}

/* RG-006: client-facing privacy self-service (data export + delete request). */
export interface PrivacyExportResponse {
  generated_at: string;
  account: { user_id: number; username: string; display_name: string; email: string; registered: string; roles: string[] };
  bookings: Record<string, unknown>[];
  booking_notes: Record<string, unknown>[];
  booking_payments: Record<string, unknown>[];
  saved_addresses: Record<string, unknown>[];
  support_tickets: Record<string, unknown>[];
  vendor_profile: Record<string, unknown> | null;
  driver_profile: Record<string, unknown> | null;
}

export function getPrivacyExport(): Promise<PrivacyExportResponse> {
  return request<PrivacyExportResponse>('/client/privacy/export');
}

export function submitPrivacyDeleteRequest(reason: string): Promise<AdminActionResponse & { id: number }> {
  return request<AdminActionResponse & { id: number }>('/client/privacy/delete-request', { method: 'POST', body: { reason } });
}

export interface AdminPrivacyRequestRow {
  id: number;
  user_id: number;
  user_login: string;
  user_email: string;
  request_type: string;
  status: string;
  reason: string;
  admin_note: string;
  reviewed_by: number | null;
  reviewed_at: string | null;
  created_at: string;
}

export function getAdminPrivacyRequests(status?: string): Promise<{ rows: AdminPrivacyRequestRow[] }> {
  return request<{ rows: AdminPrivacyRequestRow[] }>(`/admin/privacy/requests${status ? `?status=${encodeURIComponent(status)}` : ''}`);
}

export function fulfillPrivacyRequest(id: number, note: string): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/privacy/requests/${id}/fulfill`, { method: 'POST', body: { note } });
}

export function rejectPrivacyRequest(id: number, reason: string): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/privacy/requests/${id}/reject`, { method: 'POST', body: { reason } });
}

export function getAdminBookingVendorPicker(): Promise<AdminBookingVendorPickerResponse> {
  return request<AdminBookingVendorPickerResponse>('/admin/bookings/vendor-picker');
}

export interface AdminBookingsBulkResponse {
  success: boolean;
  message: string;
  succeeded: number;
  skipped: string[];
}

export function bulkBookingAction(action: 'verify_payment' | 'cancel', ids: number[]): Promise<AdminBookingsBulkResponse> {
  return request<AdminBookingsBulkResponse>('/admin/bookings/bulk', { method: 'POST', body: { action, ids } });
}

/**
 * Builds the admin-ajax.php "view proof" URL using a freshly minted
 * ridego_admin_nonce (same round-trip pattern as the Reports CSV
 * export nonce) — this is the same underlying admin-ajax action
 * (ridego_serve_file) that admin/pages/bookings.php's "View Proof"
 * link uses, so file access rules never drift between the two admins.
 */
export async function getBookingProofFileUrl(path: string): Promise<string> {
  const { nonce } = await getAdminReportsExportNonce();
  return `${window.location.origin}/wp-admin/admin-ajax.php?action=ridego_serve_file&path=${encodeURIComponent(
    path
  )}&nonce=${encodeURIComponent(nonce)}`;
}

// ---------------------------------------------------------------------------
// Admin: cities management
// ---------------------------------------------------------------------------

export function getAdminCities(): Promise<AdminCitiesResponse> {
  return request<AdminCitiesResponse>('/admin/cities');
}

export function createAdminCity(body: AdminCityInput): Promise<AdminCityCreateResponse> {
  return request<AdminCityCreateResponse>('/admin/cities', { method: 'POST', body });
}

export function updateAdminCity(id: number, body: AdminCityInput): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/cities/${id}`, { method: 'POST', body });
}

export function toggleAdminCity(id: number): Promise<AdminCityToggleResponse> {
  return request<AdminCityToggleResponse>(`/admin/cities/${id}/toggle`, { method: 'POST', body: {} });
}

// TRACE: a chosen photo file → uploaded via WordPress's own upload handler (real
//        file-type check, size cap) → { url } pointing at the saved file, same
//        pattern as uploadBrandingImage(). The caller then sends that url back as
//        image_url on createAdminCity()/updateAdminCity() — this call alone never
//        changes any city row.
export async function uploadCityImage(file: File): Promise<{ url: string }> {
  const form = new FormData();
  form.set('file', file);
  const res = await fetch(apiUrl('/admin/cities/upload-image'), { method: 'POST', credentials: 'include', headers: { 'X-WP-Nonce': getNonce() }, body: form });
  let payload: unknown = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }
  if (!res.ok) {
    const err = payload as { code?: string; message?: string; data?: { status: number } } | null;
    throw new ApiError({ code: err?.code ?? 'unknown_error', message: err?.message ?? `Upload failed with status ${res.status}`, data: err?.data ?? { status: res.status } });
  }
  return payload as { url: string };
}

// Same discipline as uploadCityImage() — real file-type check, WordPress's
// own upload handler. The caller sends the returned url back as
// upi_qr_url on the normal settings save call.
export async function uploadQrImage(file: File): Promise<{ url: string }> {
  const form = new FormData();
  form.set('file', file);
  const res = await fetch(apiUrl('/admin/settings/upload-qr'), { method: 'POST', credentials: 'include', headers: { 'X-WP-Nonce': getNonce() }, body: form });
  let payload: unknown = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }
  if (!res.ok) {
    const err = payload as { code?: string; message?: string; data?: { status: number } } | null;
    throw new ApiError({ code: err?.code ?? 'unknown_error', message: err?.message ?? `Upload failed with status ${res.status}`, data: err?.data ?? { status: res.status } });
  }
  return payload as { url: string };
}

// ---------------------------------------------------------------------------
// Admin: routes
// ---------------------------------------------------------------------------

export function getAdminRoutes(): Promise<AdminRoutesResponse> {
  return request<AdminRoutesResponse>('/admin/routes');
}

export function createAdminRoute(body: AdminRouteInput): Promise<AdminCreateResponse> {
  return request<AdminCreateResponse>('/admin/routes', { method: 'POST', body });
}

export function updateAdminRoute(id: number, body: AdminRouteInput): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/routes/${id}`, { method: 'POST', body });
}

export function deleteAdminRoute(id: number): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/routes/${id}/delete`, { method: 'POST', body: {} });
}

export function saveRouteVehiclePricing(
  routeId: number,
  body: AdminRouteVehiclePricingInput
): Promise<AdminCreateResponse> {
  return request<AdminCreateResponse>(`/admin/routes/${routeId}/vehicle-pricing`, { method: 'POST', body });
}

export function deleteRouteVehiclePricing(id: number): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/route-vehicle-pricing/${id}/delete`, { method: 'POST', body: {} });
}

// ---------------------------------------------------------------------------
// Admin: route-based SEO/marketing pages
// ---------------------------------------------------------------------------

export function getRoutePages(
  filters: { status?: string; origin?: string; destination?: string; state?: string; has_quality_issues?: boolean } = {}
): Promise<RoutePagesResponse> {
  const qs = new URLSearchParams();
  if (filters.status) qs.set('status', filters.status);
  if (filters.origin) qs.set('origin', filters.origin);
  if (filters.destination) qs.set('destination', filters.destination);
  if (filters.state) qs.set('state', filters.state);
  if (filters.has_quality_issues !== undefined) qs.set('has_quality_issues', filters.has_quality_issues ? '1' : '0');
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<RoutePagesResponse>(`/admin/route-pages${suffix}`);
}

export function getEligibleRoutes(): Promise<EligibleRoutesResponse> {
  return request<EligibleRoutesResponse>('/admin/route-pages/eligible');
}

export function generateRoutePages(routeIds: number[]): Promise<RoutePageGenerateResponse> {
  return request<RoutePageGenerateResponse>('/admin/route-pages/generate', {
    method: 'POST',
    body: { route_ids: routeIds },
  });
}

export function updateRoutePage(id: number, fields: RoutePageUpdateInput): Promise<RoutePageUpdateResponse> {
  return request<RoutePageUpdateResponse>(`/admin/route-pages/${id}`, { method: 'POST', body: fields });
}

export function setRoutePageStatus(id: number, status: RoutePageStatus): Promise<RoutePageStatusResponse> {
  return request<RoutePageStatusResponse>(`/admin/route-pages/${id}/status`, { method: 'POST', body: { status } });
}

export function deleteRoutePage(id: number): Promise<RoutePageDeleteResponse> {
  return request<RoutePageDeleteResponse>(`/admin/route-pages/${id}/delete`, { method: 'POST', body: {} });
}

// Public route-marketing-page content — GET /ridego/v1/routes/{slug} lives at
// the namespace root (not under /app), same reason getAdminReportSummary()
// passes rootApiBase(); it's also unauthenticated (no admin nonce needed,
// but the header is harmless to send — see request()'s own doc comment).
export function getPublicRoutePage(slug: string): Promise<RoutePageContent> {
  return request<RoutePageContent>(`/routes/${encodeURIComponent(slug)}`, { _base: rootApiBase() });
}

// Public /routes/ index listing — GET /ridego/v1/routes, same namespace-root
// base as getPublicRoutePage() above, for the same reason.
export function getPublicRoutePagesIndex(): Promise<RoutePagesIndexResponse> {
  return request<RoutePagesIndexResponse>('/routes', { _base: rootApiBase() });
}

// Global-default Hero settings (Task 3-6) — the fallback every route page's
// hero uses when it has no per-route override for a given field.
export function getRoutePageHeroDefaults(): Promise<RoutePageHeroFields> {
  return request<RoutePageHeroFields>('/admin/route-page-hero-defaults');
}

export function updateRoutePageHeroDefaults(
  fields: Partial<RoutePageHeroFields>
): Promise<{ success: boolean; saved: Partial<RoutePageHeroFields> }> {
  return request('/admin/route-page-hero-defaults', { method: 'POST', body: fields });
}

// Same discipline as uploadCityImage() — real file-type check, WordPress's
// own upload handler; the caller sends the returned url back as
// hero_image_desktop_url/hero_image_mobile_url/card_image_url on an update call.
export async function uploadRoutePageHeroImage(file: File, variant: 'desktop' | 'mobile' | 'card'): Promise<{ url: string }> {
  const form = new FormData();
  form.set('file', file);
  form.set('variant', variant);
  const res = await fetch(apiUrl('/admin/route-pages/upload-hero-image'), {
    method: 'POST',
    credentials: 'include',
    headers: { 'X-WP-Nonce': getNonce() },
    body: form,
  });
  let payload: unknown = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }
  if (!res.ok) {
    const err = payload as { code?: string; message?: string; data?: { status: number } } | null;
    throw new ApiError({ code: err?.code ?? 'unknown_error', message: err?.message ?? `Upload failed with status ${res.status}`, data: err?.data ?? { status: res.status } });
  }
  return payload as { url: string };
}

// ---------------------------------------------------------------------------
// Admin: zones
// ---------------------------------------------------------------------------

export function getAdminZones(): Promise<AdminZonesResponse> {
  return request<AdminZonesResponse>('/admin/zones');
}

export function createAdminZone(body: AdminZoneInput): Promise<AdminCreateResponse> {
  return request<AdminCreateResponse>('/admin/zones', { method: 'POST', body });
}

export function updateAdminZone(id: number, body: AdminZoneInput): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/zones/${id}`, { method: 'POST', body });
}

export function deleteAdminZone(id: number): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/zones/${id}/delete`, { method: 'POST', body: {} });
}

// ---------------------------------------------------------------------------
// Admin: vehicle pricing
// ---------------------------------------------------------------------------

export function getAdminPricingVehicles(): Promise<AdminPricingVehiclesResponse> {
  return request<AdminPricingVehiclesResponse>('/admin/pricing/vehicles');
}

export function createAdminPricingVehicle(body: AdminPricingVehicleInput): Promise<AdminCreateResponse> {
  return request<AdminCreateResponse>('/admin/pricing/vehicles', { method: 'POST', body });
}

export function updateAdminPricingVehicle(id: number, body: AdminPricingVehicleInput): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/pricing/vehicles/${id}`, { method: 'POST', body });
}

export function toggleAdminPricingVehicle(id: number): Promise<AdminPricingVehicleToggleResponse> {
  return request<AdminPricingVehicleToggleResponse>(`/admin/pricing/vehicles/${id}/toggle`, {
    method: 'POST',
    body: {},
  });
}

// The "Choose your ride" card image on the home page and vehicle picker — a real per-vehicle-type
// photo/illustration, replacing the seeded placeholder icon_url. Same multipart pattern as
// uploadBrandingImage() (api-leadfee.ts).
export async function uploadAdminPricingVehicleImage(id: number, file: File): Promise<{ url: string }> {
  const form = new FormData();
  form.set('file', file);
  const res = await fetch(apiUrl(`/admin/pricing/vehicles/${id}/image`), {
    method: 'POST',
    credentials: 'include',
    headers: { 'X-WP-Nonce': getNonce() },
    body: form,
  });
  let payload: unknown = null;
  try {
    payload = await res.json();
  } catch {
    payload = null;
  }
  if (!res.ok) {
    const err = payload as { code?: string; message?: string; data?: { status: number } } | null;
    throw new ApiError({ code: err?.code ?? 'unknown_error', message: err?.message ?? `Upload failed with status ${res.status}`, data: err?.data ?? { status: res.status } });
  }
  return payload as { url: string };
}

// ---------------------------------------------------------------------------
// Admin: surge pricing
// ---------------------------------------------------------------------------

export function getAdminSurgeRules(): Promise<AdminSurgeResponse> {
  return request<AdminSurgeResponse>('/admin/surge');
}

export function createAdminSurgeRule(body: AdminSurgeInput): Promise<AdminCreateResponse> {
  return request<AdminCreateResponse>('/admin/surge', { method: 'POST', body });
}

export function updateAdminSurgeRule(id: number, body: AdminSurgeInput): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/surge/${id}`, { method: 'POST', body });
}

export function deleteAdminSurgeRule(id: number): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/surge/${id}/delete`, { method: 'POST', body: {} });
}

// ---------------------------------------------------------------------------
// Admin: promo codes
// ---------------------------------------------------------------------------

export function getAdminPromoCodes(): Promise<AdminPromoResponse> {
  return request<AdminPromoResponse>('/admin/promo');
}

export function createAdminPromoCode(body: AdminPromoInput): Promise<AdminCreateResponse> {
  return request<AdminCreateResponse>('/admin/promo', { method: 'POST', body });
}

export function updateAdminPromoCode(id: number, body: AdminPromoInput): Promise<AdminActionResponse> {
  return request<AdminActionResponse>(`/admin/promo/${id}`, { method: 'POST', body });
}

export function toggleAdminPromoCode(id: number): Promise<AdminPromoToggleResponse> {
  return request<AdminPromoToggleResponse>(`/admin/promo/${id}/toggle`, { method: 'POST', body: {} });
}

// ---------------------------------------------------------------------------
// Admin: reports / analytics
// ---------------------------------------------------------------------------

function dateRangeQuery(params: { from?: string; to?: string }): string {
  const qs = new URLSearchParams();
  if (params.from) qs.set('from', params.from);
  if (params.to) qs.set('to', params.to);
  const s = qs.toString();
  return s ? `?${s}` : '';
}

/** Reuses the pre-existing GET /ridego/v1/reports/summary route (root namespace, not under /app). */
export function getAdminReportSummary(params: { from?: string; to?: string } = {}): Promise<AdminReportSummary> {
  return request<AdminReportSummary>(`/reports/summary${dateRangeQuery(params)}`, { _base: rootApiBase() });
}

/** Reuses the pre-existing GET /ridego/v1/reports/vendor-performance route (root namespace, not under /app). */
export function getAdminVendorPerformance(
  params: { from?: string; to?: string; limit?: number } = {}
): Promise<AdminVendorPerformanceResponse> {
  const qs = new URLSearchParams();
  if (params.from) qs.set('from', params.from);
  if (params.to) qs.set('to', params.to);
  if (params.limit) qs.set('limit', String(params.limit));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<AdminVendorPerformanceResponse>(`/reports/vendor-performance${suffix}`, { _base: rootApiBase() });
}

export function getAdminReportsDaily(
  params: { from?: string; to?: string; page?: number } = {}
): Promise<AdminReportsDailyResponse> {
  const qs = new URLSearchParams();
  if (params.from) qs.set('from', params.from);
  if (params.to) qs.set('to', params.to);
  if (params.page) qs.set('page', String(params.page));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<AdminReportsDailyResponse>(`/admin/reports/daily${suffix}`);
}

export function getAdminReportsTripTypes(
  params: { from?: string; to?: string } = {}
): Promise<AdminReportsTripTypesResponse> {
  return request<AdminReportsTripTypesResponse>(`/admin/reports/trip-types${dateRangeQuery(params)}`);
}

export function getAdminReportsTopRoutes(
  params: { from?: string; to?: string } = {}
): Promise<AdminReportsTopRoutesResponse> {
  return request<AdminReportsTopRoutesResponse>(`/admin/reports/top-routes${dateRangeQuery(params)}`);
}

/**
 * Mints a fresh admin-ajax.php nonce (action 'ridego_admin_nonce') for
 * the CSV export links — see the comment on the matching PHP route in
 * includes/app-admin-reports-api.php for why this round-trip exists.
 */
export function getAdminReportsExportNonce(): Promise<{ nonce: string }> {
  return request<{ nonce: string }>('/admin/reports/export-nonce');
}

// ---------------------------------------------------------------------------
// Admin: financial / wallet
// ---------------------------------------------------------------------------

export function getAdminFinancialOverview(
  params: { period?: string; from?: string; to?: string } = {}
): Promise<AdminFinancialOverview> {
  const qs = new URLSearchParams();
  if (params.period) qs.set('period', params.period);
  if (params.from) qs.set('from', params.from);
  if (params.to) qs.set('to', params.to);
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<AdminFinancialOverview>(`/admin/financial/overview${suffix}`);
}

export function getAdminWalletLedger(
  params: { period?: string; from?: string; to?: string } = {}
): Promise<AdminWalletLedgerResponse> {
  const qs = new URLSearchParams();
  if (params.period) qs.set('period', params.period);
  if (params.from) qs.set('from', params.from);
  if (params.to) qs.set('to', params.to);
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<AdminWalletLedgerResponse>(`/admin/wallet/ledger${suffix}`);
}

export function getAdminWalletReconciliation(): Promise<AdminWalletReconciliationResponse> {
  return request<AdminWalletReconciliationResponse>('/admin/wallet/reconciliation');
}

export function reconcileAdminWallet(
  vendorId: number,
  reason: string
): Promise<AdminWalletReconcileResponse> {
  return request<AdminWalletReconcileResponse>(`/admin/wallet/reconcile/${vendorId}`, {
    method: 'POST',
    body: { reason },
  });
}

export function creditAdminVendorWallet(
  vendorId: number,
  amount: number,
  notes?: string
): Promise<AdminWalletMutationResponse> {
  return request<AdminWalletMutationResponse>(`/admin/wallet/credit/${vendorId}`, {
    method: 'POST',
    body: { amount, notes },
  });
}

export function debitAdminVendorWallet(
  vendorId: number,
  amount: number,
  notes?: string
): Promise<AdminWalletMutationResponse> {
  return request<AdminWalletMutationResponse>(`/admin/wallet/debit/${vendorId}`, {
    method: 'POST',
    body: { amount, notes },
  });
}

export function getAdminVendorWalletHistory(
  vendorId: number,
  params: { page?: number; limit?: number } = {}
): Promise<AdminWalletHistoryResponse> {
  const qs = new URLSearchParams();
  if (params.page) qs.set('page', String(params.page));
  if (params.limit) qs.set('limit', String(params.limit));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<AdminWalletHistoryResponse>(`/admin/wallet/history/${vendorId}${suffix}`);
}

// ---------------------------------------------------------------------------
// Admin: complaints
// ---------------------------------------------------------------------------

export function getAdminComplaints(
  params: { status?: string; priority?: string; s?: string; page?: number } = {}
): Promise<AdminComplaintsResponse> {
  const qs = new URLSearchParams();
  if (params.status) qs.set('status', params.status);
  if (params.priority) qs.set('priority', params.priority);
  if (params.s) qs.set('s', params.s);
  if (params.page) qs.set('page', String(params.page));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<AdminComplaintsResponse>(`/admin/complaints${suffix}`);
}

export function updateAdminComplaint(
  id: number,
  body: { new_status: string; admin_note?: string }
): Promise<AdminComplaintUpdateResponse> {
  return request<AdminComplaintUpdateResponse>(`/admin/complaints/${id}`, { method: 'POST', body });
}

export function bulkUpdateAdminComplaints(
  status: string,
  ids: number[]
): Promise<AdminComplaintBulkStatusResponse> {
  return request<AdminComplaintBulkStatusResponse>('/admin/complaints/bulk-status', {
    method: 'POST',
    body: { status, ids },
  });
}

// ---------------------------------------------------------------------------
// Admin: subscriptions
// ---------------------------------------------------------------------------

export function getAdminSubscriptionPlans(): Promise<AdminSubscriptionPlansResponse> {
  return request<AdminSubscriptionPlansResponse>('/admin/subscriptions/plans');
}

export function createAdminSubscriptionPlan(body: AdminSubscriptionPlanInput): Promise<AdminSubscriptionPlanCreateResponse> {
  return request<AdminSubscriptionPlanCreateResponse>('/admin/subscriptions/plans', { method: 'POST', body });
}

export function updateAdminSubscriptionPlan(id: number, body: AdminSubscriptionPlanInput): Promise<AdminSubscriptionActionResponse> {
  return request<AdminSubscriptionActionResponse>(`/admin/subscriptions/plans/${id}`, { method: 'POST', body });
}

export function getAdminActiveSubscriptions(): Promise<AdminActiveSubscriptionsResponse> {
  return request<AdminActiveSubscriptionsResponse>('/admin/subscriptions/active');
}

export function cancelAdminVendorSubscription(vendorId: number, reason?: string): Promise<AdminSubscriptionCancelResponse> {
  return request<AdminSubscriptionCancelResponse>(`/admin/subscriptions/cancel/${vendorId}`, {
    method: 'POST',
    body: { reason },
  });
}

// ---------------------------------------------------------------------------
// Admin: audit log
// ---------------------------------------------------------------------------

export function getAdminAuditLog(
  params: { entity?: string; action_filter?: string; page?: number } = {}
): Promise<AdminAuditLogResponse> {
  const qs = new URLSearchParams();
  if (params.entity) qs.set('entity', params.entity);
  if (params.action_filter) qs.set('action_filter', params.action_filter);
  if (params.page) qs.set('page', String(params.page));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<AdminAuditLogResponse>(`/admin/audit-log${suffix}`);
}

// ---------------------------------------------------------------------------
// Admin: lead monitor
// ---------------------------------------------------------------------------

export function getAdminLeads(
  params: { status?: string; s?: string; page?: number } = {}
): Promise<AdminLeadsResponse> {
  const qs = new URLSearchParams();
  if (params.status) qs.set('status', params.status);
  if (params.s) qs.set('s', params.s);
  if (params.page) qs.set('page', String(params.page));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<AdminLeadsResponse>(`/admin/leads${suffix}`);
}

// ---------------------------------------------------------------------------
// Admin: dashboard
// ---------------------------------------------------------------------------

export function getAdminDashboard(): Promise<AdminDashboardOverview> {
  return request<AdminDashboardOverview>('/admin/dashboard');
}

// ---------------------------------------------------------------------------
// Admin: settings
// ---------------------------------------------------------------------------

export function getAdminSettings(): Promise<AdminSettingsResponse> {
  return request<AdminSettingsResponse>('/admin/settings');
}

export function saveAdminSettings(body: AdminSettingsSaveRequest): Promise<AdminSettingsSaveResponse> {
  return request<AdminSettingsSaveResponse>('/admin/settings', { method: 'POST', body });
}

// ---------------------------------------------------------------------------
// Admin: tools & database
// ---------------------------------------------------------------------------

export function getAdminTools(): Promise<AdminToolsResponse> {
  return request<AdminToolsResponse>('/admin/tools');
}

export function runAdminToolAction(action: string): Promise<AdminToolActionResponse> {
  return request<AdminToolActionResponse>('/admin/tools/action', { method: 'POST', body: { action } });
}

// ---------------------------------------------------------------------------
// Admin: notifications broadcast/queue
// ---------------------------------------------------------------------------

export function getAdminNotificationStats(): Promise<AdminNotificationStatsResponse> {
  return request<AdminNotificationStatsResponse>('/admin/notifications/stats');
}

export function getAdminNotificationQueue(
  params: { status?: string; channel?: string; event?: string; page?: number } = {}
): Promise<AdminNotificationQueueResponse> {
  const qs = new URLSearchParams();
  if (params.status) qs.set('status', params.status);
  if (params.channel) qs.set('channel', params.channel);
  if (params.event) qs.set('event', params.event);
  if (params.page) qs.set('page', String(params.page));
  const suffix = qs.toString() ? `?${qs.toString()}` : '';
  return request<AdminNotificationQueueResponse>(`/admin/notifications/queue${suffix}`);
}

export function getAdminNotificationDeadLetter(): Promise<AdminNotificationDeadLetterResponse> {
  return request<AdminNotificationDeadLetterResponse>('/admin/notifications/dead-letter');
}

export function sendAdminNotificationBroadcast(body: {
  target: string;
  booking_id?: number;
  title: string;
  message: string;
}): Promise<AdminNotificationBroadcastResponse> {
  return request<AdminNotificationBroadcastResponse>('/admin/notifications/broadcast', { method: 'POST', body });
}

export function retryAdminNotification(id: number): Promise<AdminNotificationActionResponse> {
  return request<AdminNotificationActionResponse>(`/admin/notifications/${id}/retry`, { method: 'POST' });
}

export function discardAdminNotification(id: number): Promise<AdminNotificationActionResponse> {
  return request<AdminNotificationActionResponse>(`/admin/notifications/${id}/discard`, { method: 'POST' });
}

export { ApiError };

// ---------------------------------------------------------------------------
// Facilitator-model wording (admin-editable disclaimers)
// ---------------------------------------------------------------------------

export interface PlatformNotices {
  booking_amount_label: string;
  booking_amount_note: string;
  client: string;
  vendor: string;
  receipt: string;
}

// TRACE: Terms page mount → GET /app/platform-notices (public, wording only) → PlatformNotices. Edge cases: network error → the promise rejects and the caller shows a retry banner.
export function getPlatformNotices(): Promise<PlatformNotices> {
  return request<PlatformNotices>('/platform-notices');
}

// ---------------------------------------------------------------------------
// Fleet-wide document-expiry dashboard (RG next-target, admin/regional manager)
// ---------------------------------------------------------------------------

export interface DocumentExpiryRow {
  doc_id: number;
  vendor_id: number;
  vendor_name: string;
  doc_type: string;
  expiry_date: string;
  validity: 'expired' | 'expiring_soon';
  days_until_expiry: number;
  entity_type: 'vehicle' | 'driver';
  entity_id: number;
  entity_label: string;
}

export interface DocumentExpiryResponse {
  rows: DocumentExpiryRow[];
  summary: { expired: number; expiring_soon: number };
  days: number;
}

// TRACE: admin fleet document-expiry dashboard mount → GET /app/admin/fleet/document-expiry
//        (?days=&vendor_id=&status=) → DocumentExpiryResponse. Edge cases: network error → the
//        promise rejects and the caller shows a retry banner; no expiring docs → rows: [].
export function getFleetDocumentExpiry(params?: { days?: number; vendorId?: number; status?: 'expired' | 'expiring_soon' }): Promise<DocumentExpiryResponse> {
  const q = new URLSearchParams();
  if (params?.days) q.set('days', String(params.days));
  if (params?.vendorId) q.set('vendor_id', String(params.vendorId));
  if (params?.status) q.set('status', params.status);
  const qs = q.toString();
  return request<DocumentExpiryResponse>(`/admin/fleet/document-expiry${qs ? `?${qs}` : ''}`);
}

// ---------------------------------------------------------------------------
// Cross-reason "needs attention" booking list (admin + region-scoped Regional
// Manager — registered under /app/admin/bookings/ so it passes the region
// guard automatically; see includes/app-admin-bookings-api.php)
// ---------------------------------------------------------------------------

export type NeedsAttentionUrgency = 'urgent' | 'high' | 'medium';

export interface NeedsAttentionRow {
  id: number;
  booking_number: string;
  client_name: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string;
  status: string;
  reason_code: string;
  reason_label: string;
  urgency: NeedsAttentionUrgency;
}

export interface NeedsAttentionGroup {
  code: string;
  label: string;
  urgency: NeedsAttentionUrgency;
  rows: NeedsAttentionRow[];
  count: number;
}

export interface NeedsAttentionResponse {
  groups: NeedsAttentionGroup[];
  total: number;
}

// TRACE: admin/RM bookings "needs attention" mount → GET /app/admin/bookings/needs-attention(?limit=)
//        → NeedsAttentionResponse. Edge cases: network error → the promise rejects and the caller
//        shows a retry banner; a Regional Manager with no region yet assigned gets every group empty,
//        not an error (server fails closed, not open).
export function getBookingsNeedingAttention(limit?: number): Promise<NeedsAttentionResponse> {
  return request<NeedsAttentionResponse>(`/admin/bookings/needs-attention${limit ? `?limit=${limit}` : ''}`);
}
