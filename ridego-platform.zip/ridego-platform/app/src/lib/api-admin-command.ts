import { apiRequest } from './api';

export type LeadMode = 'compare' | 'instant' | string;

export interface CommandBookingRow {
  id: number;
  booking_number: string;
  status: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string;
  journey_time: string;
  total_fare: number | string;
  client_name: string;
  vendor_id: number | null;
  interested?: number | string;
  client_phone?: string;
  response_summary?: { total: number; viewed: number; interested: number; driver_confirmed: number };
  vendors?: { vendor_id: number; name: string; phone: string; interest_status: string }[];
}

export interface ActivityRow {
  id: number | string;
  action: string;
  entity: string;
  entity_id: number | string | null;
  created_at: string;
}

export interface CommandCentreResponse {
  new_leads: CommandBookingRow[];
  awaiting_vendor_response: CommandBookingRow[];
  driver_pending: CommandBookingRow[];
  ready_for_assignment: CommandBookingRow[];
  today_trips: CommandBookingRow[];
  activity: ActivityRow[];
  needs_vendor: CommandBookingRow[];
  awaiting_selection: CommandBookingRow[];
  needs_driver_details: CommandBookingRow[];
  starting_soon: CommandBookingRow[];
  payments_pending: CommandBookingRow[];
  ongoing: CommandBookingRow[];
  complaints_open: number;
  kpis: {
    bookings_today: number;
    gmv_today: number;
    ledger_pending_net: number;
    active_vendors: number;
  };
  lead_mode: LeadMode;
}

export interface ComparisonBooking {
  id: number;
  booking_number: string;
  status: string;
  pickup_city: string;
  drop_city: string;
  journey_date: string;
  journey_time: string;
  total_fare: number;
  vendor_id: number | null;
  passengers: number;
  passenger_male: number | null;
  passenger_female: number | null;
  passenger_children: number | null;
  is_safety_sensitive: boolean;
}

export interface ComparisonCandidate {
  lead_id: number;
  vendor_id: number;
  vendor_name: string;
  vendor_type: string;
  rating: number;
  rides: number;
  status: string;
  interest_status: string;
  fee_amount: number;
  sent_at: string | null;
  viewed_at: string | null;
  interested_at: string | null;
  driver_confirmed_at: string | null;
  driver_name: string | null;
  vehicle_model: string | null;
  vehicle_registration: string | null;
  not_selected_reason: string | null;
  can_select: boolean;
}

export interface ComparisonAssignment {
  id: number;
  vendor_id: number;
  driver_name_snapshot: string;
  driver_phone_snapshot: string;
  vehicle_model_snapshot: string;
  vehicle_registration_snapshot: string;
  replacement_reason?: string;
  created_at?: string;
  driver_profile?: Record<string, string> | null;
}

export interface RankingEntry {
  vendor_id: number;
  lead_id: number;
  vendor_name: string;
  score: number;
  breakdown: Record<string, number>;
}

export interface ComparisonResponse {
  booking: ComparisonBooking;
  candidates: ComparisonCandidate[];
  assignment: ComparisonAssignment | null;
  ranking: RankingEntry[];
  recommendations_enabled: boolean;
  lead_mode: LeadMode;
}

export interface MutationResult {
  success: boolean;
  message?: string;
}

export interface ReplaceAssignmentInput {
  driver_name?: string;
  driver_phone?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
  reason: string;
}

export type BulkAction = 'cancel' | 'reopen';

export interface BulkResultRow {
  id: number;
  success: boolean;
  message: string;
}

export interface BulkResponse {
  results: BulkResultRow[];
  ok: number;
  failed: number;
}

// TRACE: command centre page → GET /admin/command-centre → typed work queues + KPIs.
//        Needs capability ridego_view_command_centre → resolves payload → 403 rejects with ApiError.
export function getCommandCentre(): Promise<CommandCentreResponse> {
  return apiRequest<CommandCentreResponse>('/admin/command-centre');
}

// TRACE: compare page → GET /admin/bookings/:id/comparison → booking, candidates, assignment, ranking.
//        Needs ridego_assign_vendor → resolves payload → 404 for an unknown booking rejects with ApiError.
export function getBookingComparison(bookingId: number): Promise<ComparisonResponse> {
  return apiRequest<ComparisonResponse>(`/admin/bookings/${bookingId}/comparison`);
}

// TRACE: admin picks a candidate → POST /admin/bookings/:id/assign {vendor_id, reason, lead_id} → assignment.
//        Booking without a vendor → booking assigned → reason_required / assign_failed reject with ApiError.
export function assignBookingCandidate(
  bookingId: number,
  body: { vendor_id: number; lead_id: number; reason: string }
): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/admin/bookings/${bookingId}/assign`, { method: 'POST', body });
}

// TRACE: admin edits driver/vehicle → POST /admin/bookings/:id/replace-assignment → new current assignment row.
//        Booking assigned and active → history row added → unavailable driver/vehicle rejects with ApiError.
export function replaceBookingAssignment(bookingId: number, body: ReplaceAssignmentInput): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/admin/bookings/${bookingId}/replace-assignment`, { method: 'POST', body });
}

// TRACE: admin reopens → POST /admin/bookings/:id/reopen {reason} → vendor cleared and leads redistributed.
//        Booking has a vendor → booking unassigned → refusal rejects with ApiError.
export function reopenBooking(bookingId: number, reason: string): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/admin/bookings/${bookingId}/reopen`, { method: 'POST', body: { reason } });
}

// TRACE: admin reports a no-show → POST /admin/bookings/:id/report-issue {type:'no_show'} → issue recorded.
//        Needs ridego_manage_bookings → issue logged (reopen only if the automatic reassignment flag is on).
export function reportBookingNoShow(bookingId: number, notes: string): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/admin/bookings/${bookingId}/report-issue`, {
    method: 'POST',
    body: { type: 'no_show', notes },
  });
}

// TRACE: admin bulk bar → POST /admin/bookings/bulk {action, ids, reason} → per-id results.
//        1..50 ids and a reason → each id processed independently → invalid input rejects with ApiError.
export function bulkBookings(action: BulkAction, ids: number[], reason: string): Promise<BulkResponse> {
  return apiRequest<BulkResponse>('/admin/bookings/bulk', { method: 'POST', body: { action, ids, reason } });
}

// TRACE: admin asks for details → POST /admin/leads/:id/request-driver-details → vendor notified.
//        Lead still open → notification queued → closed lead rejects with ApiError.
export function requestDriverDetails(leadId: number): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/admin/leads/${leadId}/request-driver-details`, { method: 'POST', body: {} });
}

// TRACE: admin rejects a candidate → POST /admin/leads/:id/reject {reason} → lead marked not selected.
//        Lead still open → vendor notified → closed lead rejects with ApiError.
export function rejectLead(leadId: number, reason: string): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/admin/leads/${leadId}/reject`, { method: 'POST', body: { reason } });
}

// TRACE: command centre card action → POST /admin/bookings/:id/remind-vendors {kind} → reminds waiting vendors.
//        Needs ridego_reassign_lead → {success, reminded, message} → 400 when nobody is waiting.
export function remindVendors(bookingId: number, kind: 'response' | 'driver'): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/admin/bookings/${bookingId}/remind-vendors`, { method: 'POST', body: { kind } });
}

// TRACE: command centre card action → POST /admin/bookings/:id/resend-leads → re-runs the lead cascade.
//        Needs ridego_reassign_lead → {success, message} → 400 when no vendor is eligible.
export function resendLeads(bookingId: number): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/admin/bookings/${bookingId}/resend-leads`, { method: 'POST', body: {} });
}

// TRACE: command centre card action → POST /admin/bookings/:id/remind-client → queues payment reminder.
//        Needs ridego_manage_bookings → {success, message} → 400 when no payment is pending.
export function remindClient(bookingId: number): Promise<MutationResult> {
  return apiRequest<MutationResult>(`/admin/bookings/${bookingId}/remind-client`, { method: 'POST', body: {} });
}
