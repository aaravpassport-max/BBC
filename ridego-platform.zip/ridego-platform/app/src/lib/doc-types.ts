// TRACE: constant → single client-side source of truth for document labels and whether a document type carries an
//        expiry date. Mirrors ridego_doc_type_needs_expiry() in includes/fleet.php (server ignores expiry otherwise).
//        Edge cases: unknown types get the raw key as label and no expiry field.
export const DOC_TYPE_LABELS: Record<string, string> = {
  driving_license: 'Driving licence',
  vehicle_rc: 'Registration certificate (RC)',
  vehicle_insurance: 'Insurance',
  permit: 'Permit',
  fitness: 'Fitness certificate',
  pan_card: 'PAN card',
  profile_photo: 'Profile photo',
  driver_photo: 'Driver photo',
  id_proof: 'ID proof (Aadhaar / Voter ID / Passport)',
  address_proof: 'Address proof',
  police_verification: 'Police verification',
};

const EXPIRY_TYPES = new Set(['driving_license', 'vehicle_insurance', 'permit', 'fitness', 'vehicle_rc', 'police_verification']);

// TRACE: doc type string → label → string. Edge cases: unknown type returns the key.
export function docTypeLabel(docType: string): string {
  return DOC_TYPE_LABELS[docType] ?? docType;
}

// TRACE: doc type string → whether an expiry date input is applicable → boolean. Pure.
export function docNeedsExpiry(docType: string): boolean {
  return EXPIRY_TYPES.has(docType);
}

// TRACE: doc type string → whether the file should be a photo (image only) → boolean. Pure.
export function docIsPhoto(docType: string): boolean {
  return docType === 'profile_photo' || docType === 'driver_photo';
}
