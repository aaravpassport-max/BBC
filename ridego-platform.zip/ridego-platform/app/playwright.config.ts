import { defineConfig, devices } from '@playwright/test';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/**
 * Checked-in Playwright suite for the mobile-first transformation.
 *
 * Runs against the local WordPress test server this whole engagement has
 * used (127.0.0.1:8899) — see tests/e2e/README.md for prerequisites.
 *
 * The sandboxed environment has no way to `npx playwright install`
 * (no network access to the browser CDN), but a matching Chromium build
 * is already present on disk at /opt/pw-browsers — every project below
 * points `launchOptions.executablePath` at it directly, the same
 * approach the throwaway /home/claude/wptest-scripts/*.js scripts used
 * with the plain `playwright` package.
 */
const CHROMIUM_PATH = '/opt/pw-browsers/chromium-1194/chrome-linux/chrome';

const AUTH_DIR = path.join(__dirname, 'tests/e2e/.auth');

export default defineConfig({
  testDir: './tests/e2e',
  timeout: 30_000,
  expect: { timeout: 8_000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [['list']],
  use: {
    baseURL: 'http://127.0.0.1:8899',
    actionTimeout: 10_000,
    navigationTimeout: 20_000,
    launchOptions: {
      executablePath: CHROMIUM_PATH,
    },
  },
  projects: [
    { name: 'setup', testMatch: /auth\.setup\.ts/, use: { viewport: { width: 1440, height: 900 } } },

    // Anonymous/public viewport projects — no storageState, so pages
    // render as a logged-out visitor unless a spec logs in itself.
    {
      name: 'phone',
      testMatch: /(smoke|bottom-nav|booking-wizard|pwa|admin-tables-cards|admin-filters-sheet|accessibility)\.spec\.ts/,
      use: { ...devices['Pixel 7'], viewport: { width: 390, height: 844 }, launchOptions: { executablePath: CHROMIUM_PATH } },
      dependencies: ['setup'],
    },
    {
      name: 'tablet',
      testMatch: /(smoke|bottom-nav|booking-wizard|admin-tables-cards|admin-filters-sheet)\.spec\.ts/,
      use: { viewport: { width: 768, height: 1024 }, launchOptions: { executablePath: CHROMIUM_PATH } },
      dependencies: ['setup'],
    },
    {
      name: 'desktop',
      testMatch: /(smoke|bottom-nav|booking-wizard|admin-tables-cards|admin-filters-sheet|accessibility)\.spec\.ts/,
      use: { viewport: { width: 1440, height: 900 }, launchOptions: { executablePath: CHROMIUM_PATH } },
      dependencies: ['setup'],
    },
  ],
});
