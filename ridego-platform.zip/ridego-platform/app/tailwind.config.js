/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50: '#eef7ff',
          100: '#d9ecff',
          200: '#bcdfff',
          300: '#8eccff',
          400: '#59b0ff',
          500: '#2f8fff',
          600: '#1a6ef5',
          700: '#1558e0',
          800: '#1846b5',
          900: '#193d8f',
          950: '#132759',
        },
        accent: {
          50: '#fff7ed',
          100: '#ffedd5',
          200: '#fed7aa',
          300: '#fdba74',
          400: '#fb923c',
          500: '#f97316',
          600: '#ea580c',
          700: '#c2410c',
        },
        ink: {
          50: '#f7f8fa',
          100: '#eef0f4',
          200: '#d9dee6',
          300: '#b7c0cd',
          400: '#8c98a9',
          500: '#6b7688',
          600: '#525c6d',
          700: '#414957',
          800: '#2d323c',
          900: '#1c1f26',
          950: '#101216',
        },
        success: {
          50: '#eefdf3',
          500: '#16a34a',
          600: '#15803d',
        },
        warning: {
          50: '#fffbeb',
          500: '#d97706',
          600: '#b45309',
        },
        danger: {
          50: '#fef2f2',
          500: '#dc2626',
          600: '#b91c1c',
        },
        canvas: '#F5F7FA',
      },
      fontFamily: {
        sans: ['"Inter"', 'ui-sans-serif', 'system-ui', '-apple-system', 'sans-serif'],
      },
      fontSize: {
        xs: ['0.75rem', { lineHeight: '1rem' }],
        sm: ['0.875rem', { lineHeight: '1.25rem' }],
        base: ['1rem', { lineHeight: '1.5rem' }],
        lg: ['1.125rem', { lineHeight: '1.75rem' }],
        xl: ['1.25rem', { lineHeight: '1.75rem' }],
        '2xl': ['1.5rem', { lineHeight: '2rem' }],
        '3xl': ['1.875rem', { lineHeight: '2.25rem' }],
        '4xl': ['2.25rem', { lineHeight: '2.5rem' }],
        '5xl': ['3rem', { lineHeight: '1.1' }],
        '6xl': ['3.75rem', { lineHeight: '1.05' }],
      },
      borderRadius: {
        sm: '0.375rem',
        DEFAULT: '0.5rem',
        md: '0.625rem',
        lg: '0.875rem',
        xl: '1.25rem',
        '2xl': '1.75rem',
        full: '9999px',
      },
      boxShadow: {
        xs: '0 1px 2px 0 rgb(16 18 22 / 0.05)',
        sm: '0 1px 3px 0 rgb(16 18 22 / 0.08), 0 1px 2px -1px rgb(16 18 22 / 0.06)',
        card: '0 2px 8px -2px rgb(16 18 22 / 0.08), 0 4px 16px -4px rgb(16 18 22 / 0.08)',
        lg: '0 8px 24px -4px rgb(16 18 22 / 0.12), 0 4px 8px -4px rgb(16 18 22 / 0.08)',
        xl: '0 20px 48px -12px rgb(16 18 22 / 0.22)',
        /* --- Premium redesign shadow scale (§39 of spec): exactly 3 levels,
           used consistently instead of ad-hoc rgba() values scattered inline. */
        l1: '0 1px 3px rgba(16,24,40,.05)',
        l2: '0 4px 16px rgba(16,24,40,.06)',
        l3: '0 10px 30px rgba(16,24,40,.08)',
        /* --- Assertive redesign pass: rest-state shadows strong enough to
           read as "raised" in a static screenshot, not just on hover.
           Each combines a tight dark contact shadow with a soft wide
           ambient shadow, using ink tokens only. */
        'card-rest': '0 1px 2px rgba(16,18,22,0.10), 0 8px 16px -4px rgba(16,18,22,0.20), 0 24px 48px -10px rgba(16,18,22,0.26)',
        'card-hover': '0 2px 4px rgba(16,18,22,0.12), 0 14px 28px -6px rgba(16,18,22,0.28), 0 32px 64px -12px rgba(16,18,22,0.34)',
        'tile-rest': '0 4px 10px -2px rgba(16,18,22,0.22), 0 1px 3px rgba(16,18,22,0.16)',
      },
      spacing: {
        18: '4.5rem',
        22: '5.5rem',
      },
    },
  },
  plugins: [],
}
