# RideGo App (React + TypeScript + Vite)

This is the standalone RideGo frontend. It is a normal React SPA — WordPress is
used only for authentication (cookie session) and as a static host for the
built files; all routing, UI and UX live here.

See `includes/app-shell.php` and `includes/app-api.php` in the plugin for how
this app is served and what REST API it talks to.

## Requirements

- Node.js 18+ (tested with Node 22)
- npm

## Development

```bash
npm install
npm run dev
```

This starts a local Vite dev server. Since the WordPress PHP shell isn't
running locally, `window.__RIDEGO__` won't be injected — `src/lib/bootstrap.ts`
falls back to dev defaults (`apiUrl: 'http://localhost/wp-json/ridego/v1/app'`)
so the app boots without crashing. Point that default at a real WordPress
install (with the RideGo plugin active) if you want live data while
developing, or adjust the fallback in `bootstrap.ts` for your local setup.

## Type checking

```bash
npx tsc --noEmit
```

## Production build

```bash
npm run build
```

This runs `tsc -b && vite build` and outputs the production bundle to
`app/dist/`. **This `dist/` folder is what WordPress actually serves** —
`includes/app-shell.php` reads `app/dist/index.html`, rewrites its
`/assets/...` references to the plugin's real URL, injects
`window.__RIDEGO__`, and serves that for every request under `/app/*`.

**Important:** if you change anything under `app/src/`, you must run
`npm run build` again and make sure the resulting `app/dist/` is committed /
shipped with the plugin. The live site does not run a Node build step — it
only serves whatever is already in `app/dist/`. Changing source without
rebuilding (or rebuilding without shipping `dist/`) has no effect in
production.

## Project structure

- `src/lib/bootstrap.ts` — reads `window.__RIDEGO__` (injected by the PHP
  shell), with safe dev fallbacks.
- `src/lib/api.ts` — typed fetch wrapper for every `/wp-json/ridego/v1/app/...`
  route, including nonce handling and stale-nonce recovery.
- `src/types/api.ts` — TypeScript types for every API request/response shape.
- `src/context/AuthContext.tsx` — auth state (user, login/register/logout/
  refresh), seeded from the bootstrap payload.
- `src/router.tsx`, `src/App.tsx` — client-side routing (React Router v6,
  browser history mode) and the app shell.
- `src/components/layout/` — header, footer, persistent app shell.
- `src/components/ui/` — shared design-system primitives (buttons, skeletons,
  error banners, empty states, confirm dialog).
- `src/pages/` — route-level pages (Home, Login, Register, My Trips, Vendor
  Dashboard, 404).

## Styling

Tailwind CSS (v3, installed via PostCSS — not a CDN). Design tokens (colors,
spacing, radius, shadows, font sizes) live in `tailwind.config.js` under
`theme.extend`.
