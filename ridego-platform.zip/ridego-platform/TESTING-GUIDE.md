# RideGo Platform - Testing Guide

## Manual Testing Checklist

### 1. Booking Flow (Client Side)

**Test Case: One-Way Booking**
1. Go to /booking page
2. Enter pickup city (use autocomplete)
3. Enter drop city
4. Select journey date (future date)
5. Select time
6. Choose vehicle type
7. Enter passenger details
8. Click "Calculate Fare"
9. Verify fare shown correctly
10. Enter phone number
11. Request OTP
12. Verify OTP received (SMS/Email/WhatsApp)
13. Enter OTP
14. Complete booking
15. Verify booking confirmation page
16. Check email/WhatsApp notification received

**Expected Result:** Booking created with status "payment_pending"

**Test Case: Payment Proof Upload**
1. From confirmation page, click "Upload Payment Proof"
2. Enter UTR number
3. Select payment app
4. Upload screenshot (JPG/PNG, <5MB)
5. Submit
6. Verify status changed to "proof_submitted"
7. Check admin notification sent (Telegram)

**Expected Result:** Admin can see payment proof in admin panel

### 2. Admin Panel Testing

**Test Case: Payment Verification**
1. Login as admin
2. Go to RideGo → Bookings
3. Filter by "Payment Pending"
4. Click booking with proof submitted
5. Click "Verify Payment"
6. Review payment proof image
7. Verify UTR matches
8. Click "VERIFY & CONFIRM"
9. Check status changed to "confirmed"
10. Verify client notification sent

**Expected Result:** Booking confirmed, client notified

**Test Case: Dashboard Analytics**
1. Go to RideGo → Dashboard
2. Verify stats cards showing correct numbers:
   - Today's Bookings
   - Pending Bookings
   - Active Vendors
   - Today's Revenue
3. Check recent bookings table populated
4. Click "View Booking" - opens detail page

**Expected Result:** All stats accurate, links working

### 3. Vendor Management

**Test Case: Vendor Registration**
1. Logout or use incognito mode
2. Go to /become-vendor page
3. Fill registration form
4. Upload KYC documents (PAN, Aadhaar, License)
5. Submit
6. Verify success message
7. Login as admin
8. Go to RideGo → Vendors
9. Find new vendor (status: pending)
10. Click "Approve"
11. Verify vendor status = "active"

**Expected Result:** Vendor can login and access dashboard

### 4. Notification Testing

**Test Case: WhatsApp Notifications**
1. Configure CallMeBot or Fonnte in settings
2. Create test booking
3. Verify WhatsApp received:
   - Booking confirmation
   - Payment instructions
4. Upload payment proof
5. Verify admin Telegram alert
6. Approve payment
7. Verify WhatsApp payment verified message

**Expected Result:** All notifications delivered

### 5. OTP System

**Test Case: OTP Delivery**
1. Enter phone number on booking form
2. Click "Send OTP"
3. Check delivery (in order): Email → WhatsApp → SMS
4. Enter correct OTP
5. Verify phone verified

**Test Case: OTP Rate Limiting**
1. Request OTP 3 times in 1 hour
2. Try 4th request
3. Verify blocked with error message

**Expected Result:** Rate limiting working

### 6. Pricing Engine

**Test Case: Fare Calculation**
1. Select Mumbai → Pune (150km)
2. Choose Sedan
3. Date: Tomorrow at 2 PM
4. Verify fare = Distance × Rate + GST

**Test Case: Night Charge**
1. Select same route
2. Time: 11:30 PM
3. Verify 15% night charge added

**Test Case: Promo Code**
1. Apply promo code "TEST10"
2. Verify 10% discount applied
3. Verify total fare reduced

**Expected Result:** All calculations accurate

### 7. Mobile Responsiveness

**Devices to Test:**
- [ ] iPhone (Safari)
- [ ] Android Phone (Chrome)
- [ ] iPad (Safari)
- [ ] Small laptop (1366×768)

**Pages to Check:**
- [ ] Homepage
- [ ] Booking form
- [ ] Search results
- [ ] Booking confirmation
- [ ] My Trips
- [ ] Vendor dashboard

**Expected Result:** All pages usable on mobile

### 8. Browser Compatibility

Test on:
- [ ] Chrome (latest)
- [ ] Firefox (latest)
- [ ] Safari (latest)
- [ ] Edge (latest)

**Expected Result:** No JavaScript errors, all features working

### 9. Performance Testing

**Page Load Speed:**
- [ ] Homepage: <2 seconds
- [ ] Booking page: <3 seconds
- [ ] Admin dashboard: <4 seconds

**Use:** Google PageSpeed Insights

**Expected Result:** All pages load within acceptable time

### 10. Security Testing

**Test Case: SQL Injection Prevention**
1. Try entering `' OR '1'='1` in search boxes
2. Verify no error, no data leak

**Test Case: XSS Prevention**
1. Try entering `<script>alert('XSS')</script>` in text fields
2. Verify script not executed

**Test Case: File Upload Validation**
1. Try uploading .exe file as payment proof
2. Verify rejected with error

**Expected Result:** All attacks blocked

## Automated Testing (Optional)

### Unit Tests (PHPUnit)
```bash
composer require --dev phpunit/phpunit
phpunit tests/
```

### Load Testing (Apache Bench)
```bash
ab -n 1000 -c 10 https://yoursite.com/booking/
```

**Target:** Handle 10 concurrent users

## Bug Reporting Template

When you find a bug, report using this format:

```
**Title:** Brief description
**Severity:** Critical / High / Medium / Low
**Steps to Reproduce:**
1. Step 1
2. Step 2
3. Step 3

**Expected Result:** What should happen
**Actual Result:** What actually happened
**Screenshot:** (attach if applicable)
**Browser/Device:** Chrome on Windows 10
```

## Test Data

**Test Phone Numbers:**
- Use your real number for OTP testing

**Test Payment:**
- Use test mode Razorpay keys
- Use test card: 4111 1111 1111 1111

**Test Promo Codes:**
Create these in admin for testing:
- TEST10 (10% off)
- FIRST50 (₹50 flat off, first booking only)
- ROUND15 (15% off round trips)

## Pass Criteria

Plugin is ready for production when:
- [ ] All critical test cases pass
- [ ] Zero errors in WordPress debug log
- [ ] All notifications delivered
- [ ] Payment flow works end-to-end
- [ ] Mobile responsive
- [ ] Page speed <3 seconds
- [ ] Security tests passed
