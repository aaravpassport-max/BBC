# RideGo Production Deployment Checklist

## Pre-Launch (Must Complete)

### Server Setup
- [ ] PHP 8.0+, MySQL 8.0+, SSL active
- [ ] WordPress 6.0+ installed
- [ ] Memory: 512MB+ (1GB recommended)

### Plugin Installation
- [ ] Upload & activate plugin
- [ ] Verify 16 pages created
- [ ] Verify 20+ database tables created
- [ ] Sample data seeded

### API Configuration (Settings)
- [ ] Google Maps API key
- [ ] Razorpay keys (test mode first!)
- [ ] WhatsApp (CallMeBot or Fonnte)
- [ ] Telegram bot token & chat ID

### Payment Setup
- [ ] Bank account details entered
- [ ] UPI ID configured
- [ ] Test payment proof upload

### Testing
- [ ] Complete one booking end-to-end
- [ ] Verify OTP delivery
- [ ] Test payment proof upload
- [ ] Check admin notifications
- [ ] Verify vendor registration
- [ ] Mobile responsive check

### Security
- [ ] Change admin username
- [ ] Strong passwords
- [ ] WP_DEBUG = false
- [ ] DISALLOW_FILE_EDIT = true
- [ ] SSL certificate valid

### Performance
- [ ] Enable caching plugin
- [ ] Optimize images
- [ ] Test page load speed (<3 seconds)

### Content
- [ ] Homepage complete
- [ ] About Us, Contact pages
- [ ] FAQ, Terms, Privacy updated

## Go Live
- [ ] Switch Razorpay to LIVE mode
- [ ] Enable real SMS/WhatsApp
- [ ] Monitor first 10 bookings closely
- [ ] Set up daily backups

## Post-Launch (Week 1)
- [ ] Check error logs daily
- [ ] Monitor booking success rate
- [ ] Track notification delivery
- [ ] Collect user feedback
- [ ] Fix any reported bugs
