<?php
/**
 * RideGo - Content Seeding (Session 5)
 * Auto-populates FAQ, Terms, Privacy pages on activation.
 *
 * Entry point: ridego_seed_content() - called by includes/install.php
 * via ridego_seed_all_data().
 */

if ( ! defined('ABSPATH') ) { exit; }

if ( ! function_exists('ridego_seed_faq_content') ) {
function ridego_seed_faq_content() {
    $faq_page_id = get_option('ridego_faq_page_id');
    if ( ! $faq_page_id ) { return; }

    $faqs = array(
        array('Q' => 'How do I book a cab?',                'A' => 'Visit our booking page, enter pickup & drop locations, select vehicle type, choose journey date & time, and complete the booking.'),
        array('Q' => 'What payment methods do you accept?', 'A' => 'We accept bank transfer, UPI, and online payment via Razorpay (credit/debit cards, net banking, wallets).'),
        array('Q' => 'How do I cancel my booking?',         'A' => 'Go to My Trips, select your booking, and click Cancel. Cancellation charges apply as per our policy.'),
        array('Q' => 'When will I get driver details?',     'A' => 'Driver details (name, phone, vehicle number) are sent 24 hours before your journey via WhatsApp and email.'),
        array('Q' => 'Is GST included in the fare?',        'A' => 'Yes, all fares are inclusive of 5% GST.'),
        array('Q' => 'Do you operate 24x7?',                'A' => 'Yes, our service is available 24 hours a day, 7 days a week.'),
        array('Q' => 'What if my flight is delayed?',       'A' => 'For airport pickups, we provide 1 hour free wait time. Just inform your driver about the delay.'),
        array('Q' => 'Can I change my booking details?',    'A' => 'Yes, contact our support team at least 6 hours before journey to modify pickup time, location, or vehicle type.'),
    );

    $content = '<h2>Frequently Asked Questions</h2>';
    foreach ( $faqs as $index => $faq ) {
        $content .= '<h3>' . ($index + 1) . '. ' . esc_html($faq['Q']) . '</h3>';
        $content .= '<p>' . esc_html($faq['A']) . '</p>';
    }

    wp_update_post( array( 'ID' => $faq_page_id, 'post_content' => $content ) );
}
}

if ( ! function_exists('ridego_seed_terms_content') ) {
function ridego_seed_terms_content() {
    $terms_page_id = get_option('ridego_terms_page_id');
    if ( ! $terms_page_id ) { return; }

    $support_email = get_option('ridego_support_email', 'support@ridego.com');
    $content = '<h1>Terms &amp; Conditions</h1>
<p><strong>Last Updated:</strong> ' . date('F Y') . '</p>

<h2>1. Acceptance of Terms</h2>
<p>By booking a cab through RideGo, you agree to these terms and conditions.</p>

<h2>2. Booking &amp; Payment</h2>
<p>All bookings are subject to availability. Payment must be completed to confirm your booking.</p>

<h2>3. Cancellation Policy</h2>
<p>Cancellations made 24+ hours before journey: Full refund<br>
12-24 hours before: 50% refund<br>
Less than 12 hours: No refund</p>

<h2>4. Passenger Responsibilities</h2>
<p>Passengers must provide accurate pickup details and be ready at the scheduled time.</p>

<h2>5. Driver Responsibilities</h2>
<p>Drivers must maintain vehicle cleanliness, follow traffic rules, and treat passengers respectfully.</p>

<h2>6. Liability</h2>
<p>RideGo is not liable for delays caused by traffic, weather, or unforeseen circumstances.</p>

<h2>7. Complaints</h2>
<p>Any complaints should be raised within 24 hours of journey completion.</p>

<h2>Contact Us</h2>
<p>For queries, contact: ' . esc_html($support_email) . '</p>';

    wp_update_post( array( 'ID' => $terms_page_id, 'post_content' => $content ) );
}
}

/**
 * Entry point called by install.php's ridego_seed_all_data().
 * The dispatcher derives the function name from the file name -
 * "data/seed-content.php" -> "ridego_seed_content" - so this name is required.
 */
if ( ! function_exists('ridego_seed_content') ) {
function ridego_seed_content() {
    ridego_seed_faq_content();
    ridego_seed_terms_content();
}
}
