<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function ridego_seed_cities() {
    global $wpdb;
    $tbl = $wpdb->prefix . 'ridego_cities';

    /* Root-cause note: this used to `return` outright once any city row
       existed, which meant re-clicking "Seed Vehicles & Cities" on the
       Tools page could never add anything new once the plugin had been
       seeded once — including the North India origin/destination batch
       below, added after the original pan-India list. Each city insert
       below is already individually guarded by its own slug-exists
       check, so it's safe to let this function run every time; it just
       inserts whatever rows are still missing and leaves everything
       else untouched. */

    $cities = array(
        /* name, state, lat, lng, airport_name, airport_code, is_popular */
        array('Mumbai',       'Maharashtra',      19.0760, 72.8777, 'Chhatrapati Shivaji Maharaj International Airport', 'BOM', 1),
        array('Delhi',        'Delhi',             28.6139, 77.2090, 'Indira Gandhi International Airport',              'DEL', 1),
        array('Bangalore',    'Karnataka',         12.9716, 77.5946, 'Kempegowda International Airport',                'BLR', 1),
        array('Chennai',      'Tamil Nadu',        13.0827, 80.2707, 'Chennai International Airport',                   'MAA', 1),
        array('Hyderabad',    'Telangana',         17.3850, 78.4867, 'Rajiv Gandhi International Airport',              'HYD', 1),
        array('Pune',         'Maharashtra',       18.5204, 73.8567, 'Pune International Airport',                     'PNQ', 1),
        array('Kolkata',      'West Bengal',       22.5726, 88.3639, 'Netaji Subhas Chandra Bose International Airport','CCU', 1),
        array('Ahmedabad',    'Gujarat',           23.0225, 72.5714, 'Sardar Vallabhbhai Patel International Airport',  'AMD', 1),
        array('Jaipur',       'Rajasthan',         26.9124, 75.7873, 'Jaipur International Airport',                   'JAI', 1),
        array('Agra',         'Uttar Pradesh',     27.1767, 78.0081, 'Agra Airport',                                   'AGR', 1),
        array('Surat',        'Gujarat',           21.1702, 72.8311, 'Surat Airport',                                  'STV', 0),
        array('Lucknow',      'Uttar Pradesh',     26.8467, 80.9462, 'Chaudhary Charan Singh Airport',                 'LKO', 0),
        array('Kanpur',       'Uttar Pradesh',     26.4499, 80.3319, 'Kanpur Airport',                                 'KNU', 0),
        array('Nagpur',       'Maharashtra',       21.1458, 79.0882, 'Dr. Babasaheb Ambedkar International Airport',   'NAG', 0),
        array('Nashik',       'Maharashtra',       20.0111, 73.7903, 'Nashik Airport',                                 'ISK', 0),
        array('Vadodara',     'Gujarat',           22.3072, 73.1812, 'Vadodara Airport',                               'BDQ', 0),
        array('Indore',       'Madhya Pradesh',    22.7196, 75.8577, 'Devi Ahilyabai Holkar Airport',                  'IDR', 0),
        array('Bhopal',       'Madhya Pradesh',    23.2599, 77.4126, 'Raja Bhoj Airport',                              'BHO', 0),
        array('Visakhapatnam','Andhra Pradesh',    17.6868, 83.2185, 'Visakhapatnam International Airport',            'VTZ', 0),
        array('Coimbatore',   'Tamil Nadu',        11.0168, 76.9558, 'Coimbatore International Airport',               'CJB', 0),
        array('Madurai',      'Tamil Nadu',         9.9252, 78.1198, 'Madurai Airport',                                'IXM', 0),
        array('Kochi',        'Kerala',             9.9312, 76.2673, 'Cochin International Airport',                   'COK', 1),
        array('Thiruvananthapuram','Kerala',        8.5241, 76.9366, 'Trivandrum International Airport',               'TRV', 0),
        array('Kozhikode',    'Kerala',            11.2588, 75.7804, 'Calicut International Airport',                  'CCJ', 0),
        array('Goa',          'Goa',               15.2993, 74.1240, 'Goa International Airport (Mopa)',               'GOX', 1),
        array('Bhubaneswar',  'Odisha',            20.2961, 85.8245, 'Biju Patnaik International Airport',             'BBI', 0),
        array('Patna',        'Bihar',             25.5941, 85.1376, 'Jay Prakash Narayan Airport',                    'PAT', 0),
        array('Ranchi',       'Jharkhand',         23.3441, 85.3096, 'Birsa Munda Airport',                           'IXR', 0),
        array('Raipur',       'Chhattisgarh',      21.2514, 81.6296, 'Swami Vivekananda Airport',                     'RPR', 0),
        array('Jodhpur',      'Rajasthan',         26.2389, 73.0243, 'Jodhpur Airport',                               'JDH', 0),
        array('Udaipur',      'Rajasthan',         24.5854, 73.7125, 'Maharana Pratap Airport',                        'UDR', 0),
        array('Amritsar',     'Punjab',            31.6340, 74.8723, 'Sri Guru Ram Dass Jee International Airport',    'ATQ', 0),
        array('Chandigarh',   'Punjab/Haryana',    30.7333, 76.7794, 'Chandigarh International Airport',               'IXC', 0),
        array('Ludhiana',     'Punjab',            30.9010, 75.8573, 'Sahnewal Airport',                               'LUH', 0),
        array('Jammu',        'J&K',               32.7266, 74.8570, 'Jammu Airport',                                  'IXJ', 0),
        array('Srinagar',     'J&K',               34.0837, 74.7973, 'Sheikh ul Alam International Airport',           'SXR', 0),
        array('Dehradun',     'Uttarakhand',       30.3165, 78.0322, 'Jolly Grant Airport',                            'DED', 0),
        array('Haridwar',     'Uttarakhand',       29.9457, 78.1642, '', '', 0),
        array('Rishikesh',    'Uttarakhand',       30.0869, 78.2676, '', '', 0),
        array('Manali',       'Himachal Pradesh',  32.2396, 77.1887, '', '', 0),
        array('Shimla',       'Himachal Pradesh',  31.1048, 77.1734, 'Shimla Airport',                                 'SLV', 0),
        array('Guwahati',     'Assam',             26.1445, 91.7362, 'Lokpriya Gopinath Bordoloi International Airport','GAU', 0),
        array('Varanasi',     'Uttar Pradesh',     25.3176, 82.9739, 'Lal Bahadur Shastri International Airport',      'VNS', 0),
        array('Prayagraj',    'Uttar Pradesh',     25.4358, 81.8463, 'Prayagraj Airport',                              'IXD', 0),
        array('Mysore',       'Karnataka',         12.2958, 76.6394, 'Mysore Airport',                                 'MYQ', 0),
        array('Mangalore',    'Karnataka',         12.9141, 74.8560, 'Mangalore International Airport',                'IXE', 0),
        array('Tirupati',     'Andhra Pradesh',    13.6288, 79.4192, 'Tirupati Airport',                               'TIR', 0),
        array('Vijayawada',   'Andhra Pradesh',    16.5062, 80.6480, 'Vijayawada International Airport',               'VGA', 0),
        array('Aurangabad',   'Maharashtra',       19.8762, 75.3433, 'Chikkalthana Airport',                           'IXU', 0),
        array('Shirdi',       'Maharashtra',       19.7642, 74.4776, 'Shirdi Airport',                                 'SAG', 0),
        array('Navi Mumbai',  'Maharashtra',       19.0330, 73.0297, '', '', 0),
        array('Thane',        'Maharashtra',       19.2183, 72.9781, '', '', 0),
    );

    $sort = 0;
    foreach ( $cities as $c ) {
        $slug = sanitize_title($c[0]);
        /* Skip if already exists */
        $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$tbl} WHERE slug=%s", $slug));
        if ( $exists ) { $sort++; continue; }
        $wpdb->insert($tbl, array(
            'name'         => $c[0],
            'slug'         => $slug,
            'state'        => $c[1],
            'country'      => 'India',
            'lat'          => $c[2],
            'lng'          => $c[3],
            'airport_name' => $c[4],
            'airport_code' => $c[5],
            'is_popular'   => $c[6],
            'is_active'    => 1,
            'sort_order'   => $sort++,
            /* is_origin_enabled / is_destination_enabled left unset here
               deliberately — the column default (1/1) is correct for
               every city in this pan-India list: all of them can serve
               as either a pickup or a drop city. */
        ));
    }

    /* ------------------------------------------------------------
       NORTH INDIA — origin/destination role batch
       ------------------------------------------------------------
       Cities from the North India outstation-route corridor list
       (Delhi NCR / Chandigarh / Jaipur / Agra / Dehradun-Haridwar /
       Himachal / Uttarakhand / Punjab / Rajasthan), added on top of
       the pan-India list above with EXPLICIT origin/destination role
       flags rather than the 1/1 default — a small NCR satellite city
       like Faridabad is a realistic pickup point but not something a
       customer books a trip TO, and conversely a hill-station/temple
       town like Kainchi Dham or Salasar Balaji is a destination a
       customer travels to, never somewhere a ride starts from. Cities
       from that same corridor list that already exist in the list
       above (Delhi, Jaipur, Agra, Lucknow, Kanpur, Varanasi, Amritsar,
       Chandigarh, Jodhpur, Udaipur, Dehradun, Haridwar, Rishikesh,
       Manali, Shimla, Ludhiana) are intentionally NOT repeated here —
       they already default to both roles enabled, which matches every
       one of them appearing in both the origin and destination tiers.
       Coordinates are each city's standard, publicly documented
       lat/lng (same source/precision as the pan-India list above),
       not measured or looked up per-route. ------------------------------------------------------------ */
    $north_india = array(
        /* name, state, lat, lng, is_origin_enabled, is_destination_enabled */
        array('Gurugram',      'Haryana',           28.4595, 77.0266, 1, 0),
        array('Noida',         'Uttar Pradesh',     28.5355, 77.3910, 1, 0),
        array('Faridabad',     'Haryana',           28.4089, 77.3178, 1, 0),
        array('Ghaziabad',     'Uttar Pradesh',     28.6692, 77.4538, 1, 0),
        array('Mathura',       'Uttar Pradesh',     27.4924, 77.6737, 1, 1),
        array('Vrindavan',     'Uttar Pradesh',     27.5820, 77.7006, 1, 1),
        array('Meerut',        'Uttar Pradesh',     28.9845, 77.7064, 1, 1),
        array('Ayodhya',       'Uttar Pradesh',     26.7922, 82.1998, 1, 1),
        array('Aligarh',       'Uttar Pradesh',     27.8974, 78.0880, 1, 0),
        array('Bareilly',      'Uttar Pradesh',     28.3670, 79.4304, 1, 0),
        array('Moradabad',     'Uttar Pradesh',     28.8386, 78.7733, 1, 0),
        array('Ajmer',         'Rajasthan',         26.4499, 74.6399, 1, 1),
        array('Pushkar',       'Rajasthan',         26.4897, 74.5511, 1, 1),
        array('Kota',          'Rajasthan',         25.2138, 75.8648, 1, 1),
        array('Bikaner',       'Rajasthan',         28.0229, 73.3119, 1, 1),
        array('Alwar',         'Rajasthan',         27.5530, 76.6346, 1, 1),
        array('Jalandhar',     'Punjab',            31.3260, 75.5762, 1, 1),
        array('Patiala',       'Punjab',            30.3398, 76.3869, 1, 1),
        array('Pathankot',     'Punjab',            32.2643, 75.6421, 1, 1),
        array('Dharamshala',   'Himachal Pradesh',  32.2190, 76.3234, 1, 1),
        array('Kullu',         'Himachal Pradesh',  31.9578, 77.1095, 1, 1),
        array('Kasauli',       'Himachal Pradesh',  30.9012, 76.9640, 1, 1),
        array('Nainital',      'Uttarakhand',       29.3919, 79.4542, 1, 1),
        array('Mussoorie',     'Uttarakhand',       30.4598, 78.0664, 1, 1),
        array('Kainchi Dham',  'Uttarakhand',       29.3667, 79.6333, 0, 1),
        array('Ramnagar',      'Uttarakhand',       29.3950, 79.1290, 0, 1),
        array('Ranikhet',      'Uttarakhand',       29.6420, 79.4330, 0, 1),
        array('Almora',        'Uttarakhand',       29.5892, 79.6467, 0, 1),
        array('Mukteshwar',    'Uttarakhand',       29.4703, 79.6478, 0, 1),
        array('Dalhousie',     'Himachal Pradesh',  32.5387, 75.9700, 0, 1),
        array('Kasol',         'Himachal Pradesh',  32.0100, 77.3145, 0, 1),
        array('Palampur',      'Himachal Pradesh',  32.1104, 76.5364, 0, 1),
        array('Ranthambore',   'Rajasthan',         26.0173, 76.5026, 0, 1),
        array('Khatu Shyam Ji','Rajasthan',         27.3382, 75.5228, 0, 1),
        array('Salasar Balaji','Rajasthan',         27.7008, 74.6135, 0, 1),
        array('Kurukshetra',   'Haryana',           29.9695, 76.8783, 0, 1),
        array('Panipat',       'Haryana',           29.3909, 76.9635, 0, 1),
    );

    foreach ( $north_india as $c ) {
        $slug = sanitize_title( $c[0] );
        $exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$tbl} WHERE slug=%s", $slug ) );
        if ( $exists ) { $sort++; continue; }
        $wpdb->insert( $tbl, array(
            'name'                    => $c[0],
            'slug'                    => $slug,
            'state'                   => $c[1],
            'country'                 => 'India',
            'lat'                     => $c[2],
            'lng'                     => $c[3],
            'airport_name'            => '',
            'airport_code'            => '',
            'is_popular'              => 0,
            'is_active'               => 1,
            'sort_order'              => $sort++,
            'is_origin_enabled'       => $c[4],
            'is_destination_enabled'  => $c[5],
        ) );
    }

    ridego_clear_cities_cache();
}
