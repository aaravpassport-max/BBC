<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Seeds ridego_routes for the North India origin/destination city set
 * (see data/seed-cities.php). Only runs when the routes table is empty
 * — unlike seed-cities.php this is NOT re-run-safe row-by-row, because
 * "already have some routes, don't touch them" is the correct default
 * for an admin who may have hand-edited/deleted routes since the last
 * seed (re-running per-pair here could silently resurrect a route an
 * admin deliberately removed).
 *
 * Distances are estimated, not fabricated: every row uses the EXACT
 * same haversine-straight-line × 1.35 road-factor formula, at the same
 * 45 km/h average speed, that ridego_resolve_route_distance()
 * (includes/pricing.php) already uses as its live fallback for ANY
 * origin/destination pair that has no explicit route row. So seeding
 * these rows does not change what fare a customer is quoted for these
 * pairs — it only makes the pairs visible and individually manageable
 * (activate/deactivate, mark popular, set a fixed price or per-vehicle
 * override) on the admin Routes page, instead of existing only as an
 * invisible on-the-fly estimate.
 *
 * "Popular" corridors are the ones explicitly named as established
 * routes in the route-planning brief this feature was built from
 * (Delhi-Agra, Delhi-Jaipur, Chandigarh-Manali, etc.) — seeded first
 * so they always make it in even though the remaining pairs are
 * capped, and flagged is_popular so they surface first in the booking
 * UI's popular-routes affordances.
 */
function ridego_seed_routes() {
    global $wpdb;
    $rtbl = $wpdb->prefix . 'ridego_routes';
    $ctbl = $wpdb->prefix . 'ridego_cities';

    if ( ! function_exists( 'ridego_haversine_km' ) ) { return; }
    if ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$rtbl}" ) > 0 ) { return; }

    $origins = $wpdb->get_results(
        "SELECT id, name, lat, lng FROM {$ctbl} WHERE is_origin_enabled=1 AND is_active=1 AND lat IS NOT NULL AND lng IS NOT NULL"
    );
    $dests = $wpdb->get_results(
        "SELECT id, name, lat, lng FROM {$ctbl} WHERE is_destination_enabled=1 AND is_active=1 AND lat IS NOT NULL AND lng IS NOT NULL"
    );
    if ( ! $origins || ! $dests ) { return; }

    $by_name = array();
    foreach ( array_merge( $origins, $dests ) as $c ) {
        $by_name[ $c->name ] = $c;
    }

    /* Explicitly named corridors from the route-planning brief this
       feature was built from — always seeded, always marked popular. */
    $priority_pairs = array(
        array( 'Delhi', 'Agra' ), array( 'Delhi', 'Jaipur' ), array( 'Delhi', 'Haridwar' ),
        array( 'Delhi', 'Rishikesh' ), array( 'Delhi', 'Chandigarh' ), array( 'Delhi', 'Shimla' ),
        array( 'Delhi', 'Manali' ), array( 'Jaipur', 'Agra' ), array( 'Jaipur', 'Udaipur' ),
        array( 'Jaipur', 'Jodhpur' ), array( 'Chandigarh', 'Shimla' ), array( 'Chandigarh', 'Manali' ),
        array( 'Delhi', 'Amritsar' ),
    );

    $seeded_pairs = array(); // "minId|maxId" => true, dedupes unordered pairs (routes are directional rows but we only ever seed one direction per pair — ridego_resolve_route_distance() already matches either direction).
    $rows         = array();

    $road_factor    = 1.35; // same constant as ridego_resolve_route_distance()'s live fallback
    $avg_speed_kmph = 45;   // same constant as ridego_resolve_route_distance()'s live fallback

    $make_row = function ( $from, $to, $popular ) use ( $road_factor, $avg_speed_kmph ) {
        $straight_line = ridego_haversine_km( (float) $from->lat, (float) $from->lng, (float) $to->lat, (float) $to->lng );
        $distance_km   = round( $straight_line * $road_factor, 1 );
        return array(
            'from_city_id'        => (int) $from->id,
            'to_city_id'          => (int) $to->id,
            'from_city'           => $from->name,
            'to_city'             => $to->name,
            'distance_km'         => $distance_km,
            'duration_mins'       => (int) round( ( $distance_km / $avg_speed_kmph ) * 60 ),
            'toll_estimate'       => null,
            'default_fixed_price' => null, // no fixed price seeded — real per-vehicle/km pricing rules (ridego_calculate_fare) apply, same as any unrouted pair today
            'is_popular'          => $popular ? 1 : 0,
            'is_active'           => 1,
            'created_at'          => current_time( 'mysql' ),
        );
    };

    foreach ( $priority_pairs as $p ) {
        if ( ! isset( $by_name[ $p[0] ] ) || ! isset( $by_name[ $p[1] ] ) ) { continue; }
        $from = $by_name[ $p[0] ];
        $to   = $by_name[ $p[1] ];
        if ( (int) $from->id === (int) $to->id ) { continue; }
        $key = min( $from->id, $to->id ) . '|' . max( $from->id, $to->id );
        if ( isset( $seeded_pairs[ $key ] ) ) { continue; }
        $seeded_pairs[ $key ] = true;
        $rows[]                = $make_row( $from, $to, true );
    }

    /* Every remaining valid origin -> destination pair, nearest-first,
       capped so this stays a curated ~450-row set rather than every
       mathematically possible combination (which would run into the
       thousands once every origin is crossed with every destination). */
    $candidates = array();
    foreach ( $origins as $o ) {
        foreach ( $dests as $d ) {
            if ( (int) $o->id === (int) $d->id ) { continue; }
            $key = min( $o->id, $d->id ) . '|' . max( $o->id, $d->id );
            if ( isset( $seeded_pairs[ $key ] ) ) { continue; }
            $candidates[] = array(
                'from' => $o,
                'to'   => $d,
                'dist' => ridego_haversine_km( (float) $o->lat, (float) $o->lng, (float) $d->lat, (float) $d->lng ),
            );
        }
    }
    usort( $candidates, function ( $a, $b ) { return $a['dist'] <=> $b['dist']; } );

    $cap = 450 - count( $rows );
    foreach ( $candidates as $cand ) {
        if ( $cap <= 0 ) { break; }
        $key = min( $cand['from']->id, $cand['to']->id ) . '|' . max( $cand['from']->id, $cand['to']->id );
        if ( isset( $seeded_pairs[ $key ] ) ) { continue; } // usort over an array that can contain the same unordered pair twice (once from each origin/destination direction) if a city is both — already-seeded guard, not just a dedupe-on-build one
        $seeded_pairs[ $key ] = true;
        $rows[]                = $make_row( $cand['from'], $cand['to'], false );
        $cap--;
    }

    foreach ( $rows as $row ) {
        $wpdb->insert( $rtbl, $row );
    }
}
