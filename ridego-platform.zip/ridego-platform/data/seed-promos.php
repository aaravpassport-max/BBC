<?php
if(!defined("ABSPATH")){exit;}
function ridego_seed_promos(){}
