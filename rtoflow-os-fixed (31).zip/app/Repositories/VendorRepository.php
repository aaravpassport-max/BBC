<?php
namespace RTOFLOW\Repositories;
// Loaded via Repositories.php combined file
if (!class_exists('RTOFLOW\\Repositories\\VendorRepository', false)) {
    require_once __DIR__ . '/Repositories.php';
}
