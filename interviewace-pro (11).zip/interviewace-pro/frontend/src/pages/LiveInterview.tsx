import { useCallback, useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { interviewsApi } from '@/api/interviews';
import { speechApi } from '@/api/speech';
import { config } from '@/api/client';
import { ErrorBlock } from '@/components/StateViews';
import type { ApiError, InterviewQuestion } from '@/types';

interface ChatTurn { turnNumber: number; role: 'ai' | 'user'; text: string }
interface LocationState { openingLine?: string; plan?: InterviewQuestion[]; maxMinutes?: number }

type VoiceState = 'idle' | 'speaking' | 'listening' | 'transcribing' | 'thinking';

/**
 * RESTORED (reported: "check the interview screen too" — confirmed by
 * comparing the user's original pre-rebuild build's bundled strings
 * against this file): this screen used to be an actual voice
 * conversation with Priya — her lines played aloud (ElevenLabs TTS),
 * then the mic auto-armed so you just spoke your answer (Deepgram STT),
 * matching what this plugin has always billed itself as ("AI-powered
 * voice interview platform" — see interviewace.php's own plugin
 * description) and what its Priya-avatar branding throughout the admin
 * settings page assumes. The rebuild after the onboarding-loop fix
 * replaced this with a plain typed chat box plus a manual
 * record-then-edit-then-send button — technically functional, but not
 * the voice interview the rest of the product is built around.
 *
 * The backend for this was NEVER touched or lost — api/class-api-
 * speech.php's /speech/stt and /speech/tts-token routes are exactly what
 * a voice flow needs and already existed. Restoring here is purely a
 * frontend wiring job: play each AI turn's audio, then auto-start
 * listening, then auto-submit once the user stops speaking.
 *
 * Two honest constraints kept in mind rather than overclaimed:
 *  1) Deepgram is called here as a single prerecorded clip per answer
 *     (record → stop → transcribe), not a live streaming transcript —
 *     the backend only exposes the prerecorded /speech/stt endpoint.
 *     "Speak now" is shown while recording; the transcript appears once
 *     the user stops.
 *  2) Browsers block audio autoplay before a user gesture, so a
 *     one-tap "Before you begin" screen is required regardless — it
 *     doubles as a mic-permission and quiet-room prompt, matching the
 *     original's "Find a quiet spot with a good microphone" copy.
 *  3) If Deepgram/ElevenLabs aren't configured (ia_cfg error from the
 *     backend) or the browser denies mic access, this falls back to the
 *     typed chat box that already existed — a broken voice flow must
 *     never be a dead end, per the app's own error-handling standard
 *     elsewhere (see StateViews.tsx).
 */
export default function LiveInterview() {
  const { id } = useParams<{ id: string }>();
  const interviewId = Number(id);
  const location = useLocation();
  const nav = useNavigate();
  const state = (location.state as LocationState) || {};

  const [turns, setTurns] = useState<ChatTurn[]>(
    state.openingLine ? [{ turnNumber: 0, role: 'ai', text: state.openingLine }] : []
  );
  const [draft, setDraft] = useState('');
  const [pendingTurnNumber, setPendingTurnNumber] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);
  const [ending, setEnding] = useState(false);
  const [complete, setComplete] = useState(false);
  const [recording, setRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const nextTurnNumber = useRef(1);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const listEndRef = useRef<HTMLDivElement | null>(null);

  const maxMinutes = state.maxMinutes ?? 60;

  /* ── Voice mode state ── */
  const [started, setStarted] = useState(false);
  const [voiceMode, setVoiceMode] = useState(true); // falls back to false on config/permission failure
  const [voiceState, setVoiceState] = useState<VoiceState>('idle');
  const [voiceUnavailable, setVoiceUnavailable] = useState<string | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const voiceModeRef = useRef(true);
  useEffect(() => { voiceModeRef.current = voiceMode; }, [voiceMode]);

  useEffect(() => {
    interviewsApi.start(interviewId).catch(() => {
      // Non-fatal: start() is idempotent server-side (returns success if
      // already active) — a failure here just means the first turn submit
      // will surface any real problem instead.
    });
  }, [interviewId]);

  useEffect(() => {
    listEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [turns]);

  /** Plays `text` as Priya's voice. Resolves once playback finishes (or immediately if voice mode is off/unavailable). */
  const speak = useCallback(async (text: string): Promise<void> => {
    if (!voiceModeRef.current) return;
    setVoiceState('speaking');
    try {
      const r = await speechApi.synthesize(text, interviewId);
      const blob = await (await fetch(`data:${r.mime};base64,${r.audio_base64}`)).blob();
      const url = URL.createObjectURL(blob);
      await new Promise<void>((resolve) => {
        const audio = new Audio(url);
        audioRef.current = audio;
        audio.onended = () => { URL.revokeObjectURL(url); resolve(); };
        audio.onerror = () => { URL.revokeObjectURL(url); resolve(); };
        void audio.play().catch(() => resolve());
      });
    } catch (err) {
      // Voice synthesis not configured or failed — fall back to silent/text mode
      // rather than blocking the interview on a voice feature.
      const apiErr = err as ApiError;
      if (apiErr?.code === 'ia_cfg') {
        setVoiceMode(false);
        setVoiceUnavailable('Voice is not set up on this site yet — continuing with text. (Missing ElevenLabs/Deepgram API key in admin settings.)');
      }
    } finally {
      setVoiceState('idle');
    }
  }, [interviewId]);

  /** Auto-arms the mic and records until the user taps "Done speaking" or `stopListening` is called. */
  const startListening = useCallback(async () => {
    if (!voiceModeRef.current) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      chunksRef.current = [];
      mr.ondataavailable = (e) => chunksRef.current.push(e.data);
      mr.start();
      mediaRecorderRef.current = mr;
      setRecording(true);
      setVoiceState('listening');
      // Stream tracks are stopped in stopListening() once recording ends.
      mr.addEventListener('stop', () => {
        stream.getTracks().forEach((t) => t.stop());
      });
    } catch {
      setVoiceMode(false);
      setVoiceUnavailable('Microphone access was denied — continuing with text. You can allow it in your browser settings and reload to try voice again.');
      setVoiceState('idle');
    }
  }, []);

  const stopListeningAndTranscribe = useCallback(async () => {
    const mr = mediaRecorderRef.current;
    if (!mr || mr.state === 'inactive') return;
    setVoiceState('transcribing');
    setTranscribing(true);
    await new Promise<void>((resolve) => {
      mr.addEventListener('stop', () => resolve(), { once: true });
      mr.stop();
    });
    setRecording(false);
    try {
      const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
      const r = await speechApi.transcribe(blob, interviewId);
      if (r.transcript.trim()) {
        setDraft(r.transcript);
        // Auto-submit the spoken answer — the whole point of voice mode is
        // not needing a manual "Send" tap after speaking.
        const turnNumber = pendingTurnNumber ?? nextTurnNumber.current;
        setPendingTurnNumber(turnNumber);
        await submitTurnRef.current(r.transcript, turnNumber);
      } else {
        setError({ code: 'ia_no_speech', message: "Didn't catch that — please try speaking again, or type your answer below.", status: 0, retryable: false });
      }
    } catch (err) {
      const apiErr = err as ApiError;
      if (apiErr?.code === 'ia_cfg') {
        setVoiceMode(false);
        setVoiceUnavailable('Voice is not set up on this site yet — continuing with text. (Missing Deepgram API key in admin settings.)');
      } else {
        setError(apiErr);
      }
    } finally {
      setTranscribing(false);
      setVoiceState('idle');
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [interviewId, pendingTurnNumber]);

  const submitTurn = useCallback(
    async (transcript: string, turnNumber: number) => {
      setSubmitting(true);
      setError(null);
      try {
        const r = await interviewsApi.submitTurn(interviewId, { transcript, turn_number: turnNumber });
        setTurns((prev) => [
          ...prev,
          { turnNumber, role: 'user', text: transcript },
          { turnNumber: turnNumber + 1, role: 'ai', text: r.ai_response },
        ]);
        setPendingTurnNumber(null);
        setDraft('');
        nextTurnNumber.current = turnNumber + 2;
        if (r.is_complete) {
          setComplete(true);
          void interviewsApi.reportCost(interviewId, {});
          if (r.report_id) {
            nav(`/report/${r.report_id}`, { replace: true });
          }
          return;
        }
        // Voice mode: speak the new AI turn, then auto-listen for the reply.
        if (voiceModeRef.current) {
          await speak(r.ai_response);
          if (voiceModeRef.current) void startListening();
        }
      } catch (err) {
        // Deliberately keep `draft`/pendingTurnNumber intact on failure —
        // the whole point of the idempotency fix is that retrying with the
        // SAME turn number and text is always safe, so we never discard
        // what the user just said.
        setError(err as ApiError);
      } finally {
        setSubmitting(false);
      }
    },
    [interviewId, nav, speak, startListening]
  );

  // submitTurn is defined after stopListeningAndTranscribe needs to call it —
  // a ref sidesteps the circular dependency without restructuring both into one function.
  const submitTurnRef = useRef(submitTurn);
  useEffect(() => { submitTurnRef.current = submitTurn; }, [submitTurn]);

  function onSend() {
    const text = draft.trim();
    if (!text || submitting) return;
    const turnNumber = pendingTurnNumber ?? nextTurnNumber.current;
    setPendingTurnNumber(turnNumber);
    void submitTurn(text, turnNumber);
  }

  function onRetry() {
    if (pendingTurnNumber == null) return;
    void submitTurn(draft.trim(), pendingTurnNumber);
  }

  async function onEndEarly() {
    if (!window.confirm('End this interview now? You can still view your report for what you’ve completed so far.')) return;
    audioRef.current?.pause();
    if (mediaRecorderRef.current?.state === 'recording') mediaRecorderRef.current.stop();
    setEnding(true);
    try {
      const r = await interviewsApi.end(interviewId);
      nav(`/report/${r.report_id}`, { replace: true });
    } catch (err) {
      setError(err as ApiError);
      setEnding(false);
    }
  }

  /** Manual record button — used when voice mode is off, or as an explicit re-record in voice mode. */
  async function toggleRecording() {
    if (recording) {
      await stopListeningAndTranscribe();
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      chunksRef.current = [];
      mr.ondataavailable = (e) => chunksRef.current.push(e.data);
      mr.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setTranscribing(true);
        try {
          const r = await speechApi.transcribe(blob, interviewId);
          setDraft((prev) => (prev ? `${prev} ${r.transcript}` : r.transcript));
        } catch (err) {
          setError(err as ApiError);
        } finally {
          setTranscribing(false);
        }
      };
      mr.start();
      mediaRecorderRef.current = mr;
      setRecording(true);
    } catch {
      setError({ code: 'ia_mic', message: 'Microphone access was denied. You can still type your answer below.', status: 0, retryable: false });
    }
  }

  /** "Before you begin" gate — required to satisfy browser autoplay policy for Priya's opening line, and doubles as the mic/quiet-room prompt. */
  async function onBeginVoice() {
    setStarted(true);
    if (state.openingLine) {
      await speak(state.openingLine);
      if (voiceModeRef.current) void startListening();
    }
  }

  function onBeginTextOnly() {
    setStarted(true);
    setVoiceMode(false);
  }

  if (!interviewId) return <ErrorBlock error={{ code: 'ia_bad_route', message: 'Invalid interview.', status: 400, retryable: false }} />;

  if (!started) {
    return (
      <div className="ia-page" style={{ textAlign: 'center', paddingTop: 'var(--ia-space-8)' }}>
        <img
          src={config.priyaAvatarUrl}
          alt="Priya, AI HR Recruiter"
          style={{ width: 120, height: 120, borderRadius: '50%', objectFit: 'cover', margin: '0 auto var(--ia-space-4)' }}
        />
        <h1>Before you begin</h1>
        <p style={{ color: 'var(--ia-text-secondary)', marginBottom: 'var(--ia-space-5)' }}>
          Find a quiet spot with a good microphone. Priya will greet you, then the mic activates automatically —
          just speak your answers naturally.
        </p>
        <button className="ia-btn ia-btn-primary ia-btn-block" onClick={() => void onBeginVoice()} style={{ marginBottom: 'var(--ia-space-3)' }}>
          🔊 Hear Priya &amp; Start
        </button>
        <button className="ia-btn ia-btn-ghost ia-btn-block" onClick={onBeginTextOnly}>
          Skip voice — type my answers instead
        </button>
      </div>
    );
  }

  return (
    <div className="ia-page-wide" style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <header className="ia-topbar">
        <strong>Live interview</strong>
        <div style={{ display: 'flex', gap: 'var(--ia-space-3)', alignItems: 'center' }}>
          <span className="ia-badge ia-badge-info">Up to {maxMinutes} min</span>
          <button className="ia-btn ia-btn-ghost" onClick={() => void onEndEarly()} disabled={ending || complete}>
            {ending ? 'Ending…' : 'End interview'}
          </button>
        </div>
      </header>

      {voiceUnavailable && (
        <div className="ia-state ia-state-error" style={{ margin: 'var(--ia-space-3) 0', padding: 'var(--ia-space-3)' }}>
          <p style={{ margin: 0 }}>{voiceUnavailable}</p>
        </div>
      )}

      <div style={{ flex: 1, overflowY: 'auto', padding: 'var(--ia-space-4) 0' }}>
        {turns.map((t) => (
          <div
            key={`${t.turnNumber}-${t.role}`}
            style={{
              display: 'flex',
              justifyContent: t.role === 'ai' ? 'flex-start' : 'flex-end',
              marginBottom: 'var(--ia-space-3)',
            }}
          >
            <div
              className="ia-card"
              style={{
                maxWidth: '75%',
                padding: 'var(--ia-space-3) var(--ia-space-4)',
                background: t.role === 'ai' ? 'var(--ia-bg-elevated)' : 'var(--ia-accent-bg)',
              }}
            >
              {t.role === 'ai' && <div className="ia-state-hint" style={{ marginBottom: 4 }}>Priya (AI Interviewer)</div>}
              <p style={{ margin: 0 }}>{t.text}</p>
            </div>
          </div>
        ))}

        {voiceMode && voiceState === 'speaking' && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--ia-space-2)', color: 'var(--ia-text-secondary)' }} role="status" aria-live="polite">
            <span className="ia-spinner" style={{ width: 18, height: 18, borderWidth: 2 }} />
            <span>Priya is speaking…</span>
          </div>
        )}
        {voiceMode && voiceState === 'listening' && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--ia-space-2)', color: 'var(--ia-accent)' }} role="status" aria-live="polite">
            <span>🎤 Listening… speak your answer</span>
          </div>
        )}
        {voiceMode && voiceState === 'transcribing' && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--ia-space-2)', color: 'var(--ia-text-secondary)' }} role="status" aria-live="polite">
            <span className="ia-spinner" style={{ width: 18, height: 18, borderWidth: 2 }} />
            <span>Processing your response…</span>
          </div>
        )}
        {submitting && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--ia-space-2)', color: 'var(--ia-text-secondary)' }} role="status" aria-live="polite">
            <span className="ia-spinner" style={{ width: 18, height: 18, borderWidth: 2 }} />
            <span>Priya is thinking…</span>
          </div>
        )}

        {error && (
          <div style={{ margin: 'var(--ia-space-3) 0' }}>
            <ErrorBlock error={error} onRetry={pendingTurnNumber != null ? onRetry : undefined} />
          </div>
        )}

        <div ref={listEndRef} />
      </div>

      {!complete && (
        <div style={{ borderTop: '1px solid var(--ia-border)', paddingTop: 'var(--ia-space-4)' }}>
          {voiceMode && recording && (
            <div style={{ textAlign: 'center', marginBottom: 'var(--ia-space-3)' }}>
              <button className="ia-btn ia-btn-danger ia-btn-block" onClick={() => void stopListeningAndTranscribe()} disabled={transcribing}>
                {transcribing ? 'Processing…' : '● Done speaking'}
              </button>
              <p className="ia-state-hint" style={{ marginTop: 'var(--ia-space-2)' }}>Speak now — tap "Done speaking" when you're finished.</p>
            </div>
          )}

          <div className="ia-field">
            <textarea
              className="ia-input"
              rows={3}
              placeholder="Type your answer, or use the mic…"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              disabled={submitting}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); onSend(); }
              }}
            />
          </div>
          <div style={{ display: 'flex', gap: 'var(--ia-space-3)' }}>
            <button
              className={`ia-btn ${recording ? 'ia-btn-danger' : 'ia-btn-secondary'}`}
              onClick={() => void toggleRecording()}
              disabled={submitting || transcribing}
              aria-pressed={recording}
              aria-label={recording ? 'Stop recording' : 'Record your answer'}
            >
              {transcribing ? 'Transcribing…' : recording ? '● Stop' : '🎤 Record'}
            </button>
            <button className="ia-btn ia-btn-primary" style={{ flex: 1 }} onClick={onSend} disabled={submitting || !draft.trim()}>
              {submitting ? 'Sending…' : 'Send answer'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
