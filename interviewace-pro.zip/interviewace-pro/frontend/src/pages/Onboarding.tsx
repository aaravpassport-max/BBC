import { useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { profileApi } from '@/api/profile';
import { useAuth } from '@/context/AuthContext';
import { ErrorBlock } from '@/components/StateViews';
import type { ApiError } from '@/types';

const STEPS = ['role', 'resume', 'jd'] as const;
type Step = (typeof STEPS)[number];

/**
 * Onboarding was listed as a known gap in the first build (no screens
 * existed at all). Kept deliberately skippable at every step — resume/JD
 * are optional inputs the backend already treats as optional
 * (IA_Claude::generate_plan falls back to a default question set, and
 * class-api-profile.php's parse_jd/resume upload never block interview
 * creation) — the UI should never force a user through steps the backend
 * doesn't actually require.
 */
export default function Onboarding() {
  const nav = useNavigate();
  const { refreshUser } = useAuth();
  const [step, setStep] = useState<Step>('role');
  const [targetRole, setTargetRole] = useState('');
  const [currentRole, setCurrentRole] = useState('');
  const [resumeFile, setResumeFile] = useState<File | null>(null);
  const [jdText, setJdText] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);

  function goNext() {
    const idx = STEPS.indexOf(step);
    if (idx < STEPS.length - 1) setStep(STEPS[idx + 1]);
    else finish();
  }

  async function onRoleSubmit(e: FormEvent) {
    e.preventDefault();
    setError(null);
    if (!targetRole.trim()) { goNext(); return; }
    setSubmitting(true);
    try {
      await profileApi.update({ target_role: targetRole, current_role: currentRole || undefined });
      goNext();
    } catch (err) {
      setError(err as ApiError);
    } finally {
      setSubmitting(false);
    }
  }

  async function onResumeSubmit() {
    setError(null);
    if (!resumeFile) { goNext(); return; }
    setSubmitting(true);
    try {
      await profileApi.uploadResume(resumeFile);
      goNext();
    } catch (err) {
      setError(err as ApiError);
    } finally {
      setSubmitting(false);
    }
  }

  async function onJdSubmit() {
    setError(null);
    if (jdText.trim().length < 50) { finish(); return; }
    setSubmitting(true);
    try {
      await profileApi.parseJd(jdText);
      finish();
    } catch (err) {
      setError(err as ApiError);
    } finally {
      setSubmitting(false);
    }
  }

  async function finish() {
    /*
     * ROOT-CAUSE FIX: this used to just refresh and navigate away, relying
     * on the target_role step to have already flipped onboarding_complete
     * server-side as a side effect. But every step here is deliberately
     * skippable (including the role step) — a user who skipped all three
     * would reach /dashboard with onboarding_complete still false, and
     * ProtectedRoute.tsx immediately bounces anyone in that state straight
     * back to /onboarding, on every protected route. That trapped a user
     * who used the "skip everything" path with no way to ever leave this
     * screen. Explicitly marking onboarding complete here, unconditionally,
     * closes that gap regardless of which steps were actually filled in.
     */
    try {
      await profileApi.update({ onboarding_complete: true });
    } catch {
      // Non-fatal: refreshUser() below will reflect whatever the server
      // actually has, and the user can still reach settings to fix things.
    }
    await refreshUser();
    nav('/dashboard', { replace: true });
  }

  const stepIndex = STEPS.indexOf(step);

  return (
    <div className="ia-page">
      <div style={{ display: 'flex', gap: 'var(--ia-space-1)', marginBottom: 'var(--ia-space-6)' }} aria-label={`Step ${stepIndex + 1} of ${STEPS.length}`}>
        {STEPS.map((s, i) => (
          <div key={s} style={{ flex: 1, height: 4, borderRadius: 2, background: i <= stepIndex ? 'var(--ia-accent)' : 'var(--ia-border)' }} />
        ))}
      </div>

      {error && <div style={{ marginBottom: 'var(--ia-space-4)' }}><ErrorBlock error={error} /></div>}

      {step === 'role' && (
        <form onSubmit={onRoleSubmit}>
          <h1>What role are you targeting?</h1>
          <p style={{ color: 'var(--ia-text-secondary)', marginBottom: 'var(--ia-space-5)' }}>This helps us tailor your interview questions.</p>
          <div className="ia-field">
            <label htmlFor="target">Target role</label>
            <input id="target" className="ia-input" placeholder="e.g. Senior Backend Engineer" value={targetRole} onChange={(e) => setTargetRole(e.target.value)} />
          </div>
          <div className="ia-field">
            <label htmlFor="current">Current role (optional)</label>
            <input id="current" className="ia-input" value={currentRole} onChange={(e) => setCurrentRole(e.target.value)} />
          </div>
          <button className="ia-btn ia-btn-primary ia-btn-block" type="submit" disabled={submitting}>Continue</button>
        </form>
      )}

      {step === 'resume' && (
        <div>
          <h1>Upload your resume</h1>
          <p style={{ color: 'var(--ia-text-secondary)', marginBottom: 'var(--ia-space-5)' }}>
            Optional, but helps the AI ask more relevant questions. PDF or DOCX, up to 5MB.
          </p>
          <div className="ia-field">
            <input
              type="file"
              accept=".pdf,.docx"
              className="ia-input"
              onChange={(e) => setResumeFile(e.target.files?.[0] ?? null)}
            />
          </div>
          <div style={{ display: 'flex', gap: 'var(--ia-space-3)' }}>
            <button className="ia-btn ia-btn-ghost" onClick={() => setStep('jd')} disabled={submitting}>Skip</button>
            <button className="ia-btn ia-btn-primary" style={{ flex: 1 }} onClick={() => void onResumeSubmit()} disabled={submitting}>
              {submitting ? 'Uploading…' : 'Continue'}
            </button>
          </div>
        </div>
      )}

      {step === 'jd' && (
        <div>
          <h1>Got a job description?</h1>
          <p style={{ color: 'var(--ia-text-secondary)', marginBottom: 'var(--ia-space-5)' }}>
            Optional — paste one to focus your practice on the exact skills it asks for.
          </p>
          <div className="ia-field">
            <textarea className="ia-input" rows={8} value={jdText} onChange={(e) => setJdText(e.target.value)} />
          </div>
          <div style={{ display: 'flex', gap: 'var(--ia-space-3)' }}>
            <button className="ia-btn ia-btn-ghost" onClick={() => void finish()} disabled={submitting}>Skip</button>
            <button className="ia-btn ia-btn-primary" style={{ flex: 1 }} onClick={() => void onJdSubmit()} disabled={submitting}>
              {submitting ? 'Saving…' : 'Finish'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
