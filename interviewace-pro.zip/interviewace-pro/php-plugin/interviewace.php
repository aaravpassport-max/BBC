<?php
/**
 * Plugin Name: InterviewAce
 * Plugin URI:  https://interviewace.in
 * Description: AI-powered voice interview platform — serves from root domain.
 * Version:     3.0.0
 * Author:      InterviewAce
 * License:     Proprietary
 * Text Domain: interviewace
 */
defined('ABSPATH') || exit;

define('IA_VERSION', '3.0.0');
define('IA_MIN_PHP',  '7.4');
define('IA_MIN_WP',   '6.0');
define('IA_MIN_MYSQL','5.7');
define('IA_DIR',     plugin_dir_path(__FILE__));
define('IA_URL',     plugin_dir_url(__FILE__));
define('IA_DB_VER',  '3.0.0'); // bumped: ia_turns unique-key migration + new cron schedules

/* ── Key reader: options DB first, wp-config constants as override ── */
/* ── Environment compatibility gate ── */
function ia_check_requirements(): bool {
    if (version_compare(PHP_VERSION, IA_MIN_PHP, '<')) {
        add_action('admin_notices', function() {
            printf('<div class="notice notice-error"><p><strong>InterviewAce</strong> requires PHP %s or higher. Current: %s</p></div>',
                IA_MIN_PHP, PHP_VERSION);
        });
        return false;
    }
    global $wp_version;
    if (version_compare($wp_version, IA_MIN_WP, '<')) {
        add_action('admin_notices', function() use ($wp_version) {
            printf('<div class="notice notice-error"><p><strong>InterviewAce</strong> requires WordPress %s or higher. Current: %s</p></div>',
                IA_MIN_WP, $wp_version);
        });
        return false;
    }
    return true;
}

function ia_key(string $name, string $default=''): string {
    // Check PHP constant first (e.g. define('IA_DEEPGRAM_KEY','dg-xxx') in wp-config.php)
    if (defined($name) && constant($name)!=='') return constant($name);
    // Convert constant name to option key: IA_DEEPGRAM_KEY → ia_deepgram_key
    $opt_key = strtolower($name);                          // ia_deepgram_key
    $v = get_option($opt_key, $default);                   // reads ia_deepgram_key directly
    return is_string($v) ? trim($v) : $default;
}
function ia_jwt_secret(): string {
    if (defined('IA_JWT_SECRET') && IA_JWT_SECRET!=='') return IA_JWT_SECRET;
    $s = get_option('ia_jwt_secret');
    if (!$s) { $s=bin2hex(random_bytes(32)); update_option('ia_jwt_secret',$s,false); }
    return $s;
}

/* ── Load all classes ── */
foreach ([
    'includes/class-jwt.php',
    'includes/class-auth-middleware.php',
    'includes/class-plan-enforcer.php',
    'includes/class-claude.php',
    'includes/class-activator.php',
    'includes/class-deactivator.php',
    'api/class-api-auth.php',
    'api/class-api-profile.php',
    'api/class-api-resume.php',
    'api/class-api-interviews.php',
    'api/class-api-reports.php',
    'api/class-api-billing.php',
    'api/class-api-history.php',
    'cron/class-report-generator.php',
    'cron/class-cron-manager.php',
    'admin/class-settings-page.php',
    'admin/class-cost-dashboard.php',
    'includes/class-pdf-report.php',
    'includes/class-cost-tracker.php',
    'api/class-api-gamification.php',
    'api/class-api-ats.php',
    'api/class-api-speech.php',
] as $f) require_once IA_DIR.$f;

register_activation_hook(__FILE__,   ['IA_Activator',   'activate']);
register_deactivation_hook(__FILE__, ['IA_Deactivator', 'deactivate']);

/* Must be registered before activation/scheduling ever runs, and on every
   load (not just plugins_loaded's closure) since WP-Cron itself fires
   outside the normal request lifecycle wp_schedule_event was called from. */
add_filter('cron_schedules', ['IA_Cron_Manager', 'register_schedules']);

add_action('plugins_loaded', function() {
    if (!ia_check_requirements()) return;

    /* Idempotent DB/schema migration check — runs on every load, not just
       activation, so a plugin update (not a fresh activate) still picks up
       schema changes like the ia_turns unique-key fix without requiring the
       site admin to manually deactivate/reactivate. */
    if (get_option('ia_db_version') !== IA_DB_VER) {
        IA_Activator::activate();
    }

    /*
     * ROOT-CAUSE FIX: this must run here, directly inside plugins_loaded,
     * NOT from inside the rest_api_init callback further down. `init`
     * fires once, well before `rest_api_init` does on every request — an
     * add_action('init', ...) issued from inside a rest_api_init handler
     * registers a callback for a hook that has already finished firing
     * on that same request, so it would never execute. Binding it here
     * (plugins_loaded runs before init) ensures the raw PDF-download
     * endpoint actually fires. See IA_PDF_Report::bind_download_handler().
     */
    IA_PDF_Report::bind_download_handler();

    /* ── Rewrite: serve root domain → same template ── */
    add_action('init', function() {
        /* Catch everything EXCEPT wp-admin, wp-json, wp-login, wp-content */
        add_rewrite_rule(
            '^(?!wp-admin|wp-json|wp-login|wp-content|wp-cron|xmlrpc)(.*)$',
            'index.php?pagename=interviewace-root',
            'top'
        );
    });

    /* ── Template override ── */
    add_filter('template_include', function($tpl) {
        global $post;
        if ($post) {
            $map = [
                'ia-home'    => 'home.php',
                'ia-pricing' => 'pricing.php',
                'ia-about'   => 'about.php',
                'ia-privacy' => 'privacy.php',
                'ia-terms'   => 'terms.php',
            ];
            if (isset($map[$post->post_name])) {
                $tmpl = IA_DIR.'templates/public/'.$map[$post->post_name];
                if (file_exists($tmpl)) return $tmpl;
            }
        }
        if (ia_is_root_app()) return IA_DIR.'templates/app-page.php';
        return $tpl;
    });

    /* ── Assets ── */
    add_action('wp_enqueue_scripts', function() {
        if (!ia_is_root_app()) return;
        wp_enqueue_script('ia-app', IA_URL.'react-app/dist/app.js', [], IA_VERSION, true);
        wp_enqueue_style('ia-app',  IA_URL.'react-app/dist/app.css', [], IA_VERSION);
        wp_localize_script('ia-app', 'IA_CONFIG', [
            'apiBase'         => esc_url(rest_url('ia/v1')),
            'siteUrl'         => esc_url(get_site_url()),
            /*
             * SECURITY FIX: Deepgram/ElevenLabs secret API keys used to be
             * sent to every visitor's browser here, unauthenticated, before
             * login — view-source was enough to lift and reuse them against
             * the site owner's paid quota. They are no longer localized at
             * all. The frontend now calls authenticated proxy endpoints
             * (/ia/v1/speech/stt, /ia/v1/speech/tts-token — see
             * api/class-api-speech.php) which hold the real keys server-side
             * and are rate-limited per user via IA_Plan_Enforcer.
             * Razorpay's key ID is a publishable/public-by-design key
             * (not a secret) and is correctly still exposed here.
             */
            'elevenLabsVoice' => get_option('ia_elevenlabs_voice','EXAVITQu4vr4xnSDxMaL'),
            'razorpayKeyId'   => get_option('ia_razorpay_key_id',''),
            'googleClientId'  => get_option('ia_google_client_id',''),
            'version'         => IA_VERSION,
            'assetsUrl'       => esc_url(IA_URL.'assets/'),
            'priyaAvatarUrl'  => esc_url(get_option('ia_priya_avatar_url', IA_URL.'assets/priya-photo.jpg')),
            'plans'           => [
                'pro'     => [
                    'display_name'  => IA_Settings_Page::get_plan_config('pro')['display_name']  ?? 'Pro',
                    'badge_label'   => IA_Settings_Page::get_plan_config('pro')['badge_label']   ?? '⭐ Pro',
                    'price_display' => IA_Settings_Page::get_plan_config('pro')['price_display'] ?? '₹299',
                    'price_period'  => IA_Settings_Page::get_plan_config('pro')['price_period']  ?? '/month',
                    'highlight'     => (bool)(IA_Settings_Page::get_plan_config('pro')['highlight'] ?? false),
                    'ribbon_text'   => IA_Settings_Page::get_plan_config('pro')['ribbon_text']   ?? '',
                    'features'      => array_values(array_filter(array_map('trim',
                        explode("\n", IA_Settings_Page::get_plan_config('pro')['features'] ?? '')))),
                    'session_minutes' => IA_Plan_Enforcer::quota('pro_session_minutes'),
                    'monthly_minutes' => IA_Plan_Enforcer::quota('pro_monthly_minutes'),
                ],
                'premium' => [
                    'display_name'  => IA_Settings_Page::get_plan_config('premium')['display_name']  ?? 'Premium',
                    'badge_label'   => IA_Settings_Page::get_plan_config('premium')['badge_label']   ?? '💎 Premium',
                    'price_display' => IA_Settings_Page::get_plan_config('premium')['price_display'] ?? '₹599',
                    'price_period'  => IA_Settings_Page::get_plan_config('premium')['price_period']  ?? '/month',
                    'highlight'     => (bool)(IA_Settings_Page::get_plan_config('premium')['highlight'] ?? true),
                    'ribbon_text'   => IA_Settings_Page::get_plan_config('premium')['ribbon_text']   ?? 'Best value',
                    'features'      => array_values(array_filter(array_map('trim',
                        explode("\n", IA_Settings_Page::get_plan_config('premium')['features'] ?? '')))),
                    'session_minutes' => IA_Plan_Enforcer::quota('premium_session_minutes'),
                    'monthly_minutes' => IA_Plan_Enforcer::quota('premium_monthly_minutes'),
                ],
            ],
        ]);
    });

    /* ── REST API ── */
    add_action('rest_api_init', function() {
        /*
         * SECURITY FIX: /health used to be public and disclosed exactly
         * which paid integrations are configured — free reconnaissance for
         * anyone probing the site. Now returns only a bare liveness signal
         * to unauthenticated callers (useful for uptime monitors) and the
         * full integration-status breakdown only to a logged-in admin.
         */
        register_rest_route('ia/v1','/health',[
            'methods'=>'GET',
            'callback'=>function(){
                $body = ['status'=>'ok','version'=>IA_VERSION];
                if (current_user_can('manage_options')) {
                    $body['keys'] = [
                        'claude'    =>ia_key('IA_CLAUDE_KEY')!=='',
                        'deepgram'  =>ia_key('IA_DEEPGRAM_KEY')!=='',
                        'elevenlabs'=>ia_key('IA_ELEVENLABS_KEY')!=='',
                        'razorpay'  =>ia_key('IA_RAZORPAY_KEY_ID')!=='',
                    ];
                }
                return new WP_REST_Response($body);
            },
            'permission_callback'=>'__return_true',
        ]);
        IA_API_Auth::register();
        IA_API_Profile::register();
        IA_API_Resume::register();
        IA_API_Interviews::register();
        IA_API_Reports::register();
        IA_API_Billing::register();
        IA_API_History::register();
        IA_API_Gamification::register();
        IA_API_ATS::register();
        IA_PDF_Report::register();
        IA_API_Speech::register();
    });

    /*
     * SECURITY FIX: CORS used to be `Access-Control-Allow-Origin: *`
     * combined with `Authorization` in the allowed headers — any website
     * could attempt authenticated cross-origin calls against this API from
     * a visitor's browser. This app is architected to run only from its own
     * root domain (that's the entire point of the catch-all rewrite in
     * ia_is_root_app()), so there is no legitimate cross-origin caller.
     * Origin is now allow-listed to the site's own URL, plus any admin-
     * configured extra origins (e.g. a staging subdomain) via the
     * `ia_cors_allowed_origins` option — never a wildcard.
     */
    add_action('rest_api_init', function() {
        remove_filter('rest_pre_serve_request','rest_send_cors_headers');
        add_filter('rest_pre_serve_request', function($s) {
            $allowed = array_filter(array_unique(array_merge(
                [get_site_url(), home_url()],
                (array) get_option('ia_cors_allowed_origins', [])
            )));
            $origin = $_SERVER['HTTP_ORIGIN'] ?? '';
            if ($origin && in_array(untrailingslashit($origin), array_map('untrailingslashit', $allowed), true)) {
                header('Access-Control-Allow-Origin: ' . $origin);
                header('Vary: Origin');
            }
            header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
            header('Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce');
            header('Access-Control-Allow-Credentials: true');
            if ($_SERVER['REQUEST_METHOD']==='OPTIONS'){status_header(200);exit;}
            return $s;
        });
    },15);

    IA_Cron_Manager::register_hooks();

    /* ── Admin bar link ── */
    add_action('admin_bar_menu', function($bar) {
        $bar->add_node(['id'=>'ia-open-app','title'=>'🎤 InterviewAce','href'=>home_url('/'),'meta'=>['target'=>'_blank']]);
    },999);

    IA_Settings_Page::init();
    IA_Cost_Dashboard::init();
});

/* ── Page detection: everything that isn't WP-core ── */
function ia_is_root_app(): bool {
    $uri = trim(parse_url($_SERVER['REQUEST_URI']??'', PHP_URL_PATH), '/');
    /*
     * ROBUSTNESS FIX: this skip-list used to be missing .well-known/,
     * sitemap.xml, robots.txt and favicon.ico — a deny-list approach means
     * any future WordPress-core or third-party-plugin route that doesn't
     * happen to start with one of these prefixes gets silently swallowed by
     * the SPA shell instead of served correctly (domain-verification files,
     * SEO plugin sitemaps, etc). Extended defensively; still a deny-list by
     * design (that's intentional — this app owns the root domain), but now
     * covers the well-known cases that would otherwise break silently.
     */
    foreach (['wp-admin','wp-json','wp-login','wp-content','wp-cron','xmlrpc','feed','.well-known','sitemap','robots.txt','favicon.ico'] as $skip) {
        if ($uri==='' ? false : strncmp($uri,$skip,strlen($skip))===0) return false;
    }
    /* Skip REST requests */
    if (defined('REST_REQUEST') && REST_REQUEST) return false;
    /* Skip public marketing pages — served by PHP templates */
    $public_pages = ['ia-home','ia-pricing','ia-about','ia-privacy','ia-terms'];
    global $post;
    if ($post && in_array($post->post_name, $public_pages)) return false;
    /* Accept root and all sub-paths */
    if ($post && $post->post_name==='interviewace-root') return true;
    if (get_query_var('pagename')==='interviewace-root') return true;
    /* Catch-all for unresolved routes (login, signup, etc.) */
    return true;
}
