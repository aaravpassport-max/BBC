<?php
/**
 * Class JP_Settings — WordPress admin settings panel.
 *
 * Registered under Tools → JP Settings (or as top-level menu).
 * Sections: General | Payments | Email/SMTP | Plans | SEO | Analytics | Security
 *
 * All settings stored in wp_options as jp_* keys.
 * Owners fill in 20 handover items here after launch.
 */
defined( 'ABSPATH' ) || exit;

class JP_Settings {

	private static ?JP_Settings $instance = null;

	const MENU_SLUG = 'jp-settings';

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'admin_menu',    [ $this, 'register_menu' ] );
		add_action( 'admin_init',    [ $this, 'register_settings' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
		add_action( 'wp_ajax_jp_test_email',  [ $this, 'ajax_test_email' ] );
		add_action( 'wp_ajax_jp_gen_vapid',   [ $this, 'ajax_gen_vapid' ] );
		add_action( 'wp_ajax_jp_flush_cache', [ $this, 'ajax_flush_cache' ] );
	}

	// ── Admin menu ────────────────────────────────────────────────────────────

	/**
	 * Root-cause fix (roadmap re-audit, Part 3.3 / Phase 3: "WordPress
	 * renders no product screens of its own... no wp-admin screens for
	 * product configuration"). Every one of these 12 wp-admin pages
	 * (General/Payments/Email/Plans/SEO/Security/System Info/Audit Log/
	 * Error Log/Feature Flags/Privacy/Skills) now has a REST + SPA
	 * equivalent (see class-jp-api.php's /admin/* routes and the
	 * corresponding app/src/pages/admin/*.tsx screens) — the last
	 * confirmed gaps (SEO social links, real SMTP "from" keys vs a set of
	 * dead options, backup status, VAPID key generation, System Info
	 * counts/integration flags) were closed in this pass. Decommissioning
	 * the menu here — rather than deleting the render_*()/ajax_*() methods
	 * outright — keeps the underlying option storage and business logic
	 * completely untouched (Part 7: "DB schema, business logic... are not
	 * being redesigned") while satisfying the actual requirement: wp-admin
	 * shows no product-configuration UI. The render methods are kept,
	 * unreachable, only as a documented rollback path.
	 */
	public function register_menu(): void {
		// Intentionally no-op. See docblock above.
	}

	/** Shared permission gate for the audit log screen — manage_options or the dedicated capability. */
	private function current_user_can_view_audit_log(): bool {
		return current_user_can( 'manage_options' ) || current_user_can( 'jp_view_audit_log' );
	}

	public function enqueue_assets( string $hook ): void {
		if ( strpos( $hook, 'jp-settings' ) === false ) return;
		wp_enqueue_style( 'jp-admin', JP_PLUGIN_URL . 'assets/css/admin.css', [], JP_VERSION );
	}

	// ── Settings registration ─────────────────────────────────────────────────

	public function register_settings(): void {
		$settings = [
			// General
			'jp_maintenance_mode'       => [ 'boolean', false ],
			'jp_jobs_per_page'          => [ 'integer', 20 ],
			'jp_auto_approve_jobs'      => [ 'boolean', false ],
			'jp_auto_approve_reviews'   => [ 'boolean', false ],
			'jp_og_default_image'       => [ 'string',  '' ],
			// Payments
			'jp_payment_gateway'        => [ 'string',  'razorpay' ],
			'jp_razorpay_key_id'        => [ 'string',  '' ],
			'jp_razorpay_key_secret'    => [ 'string',  '' ],
			'jp_stripe_publishable_key' => [ 'string',  '' ],
			'jp_stripe_secret_key'      => [ 'string',  '' ],
			'jp_stripe_webhook_secret'  => [ 'string',  '' ],
			'jp_gst_number'             => [ 'string',  '' ],
			'jp_invoice_prefix'         => [ 'string',  'INV-' ],
			// Email
			'jp_smtp_from_name'         => [ 'string',  '' ],
			'jp_smtp_from_email'        => [ 'string',  '' ],
			// SEO
			'jp_ga4_measurement_id'     => [ 'string',  '' ],
			'jp_social_twitter'         => [ 'string',  '' ],
			'jp_social_linkedin'        => [ 'string',  '' ],
			'jp_social_facebook'        => [ 'string',  '' ],
			// Security
			'jp_max_login_attempts'     => [ 'integer', 10 ],
			'jp_lockout_duration'       => [ 'integer', 3600 ],
			'jp_require_2fa_admin'      => [ 'boolean', false ],
			// PWA
			'jp_vapid_public_key'       => [ 'string',  '' ],
			'jp_vapid_private_key'      => [ 'string',  '' ],
		];

		foreach ( $settings as $key => [ $type, $default ] ) {
			register_setting( 'jp_settings_group', $key, [
				'type'              => $type,
				'default'           => $default,
				'sanitize_callback' => ( $type === 'boolean' ? 'rest_sanitize_boolean' : ( $type === 'integer' ? 'absint' : 'sanitize_text_field' ) ),
			] );
		}
	}

	// ── Page renderers ────────────────────────────────────────────────────────

	public function render_page(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Access denied.' );
		$nonce = wp_create_nonce( 'jp_general' );
		?>
		<div class="wrap" style="max-width:900px">
		<h1>⚙️ JP Job Portal — General Settings</h1>
		<form method="post" action="options.php">
		<?php settings_fields('jp_settings_group'); ?>
		<table class="form-table">
			<tr><th>Maintenance Mode</th><td>
				<label><input type="checkbox" name="jp_maintenance_mode" value="1" <?php checked(get_option('jp_maintenance_mode')); ?>> Enable maintenance mode (shows Coming Soon to visitors)</label>
			</td></tr>
			<tr><th>Jobs Per Page</th><td>
				<input type="number" name="jp_jobs_per_page" value="<?php echo esc_attr(get_option('jp_jobs_per_page',20)); ?>" min="5" max="100" class="small-text">
			</td></tr>
			<tr><th>Auto-Approve Jobs</th><td>
				<label><input type="checkbox" name="jp_auto_approve_jobs" value="1" <?php checked(get_option('jp_auto_approve_jobs')); ?>> Skip moderation queue for recruiter job posts</label>
			</td></tr>
			<tr><th>Auto-Approve Reviews</th><td>
				<label><input type="checkbox" name="jp_auto_approve_reviews" value="1" <?php checked(get_option('jp_auto_approve_reviews')); ?>> Publish company reviews immediately without moderation</label>
			</td></tr>
			<tr><th>Default OG Image URL</th><td>
				<input type="url" name="jp_og_default_image" value="<?php echo esc_url(get_option('jp_og_default_image')); ?>" class="regular-text">
				<p class="description">Used as the social sharing image when no specific image is available.</p>
			</td></tr>
		</table>
		<p><button type="button" onclick="if(confirm('This will flush all cached data. Continue?')){fetch('<?php echo admin_url('admin-ajax.php'); ?>',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:'action=jp_flush_cache&nonce=<?php echo $nonce; ?>'}).then(r=>r.json()).then(d=>alert(d.data.message))}" class="button button-secondary">🔄 Flush All Caches</button></p>
		<?php submit_button(); ?>
		</form>
		</div>
		<?php
	}

	public function render_payments(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die();
		$nonce = wp_create_nonce('jp_general');
		?>
		<div class="wrap" style="max-width:900px">
		<h1>💳 Payment Settings — Razorpay</h1>
		<div style="background:#fff3cd;border:1px solid #ffc107;border-radius:6px;padding:12px 16px;margin-bottom:20px;">
			⚠️ <strong>Security:</strong> Add these values to <code>wp-config.php</code> as PHP constants for maximum security.<br>
			e.g. <code>define('JP_RAZORPAY_KEY_ID', 'rzp_live_XXXXXXX');</code>
		</div>
		<form method="post" action="options.php">
		<?php settings_fields('jp_settings_group'); ?>
		<table class="form-table">
			<tr><th>Razorpay Key ID</th><td>
				<input type="text" name="jp_razorpay_key_id" value="<?php echo esc_attr(get_option('jp_razorpay_key_id')); ?>" class="regular-text" placeholder="rzp_live_...">
				<p class="description">Get from Razorpay Dashboard → Settings → API Keys</p>
			</td></tr>
			<tr><th>Razorpay Key Secret</th><td>
				<input type="password" name="jp_razorpay_key_secret" value="<?php echo esc_attr(get_option('jp_razorpay_key_secret')); ?>" class="regular-text">
			</td></tr>
			<tr><th>GST Number (optional)</th><td>
				<input type="text" name="jp_gst_number" value="<?php echo esc_attr(get_option('jp_gst_number')); ?>" class="regular-text" placeholder="22AAAAA0000A1Z5">
			</td></tr>
			<tr><th>Invoice Number Prefix</th><td>
				<input type="text" name="jp_invoice_prefix" value="<?php echo esc_attr(get_option('jp_invoice_prefix','INV-')); ?>" class="small-text">
			</td></tr>
		</table>
		<?php submit_button(); ?>
		</form>
		</div>
		<?php
	}

	public function render_email(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die();
		$nonce = wp_create_nonce('jp_general');
		?>
		<div class="wrap" style="max-width:900px">
		<h1>📧 Email & SMTP Settings</h1>
		<div style="background:#d4edda;border:1px solid #28a745;border-radius:6px;padding:12px 16px;margin-bottom:20px;">
			💡 <strong>Recommended:</strong> Configure SMTP in <code>wp-config.php</code>: <code>JP_SMTP_HOST</code>, <code>JP_SMTP_USER</code>, <code>JP_SMTP_PASS</code>, <code>JP_SMTP_PORT</code>, <code>JP_SMTP_FROM</code>.
		</div>
		<form method="post" action="options.php">
		<?php settings_fields('jp_settings_group'); ?>
		<table class="form-table">
			<tr><th>From Name</th><td>
				<input type="text" name="jp_smtp_from_name" value="<?php echo esc_attr(get_option('jp_smtp_from_name',jp_site_name())); ?>" class="regular-text">
			</td></tr>
			<tr><th>From Email</th><td>
				<input type="email" name="jp_smtp_from_email" value="<?php echo esc_attr(get_option('jp_smtp_from_email',get_option('admin_email'))); ?>" class="regular-text">
			</td></tr>
		</table>
		<?php submit_button(); ?>
		</form>
		<hr>
		<h2>📬 Send Test Email</h2>
		<input type="email" id="test-email-addr" value="<?php echo esc_attr(get_option('admin_email')); ?>" class="regular-text">
		<button class="button button-primary" onclick="
			fetch('<?php echo admin_url('admin-ajax.php'); ?>',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
			body:'action=jp_test_email&nonce=<?php echo $nonce; ?>&to='+encodeURIComponent(document.getElementById('test-email-addr').value)})
			.then(r=>r.json()).then(d=>alert(d.data.message||d.data))">
			Send Test Email
		</button>
		</div>
		<?php
	}

	public function render_plans(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die();
		global $wpdb;
		$plans = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}jp_plans ORDER BY price_monthly ASC");
		?>
		<div class="wrap" style="max-width:900px">
		<h1>💼 Subscription Plans</h1>
		<?php if($plans): foreach($plans as $p): ?>
		<div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:20px;margin-bottom:16px;">
			<h2 style="margin-top:0;"><?php echo esc_html($p->name); ?> Plan</h2>
			<form method="post" action="<?php echo admin_url('admin-post.php'); ?>">
			<input type="hidden" name="action" value="jp_update_plan">
			<input type="hidden" name="plan_id" value="<?php echo (int)$p->id; ?>">
			<?php wp_nonce_field('jp_update_plan'); ?>
			<table class="form-table" style="margin:0">
				<tr><th style="width:200px">Monthly Price (₹)</th><td><input type="number" name="price_monthly" value="<?php echo (int)$p->price_monthly; ?>" min="0" class="small-text"> <em style="color:#666">0 = Free</em></td></tr>
				<tr><th>Yearly Price (₹)</th><td><input type="number" name="price_yearly" value="<?php echo (int)$p->price_yearly; ?>" min="0" class="small-text"></td></tr>
				<tr><th>Job Posts / month</th><td><input type="number" name="job_posts" value="<?php echo (int)($p->features_json ? (json_decode($p->features_json,true)['job_posts']??0) : 0); ?>" min="0" class="small-text"></td></tr>
				<tr><th>Is Active</th><td><label><input type="checkbox" name="is_active" value="1" <?php checked($p->is_active); ?>> Plan visible on pricing page</label></td></tr>
			</table>
			<?php submit_button('Save Plan', 'primary', 'submit', false); ?>
			</form>
		</div>
		<?php endforeach; else: echo '<p>No plans found. <a href="'.admin_url('admin.php?page=jp-settings').'">Activate the plugin</a> first.</p>'; endif; ?>
		</div>
		<?php
	}

	public function render_seo(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die();
		$nonce = wp_create_nonce('jp_general');
		?>
		<div class="wrap" style="max-width:900px">
		<h1>🔍 SEO & Analytics Settings</h1>
		<form method="post" action="options.php">
		<?php settings_fields('jp_settings_group'); ?>
		<table class="form-table">
			<tr><th>Google Analytics 4 ID</th><td>
				<input type="text" name="jp_ga4_measurement_id" value="<?php echo esc_attr(get_option('jp_ga4_measurement_id')); ?>" class="regular-text" placeholder="G-XXXXXXXXXX">
			</td></tr>
			<tr><th>Twitter/X URL</th><td><input type="url" name="jp_social_twitter" value="<?php echo esc_url(get_option('jp_social_twitter')); ?>" class="regular-text"></td></tr>
			<tr><th>LinkedIn URL</th><td><input type="url" name="jp_social_linkedin" value="<?php echo esc_url(get_option('jp_social_linkedin')); ?>" class="regular-text"></td></tr>
			<tr><th>Facebook URL</th><td><input type="url" name="jp_social_facebook" value="<?php echo esc_url(get_option('jp_social_facebook')); ?>" class="regular-text"></td></tr>
		</table>
		<?php submit_button(); ?>
		</form>
		<hr>
		<h2>📍 Sitemap URLs</h2>
		<ul>
			<li><a href="<?php echo esc_url(home_url('/sitemap.xml')); ?>" target="_blank">Main Sitemap Index</a></li>
			<li><a href="<?php echo esc_url(home_url('/sitemap-jobs.xml')); ?>" target="_blank">Jobs Sitemap</a></li>
			<li><a href="<?php echo esc_url(home_url('/sitemap-companies.xml')); ?>" target="_blank">Companies Sitemap</a></li>
		</ul>
		<p><strong>After changing URLs/permalinks:</strong> <a href="<?php echo admin_url('options-permalink.php'); ?>">Flush rewrite rules here</a></p>
		</div>
		<?php
	}

	public function render_security(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die();
		$nonce = wp_create_nonce('jp_general');
		$backup_status = class_exists('JP_Backup') ? JP_Backup::instance()->get_status() : [];
		?>
		<div class="wrap" style="max-width:900px">
		<h1>🔒 Security Settings</h1>
		<form method="post" action="options.php">
		<?php settings_fields('jp_settings_group'); ?>
		<table class="form-table">
			<tr><th>Max Login Attempts</th><td><input type="number" name="jp_max_login_attempts" value="<?php echo esc_attr(get_option('jp_max_login_attempts',10)); ?>" min="3" max="20" class="small-text"> per 15 minutes</td></tr>
			<tr><th>IP Lockout Duration</th><td><input type="number" name="jp_lockout_duration" value="<?php echo esc_attr(get_option('jp_lockout_duration',3600)); ?>" min="300" class="small-text"> seconds</td></tr>
			<tr><th>Require 2FA for Admins</th><td><label><input type="checkbox" name="jp_require_2fa_admin" value="1" <?php checked(get_option('jp_require_2fa_admin')); ?>> All admin accounts must have 2FA enabled</label></td></tr>
		</table>
		<?php submit_button(); ?>
		</form>
		<hr>
		<h2>🗄️ Backup Status</h2>
		<?php if($backup_status): ?>
		<table class="widefat" style="max-width:500px">
			<tr><td>Latest backup</td><td><?php echo esc_html($backup_status['latest_backup']??'Never'); ?></td></tr>
			<tr><td>Backup count</td><td><?php echo esc_html($backup_status['backup_count']??0); ?></td></tr>
			<tr><td>Next scheduled</td><td><?php echo esc_html($backup_status['next_backup']??'Unknown'); ?></td></tr>
		</table>
		<?php endif; ?>
		<p style="margin-top:12px">
			<button class="button button-secondary" onclick="
				this.textContent='Running...';this.disabled=true;
				fetch('<?php echo admin_url('admin-ajax.php'); ?>',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
				body:'action=jp_trigger_backup&nonce=<?php echo $nonce; ?>'})
				.then(r=>r.json()).then(d=>{this.textContent='Run Backup Now';this.disabled=false;alert(d.data?.message||d.data);})">
				Run Backup Now
			</button>
		</p>
		<hr>
		<h2>🔑 PWA Push Keys (VAPID)</h2>
		<p>Public: <code><?php echo esc_html(substr(get_option('jp_vapid_public_key','Not generated'),0,40)); ?>...</code></p>
		<button class="button" onclick="
			fetch('<?php echo admin_url('admin-ajax.php'); ?>',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},
			body:'action=jp_gen_vapid&nonce=<?php echo $nonce; ?>'})
			.then(r=>r.json()).then(d=>alert(d.success?'VAPID keys generated! Refresh page.':d.data))">
			Generate VAPID Keys
		</button>
		</div>
		<?php
	}

	public function render_system(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die();
		global $wpdb;
		?>
		<div class="wrap" style="max-width:900px">
		<h1>🖥️ System Information</h1>
		<table class="widefat">
			<tr><td>JP Core Version</td><td><?php echo JP_VERSION; ?></td></tr>
			<tr><td>WordPress Version</td><td><?php echo get_bloginfo('version'); ?></td></tr>
			<tr><td>PHP Version</td><td><?php echo PHP_VERSION; ?></td></tr>
			<tr><td>MySQL Version</td><td><?php echo $wpdb->db_version(); ?></td></tr>
			<tr><td>Active Jobs</td><td><?php echo (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}jp_jobs WHERE status='active'"); ?></td></tr>
			<tr><td>Total Users</td><td><?php echo (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->users}"); ?></td></tr>
			<tr><td>Total Applications</td><td><?php echo (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications"); ?></td></tr>
			<tr><td>Elasticsearch</td><td><?php echo defined('JP_ES_HOST')&&JP_ES_HOST ? '✅ Configured' : '⚠️ Not configured (MySQL fallback active)'; ?></td></tr>
			<tr><td>Redis</td><td><?php echo defined('JP_REDIS_HOST')&&JP_REDIS_HOST ? '✅ Configured' : '⚠️ Not configured (transient fallback active)'; ?></td></tr>
			<tr><td>TCPDF</td><td><?php echo JP_PDF::ensure_available() ? '✅ Installed' : '⚠️ Not installed — run: composer require tecnickcom/tcpdf (PDF-producing features fall back to HTML in the meantime)'; ?></td></tr>
			<tr><td>pdftotext</td><td><?php echo JP_Resume::is_pdftotext_available() ? '✅ Available' : '⚠️ Not found or shell_exec() disabled — install poppler-utils and enable shell_exec() (resume PDF parsing falls back to a manual-fill prompt otherwise)'; ?></td></tr>
			<tr><td>WP Cron</td><td><?php echo defined('DISABLE_WP_CRON')&&DISABLE_WP_CRON ? '⚠️ Disabled (use server cron)' : '✅ Enabled'; ?></td></tr>
			<tr><td>SMS</td><td><?php echo defined('JP_SMS_PROVIDER')&&JP_SMS_PROVIDER ? '✅ '.esc_html(JP_SMS_PROVIDER) : '— Not configured (optional)'; ?></td></tr>
		</table>
		<hr>
		<h2>🕐 Scheduled Cron Jobs</h2>
		<?php
		// Root-cause fix (gap analysis P1 #116, #169): this table previously
		// showed only "next scheduled run," which — as the gap analysis put
		// it — "can look healthy while one specific job has been silently
		// failing for days" (a job stays correctly scheduled by WP-Cron even
		// if every single execution throws). JP_Cron::health_report() has
		// tracked real last-run status/error/overdue-ness per job since an
		// earlier round (see class-jp-cron.php's own docblock, written for
		// the React AdminHealthPage's server-side support), but this
		// wp-admin PHP screen — the other of the two disconnected admin
		// surfaces noted in gap analysis P1 §171 — never consumed it. Now
		// both admin surfaces read the same underlying health_report(), not
		// two different notions of "is this job okay."
		$health_by_hook = [];
		foreach ( JP_Cron::health_report() as $h ) { $health_by_hook[ $h['hook'] ] = $h; }
		?>
		<table class="widefat">
		<tr><th>Hook</th><th>Next Run</th><th>Interval</th><th>Last Run</th><th>Last Status</th></tr>
		<?php foreach(JP_Cron::JOBS as [$hook,$interval,$desc]):
			$ts = wp_next_scheduled($hook);
			$h  = $health_by_hook[$hook] ?? null;
			$status = $h['last_status'] ?? 'never_run';
			$status_html = match(true) {
				$status === 'success' && ($h['overdue'] ?? false) => '<span style="color:#c87f00">⚠️ overdue (last succeeded)</span>',
				$status === 'success' => '<span style="color:#0a0">✅ success</span>',
				$status === 'failed'  => '<span style="color:#c00" title="'.esc_attr($h['last_error'] ?? '').'">❌ failed</span>',
				default               => '<span style="color:#999">— never run</span>',
			};
		?>
		<tr>
			<td><code><?php echo esc_html($hook); ?></code><br><small style="color:#666"><?php echo esc_html($desc); ?></small></td>
			<td><?php echo $ts ? esc_html(human_time_diff($ts).' from now') : '<span style="color:red">Not scheduled</span>'; ?></td>
			<td><?php echo esc_html($interval); ?></td>
			<td><?php echo $h && $h['last_started'] ? esc_html(human_time_diff(strtotime($h['last_started'])).' ago') : '—'; ?></td>
			<td><?php echo $status_html; ?></td>
		</tr>
		<?php endforeach; ?>
		</table>
		<p style="color:#666;font-size:12px">Full per-run history (timestamps, duration, error messages) is in the <code><?php global $wpdb; echo esc_html($wpdb->prefix); ?>jp_cron_runs</code> table. A failed run's error message is available as a tooltip on "❌ failed" above.</p>
		</div>
		<?php
	}

	/**
	 * Audit log viewer + SMS delivery report.
	 *
	 * Root cause (gap analysis P1 #115, #182): jp_audit_log (recruiter/
	 * admin action trail — job create/update/delete, application stage
	 * moves, webhook admin, skill admin, etc. — see JP_Security::audit()
	 * and its callers) and jp_sms_log (every SMS send attempt with
	 * provider + status) have both been populated correctly since the
	 * insert-failure bug documented in class-jp-activator.php's audit-log
	 * migration comment was fixed, but nothing ever read either table back
	 * out for a human. This screen is a simple, filterable reader for
	 * both — not a redesign of how either table is written.
	 */
	public function render_audit_log(): void {
		if ( ! $this->current_user_can_view_audit_log() ) {
			wp_die( __( 'You do not have permission to view the audit log.', 'jp-core' ) );
		}
		global $wpdb;

		$per_page   = 50;
		$paged      = max( 1, absint( $_GET['paged'] ?? 1 ) );
		$offset     = ( $paged - 1 ) * $per_page;

		$filter_action = sanitize_text_field( wp_unslash( $_GET['jp_action'] ?? '' ) );
		$filter_user   = absint( $_GET['jp_user'] ?? 0 );
		$filter_from   = sanitize_text_field( wp_unslash( $_GET['jp_from'] ?? '' ) );
		$filter_to     = sanitize_text_field( wp_unslash( $_GET['jp_to'] ?? '' ) );

		$where  = [ '1=1' ];
		$params = [];
		if ( $filter_action !== '' ) { $where[] = 'action = %s'; $params[] = $filter_action; }
		if ( $filter_user > 0 )      { $where[] = 'user_id = %d'; $params[] = $filter_user; }
		if ( $filter_from !== '' )   { $where[] = 'created_at >= %s'; $params[] = $filter_from . ' 00:00:00'; }
		if ( $filter_to !== '' )     { $where[] = 'created_at <= %s'; $params[] = $filter_to . ' 23:59:59'; }
		$where_sql = implode( ' AND ', $where );

		$table       = $wpdb->prefix . 'jp_audit_log';
		$count_sql   = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
		$total       = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql ) );

		$list_sql    = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY created_at DESC, id DESC LIMIT %d OFFSET %d";
		$list_params = array_merge( $params, [ $per_page, $offset ] );
		$rows        = $wpdb->get_results( $wpdb->prepare( $list_sql, $list_params ) );

		// Distinct action list for the filter dropdown — cheap enough at
		// audit-log scale (a handful of distinct action strings) to run
		// unconditionally rather than caching.
		$actions = $wpdb->get_col( "SELECT DISTINCT action FROM {$table} ORDER BY action ASC" );

		// SMS delivery report (gap analysis P1 #182): aggregate rather than
		// row-by-row, since the log itself can be large and what an admin
		// actually needs here is "is SMS delivery healthy," not a raw dump.
		$sms_table   = $wpdb->prefix . 'jp_sms_log';
		$sms_summary = $wpdb->get_results(
			"SELECT provider, status, COUNT(*) AS cnt FROM {$sms_table}
			 WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
			 GROUP BY provider, status ORDER BY provider, status"
		);
		$sms_recent_failures = $wpdb->get_results(
			"SELECT phone, message, provider, created_at FROM {$sms_table}
			 WHERE status = 'failed' ORDER BY created_at DESC LIMIT 10"
		);

		$total_pages = (int) ceil( $total / $per_page );
		?>
		<div class="wrap" style="max-width:1100px">
		<h1>🧾 Audit Log</h1>
		<p style="color:#666">Recruiter and admin actions across the platform (job changes, application stage moves, skill/webhook admin, and more). Records with a Company column populated are scoped to that company's team once multi-seat support is in use.</p>

		<form method="get" style="margin:16px 0;display:flex;gap:10px;flex-wrap:wrap;align-items:end">
			<input type="hidden" name="page" value="jp-settings-audit-log">
			<div>
				<label style="display:block;font-size:12px;color:#666">Action</label>
				<select name="jp_action">
					<option value="">All actions</option>
					<?php foreach ( $actions as $a ) : ?>
						<option value="<?php echo esc_attr( $a ); ?>" <?php selected( $filter_action, $a ); ?>><?php echo esc_html( $a ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div>
				<label style="display:block;font-size:12px;color:#666">User ID</label>
				<input type="number" name="jp_user" value="<?php echo esc_attr( $filter_user ?: '' ); ?>" style="width:90px">
			</div>
			<div>
				<label style="display:block;font-size:12px;color:#666">From</label>
				<input type="date" name="jp_from" value="<?php echo esc_attr( $filter_from ); ?>">
			</div>
			<div>
				<label style="display:block;font-size:12px;color:#666">To</label>
				<input type="date" name="jp_to" value="<?php echo esc_attr( $filter_to ); ?>">
			</div>
			<button class="button button-primary">Filter</button>
			<?php if ( $filter_action || $filter_user || $filter_from || $filter_to ) : ?>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=jp-settings-audit-log' ) ); ?>">Clear</a>
			<?php endif; ?>
		</form>

		<table class="widefat striped">
			<thead><tr><th>Time</th><th>User</th><th>Action</th><th>Object</th><th>Company</th><th>Detail</th><th>IP</th></tr></thead>
			<tbody>
			<?php if ( empty( $rows ) ) : ?>
				<tr><td colspan="7">No matching audit log entries.</td></tr>
			<?php else : foreach ( $rows as $r ) :
				$u = get_userdata( $r->user_id );
			?>
				<tr>
					<td><?php echo esc_html( $r->created_at ); ?></td>
					<td><?php echo $u ? esc_html( $u->display_name . ' (#' . $r->user_id . ')' ) : 'User #' . (int) $r->user_id; ?></td>
					<td><code><?php echo esc_html( $r->action ); ?></code></td>
					<td><?php echo esc_html( trim( ( $r->object ?? '' ) . ' #' . ( $r->object_id ?: '' ) ) ); ?></td>
					<td><?php echo $r->company_id ? '#' . (int) $r->company_id : '—'; ?></td>
					<td style="max-width:280px;overflow-wrap:anywhere"><?php echo esc_html( $r->detail ?? '' ); ?></td>
					<td><?php echo esc_html( $r->ip ?? '' ); ?></td>
				</tr>
			<?php endforeach; endif; ?>
			</tbody>
		</table>

		<?php if ( $total_pages > 1 ) : ?>
			<div style="margin:14px 0">
				<?php
				echo paginate_links( [
					'base'      => add_query_arg( 'paged', '%#%' ),
					'format'    => '',
					'current'   => $paged,
					'total'     => $total_pages,
					'prev_text' => '&laquo;',
					'next_text' => '&raquo;',
				] );
				?>
			</div>
		<?php endif; ?>

		<hr>
		<h2>📱 SMS Delivery Report (last 30 days)</h2>
		<table class="widefat">
			<thead><tr><th>Provider</th><th>Status</th><th>Count</th></tr></thead>
			<tbody>
			<?php if ( empty( $sms_summary ) ) : ?>
				<tr><td colspan="3">No SMS activity in the last 30 days.</td></tr>
			<?php else : foreach ( $sms_summary as $s ) : ?>
				<tr>
					<td><?php echo esc_html( $s->provider ?: '(unset)' ); ?></td>
					<td><?php echo $s->status === 'failed' ? '<span style="color:#c00">failed</span>' : esc_html( $s->status ); ?></td>
					<td><?php echo (int) $s->cnt; ?></td>
				</tr>
			<?php endforeach; endif; ?>
			</tbody>
		</table>

		<?php if ( ! empty( $sms_recent_failures ) ) : ?>
			<h3 style="margin-top:20px">Most recent failures</h3>
			<table class="widefat striped">
				<thead><tr><th>Time</th><th>Phone</th><th>Provider</th><th>Message</th></tr></thead>
				<tbody>
				<?php foreach ( $sms_recent_failures as $f ) : ?>
					<tr>
						<td><?php echo esc_html( $f->created_at ); ?></td>
						<td><?php echo esc_html( $f->phone ); ?></td>
						<td><?php echo esc_html( $f->provider ?: '(unset)' ); ?></td>
						<td style="max-width:400px;overflow-wrap:anywhere"><?php echo esc_html( $f->message ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Error log viewer (gap analysis P0/P1 #156: "no structured error/
	 * exception monitoring or alerting pipeline anywhere"). JP_ErrorLog
	 * already captures every PHP warning/notice/uncaught exception/fatal
	 * originating from this plugin's own files, deduplicated by
	 * fingerprint with an occurrence counter, plus a threshold-based email
	 * alert — this screen is purely a reader for that already-populated
	 * table, grouped by distinct error (fingerprint) rather than raw rows,
	 * since a hot-looping bug's occurrence count matters more here than
	 * seeing the same message repeated fifty times.
	 */
	public function render_error_log(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die();
		global $wpdb;
		$table = $wpdb->prefix . 'jp_error_log';

		$per_page = 50;
		$paged    = max( 1, absint( $_GET['paged'] ?? 1 ) );
		$offset   = ( $paged - 1 ) * $per_page;

		$filter_level = sanitize_key( $_GET['jp_level'] ?? '' );
		$where  = [ '1=1' ];
		$params = [];
		if ( $filter_level !== '' ) { $where[] = 'level = %s'; $params[] = $filter_level; }
		$where_sql = implode( ' AND ', $where );

		$total = (int) ( $params
			? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}", $params ) )
			: $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}" )
		);

		$list_params = array_merge( $params, [ $per_page, $offset ] );
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} WHERE {$where_sql} ORDER BY last_seen_at DESC LIMIT %d OFFSET %d", $list_params
		) );

		$levels = $wpdb->get_col( "SELECT DISTINCT level FROM {$table} ORDER BY level ASC" );

		// Same window/threshold JP_ErrorLog::maybe_alert() uses, surfaced
		// here so an admin sees at a glance whether the site is currently
		// near (or past) the point that would trigger the alert email —
		// not just a raw list with no sense of how it compares to "normal."
		$distinct_last_hour = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$table} WHERE first_seen_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)"
		);
		$alert_threshold = 10; // mirrors JP_ErrorLog::ALERT_THRESHOLD (private; kept in sync by comment, not by reference)

		$total_pages = (int) ceil( $total / $per_page );
		?>
		<div class="wrap" style="max-width:1100px">
		<h1>🐛 Error Log</h1>
		<p style="color:#666">PHP warnings, notices, and uncaught exceptions/fatals originating from this plugin's own code (theme and plugin files only — not a site-wide error monitor for other plugins). Identical errors are deduplicated into one row with an occurrence count rather than listed individually.</p>

		<div style="margin:12px 0;padding:10px 14px;border-radius:4px;background:<?php echo $distinct_last_hour >= $alert_threshold ? '#fdecea' : '#eef7ee'; ?>;border:1px solid <?php echo $distinct_last_hour >= $alert_threshold ? '#f0b4ac' : '#b8ddb8'; ?>">
			<strong><?php echo (int) $distinct_last_hour; ?></strong> distinct new error(s) in the last hour
			<?php echo $distinct_last_hour >= $alert_threshold ? ' — ⚠️ at or above the ' . (int) $alert_threshold . '/hour threshold that triggers an admin email alert.' : " (alert threshold: {$alert_threshold}/hour)."; ?>
		</div>

		<form method="get" style="margin:16px 0;display:flex;gap:10px;flex-wrap:wrap;align-items:end">
			<input type="hidden" name="page" value="jp-settings-error-log">
			<div>
				<label style="display:block;font-size:12px;color:#666">Level</label>
				<select name="jp_level">
					<option value="">All levels</option>
					<?php foreach ( $levels as $l ) : ?>
						<option value="<?php echo esc_attr( $l ); ?>" <?php selected( $filter_level, $l ); ?>><?php echo esc_html( $l ); ?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<button class="button button-primary">Filter</button>
			<?php if ( $filter_level ) : ?>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=jp-settings-error-log' ) ); ?>">Clear</a>
			<?php endif; ?>
		</form>

		<table class="widefat striped">
			<thead><tr><th>Last Seen</th><th>Level</th><th>Message</th><th>File:Line</th><th>Occurrences</th><th>First Seen</th></tr></thead>
			<tbody>
			<?php if ( empty( $rows ) ) : ?>
				<tr><td colspan="6">No errors logged<?php echo $filter_level ? ' at this level' : ''; ?>. 🎉</td></tr>
			<?php else : foreach ( $rows as $r ) : ?>
				<tr>
					<td><?php echo esc_html( $r->last_seen_at ); ?></td>
					<td><code style="color:<?php echo in_array( $r->level, [ 'fatal_error', 'uncaught_exception' ], true ) ? '#c00' : '#666'; ?>"><?php echo esc_html( $r->level ); ?></code></td>
					<td style="max-width:400px;overflow-wrap:anywhere"><?php echo esc_html( $r->message ); ?></td>
					<td><code style="font-size:11px"><?php echo esc_html( basename( $r->file ?? '' ) . ':' . $r->line ); ?></code></td>
					<td><?php echo (int) $r->occurrences; ?></td>
					<td><?php echo esc_html( $r->first_seen_at ); ?></td>
				</tr>
				<?php if ( $r->trace ) : ?>
				<tr><td colspan="6"><details><summary style="cursor:pointer;color:#666;font-size:12px">Stack trace</summary><pre style="white-space:pre-wrap;font-size:11px;background:#f6f7f7;padding:8px;overflow-wrap:anywhere"><?php echo esc_html( $r->trace ); ?></pre></details></td></tr>
				<?php endif; ?>
			<?php endforeach; endif; ?>
			</tbody>
		</table>

		<?php if ( $total_pages > 1 ) : ?>
			<div style="margin:14px 0">
				<?php
				echo paginate_links( [
					'base'      => add_query_arg( 'paged', '%#%' ),
					'format'    => '',
					'current'   => $paged,
					'total'     => $total_pages,
					'prev_text' => '&laquo;',
					'next_text' => '&raquo;',
				] );
				?>
			</div>
		<?php endif; ?>
		</div>
		<?php
	}

	/**
	 * Feature Flags admin screen. Root cause: JP_FeatureFlags::ajax_list()/
	 * ajax_save()/ajax_delete() have existed and worked correctly since an
	 * earlier round, but nothing rendered a UI to call them — this is that
	 * UI. All data operations happen client-side via fetch() against the
	 * existing wp_ajax_jp_admin_flags_* actions using a nonce created here
	 * with the exact same action string those handlers verify
	 * ('jp_admin_flags') — the specific class of mismatch this whole audit
	 * (§31) was about, so this new screen is built nonce-consistent by
	 * construction rather than by later cross-checking it.
	 */
	public function render_feature_flags(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Access denied.' );
		$nonce = wp_create_nonce( 'jp_admin_flags' );
		global $wpdb;
		$plan_slugs = $wpdb->get_col( "SELECT slug FROM {$wpdb->prefix}jp_plans WHERE is_active = 1 ORDER BY sort_order ASC" );
		?>
		<div class="wrap" style="max-width:1000px">
		<h1>🚩 Feature Flags</h1>
		<p style="color:#666">Turn platform features on or off instantly, optionally gated to a minimum plan tier — without a code deploy. Checked at runtime via <code>JP_FeatureFlags::is_enabled()</code>.</p>

		<div id="jp-flags-msg" style="display:none;margin:10px 0;padding:10px;border-radius:4px"></div>

		<table class="widefat striped" id="jp-flags-table">
			<thead><tr><th>Flag Key</th><th>Enabled</th><th>Min Plan Tier</th><th>Description</th><th></th></tr></thead>
			<tbody id="jp-flags-tbody"><tr><td colspan="5">Loading…</td></tr></tbody>
		</table>

		<h2 style="margin-top:24px">Add / Update Flag</h2>
		<table class="form-table">
			<tr><th>Flag Key</th><td><input type="text" id="jp-flag-key" class="regular-text" placeholder="e.g. new_matching_algorithm" pattern="[a-z0-9_]+"></td></tr>
			<tr><th>Enabled</th><td><label><input type="checkbox" id="jp-flag-enabled" checked> Enabled</label></td></tr>
			<tr><th>Min Plan Tier</th><td>
				<select id="jp-flag-tier">
					<option value="all">All plans (no gating)</option>
					<?php foreach ( $plan_slugs as $slug ) : ?>
						<option value="<?php echo esc_attr( $slug ); ?>"><?php echo esc_html( $slug ); ?>+</option>
					<?php endforeach; ?>
				</select>
			</td></tr>
			<tr><th>Description</th><td><textarea id="jp-flag-desc" class="large-text" rows="2"></textarea></td></tr>
		</table>
		<p><button type="button" class="button button-primary" id="jp-flag-save">Save Flag</button></p>
		</div>

		<script>
		(function(){
			const AJAX = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
			const NONCE = <?php echo wp_json_encode( $nonce ); ?>;
			const msgEl = document.getElementById('jp-flags-msg');
			const tbody = document.getElementById('jp-flags-tbody');

			function showMsg(text, ok) {
				msgEl.style.display = 'block';
				msgEl.style.background = ok ? '#eef7ee' : '#fdecea';
				msgEl.style.border = '1px solid ' + (ok ? '#b8ddb8' : '#f0b4ac');
				msgEl.textContent = text;
			}

			async function post(action, extra) {
				const body = new URLSearchParams(Object.assign({ action: action, nonce: NONCE }, extra || {}));
				const res = await fetch(AJAX, { method: 'POST', credentials: 'same-origin', body: body });
				return res.json();
			}

			function escapeHtml(s) {
				return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
			}

			async function loadFlags() {
				tbody.innerHTML = '<tr><td colspan="5">Loading…</td></tr>';
				const res = await post('jp_admin_flags_list');
				if (!res.success) { tbody.innerHTML = '<tr><td colspan="5">Failed to load: ' + escapeHtml(res.data) + '</td></tr>'; return; }
				const flags = res.data.flags || [];
				if (!flags.length) { tbody.innerHTML = '<tr><td colspan="5">No flags defined yet.</td></tr>'; return; }
				tbody.innerHTML = flags.map(f => `
					<tr>
						<td><code>${escapeHtml(f.flag_key)}</code></td>
						<td>${Number(f.is_enabled) ? '✅ Enabled' : '⬜ Disabled'}</td>
						<td>${escapeHtml(f.plan_tier || 'all')}</td>
						<td>${escapeHtml(f.description || '')}</td>
						<td>
							<button type="button" class="button button-small jp-flag-edit" data-key="${escapeHtml(f.flag_key)}" data-enabled="${Number(f.is_enabled)}" data-tier="${escapeHtml(f.plan_tier || 'all')}" data-desc="${escapeHtml(f.description || '')}">Edit</button>
							<button type="button" class="button button-small jp-flag-delete" data-key="${escapeHtml(f.flag_key)}">Delete</button>
						</td>
					</tr>
				`).join('');

				tbody.querySelectorAll('.jp-flag-edit').forEach(btn => {
					btn.addEventListener('click', () => {
						document.getElementById('jp-flag-key').value = btn.dataset.key;
						document.getElementById('jp-flag-key').disabled = true; // editing an existing key, not renaming it
						document.getElementById('jp-flag-enabled').checked = btn.dataset.enabled === '1';
						document.getElementById('jp-flag-tier').value = btn.dataset.tier;
						document.getElementById('jp-flag-desc').value = btn.dataset.desc;
						window.scrollTo({ top: document.getElementById('jp-flag-key').getBoundingClientRect().top + window.scrollY - 100, behavior: 'smooth' });
					});
				});
				tbody.querySelectorAll('.jp-flag-delete').forEach(btn => {
					btn.addEventListener('click', async () => {
						if (!confirm('Delete flag "' + btn.dataset.key + '"? Any code checking it will fall back to its fail-closed default.')) return;
						const res = await post('jp_admin_flags_delete', { flag_key: btn.dataset.key });
						showMsg(res.data?.message || res.data || (res.success ? 'Deleted.' : 'Delete failed.'), res.success);
						loadFlags();
					});
				});
			}

			document.getElementById('jp-flag-save').addEventListener('click', async () => {
				const key = document.getElementById('jp-flag-key').value.trim();
				if (!key) { showMsg('Flag key is required.', false); return; }
				const res = await post('jp_admin_flags_save', {
					flag_key: key,
					is_enabled: document.getElementById('jp-flag-enabled').checked ? '1' : '',
					plan_tier: document.getElementById('jp-flag-tier').value,
					description: document.getElementById('jp-flag-desc').value,
				});
				showMsg(res.data?.message || res.data || (res.success ? 'Saved.' : 'Save failed.'), res.success);
				if (res.success) {
					document.getElementById('jp-flag-key').value = '';
					document.getElementById('jp-flag-key').disabled = false;
					document.getElementById('jp-flag-enabled').checked = true;
					document.getElementById('jp-flag-tier').value = 'all';
					document.getElementById('jp-flag-desc').value = '';
					loadFlags();
				}
			});

			loadFlags();
		})();
		</script>
		<?php
	}

	/**
	 * Privacy / Offboarding admin screen — company data export/erase and
	 * admin-impersonation, all backed by existing, working JP_Privacy AJAX
	 * handlers (verifying the 'jp_admin_privacy' nonce) that previously
	 * had no UI anywhere to reach them. See render_feature_flags() above
	 * for why this class of gap exists and how it was found (§31/§32).
	 */
	public function render_privacy_admin(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Access denied.' );
		$nonce = wp_create_nonce( 'jp_admin_privacy' );
		global $wpdb;
		// Small reference tables so an admin can find the ID they need
		// without a separate company/user search endpoint — this screen
		// intentionally stays read-only-lookup + action-by-ID rather than
		// building a full picker UI, since no such picker exists anywhere
		// else in wp-admin to match the look of.
		$companies = $wpdb->get_results( "SELECT id, name, status FROM {$wpdb->prefix}jp_companies ORDER BY id DESC LIMIT 25" );
		?>
		<div class="wrap" style="max-width:1000px">
		<h1>🔒 Privacy / Offboarding</h1>
		<p style="color:#666">Company data export &amp; erasure (GDPR-style offboarding) and time-boxed admin impersonation for reproducing a user's reported bug from their own session. Every action here is written to the audit log.</p>

		<div id="jp-priv-msg" style="display:none;margin:10px 0;padding:10px;border-radius:4px;white-space:pre-wrap;overflow-wrap:anywhere"></div>

		<h2>Company Offboarding</h2>
		<table class="widefat striped" style="max-width:600px">
			<thead><tr><th>ID</th><th>Name</th><th>Status</th></tr></thead>
			<tbody>
			<?php if ( empty( $companies ) ) : ?>
				<tr><td colspan="3">No companies found.</td></tr>
			<?php else : foreach ( $companies as $c ) : ?>
				<tr><td><?php echo (int) $c->id; ?></td><td><?php echo esc_html( $c->name ); ?></td><td><?php echo esc_html( $c->status ); ?></td></tr>
			<?php endforeach; endif; ?>
			</tbody>
		</table>
		<p class="description">Showing the 25 most recently created companies. Use the ID column below.</p>
		<table class="form-table">
			<tr><th>Company ID</th><td><input type="number" id="jp-priv-company-id" class="small-text" min="1"></td></tr>
		</table>
		<p>
			<button type="button" class="button" id="jp-priv-export">📤 Export Company Data (JSON)</button>
			<button type="button" class="button" style="color:#c00;border-color:#c00" id="jp-priv-erase">🗑️ Erase Company Data</button>
		</p>
		<textarea id="jp-priv-export-out" style="display:none;width:100%;height:240px;font-family:monospace;font-size:12px" readonly></textarea>

		<hr style="margin:32px 0">

		<h2>Admin Impersonation</h2>
		<p class="description">Time-boxed — automatically ends and is fully audit-logged on both start and stop. Cannot be used on another administrator account.</p>
		<table class="form-table">
			<tr><th>Target User ID</th><td><input type="number" id="jp-priv-user-id" class="small-text" min="1"></td></tr>
		</table>
		<p><button type="button" class="button button-primary" id="jp-priv-impersonate">👤 Start Impersonating</button></p>
		</div>

		<script>
		(function(){
			const AJAX = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
			const NONCE = <?php echo wp_json_encode( $nonce ); ?>;
			const msgEl = document.getElementById('jp-priv-msg');

			function showMsg(text, ok) {
				msgEl.style.display = 'block';
				msgEl.style.background = ok ? '#eef7ee' : '#fdecea';
				msgEl.style.border = '1px solid ' + (ok ? '#b8ddb8' : '#f0b4ac');
				msgEl.textContent = text;
			}

			async function post(action, extra) {
				const body = new URLSearchParams(Object.assign({ action: action, nonce: NONCE }, extra || {}));
				const res = await fetch(AJAX, { method: 'POST', credentials: 'same-origin', body: body });
				return res.json();
			}

			document.getElementById('jp-priv-export').addEventListener('click', async () => {
				const id = document.getElementById('jp-priv-company-id').value;
				if (!id) { showMsg('Enter a company ID first.', false); return; }
				const res = await post('jp_admin_export_company', { company_id: id });
				if (!res.success) { showMsg(res.data || 'Export failed.', false); return; }
				const out = document.getElementById('jp-priv-export-out');
				out.style.display = 'block';
				out.value = JSON.stringify(res.data, null, 2);
				showMsg('Export complete — shown below. Copy/paste to save it (this screen does not offer a file download).', true);
			});

			document.getElementById('jp-priv-erase').addEventListener('click', async () => {
				const id = document.getElementById('jp-priv-company-id').value;
				if (!id) { showMsg('Enter a company ID first.', false); return; }
				const typed = prompt('This PERMANENTLY deletes all data for company #' + id + ' (jobs, applications, team members, reviews, subscriptions). Type ERASE to confirm.');
				if (typed !== 'ERASE') { showMsg('Erase cancelled.', false); return; }
				const res = await post('jp_admin_erase_company', { company_id: id });
				showMsg(res.data?.message || res.data || (res.success ? 'Erased.' : 'Erase failed.'), res.success);
			});

			document.getElementById('jp-priv-impersonate').addEventListener('click', async () => {
				const id = document.getElementById('jp-priv-user-id').value;
				if (!id) { showMsg('Enter a user ID first.', false); return; }
				if (!confirm('Start impersonating user #' + id + '? You will be logged in as this user until you stop or the time box expires.')) return;
				const res = await post('jp_impersonate_start', { user_id: id });
				showMsg(res.data?.message || res.data || (res.success ? 'Impersonation started.' : 'Failed to start impersonation.'), res.success);
				if (res.success) {
					// The AJAX call already switched the server-side session to
					// the target user (wp_set_current_user/wp_set_auth_cookie),
					// so this admin screen is no longer valid for the current
					// identity — reload into the site as that user.
					setTimeout(() => { window.location.href = <?php echo wp_json_encode( home_url( '/' ) ); ?>; }, 1500);
				}
			});
		})();
		</script>
		<?php
	}

	/**
	 * Skill-taxonomy admin screen — add, delete, and (as of this fix) merge
	 * skills, all via the REST /jp/v1/admin/skills endpoints in
	 * class-jp-api.php. Those endpoints (admin_get_skills/admin_add_skill/
	 * admin_delete_skill, and the new admin_merge_skill) had no caller
	 * anywhere in this checkout — same orphaned-capability pattern as
	 * Feature Flags/Privacy above, discovered while building the merge
	 * endpoint and checking whether it would actually be reachable.
	 *
	 * Uses fetch() against the REST API directly (X-WP-Nonce + a wp_rest
	 * nonce) rather than admin-ajax.php, since these endpoints are
	 * REST-only — there is no parallel wp_ajax_* action for them to call.
	 */
	public function render_skills_admin(): void {
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Access denied.' );
		$rest_nonce = wp_create_nonce( 'wp_rest' );
		$rest_base  = esc_url_raw( rest_url( 'jp/v1/admin/skills' ) );
		?>
		<div class="wrap" style="max-width:1000px">
		<h1>🏷️ Skills</h1>
		<p style="color:#666">Manage the skill taxonomy candidates declare, assessments test, and job matching scores against. Merging folds a duplicate/near-duplicate skill (e.g. "ReactJS") into a canonical one (e.g. "React") — every candidate profile link, assessment history row, and assessment question moves with it, unlike deleting, which discards them.</p>

		<div id="jp-skills-msg" style="display:none;margin:10px 0;padding:10px;border-radius:4px;white-space:pre-wrap;overflow-wrap:anywhere"></div>

		<table class="widefat striped" id="jp-skills-table">
			<thead><tr><th>ID</th><th>Name</th><th>Category</th><th>Jobs</th><th style="width:340px">Actions</th></tr></thead>
			<tbody id="jp-skills-tbody"><tr><td colspan="5">Loading…</td></tr></tbody>
		</table>

		<h2 style="margin-top:24px">Add Skill</h2>
		<table class="form-table">
			<tr><th>Name</th><td><input type="text" id="jp-skill-name" class="regular-text" placeholder="e.g. TypeScript"></td></tr>
			<tr><th>Category</th><td><input type="text" id="jp-skill-category" class="regular-text" placeholder="e.g. Programming Languages"></td></tr>
		</table>
		<p><button type="button" class="button button-primary" id="jp-skill-add">Add Skill</button></p>
		</div>

		<script>
		(function(){
			const REST_BASE = <?php echo wp_json_encode( $rest_base ); ?>;
			const NONCE = <?php echo wp_json_encode( $rest_nonce ); ?>;
			const msgEl = document.getElementById('jp-skills-msg');
			const tbody = document.getElementById('jp-skills-tbody');
			let skills = [];

			function showMsg(text, ok) {
				msgEl.style.display = 'block';
				msgEl.style.background = ok ? '#eef7ee' : '#fdecea';
				msgEl.style.border = '1px solid ' + (ok ? '#b8ddb8' : '#f0b4ac');
				msgEl.textContent = text;
			}

			function escapeHtml(s) {
				return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
			}

			// JP_Api::ok() wraps every SUCCESS payload as {success:true, data:<payload>},
			// but JP_Api::error()/not_found() return a WP_Error, which WordPress's
			// REST error handler serializes as a DIFFERENT, flat shape:
			// {code, message, data:{status}} — "message" at the top level, not
			// nested under "data". Unwrapping both shapes here (once) means every
			// caller below can just read res.payload / res.message regardless of
			// which one came back, instead of every call site guessing.
			async function restCall(path, method, body) {
				const res = await fetch(REST_BASE + path, {
					method: method,
					credentials: 'same-origin',
					headers: Object.assign({ 'X-WP-Nonce': NONCE }, body ? { 'Content-Type': 'application/json' } : {}),
					body: body ? JSON.stringify(body) : undefined,
				});
				let json;
				try { json = await res.json(); } catch (e) { json = null; }
				return {
					ok: res.ok,
					status: res.status,
					payload: res.ok ? json?.data : json,
					message: res.ok ? (json?.data?.message ?? null) : (json?.message ?? null),
				};
			}

			function optionsExcept(excludeId) {
				return skills
					.filter(s => Number(s.id) !== Number(excludeId))
					.map(s => `<option value="${s.id}">${escapeHtml(s.name)}</option>`)
					.join('');
			}

			async function loadSkills() {
				tbody.innerHTML = '<tr><td colspan="5">Loading…</td></tr>';
				const res = await restCall('', 'GET');
				if (!res.ok) { tbody.innerHTML = '<tr><td colspan="5">Failed to load: ' + escapeHtml(res.message || res.status) + '</td></tr>'; return; }
				skills = res.payload || [];
				if (!skills.length) { tbody.innerHTML = '<tr><td colspan="5">No skills defined yet.</td></tr>'; return; }
				tbody.innerHTML = skills.map(s => `
					<tr>
						<td>${s.id}</td>
						<td>${escapeHtml(s.name)}</td>
						<td>${escapeHtml(s.category || '')}</td>
						<td>${Number(s.jobs_count || 0)}</td>
						<td>
							<select class="jp-skill-merge-target" data-id="${s.id}" style="max-width:160px">
								<option value="">Merge into…</option>
								${optionsExcept(s.id)}
							</select>
							<button type="button" class="button button-small jp-skill-merge" data-id="${s.id}" data-name="${escapeHtml(s.name)}">Merge</button>
							<button type="button" class="button button-small jp-skill-delete" data-id="${s.id}" data-name="${escapeHtml(s.name)}">Delete</button>
						</td>
					</tr>
				`).join('');

				tbody.querySelectorAll('.jp-skill-merge').forEach(btn => {
					btn.addEventListener('click', async () => {
						const id = btn.dataset.id;
						const select = tbody.querySelector(`.jp-skill-merge-target[data-id="${id}"]`);
						const targetId = select.value;
						if (!targetId) { showMsg('Choose a skill to merge "' + btn.dataset.name + '" into first.', false); return; }
						const targetName = select.options[select.selectedIndex].textContent;
						if (!confirm('Merge "' + btn.dataset.name + '" into "' + targetName + '"? All candidate links, assessment history, and assessment questions move to "' + targetName + '", and "' + btn.dataset.name + '" is then deleted. This cannot be undone.')) return;
						const res = await restCall('/' + id + '/merge', 'POST', { target_id: Number(targetId) });
						showMsg(res.message || (res.ok ? 'Merged.' : 'Merge failed (HTTP ' + res.status + ').'), res.ok);
						if (res.ok) loadSkills();
					});
				});
				tbody.querySelectorAll('.jp-skill-delete').forEach(btn => {
					btn.addEventListener('click', async () => {
						const id = btn.dataset.id;
						if (!confirm('Delete "' + btn.dataset.name + '"? If it is in use, this will ask for confirmation again with a force option that also deletes every candidate link, assessment, and assessment question tied to it.')) return;
						let res = await restCall('/' + id, 'DELETE');
						if (!res.ok && res.status === 409) {
							if (!confirm((res.message || 'This skill is in use.') + '\n\nForce-delete it and everything attached to it?')) return;
							res = await restCall('/' + id + '?force=1', 'DELETE');
						}
						showMsg(res.message || (res.ok ? 'Deleted.' : 'Delete failed (HTTP ' + res.status + ').'), res.ok);
						if (res.ok) loadSkills();
					});
				});
			}

			document.getElementById('jp-skill-add').addEventListener('click', async () => {
				const name = document.getElementById('jp-skill-name').value.trim();
				if (!name) { showMsg('Name is required.', false); return; }
				const res = await restCall('', 'POST', {
					name: name,
					category: document.getElementById('jp-skill-category').value.trim(),
				});
				showMsg(res.message || (res.ok ? 'Added.' : 'Add failed (HTTP ' + res.status + ').'), res.ok);
				if (res.ok) {
					document.getElementById('jp-skill-name').value = '';
					document.getElementById('jp-skill-category').value = '';
					loadSkills();
				}
			});

			loadSkills();
		})();
		</script>
		<?php
	}

	// ── AJAX handlers ─────────────────────────────────────────────────────────

	public function ajax_test_email(): void {
		check_ajax_referer('jp_general','nonce');
		if (!current_user_can('manage_options')) wp_die();
		$to   = sanitize_email($_POST['to']??get_option('admin_email'));
		$body = JP_Notifications::instance()->render_template('system_announcement',['name'=>'Admin','message'=>'This is a test email from JP Job Portal. If you received this, your email is configured correctly! ✅']);
		$sent = JP_Notifications::instance()->send_email($to,'Test Email from JP Job Portal',$body);
		wp_send_json_success(['message'=>$sent?'✅ Test email sent to '.$to:'❌ Send failed. Check SMTP settings.']);
	}

	public function ajax_gen_vapid(): void {
		check_ajax_referer('jp_general','nonce');
		if (!current_user_can('manage_options')) wp_die();
		$keys = JP_PWA::generate_vapid_keys();
		if (empty($keys)) { wp_send_json_error('OpenSSL EC key generation failed. Requires PHP OpenSSL extension.'); return; }
		update_option('jp_vapid_public_key',$keys['public']);
		update_option('jp_vapid_private_key',$keys['private']);
		wp_send_json_success(['message'=>'VAPID keys generated.','public'=>substr($keys['public'],0,20).'...']);
	}

	public function ajax_flush_cache(): void {
		check_ajax_referer('jp_general','nonce');
		if (!current_user_can('manage_options')) wp_die();
		JP_Cache::flush_all();
		wp_send_json_success(['message'=>'✅ All caches flushed successfully.']);
	}
}
