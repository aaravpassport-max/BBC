<?php
/**
 * Class JP_Queue — a real background job queue with retry/backoff and a
 * dead-letter state.
 *
 * ROOT CAUSE (see enterprise-gap-analysis.md P1: "No queue system anywhere
 * — all 'background' work is WP-Cron interval batch jobs with no
 * retry/backoff/dead-letter handling and no protection against WP-Cron's
 * known double-fire behavior under concurrent requests"): every piece of
 * "background" processing in this codebase (alert digests, view-count
 * flushing, match scoring, etc.) is a `foreach` loop running synchronously
 * inside a single WP-Cron HTTP request. A site with a large alert
 * subscriber base can therefore have its ENTIRE digest-send step time out
 * partway through, with the jobs already sent having no record and the
 * rest silently never sent — there is no per-item retry, no visibility
 * into what failed, and nothing stopping two near-simultaneous WP-Cron
 * fires (a well-documented WP-Cron behavior under concurrent traffic) from
 * both processing the same batch and double-sending.
 *
 * The gap analysis suggested adopting Action Scheduler (the established
 * WP-ecosystem library for exactly this). This sandbox's outbound network
 * access to packagist.org is blocked (see phase2-progress-report.md §3/§4
 * for the same limitation affecting PHPUnit), so that composer dependency
 * could not actually be fetched and vendored here. This class is a
 * deliberately minimal, dependency-free implementation of the same core
 * guarantees Action Scheduler provides — a real `jp_job_queue` table (not
 * an in-memory or transient-backed queue), atomic per-row claiming that
 * makes concurrent WP-Cron fires safe, exponential backoff, and a
 * dead-letter state after repeated failure — with a public API
 * (`enqueue()`) deliberately shaped close enough to Action Scheduler's
 * `as_schedule_single_action()` that swapping to the real library later,
 * if/when this environment's network access allows installing it, would
 * mean changing this one file's internals, not any of its call sites.
 */
defined( 'ABSPATH' ) || exit;

class JP_Queue {

	private static ?JP_Queue $instance = null;

	/** Exponential backoff (seconds) between retry attempts, capped by the cron's own polling interval. */
	private const BACKOFF_SCHEDULE = [ 30, 120, 600, 1800, 3600 ];

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'jp_process_job_queue', [ $this, 'process_batch' ] );
	}

	/**
	 * Queue a job. $hook is a normal WordPress action name — anything
	 * already registered with add_action($hook, $callback) can be enqueued
	 * without that callback needing to know it's being called from a queue
	 * rather than directly. $args are passed to do_action() as-is (must be
	 * JSON-serializable — no objects/resources).
	 *
	 * @return int|false the new job's row id, or false if the args could not be serialized.
	 */
	public function enqueue( string $hook, array $args = [], int $delay_seconds = 0, int $max_attempts = 5 ) {
		global $wpdb;
		$encoded = wp_json_encode( $args );
		if ( $encoded === false ) {
			error_log( "JP_Queue::enqueue(): args for hook '{$hook}' are not JSON-serializable — job not queued." );
			return false;
		}
		$table = $wpdb->prefix . 'jp_job_queue';
		$ok    = $wpdb->insert( $table, [
			'hook'          => $hook,
			'args_json'     => $encoded,
			'status'        => 'pending',
			'attempts'      => 0,
			'max_attempts'  => max( 1, $max_attempts ),
			'available_at'  => gmdate( 'Y-m-d H:i:s', time() + max( 0, $delay_seconds ) ),
			'created_at'    => current_time( 'mysql' ),
		] );
		return $ok ? $wpdb->insert_id : false;
	}

	/**
	 * Called every 5 minutes by JP_Cron::job_process_queue(). Atomically
	 * claims up to $limit due jobs, executes each via do_action(), and
	 * records the outcome. The claim step is what makes two overlapping
	 * WP-Cron fires safe: the UPDATE ... WHERE status = 'pending' only
	 * succeeds for rows no other process has already claimed — if two
	 * fires race, InnoDB's row-level locking on the UPDATE serializes them,
	 * and the second fire's WHERE clause simply matches nothing for rows
	 * the first already claimed. See the class docblock for why this
	 * exists (WP-Cron's documented double-fire behavior under concurrent
	 * requests).
	 */
	public function process_batch( int $limit = 20 ): void {
		global $wpdb;
		$table = $wpdb->prefix . 'jp_job_queue';
		$claim_token = wp_generate_password( 12, false );

		// Step 1: find candidate IDs (read-only, no lock implications yet).
		$candidate_ids = $wpdb->get_col( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE status = 'pending' AND available_at <= NOW() ORDER BY id ASC LIMIT %d",
			$limit
		) );
		if ( empty( $candidate_ids ) ) return;

		$ids_sql = implode( ',', array_map( 'intval', $candidate_ids ) );

		// Step 2: atomically claim — only rows STILL 'pending' actually flip.
		$wpdb->query(
			"UPDATE {$table} SET status = 'claimed', claimed_by = " . $wpdb->prepare( '%s', $claim_token ) . ", claimed_at = NOW()
			 WHERE id IN ({$ids_sql}) AND status = 'pending'"
		);

		// Step 3: fetch only what THIS process actually won the claim on.
		$jobs = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} WHERE claimed_by = %s AND status = 'claimed'", $claim_token
		) );

		foreach ( $jobs as $job ) {
			$this->execute_one( $job );
		}
	}

	private function execute_one( object $job ): void {
		global $wpdb;
		$table = $wpdb->prefix . 'jp_job_queue';
		$args  = json_decode( $job->args_json, true ) ?: [];

		try {
			if ( ! has_action( $job->hook ) ) {
				throw new \RuntimeException( "No handler registered for queued hook '{$job->hook}' — nothing to execute." );
			}
			do_action( $job->hook, ...array_values( $args ) );

			// Ghost-success / stuck-job fix: these status-transition writes
			// (completed/dead_letter/pending-for-retry) were all previously
			// unchecked. A row is only ever re-claimed by the poller above
			// while status='pending' — so if THIS write fails, the row is
			// stuck at status='claimed' forever: never retried, never
			// dead-lettered, and invisible (no error surfaces anywhere).
			// Logged here rather than retried in place, since retrying a
			// status-update inside its own failure handler risks the same
			// failure looping; a persistently-stuck 'claimed' row is now at
			// least discoverable via the error log instead of silent.
			$result = $wpdb->update( $table, [
				'status'       => 'completed',
				'completed_at' => current_time( 'mysql' ),
			], [ 'id' => $job->id ] );
			if ( false === $result && class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_job_queue mark-completed failed: ' . $wpdb->last_error ), 'JP_Queue::execute_one job_id=' . $job->id . ' hook=' . $job->hook );
			}

		} catch ( \Throwable $e ) {
			$attempts = (int) $job->attempts + 1;

			if ( $attempts >= (int) $job->max_attempts ) {
				$result = $wpdb->update( $table, [
					'status'     => 'dead_letter',
					'attempts'   => $attempts,
					'last_error' => mb_substr( $e->getMessage(), 0, 1000 ),
				], [ 'id' => $job->id ] );
				if ( false === $result && class_exists( 'JP_ErrorLog' ) ) {
					JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_job_queue mark-dead_letter failed: ' . $wpdb->last_error ), 'JP_Queue::execute_one job_id=' . $job->id . ' hook=' . $job->hook );
				}

				if ( class_exists( 'JP_Security' ) ) {
					JP_Security::instance()->audit(
						'job_queue_dead_letter', 'job_queue', (int) $job->id,
						"Job #{$job->id} (hook: {$job->hook}) failed permanently after {$attempts} attempts: " . $e->getMessage()
					);
				}
			} else {
				$delay = self::BACKOFF_SCHEDULE[ min( $attempts - 1, count( self::BACKOFF_SCHEDULE ) - 1 ) ];
				$result = $wpdb->update( $table, [
					'status'       => 'pending', // released back to the pool for the next poll
					'attempts'     => $attempts,
					'available_at' => gmdate( 'Y-m-d H:i:s', time() + $delay ),
					'last_error'   => mb_substr( $e->getMessage(), 0, 1000 ),
					'claimed_by'   => null,
				], [ 'id' => $job->id ] );
				if ( false === $result && class_exists( 'JP_ErrorLog' ) ) {
					JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_job_queue release-for-retry failed: ' . $wpdb->last_error ), 'JP_Queue::execute_one job_id=' . $job->id . ' hook=' . $job->hook );
				}
			}
		}
	}

	/**
	 * Admin-visible dead-letter queue — jobs that exhausted all retries.
	 * Previously there was nowhere for a permanently-failed background
	 * task to become visible at all; it would just never have run again.
	 */
	public function dead_letters( int $limit = 100 ): array {
		global $wpdb;
		$table = $wpdb->prefix . 'jp_job_queue';
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} WHERE status = 'dead_letter' ORDER BY id DESC LIMIT %d", $limit
		) ) ?: [];
	}

	/** Requeue a dead-letter job for one more attempt (admin action). */
	public function requeue( int $job_id ): bool {
		global $wpdb;
		$table = $wpdb->prefix . 'jp_job_queue';
		return (bool) $wpdb->update( $table, [
			'status'       => 'pending',
			'attempts'     => 0,
			'available_at' => current_time( 'mysql' ),
			'last_error'   => null,
		], [ 'id' => $job_id, 'status' => 'dead_letter' ] );
	}
}
