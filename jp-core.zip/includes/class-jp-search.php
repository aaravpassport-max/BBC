<?php
/**
 * Class JP_Search — Full implementation
 * MySQL FULLTEXT primary + Elasticsearch 8 optional accelerator.
 * Shared-hosting safe: ES falls back silently to MySQL when unavailable.
 */
defined( 'ABSPATH' ) || exit;

class JP_Search {

	private static ?JP_Search $instance = null;
	private mixed $es_client = null;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		$this->maybe_init_es();
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
		add_action( 'wp_ajax_nopriv_jp_autocomplete', [ $this, 'ajax_autocomplete' ] );
		add_action( 'wp_ajax_jp_autocomplete',        [ $this, 'ajax_autocomplete' ] );
	}

	// ── Elasticsearch optional init ──────────────────────────────────────────

	private function maybe_init_es(): void {
		$es_host = defined( 'JP_ES_HOST' ) ? JP_ES_HOST : '';
		if ( ! $es_host || ! class_exists( '\Elastic\Elasticsearch\ClientBuilder' ) ) return;
		try {
			$this->es_client = \Elastic\Elasticsearch\ClientBuilder::create()
				->setHosts( [ $es_host ] )->build();
		} catch ( \Throwable ) {
			$this->es_client = null;
		}
	}

	private function es_available(): bool {
		if ( ! $this->es_client ) return false;
		try { $this->es_client->ping(); return true; }
		catch ( \Throwable ) { return false; }
	}

	// ── Main entry point ─────────────────────────────────────────────────────

	/**
	 * @param array{keyword?:string,location?:string,job_type?:string,work_mode?:string,
	 *              industry?:string,exp?:int,sal_min?:int,sal_max?:int,skills?:array,
	 *              order_by?:string,order?:string,page?:int,per_page?:int,status?:string} $args
	 * @return array{jobs:array,total:int,pages:int,source:string}
	 */
	public function search( array $args = [] ): array {
		$args = wp_parse_args( $args, [
			'keyword' => '', 'location' => '', 'job_type' => '', 'work_mode' => '',
			'industry' => '', 'exp' => 0, 'sal_min' => 0, 'sal_max' => 0, 'skills' => [],
			'order_by' => 'created_at', 'order' => 'DESC',
			'page' => 1, 'per_page' => 20, 'status' => 'active',
		] );
		// Batch 27: dedicated multi-select AND-match skills filter, distinct
		// from the loose keyword full-text match against skills_json above.
		$args['skills'] = array_values( array_filter( array_map(
			static fn( $s ) => trim( (string) $s ), (array) $args['skills']
		) ) );

		if ( $args['keyword'] || $args['location'] ) $this->log( $args );

		if ( $this->es_available() && $args['keyword'] ) {
			$result = $this->search_es( $args );
			if ( $result !== null ) return $result;
		}
		return $this->search_mysql( $args );
	}

	// ── MySQL FULLTEXT ────────────────────────────────────────────────────────

	private function search_mysql( array $args ): array {
		global $wpdb;
		$tbl    = $wpdb->prefix . 'jp_jobs';
		$where  = [ "j.status = %s" ];
		$params = [ $args['status'] ];

		$relevance = '0 AS relevance_score';
		if ( $args['keyword'] ) {
			$kw        = esc_sql( $args['keyword'] );
			$relevance = "(MATCH(j.title,j.description,j.skills_json) AGAINST('{$kw}' IN BOOLEAN MODE)) AS relevance_score";
			$like      = '%' . $wpdb->esc_like( $args['keyword'] ) . '%';
			$where[]   = "(MATCH(j.title,j.description,j.skills_json) AGAINST(%s IN BOOLEAN MODE) OR j.title LIKE %s OR j.skills_json LIKE %s)";
			array_push( $params, $args['keyword'], $like, $like );
		}
		if ( $args['location'] ) {
			$like    = '%' . $wpdb->esc_like( $args['location'] ) . '%';
			$where[] = "(j.location_city LIKE %s OR j.location_state LIKE %s OR j.work_mode='remote')";
			array_push( $params, $like, $like );
		}
		if ( $args['job_type'] )  { $where[] = 'j.job_type=%s';  $params[] = $args['job_type'];  }
		if ( $args['work_mode'] ) { $where[] = 'j.work_mode=%s'; $params[] = $args['work_mode']; }
		if ( $args['industry'] )  { $where[] = '(j.industry_slug=%s OR j.industry=%s)'; $params[] = $args['industry']; $params[] = $args['industry']; }
		if ( $args['exp']>0 )     { $where[] = '(j.experience_min IS NULL OR j.experience_min<=%d)'; $params[] = (int)$args['exp']; }
		if ( $args['sal_min']>0 ) { $where[] = '(j.salary_max IS NULL OR j.salary_max>=%d)';       $params[] = (int)$args['sal_min']; }
		if ( $args['sal_max']>0 ) { $where[] = '(j.salary_min IS NULL OR j.salary_min<=%d)';       $params[] = (int)$args['sal_max']; }
		// Batch 27: AND-match — every requested skill must appear as a
		// quoted-substring in skills_json (avoids "Java" matching "JavaScript",
		// unlike the loose keyword LIKE above; one clause per skill => AND).
		foreach ( $args['skills'] as $skill ) {
			$where[] = 'j.skills_json LIKE %s';
			$params[] = '%"' . $wpdb->esc_like( $skill ) . '"%';
		}

		$wsql     = 'WHERE ' . implode( ' AND ', $where );
		$ob       = in_array( $args['order_by'], ['created_at','salary_max','views_count','applications_cnt','relevance_score'], true ) ? $args['order_by'] : 'created_at';
		$od       = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
		$per      = max( 1, min( 100, (int)$args['per_page'] ) );
		$offset   = ( max(1,(int)$args['page']) - 1 ) * $per;

		$total    = (int)$wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$tbl} j {$wsql}", ...$params ) );
		$jobs     = $wpdb->get_results( $wpdb->prepare(
			"SELECT j.*,c.name AS company_name,c.logo_url,c.is_verified AS company_verified,{$relevance}
			 FROM {$tbl} j LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id
			 {$wsql} ORDER BY j.is_featured DESC,{$ob} {$od} LIMIT %d OFFSET %d",
			...array_merge( $params, [ $per, $offset ] )
		) );

		return [ 'jobs' => $jobs ?: [], 'total' => $total, 'pages' => (int)ceil($total/$per), 'source' => 'mysql' ];
	}

	// ── Elasticsearch ─────────────────────────────────────────────────────────

	private function search_es( array $args ): ?array {
		try {
			$per    = max(1,min(100,(int)$args['per_page']));
			$offset = (max(1,(int)$args['page'])-1)*$per;
			$must   = [];
			$filter = [ ['term'=>['status'=>$args['status']]] ];

			if ( $args['keyword'] ) $must[] = ['multi_match'=>['query'=>$args['keyword'],'fields'=>['title^3','skills_json^2','description','company_name'],'type'=>'best_fields','fuzziness'=>'AUTO']];
			if ( $args['location'] ) $filter[] = ['bool'=>['should'=>[['match'=>['location_city'=>$args['location']]],['term'=>['work_mode'=>'remote']]]]];
			if ( $args['job_type'] )  $filter[] = ['term'=>['job_type'=>$args['job_type']]];
			if ( $args['work_mode'] ) $filter[] = ['term'=>['work_mode'=>$args['work_mode']]];
			if ( $args['industry'] )  $filter[] = ['term'=>['industry_slug'=>$args['industry']]];
			if ( $args['sal_min']>0 ) $filter[] = ['range'=>['salary_max'=>['gte'=>$args['sal_min']]]];
			if ( $args['sal_max']>0 ) $filter[] = ['range'=>['salary_min'=>['lte'=>$args['sal_max']]]];
			if ( $args['exp']>0 )     $filter[] = ['range'=>['experience_min'=>['lte'=>$args['exp']]]];
			// Batch 27: AND-match skills filter mirrors the MySQL path — one
			// match_phrase per skill inside bool.must guarantees all must match.
			foreach ( $args['skills'] as $skill ) {
				$must[] = ['match_phrase'=>['skills_json'=>$skill]];
			}

			$resp = $this->es_client->search([
				'index' => 'jp_jobs',
				'body'  => [
					'query' => ['bool'=>['must'=>$must?:[ ['match_all'=>(object)[]] ],'filter'=>$filter]],
					'sort'  => [['is_featured'=>'desc'],['_score'=>'desc']],
					'from'  => $offset, 'size' => $per,
				],
			]);

			$total = $resp['hits']['total']['value'] ?? 0;
			$ids   = array_column( array_column( $resp['hits']['hits']??[], '_source' ), 'id' );
			if ( empty($ids) ) return ['jobs'=>[],'total'=>0,'pages'=>0,'source'=>'elasticsearch'];

			global $wpdb;
			$id_list = implode(',', array_map('absint',$ids));
			$jobs    = $wpdb->get_results(
				"SELECT j.*,c.name AS company_name,c.logo_url,c.is_verified AS company_verified
				 FROM {$wpdb->prefix}jp_jobs j LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id
				 WHERE j.id IN({$id_list}) ORDER BY FIELD(j.id,{$id_list})"
			);
			return ['jobs'=>$jobs?:[],'total'=>$total,'pages'=>(int)ceil($total/$per),'source'=>'elasticsearch'];
		} catch ( \Throwable $e ) {
			error_log('[JP_Search ES] '.$e->getMessage());
			return null;
		}
	}

	// ── Logging ───────────────────────────────────────────────────────────────

	public function log( array $args ): void {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix.'jp_search_log', [
			'user_id'      => get_current_user_id() ?: null,
			'query'        => sanitize_text_field($args['keyword']),
			'location'     => sanitize_text_field($args['location']),
			'filters_json' => wp_json_encode( array_intersect_key($args,array_flip(['job_type','work_mode','industry','exp','sal_min','sal_max','skills'])) ),
			'ip'           => class_exists('JP_Security') ? JP_Security::instance()->get_ip() : sanitize_text_field($_SERVER['REMOTE_ADDR']??''),
			'created_at'   => current_time('mysql'),
		], ['%d','%s','%s','%s','%s','%s'] );
	}

	// ── Autocomplete ──────────────────────────────────────────────────────────

	public function ajax_autocomplete(): void {
		$q    = sanitize_text_field( wp_unslash($_GET['q']??'') );
		$type = sanitize_key( $_GET['type']??'jobs' );
		if ( strlen($q) < 2 ) wp_send_json_success([]);
		wp_send_json_success( $this->suggest($q,$type) );
	}

	public function suggest( string $q, string $type='jobs' ): array {
		global $wpdb;
		$like = '%'.$wpdb->esc_like($q).'%';
		if ( $type === 'companies' ) {
			return $wpdb->get_results( $wpdb->prepare( "SELECT id,name AS label,logo_url FROM {$wpdb->prefix}jp_companies WHERE name LIKE %s AND status='active' ORDER BY jobs_count DESC LIMIT 8",$like) ) ?: [];
		} elseif ( $type === 'skills' ) {
			return $wpdb->get_results( $wpdb->prepare( "SELECT id,name AS label,jobs_count FROM {$wpdb->prefix}jp_skills WHERE name LIKE %s ORDER BY jobs_count DESC LIMIT 10",$like) ) ?: [];
		} elseif ( $type === 'cities' ) {
			return $wpdb->get_results( $wpdb->prepare( "SELECT DISTINCT location_city AS label,COUNT(*) AS job_count FROM {$wpdb->prefix}jp_jobs WHERE location_city LIKE %s AND status='active' GROUP BY location_city ORDER BY job_count DESC LIMIT 8",$like) ) ?: [];
		} else {
			return $wpdb->get_results( $wpdb->prepare( "SELECT j.id,j.title AS label,j.slug,c.name AS company_name FROM {$wpdb->prefix}jp_jobs j LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id WHERE (j.title LIKE %s OR j.skills_json LIKE %s) AND j.status='active' ORDER BY j.views_count DESC LIMIT 8",$like,$like) ) ?: [];
		}
	}

	// ── REST routes ───────────────────────────────────────────────────────────

	public function register_routes(): void {
		$cb = '__return_true';
		$ns = JP_Api::namespace_str(); // Batch 31: was hardcoded 'jp/v1' (x2)
		register_rest_route($ns,'/search/suggest',['methods'=>'GET','callback'=>fn($r)=>rest_ensure_response($this->suggest(sanitize_text_field($r->get_param('q')??''),sanitize_key($r->get_param('type')??'jobs'))),'permission_callback'=>$cb]);
		register_rest_route($ns,'/search/cities', ['methods'=>'GET','callback'=>fn($r)=>rest_ensure_response($this->suggest(sanitize_text_field($r->get_param('q')??''),'cities')),'permission_callback'=>$cb]);
	}

	// ── ES index management (called by cron) ──────────────────────────────────

	public function index_job( int $id ): void {
		if ( !$this->es_available() ) return;
		global $wpdb;
		$job = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_jobs WHERE id=%d",$id) );
		if ( !$job ) return;
		try { $this->es_client->index(['index'=>'jp_jobs','id'=>$id,'body'=>(array)$job]); }
		catch(\Throwable $e){ error_log('[JP_Search] ES index job '.$id.': '.$e->getMessage()); }
	}

	public function delete_job( int $id ): void {
		if ( !$this->es_available() ) return;
		try { $this->es_client->delete(['index'=>'jp_jobs','id'=>$id]); } catch(\Throwable){}
	}

	public function bulk_reindex(): int {
		if ( !$this->es_available() ) return 0;
		global $wpdb;
		$ids = $wpdb->get_col("SELECT id FROM {$wpdb->prefix}jp_jobs WHERE status='active'");
		foreach($ids as $id) $this->index_job((int)$id);
		return count($ids);
	}
}
