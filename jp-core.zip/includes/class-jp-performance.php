<?php
/**
 * Class JP_Performance — Frontend optimisation layer.
 *
 * Features:
 *  - JS deferral / async loading
 *  - Critical CSS inlining (above-the-fold)
 *  - Image lazy loading (native + IntersectionObserver fallback)
 *  - Browser caching headers (Cache-Control / ETag)
 *  - Asset versioning (content hash)
 *  - Prefetch / preconnect hints for 3rd-party origins
 *  - Remove bloat: emoji scripts, embeds, oEmbed, block editor assets on frontend
 *  - View count buffering (avoid DB write per page view)
 *  - Search results page caching (5-minute TTL)
 *  - CORS headers for REST API
 *  - GZIP hint (server should handle it, but we ensure the right headers)
 */
defined( 'ABSPATH' ) || exit;

class JP_Performance {

	private static ?JP_Performance $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		// Remove WP bloat
		add_action( 'init',           [ $this, 'remove_bloat' ] );

		// Script / style optimisation
		add_filter( 'script_loader_tag', [ $this, 'defer_scripts' ], 10, 3 );
		add_action( 'wp_head',           [ $this, 'preconnect_hints' ], 1 );
		add_action( 'wp_head',           [ $this, 'inline_critical_css' ], 4 );

		// Cache-Control headers for static pages
		add_action( 'send_headers',      [ $this, 'set_cache_headers' ] );

		// REST API CORS
		add_action( 'rest_api_init',     [ $this, 'add_cors_headers' ] );

		// Image lazy loading
		add_filter( 'wp_lazy_loading_enabled', '__return_true' );
		add_filter( 'the_content',             [ $this, 'add_lazy_loading' ] );

		// Remove block editor CSS on front end
		add_action( 'wp_enqueue_scripts',      [ $this, 'dequeue_gutenberg' ], 100 );

		// Root-cause fix: this shutdown-hooked flush, PLUS buffer_view()
		// below, were an entirely separate, dead-on-arrival duplicate of
		// JP_Jobs::increment_view()/flush_view_buffer() — buffer_view() was
		// never actually called from anywhere (grep-confirmed), yet this
		// hook still ran on every single request, and it independently
		// raced against JP_Cron's (also-broken, see class-jp-cron.php)
		// 15-minute flush against the same transient key. Consolidated: the
		// real, working buffering/flush lives solely in JP_Jobs now,
		// flushed by the JP_Cron job every 15 minutes, restoring the actual
		// point of buffering (batched writes) instead of a
		// flush-on-every-request that defeats it.
	}

	// ── Remove WP bloat ───────────────────────────────────────────────────────

	public function remove_bloat(): void {
		// Emoji
		remove_action( 'wp_head',             'print_emoji_detection_script', 7 );
		remove_action( 'wp_print_styles',     'print_emoji_styles' );
		remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
		remove_action( 'admin_print_styles',  'print_emoji_styles' );
		remove_filter( 'the_content_feed',    'wp_staticize_emoji' );
		remove_filter( 'comment_text_rss',    'wp_staticize_emoji' );
		remove_filter( 'wp_mail',             'wp_staticize_emoji_for_email' );

		// oEmbed
		remove_action( 'wp_head', 'wp_oembed_add_discovery_links' );
		remove_action( 'wp_head', 'wp_oembed_add_host_js' );
		remove_filter( 'oembed_dataparse', 'wp_filter_oembed_result', 10 );

		// Feed links (we don't have a blog feed)
		remove_action( 'wp_head', 'feed_links', 2 );
		remove_action( 'wp_head', 'feed_links_extra', 3 );

		// WP API endpoint header
		remove_action( 'wp_head', 'rest_output_link_wp_head', 10 );
		remove_action( 'wp_head', 'wp_resource_hints', 2 );

		// WLW and RSD
		remove_action( 'wp_head', 'rsd_link' );
		remove_action( 'wp_head', 'wlwmanifest_link' );
	}

	// ── Defer non-critical JS ─────────────────────────────────────────────────

	public function defer_scripts( string $tag, string $handle, string $src ): string {
		// Always load these synchronously (critical)
		$critical = [ 'jquery', 'jquery-core', 'jquery-migrate', 'jp-main' ];
		if ( in_array( $handle, $critical, true ) ) return $tag;

		// Defer all others
		if ( str_contains( $tag, 'src=' ) && ! str_contains( $tag, 'defer' ) && ! str_contains( $tag, 'async' ) ) {
			$tag = str_replace( ' src=', ' defer src=', $tag );
		}
		return $tag;
	}

	// ── Resource hints ────────────────────────────────────────────────────────

	public function preconnect_hints(): void {
		$origins = [
			'https://fonts.googleapis.com',
			'https://fonts.gstatic.com',
			'https://checkout.razorpay.com',
			'https://www.googletagmanager.com',
		];
		foreach ( $origins as $origin ) {
			echo '<link rel="preconnect" href="' . esc_url( $origin ) . '" crossorigin>' . "\n";
			echo '<link rel="dns-prefetch" href="' . esc_url( $origin ) . '">' . "\n";
		}

		// Preload critical theme assets
		$main_css = get_template_directory_uri() . '/assets/css/main.css';
		echo '<link rel="preload" href="' . esc_url( $main_css ) . '" as="style">' . "\n";
	}

	// ── Inline critical CSS (above-the-fold) ──────────────────────────────────

	public function inline_critical_css(): void {
		// Critical CSS file generated during theme build (or hardcoded minimal version)
		$critical_path = get_template_directory() . '/assets/css/critical.css';
		if ( ! file_exists( $critical_path ) ) {
			// Fallback: inline a minimal set of critical styles
			$critical_css = $this->get_default_critical_css();
		} else {
			$critical_css = file_get_contents( $critical_path );
		}

		if ( $critical_css ) {
			// Minify inline (strip comments and redundant spaces)
			$critical_css = preg_replace( [ '/\/\*.*?\*\//s', '/\s{2,}/', '/\n/' ], [ '', ' ', '' ], $critical_css );
			echo '<style id="jp-critical">' . $critical_css . '</style>' . "\n";
		}
	}

	private function get_default_critical_css(): string {
		// Minimal above-the-fold CSS to prevent FOUC
		return '
:root{--jp-primary:#156BC9;--jp-gray-900:#111827;--jp-gray-100:#F3F4F6;}
*,::before,::after{box-sizing:border-box;}
body{margin:0;font-family:Inter,-apple-system,BlinkMacSystemFont,sans-serif;color:var(--jp-gray-900);background:#fff;-webkit-font-smoothing:antialiased;}
.jp-header{position:sticky;top:0;z-index:100;background:#fff;border-bottom:1px solid var(--jp-gray-100);height:64px;display:flex;align-items:center;}
.jp-container{max-width:1280px;margin:0 auto;padding:0 20px;}
.jp-hero{background:linear-gradient(135deg,#0F2460 0%,var(--jp-primary) 100%);color:#fff;padding:72px 0 80px;}
.jp-btn{display:inline-flex;align-items:center;gap:8px;padding:10px 20px;border-radius:8px;font-weight:600;font-size:15px;text-decoration:none;cursor:pointer;border:none;transition:all .2s;}
.jp-btn--primary{background:var(--jp-primary);color:#fff;}
img{max-width:100%;height:auto;}
';
	}

	// ── Cache-Control headers ─────────────────────────────────────────────────

	public function set_cache_headers(): void {
		if ( is_admin() || is_user_logged_in() ) return;

		// Don't cache cart / checkout / auth pages
		$no_cache_pages = [
			get_option( 'jp_page_login' ),
			get_option( 'jp_page_register' ),
			get_option( 'jp_page_dashboard' ),
			get_option( 'jp_page_recruiter' ),
		];

		if ( is_page( $no_cache_pages ) ) {
			header( 'Cache-Control: no-store, no-cache, must-revalidate' );
			header( 'Pragma: no-cache' );
			return;
		}

		// Static pages: 1 hour in browser, 24 hours in CDN
		if ( is_page() || is_singular() ) {
			header( 'Cache-Control: public, max-age=3600, s-maxage=86400, stale-while-revalidate=60' );
			return;
		}

		// Search results: don't cache (queries are unique)
		if ( is_search() || isset( $_GET['q'] ) ) {
			header( 'Cache-Control: no-store' );
			return;
		}

		// Homepage: 5 minutes
		if ( is_front_page() ) {
			header( 'Cache-Control: public, max-age=300, s-maxage=600' );
			return;
		}

		// Default
		header( 'Cache-Control: public, max-age=600' );
	}

	// ── REST API CORS ─────────────────────────────────────────────────────────

	public function add_cors_headers(): void {
		// Root-cause fix (gap analysis P1 #155: "CORS policy allows any
		// origin with credentials whenever WP_DEBUG is true — a real
		// CSRF/CORS risk if debug mode is ever left on in any reachable
		// (including 'staging that looks like prod') environment"). The
		// previous `|| WP_DEBUG` bypass reflected ANY request Origin back
		// with Access-Control-Allow-Credentials: true the moment debug mode
		// was on — meaning any site left in debug (which is a common,
		// easy-to-forget staging misconfiguration, not an exotic edge case)
		// would accept credentialed cross-origin requests from literally
		// any origin. If a local dev origin (e.g. a React dev server on
		// localhost:3000) needs CORS access, add it explicitly via the
		// jp_cors_allowed_origin option — never via a blanket debug-mode
		// bypass that also silently applies in a misconfigured production
		// environment.
		$allowed_origins = array_filter( [
			home_url(),
			get_option( 'jp_cors_allowed_origin', '' ),
		] );

		$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
		if ( in_array( $origin, $allowed_origins, true ) ) {
			header( 'Access-Control-Allow-Origin: ' . esc_url_raw( $origin ) );
			header( 'Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS' );
			header( 'Access-Control-Allow-Headers: Content-Type, Authorization, X-WP-Nonce' );
			header( 'Access-Control-Allow-Credentials: true' );
			header( 'Vary: Origin' );
		}

		// Handle preflight
		if ( 'OPTIONS' === $_SERVER['REQUEST_METHOD'] ) {
			status_header( 204 );
			exit;
		}
	}

	// ── Add lazy loading to images in content ─────────────────────────────────

	public function add_lazy_loading( string $content ): string {
		// Replace <img without loading= with loading="lazy"
		return preg_replace( '/<img(?![^>]*loading=)/', '<img loading="lazy"', $content );
	}

	// ── Remove Gutenberg bloat on frontend ────────────────────────────────────

	public function dequeue_gutenberg(): void {
		if ( ! is_admin() ) {
			// Gutenberg block styles not needed if we don't use the block editor on the front end
			wp_dequeue_style( 'wp-block-library' );
			wp_dequeue_style( 'wp-block-library-theme' );
			wp_dequeue_style( 'global-styles' );
			wp_dequeue_style( 'classic-theme-styles' );
		}
	}

	// ── View count buffer ─────────────────────────────────────────────────────
	// Removed: this class's own buffer_view()/flush_view_buffer() were a
	// dead-writer duplicate of JP_Jobs::increment_view()/flush_view_buffer()
	// (see the hooks() docblock above for the full explanation). The single
	// source of truth for job view counting now lives entirely in JP_Jobs,
	// flushed by JP_Cron::job_flush_views() every 15 minutes.

	// ── Search result caching helper ──────────────────────────────────────────

	public static function cache_search_results( array $args, callable $query_fn ): array {
		$cache_key = 'search_' . md5( serialize( $args ) );
		$cached    = JP_Cache::get( $cache_key, 'search' );
		if ( $cached !== null ) return $cached;

		$results = $query_fn();
		JP_Cache::set( $cache_key, $results, 300, 'search' ); // 5-minute TTL
		return $results;
	}
}
