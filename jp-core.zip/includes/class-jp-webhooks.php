<?php
/**
 * Class JP_Webhooks — actually dispatches the webhooks the admin UI has
 * always let people configure.
 *
 * ROOT CAUSE (see enterprise-gap-analysis.md §0, P0 item "webhooks
 * configurable but never dispatched"): the admin REST endpoints
 * (class-jp-api.php admin_webhook_*) have always supported full CRUD and a
 * manual "test send" button. Subscriptions originally lived in a single
 * `jp_webhooks` option (since moved to a real table per P1 #139 — see
 * class-jp-activator.php). But nothing in the codebase ever called
 * `do_action()` for a real platform event and had a listener translate that
 * into an actual HTTP delivery — the do_action() calls themselves exist
 * (jp_application_submitted, jp_stage_changed, jp_job_created,
 * jp_payment_completed) and always have, they just had no subscriber. A
 * config screen that silently does nothing is worse than no config screen
 * at all, because it actively misleads an admin into believing an
 * integration is live.
 *
 * This class is that subscriber. It:
 *   - Hooks all four known platform events and calls dispatch() for each
 *     configured, active webhook subscribed to that event.
 *   - Validates the target URL against an SSRF allowlist BEFORE saving a
 *     new webhook (class-jp-api.php::admin_webhook_create() now calls
 *     JP_Webhooks::is_safe_target_url() — previously: no check at all,
 *     meaning an admin, or an attacker with admin-panel access via a CSRF
 *     bug elsewhere, could point a "webhook" at http://169.254.169.254/ or
 *     an internal service and use this feature as an SSRF pivot).
 *   - Writes one row per delivery ATTEMPT to jp_webhook_deliveries (a real
 *     table, not another single option) so delivery history/failures are
 *     actually visible to an admin instead of vanishing.
 *   - Retries failed deliveries with exponential backoff via WP-Cron
 *     (JP_Cron::job_retry_webhooks(), every 15 minutes) up to a fixed
 *     attempt cap, so a target being briefly down doesn't silently drop
 *     the event forever.
 */
defined( 'ABSPATH' ) || exit;

class JP_Webhooks {

	private static ?JP_Webhooks $instance = null;

	/** Event name => do_action() argument signature, for dispatch() to build payloads from. */
	private const KNOWN_EVENTS = [
		'jp_application_submitted',
		'jp_stage_changed',
		'jp_job_created',
		'jp_payment_completed',
	];

	/** Max delivery attempts before a delivery is left permanently 'failed'. */
	private const MAX_ATTEMPTS = 6;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'jp_application_submitted', [ $this, 'on_application_submitted' ], 20, 3 );
		add_action( 'jp_stage_changed',          [ $this, 'on_stage_changed' ], 20, 4 );
		add_action( 'jp_job_created',            [ $this, 'on_job_created' ], 20, 3 );
		add_action( 'jp_payment_completed',      [ $this, 'on_payment_completed' ], 20, 1 );
	}

	// ── Event listeners — translate each platform event into a dispatch() call ──

	public function on_application_submitted( $app_id, $job_id, $user_id ): void {
		$this->dispatch( 'jp_application_submitted', [
			'application_id' => (int) $app_id,
			'job_id'         => (int) $job_id,
			'user_id'        => (int) $user_id,
		] );
	}

	public function on_stage_changed( $app_id, $from_stage, $to_stage, $changed_by ): void {
		$this->dispatch( 'jp_stage_changed', [
			'application_id' => (int) $app_id,
			'from_stage'     => (string) $from_stage,
			'to_stage'       => (string) $to_stage,
			'changed_by'     => (int) $changed_by,
		] );
	}

	public function on_job_created( $job_id, $insert, $posted_by ): void {
		$this->dispatch( 'jp_job_created', [
			'job_id'    => (int) $job_id,
			'posted_by' => (int) $posted_by,
		] );
	}

	public function on_payment_completed( $data ): void {
		// $data may be an array or object depending on the caller; normalize.
		$data = is_object( $data ) ? get_object_vars( $data ) : (array) $data;
		$this->dispatch( 'jp_payment_completed', $data );
	}

	// ── Core dispatch ────────────────────────────────────────────────────────

	/**
	 * Deliver $payload to every active webhook subscribed to $event.
	 * Writes one jp_webhook_deliveries row per subscriber, synchronously
	 * attempting delivery once; failures are picked up by the retry cron.
	 */
	public function dispatch( string $event, array $payload ): void {
		// Root-cause fix (gap analysis P1 #139): subscriptions now live in
		// the jp_webhooks table (see class-jp-activator.php), not a single
		// serialized option — see class-jp-api.php's admin_webhook_* CRUD
		// methods for the full explanation of why.
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_webhooks WHERE active=1 AND events_json LIKE %s",
			'%' . $wpdb->esc_like( wp_json_encode( $event ) ) . '%'
		) );
		if ( empty( $rows ) ) return;

		foreach ( $rows as $row ) {
			$events = json_decode( $row->events_json ?: '[]', true ) ?: [];
			if ( ! in_array( $event, $events, true ) ) continue; // LIKE above is a cheap pre-filter, not authoritative

			$hook = [ 'id' => $row->id, 'url' => $row->url, 'secret' => $row->secret ];
			$this->attempt_delivery( $hook, $event, $payload, 1 );
		}
	}

	/**
	 * Perform (or retry) one delivery attempt and record its outcome.
	 */
	private function attempt_delivery( array $hook, string $event, array $payload, int $attempt, ?int $existing_row_id = null ): void {
		global $wpdb;
		$table = $wpdb->prefix . 'jp_webhook_deliveries';

		$body = wp_json_encode( [
			'event'     => $event,
			'timestamp' => time(),
			'data'      => $payload,
		] );
		$sig = hash_hmac( 'sha256', $body, $hook['secret'] ?? '' );

		$response = wp_remote_post( $hook['url'], [
			'body'    => $body,
			'headers' => [
				'Content-Type'    => 'application/json',
				'X-JP-Signature'  => "sha256={$sig}",
				'X-JP-Event'      => $event,
				'X-JP-Delivery-Attempt' => (string) $attempt,
			],
			'timeout' => 10,
		] );

		if ( is_wp_error( $response ) ) {
			$code          = 0;
			$response_body = $response->get_error_message();
		} else {
			$code          = (int) wp_remote_retrieve_response_code( $response );
			$response_body = wp_remote_retrieve_body( $response );
		}

		$delivered = ( $code >= 200 && $code < 300 );
		$status    = $delivered ? 'delivered' : ( $attempt >= self::MAX_ATTEMPTS ? 'failed' : 'pending' );
		$next_retry_at = ( ! $delivered && $status === 'pending' )
			? gmdate( 'Y-m-d H:i:s', time() + $this->backoff_seconds( $attempt ) )
			: null;

		$row = [
			'webhook_id'    => (string) $hook['id'],
			'event'         => $event,
			'payload_json'  => $body,
			'status'        => $status,
			'http_code'     => $code ?: null,
			'response_body' => mb_substr( (string) $response_body, 0, 2000 ),
			'attempt'       => $attempt,
			'next_retry_at' => $next_retry_at,
			'delivered_at'  => $delivered ? current_time( 'mysql' ) : null,
		];

		// Root-cause fix (batch 18): unchecked write. The underlying HTTP
		// delivery already happened (or failed) independent of this DB
		// row, but that row is also the ONLY thing retry_due_deliveries()
		// (called every 15 min by cron) queries to find pending retries —
		// a failed write here on a genuinely-failed delivery attempt means
		// next_retry_at never gets recorded, so that delivery would
		// silently never be picked up for retry again, with nothing
		// anywhere surfacing why an integration stopped receiving events.
		$write_ok = $existing_row_id
			? false !== $wpdb->update( $table, $row, [ 'id' => $existing_row_id ] )
			: false !== $wpdb->insert( $table, $row );
		if ( ! $write_ok && class_exists( 'JP_ErrorLog' ) ) {
			JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_webhook_deliveries write failed: ' . $wpdb->last_error ), 'JP_Webhooks::dispatch webhook_id=' . $hook['id'] . ' event=' . $event );
		}

		if ( ! $delivered && $status === 'failed' ) {
			// Exhausted retries — surface it in the audit trail so an admin
			// investigating "why didn't my integration fire" has something
			// to find (previously: nothing anywhere would have told them).
			if ( class_exists( 'JP_Security' ) ) {
				JP_Security::instance()->audit(
					'webhook_delivery_failed',
					'webhook',
					(int) ( $existing_row_id ?? $wpdb->insert_id ),
					sprintf( 'Webhook %s failed permanently after %d attempts for event %s (last HTTP %d)', $hook['id'], $attempt, $event, $code )
				);
			}
		}
	}

	/** Exponential backoff: 1min, 5min, 15min, 30min, 60min, 120min (capped by the every-15-min cron granularity). */
	private function backoff_seconds( int $attempt ): int {
		$schedule = [ 60, 300, 900, 1800, 3600, 7200 ];
		return $schedule[ min( $attempt - 1, count( $schedule ) - 1 ) ];
	}

	/**
	 * Called by JP_Cron::job_retry_webhooks() every 15 minutes. Picks up any
	 * delivery row still 'pending' whose next_retry_at has passed and
	 * re-attempts it, incrementing the attempt counter.
	 */
	public function retry_due_deliveries(): void {
		global $wpdb;
		$table = $wpdb->prefix . 'jp_webhook_deliveries';
		$due   = $wpdb->get_results(
			"SELECT * FROM {$table} WHERE status = 'pending' AND next_retry_at IS NOT NULL AND next_retry_at <= NOW() LIMIT 50"
		);
		if ( empty( $due ) ) return;

		foreach ( $due as $row ) {
			// Root-cause fix (gap analysis P1 #139): looked up in the
			// jp_webhooks table now, not a single serialized option — see
			// dispatch() above for the same change and why.
			$hook_row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_webhooks WHERE id=%s", $row->webhook_id ) );
			if ( ! $hook_row || ! $hook_row->active ) {
				// Webhook was deleted/deactivated since this delivery was queued.
				// Root-cause fix (batch 18): unchecked write. If this update
				// fails, the row is left at status='pending' with its
				// next_retry_at already in the past, so every subsequent
				// 15-minute cron run would pick it up again and re-run this
				// exact branch forever — a silent, permanent no-op retry loop
				// for a delivery that can never succeed (its webhook no
				// longer exists or is inactive). Logging on failure at least
				// surfaces that the cleanup itself is broken.
				if ( false === $wpdb->update( $table, [ 'status' => 'failed' ], [ 'id' => $row->id ] ) && class_exists( 'JP_ErrorLog' ) ) {
					JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_webhook_deliveries status update failed: ' . $wpdb->last_error ), 'JP_Webhooks::retry_due_deliveries delivery_id=' . $row->id );
				}
				continue;
			}
			$hook    = [ 'id' => $hook_row->id, 'url' => $hook_row->url, 'secret' => $hook_row->secret ];
			$decoded = json_decode( $row->payload_json, true );
			$payload = $decoded['data'] ?? [];
			$this->attempt_delivery( $hook, $row->event, $payload, (int) $row->attempt + 1, (int) $row->id );
		}
	}

	// ── SSRF protection ──────────────────────────────────────────────────────

	/**
	 * Validate a proposed webhook target URL before it is ever saved.
	 * Previously: no validation at all — an admin (or a CSRF-tricked admin
	 * session) could register a webhook pointed at a cloud metadata endpoint
	 * or any internal-network service and use the "test send" button (which
	 * fires an authenticated, server-side HTTP request with attacker-chosen
	 * headers/body) as an SSRF primitive.
	 *
	 * Rejects: non-http(s) schemes, missing host, loopback/private/
	 * link-local/reserved IP ranges (including when the hostname *resolves*
	 * to one — DNS rebinding), and the common cloud metadata hostnames.
	 */
	public static function is_safe_target_url( string $url ): bool {
		$parts = wp_parse_url( $url );
		if ( ! $parts || empty( $parts['host'] ) ) return false;
		if ( ! in_array( strtolower( $parts['scheme'] ?? '' ), [ 'http', 'https' ], true ) ) return false;

		$host = strtolower( $parts['host'] );

		// Known cloud metadata / internal-service hostnames — never allowed
		// regardless of what they currently resolve to.
		$blocked_hosts = [ 'metadata.google.internal', 'metadata.internal', 'localhost' ];
		if ( in_array( $host, $blocked_hosts, true ) ) return false;

		// Resolve the hostname (or accept it directly if it's already an IP)
		// and reject anything in a private/reserved/loopback/link-local
		// range — this is what stops both "http://127.0.0.1/" and DNS
		// rebinding a public-looking hostname to an internal IP.
		$ip = filter_var( $host, FILTER_VALIDATE_IP ) ? $host : gethostbyname( $host );
		if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) return false; // resolution failed — reject, don't guess

		$is_public = filter_var(
			$ip,
			FILTER_VALIDATE_IP,
			FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
		);

		return (bool) $is_public;
	}
}
