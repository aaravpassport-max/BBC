<?php
/**
 * Class JP_SEO — Full SEO layer for the job portal.
 *
 * Responsibilities:
 *  1. Dynamic <title> + meta description per job / company / search page
 *  2. JobPosting JSON-LD schema (Google rich results)
 *  3. Organization + WebSite + BreadcrumbList schema
 *  4. Open Graph + Twitter Card tags
 *  5. Canonical URLs
 *  6. XML sitemap (/sitemap.xml) — jobs, companies, static pages
 *  7. Hreflang placeholder (future multi-language)
 *  8. Programmatic SEO pages: /jobs-in-{city}/, /jobs-for-{skill}/
 *  9. Robots.txt customisation
 * 10. Google Analytics 4 integration (GA4 measurement ID stored in options)
 */
defined( 'ABSPATH' ) || exit;

class JP_SEO {

	private static ?JP_SEO $instance = null;
	private array $meta = [];

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		// Meta tags + schema injected into <head>
		add_action( 'wp_head',           [ $this, 'output_meta_tags' ], 1 );
		add_action( 'wp_head',           [ $this, 'output_schema' ], 2 );
		add_action( 'wp_head',           [ $this, 'output_ga4' ], 99 );

		// <title> tag override
		add_filter( 'pre_get_document_title', [ $this, 'document_title' ] );
		add_filter( 'document_title_separator', fn() => '|' );

		// Canonical
		add_action( 'wp_head', [ $this, 'output_canonical' ], 3 );

		// Sitemap
		add_action( 'init',              [ $this, 'register_sitemap_rewrite' ] );
		add_action( 'template_redirect', [ $this, 'serve_sitemap' ] );

		// Batch 31 (part 2) — outbound job feed for board syndication
		// (Indeed / ZipRecruiter / Google for Jobs style crawlers). This
		// is the OUTBOUND half of "job-board syndication" — publishing our
		// own already-public listings in a standard machine-readable
		// format anyone can pull. It does not attempt inbound ATS
		// integration (pulling jobs FROM a third-party ATS), which needs
		// a specific vendor's API credentials we don't have and is scoped
		// out — see class-jp-seo.php's serve_job_feed() docblock.
		add_action( 'init',              [ $this, 'register_job_feed_rewrite' ] );
		add_action( 'template_redirect', [ $this, 'serve_job_feed' ] );

		// Robots.txt
		add_filter( 'robots_txt', [ $this, 'custom_robots' ], 10, 2 );

		// Programmatic SEO pages (city/skill landing pages)
		add_action( 'init', [ $this, 'register_programmatic_rewrites' ] );
		add_filter( 'query_vars', [ $this, 'add_query_vars' ] );

		// Remove WP default <link rel="prev"/"next"> — we handle pagination ourselves
		remove_action( 'wp_head', 'adjacent_posts_rel_link_wp_head', 10 );
	}

	// ── Document title ────────────────────────────────────────────────────────

	public function document_title( string $title ): string {
		$site  = jp_site_name();
		$page  = get_query_var( 'jp_city' ) ? 'city' : ( get_query_var( 'jp_skill' ) ? 'skill' : '' );

		// Single job
		if ( is_singular( 'jp_job' ) ) {
			$job = $this->get_current_job();
			return $job ? "{$job->title} at {$job->company_name} | {$site}" : $title;
		}

		// Single company
		if ( is_singular( 'jp_company' ) ) {
			global $wpdb;
			$slug    = get_post_field( 'post_name', get_the_ID() );
			$company = $wpdb->get_row( $wpdb->prepare( "SELECT name,location FROM {$wpdb->prefix}jp_companies WHERE slug=%s", $slug ) );
			return $company ? "Jobs at {$company->name} | {$site}" : $title;
		}

		// Job search results
		if ( is_page( get_option( 'jp_page_job_search' ) ) ) {
			$q = sanitize_text_field( $_GET['q'] ?? '' );
			$l = sanitize_text_field( $_GET['location'] ?? '' );
			if ( $q && $l )   return "{$q} Jobs in {$l} | {$site}";
			if ( $q )          return "{$q} Jobs | {$site}";
			if ( $l )          return "Jobs in {$l} | {$site}";
			return "Browse All Jobs | {$site}";
		}

		// Programmatic city page
		if ( get_query_var( 'jp_city' ) ) {
			$city = ucwords( str_replace( '-', ' ', get_query_var( 'jp_city' ) ) );
			return "Jobs in {$city} | {$site}";
		}

		// Programmatic skill page
		if ( get_query_var( 'jp_skill' ) ) {
			$skill = ucwords( str_replace( '-', ' ', get_query_var( 'jp_skill' ) ) );
			return "{$skill} Jobs | {$site}";
		}

		return $title;
	}

	// ── Meta tags ─────────────────────────────────────────────────────────────

	public function output_meta_tags(): void {
		$desc = $this->get_meta_description();
		$og   = $this->get_og_data();

		if ( $desc ) {
			echo '<meta name="description" content="' . esc_attr( $desc ) . '">' . "\n";
		}

		// Open Graph
		echo '<meta property="og:title" content="' . esc_attr( $og['title'] ) . '">' . "\n";
		echo '<meta property="og:description" content="' . esc_attr( $og['description'] ) . '">' . "\n";
		echo '<meta property="og:type" content="' . esc_attr( $og['type'] ) . '">' . "\n";
		echo '<meta property="og:url" content="' . esc_url( $og['url'] ) . '">' . "\n";
		echo '<meta property="og:site_name" content="' . esc_attr( jp_site_name() ) . '">' . "\n";
		if ( $og['image'] ) {
			echo '<meta property="og:image" content="' . esc_url( $og['image'] ) . '">' . "\n";
			echo '<meta property="og:image:width" content="1200">' . "\n";
			echo '<meta property="og:image:height" content="630">' . "\n";
		}

		// Twitter Card
		echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
		echo '<meta name="twitter:title" content="' . esc_attr( $og['title'] ) . '">' . "\n";
		echo '<meta name="twitter:description" content="' . esc_attr( $og['description'] ) . '">' . "\n";
		if ( $og['image'] ) {
			echo '<meta name="twitter:image" content="' . esc_url( $og['image'] ) . '">' . "\n";
		}

		// Hreflang (placeholder for future i18n)
		echo '<link rel="alternate" hreflang="en" href="' . esc_url( $og['url'] ) . '">' . "\n";
		echo '<link rel="alternate" hreflang="x-default" href="' . esc_url( home_url( '/' ) ) . '">' . "\n";
	}

	private function get_meta_description(): string {
		if ( is_singular( 'jp_job' ) ) {
			$job = $this->get_current_job();
			if ( ! $job ) return '';
			$loc     = $job->work_mode === 'remote' ? 'Remote' : ( $job->location_city ?? '' );
			$salary  = $job->salary_min ? ' | ' . jp_format_salary( (int) $job->salary_min, (int) $job->salary_max ) : '';
			$snippet = mb_substr( wp_strip_all_tags( $job->description ?? '' ), 0, 120 );
			return "{$job->title} at {$job->company_name}. {$loc}{$salary}. {$snippet}";
		}

		if ( get_query_var( 'jp_city' ) ) {
			$city = ucwords( str_replace( '-', ' ', get_query_var( 'jp_city' ) ) );
			return "Browse thousands of job openings in {$city}. Apply online to top companies. Updated daily.";
		}

		if ( get_query_var( 'jp_skill' ) ) {
			$skill = ucwords( str_replace( '-', ' ', get_query_var( 'jp_skill' ) ) );
			return "Find the best {$skill} jobs. Apply to top companies hiring {$skill} professionals now.";
		}

		return get_bloginfo( 'description' );
	}

	private function get_og_data(): array {
		$site  = jp_site_name();
		$url   = home_url( $_SERVER['REQUEST_URI'] ?? '/' );
		$logo  = get_option( 'jp_og_default_image', '' );
		$desc  = $this->get_meta_description();

		if ( is_singular( 'jp_job' ) ) {
			$job = $this->get_current_job();
			return [
				'title'       => $job ? "{$job->title} at {$job->company_name}" : $site,
				'description' => $desc,
				'type'        => 'article',
				'url'         => $url,
				'image'       => ( isset($job->company_logo) ? $job->company_logo : $logo ),
			];
		}

		return [
			'title'       => get_the_title() ?: $site,
			'description' => $desc ?: get_bloginfo( 'description' ),
			'type'        => 'website',
			'url'         => $url,
			'image'       => $logo,
		];
	}

	// ── Canonical ─────────────────────────────────────────────────────────────

	public function output_canonical(): void {
		$canonical = $this->get_canonical();
		if ( $canonical ) {
			echo '<link rel="canonical" href="' . esc_url( $canonical ) . '">' . "\n";
		}
	}

	private function get_canonical(): string {
		if ( is_singular( 'jp_job' ) ) {
			$job = $this->get_current_job();
			return $job ? home_url( '/jobs/' . $job->slug . '/' ) : '';
		}
		if ( is_singular( 'jp_company' ) ) {
			$slug = get_post_field( 'post_name', get_the_ID() );
			return home_url( '/companies/' . $slug . '/' );
		}
		if ( is_front_page() ) return home_url( '/' );
		// Strip UTM and tracking params
		$url = home_url( parse_url( home_url( add_query_arg( [] ) ), PHP_URL_PATH ) ?? '/' );
		return $url;
	}

	// ── JSON-LD Schema ────────────────────────────────────────────────────────

	public function output_schema(): void {
		$schemas = [];

		// WebSite + SearchAction (sitelinks search box)
		$schemas[] = [
			'@context' => 'https://schema.org',
			'@type'    => 'WebSite',
			'name'     => jp_site_name(),
			'url'      => home_url( '/' ),
			'potentialAction' => [
				'@type'       => 'SearchAction',
				'target'      => [
					'@type'       => 'EntryPoint',
					'urlTemplate' => home_url( '/jobs/?q={search_term_string}' ),
				],
				'query-input' => 'required name=search_term_string',
			],
		];

		// Organization
		$schemas[] = $this->organization_schema();

		// Single job page: JobPosting
		if ( is_singular( 'jp_job' ) ) {
			$job_schema = $this->job_posting_schema();
			if ( $job_schema ) $schemas[] = $job_schema;
		}

		// Breadcrumb
		$breadcrumb = $this->breadcrumb_schema();
		if ( $breadcrumb ) $schemas[] = $breadcrumb;

		foreach ( $schemas as $schema ) {
			echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT ) . '</script>' . "\n";
		}
	}

	private function organization_schema(): array {
		return [
			'@context'    => 'https://schema.org',
			'@type'       => 'Organization',
			'name'        => jp_site_name(),
			'url'         => home_url( '/' ),
			'logo'        => get_option( 'jp_og_default_image', '' ),
			'sameAs'      => array_filter( [
				get_option( 'jp_social_twitter', '' ),
				get_option( 'jp_social_linkedin', '' ),
				get_option( 'jp_social_facebook', '' ),
			] ),
			'contactPoint' => [
				'@type'       => 'ContactPoint',
				'contactType' => 'customer support',
				'email'       => get_option( 'admin_email' ),
			],
		];
	}

	private function job_posting_schema(): ?array {
		$job = $this->get_current_job();
		if ( ! $job ) return null;

		$schema = [
			'@context'         => 'https://schema.org',
			'@type'            => 'JobPosting',
			'title'            => $job->title,
			'description'      => wp_strip_all_tags( $job->description ?? '' ),
			'datePosted'       => date( 'Y-m-d', strtotime( $job->created_at ) ),
			'validThrough'     => $job->expires_at ? date( 'Y-m-d', strtotime( $job->expires_at ) ) : date( 'Y-m-d', strtotime( '+60 days' ) ),
			'employmentType'   => $this->map_employment_type( $job->job_type ?? 'full-time' ),
			'hiringOrganization' => [
				'@type'  => 'Organization',
				'name'   => $job->company_name ?? jp_site_name(),
				'sameAs' => home_url( '/companies/' . ( $job->company_slug ?? '' ) . '/' ),
				'logo'   => $job->company_logo ?? '',
			],
			'jobLocation' => [
				'@type'   => 'Place',
				'address' => [
					'@type'           => 'PostalAddress',
					'addressLocality' => $job->location_city ?? '',
					'addressRegion'   => $job->location_state ?? '',
					'addressCountry'  => $job->location_country ?? 'IN',
				],
			],
			'url'          => home_url( '/jobs/' . $job->slug . '/' ),
			'identifier'   => [
				'@type' => 'PropertyValue',
				'name'  => jp_site_name(),
				'value' => 'JP-JOB-' . $job->id,
			],
		];

		// Work mode (remote/hybrid)
		if ( in_array( $job->work_mode, [ 'remote', 'hybrid' ], true ) ) {
			$schema['jobLocationType'] = 'TELECOMMUTE';
		}

		// Salary range
		if ( $job->salary_min || $job->salary_max ) {
			$schema['baseSalary'] = [
				'@type'    => 'MonetaryAmount',
				'currency' => 'INR',
				'value'    => [
					'@type'    => 'QuantitativeValue',
					'minValue' => (int) $job->salary_min,
					'maxValue' => (int) $job->salary_max ?: (int) $job->salary_min,
					'unitText' => 'YEAR',
				],
			];
		}

		// Skills
		if ( ! empty( $job->skills_json ) ) {
			$skills = json_decode( $job->skills_json, true );
			if ( $skills ) $schema['skills'] = implode( ', ', $skills );
		}

		// Education requirement
		if ( $job->education_level ?? '' ) {
			$schema['educationRequirements'] = [
				'@type'                 => 'EducationalOccupationalCredential',
				'credentialCategory'    => $job->education_level,
			];
		}

		// Experience requirement
		if ( $job->experience_min ?? 0 ) {
			$schema['experienceRequirements'] = [
				'@type'          => 'OccupationalExperienceRequirements',
				'monthsOfExperience' => (int) $job->experience_min * 12,
			];
		}

		return $schema;
	}

	private function breadcrumb_schema(): ?array {
		$items = [ [ 'name' => 'Home', 'url' => home_url( '/' ) ] ];

		if ( is_singular( 'jp_job' ) ) {
			$job = $this->get_current_job();
			$items[] = [ 'name' => 'Jobs',          'url' => home_url( '/jobs/' ) ];
			$items[] = [ 'name' => ( isset($job->title) ? $job->title : 'Job' ), 'url' => home_url( '/jobs/' . ( ( isset($job->slug) ? $job->slug : '' ) ) . '/' ) ];
		} elseif ( is_singular( 'jp_company' ) ) {
			$items[] = [ 'name' => 'Companies', 'url' => home_url( '/companies/' ) ];
			$items[] = [ 'name' => get_the_title(), 'url' => get_permalink() ];
		} elseif ( get_query_var( 'jp_city' ) ) {
			$city     = ucwords( str_replace( '-', ' ', get_query_var( 'jp_city' ) ) );
			$items[]  = [ 'name' => 'Jobs', 'url' => home_url( '/jobs/' ) ];
			$items[]  = [ 'name' => "Jobs in {$city}", 'url' => home_url( '/jobs-in-' . get_query_var( 'jp_city' ) . '/' ) ];
		} else {
			return null;
		}

		return [
			'@context'        => 'https://schema.org',
			'@type'           => 'BreadcrumbList',
			'itemListElement' => array_map( fn( $item, $pos ) => [
				'@type'    => 'ListItem',
				'position' => $pos + 1,
				'name'     => $item['name'],
				'item'     => $item['url'],
			], $items, array_keys( $items ) ),
		];
	}

	// ── XML Sitemap ───────────────────────────────────────────────────────────

	public function register_sitemap_rewrite(): void {
		add_rewrite_rule( '^sitemap\.xml$', 'index.php?jp_sitemap=1', 'top' );
		add_rewrite_rule( '^sitemap-jobs\.xml$', 'index.php?jp_sitemap=jobs', 'top' );
		add_rewrite_rule( '^sitemap-companies\.xml$', 'index.php?jp_sitemap=companies', 'top' );
	}

	public function add_query_vars( array $vars ): array {
		$vars[] = 'jp_sitemap';
		$vars[] = 'jp_city';
		$vars[] = 'jp_skill';
		$vars[] = 'jp_jobfeed';
		return $vars;
	}

	// ── Outbound job feed (board syndication, phase 1) ─────────────────────────

	/**
	 * Batch 31 (part 2). Serves /jobs-feed.xml in the standard Indeed XML
	 * job-feed schema (<source><publisher>.../<job>... — the same schema
	 * ZipRecruiter, Glassdoor and most ATS/board crawlers already know how
	 * to ingest, so this needs no per-board custom format). Root-caused
	 * against the SAME status filter the public site's own search already
	 * uses (`status = 'active'`, see class-jp-api.php's JP_Search::search_mysql()
	 * and this file's build_jobs_sitemap() for the two existing precedents)
	 * rather than inventing a second, possibly-divergent definition of
	 * "currently open" — a job the public /jobs page shows is exactly the
	 * set this feed shows, no more, no less.
	 *
	 * Salary is included ONLY when jp_jobs.salary_visible = 1, matching
	 * the same visibility rule the public job detail page already
	 * enforces (see class-jp-api.php's get_job()) — this feed must not
	 * leak a salary the recruiter explicitly chose to hide.
	 */
	public function register_job_feed_rewrite(): void {
		add_rewrite_rule( '^jobs-feed\.xml$', 'index.php?jp_jobfeed=1', 'top' );
	}

	public function serve_job_feed(): void {
		if ( '1' !== get_query_var( 'jp_jobfeed' ) ) return;

		header( 'Content-Type: application/xml; charset=utf-8' );
		nocache_headers();
		echo $this->build_job_feed();
		exit;
	}

	private function build_job_feed(): string {
		global $wpdb;
		$jobs = $wpdb->get_results(
			"SELECT j.id, j.title, j.slug, j.description, j.job_type, j.work_mode,
			        j.location_city, j.location_state, j.salary_min, j.salary_max,
			        j.salary_currency, j.salary_visible, j.created_at, j.updated_at,
			        c.name AS company_name, c.website AS company_website, c.logo_url AS company_logo
			 FROM {$wpdb->prefix}jp_jobs j
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id = j.company_id
			 WHERE j.status = 'active'
			 ORDER BY j.updated_at DESC
			 LIMIT 5000"
		);

		$site_name = jp_site_name();
		$site_url  = home_url( '/' );

		$out  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
		$out .= "<source>\n";
		$out .= '  <publisher>' . $this->cdata( $site_name ) . "</publisher>\n";
		$out .= '  <publisherurl>' . esc_url( $site_url ) . "</publisherurl>\n";
		$out .= '  <lastBuildDate>' . esc_html( gmdate( 'D, d M Y H:i:s' ) . ' GMT' ) . "</lastBuildDate>\n";

		foreach ( $jobs as $job ) {
			$job_url = home_url( '/jobs/' . $job->slug . '/' );
			$out    .= "  <job>\n";
			$out    .= '    <title>' . $this->cdata( $job->title ) . "</title>\n";
			$out    .= '    <date>' . esc_html( gmdate( 'D, d M Y H:i:s', strtotime( $job->created_at ) ) . ' GMT' ) . "</date>\n";
			$out    .= '    <referencenumber>' . esc_html( (string) $job->id ) . "</referencenumber>\n";
			$out    .= '    <url>' . esc_url( $job_url ) . "</url>\n";
			$out    .= '    <company>' . $this->cdata( $job->company_name ?: $site_name ) . "</company>\n";
			if ( $job->company_website ) {
				$out .= '    <companyurl>' . esc_url( $job->company_website ) . "</companyurl>\n";
			}
			if ( $job->location_city ) {
				$out .= '    <city>' . $this->cdata( $job->location_city ) . "</city>\n";
			}
			if ( $job->location_state ) {
				$out .= '    <state>' . $this->cdata( $job->location_state ) . "</state>\n";
			}
			$out .= '    <country>' . $this->cdata( $this->work_mode_country_hint( $job->work_mode ) ) . "</country>\n";
			$out .= '    <description>' . $this->cdata( wp_strip_all_tags( (string) $job->description ) ) . "</description>\n";
			$out .= '    <jobtype>' . $this->cdata( $this->feed_job_type_label( $job->job_type ) ) . "</jobtype>\n";
			if ( 'remote' === $job->work_mode ) {
				$out .= "    <remote>Yes</remote>\n";
			}
			// Batch 31: only emit salary when the recruiter left it visible —
			// same rule class-jp-api.php's get_job() already enforces for the
			// public job detail page (see this method's docblock).
			if ( (int) $job->salary_visible === 1 && ( (int) $job->salary_min > 0 || (int) $job->salary_max > 0 ) ) {
				$out .= '    <salary>' . esc_html( $this->feed_salary_text( $job ) ) . "</salary>\n";
			}
			$out .= "  </job>\n";
		}

		$out .= '</source>';
		return $out;
	}

	/** Indeed-schema CDATA wrapper — same escaping guarantee as esc_html() but keeps entities like & readable inside CDATA rather than double-encoding them. */
	private function cdata( ?string $value ): string {
		$value = (string) $value;
		// CDATA sections cannot contain the literal sequence "]]>" — split it if present.
		$safe = str_replace( ']]>', ']]&gt;', $value );
		return '<![CDATA[' . $safe . ']]>';
	}

	private function feed_job_type_label( ?string $job_type ): string {
		return match ( $job_type ) {
			'full-time'  => 'Full-Time',
			'part-time'  => 'Part-Time',
			'contract'   => 'Contract',
			'internship' => 'Internship',
			'freelance'  => 'Temporary',
			default      => 'Full-Time',
		};
	}

	/**
	 * The Indeed feed schema requires a <country> element with no
	 * equivalent column in jp_jobs (this plugin has no per-job country
	 * field — location_city/location_state only, and the site itself is
	 * India-focused per the Razorpay-INR-only gate in class-jp-payments.php).
	 * Defaults to India; a remote listing is still tagged with the site's
	 * home country since Indeed's schema has no separate "remote/global"
	 * value for this element.
	 */
	private function work_mode_country_hint( ?string $work_mode ): string {
		return 'IN';
	}

	private function feed_salary_text( object $job ): string {
		$currency = $job->salary_currency ?: 'INR';
		$min      = (int) $job->salary_min;
		$max      = (int) $job->salary_max;
		if ( $min > 0 && $max > 0 && $max !== $min ) {
			return "{$currency} {$min} - {$max}";
		}
		return $currency . ' ' . ( $max > 0 ? $max : $min );
	}

	public function serve_sitemap(): void {
		$type = get_query_var( 'jp_sitemap' );
		if ( ! $type ) return;

		header( 'Content-Type: application/xml; charset=utf-8' );
		header( 'X-Robots-Tag: noindex' );
		nocache_headers();

		switch ( $type ) {
			case '1':
				echo $this->build_sitemap_index();
				break;
			case 'jobs':
				echo $this->build_jobs_sitemap();
				break;
			case 'companies':
				echo $this->build_companies_sitemap();
				break;
		}
		exit;
	}

	private function sitemap_header(): string {
		return '<?xml version="1.0" encoding="UTF-8"?>' . "\n" .
		       '<?xml-stylesheet type="text/xsl" href="' . esc_url( home_url( '/sitemap-style.xsl' ) ) . '"?>' . "\n";
	}

	private function build_sitemap_index(): string {
		$home    = home_url( '/' );
		$date    = date( 'Y-m-d' );
		$sitemaps = [
			[ 'loc' => "{$home}sitemap-jobs.xml",      'lastmod' => $date ],
			[ 'loc' => "{$home}sitemap-companies.xml", 'lastmod' => $date ],
		];

		$out = $this->sitemap_header();
		$out .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
		foreach ( $sitemaps as $s ) {
			$out .= "  <sitemap><loc>{$s['loc']}</loc><lastmod>{$s['lastmod']}</lastmod></sitemap>\n";
		}
		$out .= '</sitemapindex>';
		return $out;
	}

	private function build_jobs_sitemap(): string {
		global $wpdb;
		$jobs = $wpdb->get_results( "SELECT slug, updated_at FROM {$wpdb->prefix}jp_jobs WHERE status='active' ORDER BY updated_at DESC LIMIT 5000" );

		$out = $this->sitemap_header();
		$out .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" ' .
		        'xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">' . "\n";
		$out .= "  <url><loc>" . esc_url( home_url( '/jobs/' ) ) . "</loc><changefreq>daily</changefreq><priority>0.9</priority></url>\n";

		foreach ( $jobs as $job ) {
			$loc     = esc_url( home_url( '/jobs/' . $job->slug . '/' ) );
			$lastmod = date( 'Y-m-d', strtotime( $job->updated_at ) );
			$out    .= "  <url><loc>{$loc}</loc><lastmod>{$lastmod}</lastmod><changefreq>weekly</changefreq><priority>0.8</priority></url>\n";
		}
		$out .= '</urlset>';
		return $out;
	}

	private function build_companies_sitemap(): string {
		global $wpdb;
		$companies = $wpdb->get_results( "SELECT slug, updated_at FROM {$wpdb->prefix}jp_companies WHERE status='active' ORDER BY jobs_count DESC LIMIT 2000" );

		$out = $this->sitemap_header();
		$out .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . "\n";
		$out .= "  <url><loc>" . esc_url( home_url( '/companies/' ) ) . "</loc><changefreq>daily</changefreq><priority>0.8</priority></url>\n";

		foreach ( $companies as $c ) {
			$loc     = esc_url( home_url( '/companies/' . $c->slug . '/' ) );
			$lastmod = date( 'Y-m-d', strtotime( $c->updated_at ) );
			$out    .= "  <url><loc>{$loc}</loc><lastmod>{$lastmod}</lastmod><changefreq>weekly</changefreq><priority>0.7</priority></url>\n";
		}
		$out .= '</urlset>';
		return $out;
	}

	// ── Programmatic SEO pages ────────────────────────────────────────────────

	public function register_programmatic_rewrites(): void {
		// /jobs-in-mumbai/ → ?jp_city=mumbai
		add_rewrite_rule( '^jobs-in-([a-z0-9\-]+)/?$', 'index.php?pagename=jobs&jp_city=$matches[1]', 'top' );
		// /jobs-for-developer/ or /developer-jobs/ → ?jp_skill=developer
		add_rewrite_rule( '^jobs-for-([a-z0-9\-]+)/?$', 'index.php?pagename=jobs&jp_skill=$matches[1]', 'top' );
		add_rewrite_rule( '^([a-z0-9\-]+)-jobs/?$',     'index.php?pagename=jobs&jp_skill=$matches[1]', 'top' );
	}

	// ── robots.txt ────────────────────────────────────────────────────────────

	public function custom_robots( string $output, bool $public ): string {
		if ( ! $public ) return $output;

		$home  = home_url( '/' );
		return "User-agent: *\n"
			. "Disallow: /wp-admin/\n"
			. "Disallow: /wp-login.php\n"
			. "Disallow: /my-account/\n"
			. "Disallow: /recruiter/\n"
			. "Disallow: /admin-panel/\n"
			. "Disallow: /wp-content/uploads/jp-files/\n"
			. "Disallow: /wp-content/uploads/jp-backups/\n"
			. "Disallow: /wp-json/jp/v1/admin/\n"
			. "Allow: /wp-admin/admin-ajax.php\n\n"
			. "Sitemap: {$home}sitemap.xml\n"
			. "Sitemap: {$home}sitemap-jobs.xml\n"
			. "Sitemap: {$home}sitemap-companies.xml\n";
	}

	// ── Google Analytics 4 ────────────────────────────────────────────────────

	public function output_ga4(): void {
		$ga4_id = get_option( 'jp_ga4_measurement_id', '' );
		if ( ! $ga4_id || is_user_logged_in() ) return; // Don't track logged-in users
		$id = esc_js( $ga4_id );
		echo <<<GA4
<script async src="https://www.googletagmanager.com/gtag/js?id={$id}"></script>
<script>
window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments);}
gtag('js',new Date());gtag('config','{$id}',{anonymize_ip:true});
</script>

GA4;
	}

	// ── Utilities ─────────────────────────────────────────────────────────────

	private function get_current_job(): ?object {
		if ( ! is_singular( 'jp_job' ) ) return null;

		$cache_key = 'seo_job_' . get_the_ID();
		$cached    = JP_Cache::get( $cache_key );
		if ( $cached ) return $cached;

		global $wpdb;
		$slug = get_post_field( 'post_name', get_the_ID() );
		$job  = $wpdb->get_row( $wpdb->prepare(
			"SELECT j.*,c.name AS company_name,c.logo_url AS company_logo,c.slug AS company_slug
			 FROM {$wpdb->prefix}jp_jobs j
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id
			 WHERE j.slug=%s",
			$slug
		) );

		if ( $job ) JP_Cache::set( $cache_key, $job, 900, 'seo' );
		return $job;
	}

	private function map_employment_type( string $type ): string {
		$map = [
			'full-time'  => 'FULL_TIME',
			'part-time'  => 'PART_TIME',
			'contract'   => 'CONTRACTOR',
			'internship' => 'INTERN',
			'freelance'  => 'TEMPORARY',
		];
		return $map[$type] ?? 'OTHER';
	}
}
