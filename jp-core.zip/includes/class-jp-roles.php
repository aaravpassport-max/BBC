<?php
defined( 'ABSPATH' ) || exit;

/**
 * JP_Roles — Registers all 6 custom user roles with their capabilities.
 */
class JP_Roles {

    private static ?JP_Roles $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // ── Called once on plugin activation ─────────────────────────────────────

    public static function create_roles(): void {
        // 1. Job Seeker
        add_role( 'jp_job_seeker', __( 'Job Seeker', 'jp-core' ), [
            'read'                   => true,
            'jp_apply_jobs'          => true,
            'jp_manage_profile'      => true,
            'jp_set_alerts'          => true,
            'jp_save_jobs'           => true,
            'jp_take_assessments'    => true,
            'jp_send_messages'       => true,
            'jp_upload_resume'       => true,
            'jp_build_resume'        => true,
            'jp_write_reviews'       => true,
            'jp_register_events'     => true,
        ] );

        // 2. Recruiter
        add_role( 'jp_recruiter', __( 'Recruiter', 'jp-core' ), [
            'read'                   => true,
            'jp_post_jobs'           => true,
            'jp_manage_own_jobs'     => true,
            'jp_view_applications'   => true,
            'jp_manage_pipeline'     => true,
            'jp_search_candidates'   => true,
            'jp_schedule_interviews' => true,
            'jp_send_messages'       => true,
            'jp_view_own_analytics'  => true,
            'jp_manage_company'      => true,
            'jp_use_ats'             => true,
        ] );

        // 3. Staff (moderator)
        add_role( 'jp_staff', __( 'Staff', 'jp-core' ), [
            'read'                   => true,
            'jp_moderate_content'    => true,
            'jp_approve_jobs'        => true,
            'jp_verify_profiles'     => true,
            'jp_view_support'        => true,
            'jp_edit_help_content'   => true,
            'jp_send_messages'       => true,
            'jp_view_reports'        => true,
        ] );

        // 4. Team Manager
        add_role( 'jp_team_manager', __( 'Team Manager', 'jp-core' ), [
            'read'                   => true,
            // All recruiter caps
            'jp_post_jobs'           => true,
            'jp_manage_own_jobs'     => true,
            'jp_view_applications'   => true,
            'jp_manage_pipeline'     => true,
            'jp_search_candidates'   => true,
            'jp_schedule_interviews' => true,
            'jp_send_messages'       => true,
            'jp_view_own_analytics'  => true,
            'jp_manage_company'      => true,
            'jp_use_ats'             => true,
            // Team manager extras
            'jp_manage_team'         => true,
            'jp_assign_jobs'         => true,
            'jp_view_team_analytics' => true,
            'jp_manage_team_jobs'    => true,
        ] );

        // 5. Admin Manager
        add_role( 'jp_admin_manager', __( 'Admin Manager', 'jp-core' ), [
            'read'                   => true,
            'jp_manage_users'        => true,
            'jp_approve_jobs'        => true,
            'jp_moderate_content'    => true,
            'jp_verify_companies'    => true,
            'jp_view_analytics'      => true,
            'jp_manage_blog'         => true,
            'jp_manage_events'       => true,
            'jp_manage_featured'     => true,
            'jp_view_revenue'        => true,
            'jp_manage_team'         => true,
            'jp_search_candidates'   => true,
            'jp_send_messages'       => true,
            'jp_view_reports'        => true,
            'jp_edit_help_content'   => true,
            // Platform-ops override used by JP_Applications::can_manage_application()
            // — an Admin Manager can act on any company's applications for
            // support/moderation purposes, distinct from a company's own
            // team membership (see JP_Team).
            'jp_manage_all_applications' => true,
            // WordPress content editing
            'edit_posts'             => true,
            'publish_posts'          => true,
            'edit_others_posts'      => true,
            'delete_posts'           => true,
            'manage_categories'      => true,
            'upload_files'           => true,
        ] );

        // 6. Super Admin (Administrator role already exists — just add JP caps)
        $admin_role = get_role( 'administrator' );
        if ( $admin_role ) {
            $admin_caps = [
                'jp_system_config', 'jp_manage_roles', 'jp_manage_plans',
                'jp_manage_email_templates', 'jp_view_audit_log', 'jp_manage_backups',
                'jp_impersonate_users', 'jp_export_data', 'jp_manage_security',
                'jp_manage_users', 'jp_approve_jobs', 'jp_moderate_content',
                'jp_verify_companies', 'jp_view_analytics', 'jp_manage_blog',
                'jp_manage_events', 'jp_manage_featured', 'jp_view_revenue',
                'jp_manage_team', 'jp_search_candidates', 'jp_send_messages',
                'jp_view_reports', 'jp_post_jobs', 'jp_manage_own_jobs',
                'jp_view_applications', 'jp_manage_pipeline', 'jp_use_ats',
                'jp_apply_jobs', 'jp_manage_profile', 'jp_view_team_analytics',
                'jp_manage_all_applications',
            ];
            foreach ( $admin_caps as $cap ) {
                $admin_role->add_cap( $cap );
            }
        }
    }

    /**
     * Batch 28 — custom RBAC (per-user capability overrides).
     *
     * The 6 fixed roles above cover the common cases, but "give this one
     * recruiter view-only access to team analytics without making them a
     * Team Manager" has no answer today short of editing PHP. Rather than
     * inventing a parallel role/permission-storage system, this layers on
     * top of WordPress's own per-user capability model: WP_User already
     * supports add_cap()/remove_cap() to grant/deny a specific capability
     * to one user regardless of their role, stored in the same usermeta
     * row as the role itself — no new table needed.
     *
     * Capabilities that gate irreversible or audit/security-critical
     * actions are deliberately NEVER overridable this way — granting
     * jp_manage_users (or jp_impersonate_users, jp_export_data, etc.) to
     * an arbitrary account via a capability checkbox would let a lower
     * role silently self-escalate to a shadow super-admin, defeating the
     * entire point of a *scoped* override. Only jp_admin_manager's own
     * explicit role assignment (admin_change_role()) or Administrator
     * grants those.
     */
    private const SUPER_ONLY_CAPS = [
        'jp_system_config', 'jp_manage_roles', 'jp_manage_plans',
        'jp_manage_email_templates', 'jp_view_audit_log', 'jp_manage_backups',
        'jp_impersonate_users', 'jp_export_data', 'jp_manage_security',
        'jp_manage_users', 'jp_manage_all_applications',
    ];

    /** The full canonical jp_* capability universe, sourced from the
     * administrator role's cap list above so this never drifts out of
     * sync with what the roles actually declare. */
    public static function all_jp_capabilities(): array {
        $admin_role = get_role( 'administrator' );
        if ( ! $admin_role ) return [];
        return array_values( array_filter(
            array_keys( $admin_role->capabilities ),
            static fn( $cap ) => str_starts_with( $cap, 'jp_' )
        ) );
    }

    /** Capabilities safe to grant/revoke on a per-user basis. */
    public static function overridable_capabilities(): array {
        return array_values( array_diff( self::all_jp_capabilities(), self::SUPER_ONLY_CAPS ) );
    }

    /** A role's own default jp_* capabilities (excludes anything a user
     * only has via an override), used so the admin UI can show which
     * checked boxes are "from the role" vs. an explicit override. */
    public static function role_default_caps( string $role ): array {
        $r = get_role( $role );
        if ( ! $r ) return [];
        return array_values( array_filter(
            array_keys( array_filter( $r->capabilities ) ),
            static fn( $cap ) => str_starts_with( $cap, 'jp_' )
        ) );
    }

    /**
     * Remove all JP roles (called on uninstall).
     */
    public static function remove_roles(): void {
        remove_role( 'jp_job_seeker' );
        remove_role( 'jp_recruiter' );
        remove_role( 'jp_staff' );
        remove_role( 'jp_team_manager' );
        remove_role( 'jp_admin_manager' );
    }

    /**
     * Redirect users to their correct dashboard after login.
     */
    public function __construct() {
        add_filter( 'login_redirect', [ $this, 'login_redirect' ], 10, 3 );
        add_filter( 'register_redirect', [ $this, 'register_redirect' ] );
    }

    public function login_redirect( string $redirect_to, string $requested_redirect, $user ): string {
        if ( is_wp_error( $user ) ) return $redirect_to;

        $role = jp_current_role();

        $map = [
            'administrator'      => admin_url(),
            'jp_admin_manager'   => home_url( '/admin-panel/' ),
            'jp_team_manager'    => home_url( '/recruiter/' ),
            'jp_staff'           => home_url( '/admin-panel/' ),
            'jp_recruiter'       => home_url( '/recruiter/' ),
            'jp_job_seeker'      => home_url( '/my-account/' ),
        ];

        return $map[ $role ] ?? home_url( '/' );
    }

    public function register_redirect( string $redirect_to ): string {
        return home_url( '/my-account/' );
    }
}
