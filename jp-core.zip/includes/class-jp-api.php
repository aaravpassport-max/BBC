<?php
/**
 * Class JP_Api — Full REST API under /wp-json/jp/v1/
 *
 * 30+ endpoints covering jobs, companies, candidates, applications,
 * search, alerts, messaging, reviews, analytics, and admin operations.
 *
 * Auth: WordPress cookie auth (for browser clients) + JWT for mobile/external.
 * Public read endpoints are open. Write/sensitive endpoints require auth.
 */
defined( 'ABSPATH' ) || exit;

class JP_Api {

	private static ?JP_Api $instance = null;

	/**
	 * Batch 31 — API versioning strategy, phase 1.
	 *
	 * This is the single source of truth for the REST namespace. Before
	 * this batch the literal string 'jp/v1' was duplicated across SIX
	 * other files that each registered their own routes directly
	 * (class-jp-react.php, class-jp-search.php x2, class-jp-pwa.php,
	 * class-jp-messaging.php, class-jp-diagnostics.php x2) instead of
	 * reading it from here — the exact "write-key vs read-key drift"
	 * failure class already seen in batch 11/21's config-key bugs. If a
	 * future v2 namespace bump only updated this constant, those six
	 * call sites would silently keep registering under the old 'jp/v1'
	 * while callers expecting a v2-only route would 404 — a split-brain
	 * API surface with no error, only confused support tickets. All six
	 * were switched to call JP_Api::namespace() (see below) instead of
	 * repeating the literal.
	 *
	 * Versioning policy going forward: this namespace changes ONLY on a
	 * breaking change (a removed/renamed field, a changed status code
	 * contract, a removed endpoint). Additive changes (new optional
	 * field, new endpoint, new optional query param) ship in place under
	 * the same namespace — see batches 27/28/30 for examples that did
	 * exactly this without a version bump. A genuine breaking change
	 * should register a NEW namespace (e.g. 'jp/v2') registered
	 * *alongside* this one — not replacing it — for a deprecation window,
	 * with the old routes' callbacks left intact until traffic on them is
	 * confirmed zero (see admin_get_capabilities()-style route additions
	 * for the pattern of adding without removing). The SPA never
	 * hardcodes a namespace string (see apiClient.ts's docblock) — it
	 * reads api_url from the /config endpoint at boot, so a namespace
	 * bump is a backend-and-config-only change once this constant is the
	 * only place that knows the string.
	 */
	private const NS = 'jp/v1';

	/** Public accessor so other classes never re-hardcode the namespace string. */
	public static function namespace_str(): string {
		return self::NS;
	}

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
		// Batch 31: surface the API version on every REST response so a
		// client (or a future diagnostics check) can detect a namespace
		// mismatch without guessing from the URL alone.
		add_filter( 'rest_pre_serve_request', [ $this, 'add_version_header' ], 10, 4 );

		// §37: jp-theme-fixed's ONLY candidate-facing profile-edit form
		// (tpl-dashboard-extended.php's #jp-profile-form, driven by
		// assets/js/dashboard.js's JPApp.profileSave) has always submitted
		// via the classic wp_ajax_jp_update_profile action, but no such
		// handler existed anywhere in jp-core — confirmed by a repo-wide
		// grep for "jp_update_profile" across every includes/*.php file
		// before this fix, which returned zero matches. The theme's own JS
		// carries a self-aware comment ("jp_update_profile AJAX action
		// should be wired in jp-core") and a .catch() fallback toast
		// admitting the same. This means the form — covering headline,
		// phone, location, about, career details, and (as of this fix)
		// skills — has never saved anything, ever, for any candidate.
		// ajax_update_profile() below bridges the classic-AJAX path into
		// the exact same apply_profile_update() logic the REST
		// PUT /candidates/me endpoint already uses, so the field whitelist
		// and skills-replace semantics are defined in exactly one place.
		add_action( 'wp_ajax_jp_update_profile', [ $this, 'ajax_update_profile' ] );
	}

	/**
	 * Batch 31: adds an X-JP-API-Version response header to every REST
	 * response served under this namespace. Purely observational — does
	 * not change status codes, bodies, or behavior for any existing
	 * caller — so it carries no regression risk to any prior batch.
	 * Only fires for requests actually routed to our namespace (checked
	 * via the request's route string) so it never touches unrelated
	 * WordPress REST traffic (core routes, other plugins' routes).
	 */
	public function add_version_header( $served, $result, $request, $server ) {
		if ( $request instanceof WP_REST_Request && str_starts_with( ltrim( (string) $request->get_route(), '/' ), self::NS . '/' ) ) {
			if ( ! headers_sent() ) {
				header( 'X-JP-API-Version: ' . self::NS );
			}
		}
		return $served;
	}

	// ── Register all routes ───────────────────────────────────────────────────

	public function register_routes(): void {
		$ns  = self::NS;
		$pub = '__return_true';                              // Public endpoint
		$auth = [ $this, 'require_auth' ];                  // Must be logged in
		$rec  = [ $this, 'require_recruiter' ];             // Recruiter or above
		$adm  = [ $this, 'require_admin' ];                 // Admin only

		// ── System ────────────────────────────────────────────────────────────
		register_rest_route( $ns, '/health', [
			'methods' => 'GET',
			'callback' => fn() => $this->ok( [ 'status' => 'ok', 'version' => JP_VERSION, 'time' => current_time( 'mysql' ) ] ),
			'permission_callback' => $pub,
		] );

		// ── Jobs ──────────────────────────────────────────────────────────────
		register_rest_route( $ns, '/jobs', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'get_jobs' ],    'permission_callback' => $pub ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'create_job' ],  'permission_callback' => $rec ],
		] );
		register_rest_route( $ns, '/jobs/(?P<id>\d+)', [
			[ 'methods' => 'GET',    'callback' => [ $this, 'get_job' ],    'permission_callback' => $pub ],
			[ 'methods' => 'PUT',    'callback' => [ $this, 'update_job' ], 'permission_callback' => $rec ],
			[ 'methods' => 'DELETE', 'callback' => [ $this, 'delete_job' ], 'permission_callback' => $rec ],
		] );
		register_rest_route( $ns, '/jobs/(?P<id>\d+)/similar', [
			'methods' => 'GET', 'callback' => [ $this, 'get_similar_jobs' ], 'permission_callback' => $pub,
		] );
		register_rest_route( $ns, '/jobs/(?P<id>\d+)/apply', [
			'methods' => 'POST', 'callback' => [ $this, 'apply_job' ], 'permission_callback' => $auth,
		] );

		// ── Companies ─────────────────────────────────────────────────────────
		register_rest_route( $ns, '/companies', [
			'methods' => 'GET', 'callback' => [ $this, 'get_companies' ], 'permission_callback' => $pub,
		] );
		register_rest_route( $ns, '/companies/(?P<id>\d+)', [
			[ 'methods' => 'GET', 'callback' => [ $this, 'get_company' ], 'permission_callback' => $pub ],
			[ 'methods' => 'PUT', 'callback' => [ $this, 'update_company' ], 'permission_callback' => $rec ],
		] );
		register_rest_route( $ns, '/companies/(?P<id>\d+)/jobs', [
			'methods' => 'GET', 'callback' => [ $this, 'get_company_jobs' ], 'permission_callback' => $pub,
		] );
		register_rest_route( $ns, '/companies/(?P<id>\d+)/reviews', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'get_company_reviews' ], 'permission_callback' => $pub ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'post_review' ],         'permission_callback' => $auth ],
		] );
		// Root-cause fix (batch 17): JP_Reviews::ajax_vote() ("mark this
		// review helpful", a plain non-deduplicated counter — matches its
		// own existing behavior, not a new dedup mechanism) has existed
		// with no REST route or SPA caller anywhere; CompanyDetailPage.tsx
		// has never shown a helpful_count or any control to increment it,
		// despite the real column existing and already being selected by
		// get_company_reviews()'s `r.*`. $pub since ajax_vote() itself
		// requires no login (unlike ajax_submit()/ajax_send() elsewhere in
		// this file, which do).
		register_rest_route( $ns, '/reviews/(?P<id>\d+)/vote-helpful', [
			'methods' => 'POST', 'callback' => [ $this, 'vote_review_helpful' ], 'permission_callback' => $pub,
		] );

		// ── Candidates ────────────────────────────────────────────────────────
		register_rest_route( $ns, '/candidates', [
			'methods' => 'GET', 'callback' => [ $this, 'get_candidates' ], 'permission_callback' => $rec,
		] );
		register_rest_route( $ns, '/candidates/me', [
			[ 'methods' => 'GET', 'callback' => [ $this, 'get_me' ],        'permission_callback' => $auth ],
			[ 'methods' => 'PUT', 'callback' => [ $this, 'update_profile' ],'permission_callback' => $auth ],
		] );
		register_rest_route( $ns, '/candidates/(?P<id>\d+)', [
			'methods' => 'GET', 'callback' => [ $this, 'get_candidate' ], 'permission_callback' => $rec,
		] );
		register_rest_route( $ns, '/candidates/me/matches', [
			'methods' => 'GET', 'callback' => [ $this, 'get_matches' ], 'permission_callback' => $auth,
		] );
		// Phase 3 redesign pass — MatchesPage's audit flagged it as needing
		// a dismiss action ("not interested, stop recommending this"),
		// distinct from saving a job. A dedicated table (not a column on
		// jp_matches) because backfill_candidate_matches()/score_candidate_
		// batch_job() below both $wpdb->replace() that row on every re-score
		// run — a flag stored there would be silently wiped the next time
		// the batch/backfill job runs for this candidate.
		register_rest_route( $ns, '/candidates/me/matches/(?P<job_id>\d+)/dismiss', [
			'methods' => 'POST', 'callback' => [ $this, 'dismiss_match' ], 'permission_callback' => $auth,
		] );

		// ── Applications ──────────────────────────────────────────────────────
		register_rest_route( $ns, '/applications', [
			'methods' => 'GET', 'callback' => [ $this, 'get_applications' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/applications/(?P<id>\d+)', [
			'methods' => 'GET', 'callback' => [ $this, 'get_application' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/applications/(?P<id>\d+)/stage', [
			'methods' => 'PUT', 'callback' => [ $this, 'move_stage' ], 'permission_callback' => $rec,
		] );
		// Root-cause fix (batch 16): JP_Applications::ajax_withdraw() has
		// existed since this class was written (own permission check —
		// scoped to the candidate's own application via candidate_id=%d in
		// its SELECT — plus its own "cannot withdraw a hired/rejected
		// application" guard) with no REST route and no SPA caller
		// anywhere: ApplicationsPage.tsx displays "Withdrawn" as a possible
		// status badge but has never had any control that could produce
		// it. $auth (not $rec) since this is candidate-initiated, matching
		// ajax_withdraw()'s own candidate_id-scoped query.
		register_rest_route( $ns, '/applications/(?P<id>\d+)/withdraw', [
			'methods' => 'POST', 'callback' => [ $this, 'withdraw_application' ], 'permission_callback' => $auth,
		] );
		// Root-cause fix (batch 21, backlog "offer-letter/e-signature
		// workflow"): JP_Applications::ajax_generate_offer() has existed
		// with no REST route and no SPA caller anywhere — see
		// do_generate_offer()'s own docblock in class-jp-applications.php
		// for the full trace. $rec since only the owning recruiter can
		// generate an offer (do_generate_offer()'s own can_manage_
		// application() check is the authoritative guard; $rec here is
		// defense-in-depth against a non-recruiter role hitting the route
		// at all).
		register_rest_route( $ns, '/applications/(?P<id>\d+)/generate-offer', [
			'methods' => 'POST', 'callback' => [ $this, 'generate_offer' ], 'permission_callback' => $rec,
		] );
		// $auth (not $rec) — candidate-initiated, matching do_offer_
		// response()'s own candidate_id-scoped query.
		register_rest_route( $ns, '/applications/(?P<id>\d+)/offer-response', [
			'methods' => 'POST', 'callback' => [ $this, 'submit_offer_response' ], 'permission_callback' => $auth,
		] );
		// Read model for whichever party (candidate or recruiter) is
		// viewing the application — $auth since do_generate_offer()'s
		// can_manage_application()/candidate_id scoping already governs
		// generate-offer/offer-response above; this route is read-only so
		// $auth alone is enough (no cross-account data exposure: envelope
		// rows carry no PII beyond what's already visible to both parties
		// on the application itself).
		register_rest_route( $ns, '/applications/(?P<id>\d+)/esign-status', [
			'methods' => 'GET', 'callback' => [ $this, 'get_esign_status' ], 'permission_callback' => $auth,
		] );
		// DocuSign Connect webhook — public by necessity (DocuSign's
		// servers, not a logged-in JP user, call this), authenticated by a
		// shared-secret query param instead (see JP_ESign::handle_webhook()'s
		// docblock for why, and jp_esign_webhook_secret in admin settings).
		register_rest_route( $ns, '/esign/webhook', [
			'methods' => 'POST', 'callback' => [ $this, 'esign_webhook' ], 'permission_callback' => $pub,
		] );

		// ── Search & Autocomplete ─────────────────────────────────────────────
		register_rest_route( $ns, '/search', [
			'methods' => 'GET', 'callback' => [ $this, 'search' ], 'permission_callback' => $pub,
		] );
		// /search/suggest and /search/cities are registered by JP_Search

		// ── Alerts ────────────────────────────────────────────────────────────
		register_rest_route( $ns, '/alerts', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'get_alerts' ],   'permission_callback' => $auth ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'create_alert' ], 'permission_callback' => $auth ],
		] );
		register_rest_route( $ns, '/alerts/(?P<id>\d+)', [
			[ 'methods' => 'DELETE', 'callback' => [ $this, 'delete_alert' ], 'permission_callback' => $auth ],
			[ 'methods' => 'PUT',    'callback' => [ $this, 'toggle_alert' ], 'permission_callback' => $auth ],
		] );

		// ── Messaging ─────────────────────────────────────────────────────────
		register_rest_route( $ns, '/threads', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'get_threads' ],   'permission_callback' => $auth ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'create_thread' ], 'permission_callback' => $auth ],
		] );
		register_rest_route( $ns, '/threads/(?P<id>\d+)/messages', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'get_thread_messages' ], 'permission_callback' => $auth ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'send_message' ],        'permission_callback' => $auth ],
		] );
		// Root-cause fix (batch 23): JP_Messaging::ajax_mark_read() existed
		// (hardened against a ghost-success in batch 17) with zero REST
		// route and zero SPA caller — MessagesPage.tsx never called it when
		// a thread was opened, so is_read/unread_count never actually
		// changed from within the live app: unread badges never cleared
		// and a sender could never see whether their message had been
		// seen. See JP_Messaging::instance()->ajax_mark_read() docblock.
		register_rest_route( $ns, '/threads/(?P<id>\d+)/read', [
			'methods' => 'PUT', 'callback' => [ $this, 'mark_thread_read' ], 'permission_callback' => $auth,
		] );
		// Phase 3 redesign (Tier A, redesign-plan §MessagesPage) — root-cause
		// fix: jp_message_threads.is_archived has existed on the schema and
		// in every /threads response since this table was created, but
		// get_threads() never filtered by it and no route anywhere ever
		// wrote to it — a conversation could never actually be archived, so
		// every thread a candidate or recruiter has ever had stayed in the
		// main inbox list forever. See get_threads()/archive_thread()'s own
		// docblocks below.
		register_rest_route( $ns, '/threads/(?P<id>\d+)/archive', [
			'methods' => 'PUT', 'callback' => [ $this, 'archive_thread' ], 'permission_callback' => $auth,
		] );
		// Batch 25: recruiter-saved message templates — see
		// class-jp-messaging.php's do_list_canned()/do_save_canned()/
		// do_delete_canned() docblock.
		register_rest_route( $ns, '/canned-responses', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'get_canned_responses' ],    'permission_callback' => $rec ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'create_canned_response' ],  'permission_callback' => $rec ],
		] );
		register_rest_route( $ns, '/canned-responses/(?P<id>\d+)', [
			'methods' => 'DELETE', 'callback' => [ $this, 'delete_canned_response' ], 'permission_callback' => $rec,
		] );

		// ── Analytics ─────────────────────────────────────────────────────────
		register_rest_route( $ns, '/analytics/track', [
			'methods' => 'POST', 'callback' => [ $this, 'track_event' ], 'permission_callback' => $pub,
		] );
		register_rest_route( $ns, '/analytics/dashboard', [
			'methods' => 'GET', 'callback' => [ $this, 'analytics_dashboard' ], 'permission_callback' => $auth,
		] );

		// ── Admin ─────────────────────────────────────────────────────────────
		// Root-cause fix (batch 5, see require_cap()'s docblock): job
		// approval is exactly what jp_staff's jp_approve_jobs capability
		// was declared for — was blanket-locked to manage_options only.
		register_rest_route( $ns, '/admin/jobs/pending', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_pending_jobs' ], 'permission_callback' => $this->require_cap( 'jp_approve_jobs' ),
		] );
		register_rest_route( $ns, '/admin/jobs/(?P<id>\d+)/approve', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_approve_job' ], 'permission_callback' => $this->require_cap( 'jp_approve_jobs' ),
		] );
		// Phase 3 redesign pass — AdminJobModerationPage's audit flagged it
		// as needing bulk approve/reject.
		register_rest_route( $ns, '/admin/jobs/bulk-approve', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_bulk_approve_jobs' ], 'permission_callback' => $this->require_cap( 'jp_approve_jobs' ),
		] );
		register_rest_route( $ns, '/admin/stats', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_stats' ], 'permission_callback' => $this->require_cap( 'jp_view_reports' ),
		] );

		// ── Skills ───────────────────────────────────────────────────────────
		register_rest_route( $ns, '/skills', [
			'methods' => 'GET', 'callback' => [ $this, 'get_skills' ], 'permission_callback' => $pub,
		] );

		// ── Plans ─────────────────────────────────────────────────────────────
		register_rest_route( $ns, '/plans', [
			'methods' => 'GET', 'callback' => [ $this, 'get_plans' ], 'permission_callback' => $pub,
		] );

		// ── Notifications ─────────────────────────────────────────────────────
		register_rest_route( $ns, '/notifications', [
			[ 'methods' => 'GET', 'callback' => [ $this, 'get_notifications' ], 'permission_callback' => $auth ],
		] );
		register_rest_route( $ns, '/notifications/read-all', [
			'methods' => 'PUT', 'callback' => [ $this, 'mark_all_notifications_read' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/notifications/(?P<id>\\d+)', [
			'methods' => 'PUT', 'callback' => [ $this, 'mark_notification_read' ], 'permission_callback' => $auth,
		] );

		// ── Resumes ───────────────────────────────────────────────────────────
		register_rest_route( $ns, '/resumes', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'get_resumes' ],    'permission_callback' => $auth ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'upload_resume' ],  'permission_callback' => $auth ],
		] );
		register_rest_route( $ns, '/resumes/(?P<id>\\d+)', [
			'methods' => 'DELETE', 'callback' => [ $this, 'delete_resume' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/resumes/(?P<id>\\d+)/primary', [
			'methods' => 'PUT', 'callback' => [ $this, 'set_primary_resume' ], 'permission_callback' => $auth,
		] );

		// ── Candidate analytics ───────────────────────────────────────────────
		register_rest_route( $ns, '/candidates/me/analytics', [
			'methods' => 'GET', 'callback' => [ $this, 'candidate_analytics' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/candidates/me/saved-jobs', [
			[ 'methods' => 'GET', 'callback' => [ $this, 'get_saved_jobs' ], 'permission_callback' => $auth ],
		] );
		// Same "column exists, no writer" gap already fixed on the
		// recruiter side (update_saved_candidate_note()) — jp_saved_jobs
		// has always had a `note` column, now also selected by
		// get_saved_jobs() above, but nothing ever wrote to it either.
		register_rest_route( $ns, '/candidates/me/saved-jobs/(?P<id>\d+)/note', [
			'methods' => 'PUT', 'callback' => [ $this, 'update_saved_job_note' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/candidates/me/avatar', [
			'methods' => 'POST', 'callback' => [ $this, 'upload_avatar' ], 'permission_callback' => $auth,
		] );

		// ── Job apply status ──────────────────────────────────────────────────
		register_rest_route( $ns, '/jobs/(?P<id>\\d+)/apply-status', [
			'methods' => 'GET', 'callback' => [ $this, 'job_apply_status' ], 'permission_callback' => $auth,
		] );

		// ── Salary insights ───────────────────────────────────────────────────
		register_rest_route( $ns, '/salary/insights', [
			'methods' => 'GET', 'callback' => [ $this, 'salary_insights' ], 'permission_callback' => $pub,
		] );



		// ── Community ────────────────────────────────────────────────────────
		register_rest_route( $ns, '/community/posts', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'community_get_posts' ],  'permission_callback' => $pub ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'community_create_post' ],'permission_callback' => $auth ],
		] );
		register_rest_route( $ns, '/community/posts/(?P<id>\d+)', [
			[ 'methods' => 'GET', 'callback' => [ $this, 'community_get_post' ], 'permission_callback' => $pub ],
		] );
		register_rest_route( $ns, '/community/posts/(?P<id>\d+)/replies', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'community_get_replies' ],  'permission_callback' => $pub ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'community_add_reply' ],    'permission_callback' => $auth ],
		] );
		register_rest_route( $ns, '/community/posts/(?P<id>\d+)/like', [
			'methods' => 'POST', 'callback' => [ $this, 'community_like_post' ], 'permission_callback' => $auth,
		] );
		// New (batch 23): jp_community_replies.is_accepted and
		// jp_community_posts.is_resolved have existed on the schema since
		// these tables were created (is_accepted already drives the sort
		// order in community_get_replies() above and the "Accepted" badge
		// the SPA already renders), but no route anywhere ever wrote either
		// column — a post's author had no way to actually mark a reply as
		// the answer, so is_resolved could never become genuinely true (only
		// whatever it defaulted to at row creation).
		register_rest_route( $ns, '/community/posts/(?P<id>\d+)/replies/(?P<reply_id>\d+)/accept', [
			'methods' => 'PUT', 'callback' => [ $this, 'community_accept_reply' ], 'permission_callback' => $auth,
		] );

		// ── Gamification ──────────────────────────────────────────────────────
		register_rest_route( $ns, '/gamification/badges', [
			'methods' => 'GET', 'callback' => [ $this, 'gamification_badges' ], 'permission_callback' => $auth,
		] );
		// Phase 3 redesign pass — GamificationPage's audit flagged "badges
		// shown, but no leaderboard, progress-to-next-badge, or points
		// history." Progress-to-next-badge already existed (next_milestone,
		// above); "points history" has no backing time-series table and
		// would need fabricated data to render, so it's out of scope. A
		// leaderboard is real, buildable from data that already exists
		// (jp_user_badges counts), and adds the social/competitive layer
		// gamification pages are supposed to have.
		register_rest_route( $ns, '/gamification/leaderboard', [
			'methods' => 'GET', 'callback' => [ $this, 'gamification_leaderboard' ], 'permission_callback' => $auth,
		] );

		// ── Resume sections ───────────────────────────────────────────────────
		register_rest_route( $ns, '/resume-sections', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'get_resume_sections' ],  'permission_callback' => $auth ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'save_resume_section' ],  'permission_callback' => $auth ],
		] );

		// ── Admin companies ───────────────────────────────────────────────────
		// Root-cause fix (batch 5): company oversight is jp_admin_manager's
		// declared jp_verify_companies capability — was manage_options-only.
		register_rest_route( $ns, '/admin/companies', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_companies' ], 'permission_callback' => $this->require_cap( 'jp_verify_companies' ),
		] );
		register_rest_route( $ns, '/admin/companies/(?P<id>\d+)/status', [
			'methods' => 'PUT', 'callback' => [ $this, 'admin_company_status' ], 'permission_callback' => $this->require_cap( 'jp_verify_companies' ),
		] );
		// gap analysis: bulk actions were present for Jobs/Applications only
		register_rest_route( $ns, '/admin/companies/bulk-action', [
			'methods' => 'POST', 'callback' => [ $this, 'bulk_company_action' ], 'permission_callback' => $this->require_cap( 'jp_verify_companies' ),
		] );
		// gap analysis: CSV export existed for admin, import did not exist for anything.
		// Batch 5: jobs import maps to jp_approve_jobs (JP_Jobs::create()
		// already gates its company_id override the same way — see batch 2);
		// companies import creates new owner accounts/companies, a step up
		// from plain verification, so it stays paired with jp_verify_companies
		// rather than being opened to jp_staff (who lack that capability).
		register_rest_route( $ns, '/admin/import/jobs', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_import_jobs' ], 'permission_callback' => $this->require_cap( 'jp_approve_jobs' ),
		] );
		register_rest_route( $ns, '/admin/import/companies', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_import_companies' ], 'permission_callback' => $this->require_cap( 'jp_verify_companies' ),
		] );

		// ── Candidate public profile ──────────────────────────────────────────
		register_rest_route( $ns, '/profiles/(?P<id>\d+)', [
			'methods' => 'GET', 'callback' => [ $this, 'public_profile' ], 'permission_callback' => $pub,
		] );

		// ── Events ────────────────────────────────────────────────────────────
		register_rest_route( $ns, '/events', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'get_events' ],   'permission_callback' => $pub ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'create_event' ], 'permission_callback' => $rec ],
		] );
		register_rest_route( $ns, '/events/(?P<id>\d+)', [
			[ 'methods' => 'GET', 'callback'    => [ $this, 'get_event' ],    'permission_callback' => $pub ],
			[ 'methods' => 'PUT', 'callback'    => [ $this, 'update_event' ], 'permission_callback' => $rec ],
		] );
		register_rest_route( $ns, '/events/(?P<id>\d+)/register', [
			'methods' => 'POST', 'callback' => [ $this, 'register_event' ], 'permission_callback' => $auth,
		] );

		register_rest_route( $ns, '/events/(?P<id>\d+)/register', [
			'methods' => 'DELETE', 'callback' => [ $this, 'cancel_event_registration' ], 'permission_callback' => $auth,
		] );


		// ── Recruiter analytics ──────────────────────────────────────────────
		register_rest_route( $ns, '/recruiter/analytics', [
			'methods' => 'GET', 'callback' => [ $this, 'get_recruiter_analytics' ], 'permission_callback' => $rec,
		] );

		// ── Team management (batch 6) ─────────────────────────────────────────
		// Root-cause fix — see class-jp-team.php's class docblock for the full
		// gap trace: JP_Team's invite/accept/remove/list/reassign logic has
		// existed since an earlier pass, entirely unreachable from the live
		// SPA (wp_ajax_* only). $rec (recruiter-or-above) is a coarse filter
		// only — every do_*() method below does its own real membership/
		// ownership check, exactly like the existing recruiter-scoped routes
		// above it. /team/accept is $auth, not $rec: the accepting user may
		// still be a plain job_seeker (or brand-new registrant) at the moment
		// they accept — do_accept_invite() is what grants them jp_recruiter/
		// jp_team_manager, so requiring that role before they can accept the
		// invite that grants it would be circular.
		register_rest_route( $ns, '/team', [
			'methods' => 'GET', 'callback' => [ $this, 'team_list' ], 'permission_callback' => $rec,
		] );
		register_rest_route( $ns, '/team/invite', [
			'methods' => 'POST', 'callback' => [ $this, 'team_invite' ], 'permission_callback' => $rec,
		] );
		register_rest_route( $ns, '/team/accept', [
			'methods' => 'POST', 'callback' => [ $this, 'team_accept' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/team/(?P<id>\d+)', [
			'methods' => 'DELETE', 'callback' => [ $this, 'team_remove' ], 'permission_callback' => $rec,
		] );
		register_rest_route( $ns, '/team/reassign-job', [
			'methods' => 'POST', 'callback' => [ $this, 'team_reassign_job' ], 'permission_callback' => $rec,
		] );

		// ── Payments / checkout (batch 10) ───────────────────────────────────
		// Root-cause fix — see class-jp-payments.php's do_create_order()
		// docblock for the full gap trace: order creation and payment
		// verification have ALWAYS been wp_ajax_* only, with zero REST route
		// and zero SPA call anywhere, meaning there has never been any way
		// for a paying customer to actually start a purchase through the
		// live app — the single most business-critical gap found in this
		// entire audit. $rec (recruiter-or-above), matching plans' own
		// audience (job_posts/featured_jobs/resume_views/team_seats credits
		// are all recruiter-side concepts) — same access level /team's own
		// routes use just above.
		register_rest_route( $ns, '/payments/create-order', [
			'methods' => 'POST', 'callback' => [ $this, 'payments_create_order' ], 'permission_callback' => $rec,
		] );
		register_rest_route( $ns, '/payments/verify', [
			'methods' => 'POST', 'callback' => [ $this, 'payments_verify' ], 'permission_callback' => $rec,
		] );
		// Batch 12 — Stripe gateway abstraction's verify counterpart to
		// /payments/verify (see JP_Payments::do_verify_stripe_session()'s
		// docblock for why Stripe's redirect flow needs a distinct route
		// instead of reusing /payments/verify's signature-based shape).
		register_rest_route( $ns, '/payments/verify-stripe-session', [
			'methods' => 'POST', 'callback' => [ $this, 'payments_verify_stripe_session' ], 'permission_callback' => $rec,
		] );

		// ── Admin extended ────────────────────────────────────────────────────
		// Root-cause fix (batch 5): user administration is jp_admin_manager's
		// declared jp_manage_users capability — deliberately NOT extended to
		// jp_staff, which was never granted jp_manage_users (staff's role is
		// content/job moderation, not account administration — see
		// require_cap()'s docblock for the full reasoning on what was and
		// wasn't widened here).
		register_rest_route( $ns, '/admin/users', [
			[ 'methods' => 'GET', 'callback' => [ $this, 'admin_users' ], 'permission_callback' => $this->require_cap( 'jp_manage_users' ) ],
		] );
		register_rest_route( $ns, '/admin/users/(?P<id>\\d+)/role', [
			'methods' => 'PUT', 'callback' => [ $this, 'admin_change_role' ], 'permission_callback' => $this->require_cap( 'jp_manage_users' ),
		] );
		// Batch 28: custom RBAC — per-user capability overrides layered on
		// top of the fixed role list, see JP_Roles::overridable_capabilities().
		register_rest_route( $ns, '/admin/users/(?P<id>\\d+)/capabilities', [
			[ 'methods' => 'GET', 'callback' => [ $this, 'admin_get_capabilities' ], 'permission_callback' => $this->require_cap( 'jp_manage_users' ) ],
			[ 'methods' => 'PUT', 'callback' => [ $this, 'admin_update_capability' ], 'permission_callback' => $this->require_cap( 'jp_manage_users' ) ],
		] );
		// gap analysis: bulk actions were present for Jobs/Applications only
		register_rest_route( $ns, '/admin/users/bulk-action', [
			'methods' => 'POST', 'callback' => [ $this, 'bulk_user_action' ], 'permission_callback' => $this->require_cap( 'jp_manage_users' ),
		] );
		register_rest_route( $ns, '/admin/companies/(?P<id>\\d+)/verify', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_verify_company' ], 'permission_callback' => $this->require_cap( 'jp_verify_companies' ),
		] );
		// Payments/subscriptions viewing pairs with jp_view_revenue — the
		// same capability admin_revenue_dashboard() already uses — rather
		// than a separate declared-but-nonexistent "view payments" capability.
		register_rest_route( $ns, '/admin/payments', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_payments' ], 'permission_callback' => $this->require_cap( 'jp_view_revenue' ),
		] );
		// New in batch 39 (admin operations-center depth — pre-delivery
		// audit's "Support Scenario 1: record stuck in state" requires an
		// admin to be able to FIND a specific application across the whole
		// platform, not just look one up by an id they already have.
		// get_application()/move_stage()/add_application_note() already
		// grant manage_options a full override (get_application() since
		// batch 37, move_stage()/ajax_move_stage()/ajax_add_note() via
		// can_manage_application()'s own manage_options short-circuit) —
		// this is the missing search/list entry point into that existing
		// override capability, gated on the same jp_manage_all_applications
		// capability those checks already grant manage_options-equivalent
		// access via.
		register_rest_route( $ns, '/admin/applications', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_applications' ], 'permission_callback' => $this->require_cap( 'jp_manage_all_applications' ),
		] );

		// Root-cause fix (found while auditing the still-pending WP-Admin-only
		// settings areas — "Privacy/Offboarding"): JP_Privacy's company
		// export/erase and impersonation logic has existed since an earlier
		// pass, but only as wp_ajax_* handlers keyed to a 'jp_admin_privacy'
		// cookie nonce the REST-only SPA never has. See
		// class-jp-privacy.php's own docblock for the shared-method refactor
		// (export_company/erase_company/start_impersonation/stop_impersonation)
		// these REST callbacks now call — one implementation behind both the
		// legacy AJAX handlers and these.
		// Deliberately NOT gated by $adm (manage_options) alone: the legacy
		// ajax_export_company() accepted 'jp_export_data' OR 'manage_options'
		// — a distinct capability this codebase grants (class-jp-roles.php)
		// specifically so a non-full-admin data-export role can exist. Gating
		// this route to $adm would silently narrow that back to admins only.
		register_rest_route( $ns, '/admin/companies/(?P<id>\\d+)/export', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_export_company' ],
			'permission_callback' => function () {
				return current_user_can( 'jp_export_data' ) || current_user_can( 'manage_options' )
					? true : new \WP_Error( 'forbidden', 'Insufficient permissions.', [ 'status' => 403 ] );
			},
		] );
		register_rest_route( $ns, '/admin/companies/(?P<id>\\d+)', [
			'methods' => 'DELETE', 'callback' => [ $this, 'admin_erase_company' ], 'permission_callback' => $adm,
		] );
		// Same reasoning as the export route above: the legacy
		// ajax_impersonate_start() accepted 'jp_impersonate_users' OR
		// 'manage_options' — gating this to $adm alone would silently
		// narrow who can use it.
		register_rest_route( $ns, '/admin/impersonate/start', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_impersonate_start' ],
			'permission_callback' => function () {
				return current_user_can( 'jp_impersonate_users' ) || current_user_can( 'manage_options' )
					? true : new \WP_Error( 'forbidden', 'Insufficient permissions.', [ 'status' => 403 ] );
			},
		] );
		register_rest_route( $ns, '/admin/impersonate/stop', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_impersonate_stop' ], 'permission_callback' => $auth,
		] );

		// Root-cause fix (batch 5): jp_view_audit_log is declared in
		// class-jp-roles.php's administrator-only capability list — a
		// SECOND "declared but never checked" capability found in the same
		// pass as jp_view_revenue's original fix (require_revenue_access())
		// — nothing anywhere called current_user_can('jp_view_audit_log')
		// before this; both routes silently used manage_options instead.
		// Wiring it doesn't change who currently has access (only
		// `administrator` carries this capability today, same as before),
		// but it fixes the actual bug — the capability existing and doing
		// nothing — and means a future role grant of jp_view_audit_log
		// (e.g. to jp_admin_manager) will correctly take effect without
		// another code change.
		register_rest_route( $ns, '/admin/audit-log', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_audit_log' ], 'permission_callback' => $this->require_cap( 'jp_view_audit_log' ),
		] );
		// gap analysis: no way to filter the audit log or export a filtered slice
		register_rest_route( $ns, '/admin/audit-log/export', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_audit_log_export' ], 'permission_callback' => $this->require_cap( 'jp_view_audit_log' ),
		] );
		// Batch 14: exposes JP_Security::verify_audit_chain() — same
		// capability gate as the audit-log views themselves, since the
		// ability to check whether the trail has been tampered with is
		// only meaningful to someone who can already see it.
		register_rest_route( $ns, '/admin/audit-log/verify', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_audit_log_verify' ], 'permission_callback' => $this->require_cap( 'jp_view_audit_log' ),
		] );
		// Root-cause fix (found while auditing the still-pending WP-Admin-only
		// settings areas): JP_ErrorLog::recent()'s own docblock said a full
		// log viewer was "future" work — it was only ever called with a
		// fixed small limit from admin_health()'s combined payload, and no
		// dedicated, paginated REST route existed for it at all.
		// Left on manage_options (batch 5): error-log/health are raw
		// system-internals diagnostics with no matching declared capability
		// (unlike audit-log's jp_view_audit_log) — no non-destructive
		// widening candidate exists here, so this is intentionally unchanged.
		register_rest_route( $ns, '/admin/error-log', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_error_log' ], 'permission_callback' => $adm,
		] );
		register_rest_route( $ns, '/admin/health', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_health' ], 'permission_callback' => $adm,
		] );
		// Root-cause fix (gap analysis P1 #179: "No platform-level
		// revenue/MRR/churn dashboard despite jp_subscriptions/jp_payments
		// holding all the raw status/date data needed, and a jp_view_revenue
		// capability that exists but has no analytics method behind it").
		// Gated by require_revenue_access() (manage_options OR
		// jp_view_revenue), not the blanket $adm/require_admin() every other
		// admin endpoint here uses — see that method's docblock.
		register_rest_route( $ns, '/admin/revenue', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_revenue_dashboard' ], 'permission_callback' => [ $this, 'require_revenue_access' ],
		] );



		// ── Save job toggle ──────────────────────────────────────────────────
		register_rest_route( $ns, '/jobs/(?P<id>\d+)/save', [
			'methods' => 'POST', 'callback' => [ $this, 'toggle_save_job' ], 'permission_callback' => $auth,
		] );

		// ── Talent pool (recruiter-saved candidates) ────────────────────────
		// The recruiter-side mirror of the save-job toggle above — same
		// request shape, same rate-limit treatment, same list-with-join
		// pattern as get_saved_jobs(), just the other direction (a recruiter
		// bookmarking a candidate instead of a candidate bookmarking a job).
		register_rest_route( $ns, '/candidates/(?P<id>\d+)/save', [
			'methods' => 'POST', 'callback' => [ $this, 'toggle_save_candidate' ], 'permission_callback' => $rec,
		] );
		register_rest_route( $ns, '/recruiter/talent-pool', [
			'methods' => 'GET', 'callback' => [ $this, 'get_talent_pool' ], 'permission_callback' => $rec,
		] );
		// Root-cause fix (schema-exists-no-writer gap, self-audited): the
		// jp_saved_candidates table has a real `note` column, and
		// get_talent_pool() already SELECTs+returns it, but nothing ever
		// wrote to it — toggle_save_candidate() never sets one and no other
		// endpoint existed to add/edit one either, the exact "backend has
		// the column, no way to write to it" bug class this codebase's
		// audit history repeatedly flags. A recruiter jotting "great
		// culture fit, follow up in Q2" on a saved candidate is standard
		// ATS behavior (mirrors add_application_note()'s existing pattern).
		register_rest_route( $ns, '/recruiter/talent-pool/(?P<id>\d+)/note', [
			'methods' => 'PUT', 'callback' => [ $this, 'update_saved_candidate_note' ], 'permission_callback' => $rec,
		] );

		// ── Assessments ───────────────────────────────────────────────────────
		register_rest_route( $ns, '/assessments', [
			'methods' => 'GET', 'callback' => [ $this, 'get_assessments' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/assessments/(?P<skill_id>\d+)/take', [
			'methods' => 'POST', 'callback' => [ $this, 'take_assessment' ], 'permission_callback' => $auth,
		] );

		// ── Notification preferences ──────────────────────────────────────────
		register_rest_route( $ns, '/notifications/preferences', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'get_notif_prefs' ], 'permission_callback' => $auth ],
			[ 'methods' => 'PUT',  'callback' => [ $this, 'save_notif_prefs' ],'permission_callback' => $auth ],
		] );





		// ── Community ────────────────────────────────────────────────────────
		// ── Admin extended ────────────────────────────────────────────────────
		// Root-cause fix (batch 5): review moderation is precisely
		// jp_staff's reason for existing (jp_moderate_content) — was
		// blanket-locked to manage_options only, same bug class as the
		// job-approval routes above.
		register_rest_route( $ns, '/admin/reviews', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'admin_reviews' ],        'permission_callback' => $this->require_cap( 'jp_moderate_content' ) ],
		] );
		register_rest_route( $ns, '/admin/reviews/(?P<id>\d+)', [
			[ 'methods' => 'PUT', 'callback' => [ $this, 'admin_review_action' ],   'permission_callback' => $this->require_cap( 'jp_moderate_content' ) ],
		] );
		// gap analysis: bulk actions were present for Jobs/Applications only
		register_rest_route( $ns, '/admin/reviews/bulk-action', [
			'methods' => 'POST', 'callback' => [ $this, 'bulk_review_action' ], 'permission_callback' => $this->require_cap( 'jp_moderate_content' ),
		] );
		// Subscriptions viewing pairs with jp_view_revenue (billing-adjacent
		// data), same as /admin/payments above.
		register_rest_route( $ns, '/admin/subscriptions', [
			[ 'methods' => 'GET', 'callback' => [ $this, 'admin_subscriptions' ],   'permission_callback' => $this->require_cap( 'jp_view_revenue' ) ],
		] );
		// Phase 3 redesign pass — the audit flagged AdminSubscriptionsPage as
		// a plain list with no admin override action. Force-cancel is a
		// mutation, not a view, so it's gated on jp_manage_plans (the real
		// registered capability governing the plans/subscriptions domain —
		// see class-jp-roles.php) rather than the read-only jp_view_revenue
		// this resource is normally listed under.
		register_rest_route( $ns, '/admin/subscriptions/(?P<id>\d+)/cancel', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_cancel_subscription' ], 'permission_callback' => $this->require_cap( 'jp_manage_plans' ),
		] );
		// Skills taxonomy is content governance — jp_moderate_content, same
		// capability that already gates review moderation above.
		register_rest_route( $ns, '/admin/skills', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'admin_get_skills' ],     'permission_callback' => $this->require_cap( 'jp_moderate_content' ) ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'admin_add_skill' ],      'permission_callback' => $this->require_cap( 'jp_moderate_content' ) ],
		] );
		register_rest_route( $ns, '/admin/skills/(?P<id>\d+)', [
			[ 'methods' => 'DELETE', 'callback' => [ $this, 'admin_delete_skill' ], 'permission_callback' => $this->require_cap( 'jp_moderate_content' ) ],
		] );
		// Skill-taxonomy governance, continued from §36's deletion-safety
		// fix: admins can now merge a duplicate/near-duplicate skill (e.g.
		// "ReactJS") into a canonical one (e.g. "React") instead of their
		// only prior option being force-delete-and-lose-the-data or leave
		// the duplicate in place forever. See admin_merge_skill() below.
		register_rest_route( $ns, '/admin/skills/(?P<id>\d+)/merge', [
			[ 'methods' => 'POST', 'callback' => [ $this, 'admin_merge_skill' ], 'permission_callback' => $this->require_cap( 'jp_moderate_content' ) ],
		] );
		// Left on manage_options (batch 5, see require_cap()'s docblock):
		// pricing-plan configuration directly controls platform revenue and
		// has no declared capability of its own — misusing the READ-only
		// jp_view_revenue to gate this WRITE-capable route would be its own
		// bug, not a fix, so this is deliberately unchanged.
		register_rest_route( $ns, '/admin/plans', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'admin_get_plans' ],      'permission_callback' => $adm ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'admin_save_plan' ],      'permission_callback' => $adm ],
		] );
		// Root-cause fix (batch 5): jp_system_config is declared in
		// class-jp-roles.php's administrator-only capability list — a
		// THIRD "declared but never checked" capability found in this pass
		// (alongside jp_view_revenue, already fixed, and jp_view_audit_log,
		// above) — nothing anywhere checked it before this. Applied to the
		// whole system-configuration family below (cache-flush, backup,
		// VAPID, settings, push-broadcast, feature-flags, webhooks) for the
		// same reason: they're all the same class of operation
		// ("reconfigure how the platform itself behaves") and were all
		// gated identically to manage_options before. Access is unchanged
		// today (only `administrator` carries jp_system_config), same
		// forward-compatibility rationale as jp_view_audit_log above.
		register_rest_route( $ns, '/admin/system/cache-flush', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_flush_cache' ],      'permission_callback' => $this->require_cap( 'jp_system_config' ),
		] );
		register_rest_route( $ns, '/admin/system/backup', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_trigger_backup' ],   'permission_callback' => $this->require_cap( 'jp_system_config' ),
		] );
		// Root-cause fix (roadmap re-audit: class-jp-settings.php's "Security"
		// wp-admin page had a "Generate VAPID Keys" button — ajax_gen_vapid() —
		// with no REST/SPA equivalent at all, so an admin could never rotate
		// push-notification keys once wp-admin is retired. JP_PWA::generate_vapid_keys()
		// is the same underlying call the legacy AJAX handler made; nothing about
		// key generation itself is being redesigned here, only how it's reached.
		register_rest_route( $ns, '/admin/system/vapid', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_generate_vapid' ], 'permission_callback' => $this->require_cap( 'jp_system_config' ),
		] );
		register_rest_route( $ns, '/admin/settings', [
			[ 'methods' => 'GET', 'callback' => [ $this, 'admin_get_settings' ],    'permission_callback' => $this->require_cap( 'jp_system_config' ) ],
			[ 'methods' => 'PUT', 'callback' => [ $this, 'admin_save_settings' ],   'permission_callback' => $this->require_cap( 'jp_system_config' ) ],
		] );
		register_rest_route( $ns, '/admin/push/broadcast', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_push_broadcast' ],   'permission_callback' => $this->require_cap( 'jp_system_config' ),
		] );

		// Root-cause fix (found while auditing the still-pending WP-Admin-only
		// settings areas): JP_FeatureFlags::ajax_*() has existed since an
		// earlier pass, but only as wp_ajax_* handlers keyed to a browser
		// cookie nonce the REST-only SPA never has — no REST route existed
		// for this at all, so an admin could never manage flags (or gate any
		// UI on a resolved flag) from the app itself. See
		// class-jp-featureflags.php's own docblock for the shared-method
		// refactor this builds on (list_flags/save_flag/delete_flag/
		// get_resolved_flags_for_user), which keeps exactly one
		// implementation behind both the legacy AJAX handlers and these.
		register_rest_route( $ns, '/admin/feature-flags', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'admin_get_flags' ], 'permission_callback' => $this->require_cap( 'jp_system_config' ) ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'admin_save_flag' ], 'permission_callback' => $this->require_cap( 'jp_system_config' ) ],
		] );
		register_rest_route( $ns, '/admin/feature-flags/(?P<key>[\w-]+)', [
			'methods' => 'DELETE', 'callback' => [ $this, 'admin_delete_flag' ], 'permission_callback' => $this->require_cap( 'jp_system_config' ),
		] );
		// Logged-in-user-facing: any authenticated user (not admin-only) can
		// resolve their own gated flag set, mirroring ajax_get_resolved_flags()'s
		// existing is_user_logged_in()-only gate.
		register_rest_route( $ns, '/feature-flags', [
			'methods' => 'GET', 'callback' => [ $this, 'get_resolved_flags' ], 'permission_callback' => $auth,
		] );

		// ── Push subscription (Phase 9) ──────────────────────────────────────
		register_rest_route( $ns, '/push/subscribe', [
			'methods' => 'POST', 'callback' => [ $this, 'push_subscribe' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/push/unsubscribe', [
			'methods' => 'POST', 'callback' => [ $this, 'push_unsubscribe' ], 'permission_callback' => $auth,
		] );

		// ── Phase 10: 2FA ────────────────────────────────────────────────────
		register_rest_route( $ns, '/auth/2fa/setup', [
			'methods' => 'POST', 'callback' => [ $this, 'twofa_setup' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/auth/2fa/verify', [
			'methods' => 'POST', 'callback' => [ $this, 'twofa_verify' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/auth/2fa/disable', [
			'methods' => 'POST', 'callback' => [ $this, 'twofa_disable' ], 'permission_callback' => $auth,
		] );

		// ── Phase 10: GDPR — Data export + account deletion ──────────────────
		register_rest_route( $ns, '/account/export', [
			'methods' => 'GET', 'callback' => [ $this, 'account_export' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/account/delete', [
			'methods' => 'POST', 'callback' => [ $this, 'account_delete' ], 'permission_callback' => $auth,
		] );

		// ── Phase 10: Repost job ──────────────────────────────────────────────
		register_rest_route( $ns, '/jobs/(?P<id>\\d+)/repost', [
			'methods' => 'POST', 'callback' => [ $this, 'repost_job' ], 'permission_callback' => $rec,
		] );

		// ── Job feed import (JP_JobFeed) — same admin capability as the
		// other system-configuration/integration routes (webhooks, feature
		// flags, VAPID) below.
		register_rest_route( $ns, '/admin/job-feed/run', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_run_job_feed_import' ], 'permission_callback' => $this->require_cap( 'jp_system_config' ),
		] );
		register_rest_route( $ns, '/admin/job-feed/status', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_job_feed_status' ], 'permission_callback' => $this->require_cap( 'jp_system_config' ),
		] );

		// ── Phase 10: CSV export (admin) ─────────────────────────────────────
		// Root-cause fix (batch 5): jp_export_data is the exact capability
		// admin_export_company() and admin_impersonate_start() already
		// established the "manage_options OR jp_export_data" pattern for —
		// this general-purpose CSV export route had been left on
		// manage_options only, missing the same wiring.
		register_rest_route( $ns, '/admin/export/(?P<type>[a-z_]+)', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_csv_export' ], 'permission_callback' => $this->require_cap( 'jp_export_data' ),
		] );

		// ── Phase 10: Webhooks (admin) ───────────────────────────────────────
		// System-level integration configuration — jp_system_config, same
		// family as settings/feature-flags/backups above.
		register_rest_route( $ns, '/admin/webhooks', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'admin_webhooks_list' ],  'permission_callback' => $this->require_cap( 'jp_system_config' ) ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'admin_webhook_create' ], 'permission_callback' => $this->require_cap( 'jp_system_config' ) ],
		] );
		register_rest_route( $ns, '/admin/webhooks/(?P<id>[\\w_.-]+)', [
			[ 'methods' => 'DELETE', 'callback' => [ $this, 'admin_webhook_delete' ], 'permission_callback' => $this->require_cap( 'jp_system_config' ) ],
		] );
		register_rest_route( $ns, '/admin/webhooks/(?P<id>[\\w_.-]+)/test', [
			'methods' => 'POST', 'callback' => [ $this, 'admin_webhook_test' ], 'permission_callback' => $this->require_cap( 'jp_system_config' ),
		] );
		// Root-cause fix (batch 18): JP_Webhooks::dispatch()/retry_due_deliveries()
		// have written one real row per delivery attempt to jp_webhook_deliveries
		// since that table was created (see its own docblock: "so delivery
		// history/failures are actually visible to an admin instead of
		// vanishing") — but no route ever read it back, so it wasn't actually
		// visible to anyone.
		register_rest_route( $ns, '/admin/webhooks/(?P<id>[\\w_.-]+)/deliveries', [
			'methods' => 'GET', 'callback' => [ $this, 'admin_webhook_deliveries' ], 'permission_callback' => $this->require_cap( 'jp_system_config' ),
		] );

		// ── Phase 10: Market intelligence ────────────────────────────────────
		register_rest_route( $ns, '/market/insights', [
			'methods' => 'GET', 'callback' => [ $this, 'market_insights' ], 'permission_callback' => $pub,
		] );

		// ── Phase 10: Onboarding ─────────────────────────────────────────────
		register_rest_route( $ns, '/onboarding/status', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'onboarding_status' ],   'permission_callback' => $auth ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'onboarding_complete' ], 'permission_callback' => $auth ],
		] );

		// ── Phase 10: Help centre ────────────────────────────────────────────
		register_rest_route( $ns, '/help/articles', [
			'methods' => 'GET', 'callback' => [ $this, 'help_articles' ], 'permission_callback' => $pub,
		] );
		register_rest_route( $ns, '/help/contact', [
			'methods' => 'POST', 'callback' => [ $this, 'help_contact' ], 'permission_callback' => $pub,
		] );

		// ── Phase 10: Changelog ──────────────────────────────────────────────
		register_rest_route( $ns, '/changelog', [
			'methods' => 'GET', 'callback' => [ $this, 'get_changelog' ], 'permission_callback' => $pub,
		] );

		// ── Recruiter subscription / billing ───────────────────────────────────
		register_rest_route( $ns, '/recruiter/subscription', [
			'methods' => 'GET', 'callback' => [ $this, 'get_recruiter_subscription' ], 'permission_callback' => $rec,
		] );
		register_rest_route( $ns, '/recruiter/invoices', [
			'methods' => 'GET', 'callback' => [ $this, 'get_recruiter_invoices' ], 'permission_callback' => $rec,
		] );

		// ── Recruiter-specific ───────────────────────────────────────────────
		register_rest_route( $ns, '/recruiter/jobs', [
			'methods' => 'GET', 'callback' => [ $this, 'get_recruiter_jobs' ], 'permission_callback' => $rec,
		] );
		register_rest_route( $ns, '/recruiter/applications', [
			'methods' => 'GET', 'callback' => [ $this, 'get_recruiter_applications' ], 'permission_callback' => $rec,
		] );
		// gap analysis: admin_csv_export() (below) lets an admin export ANY
		// recruiter's applications, but a recruiter had no self-service way
		// to export their OWN applicants — a standard ATS capability (share
		// a shortlist with a hiring manager, keep an offline record). Scoped
		// to the recruiter's own postings the same way get_recruiter_applications()
		// already is (j.posted_by=$uid), not gated behind the admin-only
		// jp_export_data capability.
		register_rest_route( $ns, '/recruiter/applications/export', [
			'methods' => 'GET', 'callback' => [ $this, 'recruiter_export_applications' ], 'permission_callback' => $rec,
		] );
		register_rest_route( $ns, '/recruiter/company', [
			[ 'methods' => 'GET', 'callback' => [ $this, 'get_recruiter_company' ], 'permission_callback' => $rec ],
			[ 'methods' => 'PUT', 'callback' => [ $this, 'update_recruiter_company' ], 'permission_callback' => $rec ],
		] );
		register_rest_route( $ns, '/interviews', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'get_interviews' ],    'permission_callback' => $rec ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'schedule_interview' ],'permission_callback' => $rec ],
		] );
		register_rest_route( $ns, '/interviews/(?P<id>\d+)', [
			'methods' => 'DELETE', 'callback' => [ $this, 'cancel_interview' ], 'permission_callback' => $rec,
		] );
		// Batch 36 (interview-management depth pass): candidates previously
		// had no interview endpoints at all — get_interviews() is
		// recruiter-scoped (WHERE recruiter_id=%d) and every other route in
		// this section is $rec-gated, so a candidate's only visibility into
		// their own interview was the interview_date column already
		// rendered on ApplicationsPage.tsx. No way to see the type/time/
		// location/meeting link, confirm attendance, or ask to reschedule.
		// Gated on $auth (any logged-in user, same as e.g. apply_job())
		// rather than $rec since the caller here IS the candidate, not a
		// recruiter; ownership is enforced inside each handler by scoping
		// every query to candidate_id=current_user (mirrors how the
		// panelist-feedback route above is opened past $rec and enforces
		// ownership in the handler instead).
		register_rest_route( $ns, '/my-interviews', [
			'methods' => 'GET', 'callback' => [ $this, 'get_my_interviews' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/interviews/(?P<id>\d+)/confirm', [
			'methods' => 'PUT', 'callback' => [ $this, 'confirm_interview' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/interviews/(?P<id>\d+)/request-reschedule', [
			'methods' => 'PUT', 'callback' => [ $this, 'request_interview_reschedule' ], 'permission_callback' => $auth,
		] );
		// Root-cause fix (batch 20, gap analysis backlog "interview panel/
		// scorecard collaboration"): jp_interviews has had rating/feedback/
		// outcome columns since this table was first created, but no route
		// anywhere ever wrote to them — schedule_interview() only ever set
		// outcome='pending', and cancel_interview() only ever set it to
		// 'cancelled'. There was no way, anywhere in this product, for a
		// recruiter to record what actually happened in an interview —
		// confirmed by grepping the whole codebase for 'feedback'/'rating'
		// outside the schema definition and finding zero other references.
		// This closes the single-reviewer version of that gap (the
		// mechanism every additional panelist/scorecard feature would sit
		// on top of); true multi-interviewer panel collaboration (several
		// named reviewers each submitting their own independent scorecard
		// on the same interview) needs its own table and is intentionally
		// left as a further backlog item, not attempted in this pass.
		register_rest_route( $ns, '/interviews/(?P<id>\d+)/feedback', [
			'methods' => 'PUT', 'callback' => [ $this, 'submit_interview_feedback' ], 'permission_callback' => $rec,
		] );
		// Batch 26: true multi-interviewer panel/scorecard collaboration —
		// see add_interview_panelist()'s docblock below. GET/POST are
		// recruiter-gated at the route level like the rest of this section;
		// the feedback PUT is opened to any authenticated user because the
		// panelist submitting it may not themselves hold a recruiter role
		// (e.g. a hiring-manager account) — ownership is enforced inside
		// the handler instead (must be the exact panelist row's user).
		register_rest_route( $ns, '/interviews/(?P<id>\d+)/panelists', [
			[ 'methods' => 'GET',  'callback' => [ $this, 'get_interview_panelists' ], 'permission_callback' => $rec ],
			[ 'methods' => 'POST', 'callback' => [ $this, 'add_interview_panelist' ],  'permission_callback' => $rec ],
		] );
		register_rest_route( $ns, '/interviews/(?P<id>\d+)/panelists/(?P<panelist_row_id>\d+)', [
			'methods' => 'DELETE', 'callback' => [ $this, 'remove_interview_panelist' ], 'permission_callback' => $rec,
		] );
		register_rest_route( $ns, '/interviews/(?P<id>\d+)/panelists/(?P<panelist_row_id>\d+)/feedback', [
			'methods' => 'PUT', 'callback' => [ $this, 'submit_panelist_feedback' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/applications/(?P<id>\d+)/note', [
			'methods' => 'POST', 'callback' => [ $this, 'add_application_note' ], 'permission_callback' => $rec,
		] );
		// New in batch 37 (recruiter ATS pipeline depth) — see set_application_tags() docblock.
		register_rest_route( $ns, '/applications/(?P<id>\d+)/tags', [
			'methods' => 'PUT', 'callback' => [ $this, 'set_application_tags' ], 'permission_callback' => $rec,
		] );
		// New in batch 37 — see view_application_resume() docblock. Uses
		// $auth (not $rec) since the candidate who owns the resume is also
		// a legitimate caller; the callback itself enforces the real
		// per-application ownership check.
		register_rest_route( $ns, '/applications/(?P<id>\d+)/resume', [
			'methods' => 'GET', 'callback' => [ $this, 'view_application_resume' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/applications/bulk-stage', [
			'methods' => 'POST', 'callback' => [ $this, 'bulk_move_stage' ], 'permission_callback' => $rec,
		] );
		// gap analysis P1 #167: bulk job management, mirroring bulk-stage above
		register_rest_route( $ns, '/jobs/bulk-action', [
			'methods' => 'POST', 'callback' => [ $this, 'bulk_job_action' ], 'permission_callback' => $rec,
		] );

		// ── AI ──────────────────────────────────────────────────────────────────
		register_rest_route( $ns, '/ai/resume-score', [
			'methods' => 'GET', 'callback' => [ $this, 'ai_resume_score' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/ai/resume-improve', [
			'methods' => 'POST', 'callback' => [ $this, 'ai_resume_improve' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/ai/cover-letter', [
			'methods' => 'POST', 'callback' => [ $this, 'ai_cover_letter' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/ai/interview-prep', [
			'methods' => 'POST', 'callback' => [ $this, 'ai_interview_prep' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/ai/interview-questions', [
			'methods' => 'POST', 'callback' => [ $this, 'ai_interview_questions' ], 'permission_callback' => $rec,
		] );
		register_rest_route( $ns, '/ai/career-advice', [
			'methods' => 'POST', 'callback' => [ $this, 'ai_career_advice' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/ai/improve-jd', [
			'methods' => 'POST', 'callback' => [ $this, 'ai_improve_jd' ], 'permission_callback' => $rec,
		] );
		register_rest_route( $ns, '/ai/salary-negotiate', [
			'methods' => 'POST', 'callback' => [ $this, 'ai_salary_negotiate' ], 'permission_callback' => $auth,
		] );
		register_rest_route( $ns, '/ai/skill-demand', [
			'methods' => 'GET', 'callback' => [ $this, 'ai_skill_demand' ], 'permission_callback' => $auth,
		] );

		// ── Auth ──────────────────────────────────────────────────────────────
		// Root-cause fix: this route was entirely missing — see
		// auth_register()'s docblock. registerApi.ts has called
		// POST /auth/register since it was written; nothing here answered.
		register_rest_route( $ns, '/auth/register', [
			'methods' => 'POST', 'callback' => [ $this, 'auth_register' ], 'permission_callback' => $pub,
		] );
		register_rest_route( $ns, '/auth/token', [
			'methods' => 'POST', 'callback' => [ $this, 'auth_token' ], 'permission_callback' => $pub,
		] );
		register_rest_route( $ns, '/auth/me', [
			'methods' => 'GET', 'callback' => [ $this, 'auth_me' ], 'permission_callback' => $auth,
		] );
		// Root-cause fix: auth_token() now actually establishes a real WP
		// cookie session (wp_set_auth_cookie()) — but no endpoint existed
		// anywhere to end one. Before this fix that gap was moot (login
		// never created a session to end), but it can't stay missing now
		// that login works: without this route, no user could ever sign
		// out of the SPA, and the "logged in forever until the cookie
		// expires on its own" state that would leave behind is exactly the
		// kind of gap this audit exists to catch before it reaches a user.
		register_rest_route( $ns, '/auth/logout', [
			'methods' => 'POST', 'callback' => [ $this, 'auth_logout' ], 'permission_callback' => $pub,
		] );
		// Root-cause fix (batch 4: confirmed gap — LoginPage.tsx's "Forgot
		// password?" link pointed at /wp-login.php?action=lostpassword, a
		// legacy WP-core page outside the SPA entirely, and no REST route
		// or SPA page existed for an in-app reset flow — see
		// admin_import_companies()'s own comment above acknowledging this
		// exact absence as the reason it emails a real temp password
		// instead of a reset link). Two routes: request (always returns a
		// generic success message regardless of whether the email exists,
		// to avoid account-enumeration) and perform (validates the signed
		// key WordPress itself generated).
		register_rest_route( $ns, '/auth/forgot-password', [
			'methods' => 'POST', 'callback' => [ $this, 'auth_forgot_password' ], 'permission_callback' => $pub,
		] );
		register_rest_route( $ns, '/auth/reset-password', [
			'methods' => 'POST', 'callback' => [ $this, 'auth_reset_password' ], 'permission_callback' => $pub,
		] );
		// Root-cause fix (batch 7 — see auth_update_password()'s docblock):
		// changing your password while signed in had no route and no SPA
		// UI anywhere; only the forgot/reset-password email flow worked.
		register_rest_route( $ns, '/auth/update-password', [
			'methods' => 'POST', 'callback' => [ $this, 'auth_update_password' ], 'permission_callback' => $auth,
		] );
	}

	// ── Jobs ──────────────────────────────────────────────────────────────────

	public function get_jobs( \WP_REST_Request $r ) {
		$results = JP_Search::instance()->search( [
			'keyword'  => sanitize_text_field( $r->get_param( 'q' ) ?? '' ),
			'location' => sanitize_text_field( $r->get_param( 'location' ) ?? '' ),
			'job_type' => sanitize_key( $r->get_param( 'job_type' ) ?? '' ),
			'work_mode'=> sanitize_key( $r->get_param( 'work_mode' ) ?? '' ),
			'industry' => sanitize_key( $r->get_param( 'industry' ) ?? '' ),
			'sal_min'  => absint( $r->get_param( 'sal_min' ) ?? 0 ),
			'sal_max'  => absint( $r->get_param( 'sal_max' ) ?? 0 ),
			'exp'      => absint( $r->get_param( 'exp' ) ?? 0 ),
			// Batch 27: comma-separated skills list -> sanitized AND-match array.
			'skills'   => array_values( array_filter( array_map(
				'sanitize_text_field',
				explode( ',', (string) ( $r->get_param( 'skills' ) ?? '' ) )
			) ) ),
			'order_by' => sanitize_key( $r->get_param( 'order_by' ) ?? 'created_at' ),
			'order'    => strtoupper( sanitize_key( $r->get_param( 'order' ) ?? 'DESC' ) ),
			'page'     => max( 1, absint( $r->get_param( 'page' ) ?? 1 ) ),
			'per_page' => min( 50, max( 1, absint( $r->get_param( 'per_page' ) ?? 20 ) ) ),
		] );
		return $this->ok( $results );
	}

	public function get_job( \WP_REST_Request $r ) {
		global $wpdb;
		$id  = absint( $r->get_param( 'id' ) );
		$job = $wpdb->get_row( $wpdb->prepare(
			"SELECT j.*,c.name AS company_name,c.logo_url,c.is_verified AS company_verified,c.rating_avg
			 FROM {$wpdb->prefix}jp_jobs j LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id
			 WHERE j.id=%d AND j.status='active'",
			$id
		) );
		if ( ! $job ) return $this->not_found( 'Job not found.' );
		// Increment view (buffered)
		JP_Jobs::instance()->increment_view( $id );
		return $this->ok( $job );
	}

	public function create_job( \WP_REST_Request $r ) {
		$user_id = get_current_user_id();
		$data    = $this->extract_job_data( $r );
		// Root-cause fix (states/forms audit): JobFormPage.tsx never
		// validated the title field client-side (unlike every other form
		// in the codebase, which all check their required fields before
		// calling mutate()), and neither JP_Jobs::create() nor this
		// handler checked it either — a blank title would have been
		// silently inserted (sanitize_title('') produces an empty slug
		// too), publishing an unusable, unfindable "ghost" job listing.
		// Validated here, BEFORE the credit is spent below, so a rejected
		// submission never costs the recruiter a job-posting credit.
		if ( '' === trim( $data['title'] ) ) {
			return $this->error( 'Job title is required.', 400 );
		}
		// Check job posting credit
		if ( ! JP_Subscriptions::instance()->use_credit( $user_id, 'job_posts' ) ) {
			return $this->error( 'Insufficient credits. Please upgrade your plan.', 402 );
		}
		$id = JP_Jobs::instance()->create( $data, $user_id );
		if ( ! $id ) return $this->error( 'Failed to create job.' );
		return $this->ok( [ 'id' => $id, 'message' => 'Job submitted for review.' ], 201 );
	}

	public function update_job( \WP_REST_Request $r ) {
		$id   = absint( $r->get_param( 'id' ) );
		$data = $this->extract_job_data( $r );
		if ( '' === trim( $data['title'] ) ) {
			return $this->error( 'Job title is required.', 400 );
		}
		$ok = JP_Jobs::instance()->update( $id, $data, get_current_user_id() );
		return $ok ? $this->ok( [ 'message' => 'Job updated.' ] ) : $this->error( 'Update failed or permission denied.' );
	}

	public function delete_job( \WP_REST_Request $r ) {
		global $wpdb;
		$id  = absint( $r->get_param( 'id' ) );
		$uid = get_current_user_id();
		$job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_jobs WHERE id=%d", $id ) );
		if ( ! $job ) return $this->not_found( 'Job not found.' );
		if ( (int) $job->posted_by !== $uid && ! current_user_can( 'administrator' ) ) return $this->forbidden();
		$updated = $wpdb->update( $wpdb->prefix . 'jp_jobs', [ 'status' => 'deleted' ], [ 'id' => $id ] );
		if ( false === $updated ) {
			return $this->error( 'Failed to delete job. Please try again.' );
		}
		return $this->ok( [ 'message' => 'Job deleted.' ] );
	}

	public function get_similar_jobs( \WP_REST_Request $r ) {
		global $wpdb;
		$id  = absint( $r->get_param( 'id' ) );
		$job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_jobs WHERE id=%d", $id ) );
		if ( ! $job ) return $this->ok( [] );
		// Find jobs with matching industry or skills
		$industry = esc_sql( $job->industry_slug ?? '' );
		$similar  = $wpdb->get_results( $wpdb->prepare(
			"SELECT j.*,c.name AS company_name FROM {$wpdb->prefix}jp_jobs j
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id
			 WHERE j.status='active' AND j.id!=%d
			 AND (j.industry_slug=%s OR j.work_mode=%s)
			 ORDER BY j.created_at DESC LIMIT 6",
			$id, $industry, $job->work_mode
		) );
		return $this->ok( $similar ?: [] );
	}

	public function apply_job( \WP_REST_Request $r ) {
		global $wpdb;
		$job_id    = absint( $r->get_param( 'id' ) );
		$resume_id = absint( $r->get_param( 'resume_id' ) ?? 0 );
		$cover     = sanitize_textarea_field( $r->get_param( 'cover_letter' ) ?? '' );
		// Root-cause fix (batch 35): this REST endpoint never accepted or
		// forwarded screening-question answers at all — JP_Applications::
		// ajax_apply() (the method this simulates below) has read
		// $_POST['screening_ans'] since it was written, but this was the
		// only real caller of it, and it never set that key, so a candidate
		// answering a job's screening questions in the SPA had those answers
		// silently discarded before ever reaching the database.
		$answers   = array_map( 'sanitize_textarea_field', (array) ( $r->get_param( 'answers' ) ?? [] ) );
		$uid       = get_current_user_id();

		if ( ! $resume_id ) return $this->error( 'resume_id is required.' );
		if ( JP_Applications::instance()->has_applied( $job_id, $uid ) ) {
			return $this->error( 'You have already applied for this job.', 409 );
		}

		// Simulate the AJAX apply — reuse existing logic
		$_POST = [ 'job_id' => $job_id, 'resume_id' => $resume_id, 'cover_letter' => $cover, 'screening_ans' => $answers ];
		ob_start();
		JP_Applications::instance()->ajax_apply();
		$out = json_decode( ob_get_clean(), true );
		return $out['success'] ? $this->ok( $out['data'], 201 ) : $this->error( $out['data']['message'] ?? 'Apply failed.' );
	}

	// ── Companies ─────────────────────────────────────────────────────────────

	/**
	 * Phase 3 redesign (Tier A, redesign-plan §CompaniesPage) — was
	 * keyword-search only despite jp_companies already having real
	 * industry/is_verified/rating_avg columns nothing surfaced as filters
	 * or sorts. All additions below are real column-backed conditions, not
	 * fabricated fields.
	 */
	public function get_companies( \WP_REST_Request $r ) {
		global $wpdb;
		$q        = sanitize_text_field( $r->get_param( 'q' ) ?? '' );
		$industry = sanitize_text_field( $r->get_param( 'industry' ) ?? '' );
		$verified = $r->get_param( 'verified_only' ) === '1';
		$sort     = sanitize_text_field( $r->get_param( 'sort' ) ?? 'jobs' );
		$page     = max( 1, absint( $r->get_param( 'page' ) ?? 1 ) );
		$per      = min( 50, max( 1, absint( $r->get_param( 'per_page' ) ?? 20 ) ) );
		$off      = ( $page - 1 ) * $per;

		$conditions = [ "status='active'" ];
		if ( $q ) $conditions[] = $wpdb->prepare( 'name LIKE %s', '%' . $wpdb->esc_like( $q ) . '%' );
		if ( $industry ) $conditions[] = $wpdb->prepare( 'industry=%s', $industry );
		if ( $verified ) $conditions[] = 'is_verified=1';
		$where = 'WHERE ' . implode( ' AND ', $conditions );

		$order_by = match ( $sort ) {
			'rating' => 'rating_avg DESC, reviews_count DESC',
			'name'   => 'name ASC',
			default  => 'jobs_count DESC',
		};

		$total      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_companies {$where}" );
		$rows       = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}jp_companies {$where} ORDER BY {$order_by} LIMIT {$per} OFFSET {$off}" );
		$industries = $wpdb->get_col( "SELECT DISTINCT industry FROM {$wpdb->prefix}jp_companies WHERE status='active' AND industry IS NOT NULL AND industry<>'' ORDER BY industry ASC" );
		return $this->ok( [
			'companies'  => $rows ?: [],
			'total'      => $total,
			'pages'      => (int) ceil( $total / $per ),
			'industries' => $industries ?: [],
		] );
	}

	public function get_company( \WP_REST_Request $r ) {
		global $wpdb;
		$company = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_companies WHERE id=%d AND status='active'", absint( $r->get_param( 'id' ) ) ) );
		return $company ? $this->ok( $company ) : $this->not_found( 'Company not found.' );
	}

	public function update_company( \WP_REST_Request $r ) {
		global $wpdb;
		$id      = absint( $r->get_param( 'id' ) );
		$uid     = get_current_user_id();
		$company = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_companies WHERE id=%d", $id ) );
		if ( ! $company ) return $this->not_found( 'Company not found.' );
		if ( (int) $company->user_id !== $uid && ! current_user_can( 'administrator' ) ) return $this->forbidden();
		$data = [
			'name'        => sanitize_text_field( $r->get_param( 'name' ) ?? $company->name ),
			'description' => sanitize_textarea_field( $r->get_param( 'description' ) ?? '' ),
			'website'     => esc_url_raw( $r->get_param( 'website' ) ?? '' ),
			'industry'    => sanitize_text_field( $r->get_param( 'industry' ) ?? '' ),
			'size'        => sanitize_text_field( $r->get_param( 'size' ) ?? '' ),
			'location'    => sanitize_text_field( $r->get_param( 'location' ) ?? '' ),
		];
		// Root-cause fix (ghost-success pattern): return value was discarded,
		// so a failed write (DB error) still told the recruiter their
		// company profile saved, while the old values silently remained.
		$updated = $wpdb->update( $wpdb->prefix . 'jp_companies', $data, [ 'id' => $id ] );
		if ( false === $updated ) {
			return $this->error( 'Failed to update company. Please try again.' );
		}
		return $this->ok( [ 'message' => 'Company updated.' ] );
	}

	public function get_company_jobs( \WP_REST_Request $r ) {
		global $wpdb;
		$id   = absint( $r->get_param( 'id' ) );
		$jobs = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_jobs WHERE company_id=%d AND status='active' ORDER BY created_at DESC LIMIT 20", $id
		) );
		return $this->ok( $jobs ?: [] );
	}

	public function get_company_reviews( \WP_REST_Request $r ) {
		global $wpdb;
		$id      = absint( $r->get_param( 'id' ) );
		$page    = max( 1, absint( $r->get_param( 'page' ) ?? 1 ) );
		$per     = 10;
		$offset  = ( $page - 1 ) * $per;
		$reviews = $wpdb->get_results( $wpdb->prepare(
			"SELECT r.*,u.display_name FROM {$wpdb->prefix}jp_reviews r
			 LEFT JOIN {$wpdb->users} u ON u.ID=r.user_id
			 WHERE r.company_id=%d AND r.status='approved'
			 ORDER BY r.created_at DESC LIMIT {$per} OFFSET {$offset}",
			$id
		) );
		// Anonymise as needed
		foreach ( $reviews as &$rev ) {
			if ( $rev->is_anonymous ) $rev->display_name = 'Anonymous Employee';
		}
		return $this->ok( $reviews ?: [] );
	}

	/**
	 * Root-cause fix (batch 17) — see the route registration's docblock
	 * just above /reviews/{id}/vote-helpful.
	 */
	public function vote_review_helpful( \WP_REST_Request $r ) {
		$_POST['review_id'] = $r->get_param( 'id' );
		$_POST['useful']    = 1;
		$out = $this->bridge_ajax( fn() => JP_Reviews::instance()->ajax_vote() );
		return $out['success'] ? $this->ok( $out['data'] ) : $this->error( $out['data']['message'] ?? 'Failed.' );
	}

	public function post_review( \WP_REST_Request $r ) {
		$_POST = array_merge( $_POST, (array) $r->get_params() );
		ob_start();
		JP_Reviews::instance()->ajax_submit();
		$out = json_decode( ob_get_clean(), true );
		return $out['success'] ? $this->ok( $out['data'], 201 ) : $this->error( $out['data'] ?? 'Failed.' );
	}

	// ── Candidates ────────────────────────────────────────────────────────────

	public function get_candidates( \WP_REST_Request $r ) {
		global $wpdb;
		$q        = sanitize_text_field( $r->get_param( 'q' ) ?? '' );
		$location = sanitize_text_field( $r->get_param( 'location' ) ?? '' );
		$skill    = sanitize_text_field( $r->get_param( 'skill' ) ?? '' );
		$exp_min  = absint( $r->get_param( 'exp_min' ) ?? 0 );
		$exp_max  = absint( $r->get_param( 'exp_max' ) ?? 0 );
		$mode     = sanitize_key( $r->get_param( 'work_mode' ) ?? '' );
		$page     = max( 1, absint( $r->get_param( 'page' ) ?? 1 ) );
		// Missing-lower-bound fix (input-validation sweep): every other
		// per_page/limit param in this file clamps to [1,50] — this one
		// only clamped the upper bound. per_page=0 (or any falsy value)
		// meant LIMIT 0, silently returning zero candidates from a search
		// that may have had real matches, with no error to explain why.
		$per      = min( 50, max( 1, absint( $r->get_param( 'per_page' ) ?? 20 ) ) );
		$off      = ( $page - 1 ) * $per;

		$conditions = [ "c.visibility IN ('public','recruiters')" ];
		if ( $q )        $conditions[] = $wpdb->prepare( "(u.display_name LIKE %s OR c.headline LIKE %s OR c.current_title LIKE %s)", '%'.esc_sql($q).'%','%'.esc_sql($q).'%','%'.esc_sql($q).'%' );
		if ( $location )  $conditions[] = $wpdb->prepare( "c.location_city LIKE %s", '%'.esc_sql($location).'%' );
		// Root-cause fix (4-way skills-storage consolidation, §37):
		// c.skills_json is not a real column on jp_candidates (confirmed
		// against the actual schema in class-jp-activator.php) — this
		// condition made the ENTIRE recruiter candidate-search query fail
		// with a SQL error ("Unknown column") the moment a recruiter
		// filtered by skill at all, not just filter incorrectly. Filters
		// via the real jp_user_skills/jp_skills tables instead.
		if ( $skill )     $conditions[] = $wpdb->prepare(
			"c.user_id IN (SELECT us.user_id FROM {$wpdb->prefix}jp_user_skills us JOIN {$wpdb->prefix}jp_skills s ON s.id = us.skill_id WHERE s.name LIKE %s)",
			'%'.esc_sql($skill).'%'
		);
		if ( $exp_min )   $conditions[] = $wpdb->prepare( "c.experience_years >= %d", $exp_min );
		if ( $exp_max )   $conditions[] = $wpdb->prepare( "c.experience_years <= %d", $exp_max );
		if ( $mode )      $conditions[] = $wpdb->prepare( "c.preferred_work_mode IN (%s,'any')", $mode );

		$where = 'WHERE ' . implode( ' AND ', $conditions );

		$rows  = $wpdb->get_results(
			"SELECT c.*,u.display_name,u.user_email
			 FROM {$wpdb->prefix}jp_candidates c
			 LEFT JOIN {$wpdb->users} u ON u.ID=c.user_id
			 {$where} ORDER BY c.profile_score DESC LIMIT {$per} OFFSET {$off}"
		);
		$total = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->prefix}jp_candidates c LEFT JOIN {$wpdb->users} u ON u.ID=c.user_id {$where}"
		);

		// §37: attach each row's declared skills in a single batched query
		// (one query for the whole page of results, not one per row) —
		// same underlying gap as get_me()/get_candidate(): there is no
		// column on jp_candidates itself to have carried this.
		if ( $rows ) {
			$user_ids = array_map( fn( $row ) => (int) $row->user_id, $rows );
			$skills_by_user = [];
			if ( $user_ids ) {
				$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );
				$skill_rows = $wpdb->get_results( $wpdb->prepare(
					"SELECT us.user_id, s.name FROM {$wpdb->prefix}jp_user_skills us
					 JOIN {$wpdb->prefix}jp_skills s ON s.id = us.skill_id
					 WHERE us.user_id IN ({$placeholders})",
					$user_ids
				) );
				foreach ( $skill_rows as $sr ) $skills_by_user[ (int) $sr->user_id ][] = $sr->name;
			}
			foreach ( $rows as $row ) $row->skills = $skills_by_user[ (int) $row->user_id ] ?? [];
		}

		return $this->ok( [ 'candidates' => $rows ?: [], 'total' => $total ] );
	}

	public function get_me( \WP_REST_Request $r ) {
		$uid  = get_current_user_id();
		$user = get_userdata( $uid );
		$cand = JP_DB::instance()->get_candidate( $uid );
		// §37: skills live in jp_user_skills, not a column on $cand itself
		// (there is no such column) — attach them explicitly so the
		// profile-editor UI this feeds actually has something to bind a
		// "my skills" field to and to round-trip back through
		// update_profile()'s new 'skills' param.
		if ( $cand ) $cand->skills = JP_DB::instance()->get_user_skill_names( $uid );
		return $this->ok( [
			'id'          => $uid,
			'name'        => $user->display_name,
			'email'       => $user->user_email,
			'role'        => jp_current_role(),
			'plan'        => get_user_meta( $uid, 'jp_plan', true ) ?: 'starter',
			'candidate'   => $cand,
		] );
	}

	public function update_profile( \WP_REST_Request $r ) {
		$uid = get_current_user_id();
		$this->apply_profile_update( $uid, (array) $r->get_params() );
		return $this->ok( [ 'message' => 'Profile updated.' ] );
	}

	/**
	 * §37: shared save logic for BOTH the REST PUT /candidates/me endpoint
	 * (update_profile(), above) and the classic-AJAX jp_update_profile
	 * action (ajax_update_profile(), below) — the theme's own
	 * #jp-profile-form has only ever called the latter, so before this
	 * bridge existed the REST endpoint's whitelist/skills-replace logic
	 * was itself an orphaned capability with no real caller (see the
	 * ajax_update_profile() docblock). Keeping one shared method means the
	 * field whitelist and skills semantics can't drift between the two
	 * entry points the way they briefly did during this fix (the REST
	 * whitelist was originally missing 'current_salary',
	 * 'notice_period_days', 'portfolio_url', and 'visibility' — all real
	 * jp_candidates columns that the theme's form has always tried to
	 * save; confirmed against class-jp-activator.php's CREATE TABLE before
	 * adding them here).
	 *
	 * @param array $params Raw request params — WP_REST_Request::get_params()
	 *                       for the REST path, or wp_unslash($_POST) for the
	 *                       classic-AJAX path. Untrusted either way; every
	 *                       field is whitelisted and sanitized below.
	 */
	private function apply_profile_update( int $uid, array $params ): void {
		global $wpdb;
		$data = array_intersect_key( $params, array_flip( [
			'headline','about','location_city','location_state','phone',
			'experience_years','current_title','current_company',
			'linkedin_url','github_url','portfolio_url',
			'current_salary','expected_salary_min','expected_salary_max',
			'notice_period_days','preferred_work_mode',
			'willing_to_relocate','is_open_to_work','visibility',
		] ) );
		foreach ( $data as $k => &$v ) $v = is_numeric( $v ) ? (int) $v : sanitize_text_field( (string) $v );
		unset( $v );
		if ( ! empty( $data ) ) $wpdb->update( $wpdb->prefix . 'jp_candidates', $data, [ 'user_id' => $uid ] );

		// display_name lives on wp_users, not jp_candidates — the theme's
		// form includes it (it's the first field on the page) but the old
		// whitelist above could never have saved it even if the AJAX
		// action had existed, since $wpdb->update() above only ever
		// targets jp_candidates.
		if ( array_key_exists( 'display_name', $params ) && '' !== trim( (string) $params['display_name'] ) ) {
			wp_update_user( [ 'ID' => $uid, 'display_name' => sanitize_text_field( $params['display_name'] ) ] );
		}

		// Root-cause fix (4-way skills-storage consolidation, §37): this
		// whitelist never included 'skills' at all — there was previously
		// NO way, anywhere in this system, for a candidate to explicitly
		// declare a skill on their own profile. 'skills' now replaces the
		// candidate's full declared skill list via
		// JP_DB::replace_user_skills() — "replace," not "merge," because
		// this is an explicit profile-editor save: a candidate removing a
		// skill from the form must actually see it gone, unlike resume
		// auto-populate's additive merge (see class-jp-db.php's docblock
		// on why those two need different semantics). Omitting the key
		// entirely (vs. sending an empty value) leaves existing skills
		// untouched, matching how every other field here already behaves
		// as a partial update. Accepts either a real array (REST/JSON
		// body) or a comma-separated string (the classic-AJAX path's new
		// #jp-skills text input, submitted as a single form field).
		if ( array_key_exists( 'skills', $params ) ) {
			$raw    = $params['skills'];
			$skills = is_array( $raw )
				? $raw
				: array_filter( array_map( 'trim', explode( ',', (string) $raw ) ), 'strlen' );
			JP_DB::instance()->replace_user_skills( $uid, array_map( 'sanitize_text_field', $skills ) );
		}
	}

	/**
	 * Classic-AJAX bridge for jp-theme-fixed's #jp-profile-form.
	 *
	 * ROOT CAUSE this closes: the form has always posted to admin-ajax.php
	 * with action=jp_update_profile (see assets/js/dashboard.js,
	 * JPApp.profileSave), and the form itself has always rendered a
	 * correctly-named nonce field via wp_nonce_field('jp_update_profile',
	 * 'nonce') — but jp-core never registered a
	 * wp_ajax_jp_update_profile handler to receive it. A repo-wide grep
	 * for "jp_update_profile" across every includes/*.php file, run
	 * before this fix, returned zero matches outside the theme itself.
	 * Every submit of this form silently did nothing (the JS .catch()
	 * fallback shows a toast admitting the action doesn't exist) — this
	 * was not a partial save, it was a total no-op for every candidate
	 * who ever tried to edit headline, phone, location, about, career
	 * details, or (as of this fix) skills.
	 */
	public function ajax_update_profile(): void {
		jp_verify_nonce( 'jp_update_profile' );

		$uid = get_current_user_id();
		if ( ! $uid || 'jp_job_seeker' !== jp_current_role() ) {
			jp_json_response( __( 'Permission denied.', 'jp-core' ), false, 403 );
		}

		$this->apply_profile_update( $uid, wp_unslash( $_POST ) );
		jp_json_response( [ 'message' => __( 'Profile updated.', 'jp-core' ) ] );
	}

	public function get_candidate( \WP_REST_Request $r ) {
		$id   = absint( $r->get_param( 'id' ) );
		$cand = JP_DB::instance()->get_candidate( $id );
		// §37: same skills attachment as get_me() — a recruiter viewing a
		// candidate's profile needs to see their declared skills too, and
		// there is no column on $cand itself to have carried them.
		if ( $cand ) $cand->skills = JP_DB::instance()->get_user_skill_names( (int) ( $cand->user_id ?? 0 ) );
		return $cand ? $this->ok( $cand ) : $this->not_found( 'Candidate not found.' );
	}

	public function get_matches( \WP_REST_Request $r ) {
		return $this->ok( JP_Matching::instance()->get_matches_for_candidate( get_current_user_id() ) );
	}

	/**
	 * TRACE: POST /candidates/me/matches/{job_id}/dismiss, any logged-in
	 * candidate → INSERT IGNORE into jp_match_dismissals (idempotent — a
	 * repeat dismiss of the same job is a no-op, not an error) →
	 * get_matches_for_candidate() (both its pre-computed and real-time-
	 * fallback paths) excludes dismissed job ids from then on.
	 * Preconditions: job_id is a positive integer.
	 * Postconditions: a jp_match_dismissals row exists for
	 * (candidate_id, job_id); the job no longer appears in this
	 * candidate's /candidates/me/matches response.
	 * Edge cases handled: dismissing a job with no existing match row
	 * (fallback path never persisted one) still works, since dismissal is
	 * keyed on candidate+job, not on a jp_matches row id; a failed insert
	 * returns a real error rather than a false "dismissed" message.
	 */
	public function dismiss_match( \WP_REST_Request $r ) {
		global $wpdb;
		$job_id    = absint( $r->get_param( 'job_id' ) );
		if ( ! $job_id ) return $this->error( 'Invalid job.' );
		// jp_matches.candidate_id is jp_candidates.id, NOT the WP user id
		// (see get_matches_for_candidate()'s own queries) — dismissals must
		// use the same key so the exclusion join lines up.
		$candidate = JP_DB::instance()->get_candidate( get_current_user_id() );
		if ( ! $candidate ) return $this->error( 'Candidate profile not found.' );
		$result = $wpdb->query( $wpdb->prepare(
			"INSERT IGNORE INTO {$wpdb->prefix}jp_match_dismissals (candidate_id, job_id, dismissed_at) VALUES (%d,%d,%s)",
			$candidate->id, $job_id, current_time( 'mysql' )
		) );
		if ( false === $result ) {
			return $this->error( 'Could not dismiss this recommendation. Please try again.' );
		}
		return $this->ok( [ 'message' => 'Dismissed. We won\'t recommend this job again.' ] );
	}

	// ── Applications ──────────────────────────────────────────────────────────

	public function get_applications( \WP_REST_Request $r ) {
		global $wpdb;
		$uid   = get_current_user_id();
		$role  = jp_current_role();
		$stage = sanitize_key( $r->get_param( 'stage' ) ?? '' );
		$page  = max( 1, absint( $r->get_param( 'page' ) ?? 1 ) );
		$per   = 20;
		$off   = ( $page - 1 ) * $per;

		if ( in_array( $role, [ 'jp_job_seeker' ], true ) ) { // Fixed: was 'jp_candidate' (wrong role slug)
			$where = $wpdb->prepare( "WHERE a.candidate_id=%d", $uid );
		} else {
			$where = $wpdb->prepare( "WHERE j.posted_by=%d", $uid );
		}
		if ( $stage ) $where .= $wpdb->prepare( " AND a.stage=%s", $stage );

		$rows = $wpdb->get_results(
			"SELECT a.*,j.title AS job_title,u.display_name AS candidate_name
			 FROM {$wpdb->prefix}jp_applications a
			 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id
			 LEFT JOIN {$wpdb->users} u ON u.ID=a.candidate_id
			 {$where} ORDER BY a.created_at DESC LIMIT {$per} OFFSET {$off}"
		);
		return $this->ok( $rows ?: [] );
	}

	public function get_application( \WP_REST_Request $r ) {
		global $wpdb;
		$id  = absint( $r->get_param( 'id' ) );
		$uid = get_current_user_id();
		$app = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_applications WHERE id=%d", $id ) );
		if ( ! $app ) return $this->not_found( 'Application not found.' );
		$is_owner_candidate = (int) $app->candidate_id === $uid;
		// Root-cause fix (batch 37): this previously only checked the
		// requester's *role* ("is some kind of recruiter"), not that this
		// specific recruiter's company actually owns the job this
		// application belongs to — any recruiter account could view any
		// other company's application detail by id. Now reuses the same
		// ownership check the note/tags/stage endpoints already enforce.
		if ( ! $is_owner_candidate
			&& ! JP_Applications::instance()->user_can_manage_application( $app )
			&& ! current_user_can( 'manage_options' )
		) return $this->forbidden();

		// New in batch 37 (recruiter ATS pipeline depth): join the display
		// fields a detail view needs (job/company/candidate/resume) so the
		// SPA doesn't have to issue N follow-up requests just to render one
		// application's context.
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT a.*, j.title AS job_title, c.name AS company_name,
			        u.display_name AS candidate_name, u.user_email AS candidate_email,
			        res.id AS resume_id_full, res.file_name AS resume_file_name
			 FROM {$wpdb->prefix}jp_applications a
			 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id = a.job_id
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id = a.company_id
			 LEFT JOIN {$wpdb->users} u ON u.ID = a.candidate_id
			 LEFT JOIN {$wpdb->prefix}jp_resumes res ON res.id = a.resume_id
			 WHERE a.id = %d",
			$id
		) );
		if ( $row ) {
			$row->screening_ans = json_decode( $row->screening_ans ?? '[]', true ) ?: [];
			$history = json_decode( $row->stage_history ?? '[]', true ) ?: [];
			// Privacy/root-cause fix (batch 38): `notes` (internal recruiter
			// notes, JP_Applications::ajax_add_note()), `tags` (internal
			// pipeline-organization labels), and each stage_history entry's
			// free-text `note` + `actor_id` are recruiter-team-only by
			// design — nothing in this codebase has ever told a recruiter
			// that text typed into a stage-change note is candidate-facing
			// (RecruiterApplicationsPage doesn't even collect one yet), so
			// treating it as visible the moment this endpoint started
			// returning it (added this same slice, batch 37) would leak
			// internal shorthand/commentary to the candidate without any
			// recruiter opt-in. Candidates keep the stage+timestamp
			// sequence (genuinely useful "what happened when" transparency)
			// with the internal commentary stripped; recruiter/admin
			// callers (already ownership-checked above) get everything.
			if ( $is_owner_candidate ) {
				$row->notes = [];
				$row->tags  = [];
				$row->stage_history = array_map(
					fn( $h ) => [ 'stage' => $h['stage'] ?? '', 'timestamp' => $h['timestamp'] ?? '' ],
					$history
				);
			} else {
				$row->notes         = json_decode( $row->notes ?? '[]', true ) ?: [];
				$row->tags          = json_decode( $row->tags ?? '[]', true ) ?: [];
				$row->stage_history = $history;
			}
		}
		return $this->ok( $row ?: $app );
	}

	/**
	 * New in batch 37: get_application() joins the applicant's resume row
	 * but streaming the actual file needs its own gated endpoint —
	 * JP_Resume::ajax_download() only permits the resume's *owner*
	 * (the candidate), so a recruiter viewing an application detail had no
	 * way to actually open the attached resume even though the file
	 * existed and the recruiter was legitimately allowed to see it. Scoped
	 * to "can manage this specific application" rather than loosening
	 * ajax_download() itself, which would let any authenticated recruiter
	 * fetch any candidate's resume by guessing a resume_id.
	 */
	public function view_application_resume( \WP_REST_Request $r ) {
		global $wpdb;
		$id  = absint( $r->get_param( 'id' ) );
		$uid = get_current_user_id();
		$app = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_applications WHERE id=%d", $id ) );
		if ( ! $app ) return $this->not_found( 'Application not found.' );
		if ( (int) $app->candidate_id !== $uid
			&& ! JP_Applications::instance()->user_can_manage_application( $app )
			&& ! current_user_can( 'manage_options' )
		) return $this->forbidden();
		if ( ! $app->resume_id ) return $this->not_found( 'No resume attached to this application.' );
		$resume = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_resumes WHERE id=%d", (int) $app->resume_id ) );
		if ( ! $resume || ! file_exists( $resume->file_path ) ) return $this->not_found( 'Resume file not found.' );
		// Matches the established REST-download shape used by the CSV
		// export endpoints above (WP_REST_Response + explicit headers)
		// rather than raw readfile()+exit, which bypasses the REST response
		// pipeline (rest_pre_serve_request, envelope/CORS handling, etc.)
		// that every other download endpoint in this file goes through.
		return new \WP_REST_Response( file_get_contents( $resume->file_path ), 200, [
			'Content-Type'        => 'application/octet-stream',
			'Content-Disposition' => 'attachment; filename="' . esc_attr( $resume->file_name ) . '"',
		] );
	}

	public function move_stage( \WP_REST_Request $r ) {
		$_POST['app_id'] = $r->get_param( 'id' );
		$_POST['stage']  = $r->get_param( 'stage' );
		$_POST['note']   = $r->get_param( 'note' ) ?? '';
		ob_start();
		JP_Applications::instance()->ajax_move_stage();
		$out = json_decode( ob_get_clean(), true );
		return $out['success'] ? $this->ok( $out['data'] ) : $this->error( $out['data']['message'] ?? 'Failed.' );
	}

	/**
	 * Root-cause fix (batch 16) — see the route registration's docblock.
	 * Thin wrapper over ajax_withdraw(), matching move_stage()'s own
	 * ob_start()/json_decode() bridging pattern immediately above (not
	 * bridge_ajax(), for consistency with this specific sibling method).
	 */
	public function withdraw_application( \WP_REST_Request $r ) {
		$_POST['app_id'] = $r->get_param( 'id' );
		ob_start();
		JP_Applications::instance()->ajax_withdraw();
		$out = json_decode( ob_get_clean(), true );
		return $out['success'] ? $this->ok( $out['data'] ) : $this->error( $out['data']['message'] ?? 'Failed.' );
	}

	public function generate_offer( \WP_REST_Request $r ) {
		$app_id = absint( $r->get_param( 'id' ) );
		$ctc    = absint( $r->get_param( 'offer_ctc' ) ?? 0 );
		$result = JP_Applications::instance()->do_generate_offer( $app_id, $ctc );
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
		return $this->ok( $result );
	}

	public function submit_offer_response( \WP_REST_Request $r ) {
		$app_id   = absint( $r->get_param( 'id' ) );
		$response = sanitize_key( $r->get_param( 'response' ) ?? '' );
		$result   = JP_Applications::instance()->do_offer_response( $app_id, $response, get_current_user_id() );
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
		return $this->ok( $result );
	}

	/** Read model backing the SPA's offer view — null envelope means no e-signature is in flight; the caller falls back to the existing in-app accept/decline UI. */
	public function get_esign_status( \WP_REST_Request $r ) {
		$app_id = absint( $r->get_param( 'id' ) );
		return $this->ok( [ 'envelope' => JP_ESign::instance()->get_envelope_for_application( $app_id ) ] );
	}

	/**
	 * DocuSign Connect posts here on every envelope status change. Public
	 * route (see registration docblock) — authenticated by a shared-secret
	 * query param configured as the Connect subscription's callback URL
	 * suffix, e.g. .../esign/webhook?secret=xxxx, matched against
	 * jp_esign_webhook_secret. A wrong/missing secret returns 403 without
	 * ever reaching JP_ESign::handle_webhook(), so an unauthenticated
	 * caller cannot forge an "offer accepted" event.
	 */
	public function esign_webhook( \WP_REST_Request $r ) {
		$configured_secret = (string) get_option( 'jp_esign_webhook_secret', '' );
		$given_secret      = (string) ( $r->get_param( 'secret' ) ?? '' );
		if ( '' === $configured_secret || ! hash_equals( $configured_secret, $given_secret ) ) {
			return $this->forbidden();
		}
		$payload = $r->get_json_params();
		if ( ! is_array( $payload ) || empty( $payload ) ) $payload = $r->get_params();
		$result = JP_ESign::instance()->handle_webhook( (array) $payload );
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message() );
		return $this->ok( $result );
	}

	// ── Job feed import (JP_JobFeed) ─────────────────────────────────────────

	public function admin_run_job_feed_import( \WP_REST_Request $r ) {
		$summary = JP_JobFeed::instance()->run_import();
		return $this->ok( $summary );
	}

	public function admin_job_feed_status( \WP_REST_Request $r ) {
		return $this->ok( JP_JobFeed::instance()->last_run_summary() );
	}

	// ── Search ────────────────────────────────────────────────────────────────

	public function search( \WP_REST_Request $r ) {
		return $this->get_jobs( $r ); // Search IS get_jobs with filters
	}

	// ── Alerts ────────────────────────────────────────────────────────────────

	public function get_alerts( \WP_REST_Request $r ) {
		global $wpdb;
		$alerts = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_alerts WHERE user_id=%d ORDER BY created_at DESC",
			get_current_user_id()
		) );
		return $this->ok( $alerts ?: [] );
	}

	public function create_alert( \WP_REST_Request $r ) {
		$_POST = array_merge( $_POST, (array) $r->get_params() );
		$out = $this->bridge_ajax( fn() => JP_Alerts::instance()->ajax_save() );
		return $out['success'] ? $this->ok( $out['data'], 201 ) : $this->error( $out['data'] );
	}

	public function delete_alert( \WP_REST_Request $r ) {
		$_POST['alert_id'] = $r->get_param( 'id' );
		$out = $this->bridge_ajax( fn() => JP_Alerts::instance()->ajax_delete() );
		return $out['success'] ? $this->ok( $out['data'] ) : $this->error( $out['data'] );
	}

	public function toggle_alert( \WP_REST_Request $r ) {
		$_POST['alert_id'] = $r->get_param( 'id' );
		$out = $this->bridge_ajax( fn() => JP_Alerts::instance()->ajax_toggle() );
		return $out['success'] ? $this->ok( $out['data'] ) : $this->error( $out['data'] );
	}

	// ── Messaging ─────────────────────────────────────────────────────────────

	/**
	 * Phase 3 redesign (Tier A, redesign-plan §MessagesPage) — root-cause
	 * fix: this used to return every thread the user is part of with no
	 * is_archived filter at all, so an archived conversation (once
	 * archive_thread() below made archiving possible) would still clutter
	 * the main inbox. Defaults to the active (non-archived) list, matching
	 * every other list page's "show the live set by default" convention;
	 * `archived=1` surfaces the archived set for a dedicated tab.
	 */
	public function get_threads( \WP_REST_Request $r ) {
		global $wpdb;
		$uid      = get_current_user_id();
		$archived = $r->get_param( 'archived' ) === '1' ? 1 : 0;
		$threads  = $wpdb->get_results( $wpdb->prepare(
			"SELECT t.*,j.title AS job_title,
			        ru.display_name AS recruiter_name,cu.display_name AS candidate_name
			 FROM {$wpdb->prefix}jp_message_threads t
			 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=t.job_id
			 LEFT JOIN {$wpdb->users} ru ON ru.ID=t.recruiter_id
			 LEFT JOIN {$wpdb->users} cu ON cu.ID=t.candidate_id
			 WHERE (t.recruiter_id=%d OR t.candidate_id=%d) AND t.is_archived=%d
			 ORDER BY t.last_at DESC LIMIT 50",
			$uid, $uid, $archived
		) );
		return $this->ok( $threads ?: [] );
	}

	/**
	 * Toggles is_archived for a thread the caller is actually part of
	 * (recruiter_id or candidate_id must match — same ownership pattern as
	 * mark_thread_read()/send_message() above, so one user can't archive
	 * another user's conversation by guessing an id).
	 */
	public function archive_thread( \WP_REST_Request $r ) {
		global $wpdb;
		$id     = absint( $r->get_param( 'id' ) );
		$uid    = get_current_user_id();
		$thread = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_message_threads WHERE id=%d", $id ) );
		if ( ! $thread ) return $this->not_found( 'Conversation not found.' );
		if ( (int) $thread->recruiter_id !== $uid && (int) $thread->candidate_id !== $uid ) return $this->forbidden();
		$archive = $r->get_param( 'archived' ) === '0' ? 0 : 1;
		$updated = $wpdb->update( $wpdb->prefix . 'jp_message_threads', [ 'is_archived' => $archive ], [ 'id' => $id ] );
		if ( false === $updated ) {
			return $this->error( 'Could not update this conversation. Please try again.' );
		}
		return $this->ok( [ 'message' => $archive ? 'Conversation archived.' : 'Conversation restored.' ] );
	}

	public function create_thread( \WP_REST_Request $r ) {
		$uid       = get_current_user_id();
		$recipient = absint( $r->get_param( 'recipient_id' ) ?? 0 );
		$job_id    = absint( $r->get_param( 'job_id' ) ?? 0 );
		$thread_id = JP_Messaging::instance()->get_or_create_thread( $uid, $recipient, $job_id );
		return $this->ok( [ 'thread_id' => $thread_id ], 201 );
	}

	public function get_thread_messages( \WP_REST_Request $r ) {
		global $wpdb;
		$thread_id = absint( $r->get_param( 'id' ) );
		$since     = sanitize_text_field( $r->get_param( 'since' ) ?? '' );
		$uid       = get_current_user_id();
		$thread    = JP_Messaging::instance()->get_thread( $thread_id );
		if ( ! $thread || ! in_array( $uid, [ (int) $thread->recruiter_id, (int) $thread->candidate_id ], true ) ) {
			return $this->ok( [] );
		}
		$sql = "SELECT m.*,u.display_name FROM {$wpdb->prefix}jp_messages m LEFT JOIN {$wpdb->users} u ON u.ID=m.sender_id WHERE m.thread_id=%d";
		$p   = [ $thread_id ];
		if ( $since ) { $sql .= ' AND m.created_at>%s'; $p[] = $since; }
		$sql .= ' ORDER BY m.created_at ASC LIMIT 100';
		return $this->ok( $wpdb->get_results( $wpdb->prepare( $sql, ...$p ) ) ?: [] );
	}

	public function send_message( \WP_REST_Request $r ) {
		$_POST['thread_id'] = $r->get_param( 'id' );
		$_POST['body']      = $r->get_param( 'body' );
		$out = $this->bridge_ajax( fn() => JP_Messaging::instance()->ajax_send() );
		return $out['success'] ? $this->ok( $out['data'], 201 ) : $this->error( $out['data']['message'] ?? 'Failed.' );
	}

	public function mark_thread_read( \WP_REST_Request $r ) {
		$_POST['thread_id'] = $r->get_param( 'id' );
		$out = $this->bridge_ajax( fn() => JP_Messaging::instance()->ajax_mark_read() );
		// ajax_mark_read() calls jp_json_response(false, '<string message>')
		// on failure, not an array — same convention as every other
		// bridge_ajax() call site in this file (e.g. create_alert() above).
		return $out['success'] ? $this->ok( $out['data'] ) : $this->error( is_string( $out['data'] ) ? $out['data'] : 'Failed.' );
	}

	public function get_canned_responses( \WP_REST_Request $r ) {
		return $this->ok( JP_Messaging::instance()->do_list_canned( get_current_user_id() ) );
	}

	public function create_canned_response( \WP_REST_Request $r ) {
		$result = JP_Messaging::instance()->do_save_canned(
			get_current_user_id(),
			(string) ( $r->get_param( 'title' ) ?? '' ),
			(string) ( $r->get_param( 'body' ) ?? '' )
		);
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
		return $this->ok( $result, 201 );
	}

	public function delete_canned_response( \WP_REST_Request $r ) {
		$result = JP_Messaging::instance()->do_delete_canned( absint( $r->get_param( 'id' ) ), get_current_user_id() );
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
		return $this->ok( $result );
	}

	// ── Analytics ─────────────────────────────────────────────────────────────

	public function track_event( \WP_REST_Request $r ) {
		$event  = sanitize_key( $r->get_param( 'event' ) ?? '' );
		$obj_id = absint( $r->get_param( 'object_id' ) ?? 0 );
		if ( $event && $obj_id ) JP_Analytics::instance()->track( $event, $obj_id );
		return $this->ok( [ 'ok' => true ] );
	}

	/**
	 * Root-cause fix (batch 5 — found in the same pass as jp_view_audit_log/
	 * jp_system_config: a FOURTH declared-but-never-checked capability).
	 * jp_view_analytics is granted to jp_admin_manager (class-jp-roles.php)
	 * specifically so a non-`administrator` admin role can see the
	 * platform-wide dashboard AdminAnalyticsPage.tsx renders — but this
	 * branch checked literal current_user_can('administrator') only, so a
	 * jp_admin_manager hitting this endpoint (which this route's
	 * permission_callback, $auth, lets any logged-in user reach) fell into
	 * the company_summary() branch instead, same as a job seeker or
	 * recruiter would, getting an empty/irrelevant result instead of the
	 * platform view their role's own declared capability says they should
	 * see. Widened to also accept jp_view_analytics — doesn't change what
	 * `administrator` sees (unchanged branch for that case), only fixes
	 * jp_admin_manager's.
	 */
	public function analytics_dashboard( \WP_REST_Request $r ) {
		$days    = min( 90, max( 1, absint( $r->get_param( 'days' ) ?? 30 ) ) );
		$user_id = get_current_user_id();
		$company = JP_DB::instance()->get_company_by_user( $user_id );
		$data    = ( current_user_can( 'administrator' ) || current_user_can( 'jp_view_analytics' ) )
			? JP_Analytics::instance()->platform_summary( $days )
			: JP_Analytics::instance()->company_summary( ( isset($company->id) ? $company->id : 0 ), $days );
		return $this->ok( $data );
	}

	// ── Admin ─────────────────────────────────────────────────────────────────

	public function admin_pending_jobs( \WP_REST_Request $r ) {
		global $wpdb;
		$jobs = $wpdb->get_results(
			"SELECT j.*,c.name AS company_name,u.display_name AS posted_by_name
			 FROM {$wpdb->prefix}jp_jobs j
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id
			 LEFT JOIN {$wpdb->users} u ON u.ID=j.posted_by
			 WHERE j.status='pending' ORDER BY j.created_at ASC LIMIT 50"
		);
		return $this->ok( $jobs ?: [] );
	}

	public function admin_approve_job( \WP_REST_Request $r ) {
		global $wpdb;
		$id      = absint( $r->get_param( 'id' ) );
		$approve = (bool) $r->get_param( 'approve' );
		$status  = $approve ? 'active' : 'rejected';
		// Phase 3 redesign pass — found while wiring the rejection-reason
		// capture the audit called for: this write's return value was never
		// checked (the ghost-success pattern already fixed ~7 other places
		// this session — update_event/update_company/update_recruiter_company/
		// delete_job/admin_verify_company/etc.). A failed update here used to
		// still report "Job active."/"Job rejected." even though the row was
		// untouched. Also: reject now optionally stores a reason (real new
		// rejection_reason column — see class-jp-activator.php) so the
		// recruiter/admin history isn't just a bare status flip.
		$reason = $approve ? null : sanitize_textarea_field( $r->get_param( 'reason' ) ?? '' );
		$updated = $wpdb->update(
			$wpdb->prefix . 'jp_jobs',
			[ 'status' => $status, 'rejection_reason' => $reason ?: null ],
			[ 'id' => $id ]
		);
		if ( false === $updated ) {
			return $this->error( 'Failed to update this job. Please try again.' );
		}
		if ( $approve ) {
			do_action( 'jp_job_published', $id );
			JP_Search::instance()->index_job( $id );
		}
		JP_Security::instance()->audit( 'job_' . $status, 'job', $id );
		return $this->ok( [ 'message' => 'Job ' . $status . '.' ] );
	}

	/**
	 * TRACE: POST /admin/jobs/bulk-approve, jp_approve_jobs cap → loops the
	 * given job ids applying the same approve/reject write as
	 * admin_approve_job() (one query per id — jp_jobs has no natural
	 * multi-row UPDATE here since a rejection reason is per-job free text,
	 * not a shared value) → returns per-id success/failure counts so a
	 * partial failure is visible rather than silently swallowed.
	 * Preconditions: ids is a non-empty array of positive integers.
	 * Postconditions: each valid id's status (and rejection_reason, for
	 * rejects) is updated; approved jobs are published+indexed exactly as
	 * the single-job path does; every write's return value is checked.
	 * Edge cases handled: empty/invalid id list (400), a failed write for
	 * one id does not abort the rest, and the response tells the caller
	 * exactly which ids failed rather than reporting blanket success.
	 */
	public function admin_bulk_approve_jobs( \WP_REST_Request $r ) {
		global $wpdb;
		$ids     = array_map( 'absint', (array) ( $r->get_param( 'ids' ) ?? [] ) );
		$ids     = array_values( array_filter( $ids, fn( $id ) => $id > 0 ) );
		$approve = (bool) $r->get_param( 'approve' );
		$reason  = $approve ? null : sanitize_textarea_field( $r->get_param( 'reason' ) ?? '' );
		if ( empty( $ids ) ) return $this->error( 'No jobs selected.' );

		$status  = $approve ? 'active' : 'rejected';
		$succeeded = [];
		$failed    = [];
		foreach ( $ids as $id ) {
			$updated = $wpdb->update(
				$wpdb->prefix . 'jp_jobs',
				[ 'status' => $status, 'rejection_reason' => $reason ?: null ],
				[ 'id' => $id ]
			);
			if ( false === $updated ) {
				$failed[] = $id;
				continue;
			}
			$succeeded[] = $id;
			if ( $approve ) {
				do_action( 'jp_job_published', $id );
				JP_Search::instance()->index_job( $id );
			}
			JP_Security::instance()->audit( 'job_' . $status, 'job', $id );
		}

		return $this->ok( [
			'message'   => count( $succeeded ) . ' job' . ( count( $succeeded ) === 1 ? '' : 's' ) . ' ' . $status . '.' . ( $failed ? ' ' . count( $failed ) . ' failed.' : '' ),
			'succeeded' => $succeeded,
			'failed'    => $failed,
		] );
	}

	/**
	 * Root-cause fix (gap analysis P1 #185, #208: "Live, uncached aggregate
	 * queries power admin stats/analytics dashboards on every page load").
	 * This endpoint ran 6 unindexed-by-nothing-but-status COUNT/SUM queries
	 * against jp_jobs/jp_companies/jp_candidates/jp_applications/jp_payments
	 * on every single request — including every admin dashboard page load
	 * and refresh, with no caching at all, despite JP_Cache::remember()
	 * already existing and already used elsewhere in this codebase for
	 * exactly this pattern. A 60-second TTL keeps the numbers fresh enough
	 * for a dashboard glance (nobody needs sub-minute precision on "total
	 * active jobs") while collapsing what could be dozens of admin page
	 * loads per minute down to one real query batch per minute.
	 */
	public function admin_stats( \WP_REST_Request $r ) {
		return $this->ok( JP_Cache::remember( 'admin_stats', function () {
			global $wpdb;
			return [
				'total_jobs'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_jobs WHERE status='active'" ),
				'total_companies'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_companies WHERE status='active'" ),
				'total_candidates' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_candidates" ),
				'total_apps'       => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications" ),
				'pending_jobs'     => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_jobs WHERE status='pending'" ),
				'revenue_month'    => (int) $wpdb->get_var( "SELECT SUM(amount) FROM {$wpdb->prefix}jp_payments WHERE status='paid' AND paid_at>=DATE_FORMAT(NOW(),'%Y-%m-01')" ),
				// Phase 3 redesign pass — AdminHomePage's audit flagged it as
				// needing a real KPI dashboard including "today's signups".
				// WP core's own users table has user_registered for every
				// account type (candidate + recruiter both register through
				// wp_insert_user() per auth_register()'s docblock), so this
				// is a real count against real data, not a placeholder.
				'new_signups_today' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->users} WHERE DATE(user_registered)=CURDATE()" ),
			];
		}, 60, 'admin_stats' ) );
	}

	// ── Auth / JWT ────────────────────────────────────────────────────────────

	/**
	 * Root-cause fix (found while building CSV company-import — needed a
	 * reference for how a company row should be created, and there was
	 * none: no /auth/register REST route exists ANYWHERE in this file).
	 * features/auth/registerApi.ts's own docblock says it "wraps POST
	 * /wp-json/jp/v1/auth/register", and RegisterPage.tsx calls it as the
	 * ONLY way anyone signs up through the live SPA — confirmed via a
	 * repo-wide grep for 'auth/register' and 'auth_register' across
	 * includes/, both came back with zero matches before this fix. The
	 * legacy AJAX path (JP_Auth::ajax_register(), jp-theme-fixed only, not
	 * live per ARCHITECTURE.md) exists but the REST-only SPA can never
	 * reach it. Net effect before this fix: registration was completely
	 * broken for every real user of the live site — every submission of
	 * this form 404'd. Validation rules are transcribed from
	 * ajax_register() so both paths agree (email format, 8-char min
	 * password, name required, email not already registered), with one
	 * correctness fix layered in: ajax_register() never created a
	 * `jp_companies` row for a recruiter signup at all (job_seeker got a
	 * `jp_candidates` row, recruiter got nothing) — every downstream
	 * feature that resolves "this recruiter's company" via
	 * JP_DB::get_company_by_user() (job posting, team management, company
	 * profile) would have silently failed for every recruiter who ever
	 * signed up. Fixed here at the one REST path that's actually reachable.
	 */
	public function auth_register( \WP_REST_Request $r ) {
		// Registration-spam / brute-force account creation protection —
		// same rate_limit() primitive auth_token() uses, wider window since
		// legitimate registration is a one-time-per-person action.
		if ( ! JP_Security::rate_limit( 'auth_register', 5, 300 ) ) {
			return $this->error( 'Too many signup attempts. Please wait a few minutes.', 429 );
		}

		$name     = sanitize_text_field( $r->get_param( 'name' ) ?? '' );
		$email    = sanitize_email( $r->get_param( 'email' ) ?? '' );
		$password = (string) ( $r->get_param( 'password' ) ?? '' );
		$role     = sanitize_key( $r->get_param( 'role' ) ?? 'jp_job_seeker' );

		if ( ! in_array( $role, [ 'jp_job_seeker', 'jp_recruiter' ], true ) ) {
			return $this->error( 'Invalid account type.' );
		}
		if ( ! $name ) return $this->error( 'Please enter your name.' );
		if ( ! $email || ! is_email( $email ) ) return $this->error( 'Please enter a valid email address.' );
		if ( strlen( $password ) < 8 ) return $this->error( 'Password must be at least 8 characters.' );
		if ( email_exists( $email ) ) return $this->error( 'An account with this email already exists.', 409 );

		$user_id = wp_create_user( $email, $password, $email );
		if ( is_wp_error( $user_id ) ) return $this->error( $user_id->get_error_message() );

		$user = new \WP_User( $user_id );
		$user->set_role( $role );
		wp_update_user( [
			'ID'           => $user_id,
			'display_name' => $name,
			'first_name'   => explode( ' ', $name )[0],
			'last_name'    => implode( ' ', array_slice( explode( ' ', $name ), 1 ) ),
		] );

		$db = JP_DB::instance();
		if ( $role === 'jp_job_seeker' ) {
			$db->insert( 'candidates', [ 'user_id' => $user_id ] );
		} elseif ( $role === 'jp_recruiter' ) {
			// The root-cause fix this method exists for — see docblock above.
			$slug = $db->unique_slug( 'companies', sanitize_title( $name ) ?: 'company-' . $user_id );
			$db->insert( 'companies', [
				'user_id'    => $user_id,
				'name'       => $name,
				'slug'       => $slug,
				'email'      => $email,
				'status'     => 'pending',
				'created_at' => current_time( 'mysql' ),
			] );
		}

		JP_Security::instance()->audit( 'user_registered', 'user', $user_id, "Role: {$role}" );
		do_action( 'jp_user_registered', $user_id, $role, $name, $email );

		return $this->ok( [ 'user_id' => $user_id, 'message' => 'Account created.' ], 201 );
	}

	/**
	 * Root-cause fix (batch 4 — closes the "no forgot/reset-password flow
	 * exists in the SPA" gap surfaced while auditing batch 2's
	 * admin_import_companies(), which had to work around this exact
	 * absence with an emailed temp password). Deliberately does NOT
	 * include wp-login.php to reuse its retrieve_password()/reset_password()
	 * wrapper functions — that file is a page controller with top-level
	 * $_REQUEST-driven dispatch side effects, unsafe to require_once from a
	 * REST callback (same reasoning documented at admin_import_companies()).
	 * Uses only the safe, side-effect-free primitives WordPress core
	 * exposes in wp-includes/user.php instead: get_password_reset_key()
	 * and check_password_reset_key(), with wp_set_password() +
	 * the 'password_reset' action fired manually — exactly what wp-login.php's
	 * own reset_password() wrapper does internally, just inlined here so no
	 * unsafe include is needed.
	 *
	 * Anti-enumeration: always returns the same generic success message
	 * whether or not the email matches an account, and whether or not
	 * mail delivery succeeds — never reveals which is the case.
	 */
	public function auth_forgot_password( \WP_REST_Request $r ) {
		if ( ! JP_Security::rate_limit( 'auth_forgot_password', 5, 300 ) ) {
			return $this->error( 'Too many requests. Please wait a few minutes and try again.', 429 );
		}

		$generic = [ 'message' => 'If an account exists for that email, a password reset link has been sent.' ];
		$email   = sanitize_email( $r->get_param( 'email' ) ?? '' );
		if ( ! $email || ! is_email( $email ) ) return $this->ok( $generic );

		$user = get_user_by( 'email', $email );
		if ( ! $user ) return $this->ok( $generic );

		// Reversible-suspension check (JP_Security::is_suspended(), added
		// batch 1): a suspended account's holder can still legitimately
		// need to see the message their account is suspended, but silently
		// handing them a fresh working reset key would let a suspended
		// user regain a usable password reset around the suspension for no
		// real security reason — the suspension itself doesn't block login
		// attempts *from succeeding at the credential layer*, it blocks the
		// session (see block_suspended_login()), so a reset key here is
		// harmless. No special-case needed; falls through to the same path.
		$key = get_password_reset_key( $user );
		if ( is_wp_error( $key ) ) return $this->ok( $generic ); // never leak the failure reason

		// Root-cause note: this app is dual-served (legacy jp-theme pages +
		// the live React SPA per ARCHITECTURE.md) — the reset LINK must
		// land on the SPA's own /reset-password route (built below,
		// ResetPasswordPage.tsx), not WP core's /wp-login.php?action=rp
		// page, which this app doesn't style or control.
		$reset_url = add_query_arg(
			[ 'key' => $key, 'login' => rawurlencode( $user->user_login ) ],
			home_url( '/reset-password' )
		);

		wp_mail(
			$email,
			sprintf( __( 'Reset your %s password', 'jp-core' ), jp_site_name() ),
			sprintf(
				"Someone requested a password reset for your account on %s.\n\nIf this was you, reset your password here (this link expires in 24 hours):\n%s\n\nIf you didn't request this, you can safely ignore this email — your password will not change.",
				jp_site_name(), $reset_url
			)
		);

		JP_Security::instance()->audit( 'password_reset_requested', 'user', $user->ID, '' );

		return $this->ok( $generic );
	}

	public function auth_reset_password( \WP_REST_Request $r ) {
		if ( ! JP_Security::rate_limit( 'auth_reset_password', 10, 300 ) ) {
			return $this->error( 'Too many attempts. Please wait a few minutes and try again.', 429 );
		}

		$key      = (string) ( $r->get_param( 'key' ) ?? '' );
		$login    = (string) ( $r->get_param( 'login' ) ?? '' );
		$password = (string) ( $r->get_param( 'password' ) ?? '' );

		if ( ! $key || ! $login ) return $this->error( 'This reset link is invalid.', 400 );
		if ( strlen( $password ) < 8 ) return $this->error( 'Password must be at least 8 characters.' );

		$user = check_password_reset_key( $key, $login );
		if ( is_wp_error( $user ) ) {
			// WP_Error codes here are 'expired_key' or 'invalid_key' — both
			// map to the same user-facing message; neither implies the
			// *account* doesn't exist, so this doesn't reopen the
			// enumeration hole auth_forgot_password() closes.
			return $this->error( 'This reset link is invalid or has expired. Please request a new one.', 400 );
		}

		wp_set_password( $password, $user->ID );
		// Root-cause: wp_set_password() alone does NOT fire the
		// 'password_reset' action that other WP core/plugin code (and
		// WP_Session_Tokens-based "log out everywhere else" behavior)
		// listens for — wp-login.php's own reset_password() wrapper fires
		// it explicitly after calling wp_set_password(), so this does too,
		// to keep behavior identical to what core's own flow guarantees.
		do_action( 'password_reset', $user, $password );

		// wp_set_password() destroys all of the user's existing sessions
		// as of WP 4.3+ (documented core behavior) — consistent with
		// suspend_user()'s immediate-session-termination approach from
		// batch 1, so a stolen session can't survive a password reset
		// either. No separate JP_Security call needed here.
		JP_Security::instance()->audit( 'password_reset_completed', 'user', $user->ID, '' );

		return $this->ok( [ 'message' => 'Your password has been reset. You can now sign in.' ] );
	}

	/**
	 * Root-cause fix (batch 7). class-jp-auth.php's ajax_update_password()
	 * — change your password while already signed in, given your current
	 * one — has been fully implemented (current-password check via
	 * wp_check_password(), 8-char minimum, wp_set_password()) since before
	 * this audit started, but was reachable only via the legacy
	 * wp_ajax_jp_update_password action. A repo-wide grep for
	 * "update_password" / "current_password" across both the REST layer
	 * and app/src turned up nothing: no REST route ever called it, and no
	 * SPA page ever offered a change-password form —
	 * SecuritySettingsPage.tsx exists but only handles account deletion.
	 * The only way a logged-in user could ever change their password was
	 * the forgot/reset-password email flow built in batch 4, which is a
	 * poor substitute for a direct "change my password" control on a
	 * security settings page and forces signing out to receive an email
	 * just to change a password you already know. Deliberately re-uses
	 * the exact same validation as ajax_update_password() (current-password
	 * verification, 8-char minimum matching auth_register()'s and
	 * auth_reset_password()'s own minimum) rather than introducing a
	 * second, possibly-drifting copy of that logic.
	 */
	public function auth_update_password( \WP_REST_Request $r ) {
		if ( ! JP_Security::rate_limit( 'auth_update_password', 10, 300 ) ) {
			return $this->error( 'Too many attempts. Please wait a few minutes and try again.', 429 );
		}

		$current  = (string) ( $r->get_param( 'current_password' ) ?? '' );
		$new_pass = (string) ( $r->get_param( 'new_password' ) ?? '' );
		$user     = wp_get_current_user();

		if ( ! $current || ! wp_check_password( $current, $user->user_pass, $user->ID ) ) {
			return $this->error( 'Current password is incorrect.', 400 );
		}
		if ( strlen( $new_pass ) < 8 ) {
			return $this->error( 'New password must be at least 8 characters.', 400 );
		}

		wp_set_password( $new_pass, $user->ID );
		// Same rationale as auth_reset_password(): wp_set_password()
		// destroys the user's other sessions as of WP 4.3+, and this fires
		// the same audit event name used there so both paths show up
		// uniformly in the audit log.
		JP_Security::instance()->audit( 'password_reset_completed', 'user', $user->ID, 'via in-app change-password form' );

		// wp_set_password() invalidates auth cookies for this session too
		// (it regenerates the user's auth key), so the current browser's
		// session would otherwise be silently logged out mid-request on
		// its very next check — reissue the cookie for the current
		// session immediately, matching auth_token()'s own use of
		// wp_set_auth_cookie() so this endpoint leaves the calling browser
		// logged in exactly as auth_reset_password()'s docblock intends
		// for the *reset* flow (a fresh sign-in), except here there's no
		// separate sign-in step to do it for us.
		wp_set_auth_cookie( $user->ID, true );

		return $this->ok( [ 'message' => 'Your password has been updated.' ] );
	}

	public function auth_token( \WP_REST_Request $r ) {
		// TRACE: triggered by POST /auth/token → validates credentials → issues JWT
		// PRECONDITIONS: username and password non-empty
		// POSTCONDITIONS: returns signed JWT token with 7-day expiry
		// EDGE CASES: rate-limit exceeded returns 429, wrong creds returns 401, 2FA enabled returns 200 with 2fa_required flag

		// Brute-force protection — 5 attempts per IP per minute
		if ( ! JP_Security::rate_limit( 'auth_token', 5, 60 ) ) {
			return $this->error( 'Too many login attempts. Please wait 60 seconds.', 429 );
		}

		$login = sanitize_text_field( $r->get_param( 'username' ) ?? '' );
		$pass  = $r->get_param( 'password' ) ?? '';
		if ( ! $login || ! $pass ) return $this->error( 'username and password are required.' );

		$user = wp_authenticate( $login, $pass );
		if ( is_wp_error( $user ) ) {
			// Suspension (JP_Security::block_suspended_login(), hooked on
			// 'wp_authenticate_user') is a deliberate, admin-initiated state
			// distinct from a wrong password — tell the user why, rather
			// than folding it into the generic "invalid credentials" message
			// used elsewhere to avoid account-enumeration; the account's
			// existence is not a secret once an admin has acted on it.
			if ( $user->get_error_code() === 'account_suspended' ) {
				return $this->error( $user->get_error_message(), 403 );
			}
			return $this->error( 'Invalid credentials.', 401 );
		}

		// ── 2FA enforcement ──────────────────────────────────────────────────────
		$two_fa_enabled = (int) get_user_meta( $user->ID, 'jp_2fa_enabled', true );
		if ( $two_fa_enabled ) {
			$otp_code = sanitize_text_field( $r->get_param( 'otp' ) ?? '' );
			if ( ! $otp_code ) {
				// Return partial response indicating 2FA is required
				return $this->ok( [ '2fa_required' => true, 'message' => 'Enter your authenticator code to continue.' ] );
			}
			if ( ! JP_Security::instance()->verify_2fa( $user->ID, $otp_code ) ) {
				return $this->error( 'Invalid authenticator code.', 401 );
			}
		}

		// Root-cause fix (traced from live user report: "pages seem thin and
		// admin doesn't find automatically logged in"): this endpoint always
		// validated credentials and minted a JWT below, but never actually
		// logged the user into WordPress — no auth cookie was ever set, and
		// the frontend's own apiClient.ts (the ONLY thing every feature
		// screen in this app calls through) authenticates exclusively via
		// the WP cookie + X-WP-Nonce; the JWT this method returns was never
		// attached anywhere as a bearer token. The net effect: a user who
		// signed in through this app's own login form was left in a
		// permanent logged-out state afterward — every subsequent API call
		// ran as an anonymous visitor, which is exactly why dashboards and
		// gated content rendered "thin" (empty/public data) and why even an
		// admin's session (established correctly server-side at page
		// render, see class-jp-react.php::build_config()) never carried
		// through to actions taken after this endpoint runs (e.g.
		// re-authenticating after a 2FA challenge). wp_set_auth_cookie()
		// establishes the real session this app already depends on
		// everywhere else; wp_set_current_user() makes that identity live
		// for the rest of THIS request too, so wp_create_nonce() below
		// mints a nonce that is actually valid for the user we just
		// authenticated (a nonce generated before this point would still be
		// bound to the prior, usually anonymous, request context).
		wp_set_current_user( $user->ID );
		wp_set_auth_cookie( $user->ID, true );
		do_action( 'wp_login', $user->user_login, $user );

		// Minimal JWT (HS256 — uses WP auth key as secret). Kept for
		// non-browser/API clients that can't use cookies (see
		// maybe_auth_via_jwt() / require_auth()); the web app above uses
		// the cookie session, not this token.
		$header  = base64_encode( wp_json_encode( [ 'alg' => 'HS256', 'typ' => 'JWT' ] ) );
		$exp     = time() + 86400 * 7; // 7-day token
		$payload = base64_encode( wp_json_encode( [ 'sub' => $user->ID, 'exp' => $exp, 'iat' => time() ] ) );
		$sig     = base64_encode( hash_hmac( 'sha256', "{$header}.{$payload}", wp_salt( 'auth' ), true ) );
		$token   = "{$header}.{$payload}.{$sig}";

		return $this->ok( [
			'token'   => $token,
			'user_id' => $user->ID,
			'role'    => jp_current_role( $user->ID ),
			'expires' => $exp,
			// Root-cause fix: the SPA's post-login refresh (AuthContext.tsx's
			// refresh(), fired immediately after a successful login) needs a
			// wp_rest nonce valid for the session just established above to
			// make its very next authenticated request without a full page
			// reload. Returning it here avoids a chicken-and-egg problem:
			// the client has no way to obtain a correctly-bound nonce for a
			// session that, from its perspective, didn't exist a moment ago.
			'nonce'   => wp_create_nonce( 'wp_rest' ),
		] );
	}

	public function auth_me( \WP_REST_Request $r ) {
		return $this->get_me( $r );
	}

	// TRACE: triggered by POST /auth/logout → clears the WP auth cookie for the current browser
	// PRECONDITIONS: none — safe to call whether or not a session actually exists
	// POSTCONDITIONS: auth cookie cleared; is_user_logged_in() is false for this browser afterward
	// EDGE CASES: called with no active session simply no-ops (wp_logout() is itself idempotent)
	public function auth_logout( \WP_REST_Request $r ): \WP_REST_Response {
		wp_logout();
		return $this->ok( [ 'message' => 'Signed out.' ] );
	}

	// ── Permission callbacks ──────────────────────────────────────────────────

	public function require_auth() {
		// Support JWT in Authorization header (for mobile/API clients)
		$this->maybe_auth_via_jwt();
		if ( is_user_logged_in() ) return true;
		return new \WP_Error( 'unauthorized', 'Authentication required.', [ 'status' => 401 ] );
	}

	public function require_recruiter() {
		$this->maybe_auth_via_jwt();
		if ( ! is_user_logged_in() ) return new \WP_Error( 'unauthorized', 'Authentication required.', [ 'status' => 401 ] );
		$allowed = [ 'jp_recruiter', 'jp_team_manager', 'jp_admin_manager', 'jp_super_admin', 'administrator' ];
		if ( ! in_array( jp_current_role(), $allowed, true ) ) {
			return new \WP_Error( 'forbidden', 'Recruiter account required.', [ 'status' => 403 ] );
		}
		return true;
	}

	public function require_admin() {
		$this->maybe_auth_via_jwt();
		if ( ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error( 'forbidden', 'Administrator access required.', [ 'status' => 403 ] );
		}
		return true;
	}

	/**
	 * Root-cause fix (gap analysis: "jp_view_revenue capability exists but
	 * has no analytics method behind it that was found" — one of several
	 * declared-but-never-checked capabilities found this session, in the
	 * same family as the 2FA-enforcement setting and feature-flags gating
	 * fixed in earlier rounds). jp_revenue_dashboard() below is the first
	 * endpoint that actually exists for this capability to gate — every
	 * other admin endpoint in this file checks only literal `manage_options`
	 * via require_admin(), so a role granted jp_view_revenue (intended,
	 * per class-jp-roles.php, for something narrower than full site admin —
	 * e.g. a finance/ops role) could never have reached revenue data
	 * through the API even if a screen for it existed. Full admins keep
	 * access too, since jp_view_revenue is additive, not a replacement.
	 */
	public function require_revenue_access() {
		$this->maybe_auth_via_jwt();
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'jp_view_revenue' ) ) {
			return new \WP_Error( 'forbidden', 'Revenue dashboard access required.', [ 'status' => 403 ] );
		}
		return true;
	}

	/**
	 * Root-cause fix (batch 5 — found while investigating why the audit
	 * report's "no dedicated staff/team dashboard pages" gap looked
	 * stranger the closer it was inspected: router.tsx's /admin route
	 * ALREADY allows ['jp_staff','jp_admin_manager','administrator'] in,
	 * and class-jp-roles.php explicitly grants jp_staff and jp_admin_manager
	 * real, specific capabilities — jp_approve_jobs, jp_moderate_content,
	 * jp_view_reports, jp_manage_users, jp_verify_companies, jp_view_revenue,
	 * etc. But every one of the ~40 admin REST routes this file registers
	 * used the blanket require_admin() gate, which checks literally
	 * current_user_can('manage_options') — a capability ONLY the WordPress
	 * `administrator` role carries; jp_admin_manager and jp_staff never get
	 * it (confirmed by reading class-jp-roles.php's role definitions in
	 * full — neither role array includes 'manage_options', and the
	 * per-role capability arrays there were clearly designed as a real,
	 * granular permission model, not decoration). Net effect before this
	 * fix: a jp_staff or jp_admin_manager user could log in, land in the
	 * SPA's /admin panel (the frontend route let them through), see every
	 * nav link and page — and have literally every single action on every
	 * one of those pages 403 with "Administrator access required," with no
	 * indication anywhere that this was expected. This is the same
	 * "declared-but-never-checked capability" bug class already found and
	 * fixed once for jp_view_revenue (require_revenue_access(), above) —
	 * generalized here into one reusable factory instead of hand-rolling a
	 * bespoke require_*_access() method per capability, and then actually
	 * applied to the ~15 admin routes whose underlying action maps
	 * cleanly onto a capability jp_staff or jp_admin_manager already holds
	 * (job approval/import → jp_approve_jobs; review moderation →
	 * jp_moderate_content; company listing/status/bulk/import →
	 * jp_verify_companies; user listing/role-change/bulk →
	 * jp_manage_users; payments/subscriptions viewing → jp_view_revenue;
	 * skills taxonomy → jp_moderate_content; dashboard stats → jp_view_reports;
	 * audit log → jp_view_audit_log (itself a second "declared but never
	 * checked" capability found in the same pass, previously blanket
	 * manage_options too); CSV export → jp_export_data (already the
	 * established pattern at admin_export_company()/admin_impersonate_start()
	 * below, just not yet applied to admin_csv_export()); system
	 * configuration (settings/backups/cache/webhooks/feature-flags/VAPID/
	 * push-broadcast) → jp_system_config, another declared-but-unused
	 * capability found the same way).
	 *
	 * Deliberately LEFT on $adm/require_admin() (manage_options only, no
	 * change): admin_erase_company() (irreversible data deletion — no
	 * capability was ever declared for this specific destructive action,
	 * and granting it via a nearby-sounding capability would be a real
	 * privilege-escalation risk, not a bug fix) and admin_save_plan()/
	 * admin_get_plans() (pricing-plan configuration directly controls
	 * platform revenue; no capability was declared for "edit pricing", and
	 * misusing jp_view_revenue — a READ capability — to gate a WRITE
	 * operation here would be its own bug). Every other admin_* method not
	 * mentioned above already had its own bespoke, correctly-scoped
	 * permission_callback before this fix (admin_revenue_dashboard(),
	 * admin_export_company(), admin_impersonate_start()/stop()) and is
	 * untouched.
	 *
	 * Always ALSO accepts manage_options, so a true `administrator` (who
	 * already holds every jp_* capability via the admin_caps loop in
	 * class-jp-roles.php) is never narrowed by this change — this can only
	 * ADD access for jp_staff/jp_admin_manager, never remove it for anyone
	 * who already had it.
	 */
	private function require_cap( string $cap ): callable {
		return function () use ( $cap ) {
			$this->maybe_auth_via_jwt();
			if ( ! is_user_logged_in() ) {
				return new \WP_Error( 'unauthorized', 'Authentication required.', [ 'status' => 401 ] );
			}
			if ( ! current_user_can( $cap ) && ! current_user_can( 'manage_options' ) ) {
				return new \WP_Error( 'forbidden', 'Insufficient permissions.', [ 'status' => 403 ] );
			}
			return true;
		};
	}

	/** Authenticate the current request via JWT Bearer token */
	private function maybe_auth_via_jwt(): void {
		if ( is_user_logged_in() ) return;
		$auth = $_SERVER['HTTP_AUTHORIZATION'] ?? '';
		if ( ! str_starts_with( $auth, 'Bearer ' ) ) return;

		$token   = substr( $auth, 7 );
		$parts   = explode( '.', $token );
		if ( count( $parts ) !== 3 ) return;

		[ $header, $payload, $sig ] = $parts;
		$expected_sig = base64_encode( hash_hmac( 'sha256', "{$header}.{$payload}", wp_salt( 'auth' ), true ) );
		if ( ! hash_equals( $expected_sig, $sig ) ) return;

		$data = json_decode( base64_decode( $payload ), true );
		if ( ! $data || ( $data['exp'] ?? 0 ) < time() ) return;

		$user_id = (int) ( $data['sub'] ?? 0 );
		if ( ! $user_id ) return;

		// Root-cause fix: reject any token issued before this user's most
		// recent revocation event (account deletion, or a future
		// "log out everywhere" / password-compromise action that calls
		// revoke_jwts_for_user()) — closes the "deleted account's token
		// still works for up to 7 days" gap.
		$revoked_at = (int) ( self::jwt_revocations()[ $user_id ] ?? 0 );
		if ( $revoked_at && (int) ( $data['iat'] ?? 0 ) < $revoked_at ) return;

		wp_set_current_user( $user_id );
	}

	/**
	 * Per-user JWT revocation registry: user_id => unix timestamp of the
	 * most recent revocation. Any JWT with an 'iat' before that timestamp
	 * is rejected by maybe_auth_via_jwt(), independent of its own 'exp'.
	 * Stored as a single small option (accounts are deleted/revoked
	 * relatively rarely; this avoids a dedicated table for a handful of
	 * rows) and self-pruned of entries whose original 7-day token lifetime
	 * has long since passed, so it never grows unbounded.
	 */
	private static function jwt_revocations(): array {
		return (array) get_option( 'jp_jwt_revocations', [] );
	}

	public static function revoke_jwts_for_user( int $user_id ): void {
		$revocations = self::jwt_revocations();
		$revocations[ $user_id ] = time();
		// Prune entries older than the longest possible token lifetime
		// (7 days, see auth_token()) plus a safety margin — once a
		// revocation is older than that, every token it could have blocked
		// has expired naturally anyway.
		$cutoff = time() - ( 86400 * 7 + 3600 );
		foreach ( $revocations as $uid => $ts ) {
			if ( $ts < $cutoff ) unset( $revocations[ $uid ] );
		}
		update_option( 'jp_jwt_revocations', $revocations, false );
	}


	// ── Skills ───────────────────────────────────────────────────────────────

	public function get_skills( \WP_REST_Request $r ) {
		global $wpdb;
		$skills = $wpdb->get_results(
			"SELECT id, name, category, jobs_count FROM {$wpdb->prefix}jp_skills ORDER BY jobs_count DESC LIMIT 500"
		);
		return $this->ok( $skills ?: [] );
	}

	// ── Plans ─────────────────────────────────────────────────────────────────

	public function get_plans( \WP_REST_Request $r ) {
		global $wpdb;
		$plans = $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}jp_plans WHERE is_active=1 ORDER BY sort_order ASC"
		);
		return $this->ok( $plans ?: [] );
	}

	// ── Notifications ─────────────────────────────────────────────────────────

	public function get_notifications( \WP_REST_Request $r ) {
		global $wpdb;
		$uid   = get_current_user_id();
		// Same missing-lower-bound gap as the candidate-search per_page fix
		// above: limit=0 meant LIMIT 0, silently showing an empty
		// notification bell even when unread notifications existed.
		$limit = min( 50, max( 1, absint( $r->get_param( 'limit' ) ?? 20 ) ) );
		$rows  = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_notifications WHERE user_id=%d ORDER BY created_at DESC LIMIT %d",
			$uid, $limit
		) );
		return $this->ok( $rows ?: [] );
	}

	public function mark_notification_read( \WP_REST_Request $r ) {
		global $wpdb;
		$id  = absint( $r->get_param( 'id' ) );
		$uid = get_current_user_id();
		$wpdb->update( $wpdb->prefix . 'jp_notifications', [ 'is_read' => 1 ], [ 'id' => $id, 'user_id' => $uid ] );
		return $this->ok( [ 'ok' => true ] );
	}

	public function mark_all_notifications_read( \WP_REST_Request $r ) {
		global $wpdb;
		$uid = get_current_user_id();
		$wpdb->update( $wpdb->prefix . 'jp_notifications', [ 'is_read' => 1 ], [ 'user_id' => $uid ] );
		return $this->ok( [ 'ok' => true ] );
	}

	// ── Resumes ───────────────────────────────────────────────────────────────

	public function get_resumes( \WP_REST_Request $r ) {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_resumes WHERE user_id=%d ORDER BY is_primary DESC, created_at DESC",
			get_current_user_id()
		) );
		return $this->ok( $rows ?: [] );
	}

	public function upload_resume( \WP_REST_Request $r ) {
		// Delegate to JP_Resume AJAX handler
		$_FILES = $_FILES; // Files are already in $_FILES from multipart
		$out = $this->bridge_ajax( fn() => JP_Resume::instance()->ajax_upload() );
		return ( $out['success'] ?? false ) ? $this->ok( $out['data'], 201 ) : $this->error( $out['data'] ?? 'Upload failed.' );
	}

	public function delete_resume( \WP_REST_Request $r ) {
		$_POST['resume_id'] = $r->get_param( 'id' );
		$out = $this->bridge_ajax( fn() => JP_Resume::instance()->ajax_delete() );
		return ( $out['success'] ?? false ) ? $this->ok( $out['data'] ) : $this->error( $out['data'] ?? 'Delete failed.' );
	}

	public function set_primary_resume( \WP_REST_Request $r ) {
		$_POST['resume_id'] = $r->get_param( 'id' );
		$out = $this->bridge_ajax( fn() => JP_Resume::instance()->ajax_set_primary() );
		return ( $out['success'] ?? false ) ? $this->ok( $out['data'] ) : $this->error( $out['data'] ?? 'Failed.' );
	}

	// ── Candidate analytics ───────────────────────────────────────────────────

	public function candidate_analytics( \WP_REST_Request $r ) {
		$uid  = get_current_user_id();
		$days = min( 90, max( 1, absint( $r->get_param( 'days' ) ?? 30 ) ) );
		global $wpdb;
		$since = date( 'Y-m-d', strtotime( "-{$days} days" ) );
		return $this->ok( [
			'profile_views'   => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_analytics WHERE event='profile_view' AND object_id=%d AND created_at>=%s", $uid, $since ) ),
			'search_appears'  => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_analytics WHERE event='candidate_search' AND object_id=%d AND created_at>=%s", $uid, $since ) ),
			'applications'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications WHERE candidate_id=%d AND created_at>=%s", $uid, $since ) ),
			'shortlisted'     => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications WHERE candidate_id=%d AND stage IN('shortlisted','interview','offer','hired') AND created_at>=%s", $uid, $since ) ),
			'saved_by'        => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_saved_jobs WHERE job_id IN (SELECT id FROM {$wpdb->prefix}jp_jobs WHERE posted_by=%d)", $uid ) ),
		] );
	}

	/**
	 * Phase 3 redesign (Tier A, redesign-plan §SavedJobsPage) — root-cause
	 * fix found while wiring the "still accepting applications" filter:
	 * this query has always had `AND j.status='active'`, so a saved job
	 * that later closed was silently DROPPED from the response entirely —
	 * not returned with some closed indicator. SavedJobsPage.tsx already
	 * had a `isJobStillOpen()`/"No longer accepting applications" badge
	 * that could therefore never render, because the row it would apply to
	 * never arrived. Removed the status filter so a candidate's saved list
	 * behaves like a real saved list (nothing silently vanishes) and the
	 * existing closed-badge logic actually has data to act on.
	 */
	public function get_saved_jobs( \WP_REST_Request $r ) {
		global $wpdb;
		$uid  = get_current_user_id();
		$jobs = $wpdb->get_results( $wpdb->prepare(
			// company_verified added to match the public job-listing query's
			// SELECT (line ~1134) — SavedJobRow (features/savedJobs/api.ts)
			// aliases SavedJobRow to JobRow & {saved_at}, which already
			// declares company_verified, but this query never selected it so
			// it always arrived as undefined. Real column (jp_companies.
			// is_verified), same one the admin verify/unverify action writes.
			// note added alongside company_verified: same "column exists,
			// never selected" gap — jp_saved_jobs.note is a real column
			// (mirrored by the later jp_saved_candidates.note, which had
			// the same gap fixed first) but had never been read here either,
			// so SavedJobRow could never have surfaced it however the
			// frontend evolved.
			"SELECT j.*,c.name AS company_name,c.logo_url,c.is_verified AS company_verified,s.saved_at,s.note
			 FROM {$wpdb->prefix}jp_saved_jobs s
			 JOIN {$wpdb->prefix}jp_jobs j ON j.id=s.job_id
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id
			 WHERE s.user_id=%d
			 ORDER BY s.saved_at DESC LIMIT 50",
			$uid
		) );
		return $this->ok( $jobs ?: [] );
	}

	/**
	 * TRACE: PUT /candidates/me/saved-jobs/{id}/note, any authenticated
	 * user → updates jp_saved_jobs.note WHERE user_id=<caller> AND
	 * job_id=<id> → exact structural mirror of
	 * update_saved_candidate_note() above (same ownership-via-WHERE-clause
	 * pattern, same 300-char truncation matching the real VARCHAR(300)
	 * column, same checked-return-value write, same 404 when no saved-job
	 * row exists for the pair).
	 * Preconditions: job id is a positive integer; a jp_saved_jobs row
	 * already exists for (caller, id) — the job is actually saved.
	 * Postconditions: that row's note column holds exactly the submitted
	 * text; an empty string clears it.
	 * Edge cases handled: same as update_saved_candidate_note() — no
	 * silent truncation surprise, no ghost success, no cross-user write.
	 */
	public function update_saved_job_note( \WP_REST_Request $r ) {
		global $wpdb;
		$job_id = absint( $r->get_param( 'id' ) );
		$uid    = get_current_user_id();
		$note   = mb_substr( sanitize_textarea_field( (string) ( $r->get_param( 'note' ) ?? '' ) ), 0, 300 );

		$exists = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}jp_saved_jobs WHERE user_id=%d AND job_id=%d",
			$uid, $job_id
		) );
		if ( ! $exists ) return $this->not_found( 'This job is not in your saved list.' );

		$updated = $wpdb->update(
			$wpdb->prefix . 'jp_saved_jobs',
			[ 'note' => $note ],
			[ 'user_id' => $uid, 'job_id' => $job_id ]
		);
		if ( false === $updated ) {
			return $this->error( 'Could not save note. Please try again.' );
		}
		return $this->ok( [ 'message' => 'Note saved.', 'note' => $note ] );
	}

	public function upload_avatar( \WP_REST_Request $r ) {
		if ( empty( $_FILES['file'] ) ) return $this->error( 'No file uploaded.' );
		$file = $_FILES['file'];
		if ( ! in_array( $file['type'], [ 'image/jpeg','image/png','image/webp','image/gif' ], true ) ) {
			return $this->error( 'Invalid file type. Use JPG, PNG, WebP or GIF.' );
		}
		if ( $file['size'] > 2 * 1024 * 1024 ) return $this->error( 'File too large. Maximum 2 MB.' );
		$upload = wp_handle_upload( $file, [ 'test_form' => false ] );
		if ( isset( $upload['error'] ) ) return $this->error( $upload['error'] );
		global $wpdb;
		$result = $wpdb->update( $wpdb->prefix . 'jp_candidates', [ 'avatar_url' => $upload['url'] ], [ 'user_id' => get_current_user_id() ] );
		if ( false === $result ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_candidates avatar_url update failed: ' . $wpdb->last_error ), 'JP_Api::upload_avatar user_id=' . get_current_user_id() );
			}
			return $this->error( 'Avatar uploaded but could not be saved to your profile. Please try again.' );
		}
		return $this->ok( [ 'avatar_url' => $upload['url'] ] );
	}

	// ── Job apply-status ──────────────────────────────────────────────────────

	public function job_apply_status( \WP_REST_Request $r ) {
		$job_id = absint( $r->get_param( 'id' ) );
		$uid    = get_current_user_id();
		global $wpdb;
		$app = $wpdb->get_row( $wpdb->prepare(
			"SELECT stage FROM {$wpdb->prefix}jp_applications WHERE job_id=%d AND candidate_id=%d LIMIT 1",
			$job_id, $uid
		) );
		return $this->ok( [ 'has_applied' => (bool) $app, 'stage' => $app->stage ?? null ] );
	}

	// ── Salary insights ───────────────────────────────────────────────────────

	public function salary_insights( \WP_REST_Request $r ) {
		global $wpdb;
		$role     = sanitize_text_field( $r->get_param( 'role' ) ?? '' );
		$location = sanitize_text_field( $r->get_param( 'location' ) ?? '' );

		$where = [ "salary_min > 0 AND status='active'" ];
		$vals  = [];
		if ( $role )     { $where[] = 'title LIKE %s'; $vals[] = '%' . $wpdb->esc_like( $role ) . '%'; }
		if ( $location ) { $where[] = 'location_city LIKE %s'; $vals[] = '%' . $wpdb->esc_like( $location ) . '%'; }

		$sql = "SELECT AVG(salary_min) AS avg_min, AVG(salary_max) AS avg_max,
				MIN(salary_min) AS p25, MAX(salary_max) AS p75, COUNT(*) AS sample_size
				FROM {$wpdb->prefix}jp_jobs WHERE " . implode( ' AND ', $where );

		$row = $vals ? $wpdb->get_row( $wpdb->prepare( $sql, ...$vals ) ) : $wpdb->get_row( $sql );

		return $this->ok( [
			'avg_min'     => (int) ( $row->avg_min ?? 0 ),
			'avg_max'     => (int) ( $row->avg_max ?? 0 ),
			'p25'         => (int) ( $row->p25 ?? 0 ),
			'p75'         => (int) ( $row->p75 ?? 0 ),
			'sample_size' => (int) ( $row->sample_size ?? 0 ),
		] );
	}

	// ── Admin extended ────────────────────────────────────────────────────────

	public function admin_users( \WP_REST_Request $r ) {
		$q    = sanitize_text_field( $r->get_param( 'q' ) ?? '' );
		$role = sanitize_key( $r->get_param( 'role' ) ?? '' );
		$page = max( 1, absint( $r->get_param( 'page' ) ?? 1 ) );
		$per  = 20;

		$args = [
			'number'  => $per,
			'offset'  => ( $page - 1 ) * $per,
			'orderby' => 'registered',
			'order'   => 'DESC',
		];
		if ( $q ) $args['search'] = "*{$q}*";
		if ( $role ) $args['role'] = $role;

		$users = get_users( $args );
		$total = (int) count_users()['total_users'];

		$data = array_map( function ( $u ) {
			return [
				'id'           => $u->ID,
				'name'         => $u->display_name,
				'email'        => $u->user_email,
				'role'         => jp_current_role( $u->ID ) ?? 'subscriber',
				'registered'   => $u->user_registered,
				// gap analysis: AdminUsersPage had no visibility into
				// suspension state at all (see bulk_user_action()).
				'is_suspended' => (bool) get_user_meta( $u->ID, 'jp_account_suspended', true ),
			];
		}, $users );

		return $this->ok( [ 'users' => $data, 'total' => $total ] );
	}

	/**
	 * Root-cause fix (enterprise gap-analysis: "bulk actions exist for
	 * Jobs/Applications but were never extended to Users" — a real
	 * asymmetry once an admin has 50+ accounts to moderate). Mirrors
	 * bulk_job_action()'s exact shape: allow-listed actions, per-id
	 * try/skip rather than fail the whole batch on one bad id, audit-logged
	 * per id. Deliberately does NOT offer a bulk "delete" — deleting a
	 * WordPress user is destructive and entangled with reassigning their
	 * content; "suspend" (JP_Security::suspend_user(), reversible, ends
	 * active sessions immediately, blocks all future logins) is the correct
	 * enterprise moderation primitive here, matching how admin_company_status()
	 * already treats company suspension as reversible rather than deletion.
	 */
	public function bulk_user_action( \WP_REST_Request $r ) {
		$ids    = array_map( 'absint', (array) $r->get_param( 'ids' ) );
		$action = sanitize_key( $r->get_param( 'action' ) ?? '' );
		$role   = sanitize_key( $r->get_param( 'role' ) ?? '' );
		$allowed_actions = [ 'suspend', 'activate', 'change_role' ];
		if ( ! $ids || ! in_array( $action, $allowed_actions, true ) ) {
			return $this->error( 'ids and a valid action (suspend, activate, change_role) are required.' );
		}
		// Input-validation fix: no cap existed on batch size across any of
		// this file's 5 bulk_*_action() endpoints. This one in particular
		// loops `new WP_User($id)` per id (a real WP core lookup, not a
		// cheap array op), so an oversized batch — a buggy "select all"
		// on a huge filtered list, or a crafted request — could tie up the
		// request for a very long time. Rejected outright rather than
		// silently truncated, so the caller isn't misled into thinking a
		// full batch ran when only the first 200 did.
		if ( count( $ids ) > 200 ) {
			return $this->error( 'Bulk actions are limited to 200 items at a time. Please select fewer and try again.' );
		}
		$allowed_roles = [ 'jp_job_seeker', 'jp_recruiter', 'jp_team_manager', 'jp_staff', 'jp_admin_manager', 'administrator' ];
		if ( $action === 'change_role' && ! in_array( $role, $allowed_roles, true ) ) {
			return $this->error( 'A valid role is required for the change_role action.' );
		}

		$actor_id = get_current_user_id();
		$security = JP_Security::instance();
		$done     = 0;
		$skipped  = 0;

		foreach ( $ids as $id ) {
			// Never let an admin bulk-suspend/demote themselves by accident
			// via a "select all" — a real enterprise lockout scenario.
			if ( $id === $actor_id ) { $skipped++; continue; }
			$user = new \WP_User( $id );
			if ( ! $user->exists() ) { $skipped++; continue; }

			switch ( $action ) {
				case 'suspend':
					if ( in_array( 'administrator', (array) $user->roles, true ) ) { $skipped++; continue 2; }
					$security->suspend_user( $id, 'Bulk admin action' );
					$done++;
					break;
				case 'activate':
					$security->unsuspend_user( $id );
					$done++;
					break;
				case 'change_role':
					$user->set_role( $role );
					$security->audit( 'role_changed', 'user', $id, "Role set to {$role} (bulk)" );
					$done++;
					break;
			}
		}

		return $this->ok( [
			'done'    => $done,
			'skipped' => $skipped,
			'message' => "{$done} user(s) updated" . ( $skipped ? ", {$skipped} skipped (not found, self, or protected)." : '.' ),
		] );
	}

	public function admin_change_role( \WP_REST_Request $r ) {
		$id   = absint( $r->get_param( 'id' ) );
		$role = sanitize_key( $r->get_param( 'role' ) ?? '' );
		$allowed = [ 'jp_job_seeker','jp_recruiter','jp_team_manager','jp_staff','jp_admin_manager','administrator' ];
		if ( ! in_array( $role, $allowed, true ) ) return $this->error( 'Invalid role.' );
		$user = new \WP_User( $id );
		if ( ! $user->exists() ) return $this->not_found( 'User not found.' );
		$user->set_role( $role );
		JP_Security::instance()->audit( 'role_changed', 'user', $id, "Role set to {$role}" );
		return $this->ok( [ 'message' => 'Role updated.' ] );
	}

	/**
	 * Batch 28 — returns the target user's role, the role's own default
	 * jp_* capabilities, and any per-user overrides currently in effect
	 * (an override is any jp_* entry on the user's OWN caps array — as
	 * opposed to inherited from the role — see JP_Roles::role_default_caps()).
	 * The frontend uses base+overrides to render one checkbox per
	 * overridable capability with the correct effective (checked/unchecked)
	 * state and to flag which ones differ from the role default.
	 */
	public function admin_get_capabilities( \WP_REST_Request $r ) {
		$id   = absint( $r->get_param( 'id' ) );
		$user = new \WP_User( $id );
		if ( ! $user->exists() ) return $this->not_found( 'User not found.' );

		$role      = jp_current_role( $id ) ?? 'subscriber';
		$overridable = JP_Roles::overridable_capabilities();
		$base_caps   = JP_Roles::role_default_caps( $role );

		// $user->caps holds ONLY this user's own explicit grants/denials —
		// WordPress keeps role-inherited capabilities out of it, they only
		// appear (merged) in $user->allcaps. That's exactly what makes an
		// entry here an "override" rather than something the role already grants.
		$overrides = [];
		foreach ( $overridable as $cap ) {
			if ( array_key_exists( $cap, $user->caps ) ) $overrides[ $cap ] = (bool) $user->caps[ $cap ];
		}

		return $this->ok( [
			'role'          => $role,
			'overridable'   => $overridable,
			'base_caps'     => $base_caps,
			'overrides'     => $overrides,
		] );
	}

	/**
	 * Batch 28 — grant, revoke, or reset one capability override for a
	 * single user. One-at-a-time (not a batch payload) to match how the
	 * UI actually drives this: a single checkbox toggle.
	 *
	 * action='grant'  -> $user->add_cap($cap, true)   explicit allow
	 * action='revoke' -> $user->add_cap($cap, false)  explicit deny (this
	 *                    is how you take away a capability the ROLE itself
	 *                    grants — WP has no separate "deny" primitive,
	 *                    setting the user's own entry to false is it)
	 * action='reset'  -> $user->remove_cap($cap)       delete the override
	 *                    entirely, falling back to pure role-based resolution
	 *
	 * add_cap()/remove_cap() are void — WordPress gives no return value to
	 * check — so this verifies success the same way the rest of this
	 * engagement treats a "ghost success" risk: re-read the user fresh
	 * from the DB afterward and confirm the write actually landed before
	 * reporting success.
	 */
	public function admin_update_capability( \WP_REST_Request $r ) {
		$id     = absint( $r->get_param( 'id' ) );
		$cap    = sanitize_key( $r->get_param( 'capability' ) ?? '' );
		$action = sanitize_key( $r->get_param( 'action' ) ?? '' );

		if ( ! in_array( $action, [ 'grant', 'revoke', 'reset' ], true ) ) {
			return $this->error( 'action must be one of: grant, revoke, reset.' );
		}
		if ( ! in_array( $cap, JP_Roles::overridable_capabilities(), true ) ) {
			return $this->error( 'This capability cannot be overridden.' );
		}
		$user = new \WP_User( $id );
		if ( ! $user->exists() ) return $this->not_found( 'User not found.' );

		if ( 'grant' === $action )       $user->add_cap( $cap, true );
		elseif ( 'revoke' === $action )  $user->add_cap( $cap, false );
		else                             $user->remove_cap( $cap );

		// Verify: re-instantiate fresh (bypasses any request-scoped object
		// cache on the $user we already have) and check the write landed.
		$fresh = new \WP_User( $id );
		$ok    = match ( $action ) {
			'grant'  => array_key_exists( $cap, $fresh->caps ) && true === $fresh->caps[ $cap ],
			'revoke' => array_key_exists( $cap, $fresh->caps ) && false === $fresh->caps[ $cap ],
			'reset'  => ! array_key_exists( $cap, $fresh->caps ),
		};
		if ( ! $ok ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( "capability override write did not persist: user={$id} cap={$cap} action={$action}" ), 'JP_Api::admin_update_capability' );
			}
			return $this->error( 'Could not save this permission change. Please try again.' );
		}

		JP_Security::instance()->audit( 'capability_' . $action, 'user', $id, "{$action}: {$cap}" );
		return $this->ok( [ 'message' => 'Permission updated.' ] );
	}

	public function admin_verify_company( \WP_REST_Request $r ) {
		global $wpdb;
		$id      = absint( $r->get_param( 'id' ) );
		$verify  = (bool) $r->get_param( 'verify' );
		$updated = $wpdb->update( $wpdb->prefix . 'jp_companies', [ 'is_verified' => $verify ? 1 : 0 ], [ 'id' => $id ] );
		if ( false === $updated ) {
			return $this->error( 'Failed to update verification status. Please try again.' );
		}
		JP_Security::instance()->audit( 'company_' . ( $verify ? 'verified' : 'unverified' ), 'company', $id );
		return $this->ok( [ 'message' => $verify ? 'Company verified.' : 'Verification removed.' ] );
	}

	// ── Privacy/offboarding + impersonation ───────────────────────────────────
	// See class-jp-privacy.php's docblock for why these exist as thin REST
	// wrappers over JP_Privacy's own methods rather than a fresh
	// implementation.

	public function admin_export_company( \WP_REST_Request $r ) {
		$has_perm = current_user_can( 'jp_export_data' ) || current_user_can( 'manage_options' );
		$result   = JP_Privacy::instance()->export_company( absint( $r->get_param( 'id' ) ), $has_perm );
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
		return $this->ok( $result );
	}

	public function admin_erase_company( \WP_REST_Request $r ) {
		$result = JP_Privacy::instance()->erase_company( absint( $r->get_param( 'id' ) ), current_user_can( 'manage_options' ) );
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
		return $this->ok( [ 'message' => 'Company and all associated data erased.' ] );
	}

	public function admin_impersonate_start( \WP_REST_Request $r ) {
		$has_perm = current_user_can( 'jp_impersonate_users' ) || current_user_can( 'manage_options' );
		$result   = JP_Privacy::instance()->start_impersonation( absint( $r->get_param( 'user_id' ) ), get_current_user_id(), $has_perm );
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
		return $this->ok( $result );
	}

	public function admin_impersonate_stop( \WP_REST_Request $r ) {
		JP_Privacy::instance()->stop_impersonation();
		return $this->ok( [ 'message' => 'Impersonation ended.' ] );
	}

	public function admin_payments( \WP_REST_Request $r ) {
		global $wpdb;
		$page   = max( 1, absint( $r->get_param( 'page' ) ?? 1 ) );
		$per    = 20;
		$off    = ( $page - 1 ) * $per;
		// Phase 3 redesign pass — audit flagged this list as needing filters
		// by status/gateway/date and a reconciliation-state indicator. All
		// three filter columns (status, gateway, created_at) already exist
		// and are indexed/real; no new schema needed. "Reconciliation" has
		// no dedicated flag in this schema, so rather than invent one, it's
		// computed per-row on the frontend from data that's already here: a
		// status='paid' row with no gateway reference id (razorpay_pay_id/
		// stripe_session_id) is a genuine data-integrity anomaly worth
		// flagging, not a fabricated state.
		$status = sanitize_key( $r->get_param('status') ?? '' );
		$gateway = sanitize_key( $r->get_param('gateway') ?? '' );
		$date_from = sanitize_text_field( $r->get_param('date_from') ?? '' );
		$date_to   = sanitize_text_field( $r->get_param('date_to') ?? '' );
		$conditions = [];
		if ( $status && in_array( $status, [ 'created','paid','failed','refunded','abandoned' ], true ) ) {
			$conditions[] = $wpdb->prepare( 'p.status=%s', $status );
		}
		if ( $gateway ) {
			$conditions[] = $wpdb->prepare( 'p.gateway=%s', $gateway );
		}
		if ( $date_from && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date_from ) ) {
			$conditions[] = $wpdb->prepare( 'p.created_at >= %s', $date_from . ' 00:00:00' );
		}
		if ( $date_to && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date_to ) ) {
			$conditions[] = $wpdb->prepare( 'p.created_at <= %s', $date_to . ' 23:59:59' );
		}
		$where = $conditions ? 'WHERE ' . implode( ' AND ', $conditions ) : '';
		$rows = $wpdb->get_results(
			"SELECT p.*,u.display_name FROM {$wpdb->prefix}jp_payments p LEFT JOIN {$wpdb->users} u ON u.ID=p.user_id {$where} ORDER BY p.created_at DESC LIMIT {$per} OFFSET {$off}"
		);
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_payments p {$where}" );
		return $this->ok( [ 'payments' => $rows ?: [], 'total' => $total ] );
	}

	/**
	 * Root-cause fix (enterprise gap-analysis: "AdminAuditLogPage is a flat
	 * table with no filter-by-actor/action/date-range" — the platform's
	 * core compliance artifact was effectively unusable once it held more
	 * than a page or two of rows). Adds actor/action/date-range filtering
	 * plus a real total count for pagination; used identically by
	 * admin_audit_log_export() below so the CSV export always matches
	 * exactly what's on screen. See build_audit_log_where() for the shared
	 * WHERE-clause builder.
	 */
	public function admin_audit_log( \WP_REST_Request $r ) {
		global $wpdb;
		$page = max( 1, absint( $r->get_param( 'page' ) ?? 1 ) );
		$per  = 30;
		$off  = ( $page - 1 ) * $per;
		[ $where, $params ] = $this->build_audit_log_where( $r );
		$where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';

		$sql = "SELECT a.*,u.display_name FROM {$wpdb->prefix}jp_audit_log a LEFT JOIN {$wpdb->users} u ON u.ID=a.user_id {$where_sql} ORDER BY a.created_at DESC LIMIT {$per} OFFSET {$off}";
		$rows  = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );

		$count_sql = "SELECT COUNT(*) FROM {$wpdb->prefix}jp_audit_log a {$where_sql}";
		$total = (int) ( $params ? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) : $wpdb->get_var( $count_sql ) );

		return $this->ok( [ 'entries' => $rows ?: [], 'total' => $total ] );
	}

	/**
	 * Shared WHERE-clause builder for admin_audit_log() and
	 * admin_audit_log_export() — keeps the filter/export views from ever
	 * drifting apart (an earlier pattern this codebase already established
	 * for admin_companies()/admin_reviews()'s own conds-array approach).
	 * Returns [conditions[], prepare-params[]] — conditions are raw SQL
	 * fragments with %s/%d placeholders, safe to $wpdb->prepare() together.
	 */
	private function build_audit_log_where( \WP_REST_Request $r ): array {
		$conds  = [];
		$params = [];

		$actor = absint( $r->get_param( 'actor_id' ) ?? 0 );
		if ( $actor ) { $conds[] = 'a.user_id = %d'; $params[] = $actor; }

		$action = sanitize_key( $r->get_param( 'action' ) ?? '' );
		if ( $action ) { $conds[] = 'a.action = %s'; $params[] = $action; }

		$from = sanitize_text_field( $r->get_param( 'date_from' ) ?? '' );
		if ( $from && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ) {
			$conds[] = 'a.created_at >= %s'; $params[] = $from . ' 00:00:00';
		}
		$to = sanitize_text_field( $r->get_param( 'date_to' ) ?? '' );
		if ( $to && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) ) {
			$conds[] = 'a.created_at <= %s'; $params[] = $to . ' 23:59:59';
		}

		return [ $conds, $params ];
	}

	/**
	 * CSV export of the audit log, respecting the exact same filters as
	 * admin_audit_log() (see build_audit_log_where()) — closes the other
	 * half of the same gap: an admin filtering to a suspicious actor/date
	 * range had no way to hand that slice to legal/compliance as a file.
	 * Capped at 20,000 rows (matches the existing 5,000-row cap pattern in
	 * admin_csv_export(), scaled up since audit rows are narrower and a
	 * compliance export legitimately needs a longer window than the other
	 * CSV exports there). The export action is itself audit-logged, same
	 * as every other sensitive admin action in this file (e.g.
	 * admin_export_company()) — an audit-log export is exactly the kind of
	 * access a later investigation would want a record of.
	 */
	public function admin_audit_log_export( \WP_REST_Request $r ) {
		global $wpdb;
		[ $where, $params ] = $this->build_audit_log_where( $r );
		$where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';
		$sql = "SELECT a.id,a.created_at,u.display_name AS actor,a.action,a.object,a.object_id,a.detail,a.ip
				FROM {$wpdb->prefix}jp_audit_log a LEFT JOIN {$wpdb->users} u ON u.ID=a.user_id
				{$where_sql} ORDER BY a.created_at DESC LIMIT 20000";
		$rows = $params
			? $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A )
			: $wpdb->get_results( $sql, ARRAY_A );

		JP_Security::instance()->audit( 'audit_log_exported', 'audit_log', 0, count( $rows ?: [] ) . ' row(s)' );

		if ( empty( $rows ) ) {
			return new \WP_REST_Response( "id,created_at,actor,action,object,object_id,detail,ip\n", 200, [
				'Content-Type' => 'text/csv', 'Content-Disposition' => 'attachment; filename="jp_audit_log_' . date( 'Y-m-d' ) . '.csv"',
			] );
		}

		$csv = implode( ',', array_keys( $rows[0] ) ) . "\n";
		foreach ( $rows as $row ) {
			$csv .= implode( ',', array_map( fn( $v ) => '"' . str_replace( '"', '""', (string) ( $v ?? '' ) ) . '"', $row ) ) . "\n";
		}
		return new \WP_REST_Response( $csv, 200, [
			'Content-Type'        => 'text/csv',
			'Content-Disposition' => 'attachment; filename="jp_audit_log_' . date( 'Y-m-d' ) . '.csv"',
		] );
	}

	/**
	 * Batch 14: thin REST wrapper over JP_Security::verify_audit_chain().
	 * Accepts no params — always verifies the full table (bounded/batched
	 * internally so a large log doesn't exhaust memory) — since a partial
	 * verification would be meaningless for detecting tampering that may
	 * have occurred anywhere in the trail.
	 */
	public function admin_audit_log_verify( \WP_REST_Request $r ) {
		$result = JP_Security::instance()->verify_audit_chain();
		return $this->ok( $result );
	}

	/**
	 * $level and $q params added (batch 14): the frontend already renders
	 * a level badge and an occurrence count per row but had no way to
	 * narrow the list — root cause was JP_ErrorLog::recent() itself never
	 * accepting a filter, not a missing UI control. `levels` (distinct
	 * values actually in the table) is returned alongside the rows so the
	 * admin filter dropdown never offers an option with zero matches.
	 */
	public function admin_error_log( \WP_REST_Request $r ) {
		$page  = max( 1, absint( $r->get_param( 'page' ) ?? 1 ) );
		$per   = 30;
		$off   = ( $page - 1 ) * $per;
		$level = sanitize_text_field( (string) $r->get_param( 'level' ) );
		$q     = sanitize_text_field( (string) $r->get_param( 'q' ) );
		if ( ! class_exists( 'JP_ErrorLog' ) ) return $this->ok( [ 'rows' => [], 'levels' => [] ] );
		$log = JP_ErrorLog::instance();
		return $this->ok( [
			'rows'   => $log->recent( $per, $off, $level, $q ),
			'levels' => $log->distinct_levels(),
		] );
	}

	public function admin_health( \WP_REST_Request $r ) {
		global $wpdb;
		// Root-cause fix (gap analysis P0 #60): 'last_cron' below used to
		// read an option NOTHING wrote, so it always showed "never" no
		// matter how long the site had run — and even once fixed to a real
		// aggregate timestamp, a single global "last cron run" can look
		// healthy while one specific job has been silently failing for
		// days. 'cron_jobs' now gives the real per-job picture (see
		// JP_Cron::health_report()): last run status, last error, and
		// whether each job is overdue relative to its OWN schedule.
		$cron_jobs   = class_exists( 'JP_Cron' ) ? JP_Cron::health_report() : [];
		$any_overdue = (bool) array_filter( $cron_jobs, fn( $j ) => $j['overdue'] );
		$any_failed  = (bool) array_filter( $cron_jobs, fn( $j ) => $j['last_status'] === 'failed' );

		// Dead-letter queue backlog (gap analysis P1 "no queue system" —
		// class-jp-queue.php) surfaced here so an admin sees stuck
		// background work in the same place as everything else, instead of
		// nowhere at all.
		$queue_dead_letters = class_exists( 'JP_Queue' ) ? count( JP_Queue::instance()->dead_letters( 1000 ) ) : 0;

		// Recent centralized errors (gap analysis P0 #59/#156 — see
		// class-jp-errorlog.php). Trimmed to a small preview here; the full
		// list is available via JP_ErrorLog::instance()->recent() for a
		// dedicated log-viewer endpoint/screen (not built in this pass).
		$recent_errors = class_exists( 'JP_ErrorLog' ) ? JP_ErrorLog::instance()->recent( 10 ) : [];

		// Root-cause fix (gap analysis P1: "jp_react_app_version is tracked
		// but nothing verifies it against the actual deployed React build's
		// file hash/mtime — the same class of 'silent version drift' that
		// caused the theme-zip incident exists, unaddressed, for the other
		// front-end"). class-jp-react.php now records the version actually
		// embedded in the deployed jp-app.*.js filename (ground truth, set
		// by the SPA's own build pipeline) rather than a blind copy of
		// JP_VERSION. Surfacing both numbers here, plus an explicit
		// mismatch flag, turns "the plugin and the React bundle are out of
		// sync" from something that requires institutional memory to
		// suspect into something self-diagnosing on this health screen.
		$react_app_version = get_option( 'jp_react_app_version', '' );
		$react_version_status = ! $react_app_version
			? 'unknown (no React page rendered yet this deploy)'
			: ( $react_app_version === JP_VERSION ? 'in_sync' : 'mismatch' );

		// Root-cause fix (roadmap re-audit): class-jp-settings.php's "System
		// Info" and "Security" wp-admin pages showed a set of read-only
		// facts (MySQL version, live jobs/users/applications counts,
		// integration-configured flags, backup status) that had no REST/SPA
		// equivalent anywhere — an admin retiring wp-admin would lose visibility
		// into all of it. Folded into this existing health payload rather than
		// a new endpoint, since it's the same "is the system okay" screen.
		$backup_status = class_exists( 'JP_Backup' ) ? JP_Backup::instance()->get_status() : [];

		return $this->ok( [
			'php_version'          => PHP_VERSION,
			'wp_version'           => get_bloginfo( 'version' ),
			'mysql_version'        => $wpdb->db_version(),
			'jp_version'           => JP_VERSION,
			'react_app_version'    => $react_app_version ?: null,
			'react_version_status' => $react_version_status,
			'db_ok'                => (bool) $wpdb->get_var( 'SELECT 1' ),
			'last_cron'            => get_option( 'jp_last_cron_run', 'never' ),
			'cron_jobs'            => $cron_jobs,
			'cron_health'          => ( $any_failed || $any_overdue ) ? 'degraded' : 'ok',
			'queue_dead_letters'   => $queue_dead_letters,
			'recent_errors'        => $recent_errors,
			'cache_driver'         => wp_using_ext_object_cache() ? 'external' : 'transients',
			'uploads_writable'     => is_writable( wp_upload_dir()['basedir'] ),
			'server_time'          => current_time( 'mysql' ),
			'active_jobs'          => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_jobs WHERE status='active'" ),
			'total_users'          => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->users}" ),
			'total_applications'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications" ),
			'elasticsearch_configured' => defined( 'JP_ES_HOST' ) && JP_ES_HOST,
			'redis_configured'         => defined( 'JP_REDIS_HOST' ) && JP_REDIS_HOST,
			'tcpdf_available'          => class_exists( 'JP_PDF' ) && JP_PDF::ensure_available(),
			'pdftotext_available'      => class_exists( 'JP_Resume' ) && JP_Resume::is_pdftotext_available(),
			'wp_cron_enabled'          => ! ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ),
			'sms_provider_configured'  => defined( 'JP_SMS_PROVIDER' ) && JP_SMS_PROVIDER ? JP_SMS_PROVIDER : null,
			'backup_latest'            => $backup_status['latest_backup'] ?? null,
			'backup_count'             => $backup_status['backup_count'] ?? 0,
			'backup_next'              => $backup_status['next_backup'] ?? null,
			'vapid_configured'         => (bool) get_option( 'jp_vapid_public_key', '' ),
		] );
	}

	/**
	 * Root-cause fix (gap analysis P1 #179). MRR is computed from currently
	 * `active` subscriptions' plan pricing (yearly plans normalized to a
	 * monthly-equivalent by dividing by 12) rather than from jp_payments —
	 * payments are point-in-time transactions, not a running subscription
	 * state, so summing them would double-count a renewal and undercount a
	 * still-active subscription that hasn't hit its next renewal yet.
	 *
	 * SCOPE, STATED HONESTLY: churn here is a same-period approximation
	 * (subscriptions cancelled in the last 30 days ÷ (currently active +
	 * cancelled in the last 30 days)), not a cohort-based churn rate against
	 * a historical active-subscriber count at the start of the period —
	 * this schema has no periodic snapshot of "how many were active on day
	 * X" to compute that properly, and fabricating historical snapshots
	 * retroactively isn't possible. This is a real, useful, directionally
	 * correct number for "is churn trending up or down," not a
	 * board-deck-grade SaaS churn metric — documented here rather than
	 * silently presented as more precise than it is.
	 */
	public function admin_revenue_dashboard( \WP_REST_Request $r ) {
		global $wpdb;

		$active_subs = $wpdb->get_results(
			"SELECT s.billing_cycle, p.price_monthly, p.price_yearly, p.name AS plan_name
			 FROM {$wpdb->prefix}jp_subscriptions s
			 JOIN {$wpdb->prefix}jp_plans p ON p.id = s.plan_id
			 WHERE s.status = 'active'"
		);

		$mrr = 0.0;
		$by_plan = [];
		foreach ( $active_subs as $sub ) {
			$monthly_equiv = 'yearly' === $sub->billing_cycle
				? ( (float) $sub->price_yearly / 12 )
				: (float) $sub->price_monthly;
			$mrr += $monthly_equiv;
			$by_plan[ $sub->plan_name ] = ( $by_plan[ $sub->plan_name ] ?? 0 ) + $monthly_equiv;
		}
		$active_count = count( $active_subs );
		$arpu         = $active_count > 0 ? round( $mrr / $active_count, 2 ) : 0.0;

		$since_30d = gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS );
		$cancelled_30d = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}jp_subscriptions WHERE status='cancelled' AND cancelled_at >= %s",
			$since_30d
		) );
		$new_30d = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}jp_subscriptions WHERE created_at >= %s",
			$since_30d
		) );
		$churn_denominator = $active_count + $cancelled_30d;
		$churn_rate_pct    = $churn_denominator > 0 ? round( $cancelled_30d / $churn_denominator * 100, 1 ) : 0.0;

		$revenue_collected_30d = (float) $wpdb->get_var( $wpdb->prepare(
			"SELECT COALESCE(SUM(amount),0) FROM {$wpdb->prefix}jp_payments WHERE status='paid' AND paid_at >= %s",
			$since_30d
		) );

		$trial_count      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_subscriptions WHERE status='trial'" );
		$past_due_count   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_subscriptions WHERE status='past_due'" );

		return $this->ok( [
			'mrr'                    => round( $mrr, 2 ),
			'arpu'                   => $arpu,
			'active_subscriptions'   => $active_count,
			'mrr_by_plan'            => $by_plan,
			'trial_subscriptions'    => $trial_count,
			'past_due_subscriptions' => $past_due_count,
			'new_subscriptions_30d'  => $new_30d,
			'cancelled_30d'          => $cancelled_30d,
			'churn_rate_pct_30d'     => $churn_rate_pct,
			'revenue_collected_30d'  => round( $revenue_collected_30d, 2 ),
			'currency'               => 'INR',
			'note'                   => 'churn_rate_pct_30d is a same-period approximation (cancelled ÷ (active + cancelled) over the last 30 days), not a cohort-based rate against a historical subscriber snapshot — see admin_revenue_dashboard() docblock.',
		] );
	}

	// ── Save job toggle ──────────────────────────────────────────────────────

	public function toggle_save_job( \WP_REST_Request $r ) {
		// Root-cause fix (gap analysis P1 #153: "Rate limiting exists but is
		// inconsistently applied ... no rate limit on ... save/unsave-job
		// toggles"). A scripted toggle loop against this endpoint has no
		// natural ceiling otherwise (no unique-constraint or cooldown of any
		// kind previously existed here) and can drive unbounded insert/
		// delete churn on jp_saved_jobs.
		if ( ! JP_Security::rate_limit( 'jp_toggle_save_job', 60, 60, (string) get_current_user_id() ) ) {
			return $this->error( 'Too many requests. Please slow down.', 429 );
		}
		global $wpdb;
		$job_id  = absint( $r->get_param( 'id' ) );
		$user_id = get_current_user_id();
		$tbl     = $wpdb->prefix . 'jp_saved_jobs';

		$existing = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$tbl} WHERE user_id=%d AND job_id=%d", $user_id, $job_id
		) );

		// Ghost-success fix: both branches returned a fixed success message
		// regardless of whether the write actually happened — a failed
		// delete/insert (deadlock, disk full, table missing) would tell the
		// user "Job saved!" while jp_saved_jobs was silently unchanged.
		if ( $existing ) {
			$result = $wpdb->delete( $tbl, [ 'user_id' => $user_id, 'job_id' => $job_id ] );
			if ( false === $result ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_saved_jobs delete failed: ' . $wpdb->last_error ), 'JP_Api::toggle_save_job user_id=' . $user_id . ' job_id=' . $job_id );
				return $this->error( 'Could not remove the job from your saved list. Please try again.', 500 );
			}
			return $this->ok( [ 'saved' => false, 'message' => 'Job removed from saved list.' ] );
		} else {
			$result = $wpdb->insert( $tbl, [ 'user_id' => $user_id, 'job_id' => $job_id, 'saved_at' => current_time( 'mysql' ) ] );
			if ( false === $result ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_saved_jobs insert failed: ' . $wpdb->last_error ), 'JP_Api::toggle_save_job user_id=' . $user_id . ' job_id=' . $job_id );
				return $this->error( 'Could not save the job. Please try again.', 500 );
			}
			return $this->ok( [ 'saved' => true, 'message' => 'Job saved!' ] );
		}
	}

	// ── Talent pool (recruiter-saved candidates) ───────────────────────────────────────────────────────

	/**
	 * TRACE: POST /candidates/{id}/save, recruiter or above → toggles a row
	 * in jp_saved_candidates keyed on (user_id = the recruiter's own WP user
	 * id, candidate_id = the candidate's WP user id — the same "id" the
	 * frontend already uses for GET /candidates/{id} and for starting a
	 * message thread, confirmed against RecruiterCandidatesPage.tsx's
	 * `setSelectedId(c.user_id)`, not jp_candidates.id) → deletes the row if
	 * present, inserts it if absent. Exact mirror of toggle_save_job() above,
	 * including the same rate-limit treatment for the same reason: a
	 * scripted toggle loop has no natural ceiling otherwise.
	 * Preconditions: candidate id is a positive integer; caller holds the
	 * recruiter (or higher) capability enforced by permission_callback.
	 * Postconditions: exactly one jp_saved_candidates row exists for this
	 * (user_id, candidate_id) pair after an insert, zero after a delete —
	 * enforced by the table's own UNIQUE KEY, not just application logic.
	 * Edge cases handled: toggling a non-existent candidate id is a no-op
	 * insert (no foreign-key existence check exists for jp_saved_jobs either
	 * — same behavior, not a new gap); rapid double-toggle is rate-limited
	 * identically to save-job.
	 */
	public function toggle_save_candidate( \WP_REST_Request $r ) {
		if ( ! JP_Security::rate_limit( 'jp_toggle_save_candidate', 60, 60, (string) get_current_user_id() ) ) {
			return $this->error( 'Too many requests. Please slow down.', 429 );
		}
		global $wpdb;
		$candidate_id = absint( $r->get_param( 'id' ) );
		if ( ! $candidate_id ) return $this->error( 'Invalid candidate.' );
		$user_id = get_current_user_id();
		$tbl     = $wpdb->prefix . 'jp_saved_candidates';

		$existing = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$tbl} WHERE user_id=%d AND candidate_id=%d", $user_id, $candidate_id
		) );

		// Ghost-success fix, same class as toggle_save_job() above.
		if ( $existing ) {
			$result = $wpdb->delete( $tbl, [ 'user_id' => $user_id, 'candidate_id' => $candidate_id ] );
			if ( false === $result ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_saved_candidates delete failed: ' . $wpdb->last_error ), 'JP_Api::toggle_save_candidate user_id=' . $user_id . ' candidate_id=' . $candidate_id );
				return $this->error( 'Could not remove the candidate from your talent pool. Please try again.', 500 );
			}
			return $this->ok( [ 'saved' => false, 'message' => 'Candidate removed from talent pool.' ] );
		} else {
			$result = $wpdb->insert( $tbl, [ 'user_id' => $user_id, 'candidate_id' => $candidate_id, 'saved_at' => current_time( 'mysql' ) ] );
			if ( false === $result ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_saved_candidates insert failed: ' . $wpdb->last_error ), 'JP_Api::toggle_save_candidate user_id=' . $user_id . ' candidate_id=' . $candidate_id );
				return $this->error( 'Could not add the candidate to your talent pool. Please try again.', 500 );
			}
			return $this->ok( [ 'saved' => true, 'message' => 'Candidate added to talent pool.' ] );
		}
	}

	/**
	 * TRACE: GET /recruiter/talent-pool, recruiter or above → joins
	 * jp_saved_candidates to jp_candidates (on candidate_id = jp_candidates.
	 * user_id, the same key toggle_save_candidate() writes) and to wp_users
	 * for display_name/email → returns the recruiter's own saved-candidate
	 * list, newest-first, exact structural mirror of get_saved_jobs() above.
	 * Preconditions: caller holds the recruiter (or higher) capability.
	 * Postconditions: response is the current, real DB state — nothing
	 * fabricated when the pool is empty (returns [], not placeholder rows).
	 * Edge cases handled: a saved candidate whose jp_candidates row was since
	 * deleted is excluded by the INNER JOIN rather than surfacing a
	 * null-fielded ghost row; results capped at 50 like get_saved_jobs().
	 */
	public function get_talent_pool( \WP_REST_Request $r ) {
		global $wpdb;
		$uid  = get_current_user_id();
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT c.*,u.display_name,u.user_email,sc.saved_at,sc.note
			 FROM {$wpdb->prefix}jp_saved_candidates sc
			 JOIN {$wpdb->prefix}jp_candidates c ON c.user_id=sc.candidate_id
			 LEFT JOIN {$wpdb->users} u ON u.ID=c.user_id
			 WHERE sc.user_id=%d
			 ORDER BY sc.saved_at DESC LIMIT 50",
			$uid
		) );
		if ( $rows ) {
			$user_ids = array_map( fn( $row ) => (int) $row->user_id, $rows );
			$skills_by_user = [];
			if ( $user_ids ) {
				$placeholders = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );
				$skill_rows = $wpdb->get_results( $wpdb->prepare(
					"SELECT us.user_id, s.name FROM {$wpdb->prefix}jp_user_skills us
					 JOIN {$wpdb->prefix}jp_skills s ON s.id = us.skill_id
					 WHERE us.user_id IN ({$placeholders})",
					$user_ids
				) );
				foreach ( $skill_rows as $sr ) $skills_by_user[ (int) $sr->user_id ][] = $sr->name;
			}
			foreach ( $rows as $row ) $row->skills = $skills_by_user[ (int) $row->user_id ] ?? [];
		}
		return $this->ok( $rows ?: [] );
	}

	/**
	 * TRACE: PUT /recruiter/talent-pool/{id}/note, recruiter or above →
	 * updates jp_saved_candidates.note WHERE user_id=<caller> AND
	 * candidate_id=<id> → the WHERE clause itself is the ownership check
	 * (same pattern get_talent_pool()/toggle_save_candidate() use — a row
	 * only exists for this pair if this recruiter saved this candidate),
	 * so a recruiter can never edit another recruiter's saved-candidate
	 * note even by guessing a candidate id.
	 * Preconditions: candidate id is a positive integer; a jp_saved_candidates
	 * row already exists for (caller, id) — i.e. the candidate is actually
	 * in this recruiter's talent pool.
	 * Postconditions: on success, that row's note column holds exactly the
	 * submitted text (empty string clears it); the write's affected-row
	 * count is checked, not assumed — this is the exact "ghost success"
	 * bug class already fixed ~39 times elsewhere in this codebase.
	 * Edge cases handled: note text longer than the VARCHAR(300) column is
	 * truncated to 300 chars before the query (matching the column's real
	 * width, not silently letting MySQL truncate or error); a candidate id
	 * with no existing saved-candidate row for this recruiter returns a
	 * real 404-style error instead of a false "note saved" success.
	 */
	public function update_saved_candidate_note( \WP_REST_Request $r ) {
		global $wpdb;
		$candidate_id = absint( $r->get_param( 'id' ) );
		$uid          = get_current_user_id();
		$note         = mb_substr( sanitize_textarea_field( (string) ( $r->get_param( 'note' ) ?? '' ) ), 0, 300 );

		$exists = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}jp_saved_candidates WHERE user_id=%d AND candidate_id=%d",
			$uid, $candidate_id
		) );
		if ( ! $exists ) return $this->not_found( 'This candidate is not in your talent pool.' );

		$updated = $wpdb->update(
			$wpdb->prefix . 'jp_saved_candidates',
			[ 'note' => $note ],
			[ 'user_id' => $uid, 'candidate_id' => $candidate_id ]
		);
		if ( false === $updated ) {
			return $this->error( 'Could not save note. Please try again.' );
		}
		return $this->ok( [ 'message' => 'Note saved.', 'note' => $note ] );
	}

	// ── Assessments ───────────────────────────────────────────────────────────

	public function get_assessments( \WP_REST_Request $r ) {
		global $wpdb;
		$uid = get_current_user_id();

		// Skills with question counts and the candidate's existing badge
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT s.id AS skill_id, s.name AS skill_name, s.category,
				(SELECT COUNT(*) FROM {$wpdb->prefix}jp_assessment_questions q WHERE q.skill_id=s.id AND q.is_active=1) AS question_count,
				a.badge_level, a.score, a.taken_at, a.expires_at
			 FROM {$wpdb->prefix}jp_skills s
			 LEFT JOIN {$wpdb->prefix}jp_assessments a ON a.skill_id=s.id AND a.user_id=%d
			 HAVING question_count >= 5
			 ORDER BY a.badge_level DESC, s.jobs_count DESC
			 LIMIT 30",
			$uid
		) );

		return $this->ok( $rows ?: [] );
	}

	/**
	 * Phase 3 redesign (Tier A, redesign-plan §AssessmentsPage) — root-cause
	 * fix for a severe pre-existing correctness bug found while auditing
	 * this page: this same endpoint handles both "start" (no `answers`) and
	 * "submit" (`answers` present) calls, but it re-ran `ORDER BY RAND()
	 * LIMIT 10` on EVERY call rather than persisting the exact question set
	 * handed out on start. The submit call therefore scored the candidate's
	 * answers against a genuinely different random 10-question draw (both
	 * different questions and different order) than what they were shown
	 * and answered — silently wrong scores, wrong badges, and a results
	 * screen pairing each answer index with the wrong question/explanation
	 * entirely. Fixed by persisting the exact question-id set (in order) to
	 * a short-lived transient keyed by user+skill on the start call, and
	 * reading that same set back on submit instead of re-randomizing. Falls
	 * back to a fresh random draw only if the transient has expired (>1hr
	 * between start and submit, or a server restart cleared it) — an edge
	 * case with no persisted reference to score against either way, so this
	 * is the best available behavior rather than a regression.
	 */
	public function take_assessment( \WP_REST_Request $r ) {
		global $wpdb;
		$skill_id      = absint( $r->get_param( 'skill_id' ) );
		$uid           = get_current_user_id();
		$transient_key = "jp_assessment_q_{$uid}_{$skill_id}";
		$answers       = $r->get_param( 'answers' ); // array of answer indices

		if ( $answers && is_array( $answers ) ) {
			// Submit path: use the SAME question set handed out on start, if
			// still available, so scoring matches what the candidate saw.
			$question_ids = get_transient( $transient_key );
			if ( is_array( $question_ids ) && $question_ids ) {
				$placeholders = implode( ',', array_fill( 0, count( $question_ids ), '%d' ) );
				$field_order  = implode( ',', array_map( 'absint', $question_ids ) );
				$questions    = $wpdb->get_results( $wpdb->prepare(
					"SELECT id, question, options_json, correct_index, explanation
					 FROM {$wpdb->prefix}jp_assessment_questions
					 WHERE id IN ($placeholders)
					 ORDER BY FIELD(id, $field_order)",
					$question_ids
				) );
				delete_transient( $transient_key );
			} else {
				$questions = $wpdb->get_results( $wpdb->prepare(
					"SELECT id, question, options_json, correct_index, explanation
					 FROM {$wpdb->prefix}jp_assessment_questions
					 WHERE skill_id=%d AND is_active=1
					 ORDER BY RAND() LIMIT 10",
					$skill_id
				) );
			}
		} else {
			// Start path: draw a fresh random set and persist it so the
			// submit call above scores against these exact questions.
			$questions = $wpdb->get_results( $wpdb->prepare(
				"SELECT id, question, options_json, correct_index, explanation
				 FROM {$wpdb->prefix}jp_assessment_questions
				 WHERE skill_id=%d AND is_active=1
				 ORDER BY RAND() LIMIT 10",
				$skill_id
			) );
			if ( $questions ) {
				set_transient( $transient_key, wp_list_pluck( $questions, 'id' ), HOUR_IN_SECONDS );
			}
		}

		if ( ! $questions ) return $this->error( 'No questions available for this skill.' );

		// If answers submitted, score them
		if ( $answers && is_array( $answers ) ) {
			$correct = 0;
			foreach ( $questions as $i => $q ) {
				if ( isset( $answers[$i] ) && (int)$answers[$i] === (int)$q->correct_index ) $correct++;
			}
			$score = (int) round( ($correct / count($questions)) * 100 );
			$badge = $score >= 90 ? 'gold' : ($score >= 75 ? 'silver' : ($score >= 60 ? 'bronze' : 'none'));

			$wpdb->replace( $wpdb->prefix . 'jp_assessments', [
				'user_id'    => $uid,
				'skill_id'   => $skill_id,
				'score'      => $score,
				'badge_level'=> $badge,
				'taken_at'   => current_time('mysql'),
				'expires_at' => date('Y-m-d H:i:s', strtotime('+6 months')),
			], ['%d','%d','%d','%s','%s','%s'] );

			return $this->ok( [
				'score'      => $score,
				'badge_level'=> $badge,
				'correct'    => $correct,
				'total'      => count($questions),
				'results'    => array_map( fn($q,$i) => [
					'question'    => $q->question,
					'your_answer' => $answers[$i] ?? -1,
					'correct'     => (int)$q->correct_index,
					'explanation' => $q->explanation,
					'is_correct'  => isset($answers[$i]) && (int)$answers[$i] === (int)$q->correct_index,
				], $questions, array_keys($questions) ),
			] );
		}

		// Return questions without correct answers
		$safe = array_map( fn($q) => [
			'id'       => $q->id,
			'question' => $q->question,
			'options'  => json_decode($q->options_json, true) ?: [],
		], $questions );

		return $this->ok( [ 'questions' => $safe, 'skill_id' => $skill_id ] );
	}

	// ── Notification preferences ──────────────────────────────────────────────

	public function get_notif_prefs( \WP_REST_Request $r ) {
		$uid   = get_current_user_id();
		$prefs = get_user_meta( $uid, 'jp_notif_prefs', true );
		return $this->ok( $prefs ?: [
			'email_new_match'     => true,
			'email_stage_change'  => true,
			'email_message'       => true,
			'email_digest'        => true,
			'push_new_match'      => false,
			'push_message'        => false,
			'sms_stage_change'    => false,
		] );
	}

	public function save_notif_prefs( \WP_REST_Request $r ) {
		$uid   = get_current_user_id();
		$prefs = $r->get_json_params();
		// Sanitise: only bool values allowed
		$allowed = [ 'email_new_match','email_stage_change','email_message','email_digest','push_new_match','push_message','sms_stage_change' ];
		$clean   = [];
		foreach ( $allowed as $key ) {
			if ( isset($prefs[$key]) ) $clean[$key] = (bool) $prefs[$key];
		}
		update_user_meta( $uid, 'jp_notif_prefs', $clean );
		return $this->ok( [ 'message' => 'Preferences saved.' ] );
	}







	// ── Phase 10 handlers ────────────────────────────────────────────────────────

	// ── 2FA ──────────────────────────────────────────────────────────────────────

	public function twofa_setup( \WP_REST_Request $r ) {
		$uid    = get_current_user_id();
		$user   = get_userdata( $uid );
		$secret = JP_Security::instance()->generate_2fa_secret( $uid );
		$issuer = urlencode( jp_site_name() );
		$email  = urlencode( $user->user_email );
		$qr_uri = "otpauth://totp/{$issuer}:{$email}?secret={$secret}&issuer={$issuer}&algorithm=SHA1&digits=6&period=30";
		return $this->ok( [ 'secret' => $secret, 'qr_uri' => $qr_uri ] );
	}

	public function twofa_verify( \WP_REST_Request $r ) {
		$code = sanitize_text_field( $r->get_param( 'code' ) ?? '' );
		if ( ! $code ) return $this->error( 'code is required.' );
		$ok = JP_Security::instance()->enable_2fa( get_current_user_id(), $code );
		if ( ! $ok ) return $this->error( 'Invalid code. Verify your authenticator app shows the correct time.' );
		return $this->ok( [ 'message' => '2FA enabled successfully. Keep your backup codes safe.' ] );
	}

	public function twofa_disable( \WP_REST_Request $r ) {
		$uid  = get_current_user_id();
		$code = sanitize_text_field( $r->get_param( 'code' ) ?? '' );
		if ( ! JP_Security::instance()->verify_2fa( $uid, $code ) ) {
			return $this->error( 'Invalid code. 2FA not disabled.' );
		}
		update_user_meta( $uid, 'jp_2fa_enabled', 0 );
		delete_user_meta( $uid, 'jp_2fa_secret' );
		return $this->ok( [ 'message' => '2FA has been disabled.' ] );
	}

	// ── GDPR: Data export + account deletion ──────────────────────────────────────

	public function account_export( \WP_REST_Request $r ) {
		global $wpdb;
		$uid  = get_current_user_id();
		$user = get_userdata( $uid );

		$candidate    = JP_DB::instance()->get_candidate( $uid );
		$applications = $wpdb->get_results( $wpdb->prepare(
			"SELECT a.*, j.title AS job_title FROM {$wpdb->prefix}jp_applications a
			 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id WHERE a.candidate_id=%d", $uid
		) );
		$notifications = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_notifications WHERE user_id=%d LIMIT 500", $uid
		) );
		$sections = $wpdb->get_results( $wpdb->prepare(
			"SELECT section, content FROM {$wpdb->prefix}jp_resume_sections WHERE user_id=%d", $uid
		) );
		$badges = $wpdb->get_results( $wpdb->prepare(
			"SELECT badge, awarded_at FROM {$wpdb->prefix}jp_user_badges WHERE user_id=%d", $uid
		) );

		// Root-cause fix (see enterprise-gap-analysis.md §12: "demonstrably
		// incomplete — omits saved jobs, alerts, message threads, assessment
		// results, and authored reviews"): this endpoint queried only 4 of
		// the tables that actually hold this user's personal data. The
		// missing ones are added below rather than left for the separate
		// WP-native exporter (class-jp-privacy.php) to be the only complete
		// copy — a user hitting THIS endpoint from their account page should
		// get a genuinely complete export, not a partial one that happens to
		// be superseded elsewhere.
		$saved_jobs = $wpdb->get_results( $wpdb->prepare(
			"SELECT sj.*, j.title AS job_title FROM {$wpdb->prefix}jp_saved_jobs sj LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=sj.job_id WHERE sj.user_id=%d", $uid
		) );
		$alerts = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_alerts WHERE user_id=%d", $uid
		) );
		$message_threads = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_message_threads WHERE recruiter_id=%d OR candidate_id=%d", $uid, $uid
		) );
		$thread_ids = wp_list_pluck( $message_threads, 'id' );
		$messages   = $thread_ids ? $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}jp_messages WHERE thread_id IN (" . implode( ',', array_map( 'intval', $thread_ids ) ) . ") AND sender_id=" . (int) $uid
		) : [];
		$assessments = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, skill_id, score, badge_level, taken_at, expires_at FROM {$wpdb->prefix}jp_assessments WHERE user_id=%d", $uid
		) );
		$reviews_authored = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, company_id, title, pros, cons, rating_overall, status, created_at FROM {$wpdb->prefix}jp_reviews WHERE user_id=%d", $uid
		) );

		$data = [
			'exported_at'   => current_time( 'mysql' ),
			'account' => [
				'id'         => $uid,
				'name'       => $user->display_name,
				'email'      => $user->user_email,
				'registered' => $user->user_registered,
			],
			'profile'          => $candidate,
			'applications'     => $applications,
			'notifications'    => $notifications,
			'resume_sections'  => $sections,
			'badges'           => $badges,
			'saved_jobs'       => $saved_jobs,
			'job_alerts'       => $alerts,
			'message_threads'  => $message_threads,
			'messages_sent'    => $messages,
			'assessments'      => $assessments,
			'reviews_authored' => $reviews_authored,
		];

		JP_Security::instance()->audit( 'data_export', 'account', $uid );
		return $this->ok( $data );
	}

	public function account_delete( \WP_REST_Request $r ) {
		// TRACE: triggered by POST /account/delete → verifies password → anonymises WP user →
		//        soft-deletes candidate profile → hard-deletes personal data tables
		// PRECONDITIONS: authenticated user, correct password provided
		// POSTCONDITIONS: user_email anonymised, JWT tokens remain valid until expiry (by design — no token revocation store)
		// EDGE CASES: get_userdata returns false, concurrent deletion attempt, no candidate profile

		global $wpdb;
		$uid      = get_current_user_id();
		$password = sanitize_text_field( $r->get_param( 'password' ) ?? '' );

		if ( ! $password ) return $this->error( 'Password is required to delete your account.' );

		// BUG 11 FIX: null-check get_userdata
		$user = get_userdata( $uid );
		if ( ! $user || ! $user->exists() ) {
			return $this->error( 'User account not found.', 404 );
		}
		if ( ! wp_check_password( $password, $user->user_pass, $uid ) ) {
			return $this->error( 'Incorrect password. Account not deleted.' );
		}

		// Anonymise WP user record
		// Ghost-success / GDPR-erasure fix: this is the single write that
		// actually removes the user's real identity (email, login, display
		// name) — everything below it is supplementary data cleanup. It was
		// previously unchecked: if it failed (deadlock, unique-constraint
		// collision on the generated anon_email/login, DB unavailable), the
		// account's real email and login would remain live in wp_users
		// while the response still claimed "Your personal data has been
		// removed." Now aborts before touching any other table if this
		// core anonymisation write doesn't actually happen.
		$anon_email = 'deleted_' . $uid . '_' . time() . '@jp.invalid';
		$anon_result = $wpdb->update( $wpdb->users,
			[ 'user_email' => $anon_email, 'display_name' => 'Deleted User',
			  'user_login' => 'deleted_' . $uid,
			  'user_pass'  => wp_hash_password( wp_generate_password( 64, true, true ) ) ],
			[ 'ID' => $uid ]
		);
		if ( false === $anon_result ) {
			JP_ErrorLog::instance()->log_exception( new \Exception( 'account_delete: wp_users anonymise failed: ' . $wpdb->last_error ), 'JP_Api::account_delete uid=' . $uid );
			return $this->error( 'Could not delete your account right now. Please try again, or contact support if this keeps happening.', 500 );
		}
		// Soft-delete candidate profile
		$wpdb->update( $wpdb->prefix . 'jp_candidates',
			[ 'visibility' => 'private', 'is_open_to_work' => 0, 'avatar_url' => '' ],
			[ 'user_id' => $uid ]
		);
		// Hard delete personal data tables
		foreach ( [ 'jp_notifications', 'jp_push_subscriptions', 'jp_user_badges',
				    'jp_resume_sections', 'jp_saved_jobs', 'jp_alerts',
				    'jp_assessments' ] as $table ) {
			$wpdb->delete( $wpdb->prefix . $table, [ 'user_id' => $uid ] );
		}
		// BUG 14 FIX: message_threads uses recruiter_id/candidate_id not user_id
		$wpdb->query( $wpdb->prepare(
			"DELETE FROM {$wpdb->prefix}jp_message_threads WHERE recruiter_id=%d OR candidate_id=%d",
			$uid, $uid
		) );
		// Delete community posts and replies authored by this user
		$wpdb->delete( $wpdb->prefix . 'jp_community_posts',   [ 'user_id' => $uid ] );
		$wpdb->delete( $wpdb->prefix . 'jp_community_replies', [ 'user_id' => $uid ] );

		JP_Security::instance()->audit( 'account_deleted', 'account', $uid );

		// Root-cause fix (was "BUG 12 NOTE" above, left unresolved): a JWT
		// issued before deletion previously remained valid for up to its
		// full 7-day life, since maybe_auth_via_jwt() only checked the
		// signature and expiry, never whether the underlying account had
		// since been deleted/revoked. Record this user's deletion moment in
		// a revocation registry that maybe_auth_via_jwt() now consults —
		// any token whose 'iat' predates the user's revocation timestamp is
		// rejected immediately, regardless of its own 'exp'.
		self::revoke_jwts_for_user( $uid );
		wp_logout();

		return $this->ok( [ 'message' => 'Account deleted. Your personal data has been removed.' ] );
	}

	// ── Repost job ────────────────────────────────────────────────────────────────

	public function repost_job( \WP_REST_Request $r ) {
		global $wpdb;
		$id  = absint( $r->get_param( 'id' ) );
		$uid = get_current_user_id();
		$job = JP_DB::instance()->get_job( $id );
		if ( ! $job || (int)$job->posted_by !== $uid ) return $this->not_found( 'Job not found.' );
		$new = (array) $job;
		unset( $new['id'], $new['created_at'], $new['updated_at'], $new['views_count'], $new['applications_cnt'] );
		$new['status']     = 'pending';
		$new['expires_at'] = date( 'Y-m-d H:i:s', strtotime( '+30 days' ) );
		$new['created_at'] = current_time( 'mysql' );
		$new['views_count']= 0;
		// Generate a unique slug to prevent duplicate key collision on repost
		$new['slug'] = $new['slug'] . '-' . time();

		$result = $wpdb->insert( $wpdb->prefix . 'jp_jobs', $new );
		if ( $result === false ) {
			return $this->error( 'Failed to repost job. Please try again.' );
		}
		return $this->ok( [ 'id' => $wpdb->insert_id, 'message' => 'Job reposted. It will go live after review.' ], 201 );
	}

	// ── CSV export (admin) ────────────────────────────────────────────────────────

	public function admin_csv_export( \WP_REST_Request $r ) {
		global $wpdb;
		$type = sanitize_key( $r->get_param( 'type' ) );
		$allowed = [ 'applications', 'candidates', 'payments', 'jobs' ];
		if ( ! in_array( $type, $allowed, true ) ) return $this->error( 'Invalid export type.' );

		switch ( $type ) {
			case 'applications':
				$rows = $wpdb->get_results(
					"SELECT a.id,a.stage,a.match_score,a.created_at,j.title AS job,u.display_name AS candidate,u.user_email
					 FROM {$wpdb->prefix}jp_applications a
					 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id
					 LEFT JOIN {$wpdb->users} u ON u.ID=a.candidate_id
					 ORDER BY a.created_at DESC LIMIT 5000",
					ARRAY_A
				);
				break;
			case 'candidates':
				$rows = $wpdb->get_results(
					"SELECT c.user_id,u.display_name,u.user_email,c.location_city,c.experience_years,c.current_title,
						c.profile_score,c.is_open_to_work,c.created_at
					 FROM {$wpdb->prefix}jp_candidates c
					 LEFT JOIN {$wpdb->users} u ON u.ID=c.user_id
					 ORDER BY c.created_at DESC LIMIT 5000",
					ARRAY_A
				);
				break;
			case 'payments':
				$rows = $wpdb->get_results(
					"SELECT p.id,p.amount,p.currency,p.status,p.description,p.created_at,u.display_name,u.user_email
					 FROM {$wpdb->prefix}jp_payments p
					 LEFT JOIN {$wpdb->users} u ON u.ID=p.user_id
					 ORDER BY p.created_at DESC LIMIT 5000",
					ARRAY_A
				);
				break;
			case 'jobs':
				$rows = $wpdb->get_results(
					"SELECT j.id,j.title,j.status,j.job_type,j.work_mode,j.location_city,j.views_count,j.created_at,c.name AS company
					 FROM {$wpdb->prefix}jp_jobs j
					 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id
					 ORDER BY j.created_at DESC LIMIT 5000",
					ARRAY_A
				);
				break;
			default:
				$rows = [];
		}

		if ( empty( $rows ) ) return $this->ok( [ 'data' => [], 'type' => $type, 'count' => 0 ] );

		// Build CSV string
		$csv = implode( ',', array_keys( $rows[0] ) ) . "\n";
		foreach ( $rows as $row ) {
			$csv .= implode( ',', array_map( fn($v) => '"' . str_replace( '"', '""', (string)($v ?? '') ) . '"', $row ) ) . "\n";
		}

		return new \WP_REST_Response( $csv, 200, [
			'Content-Type'        => 'text/csv',
			'Content-Disposition' => 'attachment; filename="jp_' . $type . '_' . date('Y-m-d') . '.csv"',
		] );
	}

	// ── CSV bulk import (admin) ─────────────────────────────────────────────────
	//
	// Root-cause fix (enterprise gap-analysis: "No CSV/bulk import anywhere
	// in class-jp-api.php — export exists for admin, import does not exist
	// for anything (jobs, candidates, companies)"). Candidate import is
	// deliberately NOT built here: a job board's candidates are the actual
	// job seekers using the platform, and bulk-creating "candidate" accounts
	// from a spreadsheet on an admin's behalf would mean either fabricating
	// login credentials nobody consented to or creating unusable orphaned
	// profiles — a real anti-pattern for user data, not a missing feature.
	// Jobs (bulk-posting many listings, e.g. an agency's existing openings
	// migrating onto the platform) and Companies (bulk-onboarding employer
	// accounts) are both legitimate, common enterprise workflows, so those
	// two are built.

	/**
	 * Parses CSV text into [header[], rows[][]] using a real CSV parser
	 * (fgetcsv over an in-memory stream) rather than a naive explode("\n")/
	 * explode(",") split — the latter breaks the moment any field contains
	 * a comma or an embedded newline inside quotes, which a real job
	 * description or company name will eventually contain. Shared by both
	 * import endpoints below so there's exactly one CSV-parsing
	 * implementation in this file, not two that could drift.
	 */
	private function parse_csv_upload( string $csv_text ): array {
		$stream = fopen( 'php://temp', 'r+' );
		fwrite( $stream, $csv_text );
		rewind( $stream );

		$header = fgetcsv( $stream );
		if ( ! $header ) { fclose( $stream ); return [ [], [] ]; }
		$header = array_map( fn( $h ) => strtolower( trim( (string) $h ) ), $header );

		$rows = [];
		while ( ( $line = fgetcsv( $stream ) ) !== false ) {
			if ( count( $line ) === 1 && ( $line[0] === null || trim( (string) $line[0] ) === '' ) ) continue; // blank line
			$row = [];
			foreach ( $header as $i => $key ) {
				$row[ $key ] = isset( $line[ $i ] ) ? trim( (string) $line[ $i ] ) : '';
			}
			$rows[] = $row;
		}
		fclose( $stream );
		return [ $header, $rows ];
	}

	/**
	 * Bulk job import. Expected columns (header row, case-insensitive):
	 * title (required), company_id OR company_name (required — resolves to
	 * an EXISTING company; this endpoint does not create companies, use
	 * admin_import_companies() for that), job_type, work_mode,
	 * location_city, location_state, salary_min, salary_max,
	 * experience_min, experience_max, description, skills (semicolon-
	 * separated), openings. Each row goes through the exact same
	 * JP_Jobs::create() every other job-creation path in this codebase
	 * uses (REST create_job(), and now this) — same validation, same
	 * status/auto-approve logic, same audit trail, same cache invalidation
	 * — so an imported job is indistinguishable from a manually-posted one
	 * except for its origin in the audit log detail. Capped at 1,000 rows
	 * per request to keep this within a single PHP request's execution
	 * time budget on shared hosting (this plugin's stated deployment
	 * target — see class-jp-performance.php's docblock); a caller with a
	 * larger file splits it into multiple uploads.
	 */
	public function admin_import_jobs( \WP_REST_Request $r ) {
		$csv_text = (string) ( $r->get_param( 'csv' ) ?? '' );
		if ( ! trim( $csv_text ) ) return $this->error( 'csv is required.' );

		[ $header, $rows ] = $this->parse_csv_upload( $csv_text );
		if ( ! $rows ) return $this->error( 'No data rows found in the CSV.' );
		if ( count( $rows ) > 1000 ) return $this->error( 'This endpoint accepts at most 1,000 rows per request. Split the file and import in batches.' );
		if ( ! in_array( 'title', $header, true ) ) return $this->error( 'CSV must include a "title" column.' );
		if ( ! in_array( 'company_id', $header, true ) && ! in_array( 'company_name', $header, true ) ) {
			return $this->error( 'CSV must include a "company_id" or "company_name" column.' );
		}

		$db      = JP_DB::instance();
		$created = 0;
		$errors  = [];

		foreach ( $rows as $i => $row ) {
			$line_no = $i + 2; // +1 for header row, +1 for 1-indexing
			$title   = sanitize_text_field( $row['title'] ?? '' );
			if ( ! $title ) { $errors[] = "Row {$line_no}: title is required."; continue; }

			$company = null;
			if ( ! empty( $row['company_id'] ) ) {
				$company = $db->get_company( absint( $row['company_id'] ) );
			} elseif ( ! empty( $row['company_name'] ) ) {
				$company = $db->get_row( $db->prepare(
					"SELECT * FROM {$db->t('companies')} WHERE name = %s LIMIT 1", $row['company_name']
				) );
			}
			if ( ! $company ) { $errors[] = "Row {$line_no}: company not found (\"" . ( $row['company_id'] ?? $row['company_name'] ?? '' ) . '").'; continue; }

			$skills = ! empty( $row['skills'] ) ? array_filter( array_map( 'trim', explode( ';', $row['skills'] ) ) ) : [];
			$job_id = JP_Jobs::instance()->create( [
				'title'          => $title,
				'description'    => wp_kses_post( $row['description'] ?? '' ),
				'job_type'       => sanitize_key( $row['job_type'] ?? 'full-time' ),
				'work_mode'      => sanitize_key( $row['work_mode'] ?? 'onsite' ),
				'location_city'  => sanitize_text_field( $row['location_city'] ?? '' ),
				'location_state' => sanitize_text_field( $row['location_state'] ?? '' ),
				'salary_min'     => absint( $row['salary_min'] ?? 0 ),
				'salary_max'     => absint( $row['salary_max'] ?? 0 ),
				'experience_min' => absint( $row['experience_min'] ?? 0 ),
				'experience_max' => absint( $row['experience_max'] ?? 0 ),
				'skills'         => $skills,
				'openings'       => max( 1, absint( $row['openings'] ?? 1 ) ),
				// The gap-analysis fix in JP_Jobs::create() — see that
				// method's docblock — is what makes this attribute to the
				// RIGHT company instead of the importing admin's own.
				'company_id'     => (int) $company->id,
			], (int) $company->user_id );

			if ( $job_id ) { $created++; } else { $errors[] = "Row {$line_no}: failed to create job \"{$title}\"."; }
		}

		if ( $created > 0 ) JP_Cache::flush_group( 'jobs' );
		JP_Security::instance()->audit( 'jobs_imported', 'jobs', 0, "{$created} created, " . count( $errors ) . ' failed' );

		return $this->ok( [
			'created' => $created,
			'failed'  => count( $errors ),
			'errors'  => array_slice( $errors, 0, 50 ), // cap response size; count() above still reflects the true total
			'message' => "{$created} job(s) imported" . ( $errors ? ', ' . count( $errors ) . ' row(s) failed.' : '.' ),
		] );
	}

	/**
	 * Bulk company import. Expected columns: name (required), owner_email
	 * (required — either links to an existing jp_recruiter account with no
	 * company yet, or creates one). Optional: website, industry, phone,
	 * headquarters, size_range, founded_year.
	 *
	 * A new account's credentials: root-cause note — this deliberately
	 * does NOT call retrieve_password() (WP core's "forgot password" mail
	 * trigger). That function lives in wp-login.php, which is a
	 * page-controller file with top-level request-handling side effects,
	 * not a safely include-able function library — require_once'ing it
	 * from inside a REST callback would run wp-login.php's own $_REQUEST
	 * dispatch logic for whatever the CURRENT request happens to look
	 * like, not a safe way to reach one function. The theoretically
	 * "correct" alternative (get_password_reset_key() + a link to a
	 * reset-password page) is a real gap this codebase doesn't have yet
	 * either: grepping this repo for reset-password / ResetPasswordPage
	 * confirms no such REST route or SPA page exists (tracked separately —
	 * see the enterprise gap-analysis backlog). Rather than emailing an
	 * activation link that would 404, a real, immediately-usable temporary
	 * password is generated and emailed directly, with a prompt to change
	 * it after first login (existing login flow already fully works — see
	 * auth_token()). This is a stopgap that is HONEST about being one
	 * (logged as such below) and should be replaced with a proper
	 * reset-key flow once forgot/reset-password is built.
	 * Every imported company is created with status='pending', same as any
	 * other new company — an import does not bypass the existing
	 * verification workflow (see admin_verify_company()/bulk_company_action()).
	 */
	public function admin_import_companies( \WP_REST_Request $r ) {
		$csv_text = (string) ( $r->get_param( 'csv' ) ?? '' );
		if ( ! trim( $csv_text ) ) return $this->error( 'csv is required.' );

		[ $header, $rows ] = $this->parse_csv_upload( $csv_text );
		if ( ! $rows ) return $this->error( 'No data rows found in the CSV.' );
		if ( count( $rows ) > 1000 ) return $this->error( 'This endpoint accepts at most 1,000 rows per request. Split the file and import in batches.' );
		if ( ! in_array( 'name', $header, true ) || ! in_array( 'owner_email', $header, true ) ) {
			return $this->error( 'CSV must include "name" and "owner_email" columns.' );
		}

		$db      = JP_DB::instance();
		$created = 0;
		$invited = 0;
		$errors  = [];

		foreach ( $rows as $i => $row ) {
			$line_no = $i + 2;
			$name    = sanitize_text_field( $row['name'] ?? '' );
			$email   = sanitize_email( $row['owner_email'] ?? '' );

			if ( ! $name ) { $errors[] = "Row {$line_no}: name is required."; continue; }
			if ( ! $email || ! is_email( $email ) ) { $errors[] = "Row {$line_no}: a valid owner_email is required."; continue; }

			$user = get_user_by( 'email', $email );
			if ( $user ) {
				if ( $db->get_company_by_user( $user->ID ) ) {
					$errors[] = "Row {$line_no}: {$email} already owns a company.";
					continue;
				}
				$owner_id = $user->ID;
			} else {
				$temp_password = wp_generate_password( 16 );
				$owner_id = wp_create_user( $email, $temp_password, $email );
				if ( is_wp_error( $owner_id ) ) { $errors[] = "Row {$line_no}: could not create account for {$email} ({$owner_id->get_error_message()})."; continue; }
				( new \WP_User( $owner_id ) )->set_role( 'jp_recruiter' );
				wp_update_user( [ 'ID' => $owner_id, 'display_name' => $name ] );
				// See this method's docblock: a real, immediately-usable
				// temporary password rather than a reset-key link. Batch 4
				// built a real key-based reset flow (auth_forgot_password()/
				// auth_reset_password() + ResetPasswordPage.tsx) — this
				// still intentionally sends a usable password rather than a
				// reset link, since get_password_reset_key() here would be
				// keying a brand-new account the invited owner has never
				// touched, not a "forgot my password" case; a working
				// credential they can log in with immediately remains the
				// right shape for this specific invite flow.
				wp_mail(
					$email,
					sprintf( __( 'Your %s recruiter account is ready', 'jp-core' ), jp_site_name() ),
					sprintf(
						"An account for \"%s\" has been created on %s.\n\nLog in at: %s\nEmail: %s\nTemporary password: %s\n\nPlease change this password after logging in.",
						$name, home_url( '/' ), home_url( '/login/' ), $email, $temp_password
					)
				);
				$invited++;
			}

			$slug = $db->unique_slug( 'companies', sanitize_title( $name ) ?: 'company-' . $owner_id );
			$company_id = $db->insert( 'companies', [
				'user_id'      => $owner_id,
				'name'         => $name,
				'slug'         => $slug,
				'email'        => $email,
				'website'      => esc_url_raw( $row['website'] ?? '' ),
				'industry'     => sanitize_text_field( $row['industry'] ?? '' ),
				'phone'        => sanitize_text_field( $row['phone'] ?? '' ),
				'headquarters' => sanitize_text_field( $row['headquarters'] ?? '' ),
				'size_range'   => sanitize_text_field( $row['size_range'] ?? '' ),
				'founded_year' => ! empty( $row['founded_year'] ) ? absint( $row['founded_year'] ) : null,
				'status'       => 'pending',
				'created_at'   => current_time( 'mysql' ),
			] );

			if ( $company_id ) {
				$created++;
				JP_Security::instance()->audit( 'company_imported', 'company', $company_id, "Owner: {$email}" );
			} else {
				$errors[] = "Row {$line_no}: failed to create company \"{$name}\".";
			}
		}

		return $this->ok( [
			'created' => $created,
			'invited' => $invited,
			'failed'  => count( $errors ),
			'errors'  => array_slice( $errors, 0, 50 ),
			'message' => "{$created} compan" . ( $created === 1 ? 'y' : 'ies' ) . ' imported' . ( $invited ? " ({$invited} new owner account(s) invited by email)" : '' ) . ( $errors ? ', ' . count( $errors ) . ' row(s) failed.' : '.' ),
		] );
	}

	// ── Webhooks (admin) ──────────────────────────────────────────────────────────

	// Root-cause fix (gap analysis P1 #139: webhooks were stored as a single
	// serialized array inside one wp_options row — a read-modify-write race
	// under concurrent admin edits, plus full-blob deserialization on every
	// load. All four endpoints below now read/write a real `jp_webhooks`
	// table (one row per webhook, added by class-jp-activator.php; existing
	// option data is moved across once by
	// migrations/0002_webhooks_option_to_table.php) so each CRUD operation
	// is an atomic per-row DB statement instead of a race on a shared blob.

	public function admin_webhooks_list( \WP_REST_Request $r ) {
		global $wpdb;
		$rows  = $wpdb->get_results( "SELECT id, url, events_json, active, created_at FROM {$wpdb->prefix}jp_webhooks ORDER BY created_at DESC" );
		$hooks = array_map( function ( $row ) {
			return [
				'id'         => $row->id,
				'url'        => $row->url,
				'events'     => json_decode( $row->events_json ?: '[]', true ) ?: [],
				'active'     => (bool) $row->active,
				'created_at' => $row->created_at,
			];
		}, $rows ?: [] );
		return $this->ok( $hooks );
	}

	public function admin_webhook_create( \WP_REST_Request $r ) {
		$url    = esc_url_raw( $r->get_param( 'url' ) ?? '' );
		$events = array_map( 'sanitize_key', (array)( $r->get_param( 'events' ) ?? [] ) );
		$secret = sanitize_text_field( $r->get_param( 'secret' ) ?? wp_generate_password( 32, false ) );
		if ( ! $url ) return $this->error( 'url is required.' );
		// SSRF guard (previously: none at all — see class-jp-webhooks.php's
		// is_safe_target_url() docblock for what this closes).
		if ( ! class_exists( 'JP_Webhooks' ) || ! JP_Webhooks::is_safe_target_url( $url ) ) {
			return $this->error( 'That URL cannot be used as a webhook target (must be a public http/https host, not a loopback, private-network, or metadata-service address).' );
		}
		global $wpdb;
		$id     = uniqid( 'wh_', true );
		$result = $wpdb->insert( $wpdb->prefix . 'jp_webhooks', [
			'id'          => $id,
			'url'         => $url,
			'events_json' => wp_json_encode( $events ),
			'secret'      => $secret,
			'active'      => 1,
			'created_at'  => current_time( 'mysql' ),
		] );
		if ( false === $result ) return $this->error( 'Failed to save webhook. Please try again.' );
		return $this->ok( [ 'id' => $id, 'message' => 'Webhook created.' ], 201 );
	}

	public function admin_webhook_delete( \WP_REST_Request $r ) {
		global $wpdb;
		$id = sanitize_text_field( $r->get_param( 'id' ) );
		$wpdb->delete( $wpdb->prefix . 'jp_webhooks', [ 'id' => $id ] );
		return $this->ok( [ 'message' => 'Webhook deleted.' ] );
	}

	public function admin_webhook_test( \WP_REST_Request $r ) {
		global $wpdb;
		$id   = sanitize_text_field( $r->get_param( 'id' ) );
		$hook = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_webhooks WHERE id=%s", $id ) );
		if ( ! $hook ) return $this->not_found( 'Webhook not found.' );
		$payload  = [ 'event' => 'test', 'timestamp' => time(), 'message' => 'Test event from JP Jobs' ];
		$body     = wp_json_encode( $payload );
		$sig      = hash_hmac( 'sha256', $body, $hook->secret );
		$response = wp_remote_post( $hook->url, [
			'body'    => $body,
			'headers' => [ 'Content-Type' => 'application/json', 'X-JP-Signature' => "sha256={$sig}" ],
			'timeout' => 10,
		] );
		$code = wp_remote_retrieve_response_code( $response );
		return $this->ok( [ 'status' => $code, 'message' => $code >= 200 && $code < 300 ? 'Test delivered successfully.' : "Target returned HTTP {$code}." ] );
	}

	/**
	 * New (batch 18) — see the route registration above for why: real,
	 * always-written data that had zero read path. Capped at 25 most recent
	 * attempts (matches this file's existing small-recent-list convention,
	 * e.g. admin_health()'s recent-errors slice) since this is a
	 * per-webhook debugging view, not a paginated archive.
	 */
	public function admin_webhook_deliveries( \WP_REST_Request $r ) {
		global $wpdb;
		$id   = sanitize_text_field( $r->get_param( 'id' ) );
		$hook = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}jp_webhooks WHERE id=%s", $id ) );
		if ( ! $hook ) return $this->not_found( 'Webhook not found.' );
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT id, event, status, http_code, response_body, attempt, next_retry_at, created_at, delivered_at
			 FROM {$wpdb->prefix}jp_webhook_deliveries WHERE webhook_id=%s ORDER BY created_at DESC LIMIT 25", $id
		) );
		return $this->ok( $rows ?: [] );
	}

	// ── Market intelligence ───────────────────────────────────────────────────────

	public function market_insights( \WP_REST_Request $r ) {
		global $wpdb;
		$cached = get_transient( 'jp_market_insights' );
		if ( $cached ) return $this->ok( $cached );

		$trending_skills = $wpdb->get_results(
			"SELECT s.name, COUNT(j.id) AS demand
			 FROM {$wpdb->prefix}jp_skills s
			 JOIN {$wpdb->prefix}jp_jobs j ON j.skills_json LIKE CONCAT('%', s.name, '%')
			 WHERE j.created_at > DATE_SUB(NOW(), INTERVAL 30 DAY) AND j.status='active'
			 GROUP BY s.id ORDER BY demand DESC LIMIT 10"
		);
		$top_hiring = $wpdb->get_results(
			"SELECT c.name, c.logo_url, COUNT(j.id) AS jobs
			 FROM {$wpdb->prefix}jp_companies c
			 JOIN {$wpdb->prefix}jp_jobs j ON j.company_id=c.id
			 WHERE j.status='active' AND j.created_at > DATE_SUB(NOW(), INTERVAL 30 DAY)
			 GROUP BY c.id ORDER BY jobs DESC LIMIT 8"
		);
		$avg_salary_by_role = $wpdb->get_results(
			"SELECT title, ROUND(AVG(salary_min + salary_max)/2) AS avg_salary, COUNT(*) AS openings
			 FROM {$wpdb->prefix}jp_jobs
			 WHERE salary_visible=1 AND salary_min>0 AND status='active'
			 GROUP BY title ORDER BY openings DESC LIMIT 10"
		);
		$stats = [
			'active_jobs'        => (int)$wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_jobs WHERE status='active'" ),
			'companies_hiring'   => (int)$wpdb->get_var( "SELECT COUNT(DISTINCT company_id) FROM {$wpdb->prefix}jp_jobs WHERE status='active'" ),
			'new_jobs_today'     => (int)$wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_jobs WHERE DATE(created_at)=CURDATE() AND status='active'" ),
			'remote_jobs'        => (int)$wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_jobs WHERE work_mode='remote' AND status='active'" ),
		];

		/*
		 * Root-cause fix (platform-wide UI/UX audit — user benchmarked against
		 * Naukri/JobHai, whose homepages both lead with "Explore jobs in
		 * 500+ cities" / "What kind of role do you want?" category-chip
		 * sections backed by real counts). HomePage had no equivalent because
		 * this endpoint never aggregated job_type or location_city — both
		 * columns have existed on jp_jobs since its original CREATE TABLE and
		 * are already used for filtering (see JobsPage's job_type/location
		 * params), just never aggregated for display. Real counts, same
		 * 30-day/status='active' scoping as the rest of this endpoint — no
		 * fabricated categories or cities.
		 */
		$job_type_breakdown = $wpdb->get_results(
			"SELECT job_type, COUNT(*) AS jobs
			 FROM {$wpdb->prefix}jp_jobs
			 WHERE status='active' AND job_type IS NOT NULL AND job_type != ''
			 GROUP BY job_type ORDER BY jobs DESC"
		);
		$top_locations = $wpdb->get_results(
			"SELECT location_city, COUNT(*) AS jobs
			 FROM {$wpdb->prefix}jp_jobs
			 WHERE status='active' AND location_city IS NOT NULL AND location_city != ''
			 GROUP BY location_city ORDER BY jobs DESC LIMIT 8"
		);

		$data = compact( 'trending_skills', 'top_hiring', 'avg_salary_by_role', 'stats', 'job_type_breakdown', 'top_locations' );
		set_transient( 'jp_market_insights', $data, 30 * MINUTE_IN_SECONDS );
		return $this->ok( $data );
	}

	// ── Onboarding ────────────────────────────────────────────────────────────────

	public function onboarding_status( \WP_REST_Request $r ) {
		$uid  = get_current_user_id();
		$done = (array) get_user_meta( $uid, 'jp_onboarding_done', true );
		return $this->ok( [ 'completed_steps' => $done, 'is_complete' => count( $done ) >= 5 ] );
	}

	public function onboarding_complete( \WP_REST_Request $r ) {
		$uid  = get_current_user_id();
		$step = sanitize_key( $r->get_param( 'step' ) ?? '' );
		$done = (array) get_user_meta( $uid, 'jp_onboarding_done', true );
		if ( $step && ! in_array( $step, $done, true ) ) {
			$done[] = $step;
			update_user_meta( $uid, 'jp_onboarding_done', $done );
		}
		return $this->ok( [ 'completed_steps' => $done, 'step_saved' => $step ] );
	}

	// ── Help centre ───────────────────────────────────────────────────────────────

	public function help_articles( \WP_REST_Request $r ) {
		// Articles stored in WP options as JSON — admin editable
		$articles = get_option( 'jp_help_articles', [] );
		if ( empty( $articles ) ) {
			// Default starter articles
			$articles = [
				[ 'id'=>1, 'category'=>'Getting Started', 'title'=>'How to create your profile', 'body'=>'Complete your profile to get more recruiter views. Add a professional headline, upload your resume, and list your skills.' ],
				[ 'id'=>2, 'category'=>'Getting Started', 'title'=>'How to apply for jobs', 'body'=>'Browse jobs, click Apply, select your resume, and write a cover letter. One-click apply is available for jobs with no screening questions.' ],
				[ 'id'=>3, 'category'=>'Applications', 'title'=>'Tracking your applications', 'body'=>'Go to Dashboard → Applications to see all your applications and their current stage.' ],
				[ 'id'=>4, 'category'=>'Applications', 'title'=>'What do the application stages mean?', 'body'=>'Applied → Shortlisted → Phone Screen → Interview → Assessment → Offer → Hired. Rejected means the recruiter has decided not to proceed.' ],
				[ 'id'=>5, 'category'=>'Account', 'title'=>'How to set up two-factor authentication', 'body'=>'Go to Settings → Security → Two-Factor Authentication. Download Google Authenticator or Authy, scan the QR code, and enter your first 6-digit code to activate.' ],
				[ 'id'=>6, 'category'=>'Account', 'title'=>'How to download your data', 'body'=>'Go to Settings → Privacy → Download My Data. A JSON file with all your profile, applications, and messages will be prepared.' ],
				[ 'id'=>7, 'category'=>'Recruiters', 'title'=>'How to post a job', 'body'=>'Go to Recruiter Dashboard → Jobs → Post a Job. Fill in the job details, requirements, and salary. Jobs go live after admin review (usually within 2 hours).' ],
				[ 'id'=>8, 'category'=>'Recruiters', 'title'=>'How to move candidates through stages', 'body'=>'Go to Applications, click on a candidate, then click Move Stage. You can add a note that will be emailed to the candidate.' ],
			];
			update_option( 'jp_help_articles', $articles );
		}
		$q = sanitize_text_field( $r->get_param( 'q' ) ?? '' );
		if ( $q ) {
			$articles = array_filter( $articles, fn($a) => stripos( $a['title'], $q ) !== false || stripos( $a['body'], $q ) !== false );
		}
		return $this->ok( array_values( $articles ) );
	}

	public function help_contact( \WP_REST_Request $r ) {
		// Rate limit: 3 contact form submissions per IP per hour (spam prevention)
		if ( ! JP_Security::rate_limit( 'help_contact', 3, 3600 ) ) {
			return $this->error( 'Too many messages sent. Please try again later.', 429 );
		}

		$name    = sanitize_text_field( $r->get_param( 'name' )    ?? '' );
		$email   = sanitize_email(      $r->get_param( 'email' )   ?? '' );
		$subject = sanitize_text_field( $r->get_param( 'subject' ) ?? 'Support Request' );
		$message = sanitize_textarea_field( $r->get_param( 'message' ) ?? '' );
		if ( ! $name || ! $email || ! $message ) return $this->error( 'name, email, and message are required.' );
		if ( ! is_email( $email ) ) return $this->error( 'Please provide a valid email address.' );

		$admin_email = get_option( 'admin_email' );
		$sent = wp_mail(
			$admin_email,
			'[JP Jobs Support] ' . $subject,
			"From: {$name} ({$email})\n\n" . $message,
			[ 'Reply-To: ' . $name . ' <' . $email . '>' ]
		);
		if ( ! $sent ) return $this->error( 'Failed to send message. Please try again or email us directly.' );
		return $this->ok( [ 'message' => 'Your message has been sent. We typically respond within 24 hours.' ] );
	}

	// ── Changelog ────────────────────────────────────────────────────────────────

	public function get_changelog( \WP_REST_Request $r ) {
		$log = [
			[ 'version' => '4.8.0', 'date' => '2026-06-06', 'type' => 'major', 'notes' => [
				'PWA: Install to home screen, offline support, push notifications',
				'Mobile: Bottom navigation, voice search, biometric login',
				'Pull-to-refresh on all list views',
			] ],
			[ 'version' => '4.7.0', 'date' => '2026-06-05', 'type' => 'major', 'notes' => [
				'Community Q&A forum with categories, replies, and likes',
				'Gamification: 8 achievement badges with milestone tracking',
				'Resume builder: structured sections for experience, education, skills',
				'Admin: Company management, job approvals, full settings panel',
				'Public shareable candidate profiles',
			] ],
			[ 'version' => '4.6.0', 'date' => '2026-06-05', 'type' => 'major', 'notes' => [
				'Events system: list, register, attend webinars and career fairs',
				'Recruiter analytics: hiring funnel, top jobs, application trends',
				'Recruiter candidate search with 5 filters',
				'Company profile editor with logo upload',
			] ],
			[ 'version' => '4.5.0', 'date' => '2026-06-05', 'type' => 'major', 'notes' => [
				'Full admin panel: users, reviews, payments, settings, health',
				'Recruiter billing: current plan, credits, Razorpay upgrade, invoices',
				'Review moderation with automatic rating recalculation',
			] ],
			[ 'version' => '4.4.0', 'date' => '2026-06-05', 'type' => 'major', 'notes' => [
				'Recruiter ATS: job list, application pipeline, candidate panel',
				'Interview scheduler with Google Meet link and candidate notification',
				'Bulk stage actions, internal notes, AI interview questions',
				'Bug fix: candidates now see their applications (role slug fixed)',
			] ],
		];
		return $this->ok( $log );
	}

	// ── Push subscription handlers ───────────────────────────────────────────────

	/**
	 * Batch 29 — root-cause fix. This route wrote to a column named
	 * 'p256dh', which does not exist on jp_push_subscriptions (the real
	 * column is p256dh_key — see class-jp-activator.php's CREATE TABLE).
	 * $wpdb->replace() builds its column list directly from the array
	 * keys it's given, so MySQL rejected the whole statement ("Unknown
	 * column 'p256dh'") and NOTHING was ever persisted through this
	 * route — not even the valid endpoint/auth_key — while the unchecked
	 * write let it report success regardless. This route was dead in
	 * practice (features/candidates/meApi.ts's pushSubscribe() docblock
	 * explains the SPA deliberately routes through the AJAX pair instead,
	 * jp_save_push_sub/ajax_save_subscription() in class-jp-pwa.php, which
	 * already used the correct column and was checked in batch 18) — but
	 * a REST route with this exact name existing and silently doing
	 * nothing is exactly the kind of trap a future integration would hit
	 * first and hardest, so it's fixed here to match the working AJAX
	 * path column-for-column rather than left broken because nothing
	 * currently calls it.
	 */
	public function push_subscribe( \WP_REST_Request $r ) {
		global $wpdb;
		$uid      = get_current_user_id();
		$endpoint = esc_url_raw( $r->get_param('endpoint') ?? '' );
		$keys     = (array) ( $r->get_param('keys') ?? [] );
		$p256dh   = sanitize_text_field( $keys['p256dh'] ?? $r->get_param('p256dh') ?? '' );
		$auth_key = sanitize_text_field( $keys['auth']   ?? $r->get_param('auth_key') ?? '' );
		if ( ! $endpoint ) return $this->error( 'endpoint is required.' );

		$write_ok = false !== $wpdb->replace( $wpdb->prefix . 'jp_push_subscriptions', [
			'user_id'    => $uid,
			'endpoint'   => $endpoint,
			'p256dh_key' => $p256dh,
			'auth_key'   => $auth_key,
			'user_agent' => sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ?? '' ),
			'created_at' => current_time( 'mysql' ),
		], ['%d','%s','%s','%s','%s','%s'] );

		if ( ! $write_ok ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_push_subscriptions write failed: ' . $wpdb->last_error ), 'JP_Api::push_subscribe user_id=' . $uid );
			}
			return $this->error( 'Could not save push subscription. Please try again.' );
		}
		return $this->ok( ['message' => 'Subscribed to push notifications.'] );
	}

	public function push_unsubscribe( \WP_REST_Request $r ) {
		global $wpdb;
		$uid = get_current_user_id();
		if ( false === $wpdb->delete( $wpdb->prefix . 'jp_push_subscriptions', ['user_id' => $uid] ) ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_push_subscriptions delete failed: ' . $wpdb->last_error ), 'JP_Api::push_unsubscribe user_id=' . $uid );
			}
			return $this->error( 'Could not remove push subscription. Please try again.' );
		}
		return $this->ok( ['message' => 'Unsubscribed from push notifications.'] );
	}

	// ── Community handlers ───────────────────────────────────────────────────────

	/**
	 * Phase 3 redesign (Tier A, redesign-plan §CommunityPage) — found and
	 * fixed a real unauthenticated PII leak while touching this page: this
	 * endpoint is registered with the public permission_callback ($pub, no
	 * auth needed at all), and its SELECT included u.user_email — every
	 * community post listed a poster's real email address to anyone,
	 * logged in or not. Nothing in the SPA ever read that field (see
	 * CommunityPostRow's type, which never declared it), but the raw JSON
	 * response leaked it regardless — the same class of bug as the
	 * phone-number leak fixed on public_profile() in Phase 2. Removed
	 * u.user_email from the SELECT; only display_name (already
	 * public-facing on every post byline) is joined now.
	 */
	public function community_get_posts( \WP_REST_Request $r ) {
		global $wpdb;
		$category = sanitize_key( $r->get_param('category') ?? '' );
		$q        = sanitize_text_field( $r->get_param('q') ?? '' );
		// Whitelisted sort — user input only selects between two hardcoded safe strings; NOT injectable
		$sort     = $r->get_param('sort') === 'popular' ? 'p.views DESC' : 'p.created_at DESC';
		$page     = max(1, absint($r->get_param('page') ?? 1));
		$per      = 20; $off = ($page-1)*$per;
		$conds = ['1=1'];
		if ($category) $conds[] = $wpdb->prepare("p.category=%s", $category);
		if ($q)        $conds[] = $wpdb->prepare("(p.title LIKE %s OR p.body LIKE %s)", '%'.esc_sql($q).'%','%'.esc_sql($q).'%');
		$where = 'WHERE ' . implode(' AND ', $conds);
		$rows = $wpdb->get_results(
			"SELECT p.*,u.display_name
			 FROM {$wpdb->prefix}jp_community_posts p
			 LEFT JOIN {$wpdb->users} u ON u.ID=p.user_id
			 {$where} ORDER BY {$sort} LIMIT {$per} OFFSET {$off}"
		);
		$total = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}jp_community_posts p {$where}");
		return $this->ok(['posts'=>$rows??[],'total'=>$total]);
	}

	public function community_get_post( \WP_REST_Request $r ) {
		global $wpdb;
		$id = absint($r->get_param('id'));
		$wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}jp_community_posts SET views=views+1 WHERE id=%d", $id));
		$row = $wpdb->get_row($wpdb->prepare(
			"SELECT p.*,u.display_name FROM {$wpdb->prefix}jp_community_posts p LEFT JOIN {$wpdb->users} u ON u.ID=p.user_id WHERE p.id=%d", $id
		));
		if (!$row) return $this->not_found('Post not found.');
		return $this->ok($row);
	}

	public function community_create_post( \WP_REST_Request $r ) {
		// Root-cause fix (gap analysis P1 #153/#157: no rate limit on
		// community post/reply creation, and no spam controls of any kind
		// on these public-write endpoints beyond basic auth).
		if ( ! JP_Security::rate_limit( 'jp_community_create_post', 5, 600, (string) get_current_user_id() ) ) {
			return $this->error( 'You are posting too quickly. Please wait a few minutes.', 429 );
		}
		global $wpdb;
		$title    = sanitize_text_field($r->get_param('title') ?? '');
		$body     = wp_kses_post($r->get_param('body') ?? '');
		$category = sanitize_key($r->get_param('category') ?? 'general');
		$tags     = json_encode(array_slice((array)($r->get_param('tags') ?? []), 0, 5));
		if (!$title || !$body) return $this->error('title and body are required.');
		$result = $wpdb->insert($wpdb->prefix.'jp_community_posts', [
			'user_id'=>get_current_user_id(),'category'=>$category,
			'title'=>$title,'body'=>$body,'tags_json'=>$tags,'created_at'=>current_time('mysql'),
		], ['%d','%s','%s','%s','%s','%s']);
		if ( $result === false ) return $this->error( 'Failed to create post. Please try again.' );
		return $this->ok(['id'=>$wpdb->insert_id,'message'=>'Post created.'], 201);
	}

	public function community_get_replies( \WP_REST_Request $r ) {
		// Unbounded-query fix: this had no LIMIT at all — a long-running
		// popular discussion post could accumulate replies without bound,
		// and every request for that thread would pull the entire history
		// in one response. Capped at 500, consistent with this codebase's
		// existing convention for other "whole list" reads (jp_skills uses
		// the same 500 cap a few hundred lines above).
		global $wpdb;
		$id = absint($r->get_param('id'));
		$rows = $wpdb->get_results($wpdb->prepare(
			"SELECT r.*,u.display_name FROM {$wpdb->prefix}jp_community_replies r
			 LEFT JOIN {$wpdb->users} u ON u.ID=r.user_id
			 WHERE r.post_id=%d ORDER BY r.is_accepted DESC, r.likes DESC, r.created_at ASC LIMIT 500", $id
		));
		return $this->ok($rows??[]);
	}

	public function community_add_reply( \WP_REST_Request $r ) {
		if ( ! JP_Security::rate_limit( 'jp_community_add_reply', 10, 600, (string) get_current_user_id() ) ) {
			return $this->error( 'You are replying too quickly. Please wait a few minutes.', 429 );
		}
		global $wpdb;
		$post_id = absint($r->get_param('id'));
		$body    = wp_kses_post($r->get_param('body') ?? '');
		if (!$body) return $this->error('body is required.');
		$result = $wpdb->insert($wpdb->prefix.'jp_community_replies', [
			'post_id'=>$post_id,'user_id'=>get_current_user_id(),
			'body'=>$body,'created_at'=>current_time('mysql'),
		], ['%d','%d','%s','%s']);
		if ( $result === false ) return $this->error( 'Failed to post reply. Please try again.' );
		// Only increment count after confirmed insert
		$wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}jp_community_posts SET reply_count=reply_count+1 WHERE id=%d",$post_id));
		return $this->ok(['id'=>$wpdb->insert_id,'message'=>'Reply added.'], 201);
	}

	/**
	 * New (batch 23) — see the route registration above for the root cause.
	 * Only the post's own author can accept/unaccept a reply (own-thread
	 * ownership check, matching every other own-resource action in this
	 * file). Toggles: accepting a reply unaccepts any other reply already
	 * marked accepted on that post first (at most one accepted answer per
	 * post, matching community_get_replies()'s ORDER BY is_accepted DESC
	 * assumption of a single "top" answer) and sets is_resolved=1;
	 * unaccepting the currently-accepted reply sets is_resolved back to 0.
	 */
	public function community_accept_reply( \WP_REST_Request $r ) {
		global $wpdb;
		$post_id  = absint( $r->get_param( 'id' ) );
		$reply_id = absint( $r->get_param( 'reply_id' ) );
		$post     = $wpdb->get_row( $wpdb->prepare( "SELECT user_id FROM {$wpdb->prefix}jp_community_posts WHERE id=%d", $post_id ) );
		if ( ! $post ) return $this->not_found( 'Post not found.' );
		if ( (int) $post->user_id !== get_current_user_id() ) return $this->forbidden();
		$reply = $wpdb->get_row( $wpdb->prepare(
			"SELECT id,is_accepted FROM {$wpdb->prefix}jp_community_replies WHERE id=%d AND post_id=%d", $reply_id, $post_id
		) );
		if ( ! $reply ) return $this->not_found( 'Reply not found on this post.' );

		$now_accepted = ! $reply->is_accepted;
		if ( $now_accepted ) {
			// Only one accepted answer at a time.
			if ( false === $wpdb->update(
				$wpdb->prefix . 'jp_community_replies', [ 'is_accepted' => 0 ],
				[ 'post_id' => $post_id, 'is_accepted' => 1 ]
			) ) {
				return $this->error( 'Could not update the previously accepted reply. Please try again.' );
			}
		}
		$updated = $wpdb->update(
			$wpdb->prefix . 'jp_community_replies', [ 'is_accepted' => $now_accepted ? 1 : 0 ], [ 'id' => $reply_id ]
		);
		if ( false === $updated ) return $this->error( 'Could not update this reply. Please try again.' );

		$resolved_updated = $wpdb->update(
			$wpdb->prefix . 'jp_community_posts', [ 'is_resolved' => $now_accepted ? 1 : 0 ], [ 'id' => $post_id ]
		);
		if ( false === $resolved_updated ) return $this->error( 'Could not update the post\'s resolved status. Please try again.' );

		return $this->ok( [ 'message' => $now_accepted ? 'Reply marked as the accepted answer.' : 'Reply unmarked.', 'is_accepted' => $now_accepted ] );
	}

	public function community_like_post( \WP_REST_Request $r ) {
		// Root-cause fix (newly-discovered while addressing gap analysis
		// P1 #153): this endpoint previously did an unconditional
		// `likes = likes + 1` on every call with no per-user tracking of any
		// kind. It IS gated by $auth at route registration, but "logged in"
		// is not "has not already liked this post" — any authenticated user
		// could call it in a loop and inflate the count without limit, and
		// there was no way to unlike or to know whether the current user had
		// already liked a given post. Rewritten as a genuine toggle backed
		// by jp_community_likes (UNIQUE(post_id, user_id) — see
		// class-jp-activator.php), with the count recomputed from that table
		// (COUNT(*)) rather than trusted from a manually-incremented column,
		// and a rate limit added consistent with the other community
		// endpoints touched in this same round.
		if ( ! JP_Security::rate_limit( 'jp_community_like_post', 30, 60, (string) get_current_user_id() ) ) {
			return $this->error( 'Too many requests. Please slow down.', 429 );
		}
		global $wpdb;
		$post_id = absint( $r->get_param( 'id' ) );
		$user_id = get_current_user_id();
		$likes_tbl = $wpdb->prefix . 'jp_community_likes';
		$posts_tbl = $wpdb->prefix . 'jp_community_posts';

		if ( ! $post_id || ! $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$posts_tbl} WHERE id=%d", $post_id ) ) ) {
			return $this->error( 'Post not found.', 404 );
		}

		$existing = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$likes_tbl} WHERE post_id=%d AND user_id=%d", $post_id, $user_id
		) );

		// Ghost-success fix: both branches previously set $liked to the
		// ATTEMPTED outcome unconditionally. Since $likes below is a real
		// re-query of the authoritative table, a failed write would return
		// a self-contradictory response — e.g. liked:true but likes count
		// unchanged — visibly wrong to the frontend rather than just
		// silently wrong. Now $liked reflects the row's true post-write
		// state either way (re-derived from whether the write actually
		// succeeded, not from which branch was attempted).
		if ( $existing ) {
			$result = $wpdb->delete( $likes_tbl, [ 'post_id' => $post_id, 'user_id' => $user_id ] );
			$liked  = false === $result ? true : false; // failed delete = still liked
			if ( false === $result && class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_community_likes delete failed: ' . $wpdb->last_error ), 'JP_Api::community_toggle_like post_id=' . $post_id . ' user_id=' . $user_id );
			}
		} else {
			$result = $wpdb->insert( $likes_tbl, [
				'post_id'    => $post_id,
				'user_id'    => $user_id,
				'created_at' => current_time( 'mysql' ),
			], [ '%d', '%d', '%s' ] );
			$liked  = false !== $result; // failed insert = still not liked
			if ( false === $result && class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_community_likes insert failed: ' . $wpdb->last_error ), 'JP_Api::community_toggle_like post_id=' . $post_id . ' user_id=' . $user_id );
			}
		}

		$likes = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$likes_tbl} WHERE post_id=%d", $post_id ) );
		// Keep the denormalized counter column on jp_community_posts (used
		// elsewhere for list-view sorting/display) in sync with the
		// authoritative per-user table, rather than removing it and forcing
		// a JOIN/subquery on every post-list render.
		$wpdb->update( $posts_tbl, [ 'likes' => $likes ], [ 'id' => $post_id ] );

		return $this->ok( [ 'likes' => $likes, 'liked' => $liked ] );
	}

	// ── Gamification ──────────────────────────────────────────────────────────────

	public function gamification_badges( \WP_REST_Request $r ) {
		global $wpdb;
		$uid = get_current_user_id();
		$candidate = JP_DB::instance()->get_candidate($uid);
		$score     = $candidate ? (int)($candidate->profile_score ?? 0) : 0;
		$apps      = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications WHERE candidate_id=%d",$uid));
		$assess    = (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}jp_assessments WHERE user_id=%d AND badge_level!='none'",$uid));

		// Award badges based on milestones
		$to_award = [];
		if ($score >= 50)  $to_award[] = 'profile_starter';
		if ($score >= 80)  $to_award[] = 'profile_pro';
		if ($score >= 100) $to_award[] = 'profile_complete';
		if ($apps >= 1)    $to_award[] = 'first_application';
		if ($apps >= 10)   $to_award[] = 'active_applicant';
		if ($apps >= 50)   $to_award[] = 'power_applicant';
		if ($assess >= 1)  $to_award[] = 'skill_certified';
		if ($assess >= 5)  $to_award[] = 'multi_skilled';

		// Insert new badges
		foreach ($to_award as $badge) {
			$wpdb->query($wpdb->prepare(
				"INSERT IGNORE INTO {$wpdb->prefix}jp_user_badges (user_id,badge,awarded_at) VALUES (%d,%s,%s)",
				$uid, $badge, current_time('mysql')
			));
		}

		// Fetch all earned badges
		$earned = $wpdb->get_results($wpdb->prepare(
			"SELECT badge,awarded_at FROM {$wpdb->prefix}jp_user_badges WHERE user_id=%d ORDER BY awarded_at ASC", $uid
		));

		return $this->ok([
			'earned'        => $earned??[],
			'profile_score' => $score,
			'applications'  => $apps,
			'certifications'=> $assess,
			'next_milestone'=> $this->next_badge_milestone($score,$apps,$assess),
		]);
	}

	private function next_badge_milestone( int $score, int $apps, int $assess ): array {
		if ($score < 50)  return ['badge'=>'profile_starter','description'=>'Get your profile to 50% complete','progress'=>$score,'target'=>50];
		if ($score < 80)  return ['badge'=>'profile_pro','description'=>'Get your profile to 80% complete','progress'=>$score,'target'=>80];
		if ($apps < 1)    return ['badge'=>'first_application','description'=>'Submit your first application','progress'=>$apps,'target'=>1];
		if ($apps < 10)   return ['badge'=>'active_applicant','description'=>'Apply to 10 jobs','progress'=>$apps,'target'=>10];
		if ($assess < 1)  return ['badge'=>'skill_certified','description'=>'Pass your first skill assessment','progress'=>$assess,'target'=>1];
		if ($apps < 50)   return ['badge'=>'power_applicant','description'=>'Apply to 50 jobs','progress'=>$apps,'target'=>50];
		return ['badge'=>'all_complete','description'=>'All badges earned!','progress'=>100,'target'=>100];
	}

	/**
	 * TRACE: GET /gamification/leaderboard, any logged-in candidate →
	 * ranks candidates by (badge_count DESC, profile_score DESC) →
	 * returns the top 20 plus the current user's own row/rank even when
	 * outside the top 20, so a candidate always sees where they stand.
	 * Privacy: only candidates with jp_candidates.visibility='public' are
	 * eligible to appear (same rule public_profile() enforces), and only
	 * display_name + badge_count + profile_score + rank are exposed — no
	 * email/phone/location, matching the PII-leak fix already applied to
	 * public_profile() elsewhere in this file.
	 */
	public function gamification_leaderboard( \WP_REST_Request $r ) {
		global $wpdb;
		$uid = get_current_user_id();

		$rows = $wpdb->get_results(
			"SELECT c.user_id, u.display_name, c.profile_score,
				(SELECT COUNT(*) FROM {$wpdb->prefix}jp_user_badges b WHERE b.user_id = c.user_id) AS badge_count
			 FROM {$wpdb->prefix}jp_candidates c
			 LEFT JOIN {$wpdb->users} u ON u.ID = c.user_id
			 WHERE c.visibility = 'public'
			 HAVING badge_count > 0
			 ORDER BY badge_count DESC, c.profile_score DESC
			 LIMIT 20"
		);

		$leaderboard = [];
		$rank = 0;
		foreach ( (array) $rows as $row ) {
			$rank++;
			$leaderboard[] = [
				'rank'          => $rank,
				'user_id'       => (int) $row->user_id,
				'display_name'  => $row->display_name,
				'badge_count'   => (int) $row->badge_count,
				'profile_score' => (int) $row->profile_score,
				'is_you'        => (int) $row->user_id === $uid,
			];
		}

		// If the current user is public + has badges but fell outside the
		// top 20, compute and append their own real rank (not "20+") so
		// they still see accurate standing rather than nothing at all.
		$in_top = false;
		foreach ( $leaderboard as $row ) {
			if ( $row['is_you'] ) { $in_top = true; break; }
		}
		$your_rank = null;
		if ( ! $in_top ) {
			$candidate = JP_DB::instance()->get_candidate( $uid );
			if ( $candidate && $candidate->visibility === 'public' ) {
				$your_badges = (int) $wpdb->get_var( $wpdb->prepare(
					"SELECT COUNT(*) FROM {$wpdb->prefix}jp_user_badges WHERE user_id=%d", $uid
				) );
				if ( $your_badges > 0 ) {
					$ahead = (int) $wpdb->get_var( $wpdb->prepare(
						"SELECT COUNT(*) FROM (
							SELECT c.user_id, (SELECT COUNT(*) FROM {$wpdb->prefix}jp_user_badges b WHERE b.user_id=c.user_id) AS bc
							FROM {$wpdb->prefix}jp_candidates c WHERE c.visibility='public'
						) t WHERE t.bc > %d", $your_badges
					) );
					$your_rank = $ahead + 1;
				}
			}
		}

		return $this->ok( [
			'leaderboard' => $leaderboard,
			'your_rank'   => $your_rank,
		] );
	}

	// ── Resume sections ───────────────────────────────────────────────────────────

	public function get_resume_sections( \WP_REST_Request $r ) {
		global $wpdb;
		$rows = $wpdb->get_results($wpdb->prepare(
			"SELECT section,content FROM {$wpdb->prefix}jp_resume_sections WHERE user_id=%d ORDER BY sort_order ASC",
			get_current_user_id()
		));
		$sections = [];
		foreach ($rows as $row) $sections[$row->section] = json_decode($row->content??'[]',true)?:[];
		return $this->ok($sections);
	}

	public function save_resume_section( \WP_REST_Request $r ) {
		global $wpdb;
		$uid     = get_current_user_id();
		$section = sanitize_key($r->get_param('section') ?? '');
		$content = $r->get_param('content');
		$allowed = ['experience','education','skills','certifications','projects','languages','awards'];
		if (!in_array($section,$allowed,true)) return $this->error('Invalid section name.');
		$content_json = json_encode($content);
		$exists = $wpdb->get_var($wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}jp_resume_sections WHERE user_id=%d AND section=%s",$uid,$section
		));
		// Ghost-success fix: unconditionally returned "Section saved." even
		// if the write failed — real user-authored resume content (work
		// experience, education, projects) would appear to save in the UI
		// and then vanish on reload, with nothing in the response to
		// indicate the loss.
		if ($exists) {
			$result = $wpdb->update($wpdb->prefix.'jp_resume_sections',['content'=>$content_json,'updated_at'=>current_time('mysql')],['user_id'=>$uid,'section'=>$section]);
		} else {
			$result = $wpdb->insert($wpdb->prefix.'jp_resume_sections',['user_id'=>$uid,'section'=>$section,'content'=>$content_json,'updated_at'=>current_time('mysql')],['%d','%s','%s','%s']);
		}
		if (false === $result) {
			JP_ErrorLog::instance()->log_exception(new \Exception('jp_resume_sections write failed: '.$wpdb->last_error), 'JP_Api::save_resume_section uid='.$uid.' section='.$section);
			return $this->error('Could not save this section. Please try again.', 500);
		}
		return $this->ok(['message'=>'Section saved.']);
	}

	// ── Admin companies ───────────────────────────────────────────────────────────

	public function admin_companies( \WP_REST_Request $r ) {
		global $wpdb;
		$q      = sanitize_text_field($r->get_param('q')??'');
		$status = sanitize_key($r->get_param('status')??'');
		$page   = max(1,absint($r->get_param('page')??1));
		$per    = 20; $off = ($page-1)*$per;
		$conds  = ['1=1'];
		if ($q)      $conds[] = $wpdb->prepare("(c.name LIKE %s OR c.email LIKE %s)",'%'.esc_sql($q).'%','%'.esc_sql($q).'%');
		if ($status) $conds[] = $wpdb->prepare("c.status=%s",$status);
		$where  = 'WHERE ' . implode(' AND ',$conds);
		$rows   = $wpdb->get_results(
			"SELECT c.*,u.display_name AS owner_name,u.user_email AS owner_email,
				(SELECT COUNT(*) FROM {$wpdb->prefix}jp_jobs j WHERE j.company_id=c.id AND j.status='active') AS active_jobs
			 FROM {$wpdb->prefix}jp_companies c
			 LEFT JOIN {$wpdb->users} u ON u.ID=c.user_id
			 {$where} ORDER BY c.created_at DESC LIMIT {$per} OFFSET {$off}"
		);
		$total = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}jp_companies c {$where}");
		return $this->ok(['companies'=>$rows??[],'total'=>$total]);
	}

	/**
	 * New in batch 39. Same shape/pattern as admin_companies() /
	 * admin_users() above — platform-wide search+pagination, not scoped to
	 * one recruiter's company like get_recruiter_applications() is. Once an
	 * admin has found the application here, the existing
	 * GET /applications/{id}, PUT /applications/{id}/stage, and
	 * POST /applications/{id}/note endpoints already work for them (all
	 * three already grant a manage_options/jp_manage_all_applications
	 * override) — this endpoint's only job is the search/discovery step
	 * those never had.
	 */
	public function admin_applications( \WP_REST_Request $r ) {
		global $wpdb;
		$q      = sanitize_text_field( $r->get_param( 'q' ) ?? '' );
		$stage  = sanitize_key( $r->get_param( 'stage' ) ?? '' );
		$page   = max( 1, absint( $r->get_param( 'page' ) ?? 1 ) );
		$per    = 20;
		$off    = ( $page - 1 ) * $per;
		$conds  = [ '1=1' ];
		if ( $q ) {
			if ( ctype_digit( $q ) ) {
				$conds[] = $wpdb->prepare( 'a.id = %d', (int) $q );
			} else {
				$conds[] = $wpdb->prepare(
					'(u.display_name LIKE %s OR u.user_email LIKE %s OR j.title LIKE %s OR c.name LIKE %s)',
					'%' . esc_sql( $q ) . '%', '%' . esc_sql( $q ) . '%', '%' . esc_sql( $q ) . '%', '%' . esc_sql( $q ) . '%'
				);
			}
		}
		if ( $stage ) $conds[] = $wpdb->prepare( 'a.stage = %s', $stage );
		$where = 'WHERE ' . implode( ' AND ', $conds );

		$rows = $wpdb->get_results(
			"SELECT a.id, a.job_id, a.candidate_id, a.company_id, a.stage, a.match_score,
			        a.created_at, a.updated_at,
			        j.title AS job_title, c.name AS company_name,
			        u.display_name AS candidate_name, u.user_email AS candidate_email
			 FROM {$wpdb->prefix}jp_applications a
			 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id = a.job_id
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id = a.company_id
			 LEFT JOIN {$wpdb->users} u ON u.ID = a.candidate_id
			 {$where} ORDER BY a.updated_at DESC LIMIT {$per} OFFSET {$off}"
		);
		$total = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications a
			 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=a.company_id
			 LEFT JOIN {$wpdb->users} u ON u.ID=a.candidate_id {$where}"
		);
		return $this->ok( [ 'applications' => $rows ?: [], 'total' => $total ] );
	}

	public function admin_company_status( \WP_REST_Request $r ) {
		global $wpdb;
		$id     = absint($r->get_param('id'));
		$status = sanitize_key($r->get_param('status')??'');
		if (!in_array($status,['active','suspended','pending'],true)) return $this->error('Invalid status.');
		$wpdb->update($wpdb->prefix.'jp_companies',['status'=>$status],['id'=>$id]);
		JP_Security::instance()->audit('company_status_'.$status,'company',$id);
		return $this->ok(['message'=>"Company status set to {$status}."]);
	}

	/**
	 * Root-cause fix (enterprise gap-analysis: admin Companies had status
	 * changes and verification, but only one row at a time — the same
	 * asymmetry as Users, see bulk_user_action()). Combines
	 * admin_company_status()'s status transitions and admin_verify_company()'s
	 * verification toggle into one bulk endpoint since both are simple
	 * single-column updates on the same table; kept as one route (action
	 * dispatch) rather than two bulk routes to match the single "Companies"
	 * bulk toolbar the SPA renders.
	 */
	public function bulk_company_action( \WP_REST_Request $r ) {
		global $wpdb;
		$ids    = array_map( 'absint', (array) $r->get_param( 'ids' ) );
		$action = sanitize_key( $r->get_param( 'action' ) ?? '' );
		$allowed_actions = [ 'activate', 'suspend', 'verify', 'unverify' ];
		if ( ! $ids || ! in_array( $action, $allowed_actions, true ) ) {
			return $this->error( 'ids and a valid action (activate, suspend, verify, unverify) are required.' );
		}
		// Input-validation fix, same as bulk_user_action() above: no cap
		// existed on batch size.
		if ( count( $ids ) > 200 ) {
			return $this->error( 'Bulk actions are limited to 200 items at a time. Please select fewer and try again.' );
		}

		$table   = $wpdb->prefix . 'jp_companies';
		$done    = 0;
		$skipped = 0;

		// N+1 fix: this used to run one SELECT COUNT(*) per id inside the
		// loop below — a bulk action on, say, 200 companies selected in the
		// admin list meant 200 existence-check queries before a single
		// update ran. Fetched once as a single IN(...) query instead; the
		// per-id UPDATE + audit-log entry below still has to run per row
		// (each needs its own audit trail entry and its own update() result
		// checked), so only the existence check collapses to one query.
		$id_placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$existing_ids     = $wpdb->get_col( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE id IN ({$id_placeholders})", $ids
		) );
		$existing_ids = array_flip( array_map( 'intval', $existing_ids ) );

		foreach ( $ids as $id ) {
			if ( ! isset( $existing_ids[ $id ] ) ) { $skipped++; continue; }

			switch ( $action ) {
				case 'activate':
					$ok = $wpdb->update( $table, [ 'status' => 'active' ], [ 'id' => $id ] ) !== false;
					if ( $ok ) JP_Security::instance()->audit( 'company_status_active', 'company', $id, '(bulk)' );
					break;
				case 'suspend':
					$ok = $wpdb->update( $table, [ 'status' => 'suspended' ], [ 'id' => $id ] ) !== false;
					if ( $ok ) JP_Security::instance()->audit( 'company_status_suspended', 'company', $id, '(bulk)' );
					break;
				case 'verify':
					$ok = $wpdb->update( $table, [ 'is_verified' => 1 ], [ 'id' => $id ] ) !== false;
					if ( $ok ) JP_Security::instance()->audit( 'company_verified', 'company', $id, '(bulk)' );
					break;
				case 'unverify':
					$ok = $wpdb->update( $table, [ 'is_verified' => 0 ], [ 'id' => $id ] ) !== false;
					if ( $ok ) JP_Security::instance()->audit( 'company_unverified', 'company', $id, '(bulk)' );
					break;
				default:
					$ok = false;
			}

			if ( $ok ) $done++; else $skipped++;
		}

		return $this->ok( [
			'done'    => $done,
			'skipped' => $skipped,
			'message' => "{$done} compan" . ( $done === 1 ? 'y' : 'ies' ) . ' updated' . ( $skipped ? ", {$skipped} skipped." : '.' ),
		] );
	}

	// ── Public profile ────────────────────────────────────────────────────────────

	public function public_profile( \WP_REST_Request $r ) {
		global $wpdb;
		$id        = absint($r->get_param('id'));
		$candidate = JP_DB::instance()->get_candidate($id);
		if (!$candidate) return $this->not_found('Profile not found.');
		if ($candidate->visibility === 'private') return $this->forbidden();
		if ($candidate->visibility === 'recruiters' && !in_array(jp_current_role(),['jp_recruiter','jp_team_manager','jp_admin_manager','administrator'],true)) {
			return $this->forbidden();
		}
		$user = get_userdata($candidate->user_id);
		// Sections
		$sections_rows = $wpdb->get_results($wpdb->prepare(
			"SELECT section,content FROM {$wpdb->prefix}jp_resume_sections WHERE user_id=%d ORDER BY sort_order ASC",$candidate->user_id
		));
		$sections = [];
		foreach ($sections_rows as $s) $sections[$s->section] = json_decode($s->content??'[]',true)?:[];
		// Badges
		$badges = $wpdb->get_results($wpdb->prepare(
			"SELECT badge FROM {$wpdb->prefix}jp_user_badges WHERE user_id=%d",$candidate->user_id
		));
		// Assessments
		$assessments = $wpdb->get_results($wpdb->prepare(
			"SELECT s.name AS skill_name,a.badge_level,a.score FROM {$wpdb->prefix}jp_assessments a
			 LEFT JOIN {$wpdb->prefix}jp_skills s ON s.id=a.skill_id
			 WHERE a.user_id=%d AND a.badge_level!='none'",$candidate->user_id
		));
		// Phase 2 redesign pass — found while wiring PublicProfilePage's new
		// sidebar: $candidate here was the RAW jp_candidates row, returned
		// unfiltered to any caller of this public endpoint regardless of
		// login state. No UI ever rendered candidate.phone, but that only
		// hid it from the app's own screens — the JSON response itself
		// still leaked it to anyone calling GET /profiles/{id} directly.
		// Strip fields that were never meant to leave the private
		// dashboard/recruiter-only surfaces before this response goes out.
		$public_candidate = clone $candidate;
		unset( $public_candidate->phone );
		return $this->ok([
			'id'          => $candidate->user_id,
			'name'        => $user ? $user->display_name : '',
			'candidate'   => $public_candidate,
			'sections'    => $sections,
			'badges'      => array_column($badges??[],'badge'),
			'assessments' => $assessments??[],
		]);
	}

	// ── Events ───────────────────────────────────────────────────────────────

	/**
	 * Phase 3 redesign (Tier A, redesign-plan §EventsPage) — the `starts_at
	 * >= NOW()` condition was previously unconditional, so a completed
	 * webinar/hiring event became permanently unreachable through this
	 * endpoint the moment it started — no way to browse anything that
	 * already happened (a recording link, a past hiring event for
	 * reference). Added a real `when` param (upcoming/past) rather than a
	 * fabricated "archive" concept — both branches use the same real
	 * status/starts_at columns, just a different comparison and sort
	 * direction. Also added a title search (`q`), the one filter every
	 * other list page in this app already has and this one didn't.
	 */
	public function get_events( \WP_REST_Request $r ) {
		global $wpdb;
		$type   = sanitize_key( $r->get_param( 'type' ) ?? '' );
		$format = sanitize_key( $r->get_param( 'format' ) ?? '' );
		$q      = sanitize_text_field( $r->get_param( 'q' ) ?? '' );
		$when   = sanitize_key( $r->get_param( 'when' ) ?? 'upcoming' );
		$mine   = (bool) $r->get_param( 'mine' );
		$page   = max( 1, absint( $r->get_param( 'page' ) ?? 1 ) );
		$per    = 20; $off = ( $page - 1 ) * $per;

		// Root-cause fix (batch 31): the public listing has always hardcoded
		// status='published' AND starts_at >= NOW(), which is correct for
		// public browsing but meant a recruiter's own draft/completed/past
		// events were completely unreachable after creation — no endpoint
		// ever returned them, so "Save as draft" was effectively "delete."
		// mine=1 (recruiter-only; requires a company, same as create_event())
		// scopes to the recruiter's own host_company with no status/time
		// filter at all, so every event they've ever created shows up.
		if ( $mine ) {
			$company = JP_DB::instance()->get_company_by_user( get_current_user_id() );
			if ( ! $company ) return $this->ok( [ 'events' => [], 'total' => 0 ] );
			$conditions = [ $wpdb->prepare( 'host_company=%d', $company->id ) ];
			$order_by   = 'e.created_at DESC';
		} elseif ( 'past' === $when ) {
			$conditions = [ "status IN ('published','completed')", "starts_at < NOW()" ];
			$order_by   = 'e.starts_at DESC';
		} else {
			$conditions = [ "status='published'", "starts_at >= NOW()" ];
			$order_by   = 'e.starts_at ASC';
		}
		if ( $type )   $conditions[] = $wpdb->prepare( "event_type=%s", $type );
		if ( $format ) $conditions[] = $wpdb->prepare( "format=%s", $format );
		if ( $q )      $conditions[] = $wpdb->prepare( "title LIKE %s", '%' . $wpdb->esc_like( $q ) . '%' );
		$where = 'WHERE ' . implode( ' AND ', $conditions );

		$rows = $wpdb->get_results(
			"SELECT e.*,c.name AS company_name,c.logo_url,
				(SELECT COUNT(*) FROM {$wpdb->prefix}jp_event_registrations r WHERE r.event_id=e.id AND r.status='registered') AS attendee_count
			 FROM {$wpdb->prefix}jp_events e
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=e.host_company
			 {$where} ORDER BY {$order_by} LIMIT {$per} OFFSET {$off}"
		);
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_events e {$where}" );
		return $this->ok( [ 'events' => $rows ?: [], 'total' => $total ] );
	}

	public function get_event( \WP_REST_Request $r ) {
		global $wpdb;
		$id  = absint( $r->get_param( 'id' ) );
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT e.*,c.name AS company_name,c.logo_url
			 FROM {$wpdb->prefix}jp_events e
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=e.host_company
			 WHERE e.id=%d", $id
		) );
		if ( ! $row ) return $this->not_found( 'Event not found.' );
		// Is current user registered? Root-cause fix (batch 15): this used to
		// match ANY row regardless of status, so a user who had cancelled
		// their registration still showed as registered — status='registered'
		// scopes it to an active registration, matching register_event()'s
		// own re-registration logic below.
		$uid = get_current_user_id();
		$row->is_registered = $uid ? (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}jp_event_registrations WHERE event_id=%d AND user_id=%d AND status='registered'", $id, $uid
		) ) : false;
		return $this->ok( $row );
	}

	public function create_event( \WP_REST_Request $r ) {
		global $wpdb;
		$company = JP_DB::instance()->get_company_by_user( get_current_user_id() );
		$allowed = [ 'title','description','event_type','format','starts_at','ends_at',
			'venue','meeting_url','seats_total','is_free','price','status','banner_url' ];
		$data = [];
		foreach ( $allowed as $k ) {
			$v = $r->get_param( $k );
			if ( $v !== null ) $data[$k] = is_numeric( $v ) ? (int)$v : sanitize_text_field( $v );
		}
		if ( empty( $data['title'] ) ) return $this->error( 'title is required.' );
		$data['host_company'] = $company ? $company->id : 0;
		$data['slug']         = sanitize_title( $data['title'] ) . '-' . time();
		$data['created_at']   = current_time( 'mysql' );
		$result = $wpdb->insert( $wpdb->prefix . 'jp_events', $data );
		if ( $result === false ) return $this->error( 'Failed to create event. Please try again.' );
		return $this->ok( [ 'id' => $wpdb->insert_id, 'message' => 'Event created.' ], 201 );
	}

	public function update_event( \WP_REST_Request $r ) {
		global $wpdb;
		$id = absint( $r->get_param( 'id' ) );
		$allowed = [ 'title','description','status','starts_at','ends_at','meeting_url','seats_total' ];
		$data = [];
		foreach ( $allowed as $k ) {
			$v = $r->get_param( $k );
			if ( $v !== null ) $data[$k] = is_numeric( $v ) ? (int)$v : sanitize_text_field( $v );
		}
		if ( empty( $data ) ) return $this->error( 'No fields to update.' );
		// Root-cause fix (ghost-success pattern — same class already
		// remediated across ~34 other call sites in this codebase's history):
		// $wpdb->update()'s return value was discarded, so a failed write
		// (bad column, DB error, or simply zero matching rows because $id
		// didn't exist) still returned "Event updated." to the caller.
		$updated = $wpdb->update( $wpdb->prefix . 'jp_events', $data, [ 'id' => $id ] );
		if ( false === $updated ) {
			return $this->error( 'Failed to update event. Please try again.' );
		}
		return $this->ok( [ 'message' => 'Event updated.' ] );
	}

	public function register_event( \WP_REST_Request $r ) {
		global $wpdb;
		$event_id = absint( $r->get_param( 'id' ) );
		$uid      = get_current_user_id();
		$event    = $wpdb->get_row( $wpdb->prepare(
			"SELECT seats_total,seats_taken,status FROM {$wpdb->prefix}jp_events WHERE id=%d", $event_id
		) );
		if ( ! $event )                    return $this->not_found( 'Event not found.' );
		if ( $event->status !== 'published') return $this->error( 'Event is not open for registration.' );
		if ( $event->seats_total > 0 && $event->seats_taken >= $event->seats_total ) {
			return $this->error( 'Event is full. No seats remaining.' );
		}
		// Root-cause fix (batch 15): the UNIQUE KEY on (event_id,user_id) means
		// a user who previously registered and then cancelled has a real row
		// here already with status='cancelled' — the old code checked for ANY
		// existing row and blocked re-registration forever, and a plain
		// INSERT would fail on the unique key regardless. Re-activate that
		// row via UPDATE instead of inserting a duplicate.
		$existing = $wpdb->get_row( $wpdb->prepare(
			"SELECT id,status FROM {$wpdb->prefix}jp_event_registrations WHERE event_id=%d AND user_id=%d", $event_id, $uid
		) );
		if ( $existing && $existing->status === 'registered' ) {
			return $this->error( 'You are already registered for this event.' );
		}
		if ( $existing ) {
			$updated = $wpdb->update(
				$wpdb->prefix . 'jp_event_registrations',
				[ 'status' => 'registered', 'joined_at' => current_time( 'mysql' ) ],
				[ 'id' => $existing->id ],
				[ '%s', '%s' ], [ '%d' ]
			);
			if ( false === $updated ) return $this->error( 'Registration failed. Please try again.' );
		} else {
			$result = $wpdb->insert( $wpdb->prefix . 'jp_event_registrations', [
				'event_id' => $event_id, 'user_id' => $uid,
				'status'   => 'registered', 'joined_at' => current_time( 'mysql' ),
			], [ '%d','%d','%s','%s' ] );
			if ( $result === false ) return $this->error( 'Registration failed. You may already be registered.' );
		}
		// Only increment seats_taken AFTER confirmed successful write
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}jp_events SET seats_taken=seats_taken+1 WHERE id=%d", $event_id
		) );
		return $this->ok( [ 'message' => 'Successfully registered for the event!' ] );
	}

	/**
	 * New (batch 15) — jp_event_registrations.status has carried a
	 * 'cancelled' enum value since the table was created, but nothing ever
	 * wrote it: once registered, a user had no way to cancel short of an
	 * admin touching the database directly. Own-registration only (scoped
	 * to get_current_user_id(), not an arbitrary id) — no admin override
	 * needed here since it's the user's own seat.
	 */
	public function cancel_event_registration( \WP_REST_Request $r ) {
		global $wpdb;
		$event_id = absint( $r->get_param( 'id' ) );
		$uid      = get_current_user_id();
		$existing = $wpdb->get_row( $wpdb->prepare(
			"SELECT id,status FROM {$wpdb->prefix}jp_event_registrations WHERE event_id=%d AND user_id=%d", $event_id, $uid
		) );
		if ( ! $existing || $existing->status !== 'registered' ) {
			return $this->error( 'You are not registered for this event.' );
		}
		$updated = $wpdb->update(
			$wpdb->prefix . 'jp_event_registrations',
			[ 'status' => 'cancelled' ],
			[ 'id' => $existing->id ],
			[ '%s' ], [ '%d' ]
		);
		if ( false === $updated ) return $this->error( 'Could not cancel your registration. Please try again.' );
		$wpdb->query( $wpdb->prepare(
			"UPDATE {$wpdb->prefix}jp_events SET seats_taken = GREATEST(0, seats_taken-1) WHERE id=%d", $event_id
		) );
		return $this->ok( [ 'message' => 'Registration cancelled.' ] );
	}

	// ── Recruiter analytics ───────────────────────────────────────────────────

	/**
	 * Root-cause fix (gap analysis P1 #185, #208, continued from
	 * admin_stats()'s fix above): this method runs 9 separate queries
	 * (5 scalar aggregates, a stage-funnel GROUP BY, a top-jobs query, and
	 * a full stage_history walk over every one of a recruiter's
	 * applications) with zero caching, on every single dashboard load —
	 * the same uncached-aggregate-dashboard pattern as admin_stats(), just
	 * per-recruiter instead of platform-wide. Unlike admin_stats() (one
	 * global cache key), this one is parameterized by both the requesting
	 * recruiter's user id and the `days` window, so the cache key must
	 * incorporate both — caching on a bare 'recruiter_analytics' key would
	 * silently serve one recruiter's numbers to another, or a 30-day
	 * window's numbers to a 90-day request.
	 */
	public function get_recruiter_analytics( \WP_REST_Request $r ) {
		$uid  = get_current_user_id();
		$days = min( 90, max( 1, absint( $r->get_param( 'days' ) ?? 30 ) ) );
		return $this->ok( JP_Cache::remember(
			"recruiter_analytics_{$uid}_{$days}",
			fn() => $this->compute_recruiter_analytics( $uid, $days ),
			60,
			'recruiter_analytics'
		) );
	}

	private function compute_recruiter_analytics( int $uid, int $days ): array {
		global $wpdb;
		$since = date( 'Y-m-d', strtotime( "-{$days} days" ) );

		// Jobs stats
		$active_jobs   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_jobs WHERE posted_by=%d AND status='active'", $uid ) );
		$total_apps    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications a JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id WHERE j.posted_by=%d", $uid ) );
		$new_apps      = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications a JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id WHERE j.posted_by=%d AND a.created_at>=%s", $uid, $since ) );
		$hired         = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications a JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id WHERE j.posted_by=%d AND a.stage='hired'", $uid ) );
		$total_views   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT SUM(views_count) FROM {$wpdb->prefix}jp_jobs WHERE posted_by=%d", $uid ) );
		$avg_match     = $wpdb->get_var( $wpdb->prepare( "SELECT AVG(a.match_score) FROM {$wpdb->prefix}jp_applications a JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id WHERE j.posted_by=%d AND a.match_score>0", $uid ) );

		// Stage funnel
		$funnel = $wpdb->get_results( $wpdb->prepare(
			"SELECT a.stage, COUNT(*) AS cnt FROM {$wpdb->prefix}jp_applications a
			 JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id WHERE j.posted_by=%d
			 GROUP BY a.stage ORDER BY FIELD(a.stage,'applied','shortlisted','phone_screen','interview','assessment','offer','hired','rejected')",
			$uid
		) );

		// Top performing jobs
		$top_jobs = $wpdb->get_results( $wpdb->prepare(
			"SELECT j.title, j.views_count, COUNT(a.id) AS app_count
			 FROM {$wpdb->prefix}jp_jobs j
			 LEFT JOIN {$wpdb->prefix}jp_applications a ON a.job_id=j.id
			 WHERE j.posted_by=%d GROUP BY j.id ORDER BY app_count DESC LIMIT 5",
			$uid
		) );

		// Root-cause fix (gap analysis P1 #178: "Recruiter/company analytics
		// stops at views, applies, and apply-rate ... despite
		// jp_applications.stage_history already capturing full timestamped
		// stage transitions, nothing aggregates this into time-to-hire,
		// funnel-conversion-by-stage, or offer-acceptance-rate metrics ...
		// genuinely valuable data being captured and then never used").
		// NOTE: `funnel` above answers a different, narrower question —
		// "what does my pipeline look like RIGHT NOW" (a GROUP BY on each
		// application's CURRENT stage). It deliberately undercounts earlier
		// stages: an application currently 'hired' contributes 0 to the
		// 'interview' bucket even though it passed through interview, which
		// makes it unusable for computing real stage-to-stage conversion or
		// time-to-hire. Those need the CUMULATIVE "did this application
		// ever reach this stage, and when" answer, which only
		// stage_history's timestamped entries actually contain — so this
		// walks it directly instead of trying to approximate from the
		// current-stage snapshot. Kept as new, additive response fields
		// (funnel_reach / avg_time_to_hire_days / offer_acceptance_rate_pct)
		// rather than replacing `funnel`, since existing consumers of that
		// field's specific (narrower) meaning shouldn't have it silently
		// redefined out from under them.
		$history_rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT a.stage_history FROM {$wpdb->prefix}jp_applications a JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id WHERE j.posted_by=%d",
			$uid
		) );
		// Root-cause fix (batch 3 consolidation): this used to contain its
		// own inline copy of the stage-history-walking algorithm (including
		// the documented fix for the "conversion relative to the
		// immediately-preceding stage divides by zero when a stage is
		// skipped" bug). That algorithm has been extracted verbatim into
		// JP_Analytics::compute_funnel_metrics() so the platform-wide
		// analytics view (JP_Analytics::platform_funnel_and_sources()) and
		// this per-recruiter view share exactly one implementation instead
		// of two copies that could silently drift apart. See
		// class-jp-analytics.php for the algorithm itself and the original
		// skip-pattern regression test that motivated the "relative to
		// applied, not the previous stage" conversion choice.
		$funnel_metrics = JP_Analytics::instance()->compute_funnel_metrics( $history_rows );

		return [
			'active_jobs'                => $active_jobs,
			'total_apps'                 => $total_apps,
			'new_apps'                   => $new_apps,
			'hired'                      => $hired,
			'total_views'                => $total_views,
			'avg_match'                  => round( (float) $avg_match, 1 ),
			'funnel'                     => $funnel,
			'funnel_reach'               => $funnel_metrics['funnel_reach'],
			'avg_time_to_hire_days'      => $funnel_metrics['avg_time_to_hire_days'],
			'offer_acceptance_rate_pct'  => $funnel_metrics['offer_acceptance_rate_pct'],
			'top_jobs'                   => $top_jobs,
			'days'                       => $days,
		];
	}

	// ── Team management (batch 6) ───────────────────────────────────────────
	// Thin REST wrappers over JP_Team's do_*() methods — see
	// class-jp-team.php's class docblock and register_routes()'s /team/*
	// block above for the full root-cause trace.

	public function team_list( \WP_REST_Request $r ) {
		$result = JP_Team::instance()->do_list( get_current_user_id(), absint( $r->get_param( 'company_id' ) ?? 0 ) );
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message(), 403 );
		return $this->ok( $result );
	}

	public function team_invite( \WP_REST_Request $r ) {
		$result = JP_Team::instance()->do_invite(
			get_current_user_id(),
			(string) ( $r->get_param( 'email' ) ?? '' ),
			(string) ( $r->get_param( 'role' ) ?? '' ),
			absint( $r->get_param( 'company_id' ) ?? 0 )
		);
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message() );
		return $this->ok( $result );
	}

	public function team_accept( \WP_REST_Request $r ) {
		$result = JP_Team::instance()->do_accept_invite( wp_get_current_user(), (string) ( $r->get_param( 'token' ) ?? '' ) );
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message() );
		return $this->ok( $result );
	}

	public function team_remove( \WP_REST_Request $r ) {
		$result = JP_Team::instance()->do_remove( get_current_user_id(), absint( $r->get_param( 'id' ) ) );
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message(), 403 );
		return $this->ok( $result );
	}

	public function team_reassign_job( \WP_REST_Request $r ) {
		$result = JP_Team::instance()->do_reassign_job(
			get_current_user_id(),
			absint( $r->get_param( 'job_id' ) ?? 0 ),
			absint( $r->get_param( 'user_id' ) ?? 0 )
		);
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message(), 403 );
		return $this->ok( $result );
	}

	// ── Payments / checkout handlers (batch 10) ─────────────────────────────

	public function payments_create_order( \WP_REST_Request $r ) {
		$result = JP_Payments::instance()->do_create_order(
			get_current_user_id(),
			absint( $r->get_param( 'plan_id' ) ?? 0 ),
			(string) ( $r->get_param( 'billing' ) ?? 'monthly' )
		);
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message() );
		return $this->ok( $result );
	}

	public function payments_verify( \WP_REST_Request $r ) {
		$result = JP_Payments::instance()->do_verify_payment(
			get_current_user_id(),
			(string) ( $r->get_param( 'razorpay_order_id' ) ?? '' ),
			(string) ( $r->get_param( 'razorpay_payment_id' ) ?? '' ),
			(string) ( $r->get_param( 'razorpay_signature' ) ?? '' )
		);
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message() );
		return $this->ok( $result );
	}

	public function payments_verify_stripe_session( \WP_REST_Request $r ) {
		$result = JP_Payments::instance()->do_verify_stripe_session(
			get_current_user_id(),
			(string) ( $r->get_param( 'session_id' ) ?? '' )
		);
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message() );
		return $this->ok( $result );
	}

	// ── Admin extended handlers ───────────────────────────────────────────────

	public function admin_reviews( \WP_REST_Request $r ) {
		global $wpdb;
		$status = sanitize_key( $r->get_param('status') ?? 'pending' );
		$page   = max(1, absint($r->get_param('page') ?? 1));
		$per    = 20; $off = ($page-1)*$per;
		$where  = $status ? $wpdb->prepare("WHERE v.status=%s", $status) : '';
		$rows   = $wpdb->get_results(
			"SELECT v.*,c.name AS company_name,u.display_name AS reviewer_name
			 FROM {$wpdb->prefix}jp_reviews v
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=v.company_id
			 LEFT JOIN {$wpdb->users} u ON u.ID=v.user_id
			 {$where} ORDER BY v.created_at DESC LIMIT {$per} OFFSET {$off}"
		);
		$total = (int)$wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}jp_reviews v {$where}");
		return $this->ok(['reviews'=>$rows??[],'total'=>$total]);
	}

	public function admin_review_action( \WP_REST_Request $r ) {
		global $wpdb;
		$id     = absint($r->get_param('id'));
		$action = sanitize_key($r->get_param('action') ?? '');
		if (!in_array($action,['approve','reject'],true)) return $this->error('action must be approve or reject.');
		$this->apply_review_action( $wpdb, $id, $action );
		$status = $action === 'approve' ? 'approved' : 'rejected';
		return $this->ok(['message'=>"Review {$status}."]);
	}

	/**
	 * Shared by admin_review_action() (single) and bulk_review_action()
	 * (below) so the approve/reject transition and company-rating recalc
	 * are defined in exactly one place — extracted rather than duplicated
	 * when bulk support was added (enterprise gap-analysis: "bulk actions
	 * inconsistent across admin lists — absent for Reviews").
	 */
	private function apply_review_action( \wpdb $wpdb, int $id, string $action ): bool {
		$status = $action === 'approve' ? 'approved' : 'rejected';
		$ok = $wpdb->update( $wpdb->prefix . 'jp_reviews', [ 'status' => $status ], [ 'id' => $id ] ) !== false;
		if ( $ok && $status === 'approved' ) {
			$rev = $wpdb->get_row( $wpdb->prepare( "SELECT company_id FROM {$wpdb->prefix}jp_reviews WHERE id=%d", $id ) );
			if ( $rev ) {
				$avg = $wpdb->get_var( $wpdb->prepare(
					"SELECT AVG(rating_overall) FROM {$wpdb->prefix}jp_reviews WHERE company_id=%d AND status='approved'",
					$rev->company_id
				) );
				$wpdb->update( $wpdb->prefix . 'jp_companies', [ 'rating_avg' => round( (float) $avg, 1 ) ], [ 'id' => $rev->company_id ] );
			}
		}
		if ( $ok ) JP_Security::instance()->audit( 'review_' . $status, 'review', $id );
		return $ok;
	}

	public function bulk_review_action( \WP_REST_Request $r ) {
		global $wpdb;
		$ids    = array_map( 'absint', (array) $r->get_param( 'ids' ) );
		$action = sanitize_key( $r->get_param( 'action' ) ?? '' );
		if ( ! $ids || ! in_array( $action, [ 'approve', 'reject' ], true ) ) {
			return $this->error( 'ids and a valid action (approve, reject) are required.' );
		}
		// Input-validation fix, same as the other bulk_*_action() endpoints.
		if ( count( $ids ) > 200 ) {
			return $this->error( 'Bulk actions are limited to 200 items at a time. Please select fewer and try again.' );
		}

		$done = 0; $skipped = 0;
		foreach ( $ids as $id ) {
			if ( $this->apply_review_action( $wpdb, $id, $action ) ) $done++; else $skipped++;
		}

		$status = $action === 'approve' ? 'approved' : 'rejected';
		return $this->ok( [
			'done'    => $done,
			'skipped' => $skipped,
			'message' => "{$done} review(s) {$status}" . ( $skipped ? ", {$skipped} skipped." : '.' ),
		] );
	}

	public function admin_subscriptions( \WP_REST_Request $r ) {
		global $wpdb;
		$page   = max(1,absint($r->get_param('page')??1));
		$per    = 20; $off = ($page-1)*$per;
		// Phase 3 redesign pass — the audit flagged this list as needing
		// filters and MRR-per-row context. Status filter is a real WHERE
		// clause against the indexed `status` column (KEY status already
		// exists on jp_subscriptions — see class-jp-activator.php); the
		// row-level MRR contribution is computed server-side from the
		// joined plan's real price_monthly/price_yearly (yearly divided by
		// 12 for a monthly-equivalent figure), not invented client-side.
		$status = sanitize_key( $r->get_param('status') ?? '' );
		$allowed_statuses = [ 'trial', 'active', 'past_due', 'cancelled', 'expired' ];
		$where = '';
		if ( $status && in_array( $status, $allowed_statuses, true ) ) {
			$where = $wpdb->prepare( 'WHERE s.status=%s', $status );
		}
		$rows = $wpdb->get_results(
			"SELECT s.*,u.display_name,u.user_email,p.name AS plan_name,
				p.price_monthly,p.price_yearly,p.currency,
				(CASE WHEN s.billing_cycle='yearly' THEN ROUND(p.price_yearly/12) ELSE p.price_monthly END) AS mrr_contribution
			 FROM {$wpdb->prefix}jp_subscriptions s
			 LEFT JOIN {$wpdb->users} u ON u.ID=s.user_id
			 LEFT JOIN {$wpdb->prefix}jp_plans p ON p.id=s.plan_id
			 {$where}
			 ORDER BY s.created_at DESC LIMIT {$per} OFFSET {$off}"
		);
		$total = (int)$wpdb->get_var( $where
			? $wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}jp_subscriptions s WHERE s.status=%s", $status)
			: "SELECT COUNT(*) FROM {$wpdb->prefix}jp_subscriptions"
		);
		return $this->ok(['subscriptions'=>$rows??[],'total'=>$total]);
	}

	/**
	 * TRACE: POST /admin/subscriptions/{id}/cancel, jp_manage_plans cap →
	 * force-cancels a subscription (status='cancelled', cancelled_at=now)
	 * → audit-logged → returns ok() with the fresh status so the SPA can
	 * update the row in place without a full refetch.
	 * Preconditions: subscription exists and isn't already cancelled/expired.
	 * Postconditions: jp_subscriptions row's status/cancelled_at updated in
	 * the DB (verified via the $updated return-value check, matching this
	 * file's established ghost-success fix pattern); a failed write returns
	 * a real error rather than a false "cancelled" message.
	 * Edge cases handled: already-terminal status (409, no-op write avoided),
	 * unknown id (0 rows affected still checked via false !== $updated), and
	 * the write result itself never assumed to have succeeded.
	 */
	public function admin_cancel_subscription( \WP_REST_Request $r ) {
		global $wpdb;
		$id  = absint( $r->get_param('id') );
		$sub = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_subscriptions WHERE id=%d", $id ) );
		if ( ! $sub ) return $this->not_found( 'Subscription not found.' );
		if ( in_array( $sub->status, [ 'cancelled', 'expired' ], true ) ) {
			return $this->error( 'This subscription is already ' . $sub->status . '.', 409 );
		}
		$updated = $wpdb->update(
			$wpdb->prefix . 'jp_subscriptions',
			[ 'status' => 'cancelled', 'cancelled_at' => current_time('mysql') ],
			[ 'id' => $id ]
		);
		if ( false === $updated ) {
			return $this->error( 'Failed to cancel the subscription. Please try again.' );
		}
		JP_Security::instance()->audit( 'subscription_cancelled_by_admin', 'subscription', $id );
		return $this->ok( [ 'message' => 'Subscription cancelled.', 'status' => 'cancelled' ] );
	}

	public function admin_get_skills( \WP_REST_Request $r ) {
		global $wpdb;
		$q = sanitize_text_field($r->get_param('q')??'');
		$where = $q ? $wpdb->prepare("WHERE name LIKE %s",'%'.$wpdb->esc_like($q).'%') : '';
		$rows = $wpdb->get_results(
			"SELECT id,name,category,jobs_count FROM {$wpdb->prefix}jp_skills {$where} ORDER BY jobs_count DESC LIMIT 100"
		);
		return $this->ok($rows??[]);
	}

	public function admin_add_skill( \WP_REST_Request $r ) {
		// Newly-discovered bug (found while working the skills-fragmentation
		// item, gap analysis P1 #145): this previously supplied a
		// 'created_at' field that does not exist on jp_skills (the table has
		// no such column at all — see class-jp-activator.php) AND never
		// supplied 'slug', which the table declares NOT NULL with a UNIQUE
		// constraint and no default. $wpdb->insert() builds its INSERT
		// directly from the given keys, so on any strict-mode MySQL/MariaDB
		// (the modern default) this failed outright on every single call —
		// "Add Skill" in the admin taxonomy screen has never actually
		// worked. On a non-strict server it would instead have inserted an
		// empty-string slug, which the SECOND ever skill added would then
		// collide with on the UNIQUE KEY and fail anyway. Fixed to generate
		// the required slug and drop the nonexistent column; also switched
		// the duplicate-check to compare by slug (case/whitespace-normalized)
		// rather than an exact byte-for-byte 'name' match, so "React" and
		// "react " are correctly treated as the same skill.
		global $wpdb;
		$name     = sanitize_text_field($r->get_param('name')??'');
		$category = sanitize_text_field($r->get_param('category')??'');
		if (!$name) return $this->error('name is required.');
		$slug   = sanitize_title($name);
		$exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}jp_skills WHERE slug=%s",$slug));
		if ($exists) return $this->error('Skill already exists.');
		$result = $wpdb->insert($wpdb->prefix.'jp_skills',['name'=>$name,'slug'=>$slug,'category'=>$category,'jobs_count'=>0],['%s','%s','%s','%d']);
		if (false === $result) return $this->error('Failed to add skill. Please try again.');
		return $this->ok(['id'=>$wpdb->insert_id,'message'=>'Skill added.'],201);
	}

	/**
	 * Root cause (gap analysis "skill-taxonomy governance", §36): this
	 * deleted a jp_skills row with zero check for the 3 tables that carry
	 * a `skill_id` foreign-key-shaped column with no actual FK constraint
	 * defined (jp_user_skills — candidate skill profiles, jp_assessments —
	 * a candidate's completed assessment history, jp_assessment_questions —
	 * the question bank an admin authored for that skill). Deleting a
	 * skill silently orphaned every row in all three: a candidate's skill
	 * profile would lose that entry from any INNER JOIN-based query (e.g.
	 * JP_Matching's scoring) with no error and no trace of what happened,
	 * a candidate's past assessment score for that skill would become
	 * permanently unassociated with any real skill, and any assessment
	 * questions authored for that skill would become permanently
	 * unreachable dead data. This mirrors the same class of bug fixed for
	 * company offboarding erasure in class-jp-privacy.php, but for a much
	 * more casually-clicked admin action (a taxonomy cleanup button, not a
	 * deliberate "erase this company" flow) — so the safer default here is
	 * to BLOCK deletion when the skill is in use and tell the admin
	 * exactly how many rows reference it, rather than cascade-delete by
	 * default. Passing `force=1` opts into the same cascading behavior
	 * class-jp-privacy.php already uses elsewhere, for the rare case an
	 * admin genuinely wants to remove a skill and everything tied to it
	 * (e.g. a skill that was added as a duplicate/typo).
	 */
	public function admin_delete_skill( \WP_REST_Request $r ) {
		global $wpdb;
		$id    = absint($r->get_param('id'));
		$force = (bool) $r->get_param('force');
		if ( ! $id ) return $this->error( 'id is required.' );

		$usage = [
			'candidate_profiles'   => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_user_skills WHERE skill_id=%d", $id ) ),
			'completed_assessments'=> (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_assessments WHERE skill_id=%d", $id ) ),
			'assessment_questions' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_assessment_questions WHERE skill_id=%d", $id ) ),
		];
		$total_usage = array_sum( $usage );

		if ( $total_usage > 0 && ! $force ) {
			return $this->error(
				sprintf(
					'This skill is in use and cannot be deleted: %d candidate profile(s), %d completed assessment(s), %d assessment question(s) reference it. Pass force=1 to delete the skill AND all of these records permanently.',
					$usage['candidate_profiles'], $usage['completed_assessments'], $usage['assessment_questions']
				),
				409
			);
		}

		if ( $total_usage > 0 && $force ) {
			// Cascade in dependency order, mirroring class-jp-privacy.php's
			// company-offboarding erase pattern.
			$wpdb->delete( $wpdb->prefix . 'jp_user_skills', [ 'skill_id' => $id ] );
			$wpdb->delete( $wpdb->prefix . 'jp_assessments', [ 'skill_id' => $id ] );
			$wpdb->delete( $wpdb->prefix . 'jp_assessment_questions', [ 'skill_id' => $id ] );
			if ( class_exists( 'JP_Security' ) ) {
				JP_Security::instance()->audit( 'skill_force_deleted', 'skill', $id, "Force-deleted skill #{$id} and {$total_usage} dependent row(s) (profiles: {$usage['candidate_profiles']}, assessments: {$usage['completed_assessments']}, questions: {$usage['assessment_questions']})." );
			}
		}

		$result = $wpdb->delete($wpdb->prefix.'jp_skills',['id'=>$id]);
		if ( false === $result ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_skills delete failed: ' . $wpdb->last_error ), 'JP_Api::admin_delete_skill id=' . $id );
			}
			return $this->error( 'Could not delete this skill. Please try again.' );
		}
		return $this->ok(['message'=>'Skill deleted.']);
	}

	/**
	 * Root cause (skill-taxonomy governance, follow-on to §36): before
	 * this, an admin who spotted a duplicate skill (e.g. a candidate typed
	 * "ReactJS" via the new self-service skills field from §37, which now
	 * exists as a separate row from the canonical "React") had exactly one
	 * option — force-delete it via admin_delete_skill(), which destroys
	 * every candidate profile link, assessment history row, and assessment
	 * question tied to it. There was no way to fold a duplicate into its
	 * canonical skill without losing the data attached to it. That's a
	 * real problem now that jp_user_skills is an actual write target
	 * (§37) instead of dead weight — duplicate skill rows directly
	 * fragment matching/search results (a candidate with "ReactJS" would
	 * never match a job requiring "React", and vice versa) and every
	 * candidate self-typing a skill name (§37's free-text profile field)
	 * makes near-duplicates more likely over time, not less.
	 *
	 * Reassigns every dependent row from the source skill to the target
	 * skill, then deletes the (now-empty) source row — same three tables
	 * admin_delete_skill() already audits, reassigned in dependency order:
	 *
	 * - jp_user_skills: UNIQUE KEY(user_id, skill_id) means a straight
	 *   UPDATE ... SET skill_id=target WHERE skill_id=source would throw a
	 *   duplicate-key error for any candidate who happens to already have
	 *   BOTH the source and target skill linked. Those rows are deleted
	 *   instead (the candidate already has the canonical skill — nothing
	 *   is lost); every other source row is reassigned normally.
	 * - jp_assessments / jp_assessment_questions: no uniqueness constraint
	 *   on skill_id, so a plain reassignment is safe — a candidate's past
	 *   assessment score and an admin's authored questions both correctly
	 *   move to count against the canonical skill going forward.
	 */
	public function admin_merge_skill( \WP_REST_Request $r ) {
		global $wpdb;
		$source_id = absint( $r->get_param( 'id' ) );
		$target_id = absint( $r->get_param( 'target_id' ) );
		if ( ! $source_id || ! $target_id ) return $this->error( 'target_id is required.' );
		if ( $source_id === $target_id ) return $this->error( 'Cannot merge a skill into itself.' );

		$tbl = $wpdb->prefix . 'jp_skills';
		$source = $wpdb->get_row( $wpdb->prepare( "SELECT id, name FROM {$tbl} WHERE id=%d", $source_id ) );
		$target = $wpdb->get_row( $wpdb->prepare( "SELECT id, name FROM {$tbl} WHERE id=%d", $target_id ) );
		if ( ! $source ) return $this->not_found( 'Source skill not found.' );
		if ( ! $target ) return $this->not_found( 'Target skill not found.' );

		// Candidates who already have both skills linked: dropping the
		// duplicate source row first avoids a UNIQUE KEY(user_id,skill_id)
		// collision when the remaining source rows are reassigned below.
		$user_skills_tbl = $wpdb->prefix . 'jp_user_skills';
		$already_has_both = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$user_skills_tbl} src
			 WHERE src.skill_id=%d
			 AND EXISTS (SELECT 1 FROM {$user_skills_tbl} tgt WHERE tgt.skill_id=%d AND tgt.user_id=src.user_id)",
			$source_id, $target_id
		) );
		if ( $already_has_both > 0 ) {
			$wpdb->query( $wpdb->prepare(
				"DELETE src FROM {$user_skills_tbl} src
				 WHERE src.skill_id=%d
				 AND EXISTS (SELECT 1 FROM (SELECT user_id FROM {$user_skills_tbl} WHERE skill_id=%d) tgt WHERE tgt.user_id=src.user_id)",
				$source_id, $target_id
			) );
		}

		$reassigned_profiles = $wpdb->update( $user_skills_tbl, [ 'skill_id' => $target_id ], [ 'skill_id' => $source_id ] );
		$reassigned_assessments = $wpdb->update( $wpdb->prefix . 'jp_assessments', [ 'skill_id' => $target_id ], [ 'skill_id' => $source_id ] );
		$reassigned_questions   = $wpdb->update( $wpdb->prefix . 'jp_assessment_questions', [ 'skill_id' => $target_id ], [ 'skill_id' => $source_id ] );

		$source_deleted = $wpdb->delete( $tbl, [ 'id' => $source_id ] );
		if ( false === $source_deleted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_skills source delete after merge failed: ' . $wpdb->last_error ), 'JP_Api::admin_merge_skill source_id=' . $source_id . ' target_id=' . $target_id );
			}
		}

		if ( class_exists( 'JP_Security' ) ) {
			JP_Security::instance()->audit(
				'skill_merged', 'skill', $target_id,
				sprintf(
					'Merged skill "%s" (#%d) into "%s" (#%d): %d candidate profile(s), %d assessment(s), %d question(s) reassigned; %d duplicate profile link(s) dropped.',
					$source->name, $source_id, $target->name, $target_id,
					(int) $reassigned_profiles, (int) $reassigned_assessments, (int) $reassigned_questions, $already_has_both
				)
			);
		}

		return $this->ok( [
			'message'                => sprintf( 'Merged "%s" into "%s".', $source->name, $target->name ),
			'reassigned_profiles'    => (int) $reassigned_profiles,
			'reassigned_assessments' => (int) $reassigned_assessments,
			'reassigned_questions'   => (int) $reassigned_questions,
			'dropped_duplicates'     => $already_has_both,
		] );
	}

	public function admin_get_plans( \WP_REST_Request $r ) {
		global $wpdb;
		$plans = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}jp_plans ORDER BY sort_order ASC");
		return $this->ok($plans??[]);
	}

	/**
	 * Batch 30: added 'currency' to the writable field whitelist (backs
	 * multi-currency support — see jp-core.php's version-bump comment for
	 * the full trace) with an explicit allow-list check, since this value
	 * flows directly into a payment-gateway API call (class-jp-payments.php)
	 * and an unvalidated string reaching that is a real correctness/safety
	 * concern, not just a cosmetic one. Also root-caused: both $wpdb writes
	 * below were previously unchecked — a failed plan save (e.g. a
	 * duplicate slug hitting the UNIQUE key) would still report "Plan
	 * saved." while nothing changed, exactly the ghost-success pattern
	 * swept everywhere else in batches 15-18; this instance was missed
	 * because it was added after that sweep. Caught and fixed here while
	 * touching this method for the currency field anyway.
	 */
	public function admin_save_plan( \WP_REST_Request $r ) {
		global $wpdb;
		$id = absint($r->get_param('id')??0);
		$fields = ['name','slug','description','price_monthly','price_yearly','currency',
			'job_posts','featured_jobs','resume_views','candidate_msgs','team_seats','is_active','sort_order'];
		$data = [];
		foreach ($fields as $f) {
			$v = $r->get_param($f);
			if ($v === null) continue;
			if ($f === 'currency') {
				$v = strtoupper(sanitize_text_field($v));
				if (!in_array($v, ['INR','USD'], true)) return $this->error("currency must be one of: INR, USD.");
				$data[$f] = $v;
			} else {
				$data[$f] = is_numeric($v) ? (int)$v : sanitize_text_field($v);
			}
		}
		// Root-cause fix (batch 32): jp_plans.features_json has always been
		// read (PricingPage.tsx's parseFeatures()) and even referenced by the
		// legacy wp-admin settings screen (class-jp-settings.php), but no
		// write path anywhere in the codebase ever set it — every plan's
		// marketing feature-bullet list was permanently empty. Accepts a real
		// JSON array of strings (matching parseFeatures()'s own expected
		// shape exactly) from the new admin UI's textarea.
		$features = $r->get_param( 'features' );
		if ( is_array( $features ) ) {
			$clean = array_values( array_filter( array_map( 'sanitize_text_field', $features ), 'strlen' ) );
			$data['features_json'] = wp_json_encode( $clean );
		}
		if ($id) {
			$ok = false !== $wpdb->update($wpdb->prefix.'jp_plans',$data,['id'=>$id]);
		} else {
			$data['created_at'] = current_time('mysql');
			$ok = false !== $wpdb->insert($wpdb->prefix.'jp_plans',$data);
			$id = $wpdb->insert_id;
		}
		if (!$ok) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_plans write failed: ' . $wpdb->last_error ), 'JP_Api::admin_save_plan id=' . $id );
			}
			return $this->error('Could not save this plan — the slug may already be in use. Please try again.');
		}
		return $this->ok(['id'=>$id,'message'=>'Plan saved.']);
	}

	public function admin_flush_cache( \WP_REST_Request $r ) {
		JP_Cache::flush_all();
		wp_cache_flush();
		return $this->ok(['message'=>'Cache flushed successfully.','flushed_at'=>current_time('mysql')]);
	}

	public function admin_trigger_backup( \WP_REST_Request $r ) {
		// Schedule immediate backup via existing JP_Backup cron
		do_action('jp_manual_backup');
		return $this->ok(['message'=>'Backup triggered. Check your backup directory.','triggered_at'=>current_time('mysql')]);
	}

	/**
	 * Root-cause fix (roadmap re-audit): mirrors class-jp-settings.php's
	 * legacy ajax_gen_vapid() exactly (same JP_PWA::generate_vapid_keys()
	 * call, same two options written) so this is a reachability fix, not a
	 * behavior change — the wp-admin "Generate VAPID Keys" button had no
	 * REST/SPA path to it at all.
	 */
	public function admin_generate_vapid( \WP_REST_Request $r ) {
		if ( ! class_exists( 'JP_PWA' ) ) return new \WP_Error( 'jp_pwa_unavailable', 'PWA module unavailable.', [ 'status' => 500 ] );
		$keys = JP_PWA::generate_vapid_keys();
		update_option( 'jp_vapid_public_key', $keys['public'] );
		update_option( 'jp_vapid_private_key', $keys['private'] );
		return $this->ok( [ 'message' => 'VAPID keys generated.', 'public_key' => $keys['public'] ] );
	}

	public function admin_get_settings( \WP_REST_Request $r ) {
		// Root-cause fix (roadmap re-audit, "systematically verify nothing
		// was forgotten"): this key list previously read jp_smtp_host,
		// jp_smtp_port, jp_smtp_user, jp_from_email, jp_from_name — options
		// that NOTHING in class-jp-smtp.php (the actual mail sender) ever
		// reads. That class's phpmailer_init/wp_mail_from/wp_mail_from_name
		// hooks source SMTP host/port/user/pass exclusively from wp-config.php
		// constants (JP_SMTP_HOST etc — by design, per its own docblock) and
		// only the "From" display name/email from jp_smtp_from_name /
		// jp_smtp_from_email. So the previous fields were a "ghost setting":
		// an admin could fill in SMTP host/port/user here, save successfully,
		// and it would silently configure nothing. Replaced with the two
		// keys that are actually consumed, plus a read-only flag telling the
		// admin whether wp-config.php constants are present (matching the
		// informational banner the old wp-admin page showed).
		//
		// Also closes silent gaps found the same way for SEO (social links),
		// General (auto-approve reviews, default OG image), Payments (GST
		// number, invoice prefix), and the maintenance-mode toggle — all of
		// which existed only on the wp-admin Settings API form with no
		// REST/SPA equivalent.
		// Batch 12 — Stripe gateway. jp_payment_gateway/jp_stripe_publishable_key
		// follow jp_razorpay_key_id's existing convention (plain, not
		// asterisk-masked — a publishable id, not a secret); jp_stripe_secret_key/
		// jp_stripe_webhook_secret follow jp_razorpay_key_secret's (masked below).
		$keys = ['jp_site_name','jp_jobs_per_page','jp_auto_approve_jobs','jp_auto_approve_reviews',
			'jp_og_default_image','jp_maintenance_mode','jp_payment_gateway','jp_razorpay_key_id',
			'jp_stripe_publishable_key','jp_gst_number','jp_invoice_prefix',
			'jp_smtp_from_name','jp_smtp_from_email',
			'jp_ga4_measurement_id','jp_social_twitter','jp_social_linkedin','jp_social_facebook',
			'jp_sms_provider','jp_openai_model',
			'jp_max_login_attempts','jp_lockout_duration','jp_require_2fa_admin',
			// E-signature (JP_ESign — DocuSign). jp_docusign_private_key is
			// masked below like every other secret; the rest are plain
			// config, same convention as jp_razorpay_key_id.
			'jp_esign_provider','jp_docusign_account_id','jp_docusign_integration_key',
			'jp_docusign_user_id','jp_docusign_base_uri',
			// Inbound job-feed import (JP_JobFeed).
			'jp_feed_urls','jp_feed_auto_publish',
			// Ghost-setting fix (write-key/read-key sweep): these four are
			// all read live by real code (class-jp-jobs.php's job-expiry
			// calc, class-jp-resume.php + class-jp-security.php's upload
			// size limit, class-jp-performance.php's CORS allow-origin
			// header, class-jp-activator.php's uninstall data-wipe guard)
			// but had no update_option() call anywhere and no admin UI —
			// only reachable via a raw DB/wp-admin-options edit. jp_job_expiry_days
			// defaults to 30 in code (get_option(...,30)), so no activator
			// seed needed; the other three are already seeded at install.
			'jp_job_expiry_days','jp_resume_max_size_mb','jp_cors_allowed_origin','jp_uninstall_wipe_data'];
		$settings = [];
		foreach ($keys as $k) $settings[$k] = get_option($k,'');
		$settings['jp_smtp_constants_configured'] = defined('JP_SMTP_HOST') && JP_SMTP_HOST && defined('JP_SMTP_USER') && JP_SMTP_USER;
		$settings['jp_esign_configured'] = JP_ESign::instance()->is_configured();
		// Never return secrets in plaintext — mask them
		foreach (['jp_razorpay_key_secret','jp_stripe_secret_key','jp_stripe_webhook_secret','jp_smtp_password','jp_openai_key','jp_sms_key','jp_docusign_private_key','jp_esign_webhook_secret'] as $secret) {
			$val = get_option($secret,'');
			$settings[$secret] = $val ? str_repeat('*',8).substr($val,-4) : '';
		}
		return $this->ok($settings);
	}

	public function admin_save_settings( \WP_REST_Request $r ) {
		$safe_keys = ['jp_site_name','jp_jobs_per_page','jp_auto_approve_jobs','jp_auto_approve_reviews',
			'jp_og_default_image','jp_maintenance_mode','jp_payment_gateway','jp_gst_number','jp_invoice_prefix',
			'jp_smtp_from_name','jp_smtp_from_email',
			'jp_ga4_measurement_id','jp_social_twitter','jp_social_linkedin','jp_social_facebook',
			'jp_sms_provider','jp_openai_model','jp_max_login_attempts','jp_lockout_duration','jp_require_2fa_admin',
			'jp_esign_provider','jp_docusign_account_id','jp_docusign_integration_key','jp_docusign_user_id','jp_docusign_base_uri',
			'jp_feed_urls','jp_feed_auto_publish',
			'jp_job_expiry_days','jp_resume_max_size_mb','jp_cors_allowed_origin','jp_uninstall_wipe_data'];
		$boolean_keys = ['jp_auto_approve_jobs','jp_auto_approve_reviews','jp_maintenance_mode','jp_require_2fa_admin','jp_feed_auto_publish','jp_uninstall_wipe_data'];
		// jp_feed_urls is a newline-separated textarea, not single-line
		// text — sanitize_text_field() would strip the newlines and
		// collapse every configured feed onto one unparseable line.
		$textarea_keys = ['jp_feed_urls'];
		// Secret keys — only update if not all asterisks
		$secret_keys = ['jp_razorpay_key_id','jp_razorpay_key_secret','jp_stripe_publishable_key',
			'jp_stripe_secret_key','jp_stripe_webhook_secret','jp_openai_key','jp_sms_key','jp_smtp_password',
			'jp_docusign_private_key','jp_esign_webhook_secret'];
		$updated = 0;
		foreach ($safe_keys as $k) {
			$v = $r->get_param($k);
			if ($v === null) continue;
			$sanitized = match (true) {
				in_array($k, $boolean_keys, true)  => (bool) rest_sanitize_boolean($v),
				in_array($k, $textarea_keys, true) => sanitize_textarea_field($v),
				default => sanitize_text_field($v),
			};
			update_option($k, $sanitized);
			$updated++;
		}
		foreach ($secret_keys as $k) {
			$v = $r->get_param($k);
			if ($v === null || str_contains($v,'****')) continue;
			// jp_docusign_private_key is a multi-line PEM block —
			// sanitize_text_field() strips newlines, which would silently
			// corrupt the key into something openssl_pkey_get_private()
			// can never parse. wp_kses(...,[]) strips tags/scripts without
			// touching whitespace, the correct sanitizer for a pasted PEM.
			update_option($k, $k === 'jp_docusign_private_key' ? wp_kses($v, []) : sanitize_text_field($v));
			$updated++;
		}
		return $this->ok(['message'=>"{$updated} setting(s) saved.",'updated'=>$updated]);
	}

	// ── Feature flags (admin CRUD + resolved-flags-for-current-user) ─────────
	// See class-jp-featureflags.php's docblock for why these exist as thin
	// REST wrappers over JP_FeatureFlags's own methods rather than a fresh
	// implementation: one copy of the actual list/save/delete logic, shared
	// with the pre-existing (and still-kept-working) wp_ajax_* handlers.

	public function admin_get_flags( \WP_REST_Request $r ) {
		return $this->ok( [ 'flags' => JP_FeatureFlags::instance()->list_flags() ] );
	}

	public function admin_save_flag( \WP_REST_Request $r ) {
		$result = JP_FeatureFlags::instance()->save_flag(
			(string) $r->get_param( 'flag_key' ),
			(bool) $r->get_param( 'is_enabled' ),
			(string) ( $r->get_param( 'plan_tier' ) ?? 'all' ),
			(string) ( $r->get_param( 'description' ) ?? '' )
		);
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message() );
		return $this->ok( [ 'message' => 'Flag saved.' ] );
	}

	public function admin_delete_flag( \WP_REST_Request $r ) {
		$result = JP_FeatureFlags::instance()->delete_flag( (string) $r->get_param( 'key' ) );
		if ( is_wp_error( $result ) ) return $this->error( $result->get_error_message() );
		return $this->ok( [ 'message' => 'Flag deleted.' ] );
	}

	public function get_resolved_flags( \WP_REST_Request $r ) {
		return $this->ok( [ 'flags' => JP_FeatureFlags::instance()->get_resolved_flags_for_user( get_current_user_id() ) ] );
	}

	public function admin_push_broadcast( \WP_REST_Request $r ) {
		$title   = sanitize_text_field($r->get_param('title')??'');
		$body    = sanitize_textarea_field($r->get_param('body')??'');
		$segment = sanitize_key($r->get_param('segment')??'all');
		if (!$title||!$body) return $this->error('title and body are required.');
		// Queue notification to all subscribers (handled by JP_PWA)
		$sent = JP_PWA::instance()->broadcast($title,$body,$segment);
		return $this->ok(['message'=>"Notification sent to {$sent} subscriber(s).",'sent'=>$sent]);
	}

	// ── Recruiter subscription / billing ──────────────────────────────────────

	public function get_recruiter_subscription( \WP_REST_Request $r ) {
		$sub = JP_Subscriptions::instance()->get_active(get_current_user_id());
		if (!$sub) return $this->ok(['status'=>'none','plan'=>null,'credits'=>[]]);
		global $wpdb;
		$plan    = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_plans WHERE id=%d",$sub->plan_id));
		$credits = JP_Subscriptions::instance()->get_credits(get_current_user_id());
		return $this->ok(['status'=>$sub->status,'plan'=>$plan,'subscription'=>$sub,'credits'=>$credits]);
	}

	public function get_recruiter_invoices( \WP_REST_Request $r ) {
		global $wpdb;
		$rows = $wpdb->get_results($wpdb->prepare(
			"SELECT id,amount,currency,status,description,invoice_url,created_at
			 FROM {$wpdb->prefix}jp_payments WHERE user_id=%d ORDER BY created_at DESC LIMIT 20",
			get_current_user_id()
		));
		return $this->ok($rows??[]);
	}

	// ── Recruiter handlers ────────────────────────────────────────────────────

	public function get_recruiter_jobs( \WP_REST_Request $r ) {
		global $wpdb;
		$uid    = get_current_user_id();
		$status = sanitize_key( $r->get_param( 'status' ) ?? '' );
		$page   = max( 1, absint( $r->get_param( 'page' ) ?? 1 ) );
		$per    = 20;
		$off    = ( $page - 1 ) * $per;
		$where  = $wpdb->prepare( "WHERE j.posted_by=%d", $uid );
		if ( $status ) $where .= $wpdb->prepare( " AND j.status=%s", $status );
		$jobs = $wpdb->get_results(
			"SELECT j.*,c.name AS company_name,c.logo_url,
				(SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications a WHERE a.job_id=j.id) AS applications_cnt
			 FROM {$wpdb->prefix}jp_jobs j
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id
			 {$where} ORDER BY j.created_at DESC LIMIT {$per} OFFSET {$off}"
		);
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_jobs j {$where}" );
		return $this->ok( [ 'jobs' => $jobs ?: [], 'total' => $total ] );
	}

	public function get_recruiter_applications( \WP_REST_Request $r ) {
		global $wpdb;
		$uid    = get_current_user_id();
		$job_id = absint( $r->get_param( 'job_id' ) ?? 0 );
		$stage  = sanitize_key( $r->get_param( 'stage' ) ?? '' );
		$page   = max( 1, absint( $r->get_param( 'page' ) ?? 1 ) );
		$per    = 30;
		$off    = ( $page - 1 ) * $per;

		$where = $wpdb->prepare( "WHERE j.posted_by=%d", $uid );
		if ( $job_id )  $where .= $wpdb->prepare( " AND a.job_id=%d", $job_id );
		if ( $stage )   $where .= $wpdb->prepare( " AND a.stage=%s", $stage );

		$rows = $wpdb->get_results(
			"SELECT a.*,j.title AS job_title,
				u.display_name AS candidate_name,u.user_email AS candidate_email,
				c.headline,c.experience_years,c.avatar_url,c.location_city,
				c.profile_score,c.current_title
			 FROM {$wpdb->prefix}jp_applications a
			 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id
			 LEFT JOIN {$wpdb->users} u ON u.ID=a.candidate_id
			 LEFT JOIN {$wpdb->prefix}jp_candidates c ON c.user_id=a.candidate_id
			 {$where} ORDER BY a.match_score DESC, a.created_at DESC
			 LIMIT {$per} OFFSET {$off}"
		);
		$total = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications a
			 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id {$where}"
		);
		// New in batch 37: decode the tags JSON column so the pipeline list
		// can render tag chips without a per-row detail fetch.
		foreach ( (array) $rows as $row ) {
			$row->tags = json_decode( $row->tags ?? '[]', true ) ?: [];
		}
		return $this->ok( [ 'applications' => $rows ?: [], 'total' => $total ] );
	}

	/**
	 * TRACE: GET /recruiter/applications/export, recruiter or above → same
	 * WHERE-clause scoping as get_recruiter_applications() (j.posted_by=
	 * current user, plus optional job_id/stage filters) but with NO LIMIT/
	 * OFFSET pagination and no row cap under 5000 → builds a raw CSV string
	 * → returns it as a file download (text/csv + Content-Disposition),
	 * the exact response shape admin_csv_export() already established.
	 * Preconditions: caller holds the recruiter (or higher) capability.
	 * Postconditions: response is real, current applicant data for this
	 * recruiter's own job postings only — never another recruiter's.
	 * Edge cases handled: zero matching applications returns a header-only
	 * CSV (still a valid, openable file) rather than an error; capped at
	 * 5000 rows, matching admin_csv_export()'s own cap, since an unbounded
	 * export is the same "unbounded query" bug class flagged elsewhere in
	 * this codebase's audit history.
	 */
	public function recruiter_export_applications( \WP_REST_Request $r ) {
		global $wpdb;
		$uid    = get_current_user_id();
		$job_id = absint( $r->get_param( 'job_id' ) ?? 0 );
		$stage  = sanitize_key( $r->get_param( 'stage' ) ?? '' );

		$where = $wpdb->prepare( "WHERE j.posted_by=%d", $uid );
		if ( $job_id )  $where .= $wpdb->prepare( " AND a.job_id=%d", $job_id );
		if ( $stage )   $where .= $wpdb->prepare( " AND a.stage=%s", $stage );

		$rows = $wpdb->get_results(
			"SELECT a.id,a.stage,a.match_score,a.created_at,
				j.title AS job_title,
				u.display_name AS candidate_name,u.user_email AS candidate_email,
				c.headline,c.experience_years,c.location_city,c.current_title,c.profile_score
			 FROM {$wpdb->prefix}jp_applications a
			 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id
			 LEFT JOIN {$wpdb->users} u ON u.ID=a.candidate_id
			 LEFT JOIN {$wpdb->prefix}jp_candidates c ON c.user_id=a.candidate_id
			 {$where} ORDER BY a.match_score DESC, a.created_at DESC
			 LIMIT 5000",
			ARRAY_A
		);

		if ( empty( $rows ) ) {
			// Header-only CSV so an empty result still opens as a valid
			// file, matching admin_csv_export()'s own header row.
			$rows = [ [ 'id' => '', 'stage' => '', 'match_score' => '', 'created_at' => '',
				'job_title' => '', 'candidate_name' => '', 'candidate_email' => '',
				'headline' => '', 'experience_years' => '', 'location_city' => '',
				'current_title' => '', 'profile_score' => '' ] ];
			$csv = implode( ',', array_keys( $rows[0] ) ) . "\n";
		} else {
			$csv = implode( ',', array_keys( $rows[0] ) ) . "\n";
			foreach ( $rows as $row ) {
				$csv .= implode( ',', array_map( fn($v) => '"' . str_replace( '"', '""', (string)($v ?? '') ) . '"', $row ) ) . "\n";
			}
		}

		return new \WP_REST_Response( $csv, 200, [
			'Content-Type'        => 'text/csv',
			'Content-Disposition' => 'attachment; filename="jp_my_applicants_' . date('Y-m-d') . '.csv"',
		] );
	}

	public function get_recruiter_company( \WP_REST_Request $r ) {
		$company = JP_DB::instance()->get_company_by_user( get_current_user_id() );
		if ( ! $company ) return $this->not_found( 'No company profile found. Please create one.' );
		return $this->ok( $company );
	}

	public function update_recruiter_company( \WP_REST_Request $r ) {
		$uid    = get_current_user_id();
		$company = JP_DB::instance()->get_company_by_user( $uid );
		if ( ! $company ) return $this->not_found( 'Company not found.' );
		global $wpdb;
		$allowed = [ 'name','description','website','email','phone','industry','size_range','headquarters','founded_year' ];
		$data    = [];
		foreach ( $allowed as $key ) {
			$val = $r->get_param( $key );
			if ( $val !== null ) $data[$key] = sanitize_text_field( $val );
		}
		if ( ! $data ) return $this->error( 'No updatable fields provided.' );
		$data['updated_at'] = current_time( 'mysql' );
		// Root-cause fix (ghost-success pattern): this is the endpoint
		// RecruiterCompanyPage.tsx actually calls to save the recruiter's
		// own company profile — the return value was discarded, so a
		// failed write still told the recruiter "Company profile updated."
		// while their changes silently didn't persist.
		$updated = $wpdb->update( $wpdb->prefix . 'jp_companies', $data, [ 'id' => $company->id ] );
		if ( false === $updated ) {
			return $this->error( 'Failed to update company profile. Please try again.' );
		}
		return $this->ok( [ 'message' => 'Company profile updated.' ] );
	}

	public function get_interviews( \WP_REST_Request $r ) {
		global $wpdb;
		$uid  = get_current_user_id();
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT i.*,j.title AS job_title,u.display_name AS candidate_name
			 FROM {$wpdb->prefix}jp_interviews i
			 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=i.job_id
			 LEFT JOIN {$wpdb->users} u ON u.ID=i.candidate_id
			 WHERE i.recruiter_id=%d ORDER BY i.scheduled_at ASC",
			$uid
		) );
		return $this->ok( $rows ?: [] );
	}

	public function schedule_interview( \WP_REST_Request $r ) {
		global $wpdb;
		$app_id      = absint( $r->get_param( 'application_id' ) ?? 0 );
		$scheduled   = sanitize_text_field( $r->get_param( 'scheduled_at' ) ?? '' );
		$type        = sanitize_key( $r->get_param( 'type' ) ?? 'video' );
		$meet_link   = esc_url_raw( $r->get_param( 'meet_link' ) ?? $r->get_param( 'meeting_link' ) ?? '' );
		$location    = sanitize_text_field( $r->get_param( 'location' ) ?? '' );
		$notes       = sanitize_textarea_field( $r->get_param( 'notes' ) ?? '' );

		if ( ! $app_id || ! $scheduled ) return $this->error( 'application_id and scheduled_at are required.' );

		// Root-cause fix (states/forms audit — edge cases): the SPA's
		// client-side `min` attribute and pre-submit check are the fast
		// path, but this REST endpoint is reachable directly and had no
		// validation of its own — a past scheduled_at would silently
		// insert the row and notify the candidate of an interview that
		// already happened.
		$scheduled_ts = strtotime( $scheduled );
		if ( ! $scheduled_ts || $scheduled_ts < time() ) {
			return $this->error( 'Interview date/time must be in the future.', 400 );
		}

		$app = JP_DB::instance()->get_application( $app_id );
		if ( ! $app ) return $this->not_found( 'Application not found.' );

		$result = $wpdb->insert( $wpdb->prefix . 'jp_interviews', [
			'application_id' => $app_id,
			'job_id'         => $app->job_id,
			'recruiter_id'   => get_current_user_id(),
			'candidate_id'   => $app->candidate_id,
			'scheduled_at'   => $scheduled,
			'type'           => $type,
			'meeting_link'   => $meet_link,
			'location'       => $location,
			'notes'          => $notes,
			'outcome'        => 'pending', // Fixed: schema has 'outcome', not 'status'
			'created_at'     => current_time( 'mysql' ),
		], ['%d','%d','%d','%d','%s','%s','%s','%s','%s','%s','%s'] );
		if ( $result === false ) {
			return $this->error( 'Failed to schedule interview. Please try again.' );
		}

		// Notify candidate
		// Root-cause fix (batch 36): JP_Notifications has never had a
		// send() method — only create() (in-app + best-effort push) and
		// send_email()/send_stage_email() (email only). This call has been
		// `JP_Notifications::instance()->send(...)` since schedule_interview()
		// was written, which is a call to an undefined method — every single
		// interview-scheduling request fatally errored (PHP Error, HTTP 500)
		// AFTER the interview row was already inserted, so the recruiter saw
		// a hard failure while a real interview silently existed in the DB
		// with the candidate never notified. Switched to create() with the
		// same {user_id,type,title,body,url} shape every other in-app
		// notification call site in this codebase already uses (batches
		// 33-34), pointed at the new candidate-facing interviews page
		// (InterviewsPage.tsx / GET /my-interviews) this same batch built.
		JP_Notifications::instance()->create( [
			'user_id' => (int) $app->candidate_id,
			'type'    => 'interview_scheduled',
			'title'   => 'Interview scheduled!',
			'body'    => "Your interview has been scheduled for {$scheduled}.",
			'url'     => home_url( '/dashboard/interviews' ),
		] );

		return $this->ok( [ 'message' => 'Interview scheduled. Candidate notified.' ], 201 );
	}

	public function cancel_interview( \WP_REST_Request $r ) {
		global $wpdb;
		$id  = absint( $r->get_param( 'id' ) );
		$uid = get_current_user_id();
		$result = $wpdb->update( $wpdb->prefix . 'jp_interviews', [ 'outcome' => 'cancelled' ], [ 'id' => $id, 'recruiter_id' => $uid ] );
		if ( $result === false || $result === 0 ) return $this->error( 'Interview not found or already cancelled.' );
		return $this->ok( [ 'message' => 'Interview cancelled.' ] );
	}

	/**
	 * Batch 36 — candidate's own interview list. Deliberately a separate
	 * method rather than teaching get_interviews() a second WHERE branch:
	 * that method's SELECT joins in candidate_name (irrelevant to the
	 * candidate viewing their own interviews) and is registered under the
	 * $rec-gated /interviews route, so reusing it would mean either loosening
	 * that route's permission callback or adding a role branch inside it —
	 * both riskier than a small, obviously-scoped sibling query.
	 */
	/**
	 * Phase 3 redesign (Tier A, redesign-plan §InterviewsPage) — added the
	 * company name join. job_title alone is ambiguous once a candidate has
	 * interviews across more than one company for similarly-titled roles;
	 * company_id is already on jp_jobs, this just surfaces it. Deliberately
	 * NOT adding i.notes/i.feedback/i.rating to what the candidate sees:
	 * those are the recruiter's private interview notes/scorecard (see
	 * this method's own batch-20 docblock above on why they exist) — the
	 * same internal-vs-candidate-facing distinction already enforced for
	 * application notes/tags in get_application() (batch 38's privacy fix).
	 */
	public function get_my_interviews( \WP_REST_Request $r ) {
		global $wpdb;
		$uid  = get_current_user_id();
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT i.*,j.title AS job_title,c.name AS company_name,u.display_name AS recruiter_name
			 FROM {$wpdb->prefix}jp_interviews i
			 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=i.job_id
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id
			 LEFT JOIN {$wpdb->users} u ON u.ID=i.recruiter_id
			 WHERE i.candidate_id=%d ORDER BY i.scheduled_at ASC",
			$uid
		) );
		return $this->ok( $rows ?: [] );
	}

	/**
	 * Candidate confirms they'll attend. Scoped to the candidate's own
	 * interview (candidate_id=%d in the WHERE, not just id=%d) so one
	 * candidate can't confirm — or, via request_interview_reschedule()
	 * below, request a reschedule on — another candidate's interview by
	 * guessing an id. Only meaningful while the interview is still
	 * 'pending'; a passed/failed/cancelled/no_show interview is a closed
	 * historical record, same "already decided" guard batch 20's interview
	 * feedback and batch 21's offer-response already use.
	 */
	public function confirm_interview( \WP_REST_Request $r ) {
		global $wpdb;
		$id  = absint( $r->get_param( 'id' ) );
		$uid = get_current_user_id();
		$interview = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_interviews WHERE id=%d AND candidate_id=%d", $id, $uid
		) );
		if ( ! $interview ) return $this->not_found( 'Interview not found.' );
		if ( $interview->outcome !== 'pending' ) return $this->error( 'This interview is no longer awaiting confirmation.' );

		$ok = false !== $wpdb->update(
			$wpdb->prefix . 'jp_interviews',
			[ 'candidate_confirmed' => 1, 'reschedule_requested' => 0 ],
			[ 'id' => $id, 'candidate_id' => $uid ]
		);
		if ( ! $ok ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_interviews confirm update failed: ' . $wpdb->last_error ), 'JP_Api::confirm_interview interview_id=' . $id );
			}
			return $this->error( 'Could not confirm this interview. Please try again.' );
		}

		JP_Notifications::instance()->create( [
			'user_id' => (int) $interview->recruiter_id,
			'type'    => 'interview_confirmed',
			'title'   => 'Candidate confirmed an interview',
			'body'    => 'The candidate has confirmed they will attend.',
			'url'     => home_url( '/recruiter/interviews' ),
		] );

		return $this->ok( [ 'message' => 'Interview confirmed. The recruiter has been notified.' ] );
	}

	/**
	 * Candidate asks to reschedule. Kept as a request the recruiter acts on
	 * (reschedule the interview_at themselves, or cancel it) rather than
	 * letting the candidate change scheduled_at directly — the recruiter
	 * owns the calendar slot and any panelists already added to it.
	 */
	public function request_interview_reschedule( \WP_REST_Request $r ) {
		global $wpdb;
		$id     = absint( $r->get_param( 'id' ) );
		$uid    = get_current_user_id();
		$reason = sanitize_textarea_field( $r->get_param( 'reason' ) ?? '' );
		$interview = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_interviews WHERE id=%d AND candidate_id=%d", $id, $uid
		) );
		if ( ! $interview ) return $this->not_found( 'Interview not found.' );
		if ( $interview->outcome !== 'pending' ) return $this->error( 'This interview is no longer awaiting a response.' );

		$ok = false !== $wpdb->update(
			$wpdb->prefix . 'jp_interviews',
			[ 'reschedule_requested' => 1, 'reschedule_reason' => $reason, 'candidate_confirmed' => 0 ],
			[ 'id' => $id, 'candidate_id' => $uid ]
		);
		if ( ! $ok ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_interviews reschedule-request update failed: ' . $wpdb->last_error ), 'JP_Api::request_interview_reschedule interview_id=' . $id );
			}
			return $this->error( 'Could not send your reschedule request. Please try again.' );
		}

		JP_Notifications::instance()->create( [
			'user_id' => (int) $interview->recruiter_id,
			'type'    => 'interview_reschedule_requested',
			'title'   => 'Candidate requested a reschedule',
			'body'    => $reason !== '' ? "Reason: {$reason}" : 'No reason given.',
			'url'     => home_url( '/recruiter/interviews' ),
		] );

		return $this->ok( [ 'message' => 'Reschedule request sent to the recruiter.' ] );
	}

	/**
	 * Records the outcome of an interview after it happens: rating (0-5),
	 * free-text feedback, and a terminal outcome (passed/failed/no_show).
	 * Root-cause fix (batch 20) — see the route registration comment above
	 * for why this previously didn't exist at all. Scoped to the owning
	 * recruiter only (same ownership check cancel_interview() already
	 * uses), and only allowed from 'pending' — once an interview has a
	 * recorded outcome it's a historical record, not something to be
	 * silently overwritten by a second submission.
	 */
	public function submit_interview_feedback( \WP_REST_Request $r ) {
		global $wpdb;
		$id  = absint( $r->get_param( 'id' ) );
		$uid = get_current_user_id();

		$outcome = sanitize_key( $r->get_param( 'outcome' ) ?? '' );
		if ( ! in_array( $outcome, [ 'passed', 'failed', 'no_show' ], true ) ) {
			return $this->error( 'outcome must be one of: passed, failed, no_show.' );
		}
		$rating = absint( $r->get_param( 'rating' ) ?? 0 );
		if ( $rating > 5 ) $rating = 5;
		$feedback = sanitize_textarea_field( $r->get_param( 'feedback' ) ?? '' );

		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_interviews WHERE id=%d AND recruiter_id=%d", $id, $uid
		) );
		if ( ! $row ) return $this->not_found( 'Interview not found.' );
		if ( $row->outcome !== 'pending' ) {
			return $this->error( 'This interview already has a recorded outcome (' . $row->outcome . ') and cannot be re-submitted.' );
		}

		$result = $wpdb->update( $wpdb->prefix . 'jp_interviews', [
			'outcome'  => $outcome,
			'rating'   => $rating,
			'feedback' => $feedback,
		], [ 'id' => $id, 'recruiter_id' => $uid ] );
		if ( false === $result || 0 === $result ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_interviews feedback update failed: ' . $wpdb->last_error ), 'JP_Api::submit_interview_feedback interview_id=' . $id );
			}
			return $this->error( 'Could not save interview feedback. Please try again.' );
		}

		if ( class_exists( 'JP_Security' ) ) {
			JP_Security::instance()->audit( 'interview_feedback_submitted', 'interview', $id, "Outcome: {$outcome}, rating: {$rating}/5" );
		}

		return $this->ok( [ 'message' => 'Interview feedback saved.' ] );
	}

	/**
	 * Root-cause fix (batch 26 — closes the multi-interviewer half of the
	 * "interview panel/scorecard collaboration" backlog item that batch 20
	 * deliberately left out; see submit_interview_feedback()'s docblock).
	 * jp_interview_panelists lets several named reviewers each submit an
	 * independent scorecard on the same interview, on top of the single
	 * feedback batch 20 wired onto jp_interviews itself. Only the
	 * interview's owning recruiter can add a panelist (same ownership
	 * pattern cancel_interview()/submit_interview_feedback() already use),
	 * and the panelist must be an active team member of the SAME company
	 * the interview's job belongs to — not just any WordPress user id —
	 * so this can't be used to pull an arbitrary account into a private
	 * hiring conversation.
	 *
	 * @return array|\WP_Error
	 */
	private function get_owned_interview( int $interview_id, int $recruiter_id ) {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_interviews WHERE id=%d AND recruiter_id=%d", $interview_id, $recruiter_id
		) );
		if ( ! $row ) return new \WP_Error( 'jp_not_found', 'Interview not found.', [ 'status' => 404 ] );
		return $row;
	}

	public function add_interview_panelist( \WP_REST_Request $r ) {
		global $wpdb;
		$interview_id = absint( $r->get_param( 'id' ) );
		$panelist_id  = absint( $r->get_param( 'panelist_id' ) ?? 0 );
		$uid          = get_current_user_id();

		if ( ! $panelist_id ) return $this->error( 'panelist_id is required.' );

		$interview = $this->get_owned_interview( $interview_id, $uid );
		if ( is_wp_error( $interview ) ) return $this->error( $interview->get_error_message(), $interview->get_error_data()['status'] ?? 404 );

		$job = JP_DB::instance()->get_job( (int) $interview->job_id );
		if ( ! $job ) return $this->not_found( 'Job not found for this interview.' );

		if ( ! JP_Team::instance()->is_team_member_of( (int) $job->company_id, $panelist_id ) ) {
			return $this->forbidden();
		}

		$inserted = $wpdb->insert( $wpdb->prefix . 'jp_interview_panelists', [
			'interview_id' => $interview_id,
			'panelist_id'  => $panelist_id,
			'added_by'     => $uid,
			'outcome'      => 'pending',
			'created_at'   => current_time( 'mysql' ),
		], [ '%d', '%d', '%d', '%s', '%s' ] );

		if ( false === $inserted ) {
			// A duplicate (interview_id, panelist_id) hits the UNIQUE key
			// and lands here too — surfaced as a normal validation error
			// rather than a generic 500, since "already on this panel" is
			// the far more likely real-world cause than a genuine DB fault.
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_interview_panelists insert failed: ' . $wpdb->last_error ), 'JP_Api::add_interview_panelist interview_id=' . $interview_id . ' panelist_id=' . $panelist_id );
			}
			return $this->error( 'Could not add this panelist. They may already be on the panel.' );
		}

		// Root-cause fix (batch 36): same undefined-method fatal-error bug
		// as schedule_interview() above — this request would 500 AFTER the
		// panelist row was already inserted, so a panelist could be added
		// while the API call reports failure and the panelist is never
		// notified. Uses the interviews list, the real page a recruiter
		// panelist works from (RecruiterInterviewsPage.tsx).
		JP_Notifications::instance()->create( [
			'user_id' => $panelist_id,
			'type'    => 'interview_panel_added',
			'title'   => 'Added to an interview panel',
			'body'    => 'You have been asked to submit interview feedback.',
			'url'     => home_url( '/recruiter/interviews' ),
		] );

		return $this->ok( [ 'message' => 'Panelist added.', 'id' => (int) $wpdb->insert_id ], 201 );
	}

	public function get_interview_panelists( \WP_REST_Request $r ) {
		global $wpdb;
		$interview_id = absint( $r->get_param( 'id' ) );
		$uid          = get_current_user_id();

		$interview = $this->get_owned_interview( $interview_id, $uid );
		if ( is_wp_error( $interview ) ) return $this->error( $interview->get_error_message(), $interview->get_error_data()['status'] ?? 404 );

		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT p.*, u.display_name AS panelist_name
			 FROM {$wpdb->prefix}jp_interview_panelists p
			 LEFT JOIN {$wpdb->users} u ON u.ID=p.panelist_id
			 WHERE p.interview_id=%d ORDER BY p.created_at ASC",
			$interview_id
		) );
		return $this->ok( $rows ?: [] );
	}

	public function remove_interview_panelist( \WP_REST_Request $r ) {
		global $wpdb;
		$interview_id     = absint( $r->get_param( 'id' ) );
		$panelist_row_id  = absint( $r->get_param( 'panelist_row_id' ) );
		$uid              = get_current_user_id();

		$interview = $this->get_owned_interview( $interview_id, $uid );
		if ( is_wp_error( $interview ) ) return $this->error( $interview->get_error_message(), $interview->get_error_data()['status'] ?? 404 );

		$deleted = $wpdb->delete( $wpdb->prefix . 'jp_interview_panelists', [
			'id' => $panelist_row_id, 'interview_id' => $interview_id,
		], [ '%d', '%d' ] );

		if ( false === $deleted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_interview_panelists delete failed: ' . $wpdb->last_error ), 'JP_Api::remove_interview_panelist id=' . $panelist_row_id );
			}
			return $this->error( 'Could not remove this panelist. Please try again.' );
		}
		if ( 0 === $deleted ) return $this->not_found( 'Panelist not found on this interview.' );

		return $this->ok( [ 'message' => 'Panelist removed.' ] );
	}

	/**
	 * Submitted by the panelist themselves, not the recruiter — ownership
	 * check here is "does this panelist row belong to the current user",
	 * mirroring submit_interview_feedback()'s "already decided, cannot
	 * re-submit" guard so one panelist can't overwrite their own recorded
	 * scorecard after the fact.
	 */
	public function submit_panelist_feedback( \WP_REST_Request $r ) {
		global $wpdb;
		$panelist_row_id = absint( $r->get_param( 'panelist_row_id' ) );
		$interview_id    = absint( $r->get_param( 'id' ) );
		$uid             = get_current_user_id();

		$outcome = sanitize_key( $r->get_param( 'outcome' ) ?? '' );
		if ( ! in_array( $outcome, [ 'passed', 'failed', 'no_show' ], true ) ) {
			return $this->error( 'outcome must be one of: passed, failed, no_show.' );
		}
		$rating = absint( $r->get_param( 'rating' ) ?? 0 );
		if ( $rating > 5 ) $rating = 5;
		$feedback = sanitize_textarea_field( $r->get_param( 'feedback' ) ?? '' );

		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_interview_panelists WHERE id=%d AND interview_id=%d",
			$panelist_row_id, $interview_id
		) );
		if ( ! $row ) return $this->not_found( 'Panel assignment not found.' );
		if ( (int) $row->panelist_id !== $uid ) return $this->forbidden();
		if ( $row->outcome !== 'pending' ) {
			return $this->error( 'You have already submitted feedback for this interview and cannot re-submit.' );
		}

		$result = $wpdb->update( $wpdb->prefix . 'jp_interview_panelists', [
			'outcome'      => $outcome,
			'rating'       => $rating,
			'feedback'     => $feedback,
			'submitted_at' => current_time( 'mysql' ),
		], [ 'id' => $panelist_row_id ] );

		if ( false === $result || 0 === $result ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_interview_panelists feedback update failed: ' . $wpdb->last_error ), 'JP_Api::submit_panelist_feedback id=' . $panelist_row_id );
			}
			return $this->error( 'Could not save your feedback. Please try again.' );
		}

		if ( class_exists( 'JP_Security' ) ) {
			JP_Security::instance()->audit( 'panelist_feedback_submitted', 'interview', $interview_id, "Panelist {$uid}, outcome: {$outcome}, rating: {$rating}/5" );
		}

		return $this->ok( [ 'message' => 'Your feedback has been recorded.' ] );
	}

	public function add_application_note( \WP_REST_Request $r ) {
		$_POST['app_id'] = $r->get_param( 'id' );
		$_POST['note']   = sanitize_textarea_field( $r->get_param( 'note' ) ?? '' );
		$out = $this->bridge_ajax( fn() => JP_Applications::instance()->ajax_add_note() );
		return $out['success'] ? $this->ok( $out['data'] ) : $this->error( $out['data']['message'] ?? 'Failed.' );
	}

	/**
	 * New in batch 37 (recruiter ATS pipeline depth). REST wrapper over
	 * JP_Applications::ajax_set_tags(), same bridge_ajax() shape as
	 * add_application_note() above. Client sends the full desired tag
	 * array on every call (see ajax_set_tags()'s docblock for why).
	 */
	public function set_application_tags( \WP_REST_Request $r ) {
		$_POST['app_id'] = $r->get_param( 'id' );
		$_POST['tags']   = (array) ( $r->get_param( 'tags' ) ?? [] );
		$out = $this->bridge_ajax( fn() => JP_Applications::instance()->ajax_set_tags() );
		return $out['success'] ? $this->ok( $out['data'] ) : $this->error( $out['data']['message'] ?? 'Failed.' );
	}

	public function bulk_move_stage( \WP_REST_Request $r ) {
		global $wpdb;
		$ids   = array_map( 'absint', (array) $r->get_param( 'ids' ) );
		$stage = sanitize_key( $r->get_param( 'stage' ) ?? '' );
		if ( ! $ids || ! $stage ) return $this->error( 'ids and stage are required.' );
		// Input-validation fix, same as the other bulk_*_action() endpoints.
		if ( count( $ids ) > 200 ) {
			return $this->error( 'Bulk actions are limited to 200 items at a time. Please select fewer and try again.' );
		}
		$uid   = get_current_user_id();
		$moved = 0;
		$failed = 0;
		foreach ( $ids as $id ) {
			// Verify recruiter owns the job this application belongs to
			$app = JP_DB::instance()->get_application( $id );
			if ( ! $app ) continue;
			$job = JP_DB::instance()->get_job( $app->job_id );
			if ( ! $job || (int)$job->posted_by !== $uid ) continue;
			// Root-cause fix (batch 16): unchecked $wpdb->update() — this is
			// the ACTUAL REST-reachable bulk-stage endpoint the SPA calls
			// (registered at POST /applications/bulk-stage; JP_Applications::
			// ajax_bulk_action() is a separate, legacy-AJAX-only duplicate of
			// this same logic, fixed independently for the same reason).
			// Previously every id that passed the ownership check was
			// counted as "moved" regardless of whether its write actually
			// persisted, so a partial failure in a large batch was
			// completely invisible to the recruiter.
			$updated = $wpdb->update( $wpdb->prefix . 'jp_applications',
				[ 'stage' => $stage, 'updated_at' => current_time('mysql') ],
				[ 'id' => $id ], ['%s','%s'], ['%d']
			);
			if ( false === $updated ) {
				$failed++;
				if ( class_exists( 'JP_ErrorLog' ) ) {
					JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_applications bulk_move_stage update failed: ' . $wpdb->last_error ), 'JP_API::bulk_move_stage app_id=' . $id );
				}
				continue;
			}
			$moved++;
		}
		$message = "{$moved} application(s) moved to {$stage}.";
		if ( $failed > 0 ) {
			$message .= " {$failed} could not be updated — please retry those.";
		}
		return $this->ok( [ 'moved' => $moved, 'failed' => $failed, 'message' => $message ] );
	}

	/**
	 * Root-cause fix (gap analysis P1 #167): "No bulk job-management
	 * actions for recruiters (bulk pause/re-post/delete/feature) despite
	 * bulk stage-actions already existing for applications — a real
	 * asymmetry an enterprise recruiter managing 50+ open roles will hit
	 * immediately." Mirrors bulk_move_stage()'s shape and ownership-check
	 * pattern exactly (per-id owner-or-jp_approve_jobs check, skip
	 * silently rather than fail the whole batch on one unauthorized id) so
	 * a recruiter with 50 open roles can pause/reactivate/feature/delete a
	 * filtered selection in one request instead of one round-trip per job.
	 */
	public function bulk_job_action( \WP_REST_Request $r ) {
		$ids    = array_map( 'absint', (array) $r->get_param( 'ids' ) );
		$action = sanitize_key( $r->get_param( 'action' ) ?? '' );
		$allowed_actions = [ 'pause', 'activate', 'delete', 'feature', 'unfeature' ];
		if ( ! $ids || ! in_array( $action, $allowed_actions, true ) ) {
			return $this->error( 'ids and a valid action (pause, activate, delete, feature, unfeature) are required.' );
		}
		// Input-validation fix, same as the other bulk_*_action() endpoints.
		if ( count( $ids ) > 200 ) {
			return $this->error( 'Bulk actions are limited to 200 items at a time. Please select fewer and try again.' );
		}

		$uid     = get_current_user_id();
		$db      = JP_DB::instance();
		$done    = 0;
		$skipped = 0;

		foreach ( $ids as $id ) {
			$job = $db->get_job( $id );
			if ( ! $job ) { $skipped++; continue; }
			$can = (int) $job->posted_by === $uid || current_user_can( 'jp_approve_jobs' );
			if ( ! $can ) { $skipped++; continue; }

			switch ( $action ) {
				case 'pause':
					$ok = $db->update( 'jobs', [ 'status' => 'paused' ], [ 'id' => $id ] ) !== false;
					if ( $ok ) $db->audit( 'job_status_changed', 'job', $id, '→ paused (bulk)', (int) $job->company_id );
					break;
				case 'activate':
					$ok = $db->update( 'jobs', [ 'status' => 'active' ], [ 'id' => $id ] ) !== false;
					if ( $ok ) $db->audit( 'job_status_changed', 'job', $id, '→ active (bulk)', (int) $job->company_id );
					break;
				case 'feature':
					$ok = $db->update( 'jobs', [ 'is_featured' => 1 ], [ 'id' => $id ] ) !== false;
					if ( $ok ) $db->audit( 'job_featured', 'job', $id, '(bulk)', (int) $job->company_id );
					break;
				case 'unfeature':
					$ok = $db->update( 'jobs', [ 'is_featured' => 0 ], [ 'id' => $id ] ) !== false;
					if ( $ok ) $db->audit( 'job_unfeatured', 'job', $id, '(bulk)', (int) $job->company_id );
					break;
				case 'delete':
					$ok = (bool) $db->delete( 'jobs', [ 'id' => $id ] );
					if ( $ok ) $db->audit( 'job_deleted', 'job', $id, '(bulk)', (int) $job->company_id );
					break;
				default:
					$ok = false;
			}

			if ( $ok ) { $done++; JP_Cache::delete( "job_{$id}", 'jobs' ); }
			else { $skipped++; }
		}

		if ( $done > 0 ) JP_Cache::flush_group( 'jobs' );

		return $this->ok( [
			'done'    => $done,
			'skipped' => $skipped,
			'message' => "{$done} job(s) updated" . ( $skipped ? ", {$skipped} skipped (not found or not permitted)." : '.' ),
		] );
	}

	// ── AI Handlers ──────────────────────────────────────────────────────────────
	//
	// Root-cause fix (gap analysis P1 #153: "no rate limit on ... most AI
	// endpoints beyond a 24-hour cache keyed on exact prompt text (trivially
	// bypassed by varying input slightly)"). Every JP_AI::* method below
	// makes a real, billed OpenAI API call on any cache miss, and varying
	// so much as one word of a bullet/job-title/target-role input produces
	// a different md5() cache key while still landing an identical-cost
	// request — the existing cache provides zero cost protection against a
	// user (or script) that varies input slightly on each call. Each
	// endpoint now also enforces a per-user rate limit via
	// JP_Security::rate_limit(), independent of the cache, using the same
	// 429-response convention already established for toggle_save_job()
	// and the community endpoints (§10). Limits are set per-feature based
	// on realistic legitimate usage (e.g. a candidate improving one resume
	// bullet at a time is naturally lower-frequency than requesting a
	// single resume score).
	private function ai_rate_limited( string $bucket, int $limit, int $window ) {
		if ( ! JP_Security::rate_limit( $bucket, $limit, $window, (string) get_current_user_id() ) ) {
			return $this->error( 'Too many AI requests. Please slow down and try again shortly.', 429 );
		}
		return null;
	}

	public function ai_resume_score( \WP_REST_Request $r ) {
		if ( $err = $this->ai_rate_limited( 'jp_ai_resume_score', 10, 3600 ) ) return $err;
		return $this->ok( JP_AI::instance()->resume_score( get_current_user_id() ) );
	}

	public function ai_resume_improve( \WP_REST_Request $r ) {
		if ( $err = $this->ai_rate_limited( 'jp_ai_resume_improve', 30, 3600 ) ) return $err;
		$bullet  = sanitize_textarea_field( $r->get_param( 'bullet' ) ?? '' );
		$context = sanitize_text_field( $r->get_param( 'context' ) ?? '' );
		if ( ! $bullet ) return $this->error( 'bullet is required.' );
		return $this->ok( JP_AI::instance()->improve_bullet( $bullet, $context ) );
	}

	public function ai_cover_letter( \WP_REST_Request $r ) {
		if ( $err = $this->ai_rate_limited( 'jp_ai_cover_letter', 10, 3600 ) ) return $err;
		$job_id = absint( $r->get_param( 'job_id' ) ?? 0 );
		if ( ! $job_id ) return $this->error( 'job_id is required.' );
		return $this->ok( JP_AI::instance()->cover_letter( get_current_user_id(), $job_id ) );
	}

	public function ai_interview_prep( \WP_REST_Request $r ) {
		if ( $err = $this->ai_rate_limited( 'jp_ai_interview_prep', 10, 3600 ) ) return $err;
		$job_id = absint( $r->get_param( 'job_id' ) ?? 0 );
		if ( ! $job_id ) return $this->error( 'job_id is required.' );
		return $this->ok( JP_AI::instance()->interview_prep( $job_id, get_current_user_id() ) );
	}

	public function ai_interview_questions( \WP_REST_Request $r ) {
		if ( $err = $this->ai_rate_limited( 'jp_ai_interview_questions', 10, 3600 ) ) return $err;
		$job_id = absint( $r->get_param( 'job_id' ) ?? 0 );
		if ( ! $job_id ) return $this->error( 'job_id is required.' );
		return $this->ok( JP_AI::instance()->interview_questions( $job_id ) );
	}

	public function ai_career_advice( \WP_REST_Request $r ) {
		if ( $err = $this->ai_rate_limited( 'jp_ai_career_advice', 10, 3600 ) ) return $err;
		$target = sanitize_text_field( $r->get_param( 'target_role' ) ?? '' );
		if ( ! $target ) return $this->error( 'target_role is required.' );
		return $this->ok( JP_AI::instance()->career_advice( get_current_user_id(), $target ) );
	}

	public function ai_improve_jd( \WP_REST_Request $r ) {
		if ( $err = $this->ai_rate_limited( 'jp_ai_improve_jd', 20, 3600 ) ) return $err;
		$title = sanitize_text_field( $r->get_param( 'title' ) ?? '' );
		$desc  = wp_kses_post( $r->get_param( 'description' ) ?? '' );
		if ( ! $title || ! $desc ) return $this->error( 'title and description are required.' );
		return $this->ok( JP_AI::instance()->improve_jd( $title, $desc ) );
	}

	public function ai_salary_negotiate( \WP_REST_Request $r ) {
		if ( $err = $this->ai_rate_limited( 'jp_ai_salary_negotiate', 10, 3600 ) ) return $err;
		$offer    = absint( $r->get_param( 'offer_amount' ) ?? 0 );
		$role     = sanitize_text_field( $r->get_param( 'role' ) ?? '' );
		$location = sanitize_text_field( $r->get_param( 'location' ) ?? '' );
		if ( ! $offer || ! $role ) return $this->error( 'offer_amount and role are required.' );
		return $this->ok( JP_AI::instance()->salary_negotiate( get_current_user_id(), $offer, $role, $location ) );
	}

	public function ai_skill_demand( \WP_REST_Request $r ) {
		if ( $err = $this->ai_rate_limited( 'jp_ai_skill_demand', 30, 3600 ) ) return $err;
		$skill = sanitize_text_field( $r->get_param( 'skill' ) ?? '' );
		if ( ! $skill ) return $this->error( 'skill parameter required.' );
		return $this->ok( JP_AI::instance()->skill_demand( $skill ) );
	}

	// ── Response helpers ──────────────────────────────────────────────────────

	private function ok( $data, int $status = 200 ) {
		return new \WP_REST_Response( [ 'success' => true, 'data' => $data ], $status );
	}

	/**
	 * Root-cause fix (gap analysis P1 #214, partial: "~10 REST endpoints
	 * are implemented as a fragile bridge over legacy AJAX handlers ...
	 * Any stray PHP warning printed by the underlying handler corrupts the
	 * buffered JSON and produces a silent parse failure"). The 8 call
	 * sites below all follow the same
	 * `ob_start(); Legacy::ajax_x(); json_decode(ob_get_clean(), true)`
	 * shape — and every one of those legacy `ajax_x()` methods ends by
	 * calling `jp_json_response()`, which calls WordPress's
	 * `wp_send_json()`, which echoes the JSON and then terminates the
	 * request outright (`die`/`wp_die()`) — meaning the actual HTTP
	 * response IS whatever was flushed from that output buffer, warts and
	 * all. If ANYTHING else writes to output during the call — a PHP
	 * notice/warning/deprecation with `display_errors` on being the
	 * overwhelmingly common case — it lands in the same buffer ahead of
	 * the JSON and turns the response into invalid JSON with no
	 * indication server-side that anything went wrong.
	 *
	 * This centralizes the bridge into one helper that suppresses PHP's
	 * own error DISPLAY (not error CAPTURE — JP_ErrorLog's handlers are
	 * untouched and still record every warning to jp_error_log exactly as
	 * before) for the duration of the legacy call, so a stray warning can
	 * no longer reach the buffer at all. This does not attempt the gap
	 * analysis's larger suggested fix ("extract shared business logic into
	 * a plain method called directly by both the AJAX action and the REST
	 * callback") — that is a real, more invasive refactor across 4
	 * different classes (JP_Alerts, JP_Messaging, JP_Resume,
	 * JP_Applications) that changes each one's internal structure, and
	 * this sandbox has no live WordPress+MySQL runtime to verify such a
	 * refactor didn't subtly change behavior on any of the 8 endpoints —
	 * a correctness-critical thing to get wrong silently. This fix closes
	 * the specific, verifiable-without-a-live-runtime failure mode
	 * (display corrupting the buffer); the deeper architectural
	 * consolidation remains explicitly open, larger follow-on work.
	 */
	private function bridge_ajax( callable $fn ): ?array {
		$prev_display = ini_get( 'display_errors' );
		ini_set( 'display_errors', '0' );
		ob_start();
		$fn();
		// Only reached if $fn() returned normally instead of terminating
		// via jp_json_response()/wp_send_json() — every current call site's
		// legacy handler always calls jp_json_response() on every path, so
		// in practice this line and the ini_set() restore below are not
		// reached on today's call sites, but are kept correct/harmless for
		// any future bridge call whose wrapped method might not always die.
		$out = json_decode( ob_get_clean(), true );
		ini_set( 'display_errors', $prev_display );
		return $out;
	}

	private function error( string $message, int $status = 400 ): \WP_Error {
		return new \WP_Error( 'jp_error', $message, [ 'status' => $status ] );
	}

	private function not_found( string $msg = 'Not found.' ): \WP_Error {
		return $this->error( $msg, 404 );
	}

	private function forbidden(): \WP_Error {
		return $this->error( 'You do not have permission to perform this action.', 403 );
	}

	// ── Helpers ───────────────────────────────────────────────────────────────

	private function extract_job_data( \WP_REST_Request $r ): array {
		// Root-cause fix (enterprise UI/UX pass, batch 35): screening_questions
		// was accepted end-to-end by JP_Jobs::create() (which already
		// wp_json_encode()s $data['screening_questions'] into the screening_q
		// column) and by the frontend's JobFormPayload type — but this
		// method, the only place a REST request is turned into that $data
		// array, never actually read the param, so it was silently always
		// []. No recruiter has ever been able to set a screening question
		// through the API. Each question is {question, required} — required
		// is enforced client-side only (this backend intentionally accepts
		// whatever answers array a candidate submits, same as it already did
		// before this fix; adding server-side required-answer enforcement is
		// a separate, larger validation change, not bundled in here).
		$questions = (array) ( $r->get_param( 'screening_questions' ) ?? [] );
		$questions = array_values( array_filter( array_map( static function ( $q ) {
			if ( ! is_array( $q ) ) return null;
			$text = sanitize_text_field( $q['question'] ?? '' );
			if ( '' === $text ) return null;
			return [ 'question' => $text, 'required' => ! empty( $q['required'] ) ];
		}, $questions ) ) );

		return [
			'title'          => sanitize_text_field( $r->get_param( 'title' ) ?? '' ),
			'description'    => wp_kses_post( $r->get_param( 'description' ) ?? '' ),
			'requirements'   => sanitize_textarea_field( $r->get_param( 'requirements' ) ?? '' ),
			'job_type'       => sanitize_key( $r->get_param( 'job_type' ) ?? 'full-time' ),
			'work_mode'      => sanitize_key( $r->get_param( 'work_mode' ) ?? 'onsite' ),
			'location_city'  => sanitize_text_field( $r->get_param( 'location_city' ) ?? '' ),
			'location_state' => sanitize_text_field( $r->get_param( 'location_state' ) ?? '' ),
			'salary_min'     => absint( $r->get_param( 'salary_min' ) ?? 0 ),
			'salary_max'     => absint( $r->get_param( 'salary_max' ) ?? 0 ),
			// Root-cause fix (content-depth audit): this method never read
			// salary_visible at all, so JP_Jobs::create()'s
			// isset($data['salary_visible']) check was always false and
			// every newly-created job was silently inserted with
			// salary_visible=0 regardless of the jp_jobs schema's DEFAULT 1
			// — no recruiter has ever been able to show a salary on a job
			// they just posted. Defaulting true here (opt-out, not opt-in)
			// matches the column's own default so existing behavior for a
			// param-less caller (e.g. bulk import) is unchanged.
			'salary_visible' => (bool) ( $r->get_param( 'salary_visible' ) ?? true ),
			'experience_min' => absint( $r->get_param( 'experience_min' ) ?? 0 ),
			'experience_max' => absint( $r->get_param( 'experience_max' ) ?? 0 ),
			'skills_json'    => wp_json_encode( (array) ( $r->get_param( 'skills' ) ?? [] ) ),
			'industry_slug'  => sanitize_key( $r->get_param( 'industry' ) ?? '' ),
			'education_level'=> sanitize_text_field( $r->get_param( 'education_level' ) ?? '' ),
			'openings'       => max( 1, absint( $r->get_param( 'openings' ) ?? 1 ) ),
			'screening_questions' => $questions,
		];
	}
}
