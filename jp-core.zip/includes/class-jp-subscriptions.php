<?php
/**
 * Class JP_Subscriptions — Plan credit management & auto-expiry.
 * Plans: Starter (free) / Growth / Enterprise.
 * Credits: job_posts, featured_jobs, resume_views, candidate_msgs, team_seats.
 */
defined( 'ABSPATH' ) || exit;

class JP_Subscriptions {

	private static ?JP_Subscriptions $instance = null;

	// Default credit allocations per plan slug
	const PLAN_CREDITS = [
		'starter'    => ['job_posts'=>3,  'featured_jobs'=>0,  'resume_views'=>100, 'candidate_msgs'=>20,  'team_seats'=>1],
		'growth'     => ['job_posts'=>15, 'featured_jobs'=>5,  'resume_views'=>500, 'candidate_msgs'=>100, 'team_seats'=>3],
		'enterprise' => ['job_posts'=>999,'featured_jobs'=>25, 'resume_views'=>9999,'candidate_msgs'=>500, 'team_seats'=>10],
	];

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_jp_use_credit',       [ $this, 'ajax_use_credit' ] );
		add_action( 'jp_expire_subscriptions',     [ $this, 'expire_check' ] ); // hooked via cron
	}

	// ── Activate a subscription after payment ─────────────────────────────────

	public function activate( int $user_id, int $plan_id, string $billing_cycle = 'monthly' ): bool {
		global $wpdb;
		$plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_plans WHERE id=%d",$plan_id));
		if (!$plan) return false;

		$credits   = self::PLAN_CREDITS[$plan->slug] ?? self::PLAN_CREDITS['starter'];
		$duration  = $billing_cycle === 'yearly' ? 365 : 30;
		$expires   = date('Y-m-d H:i:s',strtotime("+{$duration} days"));

		// Deactivate any existing active sub. Unchecked previously: a
		// failure here wasn't fatal to activation (the new row below still
		// gets created and jp_plan meta still points at the new plan), but
		// it could leave a stale 'active' row alongside the new one —
		// anything that COUNTs active subscriptions per user, or iterates
		// them expecting exactly one, would silently double-count. Logged
		// rather than aborting activation over it, since the user did pay
		// and should get their new plan either way.
		$deactivate_result = $wpdb->update($wpdb->prefix.'jp_subscriptions',['status'=>'cancelled'],['user_id'=>$user_id,'status'=>'active'],['%s'],['%d','%s']);
		if ( false === $deactivate_result && class_exists( 'JP_ErrorLog' ) ) {
			JP_ErrorLog::instance()->log_exception(
				new \Exception( 'jp_subscriptions deactivate-old failed: ' . $wpdb->last_error ),
				'JP_Subscriptions::activate user_id=' . $user_id . ' plan_id=' . $plan_id
			);
		}

		// Root-cause fix (batch 9 — see class-jp-activator.php's
		// jp_subscriptions docblock). company_id is NOT NULL on this table
		// and was never provided (insert always failed for that reason
		// alone, before even reaching the two unknown-column names fixed
		// below) — resolved the same way class-jp-payments.php already
		// does for the same NOT-NULL requirement on jp_payments.
		$company    = class_exists('JP_DB') ? JP_DB::instance()->get_company_by_user($user_id) : null;
		$company_id = $company ? (int) $company->id : 0;

		$inserted = $wpdb->insert($wpdb->prefix.'jp_subscriptions',[
			'user_id'       => $user_id,
			'company_id'    => $company_id,
			'plan_id'       => $plan_id,
			'billing_cycle' => $billing_cycle,
			'status'        => 'active',
			'credits_json'  => wp_json_encode($credits),
			'starts_at'     => current_time('mysql'),
			'expires_at'    => $expires,
		],['%d','%d','%d','%s','%s','%s','%s','%s']);

		if ( false === $inserted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception(
					new \Exception( 'jp_subscriptions insert failed: ' . $wpdb->last_error ),
					'JP_Subscriptions::activate user_id=' . $user_id . ' plan_id=' . $plan_id
				);
			}
			// Deliberately does NOT set jp_plan/jp_plan_expires user meta
			// below when the actual subscription row couldn't be created —
			// that meta is what every other part of this codebase (and the
			// customer's own dashboard) trusts as "do they have this plan",
			// so setting it here while the row it's supposed to represent
			// doesn't exist would recreate exactly the kind of silent,
			// undetectable mismatch this fix exists to close.
			return false;
		}

		// Update user meta for fast access
		update_user_meta($user_id,'jp_plan',$plan->slug);
		update_user_meta($user_id,'jp_plan_expires',$expires);

		do_action('jp_subscription_activated',$user_id,$plan_id,$billing_cycle);
		return true;
	}

	// ── Get active subscription for a user ────────────────────────────────────

	public function get_active( int $user_id ): ?object {
		global $wpdb;
		// Root-cause fix (batch 9 — see class-jp-activator.php's
		// jp_subscriptions docblock). ORDER BY s.started_at referenced a
		// column that has never existed on this table (the real column is
		// starts_at, same as this method's own SELECT already correctly
		// aliases plan_name via JOIN rather than assuming a stored column)
		// — an unknown-column ORDER BY makes the whole query fail, so this
		// method has always returned null for every user regardless of
		// whether they actually had an active subscription.
		return $wpdb->get_row($wpdb->prepare(
			"SELECT s.*,p.name as plan_name FROM {$wpdb->prefix}jp_subscriptions s
			 LEFT JOIN {$wpdb->prefix}jp_plans p ON p.id=s.plan_id
			 WHERE s.user_id=%d AND s.status='active' AND s.expires_at>NOW()
			 ORDER BY s.starts_at DESC LIMIT 1",
			$user_id
		));
	}

	// ── Consume a credit ──────────────────────────────────────────────────────

	/**
	 * @param string $credit_type job_posts|featured_jobs|resume_views|candidate_msgs
	 * @return bool true if credit consumed, false if insufficient
	 */
	public function use_credit( int $user_id, string $credit_type ): bool {
		$sub = $this->get_active($user_id);

		// Free plan (Starter) — check default limits
		if (!$sub) {
			$free_credits = self::PLAN_CREDITS['starter'];
			if (!isset($free_credits[$credit_type])) return false;
			$used_key = "jp_credit_used_{$credit_type}";
			$used     = (int)get_user_meta($user_id,$used_key,true);
			if ($used >= $free_credits[$credit_type]) return false;
			update_user_meta($user_id,$used_key,$used+1);
			return true;
		}

		$credits = json_decode($sub->credits_json??'{}',true);
		if (!isset($credits[$credit_type])) return false;

		$remaining = (int)$credits[$credit_type];
		if ($remaining <= 0 && $remaining !== 999 && $remaining !== 9999) return false; // 999/9999 = unlimited sentinel

		if ($remaining !== 999 && $remaining !== 9999) {
			$credits[$credit_type] = $remaining - 1;
			global $wpdb;
			// Ghost-success / revenue-impact fix: this write was unchecked.
			// The credit is already granted in-memory by this point (the
			// caller's action — e.g. posting a job — proceeds either way),
			// but if the decrement never persists, every subsequent
			// get_active()/use_credit() call re-reads the OLD, un-decremented
			// credits_json — silently handing this user unlimited free
			// credits on this type until something else happens to update
			// the row. Logged so it's reconcilable rather than invisible.
			$persisted = $wpdb->update($wpdb->prefix.'jp_subscriptions',['credits_json'=>wp_json_encode($credits)],['id'=>$sub->id],['%s'],['%d']);
			if ( false === $persisted && class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception(
					new \Exception( 'jp_subscriptions credit decrement failed to persist: ' . $wpdb->last_error ),
					'JP_Subscriptions::use_credit sub_id=' . $sub->id . ' credit_type=' . $credit_type
				);
			}
		}
		return true;
	}

	public function get_credits( int $user_id ): array {
		$sub = $this->get_active($user_id);
		if (!$sub) return self::PLAN_CREDITS['starter'];
		return json_decode($sub->credits_json??'{}',true)?:self::PLAN_CREDITS['starter'];
	}

	public function ajax_use_credit(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');
		$type = sanitize_key($_POST['credit_type']??'');
		$ok   = $this->use_credit(get_current_user_id(),$type);
		jp_json_response($ok, $ok ? ['message'=>'Credit consumed.'] : 'Insufficient credits. Please upgrade your plan.');
	}

	// ── Cron: expire subscriptions ────────────────────────────────────────────

	public function expire_check(): void {
		global $wpdb;
		// Root-cause fix (batch 9 — see class-jp-activator.php's
		// jp_subscriptions docblock). Both queries below used to SELECT *
		// with no JOIN and then read $sub->plan_name directly — a column
		// that has never existed on this table; every other reader of a
		// subscription's plan name in this codebase (get_active() above,
		// and the admin subscriptions list in class-jp-api.php) correctly
		// computes it via LEFT JOIN jp_plans instead, so these two queries
		// now do the same rather than inventing a second, inconsistent way
		// to store it. expiry_warned was referenced by the second query
		// but never existed in the schema either — now a real column (see
		// the activator docblock) — and neither $wpdb->update() call here
		// had its return value checked, so a failed write would have
		// looked identical to a successful one; both are now logged on
		// failure.
		$expired = $wpdb->get_results(
			"SELECT s.*, p.name AS plan_name FROM {$wpdb->prefix}jp_subscriptions s
			 LEFT JOIN {$wpdb->prefix}jp_plans p ON p.id=s.plan_id
			 WHERE s.status='active' AND s.expires_at<=NOW()"
		);
		foreach ($expired as $sub) {
			$updated = $wpdb->update($wpdb->prefix.'jp_subscriptions',['status'=>'expired'],['id'=>$sub->id],['%s'],['%d']);
			if ( false === $updated && class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_subscriptions expire update failed: ' . $wpdb->last_error ), 'JP_Subscriptions::expire_check sub_id=' . $sub->id );
			}
			delete_user_meta($sub->user_id,'jp_plan');
			delete_user_meta($sub->user_id,'jp_plan_expires');
			// Send expiry notification
			$user = get_userdata($sub->user_id);
			if ($user) {
				$body = JP_Notifications::instance()->render_template('subscription_expiring',['name'=>$user->display_name,'plan_name'=>$sub->plan_name]);
				JP_Notifications::instance()->send_email($user->user_email,'Your '.($sub->plan_name).' subscription has expired',$body);
			}
			do_action('jp_subscription_expired',$sub->user_id,(int)$sub->plan_id);
		}

		// 7-day expiry warning
		$expiring_soon = $wpdb->get_results(
			"SELECT s.*, p.name AS plan_name FROM {$wpdb->prefix}jp_subscriptions s
			 LEFT JOIN {$wpdb->prefix}jp_plans p ON p.id=s.plan_id
			 WHERE s.status='active' AND s.expires_at<=DATE_ADD(NOW(),INTERVAL 7 DAY) AND s.expires_at>NOW() AND s.expiry_warned=0"
		);
		foreach ($expiring_soon as $sub) {
			$user = get_userdata($sub->user_id);
			if ($user) {
				$body = JP_Notifications::instance()->render_template('subscription_expiring',['name'=>$user->display_name,'plan_name'=>$sub->plan_name,'days_left'=>7]);
				JP_Notifications::instance()->send_email($user->user_email,'Your plan expires in 7 days — Renew now',$body);
				$updated = $wpdb->update($wpdb->prefix.'jp_subscriptions',['expiry_warned'=>1],['id'=>$sub->id],['%d'],['%d']);
				if ( false === $updated && class_exists( 'JP_ErrorLog' ) ) {
					JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_subscriptions expiry_warned update failed: ' . $wpdb->last_error ), 'JP_Subscriptions::expire_check sub_id=' . $sub->id );
				}
			}
		}
	}
}
