<?php
/**
 * Class JP_Analytics — Event tracking, aggregation, dashboard data.
 * Tracks: job_view, job_apply, search, company_view, profile_view.
 * Hourly aggregation via cron. 30-day summaries. Recruiter ROI reports.
 */
defined( 'ABSPATH' ) || exit;

class JP_Analytics {

	private static ?JP_Analytics $instance = null;

	const EVENTS = ['job_view','job_apply','search','company_view','profile_view','job_click'];

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_nopriv_jp_track', [ $this, 'ajax_track' ] );
		add_action( 'wp_ajax_jp_track',        [ $this, 'ajax_track' ] );
		add_action( 'wp_ajax_jp_get_analytics',[ $this, 'ajax_get_dashboard' ] );
		add_action( 'jp_aggregate_analytics',  [ $this, 'aggregate' ] ); // cron hook
	}

	// ── Track an event ────────────────────────────────────────────────────────

	public function track( string $event, int $object_id, array $meta = [] ): void {
		if (!in_array($event,self::EVENTS,true)) return;

		global $wpdb;
		$result = $wpdb->insert($wpdb->prefix.'jp_analytics',[
			'event'       => $event,
			'object_id'   => $object_id,
			'user_id'     => get_current_user_id() ?: null,
			'session_id'  => $this->get_session_id(),
			'ip'          => $this->get_ip_hash(),
			'meta_json'   => $meta ? wp_json_encode($meta) : null,
			'created_at'  => current_time('mysql'),
		],['%s','%d','%d','%s','%s','%s','%s']);

		// CRITICAL root-cause fix: this insert previously included a
		// 'session_id' key with no matching column on jp_analytics, so it
		// has failed on every single call since this class was written —
		// silently, because the return value was never checked. The
		// missing column is now added (see class-jp-activator.php's
		// CREATE TABLE + the JP_VERSION bump in jp-core.php that makes
		// dbDelta's column-diffing apply it to already-installed sites),
		// but the write is still fire-and-forget by design (a tracking
		// pixel can't block the page), so any future insert failure
		// (e.g. table missing before the upgrade runs, DB unavailable)
		// is now at least logged instead of vanishing without a trace.
		if ( false === $result ) {
			JP_ErrorLog::instance()->log_exception(
				new \Exception( 'jp_analytics insert failed: ' . $wpdb->last_error ),
				'JP_Analytics::track event=' . $event . ' object_id=' . $object_id
			);
		}
	}

	public function ajax_track(): void {
		// No nonce required for tracking (public pixel)
		$event    = sanitize_key($_POST['event']??'');
		$obj_id   = absint($_POST['object_id']??0);
		if ($event && $obj_id) $this->track($event,$obj_id);
		wp_send_json_success();
	}

	// ── Hourly aggregation (called by cron) ───────────────────────────────────

	public function aggregate(): void {
		global $wpdb;
		$hour = date('Y-m-d H:00:00',strtotime('-1 hour'));
		$next = date('Y-m-d H:00:00');

		$rows = $wpdb->get_results($wpdb->prepare(
			"SELECT event,object_id,COUNT(*) AS count,COUNT(DISTINCT ip) AS unique_count
			 FROM {$wpdb->prefix}jp_analytics
			 WHERE created_at>=%s AND created_at<%s
			 GROUP BY event,object_id",
			$hour,$next
		));

		foreach ($rows as $row) {
			$wpdb->replace($wpdb->prefix.'jp_analytics_agg',[
				'event'        => $row->event,
				'object_id'    => $row->object_id,
				'period'       => date('Y-m-d',strtotime($hour)),
				'count'        => $row->count,
				'unique_count' => $row->unique_count,
			],['%s','%d','%s','%d','%d']);
		}

		// Purge raw events older than 90 days to keep table lean
		$wpdb->query("DELETE FROM {$wpdb->prefix}jp_analytics WHERE created_at < DATE_SUB(NOW(),INTERVAL 90 DAY)");
	}

	// ── Dashboard API ─────────────────────────────────────────────────────────

	public function ajax_get_dashboard(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');

		$days      = min(90,absint($_GET['days']??30));
		$user_id   = get_current_user_id();
		$company   = JP_DB::instance()->get_company_by_user($user_id);
		$is_admin  = current_user_can('administrator');

		$data = $is_admin
			? $this->platform_summary($days)
			: $this->company_summary(( isset($company->id) ? $company->id : 0 ),$days);

		jp_json_response(true,$data);
	}

	public function platform_summary( int $days ): array {
		global $wpdb;
		$since = date('Y-m-d',strtotime("-{$days} days"));

		$daily = $wpdb->get_results($wpdb->prepare(
			"SELECT period,SUM(count) AS views,SUM(CASE WHEN event='job_apply' THEN count ELSE 0 END) AS applies
			 FROM {$wpdb->prefix}jp_analytics_agg
			 WHERE period>=%s GROUP BY period ORDER BY period ASC",
			$since
		));

		return array_merge( [
			'daily'          => $daily,
			'total_views'    => array_sum(array_column($daily,'views')),
			'total_applies'  => array_sum(array_column($daily,'applies')),
			'total_searches' => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}jp_search_log WHERE created_at>=DATE_SUB(NOW(),INTERVAL %d DAY)",$days)),
			'new_users'      => (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->users} WHERE user_registered>=DATE_SUB(NOW(),INTERVAL %d DAY)",$days)),
		], $this->platform_funnel_and_sources( $days ) );
	}

	/**
	 * Root-cause fix (enterprise gap-analysis: "JP_Analytics exposes only
	 * platform_summary()/company_summary() — two flat aggregates, no
	 * funnel, no source-of-hire attribution" — verified true for the
	 * PLATFORM-wide view specifically; get_recruiter_analytics() in
	 * class-jp-api.php already had a real per-recruiter funnel/time-to-
	 * hire computation, which this generalizes rather than duplicates —
	 * see compute_funnel_metrics() below, now the one shared
	 * implementation both call). Adds two things the recruiter-level view
	 * didn't need but the platform level does: (1) the same funnel-reach/
	 * time-to-hire/offer-acceptance metrics with NO posted_by filter, i.e.
	 * across every company; (2) source-of-hire attribution —
	 * jp_applications.source has been captured on every application since
	 * the schema was created (class-jp-activator.php), but nothing
	 * anywhere ever aggregated it until now.
	 */
	private function platform_funnel_and_sources( int $days ): array {
		global $wpdb;
		$since = date( 'Y-m-d H:i:s', strtotime( "-{$days} days" ) );

		$history_rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT stage_history FROM {$wpdb->prefix}jp_applications WHERE created_at>=%s", $since
		) );
		$funnel = $this->compute_funnel_metrics( $history_rows );

		$source_rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT COALESCE(NULLIF(source,''),'direct') AS source,
				COUNT(*) AS applications,
				SUM(CASE WHEN stage='hired' THEN 1 ELSE 0 END) AS hires
			 FROM {$wpdb->prefix}jp_applications
			 WHERE created_at>=%s
			 GROUP BY source ORDER BY applications DESC",
			$since
		) );
		$source_breakdown = array_map( function ( $row ) {
			$applications = (int) $row->applications;
			$hires        = (int) $row->hires;
			return [
				'source'          => $row->source,
				'applications'    => $applications,
				'hires'           => $hires,
				'hire_rate_pct'   => $applications > 0 ? round( $hires / $applications * 100, 1 ) : 0,
			];
		}, $source_rows ?: [] );

		return [
			'funnel_reach'              => $funnel['funnel_reach'],
			'avg_time_to_hire_days'     => $funnel['avg_time_to_hire_days'],
			'offer_acceptance_rate_pct' => $funnel['offer_acceptance_rate_pct'],
			'source_breakdown'          => $source_breakdown,
		];
	}

	/**
	 * Shared funnel-walking algorithm — extracted verbatim from
	 * get_recruiter_analytics()'s previously-inline implementation in
	 * class-jp-api.php (compute_recruiter_analytics()) so the platform-wide
	 * view above and the per-recruiter view share exactly one
	 * implementation rather than two copies that could silently drift.
	 * Takes raw stage_history rows (objects/arrays with a ->stage_history
	 * JSON property) already scoped by the caller (per-recruiter or
	 * platform-wide) — this method itself applies no additional filtering.
	 */
	public function compute_funnel_metrics( array $history_rows ): array {
		$stage_reach       = []; // stage => count of applications that EVER reached it (first occurrence only)
		$time_to_hire_days = [];
		foreach ( $history_rows as $row ) {
			$raw     = is_array( $row ) ? ( $row['stage_history'] ?? '' ) : ( $row->stage_history ?? '' );
			$history = json_decode( $raw ?: '[]', true ) ?: [];
			$applied_ts = null;
			$seen       = [];
			foreach ( $history as $entry ) {
				$stage = $entry['stage'] ?? '';
				if ( ! $stage || isset( $seen[ $stage ] ) ) continue; // count each stage once per application
				$seen[ $stage ] = true;
				$ts = ! empty( $entry['timestamp'] ) ? strtotime( $entry['timestamp'] ) : null;
				if ( 'applied' === $stage ) $applied_ts = $ts;
				$stage_reach[ $stage ] = ( $stage_reach[ $stage ] ?? 0 ) + 1;
				if ( 'hired' === $stage && $applied_ts && $ts && $ts >= $applied_ts ) {
					$time_to_hire_days[] = ( $ts - $applied_ts ) / DAY_IN_SECONDS;
				}
			}
		}

		// Conversion reported relative to 'applied' (the top of the
		// funnel), not the immediately preceding stage — see the original
		// root-cause comment on this exact choice, preserved at its new
		// call site in class-jp-api.php's compute_recruiter_analytics().
		$funnel_reach  = [];
		$applied_total = $stage_reach['applied'] ?? 0;
		foreach ( [ 'applied','shortlisted','phone_screen','interview','assessment','offer','hired' ] as $stage ) {
			$count          = $stage_reach[ $stage ] ?? 0;
			$funnel_reach[] = [
				'stage'                       => $stage,
				'reached'                     => $count,
				'conversion_from_applied_pct' => $applied_total > 0 ? round( $count / $applied_total * 100, 1 ) : null,
			];
		}
		$offer_count = $stage_reach['offer'] ?? 0;
		$hired_count = $stage_reach['hired'] ?? 0;

		return [
			'funnel_reach'              => $funnel_reach,
			'avg_time_to_hire_days'     => $time_to_hire_days ? round( array_sum( $time_to_hire_days ) / count( $time_to_hire_days ), 1 ) : null,
			'offer_acceptance_rate_pct' => $offer_count > 0 ? round( $hired_count / $offer_count * 100, 1 ) : null,
		];
	}

	public function company_summary( int $company_id, int $days ): array {
		global $wpdb;
		if (!$company_id) return ['daily'=>[],'total_views'=>0,'total_applies'=>0];

		$job_ids   = $wpdb->get_col($wpdb->prepare("SELECT id FROM {$wpdb->prefix}jp_jobs WHERE company_id=%d",$company_id));
		if (empty($job_ids)) return ['daily'=>[],'total_views'=>0,'total_applies'=>0];

		$id_list   = implode(',',array_map('absint',$job_ids));
		$since     = date('Y-m-d',strtotime("-{$days} days"));

		$daily = $wpdb->get_results($wpdb->prepare(
			"SELECT period,SUM(count) AS views,SUM(CASE WHEN event='job_apply' THEN count ELSE 0 END) AS applies
			 FROM {$wpdb->prefix}jp_analytics_agg
			 WHERE event IN('job_view','job_apply') AND object_id IN({$id_list}) AND period>=%s
			 GROUP BY period ORDER BY period ASC",
			$since
		));

		return [
			'daily'        => $daily,
			'total_views'  => array_sum(array_column($daily,'views')),
			'total_applies'=> array_sum(array_column($daily,'applies')),
			'apply_rate'   => count($daily) ? round(array_sum(array_column($daily,'applies'))/max(1,array_sum(array_column($daily,'views')))*100,1) : 0,
		];
	}

	// ── Helpers ───────────────────────────────────────────────────────────────

	private function get_session_id(): string {
		if (!session_id()) @session_start();
		return session_id() ?: wp_generate_password(16,false);
	}

	private function get_ip_hash(): string {
		$ip = sanitize_text_field($_SERVER['REMOTE_ADDR']??'');
		return $ip ? substr(hash('sha256',$ip.wp_salt()),0,16) : '';
	}
}
