<?php
/**
 * JP_Diagnostics — Full-system diagnostic report generator.
 *
 * Covers every layer of the JP Jobs Portal plugin:
 *   - Environment (PHP, MySQL, WordPress, server)
 *   - Database (tables, row counts, column integrity)
 *   - React frontend (asset files, CDN cache, chunk resolution)
 *   - REST API (route registration, reachability, auth)
 *   - WordPress roles and capabilities
 *   - Cron jobs (scheduled, next run, last run)
 *   - External services (OpenAI, Razorpay, SMTP, Redis, Elasticsearch)
 *   - Security (nonce config, rate limiting, WP_DEBUG exposure)
 *   - Plugin pages (template assignment, permalink)
 *   - Theme conflicts (dequeued correctly)
 *   - Configuration (options, constants, required pages)
 *   - Known bugs (the exact bugs we fixed — detects if they regress)
 *
 * Access: /wp-admin/admin.php?page=jp-diagnostics
 * Direct JSON: /wp-json/jp/v1/diagnostics (admin only)
 * Log file:    wp-content/jp-diagnostic-{timestamp}.json
 */
defined( 'ABSPATH' ) || exit;

class JP_Diagnostics {

    private static ?JP_Diagnostics $instance = null;
    private array $report = [];
    private float $start_time;

    public static function instance(): self {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action( 'admin_menu', [ $this, 'add_menu' ] );
        add_action( 'rest_api_init', [ $this, 'register_rest_route' ] );
        add_action( 'admin_post_jp_run_diagnostics',          [ $this, 'handle_export' ] );
        add_action( 'admin_post_jp_download_diagnostics',       [ $this, 'handle_download' ] );
    }

    // ── Direct browser download ──────────────────────────────────────────────

    public function handle_download(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden' );
        check_admin_referer( 'jp_download_diagnostics' );

        $report   = $this->generate();
        $json     = wp_json_encode( $report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
        $filename = 'jp-diagnostic-' . date( 'Y-m-d-His' ) . '.json';

        // Stream directly to browser — no file written to disk
        nocache_headers();
        header( 'Content-Type: application/json; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
        header( 'Content-Length: ' . strlen( $json ) );
        header( 'X-Robots-Tag: noindex' );

        echo $json;
        exit;
    }

    // ── Admin menu ────────────────────────────────────────────────────────────

    /**
     * Root-cause fix (roadmap re-audit, Part 3.3: "no wp-admin screens for
     * product configuration"). The Tools → JP Diagnostics wp-admin page was
     * a PHP-rendered view over generate() with no logic of its own — the
     * REST route below (GET /jp/v1/diagnostics) has returned the exact same
     * report since before this pass, and now has a proper SPA screen
     * (AdminDiagnosticsPage.tsx) consuming it. Decommissioning the menu
     * here, not generate()/register_rest_route()/handle_download(), so the
     * report logic and JSON-download REST path are completely untouched.
     */
    public function add_menu(): void {
        // Intentionally no-op. See docblock above.
    }

    // ── REST endpoint ─────────────────────────────────────────────────────────

    public function register_rest_route(): void {
        register_rest_route( class_exists( 'JP_Api' ) ? JP_Api::namespace_str() : 'jp/v1', '/diagnostics', [ // Batch 31: was hardcoded 'jp/v1'
            'methods'             => 'GET',
            'callback'            => [ $this, 'rest_report' ],
            'permission_callback' => fn() => current_user_can( 'manage_options' ),
        ] );
    }

    /**
     * Root-cause fix (user report: "diagnostic report link ... does not show
     * anything"): this returned the raw report array directly. Every other
     * endpoint in the app goes through JP_Api::ok(), which wraps success
     * payloads as {success: true, data: ...} — and the SPA's single shared
     * request function (apiRequest() in apiClient.ts) unconditionally does
     * `return envelope.data`, since centralizing that unwrap in one place is
     * what let every other feature module skip re-implementing it. This
     * class isn't JP_Api and has no access to that helper, so it never went
     * through the same convention — the fetch succeeded (200 OK), but
     * envelope.data was undefined because the report had no top-level
     * "data" key, so AdminDiagnosticsPage.tsx's `!data` guard correctly
     * treated it as "failed to load" and rendered its error state. Wrapping
     * the same way every other route does is the fix, not a client-side
     * special case for one endpoint.
     */
    public function rest_report(): \WP_REST_Response {
        return new \WP_REST_Response( [ 'success' => true, 'data' => $this->generate() ], 200 );
    }

    public function handle_export(): void {
        if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Forbidden' );
        check_admin_referer( 'jp_run_diagnostics' );

        $report = $this->generate();
        $json   = wp_json_encode( $report, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
        $file   = WP_CONTENT_DIR . '/jp-diagnostic-' . date( 'Y-m-d-His' ) . '.json';
        file_put_contents( $file, $json );

        wp_redirect( add_query_arg( [
            'page'    => 'jp-diagnostics',
            'saved'   => basename( $file ),
        ], admin_url( 'tools.php' ) ) );
        exit;
    }

    // ── Main report generator ─────────────────────────────────────────────────

    public function generate(): array {
        $this->start_time = microtime( true );
        $this->report     = [
            'generated_at'   => current_time( 'c' ),
            'generated_by'   => wp_get_current_user()->user_login ?? 'system',
            'plugin_version' => JP_VERSION,
            'wp_version'     => get_bloginfo( 'version' ),
            'sections'       => [],
        ];

        $this->check_environment();
        $this->check_database();
        $this->check_react_assets();
        $this->check_front_page_delivery();
        $this->check_rest_api();
        $this->check_roles();
        $this->check_crons();
        $this->check_external_services();
        $this->check_security();
        $this->check_plugin_pages();
        $this->check_theme_conflicts();
        $this->check_configuration();
        $this->check_known_bugs();
        $this->check_js_runtime();
        $this->check_css_integrity();
        $this->check_errorboundary_causes();
        $this->check_jp_config_contract();
        $this->check_dependency_management();

        // Summary
        $all_checks = [];
        foreach ( $this->report['sections'] as $section ) {
            foreach ( $section['checks'] as $check ) {
                $all_checks[] = $check['status'];
            }
        }
        $this->report['summary'] = [
            'total'    => count( $all_checks ),
            'pass'     => count( array_filter( $all_checks, fn( $s ) => $s === 'PASS' ) ),
            'warn'     => count( array_filter( $all_checks, fn( $s ) => $s === 'WARN' ) ),
            'fail'     => count( array_filter( $all_checks, fn( $s ) => $s === 'FAIL' ) ),
            'info'     => count( array_filter( $all_checks, fn( $s ) => $s === 'INFO' ) ),
            'duration' => round( microtime( true ) - $this->start_time, 3 ) . 's',
        ];

        return $this->report;
    }

    // ── Section: Environment ──────────────────────────────────────────────────

    private function check_environment(): void {
        $checks = [];

        // PHP version
        $php_ver = PHP_VERSION;
        $checks[] = $this->check(
            'PHP Version',
            version_compare( $php_ver, '8.1', '>=' ) ? 'PASS' : 'FAIL',
            "Running PHP $php_ver",
            version_compare( $php_ver, '8.1', '>=' ) ? null : 'Upgrade to PHP 8.1+. JP Core requires PHP 8.1.',
            "php-fpm --version or phpinfo()",
            "PHP $php_ver"
        );

        // MySQL version
        global $wpdb;
        $mysql_ver = $wpdb->get_var( 'SELECT VERSION()' );
        $mysql_ok  = version_compare( $mysql_ver, '8.0', '>=' );
        $checks[]  = $this->check(
            'MySQL Version',
            $mysql_ok ? 'PASS' : 'WARN',
            "MySQL $mysql_ver",
            $mysql_ok ? null : 'MySQL 8.0+ recommended for FULLTEXT search performance.',
            "SELECT VERSION()",
            $mysql_ver
        );

        // FULLTEXT indexes — required for job/company/candidate search
        $ft_tables = [ 'jp_jobs', 'jp_companies', 'jp_candidates' ];
        $ft_total  = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM information_schema.STATISTICS
             WHERE TABLE_SCHEMA = DATABASE()
             AND TABLE_NAME IN ('{$wpdb->prefix}jp_jobs','{$wpdb->prefix}jp_companies','{$wpdb->prefix}jp_candidates')
             AND INDEX_TYPE = 'FULLTEXT'"
        );
        $checks[] = $this->check(
            'FULLTEXT Indexes',
            $ft_total >= 3 ? 'PASS' : ( $ft_total > 0 ? 'WARN' : 'FAIL' ),
            "$ft_total FULLTEXT index(es) found across jp_jobs, jp_companies, jp_candidates (need 3)",
            $ft_total < 3 ? "FULLTEXT indexes missing. Plugin will attempt to add them automatically on next page load (version migration). If this persists after reload, run: ALTER TABLE {$wpdb->prefix}jp_jobs ADD FULLTEXT INDEX ft_job_search (title, description, skills_json)." : null,
            "SELECT COUNT(*) FROM information_schema.STATISTICS WHERE INDEX_TYPE='FULLTEXT'",
            "$ft_total / 3 required"
        );

        // WP version
        $wp_ver  = get_bloginfo( 'version' );
        $wp_ok   = version_compare( $wp_ver, '6.4', '>=' );
        $checks[] = $this->check(
            'WordPress Version',
            $wp_ok ? 'PASS' : 'FAIL',
            "WordPress $wp_ver",
            $wp_ok ? null : 'WordPress 6.4+ required. Update WordPress.',
            "get_bloginfo('version')",
            $wp_ver
        );

        // Memory limit
        $mem       = ini_get( 'memory_limit' );
        $mem_bytes = $this->parse_size( $mem );
        $checks[]  = $this->check(
            'PHP Memory Limit',
            $mem_bytes >= 128 * MB_IN_BYTES ? 'PASS' : 'WARN',
            "memory_limit = $mem",
            $mem_bytes < 128 * MB_IN_BYTES ? 'Set memory_limit = 256M in php.ini or wp-config.php: define("WP_MEMORY_LIMIT", "256M").' : null,
            "ini_get('memory_limit')",
            $mem
        );

        // Upload max filesize
        $upload    = ini_get( 'upload_max_filesize' );
        $post_max  = ini_get( 'post_max_size' );
        $checks[]  = $this->check(
            'Upload Limits',
            $this->parse_size( $upload ) >= 5 * MB_IN_BYTES ? 'PASS' : 'WARN',
            "upload_max_filesize=$upload, post_max_size=$post_max",
            $this->parse_size( $upload ) < 5 * MB_IN_BYTES ? 'Set upload_max_filesize=10M and post_max_size=12M for resume uploads.' : null,
            "ini_get('upload_max_filesize')",
            "$upload / $post_max"
        );

        // WP_DEBUG exposure
        $debug         = defined( 'WP_DEBUG' ) && WP_DEBUG;
        $debug_display = defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY;
        $checks[]      = $this->check(
            'WP_DEBUG_DISPLAY',
            $debug_display ? 'FAIL' : 'PASS',
            $debug_display ? 'WP_DEBUG_DISPLAY is TRUE — PHP errors shown to users' : 'WP_DEBUG_DISPLAY is off (correct for production)',
            $debug_display ? 'Set define("WP_DEBUG_DISPLAY", false) in wp-config.php. Errors are being prepended to JSON responses, breaking all API calls.' : null,
            "defined('WP_DEBUG_DISPLAY') && WP_DEBUG_DISPLAY",
            $debug_display ? 'true' : 'false'
        );

        // Max execution time
        $max_exec = (int) ini_get( 'max_execution_time' );
        $checks[] = $this->check(
            'Max Execution Time',
            $max_exec >= 30 || $max_exec === 0 ? 'PASS' : 'WARN',
            "max_execution_time = {$max_exec}s",
            $max_exec < 30 && $max_exec !== 0 ? 'Set max_execution_time = 60 for AI and export operations.' : null,
            "ini_get('max_execution_time')",
            $max_exec
        );

        // mod_rewrite / pretty permalinks
        $permalink = get_option( 'permalink_structure' );
        $checks[]  = $this->check(
            'Permalink Structure',
            ! empty( $permalink ) ? 'PASS' : 'FAIL',
            empty( $permalink ) ? 'Plain permalinks (?p=123) — React Router routing BROKEN' : "Permalink: $permalink",
            empty( $permalink ) ? 'Go to Settings → Permalinks and select "Post name". Without pretty permalinks /jobs/1/ returns 404.' : null,
            "get_option('permalink_structure')",
            $permalink ?: '(plain — BROKEN)'
        );

        $this->add_section( 'Environment', '🖥️', $checks );
    }

    // ── Section: Database ─────────────────────────────────────────────────────

    private function check_database(): void {
        global $wpdb;
        $checks = [];

        $tables = [
            'jp_jobs'              => 'Core — job listings',
            'jp_companies'         => 'Core — employer profiles',
            'jp_candidates'        => 'Core — candidate profiles',
            'jp_applications'      => 'Core — job applications',
            'jp_app_history'       => 'Core — application stage history',
            'jp_resumes'           => 'Core — uploaded resumes',
            'jp_resume_sections'   => 'Core — resume builder sections',
            'jp_message_threads'   => 'Messaging — conversation threads',
            'jp_messages'          => 'Messaging — individual messages',
            'jp_notifications'     => 'Notifications — user notifications',
            'jp_alerts'            => 'Alerts — job alert subscriptions',
            'jp_saved_jobs'        => 'Core — bookmarked jobs',
            'jp_matches'           => 'AI — candidate-job match scores',
            'jp_reviews'           => 'Social — company reviews',
            'jp_plans'             => 'Billing — subscription plans',
            'jp_subscriptions'     => 'Billing — user subscriptions',
            'jp_payments'          => 'Billing — payment records',
            'jp_skills'            => 'Taxonomy — skill definitions',
            'jp_user_skills'       => 'Taxonomy — candidate skills',
            'jp_assessments'       => 'Testing — skill assessments',
            'jp_assessment_questions' => 'Testing — assessment questions',
            'jp_sms_log'           => 'Comms — SMS delivery log',
            'jp_push_subscriptions'=> 'Push — browser push subscriptions',
            'jp_interviews'        => 'ATS — interview scheduling',
            'jp_events'            => 'Events — portal events',
            'jp_event_registrations' => 'Events — registrations',
            'jp_search_log'        => 'Analytics — search queries',
            'jp_analytics'         => 'Analytics — raw events',
            'jp_analytics_agg'     => 'Analytics — aggregated stats',
            'jp_audit_log'         => 'Security — admin audit trail',
            'jp_community_posts'   => 'Community — posts',
            'jp_community_replies' => 'Community — replies',
            'jp_user_badges'       => 'Gamification — earned badges',
            'jp_feature_flags'     => 'Config — feature flags',
        ];

        foreach ( $tables as $table => $description ) {
            $full   = $wpdb->prefix . $table;
            $exists = $wpdb->get_var( "SHOW TABLES LIKE '$full'" ) === $full;
            $rows   = $exists ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM `$full`" ) : null;

            $checks[] = $this->check(
                "Table: $table",
                $exists ? 'PASS' : 'FAIL',
                $exists ? "$description — $rows rows" : "$description — TABLE MISSING",
                $exists ? null : "Table {$full} does not exist. Deactivate and reactivate the plugin to run the installer. If it persists, check MySQL user has CREATE TABLE privilege.",
                "SHOW TABLES LIKE '$full'",
                $exists ? "{$rows} rows" : 'MISSING'
            );
        }

        // Check for critical column: interviews.outcome (not status — was a known bug)
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}jp_interviews'" ) ) {
            $has_outcome = $wpdb->get_var(
                "SELECT COUNT(*) FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                 AND TABLE_NAME = '{$wpdb->prefix}jp_interviews'
                 AND COLUMN_NAME = 'outcome'"
            );
            $has_status = $wpdb->get_var(
                "SELECT COUNT(*) FROM information_schema.COLUMNS
                 WHERE TABLE_SCHEMA = DATABASE()
                 AND TABLE_NAME = '{$wpdb->prefix}jp_interviews'
                 AND COLUMN_NAME = 'status'"
            );
            $checks[] = $this->check(
                'interviews.outcome column',
                (int) $has_outcome > 0 ? 'PASS' : 'FAIL',
                (int) $has_outcome > 0 ? "Column 'outcome' present (correct)" : "Column 'outcome' MISSING — may have 'status' instead",
                (int) $has_outcome === 0 ? "Known Bug: schema uses 'outcome' but old code used 'status'. Run: ALTER TABLE {$wpdb->prefix}jp_interviews CHANGE status outcome ENUM('pending','passed','failed','cancelled','no_show') DEFAULT 'pending'." : null,
                "SHOW COLUMNS FROM {$wpdb->prefix}jp_interviews LIKE 'outcome'",
                (int) $has_outcome > 0 ? 'present' : 'MISSING'
            );
        }

        // wpdb last_error check
        $wpdb->get_results( "SELECT 1" );
        $checks[] = $this->check(
            'Database Connection',
            empty( $wpdb->last_error ) ? 'PASS' : 'FAIL',
            empty( $wpdb->last_error ) ? 'Connection healthy' : 'DB error: ' . $wpdb->last_error,
            empty( $wpdb->last_error ) ? null : 'Check wp-config.php DB credentials. Error: ' . $wpdb->last_error,
            "SELECT 1",
            empty( $wpdb->last_error ) ? 'OK' : $wpdb->last_error
        );

        $this->add_section( 'Database', '🗄️', $checks );
    }

    // ── Section: React Assets ─────────────────────────────────────────────────

    private function check_react_assets(): void {
        $checks  = [];
        // Root-cause fix (Phase 5 cutover follow-up): this entire section was
        // still built against react-app/assets/ — the pre-cutover legacy
        // SPA's build output — while enqueue_react_assets() in class-jp-react.php
        // was already switched to serve app-dist/ (see that method's own
        // "Phase 5 cutover" docblock). react-app/assets/ is deliberately left
        // on disk as a rollback fallback and still contains real, stale files
        // (dated from before the rewrite), so every check below was silently
        // validating a directory that no real visitor's browser ever loads
        // from — capable of reporting PASS while the actual live bundle
        // (app-dist/) was broken, or FAIL while it was fine.
        $app_dir = JP_PLUGIN_DIR . 'app-dist/';
        $app_url = JP_PLUGIN_URL . 'app-dist/';

        // Versioned entry file
        $entry_files = glob( $app_dir . 'jp-app.*.js' );
        $has_versioned = ! empty( $entry_files );
        $entry_file    = $has_versioned ? basename( $entry_files[0] ) : null;
        $checks[]      = $this->check(
            'Versioned Entry File',
            $has_versioned ? 'PASS' : 'FAIL',
            $has_versioned ? "Found: $entry_file" : 'No jp-app.VERSION.js found in app-dist/',
            $has_versioned ? null : 'The versioned entry file is missing. Rebuild the React app: npm run build (from app/). The file should be named jp-app.X.Y.Z.js matching the plugin version.',
            "glob('" . JP_PLUGIN_DIR . "app-dist/jp-app.*.js')",
            $entry_file ?? 'NOT FOUND'
        );

        // Root-cause fix (gap analysis P1: "jp_react_app_version is tracked
        // but nothing verifies it against the actual deployed React build's
        // file hash/mtime — the same class of 'silent version drift' that
        // caused the theme-zip incident exists, unaddressed, for the other
        // front-end"). The check above only confirmed *a* versioned file
        // exists — it never compared the version number embedded in that
        // filename against the running plugin's JP_VERSION, so a stale
        // React build (rebuilt/deployed less often than the PHP plugin,
        // which is a realistic release-process gap for a two-front-end
        // product) would still show "PASS" here even while badly out of
        // sync. Confirmed via the actual build shipped in this codebase:
        // the file on disk is jp-app.6.10.2.js while JP_VERSION is well
        // past that — this is not a hypothetical, it's the live state.
        // Regex updated alongside vite.config.ts's entryFileNames change:
        // the entry file now also carries a trailing Rollup content hash
        // (jp-app.<version>-<hash>.js), added after live evidence showed
        // the fronting CDN caching this file by path and ignoring ?ver=
        // entirely — see class-jp-react.php::maybe_write_asset_htaccess()
        // for the full incident. The hash segment isn't captured; only
        // the version portion matters for this comparison.
        if ( $has_versioned && preg_match( '/^jp-app\.([\d.]+)-[A-Za-z0-9_]+\.js$/', $entry_file, $m ) ) {
            $bundle_version = $m[1];
            $in_sync        = $bundle_version === JP_VERSION;
            $checks[]       = $this->check(
                'React Bundle Version Matches Plugin',
                $in_sync ? 'PASS' : 'WARN',
                $in_sync
                    ? "React bundle ($bundle_version) matches plugin (" . JP_VERSION . ')'
                    : "React bundle is v$bundle_version but the plugin is v" . JP_VERSION . ' — these can legitimately be released independently, but confirm this isn\'t a forgotten React rebuild before treating any front-end bug report as a plugin issue.',
                $in_sync ? null : 'Rebuild and redeploy the React app (npm run build) so jp-app.' . JP_VERSION . '.js exists, or confirm the version skew is intentional for this release.',
                "preg_match on '" . JP_PLUGIN_DIR . "app-dist/{$entry_file}' vs JP_VERSION",
                "$bundle_version vs " . JP_VERSION
            );
        }

        // OLD jp-app.js (should NOT exist — causes CDN double-load)
        $old_entry = $app_dir . 'jp-app.js';
        $checks[]  = $this->check(
            'Old jp-app.js Absent',
            ! file_exists( $old_entry ) ? 'PASS' : 'FAIL',
            file_exists( $old_entry ) ? 'jp-app.js EXISTS — will cause TWO React instances if CDN serves both' : 'jp-app.js absent (correct)',
            file_exists( $old_entry ) ? 'Delete ' . $old_entry . '. The old unversioned file causes the CDN to serve two copies of React simultaneously, breaking all hooks (React error #321).' : null,
            "file_exists('{$old_entry}')",
            file_exists( $old_entry ) ? 'EXISTS — DELETE IT' : 'absent (correct)'
        );

        // CSS file
        $css_path = $app_dir . 'jp-app.css';
        $css_size = file_exists( $css_path ) ? round( filesize( $css_path ) / 1024, 1 ) . 'KB' : 'MISSING';
        $checks[]  = $this->check(
            'jp-app.css',
            file_exists( $css_path ) ? 'PASS' : 'FAIL',
            file_exists( $css_path ) ? "Present ($css_size)" : 'jp-app.css missing',
            file_exists( $css_path ) ? null : 'CSS file missing. Rebuild React app. Without it, all styling is lost.',
            "file_exists('{$css_path}')",
            $css_size
        );

        // Root-cause fix (Phase 5 cutover follow-up): the two checks below
        // used to look for 'vendor-react*.js' and 'rolldown-runtime*.js' —
        // chunk names produced by the LEGACY build's bundler configuration.
        // The rewrite's Vite config chunks differently (shared libs like
        // React/TanStack Query ship as their own hashed chunks under
        // app-dist/chunks/, e.g. jsx-runtime-*.js, useQuery-*.js — verified
        // directly against this codebase's own build output) and produces
        // no file matching either literal pattern at all, so a naive
        // directory swap would have flipped these from a true PASS (against
        // the wrong, frozen directory) to a false FAIL (against the right
        // one, for a naming convention that was never part of the new
        // build's contract). Replaced with a check for the actual shared
        // chunks directory the new build produces instead.
        $chunks_dir    = $app_dir . 'chunks/';
        $shared_chunks = glob( $chunks_dir . '*.js' );
        $has_chunks    = ! empty( $shared_chunks );
        $checks[]      = $this->check(
            'Shared/vendor chunks directory',
            $has_chunks ? 'PASS' : 'FAIL',
            $has_chunks ? 'Found ' . count( $shared_chunks ) . ' chunk files in app-dist/chunks/' : 'app-dist/chunks/ is missing or empty',
            $has_chunks ? null : 'No chunk files found in app-dist/chunks/. Rebuild the React app (npm run build from app/) — every lazy-loaded page and shared library (React, TanStack Query, etc.) ships as a separate chunk there.',
            "glob('{$chunks_dir}*.js')",
            $has_chunks ? count( $shared_chunks ) . ' files' : 'MISSING'
        );

        // Total chunk count. Threshold is the number of lazy() page imports
        // in app/src/routes/router.tsx at the time of this fix (58) — each
        // lazy-loaded page produces at least one chunk, so the real chunk
        // count (which also includes shared library chunks) should never
        // fall below that floor. If router.tsx gains/loses lazy routes this
        // threshold should be revisited; it is not derived automatically.
        $n_chunks = count( $shared_chunks ?? [] );
        $checks[] = $this->check(
            'JS Chunk Count',
            $n_chunks >= 58 ? 'PASS' : ( $n_chunks > 0 ? 'WARN' : 'FAIL' ),
            "$n_chunks JS files in app-dist/chunks/",
            $n_chunks < 58 ? "Expected at least 58 chunk files (one per lazy-loaded route in router.tsx, plus shared library chunks), found $n_chunks. Some page chunks may be missing. Rebuild the React app." : null,
            "count(glob('{$chunks_dir}*.js'))",
            $n_chunks
        );

        // Check entry file uses relative imports into ./chunks/ (not an
        // absolute /chunks/ or /assets/ path that would resolve to the
        // domain root instead of the plugin directory).
        if ( $has_versioned && file_exists( $entry_files[0] ) ) {
            $entry_content = file_get_contents( $entry_files[0] );
            $has_relative  = str_contains( $entry_content, './chunks/' );
            $has_absolute  = str_contains( $entry_content, '"/chunks/' ) || str_contains( $entry_content, '"/app-dist/chunks/' );
            $checks[]      = $this->check(
                'Chunk Paths Relative',
                $has_relative && ! $has_absolute ? 'PASS' : 'FAIL',
                $has_absolute ? 'ABSOLUTE paths found (/chunks/...) — CDN will 404 all chunks' : ( $has_relative ? 'Relative paths found (./chunks/...) — correct' : 'No ./chunks/ references found in entry file — cannot confirm chunk path style' ),
                $has_absolute ? 'Rebuild with base: "./" in vite.config.ts. Absolute chunk paths resolve to the domain root, not the plugin directory, causing 404 on every lazy-loaded page.' : ( $has_relative ? null : 'Investigate manually — the entry file did not contain the expected ./chunks/ reference pattern at all.' ),
                "file_get_contents and check for './chunks/' vs '/chunks/'",
                $has_absolute ? 'ABSOLUTE — BROKEN' : ( $has_relative ? 'relative — OK' : 'UNKNOWN' )
            );
        }

        // .htaccess cache control
        $htaccess = JP_PLUGIN_DIR . 'app-dist/.htaccess';
        $checks[] = $this->check(
            '.htaccess Cache Control',
            file_exists( $htaccess ) ? 'PASS' : 'WARN',
            file_exists( $htaccess ) ? 'Cache-Control headers configured' : '.htaccess missing in app-dist/',
            file_exists( $htaccess ) ? null : 'Without .htaccess, CDN caches jp-app.js indefinitely. After each deploy, old cached entry file serves stale chunk references → 404 on all lazy pages.',
            "file_exists('{$htaccess}')",
            file_exists( $htaccess ) ? 'present' : 'MISSING'
        );

        $this->add_section( 'React Assets', '⚛️', $checks );
    }

    // ── Section: Front Page Delivery & Edge/CDN Interception ────────────────────
    //
    // Root-cause fix (support-scenario audit): every check in this file so far
    // assumed a request that leaves WordPress (wp_remote_get against this same
    // site) actually reaches this site's PHP. On a CDN-fronted install that is
    // not guaranteed — an edge/proxy layer can intercept a request BEFORE it
    // ever reaches WordPress and answer it directly (HTTP 200, a cached or
    // "SPA fallback" HTML page) with no trace in this site's own logs. Two
    // concrete incidents this exact class of bug produced on a live install:
    // (1) WordPress's Reading Settings never pointed at the SPA's portal page,
    // so "/" rendered the default theme's blog index instead of the app — see
    // JP_React::maybe_fix_front_page(), which self-heals this but previously
    // had no visible diagnostic of its own; (2) a CDN edge layer serving the
    // homepage's HTML (200 OK) for /wp-json/jp/v1/config, which the React app
    // then fails to json_decode() and surfaces as a raw "Unexpected token '<'"
    // browser error with no actionable information for whoever is debugging
    // it. Both are now detected here with a specific, distinguishing message —
    // "WordPress itself is broken" and "something in front of WordPress is
    // intercepting this request" are different problems with different fixes
    // (a code/config change vs. a CDN/hosting dashboard change), and treating
    // them as the same failure wastes time chasing the wrong one.

    private function check_front_page_delivery(): void {
        $checks = [];

        // ── Reading Settings vs. the resolved portal page ──────────────────
        // JP_React::maybe_fix_front_page() self-heals this on every 'init',
        // so in steady state this should always PASS; a FAIL here means the
        // self-heal hasn't run yet (e.g. pages not created) or something
        // external (a theme switch, a Reading Settings misclick, a
        // migration) reset it since the last request — the self-heal will
        // correct it on the very next front-end page load, but flagging it
        // here makes that visible instead of silently invisible.
        $portal_page = null;
        if ( class_exists( 'JP_React' ) ) {
            $portal_page = JP_React::instance()->diagnostics_get_portal_page();
        }
        $show_on_front = get_option( 'show_on_front' );
        $page_on_front = (int) get_option( 'page_on_front' );

        if ( ! $portal_page ) {
            $checks[] = $this->check(
                'Reading Settings → Portal Page',
                'WARN',
                'No portal page could be resolved yet (jp_portal_page_id unset and no page uses the React template or [jp_app] shortcode).',
                'Visit the plugin\'s pages once (or deactivate/reactivate) so JP_Activator::create_pages() runs, or manually add [jp_app] to a published page.',
                'JP_React::instance()->diagnostics_get_portal_page()',
                'none resolved'
            );
        } else {
            $correctly_configured = ( $show_on_front === 'page' && $page_on_front === $portal_page->ID );
            $checks[] = $this->check(
                'Reading Settings → Portal Page',
                $correctly_configured ? 'PASS' : 'WARN',
                $correctly_configured
                    ? "Site front page is \"{$portal_page->post_title}\" (ID {$portal_page->ID}) — the SPA renders at \"/\"."
                    : "show_on_front=\"$show_on_front\", page_on_front=$page_on_front, but the resolved portal page is ID {$portal_page->ID} (\"{$portal_page->post_title}\").",
                $correctly_configured ? null : 'Mismatch detected. JP_React::maybe_fix_front_page() runs on every "init" and will correct this automatically on the next front-end request — reload the homepage, then re-run this diagnostic. If it still shows WARN after that, the portal page itself may be missing/unpublished.',
                "get_option('show_on_front') / get_option('page_on_front') vs resolved portal page ID",
                $correctly_configured ? 'matches' : "front={$page_on_front} vs portal={$portal_page->ID}"
            );
        }

        // ── End-to-end: does "/" actually deliver the SPA's mount point? ───
        // This is deliberately independent of the option check above — it
        // catches the same symptom (default theme/blog showing instead of
        // the app) regardless of WHY it's happening, including causes the
        // option check can't see (a caching layer serving a stale page, a
        // theme's front-page.php template overriding page_on_front, etc.).
        $home_response = wp_remote_get( home_url( '/' ), [ 'timeout' => 8, 'sslverify' => false ] );
        $home_diag     = $this->diagnose_response( $home_response, 'id="jp-root"' );
        $checks[]      = $this->check(
            'Homepage delivers the SPA',
            $home_diag['status'],
            $home_diag['message'],
            $home_diag['solution'],
            "GET " . home_url( '/' ) . " → look for id=\"jp-root\"",
            $home_diag['value']
        );

        $this->add_section( 'Front Page Delivery', '🏠', $checks );
    }

    /**
     * Shared root-cause analyzer for any "we expected X, WordPress answered,
     * but the content is wrong" symptom. Distinguishes four categories that
     * each need a completely different fix, instead of lumping them all into
     * a generic "FAIL — unexpected response":
     *
     *   1. Request never reached WordPress (transport error / timeout) —
     *      hosting/network/firewall problem, not a WordPress or plugin bug.
     *   2. WordPress answered with a real HTTP error status (4xx/5xx) —
     *      an actual WordPress/plugin-level failure worth debugging in PHP.
     *   3. WordPress answered 200, but the body doesn't contain what was
     *      expected AND looks like HTML (starts with "<!doctype"/"<html",
     *      or Content-Type is text/html) — the single most common way an
     *      edge/CDN/cache layer's "serve the homepage for anything
     *      unrecognized" fallback rule silently swallows an API or SPA
     *      request before WordPress's own routing ever runs on it. This is
     *      infrastructure-level, not something a PHP code change can fix.
     *   4. WordPress answered 200 with the expected content — genuinely OK.
     *
     * @param array|\WP_Error $response      Result of wp_remote_get().
     * @param string          $expect_needle A string that must appear in the
     *                                       body for the response to count as
     *                                       "the real thing" (e.g. a JSON key
     *                                       name, or the SPA's mount-point div).
     */
    private function diagnose_response( $response, string $expect_needle ): array {
        if ( is_wp_error( $response ) ) {
            return [
                'status'   => 'FAIL',
                'message'  => 'Request never reached the server: ' . $response->get_error_message(),
                'solution' => 'This is a network/DNS/firewall/timeout problem between this server and the public URL — not a WordPress or plugin bug. Check outbound connectivity from the server, and whether a firewall blocks the server from reaching its own public hostname (a common "loopback" restriction on some hosts).',
                'value'    => 'transport error',
            ];
        }

        $status_code  = wp_remote_retrieve_response_code( $response );
        $content_type = wp_remote_retrieve_header( $response, 'content-type' );
        $body         = wp_remote_retrieve_body( $response );
        $body_trimmed = ltrim( $body );
        $looks_like_html = (
            stripos( $body_trimmed, '<!doctype' ) === 0
            || stripos( $body_trimmed, '<html' ) === 0
            || ( is_string( $content_type ) && stripos( $content_type, 'text/html' ) !== false )
        );
        $has_expected = str_contains( $body, $expect_needle );

        if ( $status_code >= 400 ) {
            return [
                'status'   => 'FAIL',
                'message'  => "WordPress answered with HTTP $status_code.",
                'solution' => "A real WordPress-level error (permalinks, .htaccess/server rewrite rules, a fatal PHP error, or a security plugin blocking the request). Check this site's PHP error log for the same timestamp.",
                'value'    => "HTTP $status_code",
            ];
        }

        if ( $has_expected ) {
            return [
                'status'   => 'PASS',
                'message'  => "HTTP $status_code — expected content found.",
                'solution' => null,
                'value'    => "HTTP $status_code, OK",
            ];
        }

        // Root-cause fix (confirmed via a live diagnostic run: multiple
        // endpoints — including the homepage itself, not just REST routes —
        // all came back "HTTP 200, but expected content not found. First
        // 120 chars: " with NOTHING after that colon, i.e. a genuinely empty
        // body). That is a materially different, more specific failure than
        // "wrong content" or "HTML fallback page": a truly empty 200 response
        // across unrelated endpoint types (a static-ish homepage AND REST
        // JSON routes) most commonly means either (a) this server is
        // self-serializing on its own loopback request — wp_remote_get()
        // here is calling back into this exact site, and if PHP-FPM/the web
        // server has very few workers, the one handling THIS diagnostics
        // page load can starve the loopback request of a free worker until
        // it times out, at which point a proxy/CDN in front of the origin
        // sometimes answers with an empty 200 rather than a clear error; or
        // (b) a PHP fatal error terminated the target request AFTER it had
        // already sent a 200 status header but before writing any body —
        // consistent with this plugin's own known display_errors
        // suppression on REST requests (see the "PHP Errors Not Injected
        // Into JSON" check) hiding the fatal's error text along with the
        // warning text it was designed to hide. Distinguished from the HTML
        // fallback case below because it has no HTML markup or text/html
        // Content-Type at all — there is nothing to look at.
        if ( '' === trim( $body ) ) {
            return [
                'status'   => 'FAIL',
                'message'  => "HTTP $status_code with a completely EMPTY response body (0 bytes of usable content).",
                'solution' => 'ROOT CAUSE (two candidates, in order of likelihood): (1) Loopback self-serialization/timeout — this diagnostic page makes several server-to-itself HTTP requests in a row; on hosting with very few PHP-FPM/PHP-CGI workers, a request calling back into the SAME site can starve behind the worker already running this diagnostics page and time out, with the CDN/proxy in front answering an empty 200 instead of a clear timeout error. Ask your host to confirm the PHP worker/process limit and whether "loopback requests" (WordPress calling its own public URL) are known to be slow or blocked on this plan. (2) A PHP fatal error is terminating the request AFTER headers were already sent as 200 but before any output — this plugin already suppresses error TEXT on REST requests (see "PHP Errors Not Injected Into JSON" below), which would hide a fatal error the same way it hides a warning. Check the PHP error log for a fatal at the same timestamp as this report\'s generated_at.',
                'value'    => "HTTP $status_code, EMPTY BODY (0 bytes)",
            ];
        }

        if ( $looks_like_html ) {
            return [
                'status'   => 'FAIL',
                'message'  => "HTTP $status_code, but the body looks like a generic HTML page (Content-Type: " . ( $content_type ?: 'unknown' ) . '), not the expected content. First 120 chars: ' . substr( $body_trimmed, 0, 120 ),
                'solution' => 'ROOT CAUSE: something in front of WordPress — a CDN edge rule, reverse proxy, or full-page cache — is intercepting this request and answering with a generic/cached page (commonly an "SPA fallback: serve index/home for any unrecognized path" rule) BEFORE it reaches WordPress. WordPress and this plugin are not the problem here; check your CDN/hosting dashboard for a catch-all rewrite rule and exclude /wp-json/ (and any other non-static paths this site needs to reach WordPress for) from it.',
                'value'    => "HTTP $status_code, HTML fallback suspected",
            ];
        }

        return [
            'status'   => 'FAIL',
            'message'  => "HTTP $status_code, but expected content not found. First 120 chars: " . substr( $body_trimmed, 0, 120 ),
            'solution' => 'Response reached WordPress and returned 200, but the content is neither the expected result nor recognizable HTML fallback — inspect the raw response body directly to determine the cause.',
            'value'    => "HTTP $status_code, unexpected body",
        ];
    }

    // ── Section: REST API ─────────────────────────────────────────────────────

    private function check_rest_api(): void {
        $checks    = [];
        // Batch 31: this used to be a second hardcoded 'jp/v1' literal —
        // meaning if JP_Api's real namespace ever drifted (a bug, or a
        // future v2 migration done incompletely), THIS diagnostic would
        // keep reporting PASS by comparing the wrong namespace against
        // itself instead of against the app's actual configuration. Now
        // sourced from the single constant so a drift is actually caught.
        $namespace = class_exists( 'JP_Api' ) ? JP_Api::namespace_str() : 'jp/v1';

        // Check REST API is enabled
        $rest_url = rest_url( $namespace );
        $checks[] = $this->check(
            'REST API URL',
            ! empty( $rest_url ) ? 'PASS' : 'FAIL',
            "REST base: $rest_url",
            empty( $rest_url ) ? 'REST API URL could not be generated. Check permalink settings.' : null,
            "rest_url('jp/v1')",
            $rest_url
        );

        // Test /health endpoint
        // Root-cause fix: this used to only check status_code === 200, which
        // cannot distinguish "WordPress itself is broken" from "something in
        // front of WordPress (CDN edge, reverse proxy, full-page cache)
        // intercepted this request and answered 200 with unrelated HTML" —
        // the exact failure mode a live install hit on /config (see
        // check_front_page_delivery()'s docblock). diagnose_response() tells
        // these apart and gives a different, actionable fix for each.
        // Root-cause fix: added an in-process dispatch alongside the network
        // check — rest_do_request() runs the SAME route callback WordPress
        // itself would run for a real request, but entirely in-PHP via
        // rest_get_server()->dispatch(), with no HTTP/loopback round trip at
        // all. This is immune to the self-loopback starvation that produced
        // false "empty body" failures across every network-based REST check
        // in a live diagnostic run, while still exercising the real
        // permission_callback/callback chain (unlike calling a bare PHP
        // function directly, which would skip WordPress's own REST
        // dispatch/validation layer entirely).
        $in_process_health = rest_do_request( new \WP_REST_Request( 'GET', "/$namespace/health" ) );
        $in_process_ok     = ! is_wp_error( $in_process_health ) && $in_process_health->get_status() === 200;
        $checks[]          = $this->check(
            'GET /health (in-process, no network)',
            $in_process_ok ? 'PASS' : 'FAIL',
            $in_process_ok ? 'rest_do_request() returned HTTP 200' : 'rest_do_request() did not return HTTP 200 — status: ' . ( is_wp_error( $in_process_health ) ? $in_process_health->get_error_message() : $in_process_health->get_status() ),
            $in_process_ok ? null : 'This ran entirely in-process (no network involved), so a failure here is a genuine route/permission/handler bug — check the health route\'s callback in class-jp-api.php directly.',
            "rest_do_request(new WP_REST_Request('GET', '/$namespace/health'))",
            $in_process_ok ? 'HTTP 200 ✓' : 'FAILED'
        );

        $health_url = rest_url( "$namespace/health" );
        $response   = wp_remote_get( $health_url, [ 'timeout' => 5, 'sslverify' => false ] );
        $diag       = $this->diagnose_response( $response, '"status"' );
        $health_solution = $diag['solution'];
        if ( $diag['status'] !== 'PASS' && $in_process_ok ) {
            $health_solution = "The in-process dispatch above PASSED, meaning the route itself works correctly — this network check failing anyway most likely means this diagnostics page's own loopback request was starved, not a real bug (see this section's other checks for the full explanation). Confirm by opening $health_url directly in a browser tab.";
        }
        $checks[]   = $this->check(
            'GET /health (over network)',
            $diag['status'],
            $diag['message'],
            $health_solution,
            "wp_remote_get('$health_url')",
            $diag['value']
        );

        // Test /jobs endpoint (public) — in-process first, network second
        $in_process_jobs_req = new \WP_REST_Request( 'GET', "/$namespace/jobs" );
        $in_process_jobs_req->set_param( 'per_page', 1 );
        $in_process_jobs   = rest_do_request( $in_process_jobs_req );
        $in_process_jobs_data = ! is_wp_error( $in_process_jobs ) ? $in_process_jobs->get_data() : null;
        $in_process_jobs_ok   = ! is_wp_error( $in_process_jobs ) && $in_process_jobs->get_status() === 200 && isset( $in_process_jobs_data['data']['jobs'] );
        $checks[] = $this->check(
            'GET /jobs (in-process, no network)',
            $in_process_jobs_ok ? 'PASS' : 'FAIL',
            $in_process_jobs_ok ? 'rest_do_request() returned data.jobs correctly' : 'rest_do_request() did not return the expected data.jobs shape',
            $in_process_jobs_ok ? null : 'This ran entirely in-process (no network involved), so this is a genuine route/handler bug — check the jobs list route\'s callback directly.',
            "rest_do_request(new WP_REST_Request('GET', '/$namespace/jobs'))",
            $in_process_jobs_ok ? 'OK — data.jobs present' : 'FAILED'
        );

        $jobs_url = rest_url( "$namespace/jobs" );
        $response = wp_remote_get( $jobs_url . '?per_page=1', [ 'timeout' => 5, 'sslverify' => false ] );
        $diag     = $this->diagnose_response( $response, '"jobs"' );
        $jobs_solution = $diag['solution'];
        if ( $diag['status'] !== 'PASS' && $in_process_jobs_ok ) {
            $jobs_solution = "The in-process dispatch above PASSED, meaning the route itself works correctly — this network check failing anyway most likely means this diagnostics page's own loopback request was starved, not a real bug. Confirm by opening $jobs_url?per_page=1 directly in a browser tab.";
        }
        $checks[] = $this->check(
            'GET /jobs (over network)',
            $diag['status'],
            $diag['message'],
            $jobs_solution,
            "GET $jobs_url?per_page=1",
            $diag['value']
        );

        // Count registered routes
        $routes      = rest_get_server()->get_routes( $namespace );
        $route_count = count( $routes );
        $checks[]    = $this->check(
            'Registered Route Count',
            $route_count >= 60 ? 'PASS' : 'WARN',
            "$route_count routes registered under jp/v1",
            $route_count < 60 ? "Only $route_count routes found, expected 60+. Some API endpoints are missing. Check class-jp-api.php loaded correctly." : null,
            "count(rest_get_server()->get_routes('jp/v1'))",
            $route_count
        );

        // Check /auth/token (login endpoint) exists
        $has_auth = isset( $routes[ "/$namespace/auth/token" ] );
        $checks[] = $this->check(
            '/auth/token route',
            $has_auth ? 'PASS' : 'FAIL',
            $has_auth ? 'Login endpoint registered' : '/auth/token NOT REGISTERED',
            $has_auth ? null : 'Login endpoint missing. JP_Api class not instantiated. Check jp_init() in jp-core.php.',
            "isset(routes['/jp/v1/auth/token'])",
            $has_auth ? 'registered' : 'MISSING'
        );

        // Check nonce is injected into JP_CONFIG.
        // Root-cause fix: this is the exact endpoint (rest_url('jp/v1/config'))
        // that AuthContext.tsx's fetchBootstrapConfig() calls on every SPA page
        // load — a live install hit the "edge/CDN answers 200 with the
        // homepage's HTML instead of JSON" failure mode specifically here,
        // surfaced to end users as a raw, meaningless "Unexpected token '<'"
        // browser error. diagnose_response() catches that case explicitly
        // (previously this check would just json_decode('{}') on any
        // non-JSON body and silently report "nonce MISSING" with no
        // indication that the request was ever hijacked before reaching PHP).
        // Root-cause fix: this used to be the ONLY way this contract was
        // verified — a network loopback round trip. A live run showed that
        // round trip coming back as HTTP 200 with a fully empty body, on
        // /config AND unrelated endpoints AND the homepage simultaneously —
        // the signature of THIS SERVER'S OWN request queue self-serializing
        // (a request calling back into the same site starving behind the
        // one already running this diagnostics page), not a real bug in the
        // config contract itself. The authoritative check is now the
        // in-process one directly below (no network round trip, cannot be
        // affected by loopback contention); the network check is kept
        // because it is the only way to catch something the in-process call
        // cannot see — a CDN/proxy/cache rewriting the request before it
        // reaches WordPress at all (the ORIGINAL real bug a user hit on
        // this exact endpoint). When the two disagree, that disagreement
        // itself is diagnostic: in-process PASS + network FAIL = almost
        // certainly a loopback artifact of running this page, not a live
        // user-facing bug (confirm by opening the URL in a real browser
        // tab); in-process FAIL = a genuine code bug regardless of network
        // conditions.
        $in_process_config  = class_exists( 'JP_React' ) ? JP_React::instance()->diagnostics_get_config() : [];
        $in_process_ok      = ! empty( $in_process_config['nonce'] ?? '' ) && ! empty( $in_process_config['api_url'] ?? '' );
        $checks[]           = $this->check(
            'JP_CONFIG contract (in-process, no network)',
            $in_process_ok ? 'PASS' : 'FAIL',
            $in_process_ok
                ? "nonce and api_url present — api_url = {$in_process_config['api_url']}"
                : 'nonce or api_url missing from JP_React::build_config()\'s return value — a genuine code bug, not a network/loopback issue.',
            $in_process_ok ? null : 'build_config() is not returning nonce and/or api_url. Check JP_React::build_config() in class-jp-react.php directly — this result did not go over the network, so hosting/CDN cannot be the cause.',
            "JP_React::instance()->diagnostics_get_config()",
            $in_process_ok ? 'contract OK' : 'contract BROKEN'
        );

        $config_url = rest_url( "$namespace/config" );
        $response   = wp_remote_get( $config_url, [ 'timeout' => 5, 'sslverify' => false ] );
        $diag       = $this->diagnose_response( $response, '"nonce"' );
        $network_solution = $diag['solution'];
        if ( $diag['status'] !== 'PASS' && $in_process_ok ) {
            $network_solution = 'The in-process check above PASSED, meaning the config contract itself is correct — this network-loopback check failing anyway most likely means THIS diagnostics page\'s own request starved its own loopback call (see this section\'s docblock), not a real bug. Confirm by opening ' . $config_url . ' directly in a browser tab; if that shows real JSON, this row can be disregarded. If it does NOT show real JSON, see the original solution: ' . $network_solution;
        }
        $checks[]   = $this->check(
            'JP_CONFIG endpoint (GET /config, over network)',
            $diag['status'],
            $diag['message'],
            $network_solution,
            "GET $config_url → check nonce + api_url",
            $diag['value']
        );

        $this->add_section( 'REST API', '🔌', $checks );
    }

    // ── Section: Roles ────────────────────────────────────────────────────────

    private function check_roles(): void {
        $checks = [];
        $roles  = [
            'jp_job_seeker'   => 'jp_apply_jobs',
            'jp_recruiter'    => 'jp_post_jobs',
            'jp_staff'        => 'jp_moderate_content',
            'jp_team_manager' => 'jp_manage_team',
            'jp_admin_manager'=> 'jp_manage_users',
        ];

        foreach ( $roles as $role_slug => $key_cap ) {
            $role    = get_role( $role_slug );
            $exists  = ! is_null( $role );
            $has_cap = $exists && ! empty( $role->capabilities[ $key_cap ] );
            $checks[] = $this->check(
                "Role: $role_slug",
                $exists && $has_cap ? 'PASS' : 'FAIL',
                $exists ? ( $has_cap ? "Exists with $key_cap capability" : "Exists but MISSING $key_cap capability" ) : 'Role does not exist',
                ! $exists ? "Role $role_slug not registered. Deactivate and reactivate plugin to recreate roles." :
                    ( ! $has_cap ? "Role $role_slug missing $key_cap. Run JP_Roles::create_roles() or reinstall." : null ),
                "get_role('$role_slug')",
                $exists ? ( $has_cap ? 'OK' : "MISSING cap: $key_cap" ) : 'MISSING'
            );
        }

        // Administrator has JP caps
        $admin      = get_role( 'administrator' );
        $admin_cap  = $admin && ! empty( $admin->capabilities['jp_system_config'] );
        $checks[]   = $this->check(
            'Administrator JP Caps',
            $admin_cap ? 'PASS' : 'WARN',
            $admin_cap ? 'administrator has jp_system_config' : 'administrator MISSING jp_system_config',
            $admin_cap ? null : 'Administrator role missing JP capabilities. Reinstall or call JP_Roles::create_roles().',
            "get_role('administrator')->capabilities['jp_system_config']",
            $admin_cap ? 'present' : 'MISSING'
        );

        $this->add_section( 'Roles & Capabilities', '👥', $checks );
    }

    // ── Section: Cron Jobs ────────────────────────────────────────────────────

    private function check_crons(): void {
        $checks = [];
        $crons  = [
            'jp_expire_jobs'             => 'hourly',
            'jp_flush_job_views'         => 'every_15_min',
            'jp_dispatch_instant_alerts' => 'every_15_min',
            'jp_dispatch_daily_alerts'   => 'daily',
            'jp_dispatch_weekly_alerts'  => 'weekly',
            'jp_update_match_scores'     => 'daily',
            'jp_aggregate_analytics'     => 'hourly',
            'jp_expire_subscriptions'    => 'daily',
            'jp_cleanup_sessions'        => 'daily',
            'jp_cleanup_old_logs'        => 'weekly',
            'jp_backup_database'         => 'daily',
        ];

        $all_crons = _get_cron_array();

        foreach ( $crons as $hook => $expected_interval ) {
            $found    = false;
            $next_run = null;
            $interval = null;

            foreach ( $all_crons as $timestamp => $cron_hooks ) {
                if ( isset( $cron_hooks[ $hook ] ) ) {
                    $found    = true;
                    $next_run = $timestamp;
                    $schedule = reset( $cron_hooks[ $hook ] );
                    $interval = $schedule['schedule'] ?? 'unknown';
                    break;
                }
            }

            $next_human = $found ? human_time_diff( time(), $next_run ) . ' from now' : 'not scheduled';
            $checks[]   = $this->check(
                "Cron: $hook",
                $found ? 'PASS' : 'FAIL',
                $found ? "Scheduled ($interval), next: $next_human" : 'NOT SCHEDULED',
                // Root-cause fix: this message previously told the admin to
                // deactivate/reactivate — a workaround, not a fix, for a real
                // bug (JP_Activator::activate() never calls
                // JP_Cron::schedule_all(), and set_defaults() sets
                // jp_installed_version = JP_VERSION during activation itself,
                // so jp-core.php's version-bump self-heal never sees a
                // mismatch on a fresh install and never runs either — crons
                // are simply never scheduled until an actual future version
                // bump). JP_React now self-heals this on every 'init' by
                // calling the idempotent JP_Cron::schedule_all() directly, so
                // a FAIL here on the NEXT front-end page load (not this same
                // admin request, since 'init' priority 30 in JP_React runs on
                // front-end and admin requests alike, but this diagnostics
                // page itself is one such request — reload this page once
                // more) means schedule_all() itself is failing, not that
                // reactivation is needed.
                $found ? null : "Cron $hook not scheduled. Root cause: JP_Activator::activate() never called JP_Cron::schedule_all(), and the version-bump self-heal in jp-core.php never fires on a fresh install (jp_installed_version is set to the current version during activation itself). JP_React now calls the idempotent JP_Cron::schedule_all() on every 'init' as a self-heal — reload this diagnostics page once; if it still shows NOT SCHEDULED after that, check the PHP error log for 'JP_Cron: unknown interval' (a genuinely broken custom interval registration, not a scheduling-timing issue).",
                "_get_cron_array() → search for '$hook'",
                $found ? "$interval / $next_human" : 'MISSING'
            );
        }

        // WP-Cron enabled
        $cron_disabled = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
        $checks[] = $this->check(
            'WP-Cron Enabled',
            ! $cron_disabled ? 'PASS' : 'WARN',
            $cron_disabled ? 'DISABLE_WP_CRON = true — crons will not auto-run' : 'WP-Cron is active',
            $cron_disabled ? 'DISABLE_WP_CRON is set. Ensure server cron runs: */15 * * * * wget -q -O - https://yoursite.com/wp-cron.php?doing_wp_cron >/dev/null 2>&1' : null,
            "defined('DISABLE_WP_CRON') && DISABLE_WP_CRON",
            $cron_disabled ? 'disabled' : 'enabled'
        );

        $this->add_section( 'Cron Jobs', '⏰', $checks );
    }

    // ── Section: External Services ────────────────────────────────────────────

    private function check_external_services(): void {
        $checks = [];

        // OpenAI
        $openai_key = defined( 'JP_OPENAI_KEY' ) ? JP_OPENAI_KEY : '';
        $checks[]   = $this->check(
            'OpenAI API Key',
            ! empty( $openai_key ) ? 'PASS' : 'INFO',
            ! empty( $openai_key ) ? 'JP_OPENAI_KEY defined (length: ' . strlen( $openai_key ) . ')' : 'Not configured — AI features disabled',
            null,
            "defined('JP_OPENAI_KEY') && JP_OPENAI_KEY",
            ! empty( $openai_key ) ? 'configured' : 'not set (optional)'
        );

        if ( ! empty( $openai_key ) ) {
            $response = wp_remote_get( 'https://api.openai.com/v1/models', [
                'timeout' => 5,
                'headers' => [ 'Authorization' => 'Bearer ' . $openai_key ],
                'sslverify' => true,
            ] );
            $code     = is_wp_error( $response ) ? 0 : wp_remote_retrieve_response_code( $response );
            $checks[] = $this->check(
                'OpenAI Reachability',
                $code === 200 ? 'PASS' : 'FAIL',
                $code === 200 ? 'Connected to api.openai.com' : "HTTP $code" . ( is_wp_error( $response ) ? ': ' . $response->get_error_message() : '' ),
                $code !== 200 ? "Cannot reach OpenAI API (HTTP $code). Check API key validity, billing status, and server outbound HTTPS." : null,
                "wp_remote_get('https://api.openai.com/v1/models')",
                "HTTP $code"
            );
        }

        // Razorpay
        // Root-cause fix (batch 11 — see jp-core.php's jp_razorpay_key_id()/
        // jp_razorpay_key_secret() docblock). This used to read ONLY the
        // wp-config.php constants, which — now that the actual payment code
        // (class-jp-payments.php) also accepts the jp_razorpay_key_id/
        // jp_razorpay_key_secret options as a fallback — made this check
        // report a false "Not configured — payments disabled" for any
        // install that configured Razorpay through the live admin settings
        // screen instead of hand-editing wp-config.php. Now reads the same
        // helper functions the real payment code reads, so this diagnostic
        // reflects what's actually functional.
        $rzp_key    = jp_razorpay_key_id();
        $rzp_secret = jp_razorpay_key_secret();
        $checks[]   = $this->check(
            'Razorpay Keys',
            ! empty( $rzp_key ) && ! empty( $rzp_secret ) ? 'PASS' : 'INFO',
            ! empty( $rzp_key ) ? "Key ID: " . substr( $rzp_key, 0, 8 ) . '...' : 'Not configured — payments disabled',
            null,
            "jp_razorpay_key_id() (wp-config constant or jp_razorpay_key_id option)",
            ! empty( $rzp_key ) ? 'configured' : 'not set (optional)'
        );

        // SMTP
        $smtp_host = defined( 'JP_SMTP_HOST' ) ? JP_SMTP_HOST : '';
        $checks[]  = $this->check(
            'SMTP Configuration',
            ! empty( $smtp_host ) ? 'PASS' : 'INFO',
            ! empty( $smtp_host ) ? "SMTP host: $smtp_host" : 'SMTP not configured — using WP default mail()',
            null, // SMTP is optional — INFO only, not a fix-required item
            "defined('JP_SMTP_HOST')",
            ! empty( $smtp_host ) ? $smtp_host : 'not configured (optional)'
        );

        if ( ! empty( $smtp_host ) ) {
            $smtp_port = defined( 'JP_SMTP_PORT' ) ? JP_SMTP_PORT : 587;
            $connected = @fsockopen( $smtp_host, $smtp_port, $errno, $errstr, 3 );
            $checks[]  = $this->check(
                'SMTP Port Reachable',
                $connected ? 'PASS' : 'FAIL',
                $connected ? "Port $smtp_port open on $smtp_host" : "Cannot reach $smtp_host:$smtp_port — $errstr ($errno)",
                $connected ? null : "SMTP port $smtp_port blocked. Check firewall rules, server outbound connections, and SMTP credentials.",
                "fsockopen('$smtp_host', $smtp_port)",
                $connected ? 'open' : "BLOCKED ($errstr)"
            );
            if ( $connected ) fclose( $connected );
        }

        // Redis
        $redis_host = defined( 'JP_REDIS_HOST' ) ? JP_REDIS_HOST : '';
        $checks[]   = $this->check(
            'Redis',
            'INFO',
            ! empty( $redis_host ) ? "Configured: $redis_host" : 'Not configured — using WP object cache',
            null,
            "defined('JP_REDIS_HOST')",
            ! empty( $redis_host ) ? $redis_host : 'not set (optional)'
        );

        // Elasticsearch
        $es_host  = defined( 'JP_ELASTICSEARCH_HOST' ) ? JP_ELASTICSEARCH_HOST : '';
        $checks[] = $this->check(
            'Elasticsearch',
            'INFO',
            ! empty( $es_host ) ? "Configured: $es_host" : 'Not configured — using MySQL FULLTEXT search',
            null,
            "defined('JP_ELASTICSEARCH_HOST')",
            ! empty( $es_host ) ? $es_host : 'not set (optional)'
        );

        $this->add_section( 'External Services', '🌐', $checks );
    }

    // ── Section: Security ─────────────────────────────────────────────────────

    private function check_security(): void {
        $checks = [];

        // WP_DEBUG_DISPLAY (already in environment but repeat as security issue)
        $debug_display = defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY;
        $checks[]      = $this->check(
            'No PHP Error Output',
            ! $debug_display ? 'PASS' : 'FAIL',
            $debug_display ? 'WP_DEBUG_DISPLAY=true — errors injected into API JSON responses' : 'Error display off',
            $debug_display ? 'PHP errors prepend to JSON responses, breaking REST API parsing. Set define("WP_DEBUG_DISPLAY", false) in wp-config.php.' : null,
            "WP_DEBUG_DISPLAY",
            $debug_display ? 'EXPOSED' : 'hidden'
        );

        // Nonce action string consistency.
        //
        // IMPORTANT LIMITATION (found during the RULE 7 audit that added
        // jp_save_job/jp_toggle_job_status below): this self-test always
        // passes for any action string, because it creates AND verifies
        // the nonce with the identical literal string in the same call —
        // it can only detect a broken WP nonce salt/config, never the
        // actual real-world failure mode, which is the CLIENT sending a
        // nonce created for a DIFFERENT action than the one the SERVER
        // verifies against (e.g. JS sending the 'jp_general' nonce to an
        // endpoint that verifies 'jp_save_job'). That class of bug can
        // only be caught by cross-referencing every wp_create_nonce()/
        // wp_nonce_field() call site's action string against every
        // check_ajax_referer()/jp_verify_nonce() call site's action
        // string across both jp-core and jp-theme — which is exactly the
        // grep-based audit that found and fixed the jp_save_job,
        // jp_toggle_job_status, and jp_reset_password mismatches (see
        // phase2-progress-report.md). Listed here for completeness/
        // documentation of which actions this system depends on, not as
        // a substitute for that cross-codebase audit.
        $nonce_pairs = [
            'jp_login'          => 'Login form',
            'jp_register'       => 'Registration form',
            'jp_forgot_password'=> 'Forgot password form',
            'jp_reset_password' => 'Reset password form',
            'jp_logout'         => 'Logout action',
            'jp_general'        => 'General AJAX',
            'jp_save_job'       => 'Save job (candidate)',
            'jp_toggle_job_status' => 'Job status toggle (recruiter/admin)',
            'wp_rest'           => 'REST API nonce',
        ];
        foreach ( $nonce_pairs as $action => $label ) {
            $nonce    = wp_create_nonce( $action );
            $verified = wp_verify_nonce( $nonce, $action );
            $checks[] = $this->check(
                "Nonce: $action",
                $verified ? 'PASS' : 'FAIL',
                $verified ? "$label nonce creates and verifies correctly" : "$label nonce MISMATCH",
                $verified ? null : "Nonce action '$action' is broken. wp_create_nonce and wp_verify_nonce return different values. Check for nonce salt issues in wp-config.php.",
                "wp_verify_nonce(wp_create_nonce('$action'), '$action')",
                $verified ? 'valid' : 'BROKEN'
            );
        }

        // SSL
        $is_ssl  = is_ssl() || ( isset( $_SERVER['HTTPS'] ) && $_SERVER['HTTPS'] === 'on' );
        $checks[] = $this->check(
            'HTTPS / SSL',
            $is_ssl ? 'PASS' : 'WARN',
            $is_ssl ? 'Site served over HTTPS' : 'HTTP only — authentication cookies not secure',
            $is_ssl ? null : 'Enable HTTPS. Cookie-based auth sends credentials over plain HTTP, enabling interception.',
            "is_ssl()",
            $is_ssl ? 'HTTPS' : 'HTTP only'
        );

        // Duplicate constant definitions
        $constants = [ 'JP_RAZORPAY_KEY_ID', 'JP_SMTP_HOST', 'WP_DEBUG', 'JP_OPENAI_KEY' ];
        $dupe_found = false;
        foreach ( $constants as $const ) {
            if ( defined( $const ) ) {
                // We can't detect duplicates at runtime (PHP ignores them), but we can check
                // if the value is empty when it shouldn't be configured
            }
        }
        // Check if WP_DEBUG is true AND WP_DEBUG_DISPLAY is true — classic bad config
        $bad_debug = defined( 'WP_DEBUG' ) && WP_DEBUG && $debug_display;
        $checks[]  = $this->check(
            'Debug Config Safety',
            ! $bad_debug ? 'PASS' : 'FAIL',
            $bad_debug ? 'WP_DEBUG=true AND WP_DEBUG_DISPLAY=true — DANGEROUS in production' : 'Debug config safe',
            $bad_debug ? 'Set define("WP_DEBUG_DISPLAY", false) and define("WP_DEBUG_LOG", true) in wp-config.php to log errors to file instead of output.' : null,
            "WP_DEBUG && WP_DEBUG_DISPLAY",
            $bad_debug ? 'DANGEROUS' : 'safe'
        );

        $this->add_section( 'Security', '🔒', $checks );
    }

    // ── Section: Plugin Pages ─────────────────────────────────────────────────

    private function check_plugin_pages(): void {
        $checks = [];
        $pages  = [
            'jobs'        => '/jobs/',
            'login'       => '/login/',
            'register'    => '/register/',
            'my-account'  => '/my-account/',
            'recruiter'   => '/recruiter/',
            'admin-panel' => '/admin-panel/',
        ];

        foreach ( $pages as $slug => $path ) {
            $page    = get_page_by_path( $slug );
            $exists  = ! is_null( $page );
            $published = $exists && $page->post_status === 'publish';
            $template  = $exists ? get_post_meta( $page->ID, '_wp_page_template', true ) : '';
            $has_tpl   = $template === 'page-templates/tpl-react-app.php';

            $checks[] = $this->check(
                "Page: $slug",
                $published && $has_tpl ? 'PASS' : ( $exists ? 'WARN' : 'FAIL' ),
                $exists
                    ? "ID {$page->ID}, status={$page->post_status}, template=" . ( $has_tpl ? 'React ✓' : "'$template' ✗" )
                    : "Page '$slug' does not exist",
                ! $exists ? "Page '$slug' missing. Deactivate and reactivate the plugin to recreate pages. URL: " . home_url( $path ) :
                    ( ! $has_tpl ? "Page '$slug' (ID {$page->ID}) has wrong template '$template'. Set it to 'JP React App (Full Page)' in WP admin." : null ),
                "get_page_by_path('$slug')",
                $exists ? "ID={$page->ID}, status={$page->post_status}" : 'MISSING'
            );
        }

        // Portal page ID stored
        $portal_id = (int) get_option( 'jp_portal_page_id', 0 );
        $portal    = $portal_id ? get_post( $portal_id ) : null;
        $checks[]  = $this->check(
            'Portal Page ID Stored',
            $portal && $portal->post_status === 'publish' ? 'PASS' : 'WARN',
            $portal ? "jp_portal_page_id = $portal_id ('{$portal->post_title}')" : "jp_portal_page_id = $portal_id (not found or not published)",
            ! $portal ? 'Portal page ID not stored or page missing. React Router basename will be wrong. Deactivate and reactivate plugin.' : null,
            "get_option('jp_portal_page_id')",
            $portal ? $portal_id : "not set ($portal_id)"
        );

        $this->add_section( 'Plugin Pages', '📄', $checks );
    }

    // ── Section: Theme Conflicts ──────────────────────────────────────────────

    private function check_theme_conflicts(): void {
        $checks = [];

        // Is dequeue_theme_assets registered?
        $has_dequeue = has_action( 'wp_enqueue_scripts', [ JP_React::instance(), 'dequeue_theme_assets' ] );
        $checks[]    = $this->check(
            'Theme Dequeue Hook',
            $has_dequeue !== false ? 'PASS' : 'FAIL',
            $has_dequeue !== false ? "dequeue_theme_assets registered at priority $has_dequeue" : 'dequeue_theme_assets NOT registered',
            $has_dequeue === false ? 'Theme scripts/styles will not be dequeued on React pages. Theme JS will modify the DOM and cause React removeChild/insertBefore crashes. Check JP_React::__construct().' : null,
            "has_action('wp_enqueue_scripts', [JP_React, 'dequeue_theme_assets'])",
            $has_dequeue !== false ? "priority $has_dequeue" : 'NOT REGISTERED'
        );

        // Is add_module_type filter registered?
        $has_module  = has_filter( 'script_loader_tag', [ JP_React::instance(), 'add_module_type' ] );
        $checks[]    = $this->check(
            'type=module Filter',
            $has_module !== false ? 'PASS' : 'FAIL',
            $has_module !== false ? "add_module_type filter registered at priority $has_module" : 'add_module_type NOT registered',
            $has_module === false ? 'type="module" will not be added to script tags. Browser will throw "Unexpected token export" and React will not load.' : null,
            "has_filter('script_loader_tag', [JP_React, 'add_module_type'])",
            $has_module !== false ? "priority $has_module" : 'NOT REGISTERED'
        );

        // Active theme
        $theme   = wp_get_theme();
        $checks[] = $this->check(
            'Active Theme',
            'INFO',
            "Theme: {$theme->get('Name')} v{$theme->get('Version')}",
            null,
            "wp_get_theme()",
            $theme->get( 'Name' )
        );

        // Check if theme outputs inline scripts into wp_head
        $wp_head_count = count( $GLOBALS['wp_filter']['wp_head']->callbacks ?? [] );
        $checks[]      = $this->check(
            'wp_head Hook Count',
            $wp_head_count < 30 ? 'PASS' : 'WARN',
            "$wp_head_count priority levels in wp_head",
            $wp_head_count >= 30 ? "Many hooks in wp_head ($wp_head_count). Theme or plugins may be outputting extra scripts/styles. Check Network tab for unexpected assets on portal pages." : null,
            "count(\$GLOBALS['wp_filter']['wp_head']->callbacks)",
            $wp_head_count
        );

        $this->add_section( 'Theme & Conflicts', '🎨', $checks );
    }

    // ── Section: Configuration ────────────────────────────────────────────────

    private function check_configuration(): void {
        $checks = [];

        // Plugin version in DB matches code
        $db_version   = get_option( 'jp_installed_version', '' );
        $code_version = JP_VERSION;
        $checks[]     = $this->check(
            'Version Match (DB vs Code)',
            $db_version === $code_version ? 'PASS' : 'WARN',
            "DB: $db_version, Code: $code_version",
            $db_version !== $code_version ? "Version mismatch. DB has $db_version, code is $code_version. The plugin auto-migrates on each page load — reload this page to see if it resolves. If it persists after 2 reloads, deactivate and reactivate the plugin." : null,
            "get_option('jp_installed_version') vs JP_VERSION",
            "$db_version vs $code_version"
        );

        // Installed at
        $installed_at = get_option( 'jp_installed_at', '' );
        $checks[]     = $this->check(
            'Install Date',
            ! empty( $installed_at ) ? 'PASS' : 'WARN',
            ! empty( $installed_at ) ? "Installed: $installed_at" : 'Install date not set',
            empty( $installed_at ) ? 'jp_installed_at option missing. Activation hook may not have run. Deactivate and reactivate.' : null,
            "get_option('jp_installed_at')",
            $installed_at ?: 'not set'
        );

        // Options sanity
        $options = [
            'jp_jobs_per_page'       => [ 'default' => 20,   'type' => 'int', 'label' => 'Jobs per page' ],
            'jp_resume_max_size_mb'  => [ 'default' => 5,    'type' => 'int', 'label' => 'Resume max MB' ],
            'jp_auto_approve_jobs'   => [ 'default' => '0',  'type' => 'str', 'label' => 'Auto-approve jobs' ],
        ];
        foreach ( $options as $key => $meta ) {
            $val      = get_option( $key );
            $present  = $val !== false;
            $checks[] = $this->check(
                "Option: $key",
                $present ? 'PASS' : 'WARN',
                $present ? "{$meta['label']} = $val" : "{$meta['label']} not set (default: {$meta['default']})",
                null,
                "get_option('$key')",
                $present ? $val : "(default: {$meta['default']})"
            );
        }

        $this->add_section( 'Configuration', '⚙️', $checks );
    }

    /**
     * Root-cause fix (gap analysis P1 #140/#221): "No dependency-freshness
     * or vulnerability scanning for the one PHP dependency that does
     * exist (tecnickcom/tcpdf, pinned with a loose ^6.6 constraint and no
     * committed lockfile) — builds are not reproducible and a known CVE
     * in a PDF library has no automated detection path." This sandbox has
     * no packagist.org access to run a real `composer audit`/`composer
     * outdated`, so this check does the part that's actually possible
     * without network access: confirm composer.json exists and pins a
     * real version constraint (not left at WordPress's implicit "whatever
     * happens to be in vendor/"), and confirm whether a composer.lock is
     * committed — the file that actually makes "which exact version is
     * running" a reproducible fact instead of "whatever `composer
     * install` happened to resolve on whichever machine ran it last." A
     * genuine CVE scan needs either network access to a vulnerability
     * database or `composer audit` against a real lockfile, neither of
     * which this environment can do — that remains a real, disclosed gap,
     * not something this check can close outright.
     */
    private function check_dependency_management(): void {
        $checks = [];

        $composer_json_path = JP_PLUGIN_DIR . 'composer.json';
        $composer_lock_path = JP_PLUGIN_DIR . 'composer.lock';

        $has_composer_json = file_exists( $composer_json_path );
        $checks[] = $this->check(
            'composer.json Present',
            $has_composer_json ? 'PASS' : 'WARN',
            $has_composer_json ? 'Found.' : 'Not found — dependencies (TCPDF) have no declared version constraint at all.',
            $has_composer_json ? null : 'Add a composer.json declaring an explicit version constraint for every PHP dependency.',
            'file_exists(composer.json)',
            $has_composer_json ? 'present' : 'missing'
        );

        if ( $has_composer_json ) {
            $composer = json_decode( (string) file_get_contents( $composer_json_path ), true ) ?: [];
            $require  = $composer['require'] ?? [];
            foreach ( $require as $pkg => $constraint ) {
                if ( $pkg === 'php' ) continue;
                // A caret/tilde/wildcard constraint still lets `composer
                // update` silently pull in a newer minor/patch release
                // with no review — flagged as INFO (not FAIL) since a
                // reasonably tight caret range is a legitimate choice,
                // just one that depends entirely on a committed lockfile
                // to actually be reproducible (checked separately below).
                $is_loose = (bool) preg_match( '/^[\^~*]|\|\||-/', (string) $constraint );
                $checks[] = $this->check(
                    "Dependency: {$pkg}",
                    'INFO',
                    "Constraint: {$constraint}" . ( $is_loose ? ' (range — exact resolved version depends on composer.lock)' : ' (exact pin)' ),
                    null,
                    "composer.json require.{$pkg}",
                    (string) $constraint
                );
            }
        }

        $has_lock = file_exists( $composer_lock_path );
        $checks[] = $this->check(
            'composer.lock Committed',
            $has_lock ? 'PASS' : 'WARN',
            $has_lock
                ? 'Found — dependency versions are pinned and builds are reproducible.'
                : 'No composer.lock found. Without one, `composer install` resolves whatever version satisfies the range in composer.json at install time — different environments (dev machine, staging, production) can silently end up running different versions of the same dependency, and there is no fixed baseline to run a vulnerability scan (e.g. `composer audit`) against.',
            $has_lock ? null : 'Run `composer install` in an environment with registry access, then commit the resulting composer.lock alongside composer.json.',
            'file_exists(composer.lock)',
            $has_lock ? 'present' : 'missing'
        );

        $vendor_exists = is_dir( JP_PLUGIN_DIR . 'vendor' );
        $checks[] = $this->check(
            'vendor/ Directory Present',
            $vendor_exists ? 'PASS' : 'INFO',
            $vendor_exists ? 'Dependencies are installed.' : 'Not present — composer install has not been run in this environment. PDF-generating features (invoices, offer letters, resumes, certificates) fall back to HTML output via JP_PDF until TCPDF is installed (see System Info).',
            null,
            "is_dir('vendor')",
            $vendor_exists ? 'present' : 'missing'
        );

        $this->add_section( 'Dependency Management', '📦', $checks );
    }

    // ── Section: Known Bugs (Regression Detection) ────────────────────────────

    private function check_known_bugs(): void {
        global $wpdb;
        $checks = [];

        // BUG #1: interview column 'status' vs 'outcome'
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$wpdb->prefix}jp_interviews'" ) ) {
            $has_outcome = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE()
                 AND TABLE_NAME='{$wpdb->prefix}jp_interviews' AND COLUMN_NAME='outcome'"
            );
            $has_status = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE()
                 AND TABLE_NAME='{$wpdb->prefix}jp_interviews' AND COLUMN_NAME='status'"
            );
            $checks[] = $this->check(
                '[Bug #1] interviews.outcome not status',
                $has_outcome > 0 && $has_status === 0 ? 'PASS' : ( $has_status > 0 ? 'FAIL' : 'WARN' ),
                $has_outcome > 0 ? 'Column is outcome (correct)' : ( $has_status > 0 ? "Column is 'status' — WRONG, interview saves will fail" : 'Column missing entirely' ),
                $has_status > 0 ? "REGRESSION: jp_interviews still has 'status' column. Every schedule_interview INSERT silently fails. Run: ALTER TABLE {$wpdb->prefix}jp_interviews CHANGE status outcome ENUM('pending','passed','failed','cancelled','no_show') DEFAULT 'pending'." : ( $has_outcome === 0 ? 'outcome column missing. Run activation hook.' : null ),
                "INFORMATION_SCHEMA.COLUMNS WHERE COLUMN_NAME='outcome'",
                $has_outcome > 0 ? 'outcome ✓' : ( $has_status > 0 ? 'status ✗ (WRONG)' : 'MISSING' )
            );
        }

        // BUG #2: Community tables created after dbDelta loop (were never created)
        $community_tables = [ 'jp_community_posts', 'jp_community_replies', 'jp_user_badges', 'jp_feature_flags' ];
        foreach ( $community_tables as $tbl ) {
            $full    = $wpdb->prefix . $tbl;
            $exists  = $wpdb->get_var( "SHOW TABLES LIKE '$full'" ) === $full;
            $checks[] = $this->check(
                "[Bug #2] $tbl exists",
                $exists ? 'PASS' : 'FAIL',
                $exists ? "$tbl present" : "$tbl MISSING — was not created in old activator",
                $exists ? null : "REGRESSION: $tbl missing. This table was defined after the dbDelta() loop in old code and never created. Deactivate and reactivate plugin.",
                "SHOW TABLES LIKE '$full'",
                $exists ? 'exists' : 'MISSING'
            );
        }

        // BUG #3: Old jp-app.js (unversioned) causing double React load
        // Root-cause fix (Phase 5 cutover follow-up): checked react-app/assets/
        // — the legacy pre-cutover directory, left on disk only as a rollback
        // fallback — instead of app-dist/, the directory real traffic is
        // actually served from (see class-jp-react.php's enqueue_react_assets()).
        $old_entry = JP_PLUGIN_DIR . 'app-dist/jp-app.js';
        $checks[]  = $this->check(
            '[Bug #3] Old jp-app.js absent',
            ! file_exists( $old_entry ) ? 'PASS' : 'FAIL',
            file_exists( $old_entry ) ? 'REGRESSION: jp-app.js exists alongside versioned file' : 'Old jp-app.js not present (correct)',
            file_exists( $old_entry ) ? "Delete $old_entry immediately. CDN serves both files simultaneously causing two React instances, breaking all hooks (React error #321 on every page)." : null,
            "file_exists('$old_entry')",
            file_exists( $old_entry ) ? 'EXISTS — BROKEN' : 'absent ✓'
        );

        // BUG #4: WP_DEBUG_DISPLAY corrupting API responses
        $dd = defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY;
        $checks[] = $this->check(
            '[Bug #4] WP_DEBUG_DISPLAY off',
            ! $dd ? 'PASS' : 'FAIL',
            $dd ? 'REGRESSION: WP_DEBUG_DISPLAY=true — PHP warnings prepend to JSON' : 'WP_DEBUG_DISPLAY is off (correct)',
            $dd ? 'Set define("WP_DEBUG_DISPLAY", false) in wp-config.php. Every PHP notice/warning is prepended to REST API JSON responses, causing JSON parse errors in the React app.' : null,
            "WP_DEBUG_DISPLAY",
            $dd ? 'true — BREAKING' : 'false ✓'
        );

        // BUG #5: Vite base path — chunks must be relative
        // Root-cause fix (Phase 5 cutover follow-up): checked react-app/assets/
        // (legacy directory, rollback-only) for the OLD build's unhashed
        // 'assets/EventsPage.js' chunk name literal — the new build under
        // app-dist/ hashes chunk names and nests them under ./chunks/ (e.g.
        // ./chunks/EventsPage-CJg0ljUg.js, confirmed against this codebase's
        // own build output), so that literal never matches post-cutover and
        // this check would have silently done nothing useful even once the
        // directory was corrected. Checks for an absolute /chunks/ reference
        // instead, which is what would actually indicate a broken base path.
        $entry_files = glob( JP_PLUGIN_DIR . 'app-dist/jp-app.*.js' );
        if ( ! empty( $entry_files ) ) {
            $content   = file_get_contents( $entry_files[0] );
            $is_broken = str_contains( $content, '"/chunks/' ) || str_contains( $content, '"/app-dist/chunks/' );
            $checks[]  = $this->check(
                '[Bug #5] Chunk paths relative',
                ! $is_broken ? 'PASS' : 'FAIL',
                $is_broken ? 'REGRESSION: absolute chunk paths found — CDN will 404 all lazy pages' : 'Chunk paths are relative (correct)',
                $is_broken ? 'Rebuild with base: "./" in vite.config.ts. Absolute paths /chunks/EventsPage-*.js resolve to domain root (wrong). Must be ./chunks/EventsPage-*.js (relative to script location).' : null,
                "check entry file for '/chunks/' (absolute) vs './chunks/' (relative)",
                $is_broken ? 'ABSOLUTE — BROKEN' : 'relative ✓'
            );
        }

        // BUG #6: Portal page ID stored correctly
        $portal_id = (int) get_option( 'jp_portal_page_id', 0 );
        $portal    = $portal_id ? get_post( $portal_id ) : null;
        $checks[]  = $this->check(
            '[Bug #6] Portal page ID valid',
            $portal && $portal->post_status === 'publish' ? 'PASS' : 'FAIL',
            $portal ? "jp_portal_page_id=$portal_id valid" : "jp_portal_page_id=$portal_id invalid",
            ! $portal ? 'Portal page ID not set or points to non-existent page. React Router basename will be / instead of the portal path. Deactivate and reactivate to fix.' : null,
            "get_option('jp_portal_page_id') → get_post()",
            $portal ? "$portal_id valid ✓" : "$portal_id INVALID"
        );

        // BUG #7: Permalink structure (plain = React routing broken)
        $permalink = get_option( 'permalink_structure' );
        $checks[]  = $this->check(
            '[Bug #7] Pretty permalinks enabled',
            ! empty( $permalink ) ? 'PASS' : 'FAIL',
            empty( $permalink ) ? 'PLAIN permalinks — ALL React routes return 404' : "Permalinks: $permalink",
            empty( $permalink ) ? 'Go to Settings → Permalinks → Post name. Without pretty permalinks, every React route (/jobs/, /login/, etc.) returns WordPress 404.' : null,
            "get_option('permalink_structure')",
            empty( $permalink ) ? 'plain — BROKEN' : 'pretty ✓'
        );

        $this->add_section( 'Known Bug Regression Checks', '🐛', $checks );
    }

    // ── Render admin page ─────────────────────────────────────────────────────

    public function render_page(): void {
        $report = $this->generate();
        $saved  = sanitize_text_field( $_GET['saved'] ?? '' );
        ?>
        <div class="wrap" style="font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif">
        <h1 style="display:flex;align-items:center;gap:10px">
            🔍 JP Jobs Portal — Full Diagnostic Report
            <span style="font-size:13px;font-weight:400;color:#666">v<?php echo esc_html( JP_VERSION ); ?></span>
        </h1>

        <!-- Summary bar -->
        <?php $s = $report['summary']; ?>
        <div style="display:flex;gap:12px;margin:16px 0;flex-wrap:wrap">
            <?php
            $badges = [
                [ $s['pass'], '#22c55e', 'PASS' ],
                [ $s['warn'], '#f59e0b', 'WARN' ],
                [ $s['fail'], '#ef4444', 'FAIL' ],
                [ $s['info'], '#6b7280', 'INFO' ],
            ];
            foreach ( $badges as [ $count, $color, $label ] ) :
            ?>
            <div style="background:<?php echo $color; ?>;color:#fff;padding:10px 20px;border-radius:8px;font-weight:700;font-size:18px">
                <?php echo $count; ?> <span style="font-size:12px;font-weight:400"><?php echo $label; ?></span>
            </div>
            <?php endforeach; ?>
            <div style="background:#f3f4f6;color:#374151;padding:10px 20px;border-radius:8px;font-weight:600">
                <?php echo $s['total']; ?> checks in <?php echo $s['duration']; ?>
            </div>
        </div>

        <!-- Export / Download buttons -->
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;margin-bottom:24px">

            <!-- Button 1: Direct browser download (streams JSON, no server file) -->
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'jp_download_diagnostics' ); ?>
                <input type="hidden" name="action" value="jp_download_diagnostics">
                <button type="submit"
                    style="display:inline-flex;align-items:center;gap:8px;background:#2563eb;color:#fff;border:none;border-radius:8px;padding:10px 20px;font-size:14px;font-weight:600;cursor:pointer;box-shadow:0 1px 3px rgba(0,0,0,.15)"
                    onmouseover="this.style.background='#1d4ed8'"
                    onmouseout="this.style.background='#2563eb'">
                    ⬇️ Download Report
                </button>
            </form>

            <!-- Button 2: Save to server wp-content/ (for SSH/FTP access) -->
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <?php wp_nonce_field( 'jp_run_diagnostics' ); ?>
                <input type="hidden" name="action" value="jp_run_diagnostics">
                <button type="submit"
                    style="display:inline-flex;align-items:center;gap:8px;background:#fff;color:#374151;border:1px solid #d1d5db;border-radius:8px;padding:10px 20px;font-size:14px;font-weight:600;cursor:pointer"
                    onmouseover="this.style.background='#f9fafb'"
                    onmouseout="this.style.background='#fff'">
                    💾 Save to Server
                </button>
            </form>

            <!-- Button 3: Copy as JSON (client-side, no server round-trip) -->
            <button id="jp-copy-report" type="button"
                style="display:inline-flex;align-items:center;gap:8px;background:#fff;color:#374151;border:1px solid #d1d5db;border-radius:8px;padding:10px 20px;font-size:14px;font-weight:600;cursor:pointer"
                onmouseover="this.style.background='#f9fafb'"
                onmouseout="this.style.background='#fff'">
                📋 Copy JSON
            </button>

            <span style="color:#9ca3af;font-size:12px;margin-left:4px">
                <?php echo esc_html( $s['total'] ); ?> checks · <?php echo esc_html( $s['duration'] ); ?>
                <?php if ( $s['fail'] > 0 ) : ?>
                    · <span style="color:#dc2626;font-weight:600"><?php echo esc_html( $s['fail'] ); ?> issues need fixing</span>
                <?php elseif ( $s['warn'] > 0 ) : ?>
                    · <span style="color:#d97706;font-weight:600"><?php echo esc_html( $s['warn'] ); ?> warnings</span>
                <?php else : ?>
                    · <span style="color:#16a34a;font-weight:600">All checks passed ✓</span>
                <?php endif; ?>
            </span>
        </div>

        <?php if ( $saved ) : ?>
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:12px 16px;margin-bottom:16px;color:#15803d;font-size:13px">
            ✓ Report saved: <code style="background:#dcfce7;padding:2px 6px;border-radius:4px"><?php echo esc_html( WP_CONTENT_DIR . '/' . $saved ); ?></code>
        </div>
        <?php endif; ?>

        <!-- Copy-to-clipboard script -->
        <script>
        (function() {
            var btn = document.getElementById('jp-copy-report');
            if (!btn) return;
            btn.addEventListener('click', function() {
                var report = <?php echo wp_json_encode( $report ); ?>;
                var json = JSON.stringify(report, null, 2);
                if (navigator.clipboard && navigator.clipboard.writeText) {
                    navigator.clipboard.writeText(json).then(function() {
                        btn.textContent = '✓ Copied!';
                        btn.style.borderColor = '#22c55e';
                        btn.style.color = '#16a34a';
                        setTimeout(function() {
                            btn.innerHTML = '&#128203; Copy JSON';
                            btn.style.borderColor = '#d1d5db';
                            btn.style.color = '#374151';
                        }, 2000);
                    });
                } else {
                    // Fallback: open in new tab
                    var w = window.open('', '_blank');
                    w.document.write('<pre>' + json.replace(/</g, '&lt;') + '</pre>');
                    w.document.close();
                }
            });
        })();
        </script>

        <!-- Sections -->
        <?php foreach ( $report['sections'] as $section ) : ?>
        <div style="background:#fff;border:1px solid #e5e7eb;border-radius:10px;margin-bottom:20px;overflow:hidden">
            <div style="background:#f9fafb;padding:14px 20px;border-bottom:1px solid #e5e7eb;display:flex;align-items:center;justify-content:space-between">
                <h2 style="margin:0;font-size:16px">
                    <?php echo esc_html( $section['icon'] . ' ' . $section['name'] ); ?>
                </h2>
                <span style="font-size:12px;color:#666">
                    <?php
                    $sp = $section['pass'] ?? 0;
                    $sw = $section['warn'] ?? 0;
                    $sf = $section['fail'] ?? 0;
                    echo esc_html( "{$sp}✓ {$sw}⚠ {$sf}✗" );
                    ?>
                </span>
            </div>
            <table style="width:100%;border-collapse:collapse;font-size:13px">
            <thead>
                <tr style="background:#f9fafb;color:#374151;text-align:left">
                    <th style="padding:10px 16px;width:24px"></th>
                    <th style="padding:10px 16px">Check</th>
                    <th style="padding:10px 16px">Result</th>
                    <th style="padding:10px 16px">Value</th>
                    <th style="padding:10px 16px">Solution</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ( $section['checks'] as $i => $check ) :
                $colors = [
                    'PASS' => [ '#dcfce7', '#15803d', '✓' ],
                    'FAIL' => [ '#fee2e2', '#dc2626', '✗' ],
                    'WARN' => [ '#fef9c3', '#92400e', '⚠' ],
                    'INFO' => [ '#f3f4f6', '#374151', 'ℹ' ],
                ];
                [ $bg, $fg, $icon ] = $colors[ $check['status'] ] ?? $colors['INFO'];
                $row_bg = $i % 2 === 0 ? '#fff' : '#fafafa';
            ?>
            <tr style="background:<?php echo $check['solution'] ? '#fff8f8' : $row_bg; ?>;border-top:1px solid #f3f4f6">
                <td style="padding:10px 16px;text-align:center">
                    <span style="background:<?php echo $bg; ?>;color:<?php echo $fg; ?>;padding:2px 7px;border-radius:4px;font-weight:700;font-size:11px">
                        <?php echo $icon; ?>
                    </span>
                </td>
                <td style="padding:10px 16px;font-weight:500;color:#111"><?php echo esc_html( $check['name'] ); ?></td>
                <td style="padding:10px 16px;color:#374151;max-width:300px"><?php echo esc_html( $check['message'] ); ?></td>
                <td style="padding:10px 16px;font-family:monospace;font-size:12px;color:#6b7280;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="<?php echo esc_attr( $check['value'] ); ?>">
                    <?php echo esc_html( $check['value'] ); ?>
                </td>
                <td style="padding:10px 16px;color:<?php echo $check['solution'] ? '#dc2626' : '#22c55e'; ?>;max-width:400px;font-size:12px">
                    <?php if ( $check['solution'] ) : ?>
                    <details>
                        <summary style="cursor:pointer;font-weight:600">🔧 Fix required</summary>
                        <div style="margin-top:6px;padding:8px;background:#fff5f5;border-radius:4px;border-left:3px solid #dc2626">
                            <?php echo esc_html( $check['solution'] ); ?>
                        </div>
                        <div style="margin-top:4px;font-family:monospace;font-size:11px;color:#888">
                            Probe: <?php echo esc_html( $check['probe'] ); ?>
                        </div>
                    </details>
                    <?php else : ?>
                    <span style="color:#15803d">✓ No action needed</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            </table>
        </div>
        <?php endforeach; ?>

        <p style="color:#9ca3af;font-size:12px;margin-top:20px">
            Generated: <?php echo esc_html( $report['generated_at'] ); ?> |
            By: <?php echo esc_html( $report['generated_by'] ); ?> |
            REST API: <a href="<?php echo esc_url( rest_url( 'jp/v1/diagnostics' ) ); ?>" target="_blank"><?php echo esc_url( rest_url( 'jp/v1/diagnostics' ) ); ?></a>
        </p>
        </div>
        <?php
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private function check(
        string $name,
        string $status,
        string $message,
        ?string $solution,
        string $probe,
        $value
    ): array {
        return [
            'name'     => $name,
            'status'   => $status,
            'message'  => $message,
            'solution' => $solution,
            'probe'    => $probe,
            'value'    => (string) $value,
        ];
    }

    private function add_section( string $name, string $icon, array $checks ): void {
        $pass = count( array_filter( $checks, fn( $c ) => $c['status'] === 'PASS' ) );
        $warn = count( array_filter( $checks, fn( $c ) => $c['status'] === 'WARN' ) );
        $fail = count( array_filter( $checks, fn( $c ) => $c['status'] === 'FAIL' ) );

        $this->report['sections'][] = [
            'name'   => $name,
            'icon'   => $icon,
            'pass'   => $pass,
            'warn'   => $warn,
            'fail'   => $fail,
            'checks' => $checks,
        ];
    }

    // ── Section: JS Runtime Integrity ────────────────────────────────────────

    private function check_js_runtime(): void {
        $checks  = [];
        // Root-cause fix (Phase 5 cutover follow-up): this whole function was
        // still built against react-app/assets/ (legacy, rollback-only
        // directory) and assumed a flat directory of unhashed *.js files —
        // both wrong for the current build. app-dist/ holds only the
        // versioned entry file, jp-app.css, and static assets at its top
        // level; every page/library chunk lives one level down in
        // app-dist/chunks/ with a content hash in its filename (confirmed
        // against this codebase's own build output).
        $app_dir    = JP_PLUGIN_DIR . 'app-dist/';
        $chunks_dir = $app_dir . 'chunks/';

        // Find entry file
        $entry_files = glob( $app_dir . 'jp-app.*.js' ) ?: [];
        $entry_path  = $entry_files[0] ?? '';
        $entry_file  = $entry_path ? basename( $entry_path ) : '';

        // --- Chunk integrity: no empty/corrupt files ---
        // Scans both the entry file itself and every chunk in chunks/ —
        // the old flat glob('*.js') over $app_dir would silently check zero
        // chunk files today, since none live at that level anymore.
        $js_files    = array_merge( $entry_files, glob( $chunks_dir . '*.js' ) ?: [] );
        $empty_files = [];
        $tiny_files  = [];
        foreach ( $js_files as $f ) {
            $size = filesize( $f );
            if ( $size === 0 )    $empty_files[] = basename( $f );
            elseif ( $size < 50 ) $tiny_files[]  = basename( $f ) . "({$size}B)";
        }
        $checks[] = $this->check(
            'No Empty/Corrupt JS Chunks',
            empty( $empty_files ) && empty( $tiny_files ) ? 'PASS' : 'FAIL',
            empty( $empty_files ) && empty( $tiny_files )
                ? count( $js_files ) . ' JS files all have valid size'
                : 'Empty: ' . implode( ', ', $empty_files ) . ' | Tiny: ' . implode( ', ', $tiny_files ),
            ! empty( $empty_files ) || ! empty( $tiny_files )
                ? 'Corrupt/empty JS chunks found. Rebuild React app. These chunks will cause silent import failures — React loads but specific pages crash with ErrorBoundary.' : null,
            'filesize() on entry file + all *.js in chunks/',
            empty( $empty_files ) && empty( $tiny_files ) ? 'all valid' : 'CORRUPT FILES FOUND'
        );

        // Root-cause fix: the old "Single vendor-react (no duplicate)" check
        // is dropped rather than directory-swapped. It looked for exactly one
        // file matching 'vendor-react*.js', a naming convention specific to
        // the legacy bundler config; the new build produces no file matching
        // that pattern at all (verified against this codebase's own build
        // output — React ships inside per-chunk hashed bundles instead), so
        // directory-swapping this check alone would make it report FAIL
        // permanently regardless of whether the build is actually healthy —
        // a false, unactionable alarm every single run. BUG #3's dedicated
        // check above already covers the real underlying risk this existed
        // to catch (an old unversioned jp-app.js coexisting with the current
        // versioned one, causing two React instances).

        // --- No SW registration code in built bundle ---
        if ( $entry_path && file_exists( $entry_path ) ) {
            $entry_content = file_get_contents( $entry_path );
            $has_sw        = str_contains( $entry_content, 'serviceWorker' ) &&
                             str_contains( $entry_content, 'register(' );
            $checks[] = $this->check(
                'No SW Registration in Bundle',
                ! $has_sw ? 'PASS' : 'FAIL',
                ! $has_sw
                    ? 'No service worker registration found in bundle'
                    : 'SW registration found in bundle — will attempt /sw.js (404)',
                $has_sw
                    ? 'Bundle contains navigator.serviceWorker.register() but sw.js is not served from site root. This causes a 404 console error on every page load. Remove registerSW() from main.tsx and rebuild.' : null,
                'grep serviceWorker+register in entry file',
                $has_sw ? 'SW REGISTRATION PRESENT — 404 EVERY PAGE' : 'clean'
            );

            // --- Entry file mapDeps references all exist on disk ---
            // Root-cause fix (Phase 5 cutover follow-up): the old parser
            // looked for bare "./ChunkName.js" patterns directly under
            // $app_dir. The new build nests every chunk one level down as
            // "./chunks/ChunkName-<hash>.js" — the "/" before the chunk name
            // and the hash suffix both failed the old regex
            // (^[A-Za-z][A-Za-z0-9_-]+[.]js$ has no "/" in its character
            // class), so this check would have silently matched zero
            // references and reported a vacuous "0 chunks referenced, all
            // exist" PASS forever, verifying nothing. Parser and existence
            // check both updated for the "./chunks/<name>.js" shape.
            $referenced_chunks = [];
            $search_pos = 0;
            while ( ( $pos = strpos( $entry_content, "./chunks/", $search_pos ) ) !== false ) {
                $end = strpos( $entry_content, ".js", $pos );
                if ( $end !== false && $end - $pos < 80 ) {
                    $chunk = substr( $entry_content, $pos + 2, $end - $pos - 2 ) . ".js"; // "chunks/Name-hash.js"
                    if ( preg_match( "#^chunks/[A-Za-z][A-Za-z0-9_-]+[.]js$#", $chunk ) ) {
                        $referenced_chunks[] = $chunk;
                    }
                    $search_pos = $end + 3;
                } else {
                    $search_pos = $pos + 2;
                }
            }
            $referenced_chunks = array_unique( $referenced_chunks );
            $missing_chunks    = [];
            foreach ( $referenced_chunks as $chunk ) {
                if ( ! file_exists( $app_dir . $chunk ) ) {
                    $missing_chunks[] = $chunk;
                }
            }
            $checks[] = $this->check(
                'All Referenced Chunks Exist on Disk',
                ! empty( $referenced_chunks ) && empty( $missing_chunks ) ? 'PASS' : ( empty( $referenced_chunks ) ? 'WARN' : 'FAIL' ),
                empty( $referenced_chunks )
                    ? 'No ./chunks/ references found in entry file — cannot confirm chunk integrity this way'
                    : ( empty( $missing_chunks )
                        ? count( $referenced_chunks ) . ' chunks referenced, all exist on disk'
                        : count( $missing_chunks ) . ' chunks referenced but MISSING: ' . implode( ', ', array_slice( $missing_chunks, 0, 5 ) ) ),
                ! empty( $missing_chunks )
                    ? 'Entry file references chunks that do not exist on disk. These will 404 when React tries to lazy-load them, showing ErrorBoundary on those pages. Rebuild the React app with emptyOutDir:true.' : null,
                'parse "./chunks/<name>.js" references + check file_exists for each',
                empty( $referenced_chunks ) ? 'NONE FOUND' : ( empty( $missing_chunks ) ? 'all ' . count( $referenced_chunks ) . ' present' : count( $missing_chunks ) . ' MISSING' )
            );

            // --- No absolute /chunks/ paths (should all be ./chunks/) ---
            $has_abs  = str_contains( $entry_content, '"/chunks/' ) || str_contains( $entry_content, "'/chunks/" )
                || str_contains( $entry_content, '"/app-dist/chunks/' ) || str_contains( $entry_content, "'/app-dist/chunks/" );
            $checks[] = $this->check(
                'Chunk Paths Are Relative Not Absolute',
                ! $has_abs ? 'PASS' : 'FAIL',
                ! $has_abs
                    ? 'All chunk paths start with ./chunks/ (relative) — correct'
                    : 'Absolute /chunks/ paths found — CDN resolves to domain root, chunks 404',
                $has_abs
                    ? 'Rebuild with base: "./" in vite.config.ts. Absolute paths like "/chunks/EventsPage-*.js" resolve to https://site.com/chunks/... (wrong — missing plugin path). Every lazy-loaded page shows ErrorBoundary.' : null,
                'grep "/chunks/" (absolute) vs "./chunks/" (relative) in entry file',
                $has_abs ? 'ABSOLUTE PATHS — BROKEN' : 'relative ./chunks/ paths — OK'
            );
        }

        // --- type=module filter actually fires ---
        $react_instance = JP_React::instance();
        $filter_priority = has_filter( 'script_loader_tag', [ $react_instance, 'add_module_type' ] );
        $checks[] = $this->check(
            'type=module Filter Active',
            $filter_priority !== false ? 'PASS' : 'FAIL',
            $filter_priority !== false
                ? "script_loader_tag filter registered at priority $filter_priority"
                : 'add_module_type filter NOT registered',
            $filter_priority === false
                ? 'type="module" will not be added to React script tag. Browser treats ESM file as classic script, throws "Unexpected token export", React never loads. Every page shows blank white screen.' : null,
            'has_filter("script_loader_tag", [JP_React, "add_module_type"])',
            $filter_priority !== false ? "priority $filter_priority" : 'NOT REGISTERED — CRITICAL'
        );

        // --- Script tag simulation: verify filter output is valid ---
        if ( $filter_priority !== false && $entry_file ) {
            $asset_url   = JP_PLUGIN_URL . 'app-dist/' . $entry_file;
            $fake_tag    = "<script type='text/javascript' src='{$asset_url}' id='jp-react-app-js'></script>
";
            $filtered    = apply_filters( 'script_loader_tag', $fake_tag, 'jp-react-app', $asset_url );
            $has_module  = str_contains( $filtered, 'type="module"' );
            $no_textjs   = ! str_contains( $filtered, 'text/javascript' );
            $checks[] = $this->check(
                'Script Tag After Filter Is Valid',
                $has_module && $no_textjs ? 'PASS' : 'FAIL',
                $has_module && $no_textjs
                    ? 'Filter produces: <script type="module" src="...jp-app.*.js">'
                    : 'Filter output broken: ' . substr( strip_tags( $filtered ), 0, 80 ),
                ! $has_module || ! $no_textjs
                    ? 'The add_module_type filter is registered but its output is wrong. Check class-jp-react.php::add_module_type() for the str_replace logic. Without type="module" the browser rejects all ESM code.' : null,
                'apply_filters("script_loader_tag", fake_tag, "jp-react-app", url)',
                $has_module && $no_textjs ? 'type="module" ✓' : 'WRONG OUTPUT'
            );
        }

        // --- WP REST API not disabled by security plugin ---
        // Check if REST API is genuinely blocked (not just filtered by our own unblocking code).
        // We add our own filter to rest_authentication_errors (to whitelist jp/v1), so checking
        // has_filter('rest_authentication_errors') would always be true — use a stricter check.
        $rest_option_blocked = (bool) get_option( 'disable_wp_rest_api' );
        $rest_const_blocked  = defined( 'DISABLE_REST_API' ) && DISABLE_REST_API;
        $rest_enabled_false  = has_filter( 'rest_enabled', '__return_false' );
        // Test the jp/v1/health endpoint directly to see if it's actually reachable
        $health_resp   = wp_remote_get( rest_url( 'jp/v1/health' ), [ 'timeout' => 5, 'sslverify' => false ] );
        $health_ok     = ! is_wp_error( $health_resp ) && wp_remote_retrieve_response_code( $health_resp ) === 200;
        $rest_disabled = ( $rest_option_blocked || $rest_const_blocked || $rest_enabled_false ) && ! $health_ok;
        $checks[] = $this->check(
            'REST API Not Blocked by Security Plugin',
            $health_ok ? 'PASS' : ( $rest_disabled ? 'FAIL' : 'WARN' ),
            $health_ok
                ? 'jp/v1/health returns 200 — REST API accessible'
                : ( $rest_disabled
                    ? 'REST API blocked — jp/v1/health returned non-200'
                    : 'jp/v1/health did not return 200 (timeout or network issue)' ),
            ( ! $health_ok )
                ? 'If a security plugin blocks REST API, JP Jobs Portal has a built-in bypass for jp/v1 namespace. If jp/v1/health still fails: check Wordfence → Firewall → Whitelisted URLs, or temporarily disable REST API restriction plugins.' : null,
            'GET ' . rest_url( 'jp/v1/health' ),
            $health_ok ? 'HTTP 200 ✓' : 'NOT 200 — check security plugins'
        );

        // --- WP_DEBUG_DISPLAY corrupting JSON responses ---
        // JP Core applies ini_set('display_errors','0') on rest_api_init at priority 0
        // as a mitigation — but the permanent fix is wp-config.php.
        $dd = defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY;
        // Verify if our mitigation is active (rest_api_init hook fired = we are in a REST context)
        $mitigation_active = $dd && did_action( 'rest_api_init' ) && ! ini_get( 'display_errors' );
        $checks[] = $this->check(
            'PHP Errors Not Injected Into JSON',
            ! $dd ? 'PASS' : ( $mitigation_active ? 'WARN' : 'FAIL' ),
            ! $dd
                ? 'WP_DEBUG_DISPLAY off — JSON responses clean'
                : ( $mitigation_active
                    ? 'WP_DEBUG_DISPLAY=true but JP Core suppresses display_errors on REST — mitigated'
                    : 'WP_DEBUG_DISPLAY=true — PHP notices/warnings PREPEND to every JSON response' ),
            $dd
                ? 'PERMANENT FIX: Set define("WP_DEBUG_DISPLAY", false) in wp-config.php. JP Core applies a temporary mitigation (ini_set display_errors=0 on REST requests) but the wp-config.php setting is the correct fix.' : null,
            'WP_DEBUG_DISPLAY constant',
            $dd ? ( $mitigation_active ? 'true — MITIGATED by JP Core ini_set' : 'true — JSON CORRUPTED' ) : 'false — clean'
        );

        $this->add_section( 'JS Runtime Integrity', '🔧', $checks );
    }

    // ── Section: CSS Integrity ────────────────────────────────────────────────

    private function check_css_integrity(): void {
        $checks  = [];
        // Root-cause fix (Phase 5 cutover follow-up): pointed at react-app/
        // (legacy, rollback-only) instead of app-dist/, the directory real
        // traffic is served from.
        $app_dir = JP_PLUGIN_DIR . 'app-dist/';
        $css_path = $app_dir . 'jp-app.css';

        if ( ! file_exists( $css_path ) ) {
            $checks[] = $this->check(
                'CSS File',
                'FAIL',
                'jp-app.css missing entirely',
                'Rebuild React app. Without CSS the portal renders as unstyled HTML — all layouts broken.',
                "file_exists('$css_path')",
                'MISSING'
            );
            $this->add_section( 'CSS Integrity', '🎨', $checks );
            return;
        }

        $css      = file_get_contents( $css_path );
        $css_size = strlen( $css );

        // Loaded early (moved up from further below in this function) because
        // the next three checks need it: root-cause fix (Phase 5 cutover
        // follow-up) — overflow-x:hidden, the #wpadminbar override, and the
        // .jp-fullpage margin reset are NOT in jp-app.css at all. Confirmed
        // directly against this codebase: grep for all three against the
        // real app-dist/jp-app.css returns zero matches. They live inline in
        // tpl-react-app.php's own <style> block instead — deliberately, per
        // that template's own docblock ("Critical fixes — inline in template
        // so CDN caching of jp-app.css cannot break them"). These three
        // checks were still testing $css for them, so once pointed at the
        // real live directory they would have reported FAIL/WARN forever
        // for behavior that is actually correct, just implemented in the
        // other in-scope file instead of this one.
        $tpl_path = JP_PLUGIN_DIR . 'templates/page-templates/tpl-react-app.php';
        $tpl      = file_exists( $tpl_path ) ? file_get_contents( $tpl_path ) : '';

        // --- CSS file size sanity ---
        // Root-cause fix (Phase 5 cutover follow-up): the "~38KB+" baseline
        // was the legacy build's single-monolithic-CSS-file size. The
        // rewrite code-splits per-page CSS into separate chunk files
        // (app-dist/jp-app2.css, jp-app3.css, ... one per lazy-loaded page,
        // confirmed against this codebase's own build output — 19 of them,
        // totaling well under the old single-file size on top of this
        // shared file), so jp-app.css itself now holds only the shared
        // design tokens and global styles and is expected to be much
        // smaller (~8KB as of this fix) — that is correct, not truncation.
        // Lowered the floor accordingly; this checks for a near-empty/zero
        // file (genuine truncation or a broken build), not a fixed KB target
        // this file was never meant to hit after code-splitting.
        $checks[] = $this->check(
            'CSS File Size',
            $css_size > 2000 ? 'PASS' : ( $css_size > 200 ? 'WARN' : 'FAIL' ),
            round( $css_size / 1024, 1 ) . 'KB',
            $css_size <= 2000
                ? "CSS file is only {$css_size} bytes — appears truncated or empty. Rebuild React app. Note: the rewrite code-splits per-page CSS into app-dist/jp-appN.css chunk files, so this shared file is expected to be small (holding only shared tokens/global styles), not the legacy monolithic ~38KB bundle." : null,
            'filesize(jp-app.css)',
            round( $css_size / 1024, 1 ) . 'KB (shared tokens/globals only — per-page CSS is code-split into jp-appN.css)'
        );

        // --- CSS custom properties defined ---
        // Root-cause fix (Phase 5 cutover follow-up): the rewrite uses a
        // different design-token set than the legacy app — --jp-text,
        // --jp-bg, --jp-surface, --jp-border, and --jp-text-muted were never
        // defined by the new app/ source at all (confirmed by grepping every
        // .css file under app/src — zero matches for any of the five), so
        // this check would have reported FAIL forever once pointed at the
        // real app-dist/ directory, for tokens that were intentionally
        // renamed/restructured, not lost. Replaced with the token set the
        // new app's own CSS actually defines and every component references
        // (e.g. Card.css's `outline: 2px solid var(--jp-primary)` added
        // earlier this session).
        $css_vars = [
            '--jp-primary'  => 'Primary brand color variable',
            '--jp-accent'   => 'Accent color variable',
            '--jp-error'    => 'Error/danger color variable',
            '--jp-success'  => 'Success color variable',
            '--jp-warning'  => 'Warning color variable',
            '--jp-radius'   => 'Border radius variable',
            '--jp-shadow'   => 'Box shadow variable',
        ];
        $missing_vars = [];
        foreach ( $css_vars as $var => $label ) {
            if ( ! str_contains( $css, $var ) ) {
                $missing_vars[] = $var;
            }
        }
        $checks[] = $this->check(
            'CSS Custom Properties (Design Tokens)',
            empty( $missing_vars ) ? 'PASS' : 'FAIL',
            empty( $missing_vars )
                ? 'All CSS variables defined (--jp-primary, --jp-accent, --jp-error, --jp-success, --jp-warning, --jp-radius, --jp-shadow)'
                : 'Missing CSS variables: ' . implode( ', ', $missing_vars ),
            ! empty( $missing_vars )
                ? 'CSS custom properties missing: ' . implode( ', ', $missing_vars ) . '. These variables control brand colors, semantic colors, and shared layout primitives across the portal. When missing, components referencing them fall back to invalid/transparent values. Rebuild React app.' : null,
            'str_contains(css, "--jp-primary") etc',
            empty( $missing_vars ) ? 'all ' . count( $css_vars ) . ' present' : count( $missing_vars ) . ' MISSING'
        );

        // --- Critical layout fix: overflow-x hidden ---
        // Checked against $tpl (tpl-react-app.php's inline <style>), not
        // $css — see the root-cause note above this block.
        $checks[] = $this->check(
            'overflow-x:hidden in Template',
            str_contains( $tpl, 'overflow-x: hidden' ) || str_contains( $tpl, 'overflow-x:hidden' ) ? 'PASS' : 'FAIL',
            str_contains( $tpl, 'overflow-x: hidden' ) || str_contains( $tpl, 'overflow-x:hidden' )
                ? 'overflow-x:hidden present in tpl-react-app.php — horizontal scroll prevented'
                : 'overflow-x:hidden MISSING from tpl-react-app.php',
            ! str_contains( $tpl, 'overflow-x: hidden' ) && ! str_contains( $tpl, 'overflow-x:hidden' )
                ? 'overflow-x:hidden is missing from the template\'s inline <style>. Any unbroken text content (long URLs, unspaced strings) will expand the page horizontally, breaking the grid layout and triggering ErrorBoundary. Add to tpl-react-app.php: html { overflow-x: hidden !important }' : null,
            'str_contains(tpl-react-app.php, "overflow-x: hidden")',
            str_contains( $tpl, 'overflow-x: hidden' ) || str_contains( $tpl, 'overflow-x:hidden' ) ? 'present ✓' : 'MISSING'
        );

        // --- Admin bar override ---
        $checks[] = $this->check(
            'Admin Bar CSS Override',
            str_contains( $tpl, 'wpadminbar' ) ? 'PASS' : 'WARN',
            str_contains( $tpl, 'wpadminbar' )
                ? '#wpadminbar { display:none } present in tpl-react-app.php'
                : '#wpadminbar override NOT found in tpl-react-app.php',
            ! str_contains( $tpl, 'wpadminbar' )
                ? '#wpadminbar is not hidden in the template\'s inline <style>. If show_admin_bar(false) fails for any reason, the 32px WP admin bar will shift the React header down. Add to tpl-react-app.php: #wpadminbar { display:none !important }' : null,
            'str_contains(tpl-react-app.php, "wpadminbar")',
            str_contains( $tpl, 'wpadminbar' ) ? 'present ✓' : 'MISSING'
        );

        // --- jp-fullpage class (body admin bar margin reset) ---
        $checks[] = $this->check(
            'jp-fullpage Body Reset',
            str_contains( $tpl, 'jp-fullpage' ) ? 'PASS' : 'WARN',
            str_contains( $tpl, 'jp-fullpage' )
                ? '.jp-fullpage { margin-top:0 } present in tpl-react-app.php'
                : 'jp-fullpage class NOT found in tpl-react-app.php',
            ! str_contains( $tpl, 'jp-fullpage' )
                ? 'body.jp-fullpage margin reset missing from the template\'s inline <style>. WP admin bar adds margin-top:32px to body. Without this reset, all portal pages have a 32px gap at the top. Add to tpl-react-app.php: body.jp-fullpage { margin-top: 0 !important }' : null,
            'str_contains(tpl-react-app.php, "jp-fullpage")',
            str_contains( $tpl, 'jp-fullpage' ) ? 'present ✓' : 'MISSING'
        );

        // --- Template inline CSS: grid min-width fix ---
        $checks[] = $this->check(
            'Grid Overflow Fix in Template',
            str_contains( $tpl, '.grid > *' ) ? 'PASS' : 'FAIL',
            str_contains( $tpl, '.grid > *' )
                ? '#jp-root .grid > * { min-width:0 } inline CSS present in template'
                : 'Grid overflow fix MISSING from template',
            ! str_contains( $tpl, '.grid > *' )
                ? 'Critical CSS missing from tpl-react-app.php: #jp-root .grid > * { min-width: 0 }. CSS Grid columns default to min-width:auto. Any unbroken text (long job descriptions, URLs) expands the grid column beyond the viewport, breaking the layout and triggering ErrorBoundary below the footer.' : null,
            'str_contains(tpl-react-app.php, ".grid > *")',
            str_contains( $tpl, '.grid > *' ) ? 'present ✓' : 'MISSING — LAYOUT BREAKS'
        );

        // --- Template inline CSS: overflow-wrap ---
        $checks[] = $this->check(
            'overflow-wrap:anywhere in Template',
            str_contains( $tpl, 'overflow-wrap' ) ? 'PASS' : 'FAIL',
            str_contains( $tpl, 'overflow-wrap' )
                ? 'overflow-wrap:anywhere inline CSS present in template'
                : 'overflow-wrap MISSING from template',
            ! str_contains( $tpl, 'overflow-wrap' )
                ? 'overflow-wrap:anywhere missing from tpl-react-app.php. Unbroken strings (no spaces) in job descriptions will overflow horizontally past the card boundary, pushing content off-screen. Add to template <style>: #jp-root p, #jp-root div { overflow-wrap: anywhere }' : null,
            'str_contains(tpl-react-app.php, "overflow-wrap")',
            str_contains( $tpl, 'overflow-wrap' ) ? 'present ✓' : 'MISSING'
        );

        // --- CSS loaded before React executes ---
        // We can verify this by checking the CSS enqueue is registered
        $has_css = wp_style_is( 'jp-react-app', 'registered' ) || wp_style_is( 'jp-react-app', 'enqueued' );
        // Note: this check runs in admin context where maybe_enqueue may not have fired
        // so we check the file exists and enqueue function is wired up
        $checks[] = $this->check(
            'CSS Enqueue Registered',
            file_exists( $css_path ) ? 'PASS' : 'FAIL',
            file_exists( $css_path )
                ? 'jp-app.css exists and will be enqueued by maybe_enqueue() on portal pages'
                : 'jp-app.css missing — cannot be enqueued',
            ! file_exists( $css_path )
                ? 'CSS file does not exist. Portal renders without any styling. Rebuild React app.' : null,
            'file_exists(jp-app.css)',
            file_exists( $css_path ) ? 'present ✓' : 'MISSING'
        );

        $this->add_section( 'CSS Integrity', '🎨', $checks );
    }

    // ── Section: ErrorBoundary Root Cause Detection ───────────────────────────

    private function check_errorboundary_causes(): void {
        $checks  = [];
        // Root-cause fix (Phase 5 cutover follow-up): pointed at react-app/
        // (legacy, rollback-only) instead of app-dist/, the directory real
        // traffic is served from.
        $app_dir = JP_PLUGIN_DIR . 'app-dist/';

        // ── In-process wiring checks (no HTTP round trip at all) ────────────
        // Root-cause fix: everything below this point used to be judged
        // SOLELY by fetching the portal page over HTTP and grepping the
        // response body — the same loopback-self-serialization exposure
        // documented on the /config check in check_rest_api(). These three
        // checks verify the exact same three things a REAL page render
        // needs (the template markup, the script-tag filter, and the
        // localized JP_CONFIG data) directly in PHP, so a hosting-level
        // loopback hiccup can no longer masquerade as "React cannot mount."
        $tpl_path         = JP_PLUGIN_DIR . 'templates/page-templates/tpl-react-app.php';
        $tpl_src          = file_exists( $tpl_path ) ? (string) file_get_contents( $tpl_path ) : '';
        $file_has_root    = str_contains( $tpl_src, 'id="jp-root"' );
        $checks[]         = $this->check(
            'Template Contains #jp-root (in-process, no network)',
            $file_has_root ? 'PASS' : 'FAIL',
            $file_has_root ? '#jp-root div present in tpl-react-app.php on disk' : '#jp-root NOT found in tpl-react-app.php — React has no mount point in the template itself',
            $file_has_root ? null : 'Add <div id="jp-root"></div> to templates/page-templates/tpl-react-app.php — React cannot mount without it, regardless of hosting/network conditions.',
            "file_get_contents('$tpl_path')",
            $file_has_root ? '#jp-root present ✓' : 'MISSING'
        );

        $fake_tag       = '<script src="https://example.com/app-dist/jp-app.js"></script>';
        $filtered_tag   = class_exists( 'JP_React' ) ? apply_filters( 'script_loader_tag', $fake_tag, 'jp-react-app', 'https://example.com/app-dist/jp-app.js' ) : $fake_tag;
        $filter_correct = str_contains( $filtered_tag, 'type="module"' );
        $checks[]       = $this->check(
            'type=module Filter Produces Correct Tag (in-process, no network)',
            $filter_correct ? 'PASS' : 'FAIL',
            $filter_correct ? "Filter output: $filtered_tag" : "Filter did NOT add type=\"module\". Output: $filtered_tag",
            $filter_correct ? null : 'JP_React::add_module_type() is not transforming the jp-react-app script tag correctly. Without type="module" the browser throws "Unexpected token export" and React never loads.',
            "apply_filters('script_loader_tag', \$fake_tag, 'jp-react-app', \$url)",
            $filter_correct ? 'type="module" ✓' : 'WRONG TYPE'
        );

        $config_wired = false;
        if ( class_exists( 'JP_React' ) && function_exists( 'wp_scripts' ) ) {
            JP_React::instance()->force_enqueue();
            $localized    = wp_scripts()->get_data( 'jp-react-app', 'data' );
            $config_wired = is_string( $localized ) && str_contains( $localized, 'JP_CONFIG' );
        }
        $checks[] = $this->check(
            'JP_CONFIG Localization Wired (in-process, no network)',
            $config_wired ? 'PASS' : 'FAIL',
            $config_wired ? 'wp_localize_script(\'jp-react-app\', \'JP_CONFIG\', ...) data is registered on the script handle' : 'No JP_CONFIG data registered on the jp-react-app script handle',
            $config_wired ? null : 'wp_localize_script for JP_CONFIG is not firing when the React assets are enqueued. Check JP_React::enqueue_react_assets(). Without it, all API calls go to the wrong URL and React crashes on load.',
            "wp_scripts()->get_data('jp-react-app', 'data')",
            $config_wired ? 'JP_CONFIG wired ✓' : 'MISSING — all API calls broken'
        );

        // --- Fetch an actual portal page and detect ErrorBoundary HTML in response ---
        // These network checks are kept because they're the only way to catch
        // something the in-process checks above cannot see — a CDN/proxy/cache
        // rewriting or blocking the request before it ever reaches WordPress.
        // When a network check below FAILS but its in-process counterpart above
        // PASSED, that disagreement itself is the diagnosis: almost certainly
        // this diagnostics page's own loopback request got starved, not a real
        // bug — confirm by opening the portal URL directly in a browser tab.
        $portal_id  = (int) get_option( 'jp_portal_page_id', 0 );
        $portal_url = $portal_id ? get_permalink( $portal_id ) : '';
        if ( $portal_url ) {
            $response    = wp_remote_get( $portal_url, [ 'timeout' => 8, 'sslverify' => false ] );
            $body        = is_wp_error( $response ) ? '' : wp_remote_retrieve_body( $response );
            $status_code = is_wp_error( $response ) ? 0 : wp_remote_retrieve_response_code( $response );

            // Check if portal page returns 200
            $checks[] = $this->check(
                'Portal Page HTTP Status (over network)',
                $status_code === 200 ? 'PASS' : 'FAIL',
                "GET $portal_url → HTTP $status_code",
                $status_code !== 200
                    ? "Portal page returned HTTP $status_code instead of 200. URL: $portal_url. Check: permalink settings, page exists and is published, template assigned correctly." : null,
                "wp_remote_get('$portal_url')",
                "HTTP $status_code"
            );

            // Check the page has #jp-root in its HTML
            $has_root = str_contains( $body, 'id="jp-root"' );
            $checks[] = $this->check(
                'Portal Page Has #jp-root (over network)',
                $has_root ? 'PASS' : 'FAIL',
                $has_root
                    ? '#jp-root div found in page HTML'
                    : '#jp-root NOT found in page HTML — React has no mount point',
                ! $has_root
                    ? ( $file_has_root
                        ? "The template file itself DOES contain #jp-root (see the in-process check above) — this network fetch returning without it most likely means this diagnostics page's own loopback request was starved (empty or partial body), not a real template bug. Confirm by opening $portal_url directly in a browser tab."
                        : 'Page HTML does not contain &lt;div id="jp-root"&gt;. React cannot mount. Check: tpl-react-app.php template is assigned to this page, template file outputs #jp-root, WordPress is not using a different template.' )
                    : null,
                'str_contains(page_html, id=jp-root)',
                $has_root ? '#jp-root found ✓' : '#jp-root MISSING — React cannot mount'
            );

            // Check page has our JS script tag
            $has_script = str_contains( $body, 'jp-app.' ) && str_contains( $body, 'type="module"' );
            $checks[] = $this->check(
                'Portal Page Has type=module Script (over network)',
                $has_script ? 'PASS' : 'FAIL',
                $has_script
                    ? 'Found <script type="module" src="...jp-app.*.js"> in page HTML'
                    : 'type="module" script tag NOT found in page HTML',
                ! $has_script
                    ? ( $filter_correct
                        ? "The type=\"module\" filter itself works correctly (see the in-process check above) — this network fetch missing it most likely means this diagnostics page's own loopback request was starved, not a real bug. Confirm by opening $portal_url directly in a browser tab."
                        : 'The JP React script tag is missing from the page or lacks type="module". Without type="module" the browser throws Unexpected token export and React never loads. Check: maybe_enqueue() runs for this page, add_module_type filter fires.' )
                    : null,
                'str_contains(html, jp-app.) && str_contains(html, type=module)',
                $has_script ? 'script tag present ✓' : 'MISSING or wrong type'
            );

            // Check page has JP_CONFIG variable
            $has_config = str_contains( $body, 'var JP_CONFIG' ) || str_contains( $body, 'JP_CONFIG=' );
            $checks[] = $this->check(
                'Portal Page Has JP_CONFIG (over network)',
                $has_config ? 'PASS' : 'FAIL',
                $has_config
                    ? 'JP_CONFIG inline variable found in page HTML'
                    : 'JP_CONFIG NOT found in page HTML',
                ! $has_config
                    ? ( $config_wired
                        ? "JP_CONFIG localization is correctly wired (see the in-process check above) — this network fetch missing it most likely means this diagnostics page's own loopback request was starved, not a real bug. Confirm by opening $portal_url directly in a browser tab."
                        : 'JP_CONFIG is missing from the page. React reads this for api_url, nonce, portal_url, and feature flags. Without it, all API calls go to the wrong URL, authentication fails, and React crashes. Check: wp_localize_script fires for jp-react-app handle.' )
                    : null,
                'str_contains(html, "var JP_CONFIG")',
                $has_config ? 'JP_CONFIG present ✓' : 'MISSING — all API calls broken'
            );

            // Check for ErrorBoundary HTML already in server response
            // (would indicate SSR issue or previous crash cached by page cache)
            $has_errorboundary = str_contains( $body, 'Something went wrong' ) &&
                                 str_contains( $body, 'Refresh page' );
            $checks[] = $this->check(
                'No Pre-rendered ErrorBoundary in HTML',
                ! $has_errorboundary ? 'PASS' : 'FAIL',
                ! $has_errorboundary
                    ? 'No ErrorBoundary HTML in server response'
                    : 'ErrorBoundary HTML ("Something went wrong") found in RAW server response',
                $has_errorboundary
                    ? 'The server is returning ErrorBoundary HTML before React even runs. This means a page caching plugin (LiteSpeed Cache, WP Rocket, WP Super Cache) has cached a broken React page. Clear ALL page caches and page cache plugins. The cache is serving the crashed page to every visitor.' : null,
                'str_contains(html, "Something went wrong") && str_contains(html, "Refresh page")',
                $has_errorboundary ? 'ErrorBoundary CACHED — clear page cache' : 'clean ✓'
            );

            // Check page has TWO jp-app script tags (double load = two React instances)
            $script_count = substr_count( $body, 'jp-app.' );
            $checks[] = $this->check(
                'Single JP App Script (not double-loaded)',
                $script_count <= 1 ? 'PASS' : 'FAIL',
                $script_count <= 1
                    ? 'jp-app appears ' . $script_count . ' time(s) in page HTML — correct'
                    : "jp-app appears $script_count times in page HTML — TWO React instances",
                $script_count > 1
                    ? "jp-app script loaded $script_count times on the same page. Two React instances = React error #321 (Invalid hook call) on every page — all content shows ErrorBoundary. Causes: CDN serving old + new jp-app.js simultaneously, or script enqueued twice. Purge CDN. Check for duplicate wp_enqueue_script calls." : null,
                'substr_count(html, "jp-app.")',
                "$script_count occurrence(s)"
            );

            // Check page does not load theme CSS (theme dequeue working)
            $theme_name = get_template();
            $has_theme_css = str_contains( $body, "/themes/$theme_name/" ) &&
                             ( str_contains( $body, '.css' ) );
            $checks[] = $this->check(
                'Theme CSS Not Loaded on Portal Page',
                ! $has_theme_css ? 'PASS' : 'WARN',
                ! $has_theme_css
                    ? 'No theme CSS found in portal page response'
                    : "Theme CSS from /themes/$theme_name/ found in page — may conflict with React",
                $has_theme_css
                    ? "Theme CSS ($theme_name) is loading on the React portal page. Theme stylesheets can conflict with Tailwind utilities, override custom properties, and corrupt the layout. Check dequeue_theme_assets() is registered at priority 999 in JP_React::__construct()." : null,
                "str_contains(html, '/themes/$theme_name/')",
                $has_theme_css ? 'THEME CSS LOADING — potential conflicts' : 'clean ✓'
            );
        } else {
            $checks[] = $this->check(
                'Portal Page Fetch',
                'WARN',
                'Cannot fetch portal page — jp_portal_page_id not set or page missing',
                'Set jp_portal_page_id or ensure portal page exists. Without it, these live page checks cannot run.',
                'get_option("jp_portal_page_id")',
                'not available'
            );
        }

        // --- Detect causes that lead to ErrorBoundary ---
        $entry_files = glob( $app_dir . 'jp-app.*.js' ) ?: [];
        if ( ! empty( $entry_files ) ) {
            $content = file_get_contents( $entry_files[0] );

            // Zustand store: does it use useSyncExternalStore (needs single React copy)
            $has_zustand = str_contains( $content, 'useSyncExternalStore' ) ||
                           str_contains( $content, 'zustand' );
            $checks[] = $this->check(
                'Zustand Store Detected',
                'INFO',
                $has_zustand
                    ? 'Zustand detected in bundle — requires exactly ONE React instance'
                    : 'Zustand not detected in bundle',
                null,
                'grep useSyncExternalStore in entry',
                $has_zustand
                    ? 'present — must have single React copy' : 'not found'
            );
        }

        // --- Two React copies: old jp-app.js + new versioned jp-app.X.Y.Z.js ---
        $old_entry     = $app_dir . 'jp-app.js';
        $versioned     = glob( $app_dir . 'jp-app.*.js' ) ?: [];
        $has_both      = file_exists( $old_entry ) && ! empty( $versioned );
        $checks[] = $this->check(
            'No Conflicting Entry Files',
            ! $has_both ? 'PASS' : 'FAIL',
            ! $has_both
                ? 'Only one entry file exists — ' . ( ! empty( $versioned ) ? basename( $versioned[0] ) : 'jp-app.js' )
                : 'BOTH jp-app.js AND jp-app.*.js exist — CDN loads BOTH simultaneously',
            $has_both
                ? 'Two React entry files on disk: jp-app.js (old) and ' . basename( $versioned[0] ) . ' (new). CDN serves both on different requests. Two React instances = Zustand crashes = ErrorBoundary on every page. DELETE jp-app.js immediately: rm ' . $old_entry : null,
            'file_exists(jp-app.js) && glob(jp-app.*.js)',
            $has_both ? 'BOTH EXIST — DELETE jp-app.js' : 'single entry ✓'
        );

        // --- Detect page caching plugin conflicts ---
        $cache_plugins = [
            'litespeed-cache/litespeed-cache.php' => 'LiteSpeed Cache',
            'w3-total-cache/w3-total-cache.php'   => 'W3 Total Cache',
            'wp-super-cache/wp-cache.php'          => 'WP Super Cache',
            'wp-rocket/wp-rocket.php'              => 'WP Rocket',
            'comet-cache/comet-cache.php'          => 'Comet Cache',
        ];
        $active_cache = [];
        foreach ( $cache_plugins as $plugin => $name ) {
            if ( is_plugin_active( $plugin ) ) {
                $active_cache[] = $name;
            }
        }
        $checks[] = $this->check(
            'Page Cache Plugins',
            empty( $active_cache ) ? 'PASS' : 'WARN',
            empty( $active_cache )
                ? 'No page caching plugins detected'
                : 'Active page cache: ' . implode( ', ', $active_cache ),
            ! empty( $active_cache )
                ? implode( ', ', $active_cache ) . ' is active. Page caches can serve a crashed React page (ErrorBoundary HTML) to all visitors. After fixing any JS error: purge the page cache. Also exclude portal page URLs from caching in the plugin settings.' : null,
            'is_plugin_active() for known cache plugins',
            empty( $active_cache ) ? 'none ✓' : implode( ', ', $active_cache ) . ' — purge after fixes'
        );

        $this->add_section( 'ErrorBoundary Root Cause Detection', '🚨', $checks );
    }

    // ── Section: JP_CONFIG Contract ───────────────────────────────────────────

    private function check_jp_config_contract(): void {
        $checks = [];

        // Keys React reads vs keys PHP provides
        $required_keys = [
            'api_url'        => 'REST API base URL — all fetch() calls use this',
            'ajax_url'       => 'WordPress AJAX URL',
            'home_url'       => 'Site home URL — used for basename calculation',
            'portal_url'     => 'Portal page URL — React Router basename',
            'nonce'          => 'wp_rest nonce — authenticates REST API calls',
            'ajax_nonce'     => 'jp_general nonce — authenticates AJAX calls',
            'is_logged'      => 'Auth state — skips /auth/me on mount if true',
            'role'           => 'User role slug — controls which dashboard renders',
            'openai_enabled' => 'Feature flag — shows/hides AI features',
            'razorpay_key_id'=> 'Razorpay public key — payment form',
            'jobs_per_page'  => 'Pagination — search results page size',
        ];

        // Root-cause fix: this entire section used to derive $config SOLELY
        // from a network loopback fetch — meaning the same self-loopback
        // starvation documented in check_rest_api() (a live run showed
        // /config coming back HTTP 200 with a fully empty body from THIS
        // diagnostics page's own request) turned into a false "11 keys
        // MISSING" alarm here, flatly contradicting the "Critical Keys
        // Non-Empty: PASS" result from a DIFFERENT check elsewhere that
        // happened not to hit the same empty-body response. $config is now
        // sourced in-process (no network round trip, cannot be affected by
        // loopback contention) — the actual contract every check below
        // verifies. The network fetch is kept as its OWN separate,
        // non-gating reachability check, since it's still the only way to
        // catch a CDN/proxy rewriting the request before WordPress ever
        // sees it.
        $config = class_exists( 'JP_React' ) ? JP_React::instance()->diagnostics_get_config() : [];

        $config_url    = rest_url( 'jp/v1/config' );
        $response      = wp_remote_get( $config_url, [ 'timeout' => 5, 'sslverify' => false ] );
        $network_body  = is_wp_error( $response ) ? '{}' : wp_remote_retrieve_body( $response );
        $network_code  = is_wp_error( $response ) ? 0 : wp_remote_retrieve_response_code( $response );
        $network_ok    = $network_code === 200 && ! empty( json_decode( $network_body, true ) );
        $checks[] = $this->check(
            '/config Endpoint Reachable (over network)',
            $network_ok ? 'PASS' : ( ! empty( $config ) ? 'WARN' : 'FAIL' ),
            $network_ok ? 'Config endpoint returns JSON over the network' : "HTTP $network_code" . ( is_wp_error( $response ) ? ': ' . $response->get_error_message() : ', empty or invalid body' ),
            $network_ok ? null : ( ! empty( $config )
                ? "The in-process config below is valid, so this is most likely this diagnostics page's own loopback request being starved (see check_rest_api()'s docblock for why), not a real bug. Confirm by opening $config_url directly in a browser tab."
                : "JP_CONFIG endpoint not working (HTTP $network_code). React will use fallback values which may be wrong. Check jp/v1/config is registered." ),
            "GET $config_url",
            "HTTP $network_code"
        );

        // Check each required key is present in config response
        $missing_keys = [];
        $empty_keys   = [];
        foreach ( $required_keys as $key => $description ) {
            if ( ! array_key_exists( $key, $config ) ) {
                $missing_keys[] = $key;
            } elseif ( $config[ $key ] === '' || $config[ $key ] === null || $config[ $key ] === false ) {
                // Some keys being false/empty is legitimate (openai_enabled=false is fine)
                if ( in_array( $key, [ 'api_url', 'home_url', 'portal_url', 'nonce' ], true ) ) {
                    $empty_keys[] = $key;
                }
            }
        }

        $checks[] = $this->check(
            'All Required Keys Present',
            empty( $missing_keys ) ? 'PASS' : 'FAIL',
            empty( $missing_keys )
                ? 'All ' . count( $required_keys ) . ' required keys present in JP_CONFIG'
                : 'Missing keys: ' . implode( ', ', $missing_keys ),
            ! empty( $missing_keys )
                ? 'JP_CONFIG is missing: ' . implode( ', ', $missing_keys ) . '. React reads these keys on startup. Missing keys cause silent failures: API calls go to undefined URL, auth state is unknown, feature flags default to off. Fix in build_config() in class-jp-react.php.' : null,
            'array_key_exists for each required key in /config response',
            empty( $missing_keys ) ? 'all present ✓' : count( $missing_keys ) . ' MISSING: ' . implode( ', ', $missing_keys )
        );

        $checks[] = $this->check(
            'Critical Keys Non-Empty',
            empty( $empty_keys ) ? 'PASS' : 'FAIL',
            empty( $empty_keys )
                ? 'api_url, home_url, portal_url, nonce all have values'
                : 'Empty critical keys: ' . implode( ', ', $empty_keys ),
            ! empty( $empty_keys )
                ? 'Critical JP_CONFIG keys are empty: ' . implode( ', ', $empty_keys ) . '. api_url empty = all API calls go to undefined. nonce empty = all authenticated requests fail with 403. portal_url empty = React Router uses wrong basename.' : null,
            'check value of api_url, home_url, portal_url, nonce',
            empty( $empty_keys ) ? 'all non-empty ✓' : implode( ', ', $empty_keys ) . ' are EMPTY'
        );

        // Verify api_url contains the right namespace
        if ( ! empty( $config['api_url'] ) ) {
            $api_url = $config['api_url'];
            // Batch 31: was checking against a third hardcoded 'jp/v1'
            // literal — sourced from JP_Api::namespace_str() now, so this
            // check actually verifies against the live namespace instead
            // of a copy that could silently go stale.
            $ns = class_exists( 'JP_Api' ) ? JP_Api::namespace_str() : 'jp/v1';
            $has_namespace = str_ends_with( rtrim( $api_url, '/' ), '/' . $ns ) ||
                             str_contains( $api_url, $ns );
            $checks[] = $this->check(
                'api_url Contains Correct Namespace',
                $has_namespace ? 'PASS' : 'FAIL',
                $has_namespace
                    ? "api_url: $api_url"
                    : "api_url is wrong: '$api_url' — missing /$ns namespace",
                ! $has_namespace
                    ? "JP_CONFIG.api_url='$api_url' does not end with /$ns. All React API calls will hit wrong endpoints. Expected: " . rest_url( $ns ) . ". Fix in build_config() in class-jp-react.php." : null,
                "str_contains(api_url, \"$ns\")",
                $api_url
            );
        }

        // Verify portal_url matches an actual published page
        if ( ! empty( $config['portal_url'] ) ) {
            $portal_url  = $config['portal_url'];
            $portal_resp = wp_remote_get( $portal_url, [ 'timeout' => 5, 'sslverify' => false ] );
            $portal_code = is_wp_error( $portal_resp ) ? 0 : wp_remote_retrieve_response_code( $portal_resp );
            $portal_body = is_wp_error( $portal_resp ) ? '' : wp_remote_retrieve_body( $portal_resp );
            $has_root    = str_contains( $portal_body, 'id="jp-root"' );
            $tpl_check_path = JP_PLUGIN_DIR . 'templates/page-templates/tpl-react-app.php';
            $tpl_has_root   = file_exists( $tpl_check_path ) && str_contains( (string) file_get_contents( $tpl_check_path ), 'id="jp-root"' );
            $checks[] = $this->check(
                'portal_url Points to Valid React Page (over network)',
                $portal_code === 200 && $has_root ? 'PASS' : 'FAIL',
                $portal_code === 200 && $has_root
                    ? "portal_url '$portal_url' → HTTP 200 with #jp-root ✓"
                    : "portal_url '$portal_url' → HTTP $portal_code" . ( ! $has_root ? ', no #jp-root' : '' ),
                $portal_code !== 200 || ! $has_root
                    ? ( $tpl_has_root
                        ? "The React template itself does contain #jp-root on disk — this network fetch's result most likely means this diagnostics page's own loopback request was starved (see check_rest_api()'s docblock), not a real bug. Confirm by opening $portal_url directly in a browser tab."
                        : "JP_CONFIG.portal_url points to '$portal_url' but that page does not return a valid React page (HTTP $portal_code, #jp-root present: " . ( $has_root ? 'yes' : 'no' ) . "). React Router uses portal_url for basename calculation. Wrong URL = wrong basename = all routes broken." )
                    : null,
                "wp_remote_get(portal_url) → check HTTP 200 + #jp-root",
                $portal_code === 200 && $has_root ? 'valid ✓' : "HTTP $portal_code / #jp-root: " . ( $has_root ? 'yes' : 'no' )
            );
        }

        // Nonce verify: can the nonce from JP_CONFIG actually authenticate REST calls?
        if ( ! empty( $config['nonce'] ) ) {
            $nonce = $config['nonce'];
            // Verify the nonce is a valid wp_rest nonce (24-char hex string)
            $is_valid_format = (bool) preg_match( '/^[0-9a-f]{10}$/', $nonce );
            $checks[] = $this->check(
                'nonce Valid Format',
                $is_valid_format ? 'PASS' : 'WARN',
                $is_valid_format
                    ? 'nonce is valid format (10-char hex): ' . substr( $nonce, 0, 4 ) . '...'
                    : "nonce format unexpected: '$nonce'",
                ! $is_valid_format
                    ? "JP_CONFIG.nonce='$nonce' is not the expected 10-char hex format. wp_create_nonce('wp_rest') should produce this. If format is wrong, REST API authentication will fail with 403 on all authenticated endpoints." : null,
                'preg_match(/^[0-9a-f]{10}$/, nonce)',
                $is_valid_format ? 'valid format ✓' : 'UNEXPECTED FORMAT'
            );
        }

        // Duplicate define() in wp-config.php (causes notices that corrupt JSON)
        $defined_constants = [ 'JP_RAZORPAY_KEY_ID', 'JP_SMTP_HOST', 'JP_OPENAI_KEY', 'WP_DEBUG' ];
        // We detect duplicates by checking if defined() is true AND the constant
        // was set before our plugin loaded (i.e., in wp-config.php without guards)
        // We can't directly detect duplicates at runtime, but we CAN check
        // if WP_DEBUG_DISPLAY is on AND PHP error_reporting includes E_NOTICE
        $shows_notices = defined( 'WP_DEBUG' ) && WP_DEBUG &&
                         defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY &&
                         ( error_reporting() & E_NOTICE );
        $checks[] = $this->check(
            'PHP Notices Not Displayed',
            ! $shows_notices ? 'PASS' : 'FAIL',
            ! $shows_notices
                ? 'PHP notices are not displayed to output'
                : 'PHP notices ARE displayed — duplicate define() warnings will corrupt JSON responses',
            $shows_notices
                ? 'WP_DEBUG=true + WP_DEBUG_DISPLAY=true + E_NOTICE enabled. Any duplicate define() in wp-config.php (e.g. JP_RAZORPAY_KEY_ID defined twice) outputs "Constant already defined" before the JSON — breaking JSON.parse() in React. Set WP_DEBUG_DISPLAY=false.' : null,
            'WP_DEBUG && WP_DEBUG_DISPLAY && error_reporting & E_NOTICE',
            $shows_notices ? 'NOTICES SHOWN — JSON CORRUPTED' : 'notices hidden ✓'
        );

        $this->add_section( 'JP_CONFIG Contract', '📡', $checks );
    }

    private function parse_size( string $val ): int {
        $val  = trim( $val );
        $unit = strtolower( $val[ strlen( $val ) - 1 ] );
        $size = (int) $val;
        return match ( $unit ) {
            'g' => $size * GB_IN_BYTES,
            'm' => $size * MB_IN_BYTES,
            'k' => $size * KB_IN_BYTES,
            default => $size,
        };
    }
}
