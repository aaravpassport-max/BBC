<?php
/**
 * Class JP_ErrorLog — centralized error/exception capture, scoped to this
 * plugin's own code.
 *
 * ROOT CAUSE (gap analysis P0 #59/#156): `error_log()` appears in exactly 3
 * call sites across all 32 classes before this round; PHP errors are
 * explicitly suppressed on REST responses (to keep JSON well-formed)
 * rather than captured anywhere else; and the common `catch (\Throwable)
 * { return 0; }` pattern found throughout this codebase means a real
 * failure is silently swallowed with zero record it ever happened. There
 * was no centralized place any of this could have gone even if someone
 * wanted to look.
 *
 * This class:
 *   - Registers a PHP error handler, an uncaught-exception handler, and a
 *     shutdown-function fatal-error catcher, ALL SCOPED to this plugin's
 *     own files (checked via the error's file path containing 'jp-core' or
 *     'jp-theme') — this is deliberately NOT a site-wide error monitor for
 *     every other plugin's code, and always chains to whatever handler was
 *     previously registered so it never silently replaces another
 *     plugin's error handling.
 *   - Writes to a real `jp_error_log` table with a dedup window: the same
 *     error (same message+file+line) within a 5-minute window increments
 *     an `occurrences` counter on the existing row instead of writing a
 *     new one every time — a hot loop hitting the same bug doesn't turn
 *     into thousands of near-identical rows.
 *   - Exposes `log_exception()` as a public method any of the codebase's
 *     existing `catch (\Throwable) { return X; }` blocks can call before
 *     returning their fallback value — turning "silently swallowed" into
 *     "swallowed, but now on record."
 *   - Surfaces a simple threshold-based alert: N or more DISTINCT errors
 *     within an hour triggers one admin-email alert (itself rate-limited
 *     to at most once per hour, so a bad deploy doesn't also become an
 *     email flood on top of the outage it's describing).
 */
defined( 'ABSPATH' ) || exit;

class JP_ErrorLog {

	private static ?JP_ErrorLog $instance = null;

	/** Dedup window: identical errors within this many seconds increment one row instead of inserting a new one. */
	private const DEDUP_WINDOW_SECONDS = 300;

	/** Alert threshold: this many distinct errors within an hour triggers an admin email. */
	private const ALERT_THRESHOLD = 10;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private $previous_error_handler = null;

	private function __construct() {
		$this->previous_error_handler = set_error_handler( [ $this, 'handle_error' ] );
		set_exception_handler( [ $this, 'handle_exception' ] );
		register_shutdown_function( [ $this, 'handle_shutdown' ] );
	}

	/** Only this plugin's own code — never a site-wide catch-all for every installed plugin. */
	private function is_plugin_file( string $file ): bool {
		return str_contains( $file, 'jp-core' ) || str_contains( $file, 'jp-theme' );
	}

	public function handle_error( int $errno, string $errstr, string $errfile = '', int $errline = 0 ): bool {
		if ( $this->is_plugin_file( $errfile ) && ( $errno & ( E_WARNING | E_NOTICE | E_DEPRECATED | E_USER_WARNING | E_USER_NOTICE | E_USER_DEPRECATED ) ) ) {
			$this->record( 'php_' . $this->level_name( $errno ), $errstr, $errfile, $errline );
		}
		// Always defer to whatever handler existed before (another
		// plugin's, or PHP's default) so normal error display/logging
		// behavior for everything else on the site is unaffected.
		if ( $this->previous_error_handler ) {
			return (bool) call_user_func( $this->previous_error_handler, $errno, $errstr, $errfile, $errline );
		}
		return false; // let PHP's normal handling continue for non-plugin code
	}

	public function handle_exception( \Throwable $e ): void {
		if ( $this->is_plugin_file( $e->getFile() ) ) {
			$this->record( 'uncaught_exception', $e->getMessage(), $e->getFile(), $e->getLine(), $e->getTraceAsString() );
		}
		// Re-throw semantics aren't available for the global exception
		// handler (it's terminal by PHP's design), so we log then fall
		// through to PHP's own fatal-error output — we are not hiding it.
	}

	public function handle_shutdown(): void {
		$err = error_get_last();
		if ( ! $err || ! in_array( $err['type'], [ E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR ], true ) ) return;
		if ( ! $this->is_plugin_file( $err['file'] ?? '' ) ) return;
		$this->record( 'fatal_error', $err['message'], $err['file'], $err['line'] );
	}

	/**
	 * Public entry point for code that already catches an exception itself
	 * (the "catch (\Throwable) { return 0; }" pattern flagged throughout
	 * this codebase) to record it before continuing with its fallback
	 * behavior, rather than the failure vanishing with zero trace.
	 */
	public function log_exception( \Throwable $e, string $context = '' ): void {
		$msg = $context ? "[{$context}] " . $e->getMessage() : $e->getMessage();
		$this->record( 'caught_exception', $msg, $e->getFile(), $e->getLine(), $e->getTraceAsString() );
	}

	private function level_name( int $errno ): string {
		return match ( true ) {
			(bool) ( $errno & ( E_WARNING | E_USER_WARNING ) )    => 'warning',
			(bool) ( $errno & ( E_NOTICE | E_USER_NOTICE ) )      => 'notice',
			(bool) ( $errno & ( E_DEPRECATED | E_USER_DEPRECATED ) ) => 'deprecated',
			default => 'error',
		};
	}

	private function record( string $level, string $message, string $file, int $line, string $trace = '' ): void {
		global $wpdb;
		$table = $wpdb->prefix . 'jp_error_log';
		if ( ! $wpdb->query( "SHOW TABLES LIKE '{$table}'" ) ) return; // table not yet migrated in — fail silent, never fatal on top of an existing error

		$fingerprint = md5( $level . '|' . $message . '|' . $file . '|' . $line );

		$existing = $wpdb->get_row( $wpdb->prepare(
			"SELECT id, occurrences FROM {$table} WHERE fingerprint = %s AND last_seen_at >= DATE_SUB(NOW(), INTERVAL %d SECOND)",
			$fingerprint, self::DEDUP_WINDOW_SECONDS
		) );

		if ( $existing ) {
			$wpdb->update( $table, [
				'occurrences'  => (int) $existing->occurrences + 1,
				'last_seen_at' => current_time( 'mysql' ),
			], [ 'id' => $existing->id ] );
		} else {
			$wpdb->insert( $table, [
				'fingerprint'  => $fingerprint,
				'level'        => $level,
				'message'      => mb_substr( $message, 0, 2000 ),
				'file'         => mb_substr( $file, 0, 500 ),
				'line'         => $line,
				'trace'        => mb_substr( $trace, 0, 4000 ),
				'occurrences'  => 1,
				'first_seen_at'=> current_time( 'mysql' ),
				'last_seen_at' => current_time( 'mysql' ),
			] );
			// Only a genuinely NEW distinct error counts toward the alert
			// threshold below — a single hot-looping bug incrementing one
			// row's occurrences should not itself spam the alert email.
			$this->maybe_alert();
		}
	}

	/**
	 * If ALERT_THRESHOLD or more distinct errors have been logged in the
	 * last hour, email the site admin — rate-limited to at most one such
	 * email per hour via a transient, so the alert about a problem doesn't
	 * become a flood on top of it.
	 */
	private function maybe_alert(): void {
		if ( get_transient( 'jp_error_alert_sent' ) ) return;

		global $wpdb;
		$table = $wpdb->prefix . 'jp_error_log';
		$count = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$table} WHERE first_seen_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)"
		);
		if ( $count < self::ALERT_THRESHOLD ) return;

		set_transient( 'jp_error_alert_sent', 1, HOUR_IN_SECONDS );

		$admin_email = get_option( 'admin_email' );
		if ( $admin_email ) {
			wp_mail(
				$admin_email,
				'[' . jp_site_name() . '] JP Core: elevated error rate detected',
				"{$count} distinct errors have been logged from the Job Portal plugin in the last hour. Check the admin error log for details."
			);
		}
	}

	/**
	 * Admin-visible recent errors. Was previously only ever called with a
	 * fixed small $limit from admin_health()'s combined health payload —
	 * this docblock itself said "a future log viewer" was still pending.
	 * Root-cause fix (found while auditing the still-pending WP-Admin-only
	 * settings areas): that viewer was never built and no REST route
	 * existed for a full, paginated view of this table at all — an admin
	 * could see 10 recent errors buried in /admin/health and nothing more.
	 * $offset added (defaulting to 0, so every existing call site's
	 * behavior is unchanged) so a real paginated admin screen can page
	 * through the full log instead of only ever seeing the newest handful.
	 *
	 * $level and $q added (batch 14, AdminErrorLogPage redesign): the
	 * table already has a KEY on `level` and the admin UI already
	 * rendered a level badge per row, but there was never a way to
	 * actually filter by it or search message/file — every admin had to
	 * scroll the raw unfiltered log by eye. Both default to no-op so
	 * existing callers (admin_health()'s dashboard widget) are unchanged.
	 */
	public function recent( int $limit = 50, int $offset = 0, string $level = '', string $q = '' ): array {
		global $wpdb;
		$table = $wpdb->prefix . 'jp_error_log';
		$where  = [];
		$params = [];
		if ( $level !== '' ) {
			$where[]  = 'level = %s';
			$params[] = $level;
		}
		if ( $q !== '' ) {
			$like     = '%' . $wpdb->esc_like( $q ) . '%';
			$where[]  = '(message LIKE %s OR file LIKE %s)';
			$params[] = $like;
			$params[] = $like;
		}
		$where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';
		$params[]  = $limit;
		$params[]  = $offset;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$table} {$where_sql} ORDER BY last_seen_at DESC LIMIT %d OFFSET %d", $params
		) ) ?: [];
	}

	/**
	 * Distinct levels actually present in the table, for the admin filter
	 * dropdown — so the UI only ever offers levels that exist (e.g. a
	 * fresh install with only 'error' rows never shows an empty 'fatal'
	 * option), rather than a hardcoded guess at the enum.
	 */
	public function distinct_levels(): array {
		global $wpdb;
		$table = $wpdb->prefix . 'jp_error_log';
		return $wpdb->get_col( "SELECT DISTINCT level FROM {$table} ORDER BY level ASC" ) ?: [];
	}
}
