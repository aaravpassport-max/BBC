<?php
/**
 * Migration 0001 — FOREIGN KEY constraints for the core hiring-pipeline
 * relationship graph (gap analysis §0, P0: "No FOREIGN KEY constraints
 * exist anywhere across ~37 tables").
 *
 * SCOPE, STATED HONESTLY: this migration covers the core, unambiguous
 * plugin-internal relationships — company → job → application → history,
 * plus team membership, saved jobs, precomputed matches, and reviews. It
 * deliberately does NOT cover:
 *
 *   - Any column referencing wp_users.ID (jp_companies.user_id,
 *     jp_candidates.user_id, jp_jobs.posted_by, etc.). WordPress core
 *     already has its own user-deletion flow (wp_delete_user(), which asks
 *     the caller how to reassign that user's content) and a raw ON DELETE
 *     CASCADE from a plugin table straight to wp_users could silently
 *     destroy a candidate's or recruiter's entire history the moment an
 *     admin deletes their WordPress account, which may not be the desired
 *     behavior product-wise. That needs a product decision (cascade?
 *     anonymize? block deletion while dependent records exist?), not a
 *     unilateral migration — tracked as explicit follow-on work.
 *   - jp_message_threads/jp_messages: this table's candidate_id/
 *     recruiter_id columns were not confirmed against jp_candidates.id vs.
 *     wp_users.ID from schema alone (both are plausible from the column
 *     name); adding the wrong FK target is worse than adding none. The
 *     jp_messages.thread_id → jp_message_threads.id relationship (same
 *     plugin table, unambiguous) IS covered below.
 *   - Every other one of the ~37 tables not touched here (jp_payments,
 *     jp_subscriptions, jp_events, jp_community_posts, etc.) — the
 *     JP_Migrator::add_foreign_key_safely() helper this migration uses is
 *     reusable; extending coverage is now a short, low-risk follow-up
 *     migration file per additional relationship, not new infrastructure.
 *
 * This migration is written to be safe to run against a live database with
 * pre-existing orphan data (it cleans orphans before adding each
 * constraint — see JP_Migrator::add_foreign_key_safely()) and safe to
 * re-run if interrupted (each constraint checks for its own prior
 * existence first). It has NOT been executed against a real MySQL server
 * in the sandbox this was authored in (no database is available there) —
 * see phase2-progress-report.md for what verification was actually
 * possible, and run this on a staging clone of production data before
 * relying on it there.
 */

return [
	'version'     => 1,
	'description' => 'Add FOREIGN KEY constraints for the core company/job/application/team relationship graph',
	'up'          => function ( \wpdb $wpdb ): void {
		$p  = $wpdb->prefix;
		$m  = JP_Migrator::instance();

		// jp_jobs.company_id is NOT NULL DEFAULT 0 (0 = "no company yet" —
		// a job can exist in draft before a company profile is attached).
		$m->add_foreign_key_safely( $wpdb, "{$p}jp_jobs", 'company_id', "{$p}jp_companies", 'id', 'CASCADE', 'fk_jobs_company', true );

		// Applications: job_id and candidate_id are always required (no
		// sentinel), company_id mirrors jp_jobs.company_id and carries the
		// same "may be unset yet" semantics.
		$m->add_foreign_key_safely( $wpdb, "{$p}jp_applications", 'job_id', "{$p}jp_jobs", 'id', 'CASCADE', 'fk_applications_job' );
		$m->add_foreign_key_safely( $wpdb, "{$p}jp_applications", 'candidate_id', "{$p}jp_candidates", 'id', 'CASCADE', 'fk_applications_candidate' );
		$m->add_foreign_key_safely( $wpdb, "{$p}jp_applications", 'company_id', "{$p}jp_companies", 'id', 'CASCADE', 'fk_applications_company', true );

		// Per-application audit trail — deleting an application should take its history with it.
		$m->add_foreign_key_safely( $wpdb, "{$p}jp_app_history", 'application_id', "{$p}jp_applications", 'id', 'CASCADE', 'fk_app_history_application' );

		// Team membership belongs entirely to its company.
		$m->add_foreign_key_safely( $wpdb, "{$p}jp_team_members", 'company_id', "{$p}jp_companies", 'id', 'CASCADE', 'fk_team_members_company' );

		// Saved jobs and precomputed matches are pure derived/reference
		// data tied to a job — deleting the job should delete these, not
		// leave dangling rows a report could still pick up.
		$m->add_foreign_key_safely( $wpdb, "{$p}jp_saved_jobs", 'job_id', "{$p}jp_jobs", 'id', 'CASCADE', 'fk_saved_jobs_job' );
		$m->add_foreign_key_safely( $wpdb, "{$p}jp_matches", 'job_id', "{$p}jp_jobs", 'id', 'CASCADE', 'fk_matches_job' );
		$m->add_foreign_key_safely( $wpdb, "{$p}jp_matches", 'candidate_id', "{$p}jp_candidates", 'id', 'CASCADE', 'fk_matches_candidate' );

		// Reviews belong to a company.
		$m->add_foreign_key_safely( $wpdb, "{$p}jp_reviews", 'company_id', "{$p}jp_companies", 'id', 'CASCADE', 'fk_reviews_company' );

		// Messages within a thread — unambiguous same-plugin relation.
		$m->add_foreign_key_safely( $wpdb, "{$p}jp_messages", 'thread_id', "{$p}jp_message_threads", 'id', 'CASCADE', 'fk_messages_thread' );

		// Webhook delivery history belongs to nothing that has a real FK
		// target — webhook_id is a string key into the jp_webhooks option,
		// not a row in a table — so intentionally not touched here.
	},
];
