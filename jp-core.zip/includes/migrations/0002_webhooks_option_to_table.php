<?php
/**
 * Migration 0002 — move webhook subscriptions out of the single serialized
 * `jp_webhooks` wp_options row and into a real `jp_webhooks` table (gap
 * analysis P1 #139). See class-jp-activator.php's schema comment for the
 * full root-cause explanation; this migration is the one-time data move —
 * the table itself is created additively by dbDelta, as usual, but dbDelta
 * only manages schema, not existing data, so copying the option's rows
 * across needs an explicit migration step.
 *
 * Safe to re-run: each row is inserted with INSERT IGNORE against the
 * table's own id PRIMARY KEY, so running this twice (e.g. if a prior
 * attempt failed partway through) never duplicates a row. The option is
 * only deleted after every row it contained has been confirmed present in
 * the table.
 */
defined( 'ABSPATH' ) || exit;

return [
	'version'     => 2,
	'description' => 'Move jp_webhooks option data into a real jp_webhooks table',
	'up'          => function ( \wpdb $wpdb ): void {
		$hooks = get_option( 'jp_webhooks', [] );
		if ( ! is_array( $hooks ) || empty( $hooks ) ) {
			delete_option( 'jp_webhooks' );
			return;
		}

		$table   = $wpdb->prefix . 'jp_webhooks';
		$all_ok  = true;

		foreach ( $hooks as $hook ) {
			if ( empty( $hook['id'] ) || empty( $hook['url'] ) ) { $all_ok = false; continue; }

			$id = (string) $hook['id'];

			// Already migrated (e.g. a prior interrupted run) — skip.
			$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE id = %s", $id ) );
			if ( $exists ) continue;

			$result = $wpdb->query( $wpdb->prepare(
				"INSERT IGNORE INTO {$table} (id, url, events_json, secret, active, created_at) VALUES (%s, %s, %s, %s, %d, %s)",
				$id,
				(string) $hook['url'],
				wp_json_encode( (array) ( $hook['events'] ?? [] ) ),
				(string) ( $hook['secret'] ?? wp_generate_password( 32, false ) ),
				empty( $hook['active'] ) ? 0 : 1,
				! empty( $hook['created_at'] ) ? $hook['created_at'] : current_time( 'mysql' )
			) );

			if ( false === $result ) $all_ok = false;
		}

		// Only remove the legacy option once every row it held is confirmed
		// present in the table — if something failed partway through, leave
		// the option in place so the next request's migration run retries
		// the remaining rows instead of silently losing them.
		if ( $all_ok ) {
			delete_option( 'jp_webhooks' );
			return;
		}

		// Throw rather than just logging: JP_Migrator records this
		// migration's outcome by whether 'up' throws, and only retries a
		// migration on the next request if its last recorded status was
		// 'failed'. Silently swallowing the partial failure here would get
		// this migration marked 'success' despite the option (and whatever
		// rows didn't copy) still being left behind — never retried again.
		throw new \Exception( 'jp_webhooks option → table migration: one or more rows failed to copy; option left in place for retry.' );
	},
];
