<?php
/**
 * Class JP_SMTP — Configures wp_mail to use SMTP credentials from wp-config.php.
 *
 * Add to wp-config.php:
 *   define('JP_SMTP_HOST',  'smtp.sendgrid.net');
 *   define('JP_SMTP_PORT',  587);
 *   define('JP_SMTP_USER',  'apikey');
 *   define('JP_SMTP_PASS',  'SG.xxxxxxxx');
 *   define('JP_SMTP_FROM',  'noreply@yoursite.com');
 *   define('JP_SMTP_SECURE','tls');  // 'ssl' or 'tls'
 *
 * Falls back to native PHP mail() if SMTP is not configured.
 * Works with SendGrid, Mailgun, Postmark, Gmail (App Password), or any SMTP relay.
 */
defined( 'ABSPATH' ) || exit;

class JP_SMTP {

	private static ?JP_SMTP $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		if ( ! $this->is_configured() ) return;

		add_action( 'phpmailer_init', [ $this, 'configure_mailer' ] );
		add_filter( 'wp_mail_from',      [ $this, 'from_email' ] );
		add_filter( 'wp_mail_from_name', [ $this, 'from_name' ] );
	}

	public function configure_mailer( \PHPMailer\PHPMailer\PHPMailer $mailer ): void {
		$mailer->isSMTP();
		$mailer->Host        = defined('JP_SMTP_HOST')   ? JP_SMTP_HOST   : '';
		$mailer->Port        = defined('JP_SMTP_PORT')   ? (int)JP_SMTP_PORT : 587;
		$mailer->SMTPAuth    = true;
		$mailer->Username    = defined('JP_SMTP_USER')   ? JP_SMTP_USER   : '';
		$mailer->Password    = defined('JP_SMTP_PASS')   ? JP_SMTP_PASS   : '';
		$mailer->SMTPSecure  = defined('JP_SMTP_SECURE') ? JP_SMTP_SECURE : 'tls';
		$mailer->SMTPOptions = [
			'ssl' => [
				'verify_peer'       => true,
				'verify_peer_name'  => true,
				'allow_self_signed' => false,
			],
		];
	}

	public function from_email( string $email ): string {
		$configured = defined('JP_SMTP_FROM') ? JP_SMTP_FROM : '';
		return $configured ?: $email;
	}

	public function from_name( string $name ): string {
		$configured = get_option('jp_smtp_from_name','');
		return $configured ?: jp_site_name();
	}

	private function is_configured(): bool {
		return defined('JP_SMTP_HOST') && JP_SMTP_HOST
			&& defined('JP_SMTP_USER') && JP_SMTP_USER;
	}
}
