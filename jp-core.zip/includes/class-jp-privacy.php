<?php
/**
 * Class JP_Privacy — GDPR/data-subject-request tooling, company offboarding,
 * and audit-logged user impersonation.
 *
 * ROOT CAUSE (see enterprise-gap-analysis.md §0/§12, P0 if serving any
 * EU/UK/CA users): grep-confirmed zero use anywhere in this codebase of
 * WordPress's native personal-data export/eraser hooks
 * (`wp_privacy_personal_data_exporters` / `_erasers`), despite the platform
 * storing resumes, phone numbers, SMS logs, and IP-tagged audit trails.
 * WordPress core ships an entire admin UI (Tools → Export/Erase Personal
 * Data) built specifically to drive verifiable data-subject requests, and
 * this plugin simply never plugged into it — every existing "export" was
 * a bespoke, candidate-initiated, incomplete REST endpoint (fixed
 * separately in class-jp-api.php::account_export()) with no admin-driven,
 * verifiable workflow at all.
 *
 * This class also implements two capabilities that were declared and
 * granted (`jp_impersonate_users`, `jp_export_data` — class-jp-roles.php)
 * but never checked or implemented anywhere (gap analysis bug #19):
 * dead capabilities that make the permission system lie about what the
 * product can actually do.
 */
defined( 'ABSPATH' ) || exit;

class JP_Privacy {

	private static ?JP_Privacy $instance = null;

	/** How long an impersonation session is allowed to run before auto-expiring. */
	private const IMPERSONATION_MAX_SECONDS = 1800; // 30 minutes

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		// ── WordPress-native GDPR hooks ──────────────────────────────────────
		add_filter( 'wp_privacy_personal_data_exporters', [ $this, 'register_exporter' ] );
		add_filter( 'wp_privacy_personal_data_erasers',   [ $this, 'register_eraser' ] );

		// ── Company offboarding (admin-initiated) ───────────────────────────
		add_action( 'wp_ajax_jp_admin_export_company', [ $this, 'ajax_export_company' ] );
		add_action( 'wp_ajax_jp_admin_erase_company',  [ $this, 'ajax_erase_company' ] );

		// ── Impersonation ────────────────────────────────────────────────────
		add_action( 'wp_ajax_jp_impersonate_start', [ $this, 'ajax_impersonate_start' ] );
		add_action( 'wp_ajax_jp_impersonate_stop',  [ $this, 'ajax_impersonate_stop' ] );
		// Checked on every admin request (cheap: one transient read) so a
		// forgotten impersonation session can never outlive its time box,
		// even if the admin never clicks "stop".
		add_action( 'admin_init', [ $this, 'maybe_auto_expire_impersonation' ] );
		add_action( 'init',       [ $this, 'maybe_auto_expire_impersonation' ] );
	}

	// ── WP-native personal data EXPORT ──────────────────────────────────────

	public function register_exporter( array $exporters ): array {
		$exporters['jp-core-candidate-data'] = [
			'exporter_friendly_name' => __( 'Job Portal — candidate account data', 'jp-core' ),
			'callback'               => [ $this, 'export_user_data' ],
		];
		return $exporters;
	}

	/**
	 * WP's exporter contract: given an email address (not a user ID — the
	 * admin tool works from the email the data subject provided), return
	 * every group of personal data for that person, paginated. This is the
	 * single most complete personal-data query in the codebase — it is
	 * what "verifiable" actually means for a data-subject request, versus
	 * the previous single incomplete REST endpoint that only covered 4
	 * tables and had no way for an admin to run it on someone else's
	 * behalf at all.
	 */
	public function export_user_data( string $email_address, int $page = 1 ): array {
		global $wpdb;
		$user = get_user_by( 'email', $email_address );
		if ( ! $user ) {
			return [ 'data' => [], 'done' => true ];
		}
		$uid = $user->ID;
		$export_items = [];

		$group = function ( string $group_id, string $group_label, string $item_id, array $rows, array $field_map ) use ( &$export_items ) {
			foreach ( $rows as $i => $row ) {
				$data = [];
				foreach ( $field_map as $col => $label ) {
					$val = is_object( $row ) ? ( $row->$col ?? '' ) : ( $row[ $col ] ?? '' );
					if ( $val === '' || $val === null ) continue;
					$data[] = [ 'name' => $label, 'value' => is_scalar( $val ) ? (string) $val : wp_json_encode( $val ) ];
				}
				if ( $data ) {
					$export_items[] = [
						'group_id'    => $group_id,
						'group_label' => $group_label,
						'item_id'     => "{$item_id}-{$i}",
						'data'        => $data,
					];
				}
			}
		};

		$candidate = JP_DB::instance()->get_candidate( $uid );
		if ( $candidate ) {
			$group( 'jp-profile', __( 'Candidate Profile', 'jp-core' ), 'profile', [ $candidate ], [
				'headline' => 'Headline', 'about' => 'About', 'phone' => 'Phone',
				'location_city' => 'City', 'location_state' => 'State',
				'expected_salary_min' => 'Expected Salary (Min)', 'expected_salary_max' => 'Expected Salary (Max)',
				'portfolio_url' => 'Portfolio URL', 'linkedin_url' => 'LinkedIn URL', 'github_url' => 'GitHub URL',
			] );
		}

		$applications = $wpdb->get_results( $wpdb->prepare( "SELECT a.*, j.title AS job_title FROM {$wpdb->prefix}jp_applications a LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id WHERE a.candidate_id=%d", $uid ) );
		$group( 'jp-applications', __( 'Job Applications', 'jp-core' ), 'application', $applications, [
			'job_title' => 'Job', 'stage' => 'Stage', 'cover_letter' => 'Cover Letter', 'created_at' => 'Applied On',
		] );

		$saved_jobs = $wpdb->get_results( $wpdb->prepare( "SELECT sj.*, j.title AS job_title FROM {$wpdb->prefix}jp_saved_jobs sj LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=sj.job_id WHERE sj.user_id=%d", $uid ) );
		$group( 'jp-saved-jobs', __( 'Saved Jobs', 'jp-core' ), 'saved-job', $saved_jobs, [ 'job_title' => 'Job', 'note' => 'Note', 'saved_at' => 'Saved On' ] );

		$alerts = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_alerts WHERE user_id=%d", $uid ) );
		$group( 'jp-alerts', __( 'Job Alerts', 'jp-core' ), 'alert', $alerts, [ 'name' => 'Name', 'keywords' => 'Keywords', 'location' => 'Location', 'created_at' => 'Created' ] );

		$threads = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_message_threads WHERE recruiter_id=%d OR candidate_id=%d", $uid, $uid ) );
		$group( 'jp-messages', __( 'Message Threads', 'jp-core' ), 'thread', $threads, [ 'subject' => 'Subject', 'last_message' => 'Last Message', 'last_at' => 'Last Activity' ] );

		$assessments = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_assessments WHERE user_id=%d", $uid ) );
		$group( 'jp-assessments', __( 'Skill Assessments', 'jp-core' ), 'assessment', $assessments, [ 'skill_id' => 'Skill ID', 'score' => 'Score', 'badge_level' => 'Badge', 'taken_at' => 'Taken On' ] );

		$reviews = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_reviews WHERE user_id=%d", $uid ) );
		$group( 'jp-reviews', __( 'Company Reviews Authored', 'jp-core' ), 'review', $reviews, [ 'title' => 'Title', 'pros' => 'Pros', 'cons' => 'Cons', 'rating_overall' => 'Overall Rating', 'created_at' => 'Posted On' ] );

		$badges = $wpdb->get_results( $wpdb->prepare( "SELECT badge, awarded_at FROM {$wpdb->prefix}jp_user_badges WHERE user_id=%d", $uid ) );
		$group( 'jp-badges', __( 'Badges', 'jp-core' ), 'badge', $badges, [ 'badge' => 'Badge', 'awarded_at' => 'Awarded On' ] );

		return [ 'data' => $export_items, 'done' => true ];
	}

	// ── WP-native personal data ERASE ────────────────────────────────────────

	public function register_eraser( array $erasers ): array {
		$erasers['jp-core-candidate-data'] = [
			'eraser_friendly_name' => __( 'Job Portal — candidate account data', 'jp-core' ),
			'callback'             => [ $this, 'erase_user_data' ],
		];
		return $erasers;
	}

	public function erase_user_data( string $email_address, int $page = 1 ): array {
		global $wpdb;
		$user = get_user_by( 'email', $email_address );
		if ( ! $user ) {
			return [ 'items_removed' => false, 'items_retained' => false, 'messages' => [], 'done' => true ];
		}
		$uid = $user->ID;
		$removed = 0;
		// Root-cause fix (batch 18): every write below previously either
		// discarded its result entirely or cast it straight to int, which
		// collapses `false` (write error) and `0` (nothing to delete, a
		// perfectly normal outcome) to the same value. That distinction
		// matters specifically here: this is a GDPR erasure callback whose
		// contract (WP's `wp_privacy_personal_data_erasers` filter) is read
		// by WordPress core's own Privacy Tools admin UI, which displays
		// `messages` to the person running the request and decides whether
		// to mark the request "Completed" partly from `items_retained`. A
		// failed delete previously vanished into that 0/false ambiguity —
		// core would report the erasure complete with no indication that a
		// candidate's data actually survived it. $errors below tracks real
		// write failures separately from "nothing was there to remove".
		$errors = [];

		// Same table set as JP_Api::account_delete() plus the export gap's
		// additional tables — this is the canonical "erase everything" list
		// both code paths should agree on; account_delete() remains the
		// user-initiated self-service flow, this is the admin/DSR-driven one.
		foreach ( [ 'jp_notifications', 'jp_push_subscriptions', 'jp_user_badges',
					'jp_resume_sections', 'jp_saved_jobs', 'jp_alerts', 'jp_assessments' ] as $table ) {
			$result = $wpdb->delete( $wpdb->prefix . $table, [ 'user_id' => $uid ] );
			if ( false === $result ) {
				$errors[] = $table;
			} else {
				$removed += (int) $result;
			}
		}
		$thread_result = $wpdb->query( $wpdb->prepare(
			"DELETE FROM {$wpdb->prefix}jp_message_threads WHERE recruiter_id=%d OR candidate_id=%d", $uid, $uid
		) );
		if ( false === $thread_result ) {
			$errors[] = 'jp_message_threads';
		} else {
			$removed += (int) $thread_result;
		}
		// Reviews are anonymised rather than deleted (a company's aggregate
		// rating and reply thread are legitimate business records that
		// don't belong solely to the reviewer once posted), matching how
		// most GDPR-mature platforms treat published reviews: identity is
		// erased, the review content itself is retained.
		$review_result = $wpdb->update( $wpdb->prefix . 'jp_reviews', [ 'user_id' => 0, 'is_anonymous' => 1 ], [ 'user_id' => $uid ] );
		if ( false === $review_result ) {
			$errors[] = 'jp_reviews';
		} else {
			$removed += (int) $review_result;
		}
		if ( false === $wpdb->update( $wpdb->prefix . 'jp_candidates', [ 'visibility' => 'private', 'is_open_to_work' => 0, 'avatar_url' => '' ], [ 'user_id' => $uid ] ) ) {
			$errors[] = 'jp_candidates';
		}

		if ( $errors && class_exists( 'JP_ErrorLog' ) ) {
			JP_ErrorLog::instance()->log_exception( new \Exception( 'GDPR erasure write failure on table(s): ' . implode( ', ', $errors ) . ' — ' . $wpdb->last_error ), 'JP_Privacy::erase_user_data uid=' . $uid );
		}

		if ( class_exists( 'JP_Security' ) ) {
			JP_Security::instance()->audit( 'gdpr_erasure_completed', 'account', $uid, "Erased/anonymised {$removed} row(s) across candidate data tables via WP personal-data-eraser." . ( $errors ? ' INCOMPLETE — failed on: ' . implode( ', ', $errors ) : '' ) );
		}

		return [
			'items_removed'  => $removed > 0,
			// Reporting true here means "we could not confirm everything was
			// erased" — the honest signal for WP core's Privacy Tools UI to
			// surface to whoever is running this request, instead of a blanket
			// "done" when part of the erasure silently failed.
			'items_retained' => (bool) $errors,
			'messages'       => $errors ? [ __( 'Some candidate data could not be fully erased due to a database error. Please retry this request or contact support.', 'jp-core' ) ] : [],
			'done'           => true,
		];
	}

	// ── Company offboarding (admin-initiated, gap analysis §12) ─────────────

	private function require_export_capability(): bool {
		return current_user_can( 'jp_export_data' ) || current_user_can( 'manage_options' );
	}

	// ── Shared logic (plain methods, no $_POST/wp_send_json coupling) ────────
	//
	// Root-cause fix (found while auditing the still-pending WP-Admin-only
	// settings areas, specifically "Privacy/Offboarding"): company
	// offboarding export/erase and admin impersonation have existed as
	// wp_ajax_* handlers since an earlier pass, authenticated via
	// check_ajax_referer() against a 'jp_admin_privacy' cookie nonce the
	// REST-only SPA never has — confirmed by grepping class-jp-api.php's
	// route table, which has none for any of this. An admin using the SPA
	// (the only front-end this plugin now ships) could not offboard a
	// company or impersonate a user to reproduce their bug report at all.
	// Extracted into plain methods returning WP_Error|array|true (same
	// pattern already used for JP_FeatureFlags's save_flag()/delete_flag())
	// so the legacy AJAX handlers and the new REST callbacks in
	// class-jp-api.php share one implementation instead of two that can
	// drift.

	/**
	 * Export everything belonging to a company — its jobs, applications,
	 * team members, and payment history — for offboarding. Returns the
	 * export data array, or a WP_Error on validation/permission failure.
	 */
	public function export_company( int $company_id, bool $has_permission ) {
		if ( ! $has_permission ) return new \WP_Error( 'jp_privacy_forbidden', 'Insufficient permissions.', [ 'status' => 403 ] );
		if ( ! $company_id ) return new \WP_Error( 'jp_privacy_invalid', 'company_id is required.' );

		global $wpdb;
		$data = [
			'exported_at' => current_time( 'mysql' ),
			'company'     => $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_companies WHERE id=%d", $company_id ) ),
			'jobs'        => $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_jobs WHERE company_id=%d", $company_id ) ),
			'applications'=> $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_applications WHERE company_id=%d", $company_id ) ),
			'team_members'=> $wpdb->get_results( $wpdb->prepare( "SELECT id, user_id, invited_email, role, status, invited_at, accepted_at FROM {$wpdb->prefix}jp_team_members WHERE company_id=%d", $company_id ) ),
			'reviews'     => $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_reviews WHERE company_id=%d", $company_id ) ),
			'subscriptions' => $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_subscriptions WHERE company_id=%d", $company_id ) ),
		];

		JP_Security::instance()->audit( 'company_data_exported', 'company', $company_id, 'Admin-initiated company offboarding export.', $company_id );
		return $data;
	}

	/**
	 * Erase a company's data on offboarding. Deliberately soft/cascading
	 * via the FK constraints added in migration 0001 (jobs, applications,
	 * team_members, reviews all CASCADE off jp_companies.id) rather than
	 * hand-rolling per-table DELETEs here a second time — one source of
	 * truth for "what depends on a company" instead of two that can drift
	 * apart. Falls back to explicit per-table deletes if the FK migration
	 * has not run yet (e.g. this endpoint is hit before the migration
	 * completes on a given environment), so this is correct either way.
	 * Returns true on success, or a WP_Error on validation/permission failure.
	 */
	public function erase_company( int $company_id, bool $has_permission ) {
		if ( ! $has_permission ) return new \WP_Error( 'jp_privacy_forbidden', 'Insufficient permissions.', [ 'status' => 403 ] );
		if ( ! $company_id ) return new \WP_Error( 'jp_privacy_invalid', 'company_id is required.' );

		global $wpdb;
		$fk_active = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND CONSTRAINT_NAME = 'fk_jobs_company' AND CONSTRAINT_TYPE = 'FOREIGN KEY'",
			DB_NAME, $wpdb->prefix . 'jp_jobs'
		) );

		if ( ! $fk_active ) {
			// Fallback path: no FK yet, delete explicitly in dependency order.
			// Root-cause fix (batch 18): these were unchecked. Logged-only on
			// failure (not fatal here) because the final jp_companies delete
			// below is what actually determines success/failure of the whole
			// operation — if a dependent row survives because one of these
			// failed, it becomes an orphan (company_id pointing at a deleted
			// company), which is exactly the class of bug this comment block
			// already calls out as worth avoiding by relying on FK CASCADE.
			foreach ( [ 'jp_applications', 'jp_jobs', 'jp_team_members', 'jp_reviews' ] as $dependent_table ) {
				$dep_result = $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->prefix}{$dependent_table} WHERE company_id=%d", $company_id ) );
				if ( false === $dep_result && class_exists( 'JP_ErrorLog' ) ) {
					JP_ErrorLog::instance()->log_exception( new \Exception( "{$dependent_table} fallback delete failed: " . $wpdb->last_error ), 'JP_Privacy::erase_company company_id=' . $company_id );
				}
			}
		}
		// Deleting the company row itself cascades everything above when
		// the FK constraints are active; this DELETE is unconditional and
		// correct in both cases (fallback path already removed dependents).
		//
		// Root-cause fix (batch 18): this was unchecked and the method
		// unconditionally `return true` afterward — the single most
		// consequential ghost-success shape possible for an "erase this
		// company" operation: an admin offboarding a company (often for a
		// legal/compliance reason) would be told it succeeded even if the
		// company row, and everything gated on its existence, was still
		// fully live and visible.
		if ( false === $wpdb->delete( $wpdb->prefix . 'jp_companies', [ 'id' => $company_id ] ) ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_companies delete failed: ' . $wpdb->last_error ), 'JP_Privacy::erase_company company_id=' . $company_id );
			}
			return new \WP_Error( 'jp_privacy_erase_failed', 'Could not erase this company. Please try again.' );
		}

		JP_Security::instance()->audit( 'company_data_erased', 'company', $company_id, 'Admin-initiated company offboarding erasure.' );
		return true;
	}

	// ── Impersonation (gap analysis bug #19) ─────────────────────────────────

	/**
	 * Start impersonating $target_user_id as the given admin. Time-boxed
	 * (IMPERSONATION_MAX_SECONDS), fully audit-logged on both start and
	 * (automatic or manual) stop, and reversible only by the admin who
	 * started it — the original admin's ID is stored server-side (a
	 * transient, never trusted from client input) so there is no way for
	 * the impersonated session itself to escalate back to a DIFFERENT
	 * admin identity than the one who actually initiated it. Returns the
	 * success payload array, or a WP_Error on validation/permission failure.
	 */
	public function start_impersonation( int $target_id, int $admin_id, bool $has_permission ) {
		if ( ! $has_permission ) return new \WP_Error( 'jp_privacy_forbidden', 'Insufficient permissions.', [ 'status' => 403 ] );

		$target = get_userdata( $target_id );
		if ( ! $target ) return new \WP_Error( 'jp_privacy_not_found', 'User not found.', [ 'status' => 404 ] );

		// Never allow impersonating another administrator — this feature
		// exists to reproduce a REPORTED USER'S bug from their own session,
		// not to let one admin quietly take over another admin's account.
		if ( in_array( 'administrator', (array) $target->roles, true ) ) {
			return new \WP_Error( 'jp_privacy_forbidden', 'Cannot impersonate an administrator account.', [ 'status' => 403 ] );
		}

		set_transient( 'jp_impersonation_' . $admin_id, [
			'target_id'  => $target_id,
			'started_at' => time(),
		], self::IMPERSONATION_MAX_SECONDS );
		// Marks the TARGET user's session as "currently being impersonated
		// by $admin_id" so maybe_auto_expire_impersonation() can find the
		// right transient from inside the impersonated session (which has
		// no other way to know which admin started it). Cleared the moment
		// impersonation ends, by either path.
		update_user_meta( $target_id, '_jp_impersonated_by', $admin_id );

		JP_Security::instance()->audit( 'impersonation_started', 'user', $target_id, "Admin #{$admin_id} started impersonating user #{$target_id} ({$target->user_email}) for up to " . (self::IMPERSONATION_MAX_SECONDS / 60) . ' minutes.' );

		wp_set_current_user( $target_id );
		wp_set_auth_cookie( $target_id );

		return [
			'message'    => 'Now impersonating ' . $target->display_name . '. This will automatically end in ' . (self::IMPERSONATION_MAX_SECONDS / 60) . ' minutes.',
			'expires_at' => time() + self::IMPERSONATION_MAX_SECONDS,
		];
	}

	/** Public wrapper — REST callback needs a non-private entry point. */
	public function stop_impersonation(): void {
		$this->end_impersonation_for_current_session( 'manual' );
	}

	// ── Legacy AJAX entry points (thin wrappers over the methods above) ────────

	public function ajax_export_company(): void {
		check_ajax_referer( 'jp_admin_privacy', 'nonce' );
		$result = $this->export_company( (int) ( $_POST['company_id'] ?? 0 ), $this->require_export_capability() );
		if ( is_wp_error( $result ) ) jp_json_response( false, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
		jp_json_response( true, $result );
	}

	public function ajax_erase_company(): void {
		check_ajax_referer( 'jp_admin_privacy', 'nonce' );
		$result = $this->erase_company( (int) ( $_POST['company_id'] ?? 0 ), current_user_can( 'manage_options' ) );
		if ( is_wp_error( $result ) ) jp_json_response( false, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
		jp_json_response( true, [ 'message' => 'Company and all associated data erased.' ] );
	}

	public function ajax_impersonate_start(): void {
		check_ajax_referer( 'jp_admin_privacy', 'nonce' );
		$has_perm = current_user_can( 'jp_impersonate_users' ) || current_user_can( 'manage_options' );
		$result   = $this->start_impersonation( (int) ( $_POST['user_id'] ?? 0 ), get_current_user_id(), $has_perm );
		if ( is_wp_error( $result ) ) jp_json_response( false, $result->get_error_message(), $result->get_error_data()['status'] ?? 400 );
		jp_json_response( true, $result );
	}

	public function ajax_impersonate_stop(): void {
		check_ajax_referer( 'jp_admin_privacy', 'nonce' );
		$this->stop_impersonation();
		jp_json_response( true, [ 'message' => 'Impersonation ended.' ] );
	}

	/**
	 * Runs on every request. If the CURRENT session is an active
	 * impersonation whose time box has expired, restore the original admin
	 * automatically — this is what makes the time-box a real guarantee
	 * rather than an honor system that depends on the admin remembering to
	 * click "stop".
	 */
	public function maybe_auto_expire_impersonation(): void {
		$uid = get_current_user_id();
		if ( ! $uid ) return;

		// Search for a transient whose stored target_id matches the CURRENT
		// user — i.e. we are currently logged in AS someone being
		// impersonated. We don't know the admin's ID directly from the
		// impersonated session, so the transient is keyed by admin_id but
		// we look it up via a secondary marker set at start time.
		$admin_id = (int) get_user_meta( $uid, '_jp_impersonated_by', true );
		if ( ! $admin_id ) return;

		$session = get_transient( 'jp_impersonation_' . $admin_id );
		if ( ! $session || (int) $session['target_id'] !== $uid ) return;

		if ( ( time() - (int) $session['started_at'] ) >= self::IMPERSONATION_MAX_SECONDS ) {
			$this->end_impersonation_for_current_session( 'auto_expired', $admin_id );
		}
	}

	private function end_impersonation_for_current_session( string $reason, int $admin_id = 0 ): void {
		$current_uid = get_current_user_id();
		if ( ! $admin_id ) {
			$admin_id = (int) get_user_meta( $current_uid, '_jp_impersonated_by', true );
		}
		if ( $admin_id ) {
			delete_transient( 'jp_impersonation_' . $admin_id );
			delete_user_meta( $current_uid, '_jp_impersonated_by' );
			JP_Security::instance()->audit( 'impersonation_ended', 'user', $current_uid, "Impersonation of user #{$current_uid} by admin #{$admin_id} ended ({$reason})." );
			wp_set_current_user( $admin_id );
			wp_set_auth_cookie( $admin_id );
		}
	}
}
