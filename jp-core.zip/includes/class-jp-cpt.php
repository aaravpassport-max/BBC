<?php
defined( 'ABSPATH' ) || exit;

/**
 * JP_CPT — Registers custom post types and taxonomies.
 * Post types: jp_job, jp_company, jp_event
 * Taxonomies: jp_industry, jp_location, jp_skill, jp_advice_cat
 */
class JP_CPT {

    private static ?JP_CPT $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
            self::$instance->init();
        }
        return self::$instance;
    }

    private function init(): void {
        add_action( 'init', [ $this, 'register_post_types' ] );
        add_action( 'init', [ $this, 'register_taxonomies' ] );
    }

    // ── Post Types ────────────────────────────────────────────────────────────

    public function register_post_types(): void {
        // ── jp_job ────────────────────────────────────────────────────────────
        register_post_type( 'jp_job', [
            'labels' => [
                'name'               => __( 'Jobs', 'jp-core' ),
                'singular_name'      => __( 'Job', 'jp-core' ),
                'add_new'            => __( 'Post Job', 'jp-core' ),
                'add_new_item'       => __( 'Post New Job', 'jp-core' ),
                'edit_item'          => __( 'Edit Job', 'jp-core' ),
                'view_item'          => __( 'View Job', 'jp-core' ),
                'search_items'       => __( 'Search Jobs', 'jp-core' ),
                'not_found'          => __( 'No jobs found.', 'jp-core' ),
                'menu_name'          => __( 'Jobs', 'jp-core' ),
            ],
            'public'             => true,
            // Root-cause fix (roadmap re-audit, Part 3.3: "no wp-admin
            // screens for product configuration"): 'public' => true with no
            // show_ui override defaults show_ui to true, which is exactly
            // what it sounds like nothing else in this codebase intended —
            // WordPress was rendering a full native "Jobs" edit-screen and
            // top-level admin menu (menu_icon below) for this post type, and
            // nothing in the REST/SPA layer or anywhere else in this plugin
            // ever reads or writes a job via wp_posts/jp_job — the real data
            // lives in the custom {$wpdb->prefix}jp_jobs table (see
            // admin_health()'s active_jobs count and every /admin/jobs* REST
            // route in class-jp-api.php). An admin could "Post New Job"
            // through this screen and create a post that never appears
            // anywhere on the actual site — silently misleading, not just
            // architecturally wrong. show_ui => false removes the wp-admin
            // screens/menu while leaving 'public', rewrite, has_archive, and
            // show_in_rest untouched, so nothing about front-end routing or
            // the REST API surface changes.
            'show_ui'            => false,
            // Root-cause fix: this plugin also creates a real WordPress Page
            // at the exact same slug ('jobs' — see JP_Activator::create_pages(),
            // the "Find Jobs" page). With has_archive => true, WordPress
            // registers the CPT archive's rewrite rule for /jobs/ ahead of the
            // Page's own rewrite rule, so the archive rule always wins that
            // URL — every request to /jobs/ was routed to archive-jp_job.php
            // instead of the real page, and that fallback template did
            // wp_redirect(home_url('/jobs/'), 301) — an unconditional redirect
            // back to the EXACT URL that was just requested. That is a literal
            // infinite self-redirect: ERR_TOO_MANY_REDIRECTS on /jobs/. The
            // dedicated Page already serves this URL; the CPT archive rule
            // was entirely redundant and actively broke the URL it collided
            // with. Disabling has_archive removes the competing rewrite rule
            // so the real Page unambiguously owns /jobs/.
            'has_archive'        => false,
            'rewrite'            => [ 'slug' => 'jobs', 'with_front' => false ],
            'show_in_rest'       => true,
            'supports'           => [ 'title', 'editor', 'author', 'thumbnail', 'custom-fields' ],
            'menu_icon'          => 'dashicons-briefcase',
            'taxonomies'         => [ 'jp_industry', 'jp_location', 'jp_skill' ],
            'capability_type'    => 'post',
            'map_meta_cap'       => true,
        ] );

        // ── jp_company ────────────────────────────────────────────────────────
        register_post_type( 'jp_company', [
            'labels' => [
                'name'               => __( 'Companies', 'jp-core' ),
                'singular_name'      => __( 'Company', 'jp-core' ),
                'add_new_item'       => __( 'Add Company', 'jp-core' ),
                'edit_item'          => __( 'Edit Company', 'jp-core' ),
                'view_item'          => __( 'View Company', 'jp-core' ),
                'search_items'       => __( 'Search Companies', 'jp-core' ),
                'not_found'          => __( 'No companies found.', 'jp-core' ),
                'menu_name'          => __( 'Companies', 'jp-core' ),
            ],
            'public'             => true,
            // Root-cause fix (roadmap re-audit): same reasoning as jp_job
            // above — real company data lives in {$wpdb->prefix}jp_companies,
            // not wp_posts/jp_company, so the native wp-admin edit screen
            // this defaulted to (public => true, no show_ui override) was
            // pure dead-weight wp-admin UI over data nothing else reads.
            'show_ui'            => false,
            // Root-cause fix: same collision as jp_job above, against the
            // real "Companies" Page created at the 'companies' slug — see
            // JP_Activator::create_pages(). Disabling has_archive lets that
            // Page own /companies/ instead of losing it to the CPT archive
            // rewrite rule and archive-jp_company.php's self-redirect.
            'has_archive'        => false,
            'rewrite'            => [ 'slug' => 'companies', 'with_front' => false ],
            'show_in_rest'       => true,
            'supports'           => [ 'title', 'editor', 'thumbnail', 'custom-fields' ],
            'menu_icon'          => 'dashicons-building',
            'taxonomies'         => [ 'jp_industry' ],
            'capability_type'    => 'post',
            'map_meta_cap'       => true,
        ] );

        // ── jp_event ─────────────────────────────────────────────────────────
        register_post_type( 'jp_event', [
            'labels' => [
                'name'          => __( 'Events', 'jp-core' ),
                'singular_name' => __( 'Event', 'jp-core' ),
                'add_new_item'  => __( 'Add Event', 'jp-core' ),
                'menu_name'     => __( 'Events', 'jp-core' ),
            ],
            'public'             => true,
            // Root-cause fix (roadmap re-audit): confirmed via
            // class-jp-api.php's admin_events()/admin_save_event() — real
            // event data lives in {$wpdb->prefix}jp_events (its own CREATE
            // TABLE in class-jp-activator.php), not wp_posts/jp_event. Same
            // dead wp-admin-UI pattern as jp_job/jp_company above.
            'show_ui'            => false,
            'has_archive'        => true,
            'rewrite'            => [ 'slug' => 'events', 'with_front' => false ],
            'show_in_rest'       => true,
            'supports'           => [ 'title', 'editor', 'thumbnail', 'custom-fields' ],
            'menu_icon'          => 'dashicons-calendar-alt',
            'capability_type'    => 'post',
            'map_meta_cap'       => true,
        ] );
    }

    // ── Taxonomies ────────────────────────────────────────────────────────────

    public function register_taxonomies(): void {
        // jp_industry — hierarchical (like categories)
        register_taxonomy( 'jp_industry', [ 'jp_job', 'jp_company' ], [
            'labels' => [
                'name'          => __( 'Industries', 'jp-core' ),
                'singular_name' => __( 'Industry', 'jp-core' ),
                'menu_name'     => __( 'Industries', 'jp-core' ),
            ],
            'hierarchical'      => true,
            'public'            => true,
            'show_in_rest'      => true,
            'rewrite'           => [ 'slug' => 'industry', 'with_front' => false ],
            'show_admin_column' => true,
        ] );

        // jp_location — city-based, flat
        register_taxonomy( 'jp_location', [ 'jp_job' ], [
            'labels' => [
                'name'          => __( 'Job Locations', 'jp-core' ),
                'singular_name' => __( 'Location', 'jp-core' ),
                'menu_name'     => __( 'Locations', 'jp-core' ),
            ],
            'hierarchical'      => false,
            'public'            => true,
            'show_in_rest'      => true,
            'rewrite'           => [ 'slug' => 'jobs-in', 'with_front' => false ],
            'show_admin_column' => true,
        ] );

        // jp_skill — shared across jobs and candidates
        register_taxonomy( 'jp_skill', [ 'jp_job' ], [
            'labels' => [
                'name'          => __( 'Skills', 'jp-core' ),
                'singular_name' => __( 'Skill', 'jp-core' ),
                'menu_name'     => __( 'Skills', 'jp-core' ),
            ],
            'hierarchical'      => false,
            'public'            => true,
            'show_in_rest'      => true,
            'rewrite'           => [ 'slug' => 'jobs-for', 'with_front' => false ],
            'show_admin_column' => true,
        ] );

        // jp_advice_cat — blog categories for career advice
        register_taxonomy( 'jp_advice_cat', [ 'post' ], [
            'labels' => [
                'name'          => __( 'Advice Categories', 'jp-core' ),
                'singular_name' => __( 'Advice Category', 'jp-core' ),
                'menu_name'     => __( 'Career Advice', 'jp-core' ),
            ],
            'hierarchical'      => true,
            'public'            => true,
            'show_in_rest'      => true,
            'rewrite'           => [ 'slug' => 'career-advice', 'with_front' => false ],
            'show_admin_column' => true,
        ] );
    }
}
