<?php
defined( 'ABSPATH' ) || exit;

/**
 * JP_Cache — Caching layer.
 * Uses Redis when available (via WP Redis Object Cache plugin),
 * otherwise falls back to WordPress transients — which work perfectly
 * on shared hosting using the database.
 *
 * Usage:
 *   JP_Cache::set( 'key', $data, 3600 );
 *   $data = JP_Cache::get( 'key' );
 *   JP_Cache::delete( 'key' );
 *   JP_Cache::flush_group( 'jobs' );
 */
class JP_Cache {

    private static ?JP_Cache $instance = null;

    /** Cache group prefix so we can bulk-flush by group */
    private const PREFIX = 'jp_';

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Store a value.
     * @param string $key   Cache key (no prefix needed)
     * @param mixed  $value Any serialisable value
     * @param int    $ttl   Seconds until expiry (default 1 hour)
     * @param string $group Optional group for bulk invalidation
     */
    public static function set( string $key, $value, int $ttl = 3600, string $group = '' ): bool {
        $full_key = self::build_key( $key, $group );

        // WP Object Cache (Redis if the plugin is active, else a
        // per-request in-memory array with no cross-request cost)
        wp_cache_set( $full_key, $value, 'jp_cache', $ttl );

        // Root-cause fix (gap analysis P1/P2 #143): this previously wrote
        // to set_transient() unconditionally, on top of the wp_cache_set()
        // call above, regardless of whether a persistent object cache
        // (Redis) was actually configured. When it IS configured, WordPress
        // core's transient functions themselves route through the object
        // cache — so the "also write to transients" call was a genuine
        // second write to the same Redis backend on every single
        // JP_Cache::set() call, pure overhead with zero benefit (the first
        // wp_cache_set() call already made the value durable there). The
        // transient write is only actually needed as the persistence layer
        // when there is NO persistent object cache — the exact shared-
        // hosting/DB-only scenario the original comment was written for.
        if ( ! wp_using_ext_object_cache() ) {
            return set_transient( $full_key, $value, $ttl );
        }
        return true;
    }

    /**
     * Retrieve a value. Returns null on miss.
     */
    public static function get( string $key, string $group = '' ) {
        $full_key = self::build_key( $key, $group );

        // Try object cache first (in-memory, fastest)
        $val = wp_cache_get( $full_key, 'jp_cache' );
        if ( false !== $val ) return $val;

        // Root-cause fix (companion to the set() change above): when a
        // persistent object cache is active, set() no longer writes a
        // transient at all, so falling through to get_transient() here
        // would only ever find stale data from before this version (or
        // nothing) — never anything set() wrote going forward. Skip the
        // extra DB/Redis round-trip entirely in that case.
        if ( wp_using_ext_object_cache() ) {
            return null;
        }

        // Fall back to transient (DB-backed on shared hosting with no
        // persistent object cache)
        $val = get_transient( $full_key );
        if ( false !== $val ) {
            // Warm the object cache
            wp_cache_set( $full_key, $val, 'jp_cache', 3600 );
            return $val;
        }

        return null;
    }

    /**
     * Delete a single cache entry.
     */
    public static function delete( string $key, string $group = '' ): bool {
        $full_key = self::build_key( $key, $group );
        wp_cache_delete( $full_key, 'jp_cache' );
        return delete_transient( $full_key );
    }

    /**
     * Flush all keys belonging to a group by incrementing the group version.
     * Keys with an old version simply stop being returned.
     */
    public static function flush_group( string $group ): void {
        $version_key = self::PREFIX . 'grp_ver_' . $group;
        $version     = (int) get_option( $version_key, 1 );
        update_option( $version_key, $version + 1, false );
        wp_cache_delete( $version_key, 'jp_cache' );
    }

    /**
     * Flush everything (use sparingly — iterates all jp_ transients).
     */
    public static function flush_all(): void {
        global $wpdb;
        $wpdb->query(
            "DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_jp_%' OR option_name LIKE '_transient_timeout_jp_%'"
        ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        wp_cache_flush();
    }

    // ── Helper: remember pattern ──────────────────────────────────────────────

    /**
     * Fetch from cache or compute and store.
     *
     * Example:
     *   $jobs = JP_Cache::remember('featured_jobs', fn() => JP_DB::instance()->get_jobs(['is_featured'=>1]), 1800, 'jobs');
     */
    public static function remember( string $key, callable $callback, int $ttl = 3600, string $group = '' ) {
        $val = self::get( $key, $group );
        if ( null !== $val ) return $val;

        // Root-cause fix (gap analysis P1/P2 #143: "remember() has no
        // stampede/lock protection, so concurrent cache misses on an
        // expensive query can all fire simultaneously"). wp_cache_add() is
        // atomic against whatever object-cache backend is active: on a
        // persistent cache (Redis) this genuinely coordinates across
        // separate PHP-FPM worker processes — only one concurrent request
        // wins the add and actually runs $callback(), the rest wait
        // briefly for it to publish the result instead of all running the
        // same expensive query at once. Honest limit, stated once here
        // rather than left implicit: WITHOUT a persistent object cache,
        // WordPress's default object cache is a separate in-memory array
        // per PHP process/request, so this lock provides no real
        // cross-process protection in that configuration — it degrades
        // gracefully to "no-op" rather than to "false confidence," since
        // every path below still computes a correct value either way; it
        // just can't coordinate workers that don't share memory.
        $lock_key = self::PREFIX . 'lock_' . self::build_key( $key, $group );
        $acquired = wp_cache_add( $lock_key, 1, 'jp_cache', 10 ); // 10s ceiling — auto-clears even if this request dies mid-computation

        if ( ! $acquired ) {
            // Another request is already computing this value. Wait
            // briefly (capped, never indefinite) for it to publish, then
            // fall back to computing it ourselves rather than risk a hang.
            for ( $i = 0; $i < 5; $i++ ) {
                usleep( 100000 ); // 100ms
                $val = self::get( $key, $group );
                if ( null !== $val ) return $val;
            }
        }

        $val = $callback();
        if ( null !== $val ) {
            self::set( $key, $val, $ttl, $group );
        }
        if ( $acquired ) {
            wp_cache_delete( $lock_key, 'jp_cache' );
        }
        return $val;
    }

    // ── Internal ──────────────────────────────────────────────────────────────

    private static function build_key( string $key, string $group ): string {
        if ( ! $group ) {
            return self::PREFIX . $key;
        }

        // Get the current version for this group (allows bulk invalidation)
        $version_key = self::PREFIX . 'grp_ver_' . $group;
        $version     = wp_cache_get( $version_key, 'jp_cache' );
        if ( false === $version ) {
            $version = (int) get_option( $version_key, 1 );
            wp_cache_set( $version_key, $version, 'jp_cache', 86400 );
        }

        return self::PREFIX . $group . '_v' . $version . '_' . $key;
    }
}
