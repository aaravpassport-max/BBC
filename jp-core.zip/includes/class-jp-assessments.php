<?php
/**
 * Class JP_Assessments — Timed MCQ skill tests + TCPDF certificates.
 * Auto-scored. Badge levels: bronze (60-69%), silver (70-84%), gold (85%+).
 * Linked to jp_skills. Certificate stored in /uploads/jp-certs/.
 */
defined( 'ABSPATH' ) || exit;

class JP_Assessments {

	private static ?JP_Assessments $instance = null;

	const BADGE_LEVELS = [
		'gold'   => 85,
		'silver' => 70,
		'bronze' => 60,
	];

	/**
	 * Root-cause fix (gap analysis P1 #95: "Assessment question bank
	 * defaults to a 5-question hardcoded sample for any skill without
	 * admin-authored questions ... undermining the credibility of the
	 * resulting skill badges"). This constant used to be served by
	 * get_questions() as the fallback for EVERY skill that had no
	 * admin-authored questions — meaning a candidate taking, say, an
	 * "Excel" or "Sales" or "Photoshop" assessment (any skill an admin
	 * hadn't gotten around to writing real questions for yet) was actually
	 * quizzed on generic HTML/CSS/JS/SQL trivia completely unrelated to the
	 * skill their resulting badge would claim to certify. The count-based
	 * "enough questions" check in ajax_start() couldn't catch this at all —
	 * this fallback always has exactly 5 items, which passes that check
	 * every time, so the mismatch was invisible to the one guard that
	 * existed. Kept here, unused by get_questions() below, ONLY as
	 * reference content an admin can copy into jp_assessment_questions for
	 * a genuine "Web Fundamentals" skill if they want one — never served
	 * automatically for a skill it wasn't written for.
	 */
	const SAMPLE_QUESTIONS = [
		['q'=>'What does CSS stand for?','options'=>['Colorful Style Sheets','Computer Style Sheets','Cascading Style Sheets','Creative Style Sheets'],'correct'=>2],
		['q'=>'Which HTML tag is used for the largest heading?','options'=>['<heading>','<h1>','<head>','<h6>'],'correct'=>1],
		['q'=>'In JavaScript, which operator is used for strict equality?','options'=>['==','===','=','!='],'correct'=>1],
		['q'=>'What does SQL stand for?','options'=>['Structured Query Language','Simple Query Language','Sequential Query Language','Standard Query Language'],'correct'=>0],
		['q'=>'Which data structure follows LIFO?','options'=>['Queue','Linked List','Stack','Tree'],'correct'=>2],
	];

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_jp_start_assessment',  [ $this, 'ajax_start' ] );
		add_action( 'wp_ajax_jp_submit_assessment', [ $this, 'ajax_submit' ] );
		add_action( 'wp_ajax_jp_get_certificate',   [ $this, 'ajax_certificate' ] );
	}

	// ── Start assessment ──────────────────────────────────────────────────────

	public function ajax_start(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');

		$skill_id = absint($_POST['skill_id']??0);
		if (!$skill_id) jp_json_response(false,'Skill ID required.');

		global $wpdb;
		$skill = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_skills WHERE id=%d",$skill_id));
		if (!$skill) jp_json_response(false,'Skill not found.');

		// Root-cause fix: retake cooldown. Previously a candidate could call
		// ajax_start immediately after a failed/low attempt with no limit,
		// which combined with the tiny sample bank (below) made the "score
		// improves on retake" logic (see ajax_submit) trivially gameable by
		// brute-forcing attempts in a loop. 1 attempt per skill per 10 minutes.
		$uid = get_current_user_id();
		if ( JP_Security::rate_limit( 'jp_assessment_start_' . $skill_id, 1, 600, (string) $uid ) === false ) {
			jp_json_response( false, 'Please wait a few minutes before retaking this assessment.' );
		}

		// Fetch questions for this skill (or use sample bank)
		$questions = $this->get_questions($skill_id);
		$min_questions = 5; // below this, the test has no real discriminative/anti-cheat value
		if (count($questions) < $min_questions) {
			jp_json_response(false,'This assessment does not have enough questions configured yet. Please contact support or try another skill.');
		}

		// Root-cause fix: this used to unconditionally slice to 20 and tell the
		// candidate "20 questions" even when the bank (frequently just the
		// 5-item SAMPLE_QUESTIONS fallback) had far fewer — meaning retakes
		// showed the exact same questions reordered, and the UI over-promised
		// question count. Take the true minimum of what's configured and 20,
		// and surface the actual bank size so the client can set expectations.
		shuffle($questions);
		$target = min(count($questions), 20);
		$questions = array_slice($questions, 0, $target);
		$bank_size = count($this->get_questions($skill_id));

		// Store in transient (user's assessment session, 20 min TTL)
		$token   = wp_generate_password(32,false);
		$uid     = get_current_user_id();
		set_transient('jp_assessment_'.$uid.'_'.$skill_id,[
			'skill_id'   => $skill_id,
			'questions'  => $questions,
			'started_at' => time(),
			'token'      => $token,
		],1200); // 20 minutes

		// Return questions without correct answers
		$safe_qs = array_map(fn($q)=>['q'=>$q['q'],'options'=>$q['options']],$questions);

		jp_json_response(true,[
			'token'      => $token,
			'skill_name' => $skill->name,
			'questions'  => $safe_qs,
			'duration'   => 900, // 15 min in seconds
			'bank_size'  => $bank_size,
			'small_bank_warning' => $bank_size < 15,
		]);
	}

	// ── Submit and auto-score ─────────────────────────────────────────────────

	public function ajax_submit(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');

		$skill_id = absint($_POST['skill_id']??0);
		$token    = sanitize_text_field($_POST['token']??'');
		$answers  = array_map('absint',(array)($_POST['answers']??[]));
		$uid      = get_current_user_id();

		$session  = get_transient('jp_assessment_'.$uid.'_'.$skill_id);
		// Root-cause fix: `token` was a bare, unquoted word here, not the $token
		// variable — in PHP 8 this throws "Undefined constant token", fataling
		// every single assessment submission (confirmed: this made the whole
		// feature non-functional). Compare against the actual $token value.
		if (!$session||!is_string($token)||!hash_equals((string)$session['token'],$token)) jp_json_response(false,'Session expired or invalid. Please restart the assessment.');
		if ((time()-$session['started_at'])>1200) jp_json_response(false,'Time limit exceeded. Assessment cancelled.');

		delete_transient('jp_assessment_'.$uid.'_'.$skill_id);

		// Score
		$questions = $session['questions'];
		$correct   = 0;
		foreach ($questions as $i=>$q) {
			if (isset($answers[$i]) && (int)$answers[$i] === (int)$q['correct']) $correct++;
		}
		$total    = count($questions);
		$score    = $total > 0 ? (int)round($correct/$total*100) : 0;
		$badge    = 'none';
		foreach (self::BADGE_LEVELS as $level=>$threshold) {
			if ($score >= $threshold) { $badge = $level; break; }
		}

		global $wpdb;
		// Update or insert assessment record
		$existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_assessments WHERE user_id=%d AND skill_id=%d",$uid,$skill_id));
		// Root-cause fix (batch 18): neither branch's write was checked --
		// same ghost-success shape found throughout this codebase. A failed
		// write here still returned the freshly-computed score/badge/cert_url
		// to the candidate as if the attempt were recorded, while nothing
		// persisted -- the badge would vanish from their profile on next load
		// (or, on a fresh attempt, never appear at all), and any certificate
		// generated below would have no DB row for ajax_certificate() to find
		// it through later.
		$write_ok = true;
		if ($existing) {
			// Only update if score improves
			if ($score > (int)$existing->score) {
				$write_ok = false !== $wpdb->update($wpdb->prefix.'jp_assessments',['score'=>$score,'badge_level'=>$badge,'taken_at'=>current_time('mysql')],['id'=>$existing->id],['%d','%s','%s'],['%d']);
			} else {
				$score = (int)$existing->score;
				$badge = $existing->badge_level;
			}
		} else {
			$write_ok = false !== $wpdb->insert($wpdb->prefix.'jp_assessments',[
				'user_id'    => $uid,
				'skill_id'   => $skill_id,
				'score'      => $score,
				'badge_level'=> $badge,
				'taken_at'   => current_time('mysql'),
			],['%d','%d','%d','%s','%s']);
		}
		if ( ! $write_ok ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_assessments write failed: ' . $wpdb->last_error ), 'JP_Assessments::ajax_submit user_id=' . $uid . ' skill_id=' . $skill_id );
			}
			jp_json_response( false, 'Could not save your assessment result. Please try again.' );
			return;
		}

		// Generate certificate if passed
		$cert_url = '';
		if ($badge !== 'none') {
			$cert_url = $this->generate_certificate($uid,$skill_id,$score,$badge);
		}

		// Add badge to candidate profile (update skills_json with badge metadata)
		$this->update_profile_badges($uid,$skill_id,$badge);

		jp_json_response(true,[
			'score'      => $score,
			'correct'    => $correct,
			'total'      => $total,
			'badge'      => $badge,
			'passed'     => $badge !== 'none',
			'cert_url'   => $cert_url,
			'message'    => $badge !== 'none'
				? "🎉 Congratulations! You scored {$score}% and earned a ".ucfirst($badge)." badge!"
				: "You scored {$score}%. You need 60%+ to earn a badge. You can retake the test.",
		]);
	}

	// ── TCPDF Certificate generation ──────────────────────────────────────────

	public function generate_certificate( int $user_id, int $skill_id, int $score, string $badge ): string {
		global $wpdb;
		$user  = get_userdata($user_id);
		$skill = $wpdb->get_row($wpdb->prepare("SELECT name FROM {$wpdb->prefix}jp_skills WHERE id=%d",$skill_id));
		$site  = jp_site_name();

		// Root cause fix (gap analysis P1 #96): previously returned '' with
		// no fallback whenever TCPDF was unavailable, silently dropping the
		// cert_url field from ajax_submit()'s response with no indication
		// to the candidate why. Now shares JP_PDF's dependency probe and
		// degrades to an HTML certificate instead of failing silently.
		if (!JP_PDF::ensure_available()) {
			$cert_id = strtoupper(wp_generate_password(8,false));
			$html = JP_PDF::wrap_html_document(
				'Certificate of Achievement',
				'<div style="text-align:center;border:6px double #d4af37;padding:40px">'
				. '<h2>'.esc_html($site).'</h2>'
				. '<h1>Certificate of Achievement</h1>'
				. '<p>This is to certify that</p>'
				. '<h2 style="color:#156bc9">'.esc_html($user->display_name).'</h2>'
				. '<p>has successfully completed the</p>'
				. '<h3>'.esc_html($skill->name??'Skill').' Skills Assessment</h3>'
				. '<p>Score: '.(int)$score.'%  &middot;  Badge Level: '.esc_html(ucfirst($badge)).'</p>'
				. '<p><em>Issued on '.esc_html(date('j F Y')).'</em></p>'
				. '<p style="color:#999;font-size:12px">Certificate ID: JP-'.esc_html($cert_id).'</p>'
				. '</div>'
			);
			$path = JP_PDF::write_html_fallback('jp-certs','cert-'.$user_id.'-'.$skill_id.'.html',$html);
			global $wpdb;
			// Root-cause fix (batch 18): unchecked $wpdb->update(). The
			// generated file/URL is still returned to the caller either way
			// (the immediate response is unaffected), but a failed write here
			// means ajax_certificate()'s later lookup (which reads cert_path
			// back from the DB rather than regenerating) would find it empty
			// and silently regenerate a NEW cert file on every subsequent
			// request instead of reusing this one -- logged so that pattern is
			// at least diagnosable.
			$cert_saved = $wpdb->update($wpdb->prefix.'jp_assessments',['cert_path'=>$path],['user_id'=>$user_id,'skill_id'=>$skill_id],['%s'],['%d','%d']);
			if ( false === $cert_saved && class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_assessments cert_path (html fallback) update failed: ' . $wpdb->last_error ), 'JP_Assessments::generate_certificate user_id=' . $user_id . ' skill_id=' . $skill_id );
			}
			return str_replace(ABSPATH,site_url('/'),$path);
		}

		$badge_colors = ['gold'=>[212,175,55],'silver'=>[160,160,160],'bronze'=>[176,141,87]];
		[$r,$g,$b]    = $badge_colors[$badge]??[74,144,217];

		$pdf = new \TCPDF('L','mm','A4',true,'UTF-8',false);
		$pdf->SetCreator($site);
		$pdf->SetTitle('Certificate of Achievement');
		$pdf->SetMargins(0,0,0);
		$pdf->SetAutoPageBreak(false);
		$pdf->AddPage();

		// Background
		$pdf->SetFillColor(248,250,255);
		$pdf->Rect(0,0,297,210,'F');

		// Gold border
		$pdf->SetDrawColor($r,$g,$b);
		$pdf->SetLineWidth(3);
		$pdf->Rect(10,10,277,190,'D');
		$pdf->SetLineWidth(1);
		$pdf->Rect(13,13,271,184,'D');

		// Header band
		$pdf->SetFillColor(21,107,201);
		$pdf->Rect(0,0,297,28,'F');

		// Site name in header
		$pdf->SetTextColor(255,255,255);
		$pdf->SetFont('helvetica','B',14);
		$pdf->SetXY(0,8);
		$pdf->Cell(297,12,$site,0,1,'C');

		// Badge icon area
		$pdf->SetFont('helvetica','B',40);
		$pdf->SetTextColor($r,$g,$b);
		$pdf->SetXY(0,32);
		$pdf->Cell(297,20,'★',0,1,'C');

		// Title
		$pdf->SetFont('helvetica','B',28);
		$pdf->SetTextColor(30,30,30);
		$pdf->SetXY(0,58);
		$pdf->Cell(297,14,'Certificate of Achievement',0,1,'C');

		// Body text
		$pdf->SetFont('helvetica','',14);
		$pdf->SetTextColor(80,80,80);
		$pdf->SetXY(0,78);
		$pdf->Cell(297,8,'This is to certify that',0,1,'C');

		// Candidate name
		$pdf->SetFont('helvetica','B',24);
		$pdf->SetTextColor(21,107,201);
		$pdf->SetXY(0,90);
		$pdf->Cell(297,12,$user->display_name,0,1,'C');

		$pdf->SetFont('helvetica','',14);
		$pdf->SetTextColor(80,80,80);
		$pdf->SetXY(0,108);
		$pdf->Cell(297,8,'has successfully completed the',0,1,'C');

		// Skill name
		$pdf->SetFont('helvetica','B',20);
		$pdf->SetTextColor(30,30,30);
		$pdf->SetXY(0,120);
		$pdf->Cell(297,10,($skill->name??'Skill').' Skills Assessment',0,1,'C');

		// Score and badge
		$pdf->SetFont('helvetica','',13);
		$pdf->SetTextColor(80,80,80);
		$pdf->SetXY(0,135);
		$pdf->Cell(297,8,'Score: '.$score.'%  ·  Badge Level: '.ucfirst($badge),0,1,'C');

		// Date
		$pdf->SetFont('helvetica','I',12);
		$pdf->SetXY(0,148);
		$pdf->Cell(297,8,'Issued on '.date('j F Y'),0,1,'C');

		// Cert ID
		$cert_id = strtoupper(wp_generate_password(8,false));
		$pdf->SetFont('helvetica','',9);
		$pdf->SetTextColor(160,160,160);
		$pdf->SetXY(0,185);
		$pdf->Cell(297,6,'Certificate ID: JP-'.$cert_id,0,1,'C');

		// Save
		$dir  = wp_upload_dir()['basedir'].'/jp-certs/';
		wp_mkdir_p($dir);
		$path = $dir.'cert-'.$user_id.'-'.$skill_id.'.pdf';
		$pdf->Output($path,'F');

		// Store cert path in DB
		global $wpdb;
		// Root-cause fix (batch 18): same unchecked-update shape as the HTML
		// fallback branch above.
		$cert_saved = $wpdb->update($wpdb->prefix.'jp_assessments',['cert_path'=>$path],['user_id'=>$user_id,'skill_id'=>$skill_id],['%s'],['%d','%d']);
		if ( false === $cert_saved && class_exists( 'JP_ErrorLog' ) ) {
			JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_assessments cert_path (PDF) update failed: ' . $wpdb->last_error ), 'JP_Assessments::generate_certificate user_id=' . $user_id . ' skill_id=' . $skill_id );
		}

		return str_replace(ABSPATH,site_url('/'),$path);
	}

	public function ajax_certificate(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');
		$skill_id = absint($_GET['skill_id']??0);
		$uid      = get_current_user_id();
		global $wpdb;
		$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_assessments WHERE user_id=%d AND skill_id=%d AND badge_level!='none'",$uid,$skill_id));
		if (!$row) jp_json_response(false,'No certificate found.');
		$url = $row->cert_path ? str_replace(ABSPATH,site_url('/'),$row->cert_path) : $this->generate_certificate($uid,$skill_id,(int)$row->score,$row->badge_level);
		jp_json_response(true,['cert_url'=>$url]);
	}

	// ── Helpers ───────────────────────────────────────────────────────────────

	private function get_questions( int $skill_id ): array {
		global $wpdb;
		// Root-cause fix (gap analysis P1 #95 — see SAMPLE_QUESTIONS'
		// docblock above for the full explanation): no longer falls back to
		// a generic, skill-unrelated sample bank. A skill with no
		// admin-authored questions of its own now correctly returns an
		// empty bank — ajax_start()'s existing $min_questions check turns
		// that into an honest "not available for this skill yet" instead of
		// silently administering an irrelevant test and issuing a badge
		// that doesn't mean what it claims to.
		if ($wpdb->get_var("SHOW TABLES LIKE '{$wpdb->prefix}jp_assessment_questions'")) {
			$rows = $wpdb->get_results($wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}jp_assessment_questions WHERE skill_id=%d AND is_active=1 ORDER BY RAND() LIMIT 20",
				$skill_id
			));
			if (!empty($rows)) {
				return array_map(fn($r)=>['q'=>$r->question,'options'=>json_decode($r->options_json,true),'correct'=>(int)$r->correct_index],$rows);
			}
		}
		return [];
	}

	/**
	 * Root cause (4-way skills-storage consolidation, §37): this recorded
	 * a passed assessment ONLY in usermeta (`jp_skill_badges`, keyed by
	 * skill NAME), which neither JP_Matching nor the candidate-search
	 * endpoint has ever read — earning a badge for a skill had zero effect
	 * on match scores or search visibility, defeating the entire point of
	 * JP_Matching::get_verified_skill_names() existing (it reads
	 * jp_assessments directly, which this method's caller already writes
	 * to, so that half was always correct — it's specifically the
	 * usermeta write here that was the disconnected, unused copy). Now
	 * ALSO links the skill into jp_user_skills via JP_DB::add_user_skills()
	 * so passing an assessment for a skill the candidate hadn't already
	 * declared makes it a real, matchable, searchable part of their
	 * profile — not just a badge nobody but the candidate's own profile
	 * page could see. The usermeta badge write is left in place (not a
	 * duplicate of "has this skill" — it's the badge LEVEL, still useful
	 * for a profile page to render "🥇 Gold" next to a skill), just no
	 * longer the only place this information lived.
	 */
	private function update_profile_badges( int $user_id, int $skill_id, string $badge ): void {
		if ($badge === 'none') return;
		global $wpdb;
		$skill = $wpdb->get_row($wpdb->prepare("SELECT name FROM {$wpdb->prefix}jp_skills WHERE id=%d",$skill_id));
		if (!$skill) return;
		$badges = json_decode(get_user_meta($user_id,'jp_skill_badges',true)??'{}',true)?:[];
		$badges[$skill->name] = $badge;
		update_user_meta($user_id,'jp_skill_badges',wp_json_encode($badges));
		JP_DB::instance()->add_user_skills( $user_id, [ $skill->name ] );
	}
}
