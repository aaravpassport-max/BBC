<?php
/**
 * Class JP_Cron — All 12 WP-Cron background jobs.
 * Registered on plugin activation. Removed on deactivation.
 */
defined( 'ABSPATH' ) || exit;

class JP_Cron {

	private static ?JP_Cron $instance = null;

	/** All scheduled jobs: [ hook, interval, description ] */
	const JOBS = [
		['jp_expire_jobs',             'hourly',        'Mark expired job listings as expired'],
		['jp_flush_job_views',         'every_15_min',  'Flush buffered view counts to DB'],
		['jp_dispatch_instant_alerts', 'every_15_min',  'Send instant job alerts'],
		['jp_dispatch_daily_alerts',   'daily',         'Send daily job alert digests'],
		['jp_dispatch_weekly_alerts',  'weekly',        'Send weekly job alert digests'],
		['jp_update_match_scores',     'daily',         'Batch-compute candidate-job match scores'],
		['jp_aggregate_analytics',     'hourly',        'Aggregate raw analytics events'],
		['jp_expire_subscriptions',    'daily',         'Expire and warn about subscriptions'],
		['jp_cleanup_sessions',        'daily',         'Delete old PHP sessions'],
		['jp_cleanup_old_logs',        'weekly',        'Prune search and audit logs'],
		['jp_backup_database',         'daily',         'Automated mysqldump backup'],
		['jp_sync_es_index',           'twicedaily',    'Sync new/changed jobs to Elasticsearch'],
		['jp_retry_webhook_deliveries', 'every_15_min', 'Retry failed webhook deliveries with backoff'],
		['jp_process_job_queue',        'every_5_min',  'Process pending background job-queue entries'],
		['jp_reconcile_payments',       'hourly',       'Reconcile stuck/orphaned payment orders against Razorpay (gap analysis P1 #154)'],
		['jp_import_job_feeds',         'hourly',       'Pull and import jobs from configured external job-feed URLs (JP_JobFeed)'],
	];

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	/** hook => underlying job_* method name, for the monitored dispatcher below. */
	private const HOOK_METHODS = [
		'jp_expire_jobs'              => 'job_expire_listings',
		'jp_flush_job_views'          => 'job_flush_views',
		'jp_dispatch_instant_alerts'  => 'job_dispatch_alerts',
		'jp_update_match_scores'      => 'job_match_scores',
		'jp_aggregate_analytics'      => 'job_aggregate_analytics',
		'jp_expire_subscriptions'     => 'job_expire_subs',
		'jp_cleanup_sessions'         => 'job_cleanup_sessions',
		'jp_cleanup_old_logs'         => 'job_cleanup_logs',
		'jp_backup_database'          => 'job_backup',
		'jp_sync_es_index'            => 'job_sync_es',
		'jp_retry_webhook_deliveries' => 'job_retry_webhooks',
		'jp_reconcile_payments'       => 'job_reconcile_payments',
	];

	private function __construct() {
		// Register custom intervals
		add_filter( 'cron_schedules', [ $this, 'add_intervals' ] );

		// Root-cause fix (gap analysis P0 #60 / P1 #116): every job used to
		// be wired directly (add_action($hook, [$this, 'job_x'])) with
		// nothing recording whether it ran, how long it took, or whether it
		// threw. 'jp_last_cron_run' — the one field admin_health() already
		// exposed — was read in class-jp-api.php but WRITTEN BY NOTHING
		// ANYWHERE in the codebase, so that field always read "never" no
		// matter how long the site had been running; any of the 12 jobs
		// could silently stop firing indefinitely with zero queryable
		// record. Every hook now routes through run_monitored(), which
		// records a row in jp_cron_runs (start, finish, duration, success/
		// failure, error message) and updates 'jp_last_cron_run' — so both
		// the aggregate field admin_health() already reads AND a genuine
		// per-job history now exist.
		foreach ( self::HOOK_METHODS as $hook => $method ) {
			add_action( $hook, function () use ( $hook, $method ) {
				$this->run_monitored( $hook, [ $this, $method ] );
			} );
		}
	}

	/**
	 * Execute one cron job's real callback, recording the outcome. A
	 * thrown exception is caught (so one broken job cannot take down the
	 * WP-Cron request for every other job scheduled in the same fire) and
	 * recorded as a failure rather than propagating silently or fataling.
	 */
	private function run_monitored( string $hook, callable $callback ): void {
		global $wpdb;
		$table = $wpdb->prefix . 'jp_cron_runs';
		$start = microtime( true );

		$row_id = null;
		if ( $wpdb->query( "SHOW TABLES LIKE '{$table}'" ) ) {
			$wpdb->insert( $table, [ 'hook' => $hook, 'status' => 'running', 'started_at' => current_time( 'mysql' ) ] );
			$row_id = $wpdb->insert_id;
		}

		$status = 'success';
		$error  = null;
		try {
			call_user_func( $callback );
		} catch ( \Throwable $e ) {
			$status = 'failed';
			$error  = mb_substr( $e->getMessage(), 0, 1000 );
			error_log( "JP_Cron: job '{$hook}' failed: {$error}" );
			if ( class_exists( 'JP_Security' ) ) {
				JP_Security::instance()->audit( 'cron_job_failed', 'cron', 0, "Cron job '{$hook}' failed: {$error}" );
			}
		}

		$duration_ms = (int) round( ( microtime( true ) - $start ) * 1000 );

		if ( $row_id ) {
			// Low-severity ghost-success fix: this write was unchecked. A
			// failure here leaves the run's own bookkeeping row stuck at
			// status='running' forever (AdminHealthPage's per-job cron
			// health reads this table) even though the job itself
			// completed/failed correctly above — logged for visibility,
			// not treated as fatal since the actual job outcome (whether
			// it threw) is already handled independently of this row.
			$logged = $wpdb->update( $table, [
				'status'      => $status,
				'finished_at' => current_time( 'mysql' ),
				'duration_ms' => $duration_ms,
				'error'       => $error,
			], [ 'id' => $row_id ] );
			if ( false === $logged ) {
				error_log( "JP_Cron: failed to update jp_cron_runs row {$row_id} for hook '{$hook}': " . $wpdb->last_error );
			}
		}

		// Backward-compatible aggregate field — this is the one
		// admin_health() already reads; it now actually gets written.
		update_option( 'jp_last_cron_run', current_time( 'mysql' ) );
	}

	/**
	 * Admin-visible per-job cron health (gap analysis P0 #60: the
	 * client-side AdminHealthPage.js chunk exists with nothing real behind
	 * it server-side). Returns, for every registered job, when it last ran,
	 * whether it succeeded, and whether it's now overdue based on its own
	 * schedule interval — not just a single global "last cron run"
	 * timestamp, which can look healthy while one specific job has been
	 * silently failing for days.
	 */
	public static function health_report(): array {
		global $wpdb;
		$table  = $wpdb->prefix . 'jp_cron_runs';
		$report = [];

		foreach ( self::JOBS as [ $hook, $interval ] ) {
			$last = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM {$table} WHERE hook = %s ORDER BY id DESC LIMIT 1", $hook
			) );
			$interval_seconds = wp_get_schedules()[ $interval ]['interval'] ?? 86400;
			$overdue = $last
				? ( time() - strtotime( $last->started_at ) ) > ( $interval_seconds * 2 )
				: (bool) wp_next_scheduled( $hook ); // scheduled but has literally never run yet

			$report[] = [
				'hook'         => $hook,
				'interval'     => $interval,
				'last_status'  => $last->status ?? 'never_run',
				'last_started' => $last->started_at ?? null,
				'last_error'   => $last->error ?? null,
				'overdue'      => $overdue,
			];
		}
		return $report;
	}

	// ── Schedule all jobs on activation ──────────────────────────────────────

	public static function schedule_all(): void {
		// Custom intervals (every_15_min etc.) are registered via cron_schedules filter
		// which only fires at runtime — NOT during activation when this method is called.
		// wp_schedule_event() silently fails for unknown intervals.
		// Fix: apply the filter manually here so WP knows the interval exists.
		if ( ! has_filter( 'cron_schedules', [ self::instance(), 'add_intervals' ] ) ) {
			add_filter( 'cron_schedules', [ self::instance(), 'add_intervals' ] );
		}

		// Retrieve schedules with our custom intervals now registered
		$schedules = wp_get_schedules();

		foreach ( self::JOBS as [$hook, $interval] ) {
			// Skip if interval is unknown (safety guard)
			if ( ! isset( $schedules[ $interval ] ) ) {
				error_log( "JP_Cron: unknown interval '$interval' for hook '$hook' — skipping" );
				continue;
			}
			if ( ! wp_next_scheduled( $hook ) ) {
				wp_schedule_event( time(), $interval, $hook );
			}
		}
	}

	public static function unschedule_all(): void {
		foreach ( self::JOBS as [$hook] ) {
			$ts = wp_next_scheduled($hook);
			if ($ts) wp_unschedule_event($ts,$hook);
		}
	}

	// ── Custom intervals ──────────────────────────────────────────────────────

	public function add_intervals( array $schedules ): array {
		$schedules['every_15_min'] = ['interval'=>900,  'display'=>'Every 15 Minutes'];
		$schedules['every_5_min']  = ['interval'=>300,  'display'=>'Every 5 Minutes'];
		$schedules['weekly']       = ['interval'=>604800,'display'=>'Weekly'];
		return $schedules;
	}

	// ── Job implementations ───────────────────────────────────────────────────

	/** 1. Expire job listings past their expiry date */
	public function job_expire_listings(): void {
		global $wpdb;
		$expired = $wpdb->query(
			"UPDATE {$wpdb->prefix}jp_jobs SET status='expired'
			 WHERE status='active' AND expires_at IS NOT NULL AND expires_at < NOW()"
		);

		// Notify recruiters of expired jobs
		if ($expired > 0) {
			$just_expired = $wpdb->get_results(
				"SELECT j.*,u.user_email,u.display_name FROM {$wpdb->prefix}jp_jobs j
				 LEFT JOIN {$wpdb->users} u ON u.ID=j.posted_by
				 WHERE j.status='expired' AND j.expires_at BETWEEN DATE_SUB(NOW(),INTERVAL 1 HOUR) AND NOW()"
			);
			foreach ($just_expired as $job) {
				if ($job->user_email) {
					$body = JP_Notifications::instance()->render_template('job_expiring_soon',['job'=>$job,'name'=>$job->display_name]);
					JP_Notifications::instance()->send_email($job->user_email,'Your job listing has expired: '.$job->title,$body);
				}
			}
		}
	}

	/** 2. Flush buffered view counts to DB (reduce write load) */
	public function job_flush_views(): void {
		// Root-cause fix: this read a single transient key ('jp_view_buffer')
		// that JP_Jobs::increment_view() — the ONLY code path that actually
		// runs on a real job view (called from class-jp-api.php on every job
		// detail fetch) — never writes to; increment_view() instead uses one
		// transient per job (jp_view_buffer_{job_id}), which is exactly what
		// JP_Jobs::flush_view_buffer() (this job's own docblock: "called by
		// JP_Cron") scans for and flushes. This cron job was therefore a
		// permanent, silent no-op — it always found nothing to flush.
		// Delegate to the real implementation instead of duplicating (and
		// getting wrong) its own copy of the flush logic.
		if ( class_exists( 'JP_Jobs' ) ) {
			JP_Jobs::instance()->flush_view_buffer();
		}
	}

	/** 3. Instant job alert dispatch (called every 15 min for recent jobs) */
	public function job_dispatch_alerts(): void {
		global $wpdb;
		$new_jobs = $wpdb->get_results(
			"SELECT * FROM {$wpdb->prefix}jp_jobs WHERE status='active' AND created_at>=DATE_SUB(NOW(),INTERVAL 15 MINUTE)"
		);
		foreach ($new_jobs as $job) {
			do_action('jp_job_published',(int)$job->id);
		}
	}

	/** 4. Batch match scores */
	public function job_match_scores(): void {
		// Root-cause fix (gap analysis P1 #201): this used to run
		// batch_score(200) synchronously inside this single daily cron
		// request — capped to the first 200 open-to-work candidates
		// (ordered arbitrarily, so any candidate beyond the cap was never
		// scored, ever) and vulnerable to timing out partway through on a
		// large dataset with no record of how far it got. Now enqueues one
		// job-queue chunk per 100 candidates covering the ENTIRE
		// open-to-work candidate pool (no cap), so the actual scoring work
		// runs across many retried 5-minute queue cycles instead of one
		// all-or-nothing request. See JP_Matching::enqueue_daily_scoring().
		if (class_exists('JP_Matching')) {
			JP_Matching::instance()->enqueue_daily_scoring(100);
		}
	}

	/** 5. Analytics aggregation */
	public function job_aggregate_analytics(): void {
		if (class_exists('JP_Analytics')) {
			JP_Analytics::instance()->aggregate();
		}
	}

	/** 6. Expire subscriptions */
	public function job_expire_subs(): void {
		if (class_exists('JP_Subscriptions')) {
			JP_Subscriptions::instance()->expire_check();
		}
	}

	/** 7. Clean up old PHP session files */
	public function job_cleanup_sessions(): void {
		$session_path = session_save_path() ?: sys_get_temp_dir();
		$files        = glob($session_path.'/sess_*') ?: [];
		$max_age      = 86400; // 24h
		foreach ($files as $file) {
			if (is_file($file) && (time()-filemtime($file)) > $max_age) @unlink($file);
		}
	}

	/** 8. Prune search logs + audit log + error log + read notifications */
	public function job_cleanup_logs(): void {
		global $wpdb;
		// Keep 90 days of search logs
		$wpdb->query("DELETE FROM {$wpdb->prefix}jp_search_log WHERE created_at < DATE_SUB(NOW(),INTERVAL 90 DAY)");
		// Keep 180 days of audit log
		$wpdb->query("DELETE FROM {$wpdb->prefix}jp_audit_log WHERE created_at < DATE_SUB(NOW(),INTERVAL 180 DAY)");
		// Root cause (gap analysis "unbounded growth" / scalability audit,
		// §35): jp_error_log and jp_notifications had NO pruning anywhere
		// in the codebase — every distinct error fingerprint and every
		// notification ever created (read or unread) accumulated forever.
		// jp_notifications in particular is typically the highest-volume
		// table in this platform (one row per recipient per stage change,
		// message, and alert), and an ever-growing jp_error_log directly
		// undermines the Error Log admin screen built in an earlier round
		// (§20) by burying genuinely-recent errors under years of
		// long-since-fixed ones.
		//
		// Keep 180 days of error log entries (matches the audit log
		// retention window above, and errors older than that are
		// overwhelmingly either long-fixed or no longer actionable).
		$wpdb->query("DELETE FROM {$wpdb->prefix}jp_error_log WHERE last_seen_at < DATE_SUB(NOW(),INTERVAL 180 DAY)");
		// Keep 90 days of READ notifications only — unread notifications
		// are NEVER pruned by age, regardless of how old, since an unread
		// item is still something the user hasn't seen yet and deleting it
		// out from under them would be a silent, user-visible data loss
		// bug of exactly the kind this whole audit has been hunting for.
		$wpdb->query("DELETE FROM {$wpdb->prefix}jp_notifications WHERE is_read = 1 AND created_at < DATE_SUB(NOW(),INTERVAL 90 DAY)");
	}

	/** 9. Database backup (mysqldump) */
	public function job_backup(): void {
		if (class_exists('JP_Backup')) {
			JP_Backup::instance()->run();
		}
	}

	/** 10. Sync changed jobs to Elasticsearch */
	public function job_sync_es(): void {
		if (!class_exists('JP_Search')) return;
		$search = JP_Search::instance();
		global $wpdb;
		// Get jobs modified in last 24h
		$modified = $wpdb->get_results("SELECT id,status FROM {$wpdb->prefix}jp_jobs WHERE updated_at>=DATE_SUB(NOW(),INTERVAL 24 HOUR)");
		foreach ($modified as $j) {
			if ($j->status === 'active') $search->index_job((int)$j->id);
			else $search->delete_job((int)$j->id);
		}
	}

	/** 11. Retry failed/pending webhook deliveries (exponential backoff) */
	public function job_retry_webhooks(): void {
		if ( class_exists( 'JP_Webhooks' ) ) {
			JP_Webhooks::instance()->retry_due_deliveries();
		}
	}

	/**
	 * Root-cause fix (gap analysis P1 #154). See
	 * JP_Payments::reconcile_pending() for the full explanation — this is
	 * just the scheduled trigger, routed through run_monitored() like every
	 * other job so a Razorpay outage during reconciliation shows up in
	 * jp_cron_runs/admin_health() instead of failing silently.
	 */
	public function job_reconcile_payments(): void {
		if ( class_exists( 'JP_Payments' ) ) {
			JP_Payments::instance()->reconcile_pending();
		}
	}
}
