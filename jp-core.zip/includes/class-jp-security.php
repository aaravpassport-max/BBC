<?php
defined( 'ABSPATH' ) || exit;

/**
 * JP_Security — Lightweight security layer for shared hosting.
 * Features: rate limiting (transient-based), brute force protection,
 * basic WAF, nonce validation helpers, and audit logging.
 */
class JP_Security {

    private static ?JP_Security $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->hooks();
    }

    private function hooks(): void {
        // 2FA AJAX handlers
        add_action( 'wp_ajax_jp_setup_2fa',  [ $this, 'ajax_setup_2fa' ] );
        add_action( 'wp_ajax_jp_verify_2fa', [ $this, 'ajax_verify_2fa' ] );

        // Harden WordPress defaults
        add_action( 'init',             [ $this, 'harden_wp' ] );
        add_filter( 'login_errors',     [ $this, 'generic_login_error' ] );
        add_action( 'wp_login_failed',  [ $this, 'on_login_failed' ] );
        add_filter( 'the_generator',    '__return_empty_string' );

        // Security headers
        add_action( 'send_headers', [ $this, 'send_security_headers' ] );
        // Root-cause fix: send_csp_header() was fully implemented but never
        // hooked to anything — a written security control that was silently
        // never active, which is worse than not having it at all (anyone
        // reviewing this class's code would reasonably assume CSP was
        // enforced). Hook it alongside the other header method.
        add_action( 'send_headers', [ $this, 'send_csp_header' ] );

        // Root-cause fix (confirmed via live browser console: multiple
        // "Executing inline script violates ... 'nonce-...' ... blocked"
        // errors): send_csp_header() above sends a strict script-src that
        // requires a matching nonce on every inline <script> — but nothing
        // ever attached that nonce to any inline script, guaranteeing every
        // one gets blocked. That includes WordPress's own inline scripts
        // (wp_add_inline_script/wp_localize_script output — this plugin's
        // own JP_CONFIG among them: without it, the React app never even
        // gets its localized config, on top of whatever else WordPress core
        // or other plugins print inline). wp_inline_script_attributes fires
        // for every inline <script> WordPress prints through its script
        // queue system, so this one filter closes the gap for all of them
        // at once. Hand-written raw <script> tags in this plugin's own
        // templates (outside the WP script queue) are NOT covered by this
        // filter and are fixed at their own call sites instead — see
        // templates/page-templates/tpl-react-app.php's service-worker
        // cleanup script for the one example that needed it.
        add_filter( 'wp_inline_script_attributes', [ $this, 'add_csp_nonce_to_inline_scripts' ] );

        // Root-cause fix: 'jp_require_2fa_admin' was a saved, admin-visible
        // setting with no enforcement anywhere — administrators could
        // enable it and reasonably believe 2FA was now mandatory for admin
        // accounts, when in fact verify_2fa() passed by default whenever a
        // given user simply hadn't set 2FA up. Gate wp-admin access itself:
        // any manage_options user without 2FA enabled is redirected to a
        // mandatory setup screen instead of being allowed to proceed.
        add_action( 'admin_init', [ $this, 'enforce_admin_2fa' ] );

        // Block bad bots / scanners early
        add_action( 'init', [ $this, 'block_bad_requests' ], 1 );

        // Root-cause fix (enterprise gap-analysis, admin bulk-actions
        // audit): AdminUsersPage had no way to suspend an account —
        // "delete" is too destructive for e.g. a fraud investigation, and
        // there was no reversible way to lock a user out at all. Rather
        // than duplicating a suspension check inside every login entry
        // point this plugin has (REST auth_token(), the legacy AJAX
        // ajax_login()/wp_signon() path, and stock wp-admin/wp-login.php),
        // this hooks WordPress's own single chokepoint that ALL of those
        // paths funnel through after password verification succeeds —
        // 'wp_authenticate_user' — so one check enforces suspension
        // everywhere, including any future login path, with no risk of one
        // of them being missed.
        add_filter( 'wp_authenticate_user', [ $this, 'block_suspended_login' ], 10, 1 );
    }

    // ── Account suspension ────────────────────────────────────────────────────
    // A reversible, audited alternative to deleting a user outright — used
    // by the admin Users bulk-action ("Suspend"/"Reactivate") and available
    // for any future automated fraud/abuse response to call directly.

    public function is_suspended( int $user_id ): bool {
        return (bool) get_user_meta( $user_id, 'jp_account_suspended', true );
    }

    public function suspend_user( int $user_id, string $reason = '' ): void {
        update_user_meta( $user_id, 'jp_account_suspended', 1 );
        update_user_meta( $user_id, 'jp_suspended_at', current_time( 'mysql' ) );
        update_user_meta( $user_id, 'jp_suspended_reason', sanitize_text_field( $reason ) );
        // Suspending mid-session should take effect immediately, not only
        // on the user's next login attempt — destroy any active sessions
        // for this account right now.
        if ( class_exists( '\WP_Session_Tokens' ) ) {
            \WP_Session_Tokens::get_instance( $user_id )->destroy_all();
        }
        $this->audit( 'user_suspended', 'user', $user_id, $reason );
    }

    public function unsuspend_user( int $user_id ): void {
        delete_user_meta( $user_id, 'jp_account_suspended' );
        delete_user_meta( $user_id, 'jp_suspended_at' );
        delete_user_meta( $user_id, 'jp_suspended_reason' );
        $this->audit( 'user_unsuspended', 'user', $user_id );
    }

    /**
     * Fires after wp_authenticate() has already confirmed the password is
     * correct (this filter runs on the resolved WP_User, post-password-
     * check) but before a session is established anywhere. Returning a
     * WP_Error here makes wp_authenticate() itself return that error, so
     * every caller (auth_token(), wp_signon(), core login) sees a normal
     * failed-login response — no separate error-handling path needed.
     */
    public function block_suspended_login( $user ) {
        if ( is_wp_error( $user ) ) return $user; // already failed for another reason
        if ( $this->is_suspended( $user->ID ) ) {
            $reason = get_user_meta( $user->ID, 'jp_suspended_reason', true );
            $msg    = $reason
                ? sprintf( __( 'This account has been suspended: %s. Contact support.', 'jp-core' ), $reason )
                : __( 'This account has been suspended. Contact support.', 'jp-core' );
            return new \WP_Error( 'account_suspended', $msg );
        }
        return $user;
    }

    // ── Rate limiting ─────────────────────────────────────────────────────────

    /**
     * Check and enforce a rate limit.
     * Returns true if the request is allowed, false if rate limit exceeded.
     *
     * @param string $action  Unique action identifier (e.g. 'login_attempt')
     * @param int    $limit   Max requests allowed in the window
     * @param int    $window  Window in seconds
     * @param string $id      Identifier (default: client IP)
     */
    public static function rate_limit( string $action, int $limit = 5, int $window = 60, string $id = '' ): bool {
        $id      = $id ?: self::client_ip();
        $key     = 'jp_rl_' . md5( $action . $id );
        $current = (int) get_transient( $key );

        if ( $current >= $limit ) {
            return false; // Rate limit exceeded
        }

        if ( $current === 0 ) {
            set_transient( $key, 1, $window );
        } else {
            set_transient( $key, $current + 1, $window );
        }

        return true;
    }

    /**
     * Hard-block an IP for a given number of seconds.
     */
    public static function block_ip( string $ip = '', int $seconds = 3600, string $reason = '' ): void {
        $ip = $ip ?: self::client_ip();
        set_transient( 'jp_blocked_' . md5( $ip ), $reason ?: 'security', $seconds );
    }

    /**
     * Check if the current IP is blocked.
     */
    public static function is_blocked( string $ip = '' ): bool {
        $ip = $ip ?: self::client_ip();
        return (bool) get_transient( 'jp_blocked_' . md5( $ip ) );
    }

    // ── Brute force ───────────────────────────────────────────────────────────

    public function on_login_failed( string $username ): void {
        $ip  = self::client_ip();
        $key = 'jp_lf_' . md5( $ip );

        $attempts = (int) get_transient( $key );
        $attempts++;
        set_transient( $key, $attempts, 900 ); // 15-min window

        // Root-cause fix: this hardcoded 10 and 3600 regardless of the
        // admin-configurable 'jp_max_login_attempts' / 'jp_lockout_duration'
        // settings (registered and editable on the Security settings screen,
        // class-jp-settings.php) — those fields saved correctly but had no
        // effect on actual enforcement, a silent "the setting does nothing"
        // bug that gives an admin false confidence in a control they set.
        $max_attempts     = max( 1, (int) get_option( 'jp_max_login_attempts', 10 ) );
        $lockout_duration = max( 60, (int) get_option( 'jp_lockout_duration', 3600 ) );

        if ( $attempts >= $max_attempts ) {
            self::block_ip( $ip, $lockout_duration, 'brute_force' );
        }
    }

    /**
     * Enforce the 'jp_require_2fa_admin' setting. There is no dedicated
     * wp-admin page in this codebase for 2FA setup (ajax_setup_2fa/
     * ajax_verify_2fa are called from wherever the React admin panel or a
     * settings screen wires them up) — hard-redirecting every wp-admin
     * request for a non-compliant admin risks a lockout loop if that UI is
     * ever unreachable from wp-admin itself. Enforce as a persistent,
     * impossible-to-miss admin notice on every wp-admin screen instead,
     * which achieves the setting's intent (an admin can no longer be
     * unaware that 2FA is required and unset) without a hard block that
     * could brick access. If/when a dedicated wp-admin 2FA setup screen is
     * built, this should be upgraded to a real redirect-until-compliant.
     */
    public function enforce_admin_2fa(): void {
        if ( '1' !== (string) get_option( 'jp_require_2fa_admin', '0' ) ) return;
        if ( ! current_user_can( 'manage_options' ) ) return;
        if ( get_user_meta( get_current_user_id(), 'jp_2fa_enabled', true ) ) return;

        add_action( 'admin_notices', static function (): void {
            echo '<div class="notice notice-error"><p><strong>' .
                esc_html__( 'Two-factor authentication is required for administrator accounts on this site, but is not yet enabled on yours.', 'jp-core' ) .
                '</strong> ' .
                esc_html__( 'Please set it up as soon as possible.', 'jp-core' ) .
                '</p></div>';
        } );
    }

    public function generic_login_error(): string {
        return __( 'Incorrect email or password.', 'jp-core' );
    }

    // ── WordPress hardening ───────────────────────────────────────────────────

    public function harden_wp(): void {
        // Remove WP version from head
        remove_action( 'wp_head', 'wp_generator' );

        // Remove RSD / WLW links
        remove_action( 'wp_head', 'rsd_link' );
        remove_action( 'wp_head', 'wlwmanifest_link' );
        remove_action( 'wp_head', 'wp_shortlink_wp_head' );

        // Disable XML-RPC — not needed for our portal
        add_filter( 'xmlrpc_enabled', '__return_false' );

        // Disable REST API for non-logged-in users (except our JP endpoints)
        add_filter( 'rest_authentication_errors', [ $this, 'rest_only_jp' ] );
    }

    public function rest_only_jp( $access ) {
        if ( ! is_null( $access ) ) return $access; // Already handled

        $route = $GLOBALS['wp']->query_vars['rest_route'] ?? '';

        // Allow JP API and WP block editor routes
        if ( str_starts_with( $route, '/jp/v1/' ) ) return null;
        if ( str_starts_with( $route, '/wp/v2/' )  && is_user_logged_in() ) return null;

        // Block unauthenticated access to everything else
        if ( ! is_user_logged_in() ) {
            return new \WP_Error( 'rest_disabled', __( 'REST API access restricted.', 'jp-core' ), [ 'status' => 401 ] );
        }

        return null;
    }

    // ── Security headers ──────────────────────────────────────────────────────

    public function send_security_headers(): void {
        if ( headers_sent() ) return;

        header( 'X-Content-Type-Options: nosniff' );
        header( 'X-Frame-Options: SAMEORIGIN' );
        header( 'X-XSS-Protection: 1; mode=block' );
        header( 'Referrer-Policy: strict-origin-when-cross-origin' );
        header( 'Permissions-Policy: geolocation=(), microphone=(), camera=()' );

        if ( is_ssl() ) {
            header( 'Strict-Transport-Security: max-age=31536000; includeSubDomains' );
        }
    }

    // ── Basic WAF ─────────────────────────────────────────────────────────────

    public function block_bad_requests(): void {
        // Block obvious scanners — check user agent and URI
        $ua  = $_SERVER['HTTP_USER_AGENT'] ?? '';
        $uri = $_SERVER['REQUEST_URI'] ?? '';

        $bad_patterns = [
            // Bad bots / scanners
            'sqlmap', 'nikto', 'masscan', 'nmap',
            // Common exploit paths
            '/etc/passwd', 'wp-config.php.bak', '/xmlrpc.php',
            'eval(base64', '<?php', 'UNION SELECT', 'union select',
        ];

        foreach ( $bad_patterns as $pattern ) {
            if ( stripos( $uri, $pattern ) !== false || stripos( $ua, $pattern ) !== false ) {
                status_header( 403 );
                nocache_headers();
                exit( 'Access denied.' );
            }
        }

        // Block if IP is in our dynamic block list
        if ( self::is_blocked() ) {
            status_header( 429 );
            nocache_headers();
            exit( 'Too many requests. Try again later.' );
        }
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    public static function client_ip(): string {
        // Root-cause fix: this trusted client-supplied X-Forwarded-For /
        // CF-Connecting-IP headers unconditionally. Any direct client (not
        // just traffic actually proxied through Cloudflare/a load balancer)
        // can set those headers to an arbitrary value, which fed straight
        // into rate limiting and brute-force blocking (both keyed on this
        // IP) — trivially defeating both by spoofing a fresh IP on every
        // request, and poisoning jp_audit_log/analytics IP data. Only trust
        // the forwarded headers when the *direct* connection (REMOTE_ADDR)
        // is itself a configured trusted proxy (e.g. Cloudflare's or the
        // load balancer's real IP/CIDR) — otherwise fall back to
        // REMOTE_ADDR, which the client cannot forge.
        $remote_addr = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';

        if ( $remote_addr && self::is_trusted_proxy( $remote_addr ) ) {
            foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR' ] as $k ) {
                if ( ! empty( $_SERVER[ $k ] ) ) {
                    $candidate = trim( explode( ',', sanitize_text_field( wp_unslash( $_SERVER[ $k ] ) ) )[0] );
                    if ( filter_var( $candidate, FILTER_VALIDATE_IP ) ) return $candidate;
                }
            }
        }

        return $remote_addr ?: '0.0.0.0';
    }

    /**
     * Whether $ip (the direct TCP peer, REMOTE_ADDR) is a configured
     * trusted proxy allowed to set X-Forwarded-For/CF-Connecting-IP.
     * Configure via the 'jp_trusted_proxies' option — a newline-separated
     * list of IPs or CIDR ranges (e.g. Cloudflare's published ranges, or
     * your load balancer's internal subnet). Empty by default: with no
     * configured trusted proxy, forwarded headers are never trusted and
     * REMOTE_ADDR is always used, which is the safe default for a direct
     * (non-proxied) deployment.
     */
    private static function is_trusted_proxy( string $ip ): bool {
        $list = get_option( 'jp_trusted_proxies', '' );
        if ( ! $list ) return false;
        foreach ( preg_split( '/[\r\n,]+/', (string) $list, -1, PREG_SPLIT_NO_EMPTY ) as $entry ) {
            $entry = trim( $entry );
            if ( $entry === '' ) continue;
            if ( strpos( $entry, '/' ) !== false ) {
                if ( self::ip_in_cidr( $ip, $entry ) ) return true;
            } elseif ( $entry === $ip ) {
                return true;
            }
        }
        return false;
    }

    private static function ip_in_cidr( string $ip, string $cidr ): bool {
        [ $subnet, $bits ] = array_pad( explode( '/', $cidr, 2 ), 2, '32' );
        $bits = (int) $bits;
        if ( filter_var( $ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) && filter_var( $subnet, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4 ) ) {
            $ip_long     = ip2long( $ip );
            $subnet_long = ip2long( $subnet );
            if ( $ip_long === false || $subnet_long === false ) return false;
            $mask = $bits === 0 ? 0 : ( ~0 << ( 32 - $bits ) ) & 0xFFFFFFFF;
            return ( $ip_long & $mask ) === ( $subnet_long & $mask );
        }
        // IPv6: byte-wise prefix compare.
        $ip_bin = @inet_pton( $ip );
        $sub_bin = @inet_pton( $subnet );
        if ( $ip_bin === false || $sub_bin === false ) return false;
        $bytes = intdiv( $bits, 8 );
        $rem   = $bits % 8;
        if ( strncmp( $ip_bin, $sub_bin, $bytes ) !== 0 ) return false;
        if ( $rem === 0 ) return true;
        $mask = chr( ( 0xFF << ( 8 - $rem ) ) & 0xFF );
        return ( $ip_bin[ $bytes ] & $mask ) === ( $sub_bin[ $bytes ] & $mask );
    }

    /**
     * Sanitise file uploads — prevent MIME sniffing attacks.
     */
    public static function validate_upload( array $file, array $allowed_types = [] ) {
        $allowed_types = $allowed_types ?: [ 'image/jpeg', 'image/png', 'image/webp', 'application/pdf' ];
        $finfo         = finfo_open( FILEINFO_MIME_TYPE );
        $mime          = finfo_file( $finfo, $file['tmp_name'] );
        finfo_close( $finfo );

        if ( ! in_array( $mime, $allowed_types, true ) ) {
            return new \WP_Error( 'invalid_type', sprintf( __( 'File type %s is not allowed.', 'jp-core' ), esc_html( $mime ) ) );
        }

        $max_mb   = (int) get_option( 'jp_resume_max_size_mb', 5 );
        $max_size = $max_mb * 1024 * 1024;

        if ( $file['size'] > $max_size ) {
            return new \WP_Error( 'too_large', sprintf( __( 'File exceeds the %d MB limit.', 'jp-core' ), $max_mb ) );
        }

        return true;
    }

    // ── get_ip (alias used by JP_Search/Analytics) ────────────────────────────
    public function get_ip(): string {
        return self::client_ip();
    }

    // ── Audit logging ─────────────────────────────────────────────────────────
    // Genesis previous-hash used for the very first row in the chain (no prior
    // row exists to link to). 64 hex zero-chars — same length as a real
    // HMAC-SHA256 hex digest so verify_audit_chain() never has to special-case
    // the comparison itself, only the lookup that produces it.
    const AUDIT_GENESIS_HASH = '0000000000000000000000000000000000000000000000000000000000000000';

    /**
     * Batch 14 (tamper-evidence): hash-chains every audit row. Each row's
     * `hash` is HMAC-SHA256 (keyed with AUTH_KEY, a WP secret that already
     * exists on every install — no new configuration surface) over a
     * deterministic pipe-joined string of this row's own mutable fields
     * PLUS the immediately-preceding row's stored `hash` (`prev_hash`).
     * That link means altering or deleting any historical row — including
     * one not currently displayed — changes what every subsequent row's
     * hash should be, so JP_Security::verify_audit_chain() can detect
     * tampering anywhere in the table, not just in the most recent rows.
     * This is tamper-EVIDENCE, not tamper-PREVENTION: a DB-level attacker
     * who also knows AUTH_KEY could recompute a consistent chain, but any
     * attacker without shell/DB-credential access (the threat this
     * defends against — e.g. a compromised admin account trying to erase
     * its own trail) cannot.
     *
     * Also fixes this method's own previously-unchecked $wpdb->insert()
     * return value — the 4th instance of the ghost-success pattern found
     * in batches 8 (jp-payments), 9 (jp-subscriptions), and 13
     * (jp-team's do_reassign_job()): a failed insert here was silently
     * swallowed, meaning the audit trail could go missing precisely when
     * something was going wrong, with nothing surfaced anywhere.
     */
    public function audit( string $action, string $context = '', int $object_id = 0, string $detail = '', int $company_id = 0 ): void {
        global $wpdb;
        // Root-cause fix: this previously built its insert's field array
        // with a key literally named 'context', and jp_audit_log has never
        // had a column by that name — only 'object'. $wpdb->insert() turns
        // its $data array keys directly into the INSERT's column list, so
        // MySQL rejected the entire statement ("Unknown column 'context'")
        // on every single call, meaning the audit log has never recorded a
        // single row anywhere in the codebase. Map to the real 'object'
        // column. Also added $company_id (optional, defaults to 0/NULL) so
        // team-scoped actions (see JP_Team) can be filtered per-company —
        // previously impossible even in principle, since nothing here
        // recorded which company an action belonged to.
        $user_id    = get_current_user_id();
        $action_key = sanitize_key( $action );
        $object     = sanitize_text_field( $context );
        $detail_txt = sanitize_textarea_field( $detail );
        $ip         = self::client_ip();
        $ua         = substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ?? '' ) ), 0, 255 );
        $company    = $company_id ?: null;
        $created_at = current_time( 'mysql' );

        $prev_hash = self::last_audit_hash( $wpdb );
        $hash      = self::compute_audit_hash( $prev_hash, $user_id, $action_key, $object, $object_id, $detail_txt, $ip, $ua, $company, $created_at );

        $inserted = $wpdb->insert( $wpdb->prefix . 'jp_audit_log', [
            'user_id'    => $user_id,
            'action'     => $action_key,
            'object'     => $object,
            'object_id'  => $object_id,
            'detail'     => $detail_txt,
            'ip'         => $ip,
            'ua'         => $ua,
            'company_id' => $company,
            'created_at' => $created_at,
            'prev_hash'  => $prev_hash,
            'hash'       => $hash,
        ], [ '%d', '%s', '%s', '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s' ] );

        if ( false === $inserted && class_exists( 'JP_ErrorLog' ) ) {
            JP_ErrorLog::instance()->log_exception(
                new \Exception( 'jp_audit_log insert failed: ' . $wpdb->last_error ),
                'JP_Security::audit action=' . $action_key . ' object_id=' . $object_id
            );
        }
    }

    /**
     * Returns the most recently inserted row's stored `hash`, or the
     * genesis hash if the table is empty (first-ever audit entry). Reads
     * by MAX(id) rather than ORDER BY created_at, since created_at has
     * only second-level precision and two rows within the same second
     * must still chain in insertion order.
     */
    private static function last_audit_hash( $wpdb ): string {
        $prev = $wpdb->get_var( "SELECT hash FROM {$wpdb->prefix}jp_audit_log ORDER BY id DESC LIMIT 1" );
        return $prev ?: self::AUDIT_GENESIS_HASH;
    }

    /**
     * Deterministic canonical string for hashing: pipe-joined, with each
     * field's own pipe/backslash characters escaped first so field
     * boundaries can never be shifted by attacker-controlled content
     * (e.g. a `detail` string containing a literal "|") — that would
     * otherwise let two different field-value splits hash identically.
     */
    private static function audit_hash_escape( $v ): string {
        return str_replace( [ '\\', '|' ], [ '\\\\', '\\|' ], (string) $v );
    }

    private static function compute_audit_hash( string $prev_hash, int $user_id, string $action, string $object, int $object_id, string $detail, string $ip, string $ua, $company_id, string $created_at ): string {
        $canonical = implode( '|', [
            self::audit_hash_escape( $prev_hash ),
            self::audit_hash_escape( $user_id ),
            self::audit_hash_escape( $action ),
            self::audit_hash_escape( $object ),
            self::audit_hash_escape( $object_id ),
            self::audit_hash_escape( $detail ),
            self::audit_hash_escape( $ip ),
            self::audit_hash_escape( $ua ),
            self::audit_hash_escape( $company_id ?? '' ),
            self::audit_hash_escape( $created_at ),
        ] );
        return hash_hmac( 'sha256', $canonical, AUTH_KEY );
    }

    /**
     * Walks jp_audit_log in ordered, bounded batches recomputing each
     * row's expected hash from its own stored fields plus the running
     * previous hash, comparing to what's actually stored. Returns a
     * structured result rather than a bool so the caller (REST route
     * admin_audit_log_verify() in class-jp-api.php) can tell the admin
     * UI exactly where a chain break was first detected, not just that
     * one exists somewhere in a potentially very large table.
     *
     * A break can mean either: the row's own `hash` no longer matches
     * its own stored fields (that row's data was altered), or the row's
     * `hash` is internally consistent but its `prev_hash` doesn't match
     * the previous row's `hash` (a row was deleted, reordered, or
     * inserted out of band, bypassing audit()). Both are reported
     * identically as "chain broken at id X" since from a verifier's
     * standpoint both mean the trail can no longer be trusted from that
     * point backward.
     */
    public function verify_audit_chain( int $batch_size = 1000 ): array {
        global $wpdb;
        $table          = $wpdb->prefix . 'jp_audit_log';
        $running_prev   = self::AUDIT_GENESIS_HASH;
        $last_id        = 0;
        $total_checked  = 0;
        $first_break_id = null;

        while ( true ) {
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT id, user_id, action, object, object_id, detail, ip, ua, company_id, created_at, prev_hash, hash
                 FROM {$table} WHERE id > %d ORDER BY id ASC LIMIT %d",
                $last_id, $batch_size
            ) );
            if ( empty( $rows ) ) {
                break;
            }

            foreach ( $rows as $row ) {
                $total_checked++;
                $last_id = (int) $row->id;

                // Legacy rows written before batch 14 (no hash columns
                // populated) can't be verified — they predate the chain.
                // Treat as a soft boundary: skip verifying them, but the
                // chain proper starts fresh from the first row that does
                // have a hash, using ITS OWN prev_hash as the new anchor
                // rather than forcing a false break against genesis.
                if ( null === $row->hash || '' === $row->hash ) {
                    continue;
                }

                if ( self::AUDIT_GENESIS_HASH === $running_prev && null === $first_break_id && '' !== (string) $row->prev_hash && self::AUDIT_GENESIS_HASH !== (string) $row->prev_hash ) {
                    // First hashed row after a run of legacy/unhashed rows:
                    // adopt its own prev_hash as the running anchor instead
                    // of comparing against genesis (see comment above).
                    $running_prev = (string) $row->prev_hash;
                }

                $expected = self::compute_audit_hash(
                    (string) $row->prev_hash, (int) $row->user_id, (string) $row->action, (string) $row->object,
                    (int) $row->object_id, (string) $row->detail, (string) $row->ip, (string) $row->ua,
                    ( '' === $row->company_id || null === $row->company_id ) ? null : (int) $row->company_id,
                    (string) $row->created_at
                );

                $own_hash_ok  = hash_equals( $expected, (string) $row->hash );
                $link_ok      = hash_equals( $running_prev, (string) $row->prev_hash );

                if ( ! $own_hash_ok || ! $link_ok ) {
                    if ( null === $first_break_id ) {
                        $first_break_id = (int) $row->id;
                    }
                }

                $running_prev = (string) $row->hash;
            }
        }

        if ( null !== $first_break_id ) {
            return [
                'valid'         => false,
                'total_checked' => $total_checked,
                'first_break_id' => $first_break_id,
                'message'       => sprintf( 'Audit trail integrity check failed: chain broken at entry #%d. Entries before this point are verified intact; this entry or one after it may have been altered, deleted, or inserted outside the normal audit path.', $first_break_id ),
            ];
        }

        return [
            'valid'          => true,
            'total_checked'  => $total_checked,
            'first_break_id' => null,
            'message'        => $total_checked > 0
                ? sprintf( 'Audit trail intact — %d entries verified, no tampering detected.', $total_checked )
                : 'Audit log is empty — nothing to verify.',
        ];
    }

    // ── TOTP-based 2FA (Google Authenticator compatible) ─────────────────────
    /**
     * Generate a TOTP secret for a user (stored in user_meta).
     * Returns base32-encoded secret for QR code display.
     */
    public function generate_2fa_secret( int $user_id ): string {
        $secret = $this->random_base32( 16 );
        update_user_meta( $user_id, 'jp_2fa_secret', $secret );
        update_user_meta( $user_id, 'jp_2fa_enabled', 0 ); // Not enabled until verified
        return $secret;
    }

    public function enable_2fa( int $user_id, string $code ): bool {
        $secret = get_user_meta( $user_id, 'jp_2fa_secret', true );
        if ( ! $secret ) return false;
        if ( ! $this->verify_totp( $secret, $code ) ) return false;
        update_user_meta( $user_id, 'jp_2fa_enabled', 1 );
        return true;
    }

    public function verify_2fa( int $user_id, string $code ): bool {
        if ( ! get_user_meta( $user_id, 'jp_2fa_enabled', true ) ) return true; // 2FA not enabled = pass
        $secret = get_user_meta( $user_id, 'jp_2fa_secret', true );
        return $secret && $this->verify_totp( $secret, $code );
    }

    /** RFC 6238 TOTP verification (±1 window tolerance) */
    private function verify_totp( string $secret, string $code, int $window = 1 ): bool {
        $time  = floor( time() / 30 );
        for ( $i = -$window; $i <= $window; $i++ ) {
            if ( $this->generate_totp( $secret, $time + $i ) === $code ) return true;
        }
        return false;
    }

    private function generate_totp( string $secret, int $time ): string {
        $key   = $this->base32_decode( $secret );
        $msg   = pack( 'N*', 0 ) . pack( 'N*', $time );
        $hash  = hash_hmac( 'sha1', $msg, $key, true );
        $off   = ord( $hash[-1] ) & 0x0F;
        $otp   = ( ( ord( $hash[ $off ] ) & 0x7F ) << 24 )
               | ( ( ord( $hash[ $off + 1 ] ) & 0xFF ) << 16 )
               | ( ( ord( $hash[ $off + 2 ] ) & 0xFF ) << 8 )
               | ( ord( $hash[ $off + 3 ] ) & 0xFF );
        return str_pad( (string)( $otp % 1_000_000 ), 6, '0', STR_PAD_LEFT );
    }

    private function random_base32( int $length ): string {
        $chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
        $out   = '';
        for ( $i = 0; $i < $length; $i++ ) $out .= $chars[ random_int( 0, 31 ) ];
        return $out;
    }

    private function base32_decode( string $b32 ): string {
        $map   = array_flip( str_split( 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567' ) );
        $b32   = strtoupper( $b32 );
        $bits  = '';
        foreach ( str_split( $b32 ) as $c ) $bits .= isset( $map[ $c ] ) ? sprintf( '%05b', $map[ $c ] ) : '';
        $out   = '';
        foreach ( str_split( $bits, 8 ) as $byte ) if ( strlen( $byte ) === 8 ) $out .= chr( bindec( $byte ) );
        return $out;
    }

    // ── AJAX 2FA handlers ─────────────────────────────────────────────────────
    public function ajax_setup_2fa(): void {
        jp_verify_nonce( 'jp_general' );
        if ( ! is_user_logged_in() ) jp_json_response( false, 'Not authenticated.' );
        $secret = $this->generate_2fa_secret( get_current_user_id() );
        $user   = wp_get_current_user();
        $issuer = urlencode( jp_site_name() );
        $email  = urlencode( $user->user_email );
        $qr_url = "otpauth://totp/{$issuer}:{$email}?secret={$secret}&issuer={$issuer}&algorithm=SHA1&digits=6&period=30";
        jp_json_response( true, [ 'secret' => $secret, 'qr_url' => $qr_url ] );
    }

    public function ajax_verify_2fa(): void {
        jp_verify_nonce( 'jp_general' );
        $code = sanitize_text_field( $_POST['code'] ?? '' );
        $ok   = $this->enable_2fa( get_current_user_id(), $code );
        jp_json_response( $ok, $ok ? '2FA enabled successfully.' : 'Invalid code. Please try again.' );
    }

    // ── Content Security Policy header ────────────────────────────────────────
    public function send_csp_header(): void {
        if ( headers_sent() ) return;
        $nonce = base64_encode( random_bytes( 16 ) );
        // Store nonce for use in wp_head inline scripts
        define( 'JP_CSP_NONCE', $nonce );
        header( "Content-Security-Policy: default-src 'self'; script-src 'self' 'nonce-{$nonce}' https://checkout.razorpay.com https://cdnjs.cloudflare.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' data: https:; connect-src 'self' https://api.razorpay.com; frame-src https://api.razorpay.com;" );
    }

    // Root-cause fix (confirmed via live browser console: every inline
    // <script> was being blocked with "Executing inline script violates
    // ... 'nonce-...' ..."). send_csp_header() defines JP_CSP_NONCE on the
    // 'send_headers' hook (fires before any markup is output), but nothing
    // ever attached that nonce to the inline <script> tags WordPress itself
    // prints via wp_add_inline_script()/wp_localize_script() (e.g. the
    // jp-react-app JP_CONFIG bootstrap data, and any inline script any other
    // plugin/theme code queues through WP's script system). This filter is
    // WordPress's own extension point for exactly that: it fires for every
    // inline script WP prints through the queue and lets us add arbitrary
    // attributes, so wiring it here fixes ALL such scripts in one place
    // without touching each call site individually. Raw, hand-written
    // <script> tags in template files (e.g. tpl-react-app.php's service-
    // worker cleanup block) are NOT run through WP's script queue, so this
    // filter does not apply to them — those are given the nonce directly at
    // their own call site instead (already done in tpl-react-app.php).
    public function add_csp_nonce_to_inline_scripts( array $attributes ): array {
        if ( defined( 'JP_CSP_NONCE' ) ) {
            $attributes['nonce'] = JP_CSP_NONCE;
        }
        return $attributes;
    }

}
