<?php
/**
 * Class JP_Notifications — Email + in-app notification system
 *
 * 25 email templates (rendered inline — no external template files required).
 * Sent via wp_mail (configured to use SMTP via wp-config.php constants).
 * All stage transitions, alerts, and system events trigger from hooks.
 */
defined( 'ABSPATH' ) || exit;

class JP_Notifications {

	private static ?JP_Notifications $instance = null;

	/** All 25 email template keys */
	const TEMPLATES = [
		// Auth
		'welcome_job_seeker', 'welcome_recruiter', 'email_verification', 'password_reset',
		// Applications
		'application_received', 'candidate_shortlisted', 'candidate_phone_screen',
		'candidate_interview_scheduled', 'candidate_assessment', 'candidate_offer_sent',
		'candidate_hired', 'candidate_rejected',
		// Jobs
		'job_approved', 'job_rejected', 'job_expiring_soon',
		// Alerts
		'job_alert_instant', 'job_alert_digest',
		// Payments
		'payment_success', 'payment_failed', 'subscription_expiring',
		// Messages
		'new_message',
		// Reviews
		'review_approved',
		// Admin
		'new_job_pending', 'system_announcement', 'interview_reminder',
	];

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_jp_get_notifications',  [ $this, 'ajax_get' ] );
		add_action( 'wp_ajax_jp_mark_notif_read',    [ $this, 'ajax_mark_read' ] );

		// Hook into application stage changes
		add_action( 'jp_stage_changed',       [ $this, 'on_stage_changed' ], 10, 4 );
		add_action( 'jp_application_submitted', [ $this, 'on_application_submitted' ], 10, 3 );
		add_action( 'jp_job_published',         [ $this, 'on_job_published' ] );
		add_action( 'jp_payment_completed',     [ $this, 'on_payment_completed' ] );
		add_action( 'jp_new_message',           [ $this, 'on_new_message' ] );
	}

	// ── In-app notifications ─────────────────────────────────────────────────

	/**
	 * Root-cause fix (batch 17): unchecked $wpdb->insert(). Lower blast
	 * radius than most other instances of this pattern — every caller
	 * treats this purely as a side-channel notification alongside an
	 * already-completed primary action (a message send, a stage change),
	 * so a failure here never masks the real action's own success/failure
	 * — but it was previously completely silent, meaning a user could go
	 * indefinitely without any in-app notification bell for real events
	 * with nothing ever surfacing the DB-level cause.
	 */
	public function create( array $data ): int {
		global $wpdb;
		$uid   = (int)($data['user_id']??0);
		$title = sanitize_text_field($data['title']??'');
		$body  = sanitize_text_field($data['body']??'');
		$url   = esc_url_raw($data['url']??'');
		$inserted = $wpdb->insert( $wpdb->prefix.'jp_notifications', [
			'user_id'    => $uid,
			'type'       => sanitize_key($data['type']??'system'),
			'title'      => $title,
			'body'       => $body,
			'url'        => $url,
			'is_read'    => 0,
			'created_at' => current_time('mysql'),
		], ['%d','%s','%s','%s','%s','%d','%s'] );
		if ( false === $inserted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_notifications insert failed: ' . $wpdb->last_error ), 'JP_Notifications::create user_id=' . $uid . ' type=' . sanitize_key($data['type']??'system') );
			}
			return 0;
		}

		// Batch 29 — the messaging-upgrades backlog item's remaining piece
		// ("stop making users wait for the next poll") turned out to
		// already have working infra sitting unused: JP_PWA::send_push()
		// is a real, working VAPID Web Push sender (batch 18 hardened its
		// stale-subscription cleanup) that was never called from anywhere
		// except its own admin test-send route — every one of the 25+
		// call sites that build a real notification through THIS method
		// (stage changes, new messages, offers, interview panel feedback,
		// etc.) only ever produced an in-app bell notification a candidate
		// would see next time they opened the app; there was no push.
		// Hooking it in here, at the one chokepoint every caller already
		// goes through, means every existing notification type gets real
		// push delivery with no changes needed anywhere else. send_push()
		// already degrades to a safe no-op (returns 0) when the user has
		// no subscriptions or VAPID isn't configured, but a push failure
		// must never be allowed to turn a successful in-app notification
		// into a reported failure — this is a best-effort side channel,
		// not the primary action, so it's isolated in its own try/catch
		// and never re-thrown.
		if ( class_exists( 'JP_PWA' ) && $uid ) {
			try {
				JP_PWA::instance()->send_push( $uid, [ 'title' => $title, 'body' => $body, 'url' => $url ] );
			} catch ( \Throwable $e ) {
				if ( class_exists( 'JP_ErrorLog' ) ) {
					JP_ErrorLog::instance()->log_exception( $e, 'JP_Notifications::create push-notify user_id=' . $uid );
				}
			}
		}

		return (int)$wpdb->insert_id;
	}

	public function ajax_get(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');
		$uid   = get_current_user_id();
		global $wpdb;
		$notifs = $wpdb->get_results($wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_notifications WHERE user_id=%d ORDER BY created_at DESC LIMIT 50",
			$uid
		));
		// Root-cause fix: the previous expression compared the whole result
		// array to `false` and summed a 1- or 0-element literal array — it
		// could never reflect the real unread count. Count rows whose
		// is_read column is falsy instead.
		$unread = count( array_filter( $notifs ?? [], static fn( $n ) => empty( $n->is_read ) ) );
		jp_json_response(true,['notifications'=>$notifs??[],'unread'=>$unread]);
	}

	public function ajax_mark_read(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');
		global $wpdb;
		$result = $wpdb->update($wpdb->prefix.'jp_notifications',['is_read'=>1],['user_id'=>get_current_user_id(),'is_read'=>0],['%d'],['%d','%d']);
		if ( false === $result ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_notifications mark-read update failed: ' . $wpdb->last_error ), 'JP_Notifications::ajax_mark_read user_id=' . get_current_user_id() );
			}
			jp_json_response(false,'Could not mark notifications as read. Please try again.');
		}
		jp_json_response(true,['message'=>'All notifications marked as read.']);
	}

	public function get_unread_count( int $user_id ): int {
		global $wpdb;
		return (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}jp_notifications WHERE user_id=%d AND is_read=0",$user_id));
	}

	// ── Email dispatch ────────────────────────────────────────────────────────

	public function send_email( string $to, string $subject, string $html_body ): bool {
		$site_name = jp_site_name();
		$from_email= defined('JP_SMTP_FROM') ? JP_SMTP_FROM : 'noreply@'.parse_url(home_url(),PHP_URL_HOST);

		$headers = [
			'Content-Type: text/html; charset=UTF-8',
			"From: {$site_name} <{$from_email}>",
		];

		// Wrap in site template
		$wrapped = $this->wrap_email($html_body,$subject);
		return wp_mail($to,"[{$site_name}] {$subject}",$wrapped,$headers);
	}

	private function wrap_email( string $body, string $subject ): string {
		$site   = jp_site_name();
		$url    = home_url('/');
		$year   = date('Y');
		$primary= '#156BC9';
		return "<!DOCTYPE html><html><head><meta charset='UTF-8'><meta name='viewport' content='width=device-width,initial-scale=1'></head>
<body style='margin:0;padding:0;background:#F7F9FC;font-family:Inter,-apple-system,sans-serif;'>
<table width='100%' cellpadding='0' cellspacing='0'><tr><td align='center' style='padding:32px 16px;'>
<table width='600' cellpadding='0' cellspacing='0' style='background:#fff;border-radius:12px;overflow:hidden;box-shadow:0 4px 12px rgba(0,0,0,.08);'>
  <tr><td style='background:{$primary};padding:24px 32px;'>
    <a href='{$url}' style='color:#fff;font-size:20px;font-weight:800;text-decoration:none;'>{$site}</a>
  </td></tr>
  <tr><td style='padding:32px;color:#374151;font-size:15px;line-height:1.7;'>{$body}</td></tr>
  <tr><td style='background:#F9FAFB;padding:20px 32px;border-top:1px solid #E5E7EB;'>
    <p style='margin:0;font-size:12px;color:#6B7280;'>© {$year} {$site}. <a href='{$url}' style='color:{$primary};'>Visit site</a> · <a href='{$url}unsubscribe/' style='color:{$primary};'>Unsubscribe</a></p>
  </td></tr>
</table></td></tr></table></body></html>";
	}

	// ── Template renderer ─────────────────────────────────────────────────────

	public function render_template( string $template, array $vars = [] ): string {
		$primary = '#156BC9';
		$site    = jp_site_name();

		switch ($template) {

			case 'welcome_job_seeker':
				$name    = esc_html($vars['name']??'there');
				// Root-cause fix (email-template URL sweep, batch 34): every
				// dashboard/recruiter/admin link below was a pre-SPA-rewrite
				// jp-theme query-string path (/my-account/?section=..., etc.)
				// that no router.tsx route matches — a real user clicking any
				// of these emailed links landed on a 404. Replaced with the
				// actual SPA route each one is about (cross-checked against
				// router.tsx's registered paths, the same way batch 33 fixed
				// the in-app NotificationRow.url call sites).
				$dash    = esc_url(home_url('/dashboard'));
				$jobs    = esc_url(home_url('/jobs/'));
				return "<h2 style='color:#111827;margin-top:0;'>Welcome to {$site}, {$name}! 🎉</h2>
					<p>Your account is ready. Here's how to get started:</p>
					<ol><li>Complete your profile to get better job matches</li><li>Upload your resume</li><li>Set job alerts for your dream role</li></ol>
					<p><a href='{$dash}' style='background:{$primary};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;margin-right:10px;'>Go to Dashboard</a>
					<a href='{$jobs}' style='color:{$primary};font-weight:600;'>Browse Jobs →</a></p>";

			case 'welcome_recruiter':
				$name = esc_html($vars['name']??'there');
				$dash = esc_url(home_url('/recruiter'));
				return "<h2 style='color:#111827;margin-top:0;'>Welcome to {$site}! Let's start hiring.</h2>
					<p>Hi {$name}, your employer account is active.</p>
					<p><strong>Quick start:</strong></p>
					<ol><li>Complete your company profile</li><li>Post your first job (free)</li><li>Review applications in the ATS pipeline</li></ol>
					<p><a href='{$dash}' style='background:{$primary};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;'>Open Recruiter Dashboard</a></p>";

			case 'candidate_shortlisted':
				$name    = esc_html($vars['name']??'Candidate');
				$job     = $vars['job']??new \stdClass;
				$dash    = esc_url(home_url('/dashboard/applications'));
				return "<h2 style='color:#111827;margin-top:0;'>🎯 Great news, {$name}!</h2>
					<p>You've been <strong>shortlisted</strong> for <strong>".esc_html($job->title??'')."</strong>.</p>
					<p>The recruiter is reviewing your profile. You may be contacted for next steps.</p>
					<p><a href='{$dash}' style='background:{$primary};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;'>View Application</a></p>";

			case 'candidate_interview_scheduled':
				$name    = esc_html($vars['name']??'Candidate');
				$job     = $vars['job']??new \stdClass;
				$iv      = $vars['interview']??new \stdClass;
				$date    = isset($iv->scheduled_at) ? date('l, j F Y \a\t g:i A',strtotime($iv->scheduled_at)) : 'TBD';
				$type    = esc_html(ucfirst($iv->type??'interview'));
				$link    = esc_url($iv->meeting_link??'');
				// Batch 36: points at the new candidate-facing interviews
				// page (InterviewsPage.tsx) rather than the applications
				// list — a candidate reading "you have an interview" wants
				// the interview details/confirm/reschedule actions, not
				// their whole application history.
				$dash    = esc_url(home_url('/dashboard/interviews'));
				return "<h2 style='color:#111827;margin-top:0;'>📅 Interview Scheduled, {$name}!</h2>
					<p>You have an interview for <strong>".esc_html($job->title??'')."</strong>.</p>
					<table style='background:#F3F4F6;border-radius:8px;padding:16px;width:100%;'>
					<tr><td style='padding:4px 0;'><strong>Date & Time:</strong></td><td>{$date}</td></tr>
					<tr><td style='padding:4px 0;'><strong>Type:</strong></td><td>{$type}</td></tr>
					".($link?"<tr><td><strong>Link:</strong></td><td><a href='{$link}'>{$link}</a></td></tr>":'')."
					</table>
					<p style='margin-top:20px;'><a href='{$dash}' style='background:{$primary};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;'>View Details</a></p>";

			case 'candidate_offer_sent':
				$name    = esc_html($vars['name']??'Candidate');
				$job     = $vars['job']??new \stdClass;
				$salary  = esc_html(jp_format_salary((int)($job->salary_min??0),(int)($job->salary_max??0)));
				$dash    = esc_url(home_url('/dashboard/applications'));
				return "<h2 style='color:#065F46;margin-top:0;'>🎉 Offer Letter Sent, {$name}!</h2>
					<p>Congratulations! You have received an offer for <strong>".esc_html($job->title??'')."</strong>.</p>
					<p><strong>Compensation:</strong> {$salary}/year</p>
					<p>Please review the offer and confirm your acceptance within 5 business days.</p>
					<p><a href='{$dash}' style='background:#065F46;color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;'>View Offer</a></p>";

			case 'candidate_hired':
				$name = esc_html($vars['name']??'Candidate');
				$job  = $vars['job']??new \stdClass;
				return "<h2 style='color:#065F46;margin-top:0;'>🥳 Congratulations {$name} — You're Hired!</h2>
					<p>Your application for <strong>".esc_html($job->title??'')."</strong> has been confirmed.</p>
					<p>The hiring team will be in touch with onboarding details. Best of luck in your new role!</p>";

			case 'candidate_rejected':
				$name    = esc_html($vars['name']??'Candidate');
				$job     = $vars['job']??new \stdClass;
				$jobs    = esc_url(home_url('/jobs/'));
				return "<h2 style='color:#111827;margin-top:0;'>Application Update, {$name}</h2>
					<p>Thank you for applying for <strong>".esc_html($job->title??'')."</strong>.</p>
					<p>After careful consideration, the team has decided to move forward with other candidates at this time. We encourage you to apply for other openings.</p>
					<p><a href='{$jobs}' style='color:{$primary};font-weight:600;'>Browse More Jobs →</a></p>";

			case 'application_received':
				$name    = esc_html($vars['recruiter_name']??'Recruiter');
				$job     = $vars['job']??new \stdClass;
				$cand    = esc_html($vars['candidate_name']??'Candidate');
				$dash    = esc_url(home_url('/recruiter/applications'));
				return "<h2 style='color:#111827;margin-top:0;'>New Application Received</h2>
					<p>Hi {$name}, <strong>{$cand}</strong> has applied for <strong>".esc_html($job->title??'')."</strong>.</p>
					<p><a href='{$dash}' style='background:{$primary};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;'>Review Application</a></p>";

			case 'job_alert_instant':
				$name    = esc_html($vars['name']??'there');
				$job     = $vars['job']??new \stdClass;
				$url     = esc_url($vars['job_url']??home_url('/jobs/'.$job->slug.'/'));
				return "<h2 style='color:#111827;margin-top:0;'>🔔 New Job Match!</h2>
					<p>Hi {$name}, a new job matches your alert:</p>
					<div style='background:#EFF6FF;border-left:4px solid {$primary};border-radius:0 8px 8px 0;padding:16px;margin:16px 0;'>
					<strong>".esc_html($job->title??'')."</strong><br>
					<span style='color:#6B7280;'>".esc_html($job->location_city??'Remote')." · ".esc_html(str_replace('-',' ',ucfirst($job->job_type??'')))."</span>
					</div>
					<p><a href='{$url}' style='background:{$primary};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;'>View Job</a></p>";

			case 'job_alert_digest':
				$name    = esc_html($vars['name']??'there');
				$freq    = esc_html($vars['frequency']??'Daily');
				$jobs    = $vars['jobs']??[];
				$html    = "<h2 style='color:#111827;margin-top:0;'>{$freq} Job Digest 📬</h2><p>Hi {$name}, here are new jobs matching your alert:</p>";
				foreach ($jobs as $j) {
					$jurl = esc_url(home_url('/jobs/'.$j->slug.'/'));
					$html.= "<div style='border:1px solid #E5E7EB;border-radius:8px;padding:14px;margin-bottom:10px;'>
					<strong><a href='{$jurl}' style='color:{$primary};text-decoration:none;'>".esc_html($j->title)."</a></strong><br>
					<span style='font-size:13px;color:#6B7280;'>".esc_html($j->location_city??'Remote')." · ".esc_html(str_replace('-',' ',ucfirst($j->job_type??'')))."</span></div>";
				}
				return $html;

			case 'payment_success':
				$name    = esc_html($vars['name']??'Customer');
				$plan    = esc_html($vars['plan_name']??'Plan');
				$amount  = esc_html($vars['amount']??'');
				$dash    = esc_url(home_url('/recruiter/billing'));
				return "<h2 style='color:#065F46;margin-top:0;'>✅ Payment Successful</h2>
					<p>Hi {$name}, your payment of <strong>₹{$amount}</strong> for the <strong>{$plan}</strong> plan has been received.</p>
					<p>Your account has been upgraded and new credits are available.</p>
					<p><a href='{$dash}' style='color:{$primary};font-weight:600;'>View Billing →</a></p>";

			case 'new_message':
				$name    = esc_html($vars['name']??'there');
				$sender  = esc_html($vars['sender_name']??'Someone');
				$preview = esc_html(mb_substr($vars['message_body']??'',0,120));
				// class-jp-messaging.php's ajax_send() always passes a
				// correct, role-aware, already-absolute url now; this
				// fallback only matters for a caller that doesn't (there are
				// none today), so it's kept pointed at a real SPA route
				// rather than the old dead /my-account/?section= path.
				$url     = esc_url($vars['url']??home_url('/dashboard/messages'));
				return "<h2 style='color:#111827;margin-top:0;'>💬 New Message from {$sender}</h2>
					<p>Hi {$name},</p>
					<blockquote style='border-left:3px solid {$primary};padding-left:16px;color:#6B7280;margin:16px 0;'>{$preview}…</blockquote>
					<p><a href='{$url}' style='background:{$primary};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;'>Reply</a></p>";

			case 'password_reset':
				$name = esc_html($vars['name']??'User');
				$link = esc_url($vars['reset_link']??'');
				return "<h2 style='color:#111827;margin-top:0;'>Reset Your Password</h2>
					<p>Hi {$name}, you requested a password reset.</p>
					<p>Click the button below to set a new password. This link expires in 1 hour.</p>
					<p><a href='{$link}' style='background:{$primary};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;'>Reset Password</a></p>
					<p style='color:#9CA3AF;font-size:13px;'>If you didn't request this, ignore this email.</p>";

			case 'new_job_pending':
				$job  = $vars['job']??new \stdClass;
				$url  = esc_url(home_url('/admin/jobs'));
				return "<h2 style='color:#111827;margin-top:0;'>New Job Pending Review</h2>
					<p>A new job has been submitted and requires approval:</p>
					<p><strong>".esc_html($job->title??'')."</strong></p>
					<p><a href='{$url}' style='background:{$primary};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;'>Review Job</a></p>";

			// Root cause (gap analysis / RULE 7-adjacent audit, §33): these 5
			// template keys are declared in self::TEMPLATES and have real,
			// live callers (send_stage_email() for the two candidate_*
			// stages; class-jp-cron.php, class-jp-settings.php's own "Send
			// Test Email" button, and class-jp-subscriptions.php for the
			// other 3) but had NO case here — every one of them silently
			// fell through to the generic `default` below, meaning the
			// email that was actually sent to a real candidate/recruiter/
			// admin ignored every $vars value and said nothing but
			// "Notification from {site}." This was invisible in normal
			// testing because the email still "sends successfully" (no
			// error, no failed status) — the content itself was just empty
			// of any useful information, which for a phone-screen or
			// assessment-stage notification to a candidate is the email
			// equivalent of a silent failure. The 6 other declared-but-
			// unused template keys (email_verification, job_approved,
			// job_rejected, review_approved, interview_reminder,
			// payment_failed) were checked and confirmed to have NO
			// render_template() caller anywhere in the codebase — genuinely
			// unused, not another instance of this same bug — and are
			// intentionally left unimplemented rather than building content
			// for a call path that doesn't exist.
			case 'candidate_phone_screen':
				$name = esc_html($vars['name']??'Candidate');
				$job  = $vars['job']??new \stdClass;
				$dash = esc_url(home_url('/dashboard/applications'));
				return "<h2 style='color:#111827;margin-top:0;'>📞 Phone Screen Scheduled, {$name}!</h2>
					<p>Good news — you've moved forward for <strong>".esc_html($job->title??'')."</strong>. The recruiter will reach out to schedule a phone screen.</p>
					<p><a href='{$dash}' style='background:{$primary};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;'>View Application</a></p>";

			case 'candidate_assessment':
				$name = esc_html($vars['name']??'Candidate');
				$job  = $vars['job']??new \stdClass;
				$dash = esc_url(home_url('/dashboard/applications'));
				return "<h2 style='color:#111827;margin-top:0;'>📝 Skills Assessment, {$name}</h2>
					<p>You've been asked to complete a skills assessment for <strong>".esc_html($job->title??'')."</strong>.</p>
					<p>Check your dashboard for the assessment link and any deadline the recruiter has set.</p>
					<p><a href='{$dash}' style='background:{$primary};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;'>Go to Dashboard</a></p>";

			case 'job_expiring_soon':
				// Named "expiring_soon" but, per its only caller
				// (class-jp-cron.php's hourly expiry sweep), this fires
				// AFTER the job has already been moved to status='expired'
				// — content says "has expired," matching the subject line
				// that caller already uses ("Your job listing has
				// expired:..."), not "is about to expire."
				$name = esc_html($vars['name']??'there');
				$job  = $vars['job']??new \stdClass;
				$dash = esc_url(home_url('/recruiter/jobs'));
				return "<h2 style='color:#111827;margin-top:0;'>Job Listing Expired</h2>
					<p>Hi {$name}, your listing <strong>".esc_html($job->title??'')."</strong> has expired and is no longer visible to job seekers.</p>
					<p>Repost it or extend its duration from your dashboard to keep receiving applications.</p>
					<p><a href='{$dash}' style='background:{$primary};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;'>Manage Jobs</a></p>";

			case 'subscription_expiring':
				$name      = esc_html($vars['name']??'there');
				$plan      = esc_html($vars['plan_name']??'your plan');
				$days_left = $vars['days_left']??null;
				$when      = $days_left !== null ? 'in ' . (int) $days_left . ' day' . ((int) $days_left === 1 ? '' : 's') : 'soon';
				$dash      = esc_url(home_url('/recruiter/billing'));
				return "<h2 style='color:#92400E;margin-top:0;'>⏳ Subscription Renewing {$when}</h2>
					<p>Hi {$name}, your <strong>{$plan}</strong> subscription renews {$when}.</p>
					<p>No action is needed if your payment method is up to date. Update billing details from your dashboard if it isn't.</p>
					<p><a href='{$dash}' style='background:{$primary};color:#fff;padding:12px 24px;border-radius:8px;text-decoration:none;font-weight:600;display:inline-block;'>View Billing</a></p>";

			case 'system_announcement':
				$name    = esc_html($vars['name']??'there');
				$message = wp_kses_post($vars['message']??'');
				return "<h2 style='color:#111827;margin-top:0;'>📢 {$site} Announcement</h2>
					<p>Hi {$name},</p>
					<div style='background:#F3F4F6;border-radius:8px;padding:16px;margin:16px 0;'>{$message}</div>";

			default:
				return "<p>Notification from {$site}.</p>";
		}
	}

	// ── Stage email dispatcher (called by JP_Applications) ────────────────────

	public function send_stage_email( int $app_id, string $stage ): void {
		global $wpdb;
		$app       = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_applications WHERE id=%d",$app_id));
		if (!$app) return;
		$job       = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_jobs WHERE id=%d",$app->job_id));
		$candidate = get_userdata($app->candidate_id);
		if (!$candidate||!$job) return;

		$template_map = JP_Applications::STAGE_EMAILS;
		$template     = $template_map[$stage]??null;
		if (!$template) return;

		$body     = $this->render_template($template,['name'=>$candidate->display_name,'job'=>$job,'candidate_name'=>$candidate->display_name]);
		$subjects = [
			'candidate_shortlisted'        => 'You\'ve been shortlisted for '.$job->title,
			'candidate_phone_screen'       => 'Phone screen scheduled — '.$job->title,
			'candidate_interview_scheduled'=> 'Interview scheduled — '.$job->title,
			'candidate_assessment'         => 'Skills assessment — '.$job->title,
			'candidate_offer_sent'         => '🎉 Job Offer — '.$job->title,
			'candidate_hired'              => '🥳 You\'re Hired — '.$job->title,
			'candidate_rejected'           => 'Application update — '.$job->title,
		];
		$subject = $subjects[$template] ?? 'Application update';
		$this->send_email($candidate->user_email,$subject,$body);
	}

	// ── Hook handlers ─────────────────────────────────────────────────────────

	public function on_stage_changed( int $app_id, string $old_stage, string $new_stage, int $actor_id ): void {
		$this->send_stage_email($app_id,$new_stage);
	}

	public function on_application_submitted( int $app_id, int $job_id, int $user_id ): void {
		global $wpdb;
		$job  = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_jobs WHERE id=%d",$job_id));
		if (!$job||!$job->posted_by) return;
		$rec  = get_userdata($job->posted_by);
		$cand = get_userdata($user_id);
		if (!$rec||!$cand) return;
		$body = $this->render_template('application_received',['recruiter_name'=>$rec->display_name,'job'=>$job,'candidate_name'=>$cand->display_name]);
		$this->send_email($rec->user_email,'New application for '.$job->title,$body);
	}

	public function on_job_published( int $job_id ): void {
		global $wpdb;
		$job    = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_jobs WHERE id=%d",$job_id));
		if (!$job) return;
		// Notify admins of pending jobs
		if ($job->status === 'pending') {
			$admins = get_users(['role'=>'administrator']);
			foreach ($admins as $a) {
				$body = $this->render_template('new_job_pending',['job'=>$job]);
				$this->send_email($a->user_email,'New job pending review: '.$job->title,$body);
			}
		}
	}

	public function on_payment_completed( array $data ): void {
		$user = get_userdata($data['user_id']??0);
		if (!$user) return;
		$body = $this->render_template('payment_success',['name'=>$user->display_name,'plan_name'=>$data['plan_name']??'','amount'=>number_format($data['amount']??0)]);
		$this->send_email($user->user_email,'Payment confirmed — '.$data['plan_name']??'Plan',$body);
	}

	public function on_new_message( array $data ): void {
		$to   = get_userdata($data['recipient_id']??0);
		$from = get_userdata($data['sender_id']??0);
		if (!$to||!$from) return;
		$body = $this->render_template('new_message',['name'=>$to->display_name,'sender_name'=>$from->display_name,'message_body'=>$data['body']??'','url'=>$data['url']??'']);
		$this->send_email($to->user_email,'New message from '.$from->display_name,$body);
	}
}
