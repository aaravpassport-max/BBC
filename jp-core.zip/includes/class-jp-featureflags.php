<?php
/**
 * Class JP_FeatureFlags — implements the feature-flag infrastructure that
 * previously existed at the schema layer only.
 *
 * ROOT CAUSE (gap analysis P0 #58): `jp_feature_flags` — a table with
 * exactly the columns needed for safe, gradual rollout / kill-switches
 * (`flag_key`, `is_enabled`, `plan_tier`) — existed with no implementing
 * class, no REST/AJAX routes, and no UI anywhere. The infrastructure for
 * "turn a risky new feature off instantly without a code deploy" existed
 * on paper and nowhere else — meaning every actual rollout in this
 * codebase (webhooks, team seats, the background queue, all built this
 * session) shipped as an unconditional code change with no kill-switch at
 * all, because there was nothing to check one against.
 *
 * This class:
 *   - `is_enabled( string $key, ?int $company_id = null ): bool` — the one
 *     call other code needs. Checks `is_enabled` and, if the flag has a
 *     `plan_tier` other than 'all', additionally requires the given
 *     company to be on that plan tier (or higher — tiers are ordered by
 *     `jp_plans.sort_order`) before returning true. An unknown flag key
 *     defaults to `false` (fail closed — a typo'd flag key should not
 *     silently enable something) unless `$default_if_missing` is passed.
 *   - Per-request memoization (one query per unique flag key per request,
 *     not one per call site that checks it).
 *   - Admin CRUD (list/create/update/delete) so an admin can flip a flag
 *     without a deploy — the actual point of this table existing at all.
 *   - A logged-in-user-facing endpoint returning the current user's
 *     resolved flag set, so the React SPA (or any client code) can gate UI
 *     without needing its own copy of the plan-tier-resolution logic.
 */
defined( 'ABSPATH' ) || exit;

class JP_FeatureFlags {

	private static ?JP_FeatureFlags $instance = null;

	/** Per-request memoization: flag_key => row (or null if not found). */
	private array $cache = [];

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_jp_admin_flags_list',   [ $this, 'ajax_list' ] );
		add_action( 'wp_ajax_jp_admin_flags_save',   [ $this, 'ajax_save' ] );
		add_action( 'wp_ajax_jp_admin_flags_delete', [ $this, 'ajax_delete' ] );
		add_action( 'wp_ajax_jp_get_flags',          [ $this, 'ajax_get_resolved_flags' ] );
	}

	/**
	 * The one method the rest of the codebase should call. Fails closed:
	 * an unknown key returns false rather than silently enabling
	 * something, unless the caller explicitly opts into a different
	 * default (e.g. a flag meant to be "on unless explicitly disabled").
	 */
	public function is_enabled( string $key, ?int $company_id = null, bool $default_if_missing = false ): bool {
		$flag = $this->get_flag( $key );
		if ( ! $flag ) return $default_if_missing;
		if ( ! (bool) $flag->is_enabled ) return false;
		if ( ( $flag->plan_tier ?? 'all' ) === 'all' ) return true;
		if ( ! $company_id ) return false; // plan-gated flag, no company context to check against

		return $this->company_meets_tier( $company_id, $flag->plan_tier );
	}

	private function get_flag( string $key ) {
		if ( array_key_exists( $key, $this->cache ) ) return $this->cache[ $key ];
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_feature_flags WHERE flag_key = %s", $key
		) );
		return $this->cache[ $key ] = $row;
	}

	/** A company "meets" a tier if its current plan's sort_order is >= the required tier's sort_order. */
	private function company_meets_tier( int $company_id, string $required_tier ): bool {
		global $wpdb;
		$company_order = $wpdb->get_var( $wpdb->prepare(
			"SELECT pl.sort_order FROM {$wpdb->prefix}jp_subscriptions s
			 JOIN {$wpdb->prefix}jp_plans pl ON pl.id = s.plan_id
			 WHERE s.company_id = %d AND s.status IN ('trial','active') ORDER BY s.id DESC LIMIT 1",
			$company_id
		) );
		if ( $company_order === null ) return false; // no active plan at all

		$required_order = $wpdb->get_var( $wpdb->prepare(
			"SELECT sort_order FROM {$wpdb->prefix}jp_plans WHERE slug = %s", $required_tier
		) );
		if ( $required_order === null ) return false; // plan_tier references a plan slug that doesn't exist — fail closed

		return (int) $company_order >= (int) $required_order;
	}

	// ── Admin CRUD ────────────────────────────────────────────────────────────
	//
	// Root-cause fix (found while wiring the React SPA's Feature Flags
	// settings screen): this entire admin CRUD surface only ever existed as
	// wp_ajax_* handlers, authenticated via check_ajax_referer() against a
	// browser-cookie nonce ('jp_admin_flags') that is never minted for, or
	// sent by, the REST-only SPA (see AuthContext.tsx/apiClient.ts — every
	// SPA request authenticates via WP cookie + X-WP-Nonce against the
	// 'wp_rest' action, a completely different nonce action/value). There
	// was no REST route registered anywhere for feature flags at all, so an
	// admin could never reach this from the app — confirmed by grepping
	// class-jp-api.php's route table, which has none. Rather than bridge
	// AJAX from REST (the exact fragile pattern already root-caused and
	// replaced elsewhere in this codebase — see JP_Api::bridge_ajax()'s own
	// docblock), the shared DB logic is pulled out into plain methods below
	// that take/return simple values instead of reading $_POST or calling
	// wp_send_json() directly. Both the legacy ajax_*() methods (kept, in
	// case any other in-process caller still expects them) and the new
	// REST callbacks registered in JP_Api now call these same methods, so
	// there is exactly one implementation of "list/save/delete a flag" to
	// keep correct, not two copies that can drift.

	/** @return array<int,object> all flags, ordered by key. */
	public function list_flags(): array {
		global $wpdb;
		return $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}jp_feature_flags ORDER BY flag_key ASC" ) ?: [];
	}

	/**
	 * Create or update a flag. Returns a WP_Error on validation failure so
	 * both call sites (AJAX and REST) can decide how to surface it in
	 * their own response shape, instead of this method picking one for them.
	 */
	public function save_flag( string $key, bool $is_enabled, string $plan_tier, string $description ) {
		$key = sanitize_key( $key );
		if ( ! $key ) return new \WP_Error( 'jp_flag_invalid', 'flag_key is required.' );

		global $wpdb;
		$plan_tier   = sanitize_text_field( $plan_tier ?: 'all' );
		$description = sanitize_textarea_field( $description );
		$existing_id = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}jp_feature_flags WHERE flag_key = %s", $key ) );

		// Root-cause fix (batch 18): unchecked writes that unconditionally
		// `return true` regardless of outcome — same ghost-success shape
		// found throughout this codebase, here in an admin-only surface
		// (lower blast radius than customer-facing instances, but a
		// failed toggle previously still audit-logged and reported success
		// while a flag stayed in its old state, e.g. an admin believing
		// they'd disabled a broken feature for everyone when it was still
		// live).
		$data = [ 'flag_key' => $key, 'is_enabled' => $is_enabled ? 1 : 0, 'plan_tier' => $plan_tier, 'description' => $description ];
		if ( $existing_id ) {
			$write_ok = false !== $wpdb->update( $wpdb->prefix . 'jp_feature_flags', $data, [ 'id' => $existing_id ] );
		} else {
			$write_ok = false !== $wpdb->insert( $wpdb->prefix . 'jp_feature_flags', $data );
		}
		if ( ! $write_ok ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_feature_flags write failed: ' . $wpdb->last_error ), 'JP_FeatureFlags::save_flag key=' . $key );
			}
			return new \WP_Error( 'jp_flag_write_failed', 'Could not save this flag. Please try again.' );
		}

		if ( class_exists( 'JP_Security' ) ) {
			JP_Security::instance()->audit( 'feature_flag_changed', 'feature_flag', (int) ( $existing_id ?: $wpdb->insert_id ), "Flag '{$key}' set to " . ( $is_enabled ? 'enabled' : 'disabled' ) . " (tier: {$plan_tier})" );
		}
		// Cache is per-request only (a new PHP process handles the next
		// request), so no cross-request invalidation is needed here.
		unset( $this->cache[ $key ] );

		return true;
	}

	/** Returns a WP_Error on validation failure, true on success. */
	public function delete_flag( string $key ) {
		$key = sanitize_key( $key );
		if ( ! $key ) return new \WP_Error( 'jp_flag_invalid', 'flag_key is required.' );

		global $wpdb;
		// Root-cause fix (batch 18): same unchecked-write shape as
		// save_flag() above.
		$deleted = $wpdb->delete( $wpdb->prefix . 'jp_feature_flags', [ 'flag_key' => $key ] );
		if ( false === $deleted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_feature_flags delete failed: ' . $wpdb->last_error ), 'JP_FeatureFlags::delete_flag key=' . $key );
			}
			return new \WP_Error( 'jp_flag_delete_failed', 'Could not delete this flag. Please try again.' );
		}
		unset( $this->cache[ $key ] );

		return true;
	}

	/**
	 * Resolve every flag against a user's company (if any) and return just
	 * the enabled ones, so client code doesn't need its own copy of the
	 * plan-tier resolution logic.
	 *
	 * @return array<int,string> enabled flag keys
	 */
	public function get_resolved_flags_for_user( int $user_id ): array {
		global $wpdb;
		$company_id = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}jp_companies WHERE user_id = %d", $user_id ) ) ?: null;

		$all_keys = $wpdb->get_col( "SELECT flag_key FROM {$wpdb->prefix}jp_feature_flags" );
		return array_values( array_filter( $all_keys, fn( $k ) => $this->is_enabled( $k, $company_id ) ) );
	}

	// ── Legacy AJAX entry points (thin wrappers over the methods above) ────────

	public function ajax_list(): void {
		check_ajax_referer( 'jp_admin_flags', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) jp_json_response( false, 'Permission denied.', 403 );
		jp_json_response( true, [ 'flags' => $this->list_flags() ] );
	}

	public function ajax_save(): void {
		check_ajax_referer( 'jp_admin_flags', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) jp_json_response( false, 'Permission denied.', 403 );

		$result = $this->save_flag(
			(string) ( $_POST['flag_key'] ?? '' ),
			! empty( $_POST['is_enabled'] ),
			(string) ( $_POST['plan_tier'] ?? 'all' ),
			(string) ( $_POST['description'] ?? '' )
		);
		if ( is_wp_error( $result ) ) jp_json_response( false, $result->get_error_message() );
		jp_json_response( true, [ 'message' => 'Flag saved.' ] );
	}

	public function ajax_delete(): void {
		check_ajax_referer( 'jp_admin_flags', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) jp_json_response( false, 'Permission denied.', 403 );

		$result = $this->delete_flag( (string) ( $_POST['flag_key'] ?? '' ) );
		if ( is_wp_error( $result ) ) jp_json_response( false, $result->get_error_message() );
		jp_json_response( true, [ 'message' => 'Flag deleted.' ] );
	}

	public function ajax_get_resolved_flags(): void {
		if ( ! is_user_logged_in() ) jp_json_response( false, 'Not authenticated.', 401 );
		jp_json_response( true, [ 'flags' => $this->get_resolved_flags_for_user( get_current_user_id() ) ] );
	}
}
