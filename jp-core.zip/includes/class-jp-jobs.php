<?php
defined( 'ABSPATH' ) || exit;

/**
 * JP_Jobs — Job listing lifecycle management.
 * Handles: create, update, delete, expiry, status transitions, views, featured.
 */
class JP_Jobs {

    private static ?JP_Jobs $instance = null;
    private JP_DB $db;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->db = JP_DB::instance();
        $this->hooks();
    }

    private function hooks(): void {
        // AJAX handlers
        add_action( 'wp_ajax_jp_post_job',    [ $this, 'ajax_post_job' ] );
        add_action( 'wp_ajax_jp_update_job',  [ $this, 'ajax_update_job' ] );
        add_action( 'wp_ajax_jp_delete_job',  [ $this, 'ajax_delete_job' ] );
        add_action( 'wp_ajax_jp_toggle_job_status', [ $this, 'ajax_toggle_status' ] );
        add_action( 'wp_ajax_jp_save_job',    [ $this, 'ajax_save_job' ] );

        // Track job views (non-ajax)
        add_action( 'wp', [ $this, 'maybe_track_view' ] );
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Create a new job listing.
     */
    public function create( array $data, int $posted_by = 0 ) {
        $posted_by  = $posted_by ?: get_current_user_id();
        $company    = $this->db->get_company_by_user( $posted_by );
        $company_id = $company ? (int) $company->id : 0;

        // Root-cause fix (needed for admin_import_jobs()'s CSV import,
        // enterprise gap-analysis: "no CSV/bulk import anywhere"): every
        // caller of create() up to this point has been a recruiter posting
        // their OWN job, so resolving company_id from posted_by's own
        // company row was always correct. A bulk CSV import run by an
        // admin is different — each row can legitimately belong to a
        // DIFFERENT company than the admin's own (which usually has none
        // at all), so create() needs a way to set company_id explicitly
        // rather than silently mis-attributing every imported job to the
        // wrong company (or none). Gated to admins/approvers specifically
        // so a normal recruiter can't spoof company_id in a future caller.
        if ( ! empty( $data['company_id'] ) && current_user_can( 'jp_approve_jobs' ) ) {
            $override_id = absint( $data['company_id'] );
            if ( $override_id && $this->db->get_company( $override_id ) ) {
                $company_id = $override_id;
            }
        }

        // Auto-approve if admin or setting enabled
        $auto_approve  = get_option( 'jp_auto_approve_jobs' ) === '1';
        $is_admin      = current_user_can( 'jp_approve_jobs' );
        $status        = ( $auto_approve || $is_admin ) ? 'active' : 'pending';

        $expires_days = absint( get_option( 'jp_job_expiry_days', 30 ) );

        $insert = [
            'company_id'     => $company_id,
            'posted_by'      => $posted_by,
            'title'          => sanitize_text_field( $data['title'] ?? '' ),
            'slug'           => $this->unique_slug( sanitize_title( $data['title'] ?? '' ) ),
            'description'    => wp_kses_post( $data['description'] ?? '' ),
            'requirements'   => wp_kses_post( $data['requirements'] ?? '' ),
            'skills_json'    => wp_json_encode( array_map( 'sanitize_text_field', (array) ( $data['skills'] ?? [] ) ) ),
            'screening_q'    => wp_json_encode( $data['screening_questions'] ?? [] ),
            'job_type'       => $this->sanitize_enum( $data['job_type'] ?? 'full-time', [ 'full-time','part-time','contract','internship','freelance' ] ),
            'work_mode'      => $this->sanitize_enum( $data['work_mode'] ?? 'onsite', [ 'onsite','remote','hybrid' ] ),
            'experience_min' => absint( $data['experience_min'] ?? 0 ),
            'experience_max' => absint( $data['experience_max'] ?? 0 ),
            'location_city'  => sanitize_text_field( $data['location_city'] ?? '' ),
            'location_state' => sanitize_text_field( $data['location_state'] ?? '' ),
            'salary_min'     => absint( $data['salary_min'] ?? 0 ),
            'salary_max'     => absint( $data['salary_max'] ?? 0 ),
            'salary_visible' => isset( $data['salary_visible'] ) ? 1 : 0,
            'is_featured'    => 0,
            'status'         => $status,
            'expires_at'     => gmdate( 'Y-m-d H:i:s', strtotime( "+{$expires_days} days" ) ),
        ];

        $job_id = $this->db->insert( 'jobs', $insert );

        if ( $job_id ) {
            JP_Cache::flush_group( 'jobs' );
            $this->db->audit( 'job_created', 'job', $job_id, "Title: {$insert['title']}", $company_id );
            do_action( 'jp_job_created', $job_id, $insert, $posted_by );
        }

        return $job_id;
    }

    /**
     * Update an existing job.
     */
    public function update( int $job_id, array $data, int $user_id = 0 ): bool {
        $user_id = $user_id ?: get_current_user_id();
        $job     = $this->db->get_job( $job_id );

        if ( ! $job ) return false;

        // Permission check: owner or admin
        if ( (int) $job->posted_by !== $user_id && ! current_user_can( 'jp_approve_jobs' ) ) {
            return false;
        }

        $update = array_filter( [
            'title'          => isset( $data['title'] )       ? sanitize_text_field( $data['title'] )       : null,
            'description'    => isset( $data['description'] ) ? wp_kses_post( $data['description'] )        : null,
            'requirements'   => isset( $data['requirements'] ) ? wp_kses_post( $data['requirements'] )      : null,
            'skills_json'    => isset( $data['skills'] )      ? wp_json_encode( array_map( 'sanitize_text_field', (array) $data['skills'] ) ) : null,
            // Root-cause fix (batch 35): screening_questions could be set on
            // create() but was never included here, so editing an existing
            // job's screening questions (or, previously, an existing job's
            // location_state/experience_min/experience_max/salary_visible —
            // fixed alongside since they're the same "silently ignored on
            // edit" bug in the same array) had no effect at all: the SPA's
            // save call would report success (the query still matched a
            // real row) while the fields the recruiter just changed stayed
            // exactly as they were.
            'screening_q'    => isset( $data['screening_questions'] ) ? wp_json_encode( $data['screening_questions'] ) : null,
            'job_type'       => isset( $data['job_type'] )    ? $this->sanitize_enum( $data['job_type'], [ 'full-time','part-time','contract','internship','freelance' ] ) : null,
            'work_mode'      => isset( $data['work_mode'] )   ? $this->sanitize_enum( $data['work_mode'], [ 'onsite','remote','hybrid' ] )     : null,
            'location_city'  => isset( $data['location_city'] ) ? sanitize_text_field( $data['location_city'] ) : null,
            'location_state' => isset( $data['location_state'] ) ? sanitize_text_field( $data['location_state'] ) : null,
            'experience_min' => isset( $data['experience_min'] ) ? absint( $data['experience_min'] ) : null,
            'experience_max' => isset( $data['experience_max'] ) ? absint( $data['experience_max'] ) : null,
            'salary_min'     => isset( $data['salary_min'] )  ? absint( $data['salary_min'] )  : null,
            'salary_max'     => isset( $data['salary_max'] )  ? absint( $data['salary_max'] )  : null,
            'salary_visible' => isset( $data['salary_visible'] ) ? ( $data['salary_visible'] ? 1 : 0 ) : null,
            'status'         => isset( $data['status'] ) && current_user_can( 'jp_approve_jobs' ) ? sanitize_key( $data['status'] ) : null,
        ], fn( $v ) => null !== $v );

        if ( empty( $update ) ) return false;

        $result = $this->db->update( 'jobs', $update, [ 'id' => $job_id ] );

        if ( $result !== false ) {
            JP_Cache::delete( "job_{$job_id}", 'jobs' );
            JP_Cache::flush_group( 'jobs' );
            $this->db->audit( 'job_updated', 'job', $job_id, '', (int) $job->company_id );
            do_action( 'jp_job_updated', $job_id, $update );
        }

        return $result !== false;
    }

    /**
     * Get a single job (with caching).
     */
    public function get( int $job_id ): ?object {
        return JP_Cache::remember(
            "job_{$job_id}",
            fn() => $this->db->get_job( $job_id ),
            3600,
            'jobs'
        );
    }

    /**
     * Get paginated jobs for search / listing.
     */
    public function get_listing( array $args = [] ): array {
        $page     = max( 1, absint( $args['page'] ?? 1 ) );
        $per_page = absint( get_option( 'jp_jobs_per_page', 20 ) );

        $query_args = wp_parse_args( $args, [
            'status'   => 'active',
            'limit'    => $per_page,
            'offset'   => ( $page - 1 ) * $per_page,
            'order_by' => 'created_at',
            'order'    => 'DESC',
        ] );

        // Don't cache search queries (dynamic)
        if ( ! empty( $args['keyword'] ) || ! empty( $args['location'] ) ) {
            return [
                'jobs'  => $this->db->get_jobs( $query_args ),
                'total' => $this->db->count_jobs( $query_args ),
                'pages' => ceil( $this->db->count_jobs( $query_args ) / $per_page ),
            ];
        }

        $cache_key = 'listing_' . md5( serialize( $query_args ) );

        return JP_Cache::remember( $cache_key, function () use ( $query_args, $per_page ) {
            $total = $this->db->count_jobs( $query_args );
            return [
                'jobs'  => $this->db->get_jobs( $query_args ),
                'total' => $total,
                'pages' => (int) ceil( $total / $per_page ),
            ];
        }, 300, 'jobs' );
    }

    /**
     * Mark a job as expired (called by cron).
     */
    public function expire_jobs(): int {
        global $wpdb;

        $count = (int) $wpdb->query(
            "UPDATE {$wpdb->prefix}jp_jobs
             SET status = 'expired'
             WHERE status = 'active'
             AND expires_at IS NOT NULL
             AND expires_at < NOW()"
        ); // phpcs:ignore

        if ( $count > 0 ) {
            JP_Cache::flush_group( 'jobs' );
        }

        return $count;
    }

    /**
     * Increment view count (non-blocking, batched via transient).
     */
    public function increment_view( int $job_id ): void {
        $key   = "jp_view_buffer_{$job_id}";
        $count = (int) get_transient( $key );
        set_transient( $key, $count + 1, 300 ); // flush every 5 min via cron
    }

    /**
     * Flush buffered view counts to the database (called by JP_Cron).
     */
    public function flush_view_buffer(): void {
        global $wpdb;

        // Find all view buffer transients
        $rows = $wpdb->get_results(
            "SELECT option_name, option_value FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_jp_view_buffer_%'"
        ); // phpcs:ignore

        foreach ( $rows as $row ) {
            $job_id = (int) str_replace( '_transient_jp_view_buffer_', '', $row->option_name );
            $count  = (int) $row->option_value;
            if ( $job_id && $count ) {
                $wpdb->query( $wpdb->prepare(
                    "UPDATE {$wpdb->prefix}jp_jobs SET views_count = views_count + %d WHERE id = %d",
                    $count, $job_id
                ) ); // phpcs:ignore
                delete_transient( "jp_view_buffer_{$job_id}" );
            }
        }
    }

    // ── AJAX handlers ─────────────────────────────────────────────────────────

    public function ajax_post_job(): void {
        jp_verify_nonce( 'jp_post_job' );

        if ( ! current_user_can( 'jp_post_jobs' ) ) {
            jp_json_response( __( 'Permission denied.', 'jp-core' ), false, 403 );
        }

        $job_id = $this->create( $_POST );

        if ( $job_id ) {
            jp_json_response( [
                'job_id'  => $job_id,
                'message' => __( 'Job posted successfully!', 'jp-core' ),
                'status'  => get_option( 'jp_auto_approve_jobs' ) === '1' ? 'active' : 'pending',
            ] );
        } else {
            jp_json_response( __( 'Failed to post job. Please try again.', 'jp-core' ), false, 500 );
        }
    }

    /**
     * LEGACY / CONFIRMED UNREACHABLE (RULE 7 nonce audit, §31): no
     * wp_create_nonce('jp_update_job') call exists anywhere in jp-core or
     * jp-theme-fixed, and no template or script ever calls the
     * 'jp_update_job' AJAX action — this handler cannot be invoked by any
     * legitimate current caller. It is fully superseded by
     * `PUT /jobs/{id}` (JP_API::update_job()), which the React SPA
     * actually uses. Left in place (not deleted) since removing a
     * registered AJAX hook has its own small risk of breaking something
     * this audit didn't find a caller for, and it is provably inert either
     * way (fails nonce verification even if somehow invoked). Documented
     * here so a future maintainer doesn't assume this is the live path and
     * "fix" it instead of the REST endpoint.
     */
    public function ajax_update_job(): void {
        jp_verify_nonce( 'jp_update_job' );

        $job_id = absint( $_POST['job_id'] ?? 0 );
        if ( ! $job_id ) jp_json_response( __( 'Invalid job ID.', 'jp-core' ), false, 400 );

        $result = $this->update( $job_id, $_POST );
        jp_json_response( [ 'success' => $result, 'message' => $result ? __( 'Job updated.', 'jp-core' ) : __( 'Update failed.', 'jp-core' ) ], $result );
    }

    /**
     * LEGACY / CONFIRMED UNREACHABLE (RULE 7 nonce audit, §31): same
     * situation as ajax_update_job() above — no nonce is ever created for
     * 'jp_delete_job' and no caller invokes this action. Superseded by
     * `DELETE /jobs/{id}` (JP_API::delete_job()).
     *
     * IMPORTANT BEHAVIORAL DIFFERENCE if this is ever wired up or reused
     * as a reference: this method performs a HARD delete
     * ($this->db->delete()), while the REST equivalent
     * (JP_API::delete_job()) performs a SOFT delete
     * (UPDATE ... SET status='deleted'). If a future caller is ever
     * pointed at this AJAX action instead of the REST endpoint, deleted
     * jobs would be unrecoverable and would disappear from any
     * soft-delete-aware admin "trash" view that assumes the REST
     * endpoint's behavior — this discrepancy was found during the audit
     * that confirmed this handler is currently dead code, not fixed here,
     * since fixing dead code's behavior to match its live sibling is lower
     * priority than confirming it truly has no caller.
     */
    public function ajax_delete_job(): void {
        jp_verify_nonce( 'jp_delete_job' );

        $job_id = absint( $_POST['job_id'] ?? 0 );
        $job    = $this->db->get_job( $job_id );

        if ( ! $job ) jp_json_response( __( 'Job not found.', 'jp-core' ), false, 404 );

        $can = (int) $job->posted_by === get_current_user_id() || current_user_can( 'jp_approve_jobs' );
        if ( ! $can ) jp_json_response( __( 'Permission denied.', 'jp-core' ), false, 403 );

        $result = $this->db->delete( 'jobs', [ 'id' => $job_id ] );
        if ( $result ) {
            JP_Cache::flush_group( 'jobs' );
            $this->db->audit( 'job_deleted', 'job', $job_id, '', (int) $job->company_id );
        }

        jp_json_response( [ 'success' => (bool) $result ] );
    }

    public function ajax_toggle_status(): void {
        jp_verify_nonce( 'jp_toggle_job_status' );

        if ( ! current_user_can( 'jp_approve_jobs' ) && ! current_user_can( 'jp_manage_own_jobs' ) ) {
            jp_json_response( __( 'Permission denied.', 'jp-core' ), false, 403 );
        }

        $job_id    = absint( $_POST['job_id'] ?? 0 );
        $new_status = sanitize_key( $_POST['status'] ?? '' );

        $allowed = [ 'active', 'paused', 'pending', 'rejected', 'archived' ];
        if ( ! in_array( $new_status, $allowed, true ) ) {
            jp_json_response( __( 'Invalid status.', 'jp-core' ), false, 400 );
        }

        // Fetched for company_id scoping on the audit entry below (gap
        // analysis P1 #137) — was previously not fetched at all here since
        // nothing needed it before company-scoped auditing existed.
        $job_for_audit = $this->db->get_job( $job_id );

        $result = $this->db->update( 'jobs', [ 'status' => $new_status ], [ 'id' => $job_id ] );
        if ( $result !== false ) {
            JP_Cache::delete( "job_{$job_id}", 'jobs' );
            JP_Cache::flush_group( 'jobs' );
            $this->db->audit( 'job_status_changed', 'job', $job_id, "→ {$new_status}", $job_for_audit ? (int) $job_for_audit->company_id : 0 );
            do_action( 'jp_job_status_changed', $job_id, $new_status );
        }

        jp_json_response( [ 'success' => $result !== false, 'new_status' => $new_status ] );
    }

    public function ajax_save_job(): void {
        jp_verify_nonce( 'jp_save_job' );
        // jp_verify_nonce above already calls check_ajax_referer — no duplicate needed.

        if ( ! is_user_logged_in() ) {
            jp_json_response( __( 'Please log in to save jobs.', 'jp-core' ), false, 401 );
        }

        $job_id  = absint( $_POST['job_id'] ?? 0 );
        $user_id = get_current_user_id();

        global $wpdb;
        $existing = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}jp_saved_jobs WHERE user_id = %d AND job_id = %d",
            $user_id, $job_id
        ) );

        // Ghost-success fix: this legacy wp_ajax_jp_save_job handler (still
        // registered and independently reachable — a separate
        // implementation from toggle_save_job() in class-jp-api.php, which
        // the current SPA actually calls and which had the identical bug
        // fixed earlier in this same audit) unconditionally reported
        // success regardless of whether the write actually happened.
        // Fixed here too since the hook is still live, whether or not the
        // SPA is the one calling it.
        if ( $existing ) {
            $result = $wpdb->delete( "{$wpdb->prefix}jp_saved_jobs", [ 'user_id' => $user_id, 'job_id' => $job_id ] );
            if ( false === $result ) {
                if ( class_exists( 'JP_ErrorLog' ) ) {
                    JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_saved_jobs delete failed: ' . $wpdb->last_error ), 'JP_Jobs::ajax_save_job user_id=' . $user_id . ' job_id=' . $job_id );
                }
                jp_json_response( __( 'Could not remove the job from your saved list. Please try again.', 'jp-core' ), false, 500 );
                return;
            }
            jp_json_response( [ 'saved' => false, 'message' => __( 'Job removed from saved list.', 'jp-core' ) ] );
        } else {
            $result = $wpdb->insert( "{$wpdb->prefix}jp_saved_jobs", [ 'user_id' => $user_id, 'job_id' => $job_id ] );
            if ( false === $result ) {
                if ( class_exists( 'JP_ErrorLog' ) ) {
                    JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_saved_jobs insert failed: ' . $wpdb->last_error ), 'JP_Jobs::ajax_save_job user_id=' . $user_id . ' job_id=' . $job_id );
                }
                jp_json_response( __( 'Could not save the job. Please try again.', 'jp-core' ), false, 500 );
                return;
            }
            jp_json_response( [ 'saved' => true, 'message' => __( 'Job saved!', 'jp-core' ) ] );
        }
    }

    // ── View tracking ─────────────────────────────────────────────────────────

    public function maybe_track_view(): void {
        if ( ! is_singular( 'jp_job' ) ) return;

        $job_id = get_the_ID();
        if ( ! $job_id ) return;

        // Don't count the recruiter's own views
        $job = $this->db->get_job( $job_id );
        if ( $job && (int) $job->posted_by === get_current_user_id() ) return;

        // Rate-limit: 1 view per IP per job per hour via transient
        $ip_hash  = md5( $_SERVER['REMOTE_ADDR'] ?? 'anon' );
        $rate_key = "jp_view_rate_{$job_id}_{$ip_hash}";
        if ( get_transient( $rate_key ) ) return;

        set_transient( $rate_key, 1, 3600 );
        $this->increment_view( $job_id );
        $this->db->track( 'job_view', $job_id );
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private function unique_slug( string $base ): string {
        // Delegates to JP_DB::unique_slug() (extracted so auth_register()'s
        // company creation and admin_import_companies()'s CSV import don't
        // need their own copy of this exact loop) — this wrapper is kept so
        // no call site here needed to change.
        return $this->db->unique_slug( 'jobs', $base );
    }

    private function sanitize_enum( string $value, array $allowed ): string {
        return in_array( $value, $allowed, true ) ? $value : $allowed[0];
    }
}
