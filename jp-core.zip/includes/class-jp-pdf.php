<?php
/**
 * JP_PDF
 *
 * Shared PDF-generation support for the plugin.
 *
 * Root cause (gap analysis P1 #96): four separate features — invoice
 * generation (class-jp-payments.php), offer-letter generation
 * (class-jp-applications.php), resume export (class-jp-resume.php), and
 * assessment certificate generation (class-jp-assessments.php) — each
 * independently re-implemented the exact same "check class_exists('TCPDF'),
 * try to require vendor/autoload.php, check again" dependency probe. Worse,
 * only the invoice path had a graceful fallback when TCPDF turned out to be
 * unavailable (an HTML receipt); the other three simply returned false/''
 * with a generic "TCPDF must be installed" error and no admin-facing
 * guidance, meaning a site that never ran `composer install` (this sandbox
 * itself is in that state — see DIAGNOSTICS.md) silently loses three of
 * four PDF-producing features with no actionable signal.
 *
 * This class centralizes the dependency probe (ensure_available()) and a
 * shared HTML-fallback writer (write_html_fallback()) so every call site
 * uses one implementation and, wherever it makes sense for that document
 * type, degrades to a usable HTML document instead of a bare failure.
 *
 * JP_Diagnostics already surfaces "TCPDF Available" as a system-health
 * check (class-jp-diagnostics.php); this class is what the four features
 * actually consult, so fixing the underlying composer install once fixes
 * all four features at once rather than requiring four separate code
 * paths to be independently verified.
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class JP_PDF {

	private static $checked  = false;
	private static $available = false;

	/**
	 * Confirms TCPDF is loaded (or loadable via the bundled composer
	 * autoloader), memoizing the result for the rest of the request so
	 * repeated calls from multiple features don't re-probe the filesystem.
	 */
	public static function ensure_available(): bool {
		if ( self::$checked ) {
			return self::$available;
		}
		self::$checked = true;

		if ( class_exists( 'TCPDF' ) ) {
			self::$available = true;
			return true;
		}

		$autoload = JP_PLUGIN_DIR . 'vendor/autoload.php';
		if ( file_exists( $autoload ) ) {
			require_once $autoload;
		}

		self::$available = class_exists( 'TCPDF' );
		return self::$available;
	}

	/**
	 * Writes an HTML fallback document to a subdirectory of the uploads
	 * folder and returns the absolute filesystem path (callers convert to
	 * a public URL the same way they already do for the PDF path, via
	 * str_replace(ABSPATH, site_url('/'), $path) — kept consistent with
	 * the existing invoice-fallback convention in class-jp-payments.php).
	 *
	 * @param string $subdir    e.g. 'jp-invoices', 'jp-offers', 'jp-resumes', 'jp-certificates'
	 * @param string $filename  e.g. 'offer-123-1700000000.html' (caller is responsible for uniqueness)
	 * @param string $html      Full HTML document body to write.
	 */
	public static function write_html_fallback( string $subdir, string $filename, string $html ): string {
		$dir = trailingslashit( wp_upload_dir()['basedir'] ) . trim( $subdir, '/' ) . '/';
		wp_mkdir_p( $dir );
		$path = $dir . $filename;
		file_put_contents( $path, $html );
		return $path;
	}

	/**
	 * Minimal shared page chrome so the various HTML fallbacks (offer
	 * letter, resume, certificate) look like intentional documents rather
	 * than unstyled dumps, without each feature re-inventing its own
	 * inline stylesheet.
	 */
	public static function wrap_html_document( string $title, string $body_html, string $extra_css = '' ): string {
		return '<!doctype html><html><head><meta charset="utf-8"><title>' . esc_html( $title ) . '</title>'
			. '<style>body{font-family:Arial,Helvetica,sans-serif;max-width:800px;margin:40px auto;padding:0 20px;color:#1a1a1a;line-height:1.6}'
			. 'h1{color:#156bc9}.jp-pdf-fallback-note{background:#fff8e1;border:1px solid #f0d878;padding:10px 14px;border-radius:4px;font-size:13px;margin-bottom:24px}'
			. $extra_css . '</style></head><body>'
			. '<div class="jp-pdf-fallback-note">This document was generated as HTML because the PDF rendering library (TCPDF) is not installed on this server. Ask your administrator to run <code>composer install</code> in the plugin directory to enable PDF output.</div>'
			. $body_html
			. '</body></html>';
	}
}
