<?php
defined( 'ABSPATH' ) || exit;

/**
 * JP_DB — Central database query layer.
 * All DB interactions go through here; never write raw $wpdb calls in feature classes.
 */
class JP_DB {

    private static ?JP_DB $instance = null;
    protected \wpdb $wpdb;

    private function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
    }

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // ── Table name helpers ────────────────────────────────────────────────────

    public function t( string $table ): string {
        return $this->wpdb->prefix . 'jp_' . $table;
    }

    // ── Generic CRUD ──────────────────────────────────────────────────────────

    public function insert( string $table, array $data ) {
        $result = $this->wpdb->insert( $this->t( $table ), $data );
        return $result ? (int) $this->wpdb->insert_id : false;
    }

    public function update( string $table, array $data, array $where ) {
        $result = $this->wpdb->update( $this->t( $table ), $data, $where );
        return $result !== false ? (int) $result : false;
    }

    /**
     * Generic collision-safe slug generator. Extracted (enterprise
     * gap-analysis: needed by both auth_register()'s new company-creation
     * path and admin_import_companies()'s CSV import — JP_Jobs::unique_slug()
     * already had this exact logic hardcoded to the 'jobs' table only,
     * which would have meant a second, drifting copy of the same loop) so
     * every table that needs a unique slug shares one implementation.
     */
    public function unique_slug( string $table, string $base ): string {
        $slug    = $base !== '' ? $base : 'item';
        $counter = 1;
        while ( $this->get_var( $this->prepare( "SELECT id FROM {$this->t($table)} WHERE slug = %s", $slug ) ) ) {
            $slug = $base . '-' . $counter++;
        }
        return $slug;
    }

    public function delete( string $table, array $where ) {
        $result = $this->wpdb->delete( $this->t( $table ), $where );
        return $result !== false ? (int) $result : false;
    }

    public function get_row( string $sql ): ?object {
        return $this->wpdb->get_row( $sql ) ?: null;
    }

    public function get_results( string $sql ): array {
        return $this->wpdb->get_results( $sql ) ?: [];
    }

    public function get_var( string $sql ) {
        return $this->wpdb->get_var( $sql );
    }

    public function query( string $sql ) {
        return $this->wpdb->query( $sql );
    }

    public function prepare( string $sql, ...$args ): string {
        return $this->wpdb->prepare( $sql, ...$args );
    }

    public function last_error(): string {
        return $this->wpdb->last_error;
    }

    // ── Jobs queries ──────────────────────────────────────────────────────────

    public function get_job( int $id ): ?object {
        $sql = $this->prepare( "SELECT * FROM {$this->t('jobs')} WHERE id = %d LIMIT 1", $id );
        return $this->get_row( $sql );
    }

    public function get_jobs( array $args = [] ): array {
        $defaults = [
            'status'    => 'active',
            'limit'     => 20,
            'offset'    => 0,
            'order_by'  => 'created_at',
            'order'     => 'DESC',
        ];
        $args = wp_parse_args( $args, $defaults );

        $where = [];
        $values = [];

        if ( $args['status'] ) {
            $where[]  = 'status = %s';
            $values[] = $args['status'];
        }
        if ( ! empty( $args['company_id'] ) ) {
            $where[]  = 'company_id = %d';
            $values[] = (int) $args['company_id'];
        }
        if ( ! empty( $args['keyword'] ) ) {
            $where[]  = '(title LIKE %s OR description LIKE %s)';
            $kw       = '%' . $this->wpdb->esc_like( $args['keyword'] ) . '%';
            $values[] = $kw;
            $values[] = $kw;
        }
        if ( ! empty( $args['location'] ) ) {
            $where[]  = 'location_city LIKE %s';
            $values[] = '%' . $this->wpdb->esc_like( $args['location'] ) . '%';
        }
        if ( ! empty( $args['job_type'] ) ) {
            $where[]  = 'job_type = %s';
            $values[] = $args['job_type'];
        }
        if ( ! empty( $args['work_mode'] ) ) {
            $where[]  = 'work_mode = %s';
            $values[] = $args['work_mode'];
        }

        $where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';

        // Whitelist order column
        $allowed_order = [ 'created_at', 'views_count', 'applications_cnt', 'is_featured', 'expires_at' ];
        $order_by      = in_array( $args['order_by'], $allowed_order, true ) ? $args['order_by'] : 'created_at';
        $order         = strtoupper( $args['order'] ) === 'ASC' ? 'ASC' : 'DESC';
        // Featured jobs first always
        $order_clause  = "ORDER BY is_featured DESC, {$order_by} {$order}";

        $limit_clause = $this->prepare( 'LIMIT %d OFFSET %d', (int) $args['limit'], (int) $args['offset'] );

        $sql = "SELECT * FROM {$this->t('jobs')} {$where_sql} {$order_clause} {$limit_clause}";

        if ( $values ) {
            $sql = $this->prepare( "SELECT * FROM {$this->t('jobs')} {$where_sql} {$order_clause} {$limit_clause}", ...$values );
        }

        return $this->get_results( $sql );
    }

    public function count_jobs( array $args = [] ): int {
        $where  = [];
        $values = [];

        if ( ! empty( $args['status'] ) ) {
            $where[]  = 'status = %s';
            $values[] = $args['status'];
        }
        if ( ! empty( $args['company_id'] ) ) {
            $where[]  = 'company_id = %d';
            $values[] = (int) $args['company_id'];
        }

        $where_sql = $where ? 'WHERE ' . implode( ' AND ', $where ) : '';
        $sql       = "SELECT COUNT(*) FROM {$this->t('jobs')} {$where_sql}";

        if ( $values ) {
            $sql = $this->prepare( $sql, ...$values );
        }

        return (int) $this->get_var( $sql );
    }

    // ── Companies queries ─────────────────────────────────────────────────────

    public function get_company( int $id ): ?object {
        $sql = $this->prepare( "SELECT * FROM {$this->t('companies')} WHERE id = %d LIMIT 1", $id );
        return $this->get_row( $sql );
    }

    public function get_company_by_user( int $user_id ): ?object {
        $sql = $this->prepare( "SELECT * FROM {$this->t('companies')} WHERE user_id = %d LIMIT 1", $user_id );
        return $this->get_row( $sql );
    }

    // ── Candidates queries ────────────────────────────────────────────────────

    public function get_candidate( int $user_id ): ?object {
        $sql = $this->prepare( "SELECT * FROM {$this->t('candidates')} WHERE user_id = %d LIMIT 1", $user_id );
        return $this->get_row( $sql );
    }

    // ── Candidate skills (single source of truth: jp_user_skills) ─────────────
    //
    // Root cause (4-way skills-storage consolidation, §37): jp_user_skills
    // is the only correctly-designed table for "what skills does this
    // candidate have" — a real skill_id reference, proficiency, years, and
    // the table the §36 skill-deletion usage-guard already protects — but
    // nothing anywhere in this codebase ever wrote to it before this
    // change. Three other places independently tried to represent the
    // same concept and each was broken or disconnected in its own way:
    //   1. class-jp-resume.php and class-jp-api.php read/wrote a
    //      `jp_candidates.skills_json` column that was NEVER CREATED in
    //      class-jp-activator.php's schema — confirmed by reading the
    //      actual CREATE TABLE for jp_candidates: it has education_json,
    //      experience_json, certifications_json, languages_json, but no
    //      skills_json. Any UPDATE that included this key failed OUTRIGHT
    //      (MySQL rejects an UPDATE referencing an unknown column — not
    //      just that field, EVERY field in the same call), and any SELECT
    //      or WHERE referencing it returned nothing or errored.
    //   2. class-jp-assessments.php recorded badge levels in a completely
    //      separate usermeta key (`jp_skill_badges`, keyed by skill NAME,
    //      not skill_id) that neither JP_Matching nor the candidate-search
    //      endpoint ever read.
    //   3. Resume-parsed skills (class-jp-resume.php's extract_skills(),
    //      which already fuzzy-matches free text against jp_skills) tried
    //      to merge into the phantom column in #1 and silently failed.
    // Net effect: candidate skills — 40% of JP_Matching's own documented
    // scoring weight (see that class's docblock) — have been silently
    // worth 0 for every candidate since this feature was built, and there
    // was never any way, anywhere in this system, for a candidate to
    // explicitly declare a skill on their own profile (PUT /candidates/me's
    // field whitelist never included one).
    //
    // These three methods make jp_user_skills the single real source of
    // truth; every consumer (JP_Matching, candidate search, resume
    // auto-populate, the candidate profile endpoint, assessment badges)
    // is updated in this same round to read/write through them instead of
    // any of the 3 broken/disconnected paths above.

    /**
     * Additively link the given skill NAMES to a user, creating any
     * jp_skills row that doesn't already exist (same slug-based dedup
     * JP_API::admin_add_skill() uses) and skipping any the user already
     * has (the UNIQUE KEY user_skill(user_id, skill_id) makes a duplicate
     * insert fail anyway, but checking first avoids relying on catching
     * that as the normal path). Used by resume auto-populate and
     * assessment badge-earning — both are "the system learned something
     * about this candidate," which should ADD to their declared skills,
     * never silently remove one a human might have entered.
     */
    public function add_user_skills( int $user_id, array $skill_names ): int {
        $skill_names = array_values( array_unique( array_filter( array_map( 'trim', $skill_names ) ) ) );
        if ( ! $user_id || ! $skill_names ) return 0;

        $added = 0;
        foreach ( $skill_names as $name ) {
            $slug = sanitize_title( $name );
            if ( ! $slug ) continue; // e.g. a name that's pure punctuation/emoji

            $skill_id = $this->wpdb->get_var( $this->wpdb->prepare( "SELECT id FROM {$this->t('skills')} WHERE slug=%s", $slug ) );
            if ( ! $skill_id ) {
                $inserted = $this->wpdb->insert( $this->t('skills'), [
                    'name' => sanitize_text_field( $name ), 'slug' => $slug, 'category' => '', 'jobs_count' => 0,
                ] );
                if ( ! $inserted ) continue; // insert failed (e.g. a race on the UNIQUE slug) — skip, don't fatal the whole batch
                $skill_id = $this->wpdb->insert_id;
            }

            $already_has = $this->wpdb->get_var( $this->wpdb->prepare(
                "SELECT id FROM {$this->t('user_skills')} WHERE user_id=%d AND skill_id=%d", $user_id, $skill_id
            ) );
            if ( $already_has ) continue;

            $result = $this->wpdb->insert( $this->t('user_skills'), [
                'user_id' => $user_id, 'skill_id' => (int) $skill_id, 'proficiency' => 'intermediate', 'years' => 0,
            ] );
            if ( $result ) $added++;
        }
        return $added;
    }

    /**
     * Replace a candidate's ENTIRE declared skill list with exactly the
     * given names — the semantics a "my skills" profile editor needs
     * (submitting the current full list, including removals), as opposed
     * to add_user_skills()'s additive merge (right for a system inferring
     * skills from a resume or an assessment, wrong for a form the
     * candidate explicitly filled in — a candidate removing a skill from
     * their profile form must actually remove it, not have it silently
     * re-added on the next save).
     */
    public function replace_user_skills( int $user_id, array $skill_names ): int {
        if ( ! $user_id ) return 0;
        $this->wpdb->delete( $this->t('user_skills'), [ 'user_id' => $user_id ] );
        return $this->add_user_skills( $user_id, $skill_names );
    }

    /** The candidate's current skill names, joined from jp_user_skills → jp_skills. */
    public function get_user_skill_names( int $user_id ): array {
        if ( ! $user_id ) return [];
        return $this->wpdb->get_col( $this->wpdb->prepare(
            "SELECT s.name FROM {$this->t('user_skills')} us JOIN {$this->t('skills')} s ON s.id = us.skill_id WHERE us.user_id = %d ORDER BY s.name ASC",
            $user_id
        ) ) ?: [];
    }

    // ── Applications queries ──────────────────────────────────────────────────

    public function get_application( int $id ): ?object {
        $sql = $this->prepare( "SELECT * FROM {$this->t('applications')} WHERE id = %d LIMIT 1", $id );
        return $this->get_row( $sql );
    }

    public function has_applied( int $job_id, int $candidate_id ): bool {
        $sql = $this->prepare(
            "SELECT id FROM {$this->t('applications')} WHERE job_id = %d AND candidate_id = %d LIMIT 1",
            $job_id, $candidate_id
        );
        return (bool) $this->get_var( $sql );
    }

    public function get_applications_for_job( int $job_id, array $args = [] ): array {
        $limit  = (int) ( $args['limit'] ?? 50 );
        $offset = (int) ( $args['offset'] ?? 0 );
        $stage  = sanitize_key( $args['stage'] ?? '' );

        $stage_sql = $stage ? $this->prepare( ' AND a.stage = %s', $stage ) : '';

        $sql = $this->prepare(
            "SELECT a.*, u.display_name, u.user_email
             FROM {$this->t('applications')} a
             LEFT JOIN {$this->wpdb->users} u ON u.ID = a.candidate_id
             WHERE a.job_id = %d {$stage_sql}
             ORDER BY a.match_score DESC, a.created_at DESC
             LIMIT %d OFFSET %d",
            $job_id, $limit, $offset
        );

        return $this->get_results( $sql );
    }

    // ── Notifications ─────────────────────────────────────────────────────────

    public function add_notification( int $user_id, string $type, string $title, string $body = '', string $url = '', array $meta = [] ) {
        return $this->insert( 'notifications', [
            'user_id'   => $user_id,
            'type'      => $type,
            'title'     => $title,
            'body'      => $body,
            'url'       => $url,
            'meta_json' => $meta ? wp_json_encode( $meta ) : null,
        ] );
    }

    public function get_unread_count( int $user_id ): int {
        $sql = $this->prepare(
            "SELECT COUNT(*) FROM {$this->t('notifications')} WHERE user_id = %d AND is_read = 0",
            $user_id
        );
        return (int) $this->get_var( $sql );
    }

    // ── Analytics ─────────────────────────────────────────────────────────────

    public function track( string $event, int $object_id = 0, array $meta = [] ): void {
        $this->insert( 'analytics', [
            'event'     => $event,
            'user_id'   => get_current_user_id(),
            'object_id' => $object_id,
            'meta_json' => $meta ? wp_json_encode( $meta ) : null,
            'ip'        => $this->get_client_ip(),
            'ua'        => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 300 ) : '',
        ] );
    }

    // ── Audit log ─────────────────────────────────────────────────────────────

    public function audit( string $action, string $object = '', int $object_id = 0, string $detail = '', int $company_id = 0 ): void {
        // Root-cause fix (gap analysis P1 #137: "The audit log is written
        // from two separate, duplicated code paths ... with no company_id
        // scoping"). This method used to build its own raw $wpdb insert
        // directly against 'audit_log' — a second, independently-maintained
        // copy of what JP_Security::audit() already does, missing that
        // method's 'ua' (user-agent) column entirely and, until now, unable
        // to record which company an action belonged to at all. Once
        // team/multi-seat support shipped (see class-jp-team.php), that
        // meant "which of my company's recruiters touched this application"
        // was answerable for team-membership actions but NOT for job
        // create/update/delete/status-change actions logged through this
        // path — an inconsistency in the exact same audit trail. Delegating
        // to the single real writer removes the duplication outright: there
        // is now exactly one place that decides the schema of an audit row.
        if ( class_exists( 'JP_Security' ) ) {
            JP_Security::instance()->audit( $action, $object, $object_id, $detail, $company_id );
            return;
        }
        // Fallback only reachable if JP_Security somehow failed to load.
        $this->insert( 'audit_log', [
            'user_id'    => get_current_user_id(),
            'action'     => $action,
            'object'     => $object,
            'object_id'  => $object_id,
            'detail'     => $detail,
            'company_id' => $company_id ?: null,
            'ip'         => $this->get_client_ip(),
        ] );
    }

    // ── Utility ───────────────────────────────────────────────────────────────

    private function get_client_ip(): string {
        // Root-cause fix: this duplicated (and diverged from) JP_Security's
        // own client_ip() logic, and — like the original there — trusted
        // spoofable forwarded-for headers unconditionally, poisoning IP
        // data recorded here (audit/analytics) with attacker-supplied
        // values. Delegate to the single, trusted-proxy-aware
        // implementation instead of maintaining a second copy.
        return class_exists( 'JP_Security' ) ? JP_Security::client_ip() : ( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ?? '' ) ) ?: '' );
    }
}
