<?php
/**
 * JP_AI — All AI-powered features via OpenAI API.
 *
 * Requires JP_OPENAI_KEY defined in wp-config.php.
 * All responses cached (24h) to minimise API costs.
 * Graceful degradation: if key missing or API fails, returns structured empty response.
 *
 * Endpoints (registered in class-jp-api.php):
 *   POST /jp/v1/ai/resume-score        → score candidate resume 0-100 with breakdown
 *   POST /jp/v1/ai/resume-improve       → rewrite a resume bullet with 3 alternatives
 *   POST /jp/v1/ai/cover-letter         → generate cover letter for job+profile
 *   POST /jp/v1/ai/interview-prep       → 10 Q&A pairs for a specific job
 *   POST /jp/v1/ai/interview-questions  → generate screening questions for a job (recruiter)
 *   POST /jp/v1/ai/career-advice        → career path + skill gap analysis
 *   POST /jp/v1/ai/job-description      → improve a recruiter's job description
 *   POST /jp/v1/ai/salary-negotiate     → negotiation script given offer + market data
 *   POST /jp/v1/ai/skill-demand         → skill market demand + trend forecast
 */
defined( 'ABSPATH' ) || exit;

class JP_AI {

    private static ?JP_AI $instance = null;
    private const MODEL   = 'gpt-4o-mini';     // Cost-effective, fast
    private const TIMEOUT = 30;                 // seconds
    private const CACHE   = 86400;              // 24 hours

    public static function instance(): self {
        if ( null === self::$instance ) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {}

    // ── Check if AI is available ──────────────────────────────────────────────

    public static function available(): bool {
        return defined( 'JP_OPENAI_KEY' ) && ! empty( JP_OPENAI_KEY );
    }

    // ── Resume Score ──────────────────────────────────────────────────────────

    public function resume_score( int $user_id ): array {
        $candidate = JP_DB::instance()->get_candidate( $user_id );
        if ( ! $candidate ) {
            return $this->unavailable_response( 'resume_score', 'No candidate profile found.' );
        }

        $cache_key = "jp_ai_resume_score_{$user_id}";
        $cached    = JP_Cache::get( $cache_key );
        if ( $cached !== null ) return $cached;

        $skills   = json_decode( $candidate->education_json ?? '[]', true ) ?: [];
        $exp_json = json_decode( $candidate->experience_json ?? '[]', true ) ?: [];

        $prompt = "You are an expert recruiter reviewing a professional profile. Score this profile on a scale of 0-100 and provide specific improvement recommendations.\n\n"
            . "Profile:\n"
            . "Headline: " . ( $candidate->headline ?? 'Not set' ) . "\n"
            . "About: " . mb_substr( $candidate->about ?? 'Not set', 0, 400 ) . "\n"
            . "Experience: " . ( $candidate->experience_years ?? 0 ) . " years\n"
            . "Current role: " . ( $candidate->current_title ?? 'Not set' ) . "\n"
            . "Location: " . ( $candidate->location_city ?? 'Not set' ) . "\n"
            . "Portfolio: " . ( $candidate->portfolio_url ? 'Present' : 'Missing' ) . "\n"
            . "LinkedIn: " . ( $candidate->linkedin_url ? 'Present' : 'Missing' ) . "\n"
            . "Education entries: " . count( $skills ) . "\n"
            . "Experience entries: " . count( $exp_json ) . "\n\n"
            . "Respond with a JSON object (no markdown): {\"overall\":85,\"sections\":{\"headline\":80,\"about\":70,\"experience\":90,\"skills\":75,\"education\":60,\"online_presence\":50},\"strengths\":[\"string\",\"string\",\"string\"],\"improvements\":[\"string\",\"string\",\"string\"],\"missing\":[\"string\",\"string\"]}";

        $result = $this->call_openai( $prompt, 400 );

        if ( ! $result ) {
            return $this->unavailable_response( 'resume_score', 'AI service temporarily unavailable.' );
        }

        $parsed = json_decode( $result, true );
        if ( ! $parsed ) {
            // Parse was not clean JSON — try to extract it
            preg_match( '/\{.*\}/s', $result, $matches );
            $parsed = $matches ? json_decode( $matches[0], true ) : null;
        }

        if ( ! $parsed ) {
            return $this->unavailable_response( 'resume_score', 'Could not parse AI response.' );
        }

        $response = [
            'available'    => true,
            'overall'      => (int) ( $parsed['overall'] ?? 0 ),
            'sections'     => $parsed['sections'] ?? [],
            'strengths'    => (array) ( $parsed['strengths'] ?? [] ),
            'improvements' => (array) ( $parsed['improvements'] ?? [] ),
            'missing'      => (array) ( $parsed['missing'] ?? [] ),
        ];

        JP_Cache::set( $cache_key, $response, self::CACHE );
        return $response;
    }

    // ── Resume Bullet Improver ────────────────────────────────────────────────

    public function improve_bullet( string $bullet, string $context = '' ): array {
        if ( ! self::available() ) {
            return $this->unavailable_response( 'improve_bullet', 'OpenAI key not configured.' );
        }

        $cache_key = 'jp_ai_bullet_' . md5( $bullet );
        $cached    = JP_Cache::get( $cache_key );
        if ( $cached !== null ) return $cached;

        $prompt = "You are a professional resume writer. Rewrite the following resume bullet point in 3 different ways to be more impactful, quantified, and ATS-friendly.\n\n"
            . ( $context ? "Context (job role/industry): {$context}\n\n" : '' )
            . "Original bullet: {$bullet}\n\n"
            . "Respond with JSON only: {\"alternatives\":[\"version1\",\"version2\",\"version3\"]}";

        $result = $this->call_openai( $prompt, 200 );

        if ( ! $result ) {
            return $this->unavailable_response( 'improve_bullet' );
        }

        preg_match( '/\{.*\}/s', $result, $m );
        $parsed = $m ? json_decode( $m[0], true ) : null;

        $response = [
            'available'    => true,
            'alternatives' => (array) ( $parsed['alternatives'] ?? [] ),
        ];

        JP_Cache::set( $cache_key, $response, self::CACHE );
        return $response;
    }

    // ── Cover Letter Generator ────────────────────────────────────────────────

    public function cover_letter( int $user_id, int $job_id ): array {
        if ( ! self::available() ) {
            return $this->unavailable_response( 'cover_letter', 'OpenAI key not configured.' );
        }

        $cache_key = "jp_ai_coverletter_{$user_id}_{$job_id}";
        $cached    = JP_Cache::get( $cache_key );
        if ( $cached !== null ) return $cached;

        global $wpdb;
        $candidate = JP_DB::instance()->get_candidate( $user_id );
        $user      = get_userdata( $user_id );
        $job       = $wpdb->get_row( $wpdb->prepare(
            "SELECT j.*, c.name AS company_name FROM {$wpdb->prefix}jp_jobs j
             LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id
             WHERE j.id=%d", $job_id
        ) );

        if ( ! $candidate || ! $job ) {
            return $this->unavailable_response( 'cover_letter', 'Missing profile or job data.' );
        }

        $skills = json_decode( $candidate->education_json ?? '[]', true ) ?: [];

        $prompt = "Write a professional cover letter (3 paragraphs, ~200 words) for this candidate applying to this job.\n\n"
            . "Candidate: " . ( $user->display_name ?? '' ) . "\n"
            . "Headline: " . ( $candidate->headline ?? '' ) . "\n"
            . "Experience: " . ( $candidate->experience_years ?? 0 ) . " years in " . ( $candidate->current_title ?? 'their field' ) . "\n"
            . "Current company: " . ( $candidate->current_company ?? '' ) . "\n\n"
            . "Job: " . $job->title . " at " . ( $job->company_name ?? '' ) . "\n"
            . "Job type: " . $job->job_type . ", " . $job->work_mode . "\n"
            . "Job description summary: " . mb_substr( strip_tags( $job->description ?? '' ), 0, 500 ) . "\n\n"
            . "Write in a professional but warm tone. Address it to 'Dear Hiring Manager'. "
            . "Do NOT use placeholder text like [Company Name]. "
            . "Respond with JSON only: {\"subject\":\"Application for...\",\"body\":\"Dear Hiring Manager,\\n\\n[paragraph1]\\n\\n[paragraph2]\\n\\n[paragraph3]\\n\\nSincerely,\\n" . ( $user->display_name ?? 'Candidate' ) . "\"}";

        $result = $this->call_openai( $prompt, 600 );

        if ( ! $result ) {
            return $this->unavailable_response( 'cover_letter' );
        }

        preg_match( '/\{.*\}/s', $result, $m );
        $parsed = $m ? json_decode( $m[0], true ) : null;

        if ( ! $parsed || empty( $parsed['body'] ) ) {
            return $this->unavailable_response( 'cover_letter', 'Could not generate cover letter.' );
        }

        $response = [
            'available' => true,
            'subject'   => sanitize_text_field( $parsed['subject'] ?? "Application for {$job->title}" ),
            'body'      => wp_kses( $parsed['body'], [] ),  // plain text only
        ];

        JP_Cache::set( $cache_key, $response, self::CACHE );
        return $response;
    }

    // ── Interview Prep (for candidates) ──────────────────────────────────────

    public function interview_prep( int $job_id, int $user_id = 0 ): array {
        if ( ! self::available() ) {
            return $this->unavailable_response( 'interview_prep', 'OpenAI key not configured.' );
        }

        $cache_key = "jp_ai_interviewprep_{$job_id}_{$user_id}";
        $cached    = JP_Cache::get( $cache_key );
        if ( $cached !== null ) return $cached;

        global $wpdb;
        $job = $wpdb->get_row( $wpdb->prepare(
            "SELECT j.*, c.name AS company_name FROM {$wpdb->prefix}jp_jobs j
             LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id
             WHERE j.id=%d", $job_id
        ) );

        if ( ! $job ) return $this->unavailable_response( 'interview_prep', 'Job not found.' );

        $candidate_context = '';
        if ( $user_id ) {
            $c = JP_DB::instance()->get_candidate( $user_id );
            if ( $c ) {
                $candidate_context = "\nCandidate background: " . ( $c->experience_years ?? 0 ) . " years experience, "
                    . "current role: " . ( $c->current_title ?? 'unknown' ) . ".";
            }
        }

        $skills_list = implode( ', ', json_decode( $job->skills_json ?? '[]', true ) ?: [] );

        $prompt = "You are an expert interview coach. Generate 8 likely interview questions with ideal answer guidance for this job.\n\n"
            . "Job: " . $job->title . " at " . ( $job->company_name ?? 'the company' ) . "\n"
            . "Required skills: " . ( $skills_list ?: 'Not specified' ) . "\n"
            . "Job description: " . mb_substr( strip_tags( $job->description ?? '' ), 0, 500 ) . "\n"
            . $candidate_context . "\n\n"
            . "Mix of: 2 technical, 2 behavioral (STAR format), 2 situational, 1 cultural fit, 1 salary/expectations.\n"
            . "Respond with JSON only: {\"questions\":[{\"question\":\"...\",\"type\":\"technical\",\"tip\":\"...\",\"sample_answer\":\"...\"},{...}]}";

        $result = $this->call_openai( $prompt, 1200 );

        if ( ! $result ) return $this->unavailable_response( 'interview_prep' );

        preg_match( '/\{.*\}/s', $result, $m );
        $parsed = $m ? json_decode( $m[0], true ) : null;

        $response = [
            'available' => true,
            'job_title' => $job->title,
            'company'   => $job->company_name ?? '',
            'questions' => (array) ( $parsed['questions'] ?? [] ),
        ];

        JP_Cache::set( $cache_key, $response, self::CACHE );
        return $response;
    }

    // ── Interview Question Generator (for recruiters) ─────────────────────────

    public function interview_questions( int $job_id ): array {
        if ( ! self::available() ) {
            return $this->unavailable_response( 'interview_questions' );
        }

        $cache_key = "jp_ai_iq_{$job_id}";
        $cached    = JP_Cache::get( $cache_key );
        if ( $cached !== null ) return $cached;

        global $wpdb;
        $job = JP_DB::instance()->get_job( $job_id );
        if ( ! $job ) return $this->unavailable_response( 'interview_questions', 'Job not found.' );

        $prompt = "Generate 12 structured interview questions for a recruiter to use when interviewing candidates for this role.\n\n"
            . "Role: " . $job->title . "\n"
            . "Required experience: " . $job->experience_min . "-" . $job->experience_max . " years\n"
            . "Skills: " . implode( ', ', json_decode( $job->skills_json ?? '[]', true ) ?: [] ) . "\n"
            . "Description: " . mb_substr( strip_tags( $job->description ?? '' ), 0, 400 ) . "\n\n"
            . "Include: 4 technical depth questions, 3 problem-solving scenarios, 3 behavioral (STAR), 2 motivation/culture.\n"
            . "Respond with JSON only: {\"questions\":[{\"question\":\"...\",\"category\":\"technical\",\"what_to_listen_for\":\"...\"},{...}]}";

        $result = $this->call_openai( $prompt, 1000 );

        if ( ! $result ) return $this->unavailable_response( 'interview_questions' );

        preg_match( '/\{.*\}/s', $result, $m );
        $parsed = $m ? json_decode( $m[0], true ) : null;

        $response = [
            'available'  => true,
            'job_title'  => $job->title,
            'questions'  => (array) ( $parsed['questions'] ?? [] ),
        ];

        JP_Cache::set( $cache_key, $response, self::CACHE );
        return $response;
    }

    // ── Career Advice ─────────────────────────────────────────────────────────

    public function career_advice( int $user_id, string $target_role ): array {
        if ( ! self::available() ) {
            return $this->unavailable_response( 'career_advice' );
        }

        $cache_key = 'jp_ai_career_' . md5( $user_id . $target_role );
        $cached    = JP_Cache::get( $cache_key );
        if ( $cached !== null ) return $cached;

        $candidate = JP_DB::instance()->get_candidate( $user_id );
        if ( ! $candidate ) return $this->unavailable_response( 'career_advice', 'Profile not found.' );

        $prompt = "You are a career advisor. Analyse this candidate's profile and give specific advice for reaching their target role.\n\n"
            . "Current role: " . ( $candidate->current_title ?? 'Unknown' ) . "\n"
            . "Experience: " . ( $candidate->experience_years ?? 0 ) . " years\n"
            . "Current company: " . ( $candidate->current_company ?? 'Unknown' ) . "\n"
            . "Target role: " . $target_role . "\n\n"
            . "Respond with JSON only: {\"readiness_percent\":70,\"timeline_months\":12,\"skill_gaps\":[\"skill1\",\"skill2\",\"skill3\"],\"action_steps\":[{\"step\":\"...\",\"priority\":\"high\",\"timeframe\":\"1-3 months\"},{...}],\"recommended_paths\":[{\"path\":\"...\",\"description\":\"...\"}],\"market_demand\":\"high\"}";

        $result = $this->call_openai( $prompt, 700 );

        if ( ! $result ) return $this->unavailable_response( 'career_advice' );

        preg_match( '/\{.*\}/s', $result, $m );
        $parsed = $m ? json_decode( $m[0], true ) : null;

        $response = [
            'available'          => true,
            'target_role'        => $target_role,
            'readiness_percent'  => (int) ( $parsed['readiness_percent'] ?? 0 ),
            'timeline_months'    => (int) ( $parsed['timeline_months'] ?? 12 ),
            'skill_gaps'         => (array) ( $parsed['skill_gaps'] ?? [] ),
            'action_steps'       => (array) ( $parsed['action_steps'] ?? [] ),
            'recommended_paths'  => (array) ( $parsed['recommended_paths'] ?? [] ),
            'market_demand'      => $parsed['market_demand'] ?? 'unknown',
        ];

        JP_Cache::set( $cache_key, $response, self::CACHE );
        return $response;
    }

    // ── Job Description Improver (recruiter) ──────────────────────────────────

    public function improve_jd( string $title, string $description ): array {
        if ( ! self::available() ) {
            return $this->unavailable_response( 'improve_jd' );
        }

        $cache_key = 'jp_ai_jd_' . md5( $title . $description );
        $cached    = JP_Cache::get( $cache_key );
        if ( $cached !== null ) return $cached;

        $prompt = "You are a hiring expert. Improve this job description to be clearer, more attractive to candidates, and better for ATS systems.\n\n"
            . "Job Title: {$title}\n"
            . "Original Description:\n" . mb_substr( $description, 0, 800 ) . "\n\n"
            . "Respond with JSON only: {\"improved_description\":\"...\",\"improvements_made\":[\"...\"],\"ats_keywords\":[\"...\"],\"readability_score\":85}";

        $result = $this->call_openai( $prompt, 800 );

        if ( ! $result ) return $this->unavailable_response( 'improve_jd' );

        preg_match( '/\{.*\}/s', $result, $m );
        $parsed = $m ? json_decode( $m[0], true ) : null;

        $response = [
            'available'            => true,
            'improved_description' => $parsed['improved_description'] ?? '',
            'improvements_made'    => (array) ( $parsed['improvements_made'] ?? [] ),
            'ats_keywords'         => (array) ( $parsed['ats_keywords'] ?? [] ),
            'readability_score'    => (int) ( $parsed['readability_score'] ?? 0 ),
        ];

        JP_Cache::set( $cache_key, $response, self::CACHE );
        return $response;
    }

    // ── Salary Negotiation Coach ───────────────────────────────────────────────

    public function salary_negotiate( int $user_id, int $offer_amount, string $role, string $location ): array {
        if ( ! self::available() ) {
            return $this->unavailable_response( 'salary_negotiate' );
        }

        $cache_key = 'jp_ai_salary_' . md5( $user_id . $offer_amount . $role );
        $cached    = JP_Cache::get( $cache_key );
        if ( $cached !== null ) return $cached;

        $candidate = JP_DB::instance()->get_candidate( $user_id );
        $exp = $candidate ? (int) ( $candidate->experience_years ?? 0 ) : 0;

        $prompt = "You are a salary negotiation expert advising an Indian job seeker. Give specific, actionable advice.\n\n"
            . "Role: {$role}\n"
            . "Location: {$location}\n"
            . "Offer received: ₹" . number_format( $offer_amount ) . " per year\n"
            . "Candidate experience: {$exp} years\n\n"
            . "Respond with JSON only: {"
            . "\"market_rate_min\":" . max( $offer_amount * 0.9, 300000 ) . ","
            . "\"market_rate_max\":" . ($offer_amount * 1.3) . ","
            . "\"negotiation_target\":" . ($offer_amount * 1.15) . ","
            . "\"is_fair_offer\":true,"
            . "\"opening_script\":\"...\","
            . "\"counter_arguments\":[\"...\",\"...\",\"...\"],"
            . "\"non_salary_perks\":[\"...\",\"...\"],"
            . "\"walk_away_if\":\"...\"}";

        $result = $this->call_openai( $prompt, 600 );

        if ( ! $result ) return $this->unavailable_response( 'salary_negotiate' );

        preg_match( '/\{.*\}/s', $result, $m );
        $parsed = $m ? json_decode( $m[0], true ) : null;

        $response = [
            'available'          => true,
            'offer_amount'       => $offer_amount,
            'market_rate_min'    => (int) ( $parsed['market_rate_min'] ?? $offer_amount ),
            'market_rate_max'    => (int) ( $parsed['market_rate_max'] ?? $offer_amount ),
            'negotiation_target' => (int) ( $parsed['negotiation_target'] ?? $offer_amount ),
            'is_fair_offer'      => (bool) ( $parsed['is_fair_offer'] ?? true ),
            'opening_script'     => $parsed['opening_script'] ?? '',
            'counter_arguments'  => (array) ( $parsed['counter_arguments'] ?? [] ),
            'non_salary_perks'   => (array) ( $parsed['non_salary_perks'] ?? [] ),
            'walk_away_if'       => $parsed['walk_away_if'] ?? '',
        ];

        JP_Cache::set( $cache_key, $response, self::CACHE );
        return $response;
    }

    // ── Skill Demand Forecast ──────────────────────────────────────────────────

    public function skill_demand( string $skill ): array {
        if ( ! self::available() ) {
            return $this->unavailable_response( 'skill_demand' );
        }

        $cache_key = 'jp_ai_skilldemand_' . md5( $skill );
        $cached    = JP_Cache::get( $cache_key );
        if ( $cached !== null ) return $cached;

        // Get actual DB count for grounding
        global $wpdb;
        $db_count = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->prefix}jp_jobs WHERE skills_json LIKE %s AND status='active'",
            '%' . $wpdb->esc_like( $skill ) . '%'
        ) );

        $prompt = "You are a tech industry analyst. Evaluate the current and future market demand for this skill in India's job market.\n\n"
            . "Skill: {$skill}\n"
            . "Current active job postings mentioning this skill: {$db_count}\n\n"
            . "Respond with JSON only: {\"demand_level\":\"high\",\"trend\":\"growing\",\"description\":\"...\",\"avg_salary_premium_percent\":20,\"top_industries\":[\"...\",\"...\"],\"complementary_skills\":[\"...\",\"...\",\"...\"],\"future_outlook\":\"...\",\"learning_resources\":[{\"name\":\"...\",\"url\":\"...\",\"type\":\"course\"}]}";

        $result = $this->call_openai( $prompt, 500 );

        if ( ! $result ) return $this->unavailable_response( 'skill_demand' );

        preg_match( '/\{.*\}/s', $result, $m );
        $parsed = $m ? json_decode( $m[0], true ) : null;

        $response = [
            'available'               => true,
            'skill'                   => $skill,
            'active_job_count'        => $db_count,
            'demand_level'            => $parsed['demand_level'] ?? 'unknown',
            'trend'                   => $parsed['trend'] ?? 'stable',
            'description'             => $parsed['description'] ?? '',
            'avg_salary_premium_pct'  => (int) ( $parsed['avg_salary_premium_percent'] ?? 0 ),
            'top_industries'          => (array) ( $parsed['top_industries'] ?? [] ),
            'complementary_skills'    => (array) ( $parsed['complementary_skills'] ?? [] ),
            'future_outlook'          => $parsed['future_outlook'] ?? '',
            'learning_resources'      => (array) ( $parsed['learning_resources'] ?? [] ),
        ];

        JP_Cache::set( $cache_key, $response, self::CACHE );
        return $response;
    }

    // ── Private: OpenAI API call ──────────────────────────────────────────────

    private function call_openai( string $prompt, int $max_tokens = 500 ): ?string {
        if ( ! self::available() ) return null;

        $response = wp_remote_post( 'https://api.openai.com/v1/chat/completions', [
            'timeout' => self::TIMEOUT,
            'headers' => [
                'Authorization' => 'Bearer ' . JP_OPENAI_KEY,
                'Content-Type'  => 'application/json',
            ],
            'body' => wp_json_encode( [
                'model'       => self::MODEL,
                'messages'    => [ [ 'role' => 'user', 'content' => $prompt ] ],
                'max_tokens'  => $max_tokens,
                'temperature' => 0.7,
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            return null;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        if ( $code !== 200 ) {
            return null;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        return $body['choices'][0]['message']['content'] ?? null;
    }

    // ── Private: unavailable response stub ───────────────────────────────────

    private function unavailable_response( string $feature, string $reason = '' ): array {
        return [
            'available' => false,
            'feature'   => $feature,
            'reason'    => $reason ?: ( self::available()
                ? 'AI service temporarily unavailable.'
                : 'AI features require an OpenAI API key. Add JP_OPENAI_KEY to wp-config.php.' ),
        ];
    }
}
