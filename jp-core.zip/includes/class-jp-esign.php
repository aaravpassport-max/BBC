<?php
/**
 * Class JP_ESign — legally-binding e-signature integration (DocuSign),
 * closing the pending scope exclusion documented since do_generate_offer()'s
 * docblock in class-jp-applications.php: "this product has no cryptographic
 * PKI signing infrastructure... a real e-signature vendor integration is a
 * further backlog item." DocuSign is the concrete default because it is the
 * single most widely held e-signature account among businesses already using
 * a job portal — an admin who wants a different vendor swaps
 * jp_esign_provider ('none'|'docusign') and the corresponding credential
 * block without touching any caller of this class.
 *
 * DESIGN: entirely additive and fails soft. When not configured
 * (jp_esign_provider !== 'docusign', or any required credential missing),
 * is_configured() returns false and JP_Applications::do_generate_offer()
 * continues to use the existing in-app "I Agree" click-to-accept flow
 * unchanged — nothing about the pre-existing offer workflow regresses.
 * When configured, generate_offer_pdf()'s already-produced PDF is also sent
 * to DocuSign as a real signature request; the candidate signs there and
 * DocuSign Connect posts back to the /esign/webhook route below, which
 * records completion and (on 'completed') auto-advances the application the
 * same way a candidate's in-app "Accept" click already does
 * (do_offer_response-equivalent), so every downstream consumer of
 * offer_status/stage keeps working with no special-casing.
 *
 * AUTH: DocuSign's JWT Grant flow (server-to-server, no per-request user
 * interaction) — built with raw openssl_sign() rather than a Composer SDK,
 * consistent with this codebase's existing no-heavy-dependency style for
 * every other third-party integration (Razorpay/Stripe/Twilio/MSG91/OpenAI
 * above all call the vendor's plain REST API directly via wp_remote_*()).
 * Requires a DocuSign "Individual" or "Organization" integration key with a
 * generated RSA keypair and the admin's consent granted once via DocuSign's
 * OAuth consent URL (documented in the admin settings UI) — standard
 * DocuSign JWT setup, not something this class can automate away.
 */
defined( 'ABSPATH' ) || exit;

class JP_ESign {

	private static ?JP_ESign $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		// No hooks of its own — invoked directly by
		// JP_Applications::do_generate_offer() and by class-jp-api.php's
		// /esign/webhook route callback. Instantiated from jp_init() purely
		// so autoloading + ::instance() singleton semantics match every
		// other JP_* class in this codebase, even though this one has no
		// constructor-time side effects to register.
	}

	// ── Configuration ────────────────────────────────────────────────────────

	public function is_configured(): bool {
		if ( 'docusign' !== get_option( 'jp_esign_provider', 'none' ) ) return false;
		foreach ( [ 'jp_docusign_account_id', 'jp_docusign_integration_key', 'jp_docusign_user_id', 'jp_docusign_private_key' ] as $k ) {
			if ( '' === trim( (string) get_option( $k, '' ) ) ) return false;
		}
		return true;
	}

	private function base_uri(): string {
		// DocuSign's demo/sandbox environment by default — an admin flips
		// this to https://na1.docusign.net (or their region's production
		// host, returned by DocuSign's own /oauth/userinfo response after
		// go-live) once they've tested against demo.
		return trim( (string) get_option( 'jp_docusign_base_uri', 'https://demo.docusign.net' ), '/' );
	}

	private function auth_host(): string {
		return str_contains( $this->base_uri(), 'demo.docusign.net' ) ? 'account-d.docusign.com' : 'account.docusign.com';
	}

	// ── JWT Grant auth ───────────────────────────────────────────────────────

	/**
	 * Returns a cached (or freshly obtained) OAuth access token, or a
	 * WP_Error describing why authentication failed (bad key, consent not
	 * yet granted, clock skew, etc. — surfaced as-is to the caller so an
	 * admin debugging a failed offer-send sees DocuSign's own error, not a
	 * generic "something went wrong").
	 */
	private function get_access_token() {
		$cached = get_transient( 'jp_docusign_access_token' );
		if ( is_string( $cached ) && $cached !== '' ) return $cached;

		$private_key = (string) get_option( 'jp_docusign_private_key', '' );
		$jwt = $this->build_jwt(
			(string) get_option( 'jp_docusign_integration_key', '' ),
			(string) get_option( 'jp_docusign_user_id', '' ),
			$this->auth_host(),
			$private_key
		);
		if ( is_wp_error( $jwt ) ) return $jwt;

		$response = wp_remote_post( "https://{$this->auth_host()}/oauth/token", [
			'timeout' => 15,
			'headers' => [ 'Content-Type' => 'application/x-www-form-urlencoded' ],
			'body'    => [
				'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
				'assertion'  => $jwt,
			],
		] );
		if ( is_wp_error( $response ) ) return $response;

		$code = wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $code !== 200 || empty( $data['access_token'] ) ) {
			$msg = $data['error_description'] ?? $data['error'] ?? "DocuSign auth failed (HTTP {$code}).";
			// DocuSign's JWT consent error is a specific, actionable one —
			// surfaced verbatim so the admin settings screen can link
			// straight to the one-time consent URL rather than a dead end.
			return new \WP_Error( 'jp_esign_auth_failed', $msg );
		}

		$ttl = max( 60, (int) ( $data['expires_in'] ?? 3600 ) - 120 ); // refresh 2 min early
		set_transient( 'jp_docusign_access_token', $data['access_token'], $ttl );
		return $data['access_token'];
	}

	/** Builds and RS256-signs the JWT assertion by hand (no Composer SDK — see class docblock). */
	private function build_jwt( string $integration_key, string $user_id, string $auth_host, string $private_key_pem ) {
		if ( '' === $integration_key || '' === $user_id || '' === $private_key_pem ) {
			return new \WP_Error( 'jp_esign_not_configured', 'DocuSign integration key, user ID, and private key must all be set.' );
		}
		$now = time();
		$header  = [ 'alg' => 'RS256', 'typ' => 'JWT' ];
		$payload = [
			'iss'   => $integration_key,
			'sub'   => $user_id,
			'aud'   => $auth_host,
			'iat'   => $now,
			'exp'   => $now + 3600,
			'scope' => 'signature impersonation',
		];
		$b64 = fn( array $d ) => rtrim( strtr( base64_encode( wp_json_encode( $d ) ), '+/', '-_' ), '=' );
		$unsigned = $b64( $header ) . '.' . $b64( $payload );

		// Normalize \n-escaped keys pasted into a single-line settings field
		// (the common way an RSA PEM ends up in an HTML text input/textarea).
		$pem = str_contains( $private_key_pem, '\\n' ) ? str_replace( '\\n', "\n", $private_key_pem ) : $private_key_pem;
		$key = openssl_pkey_get_private( $pem );
		if ( ! $key ) {
			return new \WP_Error( 'jp_esign_bad_key', 'The configured DocuSign private key could not be parsed. Check it is a full PEM-format RSA private key.' );
		}
		$signature = '';
		$ok = openssl_sign( $unsigned, $signature, $key, OPENSSL_ALGO_SHA256 );
		if ( ! $ok ) {
			return new \WP_Error( 'jp_esign_sign_failed', 'Failed to sign the DocuSign auth request with the configured private key.' );
		}
		return $unsigned . '.' . rtrim( strtr( base64_encode( $signature ), '+/', '-_' ), '=' );
	}

	// ── Envelope send ────────────────────────────────────────────────────────

	/**
	 * Sends the already-generated offer PDF to DocuSign as a real signature
	 * request. Returns ['envelope_id' => string] on success, WP_Error on any
	 * failure — the caller (do_generate_offer()) treats a WP_Error here as
	 * non-fatal and falls back to the in-app accept flow, so a DocuSign
	 * outage or misconfiguration never blocks offer generation itself.
	 */
	public function send_envelope( object $app, object $job, \WP_User $candidate, ?object $company, string $pdf_path ) {
		$token = $this->get_access_token();
		if ( is_wp_error( $token ) ) return $token;
		if ( ! is_readable( $pdf_path ) ) {
			return new \WP_Error( 'jp_esign_pdf_missing', 'The generated offer PDF could not be read for e-signature.' );
		}

		$account_id  = (string) get_option( 'jp_docusign_account_id', '' );
		$doc_base64  = base64_encode( (string) file_get_contents( $pdf_path ) );
		$company_name = $company->name ?? jp_site_name();

		$envelope = [
			'emailSubject' => "Offer letter — {$job->title} at {$company_name}",
			'documents'    => [ [
				'documentBase64' => $doc_base64,
				'name'           => 'Offer Letter.pdf',
				'fileExtension'  => 'pdf',
				'documentId'     => '1',
			] ],
			'recipients'   => [ 'signers' => [ [
				'email'        => $candidate->user_email,
				'name'         => $candidate->display_name,
				'recipientId'  => '1',
				'routingOrder' => '1',
				// A generic anchor string placed at the end of
				// offer_letter_body_text()'s output (see
				// class-jp-applications.php) rather than a fixed x/y
				// coordinate, so the signature tab lands correctly
				// regardless of how long the offer body renders on the
				// page — anchor-based placement is DocuSign's own
				// recommended approach for exactly this reason.
				'tabs' => [ 'signHereTabs' => [ [
					'anchorString'  => '/sig/',
					'anchorUnits'   => 'pixels',
					'anchorXOffset' => '0',
					'anchorYOffset' => '-10',
				] ] ],
			] ] ],
			'status' => 'sent',
		];

		$response = wp_remote_post( "{$this->base_uri()}/restapi/v2.1/accounts/{$account_id}/envelopes", [
			'timeout' => 20,
			'headers' => [ 'Authorization' => "Bearer {$token}", 'Content-Type' => 'application/json' ],
			'body'    => wp_json_encode( $envelope ),
		] );
		if ( is_wp_error( $response ) ) return $response;

		$code = wp_remote_retrieve_response_code( $response );
		$data = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $code < 200 || $code >= 300 || empty( $data['envelopeId'] ) ) {
			$msg = $data['message'] ?? "DocuSign envelope creation failed (HTTP {$code}).";
			return new \WP_Error( 'jp_esign_envelope_failed', $msg );
		}

		global $wpdb;
		$insert_ok = false !== $wpdb->insert( $wpdb->prefix . 'jp_esign_envelopes', [
			'application_id' => (int) $app->id,
			'provider'       => 'docusign',
			'envelope_id'    => sanitize_text_field( $data['envelopeId'] ),
			'status'         => 'sent',
			'created_at'     => current_time( 'mysql' ),
			'updated_at'     => current_time( 'mysql' ),
		] );
		if ( ! $insert_ok && class_exists( 'JP_ErrorLog' ) ) {
			// The envelope really was created on DocuSign's side — losing
			// the local row only means the webhook below won't find a
			// matching envelope_id to update, not that signing itself
			// failed — logged so an admin can reconcile manually rather
			// than this being a silent data-loss point.
			JP_ErrorLog::instance()->log_exception(
				new \Exception( 'jp_esign_envelopes insert failed after successful DocuSign send: ' . $wpdb->last_error ),
				'JP_ESign::send_envelope application_id=' . $app->id
			);
		}

		return [ 'envelope_id' => $data['envelopeId'] ];
	}

	// ── Webhook (DocuSign Connect) ───────────────────────────────────────────

	/**
	 * Receives DocuSign Connect's status-change callback. Verified by a
	 * shared-secret query-string token (jp_esign_webhook_secret, admin-set —
	 * configured as the Connect subscription's URL suffix) rather than
	 * DocuSign's HMAC signature scheme, matching this codebase's existing
	 * webhook pattern (class-jp-webhooks.php signs OUTBOUND deliveries with
	 * X-JP-Signature; no existing INBOUND webhook receiver in this codebase
	 * does vendor-signature verification — Razorpay's does via
	 * hash_hmac comparison, so if the admin wants that stronger guarantee
	 * DocuSign Connect also supports HMAC, verified the same
	 * hash_equals() way — left as a documented follow-up, not silently
	 * skipped: shared-secret alone is what's implemented today).
	 */
	public function handle_webhook( array $payload ) {
		global $wpdb;
		$envelope_id = sanitize_text_field( $payload['envelopeId'] ?? $payload['data']['envelopeId'] ?? '' );
		$status      = sanitize_key( $payload['status'] ?? $payload['event'] ?? '' );
		// DocuSign Connect's classic XML->JSON bridge uses 'completed'/
		// 'declined'/'voided' directly; the newer Connect JSON format wraps
		// the same values under event names like 'envelope-completed' —
		// normalized to the same three outcomes this class stores.
		if ( str_contains( $status, 'complet' ) ) $status = 'completed';
		elseif ( str_contains( $status, 'declin' ) ) $status = 'declined';
		elseif ( str_contains( $status, 'void' ) )   $status = 'voided';

		if ( '' === $envelope_id || ! in_array( $status, [ 'completed', 'declined', 'voided', 'sent', 'delivered' ], true ) ) {
			return new \WP_Error( 'jp_esign_webhook_invalid', 'Payload missing a recognizable envelopeId/status.' );
		}

		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_esign_envelopes WHERE envelope_id=%s", $envelope_id
		) );
		if ( ! $row ) return new \WP_Error( 'jp_esign_webhook_unknown_envelope', 'No matching envelope on file.' );

		$updated = $wpdb->update(
			$wpdb->prefix . 'jp_esign_envelopes',
			[ 'status' => $status, 'updated_at' => current_time( 'mysql' ) ],
			[ 'id' => (int) $row->id ]
		);
		if ( false === $updated ) {
			return new \WP_Error( 'jp_esign_webhook_save_failed', 'Could not persist the envelope status update.' );
		}

		// A completed signature is the legally-binding equivalent of the
		// candidate's in-app "Accept" click — reuse do_offer_response()'s
		// exact write (offer_status/stage/hired) rather than duplicating
		// that logic, so this path and the click-to-accept path can never
		// drift out of sync on what "accepted" means downstream.
		if ( 'completed' === $status && class_exists( 'JP_Applications' ) ) {
			$app = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}jp_applications WHERE id=%d", (int) $row->application_id
			) );
			if ( $app && 'sent' === $app->offer_status ) {
				JP_Applications::instance()->do_offer_response( (int) $app->id, 'accepted', (int) $app->candidate_id );
			}
		} elseif ( 'declined' === $status && class_exists( 'JP_Applications' ) ) {
			$app = $wpdb->get_row( $wpdb->prepare(
				"SELECT * FROM {$wpdb->prefix}jp_applications WHERE id=%d", (int) $row->application_id
			) );
			if ( $app && 'sent' === $app->offer_status ) {
				JP_Applications::instance()->do_offer_response( (int) $app->id, 'declined', (int) $app->candidate_id );
			}
		}

		return [ 'message' => 'Webhook processed.', 'status' => $status ];
	}

	/** Read model for the SPA — current e-signature status for one application, or null if no envelope exists (falls back to the in-app accept UI). */
	public function get_envelope_for_application( int $application_id ): ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare(
			"SELECT envelope_id, provider, status, created_at, updated_at FROM {$wpdb->prefix}jp_esign_envelopes WHERE application_id=%d ORDER BY id DESC LIMIT 1",
			$application_id
		), ARRAY_A );
		return $row ?: null;
	}
}
