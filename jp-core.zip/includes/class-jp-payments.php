<?php
/**
 * Class JP_Payments — Razorpay direct API integration (no plugin).
 * Order creation → payment verification → plan activation → invoice PDF.
 * Webhook handler for async payment events.
 */
defined( 'ABSPATH' ) || exit;

class JP_Payments {

	private static ?JP_Payments $instance = null;

	const RAZORPAY_API = 'https://api.razorpay.com/v1/';

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	const STRIPE_API = 'https://api.stripe.com/v1/';

	private function __construct() {
		add_action( 'wp_ajax_jp_create_order',          [ $this, 'ajax_create_order' ] );
		add_action( 'wp_ajax_jp_verify_payment',        [ $this, 'ajax_verify_payment' ] );
		add_action( 'wp_ajax_jp_verify_stripe_session', [ $this, 'ajax_verify_stripe_session' ] );
		add_action( 'init',                             [ $this, 'handle_webhook' ] );
		add_action( 'init',                             [ $this, 'handle_stripe_webhook' ] );
	}

	// ── Create Razorpay order ─────────────────────────────────────────────────

	/**
	 * Root-cause fix (batch 10). Order creation and payment verification
	 * have ALWAYS been legacy wp_ajax_* handlers only — no REST route, no
	 * SPA call, anywhere, ever (confirmed by a repo-wide grep for
	 * create_order/verify_payment/razorpay_order_id/checkout across all of
	 * app/src, which found nothing). This is far more severe than any
	 * individual bug batches 8-9 fixed in this same file: those fixed
	 * *what happens once a payment completes*, but there has never been
	 * any way for a paying customer to actually START a payment through
	 * the live app — PricingPage.tsx's "Get started"/"Manage subscription"
	 * buttons just navigate to /register or /recruiter/billing, and
	 * RecruiterBillingPage.tsx is read-only (subscription status + past
	 * invoices, no purchase control at all). The entire monetization path
	 * has been unreachable from the SPA regardless of how correct the
	 * backend is. Extracted the real logic into do_create_order()/
	 * do_verify_payment() (array|WP_Error, no echo/exit) — the same
	 * shared-logic pattern established for class-jp-team.php and
	 * class-jp-privacy.php — so both the legacy AJAX path (kept working,
	 * unchanged behavior) and new REST routes (class-jp-api.php's
	 * payments_create_order()/payments_verify()) share one implementation.
	 * See PricingPage.tsx/RecruiterBillingPage.tsx for the new SPA side of
	 * this fix — an actual "Upgrade" control wired to Razorpay's
	 * checkout.js, which now has something real to call.
	 */
	public function do_create_order( int $user_id, int $plan_id, string $billing ) {
		$billing = in_array($billing,['monthly','yearly'],true) ? $billing : 'monthly';

		global $wpdb;
		$plan = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_plans WHERE id=%d AND is_active=1",$plan_id));
		if (!$plan) return new WP_Error('invalid_plan','Invalid plan.');

		$amount_inr = $billing === 'yearly' ? (int)$plan->price_yearly : (int)$plan->price_monthly;
		if ($amount_inr <= 0) return new WP_Error('free_plan','This plan is free — no payment required.');

		// Batch 30 — multi-currency, phase 1. A plan's price is now
		// denominated in its own currency (jp_plans.currency), not
		// necessarily INR — $amount_inr is kept as the variable name below
		// only because every existing call site already reads it that way;
		// it really means "amount in the plan's currency's major unit."
		$currency = in_array( strtoupper( $plan->currency ?? 'INR' ), [ 'INR', 'USD' ], true )
			? strtoupper( $plan->currency ) : 'INR';

		$gateway = jp_active_payment_gateway();
		// Razorpay (as configured for this deployment) is INR-only — see
		// do_create_razorpay_order()'s docblock. Silently charging a
		// USD-priced plan's numeric amount as if it were INR would be a
		// ~83x under-charge, not a cosmetic bug, so this is refused
		// outright rather than "handled" by ignoring the plan's currency.
		if ( 'razorpay' === $gateway && 'INR' !== $currency ) {
			return new WP_Error( 'currency_unsupported', 'This plan is priced in ' . $currency . ', which the configured payment gateway (Razorpay) cannot charge. Switch the site to the Stripe gateway to sell this plan, or price it in INR.' );
		}

		// Root-cause fix (batch 12 — Stripe gateway abstraction). Plan
		// lookup/amount resolution is identical for either processor; only
		// what happens with that amount (which external API is called, and
		// which columns get persisted) differs, so that part is delegated
		// to a per-gateway method rather than duplicating this validation.
		return 'stripe' === $gateway
			? $this->do_create_stripe_session( $user_id, $plan, $billing, $amount_inr, $currency )
			: $this->do_create_razorpay_order( $user_id, $plan, $billing, $amount_inr, $currency );
	}

	/**
	 * Batch 30: Razorpay is kept deliberately INR-only here — a live
	 * Razorpay merchant account is provisioned for a specific settlement
	 * currency (INR for this deployment) and cannot accept arbitrary
	 * currencies the way Stripe can, so this stays hardcoded rather than
	 * pretending it's configurable; do_create_order() already refuses to
	 * route a non-INR plan here, so $currency arriving as anything but
	 * 'INR' would indicate that guard was bypassed — kept as a parameter
	 * (rather than re-hardcoding 'INR' inline) purely so jp_payments'
	 * currency column is sourced from real data, not a second hardcoded
	 * literal that could drift from the first.
	 */
	private function do_create_razorpay_order( int $user_id, object $plan, string $billing, int $amount_inr, string $currency = 'INR' ) {
		global $wpdb;
		$plan_id      = (int) $plan->id;
		$amount_paise = $amount_inr * 100; // Razorpay uses paise

		// Root-cause fix (gap analysis P1 #154: "No idempotency protection on
		// payment-order creation ... a network retry or double-click can
		// create duplicate Razorpay orders/DB rows"). Nothing previously
		// stopped this handler from firing twice in a row for the same
		// user+plan+billing (a slow network response tempting a second click
		// on the pay button, or a client-side retry) — each call created a
		// brand-new Razorpay order and a brand-new 'created' row, with no
		// link between them. If the user then completes payment against
		// either order, the other is silently left behind as an orphaned
		// 'created' row forever (see the reconciliation job added below for
		// the other half of this fix). Instead of creating a new order when
		// an un-expired one already exists for this exact user+plan+billing,
		// reuse it — Razorpay orders don't expire, so it's still payable.
		$existing_order = $wpdb->get_row($wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_payments
			 WHERE user_id=%d AND plan_id=%d AND status='created'
			   AND description=%s AND created_at > %s
			 ORDER BY id DESC LIMIT 1",
			$user_id, $plan_id, $plan->name.' Plan ('.ucfirst($billing).')',
			gmdate('Y-m-d H:i:s', time() - 30 * MINUTE_IN_SECONDS)
		));
		if ($existing_order) {
			return [
				'gateway'  => 'razorpay',
				'order_id' => $existing_order->razorpay_order,
				'amount'   => $amount_paise,
				'key_id'   => jp_razorpay_key_id(),
			];
		}

		$response = $this->razorpay_request('POST','orders',[
			'amount'          => $amount_paise,
			'currency'        => $currency,
			'receipt'         => 'jp_'.$user_id.'_'.time(),
			'notes'           => [
				'user_id'  => $user_id,
				'plan_id'  => $plan_id,
				'billing'  => $billing,
				'plan_name'=> $plan->name,
			],
		]);

		if (is_wp_error($response)) {
			return new WP_Error('gateway_error','Payment gateway error: '.$response->get_error_message());
		}

		// Resolve company_id for this user (schema requires NOT NULL)
		$company    = JP_DB::instance()->get_company_by_user( $user_id );
		$company_id = $company ? (int) $company->id : 0;

		// Root-cause fix (batch 8 — see class-jp-activator.php's jp_payments
		// docblock for the full trace). billing_cycle is now a real column
		// (was silently absent from the schema before this batch, and this
		// INSERT never even attempted to store it — the comment that used
		// to sit here, "billing_cycle not in schema — stored in description",
		// was the record of a workaround for a bug that should have been
		// fixed instead: ajax_verify_payment() actually reads
		// $payment->billing_cycle back out to decide monthly-vs-yearly
		// subscription duration, and with nowhere to store it that read was
		// always null, silently defaulting every yearly purchase to a
		// 30-day monthly activation despite being billed the yearly price).
		$inserted = $wpdb->insert($wpdb->prefix.'jp_payments',[
			'user_id'        => $user_id,
			'company_id'     => $company_id,
			'plan_id'        => $plan_id,
			'amount'         => $amount_inr,
			'currency'       => $currency,
			'razorpay_order' => $response['id'],
			'gateway'        => 'razorpay',
			'billing_cycle'  => $billing,
			'status'         => 'created',
			'description'    => $plan->name.' Plan ('.ucfirst($billing).')',
			'created_at'     => current_time('mysql'),
		],['%d','%d','%d','%d','%s','%s','%s','%s','%s','%s','%s']);

		if ( false === $inserted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception(
					new \Exception( 'jp_payments insert failed: ' . $wpdb->last_error ),
					'JP_Payments::do_create_razorpay_order user_id=' . $user_id . ' plan_id=' . $plan_id
				);
			}
			// A Razorpay order now exists that this install has no local
			// record of — refuse to hand it to the customer (they'd have
			// no way to complete verify_payment() against a row that
			// doesn't exist) rather than silently proceeding, same "don't
			// report success on an unconfirmed write" principle as batches
			// 8-9's fixes elsewhere in this file.
			return new WP_Error('db_error','Could not create your order. Please try again or contact support.');
		}

		return [
			'gateway'  => 'razorpay',
			'order_id' => $response['id'],
			'amount'   => $amount_paise,
			'key_id'   => jp_razorpay_key_id(),
		];
	}

	/**
	 * Root-cause fix (batch 12 — Stripe gateway abstraction). Stripe
	 * Checkout is a hosted, redirect-based flow (not a JS modal like
	 * Razorpay's checkout.js) — success_url/cancel_url are where Stripe
	 * sends the browser back to, with {CHECKOUT_SESSION_ID} substituted by
	 * Stripe itself into success_url so the SPA can call
	 * do_verify_stripe_session() with it on return. Uses Stripe's own
	 * Idempotency-Key request header (see stripe_request()) instead of the
	 * Razorpay path's manual "look up an existing un-expired row" reuse
	 * check above — Stripe natively dedupes identical requests replayed
	 * with the same key within 24h, which is a more direct fit for
	 * preventing a double-click/retry from creating two sessions than
	 * reimplementing the same lookup a second time for a second gateway.
	 */
	private function do_create_stripe_session( int $user_id, object $plan, string $billing, int $amount_inr, string $currency = 'INR' ) {
		global $wpdb;
		$plan_id        = (int) $plan->id;
		$amount_minor   = $amount_inr * 100; // Stripe uses the smallest currency unit (paise for INR, cents for USD)
		$description    = $plan->name . ' Plan (' . ucfirst( $billing ) . ')';
		$idempotency_key = 'jp_order_' . $user_id . '_' . $plan_id . '_' . $billing . '_' . (int) floor( time() / ( 30 * MINUTE_IN_SECONDS ) );

		$response = $this->stripe_request( 'POST', 'checkout/sessions', [
			'mode'                          => 'payment',
			'success_url'                   => home_url( '/recruiter/billing' ) . '?stripe_session_id={CHECKOUT_SESSION_ID}',
			'cancel_url'                    => home_url( '/pricing' ),
			'client_reference_id'           => (string) $user_id,
			'line_items'                    => [ [
				'quantity'   => 1,
				'price_data' => [
					// Batch 30: Stripe requires a lowercase ISO currency code.
					'currency'    => strtolower( $currency ),
					'unit_amount' => $amount_minor,
					'product_data'=> [ 'name' => $description ],
				],
			] ],
			'metadata' => [
				'user_id' => $user_id,
				'plan_id' => $plan_id,
				'billing' => $billing,
			],
		], $idempotency_key );

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'gateway_error', 'Payment gateway error: ' . $response->get_error_message() );
		}

		$company    = JP_DB::instance()->get_company_by_user( $user_id );
		$company_id = $company ? (int) $company->id : 0;

		$inserted = $wpdb->insert( $wpdb->prefix . 'jp_payments', [
			'user_id'           => $user_id,
			'company_id'        => $company_id,
			'plan_id'           => $plan_id,
			'amount'            => $amount_inr,
			'currency'          => $currency,
			'gateway'           => 'stripe',
			'stripe_session_id' => $response['id'],
			'billing_cycle'     => $billing,
			'status'            => 'created',
			'description'       => $description,
			'created_at'        => current_time( 'mysql' ),
		], [ '%d','%d','%d','%d','%s','%s','%s','%s','%s','%s','%s' ] );

		if ( false === $inserted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception(
					new \Exception( 'jp_payments insert failed: ' . $wpdb->last_error ),
					'JP_Payments::do_create_stripe_session user_id=' . $user_id . ' plan_id=' . $plan_id
				);
			}
			// Same "don't hand back a gateway reference this install can't
			// locally confirm" guard as do_create_razorpay_order() — a
			// Stripe Checkout Session now exists that has no local row to
			// verify against.
			return new WP_Error( 'db_error', 'Could not create your order. Please try again or contact support.' );
		}

		return [
			'gateway'      => 'stripe',
			'checkout_url' => $response['url'],
			'session_id'   => $response['id'],
		];
	}

	public function ajax_create_order(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');
		$plan_id = absint($_POST['plan_id']??0);
		$billing = sanitize_text_field($_POST['billing']??'monthly');
		$result  = $this->do_create_order(get_current_user_id(),$plan_id,$billing);
		if (is_wp_error($result)) jp_json_response(false,$result->get_error_message());
		jp_json_response(true,$result);
	}

	// ── Verify payment signature ───────────────────────────────────────────────

	public function do_verify_payment( int $user_id, string $order_id, string $payment_id, string $signature ) {
		if (!$order_id||!$payment_id||!$signature) return new WP_Error('missing_params','Missing payment parameters.');

		// Verify signature: HMAC-SHA256(order_id|payment_id, key_secret)
		$secret       = jp_razorpay_key_secret();
		$expected_sig = hash_hmac('sha256', $order_id.'|'.$payment_id, $secret);

		if (!hash_equals($expected_sig,$signature)) {
			return new WP_Error('signature_mismatch','Payment verification failed. Possible fraud attempt.');
		}

		global $wpdb;
		$payment = $wpdb->get_row($wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_payments WHERE razorpay_order=%s AND user_id=%d",
			$order_id, $user_id
		));
		if (!$payment) return new WP_Error('not_found','Payment record not found.');
		if ($payment->status === 'paid') return ['message'=>'Payment already processed.'];

		// Root-cause fix (batch 8 — see class-jp-activator.php's jp_payments
		// docblock). This update's return value was never checked before —
		// a "ghost success" (Part 3/2.6-D of this audit's own checklist):
		// with razorpay_signature and paid_at previously missing from the
		// schema, this UPDATE has always failed outright (MySQL rejects an
		// UPDATE naming an unknown column), status never actually reached
		// 'paid' in the DB, and this code proceeded to activate the
		// subscription and tell the customer "Payment successful!" anyway,
		// because nothing downstream depended on this write having worked.
		// Now that the columns are real, this checks $wpdb->update()'s
		// return value (false on failure — not merely "0 rows changed",
		// which is a legitimate distinct case handled separately below) and
		// refuses to report success or activate anything against a payment
		// record this code can't actually confirm was marked paid.
		$updated = $wpdb->update($wpdb->prefix.'jp_payments',[
			'razorpay_pay_id'     => $payment_id,
			'razorpay_signature'  => $signature,
			'status'              => 'paid',
			'paid_at'             => current_time('mysql'),
		],['id'=>$payment->id],['%s','%s','%s','%s'],['%d']);

		if ( false === $updated ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception(
					new \Exception( 'jp_payments update failed: ' . $wpdb->last_error ),
					'JP_Payments::do_verify_payment payment_id=' . $payment->id
				);
			}
			return new WP_Error('record_failed','Payment was verified but could not be recorded. Please contact support with your payment ID: '.$payment_id);
		}

		// Activate subscription — billing_cycle now genuinely persisted by
		// ajax_create_order()'s INSERT (see that method's docblock), so
		// yearly purchases correctly activate a yearly subscription instead
		// of silently defaulting to monthly.
		// Root-cause fix (batch 9): activate() can now genuinely fail
		// (see class-jp-subscriptions.php's own docblock) where it
		// previously always silently returned true regardless of whether
		// anything was actually written. The payment itself is real and
		// already recorded above, so this deliberately still tells the
		// customer their payment succeeded rather than turning a
		// provisioning failure into a false "your payment failed" — but
		// logs it so an admin can see and manually resolve a customer who
		// paid but doesn't yet have their plan, instead of that staying
		// invisible the way the underlying bug was before this batch.
		if ( ! JP_Subscriptions::instance()->activate($payment->user_id,(int)$payment->plan_id,$payment->billing_cycle ?? 'monthly') && class_exists('JP_ErrorLog') ) {
			JP_ErrorLog::instance()->log_exception(new \Exception('Subscription activation failed after successful payment'),'JP_Payments::do_verify_payment payment_id='.$payment->id.' user_id='.$payment->user_id);
		}

		// Generate invoice
		$invoice_url = $this->generate_invoice((int)$payment->id);

		// Fire hooks
		do_action('jp_payment_completed',[
			'user_id'      => $payment->user_id,
			'plan_id'      => $payment->plan_id,
			'plan_name'    => $payment->description,
			'amount'       => $payment->amount,
			'payment_id'   => $payment_id,
			'invoice_url'  => $invoice_url,
		]);

		return [
			'message'     => 'Payment successful! Your plan is now active.',
			'invoice_url' => $invoice_url,
		];
	}

	public function ajax_verify_payment(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');
		$order_id   = sanitize_text_field($_POST['razorpay_order_id']??'');
		$payment_id = sanitize_text_field($_POST['razorpay_payment_id']??'');
		$signature  = sanitize_text_field($_POST['razorpay_signature']??'');
		$result     = $this->do_verify_payment(get_current_user_id(),$order_id,$payment_id,$signature);
		if (is_wp_error($result)) jp_json_response(false,$result->get_error_message());
		jp_json_response(true,$result);
	}

	/**
	 * Root-cause fix (batch 12 — Stripe gateway abstraction). Stripe
	 * Checkout's redirect flow hands the browser back only a session id in
	 * the URL (no signature to HMAC-verify the way Razorpay's checkout.js
	 * handler callback does) — the trustworthy confirmation is asking
	 * Stripe directly, server-side, what that session's actual
	 * payment_status is (a network round trip to a domain this server
	 * controls the credentials for, not anything client-suppliable), which
	 * is what this does before recording anything as paid. The Stripe
	 * webhook handler below (handle_webhook()'s checkout.session.completed
	 * branch) is this method's independent-confirmation counterpart, same
	 * relationship do_verify_payment()/handle_webhook() already have for
	 * Razorpay — whichever path gets there first activates, the other
	 * becomes a safe no-op via the same already-paid short-circuit below.
	 */
	public function do_verify_stripe_session( int $user_id, string $session_id ) {
		if ( ! $session_id ) return new WP_Error( 'missing_params', 'Missing payment parameters.' );

		$session = $this->stripe_request( 'GET', 'checkout/sessions/' . rawurlencode( $session_id ) );
		if ( is_wp_error( $session ) ) {
			return new WP_Error( 'gateway_error', 'Payment gateway error: ' . $session->get_error_message() );
		}
		if ( ( $session['payment_status'] ?? '' ) !== 'paid' ) {
			return new WP_Error( 'not_paid', 'Payment has not completed yet.' );
		}

		global $wpdb;
		$payment = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_payments WHERE stripe_session_id=%s AND user_id=%d",
			$session_id, $user_id
		) );
		if ( ! $payment ) return new WP_Error( 'not_found', 'Payment record not found.' );
		if ( $payment->status === 'paid' ) return [ 'message' => 'Payment already processed.' ];

		// Same return-value-checked, ghost-success-proof update as
		// do_verify_payment()'s Razorpay path (batch 8's fix, applied here
		// from the start). razorpay_pay_id is reused as a gateway-neutral
		// "external payment reference" column for Stripe's payment_intent
		// id — confirmed safe: every other reader of this column (the
		// Razorpay refund.created webhook lookup, the invoice PDF's
		// "Payment ID" line) either only ever runs for genuinely
		// Razorpay-sourced events or displays whatever reference is there
		// with no gateway-specific parsing, so no third migration column
		// was needed for this alone.
		$updated = $wpdb->update( $wpdb->prefix . 'jp_payments', [
			'razorpay_pay_id' => is_string( $session['payment_intent'] ?? null ) ? $session['payment_intent'] : ( $session['payment_intent']['id'] ?? '' ),
			'status'          => 'paid',
			'paid_at'         => current_time( 'mysql' ),
		], [ 'id' => $payment->id ], [ '%s','%s','%s' ], [ '%d' ] );

		if ( false === $updated ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception(
					new \Exception( 'jp_payments update failed: ' . $wpdb->last_error ),
					'JP_Payments::do_verify_stripe_session payment_id=' . $payment->id
				);
			}
			return new WP_Error( 'record_failed', 'Payment was verified but could not be recorded. Please contact support.' );
		}

		if ( ! JP_Subscriptions::instance()->activate( $payment->user_id, (int) $payment->plan_id, $payment->billing_cycle ?? 'monthly' ) && class_exists( 'JP_ErrorLog' ) ) {
			JP_ErrorLog::instance()->log_exception( new \Exception( 'Subscription activation failed after successful payment' ), 'JP_Payments::do_verify_stripe_session payment_id=' . $payment->id . ' user_id=' . $payment->user_id );
		}

		$invoice_url = $this->generate_invoice( (int) $payment->id );

		do_action( 'jp_payment_completed', [
			'user_id'     => $payment->user_id,
			'plan_id'     => $payment->plan_id,
			'plan_name'   => $payment->description,
			'amount'      => $payment->amount,
			'payment_id'  => $session_id,
			'invoice_url' => $invoice_url,
		] );

		return [
			'message'     => 'Payment successful! Your plan is now active.',
			'invoice_url' => $invoice_url,
		];
	}

	public function ajax_verify_stripe_session(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');
		$session_id = sanitize_text_field($_POST['session_id']??'');
		$result     = $this->do_verify_stripe_session(get_current_user_id(),$session_id);
		if (is_wp_error($result)) jp_json_response(false,$result->get_error_message());
		jp_json_response(true,$result);
	}

	// ── Razorpay webhook (async events) ──────────────────────────────────────

	public function handle_webhook(): void {
		if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_GET['jp_rzp_webhook'])) return;

		$payload   = file_get_contents('php://input');
		$secret    = jp_razorpay_webhook_secret();
		$signature = $_SERVER['HTTP_X_RAZORPAY_SIGNATURE'] ?? '';

		// Verify webhook signature
		if ($secret && !hash_equals(hash_hmac('sha256',$payload,$secret),$signature)) {
			http_response_code(400);
			exit('Invalid signature');
		}

		$event  = json_decode($payload,true);
		$entity = $event['payload']['payment']['entity']??null;

		switch ($event['event']??'') {
			case 'payment.captured':
				// Root-cause fix (batch 8 — see class-jp-activator.php's
				// jp_payments docblock and ajax_verify_payment()'s docblock
				// for the schema half of this fix). Two separate defects
				// fixed together here: (1) this branch never set paid_at,
				// so even once the missing columns exist, a payment
				// completed only via this webhook path (e.g. the customer
				// closed the browser before the SPA's own verify call could
				// fire) would still never count toward revenue stats;
				// (2) this branch never activated the subscription at all —
				// the webhook is meant to be Razorpay's reliable,
				// independent confirmation of payment, but previously only
				// ajax_verify_payment() (a call the customer's own browser
				// has to successfully make) or the once-an-hour
				// reconciliation job ever granted plan access, so a
				// webhook-only completion could leave a paying customer
				// without their plan for up to an hour. Fixed by loading
				// the payment row first and only activating when this call
				// is the one that actually flips status to 'paid' (skip if
				// already 'paid') — the same idempotency guard
				// ajax_verify_payment() already used for its own short-
				// circuit — so whichever of the three paths (verify
				// callback, this webhook, or reconciliation) gets there
				// first activates, and the other(s) become safe no-ops
				// instead of re-triggering JP_Subscriptions::activate()
				// (which is not itself idempotent — see the P1 #154
				// reconciliation docblock above for why that matters).
				if ($entity) {
					global $wpdb;
					$order_id = $entity['order_id']??'';
					$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_payments WHERE razorpay_order=%s",$order_id));
					if ($row && $row->status !== 'paid') {
						$updated = $wpdb->update($wpdb->prefix.'jp_payments',[
							'status'          => 'paid',
							'razorpay_pay_id' => $entity['id']??'',
							'paid_at'         => current_time('mysql'),
						],['razorpay_order'=>$order_id],['%s','%s','%s'],['%s']);
						if (false === $updated) {
							if (class_exists('JP_ErrorLog')) {
								JP_ErrorLog::instance()->log_exception(new \Exception('jp_payments webhook update failed: '.$wpdb->last_error),'JP_Payments::handle_webhook order_id='.$order_id);
							}
						} else {
							if ( ! JP_Subscriptions::instance()->activate((int)$row->user_id,(int)$row->plan_id,$row->billing_cycle??'monthly') && class_exists('JP_ErrorLog') ) {
								JP_ErrorLog::instance()->log_exception(new \Exception('Subscription activation failed after webhook-confirmed payment'),'JP_Payments::handle_webhook payment_id='.$row->id);
							}
							if (class_exists('JP_Security')) {
								JP_Security::audit('payment_confirmed_via_webhook','payment',(int)$row->id,'');
							}
						}
					}
				}
				break;
			case 'payment.failed':
				if ($entity) {
					global $wpdb;
					$updated = $wpdb->update($wpdb->prefix.'jp_payments',['status'=>'failed'],['razorpay_order'=>$entity['order_id']??''],['%s'],['%s']);
					if (false === $updated && class_exists('JP_ErrorLog')) {
						JP_ErrorLog::instance()->log_exception(new \Exception('jp_payments webhook update failed: '.$wpdb->last_error),'JP_Payments::handle_webhook payment.failed order_id='.($entity['order_id']??''));
					}
				}
				break;
			case 'refund.created':
				if ($entity) {
					global $wpdb;
					$updated = $wpdb->update($wpdb->prefix.'jp_payments',['status'=>'refunded'],['razorpay_pay_id'=>$entity['payment_id']??''],['%s'],['%s']);
					if (false === $updated && class_exists('JP_ErrorLog')) {
						JP_ErrorLog::instance()->log_exception(new \Exception('jp_payments webhook update failed: '.$wpdb->last_error),'JP_Payments::handle_webhook refund.created payment_id='.($entity['payment_id']??''));
					}
				}
				break;
		}

		http_response_code(200);
		exit('OK');
	}

	// ── Stripe webhook (async events) ─────────────────────────────────────────

	/**
	 * Root-cause fix (batch 12 — Stripe gateway abstraction). Stripe's
	 * signature scheme is deliberately different from Razorpay's plain
	 * HMAC-of-body: the Stripe-Signature header carries
	 * "t=<unix ts>,v1=<hex hmac>", where v1 is
	 * HMAC-SHA256("{t}.{raw body}", webhook_secret) — signing the
	 * timestamp together with the payload specifically to make old,
	 * replayed webhook deliveries rejectable (a 5-minute tolerance window,
	 * matching Stripe's own documented default), not just tampered ones.
	 * checkout.session.completed is the independent, Stripe-confirmed
	 * counterpart to do_verify_stripe_session() — same relationship as
	 * do_verify_payment()/handle_webhook()'s payment.captured branch have
	 * for Razorpay, including the same already-paid idempotency guard so
	 * whichever path (the SPA's own verify call on redirect-back, or this
	 * webhook) arrives first is the one that activates.
	 */
	public function handle_stripe_webhook(): void {
		if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_GET['jp_stripe_webhook'])) return;

		$payload   = file_get_contents('php://input');
		$secret    = jp_stripe_webhook_secret();
		$sig_header = $_SERVER['HTTP_STRIPE_SIGNATURE'] ?? '';

		if ($secret) {
			$parts = [];
			foreach (explode(',', $sig_header) as $part) {
				$kv = explode('=', $part, 2);
				if (count($kv) === 2) $parts[$kv[0]] = $kv[1];
			}
			$timestamp = $parts['t'] ?? '';
			$v1        = $parts['v1'] ?? '';
			$expected  = hash_hmac('sha256', $timestamp . '.' . $payload, $secret);
			$tolerance = 5 * MINUTE_IN_SECONDS;
			if (!$timestamp || !$v1 || !hash_equals($expected,$v1) || abs(time() - (int)$timestamp) > $tolerance) {
				http_response_code(400);
				exit('Invalid signature');
			}
		}

		$event  = json_decode($payload,true);
		$type   = $event['type'] ?? '';
		$object = $event['data']['object'] ?? null;

		if ($type === 'checkout.session.completed' && $object) {
			if (($object['payment_status'] ?? '') === 'paid') {
				global $wpdb;
				$session_id = $object['id'] ?? '';
				$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_payments WHERE stripe_session_id=%s",$session_id));
				if ($row && $row->status !== 'paid') {
					$payment_intent = is_string($object['payment_intent'] ?? null) ? $object['payment_intent'] : ($object['payment_intent']['id'] ?? '');
					$updated = $wpdb->update($wpdb->prefix.'jp_payments',[
						'status'          => 'paid',
						'razorpay_pay_id' => $payment_intent,
						'paid_at'         => current_time('mysql'),
					],['stripe_session_id'=>$session_id],['%s','%s','%s'],['%s']);
					if (false === $updated) {
						if (class_exists('JP_ErrorLog')) {
							JP_ErrorLog::instance()->log_exception(new \Exception('jp_payments stripe webhook update failed: '.$wpdb->last_error),'JP_Payments::handle_stripe_webhook session_id='.$session_id);
						}
					} else {
						if ( ! JP_Subscriptions::instance()->activate((int)$row->user_id,(int)$row->plan_id,$row->billing_cycle??'monthly') && class_exists('JP_ErrorLog') ) {
							JP_ErrorLog::instance()->log_exception(new \Exception('Subscription activation failed after webhook-confirmed Stripe payment'),'JP_Payments::handle_stripe_webhook payment_id='.$row->id);
						}
						if (class_exists('JP_Security')) {
							JP_Security::audit('payment_confirmed_via_webhook','payment',(int)$row->id,'');
						}
					}
				}
			}
		} elseif ($type === 'charge.refunded' && $object) {
			global $wpdb;
			$payment_intent = is_string($object['payment_intent'] ?? null) ? $object['payment_intent'] : '';
			if ($payment_intent) {
				$updated = $wpdb->update($wpdb->prefix.'jp_payments',['status'=>'refunded'],['razorpay_pay_id'=>$payment_intent],['%s'],['%s']);
				if (false === $updated && class_exists('JP_ErrorLog')) {
					JP_ErrorLog::instance()->log_exception(new \Exception('jp_payments stripe webhook update failed: '.$wpdb->last_error),'JP_Payments::handle_stripe_webhook charge.refunded payment_intent='.$payment_intent);
				}
			}
		}

		http_response_code(200);
		exit('OK');
	}

	// ── Reconciliation ────────────────────────────────────────────────────────

	/**
	 * Root-cause fix (gap analysis P1 #154: "there is no reconciliation job
	 * to catch orphaned 'created but never verified' payment rows"). A
	 * payment can be left permanently stuck in 'created' status for reasons
	 * that have nothing to do with this plugin: the user closed the
	 * Razorpay checkout modal, their browser crashed after paying but before
	 * ajax_verify_payment() ran, or the async webhook (the other write path
	 * to this table) itself failed to fire. Called hourly by
	 * JP_Cron::job_reconcile_payments(). For each 'created' row older than
	 * 30 minutes (matching the reuse window above — so we never touch a row
	 * still eligible to be reused), ask Razorpay directly what actually
	 * happened to that order, rather than guessing from our own state:
	 *  - Razorpay confirms a captured payment exists → this plugin's own
	 *    webhook/verify path silently failed to record it; correct our
	 *    state now (and activate the subscription, since the customer did
	 *    pay and should not be stuck unactivated because of our bug).
	 *  - Razorpay has no captured payment after 24h → the order was
	 *    abandoned; mark it 'abandoned' (not 'failed', which implies an
	 *    attempted-and-declined charge) so it stops appearing as a mystery
	 *    "pending forever" row to an admin looking at payments.
	 */
	public function reconcile_pending( int $limit = 50 ): array {
		global $wpdb;
		$result = [ 'checked' => 0, 'corrected_to_paid' => 0, 'marked_abandoned' => 0, 'errors' => 0 ];

		$stale = $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_payments
			 WHERE status='created' AND created_at < %s
			 ORDER BY id ASC LIMIT %d",
			gmdate( 'Y-m-d H:i:s', time() - 30 * MINUTE_IN_SECONDS ), $limit
		) );

		foreach ( $stale as $payment ) {
			$result['checked']++;
			$order = $this->razorpay_request( 'GET', 'orders/' . $payment->razorpay_order . '/payments' );

			if ( is_wp_error( $order ) ) {
				$result['errors']++;
				if ( class_exists( 'JP_ErrorLog' ) ) {
					JP_ErrorLog::instance()->log_exception(
						new \Exception( 'Payment reconciliation lookup failed: ' . $order->get_error_message() ),
						'JP_Payments::reconcile_pending order_id=' . $payment->razorpay_order
					);
				}
				continue;
			}

			$captured = null;
			foreach ( (array) ( $order['items'] ?? [] ) as $item ) {
				if ( ( $item['status'] ?? '' ) === 'captured' ) { $captured = $item; break; }
			}

			if ( $captured ) {
				// Root-cause fix (batch 8 — see class-jp-activator.php's
				// jp_payments docblock). This update's return value was
				// never checked, and activate()/audit() ran unconditionally
				// right after it regardless of whether the write actually
				// succeeded. With razorpay_signature/paid_at previously
				// missing from the schema this update failed silently on
				// every run, so status never reached 'paid' in the DB —
				// meaning the SELECT above kept re-selecting the SAME
				// already-recovered payment as still 'created' on every
				// subsequent hourly run, and activate() (not itself
				// idempotent — see this method's own docblock) would fire
				// again each time, silently re-extending a subscription's
				// expires_at forever from a single real payment. Only
				// activate/audit when this specific call is confirmed to
				// have actually flipped the row to 'paid'.
				$updated = $wpdb->update( $wpdb->prefix . 'jp_payments', [
					'razorpay_pay_id' => $captured['id'] ?? '',
					'status'          => 'paid',
					'paid_at'         => current_time( 'mysql' ),
				], [ 'id' => $payment->id ] );

				if ( false === $updated ) {
					$result['errors']++;
					if ( class_exists( 'JP_ErrorLog' ) ) {
						JP_ErrorLog::instance()->log_exception(
							new \Exception( 'jp_payments reconciliation update failed: ' . $wpdb->last_error ),
							'JP_Payments::reconcile_pending payment_id=' . $payment->id
						);
					}
					continue;
				}

				if ( ! JP_Subscriptions::instance()->activate( (int) $payment->user_id, (int) $payment->plan_id, $payment->billing_cycle ?? 'monthly' ) && class_exists( 'JP_ErrorLog' ) ) {
					JP_ErrorLog::instance()->log_exception( new \Exception( 'Subscription activation failed after reconciled payment' ), 'JP_Payments::reconcile_pending payment_id=' . $payment->id );
				}
				if ( class_exists( 'JP_Security' ) ) {
					JP_Security::audit( 'payment_reconciled_to_paid', 'payment', (int) $payment->id, [
						'razorpay_order' => $payment->razorpay_order,
						'note'           => 'Recovered by reconciliation job — webhook/verify path had not recorded this payment.',
					] );
				}
				$result['corrected_to_paid']++;
				continue;
			}

			// Still genuinely unpaid after 24h — stop treating it as pending.
			if ( strtotime( $payment->created_at ) < time() - DAY_IN_SECONDS ) {
				$wpdb->update( $wpdb->prefix . 'jp_payments', [ 'status' => 'abandoned' ], [ 'id' => $payment->id ] );
				$result['marked_abandoned']++;
			}
		}

		return $result;
	}

	// ── Invoice PDF generation ────────────────────────────────────────────────

	public function generate_invoice( int $payment_id ): string {
		global $wpdb;
		$payment = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_payments WHERE id=%d",$payment_id));
		if (!$payment) return '';

		$user    = get_userdata($payment->user_id);
		$site    = jp_site_name();

		// Root cause fix (gap analysis P1 #96): dependency probe and the
		// HTML-fallback write are now shared via JP_PDF instead of being
		// re-implemented independently per feature.
		if (!JP_PDF::ensure_available()) {
			$path = JP_PDF::write_html_fallback('jp-invoices','invoice-'.$payment_id.'.html',$this->render_invoice_html($payment,$user,$site));
			// Root-cause fix (batch 8, same defect as the TCPDF branch
			// below — this fallback branch never persisted invoice_url
			// either, so a payment made on an install without TCPDF
			// available would have a permanently-NULL invoice_url the same
			// way).
			$invoice_url = str_replace(ABSPATH,site_url('/'),$path);
			$updated = $wpdb->update($wpdb->prefix.'jp_payments',['invoice_url'=>$invoice_url],['id'=>$payment_id],['%s'],['%d']);
			if (false === $updated && class_exists('JP_ErrorLog')) {
				JP_ErrorLog::instance()->log_exception(new \Exception('jp_payments invoice_url update failed: '.$wpdb->last_error),'JP_Payments::generate_invoice(html-fallback) payment_id='.$payment_id);
			}
			return $invoice_url;
		}

		$pdf = new \TCPDF('P','mm','A4',true,'UTF-8',false);
		$pdf->SetCreator($site);
		$pdf->SetTitle('Invoice #'.$payment_id);
		$pdf->SetMargins(20,20,20);
		$pdf->SetAutoPageBreak(true,20);
		$pdf->AddPage();

		// Header
		$pdf->SetFillColor(21,107,201);
		$pdf->Rect(0,0,210,40,'F');
		$pdf->SetTextColor(255,255,255);
		$pdf->SetFont('helvetica','B',18);
		$pdf->SetXY(20,15);
		$pdf->Cell(0,10,'TAX INVOICE','',1,'L');
		$pdf->SetFont('helvetica','',11);
		$pdf->SetXY(20,27);
		$pdf->Cell(0,6,$site,'',0,'L');
		$pdf->SetXY(120,15);
		$pdf->Cell(70,6,'Invoice #'.str_pad($payment_id,6,'0',STR_PAD_LEFT),'',1,'R');
		$pdf->SetXY(120,23);
		$pdf->Cell(70,6,'Date: '.date('j M Y',strtotime($payment->paid_at??$payment->created_at)),'',1,'R');

		// Body
		$pdf->SetTextColor(0,0,0);
		$pdf->SetY(50);
		$pdf->SetFont('helvetica','B',11);
		$pdf->Cell(0,8,'Billed To:','',1);
		$pdf->SetFont('helvetica','',10);
		$pdf->Cell(0,6,$user->display_name,'',1);
		$pdf->Cell(0,6,$user->user_email,'',1);
		$pdf->Ln(6);

		// Table
		$pdf->SetFont('helvetica','B',10);
		$pdf->SetFillColor(240,245,255);
		$pdf->Cell(100,8,'Description','B',0,'L',true);
		$pdf->Cell(40,8,'Period','B',0,'C',true);
		$pdf->Cell(50,8,'Amount','B',1,'R',true);
		$pdf->SetFont('helvetica','',10);
		$pdf->Cell(100,7,$payment->description??'Subscription','',0);
		$pdf->Cell(40,7,ucfirst($payment->billing_cycle??'monthly'),'',0,'C');
		$pdf->Cell(50,7,($payment->currency ?: 'INR').' '.number_format($payment->amount),'',1,'R');
		$pdf->Ln(3);
		$pdf->SetFont('helvetica','B',11);
		$pdf->Cell(140,8,'Total (incl. 18% GST)','',0,'R');
		$pdf->Cell(50,8,($payment->currency ?: 'INR').' '.number_format($payment->amount),'',1,'R');

		$pdf->Ln(10);
		$pdf->SetFont('helvetica','I',9);
		$pdf->SetTextColor(100,100,100);
		$pdf->Cell(0,6,'Payment ID: '.($payment->razorpay_pay_id??'N/A'),'',1,'C');
		$pdf->Cell(0,6,'Thank you for your business!','',1,'C');

		$dir  = wp_upload_dir()['basedir'].'/jp-invoices/';
		wp_mkdir_p($dir);
		$path = $dir.'invoice-'.$payment_id.'.pdf';
		$pdf->Output($path,'F');

		// Root-cause fix (batch 8): this wrote to a column named
		// 'invoice_path', which has never existed in the jp_payments schema
		// (the real, always-existing column is 'invoice_url' — see
		// class-jp-activator.php's CREATE TABLE and its jp_payments
		// docblock, and every reader of this data: class-jp-api.php's admin/
		// recruiter payment-list SELECTs, and both AdminPaymentsPage.tsx and
		// RecruiterBillingPage.tsx's "View invoice" links). This UPDATE has
		// therefore always failed outright and invoice_url has always been
		// NULL in the database — meaning every "View invoice" link on both
		// of those dashboards has been broken for every payment, ever, even
		// though generate_invoice() itself correctly builds the file and
		// correctly returns a working URL for the single request that
		// triggered it. Fixed to the real column, and to store the same
		// public URL this method returns (not the raw filesystem $path,
		// which would be meaningless to a browser) so a later page load can
		// look it up from the DB instead of only the immediate response.
		$invoice_url = str_replace(ABSPATH,site_url('/'),$path);
		$updated = $wpdb->update($wpdb->prefix.'jp_payments',['invoice_url'=>$invoice_url],['id'=>$payment_id],['%s'],['%d']);
		if (false === $updated && class_exists('JP_ErrorLog')) {
			JP_ErrorLog::instance()->log_exception(new \Exception('jp_payments invoice_url update failed: '.$wpdb->last_error),'JP_Payments::generate_invoice payment_id='.$payment_id);
		}

		return $invoice_url;
	}

	/** Batch 30: was a hardcoded ₹ symbol, which silently mislabeled a
	 * USD payment's amount as rupees on the one document a customer is
	 * most likely to keep for their own records/accounting. */
	private function invoice_currency_symbol( ?string $currency ): string {
		return match ( strtoupper( $currency ?: 'INR' ) ) {
			'USD'   => '$',
			default => '₹',
		};
	}

	private function render_invoice_html( $payment, $user, string $site ): string {
		$symbol = $this->invoice_currency_symbol( $payment->currency ?? null );
		return "<html><body style='font-family:sans-serif;padding:40px;'>
		<h1 style='color:#156BC9;'>{$site} — Invoice #{$payment->id}</h1>
		<p>Billed to: <strong>{$user->display_name}</strong> ({$user->user_email})</p>
		<p>Date: ".date('j M Y',strtotime($payment->paid_at??$payment->created_at))."</p>
		<table style='border-collapse:collapse;width:100%;'><tr style='background:#EFF6FF;'><th style='padding:8px;text-align:left;'>Description</th><th style='padding:8px;'>Amount</th></tr>
		<tr><td style='padding:8px;border-bottom:1px solid #E5E7EB;'>{$payment->description}</td><td style='padding:8px;text-align:right;border-bottom:1px solid #E5E7EB;'>{$symbol}".number_format($payment->amount)."</td></tr>
		<tr><td style='padding:8px;text-align:right;'><strong>Total</strong></td><td style='padding:8px;text-align:right;'><strong>{$symbol}".number_format($payment->amount)."</strong></td></tr></table>
		</body></html>";
	}

	// ── Razorpay API helper ───────────────────────────────────────────────────

	private function razorpay_request( string $method, string $endpoint, array $data = [] ) {
		$key_id     = jp_razorpay_key_id();
		$key_secret = jp_razorpay_key_secret();

		if (!$key_id||!$key_secret) return new WP_Error('no_credentials','Razorpay credentials not configured in wp-config.php');

		$args = [
			'method'  => strtoupper($method),
			'headers' => [
				'Authorization' => 'Basic '.base64_encode("{$key_id}:{$key_secret}"),
				'Content-Type'  => 'application/json',
			],
			'timeout' => 30,
		];
		if (!empty($data)) $args['body'] = wp_json_encode($data);

		$response = wp_remote_request(self::RAZORPAY_API.$endpoint,$args);
		if (is_wp_error($response)) return $response;

		$body     = json_decode(wp_remote_retrieve_body($response),true);
		$code     = (int)wp_remote_retrieve_response_code($response);

		if ($code >= 400) {
			$msg = $body['error']['description']??$body['error']['code']??'Unknown Razorpay error';
			return new WP_Error('razorpay_error',$msg,['status'=>$code]);
		}
		return $body;
	}

	/**
	 * Root-cause fix (batch 12 — Stripe gateway abstraction). Unlike
	 * Razorpay's JSON API, Stripe's REST API takes
	 * application/x-www-form-urlencoded bodies with PHP-style bracket
	 * nesting for arrays/objects (http_build_query() produces exactly that
	 * encoding for a nested array, which is why $data is built as plain
	 * nested PHP arrays at every call site rather than assembled as query
	 * strings by hand). GET requests carry no body. $idempotency_key, when
	 * given, is sent as Stripe's own Idempotency-Key header — Stripe
	 * itself dedupes a repeated POST using the same key within 24h and
	 * returns the original response, which is what do_create_stripe_session()
	 * relies on instead of Razorpay's manual "look up an existing row"
	 * reuse check.
	 */
	private function stripe_request( string $method, string $endpoint, array $data = [], string $idempotency_key = '' ) {
		$secret_key = jp_stripe_secret_key();
		if ( ! $secret_key ) return new WP_Error( 'no_credentials', 'Stripe credentials not configured.' );

		$headers = [
			'Authorization' => 'Bearer ' . $secret_key,
			'Content-Type'  => 'application/x-www-form-urlencoded',
		];
		if ( $idempotency_key ) $headers['Idempotency-Key'] = $idempotency_key;

		$args = [
			'method'  => strtoupper( $method ),
			'headers' => $headers,
			'timeout' => 30,
		];
		if ( ! empty( $data ) && strtoupper( $method ) !== 'GET' ) {
			$args['body'] = http_build_query( $data, '', '&' );
		}

		$response = wp_remote_request( self::STRIPE_API . $endpoint, $args );
		if ( is_wp_error( $response ) ) return $response;

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		$code = (int) wp_remote_retrieve_response_code( $response );

		if ( $code >= 400 ) {
			$msg = $body['error']['message'] ?? $body['error']['type'] ?? 'Unknown Stripe error';
			return new WP_Error( 'stripe_error', $msg, [ 'status' => $code ] );
		}
		return $body;
	}
}
