<?php
/**
 * Class JP_Matching — AI Job Matching Engine (pure PHP, no external API)
 *
 * Scoring weights (from spec):
 *   Skills overlap (Jaccard)  40%
 *   Experience years match     25%
 *   Location match             15%
 *   Education match            10%
 *   Salary expectation match   10%
 *
 * Optional: OpenAI semantic boost when JP_OPENAI_KEY is defined.
 */
defined( 'ABSPATH' ) || exit;

class JP_Matching {

	private static ?JP_Matching $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_jp_get_matches', [ $this, 'ajax_get_matches' ] );
		// Background handler for the new-candidate real-time-fallback backfill
		// scheduled in get_matches_for_candidate() — keeps the AI-boosted,
		// persisted score path off the request/response cycle entirely.
		add_action( 'jp_backfill_candidate_matches', [ $this, 'backfill_candidate_matches' ] );
		// Queue handler for one chunk of the daily batch-scoring pass — see
		// enqueue_daily_scoring()'s docblock (gap analysis P1 #201).
		add_action( 'jp_score_candidate_batch', [ $this, 'score_candidate_batch_job' ], 10, 2 );
	}

	/**
	 * Per-factor score breakdown for one candidate/job pair. Populated into
	 * jp_matches.score_detail (a column that existed in the schema but was
	 * never written to) so both candidates and recruiters can see *why* a
	 * match scored the way it did, instead of a bare number.
	 */
	public function score_breakdown( object $candidate, object $job ): array {
		return [
			'skills'     => $this->score_skills( $candidate, $job ),
			'experience' => $this->score_experience( $candidate, $job ),
			'location'   => $this->score_location( $candidate, $job ),
			'education'  => $this->score_education( $candidate, $job ),
			'salary'     => $this->score_salary( $candidate, $job ),
			'weights'    => [ 'skills' => 0.40, 'experience' => 0.25, 'location' => 0.15, 'education' => 0.10, 'salary' => 0.10 ],
		];
	}

	// ── Main scoring entry point ──────────────────────────────────────────────

	/**
	 * Score a single candidate against a single job.
	 * Returns 0-100 integer.
	 */
	public function score( object $candidate, object $job, bool $use_ai_boost = true ): int {
		$skills_score = $this->score_skills( $candidate, $job );   // 40%
		$exp_score    = $this->score_experience( $candidate, $job ); // 25%
		$loc_score    = $this->score_location( $candidate, $job );   // 15%
		$edu_score    = $this->score_education( $candidate, $job );  // 10%
		$sal_score    = $this->score_salary( $candidate, $job );     // 10%

		$total = (int) round(
			$skills_score * 0.40 +
			$exp_score    * 0.25 +
			$loc_score    * 0.15 +
			$edu_score    * 0.10 +
			$sal_score    * 0.10
		);

		// Optional OpenAI semantic boost (+5 max). $use_ai_boost=false lets a
		// caller (see get_matches_for_candidate()'s real-time fallback below)
		// deliberately skip the network call for bulk/synchronous scoring —
		// see that method for why this matters.
		if ( $use_ai_boost && defined('JP_OPENAI_KEY') && JP_OPENAI_KEY && $total >= 40 ) {
			$boost  = $this->openai_semantic_boost( $candidate, $job );
			$total  = min( 100, $total + $boost );
		}

		return max( 0, min( 100, $total ) );
	}

	// ── Factor: Skills overlap (Jaccard similarity) ───────────────────────────

	private function score_skills( object $candidate, object $job ): int {
		// Root-cause fix (4-way skills-storage consolidation, §37):
		// $candidate->skills_json referenced a column that was never
		// created on jp_candidates (confirmed against the actual CREATE
		// TABLE in class-jp-activator.php) — every candidate's declared
		// skills silently evaluated to an empty array here, meaning skill
		// overlap — 40% of this class's own documented scoring weight, per
		// its docblock — has been worth 0 for every single match score
		// this system has ever computed. Reads the real jp_user_skills
		// table now, via JP_DB::get_user_skill_names(), with the same
		// "pre-attach once per candidate to avoid N+1 across a candidate's
		// job loop" pattern already used for verified_skills below.
		$candidate_skills = property_exists( $candidate, 'declared_skills' ) && is_array( $candidate->declared_skills )
			? $candidate->declared_skills
			: array_map( 'strtolower', JP_DB::instance()->get_user_skill_names( (int) ( $candidate->user_id ?? 0 ) ) );
		$job_skills       = array_map( 'strtolower', json_decode( $job->skills_json ?? '[]', true ) ?: [] );

		if ( empty($job_skills) ) return 60; // No requirements = neutral
		if ( empty($candidate_skills) ) return 0;

		// Root-cause fix (gap analysis P1 #145: "Match-score explainability
		// is provisioned but unused ... verified/assessed skills never
		// actually influence match scores"). jp_assessments already records,
		// per user, which skills a candidate has actually PROVEN by passing
		// a skill test (badge_level != 'none') — but this method previously
		// only ever compared self-declared skills_json strings, so a
		// verified skill scored identically to a candidate simply typing
		// the same word into their profile with no way to substantiate it.
		// Callers that score many job pairs for the same candidate in a
		// loop (batch_score, backfill_candidate_matches, the real-time
		// fallback in get_matches_for_candidate) attach
		// $candidate->verified_skills once per candidate before their inner
		// job loop, so this stays a single query per candidate rather than
		// one per candidate×job pair; a direct/one-off caller that hasn't
		// set it gets a lazy per-call lookup here instead.
		$verified = property_exists( $candidate, 'verified_skills' ) && is_array( $candidate->verified_skills )
			? $candidate->verified_skills
			: $this->get_verified_skill_names( (int) ( $candidate->user_id ?? 0 ) );

		$intersection = array_intersect( $candidate_skills, $job_skills );
		$union        = count( array_unique( array_merge( $candidate_skills, $job_skills ) ) );

		// A verified overlapping skill counts as 1.5 toward the match
		// weight instead of 1 — meaningfully rewarding proof without
		// changing behavior at all when no assessment is involved.
		$weighted_intersection = 0.0;
		foreach ( $intersection as $skill ) {
			$weighted_intersection += in_array( $skill, $verified, true ) ? 1.5 : 1.0;
		}

		// Jaccard: |A ∩ B| / |A ∪ B| (weighted numerator, capped at 1.0 so
		// verification weighting can only help, never push a factor's own
		// contribution past what a "perfect" match would score)
		$jaccard = $union > 0 ? min( 1.0, $weighted_intersection / $union ) : 0;

		// Also weight by coverage of required skills specifically
		$coverage = min( 1.0, $weighted_intersection / count( $job_skills ) );

		$combined = ( $jaccard * 0.4 + $coverage * 0.6 );
		return (int) round( $combined * 100 );
	}

	/**
	 * Lowercased names of skills this user has actually passed an
	 * assessment for (any non-'none' badge, not expired). See score_skills()
	 * above for why this exists and how callers should avoid triggering it
	 * once per job by pre-attaching the result to $candidate->verified_skills.
	 */
	private function get_verified_skill_names( int $user_id ): array {
		if ( ! $user_id ) return [];
		global $wpdb;
		$names = $wpdb->get_col( $wpdb->prepare(
			"SELECT DISTINCT s.name FROM {$wpdb->prefix}jp_assessments a
			 JOIN {$wpdb->prefix}jp_skills s ON s.id = a.skill_id
			 WHERE a.user_id = %d AND a.badge_level != 'none' AND ( a.expires_at IS NULL OR a.expires_at > NOW() )",
			$user_id
		) );
		return array_map( 'strtolower', $names ?: [] );
	}

	// ── Factor: Experience years ──────────────────────────────────────────────

	private function score_experience( object $candidate, object $job ): int {
		$cand_exp = (int) ($candidate->experience_years ?? 0);
		$job_min  = (int) ($job->experience_min ?? 0);
		$job_max  = (int) ($job->experience_max ?? $job_min + 10);

		if ( $job_min === 0 && $job_max === 0 ) return 80; // No requirement

		// Perfect match: candidate falls within range
		if ( $cand_exp >= $job_min && $cand_exp <= $job_max ) return 100;

		// Under-experienced
		if ( $cand_exp < $job_min ) {
			$gap   = $job_min - $cand_exp;
			$score = max( 0, 100 - ($gap * 20) ); // -20 pts per year gap
			return (int) $score;
		}

		// Over-experienced (slight penalty, employers may worry about retention)
		$over  = $cand_exp - $job_max;
		$score = max( 50, 100 - ($over * 8) );
		return (int) $score;
	}

	// ── Factor: Location ──────────────────────────────────────────────────────

	private function score_location( object $candidate, object $job ): int {
		// Remote job = perfect match for everyone
		if ( $job->work_mode === 'remote' ) return 100;

		// Candidate prefers remote — penalise on-site job
		if ( ($candidate->preferred_work_mode ?? '') === 'remote' && $job->work_mode === 'onsite' ) return 30;

		// Candidate willing to relocate
		if ( !empty($candidate->willing_to_relocate) ) return 80;

		$cand_city  = strtolower( trim( $candidate->location_city ?? '' ) );
		$job_city   = strtolower( trim( $job->location_city ?? '' ) );
		$cand_state = strtolower( trim( $candidate->location_state ?? '' ) );
		$job_state  = strtolower( trim( $job->location_state ?? '' ) );

		if ( !$job_city ) return 70; // No location constraint

		// Exact city match
		if ( $cand_city && $cand_city === $job_city ) return 100;

		// Same state
		if ( $cand_state && $job_state && $cand_state === $job_state ) return 60;

		// Different location
		return 20;
	}

	// ── Factor: Education ─────────────────────────────────────────────────────

	private function score_education( object $candidate, object $job ): int {
		$required_edu = strtolower( $job->education_level ?? '' );
		if ( ! $required_edu ) return 80; // No requirement

		$edu_hierarchy = [
			'10th'        => 1, 'secondary' => 1,
			'12th'        => 2, 'higher secondary' => 2,
			'diploma'     => 3,
			'bachelor'    => 4, "bachelor's" => 4, 'b.tech' => 4, 'be' => 4, 'bsc' => 4, 'bca' => 4,
			'master'      => 5, "master's" => 5, 'm.tech' => 5, 'mca' => 5, 'mba' => 5,
			'phd'         => 6, 'doctorate' => 6,
		];

		$cand_edu_raw = strtolower( wp_json_encode( json_decode($candidate->education_json??'[]',true) ) ?: '' );

		$cand_level = 0;
		foreach ( $edu_hierarchy as $label => $level ) {
			if ( str_contains($cand_edu_raw, $label) ) $cand_level = max($cand_level, $level);
		}

		$req_level = 0;
		foreach ( $edu_hierarchy as $label => $level ) {
			if ( str_contains($required_edu, $label) ) { $req_level = $level; break; }
		}

		if ( $cand_level >= $req_level ) return 100;
		$gap = $req_level - $cand_level;
		return max( 0, 100 - $gap * 25 );
	}

	// ── Factor: Salary ────────────────────────────────────────────────────────

	private function score_salary( object $candidate, object $job ): int {
		$cand_min = (int) ($candidate->expected_salary_min ?? 0);
		$cand_max = (int) ($candidate->expected_salary_max ?? $cand_min * 1.3);
		$job_min  = (int) ($job->salary_min ?? 0);
		$job_max  = (int) ($job->salary_max ?? $job_min * 1.3);

		if ( !$cand_min || !$job_min ) return 70; // Unknown = neutral

		// Check for range overlap
		$overlap_start = max( $cand_min, $job_min );
		$overlap_end   = min( $cand_max, $job_max );

		if ( $overlap_start <= $overlap_end ) return 100; // Overlap exists

		// Candidate expects more than job pays
		if ( $cand_min > $job_max ) {
			$gap_pct = ($cand_min - $job_max) / $job_max * 100;
			return max( 0, (int)(100 - $gap_pct * 2) );
		}

		// Job pays more than candidate expects (candidate under-priced — employer loves it)
		return 90;
	}

	// ── OpenAI semantic boost (optional) ─────────────────────────────────────

	private function openai_semantic_boost( object $candidate, object $job ): int {
		if ( ! defined('JP_OPENAI_KEY') || ! JP_OPENAI_KEY ) return 0;

		$cache_key = 'jp_ai_boost_' . $candidate->user_id . '_' . $job->id;
		$cached    = JP_Cache::get( $cache_key );
		if ( $cached !== false ) return (int) $cached;

		// Root-cause fix (§37): same phantom-column issue as score_skills()
		// — $candidate->skills_json never existed, so the AI prompt always
		// silently omitted the candidate's actual skills. Reuses the
		// pre-attached $candidate->declared_skills when a caller already
		// set it (all 3 current call sites do), falling back to a direct
		// lookup for any future direct caller that hasn't.
		$candidate_skill_names = property_exists( $candidate, 'declared_skills' ) && is_array( $candidate->declared_skills )
			? $candidate->declared_skills
			: JP_DB::instance()->get_user_skill_names( (int) ( $candidate->user_id ?? 0 ) );
		$prompt = "Rate how well this candidate matches this job on a scale 0-5. Return only a single integer.\n\n"
			. "Candidate: " . ($candidate->headline??'') . ". Skills: " . implode(', ', $candidate_skill_names) . ". "
			. "Experience: " . ($candidate->experience_years??0) . " years.\n\n"
			. "Job: " . $job->title . ". Required skills: " . implode(', ', json_decode($job->skills_json??'[]',true)?:[]) . ". "
			. "Description: " . mb_substr(strip_tags($job->description??''),0,300);

		try {
			$response = wp_remote_post('https://api.openai.com/v1/chat/completions', [
				'timeout' => 8,
				'headers' => ['Authorization'=>'Bearer '.JP_OPENAI_KEY,'Content-Type'=>'application/json'],
				'body'    => wp_json_encode(['model'=>'gpt-3.5-turbo','messages'=>[['role'=>'user','content'=>$prompt]],'max_tokens'=>5,'temperature'=>0]),
			]);
			if ( is_wp_error($response) ) return 0;
			$body  = json_decode( wp_remote_retrieve_body($response), true );
			$score = (int) trim( $body['choices'][0]['message']['content'] ?? '0' );
			$boost = min( 5, max( 0, $score ) ); // 0-5 bonus points
			JP_Cache::set( $cache_key, $boost, 86400 ); // cache 24h
			return $boost;
		} catch ( \Throwable ) {
			return 0;
		}
	}

	// ── Batch scoring (called by cron, via the job queue) ─────────────────────

	/**
	 * Root-cause fix (gap analysis P1 #201: "Match-batch scoring is
	 * O(candidates × active jobs) with a hardcoded 500-candidate cap, run as
	 * a single in-PHP nested loop on a daily cron ... at real enterprise
	 * volume this will not complete in a reasonable cron window, and any
	 * candidate beyond the cap is silently never scored at all, degrading
	 * match quality invisibly as the user base grows"). Two distinct bugs
	 * were baked into the old design:
	 *  1. A single WP-Cron HTTP request has to complete within PHP's
	 *     max_execution_time. Scoring thousands of candidates against
	 *     thousands of jobs in one synchronous loop will simply time out
	 *     partway through on a real dataset, with no record of how far it
	 *     got and no retry.
	 *  2. The `LIMIT $limit` cap meant candidates beyond the cap were not
	 *     merely delayed — they were *never* scored, forever, on every
	 *     single run, since the query had no ORDER BY or cursor and kept
	 *     re-selecting the same first N rows every time.
	 *
	 * Fix: `JP_Cron::job_match_scores()` (still the daily trigger) now calls
	 * `enqueue_daily_scoring()` below instead of calling `batch_score()`
	 * directly. That method paginates through EVERY open-to-work candidate
	 * (no cap) and enqueues one `jp_score_candidate_batch` job per chunk via
	 * the job queue built for gap analysis P1 "no queue system anywhere"
	 * (class-jp-queue.php) — so the actual scoring work is spread across
	 * many small, independently-retried 5-minute queue-processing cycles
	 * instead of one all-or-nothing daily request, and no candidate is
	 * permanently skipped just for being past an arbitrary row cap.
	 * `batch_score()` itself is kept (now accepting an $offset) as the
	 * reusable, directly-callable scoring routine — both the queued path
	 * and any future direct/manual "score this segment now" admin action
	 * can share it rather than duplicating the loop.
	 */
	public function enqueue_daily_scoring( int $chunk_size = 100 ): int {
		global $wpdb;
		$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->prefix}jp_candidates WHERE is_open_to_work=1" );
		if ( ! $total || ! class_exists( 'JP_Queue' ) ) return 0;

		$chunks = 0;
		for ( $offset = 0; $offset < $total; $offset += $chunk_size ) {
			JP_Queue::instance()->enqueue( 'jp_score_candidate_batch', [ $offset, $chunk_size ] );
			$chunks++;
		}
		return $chunks;
	}

	/** Queue handler for one chunk — registered in __construct() above. */
	public function score_candidate_batch_job( int $offset, int $limit ): void {
		$this->batch_score( $limit, $offset );
	}

	/**
	 * Score one page of open-to-work candidates against all active jobs.
	 * Stores results in jp_matches table. Ordered by id so paginated calls
	 * (offset, offset+limit, offset+2*limit, ...) cover every candidate
	 * exactly once per full pass instead of the old uncapped, cursor-less
	 * query re-selecting the same first N rows forever.
	 */
	public function batch_score( int $limit = 500, int $offset = 0 ): int {
		global $wpdb;

		$candidates = $wpdb->get_results( $wpdb->prepare(
			"SELECT c.*,u.display_name FROM {$wpdb->prefix}jp_candidates c LEFT JOIN {$wpdb->users} u ON u.ID=c.user_id
			 WHERE c.is_open_to_work=1 ORDER BY c.id ASC LIMIT %d OFFSET %d",
			$limit, $offset
		) );
		$jobs       = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}jp_jobs WHERE status='active'" );

		$count = 0;
		foreach ( $candidates as $candidate ) {
			// One verified-skills lookup per candidate, not per candidate×job
			// pair — see score_skills()'s docblock.
			$candidate->verified_skills = $this->get_verified_skill_names( (int) $candidate->user_id );
			$candidate->declared_skills = array_map( 'strtolower', JP_DB::instance()->get_user_skill_names( (int) $candidate->user_id ) );
			foreach ( $jobs as $job ) {
				$score = $this->score( $candidate, $job );
				if ( $score < 30 ) continue; // Skip low-quality matches

				// Root-cause fix: score_detail existed on the schema
				// specifically to store this breakdown but was never written.
				$wpdb->replace( $wpdb->prefix . 'jp_matches', [
					'candidate_id' => $candidate->id,
					'job_id'       => $job->id,
					'score'        => $score,
					'score_detail' => wp_json_encode( $this->score_breakdown( $candidate, $job ) ),
					'computed_at'  => current_time('mysql'),
				], ['%d','%d','%d','%s','%s'] );
				$count++;
			}
		}
		return $count;
	}

	// ── Get top matches for a candidate ──────────────────────────────────────

	public function get_matches_for_candidate( int $user_id, int $limit = 20 ): array {
		global $wpdb;
		$candidate = JP_DB::instance()->get_candidate( $user_id );
		if ( !$candidate ) return [];

		// Try pre-computed scores first. Excludes jobs this candidate has
		// dismissed ("not interested, stop recommending this") via
		// jp_match_dismissals -- see JP_API::dismiss_match()'s docblock for
		// why dismissals live in their own table rather than a column on
		// jp_matches (that row gets $wpdb->replace()'d on every re-score run,
		// which would silently wipe a column-based dismissal flag).
		$pre = $wpdb->get_results( $wpdb->prepare(
			"SELECT m.*,j.title,j.slug,j.location_city,j.work_mode,j.job_type,j.salary_min,j.salary_max,c.name AS company_name
			 FROM {$wpdb->prefix}jp_matches m
			 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=m.job_id
			 LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id
			 WHERE m.candidate_id=%d AND j.status='active'
			 AND NOT EXISTS (
			     SELECT 1 FROM {$wpdb->prefix}jp_match_dismissals d
			     WHERE d.candidate_id=m.candidate_id AND d.job_id=m.job_id
			 )
			 ORDER BY m.score DESC LIMIT %d",
			$candidate->id, $limit
		) );

		if ( !empty($pre) ) return $pre;

		// Root-cause fix: this real-time fallback (hit by every brand-new
		// candidate on their very first "matches" page load, since they have
		// no jp_matches rows yet) used to call score() — which can trigger a
		// live, blocking OpenAI HTTP call per job scoring >=40 — for up to
		// 100 jobs synchronously inside a single page-load request. That is
		// up to 100 sequential network round-trips (multi-second-to-timeout
		// page loads) and unbounded per-request AI spend, every single time
		// a new candidate loads this page before the nightly batch_score()
		// cron has ever run for them.
		//
		// Fix: score this fallback WITHOUT the AI boost (deterministic,
		// in-process, no network calls — the AI boost is a +5-point nicety,
		// not the basis of the match), and kick off an immediate one-off
		// background batch_score for just this candidate so their next page
		// load gets full AI-boosted, pre-computed scores instead of hitting
		// this fallback again.
		$dismissed = $wpdb->get_col( $wpdb->prepare(
			"SELECT job_id FROM {$wpdb->prefix}jp_match_dismissals WHERE candidate_id=%d",
			$candidate->id
		) );
		$dismissed = array_map( 'intval', $dismissed );
		$jobs    = $wpdb->get_results("SELECT j.*,c.name AS company_name FROM {$wpdb->prefix}jp_jobs j LEFT JOIN {$wpdb->prefix}jp_companies c ON c.id=j.company_id WHERE j.status='active' LIMIT 100");
		$matches = [];
		$candidate->verified_skills = $this->get_verified_skill_names( (int) $candidate->user_id );
		$candidate->declared_skills = array_map( 'strtolower', JP_DB::instance()->get_user_skill_names( (int) $candidate->user_id ) );
		foreach ($jobs as $job) {
			if ( in_array( (int) $job->id, $dismissed, true ) ) continue;
			$score = $this->score($candidate,$job,false);
			// score_detail included here too so the frontend's "why this match"
			// breakdown has the same shape whether a candidate is hitting the
			// pre-computed path (jp_matches.score_detail, already persisted by
			// backfill_candidate_matches()/score_candidate_batch_job()) or this
			// real-time fallback for brand-new candidates.
			if ($score >= 50) $matches[] = array_merge((array)$job,['score'=>$score,'score_detail'=>wp_json_encode($this->score_breakdown($candidate,$job))]);
		}
		usort($matches, fn($a,$b) => $b['score'] <=> $a['score']);

		// Debounce: only schedule once per candidate per hour, so repeated
		// page loads before the job actually runs don't queue duplicates.
		$debounce_key = 'jp_matching_backfill_' . $candidate->id;
		if ( ! get_transient( $debounce_key ) ) {
			set_transient( $debounce_key, 1, HOUR_IN_SECONDS );
			if ( ! wp_next_scheduled( 'jp_backfill_candidate_matches', [ $candidate->id ] ) ) {
				wp_schedule_single_event( time() + 30, 'jp_backfill_candidate_matches', [ $candidate->id ] );
			}
		}

		return array_slice($matches,0,$limit);
	}

	/**
	 * Score one candidate against all active jobs and persist to jp_matches,
	 * with the AI boost enabled. Runs off the request path via
	 * wp_schedule_single_event('jp_backfill_candidate_matches', [$candidate_id])
	 * — see get_matches_for_candidate()'s fallback above, and the hook
	 * registration in jp-core.php / class-jp-cron.php.
	 */
	public function backfill_candidate_matches( int $candidate_id ): void {
		global $wpdb;
		$candidate = $wpdb->get_row( $wpdb->prepare(
			"SELECT c.*,u.display_name FROM {$wpdb->prefix}jp_candidates c LEFT JOIN {$wpdb->users} u ON u.ID=c.user_id WHERE c.id=%d",
			$candidate_id
		) );
		if ( ! $candidate ) return;
		$jobs = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}jp_jobs WHERE status='active'" );
		$candidate->verified_skills = $this->get_verified_skill_names( (int) $candidate->user_id );
		$candidate->declared_skills = array_map( 'strtolower', JP_DB::instance()->get_user_skill_names( (int) $candidate->user_id ) );
		foreach ( $jobs as $job ) {
			$score = $this->score( $candidate, $job );
			if ( $score < 30 ) continue;
			$wpdb->replace( $wpdb->prefix . 'jp_matches', [
				'candidate_id' => $candidate->id,
				'job_id'       => $job->id,
				'score'        => $score,
				'score_detail' => wp_json_encode( $this->score_breakdown( $candidate, $job ) ),
				'computed_at'  => current_time( 'mysql' ),
			], [ '%d', '%d', '%d', '%s', '%s' ] );
		}
	}

	// ── AJAX endpoint ─────────────────────────────────────────────────────────

	public function ajax_get_matches(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');
		$matches = $this->get_matches_for_candidate(get_current_user_id());
		jp_json_response(true,['matches'=>$matches]);
	}
}
