<?php
/**
 * Class JP_Resume — Resume upload, parsing (NLP extraction), builder, PDF export via TCPDF.
 *
 * Parser extracts: name, email, phone, skills (fuzzy matched), experience years,
 * education, current employer + title — without any paid API.
 *
 * Requires: pdftotext (poppler-utils) on server, and optionally TCPDF for PDF export.
 */
defined( 'ABSPATH' ) || exit;

class JP_Resume {

	private static ?JP_Resume $instance = null;

	/** Fuzzy skill aliases — maps common misspellings / variants to canonical name */
	private const SKILL_ALIASES = [
		'reactjs' => 'React', 'react.js' => 'React',
		'nodejs'  => 'Node.js', 'node js' => 'Node.js',
		'vuejs'   => 'Vue.js', 'vue js' => 'Vue.js',
		'angularjs' => 'Angular', 'angular js' => 'Angular',
		'mongo'   => 'MongoDB', 'mongo db' => 'MongoDB',
		'postgres' => 'PostgreSQL', 'postgresql' => 'PostgreSQL',
		'aws'     => 'AWS', 'amazon web services' => 'AWS',
		'gcp'     => 'GCP', 'google cloud' => 'GCP',
		'k8s'     => 'Kubernetes', 'kube' => 'Kubernetes',
		'tf'      => 'TensorFlow', 'tensorflow' => 'TensorFlow',
		'js'      => 'JavaScript', 'javascript' => 'JavaScript',
		'ts'      => 'TypeScript', 'typescript' => 'TypeScript',
		'py'      => 'Python', 'python3' => 'Python',
		'rb'      => 'Ruby', 'ror' => 'Ruby on Rails',
		'css3'    => 'CSS', 'html5' => 'HTML',
		'restapi' => 'REST API', 'rest apis' => 'REST API',
		'graphql' => 'GraphQL', 'grpc' => 'gRPC',
	];

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_jp_upload_resume',      [ $this, 'ajax_upload' ] );
		add_action( 'wp_ajax_jp_delete_resume',      [ $this, 'ajax_delete' ] );
		add_action( 'wp_ajax_jp_set_primary_resume', [ $this, 'ajax_set_primary' ] );
		add_action( 'wp_ajax_jp_save_resume_section',[ $this, 'ajax_save_section' ] );
		add_action( 'wp_ajax_jp_get_resume_pdf',     [ $this, 'ajax_get_pdf' ] );
		add_action( 'wp_ajax_jp_download_resume',    [ $this, 'ajax_download' ] );
	}

	// ── Upload & parse ────────────────────────────────────────────────────────

	public function ajax_upload(): void {
		jp_verify_nonce( 'jp_general' );
		if ( ! is_user_logged_in() ) jp_json_response( false, 'Not authenticated.' );

		if ( empty( $_FILES['resume'] ) || $_FILES['resume']['error'] !== UPLOAD_ERR_OK ) {
			jp_json_response( false, 'No file received or upload error.' );
		}

		$file     = $_FILES['resume'];
		$max_size = (int) get_option( 'jp_resume_max_size_mb', 5 ) * 1024 * 1024;

		if ( $file['size'] > $max_size ) {
			jp_json_response( false, 'File too large. Maximum size is ' . get_option('jp_resume_max_size_mb',5) . 'MB.' );
		}

		$ext = strtolower( pathinfo( $file['name'], PATHINFO_EXTENSION ) );
		if ( ! in_array( $ext, ['pdf','doc','docx'], true ) ) {
			jp_json_response( false, 'Invalid file type. Only PDF and Word documents are accepted.' );
		}

		// Verify MIME
		$finfo    = finfo_open( FILEINFO_MIME_TYPE );
		$mime     = finfo_file( $finfo, $file['tmp_name'] );
		finfo_close( $finfo );
		$allowed_mimes = [ 'application/pdf','application/msword','application/vnd.openxmlformats-officedocument.wordprocessingml.document' ];
		if ( ! in_array( $mime, $allowed_mimes, true ) ) {
			jp_json_response( false, 'File content does not match extension.' );
		}

		// Save to uploads/jp-files/
		$upload_dir   = wp_upload_dir();
		$dest_dir     = $upload_dir['basedir'] . '/jp-files/';
		wp_mkdir_p( $dest_dir );

		$obfuscated   = wp_generate_uuid4() . '.' . $ext;
		$dest_path    = $dest_dir . $obfuscated;

		if ( ! move_uploaded_file( $file['tmp_name'], $dest_path ) ) {
			jp_json_response( false, 'Failed to save file. Check server permissions.' );
		}

		$user_id      = get_current_user_id();
		$is_first     = $this->count_resumes( $user_id ) === 0;

		// Parse the resume
		$parsed       = $this->parse( $dest_path, $ext );

		// Insert DB record
		global $wpdb;
		// Root-cause fix (batch 18): unchecked $wpdb->insert() — same
		// ghost-success shape found throughout this codebase. A failed
		// write here previously still fell through to auto_populate_profile()
		// and unconditionally reported "Resume uploaded..." with a stale/0
		// resume_id, while the file just written to disk at $dest_path
		// became permanently orphaned (no DB row ever referencing it, so
		// nothing could ever list, serve, or clean it up). Now the orphaned
		// file is removed on failure and a real error is returned instead.
		$inserted = $wpdb->insert( $wpdb->prefix . 'jp_resumes', [
			'user_id'      => $user_id,
			'file_name'    => sanitize_file_name( $file['name'] ),
			'file_path'    => $dest_path,
			'file_size'    => $file['size'],
			'file_type'    => $ext,
			'is_primary'   => $is_first ? 1 : 0,
			'parsed_json'  => wp_json_encode( $parsed ),
			'completeness' => $parsed['completeness'] ?? 0,
			'created_at'   => current_time( 'mysql' ),
		], [ '%d','%s','%s','%d','%s','%d','%s','%d','%s' ] );

		if ( false === $inserted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_resumes insert failed: ' . $wpdb->last_error ), 'JP_Resume::ajax_upload user_id=' . $user_id );
			}
			@unlink( $dest_path );
			jp_json_response( false, 'Could not save your resume. Please try again.' );
			return;
		}

		$resume_id = $wpdb->insert_id;

		// Root-cause fix: parse() can return ['error'=>..., 'completeness'=>0]
		// (e.g. pdftotext/poppler-utils unavailable on shared hosting, or a
		// scanned/image-only PDF with no extractable text) and the response
		// below used to unconditionally claim "uploaded and parsed
		// successfully" regardless — candidates were told their profile was
		// auto-populated when parsing had completely failed. Auto-populate
		// only on genuine success, and tell the truth in both the message
		// and a machine-readable flag the frontend can branch on.
		$parse_failed = empty( $parsed ) || ! empty( $parsed['error'] );
		if ( ! $parse_failed ) {
			$this->auto_populate_profile( $user_id, $parsed );
		}

		jp_json_response( true, [
			'message'      => $parse_failed
				? 'Resume uploaded. We could not automatically read its contents (' . ( $parsed['error'] ?? 'unknown error' ) . ') — please fill in your profile details manually.'
				: 'Resume uploaded and parsed successfully.',
			'resume_id'    => $resume_id,
			'parsed'       => $parsed,
			'parse_failed' => $parse_failed,
		] );
	}

	// ── Parser: extracts structured data from PDF / DOCX ─────────────────────

	public function parse( string $file_path, string $ext ): array {
		if ( $ext === 'pdf' ) {
			$text = $this->extract_pdf_text( $file_path );
		} elseif ( $ext === 'docx' ) {
			$text = $this->extract_docx_text( $file_path );
		} else {
			$text = '';
		}

		if ( ! $text ) return ['error' => 'Could not extract text from file.', 'completeness' => 0];

		// Root-cause fix (gap analysis P0/P1 #92): the three heuristics below
		// (experience-years, current-title, current-company) vary enormously
		// in reliability, but were previously returned and auto-populated
		// into the live profile identically regardless. Experience years in
		// particular is weighted 25% into match scoring
		// (class-jp-matching.php::score_experience()), so a bad silent guess
		// doesn't just show a wrong number on a profile page — it actively
		// corrupts recommendation quality. *_detailed() variants now return
		// a confidence alongside the value; only 'high'-confidence fields
		// are auto-written to the candidate profile in
		// auto_populate_profile() below — 'low'-confidence guesses are still
		// returned in the API response (nothing here is hidden from the
		// candidate) but under field_confidence, so a future review-before-
		// applying UI has the signal it needs without this round having to
		// build that UI (out of scope — no React source available here).
		[ $experience_years, $experience_confidence ] = $this->extract_experience_years_detailed( $text );
		[ $current_title,    $title_confidence ]      = $this->extract_current_title_detailed( $text );

		$data = [
			'name'            => $this->extract_name( $text ),
			'email'           => $this->extract_email( $text ),
			'phone'           => $this->extract_phone( $text ),
			'skills'          => $this->extract_skills( $text ),
			'experience_years'=> $experience_years,
			'education'       => $this->extract_education( $text ),
			'current_title'   => $current_title,
			'current_company' => $this->extract_current_company( $text ),
			'linkedin_url'    => $this->extract_linkedin( $text ),
			'raw_text_length' => strlen( $text ),
		];

		// Completeness is computed before field_confidence is added below —
		// field_confidence is metadata about the other fields, not itself a
		// filled-in resume field, and must not inflate the ratio.
		$filled = array_filter( $data, fn($v) => $v && $v !== [] && $v !== 0 );
		$data['completeness'] = (int) round( count($filled) / 9 * 100 );

		// current_company has always been a single fragile regex ("at
		// Company Name") with no stronger alternative pattern, so it's
		// always 'low' confidence — included here for the same
		// review-signal reason as the other two, not because a second
		// method was added for it.
		$data['field_confidence'] = [
			'experience_years' => $experience_confidence,
			'current_title'    => $title_confidence,
			'current_company'  => 'low',
		];

		return $data;
	}

	private function extract_pdf_text( string $path ): string {
		// Root-cause fix, two parts:
		// 1. shell_exec() is frequently disabled (disable_functions) on the
		//    shared hosting this platform's own docs say it targets, and this
		//    silently returned '' with no distinguishable diagnostic from any
		//    other extraction failure — is_pdftotext_available() lets callers
		//    (and JP_Diagnostics) tell "dependency missing" apart from
		//    "this specific file couldn't be parsed."
		// 2. No timeout was enforced: a malformed/adversarial PDF could hang
		//    the shell-out (and the PHP-FPM worker serving the request)
		//    indefinitely. Wrap with a hard wall-clock timeout via `timeout`
		//    when available, falling back to running without one only if the
		//    `timeout` binary itself can't be invoked.
		if ( ! self::is_pdftotext_available() ) {
			return '';
		}
		$escaped = escapeshellarg( $path );
		$cmd     = "timeout 15 pdftotext -layout {$escaped} - 2>/dev/null";
		$text    = shell_exec( $cmd );
		if ( $text === null ) {
			// `timeout` binary itself may be unavailable in a minimal
			// container image — retry once without it rather than treating
			// every environment lacking `timeout` as a parse failure.
			$text = shell_exec( "pdftotext -layout {$escaped} - 2>/dev/null" );
		}
		return $text ?: '';
	}

	/**
	 * Whether this server can actually run pdftotext at all — used both here
	 * and by the admin diagnostics/system-health screen so a missing
	 * dependency is surfaced as an operational fact, not just an occasional
	 * "resume didn't parse" support ticket.
	 */
	public static function is_pdftotext_available(): bool {
		static $available = null;
		if ( $available !== null ) return $available;
		if ( ! function_exists( 'shell_exec' ) || in_array( 'shell_exec', array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) ), true ) ) {
			return $available = false;
		}
		$which = @shell_exec( 'command -v pdftotext 2>/dev/null' );
		return $available = ! empty( trim( (string) $which ) );
	}

	private function extract_docx_text( string $path ): string {
		// Pure-PHP DOCX extraction (unzip word/document.xml and strip tags)
		try {
			$zip = new ZipArchive();
			if ( $zip->open( $path ) !== true ) return '';
			$xml  = $zip->getFromName( 'word/document.xml' );
			$zip->close();
			if ( ! $xml ) return '';
			// Replace paragraph/run breaks with newlines before stripping
			$xml  = str_replace( ['</w:p>','</w:r>'], ["\n",' '], $xml );
			return strip_tags( $xml );
		} catch ( \Throwable ) {
			return '';
		}
	}

	private function extract_name( string $text ): string {
		// Heuristic: first non-empty line that looks like a name (2-4 words, title case)
		$lines = array_filter( array_map( 'trim', explode( "\n", $text ) ) );
		foreach ( array_slice( $lines, 0, 5 ) as $line ) {
			$words = explode( ' ', $line );
			if ( count($words) >= 2 && count($words) <= 4 ) {
				$looks_like_name = true;
				foreach ( $words as $w ) {
					if ( ! preg_match('/^[A-Z][a-z]+$/', $w) ) { $looks_like_name = false; break; }
				}
				if ( $looks_like_name ) return $line;
			}
		}
		return '';
	}

	private function extract_email( string $text ): string {
		preg_match( '/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/', $text, $m );
		return $m[0] ?? '';
	}

	private function extract_phone( string $text ): string {
		// Indian mobile: 10 digits, optionally +91 prefix
		preg_match( '/(?:\+91[\s\-]?)?[6-9]\d{9}/', $text, $m );
		return $m[0] ?? '';
	}

	private function extract_skills( string $text ): array {
		global $wpdb;
		$text_lower = strtolower( $text );

		// Load all known skills from DB
		$db_skills = $wpdb->get_results( "SELECT id, name FROM {$wpdb->prefix}jp_skills" );
		$found     = [];

		foreach ( $db_skills as $skill ) {
			$name   = $skill->name;
			$needle = strtolower( $name );
			if ( str_contains( $text_lower, $needle ) ) {
				$found[] = $name;
				continue;
			}
			// Check aliases
			$aliases = array_keys( self::SKILL_ALIASES, $name, true );
			foreach ( $aliases as $alias ) {
				if ( str_contains( $text_lower, strtolower($alias) ) ) {
					$found[] = $name;
					break;
				}
			}
		}

		// Also scan for alias → canonical name
		foreach ( self::SKILL_ALIASES as $alias => $canonical ) {
			if ( str_contains( $text_lower, $alias ) && ! in_array( $canonical, $found, true ) ) {
				$found[] = $canonical;
			}
		}

		return array_unique( $found );
	}

	/**
	 * Root-cause fix (gap analysis P0/P1 #92): the original single-return
	 * version of this method fell back to "latest year minus earliest year
	 * found ANYWHERE in the whole document" whenever no explicit "N years
	 * experience" phrase was present — a heuristic the gap analysis singled
	 * out by name as misfiring badly on resumes containing unrelated dates
	 * (a certification year, a graduation year, a publication date). That
	 * fallback estimate is now explicitly labeled 'low' confidence instead
	 * of being indistinguishable from the much more reliable explicit-
	 * phrase match, so callers (auto_populate_profile() below) can choose
	 * not to silently write a shaky guess into a field that feeds 25% of
	 * match scoring.
	 *
	 * @return array{0:int,1:string} [years, confidence ('high'|'low'|'none')]
	 */
	private function extract_experience_years_detailed( string $text ): array {
		// Match patterns like "5 years experience", "3+ years", "7 yrs" —
		// an explicit, unambiguous statement of experience length.
		if ( preg_match( '/(\d+)\+?\s*(?:years?|yrs?)\s*(?:of\s+)?(?:experience|exp)/i', $text, $m ) ) {
			return [ (int) $m[1], 'high' ];
		}
		// Fallback: span between the earliest and latest 4-digit year
		// anywhere in the document. Inherently unreliable — always 'low'.
		preg_match_all( '/\b((?:19|20)\d{2})\b/', $text, $years_found );
		if ( count( $years_found[1] ) >= 2 ) {
			$years = array_map( 'intval', $years_found[1] );
			sort( $years );
			$span = max( $years ) - min( $years );
			if ( $span > 0 && $span < 50 ) return [ $span, 'low' ];
		}
		return [ 0, 'none' ];
	}

	private function extract_education( string $text ): array {
		$degrees  = ['B.Tech','B.E.','B.Sc','BCA','MBA','MCA','M.Tech','M.Sc','Ph.D','B.Com','M.Com','BA','MA','LLB','MBBS'];
		$found    = [];
		$text_u   = strtoupper( $text );
		foreach ( $degrees as $deg ) {
			if ( str_contains( $text_u, strtoupper($deg) ) ) $found[] = $deg;
		}
		return $found;
	}

	/**
	 * Root-cause fix (gap analysis P0/P1 #92): the two patterns here are
	 * not equally reliable. The first — an explicit "Designation:"/"Role:"/
	 * "Title:" label — is a deliberate, unambiguous statement. The second —
	 * "anything at all, followed by ' at '/'@'/a dash" — matches on
	 * structure alone and can just as easily grab an unrelated line (e.g.
	 * "Based in Mumbai - available immediately" would match the "at/@/-"
	 * pattern with no title present at all). Distinguishing which pattern
	 * actually matched lets auto_populate_profile() treat them differently
	 * instead of writing either one into the profile with equal trust.
	 *
	 * @return array{0:string,1:string} [title, confidence ('high'|'low'|'none')]
	 */
	private function extract_current_title_detailed( string $text ): array {
		if ( preg_match( '/(?:designation|role|position|title)[:\s]+([^\n,]{5,60})/i', $text, $m ) ) {
			return [ trim( $m[1] ), 'high' ];
		}
		if ( preg_match( '/^([^\n]{5,60})\s+(?:at|@|–|-)\s+/im', $text, $m ) ) {
			return [ trim( $m[1] ), 'low' ];
		}
		return [ '', 'none' ];
	}

	private function extract_current_company( string $text ): string {
		// "at Company Name" or "Company Name | Year-Year"
		if ( preg_match( '/\bat\s+([A-Z][A-Za-z\s&,.]{3,50})\b/', $text, $m ) ) {
			return trim( $m[1] );
		}
		return '';
	}

	private function extract_linkedin( string $text ): string {
		preg_match( '/https?:\/\/(?:www\.)?linkedin\.com\/in\/[^\s"\'<>]+/i', $text, $m );
		return $m[0] ?? '';
	}

	// ── Auto-populate candidate profile ──────────────────────────────────────

	private function auto_populate_profile( int $user_id, array $parsed ): void {
		global $wpdb;
		$tbl  = $wpdb->prefix . 'jp_candidates';
		$data = [];

		// Root-cause fix (gap analysis P0/P1 #92): experience_years,
		// current_title, and current_company are only auto-written when
		// parse() marked them 'high' confidence. A 'low'-confidence guess
		// (e.g. the year-range fallback, or the generic "X at Y" title
		// pattern) is still returned in the API response — the candidate
		// sees it and can fill the field in themselves if it's right — but
		// is no longer silently written into a profile field that feeds
		// match scoring (score_experience() weights experience_years 25%)
		// as if it were as trustworthy as an explicit statement.
		$confidence = $parsed['field_confidence'] ?? [];
		$is_high    = fn( string $field ) => ( $confidence[ $field ] ?? 'high' ) === 'high';

		if ( !empty($parsed['phone']) ) $data['phone'] = $parsed['phone'];
		if ( !empty($parsed['experience_years']) && $is_high('experience_years') ) $data['experience_years'] = $parsed['experience_years'];
		if ( !empty($parsed['current_title']) && $is_high('current_title') )       $data['current_title']   = $parsed['current_title'];
		if ( !empty($parsed['current_company']) && $is_high('current_company') )   $data['current_company']  = $parsed['current_company'];
		if ( !empty($parsed['linkedin_url']) )     $data['linkedin_url']    = $parsed['linkedin_url'];
		// Root-cause fix (4-way skills-storage consolidation, §37): this
		// used to read/write a `skills_json` column on jp_candidates that
		// was NEVER CREATED in the schema (see class-jp-db.php's new
		// add_user_skills()/replace_user_skills() docblock for the full
		// finding). Because $data['skills_json'] was bundled into the SAME
		// $wpdb->update() call as phone/experience_years/current_title/
		// current_company/linkedin_url below, MySQL rejected the ENTIRE
		// UPDATE whenever a resume had any extractable skills (i.e. almost
		// every resume) — meaning NONE of those other fields were ever
		// saved either, not just skills. Skills are now linked separately
		// via JP_DB::add_user_skills() (the real jp_user_skills table),
		// decoupled from this $data/$wpdb->update() call entirely so a
		// resume with unparseable/no skills still correctly saves every
		// other extracted field.
		$skills_added = 0;
		if ( !empty($parsed['skills']) ) {
			$skills_added = JP_DB::instance()->add_user_skills( $user_id, $parsed['skills'] );
		}

		if ( empty($data) && ! $skills_added ) return;

		$exists = $wpdb->get_var( $wpdb->prepare("SELECT id FROM {$tbl} WHERE user_id=%d",$user_id) );
		if ( $exists ) {
			// Adjacent fix found while rewriting this method for the
			// skills consolidation: $wpdb->update() must run BEFORE
			// recalculate_score() reads the row back, not after — the
			// previous order recalculated profile_score from the row's
			// OLD (pre-update) values every time, one auto-populate cycle
			// behind whatever was actually just parsed. Harmless on its
			// own (self-corrects on the NEXT resume upload) but a real,
			// avoidable staleness bug now that skills recalculation
			// happens on every upload including this one.
			// Root-cause fix (batch 18): unchecked $wpdb->update(). Lower
			// blast radius than the resume-upload insert fixed above -- this
			// is a best-effort profile auto-fill that self-corrects on the
			// next resume upload -- but was previously silent, so a
			// persistent write failure (not just a one-off) could go
			// unnoticed indefinitely.
			if ( ! empty( $data ) ) {
				$updated = $wpdb->update( $tbl, $data, ['user_id'=>$user_id] );
				if ( false === $updated && class_exists( 'JP_ErrorLog' ) ) {
					JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_candidates auto-populate update failed: ' . $wpdb->last_error ), 'JP_Resume::auto_populate_profile user_id=' . $user_id );
				}
			}
			$this->recalculate_score( $user_id );
		}
	}

	private function recalculate_score( int $user_id ): void {
		global $wpdb;
		$tbl = $wpdb->prefix . 'jp_candidates';
		$c   = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$tbl} WHERE user_id=%d",$user_id) );
		if ( !$c ) return;

		$fields = ['headline','about','phone','location_city','experience_years','current_title','current_company','linkedin_url','github_url'];
		$score  = 0;
		foreach ( $fields as $f ) if ( !empty($c->$f) ) $score += 10;
		// Root-cause fix (§37): $c->skills_json never existed on this
		// table (SELECT * simply never returns it), so this was always
		// json_decode(null, true) === null, and count(null) is itself a
		// PHP fatal on 8+ (TypeError: count(): Argument #1 must be of
		// type Countable|array, null given) — meaning EVERY call to
		// recalculate_score() for a candidate with no legacy skills_json
		// data would fatal-error, silently aborting whatever request
		// triggered it (resume upload, profile update). Reads the real
		// jp_user_skills table instead.
		$skills = JP_DB::instance()->get_user_skill_names( $user_id );
		if ( count($skills) >= 3 ) $score += 10;

		// Root-cause fix (batch 18): unchecked write. Log-only — profile_score
		// is a derived/cached value recalculated from scratch on every call
		// to this method (resume upload, profile save, etc.), so a failed
		// write here just leaves a stale cached score until the next
		// recalculation; nothing reads this as a success/failure signal.
		if ( false === $wpdb->update( $tbl, ['profile_score'=>min(100,$score)], ['user_id'=>$user_id] ) && class_exists( 'JP_ErrorLog' ) ) {
			JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_candidates profile_score update failed: ' . $wpdb->last_error ), 'JP_Resume::recalculate_score user_id=' . $user_id );
		}
	}

	// ── TCPDF PDF export ──────────────────────────────────────────────────────

	public function ajax_get_pdf(): void {
		jp_verify_nonce('jp_general');
		if ( !is_user_logged_in() ) wp_die('Unauthorized');

		$user_id    = get_current_user_id();
		$template   = sanitize_key( $_GET['template'] ?? 'modern' );
		$sections   = $this->get_user_sections( $user_id );
		$candidate  = JP_DB::instance()->get_candidate( $user_id );
		$user       = get_userdata( $user_id );

		$pdf_path   = $this->generate_pdf( $user, $candidate, $sections, $template );
		if ( !$pdf_path ) jp_json_response(false,'PDF generation failed.');

		jp_json_response(true,['pdf_url' => str_replace(ABSPATH,site_url('/'),$pdf_path)]);
	}

	private static $resume_section_titles = [
		'summary'        => 'PROFESSIONAL SUMMARY',
		'experience'     => 'WORK EXPERIENCE',
		'education'      => 'EDUCATION',
		'skills'         => 'SKILLS',
		'projects'       => 'PROJECTS',
		'certifications' => 'CERTIFICATIONS',
		'languages'      => 'LANGUAGES',
	];

	/**
	 * Root cause fix (gap analysis P1 #96): this previously bare-returned
	 * false on missing TCPDF with no fallback, the same gap as the offer
	 * letter generator. Now shares JP_PDF's dependency probe and degrades
	 * to an HTML resume instead of failing outright.
	 */
	private function generate_pdf( $user, $candidate, array $sections, string $template ) {
		if ( !JP_PDF::ensure_available() ) {
			$contact_line = implode('  •  ', array_filter([$user->user_email, $candidate->phone??'', $candidate->location_city??'']));
			$body = '<h1>'.esc_html($user->display_name).'</h1>'
				. '<p>'.esc_html($candidate->headline??'').'<br>'.esc_html($contact_line).'</p>';
			foreach ( $sections as $key => $content ) {
				if ( empty($content) ) continue;
				$title  = self::$resume_section_titles[$key] ?? strtoupper($key);
				$body  .= '<h3 style="color:#156bc9;border-bottom:1px solid #ddd">'.esc_html($title).'</h3>'
					. '<div style="white-space:pre-wrap">'.esc_html($content).'</div>';
			}
			$html = JP_PDF::wrap_html_document($user->display_name.' — Resume', $body);
			return JP_PDF::write_html_fallback('jp-resumes','resume-'.$user->ID.'-'.time().'.html',$html);
		}

		$pdf = new \TCPDF('P','mm','A4',true,'UTF-8',false);
		$pdf->SetCreator(jp_site_name());
		$pdf->SetAuthor($user->display_name);
		$pdf->SetTitle($user->display_name . ' — Resume');
		$pdf->SetMargins(15,15,15);
		$pdf->SetAutoPageBreak(true,15);
		$pdf->AddPage();

		// ── Template: Modern ─────────────────────────────────────────────────
		$primary = '#156BC9';

		// Header
		$pdf->SetFillColor(21,107,201);
		$pdf->Rect(0,0,210,45,'F');
		$pdf->SetTextColor(255,255,255);
		$pdf->SetFont('helvetica','B',22);
		$pdf->SetXY(15,12);
		$pdf->Cell(0,10,$user->display_name,'',1,'L');
		$pdf->SetFont('helvetica','',11);
		$pdf->SetXY(15,26);
		$pdf->Cell(0,6,$candidate->headline??'',0,1,'L');
		$pdf->SetXY(15,33);
		$contact_line = implode('  •  ', array_filter([$user->user_email, $candidate->phone??'', $candidate->location_city??'']));
		$pdf->Cell(0,6,$contact_line,0,1,'L');

		// Body
		$pdf->SetTextColor(0,0,0);
		$pdf->SetY(52);

		$section_titles = [
			'summary'        => 'PROFESSIONAL SUMMARY',
			'experience'     => 'WORK EXPERIENCE',
			'education'      => 'EDUCATION',
			'skills'         => 'SKILLS',
			'projects'       => 'PROJECTS',
			'certifications' => 'CERTIFICATIONS',
			'languages'      => 'LANGUAGES',
		];

		foreach ( $sections as $key => $content ) {
			if ( empty($content) ) continue;
			$title = $section_titles[$key] ?? strtoupper($key);

			// Section heading
			$pdf->SetFillColor(240,245,255);
			$pdf->SetFont('helvetica','B',9);
			$pdf->SetTextColor(21,107,201);
			$pdf->Cell(0,7,$title,'B',1,'L',true);
			$pdf->Ln(2);

			// Section content
			$pdf->SetFont('helvetica','',10);
			$pdf->SetTextColor(50,50,50);
			$pdf->MultiCell(0,5,$content,0,'L');
			$pdf->Ln(4);
		}

		// Footer
		$pdf->SetY(-15);
		$pdf->SetFont('helvetica','I',8);
		$pdf->SetTextColor(150,150,150);
		$pdf->Cell(0,10,'Generated by '.jp_site_name().' • '.date('j F Y'),0,0,'C');

		// Save to uploads
		$dir      = wp_upload_dir()['basedir'].'/jp-resumes/';
		wp_mkdir_p($dir);
		$path     = $dir . 'resume-' . $user->ID . '-' . time() . '.pdf';
		$pdf->Output($path,'F');
		return $path;
	}

	private function get_user_sections( int $user_id ): array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare(
			"SELECT section,content FROM {$wpdb->prefix}jp_resume_sections WHERE user_id=%d ORDER BY sort_order ASC",
			$user_id
		));
		$sections = [];
		foreach ($rows as $r) $sections[$r->section] = $r->content;
		return $sections;
	}

	// ── AJAX helpers ──────────────────────────────────────────────────────────

	public function ajax_delete(): void {
		jp_verify_nonce('jp_general');
		global $wpdb;
		$id  = absint( $_POST['resume_id'] ?? 0 );
		$uid = get_current_user_id();
		$row = $wpdb->get_row( $wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_resumes WHERE id=%d AND user_id=%d",$id,$uid) );
		if ( !$row ) { jp_json_response(false,'Resume not found.'); return; }
		if ( file_exists($row->file_path) ) @unlink($row->file_path);
		// Root-cause fix (batch 18): unchecked $wpdb->delete() -- a failed
		// delete previously still reported "Resume deleted." while the row
		// (now pointing at a file already unlinked above) stayed in the DB,
		// leaving a dangling reference a later download/PDF-export would
		// fail against with no explanation.
		$deleted = $wpdb->delete($wpdb->prefix.'jp_resumes',['id'=>$id,'user_id'=>$uid]);
		if ( false === $deleted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_resumes delete failed: ' . $wpdb->last_error ), 'JP_Resume::ajax_delete resume_id=' . $id );
			}
			jp_json_response( false, 'Could not delete this resume. Please try again.' );
			return;
		}
		jp_json_response(true,['message'=>'Resume deleted.']);
	}

	public function ajax_set_primary(): void {
		jp_verify_nonce('jp_general');
		global $wpdb;
		$id  = absint($_POST['resume_id']??0);
		$uid = get_current_user_id();
		// Root-cause fix (batch 18): both writes were unchecked. Most
		// consequential failure mode: the first (unset-all) succeeds but the
		// second (set-new-primary) fails -- previously reported "Primary
		// resume updated." while the candidate was left with NO primary
		// resume at all (worse than before the call), silently breaking
		// whatever auto-attach-primary-resume behavior depends on one
		// existing.
		$wpdb->update($wpdb->prefix.'jp_resumes',['is_primary'=>0],['user_id'=>$uid]);
		$set = $wpdb->update($wpdb->prefix.'jp_resumes',['is_primary'=>1],['id'=>$id,'user_id'=>$uid]);
		if ( false === $set || 0 === $set ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_resumes set-primary failed or matched no row: ' . $wpdb->last_error ), 'JP_Resume::ajax_set_primary resume_id=' . $id . ' user_id=' . $uid );
			}
			jp_json_response( false, 'Could not set this resume as primary. Please try again.' );
			return;
		}
		jp_json_response(true,['message'=>'Primary resume updated.']);
	}

	public function ajax_save_section(): void {
		jp_verify_nonce('jp_general');
		global $wpdb;
		$uid     = get_current_user_id();
		$section = sanitize_key($_POST['section']??'');
		$content = sanitize_textarea_field($_POST['content']??'');
		$allowed = ['summary','experience','education','skills','projects','certifications','languages','awards'];
		if ( !in_array($section,$allowed,true) ) jp_json_response(false,'Invalid section.');
		$exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM {$wpdb->prefix}jp_resume_sections WHERE user_id=%d AND section=%s",$uid,$section));
		// Root-cause fix (batch 18): both branches of this upsert were
		// unchecked -- a failed write told the candidate "Section saved."
		// while their resume-builder content (summary/experience/etc.) was
		// silently discarded, indistinguishable from having actually saved
		// until they reloaded the page and found it gone.
		if ($exists) {
			$ok = $wpdb->update($wpdb->prefix.'jp_resume_sections',['content'=>$content,'updated_at'=>current_time('mysql')],['user_id'=>$uid,'section'=>$section]);
		} else {
			$ok = $wpdb->insert($wpdb->prefix.'jp_resume_sections',['user_id'=>$uid,'section'=>$section,'content'=>$content,'created_at'=>current_time('mysql'),'updated_at'=>current_time('mysql')],['%d','%s','%s','%s','%s']);
		}
		if ( false === $ok ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_resume_sections upsert failed: ' . $wpdb->last_error ), 'JP_Resume::ajax_save_section user_id=' . $uid . ' section=' . $section );
			}
			jp_json_response( false, 'Could not save this section. Please try again.' );
			return;
		}
		jp_json_response(true,['message'=>'Section saved.']);
	}

	public function ajax_download(): void {
		jp_verify_nonce('jp_general');
		$uid = get_current_user_id();
		$id  = absint($_GET['resume_id']??0);
		global $wpdb;
		$row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_resumes WHERE id=%d AND user_id=%d",$id,$uid));
		if (!$row || !file_exists($row->file_path)) wp_die('Resume not found');
		header('Content-Type: application/octet-stream');
		header('Content-Disposition: attachment; filename="'.esc_attr($row->file_name).'"');
		header('Content-Length: '.filesize($row->file_path));
		readfile($row->file_path);
		exit;
	}

	private function count_resumes( int $user_id ): int {
		global $wpdb;
		return (int)$wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM {$wpdb->prefix}jp_resumes WHERE user_id=%d",$user_id));
	}
}
