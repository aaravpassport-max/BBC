<?php
defined( 'ABSPATH' ) || exit;

/**
 * JP_Activator
 * Runs on plugin activation: creates all 27 custom tables, all 6 roles,
 * all platform pages, and seeds option defaults.
 */
class JP_Activator {

    // ── Entry points ──────────────────────────────────────────────────────────

    /**
     * Run on every plugin update (version mismatch detected on plugins_loaded).
     * Lighter than full activate() — only runs migrations, not page/role/option setup.
     */
    public static function run_upgrade(): void {
        self::create_tables();
        self::ensure_fulltext_indexes();
        self::ensure_missing_tables();
        // Reschedule any missing crons (safe — checks before scheduling)
        if ( class_exists( 'JP_Cron' ) ) {
            JP_Cron::schedule_all();
        }
    }

    /**
     * CREATE TABLE IF NOT EXISTS for tables that dbDelta may have silently skipped.
     * Uses direct SQL (not dbDelta) to guarantee the table exists.
     * Idempotent: safe to call on every request.
     * Called on every plugins_loaded via the bootstrap in jp-core.php.
     */
    public static function ensure_missing_tables(): void {
        global $wpdb;
        $p       = $wpdb->prefix;
        $charset = $wpdb->get_charset_collate();

        // jp_assessment_questions — previously failed silently due to dbDelta
        // COMMENT clauses and hardcoded ENGINE= string. Now uses direct CREATE TABLE IF NOT EXISTS.
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$p}jp_assessment_questions'" ) !== "{$p}jp_assessment_questions" ) {
            $wpdb->query(
                "CREATE TABLE IF NOT EXISTS `{$p}jp_assessment_questions` (
                    `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `skill_id`      BIGINT UNSIGNED NOT NULL,
                    `question`      TEXT NOT NULL,
                    `options_json`  TEXT NOT NULL,
                    `correct_index` TINYINT UNSIGNED NOT NULL DEFAULT 0,
                    `explanation`   TEXT,
                    `difficulty`    ENUM('easy','medium','hard') DEFAULT 'medium',
                    `is_active`     TINYINT(1) DEFAULT 1,
                    `created_by`    BIGINT UNSIGNED DEFAULT NULL,
                    `created_at`    DATETIME DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    KEY `skill_id` (`skill_id`),
                    KEY `is_active` (`is_active`)
                ) {$charset}"
            );
        }

        // jp_audit_log — previously failed silently because a multi-line SQL
        // comment embedded in its column list broke dbDelta()'s line-based
        // parser (see the fix at that table's definition in create_tables()
        // for the full explanation). Sites that already activated with the
        // broken SQL will never see the corrected version from create_tables()
        // run again on their own, since dbDelta() is only invoked from
        // create_tables()/run_upgrade(), and run_upgrade() only fires on an
        // actual version bump — never on a fresh install (see JP_Cron's
        // schedule_all() self-heal in class-jp-react.php for the identical
        // "never fires on fresh install" root cause explained in full).
        // Direct CREATE TABLE IF NOT EXISTS here guarantees it regardless.
        if ( $wpdb->get_var( "SHOW TABLES LIKE '{$p}jp_audit_log'" ) !== "{$p}jp_audit_log" ) {
            $wpdb->query(
                "CREATE TABLE IF NOT EXISTS `{$p}jp_audit_log` (
                    `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `user_id`    BIGINT UNSIGNED NOT NULL,
                    `action`     VARCHAR(100)    NOT NULL,
                    `object`     VARCHAR(100),
                    `object_id`  BIGINT UNSIGNED DEFAULT 0,
                    `detail`     TEXT,
                    `ip`         VARCHAR(45),
                    `ua`         VARCHAR(255),
                    `company_id` BIGINT UNSIGNED DEFAULT NULL,
                    `created_at` DATETIME DEFAULT CURRENT_TIMESTAMP,
                    `prev_hash`  VARCHAR(64) DEFAULT NULL,
                    `hash`       VARCHAR(64) DEFAULT NULL,
                    PRIMARY KEY (`id`),
                    KEY `user_id` (`user_id`),
                    KEY `action` (`action`),
                    KEY `company_id` (`company_id`),
                    KEY `created_at` (`created_at`)
                ) {$charset}"
            );
        }

        // Root-cause fix (enterprise-hardening pass): the two explicit
        // blocks above only self-heal the two tables that are ALREADY KNOWN
        // to have failed dbDelta silently in the past. That is reactive, not
        // robust — the same dbDelta silent-failure class of bug (a
        // formatting quirk, a reserved word, a future edit that
        // reintroduces an inline comment) could affect any of this plugin's
        // ~34 tables next, and on a fresh install nothing would ever notice
        // or self-heal it: run_upgrade() (which re-runs the FULL dbDelta
        // pass via create_tables()) is only ever triggered by a version-bump
        // check in jp-core.php's bootstrap that a fresh install's own
        // set_defaults() call defeats before the first normal page load
        // even happens (jp_installed_version is set to the current version
        // during activation itself). This function, by contrast, IS called
        // unconditionally on every single request. So: do one cheap
        // SHOW TABLES sweep for every table this plugin expects, and if
        // ANYTHING is missing beyond the two explicitly-handled cases above,
        // fall back to a full create_tables() pass — the same idempotent
        // dbDelta call activation itself uses — rather than silently doing
        // nothing and leaving a feature broken until someone happens to
        // notice and file a bug report.
        static $expected_tables = [
            'jp_jobs', 'jp_companies', 'jp_candidates', 'jp_applications',
            'jp_app_history', 'jp_resumes', 'jp_resume_sections',
            'jp_message_threads', 'jp_messages', 'jp_notifications',
            'jp_alerts', 'jp_saved_jobs', 'jp_matches', 'jp_reviews',
            'jp_plans', 'jp_subscriptions', 'jp_payments', 'jp_skills',
            'jp_user_skills', 'jp_assessments', 'jp_assessment_questions',
            'jp_sms_log', 'jp_push_subscriptions', 'jp_interviews',
            'jp_events', 'jp_event_registrations', 'jp_search_log',
            'jp_analytics', 'jp_analytics_agg', 'jp_audit_log',
            'jp_community_posts', 'jp_community_replies', 'jp_user_badges',
            'jp_feature_flags', 'jp_canned_responses', 'jp_interview_panelists',
            'jp_esign_envelopes', 'jp_job_feed_imports', 'jp_match_dismissals',
            'jp_saved_candidates',
        ];

        // One query instead of 34 — list every jp_ table that actually
        // exists, then diff in PHP.
        $existing = $wpdb->get_col( "SHOW TABLES LIKE '{$p}jp\\_%'" );
        $existing = array_map( fn( $t ) => substr( $t, strlen( $p ) ), $existing );
        $missing  = array_diff( $expected_tables, $existing );

        if ( ! empty( $missing ) ) {
            self::create_tables();
            error_log( 'JP_Activator::ensure_missing_tables — self-healed missing table(s) via full create_tables() pass: ' . implode( ', ', $missing ) );
        }
    }

    public static function activate(): void {
        self::create_tables();
        JP_Roles::create_roles();
        self::create_pages();
        self::set_defaults();
        // Root-cause fix: flush_rewrite_rules() must run AFTER WordPress has
        // (re-)registered every post type for the current request — but the
        // very request that fires this activation hook is the SAME request
        // where the plugin's own add_action('init', ...) registrations
        // (including JP_CPT::register_post_types(), which is what makes
        // has_archive => false actually take effect) never run at all: this
        // plugin wasn't in the active_plugins list yet when that request's
        // 'init' fired, so its init hooks are only registered starting on
        // the NEXT request. Flushing directly here would bake in whatever
        // rewrite rules existed from LAST time — on a fresh install, that
        // can still include a stale jp_job/jp_company archive rule and
        // reproduce the exact /jobs//companies/ redirect loop this version
        // fixes. Deferring via a flag, consumed on a later 'init' priority
        // 999 (registered in jp-core.php), guarantees the flush only
        // happens once post types are definitely, correctly registered.
        update_option( 'jp_needs_rewrite_flush', 1 );
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
        // Cron cleanup handled by JP_Cron
        wp_clear_scheduled_hook( 'jp_hourly_cron' );
        wp_clear_scheduled_hook( 'jp_daily_cron' );
        wp_clear_scheduled_hook( 'jp_weekly_cron' );
    }

    public static function uninstall(): void {
        // Only full-wipe if owner explicitly enabled it in settings
        if ( get_option( 'jp_uninstall_wipe_data' ) !== '1' ) return;
        self::drop_tables();
        self::delete_options();
    }

    // ── Database tables ───────────────────────────────────────────────────────

    private static function create_tables(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $charset = $wpdb->get_charset_collate();
        $p       = $wpdb->prefix;

        $tables = [];

        // 1. Jobs
        $tables[] = "CREATE TABLE {$p}jp_jobs (
            id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            company_id       BIGINT UNSIGNED NOT NULL DEFAULT 0,
            posted_by        BIGINT UNSIGNED NOT NULL DEFAULT 0,
            title            VARCHAR(200)    NOT NULL,
            slug             VARCHAR(220)    NOT NULL,
            description      LONGTEXT,
            requirements     LONGTEXT,
            skills_json      LONGTEXT,
            screening_q      LONGTEXT,
            job_type         ENUM('full-time','part-time','contract','internship','freelance') DEFAULT 'full-time',
            work_mode        ENUM('onsite','remote','hybrid') DEFAULT 'onsite',
            experience_min   TINYINT UNSIGNED DEFAULT 0,
            experience_max   TINYINT UNSIGNED DEFAULT 0,
            location_city    VARCHAR(100),
            location_state   VARCHAR(100),
            location_lat     DECIMAL(10,7)   DEFAULT NULL,
            location_lng     DECIMAL(10,7)   DEFAULT NULL,
            salary_min       BIGINT UNSIGNED DEFAULT 0,
            salary_max       BIGINT UNSIGNED DEFAULT 0,
            salary_currency  VARCHAR(5)      DEFAULT 'INR',
            salary_visible   TINYINT(1)      DEFAULT 1,
            status           ENUM('draft','pending','active','paused','expired','filled','rejected','archived') DEFAULT 'pending',
            rejection_reason VARCHAR(500)    DEFAULT NULL,
            is_featured      TINYINT(1)      DEFAULT 0,
            is_urgent        TINYINT(1)      DEFAULT 0,
            views_count      INT UNSIGNED    DEFAULT 0,
            applications_cnt INT UNSIGNED    DEFAULT 0,
            created_at       DATETIME        DEFAULT CURRENT_TIMESTAMP,
            updated_at       DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            expires_at       DATETIME,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug),
            KEY company_id (company_id),
            KEY status_expires (status, expires_at),
            KEY is_featured (is_featured),
            KEY location_city (location_city),
            KEY created_at (created_at)
        ) $charset;";

        // 2. Companies
        $tables[] = "CREATE TABLE {$p}jp_companies (
            id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id          BIGINT UNSIGNED NOT NULL,
            name             VARCHAR(200)    NOT NULL,
            slug             VARCHAR(220)    NOT NULL,
            description      LONGTEXT,
            logo_url         VARCHAR(500),
            cover_url        VARCHAR(500),
            website          VARCHAR(300),
            email            VARCHAR(150),
            phone            VARCHAR(30),
            industry         VARCHAR(100),
            size_range       VARCHAR(50),
            founded_year     SMALLINT UNSIGNED,
            headquarters     VARCHAR(200),
            social_json      LONGTEXT,
            is_verified      TINYINT(1)      DEFAULT 0,
            is_featured      TINYINT(1)      DEFAULT 0,
            rating_avg       DECIMAL(3,2)    DEFAULT 0.00,
            reviews_count    INT UNSIGNED    DEFAULT 0,
            jobs_count       INT UNSIGNED    DEFAULT 0,
            /* Root-cause fix: the public company page previously rendered
               these four aspect scores with rand(60,90) instead of real
               data, since no columns existed to pull real averages from.
               recalculate_rating() now maintains these. */
            rating_wlb_avg     DECIMAL(3,2)  DEFAULT 0.00,
            rating_growth_avg  DECIMAL(3,2)  DEFAULT 0.00,
            rating_mgmt_avg    DECIMAL(3,2)  DEFAULT 0.00,
            rating_pay_avg     DECIMAL(3,2)  DEFAULT 0.00,
            status           ENUM('pending','active','suspended') DEFAULT 'pending',
            created_at       DATETIME        DEFAULT CURRENT_TIMESTAMP,
            updated_at       DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug),
            KEY user_id (user_id),
            KEY is_verified (is_verified),
            KEY status (status)
        ) $charset;";

        // 3. Candidates (extended profile)
        $tables[] = "CREATE TABLE {$p}jp_candidates (
            id                  BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id             BIGINT UNSIGNED NOT NULL,
            headline            VARCHAR(300),
            about               LONGTEXT,
            avatar_url          VARCHAR(500),
            phone               VARCHAR(30),
            location_city       VARCHAR(100),
            location_state      VARCHAR(100),
            experience_years    TINYINT UNSIGNED DEFAULT 0,
            current_title       VARCHAR(200),
            current_company     VARCHAR(200),
            current_salary      BIGINT UNSIGNED  DEFAULT 0,
            expected_salary_min BIGINT UNSIGNED  DEFAULT 0,
            expected_salary_max BIGINT UNSIGNED  DEFAULT 0,
            notice_period_days  SMALLINT UNSIGNED DEFAULT 0,
            willing_to_relocate TINYINT(1)       DEFAULT 0,
            preferred_work_mode ENUM('any','onsite','remote','hybrid') DEFAULT 'any',
            education_json      LONGTEXT,
            experience_json     LONGTEXT,
            certifications_json LONGTEXT,
            languages_json      LONGTEXT,
            portfolio_url       VARCHAR(300),
            linkedin_url        VARCHAR(300),
            github_url          VARCHAR(300),
            profile_score       TINYINT UNSIGNED DEFAULT 0,
            is_open_to_work     TINYINT(1)       DEFAULT 1,
            visibility          ENUM('public','recruiters','private') DEFAULT 'public',
            last_active         DATETIME,
            created_at          DATETIME         DEFAULT CURRENT_TIMESTAMP,
            updated_at          DATETIME         DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_id (user_id),
            KEY location_city (location_city),
            KEY is_open_to_work (is_open_to_work),
            KEY profile_score (profile_score)
        ) $charset;";

        // 4. Applications
        // Batch 37 (recruiter ATS pipeline depth): added `tags` — a
        // JSON-encoded array of free-text labels (e.g. "strong-culture-fit",
        // "needs-visa-sponsorship") a recruiter can attach to an application
        // for filtering/organizing a pipeline, mirroring the notes/
        // stage_history JSON-column convention already used on this table.
        // Kept as a single JSON column rather than a join table since tags
        // here are per-application free text, not a shared controlled
        // vocabulary — consistent with `notes`/`stage_history` above.
        $tables[] = "CREATE TABLE {$p}jp_applications (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            job_id          BIGINT UNSIGNED NOT NULL,
            candidate_id    BIGINT UNSIGNED NOT NULL,
            company_id      BIGINT UNSIGNED NOT NULL,
            resume_id       BIGINT UNSIGNED DEFAULT 0,
            cover_letter    LONGTEXT,
            screening_ans   LONGTEXT,
            stage           ENUM('applied','shortlisted','viewed','phone_screen','interview','assessment','offer','hired','rejected','withdrawn') DEFAULT 'applied',
            stage_history   LONGTEXT,
            match_score     TINYINT UNSIGNED DEFAULT 0,
            notes           TEXT,
            interview_date  DATETIME        DEFAULT NULL,
            offer_ctc       BIGINT UNSIGNED DEFAULT 0,
            offer_pdf_url       VARCHAR(500) DEFAULT NULL,
            offer_status        ENUM('none','sent','accepted','declined') DEFAULT 'none',
            offer_responded_at  DATETIME DEFAULT NULL,
            source          VARCHAR(50)     DEFAULT 'direct',
            tags            LONGTEXT,
            created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
            updated_at      DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY job_candidate (job_id, candidate_id),
            KEY job_id (job_id),
            KEY candidate_id (candidate_id),
            KEY company_id (company_id),
            KEY stage (stage),
            KEY created_at (created_at)
        ) $charset;";

        // 5. Application history (audit trail per application)
        $tables[] = "CREATE TABLE {$p}jp_app_history (
            id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            application_id BIGINT UNSIGNED NOT NULL,
            changed_by     BIGINT UNSIGNED NOT NULL,
            from_stage     VARCHAR(50),
            to_stage       VARCHAR(50),
            note           TEXT,
            created_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY application_id (application_id),
            KEY created_at (created_at)
        ) $charset;";

        // 6. Resumes
        $tables[] = "CREATE TABLE {$p}jp_resumes (
            id               BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id          BIGINT UNSIGNED NOT NULL,
            file_path        VARCHAR(500),
            file_name        VARCHAR(255),
            file_size        INT UNSIGNED    DEFAULT 0,
            parsed_json      LONGTEXT,
            parsed_at        DATETIME        DEFAULT NULL,
            completeness     TINYINT UNSIGNED DEFAULT 0,
            is_primary       TINYINT(1)       DEFAULT 0,
            created_at       DATETIME         DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY is_primary (is_primary)
        ) $charset;";

        // 7. Resume sections (for in-browser builder)
        $tables[] = "CREATE TABLE {$p}jp_resume_sections (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id     BIGINT UNSIGNED NOT NULL,
            section     VARCHAR(50)     NOT NULL,
            sort_order  TINYINT UNSIGNED DEFAULT 0,
            content     LONGTEXT,
            updated_at  DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id_section (user_id, section)
        ) $charset;";

        // 8. Message threads
        $tables[] = "CREATE TABLE {$p}jp_message_threads (
            id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            job_id         BIGINT UNSIGNED DEFAULT 0,
            application_id BIGINT UNSIGNED DEFAULT 0,
            recruiter_id   BIGINT UNSIGNED NOT NULL,
            candidate_id   BIGINT UNSIGNED NOT NULL,
            subject        VARCHAR(300),
            last_message   TEXT,
            last_at        DATETIME        DEFAULT CURRENT_TIMESTAMP,
            unread_count   INT UNSIGNED    DEFAULT 0,
            is_archived    TINYINT(1)      DEFAULT 0,
            created_at     DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY recruiter_id (recruiter_id),
            KEY candidate_id (candidate_id),
            KEY last_at (last_at)
        ) $charset;";

        // 9. Messages
        $tables[] = "CREATE TABLE {$p}jp_messages (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            thread_id   BIGINT UNSIGNED NOT NULL,
            sender_id   BIGINT UNSIGNED NOT NULL,
            body        LONGTEXT        NOT NULL,
            attachments LONGTEXT,
            is_read     TINYINT(1)      DEFAULT 0,
            created_at  DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY thread_id (thread_id),
            KEY sender_id (sender_id),
            KEY is_read (is_read)
        ) $charset;";

        // 10. Notifications
        $tables[] = "CREATE TABLE {$p}jp_notifications (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id    BIGINT UNSIGNED NOT NULL,
            type       VARCHAR(80)     NOT NULL,
            title      VARCHAR(300),
            body       TEXT,
            url        VARCHAR(500),
            meta_json  LONGTEXT,
            is_read    TINYINT(1)      DEFAULT 0,
            created_at DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id_read (user_id, is_read),
            KEY created_at (created_at)
        ) $charset;";

        // 11. Job alerts
        $tables[] = "CREATE TABLE {$p}jp_alerts (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id      BIGINT UNSIGNED NOT NULL,
            name         VARCHAR(200),
            keywords     VARCHAR(300),
            location     VARCHAR(200),
            job_type     VARCHAR(50),
            work_mode    VARCHAR(50),
            salary_min   BIGINT UNSIGNED DEFAULT 0,
            experience   TINYINT UNSIGNED DEFAULT 0,
            skills_json  LONGTEXT,
            frequency    ENUM('instant','daily','weekly') DEFAULT 'daily',
            channel      ENUM('email','sms','both')       DEFAULT 'email',
            is_active    TINYINT(1)      DEFAULT 1,
            last_sent    DATETIME        DEFAULT NULL,
            created_at   DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY is_active (is_active),
            KEY frequency (frequency)
        ) $charset;";

        // 12. Saved jobs
        $tables[] = "CREATE TABLE {$p}jp_saved_jobs (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id    BIGINT UNSIGNED NOT NULL,
            job_id     BIGINT UNSIGNED NOT NULL,
            note       VARCHAR(300),
            saved_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_job (user_id, job_id),
            KEY user_id (user_id)
        ) $charset;";

        // 13. Matches (pre-computed)
        $tables[] = "CREATE TABLE {$p}jp_matches (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            job_id       BIGINT UNSIGNED NOT NULL,
            candidate_id BIGINT UNSIGNED NOT NULL,
            score        TINYINT UNSIGNED DEFAULT 0,
            score_detail LONGTEXT,
            computed_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY job_candidate (job_id, candidate_id),
            KEY score (score),
            KEY computed_at (computed_at)
        ) $charset;";

        // 14. Company reviews
        $tables[] = "CREATE TABLE {$p}jp_reviews (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            company_id      BIGINT UNSIGNED NOT NULL,
            user_id         BIGINT UNSIGNED NOT NULL,
            title           VARCHAR(300),
            pros            TEXT,
            cons            TEXT,
            rating_overall  TINYINT UNSIGNED DEFAULT 0,
            rating_wlb      TINYINT UNSIGNED DEFAULT 0,
            rating_growth   TINYINT UNSIGNED DEFAULT 0,
            rating_mgmt     TINYINT UNSIGNED DEFAULT 0,
            rating_pay      TINYINT UNSIGNED DEFAULT 0,
            employment_type ENUM('current','former','interviewer') DEFAULT 'current',
            job_title       VARCHAR(200),
            is_anonymous    TINYINT(1) DEFAULT 0,
            status          ENUM('pending','approved','rejected') DEFAULT 'pending',
            helpful_count   INT UNSIGNED DEFAULT 0,
            /* Root-cause fix: JP_Reviews::ajax_reply()/is_verified logic
               referenced these columns, and ajax_vote() referenced a
               votes_helpful column, none of which existed in this table —
               every company reply and every verified-employee flag was
               being silently dropped by wpdb insert/update field-list
               mismatch, and vote clicks were failing outright against a
               column that did not exist. */
            is_verified     TINYINT(1) DEFAULT 0,
            company_reply   TEXT,
            replied_at      DATETIME NULL,
            replied_by      BIGINT UNSIGNED NULL,
            created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY company_user (company_id, user_id),
            KEY company_id (company_id),
            KEY status (status)
        ) $charset;";

        // 14b. Team members — Phase 2 remediation of gap-analysis §1: the
        // jp_team_manager role, its capabilities (jp_manage_team,
        // jp_assign_jobs, jp_view_team_analytics), and the team_seats plan
        // credit (JP_Subscriptions::PLAN_CREDITS) all existed with no
        // backing data model at all — a company could never actually add a
        // second recruiter. This table plus class-jp-team.php (JP_Team) is
        // that missing infrastructure.
        $tables[] = "CREATE TABLE {$p}jp_team_members (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            company_id    BIGINT UNSIGNED NOT NULL,
            user_id       BIGINT UNSIGNED NULL,
            invited_email VARCHAR(150) NOT NULL,
            role          ENUM('owner','manager','member') DEFAULT 'member',
            status        ENUM('invited','active','removed') DEFAULT 'invited',
            invited_by    BIGINT UNSIGNED NOT NULL,
            invite_token  VARCHAR(64) NULL,
            invited_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
            accepted_at   DATETIME NULL,
            removed_at    DATETIME NULL,
            PRIMARY KEY (id),
            UNIQUE KEY company_email (company_id, invited_email),
            KEY company_id (company_id),
            KEY user_id (user_id),
            KEY status (status),
            KEY invite_token (invite_token)
        ) $charset;";

        // 14b. Webhook delivery log — Phase 2 remediation. Webhooks were
        // fully configurable (CRUD + test-send) in the admin UI but were
        // never actually dispatched on any real platform event (see
        // enterprise-gap-analysis.md §0/"webhooks configurable but never
        // dispatched" — P0). class-jp-webhooks.php (JP_Webhooks) hooks the
        // existing do_action() call sites and writes one row per delivery
        // attempt here, so admins can see delivery history/failures instead
        // of the previous single serialized wp_options row with no history
        // at all.
        // 14a-2. Webhook subscriptions — root-cause fix (gap analysis P1
        // #139: "Webhooks are stored as a single serialized array inside
        // one wp_options row, not a proper table — a scale ceiling for both
        // performance (full deserialization on every load if autoloaded)
        // and data safety (concurrent admin edits race non-atomically on
        // read-modify-write)"). Two admins editing webhooks at the same
        // moment previously did get_option() → mutate the in-PHP array →
        // update_option() each, so whichever write landed second silently
        // discarded the other's change — a classic lost-update race with no
        // warning to either admin. A real table with per-row inserts/
        // updates/deletes makes each CRUD operation atomic at the DB layer
        // instead of racing on a shared blob. The existing
        // jp_webhook_deliveries.webhook_id column is already VARCHAR(64) to
        // match the 'wh_...' string IDs this feature has always generated,
        // so this table keeps that same string as its primary key — no
        // change needed to the deliveries table or its foreign references.
        // See migrations/0002_webhooks_option_to_table.php for the one-time
        // move of any pre-existing option data into this table.
        $tables[] = "CREATE TABLE {$p}jp_webhooks (
            id          VARCHAR(64)  NOT NULL,
            url         VARCHAR(500) NOT NULL,
            events_json TEXT,
            secret      VARCHAR(100) NOT NULL,
            active      TINYINT(1)   NOT NULL DEFAULT 1,
            created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id)
        ) $charset;";

        $tables[] = "CREATE TABLE {$p}jp_webhook_deliveries (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            webhook_id    VARCHAR(64)     NOT NULL,
            event         VARCHAR(100)    NOT NULL,
            payload_json  LONGTEXT,
            status        ENUM('pending','delivered','failed') DEFAULT 'pending',
            http_code     SMALLINT UNSIGNED NULL,
            response_body TEXT,
            attempt       TINYINT UNSIGNED DEFAULT 1,
            next_retry_at DATETIME NULL,
            created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
            delivered_at  DATETIME NULL,
            PRIMARY KEY (id),
            KEY webhook_id (webhook_id),
            KEY status (status),
            KEY next_retry_at (next_retry_at)
        ) $charset;";

        // 14c. Background job queue — Phase 2 remediation of gap-analysis
        // P1 "no queue system anywhere". See class-jp-queue.php (JP_Queue)
        // for the full design (atomic claiming, retry/backoff, dead-letter
        // state). status transitions: pending -> claimed -> completed, or
        // pending -> claimed -> pending (retry, backoff via available_at)
        // -> ... -> dead_letter (attempts exhausted).
        $tables[] = "CREATE TABLE {$p}jp_job_queue (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            hook          VARCHAR(150)    NOT NULL,
            args_json     LONGTEXT,
            status        ENUM('pending','claimed','completed','failed','dead_letter') DEFAULT 'pending',
            attempts      TINYINT UNSIGNED DEFAULT 0,
            max_attempts  TINYINT UNSIGNED DEFAULT 5,
            available_at  DATETIME NOT NULL,
            claimed_by    VARCHAR(20) NULL,
            claimed_at    DATETIME NULL,
            last_error    TEXT NULL,
            created_at    DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            completed_at  DATETIME NULL,
            PRIMARY KEY (id),
            KEY status_available (status, available_at),
            KEY hook (hook)
        ) $charset;";

        // 14d. Cron run history — Phase 2 remediation of gap-analysis P0
        // #60 ("jp_last_cron_run is read by admin_health() but never
        // written by anything") and P1 #116 ("no cron job success/failure
        // monitoring"). See class-jp-cron.php's run_monitored().
        $tables[] = "CREATE TABLE {$p}jp_cron_runs (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            hook         VARCHAR(100)    NOT NULL,
            status       ENUM('running','success','failed') DEFAULT 'running',
            started_at   DATETIME NOT NULL,
            finished_at  DATETIME NULL,
            duration_ms  INT UNSIGNED NULL,
            error        TEXT NULL,
            PRIMARY KEY (id),
            KEY hook_started (hook, started_at)
        ) $charset;";

        // 14e. Centralized error log — Phase 2 remediation of gap-analysis
        // P0 #59/#156 ("no centralized error/exception logging or
        // alerting anywhere"). See class-jp-errorlog.php (JP_ErrorLog).
        $tables[] = "CREATE TABLE {$p}jp_error_log (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            fingerprint   CHAR(32)        NOT NULL,
            level         VARCHAR(30)     NOT NULL,
            message       VARCHAR(2000),
            file          VARCHAR(500),
            line          INT UNSIGNED,
            trace         TEXT,
            occurrences   INT UNSIGNED    DEFAULT 1,
            first_seen_at DATETIME NOT NULL,
            last_seen_at  DATETIME NOT NULL,
            PRIMARY KEY (id),
            KEY fingerprint_seen (fingerprint, last_seen_at),
            KEY level (level),
            KEY last_seen_at (last_seen_at)
        ) $charset;";

        // 14c. Community post likes — root-cause fix. community_like_post()
        // in class-jp-api.php previously did an unconditional
        // `likes = likes + 1` with zero per-user tracking: any authenticated
        // user could call the (auth-gated but otherwise unlimited) endpoint
        // repeatedly and inflate a post's like count without bound, and
        // there was no way to "unlike" or know whether a given user had
        // already liked a post. This join table gives the endpoint a real
        // per-user toggle with a UNIQUE constraint enforcing "at most one
        // like per user per post" at the database layer, not just in
        // application logic.
        $tables[] = "CREATE TABLE {$p}jp_community_likes (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id    BIGINT UNSIGNED NOT NULL,
            user_id    BIGINT UNSIGNED NOT NULL,
            created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY post_user (post_id, user_id),
            KEY post_id (post_id),
            KEY user_id (user_id)
        ) $charset;";

        // 15. Plans
        $tables[] = "CREATE TABLE {$p}jp_plans (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name            VARCHAR(100)    NOT NULL,
            slug            VARCHAR(100)    NOT NULL,
            description     TEXT,
            price_monthly   INT UNSIGNED    DEFAULT 0,
            price_yearly    INT UNSIGNED    DEFAULT 0,
            currency        CHAR(3)         NOT NULL DEFAULT 'INR',
            job_posts       SMALLINT UNSIGNED DEFAULT 0,
            featured_jobs   SMALLINT UNSIGNED DEFAULT 0,
            resume_views    SMALLINT UNSIGNED DEFAULT 0,
            candidate_msgs  SMALLINT UNSIGNED DEFAULT 0,
            team_seats      TINYINT UNSIGNED  DEFAULT 1,
            features_json   LONGTEXT,
            is_active       TINYINT(1)        DEFAULT 1,
            sort_order      TINYINT UNSIGNED  DEFAULT 0,
            created_at      DATETIME          DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug)
        ) $charset;";

        // 16. Subscriptions
        $tables[] = "CREATE TABLE {$p}jp_subscriptions (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id         BIGINT UNSIGNED NOT NULL,
            company_id      BIGINT UNSIGNED NOT NULL,
            plan_id         BIGINT UNSIGNED NOT NULL,
            razorpay_sub_id VARCHAR(100),
            billing_cycle   ENUM('monthly','yearly') DEFAULT 'monthly',
            status          ENUM('trial','active','past_due','cancelled','expired') DEFAULT 'trial',
            credits_json    LONGTEXT,
            starts_at       DATETIME,
            expires_at      DATETIME,
            cancelled_at    DATETIME DEFAULT NULL,
            expiry_warned   TINYINT(1) UNSIGNED NOT NULL DEFAULT 0,
            created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY company_id (company_id),
            KEY status (status),
            KEY expires_at (expires_at)
        ) $charset;";
        // Root-cause fix (batch 9 — the close-read sweep of financially/
        // structurally sensitive classes that batch 8's payments-table bug
        // recommended). class-jp-subscriptions.php's activate() — the
        // single function that grants plan access after ANY successful
        // payment — has been writing to a column named 'plan_name', which
        // has never existed here (every other reader of a subscription's
        // plan name, including get_active() right below in the same file
        // and the admin subscriptions list in class-jp-api.php, correctly
        // computes it via a LEFT JOIN to jp_plans instead), and to
        // 'started_at' where this table has always been 'starts_at' (the
        // same DATETIME-column naming this codebase uses consistently
        // elsewhere, e.g. jp_events' own starts_at). Both are unknown-
        // column errors, so activate()'s INSERT into jp_subscriptions has
        // never once succeeded — no subscription row has ever actually
        // been created for any real payment, on top of which the insert
        // also omitted this table's NOT-NULL company_id entirely, an
        // independent reason it would still fail even with the two names
        // corrected. Because activate()'s return value was never checked
        // by any of its three callers either (see class-jp-payments.php's
        // batch 8 fixes), and because it separately (and correctly) sets
        // jp_plan/jp_plan_expires user meta regardless, this has been
        // invisible: paying customers get a "your plan is now active" user-
        // meta flag, but get_active() — the function every credit check
        // (use_credit()/get_credits(), including batch 6's team-seat limit
        // enforcement) actually queries — always returns null, because it
        // reads the very table that was never populated, and its own
        // ORDER BY s.started_at was itself a second, independent unknown-
        // column query error on top of that. Net effect: every paying
        // customer, on every plan, has always been credit-limited as if on
        // the free Starter tier. expiry_warned is a genuinely new column,
        // added here — expire_check()'s 7-day-warning query already
        // referenced it (to avoid re-sending the same warning email every
        // cron run) but it never existed either, a fourth independent
        // missing-column bug in this one table. See class-jp-subscriptions.
        // php's activate()/get_active()/expire_check() for the code-side
        // fixes: column names corrected, company_id resolved and included,
        // expire_check()'s two queries now JOIN jp_plans for plan_name
        // (matching get_active()'s and the admin list's existing pattern)
        // instead of assuming a stored column, and activate()'s insert
        // result is now checked instead of unconditionally returning true.
        // Additive, dbDelta-safe column — no data-loss risk on upgrade.

        // 17. Payments
        $tables[] = "CREATE TABLE {$p}jp_payments (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id         BIGINT UNSIGNED NOT NULL,
            company_id      BIGINT UNSIGNED NOT NULL,
            plan_id         BIGINT UNSIGNED DEFAULT 0,
            razorpay_order  VARCHAR(100),
            razorpay_pay_id VARCHAR(100),
            razorpay_signature VARCHAR(255),
            gateway         VARCHAR(20)     DEFAULT 'razorpay',
            stripe_session_id VARCHAR(120),
            billing_cycle   ENUM('monthly','yearly') DEFAULT 'monthly',
            amount          INT UNSIGNED    NOT NULL,
            currency        VARCHAR(5)      DEFAULT 'INR',
            status          ENUM('created','paid','failed','refunded','abandoned') DEFAULT 'created',
            description     VARCHAR(300),
            invoice_url     VARCHAR(500),
            paid_at         DATETIME NULL DEFAULT NULL,
            created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY status (status),
            KEY razorpay_pay_id (razorpay_pay_id),
            KEY stripe_session_id (stripe_session_id)
        ) $charset;";
        // Root-cause fix (batch 12 — Stripe gateway abstraction, now
        // unblocked by batches 8-11's fixes to the Razorpay path this
        // table already supported). Two new, additive, dbDelta-safe
        // columns: 'gateway' records which processor a given jp_payments
        // row belongs to (defaults 'razorpay' so every pre-existing row is
        // correctly attributed without a backfill migration), and
        // 'stripe_session_id' is Stripe's own Checkout Session id — kept
        // as its own column rather than overloading razorpay_order (which
        // several existing queries already filter/index by name in a way
        // that assumes it's Razorpay-specific) so a Stripe row's identity
        // never collides with or gets confused for a Razorpay one.
        // Note: 'abandoned' added to the status ENUM for the payment
        // reconciliation job (JP_Payments::reconcile_pending(), gap analysis
        // P1 #154) — dbDelta() can widen an ENUM's value list in place via
        // its normal idempotent ALTER TABLE ... MODIFY COLUMN diffing, no
        // separate migration needed for this additive change.
        //
        // Root-cause fix (batch 8 — severe, previously-undetected bug found
        // while scoping payment-gateway abstraction work). class-jp-payments.php
        // has been writing to razorpay_signature, paid_at, and billing_cycle
        // on every successful payment (ajax_verify_payment(), handle_webhook(),
        // reconcile_pending()) since those methods were written, but none of
        // those three columns existed in this table — only razorpay_order,
        // razorpay_pay_id, amount, currency, status, description, invoice_url,
        // created_at did. A $wpdb->update()/insert() naming an unknown column
        // fails the whole query (MySQL rejects it outright) and $wpdb sets
        // $wpdb->last_error, but nothing in class-jp-payments.php ever checked
        // the return value — so every one of those writes has been silently
        // failing in exactly the "ghost success" pattern this audit exists to
        // catch: status never actually advances past 'created', paid_at is
        // never set, and billing_cycle is never stored at all (not even on
        // the INSERT in ajax_create_order(), which also omitted it). Net
        // effect, three separate confirmed live bugs from one missing set of
        // columns: (1) admin/recruiter "total revenue" stats, which filter
        // strictly on status='paid' AND paid_at>=..., have always reported
        // ₹0 regardless of real payment volume; (2) every yearly-plan
        // purchase has been silently activated as a monthly subscription,
        // because JP_Subscriptions::activate()'s $billing_cycle parameter
        // defaults to 'monthly' and the real value was never persisted
        // anywhere to pass it; (3) the hourly reconciliation job
        // (JP_Payments::reconcile_pending()) — because status never actually
        // reaches 'paid' in the DB — would repeatedly rediscover the SAME
        // already-paid order as still 'created' on every run and call
        // JP_Subscriptions::activate() again each time, and activate() is
        // not idempotent (it inserts a brand-new active subscription row
        // with a fresh expires_at every call) — meaning a single real
        // payment could silently extend a subscription indefinitely, for
        // free, forever, once per hour. dbDelta() adding new nullable/
        // defaulted columns to an existing table is the same safe, additive,
        // already-relied-upon mechanism as the ENUM-widening change directly
        // above — no data loss on upgrade; see class-jp-payments.php's own
        // docblock and the fixed methods themselves for the write-side half
        // of this fix (return-value checks + reconcile_pending() no longer
        // reactivating on a write it can't confirm succeeded).

        // 18. Skills master list
        $tables[] = "CREATE TABLE {$p}jp_skills (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            name        VARCHAR(100)    NOT NULL,
            slug        VARCHAR(100)    NOT NULL,
            category    VARCHAR(100),
            jobs_count  INT UNSIGNED DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug)
        ) $charset;";

        // 19. User skills
        $tables[] = "CREATE TABLE {$p}jp_user_skills (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id     BIGINT UNSIGNED NOT NULL,
            skill_id    BIGINT UNSIGNED NOT NULL,
            proficiency ENUM('beginner','intermediate','advanced','expert') DEFAULT 'intermediate',
            years       TINYINT UNSIGNED DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY user_skill (user_id, skill_id),
            KEY skill_id (skill_id)
        ) $charset;";

        // 20. Assessments
        $tables[] = "CREATE TABLE {$p}jp_assessments (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id      BIGINT UNSIGNED NOT NULL,
            skill_id     BIGINT UNSIGNED NOT NULL,
            score        TINYINT UNSIGNED DEFAULT 0,
            badge_level  ENUM('none','bronze','silver','gold') DEFAULT 'none',
            taken_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
            expires_at   DATETIME DEFAULT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY skill_id (skill_id)
        ) $charset;";

        // 21. Interviews


        $tables[] = "CREATE TABLE {$p}jp_sms_log (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            phone       VARCHAR(20) NOT NULL,
            message     VARCHAR(200) NOT NULL,
            status      ENUM('sent','failed','pending') DEFAULT 'pending',
            provider    VARCHAR(20),
            created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY phone (phone),
            KEY created_at (created_at)
        ) {$charset};";

        $tables[] = "CREATE TABLE {$p}jp_assessment_questions (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            skill_id        BIGINT UNSIGNED NOT NULL,
            question        TEXT NOT NULL,
            options_json    TEXT NOT NULL,
            correct_index   TINYINT UNSIGNED NOT NULL DEFAULT 0,
            explanation     TEXT,
            difficulty      ENUM(\'easy\',\'medium\',\'hard\') DEFAULT \'medium\',
            is_active       TINYINT(1) DEFAULT 1,
            created_by      BIGINT UNSIGNED DEFAULT NULL,
            created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY skill_id (skill_id),
            KEY is_active (is_active)
        ) {$charset};";

        $tables[] = "CREATE TABLE {$p}jp_push_subscriptions (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id         BIGINT UNSIGNED NOT NULL,
            endpoint        VARCHAR(500) NOT NULL,
            p256dh_key      VARCHAR(255),
            auth_key        VARCHAR(255),
            user_agent      VARCHAR(300),
            created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_endpoint (user_id, endpoint(191)),
            KEY user_id (user_id)
        ) {$charset};";

        // Batch 36 (interview-management depth pass): `outcome` below is
        // pending/passed/failed/cancelled/no_show only — it has no way to
        // represent "candidate confirmed" or "candidate asked to
        // reschedule" as distinct pre-interview states, both explicitly
        // required by the enterprise-depth spec's interview-management
        // section. Added as their own additive columns rather than
        // widening the ENUM: an interview can be both confirmed AND later
        // have a reschedule requested (a confirmed slot the candidate can
        // no longer make), which a single new ENUM value can't represent,
        // and dbDelta's ENUM-widening path (see the P1 #154 comment
        // elsewhere in this file) only ever adds values — it can't express
        // "these two states coexist" either. Kept the SQL string itself
        // free of inline comments deliberately: this file's own history
        // (see the "comment embedded in its column list broke dbDelta's
        // line-based parser" note above) is a direct warning against that.
        $tables[] = "CREATE TABLE {$p}jp_interviews (
            id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            application_id BIGINT UNSIGNED NOT NULL,
            job_id         BIGINT UNSIGNED NOT NULL,
            candidate_id   BIGINT UNSIGNED NOT NULL,
            recruiter_id   BIGINT UNSIGNED NOT NULL,
            round          TINYINT UNSIGNED DEFAULT 1,
            type           ENUM('phone','video','onsite','technical','hr') DEFAULT 'video',
            scheduled_at   DATETIME,
            duration_min   SMALLINT UNSIGNED DEFAULT 45,
            meeting_link   VARCHAR(500),
            location       VARCHAR(300),
            notes          TEXT,
            feedback       TEXT,
            rating         TINYINT UNSIGNED DEFAULT 0,
            outcome        ENUM('pending','passed','failed','cancelled','no_show') DEFAULT 'pending',
            candidate_confirmed    TINYINT(1) DEFAULT 0,
            reschedule_requested   TINYINT(1) DEFAULT 0,
            reschedule_reason      TEXT,
            created_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY application_id (application_id),
            KEY scheduled_at (scheduled_at)
        ) $charset;";

        // 22. Events
        $tables[] = "CREATE TABLE {$p}jp_events (
            id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            title          VARCHAR(300)    NOT NULL,
            slug           VARCHAR(320)    NOT NULL,
            description    LONGTEXT,
            event_type     ENUM('webinar','career_fair','workshop','hackathon','other') DEFAULT 'webinar',
            host_company   BIGINT UNSIGNED DEFAULT 0,
            banner_url     VARCHAR(500),
            starts_at      DATETIME,
            ends_at        DATETIME,
            timezone       VARCHAR(50)     DEFAULT 'Asia/Kolkata',
            format         ENUM('online','offline','hybrid') DEFAULT 'online',
            venue          VARCHAR(300),
            meeting_url    VARCHAR(500),
            seats_total    SMALLINT UNSIGNED DEFAULT 0,
            seats_taken    SMALLINT UNSIGNED DEFAULT 0,
            is_free        TINYINT(1)        DEFAULT 1,
            price          INT UNSIGNED      DEFAULT 0,
            status         ENUM('draft','published','cancelled','completed') DEFAULT 'draft',
            created_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY slug (slug),
            KEY starts_at (starts_at),
            KEY status (status)
        ) $charset;";

        // 23. Event registrations
        $tables[] = "CREATE TABLE {$p}jp_event_registrations (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event_id   BIGINT UNSIGNED NOT NULL,
            user_id    BIGINT UNSIGNED NOT NULL,
            status     ENUM('registered','attended','cancelled') DEFAULT 'registered',
            joined_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY event_user (event_id, user_id),
            KEY event_id (event_id)
        ) $charset;";

        // 24. Search log
        $tables[] = "CREATE TABLE {$p}jp_search_log (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id      BIGINT UNSIGNED DEFAULT 0,
            query        VARCHAR(300),
            filters_json LONGTEXT,
            results_cnt  INT UNSIGNED    DEFAULT 0,
            ip           VARCHAR(45),
            created_at   DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY query (query(50)),
            KEY created_at (created_at)
        ) $charset;";

        // 25. Analytics (raw events)
        //
        // CRITICAL root-cause fix (self-audited while investigating an
        // unrelated feature): JP_Analytics::track() — the ONLY function
        // that ever inserts a row into this table, called from both
        // ajax_track() and the REST track_event() handler, i.e. every
        // single trackEvent() call the frontend makes for job_view,
        // job_apply, company_view, profile_view, job_click — has always
        // included a 'session_id' key in its $wpdb->insert() call. This
        // table never had a session_id column. $wpdb->insert() with a key
        // that isn't a real column fails at the SQL level ("Unknown
        // column 'session_id'") and returns false; track() never checked
        // that return value (a ghost-success, now also fixed below), so
        // the failure was completely silent. Net effect: this table has
        // been permanently empty since track() was written — every
        // caller downstream (aggregate()'s hourly cron → jp_analytics_agg
        // → platform_summary()/company_summary() → AdminAnalyticsPage/
        // RecruiterAnalyticsPage's ROI reports, plus candidate_analytics()'s
        // direct profile_views/search_appears COUNT queries in
        // class-jp-api.php) has been silently starved of real data.
        // Verified programmatically before fixing: parsed this CREATE
        // TABLE's real column list vs. track()'s actual $wpdb->insert()
        // keys — 'session_id' was the only key with no matching column.
        // Root-cause fix: add the column that was always intended to
        // exist (get_session_id() is a real, deliberately-built private
        // method purely to populate it) rather than remove the insert key
        // and lose that intended per-session-dedup capability. dbDelta()
        // (called unconditionally by both create_tables() and the
        // self-heal path above) reconciles column-level schema drift on
        // an EXISTING table the same way it creates missing tables, so
        // this heals automatically on the next admin page load or plugin
        // update, with no separate migration step required.
        $tables[] = "CREATE TABLE {$p}jp_analytics (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event      VARCHAR(80)     NOT NULL,
            user_id    BIGINT UNSIGNED DEFAULT 0,
            object_id  BIGINT UNSIGNED DEFAULT 0,
            session_id VARCHAR(64),
            meta_json  LONGTEXT,
            ip         VARCHAR(45),
            ua         VARCHAR(300),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY event (event),
            KEY object_id (object_id),
            KEY created_at (created_at)
        ) $charset;";

        // 26. Analytics aggregates
        $tables[] = "CREATE TABLE {$p}jp_analytics_agg (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            event      VARCHAR(80)     NOT NULL,
            object_id  BIGINT UNSIGNED DEFAULT 0,
            period     VARCHAR(20)     NOT NULL,
            count      INT UNSIGNED    DEFAULT 0,
            PRIMARY KEY (id),
            UNIQUE KEY event_object_period (event, object_id, period),
            KEY period (period)
        ) $charset;";

        // 27. Audit log
        //
        // Root-cause fix: JP_Security::audit() has always built its
        // $wpdb->insert() call with a 'ua' (user agent) field and,
        // separately, previously tried to insert into a nonexistent
        // 'context' column — MySQL rejects an INSERT naming an unknown
        // column outright, which means every single call to audit() across
        // the whole codebase (account deletion, login events, everything
        // routed through this method) has been silently failing to write
        // ANY row at all. The security/compliance audit trail has never
        // actually worked. Added the missing 'ua' column and company_id for
        // the team-scoping gap noted in the original analysis; the insert's
        // 'context' key is fixed to map to the existing 'object' column
        // instead of a phantom one.
        //
        // Second, independent root-cause fix (confirmed via a live
        // JP_Diagnostics run: this was the ONLY one of 34 expected tables
        // that failed to get created on a fresh install): the multi-line
        // /* ... */ SQL comment that used to sit INSIDE this CREATE TABLE's
        // column list (right where the "ua" note above now lives as a PHP
        // comment instead) broke dbDelta()'s parser. dbDelta does not use a
        // real SQL parser — it's a line-oriented regex matcher that expects
        // one column/key definition per line, and a multi-line C-style
        // comment embedded in the middle of the column list is exactly the
        // kind of construct that makes it misread or truncate the statement,
        // silently producing no table at all instead of an error. Moving the
        // explanation to a PHP comment (as done here) and keeping the SQL
        // string itself to plain column/key lines is the actual fix —
        // ensure_missing_tables() below adds a belt-and-suspenders explicit
        // self-heal for this exact table too, since sites that already
        // activated with the broken SQL will never see this corrected
        // version run again otherwise.
        $tables[] = "CREATE TABLE {$p}jp_audit_log (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id    BIGINT UNSIGNED NOT NULL,
            action     VARCHAR(100)    NOT NULL,
            object     VARCHAR(100),
            object_id  BIGINT UNSIGNED DEFAULT 0,
            detail     TEXT,
            ip         VARCHAR(45),
            ua         VARCHAR(255),
            company_id BIGINT UNSIGNED DEFAULT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            prev_hash  VARCHAR(64) DEFAULT NULL,
            hash       VARCHAR(64) DEFAULT NULL,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY action (action),
            KEY company_id (company_id),
            KEY created_at (created_at)
        ) $charset;";
        // Batch 14 (tamper-evidence): added prev_hash/hash so JP_Security::audit()
        // can hash-chain every row (see that method's docblock). Column-addition
        // reaches already-installed sites only via dbDelta's diffing in
        // run_upgrade(), which itself only fires on a JP_VERSION bump (see
        // jp-core.php's `if ( $stored !== JP_VERSION )` gate) — bumped as part
        // of this same change. The self-heal block above only creates this
        // table if entirely absent, so it does NOT retrofit these columns onto
        // an existing table; sites with a pre-existing jp_audit_log rely
        // entirely on the version-bump-triggered dbDelta path here.

        // 26. Community posts (Q&A / forums)
        $tables[] = "CREATE TABLE {$p}jp_community_posts (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id      BIGINT UNSIGNED NOT NULL,
            category     ENUM('general','career','interview','salary','workplace','tech') DEFAULT 'general',
            title        VARCHAR(300)    NOT NULL,
            body         LONGTEXT        NOT NULL,
            tags_json    VARCHAR(500),
            views        INT UNSIGNED    DEFAULT 0,
            likes        INT UNSIGNED    DEFAULT 0,
            reply_count  INT UNSIGNED    DEFAULT 0,
            is_pinned    TINYINT(1)      DEFAULT 0,
            is_resolved  TINYINT(1)      DEFAULT 0,
            created_at   DATETIME        DEFAULT CURRENT_TIMESTAMP,
            updated_at   DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id),
            KEY category (category),
            KEY created_at (created_at)
        ) $charset;";

        // 27. Community replies
        $tables[] = "CREATE TABLE {$p}jp_community_replies (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            post_id     BIGINT UNSIGNED NOT NULL,
            user_id     BIGINT UNSIGNED NOT NULL,
            body        LONGTEXT        NOT NULL,
            likes       INT UNSIGNED    DEFAULT 0,
            is_accepted TINYINT(1)      DEFAULT 0,
            created_at  DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY user_id (user_id)
        ) $charset;";

        // 28. Gamification
        $tables[] = "CREATE TABLE {$p}jp_user_badges (
            id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id    BIGINT UNSIGNED NOT NULL,
            badge      VARCHAR(100)    NOT NULL,
            awarded_at DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_badge (user_id, badge)
        ) $charset;";


        // 29. Webhooks (stored in WP options — no separate table needed)
        // 30. Feature flags
        // 31. Canned responses (batch 25 — recruiter-saved message templates)
        $tables[] = "CREATE TABLE {$p}jp_canned_responses (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id     BIGINT UNSIGNED NOT NULL,
            title       VARCHAR(150)    NOT NULL,
            body        TEXT            NOT NULL,
            created_at  DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY user_id (user_id)
        ) $charset;";

        // 32. Interview panelists (batch 26 — true multi-interviewer
        // scorecard collaboration, on top of jp_interviews' own
        // single-reviewer rating/feedback/outcome columns from batch 20)
        $tables[] = "CREATE TABLE {$p}jp_interview_panelists (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            interview_id  BIGINT UNSIGNED NOT NULL,
            panelist_id   BIGINT UNSIGNED NOT NULL,
            added_by      BIGINT UNSIGNED NOT NULL,
            rating        TINYINT UNSIGNED DEFAULT 0,
            feedback      TEXT,
            outcome       ENUM('pending','passed','failed','no_show') DEFAULT 'pending',
            submitted_at  DATETIME        DEFAULT NULL,
            created_at    DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY interview_panelist (interview_id, panelist_id),
            KEY interview_id (interview_id),
            KEY panelist_id (panelist_id)
        ) $charset;";

        // E-signature envelopes (JP_ESign — DocuSign integration; see that
        // class's own docblock for why this table exists rather than
        // widening jp_applications.offer_status's ENUM: keeps the vendor
        // integration entirely additive against an existing, working column
        // set, and supports multiple envelopes per application over time
        // (re-send after a correction) without ambiguity about which is
        // current — ORDER BY id DESC LIMIT 1 in get_envelope_for_application().
        $tables[] = "CREATE TABLE {$p}jp_esign_envelopes (
            id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            application_id  BIGINT UNSIGNED NOT NULL,
            provider        VARCHAR(30)     NOT NULL DEFAULT 'docusign',
            envelope_id     VARCHAR(100)    NOT NULL,
            status          ENUM('sent','delivered','completed','declined','voided') DEFAULT 'sent',
            created_at      DATETIME        DEFAULT CURRENT_TIMESTAMP,
            updated_at      DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY envelope_id (envelope_id),
            KEY application_id (application_id)
        ) $charset;";

        // Inbound job-feed import dedup tracking (JP_JobFeed — see that
        // class's own docblock). One row per (source feed, external job id)
        // pair ever imported, mapping to the local jp_jobs.id it produced,
        // so a repeat cron run updates the existing local job instead of
        // creating a duplicate.
        $tables[] = "CREATE TABLE {$p}jp_job_feed_imports (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            source_hash   VARCHAR(32)     NOT NULL,
            source_url    VARCHAR(500)    NOT NULL,
            external_id   VARCHAR(200)    NOT NULL,
            job_id        BIGINT UNSIGNED NOT NULL,
            imported_at   DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY source_external (source_hash, external_id),
            KEY job_id (job_id)
        ) $charset;";

        // Match dismissals ("not interested, stop recommending this") — a
        // dedicated table rather than a column on jp_matches, because
        // backfill_candidate_matches()/score_candidate_batch_job() both
        // $wpdb->replace() the jp_matches row for a (candidate, job) pair
        // on every re-score run, which would silently wipe a column-based
        // dismissal flag the next time scoring runs for this candidate.
        $tables[] = "CREATE TABLE {$p}jp_match_dismissals (
            id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            candidate_id  BIGINT UNSIGNED NOT NULL,
            job_id        BIGINT UNSIGNED NOT NULL,
            dismissed_at  DATETIME        DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY candidate_job (candidate_id, job_id),
            KEY candidate_id (candidate_id)
        ) $charset;";

        $tables[] = "CREATE TABLE {$p}jp_feature_flags (
            id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            flag_key    VARCHAR(100)    NOT NULL,
            is_enabled  TINYINT(1)      DEFAULT 1,
            plan_tier   VARCHAR(50)     DEFAULT 'all',
            description TEXT,
            updated_at  DATETIME        DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY flag_key (flag_key)
        ) $charset;";

        // Talent pool (recruiter-saved candidates) — the exact mirror of
        // jp_saved_jobs above, but keyed the other direction: a recruiter
        // (user_id) bookmarking a candidate (candidate_id) instead of a
        // candidate bookmarking a job. Added while auditing the codebase
        // for candidate-side features with no recruiter-side equivalent —
        // "Saved jobs" existed for candidates with nothing mirroring it for
        // recruiters, confirmed absent via a full-codebase grep for
        // saved_candidate/bookmark/talent_pool/candidate_pool before adding
        // this table, so this isn't duplicating an existing mechanism.
        $tables[] = "CREATE TABLE {$p}jp_saved_candidates (
            id           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
            user_id      BIGINT UNSIGNED NOT NULL,
            candidate_id BIGINT UNSIGNED NOT NULL,
            note         VARCHAR(300),
            saved_at     DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY user_candidate (user_id, candidate_id),
            KEY user_id (user_id)
        ) $charset;";

        // Run all via dbDelta (idempotent — safe to re-run)
        foreach ( $tables as $sql ) {
            dbDelta( $sql );
        }

        // Store DB version for future migrations
        update_option( 'jp_db_version', JP_VERSION );
        // jp_react_app_version is deliberately NOT set here — see
        // class-jp-react.php's enqueue_react_assets() for why blindly
        // copying JP_VERSION into it defeats the version-drift detection
        // built for gap analysis P1 "jp_react_app_version is tracked but
        // nothing verifies it against the actual deployed build."

        // Add FULLTEXT indexes — dbDelta() cannot create these, must use ALTER TABLE
        // Safe to run every activation: IF NOT EXISTS equivalent via STATISTICS check
        self::ensure_fulltext_indexes();
    }

    /**
     * Add FULLTEXT indexes that dbDelta() cannot create.
     * Checks information_schema before running ALTER — safe on every activation.
     */
    private static function ensure_fulltext_indexes(): void {
        global $wpdb;
        $p = $wpdb->prefix;

        $fulltext_indexes = [
            // [table, index_name, columns]
            // jp_jobs: used by search endpoint — title, description, skills_json
            [ 'jp_jobs', 'ft_job_search', 'title, description, skills_json' ],
            // jp_companies: used by companies search
            [ 'jp_companies', 'ft_company_search', 'name, description, industry' ],
            // jp_candidates: used by recruiter candidate search
            [ 'jp_candidates', 'ft_candidate_search', 'headline, bio, location_city' ],
        ];

        foreach ( $fulltext_indexes as [ $table, $index_name, $columns ] ) {
            $full_table = $p . $table;

            // Check if this FULLTEXT index already exists
            $exists = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM information_schema.STATISTICS
                 WHERE TABLE_SCHEMA = DATABASE()
                 AND TABLE_NAME = %s
                 AND INDEX_NAME = %s
                 AND INDEX_TYPE = 'FULLTEXT'",
                $full_table,
                $index_name
            ) );

            if ( $exists === 0 ) {
                // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
                $wpdb->query( "ALTER TABLE `{$full_table}` ADD FULLTEXT INDEX `{$index_name}` ({$columns})" );
            }
        }
    }

    // ── Platform pages ────────────────────────────────────────────────────────
    //
    // NOTE — two-front-end plugin (see /ARCHITECTURE.md for the full picture):
    // almost every page below is assigned 'page-templates/tpl-react-app.php',
    // which means it's rendered ENTIRELY by the separately-built React app in
    // react-app/ (its own Tailwind CSS — jp-app.css) — NOT by the matching
    // page-templates/tpl-*.php file of a similar name that also exists in the
    // theme (tpl-job-search.php, tpl-companies.php, tpl-dashboard.php, etc.).
    // Those theme files are an alternate/legacy implementation and are not
    // live for any of these pages unless someone has manually changed a
    // page's template in wp-admin. If you're editing CSS/markup for one of
    // these URLs and it "does nothing," you are very likely editing the
    // wrong front-end's files — check the page's actual assigned template
    // first (Pages → [page] → Page Attributes → Template in wp-admin).

    private static function create_pages(): void {
        $pages = [
            [ 'slug' => 'jobs',         'title' => 'Find Jobs',            'template' => 'page-templates/tpl-react-app.php'      ],
            [ 'slug' => 'companies',    'title' => 'Companies',             'template' => 'page-templates/tpl-react-app.php'        ],
            [ 'slug' => 'candidates',   'title' => 'Find Candidates',       'template' => 'page-templates/tpl-react-app.php'       ],
            [ 'slug' => 'salary',       'title' => 'Salary Explorer',       'template' => 'page-templates/tpl-react-app.php'           ],
            [ 'slug' => 'campus',       'title' => 'Campus Portal',         'template' => 'page-templates/tpl-react-app.php'           ],
            [ 'slug' => 'pricing',      'title' => 'Recruiter Plans',       'template' => 'page-templates/tpl-react-app.php'          ],
            [ 'slug' => 'login',        'title' => 'Login',                 'template' => 'page-templates/tpl-react-app.php'            ],
            [ 'slug' => 'register',     'title' => 'Register',              'template' => 'page-templates/tpl-react-app.php'         ],
            [ 'slug' => 'my-account',   'title' => 'My Dashboard',          'template' => 'page-templates/tpl-react-app.php'        ],
            [ 'slug' => 'recruiter',    'title' => 'Recruiter Panel',       'template' => 'page-templates/tpl-react-app.php'   ],
            [ 'slug' => 'admin-panel',  'title' => 'Admin Panel',           'template' => 'page-templates/tpl-react-app.php'       ],
            [ 'slug' => 'about',        'title' => 'About Us',              'template' => ''                                        ],
            [ 'slug' => 'contact',      'title' => 'Contact Us',            'template' => 'page-templates/tpl-react-app.php'          ],
            [ 'slug' => 'help',         'title' => 'Help Centre',           'template' => 'page-templates/tpl-react-app.php'             ],
            [ 'slug' => 'privacy-policy', 'title' => 'Privacy Policy',      'template' => ''                                        ],
            [ 'slug' => 'terms',        'title' => 'Terms & Conditions',    'template' => ''                                        ],
            [ 'slug' => 'portal',       'title' => 'JP Jobs Portal',        'template' => ''                                        ],
        ];

        $created = [];

        foreach ( $pages as $p ) {
            // Don't duplicate
            $existing = get_page_by_path( $p['slug'] );
            if ( $existing ) {
                // Update template on existing pages (handles plugin upgrades)
                if ( $p['template'] ) {
                    update_post_meta( $existing->ID, '_wp_page_template', $p['template'] );
                }
                $created[ $p['slug'] ] = $existing->ID;
                continue;
            }

            $content = $p['slug'] === 'portal' ? '[jp_app]' : '';
            $id = wp_insert_post( [
                'post_title'   => $p['title'],
                'post_name'    => $p['slug'],
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_content' => $content,
            ] );

            if ( $id && ! is_wp_error( $id ) ) {
                if ( $p['template'] ) {
                    update_post_meta( $id, '_wp_page_template', $p['template'] );
                }
                $created[ $p['slug'] ] = $id;
            }
        }

        // Store page IDs for easy reference throughout the plugin
        update_option( 'jp_page_ids', $created );

        // Store the primary portal page ID (the jobs/find-jobs page)
        // get_portal_page() reads this to find the React basename reliably
        $portal_candidates = [ 'jobs', 'find-jobs', 'portal', 'jp-portal' ];
        foreach ( $portal_candidates as $candidate ) {
            if ( ! empty( $created[ $candidate ] ) ) {
                update_option( 'jp_portal_page_id', $created[ $candidate ] );
                break;
            }
        }
        // If the template was applied to an existing page, store its ID too
        if ( ! get_option( 'jp_portal_page_id' ) ) {
            $pages = get_posts( [
                'post_type'   => 'page', 'post_status' => 'publish',
                'posts_per_page' => 1,
                'meta_key'    => '_wp_page_template',
                'meta_value'  => 'page-templates/tpl-react-app.php',
                'orderby'     => 'ID', 'order' => 'ASC',
            ] );
            if ( ! empty( $pages ) ) {
                update_option( 'jp_portal_page_id', $pages[0]->ID );
            }
        }
    }

    // ── Option defaults ───────────────────────────────────────────────────────

    private static function set_defaults(): void {
        $defaults = [
            'jp_site_name'           => get_bloginfo( 'name' ),
            'jp_jobs_per_page'       => 20,
            'jp_applications_email'  => get_bloginfo( 'admin_email' ),
            'jp_email_from_name'     => get_bloginfo( 'name' ),
            'jp_email_from_address'  => get_bloginfo( 'admin_email' ),
            'jp_razorpay_mode'       => 'test',
            'jp_auto_approve_jobs'   => '0',
            'jp_resume_max_size_mb'  => 5,
            'jp_installed_version'   => JP_VERSION,
            'jp_installed_at'        => current_time( 'mysql' ),
        ];

        foreach ( $defaults as $key => $val ) {
            if ( get_option( $key ) === false ) {
                add_option( $key, $val );
            }
        }
    }

    // ── Uninstall helpers ─────────────────────────────────────────────────────

    private static function drop_tables(): void {
        global $wpdb;
        $tables = [
            'jp_jobs','jp_companies','jp_candidates','jp_applications',
            'jp_app_history','jp_resumes','jp_resume_sections',
            'jp_message_threads','jp_messages','jp_notifications',
            'jp_alerts','jp_saved_jobs','jp_matches','jp_reviews',
            'jp_plans','jp_subscriptions','jp_payments',
            'jp_skills','jp_user_skills','jp_assessments','jp_assessment_questions','jp_push_subscriptions','jp_sms_log',
            'jp_interviews','jp_events','jp_event_registrations',
            'jp_search_log','jp_analytics','jp_analytics_agg','jp_audit_log',
            'jp_canned_responses','jp_interview_panelists',
            'jp_esign_envelopes','jp_job_feed_imports','jp_match_dismissals',
            'jp_saved_candidates',
        ];
        foreach ( $tables as $t ) {
            $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}{$t}" ); // phpcs:ignore
        }
    }

    private static function delete_options(): void {
        $opts = [
            'jp_page_ids','jp_db_version','jp_site_name','jp_jobs_per_page',
            'jp_applications_email','jp_email_from_name','jp_email_from_address',
            'jp_razorpay_mode','jp_auto_approve_jobs','jp_resume_max_size_mb',
            'jp_installed_version','jp_installed_at','jp_uninstall_wipe_data',
        ];
        foreach ( $opts as $o ) {
            delete_option( $o );
        }
    }
}
