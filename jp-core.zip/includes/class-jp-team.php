<?php
/**
 * Class JP_Team — Company team / multi-seat management.
 *
 * Phase-2 remediation of the enterprise gap analysis (§1, Critical missing
 * functionality: "Team/multi-seat functionality does not exist at all,
 * despite being sold"). The jp_team_manager role, its capabilities
 * (jp_manage_team, jp_assign_jobs, jp_view_team_analytics), and the
 * team_seats plan credit (see JP_Subscriptions::PLAN_CREDITS) all existed
 * with no backing data model, no invite/accept/remove flow, and no seat-
 * limit enforcement — a company on a paid plan selling up to 10 seats could
 * never actually add a second recruiter. This class is that missing
 * infrastructure, backed by the jp_team_members table (see
 * class-jp-activator.php).
 *
 * Every application-level check that previously only recognized a single
 * company "owner" (JP_Applications::can_manage_application(), via the
 * jp_can_manage_application filter added in the prior remediation round)
 * now also recognizes active team members through is_team_member_of().
 *
 * Root-cause fix (batch 6): despite the paragraph above — a real,
 * seat-limited, audit-logged data model — this entire feature was
 * completely unreachable from the live app. Every one of the five
 * operations above (invite/accept/remove/list/reassign) existed ONLY as a
 * wp_ajax_jp_team_* handler, keyed to a cookie-based admin-ajax nonce the
 * REST-only React SPA never has (confirmed: zero references to
 * "team_invite", "TeamPage", or any /team route anywhere under app/src —
 * the same "SPA-unreachable legacy AJAX" pattern already documented at
 * class-jp-privacy.php and class-jp-featureflags.php, except THOSE two
 * got REST wrappers built for them in earlier passes and this one never
 * did). Worse than those two: router.tsx's /recruiter route already
 * explicitly allows the jp_team_manager role in — so a team manager could
 * log in, land in the recruiter workspace, and there was no team page, no
 * invite button, nothing, anywhere, for the one thing that role exists to
 * do. Each ajax_*() handler's logic has been extracted into a matching
 * do_*() method below (returns an array or \WP_Error instead of
 * echo+exit), so the exact same logic now backs both the legacy AJAX path
 * (unchanged) and new REST routes in class-jp-api.php
 * (team_list/team_invite/team_accept/team_remove/team_reassign_job) that
 * a new TeamPage.tsx (app/src/pages/recruiter/TeamPage.tsx) consumes.
 */
defined( 'ABSPATH' ) || exit;

class JP_Team {

	private static ?JP_Team $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_jp_team_invite',        [ $this, 'ajax_invite' ] );
		add_action( 'wp_ajax_jp_team_accept_invite',  [ $this, 'ajax_accept_invite' ] );
		add_action( 'wp_ajax_jp_team_remove',         [ $this, 'ajax_remove' ] );
		add_action( 'wp_ajax_jp_team_list',           [ $this, 'ajax_list' ] );
		add_action( 'wp_ajax_jp_team_reassign_jobs',  [ $this, 'ajax_reassign_jobs' ] );

		// Grant delegated access to JP_Applications::can_manage_application()
		// for any active team member of the job's company, not just its
		// original owner — the extension point added in the prior
		// remediation round specifically for this.
		add_filter( 'jp_can_manage_application', [ $this, 'filter_can_manage_application' ], 10, 5 );
	}

	// ── Capability / membership checks ────────────────────────────────────────

	/**
	 * Whether $user_id is an active (accepted, not removed) team member of
	 * $company_id — including the company's original owner, who is always
	 * an implicit 'owner'-role member even before any jp_team_members row
	 * exists for them (see ensure_owner_seat()).
	 */
	public function is_team_member_of( int $company_id, int $user_id ): bool {
		if ( ! $company_id || ! $user_id ) return false;
		global $wpdb;

		$owner_id = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT user_id FROM {$wpdb->prefix}jp_companies WHERE id=%d", $company_id
		) );
		if ( $owner_id === $user_id ) return true;

		return (bool) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}jp_team_members WHERE company_id=%d AND user_id=%d AND status='active' LIMIT 1",
			$company_id, $user_id
		) );
	}

	public function filter_can_manage_application( bool $is_owner, object $app, ?object $job, ?object $company, \WP_User $user ): bool {
		if ( $is_owner ) return true;
		if ( ! $company ) return false;
		return $this->is_team_member_of( (int) $company->id, (int) $user->ID );
	}

	/**
	 * Current active seat count (accepted invitations only; the owner's
	 * implicit seat does not count against the paid seat limit).
	 */
	public function seat_count( int $company_id ): int {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}jp_team_members WHERE company_id=%d AND status IN ('active','invited')",
			$company_id
		) );
	}

	/**
	 * Seat limit for a company, sourced from its owner's active
	 * subscription credits (team_seats) — see JP_Subscriptions::PLAN_CREDITS.
	 * Falls back to the starter plan's limit (1) if no subscription/credits
	 * are resolvable, which matches JP_Subscriptions' own fallback.
	 */
	public function seat_limit( int $company_id ): int {
		global $wpdb;
		$owner_id = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT user_id FROM {$wpdb->prefix}jp_companies WHERE id=%d", $company_id
		) );
		if ( ! $owner_id || ! class_exists( 'JP_Subscriptions' ) ) return 1;
		$credits = JP_Subscriptions::instance()->get_credits( $owner_id );
		return (int) ( $credits['team_seats'] ?? 1 );
	}

	private function company_for_user( int $user_id ): ?object {
		global $wpdb;
		return $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_companies WHERE user_id=%d", $user_id
		) );
	}

	// ── Shared implementations (batch 6 root-cause fix — see docblock at
	// the bottom of this class for the full gap trace: this entire feature
	// had a complete, working data model and business logic behind
	// wp_ajax_* handlers only, with NO REST route and NO SPA page ANYWHERE
	// — the jp_team_manager role that router.tsx's /recruiter route
	// already explicitly allows in could never actually reach a single
	// team-management action from the live app.) Each do_*() method below
	// returns either a plain array (success payload) or a \WP_Error — no
	// echo/exit — so it can be called from both the legacy ajax_*() wrapper
	// (which still jp_json_response()s the result, unchanged behavior) and
	// the new REST callbacks in class-jp-api.php, exactly the
	// "one implementation behind both" pattern already established for
	// JP_Privacy's export/erase/impersonate methods. ──────────────────────

	public function do_invite( int $inviter_id, string $email, string $role, int $company_id_param = 0 ) {
		$email = sanitize_email( $email );
		$role  = in_array( $role, [ 'manager', 'member' ], true ) ? $role : 'member';
		if ( ! $email || ! is_email( $email ) ) return new \WP_Error( 'invalid_email', 'A valid email address is required.' );

		$company = $this->company_for_user( $inviter_id );
		// Only the company owner or an existing 'manager'-role team member
		// may invite — checked via capability + membership, not a
		// hardcoded role string (same principle as the earlier
		// can_manage_application() fix).
		if ( ! $company && ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error( 'forbidden', 'Only a company owner can manage its team.' );
		}
		$company_id = $company ? (int) $company->id : $company_id_param;
		if ( ! $company_id ) return new \WP_Error( 'not_found', 'Company not found.' );

		if ( ! $company && ! current_user_can( 'manage_options' ) && ! $this->is_manager_of( $company_id, $inviter_id ) ) {
			return new \WP_Error( 'forbidden', 'Permission denied.' );
		}

		global $wpdb;

		// Seat-limit enforcement — the entire point of this class. Without
		// this check, "up to 10 seats" on a paid plan would be purely
		// decorative marketing copy with no actual limit or actual feature.
		$limit = $this->seat_limit( $company_id );
		$used  = $this->seat_count( $company_id );
		if ( $used >= $limit ) {
			return new \WP_Error( 'seat_limit', "Your plan allows {$limit} team seat(s) and you are already using {$used}. Upgrade your plan to add more team members." );
		}

		$existing = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_team_members WHERE company_id=%d AND invited_email=%s",
			$company_id, $email
		) );
		if ( $existing && $existing->status !== 'removed' ) {
			return new \WP_Error( 'already_invited', 'This person is already invited or on your team.' );
		}

		$token = wp_generate_password( 32, false );
		$data  = [
			'company_id'    => $company_id,
			'invited_email' => $email,
			'role'          => $role,
			'status'        => 'invited',
			'invited_by'    => $inviter_id,
			'invite_token'  => $token,
			'invited_at'    => current_time( 'mysql' ),
		];

		// Ghost-success fix: this write was previously unchecked, and the
		// function went on to send the invite email and return a success
		// message regardless. A failed write here means the invite email
		// points at a token that matches no jp_team_members row at all —
		// the invitee clicks "Accept" and gets "Invalid invitation link,"
		// while the admin who sent it was told "Invitation sent."
		if ( $existing ) {
			$result = $wpdb->update( $wpdb->prefix . 'jp_team_members', $data, [ 'id' => $existing->id ] );
		} else {
			$result = $wpdb->insert( $wpdb->prefix . 'jp_team_members', $data );
		}
		if ( false === $result ) {
			JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_team_members write failed: ' . $wpdb->last_error ), 'JP_Team::invite company_id=' . $company_id . ' email=' . $email );
			return new \WP_Error( 'invite_failed', 'Could not send the invitation. Please try again.' );
		}

		// Send the invite email if a matching WP user already exists for
		// this address; otherwise the invite is still recorded and is
		// resolved to a user account on first accept (via email match at
		// registration, or an explicit accept-invite call once they sign up).
		// Root-cause fix (batch 6): this used to point at
		// home_url('/')?jp_team_invite=token — a query param no live page
		// (SPA or otherwise) ever reads; see AcceptInvitePage.tsx, the new
		// SPA route this now points to instead, which calls POST /team/accept.
		$invite_url = add_query_arg( [ 'token' => $token ], home_url( '/team/accept' ) );
		if ( class_exists( 'JP_Notifications' ) ) {
			$body = sprintf(
				'You have been invited to join a company team on %s. Accept your invitation: %s',
				jp_site_name(),
				esc_url_raw( $invite_url )
			);
			JP_Notifications::instance()->send_email( $email, 'You have been invited to join a team', $body );
		}

		JP_Security::instance()->audit( 'team_invite_sent', 'team_member', $company_id, "Invited {$email} as {$role}", $company_id );

		return [ 'message' => "Invitation sent to {$email}.", 'seats_used' => $used + 1, 'seats_limit' => $limit ];
	}

	private function is_manager_of( int $company_id, int $user_id ): bool {
		global $wpdb;
		$role = $wpdb->get_var( $wpdb->prepare(
			"SELECT role FROM {$wpdb->prefix}jp_team_members WHERE company_id=%d AND user_id=%d AND status='active'",
			$company_id, $user_id
		) );
		return $role === 'manager';
	}

	public function do_accept_invite( \WP_User $user, string $token ) {
		$token = sanitize_text_field( $token );
		if ( ! $token ) return new \WP_Error( 'invalid_token', 'Invalid invitation link.' );

		global $wpdb;
		$invite = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_team_members WHERE invite_token=%s AND status='invited'",
			$token
		) );
		if ( ! $invite ) return new \WP_Error( 'invalid_or_used', 'This invitation is invalid or has already been used.' );

		if ( strcasecmp( $user->user_email, $invite->invited_email ) !== 0 ) {
			return new \WP_Error( 'email_mismatch', 'This invitation was sent to a different email address than your account.' );
		}

		// Re-check the seat limit at accept time too — a plan downgrade
		// between invite and accept should not silently exceed the new
		// limit.
		$limit = $this->seat_limit( (int) $invite->company_id );
		$used  = $this->seat_count( (int) $invite->company_id );
		if ( $used > $limit ) {
			return new \WP_Error( 'seat_limit', 'This company has reached its team seat limit and cannot accept new members right now. Please contact them.' );
		}

		// Ghost-success / privilege-inconsistency fix: this write was
		// unchecked, and the WP role grant a few lines below happened
		// unconditionally regardless of it — meaning a failed write here
		// still handed the user real jp_recruiter/jp_team_manager
		// capabilities while jp_team_members (the record everything else,
		// including do_remove() below and seat-limit counting, treats as
		// the source of truth) never actually flipped to 'active'. Aborts
		// before granting any capability if this write doesn't succeed.
		$accepted = $wpdb->update( $wpdb->prefix . 'jp_team_members', [
			'user_id'     => $user->ID,
			'status'      => 'active',
			'accepted_at' => current_time( 'mysql' ),
		], [ 'id' => $invite->id ] );
		if ( false === $accepted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_team_members accept-invite update failed: ' . $wpdb->last_error ), 'JP_Team::do_accept_invite invite_id=' . $invite->id . ' user_id=' . $user->ID );
			}
			return new \WP_Error( 'accept_failed', 'Could not accept this invitation right now. Please try again.' );
		}

		// Grant the recruiter role's capability set (via jp_team_manager for
		// a 'manager' invite, or by simply relying on the ATS-level
		// membership check above for a 'member' invite — a member does not
		// need the full jp_recruiter WP role if they're only meant to work
		// inside this one company's applications).
		if ( $invite->role === 'manager' && ! in_array( 'jp_team_manager', $user->roles, true ) ) {
			$user->add_role( 'jp_team_manager' );
		} elseif ( ! array_intersect( [ 'jp_recruiter', 'jp_team_manager', 'jp_admin_manager', 'administrator' ], $user->roles ) ) {
			$user->add_role( 'jp_recruiter' );
		}

		JP_Security::instance()->audit( 'team_invite_accepted', 'team_member', (int) $invite->id, '', (int) $invite->company_id );

		return [ 'message' => 'You have joined the team.', 'company_id' => (int) $invite->company_id ];
	}

	public function do_remove( int $actor_id, int $member_id ) {
		if ( ! $member_id ) return new \WP_Error( 'not_found', 'Member not found.' );

		global $wpdb;
		$member = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_team_members WHERE id=%d", $member_id ) );
		if ( ! $member ) return new \WP_Error( 'not_found', 'Member not found.' );

		$company = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_companies WHERE id=%d", $member->company_id ) );
		$is_owner_or_admin = ( $company && (int) $company->user_id === $actor_id ) || current_user_can( 'manage_options' );
		if ( ! $is_owner_or_admin && ! $this->is_manager_of( (int) $member->company_id, $actor_id ) ) {
			return new \WP_Error( 'forbidden', 'Permission denied.' );
		}

		// Ghost-success / access-control fix: this write was unchecked,
		// and the function unconditionally reported "Team member removed."
		// regardless. is_manager_of()/other membership checks throughout
		// this class read status from this exact table — a failed write
		// here means an admin genuinely believes they've revoked a
		// (possibly terminated or compromised) team member's access when
		// that member's row is still 'active' and their access is intact.
		$removed = $wpdb->update( $wpdb->prefix . 'jp_team_members', [
			'status'     => 'removed',
			'removed_at' => current_time( 'mysql' ),
		], [ 'id' => $member_id ] );
		if ( false === $removed ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_team_members remove update failed: ' . $wpdb->last_error ), 'JP_Team::do_remove member_id=' . $member_id );
			}
			return new \WP_Error( 'remove_failed', 'Could not remove this team member. Please try again.' );
		}

		JP_Security::instance()->audit( 'team_member_removed', 'team_member', $member_id, '', (int) $member->company_id );

		return [ 'message' => 'Team member removed.' ];
	}

	public function do_list( int $viewer_id, int $company_id_param = 0 ) {
		$company = $this->company_for_user( $viewer_id );
		$company_id = $company ? (int) $company->id : $company_id_param;
		if ( ! $company_id || ! $this->is_team_member_of( $company_id, $viewer_id ) ) {
			return new \WP_Error( 'forbidden', 'Permission denied.' );
		}

		global $wpdb;
		$members = $wpdb->get_results( $wpdb->prepare(
			"SELECT tm.*, u.display_name, u.user_email AS user_email_actual
			 FROM {$wpdb->prefix}jp_team_members tm
			 LEFT JOIN {$wpdb->users} u ON u.ID = tm.user_id
			 WHERE tm.company_id=%d AND tm.status!='removed'
			 ORDER BY tm.invited_at DESC",
			$company_id
		) );

		// Root-cause fix: tm.* pulls invite_token along with every member
		// row, and this result was returned to the client as-is — any
		// team member (not just managers) viewing /team could read the
		// raw accept-invite token for every pending invite, letting them
		// hijack someone else's invite via /team/accept. The token has
		// no legitimate use on the client (the accept flow gets it from
		// the invite email link, not from this list), so it's stripped.
		if ( $members ) {
			foreach ( $members as $m ) {
				unset( $m->invite_token );
			}
		}

		return [
			'members'     => $members ?: [],
			'seats_used'  => $this->seat_count( $company_id ),
			'seats_limit' => $this->seat_limit( $company_id ),
		];
	}

	public function do_reassign_job( int $actor_id, int $job_id, int $new_user_id ) {
		if ( ! current_user_can( 'jp_assign_jobs' ) && ! current_user_can( 'manage_options' ) ) {
			return new \WP_Error( 'forbidden', 'Permission denied.' );
		}
		if ( ! $job_id || ! $new_user_id ) return new \WP_Error( 'missing_params', 'Job and team member are required.' );

		global $wpdb;
		$job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_jobs WHERE id=%d", $job_id ) );
		if ( ! $job ) return new \WP_Error( 'not_found', 'Job not found.' );

		if ( ! $this->is_team_member_of( (int) $job->company_id, $actor_id ) ) {
			return new \WP_Error( 'forbidden', 'Permission denied.' );
		}
		if ( ! $this->is_team_member_of( (int) $job->company_id, $new_user_id ) ) {
			return new \WP_Error( 'not_team_member', "The selected user is not on this company's team." );
		}

		// Root-cause fix (batch 13 — same "ghost success" shape batches 8-9
		// found and fixed in class-jp-payments.php/class-jp-subscriptions.php:
		// return value of a $wpdb->update() never checked before). Lower
		// blast radius than those (a wrong assignee, not silent revenue/
		// credit loss), but the same failure mode: a failed UPDATE returns
		// false, and this code proceeded to audit-log "job reassigned" and
		// tell the caller it succeeded regardless.
		$updated = $wpdb->update( $wpdb->prefix . 'jp_jobs', [ 'posted_by' => $new_user_id ], [ 'id' => $job_id ], [ '%d' ], [ '%d' ] );
		if ( false === $updated ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception(
					new \Exception( 'jp_jobs reassign update failed: ' . $wpdb->last_error ),
					'JP_Team::do_reassign_job job_id=' . $job_id . ' new_user_id=' . $new_user_id
				);
			}
			return new \WP_Error( 'db_error', 'Could not reassign this job. Please try again or contact support.' );
		}

		JP_Security::instance()->audit( 'job_reassigned', 'job', $job_id, "Reassigned to user {$new_user_id}", (int) $job->company_id );

		return [ 'message' => 'Job reassigned.' ];
	}

	// ── Legacy AJAX wrappers (jp-theme's cookie-nonce path — see
	// ARCHITECTURE.md; kept for the legacy surface, unchanged behavior) ──────

	public function ajax_invite(): void {
		jp_verify_nonce( 'jp_general' );
		if ( ! is_user_logged_in() ) jp_json_response( false, 'Not authenticated.' );
		$result = $this->do_invite( get_current_user_id(), (string) ( $_POST['email'] ?? '' ), (string) ( $_POST['role'] ?? '' ), absint( $_POST['company_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) jp_json_response( false, $result->get_error_message() );
		jp_json_response( true, $result );
	}

	public function ajax_accept_invite(): void {
		jp_verify_nonce( 'jp_general' );
		if ( ! is_user_logged_in() ) jp_json_response( false, 'Please log in or register to accept this invitation.' );
		$result = $this->do_accept_invite( wp_get_current_user(), (string) ( $_POST['token'] ?? '' ) );
		if ( is_wp_error( $result ) ) jp_json_response( false, $result->get_error_message() );
		jp_json_response( true, $result );
	}

	public function ajax_remove(): void {
		jp_verify_nonce( 'jp_general' );
		if ( ! is_user_logged_in() ) jp_json_response( false, 'Not authenticated.' );
		$result = $this->do_remove( get_current_user_id(), absint( $_POST['member_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) jp_json_response( false, $result->get_error_message() );
		jp_json_response( true, $result );
	}

	public function ajax_list(): void {
		jp_verify_nonce( 'jp_general' );
		if ( ! is_user_logged_in() ) jp_json_response( false, 'Not authenticated.' );
		$result = $this->do_list( get_current_user_id(), absint( $_POST['company_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) jp_json_response( false, $result->get_error_message() );
		jp_json_response( true, $result );
	}

	public function ajax_reassign_jobs(): void {
		jp_verify_nonce( 'jp_general' );
		if ( ! is_user_logged_in() ) jp_json_response( false, 'Not authenticated.' );
		$result = $this->do_reassign_job( get_current_user_id(), absint( $_POST['job_id'] ?? 0 ), absint( $_POST['user_id'] ?? 0 ) );
		if ( is_wp_error( $result ) ) jp_json_response( false, $result->get_error_message() );
		jp_json_response( true, $result );
	}
}
