<?php
/**
 * JP_React — Registers the [jp_app] shortcode that mounts the React SPA.
 *
 * Enqueues the built Vite output from /app-dist/ (see enqueue_react_assets()'s
 * "Phase 5 cutover" docblock) and injects the JP_CONFIG object that the React
 * app reads at runtime for API URL, nonce, user info, and site settings.
 * NOTE: this docblock previously said /react-app/assets/ — that was the
 * pre-cutover legacy SPA's build output and is no longer what real traffic
 * is served from; the /react-app/ directory itself is still on disk only as
 * a rollback fallback (see enqueue_react_assets()), not as the live source.
 *
 * Usage on any WP page: [jp_app]
 * WordPress handles routing via React Router (BrowserRouter with basename).
 *
 * ── THIS CLASS IS HALF OF A TWO-FRONT-END PLUGIN — READ THIS FIRST ─────────
 * See /ARCHITECTURE.md (plugin root) for the full picture. In short: pages
 * assigned the `page-templates/tpl-react-app.php` template (or containing
 * [jp_app]) render entirely through THIS class's compiled React/Tailwind
 * app (app-dist/jp-app.css + JS chunks) — the theme's main.css has
 * ZERO effect on them, on purpose (dequeue_theme_assets() removes it).
 * Every other page (the theme's own single-jp_job.php, single-jp_company.php,
 * front-page.php, etc.) is styled by the theme's main.css instead and has
 * nothing to do with this class or app-dist/.
 *
 * The URL-prefix list in get_spa_prefixes() below is how a page with NO
 * matching WordPress object (a client-side React Router path) gets
 * recognized as belonging to this app. Because some of those prefixes
 * ('/jobs/', '/companies/') are shared with real, theme-rendered CPT
 * single pages, dequeue_theme_assets() and strip_theme_head_actions() both
 * check the resolved post's post_type FIRST and bail out immediately for a
 * real jp_job/jp_company post, before ever consulting the prefix list —
 * do not remove that guard, and do not add a new prefix here without
 * checking whether any theme single-*.php template's permalinks could
 * start with it too (see ARCHITECTURE.md's "Known trap" section — this
 * exact class of bug has shipped once already, silently stripping the
 * theme's CSS from every job/company listing page on a live site).
 */
defined( 'ABSPATH' ) || exit;

class JP_React {

    private static ?JP_React $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_shortcode( 'jp_app', [ $this, 'render_shortcode' ] );
        add_action( 'wp_enqueue_scripts', [ $this, 'maybe_enqueue' ] );

        // Register our full-page template so WP recognises it
        add_filter( 'theme_page_templates', [ $this, 'register_page_template' ] );
        add_filter( 'template_include',     [ $this, 'load_page_template' ] );

        // Suppress WP admin bar on React portal pages — it adds 32px margin-top
        // that shifts the React header down and conflicts with our sticky header.
        // Admins can still access /wp-admin directly.
        // wp action fires after WP query is set — is_page_template() works correctly here
        add_action( 'wp', [ $this, 'suppress_admin_bar' ] );

        // Root-cause fix (traced from repeated live reports of fixes
        // "not taking effect" no matter how many times the plugin was
        // redeployed, and the site's own domain — jbportal.in2.cdn-alpha.com
        // — strongly suggesting a CDN/edge cache sits in front of it):
        // this page's HTML is NOT static content. It embeds a fresh,
        // user-specific WP REST nonce and live is_logged/role/user data
        // (see enqueue_react_assets()'s JP_CONFIG) on every single request,
        // computed from is_user_logged_in()/wp_get_current_user() at
        // render time. WordPress sends no explicit cache-control for a
        // normal Page by default, which leaves any CDN, reverse proxy, or
        // full-page-cache plugin sitting in front of the site free to
        // cache this HTML — and every time it does, EVERY visitor served
        // that cached copy gets whichever user's nonce and login state was
        // baked in at the moment it was cached, not their own. That is a
        // real, separate security/correctness bug on top of explaining why
        // deployed fixes can appear to "do nothing": the cache can keep
        // serving a snapshot from before the fix existed indefinitely,
        // completely independent of whether the plugin files themselves
        // were correctly updated on disk. nocache_headers() is WordPress
        // core's own standard mechanism for exactly this ("this response
        // must never be cached") and is respected by essentially every
        // CDN/proxy that honors HTTP caching semantics at all; a CDN that
        // ignores Cache-Control entirely is a hosting-level setting outside
        // what this plugin can control; from here, this is the correct and
        // complete application-level fix.
        add_action( 'wp', [ $this, 'send_nocache_headers' ] );

        // Add type="module" to all JP React script tags
        // Vite builds ES modules (import/export) which REQUIRE type="module"
        // Without it, browser throws "Unexpected token 'export'" and nothing loads
        add_filter( 'script_loader_tag', [ $this, 'add_module_type' ], 10, 3 );

        // Remove theme scripts/styles on React portal pages.
        // Must be registered here (in __construct) BEFORE wp_enqueue_scripts fires.
        // The template file is loaded AFTER wp_enqueue_scripts — too late to add hooks there.
        add_action( 'wp_enqueue_scripts', [ $this, 'dequeue_theme_assets' ], 999 );
        add_action( 'wp_enqueue_scripts', [ $this, 'dequeue_theme_assets' ], 1001 ); // catch themes at priority 1000

        // Strip theme wp_head/wp_footer inline HTML output on React pages
        // Themes can output <link rel="preload">, <style>, <script> directly via wp_head action
        // bypassing the wp_styles/wp_scripts queue — dequeue alone doesn't catch these
        add_action( 'wp', [ $this, 'strip_theme_head_actions' ] );

        // Allow React Router to handle sub-paths without 404
        add_action( 'template_redirect', [ $this, 'handle_spa_routing' ] );

        // Add REST API settings endpoint for React app config
        add_action( 'rest_api_init', [ $this, 'register_config_route' ] );

        // Root-cause fix: this plugin creates the portal page and stores its
        // ID in jp_portal_page_id (see JP_Activator::create_pages()), but
        // never configures WordPress's own Reading Settings
        // (show_on_front / page_on_front). Those two options control what
        // renders at the site root ("/") — handle_spa_routing() above only
        // ever runs on an actual 404, and "/" is NOT a 404 on a stock
        // install; it resolves successfully to WordPress's built-in "Your
        // latest posts" front page, rendered by whatever theme is active
        // (the bundled default theme, once jp-theme is no longer installed
        // — this plugin is meant to be the entire frontend, so there is no
        // theme left to opt back into here). The practical symptom is a
        // site root that shows the default blog/theme instead of the SPA,
        // on an otherwise fully-configured install. Fixing this via the one
        // approved-for-edits class instead of the frozen activator, using
        // the same self-healing-on-every-request pattern already
        // established in jp-core.php (JP_Activator::ensure_missing_tables(),
        // JP_Migrator::run_pending()) — this also self-heals installs where
        // the option was reset by an unrelated theme switch or a "Reading
        // Settings" misclick, not just fresh installs.
        add_action( 'init', [ $this, 'maybe_fix_front_page' ], 20 );

        // Root-cause fix (confirmed via a live JP_Diagnostics run: "Permalink
        // Structure — FAIL — Plain permalinks (?p=123) — React Router routing
        // BROKEN", already tracked in class-jp-diagnostics.php's own "Known
        // Bug Regression Checks" section as Bug #7, but with no actual fix
        // shipped anywhere — it only ever detected the problem, never
        // corrected it). Plain permalinks don't just hurt SEO here: every
        // React Router path this plugin relies on (get_permalink() results
        // used for portal_url/basename, is_404()-based handle_spa_routing(),
        // and even the site root once maybe_fix_front_page() above points it
        // at the portal page) depends on WordPress's rewrite engine being on.
        // Self-heals using the SAME flag jp-core.php's own 'init' priority
        // 999 handler already consumes (see jp-core.php's
        // "Root-cause fix: performs the rewrite-rules flush requested
        // above..." handler) — this hooks in at a much earlier init priority
        // purely so that handler (already shipped, unmodified, out of this
        // class's edit scope) sees the flag by the time it runs, and does
        // the actual flush_rewrite_rules() call exactly once, in the one
        // place in this codebase already responsible for that.
        add_action( 'init', [ $this, 'maybe_fix_permalink_structure' ], 5 );

        // Root-cause fix (confirmed via a live JP_Diagnostics run: ".htaccess
        // Cache Headers — WARN — app-dist/.htaccess not found"). See
        // maybe_write_asset_htaccess()'s own docblock for the full
        // root-cause explanation (Vite wipes app-dist/ on every rebuild, and
        // this closes a real risk to the ?ver= cache-busting fix already
        // shipped in enqueue_react_assets() if the fronting CDN ignores
        // query strings). No ordering dependency on the other self-heals
        // above, so this runs at the default priority.
        add_action( 'init', [ $this, 'maybe_write_asset_htaccess' ] );

        // Root-cause fix (confirmed via a live JP_Diagnostics run: all 11
        // cron jobs "NOT SCHEDULED" on a site installed minutes earlier).
        // Traced to a real activation-order bug: JP_Activator::activate()
        // calls set_defaults(), which sets jp_installed_version = JP_VERSION
        // immediately — BEFORE the first normal page load ever happens.
        // jp-core.php's own 'plugins_loaded' bootstrap only calls
        // JP_Cron::schedule_all() inside `if ($stored !== JP_VERSION)` (a
        // version-bump self-heal), and JP_Activator::activate() itself never
        // calls JP_Cron::schedule_all() at all — so on a FRESH install,
        // jp_installed_version already equals JP_VERSION from the moment
        // activation finishes, the version-bump branch never sees a mismatch
        // on any subsequent request, and no cron job is ever scheduled until
        // an actual version bump happens later (or a manual
        // deactivate/reactivate, which class_jp-diagnostics.php's own
        // solution text already points users toward for this exact symptom
        // — a workaround for a bug that has a real fix). JP_Cron::schedule_all()
        // is documented as idempotent (guarded by wp_next_scheduled() per
        // hook), so calling it here, once per request, is safe and self-heals
        // this without touching JP_Activator (currently frozen/out of scope)
        // or waiting for a version bump that may never come.
        if ( class_exists( 'JP_Cron' ) ) {
            add_action( 'init', [ 'JP_Cron', 'schedule_all' ], 30 );
        }
    }

    /**
     * Self-healing check: make sure WordPress uses pretty permalinks.
     *
     * TRACE: fires on every 'init' (priority 5, deliberately BEFORE
     *        jp-core.php's own priority-999 'init' handler that performs the
     *        actual flush_rewrite_rules() call for the flag this sets) →
     *        reads permalink_structure → if empty ("Plain"), sets it to
     *        '/%postname%/' and raises the existing jp_needs_rewrite_flush
     *        flag jp-core.php already watches for.
     * PRECONDITIONS: none — a single get_option() read on every request.
     * POSTCONDITIONS: get_option('permalink_structure') is non-empty after
     *        this request if it was empty before; the actual rewrite-rules
     *        regeneration happens later in THIS SAME request via the
     *        already-existing priority-999 handler in jp-core.php, not here
     *        — this method never calls flush_rewrite_rules() itself, to
     *        avoid doing it twice from two different places with two
     *        different timing guarantees.
     * EDGE CASES: site intentionally run on Plain permalinks for an
     *        unrelated reason (rare, and incompatible with this plugin's
     *        React Router design regardless of the reason) — out of scope,
     *        matches the same judgment call already implicit in
     *        class-jp-diagnostics.php flagging Plain permalinks as an
     *        outright FAIL rather than a site-choice WARN.
     */
    public function maybe_fix_permalink_structure(): void {
        if ( get_option( 'permalink_structure' ) ) {
            return; // already using pretty permalinks — nothing to do
        }

        update_option( 'permalink_structure', '/%postname%/' );
        update_option( 'jp_needs_rewrite_flush', 1 );
    }

    /**
     * Self-healing check: keep app-dist/.htaccess present and correct.
     *
     * TRACE: fires on every 'init' → compares app-dist/.htaccess's current
     *        contents (if any) against the expected contents → rewrites it
     *        only when missing or different, so this is a cheap no-op on
     *        every normal request once correct.
     * PRECONDITIONS: app-dist/ exists (it's shipped with the plugin) and is
     *        writable by PHP (same permission level the plugin itself was
     *        just deployed with).
     * POSTCONDITIONS: app-dist/.htaccess exists with the cache-control
     *        rules below.
     * EDGE CASES: app-dist/ not writable (unusual but possible on some
     *        locked-down hosts) → file_put_contents() fails silently
     *        (@-suppressed) and this becomes a permanent no-op; the
     *        underlying risk this exists to close (see below) then has to
     *        be handled at the host/CDN configuration level instead.
     *
     * Root-cause fix (found via the live diagnostic report flagging
     * app-dist/.htaccess as missing, and CONFIRMED live: a subsequent
     * browser console dump showed the entry JS served with
     * `nestify-cdn-status: HIT` — proof the fronting CDN keys purely on
     * URL path and ignores the `?ver=` query string, which then went on
     * to cause a real production failure — a stale cached entry bundle
     * dynamically importing a route chunk from a prior build that no
     * longer existed on disk, a 404, and a cascading React crash).
     * app-dist/ is also regenerated from scratch on every `npm run build`
     * (vite.config.ts's emptyOutDir: true wipes the directory first) — so
     * a hand-placed .htaccess file would be silently deleted on the very
     * next build. Self-healing it here, the same way this codebase already
     * self-heals permalinks/front-page/crons, means it comes back
     * automatically no matter how many times the app gets rebuilt.
     *
     * Given the confirmed CDN behavior above, the entry JS filename itself
     * was ALSO changed (see vite.config.ts's entryFileNames — it now
     * carries a Rollup content hash, jp-app.<version>-<hash>.js, exactly
     * like the lazy chunk files always have) so its cache-busting no
     * longer depends on this CDN honoring anything — a content change
     * produces a new PATH, which even a query-string-blind, header-blind
     * cache cannot continue serving under. That means the entry JS can
     * now safely join the chunk files in the same long-cache-immutable
     * bucket below. jp-app.css was NOT given the same hash treatment in
     * this pass (its fixed filename is depended on by ~15 existing
     * diagnostic checks in class-jp-diagnostics.php; hashing it is a
     * larger, separate refactor deferred rather than rushed unverified) —
     * it keeps the no-store treatment here as the interim defense for
     * exactly the same class of risk.
     */
    public function maybe_write_asset_htaccess(): void {
        $path = JP_PLUGIN_DIR . 'app-dist/.htaccess';

        $expected = <<<HTACCESS
# Auto-managed by JP Core — see JP_React::maybe_write_asset_htaccess().
# Regenerated automatically on every request if missing or out of date;
# do not hand-edit, changes will be silently overwritten.
<IfModule mod_headers.c>
  # Content-hashed files: any content change produces a new filename, so
  # a stale cached copy under an old name can never be served for new
  # content — this covers both the lazy route chunks (chunks/Name-<hash>.js)
  # and the main entry JS (jp-app.<version>-<hash>.js), which was changed
  # to also carry a content hash after live evidence showed the fronting
  # CDN ignores ?ver= cache-busting entirely. Safe to cache for a long time.
  <FilesMatch "^(chunks/.+-[A-Za-z0-9_]{8}\\.js|jp-app\\.[0-9]+(\\.[0-9]+)*-[A-Za-z0-9_]+\\.js)$">
    Header set Cache-Control "public, max-age=31536000, immutable"
  </FilesMatch>

  # jp-app.css keeps a fixed name across rebuilds (not yet content-hashed —
  # see docblock above) — cache-busting for it relies on a ?ver= query
  # string appended by WordPress's enqueue system. Some CDNs/caches key
  # purely on URL path and ignore query strings, which would silently
  # defeat that entirely. Forcing no-store here means a stale build can
  # never be served regardless of how the fronting cache is configured.
  <FilesMatch "^jp-app\\.css$">
    Header set Cache-Control "no-store, must-revalidate"
  </FilesMatch>
</IfModule>
HTACCESS;

        $current = file_exists( $path ) ? @file_get_contents( $path ) : false;
        if ( $current === $expected ) {
            return; // already correct — nothing to do
        }

        @file_put_contents( $path, $expected );
    }

    /**
     * Self-healing check: make sure WordPress serves the SPA's portal page
     * at the site root ("/") instead of the default blog index.
     *
     * TRACE: fires on every 'init' (priority 20, after JP_CPT registers post
     *        types on the default priority 10, so get_portal_page()'s page
     *        lookups run against a fully-booted query environment) →
     *        checks whether Reading Settings already point at a live page →
     *        if not, points them at the resolved portal page.
     * PRECONDITIONS: none — safe to run before pages exist (get_portal_page()
     *        returns null and this becomes a no-op) and safe to run on every
     *        request (cheap option reads short-circuit the common case).
     * POSTCONDITIONS: get_option('show_on_front') === 'page' and
     *        get_option('page_on_front') is a published page's ID whenever
     *        get_portal_page() can resolve one; WordPress options are
     *        otherwise left untouched.
     * EDGE CASES: portal page not yet created (no-op, retried next request);
     *        page_on_front pointing at a page that was since trashed/deleted
     *        (detected via get_post_status() check, re-fixed); site
     *        intentionally configured to show a *different* page than the
     *        portal on some other page ID (out of scope — this plugin's own
     *        options only ever point at its own resolved portal page id, so
     *        this cannot fight a site that was never pointed at jp-core's
     *        page in the first place... but see note below on re-fixing).
     */
    public function maybe_fix_front_page(): void {
        // Cheap check first: if Reading Settings already show a page whose
        // ID matches what THIS plugin considers the portal page, and that
        // page still exists and is published, there is nothing to do —
        // avoids a get_posts()/DB query (inside get_portal_page()) on the
        // overwhelming majority of requests once the site is configured.
        $show_on_front = get_option( 'show_on_front' );
        $current_front = (int) get_option( 'page_on_front' );
        $stored_portal = (int) get_option( 'jp_portal_page_id', 0 );

        if (
            $show_on_front === 'page'
            && $current_front > 0
            && $current_front === $stored_portal
            && get_post_status( $current_front ) === 'publish'
        ) {
            return; // already correctly configured
        }

        $portal_page = $this->get_portal_page();
        if ( ! $portal_page ) {
            return; // pages not created yet (e.g. activation hasn't run) — nothing to point at
        }

        if ( $show_on_front === 'page' && $current_front === $portal_page->ID ) {
            return; // already correct, matches the just-resolved portal page
        }

        update_option( 'show_on_front', 'page' );
        update_option( 'page_on_front', $portal_page->ID );
    }

    /**
     * Add type="module" to all JP React script tags.
     *
     * ES modules (Vite default output) require this attribute.
     * Without it the browser treats the file as a classic script and
     * throws SyntaxError on the first import/export statement.
     *
     * Also removes the redundant defer attribute — type=module scripts
     * are automatically deferred by the browser.
     */
    public function add_module_type( string $tag, string $handle, string $src ): string {
        // Only our main script handle
        if ( $handle !== 'jp-react-app' ) {
            return $tag;
        }
        // Guard: only transform if it's actually our JP app script
        if ( ! str_contains( $src, 'jp-app' ) && ! str_contains( $src, 'jp-core' ) ) {
            return $tag;
        }

        // Replace <script ... src with <script type="module" src
        // Also remove defer attribute since type=module implies defer
        $tag = str_replace( ' defer', '', $tag );
        $tag = str_replace( " type='text/javascript'", '', $tag );
        $tag = str_replace( ' type="text/javascript"', '', $tag );
        $tag = str_replace( '<script ', '<script type="module" ', $tag );

        return $tag;
    }

    /**
     * Remove all theme/plugin scripts and styles from React portal pages.
     * Theme JS that modifies the DOM causes React removeChild/insertBefore crashes.
     * Called at wp_enqueue_scripts priority 999 — after all themes enqueue at 10.
     * Only runs on pages using our React template.
     */
    // TRACE: triggered by wp_enqueue_scripts at priority 999 → removes all theme/plugin assets
    // PRECONDITIONS: $post is set; wp_enqueue_scripts has fired
    // POSTCONDITIONS: only 'jp-react-app' CSS and JS remain in the WP queue
    // EDGE CASES:
    //   SPA-routed pages (/login/, /dashboard/ etc.) — $post may be 404 page, not the React page.
    //   Use is_page_template() which correctly reflects the template AFTER handle_spa_routing.
    //   BUT: wp_enqueue_scripts fires BEFORE template_redirect (where SPA routing runs).
    //   Solution: also check the SPA path prefixes directly to catch these pages.
    // ROLES ALLOWED: fires on all requests, applies only on React portal pages

    public function dequeue_theme_assets(): void {
        global $post;

        // Root-cause fix: get_spa_prefixes() lists '/jobs/' and '/companies/'
        // so Check 3 below can catch client-side React Router paths like
        // /jobs/123 that live INSIDE the SPA and have no real WP object of
        // their own. But those exact same prefixes also match the theme's
        // own real, separately-rendered pages for individual listings —
        // /jobs/{job-slug}/ (single-jp_job.php, a jp_job post) and
        // /companies/{company-slug}/ (single-jp_company.php, a jp_company
        // post) — which are NOT part of the React app at all. Check 3's bare
        // string-prefix match couldn't tell those apart from a genuine SPA
        // route, so it was classifying every individual job listing and
        // every company profile — by far the highest-traffic, most-linked
        // pages on a job portal — as a React page: it dequeued the theme's
        // own 'jp-theme' stylesheet (the only stylesheet that defines
        // .jp-job-card, .jp-badge--*, .jp-container, etc. — everything
        // single-jp_job.php/single-jp_company.php's markup actually uses)
        // and left only jp-app.css (a completely different, Tailwind-based
        // design system built for the SPA's own components) in place. The
        // result: every job/company detail page rendered with none of its
        // own CSS at all — raw, unstyled HTML — which is exactly what
        // "CSS completely broken on most pages" looks like. A real jp_job/
        // jp_company singular post always has its own correct theme
        // template, so it must never be treated as a React page here,
        // regardless of what its URL happens to start with.
        if ( is_a( $post, 'WP_Post' ) && in_array( $post->post_type, [ 'jp_job', 'jp_company' ], true ) ) {
            return;
        }

        // Determine if this is a React portal page.
        // Three checks because SPA routing patches $GLOBALS['post'] late:
        $is_react = false;

        // Check 1: page has our template assigned in post meta
        if ( is_a( $post, 'WP_Post' ) ) {
            $template = get_post_meta( $post->ID, '_wp_page_template', true );
            if ( $template === 'page-templates/tpl-react-app.php' ) {
                $is_react = true;
            }
            // Check 2: page content has [jp_app] shortcode
            if ( has_shortcode( $post->post_content ?? '', 'jp_app' ) ) {
                $is_react = true;
            }
        }

        // Check 3: URL path matches known React SPA paths (catches SPA-routed 404→React pages
        // where $post is the 404 object at this hook firing time)
        if ( ! $is_react ) {
            $path = '/' . ltrim( parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ) ?? '', '/' );
            foreach ( $this->get_spa_prefixes() as $prefix ) {
                if ( $this->path_matches_prefix( $path, $prefix ) ) {
                    $is_react = true;
                    break;
                }
            }
        }

        if ( ! $is_react ) {
            return; // Not a React page — leave theme assets alone
        }

        global $wp_scripts, $wp_styles;

        // Dequeue all styles except our React CSS
        // Iterate over a copy — modifying the queue while iterating causes skips
        $styles_to_remove = array_diff( $wp_styles->queue ?? [], [ 'jp-react-app' ] );
        foreach ( $styles_to_remove as $handle ) {
            wp_dequeue_style( $handle );
            wp_deregister_style( $handle );
        }

        // Dequeue all scripts except our React bundle and WP core requirements
        $keep = [ 'jp-react-app', 'jquery' ];
        $scripts_to_remove = array_diff( $wp_scripts->queue ?? [], $keep );
        foreach ( $scripts_to_remove as $handle ) {
            wp_dequeue_script( $handle );
            wp_deregister_script( $handle );
        }

        // Also remove wp_footer scripts that themes may enqueue late
        // (themes that use wp_footer to add their JS will still be caught by the
        // wp_deregister_script calls above since those remove from the registry too)
    }

    /**
     * Remove theme functions hooked to wp_head on React portal pages.
     * Themes can output <link rel="preload"> and <script> tags directly via
     * wp_head action — these bypass wp_styles/wp_scripts queue entirely.
     * We remove the theme's entire stylesheet and script output.
     */
    // TRACE: triggered by 'wp' action (priority 10) → safely strips theme HTML/JS output
    //        from wp_head, wp_body_open, and wp_footer on React portal pages.
    // PRECONDITIONS: 'wp' action has fired; $post query is set
    // POSTCONDITIONS:
    //   - No theme <link rel=preload>, <link rel=manifest>, <script> in page head/body/footer
    //   - No theme JS in wp_footer that can mutate React's DOM (root cause of removeChild)
    //   - Our JP React CSS (jp-react-app) and JS bundle still output correctly
    //   - JP_CONFIG inline script still output before the React bundle
    // IMPLEMENTATION: Uses remove_all_actions() + selective re-add instead of iteration.
    //   Iterating $wp_filter['wp_head']->callbacks while calling remove_action() modifies
    //   the same array → unpredictable skips. remove_all_actions() is atomic and safe.
    // EDGE CASES: SPA-routed pages handled by URL path matching (same as dequeue_theme_assets)
    // BUSINESS RULE: Theme JS must NOT touch #jp-root DOM — causes removeChild crash in React

    public function strip_theme_head_actions(): void {
        global $post;

        // Root-cause fix: identical reasoning to the guard in
        // dequeue_theme_assets() above — a real jp_job/jp_company singular
        // post must never be swept up by the '/jobs/'/'/companies/' SPA
        // prefix match below, or this function strips every theme hook from
        // wp_head/wp_body_open/wp_footer on the site's own job/company
        // detail pages, on top of the CSS already being dequeued elsewhere.
        if ( is_a( $post, 'WP_Post' ) && in_array( $post->post_type, [ 'jp_job', 'jp_company' ], true ) ) {
            return;
        }

        $is_react = false;
        if ( is_a( $post, 'WP_Post' ) ) {
            $template = get_post_meta( $post->ID, '_wp_page_template', true );
            if ( $template === 'page-templates/tpl-react-app.php' ) $is_react = true;
            if ( has_shortcode( $post->post_content ?? '', 'jp_app' ) ) $is_react = true;
        }
        if ( ! $is_react ) {
            $path = '/' . ltrim( parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ) ?? '', '/' );
            foreach ( $this->get_spa_prefixes() as $prefix ) {
                if ( $this->path_matches_prefix( $path, $prefix ) ) {
                    $is_react = true;
                    break;
                }
            }
        }
        if ( ! $is_react ) return;

        // ── wp_head: remove ALL hooks, then re-add only what React needs ─────
        // This is safe: remove_all_actions() clears the callback array atomically,
        // then we add back exactly the WP core functions that output our assets.
        // wp_resource_hints is intentionally NOT re-added: it outputs <link rel=preload>
        // for theme stylesheets even after dequeue, loading theme CSS as a network request.
        remove_all_actions( 'wp_head' );
        // Re-add ONLY the WP core functions needed for our React app.
        // wp_enqueue_scripts  → triggers do_action('wp_enqueue_scripts') so our
        //                       maybe_enqueue() registers the jp-react-app handle.
        // wp_print_styles     → outputs <link href="jp-app.css"> (our Tailwind CSS).
        // _wp_render_title_tag → <title> element (SEO, browser tab).
        // locale_stylesheet   → RTL stylesheet if needed.
        // wp_site_icon        → favicon <link>.
        //
        // NOT re-added: wp_print_head_scripts — our bundle is in_footer=true and is
        // output by wp_print_footer_scripts. Adding wp_print_head_scripts risks
        // double-printing if WP's internal state gets confused about in-head vs in-footer.
        // NOT re-added: wp_resource_hints — outputs <link rel=preload> for theme CSS
        // even after we dequeue it, causing stale resource fetches.
        add_action( 'wp_head', 'wp_enqueue_scripts',        1  );  // triggers enqueue callbacks
        add_action( 'wp_head', '_wp_render_title_tag',      1  );  // <title>
        add_action( 'wp_head', 'locale_stylesheet',         8  );  // RTL
        add_action( 'wp_head', 'wp_print_styles',           9  );  // our jp-react-app CSS
        add_action( 'wp_head', 'wp_site_icon',              99 );  // favicon

        // ── wp_body_open: remove ALL hooks ───────────────────────────────────
        // Theme DOM injection right after <body> causes removeChild if theme later
        // moves those nodes. We have no content to add here ourselves.
        remove_all_actions( 'wp_body_open' );

        // ── wp_footer: remove ALL hooks, re-add only our script output ────────
        // Theme JS in wp_footer is the DIRECT cause of removeChild/insertBefore crashes:
        // React mounts first → theme JS runs after → theme modifies React-owned DOM nodes.
        remove_all_actions( 'wp_footer' );
        add_action( 'wp_footer', 'wp_print_footer_scripts', 20 );  // outputs our React bundle + JP_CONFIG
    }

    /** Helper: get a readable name from a callable */
    private function get_callback_name( $fn ): string {
        if ( is_string( $fn ) ) return $fn;
        if ( is_array( $fn ) ) {
            $obj = $fn[0];
            $method = $fn[1] ?? '';
            return ( is_object( $obj ) ? get_class( $obj ) : (string) $obj ) . '::' . $method;
        }
        if ( $fn instanceof \Closure ) return '{closure}';
        return '';
    }

    /** Helper: check if a hook name should be kept (matches any item in the keep list) */
    private function should_keep_hook( string $fn_name, array $keep_list ): bool {
        foreach ( $keep_list as $keep ) {
            if ( str_contains( $fn_name, $keep ) ) return true;
        }
        return false;
    }

    /**
     * Boundary-aware prefix match: true only if $path IS $prefix (ignoring a
     * trailing slash) or continues at a real '/' segment boundary.
     *
     * TRACE: called from dequeue_theme_assets()/strip_theme_head_actions() Check 3
     *        → normalizes $prefix by trimming any trailing slash, then requires
     *        an exact match or a match followed immediately by '/'
     *        → returns bool, no mutation.
     * PRECONDITIONS: $path is a leading-slash-normalized URL path (see callers)
     * POSTCONDITIONS: never true for a $path that merely shares a character
     *   prefix with $prefix without a '/' boundary — see BUSINESS RULE.
     * EDGE CASES: $prefix already has a trailing slash (rtrim handles it);
     *   $path exactly equals the normalized prefix (handled by the first branch).
     *
     * BUSINESS RULE / ROOT CAUSE FIXED: get_spa_prefixes() intentionally lists
     * bare prefixes without trailing slashes (e.g. '/community', '/events').
     * The previous check — str_starts_with($path, $prefix) — matched ANY path
     * that merely started with those characters, so a real WP page at
     * '/community-guidelines/' or '/eventscalendar-2024/' was misidentified as
     * a React SPA page purely by character-prefix collision, with no actual
     * route relationship. That caused dequeue_theme_assets()/
     * strip_theme_head_actions() to strip the real page's own theme CSS/JS —
     * the exact same "CSS completely broken" failure mode already documented
     * above for the jp_job/jp_company case, but via an entirely different,
     * previously-unguarded code path. Confirmed via direct execution:
     *   str_starts_with('/community-guidelines/', '/community') === true
     *   str_starts_with('/eventscalendar-2024/', '/events') === true
     * Requiring a '/' boundary (or an exact match) after trimming the
     * prefix's own trailing slash eliminates both false positives while still
     * matching every genuine sub-route (e.g. '/community/123/').
     */
    private function path_matches_prefix( string $path, string $prefix ): bool {
        $normalized = rtrim( $prefix, '/' );
        return $path === $normalized || str_starts_with( $path, $normalized . '/' );
    }

    /** Central SPA path prefix list — shared by dequeue and strip functions */
    private function get_spa_prefixes(): array {
        // Keep this list in sync with React Router routes in src/routes/router.tsx
        // (the ground-up rewrite in app/, not the legacy App.tsx this comment
        // originally referred to). Every React route that doesn't correspond
        // to a real WP page must be here, or a direct hit / page refresh on
        // it 404s instead of loading the SPA.
        // Prefix matching: '/admin/' catches /admin, /admin/users, /admin/health etc.
        //
        // Added during the Phase 5 cutover audit: '/pricing', '/community',
        // and '/profiles/' are real router.tsx routes ('/community/:id' and
        // '/profiles/:id' in particular have no matching WP object at all —
        // a numeric community-post or candidate-profile id) that this list
        // hadn't been updated for since they were built.
        //
        // Root-cause fix (public-pages CSS bug report): 'reset-password' and
        // 'team/accept' (router.tsx lines ~284-285) were never added to this
        // list even though they're real, unauthenticated router.tsx routes
        // reached by direct link from password-reset and team-invite emails —
        // by definition a fresh page load with no prior SPA navigation, so
        // Check 3 (this list) is the ONLY check that can classify them; Check
        // 1/2 (page template / shortcode) don't help here because the visitor
        // is landing cold on a URL, and $post at hook-fire time is WP's 404
        // object, not the tpl-react-app.php page. With these two prefixes
        // missing, dequeue_theme_assets()/strip_theme_head_actions() both
        // returned early and left the theme's own jp-theme stylesheet (and
        // wp_head/wp_footer hooks) loaded on top of jp-app.css — the theme's
        // classes collide with the Tailwind-based SPA classes, which is what
        // "CSS not properly applied" on a public page looks like.
        return [
            '/dashboard/', '/dashboard',
            '/recruiter/', '/recruiter',
            '/admin/', '/admin',
            '/jobs/', '/jobs',
            '/companies/', '/companies',
            '/salary', '/candidate/', '/events',
            '/help', '/market', '/changelog',
            '/onboarding', '/notifications',
            '/login/', '/login',
            '/register/', '/register',
            '/forgot-password',
            '/reset-password',
            '/team/accept', '/team/',
            '/pricing',
            '/community/', '/community',
            '/profiles/',
        ];
    }

        /**
     * Suppress the WP admin toolbar on React portal pages.
     * Hooked to 'wp' action — after WP query is set, so is_page_template() works.
     * Admin bar adds 32px margin-top to <body> via inline style, breaking React layout.
     */
    public function suppress_admin_bar(): void {
        global $post;
        $is_template   = is_page_template( 'page-templates/tpl-react-app.php' );
        $has_shortcode = is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'jp_app' );
        if ( $is_template || $has_shortcode ) {
            show_admin_bar( false );
        }
    }

    // TRACE: triggered by 'wp' action on every request → detects whether this page hosts the React app
    // PRECONDITIONS: WP's main query has resolved (global $post set, is_page_template() usable)
    // POSTCONDITIONS: if this page hosts the SPA, sends headers forbidding any cache from storing the response
    // EDGE CASES: a CDN/proxy that ignores Cache-Control entirely is unaffected — that is a hosting
    //             configuration outside this plugin's control, not something these headers can force
    public function send_nocache_headers(): void {
        global $post;
        $is_template   = is_page_template( 'page-templates/tpl-react-app.php' );
        $has_shortcode = is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'jp_app' );
        if ( ! $is_template && ! $has_shortcode ) return;
        if ( headers_sent() ) return;

        nocache_headers(); // WP core: Cache-Control, Pragma, Expires — the standard "never cache this" signal.

        // Defense-in-depth for CDNs/proxies that look at their own
        // vendor-specific headers instead of (or in addition to) the
        // standard ones nocache_headers() already sends above.
        header( 'CDN-Cache-Control: no-store' );
        header( 'Cloudflare-CDN-Cache-Control: no-store' );
        header( 'Surrogate-Control: no-store' );
    }

    /** Register our template in the page template dropdown */
    public function register_page_template( array $templates ): array {
        $templates['page-templates/tpl-react-app.php'] = 'JP React App (Full Page)';
        return $templates;
    }

    /** Load our template file when the page uses it */
    public function load_page_template( string $template ): string {
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) ) return $template;

        $assigned = get_post_meta( $post->ID, '_wp_page_template', true );
        if ( $assigned !== 'page-templates/tpl-react-app.php' ) return $template;

        $plugin_template = JP_PLUGIN_DIR . 'templates/page-templates/tpl-react-app.php';
        return file_exists( $plugin_template ) ? $plugin_template : $template;
    }

    // ── Shortcode renderer ────────────────────────────────────────────────────

    public function render_shortcode( array $atts = [] ): string {
        // Enqueue assets when shortcode is rendered
        $this->enqueue_react_assets();

        return '<div id="jp-root" aria-label="JP Jobs Portal" role="main"></div>';
    }

    // ── Conditional enqueue ───────────────────────────────────────────────────

    public function maybe_enqueue(): void {
        global $post;
        if ( ! is_a( $post, 'WP_Post' ) ) return;

        // Fire on pages using our full-page template OR containing [jp_app] shortcode
        $template = get_post_meta( $post->ID, '_wp_page_template', true );
        $is_react_template = ( $template === 'page-templates/tpl-react-app.php' );
        $has_shortcode     = has_shortcode( $post->post_content, 'jp_app' );

        if ( $is_react_template || $has_shortcode ) {
            $this->enqueue_react_assets();
        }
    }

    // ── Public enqueue (called by full-page template directly) ──────────────
    public function force_enqueue(): void {
        $this->enqueue_react_assets();
    }

    // ── Asset registration and localization ───────────────────────────────────
    // TRACE: triggered by maybe_enqueue() or render_shortcode() → registers CSS + JS + JP_CONFIG
    // PRECONDITIONS: JP_PLUGIN_DIR and JP_PLUGIN_URL defined; wp_enqueue_scripts already fired
    // POSTCONDITIONS: 'jp-react-app' handle in WP queue; JP_CONFIG inline script in page head
    // EDGE CASES: static $done guard prevents double registration on pages that both use
    //             the React template AND contain the [jp_app] shortcode in content.
    //             Without this guard: wp_localize_script fires twice → 2 JP_CONFIG blocks →
    //             second block clobbers first (different nonce) → auth failures.

    private function enqueue_react_assets(): void {
        // Guard: must run exactly once per request. Both maybe_enqueue() and render_shortcode()
        // can call this. Without a guard, a page using the React template + [jp_app] shortcode
        // causes wp_localize_script to run twice → duplicate JP_CONFIG blocks in page HTML.
        static $done = false;
        if ( $done ) return;
        $done = true;

        // Phase 5 cutover (JP-PLATFORM-ROADMAP.md Part 5): the ground-up
        // React+TypeScript rewrite in app/ builds to ../app-dist/ (see
        // app/vite.config.ts's outDir) using the exact same
        // "jp-app.<version>.js" / "jp-app.css" naming convention the glob
        // below and add_module_type() already look for, and the exact same
        // #jp-root mount id the markup below and tpl-react-app.php already
        // output — so no other change in this file's asset-loading logic
        // was needed, only the source directory. The legacy react-app/
        // directory is left on disk (not deleted) so this is reversible by
        // reverting this one line if a regression is found post-cutover.
        $app_dir = JP_PLUGIN_DIR . 'app-dist/';
        $app_url = JP_PLUGIN_URL . 'app-dist/';

        // ── CSS ───────────────────────────────────────────────────────────────
        if ( file_exists( $app_dir . 'jp-app.css' ) ) {
            wp_enqueue_style(
                'jp-react-app',
                $app_url . 'jp-app.css',
                [],
                filemtime( $app_dir . 'jp-app.css' )
            );
        }

        // ── Main entry point (ES module) ──────────────────────────────────────
        // Filename includes plugin version (jp-app.5.8.0.js) so CDN cache is
        // automatically busted on every plugin update — no manual CDN purge needed.
        // Find the versioned entry file dynamically so this code works across versions.
        $main_path = '';
        foreach ( glob( $app_dir . 'jp-app.*.js' ) as $f ) {
            $main_path = $f;
            break; // There should only be one
        }
        // Fallback to legacy name if versioned file not found
        if ( ! $main_path ) {
            $main_path = $app_dir . 'jp-app.js';
        }
        $main_file = basename( $main_path );

        // Root-cause fix (gap analysis P1: "jp_react_app_version is tracked
        // but nothing verifies it against the actual deployed React build's
        // file hash/mtime — the same class of 'silent version drift' that
        // caused the theme-zip incident exists, unaddressed, for the other
        // front-end"). jp_react_app_version was previously just set equal
        // to JP_VERSION on every plugin version bump (see jp-core.php /
        // class-jp-activator.php) — a blind copy that assumes the React
        // build was rebuilt and re-deployed in lockstep with every plugin
        // release, with nothing checking whether that was actually true.
        // The version embedded in this filename IS the ground truth (it's
        // baked in at build time by the SPA's own build pipeline) — record
        // it as the option's real value instead of overwriting it with an
        // unrelated number every time. See admin_health() in
        // class-jp-api.php for where this now surfaces a mismatch to an
        // admin instead of staying silent. Confirmed via the shipped build
        // in this very codebase: the file on disk is jp-app.6.10.2.js while
        // JP_VERSION is well past that — exactly the drift this gap
        // analysis item warned was unaddressed, not a hypothetical.
        //
        // Regex updated alongside vite.config.ts's entryFileNames change
        // (see that file's docblock: a live CDN cache-key bug meant this
        // filename now also carries a trailing Rollup content hash,
        // jp-app.<version>-<hash>.js, not just jp-app.<version>.js). The
        // hash segment is intentionally NOT captured into
        // jp_react_app_version — that option tracks the human-readable
        // build version for admin display/mismatch detection, and the
        // hash has no meaning outside cache-busting.
        if ( preg_match( '/^jp-app\.([\d.]+)-[A-Za-z0-9_]+\.js$/', $main_file, $m ) ) {
            $detected_version = $m[1];
            if ( get_option( 'jp_react_app_version' ) !== $detected_version ) {
                update_option( 'jp_react_app_version', $detected_version );
            }
        }

        if ( file_exists( $main_path ) ) {
            // Root-cause fix (confirmed via live browser console: a rebuilt
            // jp-app.<version>.js was deployed with corrected content, but
            // the ?ver= query string didn't change because it was pinned to
            // JP_VERSION, not to anything about the actual file. Any React
            // rebuild that doesn't also bump the plugin version number (e.g.
            // this exact vite.config.ts base-path fix, or any future hotfix
            // rebuild) reuses the identical enqueue URL, so browsers and any
            // CDN in front of the site keep serving the byte-for-byte stale
            // cached file indefinitely — no amount of re-uploading the
            // corrected file changes what gets served, only re-requesting a
            // *different* URL does. filemtime(), already used for jp-app.css
            // below in this same function, is the correct fix: it changes
            // automatically on every rebuild regardless of whether the
            // plugin version changed, guaranteeing a fresh URL — and
            // therefore a real cache miss — every time the JS content
            // actually changes.
            wp_enqueue_script(
                'jp-react-app',
                $app_url . $main_file,
                [],    // No WP deps — browser resolves ESM imports via relative paths
                filemtime( $main_path ), // Cache-busts on every rebuild, independent of JP_VERSION
                true   // in_footer
            );

            // JP_CONFIG injected as classic inline script before the module script.
            // Classic inline scripts run immediately during parse, before deferred modules.
            // So JP_CONFIG is guaranteed set when jp-app.js executes.
            wp_localize_script( 'jp-react-app', 'JP_CONFIG', $this->build_config() );
        }

        // Service worker disabled — WP plugin path (/wp-content/plugins/...)
        // prevents the SW from controlling root-scope paths (/jobs/, /dashboard/ etc.)
        // Re-enable when a root-path SW serving solution is in place.

        // ── Prevent WordPress head bloat on React pages ───────────────────────
        remove_action( 'wp_head', 'wp_generator' );
        remove_action( 'wp_head', 'wlwmanifest_link' );
        remove_action( 'wp_head', 'rsd_link' );
    }

    /**
     * Public accessor for JP_Diagnostics — lets the config contract be
     * verified IN-PROCESS (direct PHP call, no HTTP round trip) alongside
     * the existing network-loopback check. Root-cause context: a live
     * diagnostic run showed /config (and several other endpoints, AND the
     * homepage itself) coming back as HTTP 200 with a completely empty
     * body via wp_remote_get() loopback calls made FROM WITHIN that same
     * diagnostics page's own execution — while an earlier, independent
     * BROWSER hit against /config got back actual (wrong, but non-empty)
     * HTML content. That mismatch is the signature of loopback
     * self-serialization (this server's own request queue getting starved
     * by a request calling back into itself) rather than a real bug in
     * build_config() — a well-documented WordPress anti-pattern (the same
     * one Site Health's own loopback check exists to detect). Testing the
     * actual config contract without a network round trip closes that gap
     * for good, independent of hosting/worker-count flakiness.
     */
    public function diagnostics_get_config(): array {
        return $this->build_config();
    }

    // ── Build JP_CONFIG object ────────────────────────────────────────────────

    private function build_config(): array {
        $user    = wp_get_current_user();
        $is_auth = is_user_logged_in();

        $config = [
            // API base URL
            'api_url'   => rest_url( JP_Api::namespace_str() ), // Batch 31: was hardcoded 'jp/v1' — the ONE call site the whole SPA's routing depends on, now sourced from the single namespace constant.
            'ajax_url'  => admin_url( 'admin-ajax.php' ),
            'home_url'  => home_url( '/' ),
            // portal_url = URL of the page with [jp_app] — React Router basename
            // React reads: new URL(JP_CONFIG.portal_url).pathname
            'portal_url'=> $this->get_portal_url(),

            // WP nonce for REST API (cookie auth fallback for non-JWT requests)
            'nonce'     => wp_create_nonce( 'wp_rest' ),
            'ajax_nonce'=> wp_create_nonce( 'jp_general' ),

            // Auth state (lets React skip /auth/me call if already server-rendered)
            'is_logged' => $is_auth,
            'user_id'   => $is_auth ? (int) $user->ID : 0,
            'role'      => $is_auth && function_exists( 'jp_current_role' ) ? jp_current_role() : '', // Fixed: was user_role, React reads role
            'user_name' => $is_auth ? $user->display_name : '',
            'user_email'=> $is_auth ? $user->user_email : '',

            // Site settings
            'site_name' => get_option( 'jp_site_name', get_bloginfo( 'name' ) ),
            'currency'  => '₹',
            'timezone'  => get_option( 'timezone_string', 'Asia/Kolkata' ),

            // Feature flags
            'openai_enabled'    => ! empty( JP_OPENAI_KEY ),
            'razorpay_enabled'  => ! empty( jp_razorpay_key_id() ),
            'sms_enabled'       => ! empty( get_option( 'jp_sms_key' ) ),
            'vapid_enabled'     => ! empty( get_option( 'jp_vapid_public_key' ) ),
            'es_enabled'        => ! empty( JP_ELASTICSEARCH_HOST ),

            // Batch 12 — Stripe gateway abstraction. payment_gateway tells
            // the SPA which checkout flow to run (see PricingPage.tsx's
            // handleUpgrade()); stripe_publishable_key mirrors
            // razorpay_key_id below — Stripe's own docs are explicit that
            // the publishable key is safe for client-side/public exposure
            // (only the secret key, read via jp_stripe_secret_key() and
            // never sent to the browser, can actually move money).
            'payment_gateway'        => jp_active_payment_gateway(),
            'stripe_enabled'         => ! empty( jp_stripe_publishable_key() ),
            'stripe_publishable_key' => jp_stripe_publishable_key(),

            // Razorpay public key (safe to expose)
            'razorpay_key_id'   => jp_razorpay_key_id(),
            'vapid_public_key'  => get_option( 'jp_vapid_public_key', '' ),
            'ga4_id'            => get_option( 'jp_ga4_measurement_id', '' ),

            // Pagination
            'jobs_per_page'     => (int) get_option( 'jp_jobs_per_page', 20 ),
        ];

        // Add candidate/company data if logged in (avoids extra API call on mount)
        if ( $is_auth ) {
            $db = JP_DB::instance();
            $role = jp_current_role();

            if ( $role === 'jp_job_seeker' ) {
                $candidate = $db->get_candidate( $user->ID );
                if ( $candidate ) {
                    $config['candidate'] = (array) $candidate;
                }
            } elseif ( in_array( $role, [ 'jp_recruiter', 'jp_team_manager' ], true ) ) {
                $company = $db->get_company_by_user( $user->ID );
                if ( $company ) {
                    $config['company'] = (array) $company;
                }
            }

            // Unread counts for badge indicators
            $config['unread_notifications'] = $db->get_unread_count( $user->ID );
            $config['unread_messages']      = JP_Messaging::instance()->get_unread_count( $user->ID );
        }

        return $config;
    }

    // ── SPA routing support ───────────────────────────────────────────────────
    // When WordPress sees /dashboard/applications it 404s because there's no WP page.
    // We detect this and serve the [jp_app] page instead.

    public function handle_spa_routing(): void {
        global $wp_query;

        // Only redirect 404s to the portal page
        if ( ! is_404() ) return;

        // Find the page with [jp_app] shortcode
        $portal_page = $this->get_portal_page();
        if ( ! $portal_page ) return;

        $current_path = '/' . ltrim( parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ) ?? '', '/' );
        $portal_path  = '/' . ltrim( parse_url( get_permalink( $portal_page->ID ) ?? '', PHP_URL_PATH ) ?? '', '/' );

        // All React Router paths — any path under the portal page
        // Strategy: if portal is at /find-jobs/ then /find-jobs/jobs/1 is served as React
        // Also catch top-level paths that React owns
        // Use the central prefix list — keeps PHP SPA routing in sync with React routes
        // Also match anything under the portal page's own path
        if ( $portal_path !== '/' && str_starts_with( $current_path, $portal_path ) ) {
            $wp_query->is_404 = false;
            status_header( 200 );
            $GLOBALS['post'] = $portal_page;
            setup_postdata( $portal_page );
            return;
        }

        foreach ( $this->get_spa_prefixes() as $prefix ) {
            if ( str_starts_with( $current_path, $prefix ) ) {
                $wp_query->is_404 = false;
                status_header( 200 );
                $GLOBALS['post'] = $portal_page;
                setup_postdata( $portal_page );
                return;
            }
        }
    }

    // ── Config REST endpoint ──────────────────────────────────────────────────

    public function register_config_route(): void {
        register_rest_route( JP_Api::namespace_str(), '/config', [ // Batch 31: was hardcoded 'jp/v1'
            'methods'             => 'GET',
            'callback'            => fn() => new \WP_REST_Response( $this->build_config(), 200 ),
            'permission_callback' => '__return_true',
        ] );
    }

    // ── Helper: find the page with [jp_app] shortcode ────────────────────────

    private function get_portal_url(): string {
        static $url = null;
        if ( null === $url ) {
            $page = $this->get_portal_page();
            $url  = $page ? get_permalink( $page->ID ) : home_url( '/' );
        }
        return $url ?: home_url( '/' );
    }

    /**
     * Public accessor for JP_Diagnostics — the resolution logic in
     * get_portal_page() below is the single source of truth for "which
     * page is the portal" used by SPA routing, config's portal_url, and
     * the front-page self-heal above; the diagnostics tool needs the exact
     * same answer to report a trustworthy Reading Settings check instead
     * of re-implementing (and risking drifting from) this resolution logic.
     */
    public function diagnostics_get_portal_page(): ?\WP_Post {
        return $this->get_portal_page();
    }

    private function get_portal_page(): ?\WP_Post {
        static $page = null;
        if ( null !== $page ) return $page ?: null;

        // Strategy 1: Use stored page ID from activation (most reliable)
        $stored_id = (int) get_option( 'jp_portal_page_id', 0 );
        if ( $stored_id ) {
            $p = get_post( $stored_id );
            if ( $p && $p->post_status === 'publish' ) {
                $page = $p;
                return $page;
            }
        }

        // Strategy 2: Find page using our full-page template
        $pages = get_posts( [
            'post_type'      => 'page',
            'post_status'    => 'publish',
            'posts_per_page' => 1,
            'meta_key'       => '_wp_page_template',
            'meta_value'     => 'page-templates/tpl-react-app.php',
            'orderby'        => 'ID',
            'order'          => 'ASC',
        ] );
        if ( ! empty( $pages ) ) {
            $page = $pages[0];
            update_option( 'jp_portal_page_id', $page->ID );
            return $page;
        }

        // Strategy 3: Find page containing [jp_app] shortcode via direct DB query
        global $wpdb;
        $row = $wpdb->get_row(
            "SELECT ID FROM {$wpdb->posts}
             WHERE post_type='page' AND post_status='publish'
             AND post_content LIKE '%[jp_app]%'
             ORDER BY ID ASC LIMIT 1"
        );
        if ( $row ) {
            $p = get_post( (int) $row->ID );
            if ( $p ) {
                $page = $p;
                update_option( 'jp_portal_page_id', $p->ID );
                return $page;
            }
        }

        // Strategy 4: Known slug fallback
        foreach ( [ 'find-jobs', 'jobs', 'portal', 'jp-portal' ] as $slug ) {
            $p = get_page_by_path( $slug );
            if ( $p && $p->post_status === 'publish' ) {
                $page = $p;
                update_option( 'jp_portal_page_id', $p->ID );
                return $page;
            }
        }

        $page = false;
        return null;
    }
}
