<?php
/**
 * Class JP_SMS — SMS notifications via MSG91 / Twilio.
 *
 * Optional — enabled only when JP_SMS_PROVIDER and credentials are set in wp-config.php.
 * Candidates can disable SMS in their notification preferences.
 *
 * Triggers:
 *  - OTP on register/login (when 2FA by SMS is enabled)
 *  - Application status changes
 *  - Interview reminders (1 hour before)
 *  - Job alert (instant, when candidate opts in)
 */
defined( 'ABSPATH' ) || exit;

class JP_SMS {

	private static ?JP_SMS $instance = null;

	const PROVIDERS = [ 'msg91', 'twilio' ];

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		// Only initialise if SMS credentials are configured
		if ( ! $this->is_configured() ) return;

		add_action( 'jp_stage_changed',           [ $this, 'on_stage_changed' ], 10, 4 );
		add_action( 'jp_interview_reminder',      [ $this, 'on_interview_reminder' ] );
		add_action( 'wp_ajax_jp_send_otp',        [ $this, 'ajax_send_otp' ] );
		add_action( 'wp_ajax_nopriv_jp_send_otp', [ $this, 'ajax_send_otp' ] );
		add_action( 'wp_ajax_jp_verify_otp',        [ $this, 'ajax_verify_otp' ] );
		add_action( 'wp_ajax_nopriv_jp_verify_otp', [ $this, 'ajax_verify_otp' ] );
	}

	// ── Send SMS ──────────────────────────────────────────────────────────────

	public function send( string $to, string $message ): bool {
		if ( ! $this->is_configured() ) return false;

		// Normalise Indian mobile number
		$to = preg_replace( '/\D/', '', $to );
		if ( strlen( $to ) === 10 ) $to = '91' . $to;
		if ( strlen( $to ) < 10 )   return false;

		$provider = defined( 'JP_SMS_PROVIDER' ) ? JP_SMS_PROVIDER : 'msg91';

		if ( $provider === 'msg91' ) {
			$result = $this->send_msg91( $to, $message );
		} elseif ( $provider === 'twilio' ) {
			$result = $this->send_twilio( $to, $message );
		} else {
			$result = false;
		}

		$this->log( $to, $message, $result ? 'sent' : 'failed' );
		return $result;
	}

	// ── MSG91 ─────────────────────────────────────────────────────────────────

	private function send_msg91( string $to, string $message ): bool {
		$api_key  = defined( 'JP_MSG91_API_KEY' )  ? JP_MSG91_API_KEY  : '';
		$sender   = defined( 'JP_MSG91_SENDER' )   ? JP_MSG91_SENDER   : 'JPJOBS';
		if ( ! $api_key ) return false;

		$response = wp_remote_post( 'https://api.msg91.com/api/v2/sendsms', [
			'timeout' => 10,
			'headers' => [
				'authkey'      => $api_key,
				'Content-Type' => 'application/json',
			],
			'body' => wp_json_encode( [
				'sender'   => $sender,
				'route'    => '4',
				'country'  => '91',
				'sms'      => [ [ 'message' => $message, 'to' => [ $to ] ] ],
			] ),
		] );

		if ( is_wp_error( $response ) ) return false;
		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		return ( $body['type'] ?? '' ) === 'success';
	}

	// ── Twilio ────────────────────────────────────────────────────────────────

	private function send_twilio( string $to, string $message ): bool {
		$sid    = defined( 'JP_TWILIO_SID' )   ? JP_TWILIO_SID   : '';
		$token  = defined( 'JP_TWILIO_TOKEN' ) ? JP_TWILIO_TOKEN : '';
		$from   = defined( 'JP_TWILIO_FROM' )  ? JP_TWILIO_FROM  : '';
		if ( ! $sid || ! $token || ! $from ) return false;

		$response = wp_remote_post(
			"https://api.twilio.com/2010-04-01/Accounts/{$sid}/Messages.json",
			[
				'timeout'  => 10,
				'headers'  => [ 'Authorization' => 'Basic ' . base64_encode( "{$sid}:{$token}" ) ],
				'body'     => [ 'From' => $from, 'To' => '+' . $to, 'Body' => $message ],
			]
		);

		if ( is_wp_error( $response ) ) return false;
		$code = wp_remote_retrieve_response_code( $response );
		return $code >= 200 && $code < 300;
	}

	// ── OTP ───────────────────────────────────────────────────────────────────

	public function send_otp( string $phone ): string {
		$otp = (string) random_int( 100000, 999999 );
		set_transient( 'jp_otp_' . md5( $phone ), $otp, 600 ); // 10-min TTL

		$site    = jp_site_name();
		$message = "{$otp} is your {$site} verification code. Valid for 10 minutes. Do not share.";
		$this->send( $phone, $message );

		return $otp; // Return for testing; in prod just fire and forget
	}

	public function verify_otp( string $phone, string $code ): bool {
		$stored = get_transient( 'jp_otp_' . md5( $phone ) );
		if ( $stored && hash_equals( $stored, $code ) ) {
			delete_transient( 'jp_otp_' . md5( $phone ) );
			return true;
		}
		return false;
	}

	public function ajax_send_otp(): void {
		jp_verify_nonce( 'jp_general' );
		if ( ! JP_Security::rate_limit( 'otp_send', 3, 300 ) ) {
			jp_json_response( false, 'Too many OTP requests. Please wait 5 minutes.' );
		}
		$phone = sanitize_text_field( $_POST['phone'] ?? '' );
		if ( ! $phone ) jp_json_response( false, 'Phone number required.' );
		$this->send_otp( $phone );
		jp_json_response( true, [ 'message' => 'OTP sent to ' . substr( $phone, 0, 4 ) . 'XXXXXX' ] );
	}

	public function ajax_verify_otp(): void {
		jp_verify_nonce( 'jp_general' );
		$phone = sanitize_text_field( $_POST['phone'] ?? '' );
		$code  = sanitize_text_field( $_POST['code']  ?? '' );
		$ok    = $this->verify_otp( $phone, $code );
		jp_json_response( $ok, $ok ? 'Phone verified.' : 'Invalid or expired OTP.' );
	}

	// ── Hook handlers ─────────────────────────────────────────────────────────

	public function on_stage_changed( int $app_id, string $old_stage, string $new_stage, int $actor_id ): void {
		global $wpdb;
		$app  = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_applications WHERE id=%d", $app_id ) );
		if ( ! $app ) return;

		$cand = get_userdata( $app->candidate_id );
		if ( ! $cand ) return;

		// Check if user opted in to SMS notifications
		if ( ! get_user_meta( $app->candidate_id, 'jp_sms_enabled', true ) ) return;

		$phone = get_user_meta( $app->candidate_id, 'jp_phone', true );
		if ( ! $phone ) return;

		$job     = $wpdb->get_row( $wpdb->prepare( "SELECT title FROM {$wpdb->prefix}jp_jobs WHERE id=%d", $app->job_id ) );
		$stage_label = ucwords( str_replace( '_', ' ', $new_stage ) );

		$messages = [
			'shortlisted' => "🎯 Great news! You've been shortlisted for {$job->title}. Check your email for details.",
			'interview'   => "📅 Interview scheduled for {$job->title}. Check your email/dashboard for time & link.",
			'offer'       => "🎉 Offer received for {$job->title}! Login to your account to view details.",
			'hired'       => "🥳 Congratulations! You've been hired for {$job->title}. Welcome aboard!",
			'rejected'    => "Update on {$job->title}: The employer has moved forward with other candidates. Keep applying!",
		];

		$msg = $messages[ $new_stage ] ?? null;
		if ( $msg ) $this->send( $phone, $msg );
	}

	public function on_interview_reminder( array $data ): void {
		$phone = $data['phone'] ?? '';
		$job   = $data['job_title'] ?? 'your interview';
		$time  = $data['time'] ?? '';
		if ( ! $phone ) return;

		$msg = "⏰ Reminder: Your interview for {$job} is in 1 hour ({$time}). Best of luck! – " . jp_site_name();
		$this->send( $phone, $msg );
	}

	// ── Helpers ───────────────────────────────────────────────────────────────

	private function is_configured(): bool {
		$provider = defined( 'JP_SMS_PROVIDER' ) ? JP_SMS_PROVIDER : '';
		if ( ! $provider ) return false;
		if ( $provider === 'msg91' )  return defined( 'JP_MSG91_API_KEY' ) && JP_MSG91_API_KEY;
		if ( $provider === 'twilio' ) return defined( 'JP_TWILIO_SID' ) && JP_TWILIO_SID;
		return false;
	}

	private function log( string $to, string $message, string $status ): void {
		global $wpdb;
		$wpdb->insert( $wpdb->prefix . 'jp_sms_log', [
			'phone'      => $to,
			'message'    => substr( $message, 0, 160 ),
			'status'     => $status,
			'provider'   => defined( 'JP_SMS_PROVIDER' ) ? JP_SMS_PROVIDER : '',
			'created_at' => current_time( 'mysql' ),
		], [ '%s', '%s', '%s', '%s', '%s' ] );
	}
}
