<?php
/**
 * Class JP_Applications — Full ATS
 *
 * Stages: applied → shortlisted → phone_screen → interview → assessment → offer → hired / rejected / withdrawn
 * Features: stage-based email triggers, recruiter notes, history log, duplicate prevention,
 *           bulk actions, offer letter generation.
 */
defined( 'ABSPATH' ) || exit;

class JP_Applications {

	private static ?JP_Applications $instance = null;

	/** ATS pipeline stages in order */
	const STAGES = [
		'applied', 'shortlisted', 'phone_screen', 'interview',
		'assessment', 'offer', 'hired', 'rejected', 'withdrawn',
	];

	/** Stage transition email triggers */
	const STAGE_EMAILS = [
		'shortlisted'  => 'candidate_shortlisted',
		'phone_screen' => 'candidate_phone_screen',
		'interview'    => 'candidate_interview_scheduled',
		'assessment'   => 'candidate_assessment',
		'offer'        => 'candidate_offer_sent',
		'hired'        => 'candidate_hired',
		'rejected'     => 'candidate_rejected',
	];

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_jp_apply_job',        [ $this, 'ajax_apply' ] );
		add_action( 'wp_ajax_jp_move_stage',        [ $this, 'ajax_move_stage' ] );
		add_action( 'wp_ajax_jp_withdraw_app',      [ $this, 'ajax_withdraw' ] );
		add_action( 'wp_ajax_jp_add_app_note',      [ $this, 'ajax_add_note' ] );
		add_action( 'wp_ajax_jp_set_app_tags',      [ $this, 'ajax_set_tags' ] );
		add_action( 'wp_ajax_jp_bulk_stage_action', [ $this, 'ajax_bulk_action' ] );
		add_action( 'wp_ajax_jp_generate_offer',    [ $this, 'ajax_generate_offer' ] );
	}

	// ── Apply for a job ───────────────────────────────────────────────────────

	public function ajax_apply(): void {
		jp_verify_nonce('jp_general');
		if ( !is_user_logged_in() || !current_user_can('jp_apply_jobs') ) jp_json_response(false,'Not permitted.');

		$user_id   = get_current_user_id();
		$job_id    = absint($_POST['job_id']??0);
		$resume_id = absint($_POST['resume_id']??0);
		$cover     = sanitize_textarea_field($_POST['cover_letter']??'');
		$screening = array_map('sanitize_textarea_field',(array)($_POST['screening_ans']??[]));

		if (!$job_id || !$resume_id) jp_json_response(false,'Job and resume are required.');

		global $wpdb;
		$job = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_jobs WHERE id=%d AND status='active'",$job_id));
		if (!$job) jp_json_response(false,'This job is no longer available.');

		// Duplicate check
		if ($this->has_applied($job_id,$user_id)) jp_json_response(false,'You have already applied for this job.');

		// Rate limit: max 10 applications per 24h
		$recent = (int)$wpdb->get_var($wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications WHERE candidate_id=%d AND created_at>=DATE_SUB(NOW(),INTERVAL 24 HOUR)",
			$user_id
		));
		if ($recent >= 10) jp_json_response(false,'Daily application limit reached (10/day). Please try again tomorrow.');

		// Get candidate record
		$candidate = JP_DB::instance()->get_candidate($user_id);
		if (!$candidate) jp_json_response(false,'Please complete your profile before applying.');

		// Compute match score
		$match_score = 0;
		if (class_exists('JP_Matching')) {
			$match_score = JP_Matching::instance()->score($candidate,$job);
		}

		$history_entry = [
			'stage'     => 'applied',
			'timestamp' => current_time('mysql'),
			'actor_id'  => $user_id,
			'note'      => 'Application submitted.',
		];

		// Root-cause fix: jp_applications has a UNIQUE KEY on (job_id,
		// candidate_id), while has_applied() above deliberately excludes
		// stage='withdrawn' so a candidate who withdrew can apply again.
		// A plain $wpdb->insert() here hits the unique-key violation the
		// moment a withdrawn row already exists for this job+candidate,
		// silently/fatally failing the "allowed to re-apply" case the
		// duplicate check above was written to permit. Use an atomic
		// upsert instead: insert a fresh row normally, or — if a row
		// already exists for this job+candidate (necessarily withdrawn,
		// since has_applied() already screened out any active one) —
		// reset it to a brand-new application rather than erroring.
		$table = $wpdb->prefix . 'jp_applications';
		$sql = $wpdb->prepare(
			"INSERT INTO {$table}
				(job_id, company_id, candidate_id, resume_id, cover_letter, screening_ans,
				 stage, match_score, stage_history, created_at, updated_at)
			 VALUES (%d, %d, %d, %d, %s, %s, %s, %d, %s, %s, %s)
			 ON DUPLICATE KEY UPDATE
				resume_id      = VALUES(resume_id),
				cover_letter   = VALUES(cover_letter),
				screening_ans  = VALUES(screening_ans),
				stage          = VALUES(stage),
				match_score    = VALUES(match_score),
				stage_history  = VALUES(stage_history),
				updated_at     = VALUES(updated_at)",
			$job_id, $job->company_id, $user_id, $resume_id, $cover, wp_json_encode( $screening ),
			'applied', $match_score, wp_json_encode( [ $history_entry ] ),
			current_time( 'mysql' ), current_time( 'mysql' )
		);
		// Root-cause fix (batch 16): $wpdb->query()'s return value (int
		// affected-rows on success, false on failure) was never checked —
		// the single most consequential instance of the ghost-success
		// pattern found across this whole engagement (batches 8/9/13/14/15),
		// since this is the platform's core conversion event. A failed
		// write here still fell through to the id lookup below (finding
		// either no row at all, or a stale pre-existing row on the
		// ON DUPLICATE KEY UPDATE branch) and unconditionally told the
		// candidate "Application submitted successfully!" while the
		// recruiter's pipeline received nothing.
		$write_ok = $wpdb->query( $sql );
		if ( false === $write_ok ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_applications upsert failed: ' . $wpdb->last_error ), 'JP_Applications::ajax_apply job_id=' . $job_id . ' user_id=' . $user_id );
			}
			jp_json_response( false, 'Could not submit your application. Please try again or contact support.' );
			return;
		}

		// $wpdb->insert_id is only reliable after a fresh INSERT; on the
		// ON DUPLICATE KEY UPDATE branch it does not reflect the existing
		// row's id, so look the row up explicitly either way.
		$app_id = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$table} WHERE job_id=%d AND candidate_id=%d",
			$job_id, $user_id
		) );

		// Increment application counter on job
		$wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}jp_jobs SET applications_cnt=applications_cnt+1 WHERE id=%d",$job_id));

		// Trigger email notifications
		$this->send_stage_email($app_id,'applied');
		do_action('jp_application_submitted',$app_id,$job_id,$user_id);

		// In-app notification to recruiter
		JP_Notifications::instance()->create([
			'user_id' => $job->posted_by,
			'type'    => 'new_application',
			'title'   => 'New application received',
			'body'    => get_userdata($user_id)->display_name.' applied for '.$job->title,
			// Root-cause fix: this used to point at a pre-SPA-rewrite
			// jp-theme query-string URL (/recruiter/?section=applications&...)
			// that no route in router.tsx ever matched, so clicking the
			// notification could only ever land on a 404. The recruiter's
			// applications list lives at /recruiter/applications and already
			// reads a job_id search param (see RecruiterApplicationsPage.tsx).
			'url'     => home_url('/recruiter/applications?job_id='.$job_id),
		]);

		jp_json_response(true,['message'=>'Application submitted successfully! The recruiter will review your profile.','app_id'=>$app_id]);
	}

	// ── Move stage ────────────────────────────────────────────────────────────

	public function ajax_move_stage(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');

		$app_id = absint($_POST['app_id']??0);
		$stage  = sanitize_key($_POST['stage']??'');
		$note   = sanitize_textarea_field($_POST['note']??'');

		if (!in_array($stage, self::STAGES, true)) jp_json_response(false,'Invalid stage.');

		global $wpdb;
		$app = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_applications WHERE id=%d",$app_id));
		if (!$app) jp_json_response(false,'Application not found.');

		// Permission: recruiter must own the job, or admin
		if (!$this->can_manage_application($app)) jp_json_response(false,'Permission denied.');

		// Append to history
		$history   = json_decode($app->stage_history??'[]',true)?:[];
		$history[] = [
			'stage'     => $stage,
			'timestamp' => current_time('mysql'),
			'actor_id'  => get_current_user_id(),
			'note'      => $note,
		];

		// Root-cause fix (batch 16): unchecked $wpdb->update() — same
		// ghost-success shape as ajax_apply() above. A failed write here
		// still fired the stage-change email/notification/hook below and
		// told the recruiter "Stage updated" while the application stayed
		// on its previous stage in the DB, silently desynchronizing the
		// pipeline UI from what was actually persisted.
		$updated = $wpdb->update($wpdb->prefix.'jp_applications',[
			'stage'        => $stage,
			'stage_history' => wp_json_encode($history),
			'updated_at'   => current_time('mysql'),
		],['id'=>$app_id],['%s','%s','%s'],['%d']);
		if ( false === $updated ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_applications stage update failed: ' . $wpdb->last_error ), 'JP_Applications::ajax_move_stage app_id=' . $app_id );
			}
			jp_json_response( false, 'Could not update this application. Please try again or contact support.' );
			return;
		}

		// Root-cause fix: this direct send_stage_email() call duplicated the
		// email already sent by JP_Notifications::on_stage_changed(), which
		// is hooked to the do_action('jp_stage_changed', ...) call below —
		// every stage transition was sending the candidate two identical
		// emails. The hook-based dispatch is the single source of truth for
		// single-application stage changes; ajax_bulk_action() below still
		// sends its own direct email since it has no equivalent hook.

		// In-app notification to candidate
		$job = $wpdb->get_row($wpdb->prepare("SELECT title FROM {$wpdb->prefix}jp_jobs WHERE id=%d",$app->job_id));
		JP_Notifications::instance()->create([
			'user_id' => $app->candidate_id,
			'type'    => 'application_update',
			'title'   => 'Application status updated',
			'body'    => 'Your application for '.$job->title.' is now: '.ucwords(str_replace('_',' ',$stage)),
			// Root-cause fix: /my-account/?section=applications was the
			// pre-SPA-rewrite jp-theme path; the candidate applications list
			// now lives at /dashboard/applications (see router.tsx).
			'url'     => home_url('/dashboard/applications'),
		]);

		do_action('jp_stage_changed',$app_id,$app->stage,$stage,get_current_user_id());
		jp_json_response(true,['message'=>'Stage updated to '.ucwords(str_replace('_',' ',$stage)),'stage'=>$stage]);
	}

	// ── Withdraw ──────────────────────────────────────────────────────────────

	public function ajax_withdraw(): void {
		jp_verify_nonce('jp_general');
		$app_id  = absint($_POST['app_id']??0);
		$user_id = get_current_user_id();
		global $wpdb;
		$app = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_applications WHERE id=%d AND candidate_id=%d",$app_id,$user_id));
		if (!$app) jp_json_response(false,'Application not found.');
		if (in_array($app->stage,['hired','rejected'],true)) jp_json_response(false,'This application cannot be withdrawn.');

		$history   = json_decode($app->stage_history??'[]',true)?:[];
		$history[] = ['stage'=>'withdrawn','timestamp'=>current_time('mysql'),'actor_id'=>$user_id,'note'=>'Withdrawn by candidate.'];

		// Root-cause fix (batch 16): same unchecked-update ghost-success
		// shape as ajax_apply()/ajax_move_stage() above — a failed write
		// here told the candidate their application was withdrawn while
		// it silently remained active (and, more importantly, remained
		// visible/actionable to the recruiter, the opposite of what the
		// candidate believed they'd just done).
		$updated = $wpdb->update($wpdb->prefix.'jp_applications',['stage'=>'withdrawn','stage_history'=>wp_json_encode($history),'updated_at'=>current_time('mysql')],['id'=>$app_id],['%s','%s','%s'],['%d']);
		if ( false === $updated ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_applications withdraw failed: ' . $wpdb->last_error ), 'JP_Applications::ajax_withdraw app_id=' . $app_id );
			}
			jp_json_response( false, 'Could not withdraw this application. Please try again or contact support.' );
			return;
		}
		jp_json_response(true,['message'=>'Application withdrawn.']);
	}

	// ── Recruiter notes ───────────────────────────────────────────────────────

	public function ajax_add_note(): void {
		jp_verify_nonce('jp_general');
		$app_id = absint($_POST['app_id']??0);
		$note   = sanitize_textarea_field($_POST['note']??'');
		if (!$note) jp_json_response(false,'Note cannot be empty.');
		global $wpdb;
		$app = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_applications WHERE id=%d",$app_id));
		if (!$app || !$this->can_manage_application($app)) jp_json_response(false,'Permission denied.');
		$notes   = json_decode($app->notes??'[]',true)?:[];
		$notes[] = ['text'=>$note,'user_id'=>get_current_user_id(),'created_at'=>current_time('mysql')];
		// Root-cause fix (batch 16): same unchecked-update shape as the
		// other handlers in this file — a failed write silently dropped
		// the recruiter's note while reporting "Note added.".
		$updated = $wpdb->update($wpdb->prefix.'jp_applications',['notes'=>wp_json_encode($notes)],['id'=>$app_id],['%s'],['%d']);
		if ( false === $updated ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_applications note update failed: ' . $wpdb->last_error ), 'JP_Applications::ajax_add_note app_id=' . $app_id );
			}
			jp_json_response( false, 'Could not save this note. Please try again or contact support.' );
			return;
		}
		jp_json_response(true,['message'=>'Note added.','note'=>end($notes)]);
	}

	/**
	 * New in batch 37 (recruiter ATS pipeline depth). Replaces the
	 * application's whole tag set (client sends the full desired list —
	 * simpler and race-free for a small per-application array vs. separate
	 * add/remove endpoints) with sanitized, de-duplicated, length-capped
	 * free-text labels. Same permission/ownership shape as ajax_add_note().
	 */
	public function ajax_set_tags(): void {
		jp_verify_nonce('jp_general');
		$app_id = absint($_POST['app_id']??0);
		$raw    = (array)($_POST['tags']??[]);
		$tags   = [];
		foreach ($raw as $t) {
			$t = sanitize_text_field((string)$t);
			$t = substr(trim($t),0,40);
			if ($t !== '' && !in_array($t,$tags,true)) $tags[] = $t;
			if (count($tags) >= 20) break; // sane upper bound on a UI chip list
		}
		global $wpdb;
		$app = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_applications WHERE id=%d",$app_id));
		if (!$app || !$this->can_manage_application($app)) jp_json_response(false,'Permission denied.');
		$updated = $wpdb->update($wpdb->prefix.'jp_applications',['tags'=>wp_json_encode($tags)],['id'=>$app_id],['%s'],['%d']);
		if ( false === $updated ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_applications tags update failed: ' . $wpdb->last_error ), 'JP_Applications::ajax_set_tags app_id=' . $app_id );
			}
			jp_json_response( false, 'Could not save tags. Please try again or contact support.' );
			return;
		}
		jp_json_response(true,['message'=>'Tags updated.','tags'=>$tags]);
	}

	// ── Bulk actions ──────────────────────────────────────────────────────────

	public function ajax_bulk_action(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');
		$ids    = array_map('absint',(array)($_POST['app_ids']??[]));
		$action = sanitize_key($_POST['bulk_action']??'');
		if (empty($ids)) jp_json_response(false,'No applications selected.');
		$valid_actions = array_merge(self::STAGES,['shortlist','reject']);
		if (!in_array($action,$valid_actions,true)) jp_json_response(false,'Invalid action.');
		$stage = $action === 'shortlist' ? 'shortlisted' : ($action === 'reject' ? 'rejected' : $action);
		$count = 0;
		$failed = 0;
		global $wpdb;
		foreach ($ids as $id) {
			$app = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_applications WHERE id=%d",$id));
			if (!$app || !$this->can_manage_application($app)) continue;
			$history   = json_decode($app->stage_history??'[]',true)?:[];
			$history[] = ['stage'=>$stage,'timestamp'=>current_time('mysql'),'actor_id'=>get_current_user_id(),'note'=>'Bulk action.'];
			// Root-cause fix (batch 16): same unchecked-update shape as the
			// rest of this file. Previously every id in the loop was
			// counted as a success and emailed regardless of whether its
			// own write actually persisted — a single failed row in a
			// large bulk action was invisible, both in the returned count
			// and in whether that candidate got a (now-inaccurate) stage
			// email. Failures are now excluded from $count/the email and
			// tallied separately so the response reflects reality.
			$updated = $wpdb->update($wpdb->prefix.'jp_applications',['stage'=>$stage,'stage_history'=>wp_json_encode($history),'updated_at'=>current_time('mysql')],['id'=>$id],['%s','%s','%s'],['%d']);
			if ( false === $updated ) {
				$failed++;
				if ( class_exists( 'JP_ErrorLog' ) ) {
					JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_applications bulk update failed: ' . $wpdb->last_error ), 'JP_Applications::ajax_bulk_action app_id=' . $id );
				}
				continue;
			}
			if (isset(self::STAGE_EMAILS[$stage])) $this->send_stage_email($id,$stage);
			$count++;
		}
		$message = "{$count} application(s) moved to ".ucwords(str_replace('_',' ',$stage)).'.';
		if ( $failed > 0 ) {
			$message .= " {$failed} could not be updated — please retry those.";
		}
		jp_json_response(true,['message'=>$message,'updated'=>$count,'failed'=>$failed]);
	}

	// ── Offer letter generation (TCPDF) ──────────────────────────────────────

	public function ajax_generate_offer(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');
		$app_id = absint($_POST['app_id']??0);
		$ctc    = absint($_POST['offer_ctc']??0);
		$result = $this->do_generate_offer($app_id, $ctc);
		if (is_wp_error($result)) jp_json_response(false, $result->get_error_message());
		jp_json_response(true, $result);
	}

	/**
	 * Root-cause fix (batch 21, backlog "offer-letter/e-signature
	 * workflow"): this previously generated a PDF and handed its URL back
	 * in a single, one-off AJAX response with NOTHING persisted anywhere —
	 * confirmed by grepping the whole codebase for offer_pdf_url/wp_ajax_
	 * jp_generate_offer's own registration, and finding zero REST route and
	 * zero SPA caller for it, ever. A recruiter could never actually reach
	 * this from the live app, and even if they somehow had, the generated
	 * link was never stored anywhere a candidate could later see it —
	 * there was no way for an offer, once made, to actually reach the
	 * candidate through the product at all. Also, offer_ctc has existed as
	 * a jp_applications column (and even in the frontend's own TS type)
	 * since this table was first created, but nothing anywhere ever wrote
	 * to it — a fully silent, unused column. This method now: persists
	 * offer_pdf_url + offer_ctc + sets offer_status='sent' (checked write),
	 * and uses the recruiter-provided CTC in the letter body when given,
	 * falling back to the job's own stated salary range otherwise. Shared
	 * (no $_POST/wp_send_json coupling) so the legacy AJAX handler above
	 * and the new REST route in class-jp-api.php call the same logic
	 * instead of two copies that can drift — same pattern as privacy.php/
	 * team.php/featureflags.php's do_*() methods.
	 */
	public function do_generate_offer( int $app_id, int $ctc ) {
		global $wpdb;
		$app = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_applications WHERE id=%d", $app_id ) );
		if ( ! $app ) return new \WP_Error( 'jp_offer_not_found', 'Application not found.' );
		if ( ! $this->can_manage_application( $app ) ) return new \WP_Error( 'jp_offer_forbidden', 'Permission denied.', [ 'status' => 403 ] );

		$job       = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_jobs WHERE id=%d", $app->job_id ) );
		if ( ! $job ) return new \WP_Error( 'jp_offer_invalid', 'The job for this application no longer exists.' );
		$candidate = get_userdata( $app->candidate_id );
		$company   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_companies WHERE id=%d", $job->company_id ) );

		$pdf_path = $this->generate_offer_pdf( $app, $job, $candidate, $company, $ctc );
		if ( ! $pdf_path ) return new \WP_Error( 'jp_offer_pdf_failed', 'PDF generation failed. Please try again.' );
		$pdf_url = str_replace( ABSPATH, site_url( '/' ), $pdf_path );

		$write_ok = false !== $wpdb->update( $wpdb->prefix . 'jp_applications', [
			'offer_pdf_url' => $pdf_url,
			'offer_ctc'     => $ctc,
			'offer_status'  => 'sent',
		], [ 'id' => $app_id ] );
		if ( ! $write_ok ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_applications offer update failed: ' . $wpdb->last_error ), 'JP_Applications::do_generate_offer app_id=' . $app_id );
			}
			// The PDF itself was generated fine — only the persistence
			// failed. Returning the pdf_url anyway (as this method always
			// has) would leave the candidate unable to ever see it again
			// (offer_status stays 'none', nothing shows on their
			// dashboard), so surface this as a real failure instead of a
			// ghost success rather than silently generating an orphaned file.
			return new \WP_Error( 'jp_offer_save_failed', 'The offer letter was generated but could not be saved. Please try again.' );
		}

		if ( class_exists( 'JP_Notifications' ) ) {
			JP_Notifications::instance()->create( [
				'user_id' => (int) $app->candidate_id,
				'type'    => 'offer_sent',
				'title'   => 'You have a new offer!',
				'body'    => "You've received an offer for {$job->title}.",
				// Root-cause fix: this was left as an empty string, so the
				// notification's click-through had nowhere to go at all.
				// The candidate can see/respond to the offer from their
				// applications list.
				'url'     => home_url('/dashboard/applications'),
			] );
		}
		if ( class_exists( 'JP_Security' ) ) {
			JP_Security::instance()->audit( 'offer_generated', 'application', $app_id, "Offer generated for {$job->title}" . ( $ctc ? ", CTC: {$ctc}" : '' ) );
		}

		// E-signature (batch: closing the deliberately-scoped-out vendor
		// integration — see JP_ESign's own docblock). Entirely additive and
		// non-blocking: when not configured this is a no-op and the
		// existing in-app "I Agree" flow (do_offer_response()) is exactly
		// what the candidate uses, unchanged. When configured, a DocuSign
		// send failure (network error, bad credentials, consent not
		// granted) is logged but never fails this request — the offer PDF
		// was already generated and saved successfully above, and the
		// candidate can still accept in-app even if the e-sign send failed.
		$esign_envelope_id = null;
		// Guard: generate_offer_pdf() falls back to an .html file (see its
		// own docblock) when TCPDF isn't installed — DocuSign's envelope
		// API is given a hardcoded fileExtension of 'pdf' in
		// JP_ESign::send_envelope(), so sending an HTML fallback file
		// through it would silently produce a corrupt "PDF." Real
		// e-signature requires the real PDF path.
		if ( class_exists( 'JP_ESign' ) && JP_ESign::instance()->is_configured() && str_ends_with( $pdf_path, '.pdf' ) ) {
			$sent = JP_ESign::instance()->send_envelope( $app, $job, $candidate, $company, $pdf_path );
			if ( is_wp_error( $sent ) ) {
				if ( class_exists( 'JP_ErrorLog' ) ) {
					JP_ErrorLog::instance()->log_exception(
						new \Exception( 'DocuSign envelope send failed: ' . $sent->get_error_message() ),
						'JP_Applications::do_generate_offer app_id=' . $app_id
					);
				}
			} else {
				$esign_envelope_id = $sent['envelope_id'];
			}
		}

		return [
			'message' => $esign_envelope_id
				? 'Offer letter generated and sent to the candidate for e-signature.'
				: 'Offer letter generated and sent to the candidate.',
			'pdf_url' => $pdf_url,
			'esign_envelope_id' => $esign_envelope_id,
		];
	}

	/**
	 * Candidate-facing counterpart of do_generate_offer(): records the
	 * candidate's accept/decline response (a click-to-accept acknowledgment
	 * — this product has no cryptographic PKI signing infrastructure, so
	 * this is the same "I Agree" pattern most SaaS offer/consent flows use,
	 * not a legally-binding digital signature; a real e-signature vendor
	 * integration is a further backlog item, not attempted here). Scoped to
	 * the candidate's own application, and only usable once (an offer that
	 * has already been responded to is a historical record — same
	 * already-decided guard as batch 20's interview feedback).
	 */
	public function do_offer_response( int $app_id, string $response, int $candidate_id ) {
		if ( ! in_array( $response, [ 'accepted', 'declined' ], true ) ) {
			return new \WP_Error( 'jp_offer_invalid_response', "response must be 'accepted' or 'declined'." );
		}
		global $wpdb;
		$app = $wpdb->get_row( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_applications WHERE id=%d AND candidate_id=%d", $app_id, $candidate_id
		) );
		if ( ! $app ) return new \WP_Error( 'jp_offer_not_found', 'Application not found.' );
		if ( $app->offer_status !== 'sent' ) {
			return new \WP_Error( 'jp_offer_not_pending', 'There is no pending offer to respond to on this application.' );
		}

		$write_ok = false !== $wpdb->update( $wpdb->prefix . 'jp_applications', [
			'offer_status'       => $response,
			'offer_responded_at' => current_time( 'mysql' ),
			// Accepting an offer is the natural terminal event for an
			// application's pipeline stage too — mirrors how a recruiter
			// would manually move it to 'hired' next, so it doesn't sit at
			// stage='offer' with a hidden accepted flag only visible by
			// reading offer_status separately.
			'stage'              => $response === 'accepted' ? 'hired' : $app->stage,
		], [ 'id' => $app_id, 'candidate_id' => $candidate_id ] );
		if ( ! $write_ok ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_applications offer_response update failed: ' . $wpdb->last_error ), 'JP_Applications::do_offer_response app_id=' . $app_id );
			}
			return new \WP_Error( 'jp_offer_response_failed', 'Could not record your response. Please try again.' );
		}

		if ( class_exists( 'JP_Notifications' ) ) {
			JP_Notifications::instance()->create( [
				'user_id' => (int) ( $wpdb->get_var( $wpdb->prepare( "SELECT j.posted_by FROM {$wpdb->prefix}jp_jobs j WHERE j.id=%d", $app->job_id ) ) ?? 0 ),
				'type'    => 'offer_' . $response,
				'title'   => 'Offer ' . $response,
				'body'    => 'A candidate has ' . $response . ' their offer.',
				// Root-cause fix: also left empty previously. job_id is
				// already available on $app, so link straight to that job's
				// applications list.
				'url'     => home_url('/recruiter/applications?job_id='.$app->job_id),
			] );
		}
		if ( class_exists( 'JP_Security' ) ) {
			JP_Security::instance()->audit( 'offer_' . $response, 'application', $app_id, "Candidate {$response} the offer." );
		}

		return [ 'message' => 'Your response has been recorded.' ];
	}

	private function offer_letter_body_text( $job, $candidate, $company, int $ctc = 0 ): string {
		// jp_format_salary() is built for a min-max range display ("₹X – ₹Y
		// / yr", "₹X+ / yr", "Up to ₹Y / yr") — none of those read correctly
		// for a single, definite recruiter-specified CTC figure, so a plain
		// number-format is used here instead when a real CTC is given.
		$compensation = $ctc > 0
			? '₹' . number_format( $ctc ) . ' / year'
			: jp_format_salary( (int) $job->salary_min, (int) $job->salary_max );
		return "Date: ".date('j F Y')."\n\n"
			. "Dear ".$candidate->display_name.",\n\n"
			. "We are pleased to offer you the position of **".$job->title."** at ".($company->name??jp_site_name()).".\n\n"
			. "Start Date: [Please confirm]\n"
			. "Compensation: ".$compensation."\n"
			. "Work Mode: ".ucfirst($job->work_mode??'On-site')."\n\n"
			. "This offer is contingent on satisfactory completion of background verification.\n\n"
			. "Please confirm your acceptance within 5 business days.\n\n"
			. "Congratulations and welcome to the team!\n\n"
			. "Regards,\n"
			. "HR Department\n"
			. ($company->name??jp_site_name())."\n\n"
			// Anchor text for JP_ESign::send_envelope()'s DocuSign
			// signHereTabs anchorString — invisible in the plain-text/HTML
			// offer view (no styling calls it out) but present verbatim in
			// the PDF text layer so DocuSign's anchor search finds it and
			// places the signature block at the true end of the letter
			// regardless of how long the body above renders.
			. "Candidate signature: /sig/";
	}

	/**
	 * Root cause fix (gap analysis P1 #96): previously this bare-returned
	 * false with no fallback whenever TCPDF was unavailable, unlike the
	 * invoice generator. Now shares JP_PDF's dependency probe and, on
	 * unavailability, degrades to an HTML offer letter instead of failing
	 * outright — consistent with generate_invoice()'s existing behavior.
	 */
	private function generate_offer_pdf( $app, $job, $candidate, $company, int $ctc = 0 ) {
		$body = $this->offer_letter_body_text($job,$candidate,$company,$ctc);

		if (!JP_PDF::ensure_available()) {
			$html = JP_PDF::wrap_html_document(
				'Offer Letter',
				'<h1>OFFER LETTER</h1><pre style="white-space:pre-wrap;font-family:inherit">'.esc_html(str_replace('**','',$body)).'</pre>'
			);
			return JP_PDF::write_html_fallback('jp-offers','offer-'.$app->id.'-'.time().'.html',$html);
		}

		$pdf = new \TCPDF('P','mm','A4',true,'UTF-8',false);
		$pdf->SetMargins(20,20,20);
		$pdf->SetAutoPageBreak(true,20);
		$pdf->AddPage();
		$pdf->SetFont('helvetica','B',18);
		$pdf->Cell(0,10,'OFFER LETTER','',1,'C');
		$pdf->Ln(5);
		$pdf->SetFont('helvetica','',11);
		$pdf->MultiCell(0,6,str_replace('**','',$body),0,'L');
		$dir  = wp_upload_dir()['basedir'].'/jp-offers/';
		wp_mkdir_p($dir);
		$path = $dir.'offer-'.$app->id.'-'.time().'.pdf';
		$pdf->Output($path,'F');
		return $path;
	}

	// ── Helpers ───────────────────────────────────────────────────────────────

	public function has_applied( int $job_id, int $user_id ): bool {
		global $wpdb;
		return (bool)$wpdb->get_var($wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}jp_applications WHERE job_id=%d AND candidate_id=%d AND stage!='withdrawn' LIMIT 1",
			$job_id,$user_id
		));
	}

	/**
	 * New in batch 37: public wrapper so class-jp-api.php's REST handlers
	 * (get_application(), the new resume-view endpoint) can reuse this
	 * exact ownership check instead of re-implementing/duplicating it —
	 * get_application() previously only checked the requester's *role*
	 * ("is some kind of recruiter"), not that this specific recruiter's
	 * company actually owns the job this application belongs to, which
	 * meant any recruiter account could view any other company's
	 * application detail by id. Tightened to use the real ownership check.
	 */
	public function user_can_manage_application( object $app ): bool {
		return $this->can_manage_application( $app );
	}

	private function can_manage_application( object $app ): bool {
		$user = wp_get_current_user();
		// Root-cause fix: this hardcoded a check for the literal WP role
		// string 'administrator', which (a) silently fails to recognize any
		// custom role granted equivalent capabilities, and (b) has no concept
		// of company teams — a second recruiter at the same company as the
		// job's original poster could never manage that job's applications
		// because ownership was checked only against a single user_id. Full
		// multi-seat team support requires a jp_team_members table (tracked
		// separately — see ARCHITECTURE.md / gap analysis §1); until that
		// ships, this at least stops relying on a magic role-name string and
		// checks capability + (owner OR — via the jp_team filter hook, for
		// forward-compat once team membership exists) delegated access.
		if ( current_user_can( 'manage_options' ) || current_user_can( 'jp_manage_all_applications' ) ) return true;
		global $wpdb;
		$job = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_jobs WHERE id=%d",$app->job_id));
		if (!$job) return false;
		$company = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_companies WHERE id=%d",$job->company_id));
		$is_owner = $company && (int)$company->user_id === (int)$user->ID;
		// Extension point: once jp_team_members exists, a filter here can
		// grant access to teammates without touching this method again.
		return (bool) apply_filters( 'jp_can_manage_application', $is_owner, $app, $job, $company, $user );
	}

	private function send_stage_email( int $app_id, string $stage ): void {
		if (class_exists('JP_Notifications')) {
			JP_Notifications::instance()->send_stage_email($app_id,$stage);
		}
	}

	public function get_applications_for_job( int $job_id, array $args = [] ): array {
		global $wpdb;
		$stage = sanitize_key($args['stage']??'');
		$limit = absint($args['limit']??50);
		$sql   = "SELECT a.*,u.display_name,u.user_email,c.headline,c.experience_years,c.location_city
		          FROM {$wpdb->prefix}jp_applications a
		          LEFT JOIN {$wpdb->users} u ON u.ID=a.candidate_id
		          LEFT JOIN {$wpdb->prefix}jp_candidates c ON c.user_id=a.candidate_id
		          WHERE a.job_id=%d";
		$params = [$job_id];
		if ($stage) { $sql.=' AND a.stage=%s'; $params[]=$stage; }
		$sql.=' ORDER BY a.created_at DESC LIMIT %d';
		$params[]=$limit;
		return $wpdb->get_results($wpdb->prepare($sql,...$params))?:[];
	}
}
