<?php
/**
 * Class JP_JobFeed — inbound job-feed pull importer, closing the other
 * deliberately-scoped-out vendor integration (see jp-core.php's batch-31
 * changelog line: "inbound ATS/job-board pull integration needs vendor
 * credentials and stays out of scope").
 *
 * There is no single "the ATS API" to integrate against — every ATS
 * (Greenhouse, Lever, Workday, Zoho Recruit, ...) has its own private,
 * differently-shaped API requiring its own named vendor account and
 * credentials, which is exactly why this was originally left out rather
 * than guessed at. What IS a real, universal, credential-free integration
 * point is a job-feed XML file — the same format this plugin already
 * PRODUCES outbound at /jobs-feed.xml (see class-jp-seo.php's
 * build_job_feed(), "standard Indeed XML schema") for Indeed/ZipRecruiter/
 * Google-for-Jobs to pull FROM this site. The overwhelming majority of ATS
 * platforms and job boards can also PRODUCE a feed in this same
 * <source><job>...</job></source> shape (Indeed's own XML feed spec, which
 * Greenhouse, Lever, Workable, Zoho Recruit, and most job boards all
 * support exporting), so pulling from one is a real, working end-to-end
 * integration requiring nothing from the user but a feed URL — not a
 * placeholder. If a specific ATS is later named with real API credentials,
 * that would be a genuinely different feed_type here ('greenhouse_api' etc)
 * added alongside this one, not a replacement for it.
 */
defined( 'ABSPATH' ) || exit;

class JP_JobFeed {

	private static ?JP_JobFeed $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'jp_import_job_feeds', [ $this, 'run_import' ] );
	}

	private function configured_urls(): array {
		$raw = (string) get_option( 'jp_feed_urls', '' );
		$urls = array_filter( array_map( 'trim', preg_split( '/[\r\n]+/', $raw ) ) );
		return array_values( array_filter( $urls, fn( $u ) => filter_var( $u, FILTER_VALIDATE_URL ) !== false ) );
	}

	/**
	 * Pulls every configured feed URL, parses it as an Indeed-schema job
	 * XML feed, and inserts any job whose (source_url, external_id) pair
	 * hasn't been imported before. Idempotent and safe to run repeatedly —
	 * re-running never creates duplicates, and an updated upstream listing
	 * (same referencenumber, changed fields) updates the existing imported
	 * row rather than inserting a second one.
	 *
	 * Imported jobs land with status='pending' by default (reviewed through
	 * the same admin moderation queue every recruiter-submitted job already
	 * goes through) unless jp_feed_auto_publish is enabled, matching the
	 * existing jp_auto_approve_jobs convention for recruiter submissions.
	 */
	public function run_import(): array {
		global $wpdb;
		$urls = $this->configured_urls();
		$summary = [ 'feeds' => count( $urls ), 'imported' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => [], 'ran_at' => current_time( 'mysql' ) ];

		if ( ! $urls ) {
			update_option( 'jp_job_feed_last_run', $summary );
			return $summary;
		}

		$system_user_id = $this->system_importer_user_id();
		$auto_publish   = (bool) get_option( 'jp_feed_auto_publish', false );

		foreach ( $urls as $url ) {
			$source_hash = md5( $url );
			$response = wp_remote_get( $url, [ 'timeout' => 30 ] );
			if ( is_wp_error( $response ) ) {
				$summary['errors'][] = "{$url}: " . $response->get_error_message();
				continue;
			}
			$code = wp_remote_retrieve_response_code( $response );
			if ( $code < 200 || $code >= 300 ) {
				$summary['errors'][] = "{$url}: HTTP {$code}";
				continue;
			}
			$body = wp_remote_retrieve_body( $response );
			libxml_use_internal_errors( true );
			$xml = simplexml_load_string( $body );
			if ( false === $xml ) {
				$summary['errors'][] = "{$url}: could not be parsed as XML.";
				libxml_clear_errors();
				continue;
			}

			// Indeed-schema: <source><publisher>...</publisher><job>...</job>...</source>
			$jobs = $xml->job ?? ( $xml->channel->item ?? [] );
			foreach ( $jobs as $node ) {
				$external_id = trim( (string) ( $node->referencenumber ?? $node->guid ?? $node->url ?? '' ) );
				if ( '' === $external_id ) { $summary['skipped']++; continue; }

				$existing = $wpdb->get_row( $wpdb->prepare(
					"SELECT * FROM {$wpdb->prefix}jp_job_feed_imports WHERE source_hash=%s AND external_id=%s",
					$source_hash, $external_id
				) );

				$title = sanitize_text_field( (string) ( $node->title ?? '' ) );
				if ( '' === $title ) { $summary['skipped']++; continue; }

				$company_name = sanitize_text_field( (string) ( $node->company ?? 'Imported' ) );
				$company_id   = $this->find_or_create_company( $company_name, $system_user_id );

				$job_data = [
					'company_id'     => $company_id,
					'posted_by'      => $system_user_id,
					'title'          => $title,
					'description'    => wp_kses_post( (string) ( $node->description ?? '' ) ),
					'location_city'  => sanitize_text_field( (string) ( $node->city ?? '' ) ),
					'location_state' => sanitize_text_field( (string) ( $node->state ?? '' ) ),
					'job_type'       => $this->normalize_job_type( (string) ( $node->jobtype ?? '' ) ),
					'work_mode'      => strtolower( (string) ( $node->city ?? '' ) ) === 'remote' ? 'remote' : 'onsite',
					'status'         => $auto_publish ? 'active' : 'pending',
					'updated_at'     => current_time( 'mysql' ),
				];

				if ( $existing ) {
					$job_id = (int) $existing->job_id;
					$job_still_exists = (bool) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}jp_jobs WHERE id=%d", $job_id ) );
					if ( $job_still_exists ) {
						$updated = $wpdb->update( $wpdb->prefix . 'jp_jobs', $job_data, [ 'id' => $job_id ] );
						if ( false !== $updated ) $summary['updated']++;
						else $summary['errors'][] = "{$url}#{$external_id}: update failed — {$wpdb->last_error}";
						continue;
					}
					// The originally-imported job row was deleted locally —
					// fall through and re-insert a fresh one, but reuse the
					// same import-tracking row (update its job_id below)
					// rather than creating a second tracking row for the
					// same (source_hash, external_id) pair, which the
					// table's UNIQUE KEY would reject anyway.
				}

				$job_data['slug']       = sanitize_title( $title ) . '-feed-' . substr( md5( $source_hash . $external_id ), 0, 8 );
				$job_data['created_at'] = current_time( 'mysql' );
				$job_data['skills_json'] = wp_json_encode( array_filter( array_map( 'trim', explode( ',', (string) ( $node->skills ?? '' ) ) ) ) );
				$inserted = $wpdb->insert( $wpdb->prefix . 'jp_jobs', $job_data );
				if ( false === $inserted ) {
					$summary['errors'][] = "{$url}#{$external_id}: insert failed — {$wpdb->last_error}";
					continue;
				}
				$new_job_id = (int) $wpdb->insert_id;

				// Ghost-success fix: this dedup-bookkeeping write was
				// unchecked. jp_job_feed_imports is what $existing (above)
				// consults to decide whether an external job was already
				// imported — a failed write here doesn't affect the job
				// just created, but it means the same external listing
				// gets treated as new and re-imported as a duplicate on
				// every future feed run, silently. Logged rather than
				// aborting the import, since the actual job posting
				// (the real deliverable) already succeeded.
				if ( $existing ) {
					$tracked = $wpdb->update( $wpdb->prefix . 'jp_job_feed_imports', [ 'job_id' => $new_job_id, 'imported_at' => current_time( 'mysql' ) ], [ 'id' => (int) $existing->id ] );
				} else {
					$tracked = $wpdb->insert( $wpdb->prefix . 'jp_job_feed_imports', [
						'source_hash' => $source_hash,
						'source_url'  => $url,
						'external_id' => $external_id,
						'job_id'      => $new_job_id,
						'imported_at' => current_time( 'mysql' ),
					] );
				}
				if ( false === $tracked && class_exists( 'JP_ErrorLog' ) ) {
					JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_job_feed_imports write failed: ' . $wpdb->last_error ), 'JP_JobFeed::run_import external_id=' . $external_id . ' job_id=' . $new_job_id );
				}
				$summary['imported']++;
			}
			libxml_clear_errors();
		}

		update_option( 'jp_job_feed_last_run', $summary );
		if ( class_exists( 'JP_Security' ) ) {
			JP_Security::instance()->audit(
				'job_feed_import', 'system', 0,
				"Imported {$summary['imported']}, updated {$summary['updated']}, skipped {$summary['skipped']}, " . count( $summary['errors'] ) . ' error(s), across ' . count( $urls ) . ' feed(s).'
			);
		}
		return $summary;
	}

	public function last_run_summary(): array {
		return (array) get_option( 'jp_job_feed_last_run', [ 'feeds' => 0, 'imported' => 0, 'updated' => 0, 'skipped' => 0, 'errors' => [], 'ran_at' => null ] );
	}

	private function normalize_job_type( string $raw ): string {
		$raw = strtolower( $raw );
		return match ( true ) {
			str_contains( $raw, 'part' )   => 'part-time',
			str_contains( $raw, 'contract') => 'contract',
			str_contains( $raw, 'intern' ) => 'internship',
			str_contains( $raw, 'freelance') => 'freelance',
			default => 'full-time',
		};
	}

	/**
	 * Every imported job needs a real posted_by user id (jp_jobs.posted_by
	 * is NOT NULL). Rather than attributing feed imports to whichever admin
	 * happens to trigger the cron run (misleading in the audit log and in
	 * "my job postings" — an admin shouldn't see external feed jobs mixed
	 * into their own list), a single dedicated system account is
	 * created once and reused for every future import.
	 */
	private function system_importer_user_id(): int {
		$existing = get_option( 'jp_feed_system_user_id', 0 );
		if ( $existing && get_userdata( (int) $existing ) ) return (int) $existing;

		$login = 'jp-feed-importer';
		$user  = get_user_by( 'login', $login );
		if ( ! $user ) {
			$user_id = wp_insert_user( [
				'user_login'   => $login,
				'user_pass'    => wp_generate_password( 32, true, true ),
				'user_email'   => 'jp-feed-importer@' . wp_parse_url( home_url(), PHP_URL_HOST ),
				'display_name' => 'Job Feed Import (system)',
				'role'         => 'subscriber',
			] );
			if ( is_wp_error( $user_id ) ) return get_current_user_id() ?: 1;
		} else {
			$user_id = $user->ID;
		}
		update_option( 'jp_feed_system_user_id', $user_id );
		return (int) $user_id;
	}

	private function find_or_create_company( string $name, int $owner_id ): int {
		global $wpdb;
		if ( '' === $name ) $name = 'Imported';
		$existing = $wpdb->get_var( $wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}jp_companies WHERE name=%s AND user_id=%d LIMIT 1", $name, $owner_id
		) );
		if ( $existing ) return (int) $existing;

		$slug = sanitize_title( $name );
		// Companies.slug is UNIQUE — a name collision with an existing
		// real (non-imported) company must not silently attach imported
		// jobs to someone else's company profile.
		$slug_exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$wpdb->prefix}jp_companies WHERE slug=%s", $slug ) );
		if ( $slug_exists ) $slug .= '-' . substr( md5( $name . microtime() ), 0, 6 );

		$inserted = $wpdb->insert( $wpdb->prefix . 'jp_companies', [
			'user_id'     => $owner_id,
			'name'        => $name,
			'slug'        => $slug,
			'description' => 'Company profile auto-created from an imported job feed.',
			// Root-cause guard: jp_companies.status defaults to 'pending'
			// (correct for a real recruiter's self-submitted company,
			// which needs moderation) but an imported job that goes
			// 'active' (jp_feed_auto_publish on) linking to a 'pending'
			// company would 404/hide on the company detail page — this is
			// a system-generated record, not user-submitted, so it's
			// created already-active.
			'status'      => 'active',
			'created_at'  => current_time( 'mysql' ),
		] );
		return $inserted !== false ? (int) $wpdb->insert_id : 0;
	}
}
