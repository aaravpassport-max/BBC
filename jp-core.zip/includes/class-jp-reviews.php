<?php
/**
 * Class JP_Reviews — Multi-dimensional company ratings.
 * Aspects: overall, culture, work_life, management, salary.
 * Features: moderation, verified employee badge, company reply.
 */
defined( 'ABSPATH' ) || exit;

class JP_Reviews {

	private static ?JP_Reviews $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_jp_submit_review', [ $this, 'ajax_submit' ] );
		add_action( 'wp_ajax_jp_reply_review',  [ $this, 'ajax_reply' ] );
		add_action( 'wp_ajax_jp_vote_review',   [ $this, 'ajax_vote' ] );
	}

	public function ajax_submit(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Please log in to leave a review.');

		// Root-cause fix (gap analysis P1 #153: "no rate limit on review
		// submission"). The existing one-review-per-company UNIQUE-style
		// check below already blocks repeat reviews of the SAME company, but
		// placed no ceiling on how many DIFFERENT companies a single account
		// could be used to spam-review in a short window. Rate-limited
		// consistent with the other submission endpoints fixed in this round.
		if ( class_exists( 'JP_Security' ) && ! JP_Security::rate_limit( 'jp_submit_review', 5, 600, (string) get_current_user_id() ) ) {
			jp_json_response( false, 'You are submitting reviews too quickly. Please wait a few minutes.' );
		}

		$uid        = get_current_user_id();
		$company_id = absint($_POST['company_id']??0);
		$rating     = min(5,max(1,absint($_POST['rating_overall']??0)));

		if (!$company_id||!$rating) jp_json_response(false,'Company and rating are required.');

		global $wpdb;

		// One review per user per company
		$exists = $wpdb->get_var($wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}jp_reviews WHERE user_id=%d AND company_id=%d LIMIT 1",
			$uid,$company_id
		));
		if ($exists) jp_json_response(false,'You have already reviewed this company.');

		// Check if verified employee (has application that was hired at this company)
		$is_verified = (bool)$wpdb->get_var($wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}jp_applications a
			 LEFT JOIN {$wpdb->prefix}jp_jobs j ON j.id=a.job_id
			 WHERE a.candidate_id=%d AND j.company_id=%d AND a.stage='hired'",
			$uid,$company_id
		));

		$status = get_option('jp_auto_approve_reviews','0') === '1' ? 'approved' : 'pending';

		// Root-cause fix: this previously wrote 'rating_culture' and
		// 'rating_salary' into $wpdb->insert()'s field array, but the
		// jp_reviews table has never had those columns — only rating_wlb,
		// rating_growth, rating_mgmt, and rating_pay. $wpdb->insert() builds
		// its SQL from exactly the keys given, so those two submitted rating
		// aspects were silently discarded on every single review, and the
		// public company page (single-jp_company.php) had no real data to
		// show for "Career Growth"/"Salary & Benefits", which is why it was
		// showing rand(60,90) instead. Accept both the schema's own field
		// names and the older 'rating_culture'/'rating_salary' names a
		// caller may still send (frontend compat), and write to the real
		// columns either way.
		$rating_growth = absint( $_POST['rating_growth'] ?? $_POST['rating_culture'] ?? 0 );
		$rating_pay    = absint( $_POST['rating_pay']    ?? $_POST['rating_salary'] ?? 0 );

		// Root-cause fix (batch 17): unchecked $wpdb->insert() — same
		// ghost-success shape found throughout this codebase. A failed
		// write here still told the candidate their review was
		// published/submitted-for-moderation while nothing was persisted.
		$inserted = $wpdb->insert($wpdb->prefix.'jp_reviews',[
			'user_id'         => $uid,
			'company_id'      => $company_id,
			'title'           => sanitize_text_field($_POST['title']??''),
			'job_title'       => sanitize_text_field($_POST['job_title']??''),
			'employment_type' => sanitize_key($_POST['employment_type']??'current'),
			'rating_overall'  => $rating,
			'rating_wlb'      => min(5,max(0,absint($_POST['rating_wlb']??0))),
			'rating_growth'   => min(5,max(0,$rating_growth)),
			'rating_mgmt'     => min(5,max(0,absint($_POST['rating_mgmt']??0))),
			'rating_pay'      => min(5,max(0,$rating_pay)),
			'pros'            => sanitize_textarea_field($_POST['pros']??''),
			'cons'            => sanitize_textarea_field($_POST['cons']??''),
			'is_anonymous'    => absint($_POST['is_anonymous']??0),
			'is_verified'     => $is_verified ? 1 : 0,
			'status'          => $status,
			'created_at'      => current_time('mysql'),
		],['%d','%d','%s','%s','%s','%d','%d','%d','%d','%d','%s','%s','%d','%d','%s','%s']);
		if ( false === $inserted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_reviews insert failed: ' . $wpdb->last_error ), 'JP_Reviews::ajax_submit user_id=' . $uid . ' company_id=' . $company_id );
			}
			jp_json_response( false, 'Could not submit your review. Please try again.' );
			return;
		}

		if ($status === 'approved') $this->recalculate_rating($company_id);
		jp_json_response(true,['message'=>$status==='approved'?'Review published!':'Review submitted and pending moderation. Thank you!']);
	}

	public function ajax_reply(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');

		$review_id = absint($_POST['review_id']??0);
		$reply     = sanitize_textarea_field($_POST['reply']??'');
		if (!$review_id||!$reply) jp_json_response(false,'Missing data.');

		global $wpdb;
		$review  = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_reviews WHERE id=%d",$review_id));
		if (!$review) jp_json_response(false,'Review not found.');

		// Must be company owner or admin
		$company = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_companies WHERE id=%d",$review->company_id));
		$uid     = get_current_user_id();
		if (!current_user_can('administrator') && (int)$company->user_id !== $uid) {
			jp_json_response(false,'Permission denied.');
		}

		// Root-cause fix (batch 17): unchecked $wpdb->update() — same shape
		// as ajax_submit() above. A failed write told the company owner
		// "Reply posted." while the review stayed unreplied.
		$updated = $wpdb->update($wpdb->prefix.'jp_reviews',[
			'company_reply'    => $reply,
			'replied_at'       => current_time('mysql'),
			'replied_by'       => $uid,
		],['id'=>$review_id],['%s','%s','%d'],['%d']);
		if ( false === $updated ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_reviews reply update failed: ' . $wpdb->last_error ), 'JP_Reviews::ajax_reply review_id=' . $review_id );
			}
			jp_json_response( false, 'Could not post this reply. Please try again.' );
			return;
		}

		jp_json_response(true,['message'=>'Reply posted.']);
	}

	public function ajax_vote(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');
		$review_id = absint($_POST['review_id']??0);
		$useful    = absint($_POST['useful']??0);
		global $wpdb;
		if ($useful) {
			// Root-cause fix: the schema's real column is 'helpful_count' —
			// 'votes_helpful' does not exist, so every "helpful" vote was
			// silently failing (raw $wpdb->query() against a nonexistent
			// column returns false with no exception, so this looked fine
			// end-to-end but never persisted a single vote).
			$wpdb->query($wpdb->prepare("UPDATE {$wpdb->prefix}jp_reviews SET helpful_count=helpful_count+1 WHERE id=%d",$review_id));
		}
		jp_json_response(true,['message'=>'Thanks for your feedback.']);
	}

	public function recalculate_rating( int $company_id ): void {
		global $wpdb;
		// Root-cause fix: this only ever aggregated rating_overall. The four
		// per-aspect averages (Work-Life Balance, Career Growth, Management,
		// Salary & Benefits) shown on the public company page had no real
		// source at all — hence the rand(60,90) placeholder there. Aggregate
		// all five here and persist them onto jp_companies so the page can
		// render real data.
		$row = $wpdb->get_row($wpdb->prepare(
			"SELECT AVG(rating_overall) AS avg_overall, AVG(rating_wlb) AS avg_wlb,
			        AVG(rating_growth) AS avg_growth, AVG(rating_mgmt) AS avg_mgmt,
			        AVG(rating_pay) AS avg_pay, COUNT(*) AS cnt
			 FROM {$wpdb->prefix}jp_reviews WHERE company_id=%d AND status='approved'",
			$company_id
		));
		if ($row) {
			$wpdb->update($wpdb->prefix.'jp_companies',[
				'rating_avg'        => round((float)$row->avg_overall,2),
				'rating_wlb_avg'    => round((float)$row->avg_wlb,2),
				'rating_growth_avg' => round((float)$row->avg_growth,2),
				'rating_mgmt_avg'   => round((float)$row->avg_mgmt,2),
				'rating_pay_avg'    => round((float)$row->avg_pay,2),
				'reviews_count'     => (int)$row->cnt,
			],['id'=>$company_id],['%f','%f','%f','%f','%f','%d'],['%d']);
		}
	}

	public function approve( int $review_id ): void {
		global $wpdb;
		$rev = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_reviews WHERE id=%d",$review_id));
		if (!$rev) return;
		// Root-cause fix (batch 17): unchecked $wpdb->update() — an admin
		// approving a pending review from the moderation queue would
		// previously see it vanish from "pending" with no confirmation
		// the status actually flipped, and recalculate_rating() would
		// still run against a review that was never actually marked
		// approved (which its own WHERE status='approved' would then
		// correctly exclude — silently under-counting the aggregate
		// rather than corrupting it, but the review itself stays
		// invisible to the public with no signal to the admin why).
		$updated = $wpdb->update($wpdb->prefix.'jp_reviews',['status'=>'approved'],['id'=>$review_id],['%s'],['%d']);
		if ( false === $updated ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_reviews approve update failed: ' . $wpdb->last_error ), 'JP_Reviews::approve review_id=' . $review_id );
			}
			return;
		}
		$this->recalculate_rating((int)$rev->company_id);
	}
}
