<?php
/**
 * Class JP_Migrator — versioned schema migration framework.
 *
 * ROOT CAUSE (see enterprise-gap-analysis.md, P0: "No schema
 * migration/versioning framework"): every version bump simply re-ran the
 * full idempotent `dbDelta()` schema definition in one giant method
 * (`JP_Activator::activate()`). `dbDelta()` can safely ADD new
 * tables/columns/indexes, but it can never DROP or rename a column, can
 * never add a FOREIGN KEY constraint (dbDelta's parser does not understand
 * `CONSTRAINT ... FOREIGN KEY` clauses at all — it silently ignores them),
 * and has no concept of "run this one-time data-repair step exactly once."
 * The result: schema cruft could only ever accumulate, and any change that
 * wasn't a pure additive `CREATE TABLE`/`ADD COLUMN` had no home in this
 * codebase at all.
 *
 * This class is that home. It is deliberately small and boring:
 *   - A real `jp_schema_migrations` table (id, version, description,
 *     status, error, ran_at) tracks exactly which migrations have run.
 *   - Each migration is a numbered file under `includes/migrations/`
 *     returning `['version' => int, 'description' => string, 'up' =>
 *     callable(wpdb): void]`. `up()` receives `$wpdb` directly and is
 *     expected to throw on unrecoverable failure — JP_Migrator catches
 *     that per-migration so one broken migration cannot block every
 *     migration after it (or before it) from running.
 *   - `run_pending()` is called from the existing version-bump check in
 *     jp-core.php (the same place that already calls dbDelta), AFTER
 *     dbDelta, so a migration can assume the additive schema already
 *     exists and focus purely on constraints/backfills/cleanup.
 *   - Every migration is idempotent-safe to re-run manually (each ALTER
 *     wraps its own try/catch and checks "does this constraint already
 *     exist" before adding it) so a partial failure can be retried without
 *     manual DB surgery.
 *
 * This does NOT replace dbDelta for additive schema changes (new
 * table/column) — that remains the right, simpler tool for that job, per
 * WordPress convention. This exists specifically for what dbDelta cannot
 * do: constraints, data cleanup, and any destructive/structural change.
 */
defined( 'ABSPATH' ) || exit;

class JP_Migrator {

	private static ?JP_Migrator $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {}

	/** Ensure the tracking table exists. Safe to call every request (cheap, uses IF NOT EXISTS). */
	public function ensure_tracking_table(): void {
		global $wpdb;
		$table   = $wpdb->prefix . 'jp_schema_migrations';
		$charset = $wpdb->get_charset_collate();
		$wpdb->query( "CREATE TABLE IF NOT EXISTS {$table} (
			id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			version     INT UNSIGNED    NOT NULL,
			description VARCHAR(255)    NOT NULL,
			status      ENUM('success','failed') NOT NULL,
			error       TEXT NULL,
			ran_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			UNIQUE KEY version (version)
		) $charset;" );
	}

	/**
	 * Discover migration files, run any whose version has no 'success' row
	 * yet, and record the outcome of each. A migration that previously
	 * failed is retried on the next call (so fixing the underlying issue —
	 * e.g. an unexpectedly non-InnoDB table — and re-deploying is enough to
	 * pick it back up, with no manual DB surgery).
	 */
	public function run_pending(): void {
		global $wpdb;
		$this->ensure_tracking_table();

		$table   = $wpdb->prefix . 'jp_schema_migrations';
		$already = $wpdb->get_col( "SELECT version FROM {$table} WHERE status = 'success'" );
		$already = array_map( 'intval', $already ?: [] );

		foreach ( $this->discover_migrations() as $migration ) {
			if ( in_array( $migration['version'], $already, true ) ) continue;

			try {
				$migration['up']( $wpdb );
				$this->record( $migration, 'success', null );
			} catch ( \Throwable $e ) {
				$this->record( $migration, 'failed', $e->getMessage() );
				// Log and continue — one failed migration must not prevent
				// unrelated later migrations (or the rest of plugin init)
				// from proceeding. See class docblock.
				error_log( sprintf(
					'JP_Migrator: migration %d (%s) failed: %s',
					$migration['version'], $migration['description'], $e->getMessage()
				) );
			}
		}
	}

	private function record( array $migration, string $status, ?string $error ): void {
		global $wpdb;
		$table = $wpdb->prefix . 'jp_schema_migrations';
		// REPLACE semantics via the UNIQUE KEY on version: a retried failed
		// migration overwrites its own prior row instead of accumulating
		// duplicate failure rows for the same version.
		$wpdb->query( $wpdb->prepare(
			"INSERT INTO {$table} (version, description, status, error, ran_at)
			 VALUES (%d, %s, %s, %s, NOW())
			 ON DUPLICATE KEY UPDATE description = VALUES(description), status = VALUES(status), error = VALUES(error), ran_at = VALUES(ran_at)",
			$migration['version'], $migration['description'], $status, $error
		) );
	}

	/** @return array<int, array{version:int, description:string, up:callable}> sorted by version ascending */
	private function discover_migrations(): array {
		$dir = __DIR__ . '/migrations';
		if ( ! is_dir( $dir ) ) return [];

		$migrations = [];
		foreach ( glob( $dir . '/*.php' ) ?: [] as $file ) {
			$def = require $file;
			if ( ! is_array( $def ) || ! isset( $def['version'], $def['up'] ) || ! is_callable( $def['up'] ) ) {
				error_log( "JP_Migrator: skipping malformed migration file: $file" );
				continue;
			}
			$def['description'] ??= basename( $file );
			$migrations[] = $def;
		}
		usort( $migrations, fn( $a, $b ) => $a['version'] <=> $b['version'] );
		return $migrations;
	}

	// ── Reusable FK-addition helper for migration files ───────────────────────

	/**
	 * Safely add a FOREIGN KEY constraint to an existing table, handling
	 * every real-world reason this can go wrong on a live database that was
	 * never designed with constraints in mind:
	 *
	 *  1. Both tables must be InnoDB (MyISAM does not support FKs at all).
	 *     If either isn't, this logs and returns false rather than fataling
	 *     the whole migration — a non-InnoDB table is a pre-existing
	 *     environment issue this migration cannot safely fix by itself.
	 *  2. The constraint may already exist (a retried migration, or someone
	 *     added it by hand) — checked via information_schema and skipped,
	 *     not re-added (which would error).
	 *  3. If $nullable_sentinel_zero is true, the child column is treated as
	 *     using 0 as a NOT-NULL "no relation" sentinel (a common pattern in
	 *     this codebase, e.g. jp_jobs.company_id). A FK constraint cannot
	 *     accept a value that never exists in the parent (there is no row
	 *     with id=0), so this: (a) MODIFYs the column to be NULLable, (b)
	 *     converts every existing 0 to NULL, then (c) adds the constraint
	 *     with ON DELETE SET NULL regardless of the requested $on_delete —
	 *     CASCADE on a nullable "optional relation" column would delete
	 *     rows that were only ever loosely associated, which is not the
	 *     intended semantics of a 0/optional sentinel.
	 *  4. Orphan rows (a child value with no matching parent row at all —
	 *     from a bad delete that happened before this constraint existed)
	 *     are cleaned up before the ALTER, because MySQL will refuse to add
	 *     a FK constraint while any orphan exists. Cleanup for a
	 *     non-nullable relation means those specific rows cannot be kept
	 *     (there is no valid value to set them to) — they are logged via
	 *     JP_Security::audit() with the exact row count so this is visible,
	 *     not silent, before being removed.
	 *
	 * @return bool true if the constraint is present after this call (either newly added or already existed), false if it could not be added.
	 */
	public function add_foreign_key_safely(
		\wpdb $wpdb,
		string $child_table,
		string $child_col,
		string $parent_table,
		string $parent_col,
		string $on_delete,
		string $constraint_name,
		bool $nullable_sentinel_zero = false
	): bool {
		$db = DB_NAME;

		// 1. Both tables InnoDB?
		$engines = $wpdb->get_results( $wpdb->prepare(
			"SELECT TABLE_NAME, ENGINE FROM information_schema.TABLES WHERE TABLE_SCHEMA = %s AND TABLE_NAME IN (%s, %s)",
			$db, $child_table, $parent_table
		) );
		$engine_by_table = [];
		foreach ( $engines as $row ) $engine_by_table[ $row->TABLE_NAME ] = $row->ENGINE;
		if ( ( $engine_by_table[ $child_table ] ?? '' ) !== 'InnoDB' || ( $engine_by_table[ $parent_table ] ?? '' ) !== 'InnoDB' ) {
			error_log( "JP_Migrator: skipping FK {$constraint_name} — {$child_table} or {$parent_table} is not InnoDB (found: " . json_encode( $engine_by_table ) . ')' );
			return false;
		}

		// 2. Already exists?
		$exists = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND CONSTRAINT_NAME = %s AND CONSTRAINT_TYPE = 'FOREIGN KEY'",
			$db, $child_table, $constraint_name
		) );
		if ( $exists > 0 ) return true;

		// 3. Sentinel-zero handling: make the column nullable and convert 0 -> NULL first.
		$effective_on_delete = $on_delete;
		if ( $nullable_sentinel_zero ) {
			$col_def = $wpdb->get_row( $wpdb->prepare(
				"SELECT COLUMN_TYPE FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s AND COLUMN_NAME = %s",
				$db, $child_table, $child_col
			) );
			if ( ! $col_def ) {
				error_log( "JP_Migrator: skipping FK {$constraint_name} — column {$child_table}.{$child_col} not found" );
				return false;
			}
			$wpdb->query( "ALTER TABLE {$child_table} MODIFY {$child_col} {$col_def->COLUMN_TYPE} NULL DEFAULT NULL" );
			$wpdb->query( "UPDATE {$child_table} SET {$child_col} = NULL WHERE {$child_col} = 0" );
			$effective_on_delete = 'SET NULL';
		}

		// 4. Orphan cleanup — required or the ALTER will simply fail.
		$orphan_count = (int) $wpdb->get_var(
			"SELECT COUNT(*) FROM {$child_table} c
			 WHERE c.{$child_col} IS NOT NULL
			   AND NOT EXISTS ( SELECT 1 FROM {$parent_table} p WHERE p.{$parent_col} = c.{$child_col} )"
		);
		if ( $orphan_count > 0 ) {
			if ( class_exists( 'JP_Security' ) ) {
				JP_Security::instance()->audit(
					'migration_orphan_cleanup',
					$child_table,
					0,
					sprintf( 'Removed %d orphan row(s) from %s.%s with no matching %s.%s before adding FK %s (pre-existing data issue from before this constraint existed).', $orphan_count, $child_table, $child_col, $parent_table, $parent_col, $constraint_name )
				);
			}
			if ( $nullable_sentinel_zero ) {
				// Optional relation — repoint the orphan to "no relation" instead of deleting the row.
				$wpdb->query(
					"UPDATE {$child_table} c SET c.{$child_col} = NULL
					 WHERE c.{$child_col} IS NOT NULL AND NOT EXISTS ( SELECT 1 FROM {$parent_table} p WHERE p.{$parent_col} = c.{$child_col} )"
				);
			} else {
				// Required relation with no valid parent — the row itself is unrecoverable data debt; removing it is the only option a FK constraint leaves.
				$wpdb->query(
					"DELETE c FROM {$child_table} c
					 WHERE c.{$child_col} IS NOT NULL AND NOT EXISTS ( SELECT 1 FROM {$parent_table} p WHERE p.{$parent_col} = c.{$child_col} )"
				);
			}
		}

		// 5. Add the constraint.
		$sql = "ALTER TABLE {$child_table} ADD CONSTRAINT {$constraint_name} FOREIGN KEY ({$child_col}) REFERENCES {$parent_table} ({$parent_col}) ON DELETE {$effective_on_delete}";
		$ok  = $wpdb->query( $sql );
		if ( $ok === false ) {
			error_log( "JP_Migrator: failed to add FK {$constraint_name}: " . $wpdb->last_error );
			return false;
		}
		return true;
	}

	/**
	 * Admin-visible status (per phase2-progress-report.md's "no working
	 * admin health endpoint" and "no centralized error logging" findings —
	 * this gives an admin somewhere to actually SEE migration state instead
	 * of grepping error logs).
	 *
	 * @return array<int, object> rows from jp_schema_migrations, newest first
	 */
	public function status(): array {
		global $wpdb;
		$this->ensure_tracking_table();
		$table = $wpdb->prefix . 'jp_schema_migrations';
		return $wpdb->get_results( "SELECT * FROM {$table} ORDER BY version DESC" ) ?: [];
	}
}
