<?php
/**
 * Class JP_PWA — Progressive Web App integration.
 *
 * - Registers service worker via JS
 * - Injects <link rel="manifest"> and Apple/Android meta tags
 * - VAPID key management for Web Push notifications
 * - Push subscription CRUD (save to DB when user subscribes)
 * - Send push notifications to individual users or broadcast
 * - Install prompt banner logic
 */
defined( 'ABSPATH' ) || exit;

class JP_PWA {

	private static ?JP_PWA $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_head',           [ $this, 'output_pwa_tags' ], 2 );
		add_action( 'wp_footer',         [ $this, 'register_sw_script' ], 99 );
		add_action( 'init',              [ $this, 'serve_sw_route' ] );
		add_action( 'wp_enqueue_scripts',[ $this, 'enqueue_pwa_assets' ] );

		// REST endpoints for push subscriptions
		add_action( 'rest_api_init', [ $this, 'register_push_routes' ] );

		// AJAX handlers
		add_action( 'wp_ajax_jp_save_push_sub',   [ $this, 'ajax_save_subscription' ] );
		add_action( 'wp_ajax_jp_delete_push_sub', [ $this, 'ajax_delete_subscription' ] );
	}

	// ── PWA tags in <head> ────────────────────────────────────────────────────

	public function output_pwa_tags(): void {
		$manifest_url = get_template_directory_uri() . '/manifest.webmanifest';
		$theme_color  = '#156BC9';
		$app_name     = jp_site_name();
		$icon_url     = get_template_directory_uri() . '/assets/images/icon-192.png';

		echo '<link rel="manifest" href="' . esc_url( $manifest_url ) . '">' . "\n";
		echo '<meta name="theme-color" content="' . esc_attr( $theme_color ) . '">' . "\n";
		echo '<meta name="mobile-web-app-capable" content="yes">' . "\n";
		echo '<meta name="apple-mobile-web-app-capable" content="yes">' . "\n";
		echo '<meta name="apple-mobile-web-app-status-bar-style" content="default">' . "\n";
		echo '<meta name="apple-mobile-web-app-title" content="' . esc_attr( $app_name ) . '">' . "\n";
		echo '<link rel="apple-touch-icon" href="' . esc_url( $icon_url ) . '">' . "\n";
		echo '<meta name="application-name" content="' . esc_attr( $app_name ) . '">' . "\n";
		echo '<meta name="msapplication-TileColor" content="' . esc_attr( $theme_color ) . '">' . "\n";
		echo '<meta name="msapplication-TileImage" content="' . esc_url( get_template_directory_uri() . '/assets/images/icon-144.png' ) . '">' . "\n";
	}

	// ── Service worker registration ───────────────────────────────────────────

	public function register_sw_script(): void {
		$sw_url   = home_url( '/sw.js' );
		$vapid_pub = get_option( 'jp_vapid_public_key', '' );
		$nonce    = wp_create_nonce( 'jp_general' );
		$ajax_url = admin_url( 'admin-ajax.php' );
		echo <<<JS
<script>
(function(){
  if (!('serviceWorker' in navigator)) return;

  const SW_URL      = '{$sw_url}';
  const VAPID_KEY   = '{$vapid_pub}';
  const AJAX_URL    = '{$ajax_url}';
  const NONCE       = '{$nonce}';

  // Register service worker
  navigator.serviceWorker.register(SW_URL, { scope: '/' })
    .then(reg => {
      console.log('[SW] Registered, scope:', reg.scope);

      // Auto-subscribe to push if permission already granted
      if (Notification.permission === 'granted' && VAPID_KEY) {
        subscribePush(reg);
      }

      // Listen for updates
      reg.addEventListener('updatefound', () => {
        const sw = reg.installing;
        sw.addEventListener('statechange', () => {
          if (sw.state === 'installed' && navigator.serviceWorker.controller) {
            showUpdateBanner();
          }
        });
      });
    })
    .catch(err => console.warn('[SW] Registration failed:', err));

  // Push subscription
  window.jpRequestPushPermission = async function() {
    if (!('PushManager' in window) || !VAPID_KEY) return;
    const permission = await Notification.requestPermission();
    if (permission !== 'granted') return;
    const reg = await navigator.serviceWorker.ready;
    subscribePush(reg);
  };

  async function subscribePush(reg) {
    try {
      const sub = await reg.pushManager.subscribe({
        userVisibleOnly:      true,
        applicationServerKey: urlBase64ToUint8Array(VAPID_KEY),
      });
      // Send subscription to server
      await fetch(AJAX_URL, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body:    new URLSearchParams({ action: 'jp_save_push_sub', nonce: NONCE, subscription: JSON.stringify(sub) }),
      });
    } catch (err) {
      console.warn('[SW] Push subscribe failed:', err);
    }
  }

  function urlBase64ToUint8Array(base64String) {
    const padding  = '='.repeat((4 - base64String.length % 4) % 4);
    const base64   = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/');
    const rawData  = window.atob(base64);
    return Uint8Array.from([...rawData].map(c => c.charCodeAt(0)));
  }

  // Install prompt
  let deferredPrompt;
  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    const banner = document.getElementById('jp-install-banner');
    if (banner) banner.classList.add('jp-install-banner--visible');
  });

  window.jpInstallApp = async function() {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    deferredPrompt = null;
    if (outcome === 'accepted') {
      const banner = document.getElementById('jp-install-banner');
      if (banner) banner.remove();
    }
  };

  function showUpdateBanner() {
    const banner = document.createElement('div');
    banner.id    = 'jp-update-banner';
    banner.style.cssText = 'position:fixed;bottom:20px;left:50%;transform:translateX(-50%);background:#156BC9;color:#fff;padding:12px 24px;border-radius:8px;z-index:9999;font-family:sans-serif;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,0.2)';
    banner.textContent = '🔄 New version available — Click to update';
    banner.onclick = () => window.location.reload();
    document.body.appendChild(banner);
  }
})();
</script>
JS;
	}

	// ── Serve sw.js from site root ────────────────────────────────────────────
	// Needed so SW has scope over the entire site, not just /wp-content/...

	public function serve_sw_route(): void {
		add_rewrite_rule( '^sw\.js$', 'index.php?jp_sw=1', 'top' );
		add_filter( 'query_vars', fn( $v ) => array_merge( $v, [ 'jp_sw' ] ) );

		if ( get_query_var( 'jp_sw' ) ) {
			$sw_path = get_template_directory() . '/assets/js/service-worker.js';
			if ( ! file_exists( $sw_path ) ) {
				status_header( 404 );
				exit;
			}
			header( 'Content-Type: application/javascript; charset=utf-8' );
			header( 'Service-Worker-Allowed: /' );
			header( 'Cache-Control: no-cache, no-store' );
			readfile( $sw_path );
			exit;
		}
	}

	// ── Enqueue PWA assets ────────────────────────────────────────────────────

	public function enqueue_pwa_assets(): void {
		// Nothing to enqueue — SW is registered inline in footer
		// But register the offline page template
	}

	// ── AJAX: Save push subscription ──────────────────────────────────────────

	public function ajax_save_subscription(): void {
		jp_verify_nonce( 'jp_general' );
		if ( ! is_user_logged_in() ) wp_send_json_success(); // Silently fail for guests

		$sub_json = sanitize_text_field( $_POST['subscription'] ?? '' );
		$sub      = json_decode( $sub_json, true );
		if ( empty( $sub['endpoint'] ) ) wp_die( 'Invalid subscription' );

		global $wpdb;
		// Root-cause fix (batch 18): unchecked write. The browser's Push API
		// subscribe() call already succeeded by the time this request is
		// sent, so a failed write here means the user's browser believes
		// push is enabled while the server has no record of it — every
		// future job-alert push send would simply have nothing to send to,
		// with no error anywhere pointing back at this silent failure.
		$write_ok = false !== $wpdb->replace( $wpdb->prefix . 'jp_push_subscriptions', [
			'user_id'          => get_current_user_id(),
			'endpoint'         => $sub['endpoint'],
			'p256dh_key'       => $sub['keys']['p256dh'] ?? '',
			'auth_key'         => $sub['keys']['auth']   ?? '',
			'user_agent'       => sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ?? '' ),
			'created_at'       => current_time( 'mysql' ),
		], [ '%d','%s','%s','%s','%s','%s' ] );

		if ( ! $write_ok ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_push_subscriptions write failed: ' . $wpdb->last_error ), 'JP_PWA::ajax_save_subscription user_id=' . get_current_user_id() );
			}
			wp_send_json_error( [ 'message' => 'Could not save push subscription. Please try again.' ] );
			return;
		}

		wp_send_json_success( [ 'ok' => true ] );
	}

	public function ajax_delete_subscription(): void {
		jp_verify_nonce( 'jp_general' );
		if ( ! is_user_logged_in() ) wp_die( 'Unauthorized' );
		global $wpdb;
		// Root-cause fix (batch 18): unchecked write. A failure here means
		// the user's browser unsubscribes locally (or believes it has) while
		// the server-side row survives — the account would keep receiving
		// push notifications after apparently opting out, with no error
		// shown anywhere to explain why.
		if ( false === $wpdb->delete( $wpdb->prefix . 'jp_push_subscriptions', [ 'user_id' => get_current_user_id() ] ) ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_push_subscriptions delete failed: ' . $wpdb->last_error ), 'JP_PWA::ajax_delete_subscription user_id=' . get_current_user_id() );
			}
			wp_send_json_error( [ 'message' => 'Could not remove push subscription. Please try again.' ] );
			return;
		}
		wp_send_json_success( [ 'ok' => true ] );
	}

	// ── REST routes ───────────────────────────────────────────────────────────

	public function register_push_routes(): void {
		register_rest_route( JP_Api::namespace_str(), '/push/send', [ // Batch 31: was hardcoded 'jp/v1'
			'methods'             => 'POST',
			'callback'            => [ $this, 'rest_send_push' ],
			'permission_callback' => fn() => current_user_can( 'manage_options' ),
		] );
	}

	public function rest_send_push( \WP_REST_Request $r ) {
		$user_id = absint( $r->get_param( 'user_id' ) ?? 0 );
		$title   = sanitize_text_field( $r->get_param( 'title' ) ?? '' );
		$body    = sanitize_text_field( $r->get_param( 'body' ) ?? '' );
		$url     = esc_url_raw( $r->get_param( 'url' ) ?? home_url('/') );

		if ( ! $title || ! $body ) return new \WP_Error( 'missing_params', 'title and body are required.', [ 'status' => 400 ] );

		$sent = $this->send_push( $user_id, [ 'title' => $title, 'body' => $body, 'url' => $url ] );
		// Root-cause fix (same class of bug found and fixed in
		// class-jp-diagnostics.php's rest_report(), found via a user report
		// that a REST-backed screen "showed nothing"): this route isn't
		// currently called from the SPA via apiRequest() — grepped and
		// confirmed unused there — but returning the raw payload instead of
		// the {success, data} envelope every other endpoint uses would
		// silently reproduce the exact same "fetch succeeds, unwrap yields
		// undefined" failure the moment anything in the app calls it.
		// Wrapping now, before that happens, rather than waiting to be
		// asked why this one doesn't work either.
		return new \WP_REST_Response( [ 'success' => true, 'data' => [ 'sent' => $sent ] ], 200 );
	}

	// ── Send push notification via Web Push (VAPID) ───────────────────────────

	public function send_push( int $user_id, array $payload ): int {
		global $wpdb;

		$where = $user_id
			? $wpdb->prepare( "WHERE user_id=%d", $user_id )
			: '';

		$subs  = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}jp_push_subscriptions {$where}" );
		if ( empty( $subs ) ) return 0;

		$vapid_public  = get_option( 'jp_vapid_public_key', '' );
		$vapid_private = get_option( 'jp_vapid_private_key', '' );

		if ( ! $vapid_public || ! $vapid_private ) return 0;

		$sent  = 0;
		$stale = [];

		foreach ( $subs as $sub ) {
			$result = $this->send_web_push( $sub, $payload, $vapid_public, $vapid_private );
			if ( $result === 'sent' )  $sent++;
			if ( $result === 'stale' ) $stale[] = $sub->id;
		}

		// Remove expired subscriptions (endpoint returned 410).
		// Root-cause fix (batch 18): unchecked write. Left log-only (not
		// surfaced to any caller) since this is best-effort cleanup — a
		// failed delete here just means a dead subscription is retried on
		// the next send_push() call, gets another 410, and is retried for
		// cleanup again; it never blocks a real notification from reaching
		// a live subscriber, so it self-corrects with no user-facing impact.
		if ( $stale ) {
			$ids = implode( ',', array_map( 'absint', $stale ) );
			if ( false === $wpdb->query( "DELETE FROM {$wpdb->prefix}jp_push_subscriptions WHERE id IN({$ids})" ) && class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'stale jp_push_subscriptions cleanup failed: ' . $wpdb->last_error ), 'JP_PWA::send_push' );
			}
		}

		return $sent;
	}

	private function send_web_push( object $sub, array $payload, string $vapid_pub, string $vapid_priv ): string {
		$endpoint   = $sub->endpoint;
		$auth_key   = $sub->auth_key;
		$p256dh_key = $sub->p256dh_key;

		if ( ! $endpoint ) return 'error';

		$body = wp_json_encode( $payload );
		$exp  = time() + 43200; // 12 hours

		// Root-cause fix: this JWT was never actually signed — the previous
		// code built header+claims and shipped it as the "token" with no
		// signature at all, which real push services (FCM, Mozilla
		// autopush) reject outright, since a valid ES256 VAPID JWT requires
		// a genuine EC signature over header.claims. Sign it for real with
		// OpenSSL using the site's own VAPID private key, and convert
		// OpenSSL's DER-encoded ECDSA signature into the raw, fixed-length
		// r||s (P-1363 / "JOSE") format the Web Push / JWS ES256 spec
		// requires — DER and JOSE are NOT the same byte layout.
		$audience = parse_url( $endpoint, PHP_URL_SCHEME ) . '://' . parse_url( $endpoint, PHP_URL_HOST );
		$header   = self::b64url( wp_json_encode( [ 'typ' => 'JWT', 'alg' => 'ES256' ] ) );
		$claims   = self::b64url( wp_json_encode( [ 'aud' => $audience, 'exp' => $exp, 'sub' => 'mailto:' . get_option('admin_email') ] ) );
		$signing_input = "{$header}.{$claims}";

		$signature = self::sign_es256( $signing_input, $vapid_priv );
		if ( $signature === '' ) {
			// Cannot produce a valid signature (e.g. no OpenSSL EC support,
			// or a malformed stored key) — do not send an unsigned/garbage
			// token that will just be silently rejected by the push
			// service; fail loudly enough that send_web_push()'s caller can
			// tell this subscription attempt didn't really go out.
			return 'error';
		}
		$vapid_token = "{$signing_input}." . self::b64url_raw( $signature );

		$response = wp_remote_post( $endpoint, [
			'timeout' => 10,
			'headers' => [
				'Content-Type'   => 'application/json',
				'Content-Length' => strlen( $body ),
				'TTL'            => '86400',
				'Authorization'  => "vapid t={$vapid_token},k={$vapid_pub}",
			],
			'body' => $body,
		] );

		if ( is_wp_error( $response ) ) return 'error';
		$code = wp_remote_retrieve_response_code( $response );

		if ( $code === 410 || $code === 404 ) return 'stale'; // Subscription expired
		if ( $code >= 200 && $code < 300 )    return 'sent';
		return 'error';
	}

	private static function b64url( string $data ): string {
		return self::b64url_raw( $data );
	}

	private static function b64url_raw( string $data ): string {
		return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' );
	}

	private static function b64url_decode( string $data ): string {
		$data = strtr( $data, '-_', '+/' );
		$pad  = strlen( $data ) % 4;
		if ( $pad ) $data .= str_repeat( '=', 4 - $pad );
		return (string) base64_decode( $data );
	}

	/**
	 * Sign $signing_input with the site's VAPID private key (base64url,
	 * raw 32-byte EC scalar, as produced/stored by generate_vapid_keys())
	 * using ES256, returning the raw fixed-length r||s signature the Web
	 * Push / JWS spec expects (NOT OpenSSL's default DER encoding).
	 * Returns '' on any failure (missing OpenSSL EC support, malformed key).
	 */
	private static function sign_es256( string $signing_input, string $vapid_priv_b64url ): string {
		if ( ! function_exists( 'openssl_sign' ) || ! function_exists( 'openssl_pkey_new' ) ) return '';

		$d = self::b64url_decode( $vapid_priv_b64url );
		if ( strlen( $d ) !== 32 ) return '';

		// Build a PEM EC private key from the raw 'd' scalar via an ASN.1
		// SEC1 ECPrivateKey structure (named curve prime256v1 / secp256r1),
		// since PHP's openssl_pkey_* has no "import raw scalar" API.
		$pem = self::ec_private_key_pem_from_d( $d );
		if ( $pem === '' ) return '';

		$pkey = openssl_pkey_get_private( $pem );
		if ( ! $pkey ) return '';

		$der_signature = '';
		$ok = openssl_sign( $signing_input, $der_signature, $pkey, OPENSSL_ALGO_SHA256 );
		if ( ! $ok || $der_signature === '' ) return '';

		return self::der_to_p1363( $der_signature, 32 );
	}

	/**
	 * Wrap a raw P-256 private scalar into a minimal SEC1 ECPrivateKey PEM.
	 * Avoids depending on any external crypto library for VAPID signing.
	 */
	private static function ec_private_key_pem_from_d( string $d ): string {
		// ASN.1 DER for SEC1 ECPrivateKey { version=1, privateKey=$d,
		// parameters=[0] namedCurve prime256v1 (OID 1.2.840.10045.3.1.7) }.
		// Constructed by hand (no bcmath/gmp dependency) since this is a
		// fixed, well-known structure once $d's length is known (32 bytes).
		$oid_prime256v1 = "\x06\x08\x2a\x86\x48\xce\x3d\x03\x01\x07"; // OID 1.2.840.10045.3.1.7
		$version   = "\x02\x01\x01"; // INTEGER 1
		$priv_key  = "\x04\x20" . $d; // OCTET STRING, 32 bytes
		$params    = "\xa0\x0a" . $oid_prime256v1; // [0] EXPLICIT namedCurve

		$body = $version . $priv_key . $params;
		$seq  = "\x30" . self::der_len( strlen( $body ) ) . $body;

		$pem = "-----BEGIN EC PRIVATE KEY-----\n" . chunk_split( base64_encode( $seq ), 64, "\n" ) . "-----END EC PRIVATE KEY-----\n";
		// Validate round-trip before trusting it — if OpenSSL can't parse
		// what we built, fail closed rather than sign with garbage.
		return openssl_pkey_get_private( $pem ) ? $pem : '';
	}

	private static function der_len( int $len ): string {
		if ( $len < 128 ) return chr( $len );
		$bytes = ltrim( pack( 'N', $len ), "\x00" );
		return chr( 0x80 | strlen( $bytes ) ) . $bytes;
	}

	/**
	 * Convert an OpenSSL DER ECDSA signature to the fixed-length raw r||s
	 * ("P-1363"/JOSE) format required by JWS ES256, for a curve whose
	 * order fits in $coord_size bytes (32 for P-256).
	 */
	private static function der_to_p1363( string $der, int $coord_size ): string {
		$offset = 0;
		if ( ord( $der[ $offset++ ] ?? "\x00" ) !== 0x30 ) return '';
		$seq_len = ord( $der[ $offset++ ] ?? "\x00" );
		if ( $seq_len & 0x80 ) $offset += $seq_len & 0x7f; // skip long-form length bytes

		$read_int = function () use ( $der, &$offset ): string {
			if ( ( $der[ $offset++ ] ?? '' ) !== "\x02" ) return '';
			$len = ord( $der[ $offset++ ] ?? "\x00" );
			$val = substr( $der, $offset, $len );
			$offset += $len;
			return ltrim( $val, "\x00" ); // drop DER's leading zero-pad
		};

		$r = $read_int();
		$s = $read_int();
		if ( $r === '' || $s === '' ) return '';

		return str_pad( $r, $coord_size, "\x00", STR_PAD_LEFT ) . str_pad( $s, $coord_size, "\x00", STR_PAD_LEFT );
	}

	// ── VAPID key generation ──────────────────────────────────────────────────

	public static function generate_vapid_keys(): array {
		// Requires OpenSSL with EC support (standard on all modern PHP installs)
		if ( ! function_exists( 'openssl_pkey_new' ) ) return [];

		$key = openssl_pkey_new( [
			'curve_name' => 'prime256v1',
			'private_key_type' => OPENSSL_KEYTYPE_EC,
		] );
		if ( ! $key ) return [];

		$details = openssl_pkey_get_details( $key );
		$ec      = $details['ec'] ?? null;
		if ( ! $ec ) return [];

		$private = base64_encode( $ec['d'] );
		$public  = base64_encode( "\x04" . $ec['x'] . $ec['y'] );

		// Root-cause fix: 'public' and 'private' were swapped here. The
		// "public" key returned by this function is embedded directly into
		// front-end JavaScript for every visitor (output_pwa_tags(), which
		// exposes it as a JS constant sent to the browser) — with the swap,
		// that meant the site's actual VAPID PRIVATE key (the EC private
		// scalar, $ec['d']) was being served to every visitor's browser as
		// if it were public, a real secret-exposure bug, not just a
		// functional one. If VAPID keys were already generated on a live
		// site with the old (buggy) code, they must be regenerated AND any
		// already-exposed value must be treated as compromised — rotate,
		// don't just patch.
		return [
			'public'  => rtrim( strtr( $public,  '+/', '-_' ), '=' ),
			'private' => rtrim( strtr( $private, '+/', '-_' ), '=' ),
		];
	}

	/**
	 * Broadcast a push notification to all subscribers (or a segment).
	 * Returns the count of subscribers notified.
	 */
	public function broadcast( string $title, string $body, string $segment = 'all' ): int {
		// Root-cause fix: this called send_push() with 5 positional
		// arguments ($endpoint, $p256dh, $auth_key, $title, $body), but
		// send_push()'s actual signature is (int $user_id, array $payload) —
		// any invocation of broadcast() would throw a PHP TypeError before
		// sending a single notification. send_push(0, ...) already means
		// "all subscriptions" (see its $where construction), so delegate to
		// it directly instead of re-implementing the subscription loop here.
		// $segment is accepted for a future targeted-broadcast feature but
		// is not yet used to filter recipients.
		return $this->send_push( 0, [
			'title' => $title,
			'body'  => $body,
			'url'   => home_url( '/' ),
		] );
	}

}
