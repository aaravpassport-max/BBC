<?php
defined( 'ABSPATH' ) || exit;

/**
 * JP_Auth — Custom authentication: login, register, password reset,
 * AJAX endpoints, and role-gated page access control.
 */
class JP_Auth {

    private static ?JP_Auth $instance = null;

    public static function instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->hooks();
    }

    private function hooks(): void {
        // AJAX — unauthenticated
        add_action( 'wp_ajax_nopriv_jp_login',    [ $this, 'ajax_login' ] );
        add_action( 'wp_ajax_nopriv_jp_register', [ $this, 'ajax_register' ] );
        add_action( 'wp_ajax_nopriv_jp_forgot_password', [ $this, 'ajax_forgot_password' ] );
        add_action( 'wp_ajax_nopriv_jp_reset_password',  [ $this, 'ajax_reset_password' ] );

        // AJAX — authenticated
        add_action( 'wp_ajax_jp_logout',          [ $this, 'ajax_logout' ] );
        add_action( 'wp_ajax_jp_update_password', [ $this, 'ajax_update_password' ] );

        // Page access control
        add_action( 'template_redirect', [ $this, 'gate_pages' ] );

        // Disable default WP login page — redirect to our custom /login/
        add_action( 'login_init', [ $this, 'redirect_wp_login' ] );

        // Remove WP admin bar for non-admins
        add_action( 'after_setup_theme', [ $this, 'remove_admin_bar_for_non_admin' ] );

        // Prevent non-admins from accessing /wp-admin/
        add_action( 'admin_init', [ $this, 'block_wp_admin' ] );
    }

    // ── AJAX: Login ───────────────────────────────────────────────────────────

    public function ajax_login(): void {
        jp_verify_nonce( 'jp_login' );

        $username = sanitize_user( wp_unslash( $_POST['username'] ?? '' ) );
        $password = $_POST['password'] ?? '';
        $remember = ! empty( $_POST['remember'] );

        if ( ! $username || ! $password ) {
            jp_json_response( __( 'Please enter your email and password.', 'jp-core' ), false, 400 );
        }

        // Allow login by email
        if ( is_email( $username ) ) {
            $user = get_user_by( 'email', $username );
            if ( $user ) $username = $user->user_login;
        }

        $user = wp_signon( [
            'user_login'    => $username,
            'user_password' => $password,
            'remember'      => $remember,
        ], is_ssl() );

        if ( is_wp_error( $user ) ) {
            jp_json_response( __( 'Invalid email or password.', 'jp-core' ), false, 401 );
        }

        // Determine redirect URL by role
        $role = jp_current_role();
        $map  = [
            'administrator'    => admin_url(),
            'jp_admin_manager' => home_url( '/admin-panel/' ),
            'jp_team_manager'  => home_url( '/recruiter/' ),
            'jp_staff'         => home_url( '/admin-panel/' ),
            'jp_recruiter'     => home_url( '/recruiter/' ),
            'jp_job_seeker'    => home_url( '/my-account/' ),
        ];

        jp_json_response( [
            'message'  => __( 'Login successful! Redirecting…', 'jp-core' ),
            'redirect' => $map[ $role ] ?? home_url( '/' ),
        ] );
    }

    // ── AJAX: Register ────────────────────────────────────────────────────────

    public function ajax_register(): void {
        jp_verify_nonce( 'jp_register' );

        $email    = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
        $password = $_POST['password'] ?? '';
        $name     = sanitize_text_field( wp_unslash( $_POST['name'] ?? '' ) );
        $type     = sanitize_key( $_POST['account_type'] ?? 'job_seeker' ); // job_seeker | recruiter

        // Validation
        if ( ! $email || ! is_email( $email ) ) {
            jp_json_response( __( 'Please enter a valid email address.', 'jp-core' ), false, 400 );
        }
        if ( strlen( $password ) < 8 ) {
            jp_json_response( __( 'Password must be at least 8 characters.', 'jp-core' ), false, 400 );
        }
        if ( email_exists( $email ) ) {
            jp_json_response( __( 'An account with this email already exists.', 'jp-core' ), false, 409 );
        }
        if ( ! $name ) {
            jp_json_response( __( 'Please enter your name.', 'jp-core' ), false, 400 );
        }

        $role = $type === 'recruiter' ? 'jp_recruiter' : 'jp_job_seeker';

        $user_id = wp_create_user( $email, $password, $email );

        if ( is_wp_error( $user_id ) ) {
            jp_json_response( $user_id->get_error_message(), false, 500 );
        }

        // Set role and name
        $user = new \WP_User( $user_id );
        $user->set_role( $role );
        wp_update_user( [
            'ID'           => $user_id,
            'display_name' => $name,
            'first_name'   => explode( ' ', $name )[0],
            'last_name'    => implode( ' ', array_slice( explode( ' ', $name ), 1 ) ),
        ] );

        // Create candidate or company record
        $db = JP_DB::instance();
        if ( $role === 'jp_job_seeker' ) {
            $db->insert( 'candidates', [ 'user_id' => $user_id ] );
        }

        // Auto-login
        wp_signon( [ 'user_login' => $email, 'user_password' => $password, 'remember' => true ], is_ssl() );

        // Send welcome email
        do_action( 'jp_user_registered', $user_id, $role, $name, $email );

        jp_json_response( [
            'message'  => __( 'Account created! Welcome aboard.', 'jp-core' ),
            'redirect' => $role === 'jp_recruiter' ? home_url( '/recruiter/' ) : home_url( '/my-account/' ),
        ] );
    }

    // ── AJAX: Forgot password ─────────────────────────────────────────────────

    public function ajax_forgot_password(): void {
        jp_verify_nonce( 'jp_forgot_password' );

        $email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );

        if ( ! $email || ! is_email( $email ) ) {
            jp_json_response( __( 'Please enter a valid email.', 'jp-core' ), false, 400 );
        }

        $user = get_user_by( 'email', $email );

        // Always return success to prevent email enumeration
        if ( $user ) {
            $key = get_password_reset_key( $user );
            if ( ! is_wp_error( $key ) ) {
                $reset_url = add_query_arg( [
                    'action' => 'rp',
                    'key'    => $key,
                    'login'  => rawurlencode( $user->user_login ),
                ], home_url( '/login/' ) );

                do_action( 'jp_send_password_reset', $user, $reset_url );
            }
        }

        jp_json_response( [
            'message' => __( 'If an account exists with that email, you will receive a reset link shortly.', 'jp-core' ),
        ] );
    }

    // ── AJAX: Reset password ──────────────────────────────────────────────────

    public function ajax_reset_password(): void {
        jp_verify_nonce( 'jp_reset_password' );

        $key      = sanitize_text_field( wp_unslash( $_POST['key'] ?? '' ) );
        $login    = sanitize_user( wp_unslash( $_POST['login'] ?? '' ) );
        $password = $_POST['password'] ?? '';

        if ( strlen( $password ) < 8 ) {
            jp_json_response( __( 'Password must be at least 8 characters.', 'jp-core' ), false, 400 );
        }

        $user = check_password_reset_key( $key, $login );
        if ( is_wp_error( $user ) ) {
            jp_json_response( __( 'This reset link is invalid or has expired.', 'jp-core' ), false, 400 );
        }

        reset_password( $user, $password );

        jp_json_response( [
            'message'  => __( 'Password reset! Please log in with your new password.', 'jp-core' ),
            'redirect' => home_url( '/login/' ),
        ] );
    }

    // ── AJAX: Logout ──────────────────────────────────────────────────────────

    public function ajax_logout(): void {
        jp_verify_nonce( 'jp_logout' );
        wp_logout();
        jp_json_response( [ 'redirect' => home_url( '/' ) ] );
    }

    // ── AJAX: Update password ─────────────────────────────────────────────────

    public function ajax_update_password(): void {
        jp_verify_nonce( 'jp_update_password' );

        if ( ! is_user_logged_in() ) {
            jp_json_response( __( 'Not authenticated.', 'jp-core' ), false, 401 );
        }

        $current  = $_POST['current_password'] ?? '';
        $new_pass = $_POST['new_password'] ?? '';
        $user     = wp_get_current_user();

        if ( ! wp_check_password( $current, $user->user_pass, $user->ID ) ) {
            jp_json_response( __( 'Current password is incorrect.', 'jp-core' ), false, 400 );
        }
        if ( strlen( $new_pass ) < 8 ) {
            jp_json_response( __( 'New password must be at least 8 characters.', 'jp-core' ), false, 400 );
        }

        wp_set_password( $new_pass, $user->ID );

        jp_json_response( [ 'message' => __( 'Password updated successfully.', 'jp-core' ) ] );
    }

    // ── Page gating ───────────────────────────────────────────────────────────

    public function gate_pages(): void {
        // Pages only logged-in users can access
        $auth_required = [
            '/my-account/', '/recruiter/', '/admin-panel/',
        ];

        // Pages only guests should see
        $guest_only = [ '/login/', '/register/' ];

        $current = '/' . ltrim( parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ), '/' );

        foreach ( $auth_required as $path ) {
            if ( str_starts_with( $current, $path ) && ! is_user_logged_in() ) {
                wp_redirect( home_url( '/login/?redirect=' . urlencode( home_url( $current ) ) ) );
                exit;
            }
        }

        foreach ( $guest_only as $path ) {
            if ( str_starts_with( $current, $path ) && is_user_logged_in() ) {
                $role = jp_current_role();
                if ( $role === 'jp_job_seeker' ) {
                    $dest = home_url( '/my-account/' );
                } elseif ( in_array( $role, [ 'jp_recruiter', 'jp_team_manager' ], true ) ) {
                    $dest = home_url( '/recruiter/' );
                } elseif ( in_array( $role, [ 'jp_admin_manager', 'jp_staff', 'administrator' ], true ) ) {
                    $dest = home_url( '/admin-panel/' );
                } else {
                    $dest = home_url( '/' );
                }
                wp_redirect( $dest );
                exit;
            }
        }

        // Role-specific area protection
        if ( str_starts_with( $current, '/recruiter/' ) && is_user_logged_in() ) {
            $allowed = [ 'jp_recruiter', 'jp_team_manager', 'jp_admin_manager', 'administrator' ];
            if ( ! in_array( jp_current_role(), $allowed, true ) ) {
                wp_redirect( home_url( '/my-account/' ) );
                exit;
            }
        }

        if ( str_starts_with( $current, '/admin-panel/' ) && is_user_logged_in() ) {
            $allowed = [ 'jp_admin_manager', 'jp_staff', 'administrator' ];
            if ( ! in_array( jp_current_role(), $allowed, true ) ) {
                wp_redirect( home_url( '/' ) );
                exit;
            }
        }
    }

    // ── WP admin area control ─────────────────────────────────────────────────

    public function redirect_wp_login(): void {
        // If it's a password reset link, let WP handle it
        $action = $_GET['action'] ?? '';
        if ( in_array( $action, [ 'rp', 'resetpass', 'logout' ], true ) ) return;

        wp_redirect( home_url( '/login/' ) );
        exit;
    }

    public function remove_admin_bar_for_non_admin(): void {
        $role = jp_current_role();
        if ( ! in_array( $role, [ 'administrator', 'jp_admin_manager' ], true ) ) {
            show_admin_bar( false );
        }
    }

    public function block_wp_admin(): void {
        if ( defined( 'DOING_AJAX' ) && DOING_AJAX ) return;

        $role    = jp_current_role();
        $allowed = [ 'administrator', 'jp_admin_manager' ];

        if ( is_user_logged_in() && ! in_array( $role, $allowed, true ) ) {
            wp_redirect( home_url( '/' ) );
            exit;
        }
    }
}
