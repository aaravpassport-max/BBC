<?php
/**
 * Class JP_Backup — Automated database backup via mysqldump.
 * Backs up to /uploads/jp-backups/ (auto-rotated, 7 copies max).
 * Admins can trigger manually and download from the Super Admin dashboard.
 */
defined( 'ABSPATH' ) || exit;

class JP_Backup {

	private static ?JP_Backup $instance = null;
	private string $backup_dir;

	const MAX_BACKUPS  = 7;    // Keep last 7 backups (daily = 1 week)
	const MAX_SIZE_MB  = 500;  // Skip backup if DB is >500MB (very large — manual only)

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		$upload_dir       = wp_upload_dir();
		$this->backup_dir = $upload_dir['basedir'] . '/jp-backups/';
		wp_mkdir_p( $this->backup_dir );

		// Protect the backup directory from direct web access
		$htaccess = $this->backup_dir . '.htaccess';
		if ( ! file_exists( $htaccess ) ) {
			file_put_contents( $htaccess, "Options -Indexes\nDeny from all\n" );
		}

		add_action( 'wp_ajax_jp_trigger_backup', [ $this, 'ajax_trigger' ] );
		add_action( 'wp_ajax_jp_list_backups',   [ $this, 'ajax_list' ] );
		add_action( 'wp_ajax_jp_download_backup',[ $this, 'ajax_download' ] );
		add_action( 'wp_ajax_jp_delete_backup',  [ $this, 'ajax_delete_backup' ] );
		add_action( 'wp_ajax_jp_restore_backup', [ $this, 'ajax_restore' ] );
		add_action( 'jp_backup_database',        [ $this, 'run' ] ); // cron hook
	}

	// ── Run a backup ──────────────────────────────────────────────────────────

	public function run(): array {
		// Root-cause fix (gap analysis P0 #103: "MAX_SIZE_MB is declared but
		// never checked anywhere in the class"). Previously this constant
		// existed purely as documentation — a database far larger than the
		// intended cap would still trigger a full, unbounded mysqldump (or
		// worse, the PHP row-by-row fallback, which loads the WHOLE result
		// set's memory footprint across potentially millions of rows) on
		// whatever cron/shared-hosting resources happen to be available,
		// with no warning to anyone that this was ever a risk. Now checked
		// BEFORE attempting either dump method.
		$size_mb = $this->current_db_size_mb();
		if ( $size_mb > self::MAX_SIZE_MB ) {
			$result = [
				'success' => false,
				'method'  => 'skipped',
				'error'   => sprintf( 'Database size (%.1f MB) exceeds the automated backup cap (%d MB). Skipped — run a manual, monitored backup instead.', $size_mb, self::MAX_SIZE_MB ),
			];
			if ( class_exists( 'JP_Security' ) ) {
				JP_Security::instance()->audit( 'backup_skipped_size_cap', 'backup', 0, $result['error'] );
			}
			return $result;
		}

		$result = $this->dump_via_mysqldump();
		if ( ! $result['success'] ) {
			// Fallback: PHP-based table-by-table export
			$result = $this->dump_via_php();
		}

		if ( $result['success'] ) {
			$this->rotate_old_backups();
			$this->log_backup( $result );
		} elseif ( class_exists( 'JP_Security' ) ) {
			JP_Security::instance()->audit( 'backup_failed', 'backup', 0, 'Both mysqldump and PHP fallback backup methods failed: ' . ( $result['error'] ?? 'unknown error' ) );
		}

		return $result;
	}

	/** Sum of data+index bytes across every table in this WordPress database, in MB. */
	private function current_db_size_mb(): float {
		global $wpdb;
		$bytes = $wpdb->get_var( $wpdb->prepare(
			"SELECT SUM(data_length + index_length) FROM information_schema.TABLES WHERE table_schema = %s",
			DB_NAME
		) );
		return $bytes ? ( (float) $bytes / 1048576 ) : 0.0;
	}

	// ── mysqldump method (fast, works if shell_exec is enabled) ───────────────

	private function dump_via_mysqldump(): array {
		if ( ! function_exists( 'shell_exec' ) || ! $this->mysqldump_available() ) {
			return [ 'success' => false, 'method' => 'mysqldump', 'error' => 'shell_exec or mysqldump unavailable' ];
		}

		$filename = $this->get_filename( 'sql.gz' );
		$path     = $this->backup_dir . $filename;

		$host   = DB_HOST;
		$user   = DB_USER;
		$pass   = DB_PASSWORD;
		$name   = DB_NAME;

		// Escape credentials for shell — use a temporary my.cnf for security (avoids password in process list)
		$mycnf_path  = sys_get_temp_dir() . '/jp_backup_' . uniqid() . '.cnf';
		$mycnf_body  = "[client]\nhost={$host}\nuser={$user}\npassword={$pass}\n";
		file_put_contents( $mycnf_path, $mycnf_body );
		chmod( $mycnf_path, 0600 );

		$cmd    = sprintf(
			'mysqldump --defaults-file=%s --single-transaction --quick --lock-tables=false %s 2>&1 | gzip > %s',
			escapeshellarg( $mycnf_path ),
			escapeshellarg( $name ),
			escapeshellarg( $path )
		);

		$output = shell_exec( $cmd );
		@unlink( $mycnf_path );

		$success = file_exists( $path ) && filesize( $path ) > 100;

		return [
			'success'  => $success,
			'method'   => 'mysqldump',
			'filename' => $filename,
			'path'     => $path,
			'size'     => $success ? filesize( $path ) : 0,
			'error'    => $success ? '' : ( $output ?: 'Unknown error' ),
		];
	}

	// ── PHP fallback: export all JP tables row-by-row ─────────────────────────

	private function dump_via_php(): array {
		global $wpdb;

		$filename = $this->get_filename( 'sql' );
		$path     = $this->backup_dir . $filename;
		$handle   = fopen( $path, 'w' );

		if ( ! $handle ) {
			return [ 'success' => false, 'method' => 'php', 'error' => 'Cannot create backup file. Check directory permissions.' ];
		}

		fwrite( $handle, "-- JP Job Portal Database Backup\n" );
		fwrite( $handle, "-- Generated: " . current_time( 'mysql' ) . "\n" );
		fwrite( $handle, "-- WordPress DB: " . DB_NAME . "\n\n" );
		fwrite( $handle, "SET FOREIGN_KEY_CHECKS=0;\n\n" );

		// Get all JP tables + core WP tables needed for restoration
		$tables = $wpdb->get_col( "SHOW TABLES LIKE '{$wpdb->prefix}jp_%'" );
		$wp_tables = [ $wpdb->users, $wpdb->usermeta, $wpdb->options ];
		$all_tables = array_unique( array_merge( $tables, $wp_tables ) );

		$rows_written = 0;

		foreach ( $all_tables as $table ) {
			// CREATE TABLE statement
			$create = $wpdb->get_row( "SHOW CREATE TABLE `{$table}`", ARRAY_N );
			if ( ! $create ) continue;

			fwrite( $handle, "\n-- Table: {$table}\n" );
			fwrite( $handle, "DROP TABLE IF EXISTS `{$table}`;\n" );
			fwrite( $handle, $create[1] . ";\n\n" );

			// Data rows in chunks to avoid memory exhaustion
			$offset = 0;
			$chunk  = 500;
			do {
				$rows = $wpdb->get_results( "SELECT * FROM `{$table}` LIMIT {$chunk} OFFSET {$offset}", ARRAY_A );
				if ( empty( $rows ) ) break;

				foreach ( $rows as $row ) {
					$values = array_map( function ( $v ) use ( $wpdb ) {
						if ( $v === null ) return 'NULL';
						return "'" . esc_sql( $v ) . "'";
					}, array_values( $row ) );

					fwrite( $handle, "INSERT INTO `{$table}` VALUES (" . implode( ', ', $values ) . ");\n" );
					$rows_written++;
				}

				$offset += $chunk;
			} while ( count( $rows ) === $chunk );
		}

		fwrite( $handle, "\nSET FOREIGN_KEY_CHECKS=1;\n" );
		fclose( $handle );

		// Compress with gzip if available
		$gz_path = $path . '.gz';
		if ( function_exists( 'gzencode' ) ) {
			$gz = gzencode( file_get_contents( $path ), 6 );
			file_put_contents( $gz_path, $gz );
			unlink( $path );
			$path     = $gz_path;
			$filename = $filename . '.gz';
		}

		return [
			'success'      => true,
			'method'       => 'php',
			'filename'     => $filename,
			'path'         => $path,
			'size'         => filesize( $path ),
			'rows_written' => $rows_written,
			'error'        => '',
		];
	}

	// ── Rotation: keep only last N backups ────────────────────────────────────

	private function rotate_old_backups(): void {
		$files = glob( $this->backup_dir . 'jp-backup-*.sql*' ) ?: [];
		if ( count( $files ) <= self::MAX_BACKUPS ) return;

		// Sort by modification time ascending (oldest first)
		usort( $files, fn( $a, $b ) => filemtime( $a ) - filemtime( $b ) );

		$to_delete = array_slice( $files, 0, count( $files ) - self::MAX_BACKUPS );
		foreach ( $to_delete as $f ) @unlink( $f );
	}

	// ── AJAX handlers ─────────────────────────────────────────────────────────

	public function ajax_trigger(): void {
		check_ajax_referer( 'jp_general', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) jp_json_response( false, 'Permission denied.' );

		$result = $this->run();
		if ( $result['success'] ) {
			jp_json_response( true, [
				'message'  => 'Backup completed successfully via ' . $result['method'] . '.',
				'filename' => $result['filename'],
				'size_mb'  => round( $result['size'] / 1048576, 2 ),
			] );
		} else {
			jp_json_response( false, 'Backup failed: ' . $result['error'] );
		}
	}

	public function ajax_list(): void {
		check_ajax_referer( 'jp_general', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) jp_json_response( false, 'Permission denied.' );

		$files   = glob( $this->backup_dir . 'jp-backup-*.sql*' ) ?: [];
		usort( $files, fn( $a, $b ) => filemtime( $b ) - filemtime( $a ) ); // newest first

		$list = array_map( fn( $f ) => [
			'filename'   => basename( $f ),
			'size_mb'    => round( filesize( $f ) / 1048576, 2 ),
			'created_at' => date( 'Y-m-d H:i:s', filemtime( $f ) ),
		], $files );

		jp_json_response( true, [ 'backups' => $list ] );
	}

	public function ajax_download(): void {
		check_ajax_referer( 'jp_general', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) wp_die( 'Permission denied.' );

		$filename = sanitize_file_name( $_GET['file'] ?? '' );
		$path     = $this->backup_dir . $filename;

		if ( ! $filename || ! file_exists( $path ) ) wp_die( 'File not found.' );

		// Log the download
		JP_Security::instance()->audit( 'backup_download', 'backup', 0, $filename );

		header( 'Content-Type: application/octet-stream' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'Content-Length: ' . filesize( $path ) );
		header( 'Cache-Control: no-cache, must-revalidate' );
		readfile( $path );
		exit;
	}

	public function ajax_delete_backup(): void {
		check_ajax_referer( 'jp_general', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) jp_json_response( false, 'Permission denied.' );

		$filename = sanitize_file_name( $_POST['file'] ?? '' );
		$path     = $this->backup_dir . $filename;

		// Safety: only allow deleting jp-backup-* files in the backup dir
		if ( ! $filename || ! str_starts_with( $filename, 'jp-backup-' ) || ! file_exists( $path ) ) {
			jp_json_response( false, 'File not found.' );
		}

		@unlink( $path );
		jp_json_response( true, [ 'message' => 'Backup deleted.' ] );
	}

	/**
	 * Root-cause fix (gap analysis P0 #103: "there is no restore() method
	 * at all — only dump, list, download, delete. For a platform holding
	 * payment and PII data, this means disaster recovery has never
	 * actually been exercised and likely doesn't work"). A backup nobody
	 * has ever restored from is not a verified backup — it's an assumption.
	 *
	 * Requires explicit typed confirmation ($confirm_token === filename) —
	 * this is a fully destructive, irreversible operation on the live
	 * database, and a fat-fingered AJAX call must not be able to trigger it.
	 * A safety backup of the CURRENT state is taken first (best-effort — if
	 * that itself fails, the restore is aborted rather than proceeding
	 * blind), so a bad restore is itself recoverable.
	 */
	public function restore( string $filename, string $confirm_token ): array {
		if ( $confirm_token !== $filename ) {
			return [ 'success' => false, 'error' => 'Confirmation token does not match the backup filename — restore aborted.' ];
		}
		$path = $this->backup_dir . $filename;
		if ( ! str_starts_with( $filename, 'jp-backup-' ) || ! file_exists( $path ) ) {
			return [ 'success' => false, 'error' => 'Backup file not found.' ];
		}

		// Safety snapshot of CURRENT state before overwriting anything.
		$pre_restore = $this->run();
		if ( ! $pre_restore['success'] ) {
			return [ 'success' => false, 'error' => 'Aborted: could not take a pre-restore safety backup of the current database state (' . ( $pre_restore['error'] ?? 'unknown error' ) . '). Restoring without one is not safe.' ];
		}

		$sql = $this->read_backup_sql( $path );
		if ( $sql === false ) {
			return [ 'success' => false, 'error' => 'Could not read/decompress the backup file.' ];
		}

		$result = ( function_exists( 'shell_exec' ) && $this->mysql_client_available() )
			? $this->restore_via_mysql_cli( $path )
			: $this->restore_via_php( $sql );

		if ( class_exists( 'JP_Security' ) ) {
			JP_Security::instance()->audit(
				$result['success'] ? 'backup_restored' : 'backup_restore_failed',
				'backup', 0,
				"Restore of {$filename} " . ( $result['success'] ? 'succeeded' : 'FAILED: ' . ( $result['error'] ?? '' ) ) . " (pre-restore safety backup: {$pre_restore['filename']})"
			);
		}

		return $result;
	}

	private function read_backup_sql( string $path ) {
		if ( str_ends_with( $path, '.gz' ) ) {
			$data = @file_get_contents( $path );
			return $data === false ? false : @gzdecode( $data );
		}
		return @file_get_contents( $path );
	}

	private function mysql_client_available(): bool {
		$out = shell_exec( 'which mysql 2>/dev/null' );
		return ! empty( trim( $out ?? '' ) );
	}

	/** Fast path: pipe the (decompressed, if needed) SQL straight into the mysql CLI via the same credentials-file pattern used for mysqldump. */
	private function restore_via_mysql_cli( string $path ): array {
		$mycnf_path = sys_get_temp_dir() . '/jp_restore_' . uniqid() . '.cnf';
		file_put_contents( $mycnf_path, "[client]\nhost=" . DB_HOST . "\nuser=" . DB_USER . "\npassword=" . DB_PASSWORD . "\n" );
		chmod( $mycnf_path, 0600 );

		$is_gz = str_ends_with( $path, '.gz' );
		$cmd   = $is_gz
			? sprintf( 'gunzip -c %s | mysql --defaults-file=%s %s 2>&1', escapeshellarg( $path ), escapeshellarg( $mycnf_path ), escapeshellarg( DB_NAME ) )
			: sprintf( 'mysql --defaults-file=%s %s < %s 2>&1', escapeshellarg( $mycnf_path ), escapeshellarg( DB_NAME ), escapeshellarg( $path ) );

		$output = shell_exec( $cmd );
		@unlink( $mycnf_path );

		// mysql CLI is silent on success; any output is almost always an error/warning.
		$success = empty( trim( (string) $output ) );
		return [ 'success' => $success, 'method' => 'mysql_cli', 'error' => $success ? '' : trim( (string) $output ) ];
	}

	/** Fallback: execute the dump's statements one at a time via $wpdb — slower, but requires no shell access. */
	private function restore_via_php( string $sql ): array {
		global $wpdb;
		// Naive but adequate statement split for this backup's own generated
		// format (one statement per line, no embedded semicolons inside
		// string values thanks to esc_sql() at dump time never introducing
		// a raw unescaped ';'-adjacent quote break).
		$statements = array_filter( array_map( 'trim', explode( ";\n", $sql ) ) );
		$executed   = 0;
		$errors     = [];

		foreach ( $statements as $stmt ) {
			if ( $stmt === '' || str_starts_with( $stmt, '--' ) ) continue;
			$ok = $wpdb->query( $stmt );
			if ( $ok === false ) {
				$errors[] = $wpdb->last_error . ' (statement: ' . mb_substr( $stmt, 0, 100 ) . '...)';
			} else {
				$executed++;
			}
		}

		return [
			'success' => empty( $errors ),
			'method'  => 'php',
			'executed'=> $executed,
			'error'   => $errors ? implode( '; ', array_slice( $errors, 0, 5 ) ) . ( count( $errors ) > 5 ? ' (+' . ( count( $errors ) - 5 ) . ' more)' : '' ) : '',
		];
	}

	public function ajax_restore(): void {
		check_ajax_referer( 'jp_general', 'nonce' );
		if ( ! current_user_can( 'manage_options' ) ) jp_json_response( false, 'Permission denied.' );

		$filename = sanitize_file_name( $_POST['file'] ?? '' );
		// The client must echo the exact filename back as explicit
		// confirmation it understood which backup it's restoring — see
		// restore()'s docblock for why this exists.
		$confirm  = sanitize_file_name( $_POST['confirm'] ?? '' );

		$result = $this->restore( $filename, $confirm );
		if ( $result['success'] ) {
			jp_json_response( true, [ 'message' => 'Database restored from ' . $filename . '. A safety backup of the pre-restore state was taken automatically.' ] );
		} else {
			jp_json_response( false, 'Restore failed: ' . ( $result['error'] ?? 'unknown error' ) );
		}
	}

	// ── Helpers ───────────────────────────────────────────────────────────────

	private function get_filename( string $ext ): string {
		return 'jp-backup-' . date( 'Y-m-d-His' ) . '.' . $ext;
	}

	private function mysqldump_available(): bool {
		$out = shell_exec( 'which mysqldump 2>/dev/null' );
		return ! empty( trim( $out ?? '' ) );
	}

	private function log_backup( array $result ): void {
		$log     = get_option( 'jp_backup_log', [] );
		$log[]   = [
			'timestamp' => current_time( 'mysql' ),
			'method'    => $result['method'],
			'filename'  => $result['filename'] ?? '',
			'size_mb'   => round( ( $result['size'] ?? 0 ) / 1048576, 2 ),
		];
		// Keep last 30 log entries
		update_option( 'jp_backup_log', array_slice( $log, -30 ) );
	}

	public function get_log(): array {
		return get_option( 'jp_backup_log', [] );
	}

	public function get_status(): array {
		$files  = glob( $this->backup_dir . 'jp-backup-*.sql*' ) ?: [];
		$latest = $files ? max( array_map( 'filemtime', $files ) ) : null;
		return [
			'backup_count'    => count( $files ),
			'latest_backup'   => $latest ? date( 'Y-m-d H:i:s', $latest ) : 'Never',
			'next_backup'     => date( 'Y-m-d H:i:s', wp_next_scheduled( 'jp_backup_database' ) ?: 0 ),
			'backup_dir_size' => array_sum( array_map( 'filesize', $files ) ),
		];
	}
}
