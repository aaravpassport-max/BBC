<?php
/**
 * Class JP_Messaging — Thread-based messaging between recruiters and candidates.
 * Real-time via polling (/messages/poll). Unread badge. File attachment support.
 */
defined( 'ABSPATH' ) || exit;

class JP_Messaging {

	private static ?JP_Messaging $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		$aj = 'wp_ajax_';
		add_action( $aj.'jp_send_message',     [ $this, 'ajax_send' ] );
		add_action( $aj.'jp_get_messages',     [ $this, 'ajax_get' ] );
		add_action( $aj.'jp_mark_read',        [ $this, 'ajax_mark_read' ] );
		add_action( $aj.'jp_get_unread_count', [ $this, 'ajax_unread_count' ] );
		add_action( 'rest_api_init',           [ $this, 'register_routes' ] );
	}

	// ── Send a message ────────────────────────────────────────────────────────

	public function ajax_send(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');

		$user_id   = get_current_user_id();
		$thread_id = absint($_POST['thread_id']??0);
		$body      = sanitize_textarea_field($_POST['body']??'');
		$job_id    = absint($_POST['job_id']??0);
		$recipient = absint($_POST['recipient_id']??0);

		if (!$body) jp_json_response(false,'Message cannot be empty.');

		global $wpdb;

		// Get or create thread
		if (!$thread_id && $recipient && $job_id) {
			$thread_id = $this->get_or_create_thread($user_id,$recipient,$job_id);
		}

		if (!$thread_id) jp_json_response(false,'Invalid thread.');

		// Verify thread access
		$thread = $this->get_thread($thread_id);
		if (!$thread) jp_json_response(false,'Thread not found.');
		if (!in_array($user_id,[(int)$thread->recruiter_id,(int)$thread->candidate_id],true)) {
			jp_json_response(false,'Access denied.');
		}

		// Rate limit: 30 messages per hour per user
		$recent = (int)$wpdb->get_var($wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}jp_messages WHERE sender_id=%d AND created_at>=DATE_SUB(NOW(),INTERVAL 1 HOUR)",
			$user_id
		));
		if ($recent >= 30) jp_json_response(false,'Message rate limit reached. Please wait.');

		// Root-cause fix (batch 17): unchecked $wpdb->insert() — same
		// ghost-success shape found repeatedly across this codebase
		// (batches 8/9/13/14/15/16). A failed write here still fell through
		// to the thread-counter update, notification, and hook below, then
		// told the sender "Sent." with a stale/0 msg_id, while the
		// recipient would never see the message — a silent one-way failure
		// in the platform's core recruiter-candidate communication channel.
		$inserted = $wpdb->insert($wpdb->prefix.'jp_messages',[
			'thread_id'  => $thread_id,
			'sender_id'  => $user_id,
			'body'       => $body,
			'is_read'    => 0,
			'created_at' => current_time('mysql'),
		],['%d','%d','%s','%d','%s']);
		if ( false === $inserted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_messages insert failed: ' . $wpdb->last_error ), 'JP_Messaging::ajax_send thread_id=' . $thread_id . ' sender_id=' . $user_id );
			}
			jp_json_response( false, 'Could not send this message. Please try again.' );
			return;
		}

		$msg_id = $wpdb->insert_id;

		// Update thread: increment unread_count and refresh last_message/last_at atomically.
		// A single raw query handles the increment correctly (wpdb->update cannot do column += 1).
		$wpdb->query($wpdb->prepare(
			"UPDATE {$wpdb->prefix}jp_message_threads SET unread_count=unread_count+1, last_message=%s, last_at=%s WHERE id=%d",
			mb_substr($body,0,100), current_time('mysql'), $thread_id
		));

		// Notify recipient
		$recipient_id = (int)$thread->recruiter_id === $user_id ? (int)$thread->candidate_id : (int)$thread->recruiter_id;
		// Root-cause fix: this used to link to /my-account/?section=messages
		// — a pre-SPA-rewrite jp-theme path no router.tsx route matches, so
		// clicking it (or the emailed link built from the same value below)
		// could only 404. MessagesPage is mounted at two different base
		// paths depending on role (/dashboard/messages for candidates,
		// /recruiter/messages for recruiters), so the link must be
		// role-aware: the recipient is the recruiter iff they match
		// thread->recruiter_id (same comparison already used above to
		// derive $recipient_id itself). ?thread= lets MessagesPage deep-link
		// straight to this conversation instead of just opening the inbox.
		$recipient_is_recruiter = (int)$thread->recruiter_id === $recipient_id;
		$message_url = home_url(($recipient_is_recruiter ? '/recruiter/messages' : '/dashboard/messages').'?thread='.$thread_id);
		JP_Notifications::instance()->create([
			'user_id' => $recipient_id,
			'type'    => 'new_message',
			'title'   => 'New message from '.get_userdata($user_id)->display_name,
			'body'    => mb_substr($body,0,80),
			'url'     => $message_url,
		]);
		do_action('jp_new_message',['sender_id'=>$user_id,'recipient_id'=>$recipient_id,'body'=>$body,'url'=>$message_url]);

		jp_json_response(true,['message'=>'Sent.','msg_id'=>$msg_id]);
	}

	// ── Get messages for a thread ─────────────────────────────────────────────

	public function ajax_get(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');

		$user_id   = get_current_user_id();
		$thread_id = absint($_POST['thread_id']??$_GET['thread_id']??0);

		global $wpdb;
		$thread = $this->get_thread($thread_id);
		if (!$thread) jp_json_response(false,'Thread not found.');
		if (!in_array($user_id,[(int)$thread->recruiter_id,(int)$thread->candidate_id],true)) {
			jp_json_response(false,'Access denied.');
		}

		$since = sanitize_text_field($_POST['since']??$_GET['since']??'');
		$sql   = "SELECT m.*,u.display_name FROM {$wpdb->prefix}jp_messages m LEFT JOIN {$wpdb->users} u ON u.ID=m.sender_id WHERE m.thread_id=%d";
		$params= [$thread_id];
		if ($since) { $sql.=' AND m.created_at>%s'; $params[]=$since; }
		$sql.=' ORDER BY m.created_at ASC LIMIT 100';
		$msgs = $wpdb->get_results($wpdb->prepare($sql,...$params))?:[];

		jp_json_response(true,$msgs);
	}

	// ── Mark thread as read ───────────────────────────────────────────────────

	public function ajax_mark_read(): void {
		jp_verify_nonce('jp_general');
		$uid       = get_current_user_id();
		$thread_id = absint($_POST['thread_id']??0);
		global $wpdb;
		$wpdb->query($wpdb->prepare(
			"UPDATE {$wpdb->prefix}jp_messages SET is_read=1 WHERE thread_id=%d AND sender_id!=%d AND is_read=0",
			$thread_id, $uid
		));
		// Root-cause fix (batch 17): unchecked $wpdb->update(). Lower blast
		// radius than the send/thread-create fixes above (the individual
		// messages ARE correctly marked read by the raw query just above
		// regardless), but a failed reset here previously still reported
		// {ok:true} while the thread's unread badge count stayed stuck at
		// its old value — an already-read thread would keep showing as
		// unread in the inbox list.
		$updated = $wpdb->update($wpdb->prefix.'jp_message_threads',['unread_count'=>0],['id'=>$thread_id],['%d'],['%d']);
		if ( false === $updated ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_message_threads unread reset failed: ' . $wpdb->last_error ), 'JP_Messaging::ajax_mark_read thread_id=' . $thread_id );
			}
			jp_json_response( false, 'Could not mark this thread as read.' );
			return;
		}
		jp_json_response(true,['ok'=>true]);
	}

	// ── Unread count ──────────────────────────────────────────────────────────

	public function ajax_unread_count(): void {
		jp_verify_nonce('jp_general');
		$uid   = get_current_user_id();
		$count = $this->get_unread_count($uid);
		wp_send_json_success(['count'=>$count]);
	}

	public function get_unread_count( int $user_id ): int {
		global $wpdb;
		return (int)$wpdb->get_var($wpdb->prepare(
			"SELECT SUM(unread_count) FROM {$wpdb->prefix}jp_message_threads WHERE (recruiter_id=%d OR candidate_id=%d)",
			$user_id,$user_id
		));
	}

	// ── Thread management ─────────────────────────────────────────────────────

	public function get_or_create_thread( int $user_id, int $recipient_id, int $job_id = 0 ): int {
		global $wpdb;
		$current_role = jp_current_role();
		$is_recruiter = in_array($current_role,['jp_recruiter','jp_team_manager','jp_admin_manager','administrator'],true);

		$rec_id  = $is_recruiter ? $user_id : $recipient_id;
		$cand_id = $is_recruiter ? $recipient_id : $user_id;

		// Check existing thread
		$existing = $wpdb->get_var($wpdb->prepare(
			"SELECT id FROM {$wpdb->prefix}jp_message_threads WHERE recruiter_id=%d AND candidate_id=%d AND job_id=%d LIMIT 1",
			$rec_id,$cand_id,$job_id
		));
		if ($existing) return (int)$existing;

		// Root-cause fix (batch 17): unchecked $wpdb->insert(). On failure
		// $wpdb->insert_id is left at whatever it was last set to — 0 on a
		// fresh request, or a STALE id from an earlier successful insert
		// elsewhere in the same request lifecycle — either of which this
		// method would previously have returned as if it were a real new
		// thread id. Callers (ajax_send() above) treat 0 as "no thread"
		// and correctly bail with an error, but a stale nonzero id would
		// have silently attached the new message to the WRONG thread.
		$inserted = $wpdb->insert($wpdb->prefix.'jp_message_threads',[
			'recruiter_id'  => $rec_id,
			'candidate_id'  => $cand_id,
			'job_id'        => $job_id,
			'last_message'  => '',
			'unread_count'  => 0,
			'last_at'       => current_time('mysql'),
			'created_at'    => current_time('mysql'),
		],['%d','%d','%d','%s','%d','%s','%s']);
		if ( false === $inserted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_message_threads insert failed: ' . $wpdb->last_error ), 'JP_Messaging::get_or_create_thread recruiter_id=' . $rec_id . ' candidate_id=' . $cand_id );
			}
			return 0;
		}
		return (int)$wpdb->insert_id;
	}

	public function get_thread( int $thread_id ): ?object {
		global $wpdb;
		return $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_message_threads WHERE id=%d",$thread_id));
	}

	// ── Canned responses (batch 25) ─────────────────────────────────────────────
	// New jp_canned_responses table (class-jp-activator.php) — lets a
	// recruiter save a reusable reply template instead of retyping the same
	// message to every candidate. REST-only (no legacy wp_ajax_ wrapper):
	// this is a brand-new feature with no jp-theme call site to preserve
	// compatibility with, consistent with the plugin's stated direction of
	// building new surface area SPA/REST-first. Scoped to the owning
	// recruiter — never shared across recruiters/team — and capped at 50
	// templates per recruiter so this can't become an unbounded-growth
	// vector for one account.

	public function do_list_canned( int $user_id ): array {
		global $wpdb;
		return $wpdb->get_results( $wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_canned_responses WHERE user_id=%d ORDER BY created_at DESC",
			$user_id
		) ) ?: [];
	}

	/**
	 * @return array|\WP_Error
	 */
	public function do_save_canned( int $user_id, string $title, string $body ) {
		$title = trim( sanitize_text_field( $title ) );
		$body  = trim( sanitize_textarea_field( $body ) );
		if ( '' === $title ) return new \WP_Error( 'jp_invalid', 'Give this template a name.', [ 'status' => 400 ] );
		if ( '' === $body )  return new \WP_Error( 'jp_invalid', 'Template text cannot be empty.', [ 'status' => 400 ] );
		if ( mb_strlen( $title ) > 150 ) return new \WP_Error( 'jp_invalid', 'Template name is too long.', [ 'status' => 400 ] );

		global $wpdb;
		$existing = (int) $wpdb->get_var( $wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->prefix}jp_canned_responses WHERE user_id=%d", $user_id
		) );
		if ( $existing >= 50 ) {
			return new \WP_Error( 'jp_limit', 'You have reached the 50 saved-template limit. Delete one before adding another.', [ 'status' => 400 ] );
		}

		$inserted = $wpdb->insert( $wpdb->prefix . 'jp_canned_responses', [
			'user_id'    => $user_id,
			'title'      => $title,
			'body'       => $body,
			'created_at' => current_time( 'mysql' ),
		], [ '%d', '%s', '%s', '%s' ] );

		if ( false === $inserted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_canned_responses insert failed: ' . $wpdb->last_error ), 'JP_Messaging::do_save_canned user_id=' . $user_id );
			}
			return new \WP_Error( 'jp_db_error', 'Could not save this template. Please try again.', [ 'status' => 500 ] );
		}

		return [ 'message' => 'Template saved.', 'id' => (int) $wpdb->insert_id ];
	}

	/**
	 * @return array|\WP_Error
	 */
	public function do_delete_canned( int $id, int $user_id ) {
		global $wpdb;
		$deleted = $wpdb->delete(
			$wpdb->prefix . 'jp_canned_responses',
			[ 'id' => $id, 'user_id' => $user_id ],
			[ '%d', '%d' ]
		);
		// $wpdb->delete() returns the number of rows affected (int, possibly
		// 0) on success, or false on a query error — 0 means "nothing
		// matched" (already deleted, or belongs to someone else), which is
		// reported the same as a real not-found rather than a server error.
		if ( false === $deleted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_canned_responses delete failed: ' . $wpdb->last_error ), 'JP_Messaging::do_delete_canned id=' . $id . ' user_id=' . $user_id );
			}
			return new \WP_Error( 'jp_db_error', 'Could not delete this template. Please try again.', [ 'status' => 500 ] );
		}
		if ( 0 === $deleted ) {
			return new \WP_Error( 'jp_not_found', 'Template not found.', [ 'status' => 404 ] );
		}
		return [ 'message' => 'Template deleted.' ];
	}

	// ── REST: polling endpoint ────────────────────────────────────────────────

	public function register_routes(): void {
		register_rest_route(JP_Api::namespace_str(),'/messages/poll',[ // Batch 31: was hardcoded 'jp/v1'
			'methods'             => 'GET',
			'callback'            => function($r) {
				if (!is_user_logged_in()) return new WP_Error('unauthorized','Not authenticated',['status'=>401]);
				$thread_id = absint($r->get_param('thread_id'));
				$since     = sanitize_text_field($r->get_param('since')??'');
				$uid       = get_current_user_id();
				global $wpdb;
				$thread    = $this->get_thread($thread_id);
				if (!$thread||!in_array($uid,[(int)$thread->recruiter_id,(int)$thread->candidate_id],true)) {
					return new WP_Error('forbidden','Access denied',['status'=>403]);
				}
				$sql = "SELECT m.*,u.display_name FROM {$wpdb->prefix}jp_messages m LEFT JOIN {$wpdb->users} u ON u.ID=m.sender_id WHERE m.thread_id=%d";
				$p   = [$thread_id];
				if ($since){ $sql.=' AND m.created_at>%s'; $p[]=$since; }
				$sql.=' ORDER BY m.created_at ASC LIMIT 50';
				return rest_ensure_response($wpdb->get_results($wpdb->prepare($sql,...$p))?:[]);
			},
			'permission_callback' => '__return_true',
		]);
	}
}
