<?php
/**
 * Class JP_Alerts — Job Alert System
 * Modes: instant (on new job post), daily digest, weekly digest.
 * Rule-based matching on keywords, location, job_type, salary, work_mode.
 * WP-Cron dispatch every 15 min (instant), daily at 8am, weekly on Monday.
 */
defined( 'ABSPATH' ) || exit;

class JP_Alerts {

	private static ?JP_Alerts $instance = null;

	public static function instance(): self {
		if ( null === self::$instance ) self::$instance = new self();
		return self::$instance;
	}

	private function __construct() {
		add_action( 'wp_ajax_jp_save_alert',    [ $this, 'ajax_save' ] );
		add_action( 'wp_ajax_jp_delete_alert',  [ $this, 'ajax_delete' ] );
		add_action( 'wp_ajax_jp_toggle_alert',  [ $this, 'ajax_toggle' ] );

		// Hook new job posts to trigger instant alerts
		add_action( 'jp_job_published', [ $this, 'on_job_published' ] );

		// Scheduled digest dispatch (schedules registered in JP_Cron)
		add_action( 'jp_dispatch_daily_alerts',  [ $this, 'dispatch_daily' ] );
		add_action( 'jp_dispatch_weekly_alerts', [ $this, 'dispatch_weekly' ] );

		// Phase-2 remediation: these two used to be called directly, inline,
		// inside the synchronous cron loops below — meaning a large alert
		// subscriber base could time out a single WP-Cron request partway
		// through sending, with no retry for whichever sends never
		// happened (gap analysis P1: "no queue system anywhere"). They are
		// now background-job-queue consumers (see class-jp-queue.php) —
		// on_job_published()/dispatch_digest() enqueue one job per
		// alert+recipient instead of sending inline.
		add_action( 'jp_queue_alert_instant_email', [ $this, 'queue_send_alert_email' ] );
		add_action( 'jp_queue_alert_digest_email',  [ $this, 'queue_send_digest_email' ] );
	}

	// ── AJAX: Save alert ──────────────────────────────────────────────────────

	/**
	 * Root-cause fix (batch 15): this previously called $wpdb->insert()
	 * without checking its return value, then unconditionally reported
	 * "Alert created!" back to the caller (and, via create_alert()'s
	 * bridge_ajax() wrapper in class-jp-api.php, straight through the
	 * REST API to AlertsPage.tsx) — the same ghost-success shape already
	 * found and fixed in batches 8 (payments), 9 (subscriptions), 13
	 * (team reassignment), and 14 (audit log). A failed insert left the
	 * user believing an alert existed (id defaulting to whatever
	 * $wpdb->insert_id was last set to — stale or 0, not this row's) when
	 * none was ever written, meaning they would silently never receive
	 * the job-match emails they thought they'd signed up for.
	 *
	 * Root-cause fix (batch 22): jp_alerts.experience has existed since
	 * table creation but was never in this $data array, so it was always
	 * written as its column default (0) regardless of what a candidate
	 * saved from JobsPage.tsx's "Min. experience" filter (added batch 19)
	 * — every saved search/alert silently dropped that criterion. Clamped
	 * to 0-60 to match the UI's plausible range; job_matches_alert() below
	 * now actually filters on it using the same semantics as
	 * class-jp-search.php's 'exp' param (candidate's years >= job's
	 * experience_min).
	 *
	 * Batch 27: skills_json is now wired up too, sourced from the new
	 * dedicated skills filter on JobsPage.tsx (see class-jp-search.php's
	 * 'skills' AND-match arg) — the gap noted above (no real writer existed)
	 * is closed now that the filter UI exists.
	 */
	public function ajax_save(): void {
		jp_verify_nonce('jp_general');
		if (!is_user_logged_in()) jp_json_response(false,'Not authenticated.');
		$uid  = get_current_user_id();
		$data = [
			'user_id'   => $uid,
			'name'      => sanitize_text_field($_POST['name']??''),
			'keywords'  => sanitize_text_field($_POST['keywords']??''),
			'location'  => sanitize_text_field($_POST['location']??''),
			'job_type'  => sanitize_key($_POST['job_type']??''),
			'work_mode' => sanitize_key($_POST['work_mode']??''),
			'salary_min'=> absint($_POST['salary_min']??0),
			'experience'=> min(60, absint($_POST['experience']??0)),
			// Batch 27: comma-separated skills list, same AND-match shape as
			// class-jp-search.php's 'skills' filter — see job_matches_alert().
			'skills_json'=> wp_json_encode( array_values( array_filter( array_map(
				'sanitize_text_field',
				explode( ',', (string) ( $_POST['skills'] ?? '' ) )
			) ) ) ),
			'frequency' => in_array($_POST['frequency']??'',['instant','daily','weekly'],true) ? $_POST['frequency'] : 'daily',
			'is_active' => 1,
			'created_at'=> current_time('mysql'),
		];
		global $wpdb;
		$inserted = $wpdb->insert($wpdb->prefix.'jp_alerts',$data,['%d','%s','%s','%s','%s','%s','%d','%d','%s','%s','%d','%s']);
		if ( false === $inserted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_alerts insert failed: ' . $wpdb->last_error ), 'JP_Alerts::ajax_save user_id=' . $uid );
			}
			jp_json_response( false, 'Could not create this alert. Please try again or contact support.' );
			return;
		}
		jp_json_response(true,['message'=>'Alert created! You\'ll be notified when matching jobs are posted.','id'=>$wpdb->insert_id]);
	}

	public function ajax_delete(): void {
		jp_verify_nonce('jp_general');
		$id  = absint($_POST['alert_id']??0);
		$uid = get_current_user_id();
		global $wpdb;
		// Ghost-success fix, same class as ajax_save() below: this
		// unconditionally returned "Alert deleted." even if the delete
		// never ran (lock timeout, DB unavailable) — the alert would still
		// exist and keep firing while the user believed they'd turned it off.
		$deleted = $wpdb->delete($wpdb->prefix.'jp_alerts',['id'=>$id,'user_id'=>$uid],['%d','%d']);
		if ( false === $deleted ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_alerts delete failed: ' . $wpdb->last_error ), 'JP_Alerts::ajax_delete alert_id=' . $id . ' user_id=' . $uid );
			}
			jp_json_response( false, 'Could not delete this alert. Please try again.' );
			return;
		}
		jp_json_response(true,['message'=>'Alert deleted.']);
	}

	/**
	 * Root-cause fix (batch 15): same ghost-success shape as ajax_save()
	 * above — $wpdb->update()'s return value was never checked, so a
	 * failed toggle (e.g. a lock timeout) still told the user their alert
	 * was activated/paused while is_active in the DB never changed,
	 * leaving the alert silently stuck in whatever state it was already
	 * in (and, if that state was "paused", the user believing they'd
	 * re-enabled notifications that were never actually resumed).
	 */
	public function ajax_toggle(): void {
		jp_verify_nonce('jp_general');
		$id     = absint($_POST['alert_id']??0);
		$uid    = get_current_user_id();
		global $wpdb;
		$alert  = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_alerts WHERE id=%d AND user_id=%d",$id,$uid));
		if (!$alert) { jp_json_response(false,'Alert not found.'); return; }
		$new    = $alert->is_active ? 0 : 1;
		$updated = $wpdb->update($wpdb->prefix.'jp_alerts',['is_active'=>$new],['id'=>$id],['%d'],['%d']);
		if ( false === $updated ) {
			if ( class_exists( 'JP_ErrorLog' ) ) {
				JP_ErrorLog::instance()->log_exception( new \Exception( 'jp_alerts update failed: ' . $wpdb->last_error ), 'JP_Alerts::ajax_toggle alert_id=' . $id );
			}
			jp_json_response( false, 'Could not update this alert. Please try again or contact support.' );
			return;
		}
		jp_json_response(true,['message'=>$new?'Alert activated.':'Alert paused.','is_active'=>$new]);
	}

	// ── Match a job against all active alerts ─────────────────────────────────

	public function on_job_published( int $job_id ): void {
		global $wpdb;
		$job     = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_jobs WHERE id=%d",$job_id));
		if (!$job) return;

		$alerts  = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}jp_alerts WHERE is_active=1 AND frequency='instant'");
		foreach ($alerts as $alert) {
			if ($this->job_matches_alert($job,$alert)) {
				JP_Queue::instance()->enqueue( 'jp_queue_alert_instant_email', [ (int) $alert->id, (int) $job->id ] );
			}
		}
	}

	// ── Digest dispatchers (called by cron) ───────────────────────────────────

	public function dispatch_daily(): void {
		$this->dispatch_digest('daily',1);
	}

	public function dispatch_weekly(): void {
		$this->dispatch_digest('weekly',7);
	}

	private function dispatch_digest( string $frequency, int $days_back ): void {
		global $wpdb;
		$alerts  = $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}jp_alerts WHERE is_active=1 AND frequency=%s",$frequency));
		$jobs    = $wpdb->get_results($wpdb->prepare(
			"SELECT * FROM {$wpdb->prefix}jp_jobs WHERE status='active' AND created_at>=DATE_SUB(NOW(),INTERVAL %d DAY)",
			$days_back
		));
		if (empty($jobs)) return;

		foreach ($alerts as $alert) {
			$matched = array_filter($jobs, fn($j) => $this->job_matches_alert($j,$alert));
			if (!empty($matched)) {
				$job_ids = array_map( fn( $j ) => (int) $j->id, array_values( $matched ) );
				JP_Queue::instance()->enqueue( 'jp_queue_alert_digest_email', [ (int) $alert->id, $job_ids, $frequency ] );
			}
		}
	}

	// ── Match logic ───────────────────────────────────────────────────────────

	public function job_matches_alert( object $job, object $alert ): bool {
		// Keywords — check title, description, skills
		if ($alert->keywords) {
			$kws    = array_map('trim',explode(',',$alert->keywords));
			$haystack = strtolower($job->title.' '.($job->description??'').' '.($job->skills_json??''));
			$matched  = false;
			foreach ($kws as $kw) { if ($kw && str_contains($haystack,strtolower($kw))) { $matched=true; break; } }
			if (!$matched) return false;
		}

		// Location
		if ($alert->location && $job->work_mode !== 'remote') {
			$loc = strtolower($alert->location);
			if (!str_contains(strtolower($job->location_city??''),$loc) && !str_contains(strtolower($job->location_state??''),$loc)) {
				return false;
			}
		}

		// Job type
		if ($alert->job_type && $job->job_type !== $alert->job_type) return false;

		// Work mode
		if ($alert->work_mode && $job->work_mode !== $alert->work_mode) return false;

		// Minimum salary
		if ($alert->salary_min > 0 && $job->salary_max > 0 && $job->salary_max < $alert->salary_min) return false;

		// Experience (batch 22) — same semantics as class-jp-search.php's
		// 'exp' filter: a job with no stated minimum, or one at/below the
		// candidate's years, matches; a job requiring more than the
		// candidate has does not.
		if (!empty($alert->experience) && $alert->experience > 0) {
			$job_min = isset($job->experience_min) ? (int) $job->experience_min : 0;
			if ($job_min > 0 && $job_min > (int) $alert->experience) return false;
		}

		// Skills (batch 27) — AND semantics, consistent with the search
		// filter: every skill stored on the alert must appear on the job.
		if (!empty($alert->skills_json)) {
			$alert_skills = json_decode($alert->skills_json, true);
			if (is_array($alert_skills) && $alert_skills) {
				$job_skills_haystack = strtolower((string) ($job->skills_json ?? ''));
				foreach ($alert_skills as $skill) {
					if (!$skill) continue;
					if (!str_contains($job_skills_haystack, strtolower((string) $skill))) return false;
				}
			}
		}

		return true;
	}

	// ── Background-job-queue consumers (see class-jp-queue.php) ─────────────────
	// These are the do_action() targets JP_Queue::process_batch() invokes.
	// They re-fetch the alert/job(s) by ID rather than receiving live
	// objects, because everything passed through the queue is round-tripped
	// through JSON storage (jp_job_queue.args_json) — only scalars/IDs
	// survive that, which is also why this is a safer boundary than trying
	// to serialize whole WP/DB row objects into a queue table.

	public function queue_send_alert_email( int $alert_id, int $job_id ): void {
		global $wpdb;
		$alert = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_alerts WHERE id=%d", $alert_id ) );
		$job   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_jobs WHERE id=%d", $job_id ) );
		if ( ! $alert || ! $job ) return; // Deleted between enqueue and processing — nothing to send.

		$this->send_alert_email( $alert, $job );
	}

	public function queue_send_digest_email( int $alert_id, array $job_ids, string $frequency ): void {
		global $wpdb;
		$alert = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}jp_alerts WHERE id=%d", $alert_id ) );
		if ( ! $alert || empty( $job_ids ) ) return;

		$ids_sql = implode( ',', array_map( 'intval', $job_ids ) );
		$jobs    = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}jp_jobs WHERE id IN ({$ids_sql})" );
		if ( empty( $jobs ) ) return;

		$this->send_digest_email( $alert, $jobs, $frequency );
	}

	// ── Email dispatch ────────────────────────────────────────────────────────

	private function send_alert_email( object $alert, object $job ): void {
		$user = get_userdata($alert->user_id);
		if (!$user) return;

		$job_url = home_url('/jobs/'.$job->slug.'/');
		$subject = "New job match: {$job->title}";
		$body    = JP_Notifications::instance()->render_template('job_alert_instant',[
			'name'    => $user->display_name,
			'job'     => $job,
			'job_url' => $job_url,
		]);

		JP_Notifications::instance()->send_email($user->user_email,$subject,$body);
		$this->log_sent($alert->id);
	}

	private function send_digest_email( object $alert, array $jobs, string $frequency ): void {
		$user = get_userdata($alert->user_id);
		if (!$user) return;

		$label   = $frequency === 'weekly' ? 'Weekly' : 'Daily';
		$subject = "{$label} Job Digest — ".count($jobs)." new jobs matching your alert";
		$body    = JP_Notifications::instance()->render_template('job_alert_digest',[
			'name'      => $user->display_name,
			'jobs'      => array_slice($jobs,0,10),
			'frequency' => $label,
			'alert'     => $alert,
		]);

		JP_Notifications::instance()->send_email($user->user_email,$subject,$body);
		$this->log_sent($alert->id);
	}

	/**
	 * Root-cause fix: this previously did an $wpdb->insert() with the
	 * existing alert's id (guaranteed PRIMARY KEY collision — always
	 * failed) into a column named 'last_sent_at', followed by an UPDATE
	 * referencing that same column name — but the actual schema column
	 * (class-jp-activator.php) is named 'last_sent', not 'last_sent_at'.
	 * Both statements failed silently on every single call (wpdb suppresses
	 * SQL errors by default), meaning jp_alerts.last_sent had NEVER been
	 * written by this code path since it was built. Fixed to a single
	 * UPDATE against the real column name, and the bogus INSERT removed
	 * entirely — it served no purpose even if the column names had matched.
	 */
	private function log_sent( int $alert_id ): void {
		global $wpdb;
		$wpdb->update( $wpdb->prefix . 'jp_alerts', [ 'last_sent' => current_time( 'mysql' ) ], [ 'id' => $alert_id ] );
	}
}
