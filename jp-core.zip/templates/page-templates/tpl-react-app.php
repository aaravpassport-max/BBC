<?php
/**
 * Template Name: JP React App (Full Page)
 *
 * Outputs ONLY the React mount div — no theme header, footer, sidebar,
 * scripts, or styles. All asset management is handled in JP_React::__construct()
 * via wp_enqueue_scripts hooks that fire at the correct time.
 *
 * DO NOT add wp_enqueue_scripts hooks here — the template loads after that
 * action has already fired, making any hooks registered here dead code.
 */
defined( 'ABSPATH' ) || exit;

?><!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#4A90D9">
<?php
// Root-cause fix: this hardcoded WordPress's own Settings → General →
// "Site Title" here, completely bypassing jp_site_name (the "Site name"
// field on the JP Settings page — the one field an admin actually expects
// to control the portal's brand name everywhere). React's
// useDocumentTitle() overwrites this a moment after mount for every
// client-side navigation, but THIS is the title a search engine, a
// social-share unfurl, or a user's very first paint (before JS executes)
// actually sees — it needs the same source of truth as the rest of the
// platform, not a second, unrelated WordPress field.
?>
<title><?php wp_title( '—', true, 'right' ); ?><?php echo esc_html( jp_site_name() ); ?></title>
<?php
// Root-cause fix (Phase 5 cutover accessibility/SEO audit): this page had
// no <meta name="description"> at all — every SPA-hosted page (every job,
// company, and search-result URL) shared nothing but a bare <title>, which
// search engines fall back to auto-generating a snippet from page text
// for. React sets a specific document.title per route client-side
// (App.tsx / useDocumentTitle), which resolves the same gap for the title
// element for JS-executing crawlers, but a description needs a server-
// rendered fallback too since it's frequently read by tools that don't
// run JS. This is necessarily generic (one PHP template serves every SPA
// route, so it can't know "this is job #482" the way React does) — it's
// a real improvement over having none at all, not a substitute for true
// per-page descriptions, which would need server-side data lookups this
// template doesn't have.
$jp_meta_description = get_bloginfo( 'description' );
if ( ! $jp_meta_description ) {
	$jp_meta_description = jp_site_name() . ' — find jobs, hire talent, and grow your career.';
}
?>
<meta name="description" content="<?php echo esc_attr( $jp_meta_description ); ?>">
<?php wp_head(); ?>
<style>
/* ── Critical fixes — inline in template so CDN caching of jp-app.css cannot break them ── */

/* Prevent horizontal page scroll from any overflowing element */
html { overflow-x: hidden !important; }
#jp-root { overflow-x: hidden !important; max-width: 100vw !important; }

/* Remove WP admin bar layout shift */
body.jp-fullpage { margin-top: 0 !important; padding-top: 0 !important; }
#wpadminbar { display: none !important; }

/* Fix CSS Grid column overflow bug:
   Default min-width:auto on grid cells lets unbroken text blow out the layout.
   Tailwind grid-cols-3 uses minmax(0,1fr) but explicit min-width:0 is needed on children. */
#jp-root .grid > * { min-width: 0; }

/* Fix text overflow: target text content elements, NOT layout containers */
/* Applying overflow-wrap to ALL divs breaks flex/grid layout and header nav */
#jp-root p { overflow-wrap: anywhere; word-break: break-word; }
#jp-root [class*="leading-relaxed"] { 
  overflow-wrap: anywhere;
  word-break: break-word;
  max-width: 100%;
}
/* Job description HTML content specifically */
#jp-root .job-description, 
#jp-root .job-requirements { 
  overflow-wrap: anywhere !important;
  word-break: break-word !important;
}
</style>
<script<?php
// Root-cause fix (confirmed via live browser console: "Executing inline
// script violates the following Content Security Policy directive
// 'script-src ... 'nonce-...'... The action has been blocked."):
// JP_Security::send_csp_header() sends a strict script-src that requires
// EVERY inline <script> to carry a matching nonce attribute — but this
// hand-written <script> tag never got one, so this whole service-worker
// cleanup block (including the very logic protecting a user's push
// subscription from being silently torn down — see the comment inside)
// has been unconditionally blocked by the browser on any request where
// the CSP header fires. JP_CSP_NONCE is defined by send_csp_header() on
// the 'send_headers' hook, which fires well before this template renders.
echo defined( 'JP_CSP_NONCE' ) ? ' nonce="' . esc_attr( JP_CSP_NONCE ) . '"' : '';
?>>
// Root-cause fix (Phase 5 cutover): this used to unconditionally clear
// EVERY service worker registration on load and then permanently override
// navigator.serviceWorker.register() to always reject — written when this
// page hosted the legacy compiled SPA, which registered no service worker
// of its own and only needed defense against the old theme's stray sw.js
// registration attempt (404, and a stale-cache/React-error-#321 risk).
// The React+TypeScript rewrite that now runs on this page legitimately
// registers its own push-notification service worker (src/lib/push.ts,
// public/jp-push-sw.js) — the blanket override above would silently break
// that feature (every registration attempt, including our own, would
// reject) and the blanket unregister-everything-on-every-load would also
// tear down an already-subscribed user's push registration on their next
// page view. Scoped down to only ever touch a stray registration that
// ISN'T our own push worker, identified by its scriptURL; our own
// jp-push-sw.js registration is left completely alone.
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.getRegistrations().then(function(registrations) {
    for (var r of registrations) {
      if (r.active && r.active.scriptURL.indexOf('jp-push-sw.js') !== -1) continue;
      r.unregister();
    }
  });
}
</script>
<?php
// Root-cause fix (this engagement's own repeated pattern: diagnosing a live
// bug required several rounds of "please open DevTools and paste X", which
// is real, avoidable friction — everything asked for in those rounds is
// information the BROWSER already has and can collect itself in one pass).
// This is a single, self-contained diagnostic tool that answers every
// question that came up today at once: whether window.JP_CONFIG reflects
// the real logged-in session, whether an authenticated fetch to /config
// (the exact call the app itself makes) sees that session, what cache
// headers the page and its assets are actually served with (the CDN/cache
// question), what script/CSS URLs are actually wired into the page, any
// JS errors thrown before this point, and service worker state. One click
// produces one copyable report instead of five separate manual checks.
// Gated to administrators only — this exposes internal wiring (nonces,
// response headers) that has no business being visible to a job seeker or
// recruiter browsing the site.
if ( current_user_can( 'manage_options' ) ) :
?>
<script<?php echo defined( 'JP_CSP_NONCE' ) ? ' nonce="' . esc_attr( JP_CSP_NONCE ) . '"' : ''; ?>>
(function () {
  var caughtErrors = [];
  window.addEventListener('error', function (e) {
    caughtErrors.push({
      message: e.message,
      source: e.filename,
      line: e.lineno,
      col: e.colno,
      stack: e.error && e.error.stack ? String(e.error.stack) : null,
    });
  });
  window.addEventListener('unhandledrejection', function (e) {
    var reason = e.reason;
    caughtErrors.push({
      message: 'Unhandled promise rejection: ' + (reason && reason.message ? reason.message : String(reason)),
      stack: reason && reason.stack ? String(reason.stack) : null,
    });
  });

  async function runFullDiagnostic() {
    var report = {};
    report.generated_at = new Date().toISOString();
    report.page_url = window.location.href;
    report.user_agent = navigator.userAgent;

    // ── 1. What the server told THIS page load about the current session ──
    report.window_JP_CONFIG = window.JP_CONFIG || null;

    // ── 2. Did the React app actually mount, or crash before rendering? ──
    var root = document.getElementById('jp-root');
    report.jp_root_present = !!root;
    report.jp_root_child_count = root ? root.children.length : null;
    report.jp_root_html_preview = root
      ? root.innerHTML.slice(0, 300) + (root.innerHTML.length > 300 ? '…' : '')
      : null;

    // ── 3. Exactly which script/CSS URLs are wired into this page ──
    var scriptTag = document.getElementById('jp-react-app-js');
    var linkTag = document.getElementById('jp-react-app-css');
    report.entry_script_src = scriptTag ? scriptTag.getAttribute('src') : null;
    report.entry_css_href = linkTag ? linkTag.getAttribute('href') : null;

    // ── 4. Cache headers actually served for THIS document ──
    // Answers the "is a CDN/cache serving a stale page" question directly,
    // instead of inferring it from symptoms.
    try {
      var docRes = await fetch(window.location.href, { cache: 'no-store', credentials: 'same-origin' });
      var docHeaders = {};
      docRes.headers.forEach(function (v, k) { docHeaders[k] = v; });
      report.document_response_headers = docHeaders;
      report.document_http_status = docRes.status;
    } catch (e) {
      report.document_response_headers = 'FETCH FAILED: ' + e.message;
    }

    // ── 5. Cache headers for the JS/CSS bundle itself ──
    try {
      if (scriptTag) {
        var jsRes = await fetch(scriptTag.src, { cache: 'no-store', credentials: 'same-origin' });
        var jsHeaders = {};
        jsRes.headers.forEach(function (v, k) { jsHeaders[k] = v; });
        report.entry_script_response_headers = jsHeaders;
      }
    } catch (e) {
      report.entry_script_response_headers = 'FETCH FAILED: ' + e.message;
    }

    // ── 6. The EXACT authenticated call AuthContext.tsx makes at boot ──
    // This is the single most direct answer to "is the admin session
    // actually recognized by the API": it reproduces fetchBootstrapConfig()
    // byte-for-byte, right now, in this real browser session.
    try {
      var nonce = (window.JP_CONFIG && window.JP_CONFIG.nonce) || '';
      var apiUrl = (window.JP_CONFIG && window.JP_CONFIG.api_url) || (window.location.origin + '/wp-json/jp/v1');
      var cfgRes = await fetch(apiUrl.replace(/\/$/, '') + '/config', {
        credentials: 'same-origin',
        headers: nonce ? { 'X-WP-Nonce': nonce } : {},
      });
      report.live_authenticated_config_fetch_status = cfgRes.status;
      try {
        report.live_authenticated_config_fetch_body = await cfgRes.json();
      } catch (e) {
        report.live_authenticated_config_fetch_body = 'NON-JSON RESPONSE BODY';
      }
    } catch (e) {
      report.live_authenticated_config_fetch_error = e.message;
    }

    // ── 7. Service worker state ──
    try {
      if ('serviceWorker' in navigator) {
        var regs = await navigator.serviceWorker.getRegistrations();
        report.service_workers = regs.map(function (r) {
          return { scope: r.scope, active_script: r.active ? r.active.scriptURL : null };
        });
      } else {
        report.service_workers = 'not supported';
      }
    } catch (e) {
      report.service_workers = 'ERROR: ' + e.message;
    }

    // ── 8. Any JS errors thrown on this page before the report was run ──
    report.caught_js_errors = caughtErrors.slice();

    return report;
  }

  function showReport(text) {
    var overlay = document.createElement('div');
    overlay.style.cssText =
      'position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:2147483647;' +
      'display:flex;align-items:center;justify-content:center;padding:24px;font-family:system-ui,sans-serif;';
    var box = document.createElement('div');
    box.style.cssText =
      'background:#fff;border-radius:12px;padding:20px;max-width:800px;width:100%;' +
      'max-height:80vh;display:flex;flex-direction:column;gap:12px;box-shadow:0 8px 30px rgba(0,0,0,.3);';
    var title = document.createElement('h2');
    title.textContent = 'JP Diagnostic Report';
    title.style.cssText = 'margin:0;font:600 18px system-ui;color:#111;';
    var hint = document.createElement('p');
    hint.textContent = 'Copy this and send it as-is — it answers everything needed in one piece.';
    hint.style.cssText = 'margin:0;font:13px system-ui;color:#555;';
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.readOnly = true;
    ta.style.cssText =
      'flex:1;min-height:320px;font:12px/1.4 ui-monospace,monospace;padding:10px;' +
      'border:1px solid #ddd;border-radius:8px;resize:vertical;';
    var actions = document.createElement('div');
    actions.style.cssText = 'display:flex;gap:8px;justify-content:flex-end;';
    var copyBtn = document.createElement('button');
    copyBtn.textContent = 'Copy Report';
    copyBtn.style.cssText =
      'background:#4A90D9;color:#fff;border:none;border-radius:6px;padding:8px 14px;cursor:pointer;font:14px system-ui;';
    copyBtn.addEventListener('click', function () {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(text).then(function () {
          copyBtn.textContent = 'Copied!';
        }, function () {
          ta.select();
        });
      } else {
        ta.select();
      }
    });
    var closeBtn = document.createElement('button');
    closeBtn.textContent = 'Close';
    closeBtn.style.cssText =
      'background:#eee;color:#111;border:none;border-radius:6px;padding:8px 14px;cursor:pointer;font:14px system-ui;';
    closeBtn.addEventListener('click', function () { overlay.remove(); });
    actions.appendChild(copyBtn);
    actions.appendChild(closeBtn);
    box.appendChild(title);
    box.appendChild(hint);
    box.appendChild(ta);
    box.appendChild(actions);
    overlay.appendChild(box);
    document.body.appendChild(overlay);
    ta.focus();
    ta.select();
  }

  function buildButton() {
    var btn = document.createElement('button');
    btn.textContent = '🔍 Run JP Diagnostic';
    btn.style.cssText =
      'position:fixed;bottom:16px;right:16px;z-index:2147483646;background:#4A90D9;color:#fff;' +
      'border:none;border-radius:8px;padding:10px 16px;font:14px system-ui;cursor:pointer;' +
      'box-shadow:0 2px 10px rgba(0,0,0,.35);';
    btn.addEventListener('click', async function () {
      var original = btn.textContent;
      btn.textContent = 'Running…';
      btn.disabled = true;
      try {
        var report = await runFullDiagnostic();
        showReport(JSON.stringify(report, null, 2));
      } catch (e) {
        showReport('DIAGNOSTIC ITSELF THREW AN ERROR:\n' + (e && e.stack ? e.stack : String(e)));
      } finally {
        btn.textContent = original;
        btn.disabled = false;
      }
    });
    document.body.appendChild(btn);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', buildButton);
  } else {
    buildButton();
  }
})();
</script>
<?php endif; ?>
</head>
<body <?php body_class( "jp-fullpage" ); ?>>
<?php wp_body_open(); ?>

<div id="jp-root"></div>

<noscript>
  <div style="padding:2rem;text-align:center;font-family:system-ui,sans-serif;color:#374151">
    <h2 style="font-size:1.5rem;margin-bottom:.5rem">JavaScript Required</h2>
    <p>JP Jobs Portal requires JavaScript. Please enable it in your browser settings.</p>
  </div>
</noscript>

<?php wp_footer(); ?>
</body>
</html>
