import{n as e}from"./apiClient-B0H3oCKz.js";function t(t=30){return e.get(`/recruiter/analytics`,{days:t})}export{t};
//# sourceMappingURL=analyticsApi-BuulljDz.js.map