import{n as e}from"./apiClient-CeGGJ11B.js";function t(t=30){return e.get(`/recruiter/analytics`,{days:t})}export{t};
//# sourceMappingURL=analyticsApi-Z_AeBUPZ.js.map