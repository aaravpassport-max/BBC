// Minimal Web Push service worker for the JP job portal SPA.
//
// This only handles showing a notification when a push arrives and routing
// a click on it — it deliberately does NOT do any asset caching/offline
// support, since that's a separate concern from "let jp_push_subscriptions
// rows actually receive a notification" (the gap this file closes: the
// backend's push_subscribe()/push_unsubscribe() REST endpoints and the
// VAPID-based send path in class-jp-push.php had no browser-side
// subscriber at all before this).
//
// Registered from src/lib/push.ts at an absolute site-root path so its
// scope covers the whole origin, matching how this app already treats
// window.location.origin as the WordPress site root everywhere else
// (AuthContext's bootstrap config fetch, home_url-based links, etc).

self.addEventListener('push', (event) => {
  let payload = { title: 'Notification', body: '', url: '/' }
  try {
    if (event.data) payload = { ...payload, ...event.data.json() }
  } catch {
    // Non-JSON payload — fall back to the defaults above rather than failing.
  }

  event.waitUntil(
    self.registration.showNotification(payload.title, {
      body: payload.body,
      icon: '/favicon.svg',
      data: { url: payload.url },
    }),
  )
})

self.addEventListener('notificationclick', (event) => {
  event.notification.close()
  const url = event.notification.data?.url || '/'
  event.waitUntil(self.clients.openWindow(url))
})
