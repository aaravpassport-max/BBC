import type { ReactNode } from 'react'
import { Navigate, useLocation } from 'react-router-dom'
import { useAuth } from '@/lib/auth/AuthContext'
import type { JpRole } from '@/lib/auth/types'
import { FullPageSpinner } from '@/components/ui/FullPageSpinner'

/**
 * Route guard. `roles` omitted = any authenticated user. This is the
 * client-side half of access control only — every protected screen's real
 * enforcement is the REST endpoint's own permission_callback (already
 * correct, per the backend audit). This guard exists purely for UX (don't
 * flash an admin screen before redirecting), never as the security
 * boundary — exactly the "UI Access Restriction is defense-in-depth, not
 * the sole control" principle from the standing audit protocol.
 */
export function ProtectedRoute({ roles, children }: { roles?: JpRole[]; children: ReactNode }) {
  const { loading, isAuthenticated, role } = useAuth()
  const location = useLocation()

  if (loading) return <FullPageSpinner />

  if (!isAuthenticated) {
    return <Navigate to="/login" state={{ from: location }} replace />
  }

  if (roles && !roles.includes(role)) {
    return <Navigate to="/" replace />
  }

  return <>{children}</>
}
