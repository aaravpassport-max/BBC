import { lazy, useMemo } from 'react'
import { createBrowserRouter } from 'react-router-dom'
import { App } from '@/App'
import { ProtectedRoute } from '@/routes/ProtectedRoute'
import { DashboardLayout } from '@/components/layout/DashboardLayout'
import { useAuth } from '@/lib/auth/AuthContext'

// Route-based code splitting: every page is its own chunk, fetched only
// when its route is visited. Public/candidate/recruiter/admin are
// disjoint audiences that never need each other's code in the same
// session, so this keeps the initial bundle to the shell + whichever
// area the visitor actually lands in, instead of one ever-growing
// ~500KB+ bundle as more Phase 4/5 screens get added (see JP-PLATFORM-
// ROADMAP.md Part 5 performance NFRs). App.tsx's <Suspense> is what
// renders while a chunk is in flight.
const HomePage = lazy(() => import('@/pages/public/HomePage').then((m) => ({ default: m.HomePage })))
const JobsPage = lazy(() => import('@/pages/public/JobsPage').then((m) => ({ default: m.JobsPage })))
const JobDetailPage = lazy(() => import('@/pages/public/JobDetailPage').then((m) => ({ default: m.JobDetailPage })))
const CompaniesPage = lazy(() => import('@/pages/public/CompaniesPage').then((m) => ({ default: m.CompaniesPage })))
const CompanyDetailPage = lazy(() =>
  import('@/pages/public/CompanyDetailPage').then((m) => ({ default: m.CompanyDetailPage })),
)
const LoginPage = lazy(() => import('@/pages/auth/LoginPage').then((m) => ({ default: m.LoginPage })))
const RegisterPage = lazy(() => import('@/pages/auth/RegisterPage').then((m) => ({ default: m.RegisterPage })))
const ForgotPasswordPage = lazy(() =>
  import('@/pages/auth/ForgotPasswordPage').then((m) => ({ default: m.ForgotPasswordPage })),
)
const ResetPasswordPage = lazy(() =>
  import('@/pages/auth/ResetPasswordPage').then((m) => ({ default: m.ResetPasswordPage })),
)
const CommunityPage = lazy(() => import('@/pages/public/CommunityPage').then((m) => ({ default: m.CommunityPage })))
const CommunityPostPage = lazy(() =>
  import('@/pages/public/CommunityPostPage').then((m) => ({ default: m.CommunityPostPage })),
)
const EventsPage = lazy(() => import('@/pages/public/EventsPage').then((m) => ({ default: m.EventsPage })))
const EventDetailPage = lazy(() => import('@/pages/public/EventDetailPage').then((m) => ({ default: m.EventDetailPage })))
const MarketInsightsPage = lazy(() =>
  import('@/pages/public/MarketInsightsPage').then((m) => ({ default: m.MarketInsightsPage })),
)
const PricingPage = lazy(() => import('@/pages/public/PricingPage').then((m) => ({ default: m.PricingPage })))
const HelpCenterPage = lazy(() => import('@/pages/public/HelpCenterPage').then((m) => ({ default: m.HelpCenterPage })))
const ChangelogPage = lazy(() => import('@/pages/public/ChangelogPage').then((m) => ({ default: m.ChangelogPage })))
const PublicProfilePage = lazy(() =>
  import('@/pages/public/PublicProfilePage').then((m) => ({ default: m.PublicProfilePage })),
)

const DashboardHomePage = lazy(() =>
  import('@/pages/dashboard/DashboardHomePage').then((m) => ({ default: m.DashboardHomePage })),
)
const MatchesPage = lazy(() => import('@/pages/dashboard/MatchesPage').then((m) => ({ default: m.MatchesPage })))
const ApplicationsPage = lazy(() =>
  import('@/pages/dashboard/ApplicationsPage').then((m) => ({ default: m.ApplicationsPage })),
)
const SavedJobsPage = lazy(() => import('@/pages/dashboard/SavedJobsPage').then((m) => ({ default: m.SavedJobsPage })))
const InterviewsPage = lazy(() => import('@/pages/dashboard/InterviewsPage').then((m) => ({ default: m.InterviewsPage })))
const AlertsPage = lazy(() => import('@/pages/dashboard/AlertsPage').then((m) => ({ default: m.AlertsPage })))
const ResumesPage = lazy(() => import('@/pages/dashboard/ResumesPage').then((m) => ({ default: m.ResumesPage })))
const ResumeBuilderPage = lazy(() =>
  import('@/pages/dashboard/ResumeBuilderPage').then((m) => ({ default: m.ResumeBuilderPage })),
)
const NotificationsPage = lazy(() =>
  import('@/pages/dashboard/NotificationsPage').then((m) => ({ default: m.NotificationsPage })),
)
const ProfilePage = lazy(() => import('@/pages/dashboard/ProfilePage').then((m) => ({ default: m.ProfilePage })))
const AssessmentsPage = lazy(() =>
  import('@/pages/dashboard/AssessmentsPage').then((m) => ({ default: m.AssessmentsPage })),
)
const GamificationPage = lazy(() =>
  import('@/pages/dashboard/GamificationPage').then((m) => ({ default: m.GamificationPage })),
)
const SecuritySettingsPage = lazy(() =>
  import('@/pages/dashboard/SecuritySettingsPage').then((m) => ({ default: m.SecuritySettingsPage })),
)
const AiHubPage = lazy(() => import('@/pages/dashboard/AiHubPage').then((m) => ({ default: m.AiHubPage })))

const RecruiterHomePage = lazy(() =>
  import('@/pages/recruiter/RecruiterHomePage').then((m) => ({ default: m.RecruiterHomePage })),
)
const RecruiterJobsPage = lazy(() =>
  import('@/pages/recruiter/RecruiterJobsPage').then((m) => ({ default: m.RecruiterJobsPage })),
)
const JobFormPage = lazy(() => import('@/pages/recruiter/JobFormPage').then((m) => ({ default: m.JobFormPage })))
const RecruiterApplicationsPage = lazy(() =>
  import('@/pages/recruiter/RecruiterApplicationsPage').then((m) => ({ default: m.RecruiterApplicationsPage })),
)
const RecruiterCandidatesPage = lazy(() =>
  import('@/pages/recruiter/RecruiterCandidatesPage').then((m) => ({ default: m.RecruiterCandidatesPage })),
)
const RecruiterTalentPoolPage = lazy(() =>
  import('@/pages/recruiter/RecruiterTalentPoolPage').then((m) => ({ default: m.RecruiterTalentPoolPage })),
)
const RecruiterCompanyPage = lazy(() =>
  import('@/pages/recruiter/RecruiterCompanyPage').then((m) => ({ default: m.RecruiterCompanyPage })),
)
const RecruiterEventsPage = lazy(() =>
  import('@/pages/recruiter/RecruiterEventsPage').then((m) => ({ default: m.RecruiterEventsPage })),
)
const RecruiterAnalyticsPage = lazy(() =>
  import('@/pages/recruiter/RecruiterAnalyticsPage').then((m) => ({ default: m.RecruiterAnalyticsPage })),
)
const RecruiterInterviewsPage = lazy(() =>
  import('@/pages/recruiter/RecruiterInterviewsPage').then((m) => ({ default: m.RecruiterInterviewsPage })),
)
const RecruiterBillingPage = lazy(() =>
  import('@/pages/recruiter/RecruiterBillingPage').then((m) => ({ default: m.RecruiterBillingPage })),
)
const RecruiterAiToolsPage = lazy(() =>
  import('@/pages/recruiter/RecruiterAiToolsPage').then((m) => ({ default: m.RecruiterAiToolsPage })),
)
const TeamPage = lazy(() => import('@/pages/recruiter/TeamPage').then((m) => ({ default: m.TeamPage })))
const AcceptInvitePage = lazy(() =>
  import('@/pages/team/AcceptInvitePage').then((m) => ({ default: m.AcceptInvitePage })),
)

const AdminHomePage = lazy(() => import('@/pages/admin/AdminHomePage').then((m) => ({ default: m.AdminHomePage })))
const AdminJobModerationPage = lazy(() =>
  import('@/pages/admin/AdminJobModerationPage').then((m) => ({ default: m.AdminJobModerationPage })),
)
const AdminCompaniesPage = lazy(() =>
  import('@/pages/admin/AdminCompaniesPage').then((m) => ({ default: m.AdminCompaniesPage })),
)
const AdminApplicationsPage = lazy(() =>
  import('@/pages/admin/AdminApplicationsPage').then((m) => ({ default: m.AdminApplicationsPage })),
)
const AdminUsersPage = lazy(() => import('@/pages/admin/AdminUsersPage').then((m) => ({ default: m.AdminUsersPage })))
const AdminPaymentsPage = lazy(() =>
  import('@/pages/admin/AdminPaymentsPage').then((m) => ({ default: m.AdminPaymentsPage })),
)
const AdminSkillsPage = lazy(() => import('@/pages/admin/AdminSkillsPage').then((m) => ({ default: m.AdminSkillsPage })))
const AdminAuditLogPage = lazy(() =>
  import('@/pages/admin/AdminAuditLogPage').then((m) => ({ default: m.AdminAuditLogPage })),
)
const AdminHealthPage = lazy(() => import('@/pages/admin/AdminHealthPage').then((m) => ({ default: m.AdminHealthPage })))
const AdminDiagnosticsPage = lazy(() =>
  import('@/pages/admin/AdminDiagnosticsPage').then((m) => ({ default: m.AdminDiagnosticsPage })),
)
const AdminReviewModerationPage = lazy(() =>
  import('@/pages/admin/AdminReviewsPage').then((m) => ({ default: m.AdminReviewModerationPage })),
)
const AdminPlansPage = lazy(() => import('@/pages/admin/AdminPlansPage').then((m) => ({ default: m.AdminPlansPage })))
const AdminSettingsPage = lazy(() =>
  import('@/pages/admin/AdminSettingsPage').then((m) => ({ default: m.AdminSettingsPage })),
)
const AdminWebhooksPage = lazy(() =>
  import('@/pages/admin/AdminWebhooksPage').then((m) => ({ default: m.AdminWebhooksPage })),
)
const AdminFeatureFlagsPage = lazy(() =>
  import('@/pages/admin/AdminFeatureFlagsPage').then((m) => ({ default: m.AdminFeatureFlagsPage })),
)
const AdminErrorLogPage = lazy(() =>
  import('@/pages/admin/AdminErrorLogPage').then((m) => ({ default: m.AdminErrorLogPage })),
)
const AdminSystemPage = lazy(() => import('@/pages/admin/AdminSystemPage').then((m) => ({ default: m.AdminSystemPage })))
const AdminRevenuePage = lazy(() => import('@/pages/admin/AdminRevenuePage').then((m) => ({ default: m.AdminRevenuePage })))
const AdminSubscriptionsPage = lazy(() =>
  import('@/pages/admin/AdminSubscriptionsPage').then((m) => ({ default: m.AdminSubscriptionsPage })),
)
const AdminAnalyticsPage = lazy(() =>
  import('@/pages/admin/AdminAnalyticsPage').then((m) => ({ default: m.AdminAnalyticsPage })),
)

const MessagesPage = lazy(() => import('@/pages/messaging/MessagesPage').then((m) => ({ default: m.MessagesPage })))
const NotFoundPage = lazy(() => import('@/pages/errors/NotFoundPage').then((m) => ({ default: m.NotFoundPage })))

const DASHBOARD_LINKS = [
  { to: '', label: 'Overview' },
  { to: '/matches', label: 'Matches' },
  { to: '/applications', label: 'Applications' },
  { to: '/interviews', label: 'Interviews' },
  { to: '/saved-jobs', label: 'Saved jobs' },
  { to: '/alerts', label: 'Job alerts' },
  { to: '/resumes', label: 'Resumes' },
  { to: '/resume-builder', label: 'Resume builder' },
  { to: '/assessments', label: 'Assessments' },
  { to: '/achievements', label: 'Achievements' },
  { to: '/messages', label: 'Messages' },
  { to: '/notifications', label: 'Notifications' },
  { to: '/profile', label: 'Profile' },
  { to: '/security', label: 'Security & privacy' },
  { to: '/ai-hub', label: 'AI career hub' },
]

const RECRUITER_LINKS = [
  { to: '', label: 'Overview' },
  { to: '/jobs', label: 'Job postings' },
  { to: '/applications', label: 'Applicants' },
  { to: '/candidates', label: 'Find candidates' },
  { to: '/talent-pool', label: 'Talent pool' },
  { to: '/messages', label: 'Messages' },
  { to: '/company', label: 'Company profile' },
  { to: '/team', label: 'Team' },
  { to: '/events', label: 'Events' },
  { to: '/analytics', label: 'Analytics' },
  { to: '/interviews', label: 'Interviews' },
  { to: '/billing', label: 'Billing' },
  { to: '/ai-tools', label: 'AI tools' },
]

const ADMIN_LINKS = [
  { to: '', label: 'Overview' },
  { to: '/jobs', label: 'Job moderation' },
  { to: '/companies', label: 'Companies' },
  { to: '/users', label: 'Users' },
  { to: '/applications', label: 'Applications' },
  { to: '/payments', label: 'Payments' },
  { to: '/skills', label: 'Skills' },
  { to: '/reviews', label: 'Reviews' },
  { to: '/plans', label: 'Plans' },
  { to: '/revenue', label: 'Revenue' },
  { to: '/subscriptions', label: 'Subscriptions' },
  { to: '/analytics', label: 'Analytics' },
  { to: '/audit-log', label: 'Audit log' },
  { to: '/error-log', label: 'Error log' },
  { to: '/health', label: 'System health' },
  { to: '/diagnostics', label: 'Diagnostics' },
  { to: '/webhooks', label: 'Webhooks' },
  { to: '/feature-flags', label: 'Feature flags' },
  { to: '/settings', label: 'Settings' },
  { to: '/system', label: 'System' },
]

/**
 * Root-cause fix (batch 5 — see class-jp-api.php's require_cap() docblock
 * for the full backend half of this fix). Before this, jp_staff and
 * jp_admin_manager landed in /admin and saw EVERY link above — including
 * ones their role's own declared capabilities (class-jp-roles.php) could
 * never actually use, since every admin REST route required literal
 * manage_options. Now that the backend accepts each route's specific
 * capability, this maps the same capability grants onto which nav links
 * each role should even see, so a staff/admin-manager user's admin panel
 * shows only pages they can act on — not a wall of links that all 403.
 * `administrator` is intentionally NOT special-cased here: it already
 * falls through the `|| true` default below and always sees everything,
 * matching its manage_options-covers-everything backend behavior.
 */
const ADMIN_LINK_VISIBILITY: Record<string, ((role: string) => boolean) | undefined> = {
  '': () => true, // Overview — admin_stats() now accepts jp_view_reports, which every admin-family role has
  '/jobs': () => true, // jp_approve_jobs: jp_staff + jp_admin_manager + administrator (all 3 roles able to reach /admin at all)
  '/companies': (role) => role === 'jp_admin_manager' || role === 'administrator', // jp_verify_companies
  '/users': (role) => role === 'jp_admin_manager' || role === 'administrator', // jp_manage_users
  '/applications': (role) => role === 'jp_admin_manager' || role === 'administrator', // jp_manage_all_applications — same admin-family roles jp_users has, see class-jp-roles.php
  '/payments': (role) => role === 'jp_admin_manager' || role === 'administrator', // jp_view_revenue
  '/skills': () => true, // jp_moderate_content: jp_staff + jp_admin_manager + administrator
  '/reviews': () => true, // jp_moderate_content
  '/plans': (role) => role === 'administrator', // left on manage_options — see require_cap() docblock
  '/revenue': (role) => role === 'jp_admin_manager' || role === 'administrator', // jp_view_revenue
  '/subscriptions': (role) => role === 'jp_admin_manager' || role === 'administrator', // jp_view_revenue
  '/analytics': (role) => role === 'jp_admin_manager' || role === 'administrator', // jp_view_analytics
  '/audit-log': (role) => role === 'administrator', // jp_view_audit_log — administrator-only today
  '/error-log': (role) => role === 'administrator', // no declared capability; manage_options only
  '/health': (role) => role === 'administrator',
  '/diagnostics': (role) => role === 'administrator',
  '/webhooks': (role) => role === 'administrator', // jp_system_config — administrator-only today
  '/feature-flags': (role) => role === 'administrator',
  '/settings': (role) => role === 'administrator',
  '/system': (role) => role === 'administrator',
}

function AdminDashboardLayout() {
  const { role } = useAuth()
  const links = useMemo(
    () => ADMIN_LINKS.filter((link) => (ADMIN_LINK_VISIBILITY[link.to] ?? (() => true))(role)),
    [role],
  )
  return <DashboardLayout basePath="/admin" links={links} />
}

/**
 * Single route tree for the whole standalone app (public site + candidate
 * portal + recruiter workspace + admin panel — replacing wp-admin per
 * JP-PLATFORM-ROADMAP.md Part 3.3). /dashboard, /recruiter, and /admin are
 * each a full nested tree now (Phases 1-3); Phase 4 adds sibling sections
 * the same way.
 */
export const router = createBrowserRouter([
  {
    path: '/',
    element: <App />,
    children: [
      { index: true, element: <HomePage /> },
      { path: 'jobs', element: <JobsPage /> },
      { path: 'jobs/:id', element: <JobDetailPage /> },
      { path: 'companies', element: <CompaniesPage /> },
      { path: 'companies/:id', element: <CompanyDetailPage /> },
      { path: 'login', element: <LoginPage /> },
      { path: 'register', element: <RegisterPage /> },
      { path: 'forgot-password', element: <ForgotPasswordPage /> },
      { path: 'team/accept', element: <AcceptInvitePage /> },
      { path: 'reset-password', element: <ResetPasswordPage /> },
      { path: 'community', element: <CommunityPage /> },
      { path: 'community/:id', element: <CommunityPostPage /> },
      { path: 'events', element: <EventsPage /> },
      { path: 'events/:id', element: <EventDetailPage /> },
      { path: 'salary', element: <MarketInsightsPage /> },
      { path: 'pricing', element: <PricingPage /> },
      { path: 'help', element: <HelpCenterPage /> },
      { path: 'changelog', element: <ChangelogPage /> },
      { path: 'profiles/:id', element: <PublicProfilePage /> },
      {
        path: 'dashboard',
        element: (
          <ProtectedRoute roles={['jp_job_seeker']}>
            <DashboardLayout basePath="/dashboard" links={DASHBOARD_LINKS} />
          </ProtectedRoute>
        ),
        children: [
          { index: true, element: <DashboardHomePage /> },
          { path: 'matches', element: <MatchesPage /> },
          { path: 'applications', element: <ApplicationsPage /> },
          { path: 'interviews', element: <InterviewsPage /> },
          { path: 'saved-jobs', element: <SavedJobsPage /> },
          { path: 'alerts', element: <AlertsPage /> },
          { path: 'resumes', element: <ResumesPage /> },
          { path: 'resume-builder', element: <ResumeBuilderPage /> },
          { path: 'assessments', element: <AssessmentsPage /> },
          { path: 'achievements', element: <GamificationPage /> },
          { path: 'messages', element: <MessagesPage /> },
          { path: 'notifications', element: <NotificationsPage /> },
          { path: 'profile', element: <ProfilePage /> },
          { path: 'security', element: <SecuritySettingsPage /> },
          { path: 'ai-hub', element: <AiHubPage /> },
        ],
      },
      {
        path: 'recruiter',
        element: (
          <ProtectedRoute roles={['jp_recruiter', 'jp_team_manager']}>
            <DashboardLayout basePath="/recruiter" links={RECRUITER_LINKS} />
          </ProtectedRoute>
        ),
        children: [
          { index: true, element: <RecruiterHomePage /> },
          { path: 'jobs', element: <RecruiterJobsPage /> },
          { path: 'jobs/new', element: <JobFormPage /> },
          { path: 'jobs/:id/edit', element: <JobFormPage /> },
          { path: 'applications', element: <RecruiterApplicationsPage /> },
          { path: 'candidates', element: <RecruiterCandidatesPage /> },
          { path: 'talent-pool', element: <RecruiterTalentPoolPage /> },
          { path: 'messages', element: <MessagesPage /> },
          { path: 'company', element: <RecruiterCompanyPage /> },
          { path: 'team', element: <TeamPage /> },
          { path: 'events', element: <RecruiterEventsPage /> },
          { path: 'analytics', element: <RecruiterAnalyticsPage /> },
          { path: 'interviews', element: <RecruiterInterviewsPage /> },
          { path: 'billing', element: <RecruiterBillingPage /> },
          { path: 'ai-tools', element: <RecruiterAiToolsPage /> },
        ],
      },
      {
        path: 'admin',
        element: (
          <ProtectedRoute roles={['jp_staff', 'jp_admin_manager', 'administrator']}>
            <AdminDashboardLayout />
          </ProtectedRoute>
        ),
        children: [
          { index: true, element: <AdminHomePage /> },
          { path: 'jobs', element: <AdminJobModerationPage /> },
          { path: 'companies', element: <AdminCompaniesPage /> },
          { path: 'users', element: <AdminUsersPage /> },
          { path: 'applications', element: <AdminApplicationsPage /> },
          { path: 'payments', element: <AdminPaymentsPage /> },
          { path: 'skills', element: <AdminSkillsPage /> },
          { path: 'reviews', element: <AdminReviewModerationPage /> },
          { path: 'plans', element: <AdminPlansPage /> },
          { path: 'revenue', element: <AdminRevenuePage /> },
          { path: 'subscriptions', element: <AdminSubscriptionsPage /> },
          { path: 'analytics', element: <AdminAnalyticsPage /> },
          { path: 'audit-log', element: <AdminAuditLogPage /> },
          { path: 'error-log', element: <AdminErrorLogPage /> },
          { path: 'health', element: <AdminHealthPage /> },
          { path: 'diagnostics', element: <AdminDiagnosticsPage /> },
          { path: 'webhooks', element: <AdminWebhooksPage /> },
          { path: 'feature-flags', element: <AdminFeatureFlagsPage /> },
          { path: 'settings', element: <AdminSettingsPage /> },
          { path: 'system', element: <AdminSystemPage /> },
        ],
      },
      { path: '*', element: <NotFoundPage /> },
    ],
  },
])
