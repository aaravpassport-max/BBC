import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { RouterProvider } from 'react-router-dom'
import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
import { AuthProvider } from '@/lib/auth/AuthContext'
import { ToastProvider } from '@/components/ui/ToastProvider'
import { ErrorBoundary } from '@/components/ErrorBoundary'
import { router } from '@/routes/router'
import { setAssetBaseUrl } from '@/lib/assetBase'
import '@/styles/tokens.css'
import '@/styles/shared.css'
import '@/styles/platform.css'
import '@/styles/portal-pages.css'
import '@/styles/workspace-pages.css'
import './index.css'

// See assetBase.ts's docblock: this MUST run here, in the true entry
// module, not in some lazily-imported file — import.meta.url is only
// guaranteed to point at the build output root from the file Vite names
// via entryFileNames (jp-app.<version>.js), which is this one.
setAssetBaseUrl(new URL('.', import.meta.url).href)

// Root-cause fix (confirmed via a live browser console error: "Failed to
// fetch dynamically imported module: .../chunks/LoginPage-B-V51miR.js").
// vite.config.ts's entryFileNames was just given a content hash (see that
// file's docblock) specifically so a fronting CDN that ignores ?ver=
// query strings can no longer serve a stale entry bundle under an
// unchanged URL. That closes the case of a *fresh page load* fetching a
// stale entry. It does NOT close a second, narrower case: a tab that was
// already open — and had already loaded the OLD entry bundle into memory
// — BEFORE a new deploy ran. That tab's in-memory JS still tries to
// dynamically import route chunks by their OLD hashed names when the user
// navigates, and vite.config.ts's emptyOutDir wipes those exact files on
// every build — so the request 404s, permanently, for as long as that tab
// stays open. This is precisely what Vite's own `vite:preloadError` event
// exists to signal (dispatched on `window` whenever a dynamic import used
// for route-based code-splitting fails) — the documented, intended fix is
// to reload the page once, which re-fetches the (now content-hashed, so
// guaranteed-fresh) entry bundle and its correctly-matched chunk set.
// Guarded with a sessionStorage flag so a *genuine* network/hosting
// failure (not a stale-deploy mismatch) can't loop the page forever —
// one reload attempt per browser session is enough to recover from a
// deploy race and not enough to mask a real, persistent outage.
window.addEventListener('vite:preloadError', () => {
  const key = 'jp_reloaded_after_preload_error'
  if (sessionStorage.getItem(key)) return // already tried once this session — don't loop
  sessionStorage.setItem(key, '1')
  window.location.reload()
})

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      // Server data here is mutated by other users (recruiters, other
      // admins) constantly — a long staleTime would show stale pipelines/
      // application counts, which is worse than an extra request.
      staleTime: 30_000,
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
})

// Mounts to "jp-root", not "root" — matches the WordPress host markup
// (class-jp-react.php / tpl-react-app.php) this app is served from. See
// index.html's comment on the same div for the full reasoning.
createRoot(document.getElementById('jp-root')!).render(
  <StrictMode>
    {/*
      Outermost boundary: catches a render-time throw from ANY provider in
      this tree, including AuthProvider/ToastProvider/RouterProvider
      themselves — not just page content. See ErrorBoundary.tsx's docblock
      for why #jp-root was previously left permanently blank on any such
      throw. App.tsx additionally wraps just its <Outlet> in a second,
      route-scoped boundary so a single page crashing doesn't also take out
      the persistent header/nav — this outer one is the last-resort catch
      for everything above that layer.
    */}
    <ErrorBoundary>
      <QueryClientProvider client={queryClient}>
        <AuthProvider>
          <ToastProvider>
            <RouterProvider router={router} />
          </ToastProvider>
        </AuthProvider>
      </QueryClientProvider>
    </ErrorBoundary>
  </StrictMode>,
)
