import { useEffect, useRef, useState } from 'react'

/** Adds `jp-reveal--visible` when the element enters the viewport (respects reduced motion via CSS). */
export function useRevealOnScroll<T extends HTMLElement = HTMLDivElement>(rootMargin = '0px 0px -8% 0px') {
  const ref = useRef<T | null>(null)
  const [visible, setVisible] = useState(false)

  useEffect(() => {
    const node = ref.current
    if (!node || visible) return
    if (typeof IntersectionObserver === 'undefined') {
      setVisible(true)
      return
    }
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setVisible(true)
          observer.disconnect()
        }
      },
      { rootMargin, threshold: 0.08 },
    )
    observer.observe(node)
    return () => observer.disconnect()
  }, [rootMargin, visible])

  return { ref, className: visible ? 'jp-reveal jp-reveal--visible' : 'jp-reveal' }
}
