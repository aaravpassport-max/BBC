import { useRef, useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import { Card, CardBody } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import type { CsvImportResult } from '@/features/admin/api'

interface CsvImportPanelProps {
  title: string
  hint: string
  onImport: (csvText: string) => Promise<CsvImportResult>
  onDone?: () => void
}

/**
 * Root-cause fix (enterprise gap-analysis: "No CSV/bulk import anywhere").
 * Shared by AdminJobModerationPage and AdminCompaniesPage rather than
 * duplicated — both need an identical file-picker → read-as-text → POST →
 * per-row result summary flow, differing only in which endpoint they call
 * and their column-format hint text.
 */
export function CsvImportPanel({ title, hint, onImport, onDone }: CsvImportPanelProps) {
  const toast = useToast()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [fileName, setFileName] = useState<string | null>(null)
  const [result, setResult] = useState<CsvImportResult | null>(null)

  const importMutation = useMutation({
    mutationFn: onImport,
    onSuccess: (r) => {
      setResult(r)
      toast.success(r.message)
      onDone?.()
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Import failed.'),
  })

  function handleFileChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file) return
    setFileName(file.name)
    setResult(null)
    const reader = new FileReader()
    reader.onload = () => {
      const text = typeof reader.result === 'string' ? reader.result : ''
      if (!text.trim()) {
        toast.error('That file appears to be empty.')
        return
      }
      importMutation.mutate(text)
    }
    reader.onerror = () => toast.error('Could not read that file.')
    reader.readAsText(file)
  }

  return (
    <Card style={{ marginBottom: 16 }}>
      <CardBody>
        <h2 className="jp-job-title" style={{ fontSize: 16, marginBottom: 4 }}>
          {title}
        </h2>
        <p className="jp-job-company" style={{ marginBottom: 12 }}>
          {hint}
        </p>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, flexWrap: 'wrap' }}>
          <input
            ref={fileInputRef}
            type="file"
            accept=".csv,text/csv"
            onChange={handleFileChange}
            aria-label={`Choose CSV file to ${title.toLowerCase()}`}
          />
          {fileName && !importMutation.isPending && <span className="jp-job-company">{fileName}</span>}
          {importMutation.isPending && <span className="jp-job-company">Importing…</span>}
          {result && (
            <Button
              size="sm"
              variant="ghost"
              onClick={() => {
                setResult(null)
                setFileName(null)
                if (fileInputRef.current) fileInputRef.current.value = ''
              }}
            >
              Clear
            </Button>
          )}
        </div>

        {result && (
          <div style={{ marginTop: 12 }}>
            <p className="jp-job-company">
              {result.created} created{'invited' in result ? `, ${(result as { invited: number }).invited} account(s) invited` : ''}
              {result.failed > 0 ? `, ${result.failed} row(s) failed` : ''}.
            </p>
            {result.errors.length > 0 && (
              <ul style={{ margin: '8px 0 0', paddingLeft: 20, fontSize: 13, color: 'var(--jp-color-error, #b42318)' }}>
                {result.errors.map((err, i) => (
                  <li key={i}>{err}</li>
                ))}
              </ul>
            )}
          </div>
        )}
      </CardBody>
    </Card>
  )
}
