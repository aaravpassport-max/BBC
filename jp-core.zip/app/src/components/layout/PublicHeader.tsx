import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '@/lib/auth/AuthContext'
import { ROLE_LANDING_ROUTE } from '@/lib/auth/types'
import { Button } from '@/components/ui/Button'
import './PublicHeader.css'

const NAV_LINKS = [
  { to: '/jobs', label: 'Find Jobs' },
  { to: '/companies', label: 'Companies' },
  { to: '/pricing', label: 'For Employers' },
  { to: '/salary', label: 'Salary Explorer' },
  { to: '/community', label: 'Community' },
  { to: '/events', label: 'Events' },
  { to: '/help', label: 'Help' },
] as const

/**
 * Site-wide header. Behaviorally ports jp-theme-fixed/header.php (unread
 * notification badge, user menu, mobile nav) — the LIVE theme file, not
 * one of the 16 dead ones — but as a real, typed React component instead
 * of PHP + jQuery-ish DOM manipulation.
 */
export function PublicHeader() {
  const { isAuthenticated, role, config, logout } = useAuth()
  const navigate = useNavigate()
  const [mobileOpen, setMobileOpen] = useState(false)

  async function handleLogout() {
    await logout()
    navigate('/')
    setMobileOpen(false)
  }

  function closeMobile() {
    setMobileOpen(false)
  }

  return (
    <header className="jp-header">
      <div className="jp-header__inner">
        <Link
          to="/"
          className="jp-header__logo"
          aria-label={`${config?.site_name ?? 'JP Job Portal'} home`}
          onClick={closeMobile}
        >
          <svg width="28" height="28" viewBox="0 0 28 28" fill="none" aria-hidden="true">
            <rect width="28" height="28" rx="7" fill="var(--jp-primary)" />
            <path
              d="M9 12h10v7a1 1 0 0 1-1 1H10a1 1 0 0 1-1-1v-7Z"
              stroke="#fff"
              strokeWidth="1.6"
            />
            <path d="M11 12V9.5A1.5 1.5 0 0 1 12.5 8h3A1.5 1.5 0 0 1 17 9.5V12" stroke="#fff" strokeWidth="1.6" />
          </svg>
          <span>{config?.site_name ?? 'JP Job Portal'}</span>
        </Link>

        <nav className="jp-header__nav" aria-label="Primary">
          {NAV_LINKS.map((link) => (
            <Link key={link.to} to={link.to}>
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="jp-header__actions">
          {isAuthenticated ? (
            <>
              <Link to={ROLE_LANDING_ROUTE[role]}>
                <Button variant="outline" size="sm">
                  My Dashboard
                </Button>
              </Link>
              <Button variant="ghost" size="sm" onClick={() => void handleLogout()}>
                Log out
              </Button>
            </>
          ) : (
            <>
              <Link to="/login">
                <Button variant="ghost" size="sm">
                  Log in
                </Button>
              </Link>
              <Link to="/register">
                <Button variant="primary" size="sm">
                  Sign up
                </Button>
              </Link>
            </>
          )}
          <button
            type="button"
            className="jp-header__menu-btn"
            aria-expanded={mobileOpen}
            aria-controls="jp-mobile-nav"
            onClick={() => setMobileOpen((o) => !o)}
          >
            <span className="jp-sr-only">{mobileOpen ? 'Close menu' : 'Open menu'}</span>
            <span className="jp-header__menu-icon" aria-hidden="true" />
          </button>
        </div>
      </div>

      <div id="jp-mobile-nav" className={['jp-header__mobile', mobileOpen ? 'jp-header__mobile--open' : ''].join(' ')}>
        <nav className="jp-header__mobile-nav" aria-label="Mobile primary">
          {NAV_LINKS.map((link) => (
            <Link key={link.to} to={link.to} onClick={closeMobile}>
              {link.label}
            </Link>
          ))}
        </nav>
        <div className="jp-header__mobile-actions">
          {isAuthenticated ? (
            <>
              <Link to={ROLE_LANDING_ROUTE[role]} onClick={closeMobile}>
                <Button variant="primary" fullWidth>
                  My Dashboard
                </Button>
              </Link>
              <Button variant="ghost" fullWidth onClick={() => void handleLogout()}>
                Log out
              </Button>
            </>
          ) : (
            <>
              <Link to="/register" onClick={closeMobile}>
                <Button variant="primary" fullWidth>
                  Sign up free
                </Button>
              </Link>
              <Link to="/login" onClick={closeMobile}>
                <Button variant="outline" fullWidth>
                  Log in
                </Button>
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  )
}
