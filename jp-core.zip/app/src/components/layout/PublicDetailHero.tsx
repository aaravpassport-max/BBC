import type { ReactNode } from 'react'
import { Breadcrumbs, type Crumb } from '@/components/ui/Breadcrumbs'
import './PublicDetailHero.css'

export interface PublicDetailHeroProps {
  breadcrumbs?: Crumb[]
  title: string
  meta?: ReactNode
  badges?: ReactNode
  actions?: ReactNode
  side?: ReactNode
  coverUrl?: string | null
  logoUrl?: string | null
  logoFallback?: string
}

export function PublicDetailHero({
  breadcrumbs,
  title,
  meta,
  badges,
  actions,
  side,
  coverUrl,
  logoUrl,
  logoFallback,
}: PublicDetailHeroProps) {
  const showBrand = Boolean(logoUrl || logoFallback)
  const hasSideColumn = Boolean(side || actions)

  return (
    <section className="jp-public-detail-hero">
      {coverUrl && (
        <div className="jp-public-detail-hero__cover" aria-hidden="true">
          <img src={coverUrl} alt="" className="jp-public-detail-hero__cover-img" />
        </div>
      )}
      <div className="jp-public-detail-hero__inner">
        {breadcrumbs && breadcrumbs.length > 0 && <Breadcrumbs items={breadcrumbs} />}
        <div className={['jp-public-detail-hero__grid', !hasSideColumn ? 'jp-public-detail-hero__grid--single' : ''].filter(Boolean).join(' ')}>
          <div className="jp-public-detail-hero__main">
            {showBrand && (
              <div className="jp-public-detail-hero__brand">
                {logoUrl ? (
                  <img src={logoUrl} alt="" className="jp-public-detail-hero__logo" />
                ) : (
                  <span className="jp-public-detail-hero__logo jp-public-detail-hero__logo--fallback">{logoFallback}</span>
                )}
                {meta && <p className="jp-public-detail-hero__meta">{meta}</p>}
              </div>
            )}
            {!showBrand && meta && <p className="jp-public-detail-hero__meta jp-public-detail-hero__meta--solo">{meta}</p>}
            <h1 className="jp-public-detail-hero__title">{title}</h1>
            {badges && <div className="jp-public-detail-hero__badges">{badges}</div>}
            {actions && !hasSideColumn && (
              <div className="jp-public-detail-hero__actions jp-public-detail-hero__actions--inline">{actions}</div>
            )}
          </div>
          {hasSideColumn && (
            <div className="jp-public-detail-hero__side">
              {side}
              {actions && <div className="jp-public-detail-hero__actions">{actions}</div>}
            </div>
          )}
        </div>
      </div>
    </section>
  )
}
