import type { ReactNode } from 'react'
import './WorkspacePageHeader.css'

interface WorkspacePageHeaderProps {
  title: ReactNode
  subtitle?: ReactNode
  actions?: ReactNode
  stats?: ReactNode
  tone?: 'candidate' | 'recruiter' | 'admin'
}

/** In-app page header for dashboard, recruiter, and admin routes (below global nav + side nav). */
export function WorkspacePageHeader({
  title,
  subtitle,
  actions,
  stats,
  tone = 'candidate',
}: WorkspacePageHeaderProps) {
  return (
    <header className={['jp-workspace-hero', `jp-workspace-hero--${tone}`].join(' ')}>
      <div className="jp-workspace-hero__row">
        <div className="jp-workspace-hero__titles">
          <h1 className="jp-workspace-hero__title">{title}</h1>
          {subtitle && <p className="jp-workspace-hero__subtitle">{subtitle}</p>}
        </div>
        {actions && <div className="jp-workspace-hero__actions">{actions}</div>}
      </div>
      {stats && <div className="jp-workspace-hero__stats">{stats}</div>}
    </header>
  )
}
