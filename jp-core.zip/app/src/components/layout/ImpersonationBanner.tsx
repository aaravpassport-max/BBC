import { useNavigate } from 'react-router-dom'
import { useMutation } from '@tanstack/react-query'
import { impersonateStop } from '@/features/admin/api'
import { useAuth } from '@/lib/auth/AuthContext'
import { useToast } from '@/components/ui/ToastProvider'

/** sessionStorage key set by AdminUsersPage.tsx when an impersonation session starts. */
export const IMPERSONATION_FLAG_KEY = 'jp_impersonating'

/**
 * Persistent, unmissable banner shown on every page while the current
 * session is an active admin impersonation. Root-cause fix (found while
 * auditing the still-pending WP-Admin-only settings areas — "Privacy/
 * Offboarding"): JP_Privacy's impersonation feature already time-boxes and
 * audit-logs sessions server-side, but there was no REST route OR any
 * client UI for it at all — an admin starting one from this SPA would have
 * no visible indication they'd swapped identity, and no way back short of
 * waiting up to 30 minutes for the server-side auto-expiry to kick in.
 * This reads a plain sessionStorage flag (set by AdminUsersPage.tsx on a
 * successful start) rather than a server-sourced field, because the
 * server-side signal that actually matters (whether THIS request is inside
 * an active, non-expired impersonation window) already governs everything
 * that counts — the flag here is purely "should this banner render," and
 * being wrong in the direction of showing it one extra page load if
 * impersonation already auto-expired server-side costs nothing but a
 * slightly stale banner until the next "Stop" click, which clears it either way.
 */
export function ImpersonationBanner() {
  const toast = useToast()
  const navigate = useNavigate()
  const { refresh } = useAuth()

  const isImpersonating =
    typeof window !== 'undefined' && sessionStorage.getItem(IMPERSONATION_FLAG_KEY) === '1'

  const stopMutation = useMutation({
    mutationFn: impersonateStop,
    onSuccess: async () => {
      sessionStorage.removeItem(IMPERSONATION_FLAG_KEY)
      await refresh()
      navigate('/admin/users')
    },
    onError: () => {
      // Even on a network failure, clear the local flag and refresh — the
      // server-side session state is the source of truth either way, and
      // leaving a stale banner up when the user believes they clicked
      // "Stop" is worse than a refresh that reveals the real state.
      sessionStorage.removeItem(IMPERSONATION_FLAG_KEY)
      void refresh()
      toast.error('Could not confirm impersonation stopped — refreshing to check current session.')
    },
  })

  if (!isImpersonating) return null

  return (
    <div
      role="alert"
      style={{
        background: '#7c2d12',
        color: '#fff',
        padding: '8px 16px',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        gap: 12,
        fontSize: 13,
      }}
    >
      <span>You are impersonating another user. Actions you take are logged against this session.</span>
      <button
        type="button"
        onClick={() => stopMutation.mutate()}
        disabled={stopMutation.isPending}
        style={{
          background: '#fff',
          color: '#7c2d12',
          border: 'none',
          borderRadius: 4,
          padding: '4px 12px',
          fontSize: 13,
          fontWeight: 600,
          cursor: 'pointer',
        }}
      >
        {stopMutation.isPending ? 'Stopping…' : 'Stop impersonating'}
      </button>
    </div>
  )
}
