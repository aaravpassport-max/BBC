import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getMarketInsights } from '@/features/market/api'
import './AuthShell.css'

interface AuthShellProps {
  title: string
  lead?: string
  children: ReactNode
  footer?: ReactNode
  wide?: boolean
  /** Register-style multi-column forms render in a fluid panel without the inner card. */
  layout?: 'card' | 'fluid'
}

export function AuthShell({ title, lead, children, footer, wide, layout = 'card' }: AuthShellProps) {
  const { data: insights } = useQuery({ queryKey: ['market-insights'], queryFn: getMarketInsights, retry: false })

  return (
    <div className="jp-auth-shell">
      <aside className="jp-auth-shell__brand" aria-label="Platform overview">
        <Link to="/" className="jp-auth-shell__logo">
          JP Job Portal
        </Link>
        <h2 className="jp-auth-shell__pitch">Where hiring moves fast — for candidates and teams.</h2>
        <ul className="jp-auth-shell__points">
          <li>Search roles with filters that behave like a product</li>
          <li>Track applications, interviews, and offers in one workspace</li>
          <li>Post jobs and manage pipelines without leaving the platform</li>
        </ul>
        {insights && (
          <dl className="jp-auth-shell__metrics">
            <div>
              <dt>Active jobs</dt>
              <dd>{insights.stats.active_jobs.toLocaleString()}</dd>
            </div>
            <div>
              <dt>Companies hiring</dt>
              <dd>{insights.stats.companies_hiring.toLocaleString()}</dd>
            </div>
            <div>
              <dt>New today</dt>
              <dd>{insights.stats.new_jobs_today.toLocaleString()}</dd>
            </div>
          </dl>
        )}
      </aside>
      <div className={['jp-auth-shell__panel', wide ? 'jp-auth-shell__panel--wide' : ''].filter(Boolean).join(' ')}>
        {layout === 'fluid' ? (
          <div className="jp-auth-shell__fluid">
            <h1 className="jp-auth-shell__title">{title}</h1>
            {lead && <p className="jp-auth-shell__lead">{lead}</p>}
            {children}
            {footer}
          </div>
        ) : (
          <div className="jp-auth-shell__card">
            <h1 className="jp-auth-shell__title">{title}</h1>
            {lead && <p className="jp-auth-shell__lead">{lead}</p>}
            {children}
            {footer}
          </div>
        )}
      </div>
    </div>
  )
}
