import type { ReactNode } from 'react'
import './PublicPageHero.css'

type PublicPageHeroTone = 'default' | 'primary' | 'dark' | 'accent' | 'muted'

interface PublicPageHeroProps {
  eyebrow?: string
  title: ReactNode
  subtitle?: ReactNode
  stats?: ReactNode
  actions?: ReactNode
  tone?: PublicPageHeroTone
  children?: ReactNode
}

export function PublicPageHero({
  eyebrow,
  title,
  subtitle,
  stats,
  actions,
  tone = 'default',
  children,
}: PublicPageHeroProps) {
  return (
    <header className={['jp-page-hero', `jp-page-hero--${tone}`].join(' ')}>
      <div className="jp-page-hero__inner">
        {eyebrow && <p className="jp-page-hero__eyebrow">{eyebrow}</p>}
        <div className="jp-page-hero__head">
          <div className="jp-page-hero__titles">
            <h1 className="jp-page-hero__title">{title}</h1>
            {subtitle && <p className="jp-page-hero__subtitle">{subtitle}</p>}
          </div>
          {actions && <div className="jp-page-hero__actions">{actions}</div>}
        </div>
        {stats && <div className="jp-page-hero__stats">{stats}</div>}
        {children && <div className="jp-page-hero__slot">{children}</div>}
      </div>
    </header>
  )
}
