import { NavLink, Outlet } from 'react-router-dom'
import './DashboardLayout.css'

/**
 * Shared shell for every candidate dashboard sub-page (Phase 1) — sidebar
 * nav + <Outlet/>. Kept separate from the top-level App layout so the
 * public header stays visible above it, matching how the old theme's
 * dashboard.php nested inside the site chrome rather than replacing it.
 */
export function DashboardLayout({ basePath, links }: { basePath: string; links: { to: string; label: string }[] }) {
  return (
    <div className="jp-dash-layout">
      <nav className="jp-dash-nav">
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={`${basePath}${link.to}`}
            end={link.to === ''}
            className={({ isActive }) => `jp-dash-nav__link${isActive ? ' is-active' : ''}`}
          >
            {link.label}
          </NavLink>
        ))}
      </nav>
      <div className="jp-dash-content">
        <Outlet />
      </div>
    </div>
  )
}
