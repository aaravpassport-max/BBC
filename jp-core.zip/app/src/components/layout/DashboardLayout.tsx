import { NavLink, Outlet, useLocation } from 'react-router-dom'
import './DashboardLayout.css'

/**
 * Shared shell for every candidate dashboard sub-page (Phase 1) — sidebar
 * nav + <Outlet/>. Kept separate from the top-level App layout so the
 * public header stays visible above it, matching how the old theme's
 * dashboard.php nested inside the site chrome rather than replacing it.
 */
export function DashboardLayout({ basePath, links }: { basePath: string; links: { to: string; label: string }[] }) {
  const location = useLocation()
  const isRecruiter = location.pathname.includes('/recruiter')
  const isAdmin = location.pathname.includes('/admin')
  const sectionLabel = isRecruiter ? 'Recruiter workspace' : isAdmin ? 'Admin console' : 'Candidate workspace'
  const shellTone = isRecruiter ? 'recruiter' : isAdmin ? 'admin' : 'candidate'

  return (
    <div className={`jp-dash-layout jp-workspace-shell jp-workspace-shell--${shellTone}`}>
      <aside className="jp-dash-nav" aria-label="Workspace navigation">
        <p className="jp-dash-nav__heading">{sectionLabel}</p>
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={`${basePath}${link.to}`}
            end={link.to === ''}
            className={({ isActive }) => `jp-dash-nav__link${isActive ? ' is-active' : ''}`}
          >
            {link.label}
          </NavLink>
        ))}
      </aside>
      <div className="jp-dash-content">
        <Outlet />
      </div>
    </div>
  )
}
