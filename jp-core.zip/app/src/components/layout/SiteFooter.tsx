import { Link } from 'react-router-dom'
import { useAuth } from '@/lib/auth/AuthContext'
import { ROLE_LANDING_ROUTE } from '@/lib/auth/types'
import './SiteFooter.css'

/**
 * Root-cause fix: this app had NO footer anywhere — App.tsx renders only
 * PublicHeader + <main>, confirmed by grepping the entire app/src tree for
 * "<footer" and "jp-footer" and finding zero matches. Every page (including
 * the homepage, which otherwise has real, populated sections — stats,
 * latest jobs, trending skills, top companies, browse-by-type/city,
 * how-it-works) simply stopped rendering after its last section with no
 * closing site chrome, which is exactly what makes an otherwise-complete
 * page feel like an unfinished prototype. Rendered once, site-wide, in
 * App.tsx below the routed <main> (not per-page) so every one of the 67
 * pages gets it automatically and consistently, matching how PublicHeader
 * already works.
 *
 * Every link below routes to a real page that already exists in router.tsx
 * — nothing here is a dead/fabricated link. "For Employers" section mirrors
 * PublicHeader's existing employer-facing nav. The dashboard link resolves
 * to the signed-in user's own real role-landing route (same map
 * PublicHeader/NotFoundPage already use), or to /login when signed out.
 */
export function SiteFooter() {
  const { isAuthenticated, role, config } = useAuth()
  const year = new Date().getFullYear()
  const siteName = config?.site_name ?? 'JP Job Portal'
  const dashboardHref = isAuthenticated ? ROLE_LANDING_ROUTE[role] : '/login'

  return (
    <footer className="jp-footer">
      <div className="jp-footer__inner">
        <div className="jp-footer__grid">
          <div className="jp-footer__brand">
            <Link to="/" className="jp-footer__logo" aria-label={`${siteName} home`}>
              <svg width="24" height="24" viewBox="0 0 28 28" fill="none" aria-hidden="true">
                <rect width="28" height="28" rx="7" fill="var(--jp-primary)" />
                <path d="M9 12h10v7a1 1 0 0 1-1 1H10a1 1 0 0 1-1-1v-7Z" stroke="#fff" strokeWidth="1.6" />
                <path d="M11 12V9.5A1.5 1.5 0 0 1 12.5 8h3A1.5 1.5 0 0 1 17 9.5V12" stroke="#fff" strokeWidth="1.6" />
              </svg>
              <span>{siteName}</span>
            </Link>
            <p className="jp-footer__tagline">
              Find your next role, or your next hire — jobs, salary benchmarks, and a hiring workspace in one place.
            </p>
            <div className="jp-footer__social">
              <a href="https://linkedin.com" target="_blank" rel="noreferrer noopener" aria-label="LinkedIn">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M20.45 20.45h-3.56v-5.57c0-1.33-.02-3.04-1.85-3.04-1.85 0-2.14 1.45-2.14 2.94v5.67H9.34V9h3.42v1.56h.05c.48-.9 1.64-1.85 3.38-1.85 3.6 0 4.27 2.37 4.27 5.46v6.28ZM5.34 7.43a2.07 2.07 0 1 1 0-4.14 2.07 2.07 0 0 1 0 4.14ZM7.12 20.45H3.56V9h3.56v11.45Z" />
                </svg>
              </a>
              <a href="https://twitter.com" target="_blank" rel="noreferrer noopener" aria-label="X (Twitter)">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M18.9 2.9h3.1l-6.8 7.7 8 10.5h-6.3l-4.9-6.4-5.6 6.4H3.3l7.2-8.3-7.7-9.9h6.5l4.4 5.9 5.2-5.9Zm-1.1 16.3h1.7L7.2 4.7H5.4l12.4 14.5Z" />
                </svg>
              </a>
              <a href="https://facebook.com" target="_blank" rel="noreferrer noopener" aria-label="Facebook">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
                  <path d="M13.5 21.9v-8.4h2.8l.4-3.3h-3.2V8.1c0-.95.27-1.6 1.63-1.6h1.74V3.56A23.6 23.6 0 0 0 14.3 3.4c-2.5 0-4.2 1.53-4.2 4.34v2.42H7.3v3.3h2.8v8.44h3.4Z" />
                </svg>
              </a>
            </div>
          </div>

          <nav className="jp-footer__col" aria-labelledby="jp-footer-heading-candidates">
            <h3 id="jp-footer-heading-candidates">For job seekers</h3>
            <Link to="/jobs">Browse jobs</Link>
            <Link to="/companies">Browse companies</Link>
            <Link to="/salary">Salary explorer</Link>
            <Link to="/community">Community</Link>
            <Link to="/events">Events</Link>
            <Link to={dashboardHref}>My dashboard</Link>
          </nav>

          <nav className="jp-footer__col" aria-labelledby="jp-footer-heading-employers">
            <h3 id="jp-footer-heading-employers">For employers</h3>
            <Link to="/pricing">Pricing &amp; plans</Link>
            <Link to="/recruiter">Recruiter workspace</Link>
            <Link to="/recruiter/jobs/new">Post a job</Link>
            <Link to="/recruiter/candidates">Find candidates</Link>
            <Link to="/recruiter/events">Host an event</Link>
          </nav>

          <nav className="jp-footer__col" aria-labelledby="jp-footer-heading-resources">
            <h3 id="jp-footer-heading-resources">Resources</h3>
            <Link to="/help">Help center</Link>
            <Link to="/changelog">What&apos;s new</Link>
            <Link to="/community">Discussions</Link>
          </nav>

          <nav className="jp-footer__col" aria-labelledby="jp-footer-heading-account">
            <h3 id="jp-footer-heading-account">Account</h3>
            {isAuthenticated ? (
              <Link to={dashboardHref}>My dashboard</Link>
            ) : (
              <>
                <Link to="/login">Log in</Link>
                <Link to="/register">Create account</Link>
              </>
            )}
            <Link to="/help">Contact support</Link>
          </nav>
        </div>

        <div className="jp-footer__bottom">
          <p>&copy; {year} {siteName}. All rights reserved.</p>
          <div className="jp-footer__bottom-links">
            <Link to="/help">Help</Link>
            <Link to="/changelog">Changelog</Link>
          </div>
        </div>
      </div>
    </footer>
  )
}
