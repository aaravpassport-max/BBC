import { Link } from 'react-router-dom'
import type { JobRow } from '@/features/jobs/api'
import { Badge } from '@/components/ui/Badge'
import { formatExperience, formatJobSalary, formatJobType, formatPostedRelative, jobLocationLabel } from '@/lib/jobs/format'
import './JobCard.css'

export type JobCardVariant = 'list' | 'grid'

interface JobCardProps {
  job: JobRow
  variant?: JobCardVariant
  className?: string
  onNavigate?: () => void
}

export function JobCard({ job, variant = 'list', className, onNavigate }: JobCardProps) {
  const salary = formatJobSalary(job.salary_min, job.salary_max, job.salary_currency, job.salary_visible)
  const experience = formatExperience(job.experience_min, job.experience_max)
  const posted = formatPostedRelative(job.created_at)
  const location = jobLocationLabel(job)

  const classes = ['jp-job-card', `jp-job-card--${variant}`, className ?? ''].filter(Boolean).join(' ')

  return (
    <Link to={`/jobs/${job.id}`} className={classes} onClick={onNavigate}>
      <div className="jp-job-card__top">
        <div className="jp-job-card__brand" aria-hidden="true">
          {job.logo_url ? (
            <img src={job.logo_url} alt="" className="jp-job-card__logo" loading="lazy" />
          ) : (
            <span className="jp-job-card__logo jp-job-card__logo--fallback">{job.company_name?.[0] ?? '?'}</span>
          )}
        </div>
        <div className="jp-job-card__head">
          <h2 className="jp-job-card__title">{job.title}</h2>
          <p className="jp-job-card__company">
            {job.company_name}
            {job.company_verified === 1 && (
              <span className="jp-job-card__verified" title="Verified company">
                ✓
              </span>
            )}
          </p>
          <p className="jp-job-card__meta">
            {location} · {formatJobType(job.job_type)} · {job.work_mode}
            {experience ? ` · ${experience}` : ''}
          </p>
        </div>
        {salary && <p className="jp-job-card__salary">{salary}</p>}
      </div>

      <div className="jp-job-card__footer">
        <div className="jp-job-card__badges">
          {job.is_featured === 1 && <Badge variant="accent">Featured</Badge>}
          {job.is_urgent === 1 && <Badge variant="error">Urgent</Badge>}
          {job.work_mode === 'remote' && <Badge variant="info">Remote</Badge>}
          {job.applications_cnt > 0 && variant === 'list' && (
            <Badge variant="gray">{job.applications_cnt} applicants</Badge>
          )}
        </div>
        <span className="jp-job-card__cta">
          {posted || 'View role'}
          <span className="jp-job-card__cta-arrow" aria-hidden="true">
            →
          </span>
        </span>
      </div>
    </Link>
  )
}
