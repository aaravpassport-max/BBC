import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import type { JobRow } from '@/features/jobs/api'
import type { CompanyRow } from '@/features/companies/api'
import { Badge } from '@/components/ui/Badge'
import { Breadcrumbs } from '@/components/ui/Breadcrumbs'
import { formatJobSalary, formatPostedRelative, jobLocationLabel } from '@/lib/jobs/format'
import './JobDetailHero.css'

interface JobDetailHeroProps {
  job: JobRow
  company?: CompanyRow | null
  actions?: ReactNode
}

export function JobDetailHero({ job, company, actions }: JobDetailHeroProps) {
  const salary = formatJobSalary(job.salary_min, job.salary_max, job.salary_currency, job.salary_visible)
  const location = jobLocationLabel(job)
  const posted = formatPostedRelative(job.created_at)

  return (
    <section className="jp-job-hero">
      <div className="jp-job-hero__inner">
        <Breadcrumbs
          items={[
            { label: 'Jobs', to: '/jobs' },
            { label: job.company_name, to: `/companies/${job.company_id}` },
            { label: job.title },
          ]}
        />
        <div className="jp-job-hero__grid">
          <div className="jp-job-hero__main">
            <div className="jp-job-hero__brand">
              {company?.logo_url || job.logo_url ? (
                <img src={(company?.logo_url || job.logo_url)!} alt="" className="jp-job-hero__logo" />
              ) : (
                <span className="jp-job-hero__logo jp-job-hero__logo--fallback">{job.company_name[0]}</span>
              )}
              <div>
                <p className="jp-job-hero__company">
                  {job.company_name}
                  {job.company_verified === 1 && <span className="jp-job-hero__verified">Verified</span>}
                </p>
                <p className="jp-job-hero__meta">
                  {location} · {job.job_type} · {job.work_mode}
                  {posted ? ` · ${posted}` : ''}
                </p>
              </div>
            </div>
            <h1 className="jp-job-hero__title">{job.title}</h1>
            <div className="jp-job-hero__badges">
              {job.is_featured === 1 && <Badge variant="accent">Featured</Badge>}
              {job.is_urgent === 1 && <Badge variant="error">Urgent</Badge>}
              {job.work_mode === 'remote' && <Badge variant="info">Remote</Badge>}
              {job.applications_cnt > 0 && (
                <Badge variant="gray">
                  {job.applications_cnt} applicant{job.applications_cnt === 1 ? '' : 's'}
                </Badge>
              )}
            </div>
          </div>
          <div className="jp-job-hero__side">
            {salary && <p className="jp-job-hero__salary">{salary}</p>}
            {actions && <div className="jp-job-hero__actions">{actions}</div>}
            <Link to={`/companies/${job.company_id}`} className="jp-job-hero__company-link">
              View company →
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}
