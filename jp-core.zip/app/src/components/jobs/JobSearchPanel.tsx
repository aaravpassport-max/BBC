import { type FormEvent, type ReactNode } from 'react'
import { Link } from 'react-router-dom'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import './JobSearchPanel.css'

export interface JobSearchPanelProps {
  q: string
  location: string
  onQChange: (value: string) => void
  onLocationChange: (value: string) => void
  onSubmit: (e: FormEvent) => void
  submitLabel?: string
  popularSearches?: string[]
  hint?: ReactNode
  compact?: boolean
}

export function JobSearchPanel({
  q,
  location,
  onQChange,
  onLocationChange,
  onSubmit,
  submitLabel = 'Search jobs',
  popularSearches,
  hint,
  compact,
}: JobSearchPanelProps) {
  return (
    <div className={['jp-job-search', compact ? 'jp-job-search--compact' : ''].filter(Boolean).join(' ')}>
      <form className="jp-job-search__form" onSubmit={onSubmit}>
        <div className="jp-job-search__fields">
          <Input
            aria-label="Job title or keyword"
            placeholder="Role, skill, or company"
            value={q}
            onChange={(e) => onQChange(e.target.value)}
          />
          <Input
            aria-label="Location"
            placeholder="City or remote"
            value={location}
            onChange={(e) => onLocationChange(e.target.value)}
          />
        </div>
        <Button type="submit" variant="accent" className="jp-job-search__submit">
          {submitLabel}
        </Button>
      </form>
      {hint && <p className="jp-job-search__hint">{hint}</p>}
      {popularSearches && popularSearches.length > 0 && (
        <div className="jp-job-search__popular">
          <span className="jp-job-search__popular-label">Popular:</span>
          <div className="jp-job-search__popular-links">
            {popularSearches.map((term) => (
              <Link key={term} to={`/jobs?q=${encodeURIComponent(term)}`} className="jp-job-search__popular-link">
                {term}
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}
