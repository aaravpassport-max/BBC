import './ActiveFilterChips.css'

const FILTER_LABELS: Record<string, string> = {
  q: 'Keyword',
  location: 'Location',
  job_type: 'Type',
  work_mode: 'Mode',
  exp: 'Experience',
  sal_min: 'Min salary',
  skills: 'Skills',
  order_by: 'Sort',
}

interface ActiveFilterChipsProps {
  searchParams: URLSearchParams
  onClearKey: (key: string) => void
  onClearAll: () => void
}

export function ActiveFilterChips({ searchParams, onClearKey, onClearAll }: ActiveFilterChipsProps) {
  const keys = ['q', 'location', 'job_type', 'work_mode', 'exp', 'sal_min', 'skills', 'order_by']
  const active = keys.filter((k) => searchParams.get(k))

  if (active.length === 0) return null

  return (
    <div className="jp-filter-chips" role="region" aria-label="Active filters">
      {active.map((key) => {
        const value = searchParams.get(key) ?? ''
        return (
          <button key={key} type="button" className="jp-filter-chip" onClick={() => onClearKey(key)}>
            <span className="jp-filter-chip__label">{FILTER_LABELS[key] ?? key}</span>
            <span className="jp-filter-chip__value">{value}</span>
            <span className="jp-filter-chip__remove" aria-hidden="true">
              ×
            </span>
            <span className="jp-sr-only">Remove {FILTER_LABELS[key] ?? key} filter</span>
          </button>
        )
      })}
      <button type="button" className="jp-filter-chip jp-filter-chip--clear" onClick={onClearAll}>
        Clear all
      </button>
    </div>
  )
}
