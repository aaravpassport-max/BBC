import './Skeleton.css'

/**
 * Sized skeleton placeholder — the fix for the layout-jump/CLS problem
 * discussed while planning this rebuild: a skeleton must occupy the same
 * space the real content will, not a generic spinner of arbitrary size.
 * Every list/card screen renders N of these, shaped like the real row/card,
 * while data loads — never a bare "Loading…" string.
 */
export function Skeleton({
  width = '100%',
  height = '1em',
  radius = 'var(--jp-radius-sm)',
  className,
}: {
  width?: string | number
  height?: string | number
  radius?: string
  className?: string
}) {
  return (
    <div
      className={['jp-skeleton', className ?? ''].filter(Boolean).join(' ')}
      style={{ width, height, borderRadius: radius }}
      aria-hidden="true"
    />
  )
}

/** A skeleton shaped like a .jp-card job/candidate list row, used across Jobs, Candidates, Applications lists. */
export function CardSkeleton() {
  return (
    <div className="jp-card jp-card__body" aria-hidden="true">
      <Skeleton width="60%" height={18} />
      <div style={{ height: 10 }} />
      <Skeleton width="40%" height={14} />
      <div style={{ height: 14 }} />
      <Skeleton width="100%" height={14} />
      <div style={{ height: 6 }} />
      <Skeleton width="90%" height={14} />
    </div>
  )
}

/**
 * Phase 2 (redesign-plan cross-cutting gap #5) — several list pages fell
 * back to a single generic <Skeleton> block instead of a placeholder shaped
 * like the layout that will actually render, which reads as a visible
 * "flash" the instant real content replaces it. These three match the three
 * layouts used across the app (stacked list rows, card grids, data tables)
 * so the loading state occupies the same shape as the loaded state.
 */
export function ListSkeleton({ rows = 5 }: { rows?: number }) {
  return (
    <div className="jp-skeleton-list" aria-hidden="true">
      {Array.from({ length: rows }).map((_, i) => (
        <div className="jp-skeleton-list__row" key={i}>
          <Skeleton width={40} height={40} radius="var(--jp-radius-full)" />
          <div className="jp-skeleton-list__lines">
            <Skeleton width="45%" height={14} />
            <Skeleton width="70%" height={12} />
          </div>
        </div>
      ))}
    </div>
  )
}

export function GridSkeleton({ items = 6 }: { items?: number }) {
  return (
    <div className="jp-skeleton-grid" aria-hidden="true">
      {Array.from({ length: items }).map((_, i) => (
        <CardSkeleton key={i} />
      ))}
    </div>
  )
}

export function TableSkeleton({ rows = 6, columns = 4 }: { rows?: number; columns?: number }) {
  return (
    <div className="jp-skeleton-table" aria-hidden="true">
      {Array.from({ length: rows }).map((_, r) => (
        <div
          className="jp-skeleton-table__row"
          key={r}
          style={{ gridTemplateColumns: `repeat(${columns}, 1fr)` }}
        >
          {Array.from({ length: columns }).map((_, c) => (
            <Skeleton key={c} width={c === 0 ? '80%' : '60%'} height={14} />
          ))}
        </div>
      ))}
    </div>
  )
}
