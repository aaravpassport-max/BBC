import { forwardRef, type InputHTMLAttributes } from 'react'
import './Input.css'

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  label?: string
  error?: string
  hint?: string
}

let uid = 0
function useId(explicit?: string) {
  const ref = explicit ?? `jp-field-${++uid}`
  return ref
}

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { label, error, hint, id, className, ...rest },
  ref,
) {
  const fieldId = useId(id)
  return (
    <div className="jp-form-group">
      {label && (
        <label className="jp-label" htmlFor={fieldId}>
          {label}
        </label>
      )}
      <input
        ref={ref}
        id={fieldId}
        className={['jp-input', error ? 'is-error' : '', className ?? ''].filter(Boolean).join(' ')}
        aria-invalid={!!error}
        aria-describedby={error ? `${fieldId}-error` : hint ? `${fieldId}-hint` : undefined}
        {...rest}
      />
      {error && (
        <p id={`${fieldId}-error`} className="jp-form-error" role="alert">
          {error}
        </p>
      )}
      {!error && hint && (
        <p id={`${fieldId}-hint`} className="jp-form-hint">
          {hint}
        </p>
      )}
    </div>
  )
})
