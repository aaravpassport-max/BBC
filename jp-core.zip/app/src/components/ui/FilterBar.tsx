import type { ReactNode } from 'react'
import './FilterBar.css'

interface FilterBarProps {
  /** The search input, typically an <Input> with a debounce handler already wired by the caller. */
  search?: ReactNode
  /** One or more <select>/<Input type="date">/custom filter controls. */
  filters?: ReactNode
  /** A sort <select> or similar, visually separated to the trailing edge on wide screens. */
  sort?: ReactNode
  /** Active-filter chips row (rendered below the controls when any filter is non-default). */
  chips?: ReactNode
  className?: string
}

/**
 * Phase 2 (redesign-plan cross-cutting gap #2) — every list page (Jobs,
 * Companies, AdminUsers, AdminPayments, RecruiterCandidates, etc.) was
 * hand-rolling its own search+filter+sort row with inconsistent spacing,
 * wrapping, and mobile behaviour. FilterBar is the one shared layout: search
 * grows to fill available space, filters and sort sit to the right on desktop
 * and wrap onto their own row on narrow screens, and an optional chips row
 * surfaces active non-default filters with a way to clear them individually.
 */
export function FilterBar({ search, filters, sort, chips, className }: FilterBarProps) {
  const hasControls = filters || sort
  return (
    <div className={['jp-filter-bar', className ?? ''].filter(Boolean).join(' ')}>
      <div className="jp-filter-bar__row">
        {search && <div className="jp-filter-bar__search">{search}</div>}
        {hasControls && (
          <div className="jp-filter-bar__controls">
            {filters}
            {sort && <div className="jp-filter-bar__sort">{sort}</div>}
          </div>
        )}
      </div>
      {chips && <div className="jp-filter-bar__chips">{chips}</div>}
    </div>
  )
}

/** A single removable "active filter" chip, e.g. "Location: Bengaluru ×". */
export function FilterChip({ children, onRemove }: { children: ReactNode; onRemove: () => void }) {
  return (
    <button type="button" className="jp-filter-chip" onClick={onRemove}>
      <span>{children}</span>
      <span className="jp-filter-chip__remove" aria-hidden="true">
        ×
      </span>
      <span className="jp-sr-only">Remove filter</span>
    </button>
  )
}
