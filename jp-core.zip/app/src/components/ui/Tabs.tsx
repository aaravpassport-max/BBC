import { useRef, type KeyboardEvent, type ReactNode } from 'react'
import './Tabs.css'

export interface TabItem {
  key: string
  label: ReactNode
  /** Optional trailing count badge, e.g. unread messages or upcoming-events count. */
  count?: number
}

interface TabsProps {
  items: TabItem[]
  activeKey: string
  onChange: (key: string) => void
  className?: string
  /** Accessible label for the tablist as a whole, e.g. "Event filters". */
  label?: string
}

/**
 * Phase 2 (redesign-plan cross-cutting gap #4) — several pages (Events
 * upcoming/past, Community categories, Notifications types,
 * AdminApplications by status) previously faked tabs with individually
 * styled buttons, if they had any grouping at all. This is the one
 * accessible tab primitive every such page now composes from: roving
 * tabindex (only the active tab is in the normal tab order; arrow keys move
 * focus within the group, matching the WAI-ARIA tabs pattern), `aria-selected`,
 * and a `role="tablist"`/`role="tab"` structure so screen readers announce
 * the group and the current selection correctly.
 */
export function Tabs({ items, activeKey, onChange, className, label }: TabsProps) {
  const refs = useRef<Record<string, HTMLButtonElement | null>>({})

  function handleKeyDown(event: KeyboardEvent<HTMLDivElement>) {
    const currentIndex = items.findIndex((item) => item.key === activeKey)
    if (currentIndex === -1) return
    let nextIndex: number | null = null
    if (event.key === 'ArrowRight' || event.key === 'ArrowDown') {
      nextIndex = (currentIndex + 1) % items.length
    } else if (event.key === 'ArrowLeft' || event.key === 'ArrowUp') {
      nextIndex = (currentIndex - 1 + items.length) % items.length
    } else if (event.key === 'Home') {
      nextIndex = 0
    } else if (event.key === 'End') {
      nextIndex = items.length - 1
    }
    if (nextIndex !== null) {
      event.preventDefault()
      const nextKey = items[nextIndex].key
      onChange(nextKey)
      refs.current[nextKey]?.focus()
    }
  }

  return (
    <div
      className={['jp-tabs', className ?? ''].filter(Boolean).join(' ')}
      role="tablist"
      aria-label={label}
      onKeyDown={handleKeyDown}
    >
      {items.map((item) => {
        const isActive = item.key === activeKey
        return (
          <button
            key={item.key}
            ref={(el) => {
              refs.current[item.key] = el
            }}
            type="button"
            role="tab"
            id={`jp-tab-${item.key}`}
            aria-selected={isActive}
            aria-controls={`jp-tabpanel-${item.key}`}
            tabIndex={isActive ? 0 : -1}
            className={['jp-tabs__tab', isActive ? 'is-active' : ''].filter(Boolean).join(' ')}
            onClick={() => onChange(item.key)}
          >
            {item.label}
            {typeof item.count === 'number' && (
              <span className="jp-tabs__count" aria-hidden="true">
                {item.count}
              </span>
            )}
          </button>
        )
      })}
    </div>
  )
}

/** Wraps the panel content for a given tab key — provides the matching id/labelledby/role for AX. */
export function TabPanel({ tabKey, activeKey, children }: { tabKey: string; activeKey: string; children: ReactNode }) {
  if (tabKey !== activeKey) return null
  return (
    <div role="tabpanel" id={`jp-tabpanel-${tabKey}`} aria-labelledby={`jp-tab-${tabKey}`} className="jp-tabs__panel">
      {children}
    </div>
  )
}
