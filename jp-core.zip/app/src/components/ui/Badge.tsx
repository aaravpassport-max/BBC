import type { HTMLAttributes } from 'react'
import './Badge.css'

type Variant = 'primary' | 'accent' | 'success' | 'warning' | 'error' | 'gray' | 'info'

interface BadgeProps extends HTMLAttributes<HTMLSpanElement> {
  variant?: Variant
}

export function Badge({ variant = 'gray', className, children, ...rest }: BadgeProps) {
  const classes = ['jp-badge', `jp-badge--${variant}`, className ?? ''].filter(Boolean).join(' ')
  return (
    <span className={classes} {...rest}>
      {children}
    </span>
  )
}
