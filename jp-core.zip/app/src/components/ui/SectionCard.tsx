import type { ReactNode } from 'react'
import { Card, CardBody } from './Card'
import './SectionCard.css'

interface SectionCardProps {
  title: ReactNode
  icon?: ReactNode
  action?: ReactNode
  children: ReactNode
  className?: string
  id?: string
}

/**
 * Batch 32 — design-system foundation. The audit's core complaint is
 * "detail pages expose raw fields instead of organizing information into
 * logical sections" (item #11). SectionCard is the one titled-content-block
 * primitive every rebuilt detail page (job, application, interview, order)
 * composes its Overview / Documents / Activity / Related sections from,
 * so a detail page reads as a set of purpose-labeled sections rather than
 * one undifferentiated block of fields.
 */
export function SectionCard({ title, icon, action, children, className, id }: SectionCardProps) {
  return (
    <Card id={id} className={['jp-section-card', className ?? ''].filter(Boolean).join(' ')}>
      <div className="jp-section-card__header">
        <h2 className="jp-section-card__title">
          {icon && <span className="jp-section-card__icon" aria-hidden="true">{icon}</span>}
          {title}
        </h2>
        {action && <div className="jp-section-card__action">{action}</div>}
      </div>
      <CardBody className="jp-section-card__body">{children}</CardBody>
    </Card>
  )
}
