import './FullPageSpinner.css'

/** Used only for the two genuinely full-page blocking states: initial auth
 * bootstrap and route-guard redirects — never for in-page data loading,
 * which always uses sized Skeleton/CardSkeleton instead (see Skeleton.tsx). */
export function FullPageSpinner() {
  return (
    <div className="jp-full-spinner" role="status" aria-label="Loading">
      <div className="jp-full-spinner__ring" />
    </div>
  )
}
