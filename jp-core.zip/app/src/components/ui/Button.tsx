import { forwardRef, type ButtonHTMLAttributes } from 'react'
import './Button.css'

type Variant = 'primary' | 'accent' | 'outline' | 'ghost' | 'danger'
type Size = 'sm' | 'md' | 'lg' | 'icon'

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: Variant
  size?: Size
  loading?: boolean
  fullWidth?: boolean
}

/**
 * The one button component every screen uses. `loading` disables the
 * button AND shows a spinner in place of the label — this is the
 * "prevent double-submit" pattern required across the whole app (see
 * JP-PLATFORM-ROADMAP.md Part 5 / the standing audit protocol's "loading
 * states are visible" and "double-click prevention" checks) implemented
 * once here instead of ad hoc in every form.
 */
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  { variant = 'primary', size = 'md', loading = false, fullWidth = false, disabled, className, children, ...rest },
  ref,
) {
  const classes = [
    'jp-btn',
    `jp-btn--${variant}`,
    `jp-btn--${size}`,
    fullWidth ? 'jp-btn--full' : '',
    loading ? 'is-loading' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <button ref={ref} className={classes} disabled={disabled || loading} aria-busy={loading} {...rest}>
      {loading && <span className="jp-btn__spinner" aria-hidden="true" />}
      <span className="jp-btn__label">{children}</span>
    </button>
  )
})
