import type { ReactNode } from 'react'
import './Timeline.css'

export interface TimelineItem {
  id: string | number
  title: ReactNode
  timestamp?: string
  description?: ReactNode
  tone?: 'default' | 'primary' | 'success' | 'warning' | 'error'
  icon?: ReactNode
}

interface TimelineProps {
  items: TimelineItem[]
  emptyLabel?: string
  className?: string
}

/**
 * Batch 32 — design-system foundation. Every "detail page" in the audit
 * (request/application/interview/order) is expected to show activity
 * history, not just current-state fields. Timeline is the shared vertical
 * activity-feed component every detail page now uses for that section
 * instead of a plain <ul> or nothing at all.
 */
export function Timeline({ items, emptyLabel = 'No activity yet.', className }: TimelineProps) {
  if (items.length === 0) {
    return <p className="jp-timeline__empty">{emptyLabel}</p>
  }
  return (
    <ol className={['jp-timeline', className ?? ''].filter(Boolean).join(' ')}>
      {items.map((item) => (
        <li key={item.id} className={`jp-timeline__item jp-timeline__item--${item.tone ?? 'default'}`}>
          <span className="jp-timeline__dot" aria-hidden="true">{item.icon}</span>
          <div className="jp-timeline__content">
            <div className="jp-timeline__row">
              <span className="jp-timeline__title">{item.title}</span>
              {item.timestamp && <span className="jp-timeline__timestamp">{item.timestamp}</span>}
            </div>
            {item.description && <div className="jp-timeline__description">{item.description}</div>}
          </div>
        </li>
      ))}
    </ol>
  )
}
