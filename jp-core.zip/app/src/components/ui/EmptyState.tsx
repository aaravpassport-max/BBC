import type { ReactNode } from 'react'
import './EmptyState.css'

interface EmptyStateProps {
  /** A short SVG/emoji/icon node, or omit for the default neutral glyph. */
  icon?: ReactNode
  title: string
  description?: string
  /** Primary call-to-action, e.g. a <Button> or <Link>. */
  action?: ReactNode
  /** Secondary, lower-emphasis action rendered next to the primary one. */
  secondaryAction?: ReactNode
  className?: string
}

/**
 * Batch 32 — design-system foundation. Every list/table/search-results page
 * in the app previously either rendered nothing when a query came back
 * empty, or a single unstyled line of text ("No jobs found.") — this is
 * exactly the "thin page" / "incomplete state" pattern flagged across the
 * platform audit (states are part of the product design, not an
 * afterthought). One shared component means every empty state in the app
 * now gets the same icon treatment, spacing, and a real next action instead
 * of a dead end.
 */
export function EmptyState({ icon, title, description, action, secondaryAction, className }: EmptyStateProps) {
  return (
    <div className={['jp-empty-state', className ?? ''].filter(Boolean).join(' ')}>
      <div className="jp-empty-state__icon" aria-hidden="true">
        {icon ?? <DefaultEmptyIcon />}
      </div>
      <p className="jp-empty-state__title">{title}</p>
      {description && <p className="jp-empty-state__description">{description}</p>}
      {(action || secondaryAction) && (
        <div className="jp-empty-state__actions">
          {action}
          {secondaryAction}
        </div>
      )}
    </div>
  )
}

function DefaultEmptyIcon() {
  return (
    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M4 7h16M4 7l1.5 12a1 1 0 0 0 1 .9h11a1 1 0 0 0 1-.9L20 7M4 7l2-4h12l2 4M9 11h6"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  )
}

/*
 * Phase 2 (redesign-plan cross-cutting gap #3) — every EmptyState in the app
 * used the identical box-with-lines glyph regardless of context, so "no
 * messages yet" and "no jobs match your filters" looked the same even though
 * they call for different next actions (start a conversation vs. loosen a
 * filter). These three purpose-built icons are meant to be passed as the
 * `icon` prop so a caller picks the one matching *why* the list is empty.
 */
export function NoResultsIcon() {
  return (
    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <circle cx="10.5" cy="10.5" r="6.5" stroke="currentColor" strokeWidth="1.5" />
      <path d="M15.5 15.5L21 21" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <path d="M8 10.5h5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  )
}

export function GenericEmptyIcon() {
  return (
    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <rect x="4" y="4" width="16" height="16" rx="3" stroke="currentColor" strokeWidth="1.5" strokeDasharray="3 3" />
      <path d="M12 9v6M9 12h6" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
    </svg>
  )
}

export function ErrorStateIcon() {
  return (
    <svg width="48" height="48" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path
        d="M12 3l9 16H3l9-16z"
        stroke="currentColor"
        strokeWidth="1.5"
        strokeLinejoin="round"
      />
      <path d="M12 10v4" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      <circle cx="12" cy="17" r="0.9" fill="currentColor" />
    </svg>
  )
}
