import type { HTMLAttributes, KeyboardEvent, MouseEvent as ReactMouseEvent, ReactNode } from 'react'
import './Card.css'

interface CardProps extends HTMLAttributes<HTMLDivElement> {
  clickable?: boolean
  children: ReactNode
}

/**
 * Root-cause fix: two call sites (NotificationsPage, RecruiterCandidatesPage)
 * put `onClick` directly on a `<Card>` to make the whole row interactive —
 * unlike every other `clickable` Card in the app, which wraps the Card in a
 * `<Link>` (making the Link the real focusable/keyboard element and Card's
 * `clickable` purely a visual hint). A `<Card>` is a plain `<div>` under the
 * hood, so those two were mouse-only: no tab stop, no Enter/Space
 * activation, no role announcing them as interactive at all — a WCAG 2.1.1
 * (Keyboard) gap identical in kind to the toast-dismiss one fixed earlier
 * this pass. Fixing it here, once, in the shared component, means any
 * future `<Card onClick={...}>` gets this for free instead of depending on
 * every call site remembering to add it. Only activates when `onClick` is
 * actually supplied — a decorative Card wrapped in a Link (every other
 * usage in the app) never passes onClick, so it renders exactly as before.
 * Both current onClick handlers ignore their event argument, so the
 * keyboard path re-invoking onClick with the originating KeyboardEvent
 * (rather than a real MouseEvent) is safe in practice; the cast reflects
 * that this is a deliberate synthetic-activation bridge, not a type escape
 * hatch used carelessly.
 */
export function Card({ clickable, className, onClick, onKeyDown, role, tabIndex, children, ...rest }: CardProps) {
  const classes = ['jp-card', clickable ? 'jp-card--clickable' : '', className ?? ''].filter(Boolean).join(' ')
  const isInteractive = typeof onClick === 'function'

  function handleKeyDown(e: KeyboardEvent<HTMLDivElement>) {
    onKeyDown?.(e)
    if (isInteractive && !e.defaultPrevented && (e.key === 'Enter' || e.key === ' ')) {
      e.preventDefault()
      onClick?.(e as unknown as ReactMouseEvent<HTMLDivElement>)
    }
  }

  return (
    <div
      className={classes}
      onClick={onClick}
      onKeyDown={isInteractive ? handleKeyDown : onKeyDown}
      role={isInteractive ? (role ?? 'button') : role}
      tabIndex={isInteractive ? (tabIndex ?? 0) : tabIndex}
      {...rest}
    >
      {children}
    </div>
  )
}

export function CardBody({ children, className, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={['jp-card__body', className ?? ''].filter(Boolean).join(' ')} {...rest}>
      {children}
    </div>
  )
}

export function CardHeader({ children, className, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={['jp-card__header', className ?? ''].filter(Boolean).join(' ')} {...rest}>
      {children}
    </div>
  )
}

export function CardFooter({ children, className, ...rest }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div className={['jp-card__footer', className ?? ''].filter(Boolean).join(' ')} {...rest}>
      {children}
    </div>
  )
}
