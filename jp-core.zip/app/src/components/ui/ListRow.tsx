import type { ReactNode } from 'react'
import { Link } from 'react-router-dom'
import './ListRow.css'

interface ListRowProps {
  title: ReactNode
  meta?: ReactNode
  aside?: ReactNode
  to?: string
  onClick?: () => void
}

export function ListRow({ title, meta, aside, to, onClick }: ListRowProps) {
  const className = 'jp-list-row'
  const body = (
    <>
      <div className="jp-list-row__main">
        <p className="jp-list-row__title">{title}</p>
        {meta && <p className="jp-list-row__meta">{meta}</p>}
      </div>
      {aside && <div className="jp-list-row__aside">{aside}</div>}
    </>
  )

  if (to) {
    return (
      <Link to={to} className={className}>
        {body}
      </Link>
    )
  }

  if (onClick) {
    return (
      <button type="button" className={className} onClick={onClick}>
        {body}
      </button>
    )
  }

  return <div className={className}>{body}</div>
}
