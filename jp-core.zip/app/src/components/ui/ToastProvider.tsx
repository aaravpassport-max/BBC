import { createContext, useCallback, useContext, useRef, useState, type ReactNode } from 'react'
import './Toast.css'

type ToastType = 'success' | 'error' | 'warning' | 'info'

interface Toast {
  id: number
  type: ToastType
  message: string
}

interface ToastApi {
  success: (message: string) => void
  error: (message: string) => void
  warning: (message: string) => void
  info: (message: string) => void
}

const ToastContext = createContext<ToastApi | null>(null)

const AUTO_DISMISS_MS = 4000

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([])
  const nextId = useRef(1)

  const dismiss = useCallback((id: number) => {
    setToasts((prev) => prev.filter((t) => t.id !== id))
  }, [])

  const push = useCallback(
    (type: ToastType, message: string) => {
      const id = nextId.current++
      setToasts((prev) => [...prev, { id, type, message }])
      window.setTimeout(() => dismiss(id), AUTO_DISMISS_MS)
    },
    [dismiss],
  )

  const api: ToastApi = {
    success: (m) => push('success', m),
    error: (m) => push('error', m),
    warning: (m) => push('warning', m),
    info: (m) => push('info', m),
  }

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="jp-toast-container" role="status" aria-live="polite">
        {toasts.map((t) => (
          // A <button>, not a clickable <div> — dismissal was previously
          // mouse-only (onClick with no keyboard equivalent), a WCAG 2.1.1
          // (Keyboard) gap: a sighted mouse user could dismiss early, a
          // keyboard user could only wait out the 4s auto-dismiss.
          <button
            key={t.id}
            type="button"
            className={`jp-toast jp-toast--${t.type}`}
            onClick={() => dismiss(t.id)}
            aria-label={`Dismiss notification: ${t.message}`}
          >
            {t.message}
          </button>
        ))}
      </div>
    </ToastContext.Provider>
  )
}

export function useToast(): ToastApi {
  const ctx = useContext(ToastContext)
  if (!ctx) throw new Error('useToast() must be used within <ToastProvider>.')
  return ctx
}
