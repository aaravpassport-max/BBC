import { useEffect, useRef, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import './Modal.css'

interface ModalProps {
  open: boolean
  onClose: () => void
  title?: string
  children: ReactNode
  footer?: ReactNode
}

/**
 * Focus-trapping, Escape-to-close, backdrop-click-to-close modal, ported
 * behaviorally (not code-wise — the old implementation was jQuery-ish
 * vanilla JS with no focus trap at all) from the theme's JPApp.modal
 * module, with the accessibility gap that had (no real focus trap, just a
 * "focus first input on open" one-shot) fixed properly: focus is trapped
 * within the dialog for the whole time it's open, and returns to the
 * trigger element on close, per the audit protocol's accessibility checks.
 */
export function Modal({ open, onClose, title, children, footer }: ModalProps) {
  const dialogRef = useRef<HTMLDivElement>(null)
  const triggerRef = useRef<Element | null>(null)

  useEffect(() => {
    if (!open) return

    triggerRef.current = document.activeElement
    dialogRef.current
      ?.querySelectorAll<HTMLElement>('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')[0]
      ?.focus()

    // Root-cause fix: the focusable-element list used to be queried ONCE
    // here and captured in this closure for the whole time the modal stays
    // open ([open, onClose] deps don't change when only the modal's
    // *content* does). AssessmentsPage swaps its question list for a result
    // view, and RecruiterCandidatesPage swaps a loading skeleton for a
    // detail panel with 0-3 links, both without closing the modal — so the
    // captured list went stale the moment content changed, and Tab/Shift+Tab
    // wrapping used elements that might no longer be first/last, or missed
    // newly-added ones entirely. It happened not to manifest today only
    // because every current caller passes a fresh (non-memoized) onClose
    // each render, which incidentally re-ran this effect whenever content
    // changed too — a coincidence that a future `useCallback` on any onClose
    // would silently break. Querying live inside the handler removes the
    // dependency on that coincidence entirely.
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === 'Escape') {
        onClose()
        return
      }
      if (e.key !== 'Tab') return

      const focusable = dialogRef.current?.querySelectorAll<HTMLElement>(
        'button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])',
      )
      if (!focusable || focusable.length === 0) return

      const first = focusable[0]
      const last = focusable[focusable.length - 1]
      if (e.shiftKey && document.activeElement === first) {
        e.preventDefault()
        last.focus()
      } else if (!e.shiftKey && document.activeElement === last) {
        e.preventDefault()
        first.focus()
      }
    }

    document.addEventListener('keydown', onKeyDown)
    document.body.style.overflow = 'hidden'

    return () => {
      document.removeEventListener('keydown', onKeyDown)
      document.body.style.overflow = ''
      ;(triggerRef.current as HTMLElement | null)?.focus?.()
    }
  }, [open, onClose])

  if (!open) return null

  return createPortal(
    <div className="jp-modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="jp-modal" role="dialog" aria-modal="true" aria-label={title} ref={dialogRef}>
        {title && (
          <div className="jp-modal__header">
            <h2 className="jp-modal__title">{title}</h2>
            <button className="jp-modal__close" onClick={onClose} aria-label="Close dialog">
              ×
            </button>
          </div>
        )}
        <div className="jp-modal__body">{children}</div>
        {footer && <div className="jp-modal__footer">{footer}</div>}
      </div>
    </div>,
    document.body,
  )
}
