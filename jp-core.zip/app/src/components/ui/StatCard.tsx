import type { ReactNode } from 'react'
import './StatCard.css'

interface StatCardProps {
  label: string
  value: ReactNode
  icon?: ReactNode
  /** Positive/negative/neutral trend vs. a prior period, e.g. "+12% this month". */
  trend?: { direction: 'up' | 'down' | 'flat'; label: string }
  tone?: 'default' | 'primary' | 'success' | 'warning' | 'error'
  className?: string
}

/**
 * Batch 32 — design-system foundation. Item #10 of the platform audit:
 * "dashboards must actually feel like dashboards" — a dashboard whose only
 * content is a table doesn't communicate at-a-glance status. StatCard is
 * the shared KPI tile every dashboard (candidate, recruiter, admin) now
 * builds its summary row from, so the four dashboards stay visually
 * consistent instead of each inventing its own number-in-a-box markup.
 */
export function StatCard({ label, value, icon, trend, tone = 'default', className }: StatCardProps) {
  return (
    <div className={['jp-stat-card', `jp-stat-card--${tone}`, className ?? ''].filter(Boolean).join(' ')}>
      <div className="jp-stat-card__top">
        <span className="jp-stat-card__label">{label}</span>
        {icon && <span className="jp-stat-card__icon" aria-hidden="true">{icon}</span>}
      </div>
      <div className="jp-stat-card__value">{value}</div>
      {trend && (
        <div className={`jp-stat-card__trend jp-stat-card__trend--${trend.direction}`}>
          <TrendIcon direction={trend.direction} />
          <span>{trend.label}</span>
        </div>
      )}
    </div>
  )
}

function TrendIcon({ direction }: { direction: 'up' | 'down' | 'flat' }) {
  if (direction === 'flat') {
    return (
      <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true">
        <path d="M2 6h8" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
      </svg>
    )
  }
  const rotate = direction === 'down' ? 'rotate(180deg)' : undefined
  return (
    <svg width="12" height="12" viewBox="0 0 12 12" fill="none" aria-hidden="true" style={{ transform: rotate }}>
      <path d="M6 10V2M2.5 5.5 6 2l3.5 3.5" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}
