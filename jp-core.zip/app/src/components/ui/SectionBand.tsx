import type { ReactNode } from 'react'
import './SectionBand.css'

type SectionBandTone = 'default' | 'muted' | 'primary' | 'dark' | 'accent'

interface SectionBandProps {
  title?: ReactNode
  subtitle?: ReactNode
  action?: ReactNode
  children: ReactNode
  tone?: SectionBandTone
  className?: string
  bleed?: boolean
}

export function SectionBand({
  title,
  subtitle,
  action,
  children,
  tone = 'default',
  className,
  bleed,
}: SectionBandProps) {
  const classes = [
    'jp-section-band',
    `jp-section-band--${tone}`,
    bleed ? 'jp-section-band--bleed' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ')

  return (
    <section className={classes}>
      <div className="jp-section-band__inner">
        {(title || action) && (
          <header className="jp-section-band__header">
            <div className="jp-section-band__titles">
              {title && <h2 className="jp-section-band__title">{title}</h2>}
              {subtitle && <p className="jp-section-band__subtitle">{subtitle}</p>}
            </div>
            {action && <div className="jp-section-band__action">{action}</div>}
          </header>
        )}
        <div className="jp-section-band__content">{children}</div>
      </div>
    </section>
  )
}
