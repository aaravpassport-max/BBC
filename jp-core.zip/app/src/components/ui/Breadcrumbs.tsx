import { Link } from 'react-router-dom'
import './Breadcrumbs.css'

export interface Crumb {
  label: string
  to?: string
}

interface BreadcrumbsProps {
  items: Crumb[]
  className?: string
}

/**
 * Batch 32 — design-system foundation. No breadcrumb component existed
 * anywhere in the app before this batch (confirmed by a repo-wide grep) —
 * every detail page dropped the user straight onto a floating card with no
 * sense of "where am I / how do I get back", one of the specific symptoms
 * named in the platform audit. The last item is rendered as the current
 * page (no link, aria-current="page"); every other item is a real Link.
 */
export function Breadcrumbs({ items, className }: BreadcrumbsProps) {
  if (items.length === 0) return null
  return (
    <nav className={['jp-breadcrumbs', className ?? ''].filter(Boolean).join(' ')} aria-label="Breadcrumb">
      <ol>
        {items.map((item, i) => {
          const isLast = i === items.length - 1
          return (
            <li key={`${item.label}-${i}`}>
              {isLast || !item.to ? (
                <span aria-current={isLast ? 'page' : undefined}>{item.label}</span>
              ) : (
                <Link to={item.to}>{item.label}</Link>
              )}
              {!isLast && <span className="jp-breadcrumbs__sep" aria-hidden="true">/</span>}
            </li>
          )
        })}
      </ol>
    </nav>
  )
}
