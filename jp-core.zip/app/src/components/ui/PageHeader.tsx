import type { ReactNode } from 'react'
import { Breadcrumbs, type Crumb } from './Breadcrumbs'
import './PageHeader.css'

interface PageHeaderProps {
  breadcrumbs?: Crumb[]
  title: ReactNode
  subtitle?: ReactNode
  /** Status/meta badges shown next to the title (e.g. a status Badge). */
  badges?: ReactNode
  actions?: ReactNode
  className?: string
}

/**
 * Batch 32 — design-system foundation. Before this batch every page wrote
 * its own ad hoc "<h1> + optional <p>" combination with no consistent
 * spacing, no breadcrumb slot, and no dedicated place for page-level
 * actions (so those ended up scattered inside the body instead). This is
 * the one header every rebuilt page now starts with.
 */
export function PageHeader({ breadcrumbs, title, subtitle, badges, actions, className }: PageHeaderProps) {
  return (
    <div className={['jp-page-header', className ?? ''].filter(Boolean).join(' ')}>
      {breadcrumbs && breadcrumbs.length > 0 && <Breadcrumbs items={breadcrumbs} />}
      <div className="jp-page-header__row">
        <div className="jp-page-header__titleblock">
          <div className="jp-page-header__titleline">
            <h1 className="jp-page-header__title">{title}</h1>
            {badges && <div className="jp-page-header__badges">{badges}</div>}
          </div>
          {subtitle && <p className="jp-page-header__subtitle">{subtitle}</p>}
        </div>
        {actions && <div className="jp-page-header__actions">{actions}</div>}
      </div>
    </div>
  )
}
