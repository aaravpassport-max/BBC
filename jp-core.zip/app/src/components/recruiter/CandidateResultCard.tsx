import type { ReactNode } from 'react'
import { Badge } from '@/components/ui/Badge'
import './CandidateResultCard.css'

interface CandidateResultCardProps {
  name: string
  headline: string
  meta?: string
  openToWork?: boolean
  skills?: string[]
  trailing?: ReactNode
  onClick?: () => void
}

export function CandidateResultCard({
  name,
  headline,
  meta,
  openToWork,
  skills,
  trailing,
  onClick,
}: CandidateResultCardProps) {
  return (
    <div
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      className={['jp-candidate-result', onClick ? 'jp-candidate-result--clickable' : ''].filter(Boolean).join(' ')}
      onClick={onClick}
      onKeyDown={
        onClick
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault()
                onClick()
              }
            }
          : undefined
      }
    >
      <div className="jp-candidate-result__main">
        <div className="jp-candidate-result__avatar" aria-hidden="true">
          {name[0]?.toUpperCase() ?? '?'}
        </div>
        <div className="jp-candidate-result__body">
          <div className="jp-candidate-result__title-row">
            <h2 className="jp-candidate-result__name">{name}</h2>
            {openToWork && <Badge variant="success">Open to work</Badge>}
          </div>
          <p className="jp-candidate-result__headline">{headline}</p>
          {meta && <p className="jp-candidate-result__meta">{meta}</p>}
          {skills && skills.length > 0 && (
            <div className="jp-candidate-result__skills">
              {skills.slice(0, 6).map((s) => (
                <Badge key={s} variant="gray">
                  {s}
                </Badge>
              ))}
            </div>
          )}
        </div>
      </div>
      {trailing && (
        <div className="jp-candidate-result__trailing" onClick={(e) => e.stopPropagation()} onKeyDown={(e) => e.stopPropagation()}>
          {trailing}
        </div>
      )}
    </div>
  )
}
