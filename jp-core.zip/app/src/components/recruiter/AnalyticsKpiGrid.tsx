import type { ReactNode } from 'react'
import './AnalyticsKpiGrid.css'

export function AnalyticsKpiGrid({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={['jp-analytics-kpi-grid', className ?? ''].filter(Boolean).join(' ')}>{children}</div>
}
