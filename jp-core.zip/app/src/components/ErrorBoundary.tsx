import { Component, type ErrorInfo, type ReactNode } from 'react'
import './ErrorBoundary.css'

interface ErrorBoundaryProps {
  children: ReactNode
}

interface ErrorBoundaryState {
  error: Error | null
}

/**
 * Root-cause fix: nothing in this app ever caught a render-time exception.
 * React unmounts the entire tree the instant any component throws during
 * render (a null-pointer on an unexpected API shape, a `.map()` on
 * `undefined` from a malformed response, etc.), which — with no error
 * boundary anywhere — left `#jp-root` permanently empty: a blank white
 * screen with no way to recover short of the user manually reloading, and
 * no indication anything went wrong at all.
 *
 * This must be a class component: there is no hook equivalent of
 * `getDerivedStateFromError`/`componentDidCatch` — the whole reason error
 * boundaries need special-cased class-only lifecycle methods in the first
 * place is that a hook can't intercept an exception thrown by a sibling or
 * child component's render, only its own.
 *
 * Deliberately does NOT attempt to POST the error to a logging endpoint:
 * grepped class-jp-api.php for any client-error-reporting route and found
 * none (jp_error_log is server-side PHP warning capture, unrelated). Given
 * the backend is frozen, inventing an unsupported network call here would
 * itself be an untraceable, contract-violating addition — console.error is
 * the honest option that actually exists.
 */
export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  state: ErrorBoundaryState = { error: null }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { error }
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // eslint-disable-next-line no-console -- only viable diagnostic path; see docblock above.
    console.error('Unhandled error in component tree:', error, info.componentStack)
  }

  render() {
    if (this.state.error) {
      return (
        <div className="jp-error-boundary" role="alert">
          <h1>Something went wrong</h1>
          <p>
            An unexpected error occurred and this part of the page couldn&apos;t be displayed. You can try reloading
            the page, or go back to the homepage.
          </p>
          <div className="jp-error-boundary__actions">
            <button type="button" onClick={() => window.location.reload()}>
              Reload page
            </button>
            <a href="/">Go to homepage</a>
          </div>
        </div>
      )
    }

    return this.props.children
  }
}
