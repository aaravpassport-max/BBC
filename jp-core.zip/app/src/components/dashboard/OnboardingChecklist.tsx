import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { completeOnboardingStep, getOnboardingStatus } from '@/features/onboarding/api'
import { Button } from '@/components/ui/Button'
import { useToast } from '@/components/ui/ToastProvider'
import './OnboardingChecklist.css'

const STEPS: { key: string; label: string; to: string }[] = [
  { key: 'complete_profile', label: 'Complete your profile', to: '/dashboard/profile' },
  { key: 'upload_resume', label: 'Upload a resume', to: '/dashboard/resumes' },
  { key: 'set_alert', label: 'Create a job alert', to: '/dashboard/alerts' },
  { key: 'apply_first_job', label: 'Apply to a job', to: '/jobs' },
  { key: 'take_assessment', label: 'Take a skill assessment', to: '/dashboard/assessments' },
]

export function OnboardingChecklist() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const { data } = useQuery({ queryKey: ['onboarding-status'], queryFn: getOnboardingStatus })

  const completeMutation = useMutation({
    mutationFn: completeOnboardingStep,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['onboarding-status'] }),
    onError: () => toast.error('Could not dismiss the checklist. Please try again.'),
  })

  if (!data || data.is_complete) return null

  const done = new Set(data.completed_steps)
  const progressPct = Math.round((done.size / STEPS.length) * 100)

  function dismiss() {
    for (const step of STEPS) {
      if (!done.has(step.key)) completeMutation.mutate(step.key)
    }
  }

  return (
    <section className="jp-onboarding" aria-labelledby="onboarding-title">
      <div className="jp-onboarding__header">
        <div>
          <h2 id="onboarding-title" className="jp-onboarding__title">
            Get started
          </h2>
          <p className="jp-onboarding__subtitle">
            {done.size} of {STEPS.length} steps complete — finish these to unlock better matches and alerts.
          </p>
        </div>
        <Button variant="ghost" size="sm" loading={completeMutation.isPending} onClick={dismiss}>
          Dismiss
        </Button>
      </div>
      <div className="jp-onboarding__progress" role="progressbar" aria-valuenow={progressPct} aria-valuemin={0} aria-valuemax={100}>
        <div className="jp-onboarding__progress-fill" style={{ width: `${progressPct}%` }} />
      </div>
      <ul className="jp-onboarding__list">
        {STEPS.map((step) => {
          const complete = done.has(step.key)
          return (
            <li key={step.key} className={['jp-onboarding__item', complete ? 'is-complete' : ''].filter(Boolean).join(' ')}>
              <span className="jp-onboarding__check" aria-hidden="true">
                {complete ? '✓' : ''}
              </span>
              {complete ? (
                <span className="jp-onboarding__label jp-onboarding__label--done">{step.label}</span>
              ) : (
                <Link to={step.to} className="jp-onboarding__label">
                  {step.label}
                </Link>
              )}
            </li>
          )
        })}
      </ul>
    </section>
  )
}
