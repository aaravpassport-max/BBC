import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { completeOnboardingStep, getOnboardingStatus } from '@/features/onboarding/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { useToast } from '@/components/ui/ToastProvider'
import './OnboardingChecklist.css'

/**
 * Steps are self-reported by the candidate (visiting/using a feature marks
 * it done via completeOnboardingStep()) — onboarding_status() on the
 * backend just tracks arbitrary step keys in user meta and considers
 * onboarding complete once 5+ are recorded, so this list intentionally has
 * exactly 5 entries plus a bonus one; there's no server-side definition of
 * "the 5 steps" beyond that count.
 */
const STEPS: { key: string; label: string; to: string }[] = [
  { key: 'complete_profile', label: 'Complete your profile', to: '/dashboard/profile' },
  { key: 'upload_resume', label: 'Upload a resume', to: '/dashboard/resumes' },
  { key: 'set_alert', label: 'Create a job alert', to: '/dashboard/alerts' },
  { key: 'apply_first_job', label: 'Apply to a job', to: '/jobs' },
  { key: 'take_assessment', label: 'Take a skill assessment', to: '/dashboard/assessments' },
]

export function OnboardingChecklist() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const { data } = useQuery({ queryKey: ['onboarding-status'], queryFn: getOnboardingStatus })

  const completeMutation = useMutation({
    mutationFn: completeOnboardingStep,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['onboarding-status'] }),
    onError: () => toast.error('Could not dismiss the checklist. Please try again.'),
  })

  // Hide once the candidate has finished onboarding — nothing left to nudge.
  if (!data || data.is_complete) return null

  const done = new Set(data.completed_steps)

  function dismiss() {
    // onboarding_status() only checks completed_steps.length >= 5 with no
    // notion of "skipped" — so dismissing marks every remaining step done
    // (one POST per step, since the endpoint records one key per call) to
    // reach that threshold and hide the checklist for good.
    for (const step of STEPS) {
      if (!done.has(step.key)) completeMutation.mutate(step.key)
    }
  }

  return (
    <Card style={{ marginBottom: 16 }}>
      <CardBody>
        <div className="jp-onboarding__header">
          <h2 className="jp-onboarding__title">
            Get started ({done.size}/{STEPS.length})
          </h2>
          <Button variant="ghost" size="sm" loading={completeMutation.isPending} onClick={dismiss}>
            Dismiss
          </Button>
        </div>
        <ul className="jp-onboarding__list">
          {STEPS.map((step) => (
            <li key={step.key} className="jp-onboarding__item">
              <label>
                <input type="checkbox" checked={done.has(step.key)} readOnly disabled />
                {done.has(step.key) ? <s>{step.label}</s> : <Link to={step.to}>{step.label}</Link>}
              </label>
            </li>
          ))}
        </ul>
      </CardBody>
    </Card>
  )
}
