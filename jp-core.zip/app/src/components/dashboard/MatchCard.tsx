import { Link } from 'react-router-dom'
import type { MatchRow } from '@/features/matches/api'
import { matchJobId, parseScoreDetail } from '@/features/matches/api'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import './MatchCard.css'

function scoreVariant(score: number): 'success' | 'info' | 'gray' {
  if (score >= 80) return 'success'
  if (score >= 60) return 'info'
  return 'gray'
}

function formatSalary(min?: number, max?: number): string | null {
  if (!min && !max) return null
  const fmt = (n: number) => n.toLocaleString()
  if (min && max) return `${fmt(min)} – ${fmt(max)} / yr`
  return `${fmt(min || max || 0)} / yr`
}

const FACTOR_LABELS: Record<'skills' | 'experience' | 'location' | 'education' | 'salary', string> = {
  skills: 'Skills',
  experience: 'Experience',
  location: 'Location',
  education: 'Education',
  salary: 'Salary fit',
}

interface MatchCardProps {
  match: MatchRow
  expanded: boolean
  onToggleExpand: () => void
  onSave: () => void
  onDismiss: () => void
  saveLoading: boolean
  dismissLoading: boolean
}

export function MatchCard({
  match: m,
  expanded,
  onToggleExpand,
  onSave,
  onDismiss,
  saveLoading,
  dismissLoading,
}: MatchCardProps) {
  const salary = formatSalary(m.salary_min, m.salary_max)
  const jobId = matchJobId(m)
  const breakdown = parseScoreDetail(m)

  return (
    <article className="jp-match-card">
      <div className="jp-match-card__head">
        <Link to={`/jobs/${jobId}`} className="jp-match-card__link">
          <h2 className="jp-match-card__title">{m.title}</h2>
          <p className="jp-match-card__company">
            {m.company_name} · {m.location_city || 'Location not specified'}
            {salary && <> · {salary}</>}
          </p>
        </Link>
        <span className="jp-match-card__score">
          <Badge variant={scoreVariant(m.score)}>{Math.round(m.score)}% match</Badge>
        </span>
      </div>

      <div className="jp-match-card__badges">
        {m.work_mode === 'remote' && <Badge variant="info">Remote</Badge>}
        {m.job_type && <Badge variant="gray">{m.job_type}</Badge>}
      </div>

      <div className="jp-match-card__actions">
        {breakdown && (
          <button type="button" className="jp-match-card__why" aria-expanded={expanded} onClick={onToggleExpand}>
            {expanded ? 'Hide match details' : 'Why this match?'}
          </button>
        )}
        <div className="jp-match-card__buttons">
          <Button variant="outline" size="sm" loading={saveLoading} onClick={onSave}>
            Save
          </Button>
          <Button variant="outline" size="sm" loading={dismissLoading} onClick={onDismiss}>
            Not interested
          </Button>
          <Link to={`/jobs/${jobId}`}>
            <Button variant="accent" size="sm">
              View job
            </Button>
          </Link>
        </div>
      </div>

      {expanded && breakdown && (
        <div className="jp-match-card__breakdown">
          {(Object.keys(FACTOR_LABELS) as Array<keyof typeof FACTOR_LABELS>).map((factor) => {
            const value = breakdown[factor]
            const weightPct = Math.round(breakdown.weights[factor] * 100)
            return (
              <div className="jp-match-card__factor" key={factor}>
                <div className="jp-match-card__factor-label">
                  <span>{FACTOR_LABELS[factor]}</span>
                  <span className="jp-match-card__factor-weight">{weightPct}% of score</span>
                </div>
                <div className="jp-match-card__factor-track">
                  <div className="jp-match-card__factor-fill" style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
                </div>
              </div>
            )
          })}
        </div>
      )}
    </article>
  )
}
