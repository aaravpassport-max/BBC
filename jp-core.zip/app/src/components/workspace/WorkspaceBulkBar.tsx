import type { ReactNode } from 'react'
import './WorkspaceBulkBar.css'

interface WorkspaceBulkBarProps {
  count: number
  children: ReactNode
  onClear?: () => void
}

export function WorkspaceBulkBar({ count, children, onClear }: WorkspaceBulkBarProps) {
  if (count <= 0) return null

  return (
    <div className="jp-workspace-bulk" role="region" aria-label="Bulk actions">
      <span className="jp-workspace-bulk__count">{count} selected</span>
      <div className="jp-workspace-bulk__actions">{children}</div>
      {onClear && (
        <button type="button" className="jp-workspace-bulk__clear" onClick={onClear}>
          Clear selection
        </button>
      )}
    </div>
  )
}
