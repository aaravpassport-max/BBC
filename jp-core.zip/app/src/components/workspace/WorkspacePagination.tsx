import { Button } from '@/components/ui/Button'
import './WorkspacePagination.css'

interface WorkspacePaginationProps {
  page: number
  totalPages: number
  onPageChange: (page: number) => void
  className?: string
}

export function WorkspacePagination({ page, totalPages, onPageChange, className }: WorkspacePaginationProps) {
  if (totalPages <= 1) return null

  return (
    <nav className={['jp-workspace-pagination', className ?? ''].filter(Boolean).join(' ')} aria-label="Pagination">
      <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => onPageChange(page - 1)}>
        Previous
      </Button>
      <span className="jp-workspace-pagination__label">
        Page {page} of {totalPages}
      </span>
      <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => onPageChange(page + 1)}>
        Next
      </Button>
    </nav>
  )
}
