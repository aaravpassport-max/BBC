import './PipelineStageChips.css'

export interface PipelineStageOption<T extends string = string> {
  value: T | ''
  label: string
}

interface PipelineStageChipsProps<T extends string = string> {
  options: PipelineStageOption<T>[]
  value: T | ''
  onChange: (value: T | '') => void
  label?: string
}

export function PipelineStageChips<T extends string = string>({
  options,
  value,
  onChange,
  label = 'Filter by stage',
}: PipelineStageChipsProps<T>) {
  return (
    <div className="jp-pipeline-chips" role="group" aria-label={label}>
      {options.map((opt) => (
        <button
          key={opt.value || 'all'}
          type="button"
          className={['jp-pipeline-chips__chip', value === opt.value ? 'is-active' : ''].filter(Boolean).join(' ')}
          aria-pressed={value === opt.value}
          onClick={() => onChange(opt.value)}
        >
          {opt.label}
        </button>
      ))}
    </div>
  )
}
