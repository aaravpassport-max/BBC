import { useEffect } from 'react'

/**
 * Sets document.title. Every page in this app previously left the static
 * "JP Job Portal" title from index.html in place forever — no page,
 * dashboard section, or job/company/event/post detail view ever changed
 * it. That's a real WCAG 2.4.2 (Page Titled) failure (each view needs a
 * title that describes its topic or purpose) and a usability gap besides:
 * every browser tab, bookmark, and history entry for this whole app was
 * indistinguishable from every other one.
 *
 * App.tsx sets a route-pattern-based fallback title on every navigation
 * (see ROUTE_TITLES there). Pages that have a real entity name to show
 * (a specific job's title, a company's name, …) call this again once
 * that data loads, to replace the generic fallback with the specific one.
 */
export function useDocumentTitle(title: string | null | undefined): void {
  useEffect(() => {
    if (title) document.title = title
  }, [title])
}
