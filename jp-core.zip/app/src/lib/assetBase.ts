/**
 * Absolute base URL this app's own static assets are served from.
 *
 * This app is served from a WordPress plugin's directory
 * (.../wp-content/plugins/jp-core/app-dist/ — see class-jp-react.php's
 * enqueue_react_assets()), not from the site root. window.location.origin
 * is the WP *site* root, which is right for API calls and for-the-user
 * links (AuthContext's bootstrap fetch, home_url-based links, etc.) but
 * wrong for any static file this build itself outputs — e.g. the push
 * notification service worker (public/jp-push-sw.js, copied verbatim to
 * app-dist/jp-push-sw.js by Vite) lives at .../app-dist/jp-push-sw.js,
 * not at the site root, and registering a service worker at the wrong URL
 * fails outright (404) rather than merely picking the wrong scope.
 *
 * Root-cause fix: before this, src/lib/push.ts registered the SW at a
 * hardcoded absolute root path ('/jp-push-sw.js'), documented at the time
 * as "a reasonable, in-authority decision since Phase 5 cutover ... hasn't
 * happened yet." Now that class-jp-react.php actually serves this build
 * from app-dist/ (a plugin subdirectory, never the site root), that
 * assumption is simply wrong and would 404 on every real deployment.
 *
 * Computed once, in the one module Vite guarantees sits directly in the
 * build output root: main.tsx, per vite.config.ts's
 * `entryFileNames: jp-app.${APP_VERSION}.js` (no subdirectory prefix) —
 * unlike every other module in the app, which Rollup may place under
 * chunks/ at an unpredictable depth, so only the true entry's
 * import.meta.url is safe to derive a base path from.
 */
export let ASSET_BASE_URL = '/'

export function setAssetBaseUrl(url: string): void {
  ASSET_BASE_URL = url
}
