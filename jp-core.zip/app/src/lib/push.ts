import { pushSubscribe, pushUnsubscribe } from '@/features/candidates/meApi'
import { ASSET_BASE_URL } from '@/lib/assetBase'

// Root-cause fix: this used to be a hardcoded absolute root path
// ('/jp-push-sw.js'), which only works if the app is served from the site
// root. It's actually served from a WordPress plugin subdirectory
// (.../wp-content/plugins/jp-core/app-dist/) — see assetBase.ts's
// docblock — so the SW's real, resolvable URL has to be derived from
// where this app's own assets actually live.
const PUSH_SW_URL = `${ASSET_BASE_URL}jp-push-sw.js`

/**
 * Converts a URL-safe base64 VAPID public key (as WordPress's
 * get_option('jp_vapid_public_key') and JP_CONFIG.vapid_public_key store
 * it) into the Uint8Array applicationServerKey the PushManager API needs.
 */
function urlBase64ToUint8Array(base64String: string): BufferSource {
  const padding = '='.repeat((4 - (base64String.length % 4)) % 4)
  const base64 = (base64String + padding).replace(/-/g, '+').replace(/_/g, '/')
  const rawData = atob(base64)
  const outputArray = new Uint8Array(rawData.length)
  for (let i = 0; i < rawData.length; i++) outputArray[i] = rawData.charCodeAt(i)
  return outputArray.buffer
}

export function isPushSupported(): boolean {
  return 'serviceWorker' in navigator && 'PushManager' in window
}

export async function getPushSubscriptionState(): Promise<'subscribed' | 'unsubscribed' | 'unsupported'> {
  if (!isPushSupported()) return 'unsupported'
  const registration = await navigator.serviceWorker.getRegistration(ASSET_BASE_URL)
  if (!registration) return 'unsubscribed'
  const sub = await registration.pushManager.getSubscription()
  return sub ? 'subscribed' : 'unsubscribed'
}

export async function subscribeToPush(vapidPublicKey: string, ajaxUrl: string, ajaxNonce: string): Promise<void> {
  if (!isPushSupported()) throw new Error('Push notifications are not supported in this browser.')
  const permission = await Notification.requestPermission()
  if (permission !== 'granted') throw new Error('Notification permission was not granted.')

  const registration = await navigator.serviceWorker.register(PUSH_SW_URL)
  const subscription = await registration.pushManager.subscribe({
    userVisibleOnly: true,
    applicationServerKey: urlBase64ToUint8Array(vapidPublicKey),
  })
  await pushSubscribe(ajaxUrl, ajaxNonce, subscription.toJSON() as PushSubscriptionJSON)
}

export async function unsubscribeFromPush(): Promise<void> {
  const registration = await navigator.serviceWorker.getRegistration(ASSET_BASE_URL)
  const sub = await registration?.pushManager.getSubscription()
  if (sub) await sub.unsubscribe()
  await pushUnsubscribe()
}
