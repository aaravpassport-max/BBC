import type { JobRow } from '@/features/jobs/api'

export function formatJobType(jobType: string): string {
  return jobType
    .split('-')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join('-')
}

/** Human-readable salary for cards and detail headers (INR uses ₹ + LPA-style when large enough). */
export function formatJobSalary(
  min: number,
  max: number,
  currency: string,
  visible: 0 | 1 | boolean = true,
): string | null {
  if (!visible || (!min && !max)) return null
  const symbol = currency === 'INR' ? '₹' : `${currency} `
  const fmtCompact = (n: number) => {
    if (currency === 'INR' && n >= 100000) return `${(n / 100000).toFixed(n % 100000 === 0 ? 0 : 1)} LPA`
    if (n >= 1000) return `${symbol}${(n / 1000).toFixed(0)}k`
    return `${symbol}${n.toLocaleString()}`
  }
  if (min && max) return `${fmtCompact(min)} – ${fmtCompact(max)}`
  return fmtCompact(min || max)
}

export function formatExperience(min: number, max: number): string | null {
  if (min <= 0 && max <= 0) return null
  if (min > 0 && max > 0) return `${min}–${max} yrs`
  return `${min || max}+ yrs`
}

export function formatPostedRelative(createdAt: string): string {
  const created = new Date(createdAt)
  if (Number.isNaN(created.getTime())) return ''
  const diffMs = Date.now() - created.getTime()
  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24))
  if (days <= 0) return 'Posted today'
  if (days === 1) return 'Posted yesterday'
  if (days < 7) return `Posted ${days} days ago`
  if (days < 30) return `Posted ${Math.floor(days / 7)} wk ago`
  return created.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })
}

export function jobLocationLabel(job: Pick<JobRow, 'location_city' | 'location_state' | 'work_mode'>): string {
  if (job.work_mode === 'remote') return 'Remote'
  const place = [job.location_city, job.location_state].filter(Boolean).join(', ')
  return place || 'Location flexible'
}
