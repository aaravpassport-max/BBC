import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import { api, setRuntimeConfig } from '@/lib/apiClient'
import type { RuntimeAppConfig, JpRole, RawWindowJpConfig } from './types'

interface AuthState {
  config: RuntimeAppConfig | null
  loading: boolean
  error: string | null
  isAuthenticated: boolean
  role: JpRole
  /**
   * `nonceOverride` is used exactly once, right after a successful login:
   * the freshly-authenticated session's own nonce (returned directly by
   * POST /auth/token — see class-jp-api.php::auth_token()) has to be used
   * for THIS refetch, because the nonce currently held in runtimeConfig
   * was minted for whatever identity (usually anonymous) existed before
   * login and WordPress's REST cookie check hard-rejects a mismatched
   * nonce rather than silently treating the request as anonymous.
   */
  refresh: (nonceOverride?: string) => Promise<void>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthState | null>(null)

// Before the app's own runtime config exists, we don't yet know the real
// api_url (that's IN the config we're about to fetch) — so the very first
// request has to guess a sane default. Same-origin '/wp-json/jp/v1' is
// correct for the standard WordPress REST API location and matches how
// class-jp-react.php's rest_url('jp/v1') always resolves for this site,
// so this is not really a "guess," it's the one bootstrap request allowed
// to assume the default WordPress REST base before real config exists.
const BOOTSTRAP_CONFIG_URL = `${window.location.origin}/wp-json/jp/v1/config`

// Root-cause fix (traced from live user report: "admin doesn't find
// automatically logged in", pages rendering "thin"): wp_localize_script()
// stringifies every value it injects (a documented WordPress quirk, not a
// bug in this codebase) — booleans become "1"/"", numbers become their
// string form. window.JP_CONFIG is raw in that shape; this coerces it back
// to RuntimeAppConfig's real types so downstream code (which does real
// number math on jobs_per_page/unread_notifications, and may someday do a
// strict === true check on a feature flag) behaves identically regardless
// of which of the two sources (inline script vs REST /config) produced it.
function normalizeWindowConfig(raw: RawWindowJpConfig): RuntimeAppConfig {
  const bool = (v: string | undefined) => v === '1' || v === 'true'
  const num = (v: string | undefined, fallback = 0) => {
    const n = Number(v)
    return Number.isFinite(n) ? n : fallback
  }
  return {
    api_url: raw.api_url ?? '',
    ajax_url: raw.ajax_url ?? '',
    home_url: raw.home_url ?? '',
    portal_url: raw.portal_url ?? '',
    nonce: raw.nonce ?? '',
    ajax_nonce: raw.ajax_nonce ?? '',
    is_logged: bool(raw.is_logged),
    user_id: num(raw.user_id),
    role: (raw.role ?? '') as JpRole,
    user_name: raw.user_name ?? '',
    user_email: raw.user_email ?? '',
    site_name: raw.site_name ?? '',
    currency: raw.currency ?? '',
    timezone: raw.timezone ?? '',
    openai_enabled: bool(raw.openai_enabled),
    razorpay_enabled: bool(raw.razorpay_enabled),
    sms_enabled: bool(raw.sms_enabled),
    vapid_enabled: bool(raw.vapid_enabled),
    es_enabled: bool(raw.es_enabled),
    razorpay_key_id: raw.razorpay_key_id ?? '',
    payment_gateway: raw.payment_gateway === 'stripe' ? 'stripe' : 'razorpay',
    stripe_enabled: bool(raw.stripe_enabled),
    stripe_publishable_key: raw.stripe_publishable_key ?? '',
    vapid_public_key: raw.vapid_public_key ?? '',
    ga4_id: raw.ga4_id ?? '',
    jobs_per_page: num(raw.jobs_per_page, 20),
    unread_notifications: num(raw.unread_notifications),
    unread_messages: num(raw.unread_messages),
  }
}

async function fetchBootstrapConfig(nonceOverride?: string): Promise<RuntimeAppConfig> {
  // Root-cause fix: every OTHER authenticated request in this app
  // (apiClient.ts's apiRequest()/apiUpload()) attaches X-WP-Nonce, which
  // WordPress's REST cookie authentication requires — without it, a
  // request made with genuinely valid login cookies is hard-rejected
  // ('rest_cookie_invalid_nonce'), not silently treated as anonymous. This
  // call was the one exception, written as a raw fetch() before any nonce
  // was known — but by the time this function can be called at all, either
  // window.JP_CONFIG (read first — see AuthProvider below) already
  // supplied a valid nonce, or a fresh one was just returned by
  // POST /auth/token. Falling back to the page's own initial nonce when no
  // override is given covers a manual refresh() call with no other source.
  const nonce = nonceOverride ?? window.JP_CONFIG?.nonce
  const res = await fetch(BOOTSTRAP_CONFIG_URL, {
    credentials: 'same-origin',
    headers: nonce ? { 'X-WP-Nonce': nonce } : undefined,
  })
  if (!res.ok) {
    throw new Error(`Failed to load app configuration (HTTP ${res.status}).`)
  }
  // /config's callback (class-jp-react.php::register_config_route) returns
  // build_config()'s object directly, NOT wrapped in {success, data} the
  // way every other endpoint is — it's a plain WP_REST_Response, so this
  // one call is the deliberate exception to apiClient.ts's envelope
  // unwrapping and must NOT go through apiRequest().
  return (await res.json()) as RuntimeAppConfig
}

export function AuthProvider({ children }: { children: ReactNode }) {
  // Root-cause fix: window.JP_CONFIG is already correct and already free
  // (server-rendered at page-load time, before any JS runs — see
  // tpl-react-app.php's inline "jp-react-app-js-extra" script) for the
  // single most common case: a page load where WordPress's own
  // is_user_logged_in() already knows the answer. Seeding state with it
  // synchronously means an already-logged-in WP admin (or any
  // cookie-authenticated user) is recognized as authenticated on the very
  // first render, with no network round-trip and nothing that can race or
  // fail against WordPress's REST cookie-nonce check.
  const initialConfig = window.JP_CONFIG ? normalizeWindowConfig(window.JP_CONFIG) : null
  if (initialConfig) {
    setRuntimeConfig({ apiUrl: initialConfig.api_url, nonce: initialConfig.nonce })
  }

  const [config, setConfig] = useState<RuntimeAppConfig | null>(initialConfig)
  const [loading, setLoading] = useState(!initialConfig)
  const [error, setError] = useState<string | null>(null)

  async function load(nonceOverride?: string) {
    setLoading(true)
    setError(null)
    try {
      const cfg = await fetchBootstrapConfig(nonceOverride)
      setRuntimeConfig({ apiUrl: cfg.api_url, nonce: cfg.nonce })
      setConfig(cfg)
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Could not reach the server.')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    // If window.JP_CONFIG was already available, that's a complete, valid
    // config — no need to also fire an initial network request. A fresh
    // fetch still happens later via explicit refresh() calls (post-login,
    // post-logout). Only fall back to fetching here if, for some reason,
    // the inline script wasn't present (e.g. this component were ever
    // rendered outside the WordPress-hosted page template).
    if (!initialConfig) void load()
    // Intentionally runs once on mount — a nonce refresh mid-session (e.g.
    // after 2FA state changes) is handled by explicit refresh() calls from
    // the login/logout flows, not a polling interval here.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Root-cause fix: login previously never established a real session, so
  // there was nothing to sign out of and no logout control existed
  // anywhere in the app (confirmed — grepped the whole codebase). Now that
  // POST /auth/token actually calls wp_set_auth_cookie(), a way to end
  // that session is required, not optional. Goes through apiClient's api
  // (not a raw fetch) so it's authenticated the same way every other
  // in-session request is (nonce + cookie). Clears local state
  // immediately rather than re-fetching /config afterward — a refetch
  // would itself need a nonce valid for the now-logged-out (anonymous)
  // context, reintroducing the exact bootstrapping problem this whole fix
  // was about; setting the known post-logout shape locally is simpler and
  // has nothing left to race against.
  async function logout() {
    try {
      await api.post('/auth/logout')
    } catch {
      // Best-effort: even if the network call fails, the user clicked
      // "Log out" and the UI must not keep claiming they're signed in.
    }
    setConfig((prev) =>
      prev
        ? { ...prev, is_logged: false, role: '', user_id: 0, user_name: '', user_email: '' }
        : prev,
    )
  }

  const value = useMemo<AuthState>(
    () => ({
      config,
      loading,
      error,
      isAuthenticated: !!config?.is_logged,
      role: config?.role ?? '',
      refresh: load,
      logout,
    }),
    [config, loading, error],
  )

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export function useAuth(): AuthState {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth() must be used within <AuthProvider>.')
  return ctx
}
