/**
 * Mirrors JP_React::build_config()'s actual return shape in
 * class-jp-react.php (jp-core), and the 6 real roles from class-jp-roles.php
 * (see JP-PLATFORM-ROADMAP.md Part 2.2) — kept in sync with the backend by
 * hand since the backend is frozen and this is the one place role names
 * would need updating if that ever changes.
 */
export type JpRole =
  | 'jp_job_seeker'
  | 'jp_recruiter'
  | 'jp_team_manager'
  | 'jp_staff'
  | 'jp_admin_manager'
  | 'administrator'
  | ''

export interface CandidateSummary {
  user_id: number
  headline?: string
  profile_score?: number
  is_open_to_work?: boolean
  skills?: string[]
  [key: string]: unknown
}

export interface CompanySummary {
  id: number
  name: string
  slug: string
  is_verified?: boolean
  [key: string]: unknown
}

/**
 * The shape WordPress's wp_localize_script() actually produces for
 * `window.JP_CONFIG` (see templates/page-templates/tpl-react-app.php's
 * inline "jp-react-app-js-extra" script, injected by
 * class-jp-react.php::enqueue_react_assets()). wp_localize_script() has a
 * long-standing, well-documented quirk: it does NOT preserve JSON types —
 * every value is stringified, so a PHP `true`/`false` becomes the string
 * "1"/"" and every number becomes its string form. This is DIFFERENT from
 * the same build_config() data returned by the real /config REST endpoint,
 * which serializes with native JSON types intact. Both sources must be
 * normalized to RuntimeAppConfig's real types before use — see
 * normalizeWindowConfig() in AuthContext.tsx.
 */
export type RawWindowJpConfig = Record<string, string>

declare global {
  interface Window {
    /**
     * Present on every page render from first paint (injected as a classic
     * inline script that runs before the deferred module script — see
     * tpl-react-app.php) — this is the source of truth for the user's auth
     * state AT THE TIME THE PAGE WAS RENDERED, straight from
     * is_user_logged_in() with zero network round-trip. Using this instead
     * of a fresh fetch to /config avoids depending on that fetch correctly
     * threading WordPress's cookie+nonce REST authentication (a class of
     * bug that previously caused an already-logged-in WP admin to appear
     * logged out inside the SPA).
     */
    JP_CONFIG?: RawWindowJpConfig
  }
}

export interface RuntimeAppConfig {
  api_url: string
  ajax_url: string
  home_url: string
  portal_url: string
  nonce: string
  ajax_nonce: string
  is_logged: boolean
  user_id: number
  role: JpRole
  user_name: string
  user_email: string
  site_name: string
  currency: string
  timezone: string
  openai_enabled: boolean
  razorpay_enabled: boolean
  sms_enabled: boolean
  vapid_enabled: boolean
  es_enabled: boolean
  razorpay_key_id: string
  /** Batch 12 — Stripe gateway abstraction. See JP_React::build_config() in class-jp-react.php. */
  payment_gateway: 'razorpay' | 'stripe'
  stripe_enabled: boolean
  stripe_publishable_key: string
  vapid_public_key: string
  ga4_id: string
  jobs_per_page: number
  candidate?: CandidateSummary
  company?: CompanySummary
  unread_notifications?: number
  unread_messages?: number
}

/**
 * Role → landing route, mirrored from the redirect map documented in the
 * platform audit (JP-PLATFORM-ROADMAP.md Part 2.2). Used right after login
 * and to redirect a signed-in user away from /login.
 */
export const ROLE_LANDING_ROUTE: Record<JpRole, string> = {
  jp_job_seeker: '/dashboard',
  jp_recruiter: '/recruiter',
  jp_team_manager: '/recruiter',
  jp_staff: '/admin',
  jp_admin_manager: '/admin',
  administrator: '/admin',
  '': '/',
}
