/**
 * Central REST client for the entire app. Every feature module's API file
 * (jobs.ts, candidates.ts, admin/*.ts, etc.) goes through this — no
 * component ever calls fetch() directly. That's what makes it possible to
 * change auth handling, error shape, or the base URL in exactly one place.
 *
 * Talks to the EXISTING /wp-json/jp/v1/ REST API (class-jp-api.php and
 * friends) — see JP-PLATFORM-ROADMAP.md Part 3.1: the backend is frozen,
 * this client is the only new "surface" on the API side.
 */

export interface ApiEnvelope<T> {
  success: boolean
  data: T
}

/** Matches WordPress's WP_Error REST serialization: {code, message, data:{status}} */
export interface ApiErrorBody {
  code: string
  message: string
  data?: { status?: number }
}

export class ApiError extends Error {
  status: number
  code: string

  constructor(message: string, status: number, code: string) {
    super(message)
    this.name = 'ApiError'
    this.status = status
    this.code = code
  }
}

interface RuntimeConfig {
  apiUrl: string
  nonce: string
}

// Populated once at boot by bootstrapAuth() (see auth/AuthContext.tsx),
// reading the /wp-json/jp/v1/config endpoint that class-jp-react.php
// already exposes for exactly this purpose. Until boot completes this is
// null and any call will throw loudly rather than silently hit the wrong
// origin — a caller racing ahead of boot is a bug, not something to paper
// over with a guessed default.
let runtimeConfig: RuntimeConfig | null = null

export function setRuntimeConfig(config: RuntimeConfig): void {
  runtimeConfig = config
}

export function getRuntimeConfig(): RuntimeConfig {
  if (!runtimeConfig) {
    throw new Error(
      'API client used before bootstrapAuth() completed — runtimeConfig is not set yet.',
    )
  }
  return runtimeConfig
}

interface RequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH'
  body?: unknown
  query?: Record<string, string | number | boolean | undefined>
  signal?: AbortSignal
}

function buildUrl(path: string, query?: RequestOptions['query']): string {
  const { apiUrl } = getRuntimeConfig()
  const url = new URL(apiUrl.replace(/\/$/, '') + '/' + path.replace(/^\//, ''))
  if (query) {
    for (const [key, value] of Object.entries(query)) {
      if (value !== undefined) url.searchParams.set(key, String(value))
    }
  }
  return url.toString()
}

/**
 * Low-level request function. Every typed endpoint wrapper (see each
 * feature module's api.ts under src/features/) calls this and unwraps the {success, data}
 * envelope — see the class-jp-settings.php Skills-screen fix earlier in
 * this engagement for why that unwrapping has to be exact: JP_Api::ok()
 * wraps success payloads as {success, data}, while WP_Error responses
 * serialize as the DIFFERENT {code, message, data:{status}} shape. Getting
 * this wrong once already cost real debugging time — centralizing it here
 * means it only has to be correct once, for every endpoint in the app.
 */
export async function apiRequest<T>(path: string, options: RequestOptions = {}): Promise<T> {
  const { nonce } = getRuntimeConfig()
  const { method = 'GET', body, query, signal } = options

  const res = await fetch(buildUrl(path, query), {
    method,
    credentials: 'same-origin',
    signal,
    headers: {
      'X-WP-Nonce': nonce,
      ...(body ? { 'Content-Type': 'application/json' } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  })

  let json: unknown = null
  try {
    json = await res.json()
  } catch {
    // A non-JSON body (e.g. a raw PHP fatal error page) is itself the
    // failure — surface it as an ApiError rather than let a JSON.parse
    // exception propagate as an unrelated-looking crash.
  }

  if (!res.ok) {
    const err = json as ApiErrorBody | null
    throw new ApiError(
      err?.message ?? `Request failed with status ${res.status}`,
      res.status,
      err?.code ?? 'unknown_error',
    )
  }

  const envelope = json as ApiEnvelope<T>
  return envelope.data
}

/**
 * Multipart uploads (resume files, avatar images) can't go through
 * apiRequest() — that function always JSON.stringify()s its body and sets
 * Content-Type: application/json, which would corrupt a file upload.
 * upload_resume() (class-jp-api.php) delegates straight to
 * JP_Resume::ajax_upload(), which reads $_FILES['resume'] — so the field
 * name below is NOT arbitrary, it has to be exactly 'resume' or the PHP
 * side sees an empty $_FILES and returns "No file received."
 */
export async function apiUpload<T>(path: string, fieldName: string, file: File): Promise<T> {
  const { apiUrl, nonce } = getRuntimeConfig()
  const url = apiUrl.replace(/\/$/, '') + '/' + path.replace(/^\//, '')
  const formData = new FormData()
  formData.append(fieldName, file)

  const res = await fetch(url, {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'X-WP-Nonce': nonce },
    body: formData,
  })

  let json: unknown = null
  try {
    json = await res.json()
  } catch {
    // handled below via !res.ok / missing envelope
  }

  if (!res.ok) {
    const err = json as ApiErrorBody | null
    throw new ApiError(err?.message ?? `Upload failed with status ${res.status}`, res.status, err?.code ?? 'unknown_error')
  }

  return (json as ApiEnvelope<T>).data
}

export const api = {
  get: <T>(path: string, query?: RequestOptions['query'], signal?: AbortSignal) =>
    apiRequest<T>(path, { method: 'GET', query, signal }),
  post: <T>(path: string, body?: unknown, signal?: AbortSignal) =>
    apiRequest<T>(path, { method: 'POST', body, signal }),
  put: <T>(path: string, body?: unknown, signal?: AbortSignal) =>
    apiRequest<T>(path, { method: 'PUT', body, signal }),
  delete: <T>(path: string, query?: RequestOptions['query'], signal?: AbortSignal) =>
    apiRequest<T>(path, { method: 'DELETE', query, signal }),
  patch: <T>(path: string, body?: unknown, signal?: AbortSignal) =>
    apiRequest<T>(path, { method: 'PATCH', body, signal }),
}
