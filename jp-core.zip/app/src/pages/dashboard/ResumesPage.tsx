import { useRef, useState, type ChangeEvent } from 'react'
import { Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  deleteResume,
  formatFileSize,
  listResumes,
  parseResumeDetail,
  setPrimaryResume,
  uploadResume,
  type ResumeRow,
} from '@/features/resumes/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './ResumesPage.css'

function completenessVariant(pct: number): 'success' | 'warning' | 'error' {
  if (pct >= 80) return 'success'
  if (pct >= 50) return 'warning'
  return 'error'
}

/**
 * Phase 3 redesign (Tier A, redesign-plan §ResumesPage) — jp_resumes has
 * always carried file_size/parsed_json/parsed_at/completeness (populated
 * by JP_Resume::parse() on every upload), and that parser's own docblock
 * explicitly flagged "a future review-before-applying UI" as out of scope
 * for that backend pass. This page previously showed only a filename and
 * an upload date. Now shows the real per-resume completeness score, file
 * size, and an expandable "What we found" panel with the actual extracted
 * fields (skills/experience/education/title/company) — low-confidence
 * heuristic guesses (current_title/current_company/experience_years) are
 * flagged for review rather than presented as fact, matching the parser's
 * own field_confidence signal instead of hiding it.
 */
export function ResumesPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const fileInputRef = useRef<HTMLInputElement>(null)
  const [expandedId, setExpandedId] = useState<number | null>(null)

  const { data, isLoading, isError } = useQuery({ queryKey: ['resumes'], queryFn: listResumes })

  const uploadMutation = useMutation({
    mutationFn: uploadResume,
    onSuccess: () => {
      toast.success('Resume uploaded.')
      queryClient.invalidateQueries({ queryKey: ['resumes'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Upload failed. Only PDF/DOC/DOCX up to 5MB are accepted.'),
  })

  const deleteMutation = useMutation({
    mutationFn: deleteResume,
    onSuccess: () => {
      toast.success('Resume deleted.')
      queryClient.invalidateQueries({ queryKey: ['resumes'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not delete this resume.'),
  })

  const primaryMutation = useMutation({
    mutationFn: setPrimaryResume,
    onSuccess: () => {
      toast.success('Primary resume updated.')
      queryClient.invalidateQueries({ queryKey: ['resumes'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update primary resume.'),
  })

  function onFileSelected(e: ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (file) uploadMutation.mutate(file)
    e.target.value = ''
  }

  return (
    <div>
      <WorkspacePageHeader tone="candidate"
        title="My resumes"
        subtitle={
          data && data.length > 0
            ? `${data.length} resume${data.length === 1 ? '' : 's'} on file. Your primary resume is used by default when applying.`
            : 'Upload a resume to start applying to jobs.'
        }
        actions={
          <>
            <Link to="/dashboard/resume-builder">
              <Button variant="outline">Resume builder</Button>
            </Link>
            <input ref={fileInputRef} type="file" accept=".pdf,.doc,.docx" hidden onChange={onFileSelected} />
            <Button variant="accent" loading={uploadMutation.isPending} onClick={() => fileInputRef.current?.click()}>
              Upload resume
            </Button>
          </>
        }
      />

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 2 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load your resumes. Please try again.
        </div>
      )}

      {!isLoading && data && data.length === 0 && (
        <EmptyState
          title="No resumes on file yet"
          description="Upload a resume (PDF, DOC, or DOCX, up to 5MB) so you can start applying, or build one from scratch."
          action={
            <Button variant="accent" loading={uploadMutation.isPending} onClick={() => fileInputRef.current?.click()}>
              Upload resume
            </Button>
          }
          secondaryAction={
            <Link to="/dashboard/resume-builder">
              <Button variant="outline">Use resume builder</Button>
            </Link>
          }
        />
      )}

      {!isLoading && data && data.length > 0 && (
        <div className="jp-jobs-list">
          {data.map((resume) => (
            <ResumeCard
              key={resume.id}
              resume={resume}
              expanded={expandedId === resume.id}
              onToggleExpand={() => setExpandedId(expandedId === resume.id ? null : resume.id)}
              primaryPending={primaryMutation.isPending && primaryMutation.variables === resume.id}
              onMakePrimary={() => primaryMutation.mutate(resume.id)}
              deletePending={deleteMutation.isPending && deleteMutation.variables === resume.id}
              onDelete={() => {
                if (window.confirm(`Delete "${resume.file_name}"? This cannot be undone.`)) {
                  deleteMutation.mutate(resume.id)
                }
              }}
            />
          ))}
        </div>
      )}
    </div>
  )
}

function ResumeCard({
  resume,
  expanded,
  onToggleExpand,
  primaryPending,
  onMakePrimary,
  deletePending,
  onDelete,
}: {
  resume: ResumeRow
  expanded: boolean
  onToggleExpand: () => void
  primaryPending: boolean
  onMakePrimary: () => void
  deletePending: boolean
  onDelete: () => void
}) {
  const parsed = parseResumeDetail(resume)
  const fileSize = formatFileSize(resume.file_size)
  const completeness = resume.completeness ?? parsed?.completeness

  return (
    <Card>
      <CardBody>
        <div className="jp-job-row">
          <div>
            <h2 className="jp-job-title">
              <a href={resume.file_url} target="_blank" rel="noreferrer">
                {resume.file_name}
              </a>
            </h2>
            <p className="jp-job-company">
              Uploaded {new Date(resume.created_at).toLocaleDateString()}
              {fileSize && <> · {fileSize}</>}
            </p>
          </div>
          <div className="jp-job-badges">
            {resume.is_primary === 1 ? (
              <Badge variant="success">Primary</Badge>
            ) : (
              <Button variant="ghost" size="sm" loading={primaryPending} onClick={onMakePrimary}>
                Make primary
              </Button>
            )}
            <Button variant="danger" size="sm" loading={deletePending} onClick={onDelete}>
              Delete
            </Button>
          </div>
        </div>

        {typeof completeness === 'number' && (
          <div className="jp-resumes__completeness">
            <div className="jp-resumes__completeness-row">
              <span className="jp-resumes__completeness-label">Profile-readiness score</span>
              <span className="jp-resumes__completeness-value">{completeness}%</span>
            </div>
            <div className="jp-resumes__completeness-track">
              <div
                className={`jp-resumes__completeness-fill jp-resumes__completeness-fill--${completenessVariant(completeness)}`}
                style={{ width: `${Math.min(100, Math.max(0, completeness))}%` }}
              />
            </div>
            {parsed && !parsed.error && (
              <button type="button" className="jp-resumes__toggle-btn" aria-expanded={expanded} onClick={onToggleExpand}>
                {expanded ? 'Hide what we found' : 'What we found in this resume'}
              </button>
            )}
            {parsed?.error && <p className="jp-resumes__parse-error">Could not extract details from this file automatically.</p>}
          </div>
        )}

        {expanded && parsed && !parsed.error && (
          <div className="jp-resumes__details">
            {parsed.current_title && (
              <DetailRow label="Current title" value={parsed.current_title} confidence={parsed.field_confidence?.current_title} />
            )}
            {parsed.current_company && (
              <DetailRow label="Current company" value={parsed.current_company} confidence={parsed.field_confidence?.current_company} />
            )}
            {typeof parsed.experience_years === 'number' && parsed.experience_years > 0 && (
              <DetailRow
                label="Experience"
                value={`${parsed.experience_years} year${parsed.experience_years === 1 ? '' : 's'}`}
                confidence={parsed.field_confidence?.experience_years}
              />
            )}
            {parsed.skills && parsed.skills.length > 0 && (
              <div className="jp-resumes__detail-row">
                <span className="jp-resumes__detail-label">Skills detected</span>
                <div className="jp-resumes__skill-chips">
                  {parsed.skills.map((s) => (
                    <Badge key={s} variant="gray">
                      {s}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            {parsed.education && parsed.education.length > 0 && (
              <div className="jp-resumes__detail-row">
                <span className="jp-resumes__detail-label">Education</span>
                <span className="jp-resumes__detail-value">{parsed.education.join(', ')}</span>
              </div>
            )}
            <p className="jp-resumes__hint">
              Low-confidence fields are marked for review — double-check them on your profile before relying on them.
            </p>
          </div>
        )}
      </CardBody>
    </Card>
  )
}

function DetailRow({ label, value, confidence }: { label: string; value: string; confidence?: 'high' | 'low' }) {
  return (
    <div className="jp-resumes__detail-row">
      <span className="jp-resumes__detail-label">{label}</span>
      <span className="jp-resumes__detail-value">
        {value}
        {confidence === 'low' && (
          <Badge variant="warning" style={{ marginLeft: 8 }}>
            Review
          </Badge>
        )}
      </span>
    </div>
  )
}
