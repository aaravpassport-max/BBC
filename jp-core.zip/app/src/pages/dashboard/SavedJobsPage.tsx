import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { listSavedJobs, toggleSaveJob, updateSavedJobNote, type SavedJobRow } from '@/features/savedJobs/api'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { StatCard } from '@/components/ui/StatCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { FilterBar } from '@/components/ui/FilterBar'
import '../public/JobsPage.css'
import './SavedJobsPage.css'

/**
 * Batch 32 (phase 4) — root-cause fix: SavedJobRow is JobRow & {saved_at},
 * so status/salary_min/max/visible/job_type were all already present on
 * every row this page fetches, but the page rendered only title/company/
 * location/remote-badge. A job saved weeks ago can have closed since — the
 * candidate had no way to tell without opening it. Adds a real "no longer
 * accepting applications" flag plus salary and saved-date, all sourced
 * from data already on the row.
 *
 * Phase 3 redesign (Tier A, redesign-plan §SavedJobsPage) — that closed
 * badge could actually never render, because get_saved_jobs() unconditionally
 * filtered `j.status='active'` server-side: a closed job silently vanished
 * from the response instead of arriving with a closed indicator. Fixed at
 * the root (class-jp-api.php) rather than patching around it here. With
 * closed jobs now genuinely reachable, added a real Show filter (All /
 * Open only) and a sort (recently saved / title), plus the company logo
 * that was already on every row (c.logo_url) but never rendered.
 */
function isJobStillOpen(status: string): boolean {
  return status === 'active'
}

function formatSalary(min: number, max: number, currency: string): string | null {
  if (!min && !max) return null
  const fmt = (n: number) => n.toLocaleString()
  if (min && max) return `${currency} ${fmt(min)} – ${fmt(max)} / yr`
  return `${currency} ${fmt(min || max)} / yr`
}

/**
 * job.experience_min/max are real columns on jp_jobs (part of `j.*` in
 * get_saved_jobs()), same fields JobsPage.tsx's job cards already surface,
 * but this page never rendered them — a saved job gave no sense of whether
 * the candidate is even eligible without opening it.
 */
function formatExperience(min: number, max: number): string | null {
  if (!min && !max) return null
  if (min && max) return `${min}–${max} yrs exp`
  return `${min || max}+ yrs exp`
}

type ShowFilter = 'all' | 'open'
type SortOrder = 'recent' | 'title'

export function SavedJobsPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [show, setShow] = useState<ShowFilter>('all')
  const [sort, setSort] = useState<SortOrder>('recent')
  // Root-cause fix (schema-exists-no-writer gap): jp_saved_jobs.note is now
  // selected by get_saved_jobs() but had no editor — same local-draft +
  // explicit-Save-button pattern as RecruiterTalentPoolPage's note field.
  const [noteDrafts, setNoteDrafts] = useState<Record<number, string>>({})

  const { data, isLoading, isError } = useQuery({
    queryKey: ['saved-jobs'],
    queryFn: listSavedJobs,
  })

  const unsaveMutation = useMutation({
    mutationFn: (jobId: number) => toggleSaveJob(jobId),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['saved-jobs'] })
    },
    onError: () => toast.error('Could not update saved jobs.'),
  })

  const noteMutation = useMutation({
    mutationFn: ({ jobId, note }: { jobId: number; note: string }) => updateSavedJobNote(jobId, note),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['saved-jobs'] })
    },
    onError: () => toast.error('Could not save your note.'),
  })

  const openCount = (data ?? []).filter((j) => isJobStillOpen(j.status)).length

  const visibleJobs = useMemo(() => {
    const rows: SavedJobRow[] = data ?? []
    const filtered = show === 'open' ? rows.filter((j) => isJobStillOpen(j.status)) : rows
    const sorted = [...filtered]
    if (sort === 'title') sorted.sort((a, b) => a.title.localeCompare(b.title))
    else sorted.sort((a, b) => new Date(b.saved_at).getTime() - new Date(a.saved_at).getTime())
    return sorted
  }, [data, show, sort])

  return (
    <div>
      <WorkspacePageHeader
        tone="candidate"
        title="Saved jobs"
        subtitle="Compare roles you bookmarked, add private notes, and jump back to apply when you're ready."
        stats={
          data && data.length > 0 ? (
            <>
              <StatCard label="Total saved" value={data.length} tone="primary" />
              <StatCard label="Still open" value={openCount} tone="success" />
              <StatCard label="Closed" value={data.length - openCount} />
            </>
          ) : undefined
        }
      />

      {data && data.length > 0 && (
        <FilterBar
          filters={
            <select className="jp-input" value={show} onChange={(e) => setShow(e.target.value as ShowFilter)} aria-label="Filter saved jobs">
              <option value="all">All saved jobs</option>
              <option value="open">Open only</option>
            </select>
          }
          sort={
            <select className="jp-input" value={sort} onChange={(e) => setSort(e.target.value as SortOrder)} aria-label="Sort saved jobs">
              <option value="recent">Recently saved</option>
              <option value="title">Title (A–Z)</option>
            </select>
          }
        />
      )}

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load your saved jobs.</p>}

      {!isLoading && data && data.length === 0 && (
        <EmptyState
          title="No saved jobs yet"
          description="Save a job while browsing to come back to it later — you'll find it here."
          action={
            <Link to="/jobs">
              <Button variant="accent">Browse jobs</Button>
            </Link>
          }
        />
      )}

      {!isLoading && data && data.length > 0 && visibleJobs.length === 0 && (
        <EmptyState title="No open saved jobs" description={'All of your saved jobs have closed. Switch to "All saved jobs" to see them.'} />
      )}

      {!isLoading && visibleJobs.length > 0 && (
        <div className="jp-jobs-list">
          {visibleJobs.map((job) => {
            const stillOpen = isJobStillOpen(job.status)
            const salary = job.salary_visible === 1 ? formatSalary(job.salary_min, job.salary_max, job.salary_currency) : null
            const experience = formatExperience(job.experience_min, job.experience_max)
            return (
              <Card key={job.id} className="jp-application-card">
                <CardBody>
                  <div className="jp-job-row">
                    <div className="jp-saved-jobs__identity">
                      {job.logo_url ? (
                        <img src={job.logo_url} alt="" className="jp-saved-jobs__logo" />
                      ) : (
                        <div className="jp-saved-jobs__logo jp-saved-jobs__logo--placeholder">{job.company_name[0]}</div>
                      )}
                      <div>
                        <h2 className="jp-job-title">
                          <Link to={`/jobs/${job.id}`}>{job.title}</Link>
                        </h2>
                        <p className="jp-job-company">
                          {job.company_name}
                          {job.company_verified === 1 && (
                            <span className="jp-saved-jobs__verified" title="Verified company">✓</span>
                          )}
                          {' · '}
                          {job.location_city || 'Location not specified'}
                        </p>
                        <p className="jp-job-company">
                          Saved {new Date(job.saved_at.replace(' ', 'T')).toLocaleDateString()}
                          {salary && <> · {salary}</>}
                          {experience && <> · {experience}</>}
                        </p>
                      </div>
                    </div>
                    <div className="jp-job-badges">
                      {!stillOpen && <Badge variant="error">No longer accepting applications</Badge>}
                      {stillOpen && job.is_featured === 1 && <Badge variant="accent">Featured</Badge>}
                      {stillOpen && job.is_urgent === 1 && <Badge variant="error">Urgently hiring</Badge>}
                      {stillOpen && job.work_mode === 'remote' && <Badge variant="info">Remote</Badge>}
                      {stillOpen && <Badge variant="gray">{job.job_type}</Badge>}
                      {stillOpen && (
                        <Link to={`/jobs/${job.id}`}>
                          <Button variant="accent" size="sm">
                            Apply now
                          </Button>
                        </Link>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        loading={unsaveMutation.isPending && unsaveMutation.variables === job.id}
                        onClick={() => unsaveMutation.mutate(job.id)}
                      >
                        Remove
                      </Button>
                    </div>
                  </div>
                  <div className="jp-saved-jobs__note" style={{ marginTop: 12 }}>
                    <label className="jp-label" htmlFor={`saved-job-note-${job.id}`}>
                      Private note
                    </label>
                    <textarea
                      id={`saved-job-note-${job.id}`}
                      className="jp-textarea"
                      rows={2}
                      maxLength={300}
                      placeholder="e.g. Ask about remote policy before applying..."
                      value={noteDrafts[job.id] ?? job.note ?? ''}
                      onChange={(e) => setNoteDrafts((prev) => ({ ...prev, [job.id]: e.target.value }))}
                    />
                    {(noteDrafts[job.id] ?? job.note ?? '') !== (job.note ?? '') && (
                      <Button
                        variant="outline"
                        size="sm"
                        style={{ marginTop: 6 }}
                        loading={noteMutation.isPending && noteMutation.variables?.jobId === job.id}
                        onClick={() => noteMutation.mutate({ jobId: job.id, note: noteDrafts[job.id] ?? '' })}
                      >
                        Save note
                      </Button>
                    )}
                  </div>
                </CardBody>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
