import { useEffect, useRef, useState, type FormEvent } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { getMe, updateProfile, type ProfileUpdatePayload } from '@/features/candidates/api'
import { getCandidateAnalytics, uploadAvatar } from '@/features/candidates/meApi'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { useToast } from '@/components/ui/ToastProvider'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { StatCard } from '@/components/ui/StatCard'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './ProfilePage.css'

function AvatarUploader({ avatarUrl }: { avatarUrl: string | null }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const fileInputRef = useRef<HTMLInputElement>(null)

  const uploadMutation = useMutation({
    mutationFn: uploadAvatar,
    onSuccess: () => {
      toast.success('Photo updated.')
      queryClient.invalidateQueries({ queryKey: ['me'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not upload photo.'),
  })

  return (
    <SectionCard title="Profile photo" className="jp-profile-page__section">
      <div className="jp-job-row">
        <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
          {avatarUrl ? (
            <img src={avatarUrl} alt="Your profile photo" style={{ width: 64, height: 64, borderRadius: '50%', objectFit: 'cover' }} />
          ) : (
            <div
              style={{
                width: 64,
                height: 64,
                borderRadius: '50%',
                background: 'var(--jp-gray-200)',
              }}
            />
          )}
          <div>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/jpeg,image/png,image/webp,image/gif"
              hidden
              onChange={(e) => {
                const file = e.target.files?.[0]
                if (file) uploadMutation.mutate(file)
                e.target.value = ''
              }}
            />
            <Button
              type="button"
              variant="outline"
              size="sm"
              loading={uploadMutation.isPending}
              onClick={() => fileInputRef.current?.click()}
            >
              Change photo
            </Button>
            <p className="jp-job-company" style={{ marginTop: 6 }}>
              JPG, PNG, WebP or GIF · up to 2 MB
            </p>
          </div>
        </div>
      </div>
    </SectionCard>
  )
}

function ProfileAnalyticsPanel() {
  const { data } = useQuery({ queryKey: ['candidate-analytics'], queryFn: () => getCandidateAnalytics(30) })
  if (!data) return null

  return (
    <div className="jp-profile-page__stats">
      <StatCard label="Profile views (30d)" value={data.profile_views} tone="primary" />
      <StatCard label="Search appearances" value={data.search_appears} />
      <StatCard label="Applications" value={data.applications} />
      <StatCard label="Shortlisted" value={data.shortlisted} tone="success" />
    </div>
  )
}

type FormState = ProfileUpdatePayload & { skillsText: string }

const EMPTY_FORM: FormState = {
  display_name: '',
  headline: '',
  about: '',
  location_city: '',
  location_state: '',
  phone: '',
  experience_years: 0,
  current_title: '',
  current_company: '',
  linkedin_url: '',
  github_url: '',
  portfolio_url: '',
  current_salary: 0,
  expected_salary_min: 0,
  expected_salary_max: 0,
  notice_period_days: 0,
  preferred_work_mode: 'any',
  willing_to_relocate: 0,
  is_open_to_work: 1,
  visibility: 'public',
  skillsText: '',
}

export function ProfilePage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [form, setForm] = useState<FormState>(EMPTY_FORM)

  const { data: me, isLoading, isError } = useQuery({ queryKey: ['me'], queryFn: getMe })

  // Synchronizes local, editable form state with the server's copy once it
  // arrives — a legitimate external-sync effect (React Query owns the
  // fetch; this component owns the in-progress edit), not derived render
  // state, since the user then mutates `form` independently of `me`.
  useEffect(() => {
    if (!me) return
    const c = me.candidate
    setForm({
      display_name: me.name,
      headline: c?.headline ?? '',
      about: c?.about ?? '',
      location_city: c?.location_city ?? '',
      location_state: c?.location_state ?? '',
      phone: c?.phone ?? '',
      experience_years: c?.experience_years ?? 0,
      current_title: c?.current_title ?? '',
      current_company: c?.current_company ?? '',
      linkedin_url: c?.linkedin_url ?? '',
      github_url: c?.github_url ?? '',
      portfolio_url: c?.portfolio_url ?? '',
      current_salary: c?.current_salary ?? 0,
      expected_salary_min: c?.expected_salary_min ?? 0,
      expected_salary_max: c?.expected_salary_max ?? 0,
      notice_period_days: c?.notice_period_days ?? 0,
      preferred_work_mode: c?.preferred_work_mode ?? 'any',
      willing_to_relocate: c?.willing_to_relocate ?? 0,
      is_open_to_work: c?.is_open_to_work ?? 1,
      visibility: c?.visibility ?? 'public',
      skillsText: (c?.skills ?? []).join(', '),
    })
  }, [me])

  const saveMutation = useMutation({
    mutationFn: (payload: ProfileUpdatePayload) => updateProfile(payload),
    onSuccess: () => {
      toast.success('Profile updated.')
      queryClient.invalidateQueries({ queryKey: ['me'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not save your profile.'),
  })

  function field<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    const { skillsText, ...rest } = form
    const skills = skillsText
      .split(',')
      .map((s) => s.trim())
      .filter(Boolean)
    saveMutation.mutate({ ...rest, skills })
  }

  if (isLoading) {
    return (
      <div className="jp-profile-form">
        <Skeleton height={32} width="40%" />
        <div style={{ height: 16 }} />
        <Skeleton height={300} width="100%" />
      </div>
    )
  }

  // Root-cause fix: on a fetch failure `me` stays undefined, the hydration
  // effect above never runs (`if (!me) return`), and `form` stays at its
  // initial blank state with no error shown — a candidate would see every
  // profile field empty with no indication their real profile failed to
  // load, and submitting would overwrite it with blanks.
  if (isError) {
    return (
      <div className="jp-jobs-error" role="alert">
        Could not load your profile. Please try again.
      </div>
    )
  }

  return (
    <form className="jp-profile-form" onSubmit={onSubmit}>
      <WorkspacePageHeader tone="candidate"
        title="My profile"
        subtitle="Recruiters see this information when they view your application or search the candidate directory."
      />

      <AvatarUploader avatarUrl={me?.candidate?.avatar_url ?? null} />
      <ProfileAnalyticsPanel />

      <SectionCard title="Basic information" className="jp-profile-page__section">
        <div className="jp-profile-grid">
          <Input label="Full name" value={form.display_name} onChange={(e) => field('display_name', e.target.value)} />
          <Input label="Headline" value={form.headline} onChange={(e) => field('headline', e.target.value)} />
          <Input label="Current title" value={form.current_title} onChange={(e) => field('current_title', e.target.value)} />
          <Input label="Current company" value={form.current_company} onChange={(e) => field('current_company', e.target.value)} />
          <Input label="City" value={form.location_city} onChange={(e) => field('location_city', e.target.value)} />
          <Input label="State" value={form.location_state} onChange={(e) => field('location_state', e.target.value)} />
          <Input label="Phone" value={form.phone} onChange={(e) => field('phone', e.target.value)} />
          <Input
            label="Years of experience"
            type="number"
            min={0}
            value={form.experience_years}
            onChange={(e) => field('experience_years', Number(e.target.value))}
          />
        </div>
      </SectionCard>

      <SectionCard title="About & skills" className="jp-profile-page__section">
        <div className="jp-form-group">
          <label className="jp-label" htmlFor="about">
            About
          </label>
          <textarea
            id="about"
            className="jp-textarea"
            rows={5}
            value={form.about}
            onChange={(e) => field('about', e.target.value)}
          />
        </div>
        <Input label="Skills (comma separated)" value={form.skillsText} onChange={(e) => field('skillsText', e.target.value)} />
      </SectionCard>

      <SectionCard title="Links" className="jp-profile-page__section">
        <div className="jp-profile-grid">
          <Input label="LinkedIn URL" value={form.linkedin_url} onChange={(e) => field('linkedin_url', e.target.value)} />
          <Input label="GitHub URL" value={form.github_url} onChange={(e) => field('github_url', e.target.value)} />
          <Input label="Portfolio URL" value={form.portfolio_url} onChange={(e) => field('portfolio_url', e.target.value)} />
        </div>
      </SectionCard>

      <SectionCard title="Compensation & availability" className="jp-profile-page__section">
        <div className="jp-profile-grid">
          <Input
            label="Current salary"
            type="number"
            min={0}
            value={form.current_salary}
            onChange={(e) => field('current_salary', Number(e.target.value))}
          />
          <Input
            label="Expected salary (min)"
            type="number"
            min={0}
            value={form.expected_salary_min}
            onChange={(e) => field('expected_salary_min', Number(e.target.value))}
          />
          <Input
            label="Expected salary (max)"
            type="number"
            min={0}
            value={form.expected_salary_max}
            onChange={(e) => field('expected_salary_max', Number(e.target.value))}
          />
          <Input
            label="Notice period (days)"
            type="number"
            min={0}
            value={form.notice_period_days}
            onChange={(e) => field('notice_period_days', Number(e.target.value))}
          />
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="work-mode">
              Preferred work mode
            </label>
            <select
              id="work-mode"
              className="jp-input"
              value={form.preferred_work_mode}
              onChange={(e) => field('preferred_work_mode', e.target.value as FormState['preferred_work_mode'])}
            >
              <option value="any">Any</option>
              <option value="onsite">On-site</option>
              <option value="remote">Remote</option>
              <option value="hybrid">Hybrid</option>
            </select>
          </div>
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="visibility">
              Profile visibility
            </label>
            <select
              id="visibility"
              className="jp-input"
              value={form.visibility}
              onChange={(e) => field('visibility', e.target.value as FormState['visibility'])}
            >
              <option value="public">Public</option>
              <option value="recruiters">Recruiters only</option>
              <option value="private">Private</option>
            </select>
          </div>
        </div>
        <div className="jp-profile-checks">
          <label className="jp-checkbox">
            <input
              type="checkbox"
              checked={form.willing_to_relocate === 1}
              onChange={(e) => field('willing_to_relocate', e.target.checked ? 1 : 0)}
            />
            Willing to relocate
          </label>
          <label className="jp-checkbox">
            <input
              type="checkbox"
              checked={form.is_open_to_work === 1}
              onChange={(e) => field('is_open_to_work', e.target.checked ? 1 : 0)}
            />
            Open to work
          </label>
        </div>
      </SectionCard>

      <Button type="submit" variant="accent" loading={saveMutation.isPending}>
        Save profile
      </Button>
    </form>
  )
}
