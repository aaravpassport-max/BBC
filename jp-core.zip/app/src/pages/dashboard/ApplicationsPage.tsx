import { useMemo, useState } from 'react'
import { Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  getApplicationDetail,
  getApplicationResumeUrl,
  listApplications,
  respondToOffer,
  withdrawApplication,
  type ApplicationRow,
  type ApplicationStage,
} from '@/features/applications/api'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { StatCard } from '@/components/ui/StatCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './ApplicationsPage.css'

const STAGE_LABEL: Record<ApplicationStage, string> = {
  applied: 'Applied',
  shortlisted: 'Shortlisted',
  viewed: 'Viewed',
  phone_screen: 'Phone screen',
  interview: 'Interview',
  assessment: 'Assessment',
  offer: 'Offer',
  hired: 'Hired',
  rejected: 'Not selected',
  withdrawn: 'Withdrawn',
}

const STAGE_VARIANT: Record<ApplicationStage, 'gray' | 'info' | 'success' | 'warning' | 'error'> = {
  applied: 'gray',
  shortlisted: 'info',
  viewed: 'gray',
  phone_screen: 'info',
  interview: 'info',
  assessment: 'info',
  offer: 'success',
  hired: 'success',
  rejected: 'error',
  withdrawn: 'warning',
}

// Root-cause fix (batch 16): withdrawal is now reachable — see
// features/applications/api.ts's withdrawApplication() docblock for the
// full gap trace (backend existed, no route, no SPA caller anywhere).
const WITHDRAWABLE_STAGES: ApplicationStage[] = [
  'applied', 'shortlisted', 'viewed', 'phone_screen', 'interview', 'assessment', 'offer',
]

const IN_PROGRESS_STAGES: ApplicationStage[] = ['applied', 'viewed', 'shortlisted', 'phone_screen']
const INTERVIEWING_STAGES: ApplicationStage[] = ['interview', 'assessment']

/**
 * Batch 32 (phase 4) — root-cause fix: ApplicationRow.match_score,
 * .interview_date, .offer_ctc, and .source have all been returned by
 * GET /applications since the route existed (get_applications()'s
 * `SELECT a.*, ...` — see class-jp-api.php), but this page never rendered
 * any of them. Same "data exists in the API response, UI never renders
 * it" class as batch 24's fix on JobDetailPage. All four are shown below
 * only when present/meaningful, never fabricated for rows that lack them.
 */
function ApplicationCard({
  app,
  onWithdraw,
  withdrawPending,
  onOfferResponse,
  offerPending,
  expanded,
  onToggleExpand,
}: {
  app: ApplicationRow
  onWithdraw: (id: number) => void
  withdrawPending: boolean
  onOfferResponse: (id: number, response: 'accepted' | 'declined') => void
  offerPending: { id: number; response: 'accepted' | 'declined' } | null
  expanded: boolean
  onToggleExpand: () => void
}) {
  return (
    <Card className="jp-application-card">
      <CardBody>
        <div className="jp-job-row">
          <div>
            <h2 className="jp-job-title">
              <Link to={`/jobs/${app.job_id}`}>{app.job_title}</Link>
            </h2>
            <p className="jp-job-company">Applied {new Date(app.created_at).toLocaleDateString()}</p>
            <ul className="jp-application-card__facts">
              {app.match_score > 0 && <li>🎯 {Math.round(app.match_score)}% match</li>}
              {app.interview_date && (
                <li>📅 Interview scheduled: {new Date(app.interview_date.replace(' ', 'T')).toLocaleString()}</li>
              )}
              {app.offer_ctc > 0 && <li>💰 Offer: {app.offer_ctc.toLocaleString()}</li>}
              {app.source && app.source !== 'direct' && <li>via {app.source}</li>}
            </ul>
            {app.offer_status === 'sent' && app.offer_pdf_url && (
              <p className="jp-job-company">
                <a href={app.offer_pdf_url} target="_blank" rel="noreferrer">
                  View your offer letter
                </a>
              </p>
            )}
            {app.offer_status === 'accepted' && <p className="jp-job-company">You accepted this offer.</p>}
            {app.offer_status === 'declined' && <p className="jp-job-company">You declined this offer.</p>}
          </div>
          <div className="jp-job-badges">
            <Badge variant={STAGE_VARIANT[app.stage]}>{STAGE_LABEL[app.stage]}</Badge>
            {app.offer_status === 'sent' && (
              <>
                <Button
                  variant="accent"
                  size="sm"
                  loading={offerPending?.id === app.id && offerPending.response === 'accepted'}
                  onClick={() => onOfferResponse(app.id, 'accepted')}
                >
                  Accept offer
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  loading={offerPending?.id === app.id && offerPending.response === 'declined'}
                  onClick={() => {
                    if (window.confirm(`Decline the offer for "${app.job_title}"? This cannot be undone.`)) {
                      onOfferResponse(app.id, 'declined')
                    }
                  }}
                >
                  Decline
                </Button>
              </>
            )}
            {WITHDRAWABLE_STAGES.includes(app.stage) && (
              <Button
                variant="outline"
                size="sm"
                loading={withdrawPending}
                onClick={() => {
                  if (window.confirm(`Withdraw your application for "${app.job_title}"? This cannot be undone.`)) {
                    onWithdraw(app.id)
                  }
                }}
              >
                Withdraw
              </Button>
            )}
            <Button type="button" variant="ghost" size="sm" onClick={onToggleExpand} aria-expanded={expanded}>
              {expanded ? 'Hide details' : 'Track application'}
            </Button>
          </div>
        </div>

        {expanded && <ApplicationTrackingPanel applicationId={app.id} />}
      </CardBody>
    </Card>
  )
}

/**
 * New in batch 38 (candidate application-tracking depth). Gives the
 * candidate genuine visibility into their own application — a stage
 * timeline, their submitted screening answers, and their attached resume
 * — sourced from get_application()'s candidate-safe branch (batch 38's
 * privacy fix: internal recruiter notes/tags/stage-note text are stripped
 * server-side before this response is built, so nothing internal reaches
 * this component even though it reuses the same endpoint the recruiter
 * ATS detail panel calls).
 */
function ApplicationTrackingPanel({ applicationId }: { applicationId: number }) {
  const { data, isLoading, isError } = useQuery({
    queryKey: ['application-detail', applicationId],
    queryFn: () => getApplicationDetail(applicationId),
  })

  return (
    <div className="jp-app-tracking" style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--jp-gray-200)' }}>
      {isLoading && <p className="jp-app-tracking__loading">Loading…</p>}
      {isError && <p className="jp-jobs-error" role="alert">Could not load application details.</p>}
      {data && (
        <div className="jp-app-tracking__grid">
          <section>
            <h3 className="jp-app-tracking__heading">Application timeline</h3>
            {data.stage_history.length > 0 ? (
              <ol className="jp-app-tracking__timeline">
                {data.stage_history.map((h, i) => (
                  <li key={i}>
                    <span className="jp-app-tracking__timeline-stage">{STAGE_LABEL[h.stage] ?? h.stage}</span>
                    <span className="jp-app-tracking__meta">
                      {new Date(h.timestamp.replace(' ', 'T')).toLocaleString(undefined, {
                        dateStyle: 'medium',
                        timeStyle: 'short',
                      })}
                    </span>
                  </li>
                ))}
              </ol>
            ) : (
              <p className="jp-app-tracking__empty">No timeline events recorded yet.</p>
            )}
          </section>

          {data.cover_letter && (
            <section>
              <h3 className="jp-app-tracking__heading">Your cover letter</h3>
              <p className="jp-app-tracking__cover-letter">{data.cover_letter}</p>
            </section>
          )}

          {data.screening_ans.length > 0 && (
            <section>
              <h3 className="jp-app-tracking__heading">Your screening answers</h3>
              <ol className="jp-app-tracking__answers">
                {data.screening_ans.map((ans, i) => (
                  <li key={i}>{ans || <em>No answer given</em>}</li>
                ))}
              </ol>
            </section>
          )}

          {data.resume_file_name && (
            <section>
              <h3 className="jp-app-tracking__heading">Resume submitted</h3>
              <a href={getApplicationResumeUrl(applicationId)} target="_blank" rel="noreferrer">
                {data.resume_file_name}
              </a>
            </section>
          )}
        </div>
      )}
    </div>
  )
}

export function ApplicationsPage() {
  const [stage, setStage] = useState<ApplicationStage | ''>('')
  const [withdrawingId, setWithdrawingId] = useState<number | null>(null)
  const [expandedId, setExpandedId] = useState<number | null>(null)
  const toast = useToast()
  const queryClient = useQueryClient()

  const { data, isLoading, isError } = useQuery({
    queryKey: ['applications', stage],
    queryFn: () => listApplications(stage ? { stage } : {}),
  })

  // Batch 32: the unfiltered set (independent of the stage dropdown above)
  // powers the summary strip so switching filters doesn't make the
  // summary numbers themselves jump around — a KPI strip should read as
  // "your whole pipeline," not "your currently filtered view."
  const { data: allApplications } = useQuery({
    queryKey: ['applications', ''],
    queryFn: () => listApplications(),
  })

  const summary = useMemo(() => {
    const rows = allApplications ?? []
    return {
      total: rows.length,
      inProgress: rows.filter((r) => IN_PROGRESS_STAGES.includes(r.stage)).length,
      interviewing: rows.filter((r) => INTERVIEWING_STAGES.includes(r.stage)).length,
      offers: rows.filter((r) => r.stage === 'offer' || r.stage === 'hired').length,
    }
  }, [allApplications])

  const withdrawMutation = useMutation({
    mutationFn: withdrawApplication,
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['applications'] })
      setWithdrawingId(null)
    },
    onError: () => {
      toast.error('Could not withdraw this application.')
      setWithdrawingId(null)
    },
  })

  const offerResponseMutation = useMutation({
    mutationFn: ({ id, response }: { id: number; response: 'accepted' | 'declined' }) => respondToOffer(id, response),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['applications'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not record your response.'),
  })

  return (
    <div className="jp-applications-page">
      <WorkspacePageHeader
        tone="candidate"
        title="My applications"
        subtitle="Track every application you've submitted, respond to offers, and expand any row for your timeline."
        stats={
          <>
            <StatCard label="Total" value={summary.total} tone="primary" />
            <StatCard label="In progress" value={summary.inProgress} />
            <StatCard label="Interviewing" value={summary.interviewing} tone="warning" />
            <StatCard label="Offers & hires" value={summary.offers} tone="success" />
          </>
        }
      />

      <div className="jp-applications-page__pipeline" role="tablist" aria-label="Filter by stage">
        <button
          type="button"
          role="tab"
          aria-selected={stage === ''}
          className={['jp-applications-page__stage-chip', stage === '' ? 'is-active' : ''].filter(Boolean).join(' ')}
          onClick={() => setStage('')}
        >
          All stages
        </button>
        {Object.entries(STAGE_LABEL).map(([value, label]) => (
          <button
            key={value}
            type="button"
            role="tab"
            aria-selected={stage === value}
            className={['jp-applications-page__stage-chip', stage === value ? 'is-active' : ''].filter(Boolean).join(' ')}
            onClick={() => setStage(value as ApplicationStage)}
          >
            {label}
          </button>
        ))}
      </div>

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load your applications.</p>}

      {!isLoading && data && data.length === 0 && (
        <EmptyState
          title={stage ? `No applications in "${STAGE_LABEL[stage]}"` : "You haven't applied to any jobs yet"}
          description={stage ? 'Try a different stage filter, or browse open roles.' : 'Once you apply, you can track every application and its status here.'}
          action={
            <Link to="/jobs">
              <Button variant="accent">Browse jobs</Button>
            </Link>
          }
        />
      )}

      {!isLoading && data && data.length > 0 && (
        <div className="jp-jobs-list">
          {data.map((app) => (
            <ApplicationCard
              key={app.id}
              app={app}
              withdrawPending={withdrawMutation.isPending && withdrawingId === app.id}
              onWithdraw={(id) => {
                setWithdrawingId(id)
                withdrawMutation.mutate(id)
              }}
              offerPending={
                offerResponseMutation.isPending && offerResponseMutation.variables
                  ? offerResponseMutation.variables
                  : null
              }
              onOfferResponse={(id, response) => offerResponseMutation.mutate({ id, response })}
              expanded={expandedId === app.id}
              onToggleExpand={() => setExpandedId(expandedId === app.id ? null : app.id)}
            />
          ))}
        </div>
      )}
    </div>
  )
}
