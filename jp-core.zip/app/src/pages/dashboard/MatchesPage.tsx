import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { dismissMatch, getMatches, matchJobId, type MatchRow } from '@/features/matches/api'
import { toggleSaveJob } from '@/features/savedJobs/api'
import { ApiError } from '@/lib/apiClient'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Button } from '@/components/ui/Button'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { MatchCard } from '@/components/dashboard/MatchCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import './MatchesPage.css'

export function MatchesPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [expandedKey, setExpandedKey] = useState<string | null>(null)

  const { data, isLoading, isError } = useQuery({ queryKey: ['matches'], queryFn: getMatches })

  const dismissMutation = useMutation({
    mutationFn: (jobId: number) => dismissMatch(jobId),
    onSuccess: (result, jobId) => {
      toast.success(result.message)
      queryClient.setQueryData<MatchRow[]>(['matches'], (prev) =>
        prev ? prev.filter((m) => matchJobId(m) !== jobId) : prev,
      )
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not dismiss this recommendation.'),
  })

  const saveMutation = useMutation({
    mutationFn: (jobId: number) => toggleSaveJob(jobId),
    onSuccess: (result) => toast.success(result.message),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update saved jobs.'),
  })

  return (
    <div className="jp-matches-page">
      <WorkspacePageHeader
        tone="candidate"
        title="Recommended for you"
        subtitle={
          data && data.length > 0
            ? `${data.length} job${data.length === 1 ? '' : 's'} matched to your profile and skills.`
            : 'Jobs matched to your profile and skills show up here.'
        }
      />

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load your matches.</p>}

      {!isLoading && data && data.length === 0 && (
        <EmptyState
          title="No matches yet"
          description="Complete your profile and add your skills to get personalized job recommendations."
          action={
            <Link to="/dashboard/profile">
              <Button variant="accent">Update your profile</Button>
            </Link>
          }
        />
      )}

      {!isLoading && data && data.length > 0 && (
        <div className="jp-matches-page__list">
          {data.map((m) => {
            const jobId = matchJobId(m)
            const rowKey = `${jobId}-${m.id}`
            return (
              <MatchCard
                key={rowKey}
                match={m}
                expanded={expandedKey === rowKey}
                onToggleExpand={() => setExpandedKey(expandedKey === rowKey ? null : rowKey)}
                onSave={() => saveMutation.mutate(jobId)}
                onDismiss={() => dismissMutation.mutate(jobId)}
                saveLoading={saveMutation.isPending && saveMutation.variables === jobId}
                dismissLoading={dismissMutation.isPending && dismissMutation.variables === jobId}
              />
            )
          })}
        </div>
      )}
    </div>
  )
}
