import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { dismissMatch, getMatches, matchJobId, parseScoreDetail, type MatchRow } from '@/features/matches/api'
import { toggleSaveJob } from '@/features/savedJobs/api'
import { ApiError } from '@/lib/apiClient'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import '../public/JobsPage.css'
import './MatchesPage.css'

function scoreVariant(score: number): 'success' | 'info' | 'gray' {
  if (score >= 80) return 'success'
  if (score >= 60) return 'info'
  return 'gray'
}

/**
 * Batch 32 (phase 4b) — root-cause fix: MatchRow already carries job_type,
 * work_mode, salary_min/max whenever the real-time fallback path populates
 * them (see features/matches/api.ts's docblock on the two divergent row
 * shapes) but this page rendered only title/company/location/score —
 * throwing away exactly the information a candidate needs to judge a
 * recommendation without opening it. Rendered defensively since the
 * pre-computed jp_matches path may not carry these fields at all.
 */
function formatSalary(min?: number, max?: number): string | null {
  if (!min && !max) return null
  const fmt = (n: number) => n.toLocaleString()
  if (min && max) return `${fmt(min)} – ${fmt(max)} / yr`
  return `${fmt(min || max || 0)} / yr`
}

const FACTOR_LABELS: Record<'skills' | 'experience' | 'location' | 'education' | 'salary', string> = {
  skills: 'Skills',
  experience: 'Experience',
  location: 'Location',
  education: 'Education',
  salary: 'Salary fit',
}

/**
 * Enterprise redesign pass, Tier A batch 5 — MatchesPage previously showed
 * only a bare percentage with no explanation of what drove it, and had no
 * way to act on a recommendation the candidate isn't interested in (only
 * "open the job" via the whole-card link). Both gaps closed with real,
 * already-scored backend data rather than fabricated content:
 *  - "Why this match": JP_Matching::score_breakdown() (skills/experience/
 *    location/education/salary + the weights actually used to compute the
 *    score) has been computed and persisted to jp_matches.score_detail
 *    since earlier batches — this page just didn't surface it. The
 *    real-time-fallback path (brand-new candidates before their first
 *    backfill run) now computes it too, so the breakdown is available
 *    regardless of which path served a given row.
 *  - Dismiss: POST .../dismiss writes to the new jp_match_dismissals table;
 *    get_matches_for_candidate() excludes dismissed jobs on the next fetch.
 *    Optimistic local removal here so the action feels immediate rather
 *    than waiting on a refetch.
 *  - Save: reuses the existing toggleSaveJob() used elsewhere in the app
 *    (JobDetailPage, SavedJobsPage) rather than inventing a parallel path.
 */
export function MatchesPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [expandedKey, setExpandedKey] = useState<string | null>(null)

  const { data, isLoading, isError } = useQuery({ queryKey: ['matches'], queryFn: getMatches })

  const dismissMutation = useMutation({
    mutationFn: (jobId: number) => dismissMatch(jobId),
    onSuccess: (result, jobId) => {
      toast.success(result.message)
      queryClient.setQueryData<MatchRow[]>(['matches'], (prev) =>
        prev ? prev.filter((m) => matchJobId(m) !== jobId) : prev
      )
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not dismiss this recommendation.'),
  })

  const saveMutation = useMutation({
    mutationFn: (jobId: number) => toggleSaveJob(jobId),
    onSuccess: (result) => toast.success(result.message),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update saved jobs.'),
  })

  return (
    <div>
      <WorkspacePageHeader tone="candidate"
        title="Recommended for you"
        subtitle={
          data && data.length > 0
            ? `${data.length} job${data.length === 1 ? '' : 's'} matched to your profile and skills.`
            : 'Jobs matched to your profile and skills show up here.'
        }
      />

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load your matches.</p>}

      {!isLoading && data && data.length === 0 && (
        <EmptyState
          title="No matches yet"
          description="Complete your profile and add your skills to get personalized job recommendations."
          action={
            <Link to="/dashboard/profile">
              <Button variant="accent">Update your profile</Button>
            </Link>
          }
        />
      )}

      {!isLoading && data && data.length > 0 && (
        <div className="jp-jobs-list">
          {data.map((m) => {
            const salary = formatSalary(m.salary_min, m.salary_max)
            const jobId = matchJobId(m)
            const rowKey = `${jobId}-${m.id}`
            const breakdown = parseScoreDetail(m)
            const expanded = expandedKey === rowKey

            return (
              <Card key={rowKey}>
                <CardBody>
                  <div className="jp-job-row">
                    <Link to={`/jobs/${jobId}`} className="jp-jobs-link">
                      <div>
                        <h2 className="jp-job-title">{m.title}</h2>
                        <p className="jp-job-company">
                          {m.company_name} · {m.location_city || 'Location not specified'}
                          {salary && <> · {salary}</>}
                        </p>
                      </div>
                    </Link>
                    <div className="jp-job-badges">
                      {m.work_mode === 'remote' && <Badge variant="info">Remote</Badge>}
                      {m.job_type && <Badge variant="gray">{m.job_type}</Badge>}
                      <Badge variant={scoreVariant(m.score)}>{Math.round(m.score)}% match</Badge>
                    </div>
                  </div>

                  <div className="jp-matches__actions">
                    {breakdown && (
                      <button
                        type="button"
                        className="jp-matches__why-btn"
                        aria-expanded={expanded}
                        onClick={() => setExpandedKey(expanded ? null : rowKey)}
                      >
                        {expanded ? 'Hide match details' : 'Why this match?'}
                      </button>
                    )}
                    <div className="jp-matches__action-buttons">
                      <Button
                        variant="outline"
                        size="sm"
                        loading={saveMutation.isPending && saveMutation.variables === jobId}
                        onClick={() => saveMutation.mutate(jobId)}
                      >
                        Save
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        loading={dismissMutation.isPending && dismissMutation.variables === jobId}
                        onClick={() => dismissMutation.mutate(jobId)}
                      >
                        Not interested
                      </Button>
                    </div>
                  </div>

                  {expanded && breakdown && (
                    <div className="jp-matches__breakdown">
                      {(Object.keys(FACTOR_LABELS) as Array<keyof typeof FACTOR_LABELS>).map((factor) => {
                        const value = breakdown[factor]
                        const weightPct = Math.round(breakdown.weights[factor] * 100)
                        return (
                          <div className="jp-matches__factor" key={factor}>
                            <div className="jp-matches__factor-label">
                              <span>{FACTOR_LABELS[factor]}</span>
                              <span className="jp-matches__factor-weight">{weightPct}% of score</span>
                            </div>
                            <div className="jp-matches__factor-track">
                              <div className="jp-matches__factor-fill" style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
                            </div>
                          </div>
                        )
                      })}
                    </div>
                  )}
                </CardBody>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
