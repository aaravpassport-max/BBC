import { useQuery } from '@tanstack/react-query'
import { BADGE_LABELS, getGamificationBadges, getGamificationLeaderboard } from '@/features/gamification/api'
import { PageHeader } from '@/components/ui/PageHeader'
import { StatCard } from '@/components/ui/StatCard'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { Skeleton } from '@/components/ui/Skeleton'
import { ListSkeleton } from '@/components/ui/Skeleton'
import './GamificationPage.css'

const ALL_BADGE_SLUGS = Object.keys(BADGE_LABELS)

export function GamificationPage() {
  const { data, isLoading, isError } = useQuery({ queryKey: ['gamification-badges'], queryFn: getGamificationBadges })
  const { data: board, isLoading: boardLoading } = useQuery({
    queryKey: ['gamification-leaderboard'],
    queryFn: getGamificationLeaderboard,
  })

  if (isLoading) {
    return (
      <div>
        <Skeleton height={28} width="40%" />
        <div style={{ height: 16 }} />
        <Skeleton height={200} width="100%" />
      </div>
    )
  }

  if (isError || !data) {
    return (
      <EmptyState title="Could not load your achievements" description="Please try refreshing the page." />
    )
  }

  const progressPct = Math.min(100, Math.round((data.next_milestone.progress / data.next_milestone.target) * 100))
  const earnedSlugs = new Set(data.earned.map((b) => b.badge))
  const earnedAtBySlug = new Map(data.earned.map((b) => [b.badge, b.awarded_at]))

  return (
    <div>
      <PageHeader
        title="Achievements"
        subtitle="Track your progress and the badges you've earned as you build your profile and apply to jobs."
      />

      <div className="jp-gamification__stats">
        <StatCard label="Profile score" value={`${data.profile_score}%`} tone="primary" />
        <StatCard label="Applications submitted" value={data.applications} />
        <StatCard label="Skill certifications" value={data.certifications} tone="success" />
        <StatCard label="Badges earned" value={`${data.earned.length} / ${ALL_BADGE_SLUGS.length}`} tone="warning" />
      </div>

      <SectionCard title={`Next milestone: ${BADGE_LABELS[data.next_milestone.badge] ?? data.next_milestone.badge}`}>
        <p className="jp-gamification__milestone-desc">{data.next_milestone.description}</p>
        <div className="jp-gamification__progress-track">
          <div className="jp-gamification__progress-fill" style={{ width: `${progressPct}%` }} />
        </div>
        <p className="jp-gamification__progress-label">
          {data.next_milestone.progress} / {data.next_milestone.target} ({progressPct}%)
        </p>
      </SectionCard>

      {/*
       * Batch 32 (phase 5) — root-cause fix: BADGE_LABELS is a fixed,
       * already-known 8-badge catalog (features/gamification/api.ts), but
       * this page previously rendered ONLY data.earned — a candidate with
       * 1 badge saw one pill and nothing else, no sense of what else
       * exists to work toward. Now shows the full catalog with earned
       * badges highlighted and locked ones dimmed, using only the real
       * earned/not-earned fact per badge — no fabricated progress numbers
       * for locked badges beyond what's already shown in the milestone
       * card above.
       */}
      <SectionCard title="All badges">
        <div className="jp-gamification__badge-grid">
          {ALL_BADGE_SLUGS.map((slug) => {
            const earned = earnedSlugs.has(slug)
            const awardedAt = earnedAtBySlug.get(slug)
            return (
              <div key={slug} className={`jp-gamification__badge-tile${earned ? ' is-earned' : ' is-locked'}`}>
                <span className="jp-gamification__badge-icon" aria-hidden="true">{earned ? '🏅' : '🔒'}</span>
                <span className="jp-gamification__badge-label">{BADGE_LABELS[slug]}</span>
                {earned && awardedAt && (
                  <span className="jp-gamification__badge-date">Earned {new Date(awardedAt.replace(' ', 'T')).toLocaleDateString()}</span>
                )}
              </div>
            )
          })}
        </div>
      </SectionCard>

      {/*
       * Phase 3 redesign — the leaderboard the audit called out as missing.
       * Ranked by badge count among candidates who opted into public
       * visibility (same rule public_profile() enforces); the current
       * user's own row is highlighted, and if they earned badges but
       * landed outside the top 20, their real computed rank is shown below
       * the table instead of disappearing entirely.
       */}
      <SectionCard title="Leaderboard" className="jp-gamification__leaderboard-card">
        {boardLoading && <ListSkeleton rows={5} />}
        {!boardLoading && (!board || board.leaderboard.length === 0) && (
          <EmptyState
            title="No leaderboard entries yet"
            description="Candidates who make their profile public and earn badges will appear here."
          />
        )}
        {!boardLoading && board && board.leaderboard.length > 0 && (
          <>
            <ol className="jp-gamification__leaderboard">
              {board.leaderboard.map((entry) => (
                <li
                  key={entry.user_id}
                  className={`jp-gamification__leaderboard-row${entry.is_you ? ' is-you' : ''}`}
                >
                  <span className="jp-gamification__leaderboard-rank">#{entry.rank}</span>
                  <span className="jp-gamification__leaderboard-name">
                    {entry.display_name}
                    {entry.is_you && <span className="jp-gamification__leaderboard-you-tag">You</span>}
                  </span>
                  <span className="jp-gamification__leaderboard-badges">🏅 {entry.badge_count}</span>
                </li>
              ))}
            </ol>
            {board.your_rank && (
              <p className="jp-gamification__your-rank">
                Your rank: <strong>#{board.your_rank}</strong>
              </p>
            )}
          </>
        )}
      </SectionCard>
    </div>
  )
}
