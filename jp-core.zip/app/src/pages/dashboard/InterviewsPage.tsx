import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  confirmInterview,
  listMyInterviews,
  requestInterviewReschedule,
  type MyInterviewRow,
} from '@/features/interviews/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { PageHeader } from '@/components/ui/PageHeader'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './InterviewsPage.css'

const TYPE_LABEL: Record<MyInterviewRow['type'], string> = {
  phone: 'Phone screen',
  video: 'Video call',
  onsite: 'On-site',
  technical: 'Technical round',
  hr: 'HR round',
}

/**
 * Batch 36 (interview-management depth pass) — root-cause fix. Candidates
 * previously had zero visibility into their scheduled interviews beyond a
 * single "interview_date" string rendered inline on ApplicationsPage.tsx:
 * no type, time zone-aware formatting, location/meeting link, duration, or
 * any way to respond. GET /my-interviews (get_my_interviews()) and the
 * confirm/request-reschedule endpoints existed nowhere in the SPA until
 * this batch built them alongside this page — this is the first and only
 * caller of all three.
 */
function formatWhen(scheduledAt: string | null): string {
  if (!scheduledAt) return 'Time to be confirmed'
  const d = new Date(scheduledAt.replace(' ', 'T'))
  if (Number.isNaN(d.getTime())) return scheduledAt
  return d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })
}

function isPast(scheduledAt: string | null): boolean {
  if (!scheduledAt) return false
  const d = new Date(scheduledAt.replace(' ', 'T'))
  return !Number.isNaN(d.getTime()) && d.getTime() < Date.now()
}

/**
 * Phase 3 redesign (Tier A, redesign-plan §InterviewsPage) — a scheduled
 * interview with no way to add it to a personal calendar is a real gap
 * benchmarked against Naukri/LinkedIn's interview scheduling flows. Built
 * entirely client-side from data already on the row (scheduled_at,
 * duration_min, location/meeting_link, job_title, company_name) — no
 * backend endpoint needed for a standard .ics download.
 */
function toIcsDate(d: Date): string {
  return d.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z'
}

function downloadInterviewIcs(interview: MyInterviewRow) {
  if (!interview.scheduled_at) return
  const start = new Date(interview.scheduled_at.replace(' ', 'T'))
  if (Number.isNaN(start.getTime())) return
  const end = new Date(start.getTime() + interview.duration_min * 60 * 1000)
  const summary = `${TYPE_LABEL[interview.type]}${interview.company_name ? ` — ${interview.company_name}` : ''}`
  const descriptionParts = [interview.job_title ? `Role: ${interview.job_title}` : null, interview.meeting_link ? `Join: ${interview.meeting_link}` : null].filter(
    Boolean
  )
  const ics = [
    'BEGIN:VCALENDAR',
    'VERSION:2.0',
    'PRODID:-//JP Core//Interview//EN',
    'BEGIN:VEVENT',
    `UID:jp-interview-${interview.id}@jpcore`,
    `DTSTAMP:${toIcsDate(new Date())}`,
    `DTSTART:${toIcsDate(start)}`,
    `DTEND:${toIcsDate(end)}`,
    `SUMMARY:${summary}`,
    interview.location ? `LOCATION:${interview.location}` : '',
    descriptionParts.length ? `DESCRIPTION:${descriptionParts.join('\\n')}` : '',
    'END:VEVENT',
    'END:VCALENDAR',
  ]
    .filter(Boolean)
    .join('\r\n')

  const blob = new Blob([ics], { type: 'text/calendar' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `interview-${interview.id}.ics`
  a.click()
  URL.revokeObjectURL(url)
}

function StatusBadge({ interview }: { interview: MyInterviewRow }) {
  if (interview.outcome === 'cancelled') return <Badge variant="gray">Cancelled</Badge>
  if (interview.outcome === 'passed') return <Badge variant="success">Passed</Badge>
  if (interview.outcome === 'failed') return <Badge variant="error">Not selected</Badge>
  if (interview.outcome === 'no_show') return <Badge variant="warning">Marked no-show</Badge>
  // outcome === 'pending' from here — the interview hasn't happened (or
  // hasn't been scored) yet, so the useful status is the candidate's own
  // response state, not the terminal outcome.
  if (interview.reschedule_requested === 1) return <Badge variant="warning">Reschedule requested</Badge>
  if (interview.candidate_confirmed === 1) return <Badge variant="info">Confirmed</Badge>
  if (isPast(interview.scheduled_at)) return <Badge variant="gray">Awaiting feedback</Badge>
  return <Badge variant="gray">Awaiting your confirmation</Badge>
}

function InterviewCard({ interview }: { interview: MyInterviewRow }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [reschedulePanelOpen, setReschedulePanelOpen] = useState(false)
  const [reason, setReason] = useState('')

  const confirmMutation = useMutation({
    mutationFn: () => confirmInterview(interview.id),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['my-interviews'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not confirm this interview.'),
  })

  const rescheduleMutation = useMutation({
    mutationFn: () => requestInterviewReschedule(interview.id, reason.trim()),
    onSuccess: (result) => {
      toast.success(result.message)
      setReschedulePanelOpen(false)
      setReason('')
      queryClient.invalidateQueries({ queryKey: ['my-interviews'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not send your reschedule request.'),
  })

  const canRespond = interview.outcome === 'pending' && !isPast(interview.scheduled_at)

  return (
    <Card className="jp-interview-card">
      <CardBody>
        <div className="jp-interview-card__header">
          <div>
            <p className="jp-interview-card__title">
              {interview.job_title ?? 'Interview'}
              {interview.company_name && <span className="jp-interview-card__company"> · {interview.company_name}</span>}
            </p>
            <p className="jp-interview-card__meta">
              {TYPE_LABEL[interview.type]} · Round {interview.round}
              {interview.recruiter_name && <> · with {interview.recruiter_name}</>}
            </p>
          </div>
          <StatusBadge interview={interview} />
        </div>

        <ul className="jp-interview-card__facts">
          <li>🗓 {formatWhen(interview.scheduled_at)}</li>
          <li>⏱ {interview.duration_min} minutes</li>
          {interview.meeting_link && (
            <li>
              🔗{' '}
              <a href={interview.meeting_link} target="_blank" rel="noreferrer">
                Join meeting
              </a>
            </li>
          )}
          {interview.location && <li>📍 {interview.location}</li>}
        </ul>

        {interview.reschedule_requested === 1 && interview.outcome === 'pending' && (
          <p className="jp-interview-card__notice">
            You asked to reschedule this interview{interview.reschedule_reason ? `: "${interview.reschedule_reason}"` : '.'} The
            recruiter will follow up with a new time.
          </p>
        )}

        {canRespond && !reschedulePanelOpen && (
          <div className="jp-interview-card__actions">
            {interview.candidate_confirmed !== 1 && interview.reschedule_requested !== 1 && (
              <Button size="sm" variant="accent" loading={confirmMutation.isPending} onClick={() => confirmMutation.mutate()}>
                Confirm attendance
              </Button>
            )}
            {interview.reschedule_requested !== 1 && (
              <Button size="sm" variant="outline" onClick={() => setReschedulePanelOpen(true)}>
                Request reschedule
              </Button>
            )}
            {interview.scheduled_at && (
              <Button size="sm" variant="ghost" onClick={() => downloadInterviewIcs(interview)}>
                Add to calendar
              </Button>
            )}
          </div>
        )}

        {reschedulePanelOpen && (
          <div className="jp-interview-card__reschedule-form">
            <textarea
              className="jp-textarea"
              rows={2}
              placeholder="Let the recruiter know why (optional)"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
            />
            <div className="jp-interview-card__actions">
              <Button size="sm" variant="outline" onClick={() => setReschedulePanelOpen(false)}>
                Cancel
              </Button>
              <Button size="sm" variant="accent" loading={rescheduleMutation.isPending} onClick={() => rescheduleMutation.mutate()}>
                Send request
              </Button>
            </div>
          </div>
        )}
      </CardBody>
    </Card>
  )
}

export function InterviewsPage() {
  const { data, isLoading, isError } = useQuery({ queryKey: ['my-interviews'], queryFn: listMyInterviews })

  const upcoming = data?.filter((i) => i.outcome === 'pending' && !isPast(i.scheduled_at)) ?? []
  const past = data?.filter((i) => i.outcome !== 'pending' || isPast(i.scheduled_at)) ?? []

  return (
    <div>
      <PageHeader
        title="Interviews"
        subtitle={
          upcoming.length > 0
            ? `${upcoming.length} upcoming interview${upcoming.length === 1 ? '' : 's'}.`
            : 'No upcoming interviews scheduled.'
        }
      />

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 2 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load your interviews.</p>}

      {!isLoading && data && data.length === 0 && (
        <EmptyState
          title="No interviews yet"
          description="When a recruiter schedules an interview for one of your applications, it will show up here with the time, format, and how to join."
          action={
            <Link to="/jobs">
              <Button variant="accent">Browse jobs</Button>
            </Link>
          }
        />
      )}

      {!isLoading && upcoming.length > 0 && (
        <section className="jp-interviews-section">
          <h2 className="jp-jobs-heading">Upcoming</h2>
          <div className="jp-jobs-list">
            {upcoming.map((i) => (
              <InterviewCard key={i.id} interview={i} />
            ))}
          </div>
        </section>
      )}

      {!isLoading && past.length > 0 && (
        <section className="jp-interviews-section">
          <h2 className="jp-jobs-heading">Past &amp; other interviews</h2>
          <div className="jp-jobs-list">
            {past.map((i) => (
              <InterviewCard key={i.id} interview={i} />
            ))}
          </div>
        </section>
      )}
    </div>
  )
}
