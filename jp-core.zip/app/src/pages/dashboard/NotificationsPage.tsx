import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  listNotifications,
  markAllNotificationsRead,
  markNotificationRead,
  type NotificationRow,
} from '@/features/notifications/api'
import {
  getNotificationPreferences,
  saveNotificationPreferences,
  type NotificationPreferences,
} from '@/features/candidates/meApi'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Button } from '@/components/ui/Button'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import '../public/JobsPage.css'
import './ProfilePage.css'
import './NotificationsPage.css'

const PREF_LABELS: Record<keyof NotificationPreferences, string> = {
  email_new_match: 'Email me about new job matches',
  email_stage_change: 'Email me when an application status changes',
  email_message: 'Email me when I get a new message',
  email_digest: 'Send me a periodic digest email',
  push_new_match: 'Push notification for new job matches',
  push_message: 'Push notification for new messages',
  sms_stage_change: 'Text me when an application status changes',
}

function NotificationPreferencesPanel() {
  const toast = useToast()
  const { data, isLoading } = useQuery({ queryKey: ['notification-prefs'], queryFn: getNotificationPreferences })
  const [prefs, setPrefs] = useState<NotificationPreferences | null>(null)

  // External-sync effect: hydrates local editable checkboxes from the
  // server's saved preferences once they arrive, same pattern used for
  // ProfilePage/JobFormPage's form hydration elsewhere in this app.
  useEffect(() => {
    if (data) setPrefs(data)
  }, [data])

  const saveMutation = useMutation({
    mutationFn: (p: NotificationPreferences) => saveNotificationPreferences(p),
    onSuccess: () => toast.success('Preferences saved.'),
    onError: () => toast.error('Could not save preferences.'),
  })

  if (isLoading || !prefs) return null

  return (
    <SectionCard title="Notification preferences" className="jp-notifications-page__prefs">
      <div className="jp-profile-checks">
        {(Object.keys(PREF_LABELS) as (keyof NotificationPreferences)[]).map((key) => (
          <label key={key} className="jp-checkbox">
            <input
              type="checkbox"
              checked={prefs[key]}
              onChange={(e) => setPrefs((prev) => (prev ? { ...prev, [key]: e.target.checked } : prev))}
            />
            {PREF_LABELS[key]}
          </label>
        ))}
      </div>
      <Button size="sm" style={{ marginTop: 12 }} loading={saveMutation.isPending} onClick={() => saveMutation.mutate(prefs)}>
        Save preferences
      </Button>
    </SectionCard>
  )
}

// Root-cause fix (see class-jp-applications.php / class-jp-messaging.php):
// NotificationRow.url is now a real absolute home_url()-based link into the
// SPA (e.g. https://site.example/dashboard/applications) rather than a
// pre-SPA-rewrite jp-theme path. react-router's navigate() needs an
// in-SPA-relative path, not a full origin — so this strips the origin when
// it matches this site, and otherwise treats the url as unusable rather than
// forcing a full-page navigation to a possibly-foreign host.
/**
 * Root-cause fix (batch 25): NotificationRow.type has always been on the
 * response (jp_notifications.type, written by every JP_Notifications::
 * create() call site — interview_scheduled/interview_confirmed/
 * interview_reschedule_requested/interview_panel_added/new_application/
 * application_update/offer_sent/offer_accepted/new_message/new_match, etc.), but
 * this page never read it — every notification rendered with an identical
 * plain card, so a candidate scanning a long list had no visual way to
 * tell a new message from an offer without reading each title. Prefix-
 * matched against the real observed type strings rather than an exhaustive
 * hardcoded list, so a new type this pass hasn't seen still gets a sane
 * default instead of rendering nothing.
 */
function notificationIcon(type: string): string {
  if (type.startsWith('interview')) return '📅'
  if (type.startsWith('offer')) return '🎉'
  if (type === 'new_message') return '💬'
  if (type.startsWith('application') || type === 'new_application') return '📄'
  if (type.startsWith('match')) return '🎯'
  if (type.startsWith('community')) return '💭'
  if (type.startsWith('review')) return '⭐'
  return '🔔'
}

function toInAppPath(url: string): string | null {
  try {
    const parsed = new URL(url, window.location.origin)
    if (parsed.origin !== window.location.origin) return null
    return parsed.pathname + parsed.search + parsed.hash
  } catch {
    return null
  }
}

export function NotificationsPage() {
  const toast = useToast()
  const navigate = useNavigate()
  const queryClient = useQueryClient()

  const { data, isLoading, isError } = useQuery({
    queryKey: ['notifications'],
    queryFn: () => listNotifications(50),
  })

  const markOneMutation = useMutation({
    mutationFn: (id: number) => markNotificationRead(id),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['notifications'] }),
    onError: () => toast.error('Could not mark notification as read.'),
  })

  const markAllMutation = useMutation({
    mutationFn: markAllNotificationsRead,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['notifications'] }),
    onError: () => toast.error('Could not mark all notifications as read.'),
  })

  const unreadCount = data?.filter((n) => n.is_read === 0).length ?? 0

  // Root-cause fix: clicking a notification previously only ever marked it
  // read (and only while unread) — it never used the url field at all, so
  // even a correctly-populated backend url was completely inert. Now marks
  // read (when unread) and navigates when the url resolves to an in-app
  // path; a notification with no usable url (null, or pointing off-site)
  // still marks read but doesn't attempt a broken navigation.
  function onNotificationClick(n: NotificationRow) {
    if (n.is_read === 0) markOneMutation.mutate(n.id)
    const path = n.url ? toInAppPath(n.url) : null
    if (path) navigate(path)
  }

  return (
    <div>
      <WorkspacePageHeader tone="candidate"
        title="Notifications"
        subtitle={unreadCount > 0 ? `${unreadCount} unread notification${unreadCount === 1 ? '' : 's'}.` : "You're all caught up."}
        actions={
          unreadCount > 0 && (
            <Button variant="outline" size="sm" loading={markAllMutation.isPending} onClick={() => markAllMutation.mutate()}>
              Mark all as read
            </Button>
          )
        }
      />

      <NotificationPreferencesPanel />

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load notifications.</p>}

      {!isLoading && data && data.length === 0 && (
        <EmptyState title="You're all caught up" description="New notifications about your applications, messages, and matches will appear here." />
      )}

      {!isLoading && data && data.length > 0 && (
        <div className="jp-jobs-list">
          {data.map((n) => (
            <Card
              key={n.id}
              className={`jp-notification${n.is_read === 0 ? ' is-unread' : ''}`}
              clickable={n.is_read === 0 || !!(n.url && toInAppPath(n.url))}
              onClick={() => onNotificationClick(n)}
            >
              <CardBody>
                <div className="jp-notification__row">
                  <span className="jp-notification__icon" aria-hidden="true">
                    {notificationIcon(n.type)}
                  </span>
                  <div>
                    <p className="jp-notification__title">{n.title}</p>
                    {n.body && <p className="jp-notification__body">{n.body}</p>}
                    <p className="jp-notification__time">{new Date(n.created_at).toLocaleString()}</p>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
