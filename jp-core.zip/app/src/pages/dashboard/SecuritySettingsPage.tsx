import { useState, type FormEvent } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { disableTwoFa, setupTwoFa, verifyTwoFa, type TwoFaSetup } from '@/features/security/twofaApi'
import { deleteAccount, exportAccountData } from '@/features/account/privacyApi'
import { updatePassword } from '@/features/auth/api'
import { getPushSubscriptionState, subscribeToPush, unsubscribeFromPush } from '@/lib/push'
import { useAuth } from '@/lib/auth/AuthContext'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './SecuritySettingsPage.css'

function PushNotificationsPanel() {
  const toast = useToast()
  const { config } = useAuth()
  const { data: state, refetch, isLoading } = useQuery({
    queryKey: ['push-subscription-state'],
    queryFn: getPushSubscriptionState,
  })

  const subscribeMutation = useMutation({
    mutationFn: () => subscribeToPush(config?.vapid_public_key ?? '', config?.ajax_url ?? '', config?.ajax_nonce ?? ''),
    onSuccess: () => {
      toast.success('Push notifications enabled.')
      void refetch()
    },
    onError: (e) => toast.error(e instanceof Error ? e.message : 'Could not enable push notifications.'),
  })

  const unsubscribeMutation = useMutation({
    mutationFn: unsubscribeFromPush,
    onSuccess: () => {
      toast.success('Push notifications disabled.')
      void refetch()
    },
    onError: () => toast.error('Could not disable push notifications.'),
  })

  if (!config?.vapid_enabled || isLoading) return null

  if (state === 'unsupported') {
    return (
      <SectionCard title="Push notifications" className="jp-security-page__section">
        <p className="jp-job-company">Your browser doesn&apos;t support push notifications.</p>
      </SectionCard>
    )
  }

  return (
    <SectionCard
      title="Push notifications"
      className="jp-security-page__section"
      action={
        <span className={`jp-security-page__status${state === 'subscribed' ? ' is-on' : ''}`}>
          {state === 'subscribed' ? 'On' : 'Off'}
        </span>
      }
    >
      <p className="jp-job-company">Get browser notifications for new matches and messages, even when the tab is closed.</p>
      {state === 'subscribed' ? (
        <Button variant="outline" loading={unsubscribeMutation.isPending} onClick={() => unsubscribeMutation.mutate()}>
          Turn off push notifications
        </Button>
      ) : (
        <Button variant="outline" loading={subscribeMutation.isPending} onClick={() => subscribeMutation.mutate()}>
          Turn on push notifications
        </Button>
      )}
    </SectionCard>
  )
}

function downloadJson(data: unknown, filename: string) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = filename
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(url)
}

export function SecuritySettingsPage() {
  const toast = useToast()
  const [setup, setSetup] = useState<TwoFaSetup | null>(null)
  const [verifyCode, setVerifyCode] = useState('')
  const [disableCode, setDisableCode] = useState('')
  const [deletePassword, setDeletePassword] = useState('')
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [currentPassword, setCurrentPassword] = useState('')
  const [newPassword, setNewPassword] = useState('')

  const setupMutation = useMutation({
    mutationFn: setupTwoFa,
    onSuccess: (result) => setSetup(result),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not start 2FA setup.'),
  })

  const verifyMutation = useMutation({
    mutationFn: () => verifyTwoFa(verifyCode),
    onSuccess: (result) => {
      toast.success(result.message)
      setSetup(null)
      setVerifyCode('')
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Invalid code.'),
  })

  const disableMutation = useMutation({
    mutationFn: () => disableTwoFa(disableCode),
    onSuccess: (result) => {
      toast.success(result.message)
      setDisableCode('')
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not disable 2FA.'),
  })

  const exportMutation = useMutation({
    mutationFn: exportAccountData,
    onSuccess: (data) => {
      downloadJson(data, `jp-account-export-${new Date().toISOString().slice(0, 10)}.json`)
      toast.success('Your data export has downloaded.')
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not export your data.'),
  })

  const deleteMutation = useMutation({
    mutationFn: () => deleteAccount(deletePassword),
    onSuccess: (result) => toast.success(result.message),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not delete your account.'),
  })

  const updatePasswordMutation = useMutation({
    mutationFn: () => updatePassword({ current_password: currentPassword, new_password: newPassword }),
    onSuccess: (result) => {
      toast.success(result.message)
      setCurrentPassword('')
      setNewPassword('')
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update your password.'),
  })

  function onVerifySubmit(e: FormEvent) {
    e.preventDefault()
    if (!verifyCode.trim()) {
      toast.error('Enter the 6-digit code from your authenticator app.')
      return
    }
    verifyMutation.mutate()
  }

  function onDisableSubmit(e: FormEvent) {
    e.preventDefault()
    if (!disableCode.trim()) {
      toast.error('Enter your current 2FA code to disable it.')
      return
    }
    disableMutation.mutate()
  }

  function onDeleteSubmit(e: FormEvent) {
    e.preventDefault()
    if (!deletePassword.trim()) {
      toast.error('Enter your password to confirm.')
      return
    }
    if (!confirmDelete) {
      toast.error('Check the confirmation box to proceed.')
      return
    }
    deleteMutation.mutate()
  }

  function onUpdatePasswordSubmit(e: FormEvent) {
    e.preventDefault()
    if (!currentPassword) {
      toast.error('Enter your current password.')
      return
    }
    if (newPassword.length < 8) {
      toast.error('New password must be at least 8 characters.')
      return
    }
    updatePasswordMutation.mutate()
  }

  return (
    <div>
      <WorkspacePageHeader tone="candidate"
        title="Security & privacy"
        subtitle="Manage how you sign in, control notifications, and control your account data."
      />

      <PushNotificationsPanel />

      <SectionCard title="Two-factor authentication" className="jp-security-page__section">
          {!setup && (
            <>
              <p className="jp-job-company">Add an extra layer of security using an authenticator app.</p>
              <div style={{ display: 'flex', gap: 12, marginTop: 8 }}>
                <Button variant="outline" loading={setupMutation.isPending} onClick={() => setupMutation.mutate()}>
                  Set up 2FA
                </Button>
              </div>
            </>
          )}

          {setup && (
            <form onSubmit={onVerifySubmit} className="jp-profile-grid" style={{ marginTop: 12 }}>
              <p className="jp-job-company" style={{ gridColumn: '1 / -1' }}>
                Scan this into your authenticator app (Google Authenticator, Authy, etc.), or enter the secret
                manually, then confirm with the 6-digit code it generates.
              </p>
              <div style={{ gridColumn: '1 / -1' }}>
                <p className="jp-job-title" style={{ fontSize: 13, wordBreak: 'break-all' }}>
                  Secret: {setup.secret}
                </p>
                <p className="jp-job-company" style={{ wordBreak: 'break-all' }}>{setup.qr_uri}</p>
              </div>
              <Input label="Verification code" value={verifyCode} onChange={(e) => setVerifyCode(e.target.value)} />
              <div style={{ alignSelf: 'end' }}>
                <Button type="submit" variant="accent" loading={verifyMutation.isPending}>
                  Confirm and enable
                </Button>
              </div>
            </form>
          )}

          <form onSubmit={onDisableSubmit} className="jp-profile-grid" style={{ marginTop: 16 }}>
            <p className="jp-job-company" style={{ gridColumn: '1 / -1' }}>
              Already have 2FA enabled and want to turn it off? Enter your current code.
            </p>
            <Input label="Current 2FA code" value={disableCode} onChange={(e) => setDisableCode(e.target.value)} />
            <div style={{ alignSelf: 'end' }}>
              <Button type="submit" variant="outline" loading={disableMutation.isPending}>
                Disable 2FA
              </Button>
            </div>
          </form>
      </SectionCard>

      {/*
        Root-cause fix (batch 7 — see class-jp-api.php's auth_update_password()
        docblock). This page previously had no way to change your password
        while signed in at all — only the forgot/reset-password email flow
        (built in batch 4) worked, which meant signing out and waiting on
        an email just to change a password you already know.
      */}
      <SectionCard title="Change password" className="jp-security-page__section">
        <p className="jp-job-company">Update the password you use to sign in.</p>
        <form onSubmit={onUpdatePasswordSubmit} className="jp-profile-grid" style={{ marginTop: 8 }}>
          <Input
            label="Current password"
            type="password"
            value={currentPassword}
            onChange={(e) => setCurrentPassword(e.target.value)}
          />
          <Input
            label="New password"
            type="password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
          />
          <div style={{ alignSelf: 'end' }}>
            <Button type="submit" variant="accent" loading={updatePasswordMutation.isPending}>
              Update password
            </Button>
          </div>
        </form>
      </SectionCard>

      <SectionCard title="Your data" className="jp-security-page__section">
        <p className="jp-job-company">
          Download a complete copy of your profile, applications, messages, resume sections, badges, saved jobs,
          alerts, assessments, and authored reviews.
        </p>
        <Button variant="outline" loading={exportMutation.isPending} onClick={() => exportMutation.mutate()}>
          Download my data
        </Button>
      </SectionCard>

      <SectionCard title="Delete account" className="jp-security-page__section jp-security-page__danger">
        <p className="jp-job-company">
          This permanently anonymises your account and removes your personal data. This cannot be undone.
        </p>
        <form onSubmit={onDeleteSubmit} className="jp-profile-grid" style={{ marginTop: 8 }}>
          <Input
            label="Password"
            type="password"
            value={deletePassword}
            onChange={(e) => setDeletePassword(e.target.value)}
          />
          <div className="jp-form-group" style={{ alignSelf: 'end' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
              <input type="checkbox" checked={confirmDelete} onChange={(e) => setConfirmDelete(e.target.checked)} />
              I understand this is permanent
            </label>
          </div>
          <div style={{ alignSelf: 'end' }}>
            <Button type="submit" variant="danger" loading={deleteMutation.isPending}>
              Delete my account
            </Button>
          </div>
        </form>
      </SectionCard>
    </div>
  )
}
