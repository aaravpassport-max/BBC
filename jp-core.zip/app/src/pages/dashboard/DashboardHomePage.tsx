import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { useAuth } from '@/lib/auth/AuthContext'
import { listApplications, type ApplicationStage } from '@/features/applications/api'
import { listSavedJobs } from '@/features/savedJobs/api'
import { getMatches, matchJobId } from '@/features/matches/api'
import { listNotifications } from '@/features/notifications/api'
import { OnboardingChecklist } from '@/components/dashboard/OnboardingChecklist'
import { PageHeader } from '@/components/ui/PageHeader'
import { StatCard } from '@/components/ui/StatCard'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { Timeline, type TimelineItem } from '@/components/ui/Timeline'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import './DashboardHomePage.css'

const STAGE_BADGE: Record<ApplicationStage, { label: string; variant: 'gray' | 'info' | 'warning' | 'success' | 'error' }> = {
  applied: { label: 'Applied', variant: 'gray' },
  viewed: { label: 'Viewed', variant: 'info' },
  shortlisted: { label: 'Shortlisted', variant: 'info' },
  phone_screen: { label: 'Phone screen', variant: 'warning' },
  interview: { label: 'Interview', variant: 'warning' },
  assessment: { label: 'Assessment', variant: 'warning' },
  offer: { label: 'Offer', variant: 'success' },
  hired: { label: 'Hired', variant: 'success' },
  rejected: { label: 'Not selected', variant: 'error' },
  withdrawn: { label: 'Withdrawn', variant: 'gray' },
}

function notificationsToTimeline(rows: { id: number; title: string | null; body: string | null; created_at: string; is_read: 0 | 1 }[]): TimelineItem[] {
  return rows.map((n) => ({
    id: n.id,
    title: n.title || 'Notification',
    description: n.body,
    timestamp: new Date(n.created_at.replace(' ', 'T') + 'Z').toLocaleDateString(),
    tone: n.is_read === 0 ? 'primary' : 'default',
  }))
}

/**
 * Batch 32 (phase 3) — platform UI/UX depth pass, dashboard exemplar.
 *
 * Root-cause of the "thin dashboard" complaint: this page fetched exactly
 * one thing (onboarding status, inside OnboardingChecklist) and read three
 * numbers straight off the already-loaded /config payload. Every other
 * data source a candidate dashboard needs — applications, saved jobs,
 * matches, notifications — already has a working, already-used-elsewhere
 * endpoint (ApplicationsPage/SavedJobsPage/MatchesPage/NotificationsPage
 * all call these same functions) but the dashboard HOME page never called
 * any of them, so landing here told the candidate nothing about their
 * actual activity. This rebuild turns it into an actual workspace: KPI
 * row, recent-applications list with real stage badges, top job matches,
 * a real activity feed (unread notifications via the shared Timeline
 * component), and quick actions — while keeping every existing piece
 * (OnboardingChecklist, the three /config-sourced stats) intact, per the
 * "do not remove existing functionality" rule.
 */
export function DashboardHomePage() {
  const { config } = useAuth()

  const { data: applications, isLoading: applicationsLoading, isError: applicationsError } = useQuery({
    queryKey: ['applications', {}],
    queryFn: () => listApplications(),
  })

  const { data: savedJobs } = useQuery({
    queryKey: ['saved-jobs'],
    queryFn: listSavedJobs,
  })

  const { data: matches, isLoading: matchesLoading, isError: matchesError } = useQuery({
    queryKey: ['matches'],
    queryFn: getMatches,
  })

  const { data: notifications, isError: notificationsError } = useQuery({
    queryKey: ['notifications', 5],
    queryFn: () => listNotifications(5),
  })

  const recentApplications = (applications ?? []).slice(0, 5)
  const topMatches = (matches ?? []).slice(0, 4)

  return (
    <div className="jp-dashboard">
      <PageHeader
        title={`Welcome back${config?.user_name ? `, ${config.user_name}` : ''}`}
        subtitle="Here's what's happening with your job search."
        actions={
          <Link to="/jobs">
            <Button variant="accent">Browse jobs</Button>
          </Link>
        }
      />

      <OnboardingChecklist />

      <div className="jp-dashboard__stats">
        <StatCard label="Applications" value={applications?.length ?? (applicationsLoading ? '—' : 0)} tone="primary" />
        <StatCard label="Saved jobs" value={savedJobs?.length ?? 0} />
        <StatCard label="Unread notifications" value={config?.unread_notifications ?? 0} tone={config?.unread_notifications ? 'warning' : 'default'} />
        <StatCard label="Unread messages" value={config?.unread_messages ?? 0} tone={config?.unread_messages ? 'warning' : 'default'} />
        <StatCard label="Profile strength" value={`${config?.candidate?.profile_score ?? 0}%`} tone="success" />
      </div>

      <div className="jp-dashboard__grid">
        <div className="jp-dashboard__main">
          <SectionCard
            title="Recent applications"
            action={
              <Link to="/dashboard/applications">
                <Button variant="ghost" size="sm">View all</Button>
              </Link>
            }
          >
            {applicationsLoading ? (
              <Skeleton height={120} width="100%" />
            ) : applicationsError ? (
              <p className="jp-jobs-error" role="alert">Could not load your recent applications.</p>
            ) : recentApplications.length === 0 ? (
              <EmptyState
                title="No applications yet"
                description="Once you apply to a job, you'll be able to track its status here."
                action={
                  <Link to="/jobs">
                    <Button variant="accent" size="sm">Find jobs to apply to</Button>
                  </Link>
                }
              />
            ) : (
              <ul className="jp-dashboard__app-list">
                {recentApplications.map((app) => {
                  const stage = STAGE_BADGE[app.stage] ?? STAGE_BADGE.applied
                  return (
                    <li key={app.id}>
                      <Link to={`/jobs/${app.job_id}`} className="jp-dashboard__app-title">
                        {app.job_title}
                      </Link>
                      <Badge variant={stage.variant}>{stage.label}</Badge>
                    </li>
                  )
                })}
              </ul>
            )}
          </SectionCard>

          <SectionCard
            title="Matches for you"
            action={
              <Link to="/dashboard/matches">
                <Button variant="ghost" size="sm">View all</Button>
              </Link>
            }
          >
            {matchesLoading ? (
              <Skeleton height={100} width="100%" />
            ) : matchesError ? (
              <p className="jp-jobs-error" role="alert">Could not load your matches.</p>
            ) : topMatches.length === 0 ? (
              <EmptyState
                title="No matches yet"
                description="Complete your profile and add skills to get personalized job matches."
                action={
                  <Link to="/dashboard/profile">
                    <Button variant="outline" size="sm">Complete your profile</Button>
                  </Link>
                }
              />
            ) : (
              <div className="jp-dashboard__match-grid">
                {topMatches.map((m) => (
                  <Link key={`${m.id}-${matchJobId(m)}`} to={`/jobs/${matchJobId(m)}`} className="jp-dashboard__match-card">
                    <p className="jp-dashboard__match-title">{m.title}</p>
                    <p className="jp-dashboard__match-meta">{m.company_name}</p>
                    <Badge variant="success">{Math.round(m.score)}% match</Badge>
                  </Link>
                ))}
              </div>
            )}
          </SectionCard>
        </div>

        <div className="jp-dashboard__side">
          <SectionCard title="Quick actions">
            <div className="jp-dashboard__quick-actions">
              <Link to="/dashboard/resumes"><Button variant="outline" size="sm" fullWidth>Manage resumes</Button></Link>
              <Link to="/dashboard/alerts"><Button variant="outline" size="sm" fullWidth>Manage job alerts</Button></Link>
              <Link to="/dashboard/saved-jobs"><Button variant="outline" size="sm" fullWidth>Saved jobs</Button></Link>
              <Link to="/dashboard/profile"><Button variant="outline" size="sm" fullWidth>Edit profile</Button></Link>
            </div>
          </SectionCard>

          <SectionCard
            title="Recent activity"
            action={
              <Link to="/dashboard/notifications">
                <Button variant="ghost" size="sm">View all</Button>
              </Link>
            }
          >
            {notificationsError ? (
              <p className="jp-jobs-error" role="alert">Could not load recent activity.</p>
            ) : (
              <Timeline items={notificationsToTimeline(notifications ?? [])} emptyLabel="No recent activity." />
            )}
          </SectionCard>
        </div>
      </div>
    </div>
  )
}
