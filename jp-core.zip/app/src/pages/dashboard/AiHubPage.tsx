import { useState } from 'react'
import { useMutation } from '@tanstack/react-query'
import {
  getResumeScore,
  improveBullet,
  generateCoverLetter,
  getInterviewPrep,
  getCareerAdvice,
  getSalaryNegotiationAdvice,
  getSkillDemand,
  type ResumeScoreResult,
  type ImproveBulletResult,
  type CoverLetterResult,
  type InterviewPrepResult,
  type CareerAdviceResult,
  type SalaryNegotiateResult,
  type SkillDemandResult,
  type AiUnavailable,
} from '@/features/ai/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Badge } from '@/components/ui/Badge'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { useToast } from '@/components/ui/ToastProvider'
import './ProfilePage.css'
import './AiHubPage.css'

function Unavailable({ result }: { result: AiUnavailable }) {
  return (
    <p className="jp-job-company" style={{ marginTop: 8 }}>
      AI unavailable: {result.reason}
    </p>
  )
}

function ResumeScoreTool() {
  const toast = useToast()
  const mutation = useMutation({
    mutationFn: getResumeScore,
    onError: () => toast.error('Could not score resume.'),
  })
  const result = mutation.data

  return (
    <SectionCard title="Resume score" className="jp-ai-hub__tool">
        <Button onClick={() => mutation.mutate()} loading={mutation.isPending}>
          Score my resume
        </Button>
        {result && !result.available && <Unavailable result={result} />}
        {result && result.available && (
          <div style={{ marginTop: 12 }}>
            <p className="jp-job-title">Overall: {(result as ResumeScoreResult).overall}/100</p>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
              {Object.entries((result as ResumeScoreResult).sections).map(([k, v]) => (
                <Badge key={k} variant="gray">
                  {k}: {v}
                </Badge>
              ))}
            </div>
            <p className="jp-job-company" style={{ marginTop: 8 }}>
              Strengths: {(result as ResumeScoreResult).strengths.join(', ') || '—'}
            </p>
            <p className="jp-job-company">
              Improvements: {(result as ResumeScoreResult).improvements.join(', ') || '—'}
            </p>
            <p className="jp-job-company">Missing: {(result as ResumeScoreResult).missing.join(', ') || '—'}</p>
          </div>
        )}
    </SectionCard>
  )
}

function ImproveBulletTool() {
  const [bullet, setBullet] = useState('')
  const toast = useToast()
  const mutation = useMutation({
    mutationFn: () => improveBullet(bullet),
    onError: () => toast.error('Could not improve bullet.'),
  })
  const result = mutation.data

  return (
    <SectionCard title="Improve a resume bullet" className="jp-ai-hub__tool">
        <Input
          label="Bullet point"
          value={bullet}
          onChange={(e) => setBullet(e.target.value)}
          placeholder="Managed a team of 5 engineers..."
        />
        <Button onClick={() => mutation.mutate()} loading={mutation.isPending} disabled={!bullet.trim()}>
          Improve
        </Button>
        {result && !result.available && <Unavailable result={result} />}
        {result && result.available && (
          <ul style={{ marginTop: 12 }}>
            {(result as ImproveBulletResult).alternatives.map((alt, i) => (
              <li key={i} className="jp-job-company">
                {alt}
              </li>
            ))}
          </ul>
        )}
    </SectionCard>
  )
}

function CoverLetterTool() {
  const [jobId, setJobId] = useState('')
  const toast = useToast()
  const mutation = useMutation({
    mutationFn: () => generateCoverLetter(Number(jobId)),
    onError: () => toast.error('Could not generate cover letter.'),
  })
  const result = mutation.data

  return (
    <SectionCard title="Cover letter generator" className="jp-ai-hub__tool">
        <Input label="Job ID" value={jobId} onChange={(e) => setJobId(e.target.value)} placeholder="123" />
        <Button onClick={() => mutation.mutate()} loading={mutation.isPending} disabled={!jobId.trim()}>
          Generate
        </Button>
        {result && !result.available && <Unavailable result={result} />}
        {result && result.available && (
          <div style={{ marginTop: 12 }}>
            <p className="jp-job-title">{(result as CoverLetterResult).subject}</p>
            <p className="jp-job-company" style={{ whiteSpace: 'pre-wrap' }}>
              {(result as CoverLetterResult).body}
            </p>
          </div>
        )}
    </SectionCard>
  )
}

function InterviewPrepTool() {
  const [jobId, setJobId] = useState('')
  const toast = useToast()
  const mutation = useMutation({
    mutationFn: () => getInterviewPrep(Number(jobId)),
    onError: () => toast.error('Could not build interview prep.'),
  })
  const result = mutation.data

  return (
    <SectionCard title="Interview prep" className="jp-ai-hub__tool">
        <Input label="Job ID" value={jobId} onChange={(e) => setJobId(e.target.value)} placeholder="123" />
        <Button onClick={() => mutation.mutate()} loading={mutation.isPending} disabled={!jobId.trim()}>
          Prepare me
        </Button>
        {result && !result.available && <Unavailable result={result} />}
        {result && result.available && (
          <div style={{ marginTop: 12 }}>
            <p className="jp-job-company">
              {(result as InterviewPrepResult).job_title} at {(result as InterviewPrepResult).company}
            </p>
            <div className="jp-jobs-list" style={{ marginTop: 8 }}>
              {(result as InterviewPrepResult).questions.map((q, i) => (
                <Card key={i}>
                  <CardBody>
                    <p className="jp-job-title" style={{ fontSize: 14 }}>
                      {q.question}
                    </p>
                    <Badge variant="gray">{q.type}</Badge>
                    <p className="jp-job-company" style={{ marginTop: 6 }}>
                      Tip: {q.tip}
                    </p>
                    <p className="jp-job-company">Sample answer: {q.sample_answer}</p>
                  </CardBody>
                </Card>
              ))}
            </div>
          </div>
        )}
    </SectionCard>
  )
}

function CareerAdviceTool() {
  const [role, setRole] = useState('')
  const toast = useToast()
  const mutation = useMutation({
    mutationFn: () => getCareerAdvice(role),
    onError: () => toast.error('Could not get career advice.'),
  })
  const result = mutation.data

  return (
    <SectionCard title="Career advice" className="jp-ai-hub__tool">
        <Input label="Target role" value={role} onChange={(e) => setRole(e.target.value)} placeholder="Senior Product Manager" />
        <Button onClick={() => mutation.mutate()} loading={mutation.isPending} disabled={!role.trim()}>
          Get advice
        </Button>
        {result && !result.available && <Unavailable result={result} />}
        {result && result.available && (
          <div style={{ marginTop: 12 }}>
            <p className="jp-job-title">
              Readiness: {(result as CareerAdviceResult).readiness_percent}% · {(result as CareerAdviceResult).timeline_months} mo
              timeline
            </p>
            <p className="jp-job-company">Market demand: {(result as CareerAdviceResult).market_demand}</p>
            <p className="jp-job-company">Skill gaps: {(result as CareerAdviceResult).skill_gaps.join(', ') || '—'}</p>
            <div className="jp-jobs-list" style={{ marginTop: 8 }}>
              {(result as CareerAdviceResult).action_steps.map((s, i) => (
                <div key={i} className="jp-job-row">
                  <span className="jp-job-company">{s.step}</span>
                  <Badge variant="gray">
                    {s.priority} · {s.timeframe}
                  </Badge>
                </div>
              ))}
            </div>
            <p className="jp-job-company" style={{ marginTop: 8 }}>
              Recommended paths:{' '}
              {(result as CareerAdviceResult).recommended_paths.map((p) => p.path).join(', ') || '—'}
            </p>
          </div>
        )}
    </SectionCard>
  )
}

function SalaryNegotiateTool() {
  const [offer, setOffer] = useState('')
  const [role, setRole] = useState('')
  const [location, setLocation] = useState('')
  const toast = useToast()
  const mutation = useMutation({
    mutationFn: () => getSalaryNegotiationAdvice(Number(offer), role, location),
    onError: () => toast.error('Could not get negotiation advice.'),
  })
  const result = mutation.data

  return (
    <SectionCard title="Salary negotiation coach" className="jp-ai-hub__tool">
        <Input label="Offer amount" value={offer} onChange={(e) => setOffer(e.target.value)} placeholder="90000" />
        <Input label="Role" value={role} onChange={(e) => setRole(e.target.value)} placeholder="Backend Engineer" />
        <Input label="Location" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="Bengaluru" />
        <Button
          onClick={() => mutation.mutate()}
          loading={mutation.isPending}
          disabled={!offer.trim() || !role.trim() || !location.trim()}
        >
          Get negotiation advice
        </Button>
        {result && !result.available && <Unavailable result={result} />}
        {result && result.available && (
          <div style={{ marginTop: 12 }}>
            <p className="jp-job-title">
              Market range: {(result as SalaryNegotiateResult).market_rate_min}–
              {(result as SalaryNegotiateResult).market_rate_max} · Target:{' '}
              {(result as SalaryNegotiateResult).negotiation_target}
            </p>
            <Badge variant={(result as SalaryNegotiateResult).is_fair_offer ? 'success' : 'warning'}>
              {(result as SalaryNegotiateResult).is_fair_offer ? 'Fair offer' : 'Below market'}
            </Badge>
            <p className="jp-job-company" style={{ marginTop: 8, whiteSpace: 'pre-wrap' }}>
              {(result as SalaryNegotiateResult).opening_script}
            </p>
            <p className="jp-job-company">
              Counter-arguments: {(result as SalaryNegotiateResult).counter_arguments.join(', ') || '—'}
            </p>
            <p className="jp-job-company">
              Non-salary perks to ask for: {(result as SalaryNegotiateResult).non_salary_perks.join(', ') || '—'}
            </p>
            <p className="jp-job-company">Walk away if: {(result as SalaryNegotiateResult).walk_away_if}</p>
          </div>
        )}
    </SectionCard>
  )
}

function SkillDemandTool() {
  const [skill, setSkill] = useState('')
  const toast = useToast()
  const mutation = useMutation({
    mutationFn: () => getSkillDemand(skill),
    onError: () => toast.error('Could not fetch skill demand.'),
  })
  const result = mutation.data

  return (
    <SectionCard title="Skill demand forecast" className="jp-ai-hub__tool">
        <Input label="Skill" value={skill} onChange={(e) => setSkill(e.target.value)} placeholder="React" />
        <Button onClick={() => mutation.mutate()} loading={mutation.isPending} disabled={!skill.trim()}>
          Check demand
        </Button>
        {result && !result.available && <Unavailable result={result} />}
        {result && result.available && (
          <div style={{ marginTop: 12 }}>
            <p className="jp-job-title">
              {(result as SkillDemandResult).active_job_count} active jobs · {(result as SkillDemandResult).demand_level} demand ·{' '}
              {(result as SkillDemandResult).trend}
            </p>
            <p className="jp-job-company">{(result as SkillDemandResult).description}</p>
            <p className="jp-job-company">
              Salary premium: +{(result as SkillDemandResult).avg_salary_premium_pct}%
            </p>
            <p className="jp-job-company">
              Top industries: {(result as SkillDemandResult).top_industries.join(', ') || '—'}
            </p>
            <p className="jp-job-company">
              Complementary skills: {(result as SkillDemandResult).complementary_skills.join(', ') || '—'}
            </p>
            <p className="jp-job-company">Outlook: {(result as SkillDemandResult).future_outlook}</p>
            {(result as SkillDemandResult).learning_resources.length > 0 && (
              <ul style={{ marginTop: 8 }}>
                {(result as SkillDemandResult).learning_resources.map((r, i) => (
                  <li key={i} className="jp-job-company">
                    <a href={r.url} target="_blank" rel="noreferrer">
                      {r.name}
                    </a>{' '}
                    ({r.type})
                  </li>
                ))}
              </ul>
            )}
          </div>
        )}
    </SectionCard>
  )
}

export function AiHubPage() {
  return (
    <div>
      <WorkspacePageHeader tone="candidate"
        title="AI Career Hub"
        subtitle="AI-powered tools to improve your resume, prepare for interviews, negotiate offers, and plan your career."
      />
      <div className="jp-ai-hub__grid">
        <ResumeScoreTool />
        <ImproveBulletTool />
        <CoverLetterTool />
        <InterviewPrepTool />
        <CareerAdviceTool />
        <SalaryNegotiateTool />
        <SkillDemandTool />
      </div>
    </div>
  )
}
