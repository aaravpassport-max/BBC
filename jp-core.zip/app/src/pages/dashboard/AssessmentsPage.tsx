import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  listAssessmentSkills,
  startAssessment,
  submitAssessment,
  type AssessmentResult,
  type AssessmentStart,
} from '@/features/assessments/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Modal } from '@/components/ui/Modal'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { StatCard } from '@/components/ui/StatCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './AssessmentsPage.css'

const BADGE_VARIANT = { gold: 'success', silver: 'gray', bronze: 'warning', none: 'gray' } as const

export function AssessmentsPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [activeSkillId, setActiveSkillId] = useState<number | null>(null)
  const [inProgress, setInProgress] = useState<AssessmentStart | null>(null)
  const [answers, setAnswers] = useState<Record<number, number>>({})
  const [result, setResult] = useState<AssessmentResult | null>(null)

  const { data, isLoading, isError } = useQuery({ queryKey: ['assessment-skills'], queryFn: listAssessmentSkills })

  const startMutation = useMutation({
    mutationFn: startAssessment,
    onSuccess: (start) => {
      setInProgress(start)
      setAnswers({})
      setResult(null)
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not start assessment.'),
  })

  const submitMutation = useMutation({
    mutationFn: ({ skillId, values }: { skillId: number; values: number[] }) => submitAssessment(skillId, values),
    onSuccess: (r) => {
      setResult(r)
      setInProgress(null)
      queryClient.invalidateQueries({ queryKey: ['assessment-skills'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not submit assessment.'),
  })

  function openSkill(skillId: number) {
    setActiveSkillId(skillId)
    setResult(null)
    setInProgress(null)
    startMutation.mutate(skillId)
  }

  function closeModal() {
    setActiveSkillId(null)
    setInProgress(null)
    setResult(null)
    setAnswers({})
  }

  function submit() {
    if (!activeSkillId || !inProgress) return
    const unanswered = inProgress.questions.length - Object.keys(answers).length
    if (unanswered > 0 && !window.confirm(`${unanswered} question${unanswered === 1 ? '' : 's'} unanswered — they'll be scored as incorrect. Submit anyway?`)) {
      return
    }
    const values = inProgress.questions.map((_, i) => answers[i] ?? -1)
    submitMutation.mutate({ skillId: activeSkillId, values })
  }

  const takenCount = (data ?? []).filter((s) => s.taken_at).length
  const badgeCount = (data ?? []).filter((s) => s.badge_level && s.badge_level !== 'none').length

  return (
    <div>
      <WorkspacePageHeader tone="candidate"
        title="Skill assessments"
        subtitle="Take a short quiz on any skill to earn a badge and boost your job-match score."
      />

      {data && data.length > 0 && (
        <div className="jp-assessments-page__stats">
          <StatCard label="Skills available" value={data.length} tone="primary" />
          <StatCard label="Assessments taken" value={takenCount} />
          <StatCard label="Badges earned" value={badgeCount} tone="success" />
        </div>
      )}

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <p className="jp-jobs-error" role="alert">
          Could not load assessments.
        </p>
      )}

      {!isLoading && data && data.length === 0 && (
        <EmptyState title="No assessments available yet" description="Check back later — new skill assessments are added regularly." />
      )}

      {!isLoading && data && data.length > 0 && (
        <div className="jp-jobs-list">
          {data.map((skill) => (
            <Card key={skill.skill_id}>
              <CardBody>
                <div className="jp-job-row">
                  <div>
                    <p className="jp-job-title" style={{ fontSize: 14 }}>
                      {skill.skill_name}
                    </p>
                    <p className="jp-job-company">
                      {skill.category || 'Uncategorized'} · {skill.question_count} questions
                      {skill.score !== null && ` · Last score: ${skill.score}%`}
                    </p>
                    {skill.badge_level && skill.badge_level !== 'none' && skill.expires_at && (
                      <p className="jp-assessments-page__expiry">
                        Badge valid until {new Date(skill.expires_at.replace(' ', 'T')).toLocaleDateString()}
                      </p>
                    )}
                  </div>
                  <div className="jp-job-badges">
                    {skill.badge_level && skill.badge_level !== 'none' && (
                      <Badge variant={BADGE_VARIANT[skill.badge_level]}>{skill.badge_level} badge</Badge>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      loading={startMutation.isPending && startMutation.variables === skill.skill_id}
                      onClick={() => openSkill(skill.skill_id)}
                    >
                      {skill.taken_at ? 'Retake' : 'Take assessment'}
                    </Button>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      <Modal open={activeSkillId !== null} onClose={closeModal} title="Skill assessment">
        {inProgress && !result && (
          <div>
            <p className="jp-assessments-page__progress">
              {Object.keys(answers).length} of {inProgress.questions.length} answered
            </p>
            {inProgress.questions.map((q, i) => (
              <div key={q.id} style={{ marginBottom: 16 }}>
                <p className="jp-job-title" style={{ fontSize: 14 }}>
                  {i + 1}. {q.question}
                </p>
                <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
                  {q.options.map((opt, oi) => (
                    <label key={oi} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
                      <input
                        type="radio"
                        name={`q-${q.id}`}
                        checked={answers[i] === oi}
                        onChange={() => setAnswers((a) => ({ ...a, [i]: oi }))}
                      />
                      {opt}
                    </label>
                  ))}
                </div>
              </div>
            ))}
            <Button variant="accent" loading={submitMutation.isPending} onClick={submit}>
              Submit answers
            </Button>
          </div>
        )}

        {result && (
          <div>
            <p className="jp-job-title">
              Score: {result.score}% ({result.correct}/{result.total}) —{' '}
              <Badge variant={BADGE_VARIANT[result.badge_level]}>{result.badge_level} badge</Badge>
            </p>
            <div className="jp-jobs-list" style={{ marginTop: 12 }}>
              {result.results.map((r, i) => (
                <Card key={i}>
                  <CardBody>
                    <p className="jp-job-title" style={{ fontSize: 13 }}>
                      {r.is_correct ? '✅' : '❌'} {r.question}
                    </p>
                    {r.explanation && <p className="jp-job-company">{r.explanation}</p>}
                  </CardBody>
                </Card>
              ))}
            </div>
            <div style={{ marginTop: 12 }}>
              <Button variant="outline" onClick={closeModal}>
                Close
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
