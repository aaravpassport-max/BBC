import { useEffect, useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  getResumeSections,
  saveResumeSection,
  type ResumeEntry,
  type ResumeSectionName,
  type ResumeSections,
} from '@/features/resumeBuilder/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { useToast } from '@/components/ui/ToastProvider'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { StatCard } from '@/components/ui/StatCard'
import '../public/JobsPage.css'
import './ProfilePage.css'
import './ResumeBuilderPage.css'

const LIST_SECTIONS: ResumeSectionName[] = ['experience', 'education', 'certifications', 'projects', 'awards']
const TAG_SECTIONS: ResumeSectionName[] = ['skills', 'languages']

const SECTION_LABELS: Record<ResumeSectionName, string> = {
  experience: 'Work experience',
  education: 'Education',
  skills: 'Skills',
  certifications: 'Certifications',
  projects: 'Projects',
  languages: 'Languages',
  awards: 'Awards',
}

const EMPTY_ENTRY: ResumeEntry = { title: '', subtitle: '', start_date: '', end_date: '', description: '' }

/**
 * Entries have no server-assigned id (save_resume_section() stores the
 * whole array as opaque JSON, not individual rows), so this editor needs
 * its own stable client-side key — using the array index as the React key
 * here would misassign each <Input>'s uncommitted keystrokes/focus to the
 * wrong entry the moment a middle entry is removed or the list reorders,
 * since React would reuse DOM nodes by position rather than identity. A
 * monotonically increasing counter, attached once per entry and stripped
 * before the array is sent to saveResumeSection(), avoids that.
 */
let nextEntryKey = 0
type KeyedEntry = ResumeEntry & { _key: number }
const withKey = (entry: ResumeEntry): KeyedEntry => ({ ...entry, _key: nextEntryKey++ })
const stripKey = ({ _key, ...entry }: KeyedEntry): ResumeEntry => entry

function EntryListEditor({ section, initial }: { section: ResumeSectionName; initial: ResumeEntry[] }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [entries, setEntries] = useState<KeyedEntry[]>(() => initial.map(withKey))

  const saveMutation = useMutation({
    mutationFn: (payload: ResumeEntry[]) => saveResumeSection(section, payload),
    onSuccess: () => {
      toast.success(`${SECTION_LABELS[section]} saved.`)
      queryClient.invalidateQueries({ queryKey: ['resume-sections'] })
    },
    onError: () => toast.error(`Could not save ${SECTION_LABELS[section].toLowerCase()}.`),
  })

  function update(key: number, field: keyof ResumeEntry, value: string) {
    setEntries((prev) => prev.map((e) => (e._key === key ? { ...e, [field]: value } : e)))
  }

  return (
    <SectionCard
      title={SECTION_LABELS[section]}
      className="jp-resume-builder__section"
      action={<span className="jp-resume-builder__count">{entries.length} {entries.length === 1 ? 'entry' : 'entries'}</span>}
    >
      {entries.length === 0 && (
        <p className="jp-resume-builder__empty">No {SECTION_LABELS[section].toLowerCase()} added yet.</p>
      )}

      <div className="jp-jobs-list">
        {entries.map((entry) => (
            <Card key={entry._key}>
              <CardBody className="jp-profile-grid">
                <Input label="Title" value={entry.title} onChange={(e) => update(entry._key, 'title', e.target.value)} />
                <Input
                  label="Subtitle (company / school)"
                  value={entry.subtitle ?? ''}
                  onChange={(e) => update(entry._key, 'subtitle', e.target.value)}
                />
                <Input
                  label="Start date"
                  type="month"
                  value={entry.start_date ?? ''}
                  onChange={(e) => update(entry._key, 'start_date', e.target.value)}
                />
                <Input
                  label="End date"
                  type="month"
                  value={entry.end_date ?? ''}
                  onChange={(e) => update(entry._key, 'end_date', e.target.value)}
                />
                <div className="jp-form-group" style={{ gridColumn: '1 / -1' }}>
                  <label className="jp-label" htmlFor={`description-${entry._key}`}>
                    Description
                  </label>
                  <textarea
                    id={`description-${entry._key}`}
                    className="jp-textarea"
                    rows={3}
                    value={entry.description ?? ''}
                    onChange={(e) => update(entry._key, 'description', e.target.value)}
                  />
                </div>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={() => setEntries((prev) => prev.filter((e) => e._key !== entry._key))}
                >
                  Remove
                </Button>
              </CardBody>
            </Card>
          ))}
        </div>

        <div className="jp-job-row" style={{ marginTop: 12 }}>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => setEntries((prev) => [...prev, withKey({ ...EMPTY_ENTRY })])}
          >
            Add entry
          </Button>
          <Button
            type="button"
            size="sm"
            loading={saveMutation.isPending}
            onClick={() => saveMutation.mutate(entries.map(stripKey))}
          >
            Save {SECTION_LABELS[section].toLowerCase()}
          </Button>
        </div>
    </SectionCard>
  )
}

function TagListEditor({ section, initial }: { section: ResumeSectionName; initial: string[] }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [text, setText] = useState(initial.join(', '))

  const saveMutation = useMutation({
    mutationFn: (payload: string[]) => saveResumeSection(section, payload),
    onSuccess: () => {
      toast.success(`${SECTION_LABELS[section]} saved.`)
      queryClient.invalidateQueries({ queryKey: ['resume-sections'] })
    },
    onError: () => toast.error(`Could not save ${SECTION_LABELS[section].toLowerCase()}.`),
  })

  const tagCount = text.split(',').map((s) => s.trim()).filter(Boolean).length

  return (
    <SectionCard
      title={SECTION_LABELS[section]}
      className="jp-resume-builder__section"
      action={<span className="jp-resume-builder__count">{tagCount} listed</span>}
    >
      <Input
        label={`${SECTION_LABELS[section]} (comma separated)`}
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <Button
        type="button"
        size="sm"
        style={{ marginTop: 12 }}
        loading={saveMutation.isPending}
        onClick={() =>
          saveMutation.mutate(
            text
              .split(',')
              .map((s) => s.trim())
              .filter(Boolean),
          )
        }
      >
        Save {SECTION_LABELS[section].toLowerCase()}
      </Button>
    </SectionCard>
  )
}

export function ResumeBuilderPage() {
  const { data, isLoading, isError } = useQuery({ queryKey: ['resume-sections'], queryFn: getResumeSections })
  const [hydrated, setHydrated] = useState<ResumeSections | null>(null)

  // External-sync effect: seeds each section editor's local draft from the
  // server once, same hydration pattern used across this app's other
  // edit-in-place forms (ProfilePage, JobFormPage, etc).
  useEffect(() => {
    if (data && !hydrated) setHydrated(data)
  }, [data, hydrated])

  // Root-cause fix: `hydrated` only ever gets set from a successful `data`
  // response, so on a fetch failure `isLoading` becomes false but
  // `hydrated` stays null forever — the `isLoading || !hydrated` guard
  // below would then stay true permanently, showing the loading skeleton
  // forever with no escape and no indication anything went wrong.
  if (isError) {
    return (
      <div className="jp-jobs-error" role="alert">
        Could not load your resume sections. Please try again.
      </div>
    )
  }

  if (isLoading || !hydrated) {
    return (
      <div>
        <Skeleton height={32} width="40%" />
        <div style={{ height: 16 }} />
        <Skeleton height={300} width="100%" />
      </div>
    )
  }

  const allSections = [...LIST_SECTIONS, ...TAG_SECTIONS]
  const filledCount = allSections.filter((section) => {
    const value = hydrated[section]
    return Array.isArray(value) && value.length > 0
  }).length
  const completionPct = Math.round((filledCount / allSections.length) * 100)

  return (
    <div>
      <WorkspacePageHeader tone="candidate"
        title="Resume builder"
        subtitle="Build a structured resume the platform can use for matching and AI tools — separate from the PDF/DOC files you upload under Resumes."
      />

      <div className="jp-resume-builder__stats">
        <StatCard label="Sections completed" value={`${filledCount} / ${allSections.length}`} tone="primary" />
        <StatCard label="Profile completeness" value={`${completionPct}%`} tone={completionPct >= 100 ? 'success' : 'warning'} />
      </div>

      {LIST_SECTIONS.map((section) => (
        <EntryListEditor key={section} section={section} initial={(hydrated[section] as ResumeEntry[] | undefined) ?? []} />
      ))}

      {TAG_SECTIONS.map((section) => (
        <TagListEditor key={section} section={section} initial={(hydrated[section] as string[] | undefined) ?? []} />
      ))}
    </div>
  )
}
