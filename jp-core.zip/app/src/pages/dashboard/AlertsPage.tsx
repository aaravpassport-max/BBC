import { useState, type FormEvent } from 'react'
import { Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { createAlert, deleteAlert, listAlerts, toggleAlert, type AlertRow } from '@/features/alerts/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './ProfilePage.css'

const EMPTY = {
  name: '',
  keywords: '',
  location: '',
  experience: '',
  skills: '',
  job_type: '',
  work_mode: '',
  salary_min: '',
  frequency: 'instant' as 'instant' | 'daily' | 'weekly',
}

/**
 * Builds a /jobs query string from a saved alert's criteria, so "Run this
 * search" re-executes the exact same search on the public Jobs page rather
 * than requiring the candidate to re-enter every filter by hand. Uses the
 * same query param keys JobsPage.tsx itself reads (q/location/job_type/
 * work_mode/sal_min) — this is the other half of createAlert()'s use on
 * JobsPage.tsx: a search saved from there round-trips back to a live search
 * here.
 */
function alertToJobsSearchQuery(alert: AlertRow): string {
  const params = new URLSearchParams()
  if (alert.keywords) params.set('q', alert.keywords)
  if (alert.location) params.set('location', alert.location)
  if (alert.job_type) params.set('job_type', alert.job_type)
  if (alert.work_mode) params.set('work_mode', alert.work_mode)
  if (alert.salary_min) params.set('sal_min', String(alert.salary_min))
  if (alert.experience) params.set('exp', String(alert.experience))
  if (alert.skills_json) {
    try {
      const skills = JSON.parse(alert.skills_json) as unknown
      if (Array.isArray(skills) && skills.length) params.set('skills', skills.join(','))
    } catch {
      // Malformed skills_json is treated as "no skills filter" rather than
      // breaking the whole "Run search" link.
    }
  }
  return params.toString()
}

export function AlertsPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [form, setForm] = useState(EMPTY)

  const { data, isLoading, isError } = useQuery({ queryKey: ['alerts'], queryFn: listAlerts })

  const createMutation = useMutation({
    mutationFn: createAlert,
    onSuccess: (result) => {
      toast.success(result.message)
      setForm(EMPTY)
      queryClient.invalidateQueries({ queryKey: ['alerts'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not create alert.'),
  })

  const deleteMutation = useMutation({
    mutationFn: deleteAlert,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['alerts'] }),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not delete this alert.'),
  })

  const toggleMutation = useMutation({
    mutationFn: toggleAlert,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['alerts'] }),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update this alert.'),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!form.name.trim()) {
      toast.error('Give this alert a name.')
      return
    }
    createMutation.mutate({
      ...form,
      experience: form.experience ? Number(form.experience) : undefined,
      skills: form.skills.trim() || undefined,
      job_type: form.job_type || undefined,
      work_mode: form.work_mode || undefined,
      salary_min: form.salary_min ? Number(form.salary_min) : undefined,
    })
  }

  const activeCount = (data ?? []).filter((a) => a.is_active === 1).length

  return (
    <div>
      <WorkspacePageHeader tone="candidate"
        title="Job alerts"
        subtitle={
          data && data.length > 0
            ? `${activeCount} of ${data.length} alert${data.length === 1 ? '' : 's'} active — you'll be notified when a matching job is posted.`
            : "Get notified automatically when a job matching your criteria is posted."
        }
      />

      <SectionCard title="Create a new alert" className="jp-alerts-page__form-card">
        {/*
          Root-cause fix (batch 30): job_type/work_mode/salary_min/frequency
          have always been real, writable columns — CreateAlertPayload
          already declares them and JP_Alerts::ajax_save()'s $_POST
          whitelist already accepts them (job_type/work_mode/salary_min
          since the table's creation; frequency likewise) — but this form
          never offered any of the four, so every alert was created with an
          instant-frequency, any-type, any-mode search regardless of what
          the candidate actually wanted. Option values match JobsPage.tsx's
          own filter dropdowns exactly (same backend enum contract).
        */}
        <form onSubmit={onSubmit} className="jp-profile-grid">
          <Input
            label="Alert name"
            value={form.name}
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
          />
          <Input
            label="Keywords"
            value={form.keywords}
            onChange={(e) => setForm((f) => ({ ...f, keywords: e.target.value }))}
          />
          <Input
            label="Location"
            value={form.location}
            onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))}
          />
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="alert-job-type">
              Job type
            </label>
            <select
              id="alert-job-type"
              className="jp-input"
              value={form.job_type}
              onChange={(e) => setForm((f) => ({ ...f, job_type: e.target.value }))}
            >
              <option value="">Any</option>
              <option value="full-time">Full-time</option>
              <option value="part-time">Part-time</option>
              <option value="contract">Contract</option>
              <option value="internship">Internship</option>
              <option value="freelance">Freelance</option>
            </select>
          </div>
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="alert-work-mode">
              Work mode
            </label>
            <select
              id="alert-work-mode"
              className="jp-input"
              value={form.work_mode}
              onChange={(e) => setForm((f) => ({ ...f, work_mode: e.target.value }))}
            >
              <option value="">Any</option>
              <option value="onsite">On-site</option>
              <option value="remote">Remote</option>
              <option value="hybrid">Hybrid</option>
            </select>
          </div>
          <Input
            label="Min. experience (years)"
            type="number"
            min={0}
            max={60}
            value={form.experience}
            onChange={(e) => setForm((f) => ({ ...f, experience: e.target.value }))}
          />
          <Input
            label="Min. salary"
            type="number"
            min={0}
            value={form.salary_min}
            onChange={(e) => setForm((f) => ({ ...f, salary_min: e.target.value }))}
          />
          <Input
            label="Skills (comma-separated)"
            placeholder="e.g. React, Node.js"
            value={form.skills}
            onChange={(e) => setForm((f) => ({ ...f, skills: e.target.value }))}
            hint="A job must have ALL of these skills to match."
          />
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="alert-frequency">
              Notify me
            </label>
            <select
              id="alert-frequency"
              className="jp-input"
              value={form.frequency}
              onChange={(e) => setForm((f) => ({ ...f, frequency: e.target.value as typeof f.frequency }))}
            >
              <option value="instant">Instantly</option>
              <option value="daily">Daily digest</option>
              <option value="weekly">Weekly digest</option>
            </select>
          </div>
          <div style={{ alignSelf: 'end' }}>
            <Button type="submit" variant="accent" loading={createMutation.isPending}>
              Create alert
            </Button>
          </div>
        </form>
      </SectionCard>

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 2 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load your alerts. Please try again.
        </div>
      )}

      {!isLoading && data && data.length === 0 && (
        <EmptyState
          title="No alerts set up yet"
          description="Create one above to get notified automatically when a new job matches your criteria."
        />
      )}

      {!isLoading && data && data.length > 0 && (
        <div className="jp-jobs-list">
          {data.map((alert) => (
            <Card key={alert.id}>
              <CardBody>
                <div className="jp-job-row">
                  <div>
                    <h2 className="jp-job-title">{alert.name}</h2>
                    <p className="jp-job-company">
                      {[
                        alert.keywords,
                        alert.location,
                        alert.experience ? `${alert.experience}+ yrs exp` : '',
                        (() => {
                          if (!alert.skills_json) return ''
                          try {
                            const skills = JSON.parse(alert.skills_json) as unknown
                            return Array.isArray(skills) && skills.length ? skills.join(', ') : ''
                          } catch {
                            return ''
                          }
                        })(),
                      ]
                        .filter(Boolean)
                        .join(' · ') || 'Any job, any location'}
                    </p>
                  </div>
                  <div className="jp-job-badges">
                    <Badge variant={alert.is_active === 1 ? 'success' : 'gray'}>
                      {alert.is_active === 1 ? 'Active' : 'Paused'}
                    </Badge>
                    <Badge variant="gray">
                      {alert.frequency === 'instant' ? 'Instant' : alert.frequency === 'daily' ? 'Daily digest' : 'Weekly digest'}
                    </Badge>
                    {/*
                      Root-cause fix (batch 32/phase 5): jp_alerts.last_sent
                      is a real column, populated by JP_Alerts::mark_sent()
                      (class-jp-alerts.php) whenever the digest cron actually
                      sends a matching job, and listAlerts()'s AlertRow type
                      already declares it — but no page ever rendered it, so
                      a candidate with a daily/weekly digest had no way to
                      tell whether the alert was actually firing or silently
                      never matching anything.
                    */}
                    <span className="jp-alerts__last-sent">
                      {alert.last_sent
                        ? `Last sent ${new Date(alert.last_sent.replace(' ', 'T')).toLocaleDateString()}`
                        : 'Not sent yet'}
                    </span>
                    <Link to={`/jobs?${alertToJobsSearchQuery(alert)}`}>
                      <Button variant="outline" size="sm">
                        Run search
                      </Button>
                    </Link>
                    <Button
                      variant="ghost"
                      size="sm"
                      loading={toggleMutation.isPending && toggleMutation.variables === alert.id}
                      onClick={() => toggleMutation.mutate(alert.id)}
                    >
                      {alert.is_active === 1 ? 'Pause' : 'Resume'}
                    </Button>
                    <Button
                      variant="danger"
                      size="sm"
                      loading={deleteMutation.isPending && deleteMutation.variables === alert.id}
                      onClick={() => {
                        if (window.confirm(`Delete the alert "${alert.name}"?`)) deleteMutation.mutate(alert.id)
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
