import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/Button'
import { useAuth } from '@/lib/auth/AuthContext'
import { ROLE_LANDING_ROUTE } from '@/lib/auth/types'
import './NotFoundPage.css'

export function NotFoundPage() {
  const { isAuthenticated, role } = useAuth()
  const dashboardPath = ROLE_LANDING_ROUTE[role]

  return (
    <div className="jp-notfound">
      <p className="jp-notfound__eyebrow">Page not found</p>
      <h1>404</h1>
      <p className="jp-notfound__lead">
        That URL does not match anything on the job portal — the listing may have moved or the link may be outdated.
      </p>
      <div className="jp-notfound-actions">
        {isAuthenticated && dashboardPath !== '/' ? (
          <Link to={dashboardPath}>
            <Button variant="primary">Go to dashboard</Button>
          </Link>
        ) : (
          <Link to="/">
            <Button variant="primary">Back to home</Button>
          </Link>
        )}
        <Link to="/jobs">
          <Button variant="outline">Browse jobs</Button>
        </Link>
      </div>
    </div>
  )
}
