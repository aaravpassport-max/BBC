import { Link } from 'react-router-dom'
import { Button } from '@/components/ui/Button'
import { useAuth } from '@/lib/auth/AuthContext'
import { ROLE_LANDING_ROUTE } from '@/lib/auth/types'
import './NotFoundPage.css'

/**
 * Root-cause fix: a bare "404, back to home" link stranded a signed-in user
 * — their real landing page is /dashboard, /recruiter or /admin depending on
 * role (ROLE_LANDING_ROUTE, same map LoginPage/App.tsx use after sign-in),
 * not the public "/". Uses the real useAuth() state already available
 * app-wide; no fabricated content, just correct navigation for the state
 * the app is actually in.
 */
export function NotFoundPage() {
  const { isAuthenticated, role } = useAuth()
  const dashboardPath = ROLE_LANDING_ROUTE[role]

  return (
    <div className="jp-notfound">
      <h1>404</h1>
      <p>We couldn&apos;t find that page.</p>
      <div className="jp-notfound-actions">
        {isAuthenticated && dashboardPath !== '/' ? (
          <Link to={dashboardPath}>
            <Button variant="primary">Go to dashboard</Button>
          </Link>
        ) : (
          <Link to="/">
            <Button variant="primary">Back to home</Button>
          </Link>
        )}
        <Link to="/jobs">
          <Button variant="outline">Browse jobs</Button>
        </Link>
      </div>
    </div>
  )
}
