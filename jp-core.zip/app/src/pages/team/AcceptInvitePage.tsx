import { useEffect, useRef, useState } from 'react'
import { useNavigate, useSearchParams, Link } from 'react-router-dom'
import { acceptTeamInvite } from '@/features/team/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { useAuth } from '@/lib/auth/AuthContext'
import { ApiError } from '@/lib/apiClient'
import '../auth/LoginPage.css'

/**
 * Root-cause fix (batch 6 — see class-jp-team.php's do_invite()/class
 * docblock). The email an invite sends now links here
 * (home_url('/team/accept')?token=...) instead of a query param no page
 * ever read. Public route (not behind ProtectedRoute) because the invitee
 * may not be signed in yet — a brand-new hire clicking this link from their
 * email has no account. If they're not logged in, this shows a plain
 * "log in or register, then come back to this link" message rather than
 * silently redirecting through a login flow that has no way to return them
 * here with the token intact (LoginPage's own post-login redirect relies on
 * router state a plain email link can't set).
 */
export function AcceptInvitePage() {
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const { loading, isAuthenticated } = useAuth()
  const token = searchParams.get('token') ?? ''

  const [status, setStatus] = useState<'idle' | 'working' | 'done' | 'error'>('idle')
  const [message, setMessage] = useState('')
  const attempted = useRef(false)

  useEffect(() => {
    if (loading || !isAuthenticated || !token || attempted.current) return
    attempted.current = true
    setStatus('working')
    acceptTeamInvite(token)
      .then((result) => {
        setStatus('done')
        setMessage(result.message)
      })
      .catch((e) => {
        setStatus('error')
        setMessage(e instanceof ApiError ? e.message : 'Could not accept this invitation.')
      })
  }, [loading, isAuthenticated, token])

  return (
    <div className="jp-auth-page">
      <Card className="jp-auth-card">
        <CardBody>
          <h1 className="jp-auth-title">Team invitation</h1>

          {!token && <p className="jp-auth-hint">This invitation link is missing its token.</p>}

          {token && loading && <p className="jp-auth-hint">Checking your account…</p>}

          {token && !loading && !isAuthenticated && (
            <>
              <p className="jp-auth-hint">
                Log in or create an account with the email this invitation was sent to, then come back to this same
                link to accept it.
              </p>
              <p className="jp-auth-switch">
                <Link to="/login">Log in</Link> · <Link to="/register">Create an account</Link>
              </p>
            </>
          )}

          {token && !loading && isAuthenticated && status === 'working' && (
            <p className="jp-auth-hint">Accepting your invitation…</p>
          )}

          {status === 'done' && (
            <>
              <p className="jp-auth-hint">{message}</p>
              <Button fullWidth onClick={() => navigate('/recruiter/team', { replace: true })}>
                Go to your team
              </Button>
            </>
          )}

          {status === 'error' && (
            <p className="jp-auth-hint" role="alert">
              {message}
            </p>
          )}
        </CardBody>
      </Card>
    </div>
  )
}
