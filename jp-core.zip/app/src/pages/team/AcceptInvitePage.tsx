import { useEffect, useRef, useState } from 'react'
import { useNavigate, useSearchParams, Link } from 'react-router-dom'
import { acceptTeamInvite } from '@/features/team/api'
import { Button } from '@/components/ui/Button'
import { AuthShell } from '@/components/layout/AuthShell'
import { useAuth } from '@/lib/auth/AuthContext'
import { ApiError } from '@/lib/apiClient'

export function AcceptInvitePage() {
  const [searchParams] = useSearchParams()
  const navigate = useNavigate()
  const { loading, isAuthenticated } = useAuth()
  const token = searchParams.get('token') ?? ''

  const [status, setStatus] = useState<'idle' | 'working' | 'done' | 'error'>('idle')
  const [message, setMessage] = useState('')
  const attempted = useRef(false)

  useEffect(() => {
    if (loading || !isAuthenticated || !token || attempted.current) return
    attempted.current = true
    setStatus('working')
    acceptTeamInvite(token)
      .then((result) => {
        setStatus('done')
        setMessage(result.message)
      })
      .catch((e) => {
        setStatus('error')
        setMessage(e instanceof ApiError ? e.message : 'Could not accept this invitation.')
      })
  }, [loading, isAuthenticated, token])

  return (
    <AuthShell
      title="Team invitation"
      lead="Join your recruiting team on the platform — use the email address this invite was sent to."
      footer={
        !isAuthenticated && token ? (
          <p className="jp-auth-shell__switch">
            <Link to="/login">Log in</Link> · <Link to="/register">Create an account</Link>
          </p>
        ) : undefined
      }
    >
      {!token && <p role="alert">This invitation link is missing its token.</p>}

      {token && loading && <p>Checking your account…</p>}

      {token && !loading && !isAuthenticated && (
        <p>Log in or create an account, then open this same link again to accept the invitation.</p>
      )}

      {token && !loading && isAuthenticated && status === 'working' && <p>Accepting your invitation…</p>}

      {status === 'done' && (
        <>
          <p>{message}</p>
          <Button fullWidth onClick={() => navigate('/recruiter/team', { replace: true })}>
            Go to your team
          </Button>
        </>
      )}

      {status === 'error' && (
        <p role="alert" className="jp-jobs-error">
          {message}
        </p>
      )}
    </AuthShell>
  )
}
