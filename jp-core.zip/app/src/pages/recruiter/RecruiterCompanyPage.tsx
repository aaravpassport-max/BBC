import { useEffect, useState, type FormEvent } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { getRecruiterCompany, updateRecruiterCompany, type CompanyUpdatePayload } from '@/features/recruiter/companyApi'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import '../dashboard/ProfilePage.css'

const EMPTY: Required<CompanyUpdatePayload> = {
  name: '',
  description: '',
  website: '',
  email: '',
  phone: '',
  industry: '',
  size_range: '',
  headquarters: '',
  founded_year: 0,
}

export function RecruiterCompanyPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [form, setForm] = useState(EMPTY)

  const { data: company, isLoading, error } = useQuery({
    queryKey: ['recruiter-company'],
    queryFn: getRecruiterCompany,
    retry: false,
  })
  const notFound = error instanceof ApiError && error.status === 404

  // External-sync effect (server row -> local editable draft), same
  // justification as ProfilePage.tsx's identical pattern.
  useEffect(() => {
    if (!company) return
    setForm({
      name: company.name,
      description: company.description ?? '',
      website: company.website ?? '',
      // Depth pass (batch 4) — root-cause fix: email/phone/founded_year are
      // real, writable fields (update_recruiter_company()'s own $allowed
      // whitelist) already returned by get_recruiter_company(), but this
      // effect always reset them to '' / 0 — even after adding the RecruiterCompanyRow
      // type so the real values are available, so a recruiter's existing
      // saved email/phone/founded_year was silently discarded on every save
      // (the input never showed it, so the form always submitted the blank
      // default). Now pre-fills from the real row.
      email: company.email ?? '',
      phone: company.phone ?? '',
      industry: company.industry ?? '',
      size_range: company.size_range ?? '',
      headquarters: company.headquarters ?? '',
      founded_year: company.founded_year ?? 0,
    })
  }, [company])

  const saveMutation = useMutation({
    mutationFn: (payload: CompanyUpdatePayload) => updateRecruiterCompany(payload),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['recruiter-company'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not save company profile.'),
  })

  function field<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    saveMutation.mutate(form)
  }

  if (isLoading) {
    return (
      <div>
        <Skeleton height={32} width="40%" />
        <div style={{ height: 16 }} />
        <Skeleton height={200} width="100%" />
      </div>
    )
  }

  if (notFound) {
    return (
      <EmptyState
        title="No company profile found yet"
        description="Contact support to set up your company profile before posting jobs."
      />
    )
  }

  // Root-cause fix: any OTHER error (500, network failure — anything that
  // isn't the 404 case above) previously fell through to the plain form
  // below with `company` still undefined, silently rendering every field
  // blank. A recruiter would have no way to tell that apart from "my
  // profile really is empty," and could fill in and submit a fresh copy
  // over what may still exist server-side.
  if (error) {
    return (
      <div className="jp-jobs-error" role="alert">
        Could not load your company profile. Please try again.
      </div>
    )
  }

  return (
    <form className="jp-profile-form" onSubmit={onSubmit}>
      <WorkspacePageHeader tone="recruiter"
        title="Company profile"
        subtitle="This is what candidates see on your company page and job listings."
      />
      <SectionCard title="Company details">
        <div className="jp-profile-grid">
          <Input label="Company name" value={form.name} onChange={(e) => field('name', e.target.value)} />
          <Input label="Website" value={form.website} onChange={(e) => field('website', e.target.value)} />
          <Input label="Industry" value={form.industry} onChange={(e) => field('industry', e.target.value)} />
          <Input label="Company size" value={form.size_range} onChange={(e) => field('size_range', e.target.value)} />
          <Input label="Headquarters" value={form.headquarters} onChange={(e) => field('headquarters', e.target.value)} />
          <Input
            label="Founded year"
            type="number"
            value={form.founded_year || ''}
            onChange={(e) => field('founded_year', e.target.value ? Number(e.target.value) : 0)}
          />
        </div>
      </SectionCard>

      {/*
        Depth pass (Naukri/JobHai benchmarking, batch 4) — root-cause fix:
        email/phone are real fields update_recruiter_company() already
        accepts and persists (see its $allowed whitelist), but this form
        never rendered inputs for either — worse, since `form` always sent
        both keys in the PUT payload regardless, every save silently
        overwrote any existing email/phone with an empty string (the field
        could never be non-'' since nothing ever set it). Adding real inputs
        fixes both the missing depth AND that silent-data-loss bug at once.
      */}
      <SectionCard title="Contact details">
        <p className="jp-form-hint">Used for internal verification — not shown publicly on your company page.</p>
        <div className="jp-profile-grid">
          <Input label="Contact email" type="email" value={form.email} onChange={(e) => field('email', e.target.value)} />
          <Input label="Contact phone" type="tel" value={form.phone} onChange={(e) => field('phone', e.target.value)} />
        </div>
      </SectionCard>
      <SectionCard title="About the company">
        <div className="jp-form-group">
          <label className="jp-label" htmlFor="description">
            Description
          </label>
          <textarea
            id="description"
            className="jp-textarea"
            rows={5}
            value={form.description}
            onChange={(e) => field('description', e.target.value)}
          />
        </div>
      </SectionCard>
      <Button type="submit" variant="accent" loading={saveMutation.isPending}>
        Save company profile
      </Button>
    </form>
  )
}
