import { useEffect, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  bulkMoveStage,
  downloadMyApplicationsCsv,
  generateOffer,
  getApplicationDetail,
  getApplicationResumeUrl,
  listRecruiterApplications,
  moveApplicationStage,
  setApplicationTags,
  addApplicationNote,
} from '@/features/recruiter/applicationsApi'
import type { ApplicationStage, OfferStatus } from '@/features/applications/api'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { WorkspaceBulkBar } from '@/components/workspace/WorkspaceBulkBar'
import { WorkspacePagination } from '@/components/workspace/WorkspacePagination'
import { PipelineStageChips } from '@/components/workspace/PipelineStageChips'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './RecruiterApplicationsPage.css'

const OFFER_STATUS_LABEL: Record<OfferStatus, string> = {
  none: '',
  sent: 'Offer sent',
  accepted: 'Offer accepted',
  declined: 'Offer declined',
}

const OFFER_STATUS_VARIANT: Record<OfferStatus, 'gray' | 'success' | 'error' | 'info'> = {
  none: 'gray',
  sent: 'info',
  accepted: 'success',
  declined: 'error',
}

const STAGES: ApplicationStage[] = [
  'applied',
  'shortlisted',
  'viewed',
  'phone_screen',
  'interview',
  'assessment',
  'offer',
  'hired',
  'rejected',
  'withdrawn',
]

const STAGE_LABEL: Record<ApplicationStage, string> = {
  applied: 'Applied',
  shortlisted: 'Shortlisted',
  viewed: 'Viewed',
  phone_screen: 'Phone screen',
  interview: 'Interview',
  assessment: 'Assessment',
  offer: 'Offer',
  hired: 'Hired',
  rejected: 'Rejected',
  withdrawn: 'Withdrawn',
}

export function RecruiterApplicationsPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const jobId = searchParams.get('job_id') ? Number(searchParams.get('job_id')) : undefined
  const toast = useToast()
  const queryClient = useQueryClient()
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [offerFormOpenFor, setOfferFormOpenFor] = useState<number | null>(null)
  const [offerCtc, setOfferCtc] = useState('')
  const [expandedId, setExpandedId] = useState<number | null>(null)
  // Root-cause fix (states audit — large-data pagination): the backend
  // (get_recruiter_applications() in class-jp-api.php) has always hard-capped
  // results at 30 per page and returned a real `total`, and the API client
  // function already accepted a `page` param — but this page never sent one
  // and had no page controls, so a recruiter with more than 30 applicants
  // across their jobs could never see or act on any applicant past #30, with
  // no error or indication anything was being hidden.
  const [page, setPage] = useState(1)
  const [stageFilter, setStageFilter] = useState<ApplicationStage | ''>('')
  const [exporting, setExporting] = useState(false)

  async function onExport() {
    setExporting(true)
    try {
      await downloadMyApplicationsCsv(jobId)
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Could not export applicants.')
    } finally {
      setExporting(false)
    }
  }

  const { data, isLoading, isError } = useQuery({
    queryKey: ['recruiter-applications', jobId, page, stageFilter],
    queryFn: () =>
      listRecruiterApplications({ job_id: jobId, page, stage: stageFilter || undefined }),
    placeholderData: (prev) => prev,
  })
  const totalPages = data ? Math.max(1, Math.ceil(data.total / 30)) : 1

  // Switching the job filter (via the "Show all applicants" link or a
  // job-scoped deep link) changes the result set entirely, so a page number
  // left over from the previous filter could point past the end of the new
  // one — reset to page 1 whenever the filter changes, same as the search
  // form on RecruiterCandidatesPage resets page on every new search.
  useEffect(() => {
    setPage(1)
  }, [jobId, stageFilter])

  const stageMutation = useMutation({
    mutationFn: ({ id, stage }: { id: number; stage: ApplicationStage }) => moveApplicationStage(id, stage),
    onSuccess: () => {
      toast.success('Stage updated.')
      queryClient.invalidateQueries({ queryKey: ['recruiter-applications'] })
    },
    onError: () => toast.error('Could not update stage.'),
  })

  const offerMutation = useMutation({
    mutationFn: ({ id, ctc }: { id: number; ctc: number }) => generateOffer(id, ctc),
    onSuccess: (result) => {
      toast.success(result.message)
      setOfferFormOpenFor(null)
      setOfferCtc('')
      queryClient.invalidateQueries({ queryKey: ['recruiter-applications'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not generate the offer letter.'),
  })

  const bulkStageMutation = useMutation({
    mutationFn: ({ ids, stage }: { ids: number[]; stage: ApplicationStage }) => bulkMoveStage(ids, stage),
    onSuccess: (result) => {
      toast.success(result.message)
      setSelected(new Set())
      queryClient.invalidateQueries({ queryKey: ['recruiter-applications'] })
    },
    // Surfaces the real server message (e.g. the 200-item bulk-action cap)
    // instead of a fixed generic string — same fix applied across the
    // other bulk-action pages during this audit pass.
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Bulk update failed.'),
  })

  function toggleSelected(id: number) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  return (
    <div>
      <WorkspacePageHeader tone="recruiter"
        title={`Applicants${jobId ? ' for this job' : ''}`}
        subtitle={data ? `${data.total.toLocaleString()} applicant${data.total === 1 ? '' : 's'}${jobId ? ' for this job' : ' across all your jobs'}.` : undefined}
        actions={
          data && data.total > 0 ? (
            <Button variant="outline" size="sm" loading={exporting} onClick={() => void onExport()}>
              Export CSV
            </Button>
          ) : undefined
        }
      />

      <WorkspaceBulkBar count={selected.size} onClear={() => setSelected(new Set())}>
        <select
          className="jp-input"
          style={{ width: 200 }}
          value=""
          disabled={bulkStageMutation.isPending}
          onChange={(e) => {
            const stage = e.target.value as ApplicationStage
            if (stage) bulkStageMutation.mutate({ ids: [...selected], stage })
          }}
          aria-label="Move selected applications to stage"
        >
          <option value="" disabled>
            Move to stage...
          </option>
          {STAGES.map((s) => (
            <option key={s} value={s}>
              {s.replace('_', ' ')}
            </option>
          ))}
        </select>
      </WorkspaceBulkBar>

      <PipelineStageChips
        value={stageFilter}
        onChange={setStageFilter}
        options={[
          { value: '', label: 'All stages' },
          ...STAGES.map((s) => ({ value: s, label: STAGE_LABEL[s] })),
        ]}
      />
      {jobId && (
        <button type="button" className="jp-recruiter-apps__back-link" onClick={() => setSearchParams({})}>
          ← Show all applicants
        </button>
      )}

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load applicants.</p>}

      {!isLoading && data && data.applications.length === 0 && (
        <EmptyState
          title="No applicants yet"
          description={jobId ? 'No one has applied to this job yet.' : 'Applications to your posted jobs will appear here.'}
        />
      )}

      {!isLoading && data && data.applications.length > 0 && (
        <div className="jp-workspace-list">
          {data.applications.map((app) => (
            <Card key={app.id} className="jp-workspace-record jp-workspace-record--applicant">
              <CardBody>
                <div className="jp-job-row">
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                    <input
                      type="checkbox"
                      checked={selected.has(app.id)}
                      onChange={() => toggleSelected(app.id)}
                      aria-label={`Select ${app.candidate_name}`}
                      style={{ marginTop: 4 }}
                    />
                    <div>
                      <h2 className="jp-job-title">{app.candidate_name}</h2>
                      <p className="jp-job-company">
                        {app.current_title || app.headline || 'Candidate'} · Applied for {app.job_title}
                      </p>
                      <p className="jp-job-company">
                        {app.candidate_email}
                        {app.location_city && ` · ${app.location_city}`}
                        {app.experience_years !== null && ` · ${app.experience_years} yrs experience`}
                      </p>
                    </div>
                  </div>
                  <div className="jp-job-badges" style={{ flexDirection: 'column', alignItems: 'flex-end', gap: 8 }}>
                    {app.match_score > 0 && <Badge variant="info">{app.match_score}% match</Badge>}
                    {app.profile_score !== null && <Badge variant="gray">Profile {app.profile_score}</Badge>}
                    {app.offer_status !== 'none' && (
                      <Badge variant={OFFER_STATUS_VARIANT[app.offer_status]}>{OFFER_STATUS_LABEL[app.offer_status]}</Badge>
                    )}
                    <select
                      className="jp-input"
                      style={{ width: 160 }}
                      value={app.stage}
                      disabled={stageMutation.isPending && stageMutation.variables?.id === app.id}
                      onChange={(e) => stageMutation.mutate({ id: app.id, stage: e.target.value as ApplicationStage })}
                      aria-label={`Application stage for ${app.candidate_name}`}
                    >
                      {STAGES.map((s) => (
                        <option key={s} value={s}>
                          {s.replace('_', ' ')}
                        </option>
                      ))}
                    </select>
                    {app.stage === 'offer' && app.offer_status === 'none' && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          setOfferFormOpenFor(offerFormOpenFor === app.id ? null : app.id)
                          setOfferCtc('')
                        }}
                      >
                        Generate offer letter
                      </Button>
                    )}
                    {app.offer_pdf_url && (
                      <a href={app.offer_pdf_url} target="_blank" rel="noreferrer" style={{ fontSize: 13 }}>
                        View offer letter
                      </a>
                    )}
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => setExpandedId(expandedId === app.id ? null : app.id)}
                      aria-expanded={expandedId === app.id}
                    >
                      {expandedId === app.id ? 'Hide details' : 'View details'}
                    </Button>
                  </div>
                </div>

                {app.tags && app.tags.length > 0 && (
                  <div className="jp-app-tag-row">
                    {app.tags.map((t) => (
                      <Badge key={t} variant="gray">{t}</Badge>
                    ))}
                  </div>
                )}

                {expandedId === app.id && (
                  <ApplicationDetailPanel applicationId={app.id} />
                )}

                {offerFormOpenFor === app.id && (
                  <form
                    onSubmit={(e) => {
                      e.preventDefault()
                      offerMutation.mutate({ id: app.id, ctc: Number(offerCtc) || 0 })
                    }}
                    className="jp-job-row"
                    style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--jp-gray-200)' }}
                  >
                    <Input
                      label="Annual CTC (optional — leave blank to use the job's stated salary range)"
                      type="number"
                      min={0}
                      value={offerCtc}
                      onChange={(e) => setOfferCtc(e.target.value)}
                      autoFocus
                    />
                    <div style={{ display: 'flex', gap: 8, alignSelf: 'end' }}>
                      <Button type="submit" variant="accent" size="sm" loading={offerMutation.isPending}>
                        Send offer
                      </Button>
                      <Button type="button" variant="outline" size="sm" onClick={() => setOfferFormOpenFor(null)}>
                        Cancel
                      </Button>
                    </div>
                  </form>
                )}
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      {!isLoading && data && (
        <WorkspacePagination page={page} totalPages={totalPages} onPageChange={setPage} />
      )}
    </div>
  )
}

function formatWhen(iso: string): string {
  const d = new Date(iso.replace(' ', 'T'))
  if (Number.isNaN(d.getTime())) return iso
  return d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' })
}

/**
 * New in batch 37 (recruiter ATS pipeline depth). Surfaces everything
 * get_application() now returns — cover letter, screening answers, notes,
 * stage-history timeline, tags, resume — that previously had no SPA
 * caller at all despite the backend endpoint already existing and being
 * fully permissioned. Fetched lazily (only while its card is expanded)
 * rather than baked into the list query, since the list already carries
 * enough payload for 30 applicants per page.
 */
function ApplicationDetailPanel({ applicationId }: { applicationId: number }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [noteDraft, setNoteDraft] = useState('')
  const [tagDraft, setTagDraft] = useState('')

  const { data, isLoading, isError } = useQuery({
    queryKey: ['application-detail', applicationId],
    queryFn: () => getApplicationDetail(applicationId),
  })

  const noteMutation = useMutation({
    mutationFn: (note: string) => addApplicationNote(applicationId, note),
    onSuccess: () => {
      setNoteDraft('')
      toast.success('Note added.')
      queryClient.invalidateQueries({ queryKey: ['application-detail', applicationId] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not add the note.'),
  })

  const tagsMutation = useMutation({
    mutationFn: (tags: string[]) => setApplicationTags(applicationId, tags),
    onSuccess: () => {
      toast.success('Tags updated.')
      queryClient.invalidateQueries({ queryKey: ['application-detail', applicationId] })
      queryClient.invalidateQueries({ queryKey: ['recruiter-applications'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update tags.'),
  })

  function addTag() {
    const t = tagDraft.trim()
    if (!t || !data) return
    if (data.tags.includes(t)) {
      setTagDraft('')
      return
    }
    tagsMutation.mutate([...data.tags, t])
    setTagDraft('')
  }

  function removeTag(t: string) {
    if (!data) return
    tagsMutation.mutate(data.tags.filter((existing) => existing !== t))
  }

  return (
    <div className="jp-app-detail" style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--jp-gray-200)' }}>
      {isLoading && <p className="jp-app-detail__loading">Loading application details…</p>}
      {isError && <p className="jp-jobs-error" role="alert">Could not load this application's details.</p>}

      {data && (
        <div className="jp-app-detail__grid">
          <section className="jp-app-detail__section">
            <h3 className="jp-app-detail__heading">Cover letter</h3>
            {data.cover_letter ? (
              <p className="jp-app-detail__text">{data.cover_letter}</p>
            ) : (
              <p className="jp-app-detail__empty">No cover letter submitted.</p>
            )}
          </section>

          <section className="jp-app-detail__section">
            <h3 className="jp-app-detail__heading">Screening answers</h3>
            {data.screening_ans.length > 0 ? (
              <ol className="jp-app-detail__answers">
                {data.screening_ans.map((ans, i) => (
                  <li key={i}>{ans || <em>No answer given</em>}</li>
                ))}
              </ol>
            ) : (
              <p className="jp-app-detail__empty">This job had no screening questions.</p>
            )}
          </section>

          <section className="jp-app-detail__section">
            <h3 className="jp-app-detail__heading">Resume</h3>
            {data.resume_id ? (
              <a href={getApplicationResumeUrl(applicationId)} target="_blank" rel="noreferrer">
                {data.resume_file_name || 'View resume'}
              </a>
            ) : (
              <p className="jp-app-detail__empty">No resume attached.</p>
            )}
          </section>

          <section className="jp-app-detail__section">
            <h3 className="jp-app-detail__heading">Tags</h3>
            <div className="jp-app-tag-row">
              {data.tags.map((t) => (
                <button
                  key={t}
                  type="button"
                  className="jp-app-tag-removable"
                  onClick={() => removeTag(t)}
                  disabled={tagsMutation.isPending}
                  aria-label={`Remove tag ${t}`}
                  title="Click to remove"
                >
                  {t} ×
                </button>
              ))}
              {data.tags.length === 0 && <span className="jp-app-detail__empty">No tags yet.</span>}
            </div>
            <form
              className="jp-app-detail__inline-form"
              onSubmit={(e) => {
                e.preventDefault()
                addTag()
              }}
            >
              <Input
                aria-label="Add a tag"
                placeholder="Add a tag (e.g. strong-culture-fit)"
                value={tagDraft}
                onChange={(e) => setTagDraft(e.target.value)}
                maxLength={40}
              />
              <Button type="submit" size="sm" variant="outline" loading={tagsMutation.isPending} disabled={!tagDraft.trim()}>
                Add
              </Button>
            </form>
          </section>

          <section className="jp-app-detail__section">
            <h3 className="jp-app-detail__heading">Notes</h3>
            {data.notes.length > 0 ? (
              <ul className="jp-app-detail__notes">
                {data.notes.map((n, i) => (
                  <li key={i}>
                    <p className="jp-app-detail__text">{n.text}</p>
                    <span className="jp-app-detail__meta">{formatWhen(n.created_at)}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="jp-app-detail__empty">No internal notes yet.</p>
            )}
            <form
              className="jp-app-detail__inline-form"
              onSubmit={(e) => {
                e.preventDefault()
                const t = noteDraft.trim()
                if (t) noteMutation.mutate(t)
              }}
            >
              <Input
                aria-label="Add an internal note"
                placeholder="Add an internal note (only your team can see this)"
                value={noteDraft}
                onChange={(e) => setNoteDraft(e.target.value)}
                maxLength={2000}
              />
              <Button type="submit" size="sm" variant="outline" loading={noteMutation.isPending} disabled={!noteDraft.trim()}>
                Add note
              </Button>
            </form>
          </section>

          <section className="jp-app-detail__section jp-app-detail__section--wide">
            <h3 className="jp-app-detail__heading">Stage history</h3>
            {data.stage_history.length > 0 ? (
              <ol className="jp-app-detail__timeline">
                {[...data.stage_history].reverse().map((h, i) => (
                  <li key={i}>
                    <span className="jp-app-detail__timeline-stage">{STAGE_LABEL[h.stage] ?? h.stage}</span>
                    <span className="jp-app-detail__meta">{formatWhen(h.timestamp)}</span>
                    {h.note && <p className="jp-app-detail__text">{h.note}</p>}
                  </li>
                ))}
              </ol>
            ) : (
              <p className="jp-app-detail__empty">No stage changes recorded yet.</p>
            )}
          </section>
        </div>
      )}
    </div>
  )
}
