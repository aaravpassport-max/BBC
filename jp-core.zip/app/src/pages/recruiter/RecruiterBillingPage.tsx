import { useEffect, useRef, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useQuery, useQueryClient } from '@tanstack/react-query'
import { getRecruiterInvoices, getRecruiterSubscription } from '@/features/recruiter/billingApi'
import { verifyStripeSession } from '@/features/payments/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { CardSkeleton, Skeleton } from '@/components/ui/Skeleton'
import { PageHeader } from '@/components/ui/PageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import '../public/JobsPage.css'
import '../dashboard/ProfilePage.css'
import './RecruiterBillingPage.css'

const STATUS_VARIANT = {
  none: 'gray',
  trial: 'warning',
  active: 'success',
  past_due: 'warning',
  cancelled: 'gray',
  expired: 'gray',
} as const

const INVOICE_VARIANT = { created: 'gray', paid: 'success', failed: 'error', refunded: 'warning', abandoned: 'gray' } as const

export function RecruiterBillingPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [searchParams, setSearchParams] = useSearchParams()
  const [verifying, setVerifying] = useState(false)
  const verifiedSessionRef = useRef<string | null>(null)

  const {
    data: sub,
    isLoading: subLoading,
    isError: subError,
  } = useQuery({
    queryKey: ['recruiter-subscription'],
    queryFn: getRecruiterSubscription,
  })

  const {
    data: invoices,
    isLoading: invoicesLoading,
    isError: invoicesError,
  } = useQuery({
    queryKey: ['recruiter-invoices'],
    queryFn: getRecruiterInvoices,
  })

  // Root-cause fix (batch 12 — Stripe gateway abstraction). Stripe's
  // Checkout is a redirect flow, not a modal callback like Razorpay's — the
  // moment payment actually gets confirmed is when Stripe sends the
  // browser back here with ?stripe_session_id={CHECKOUT_SESSION_ID}
  // substituted in (see do_create_stripe_session()'s success_url in
  // class-jp-payments.php). This effect is that confirmation step; it's an
  // external-navigation-triggered side effect (not derivable render state),
  // so a useEffect synchronizing with the URL param is correct here — same
  // category as ProfilePage.tsx's server-hydration effect. verifiedSessionRef
  // guards against calling verifyStripeSession() twice for the same session
  // id (e.g. a re-render before the query param is stripped from the URL).
  useEffect(() => {
    const sessionId = searchParams.get('stripe_session_id')
    if (!sessionId || verifiedSessionRef.current === sessionId) return
    verifiedSessionRef.current = sessionId
    setVerifying(true)
    verifyStripeSession(sessionId)
      .then((result) => {
        toast.success(result.message || 'Payment successful — your plan is now active.')
        queryClient.invalidateQueries({ queryKey: ['recruiter-subscription'] })
        queryClient.invalidateQueries({ queryKey: ['recruiter-invoices'] })
      })
      .catch((e) => {
        toast.error(e instanceof Error ? e.message : 'Could not confirm your payment. If you were charged, contact support.')
      })
      .finally(() => {
        setVerifying(false)
        setSearchParams((prev) => {
          const next = new URLSearchParams(prev)
          next.delete('stripe_session_id')
          return next
        }, { replace: true })
      })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [searchParams])

  return (
    <div>
      <PageHeader title="Billing" subtitle="Your plan, usage credits, and payment history." />

      {verifying && (
        <div className="jp-job-company" style={{ marginBottom: 16 }} role="status">
          Confirming your payment with Stripe…
        </div>
      )}

      {subLoading && <Skeleton height={140} width="100%" />}

      {subError && (
        <div className="jp-jobs-error" role="alert">
          Could not load your subscription. Please try again.
        </div>
      )}

      {sub && (
        // Root-cause fix (batch 28): SubscriptionRow.cancelled_at has always
        // been on the response (jp_subscriptions.cancelled_at, set by
        // admin_cancel_subscription()) but this page only ever showed a
        // generic "cancelled" badge with a "renews" date that no longer made
        // sense post-cancellation — a recruiter had no way to tell whether
        // they'd lost access already or were still in a paid-through grace
        // period. No self-service cancel endpoint exists yet (only
        // admin_cancel_subscription(), jp_manage_plans-gated) — confirmed via
        // grep, correctly left unbuilt rather than fabricating one.
        <Card style={{ marginBottom: 16 }}>
          <CardBody>
            <div className="jp-job-row">
              <div>
                <p className="jp-job-title">{sub.plan?.name ?? 'No active plan'}</p>
                {sub.subscription && (
                  <p className="jp-job-company">
                    {sub.subscription.billing_cycle} ·{' '}
                    {sub.subscription.cancelled_at
                      ? `cancelled ${new Date(sub.subscription.cancelled_at).toLocaleDateString()} — access until ${sub.subscription.expires_at ? new Date(sub.subscription.expires_at).toLocaleDateString() : '—'}`
                      : `renews ${sub.subscription.expires_at ? new Date(sub.subscription.expires_at).toLocaleDateString() : '—'}`}
                  </p>
                )}
              </div>
              <Badge variant={STATUS_VARIANT[sub.status]}>{sub.status}</Badge>
            </div>

            {sub.status === 'none' && (
              <p className="jp-job-company" style={{ marginTop: 8 }}>
                You're on the free tier. Contact us or check the plans page to upgrade.
              </p>
            )}

            <div className="jp-profile-grid" style={{ marginTop: 16 }}>
              {Object.entries(sub.credits).map(([key, value]) => (
                <div key={key}>
                  <p className="jp-job-company">{key.replace(/_/g, ' ')}</p>
                  <p className="jp-job-title">{value}</p>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>
      )}

      <SectionCard title="Invoices" className="jp-recruiter-billing__section">

      {invoicesLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 3 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {invoicesError && (
        <div className="jp-jobs-error" role="alert">
          Could not load invoices. Please try again.
        </div>
      )}

      {!invoicesLoading && invoices && invoices.length === 0 && (
        <EmptyState title="No invoices yet" description="Payment history will appear here once you upgrade or make a purchase." />
      )}

      {!invoicesLoading && invoices && invoices.length > 0 && (
        <div className="jp-jobs-list">
          {invoices.map((inv) => (
            <Card key={inv.id}>
              <CardBody>
                <div className="jp-job-row">
                  <div>
                    <p className="jp-job-title" style={{ fontSize: 14 }}>
                      {inv.description ?? 'Payment'}
                    </p>
                    <p className="jp-job-company">{new Date(inv.created_at).toLocaleDateString()}</p>
                  </div>
                  <div className="jp-job-badges">
                    <Badge variant={INVOICE_VARIANT[inv.status]}>{inv.status}</Badge>
                    <span className="jp-job-title" style={{ fontSize: 14 }}>
                      {inv.currency} {inv.amount.toLocaleString()}
                    </span>
                    {inv.invoice_url && (
                      <a href={inv.invoice_url} target="_blank" rel="noreferrer">
                        Invoice
                      </a>
                    )}
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}
      </SectionCard>
    </div>
  )
}
