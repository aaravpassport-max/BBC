import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { bulkJobAction, deleteJob, listRecruiterJobs, repostJob, type BulkJobAction } from '@/features/recruiter/jobsApi'
import { getTeam, reassignJob } from '@/features/team/api'
import { useAuth } from '@/lib/auth/AuthContext'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { PageHeader } from '@/components/ui/PageHeader'
import { StatCard } from '@/components/ui/StatCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './RecruiterJobsPage.css'

const STATUS_VARIANT: Record<string, 'gray' | 'success' | 'warning' | 'error' | 'info'> = {
  draft: 'gray',
  pending: 'warning',
  active: 'success',
  paused: 'gray',
  expired: 'error',
  filled: 'info',
  rejected: 'error',
  archived: 'gray',
}

export function RecruiterJobsPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const { config } = useAuth()
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [reassignTarget, setReassignTarget] = useState<Record<number, string>>({})
  // Root-cause fix (batch 35): get_recruiter_jobs() has always had real
  // 20-per-page pagination and a real status filter (both accepted and
  // applied server-side), but this page fetched with no params at all and
  // discarded the response's real `total` — a recruiter with more than 20
  // postings had everything past #20 silently unreachable, with no
  // indication more jobs even existed.
  const [status, setStatus] = useState('')
  const [page, setPage] = useState(1)

  const { data, isLoading, isError } = useQuery({
    queryKey: ['recruiter-jobs', status, page],
    queryFn: () => listRecruiterJobs({ status: status || undefined, page }),
    placeholderData: (prev) => prev,
  })

  const totalPages = data ? Math.max(1, Math.ceil(data.total / 20)) : 1

  // Root-cause fix (batch 13 — see features/team/api.ts's reassignJob()
  // docblock). Only jp_team_manager has the jp_assign_jobs capability
  // do_reassign_job() requires server-side, so the team roster (and the
  // reassign control below) is only fetched/shown for that role — matching
  // the backend's own enforcement rather than relying on it alone.
  const canAssign = config?.role === 'jp_team_manager'
  const { data: team } = useQuery({
    queryKey: ['team'],
    queryFn: getTeam,
    enabled: canAssign,
  })
  const activeMembers = (team?.members ?? []).filter((m) => m.status === 'active' && m.user_id)

  const reassignMutation = useMutation({
    mutationFn: ({ jobId, userId }: { jobId: number; userId: number }) => reassignJob(jobId, userId),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['recruiter-jobs'] })
    },
    onError: () => toast.error('Could not reassign this job.'),
  })

  const deleteMutation = useMutation({
    mutationFn: deleteJob,
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['recruiter-jobs'] })
    },
    onError: () => toast.error('Could not delete this job.'),
  })

  const repostMutation = useMutation({
    mutationFn: repostJob,
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['recruiter-jobs'] })
    },
    onError: () => toast.error('Could not repost this job.'),
  })

  const bulkMutation = useMutation({
    mutationFn: ({ ids, action }: { ids: number[]; action: BulkJobAction }) => bulkJobAction(ids, action),
    onSuccess: (result) => {
      toast.success(result.message)
      setSelected(new Set())
      queryClient.invalidateQueries({ queryKey: ['recruiter-jobs'] })
    },
    // Surfaces the real server message (e.g. the 200-item bulk-action cap)
    // instead of a fixed generic string — same fix applied across the
    // other bulk-action pages during this audit pass.
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Bulk action failed.'),
  })

  function toggleSelected(id: number) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  const jobs = data?.jobs ?? []
  // Root-cause fix (batch 35): with pagination now real, jobs.length only
  // reflects the current 20-item page — the "Total postings" stat used to
  // silently understate the true count for any recruiter with >20 jobs.
  // data.total is the real, already-returned aggregate count.
  const activeCount = jobs.filter((j) => j.status === 'active').length
  const draftCount = jobs.filter((j) => j.status === 'draft' || j.status === 'pending').length
  const totalApplicants = jobs.reduce((sum, j) => sum + j.applications_cnt, 0)

  return (
    <div>
      <PageHeader
        title="My job postings"
        subtitle="Manage all the roles you've posted, in one place."
        actions={
          <Link to="/recruiter/jobs/new">
            <Button variant="accent">Post a job</Button>
          </Link>
        }
      />

      {!isLoading && jobs.length > 0 && (
        <div className="jp-recruiter-jobs__stats">
          <StatCard label="Total postings" value={data?.total ?? jobs.length} tone="primary" />
          <StatCard label="Active (this page)" value={activeCount} tone="success" />
          <StatCard label="Draft / pending (this page)" value={draftCount} />
          <StatCard label="Applicants (this page)" value={totalApplicants} />
        </div>
      )}

      <div className="jp-form-group" style={{ maxWidth: 200, marginBottom: 16 }}>
        <label className="jp-label" htmlFor="recruiter-jobs-status">
          Status
        </label>
        <select
          id="recruiter-jobs-status"
          className="jp-input"
          value={status}
          onChange={(e) => {
            setStatus(e.target.value)
            setPage(1)
          }}
        >
          <option value="">All statuses</option>
          {Object.keys(STATUS_VARIANT).map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
      </div>

      {selected.size > 0 && (
        <Card style={{ marginBottom: 16 }}>
          <CardBody className="jp-job-row">
            <span className="jp-job-company">{selected.size} selected</span>
            <div className="jp-job-badges">
              <Button
                size="sm"
                variant="outline"
                loading={bulkMutation.isPending}
                onClick={() => bulkMutation.mutate({ ids: [...selected], action: 'activate' })}
              >
                Activate
              </Button>
              <Button
                size="sm"
                variant="outline"
                loading={bulkMutation.isPending}
                onClick={() => bulkMutation.mutate({ ids: [...selected], action: 'pause' })}
              >
                Pause
              </Button>
              <Button
                size="sm"
                variant="outline"
                loading={bulkMutation.isPending}
                onClick={() => bulkMutation.mutate({ ids: [...selected], action: 'feature' })}
              >
                Feature
              </Button>
              {/* Root-cause fix (batch 35): bulk_job_action() has always
                  accepted 'unfeature' (BulkJobAction already declares it),
                  but only the one-way "Feature" button was ever offered —
                  there was no way to undo a bulk-feature short of editing
                  jobs one at a time. */}
              <Button
                size="sm"
                variant="outline"
                loading={bulkMutation.isPending}
                onClick={() => bulkMutation.mutate({ ids: [...selected], action: 'unfeature' })}
              >
                Unfeature
              </Button>
              <Button
                size="sm"
                variant="danger"
                loading={bulkMutation.isPending}
                onClick={() => {
                  if (window.confirm(`Delete ${selected.size} job(s)? This cannot be undone.`)) {
                    bulkMutation.mutate({ ids: [...selected], action: 'delete' })
                  }
                }}
              >
                Delete
              </Button>
            </div>
          </CardBody>
        </Card>
      )}

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 3 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load your job postings.</p>}

      {!isLoading && data && data.jobs.length === 0 && status !== '' && (
        <EmptyState title={`No ${status} jobs`} description="Try a different status filter, or clear it to see everything." />
      )}

      {!isLoading && data && data.jobs.length === 0 && status === '' && (
        <EmptyState
          title="You haven't posted any jobs yet"
          description="Post your first job to start receiving applications."
          action={
            <Link to="/recruiter/jobs/new">
              <Button variant="accent" size="sm">Post a job</Button>
            </Link>
          }
        />
      )}

      {!isLoading && data && data.jobs.length > 0 && (
        <div className="jp-jobs-list">
          {data.jobs.map((job) => (
            <Card key={job.id}>
              <CardBody>
                <div className="jp-job-row">
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                    <input
                      type="checkbox"
                      checked={selected.has(job.id)}
                      onChange={() => toggleSelected(job.id)}
                      aria-label={`Select ${job.title}`}
                      style={{ marginTop: 4 }}
                    />
                    <div>
                      <h2 className="jp-job-title">{job.title}</h2>
                      <p className="jp-job-company">
                        {job.applications_cnt} application{job.applications_cnt === 1 ? '' : 's'} ·{' '}
                        {job.views_count} view{job.views_count === 1 ? '' : 's'} ·{' '}
                        {new Date(job.created_at).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="jp-job-badges">
                    <Badge variant={STATUS_VARIANT[job.status] ?? 'gray'}>{job.status}</Badge>
                    {job.is_featured === 1 && <Badge variant="info">Featured</Badge>}
                    {job.is_urgent === 1 && <Badge variant="warning">Urgent</Badge>}
                    {canAssign && activeMembers.length > 0 && (
                      <>
                        <select
                          className="jp-input"
                          aria-label={`Reassign ${job.title} to`}
                          value={reassignTarget[job.id] ?? ''}
                          onChange={(e) => setReassignTarget((prev) => ({ ...prev, [job.id]: e.target.value }))}
                        >
                          <option value="">Reassign to…</option>
                          {activeMembers.map((m) => (
                            <option key={m.id} value={m.user_id ?? ''}>
                              {m.display_name ?? m.invited_email}
                            </option>
                          ))}
                        </select>
                        <Button
                          variant="outline"
                          size="sm"
                          disabled={!reassignTarget[job.id]}
                          loading={reassignMutation.isPending && reassignMutation.variables?.jobId === job.id}
                          onClick={() => {
                            const userId = Number(reassignTarget[job.id])
                            if (userId) reassignMutation.mutate({ jobId: job.id, userId })
                          }}
                        >
                          Reassign
                        </Button>
                      </>
                    )}
                    {(job.status === 'expired' || job.status === 'archived' || job.status === 'filled') && (
                      <Button
                        variant="outline"
                        size="sm"
                        loading={repostMutation.isPending && repostMutation.variables === job.id}
                        onClick={() => repostMutation.mutate(job.id)}
                      >
                        Repost
                      </Button>
                    )}
                    <Link to={`/recruiter/jobs/${job.id}/edit`}>
                      <Button variant="ghost" size="sm">
                        Edit
                      </Button>
                    </Link>
                    <Link to={`/recruiter/applications?job_id=${job.id}`}>
                      <Button variant="outline" size="sm">
                        View applicants
                      </Button>
                    </Link>
                    <Button
                      variant="danger"
                      size="sm"
                      loading={deleteMutation.isPending && deleteMutation.variables === job.id}
                      onClick={() => {
                        if (window.confirm(`Delete "${job.title}"? This cannot be undone.`)) deleteMutation.mutate(job.id)
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}

          {data.total > 20 && (
            <div className="jp-job-row" style={{ marginTop: 16 }}>
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Previous
              </Button>
              <span className="jp-job-company">
                Page {page} of {totalPages} · {data.total.toLocaleString()} job{data.total === 1 ? '' : 's'}
              </span>
              <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                Next
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  )
}
