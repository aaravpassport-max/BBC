import { useEffect, useState, type FormEvent } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { createJob, updateJob, type JobFormPayload } from '@/features/recruiter/jobsApi'
import { getJob } from '@/features/jobs/api'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { PageHeader } from '@/components/ui/PageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import '../dashboard/ProfilePage.css'

type FormState = Omit<JobFormPayload, 'skills'> & { skillsText: string }

// Local editable shape for a screening-question row: a stable `key` (not
// sent to the server) so React can key list rows correctly through
// add/remove/reorder without index-as-key reconciliation bugs — same
// pattern ResumeBuilderPage.tsx's entry-list editors already use.
interface ScreeningQuestionDraft {
  key: string
  question: string
  required: boolean
}

let draftKeySeq = 0
function newDraftKey() {
  draftKeySeq += 1
  return `sq-${draftKeySeq}`
}

const EMPTY: FormState = {
  title: '',
  description: '',
  requirements: '',
  job_type: 'full-time',
  work_mode: 'onsite',
  location_city: '',
  location_state: '',
  salary_min: 0,
  salary_max: 0,
  salary_visible: true,
  experience_min: 0,
  experience_max: 0,
  skillsText: '',
  industry: '',
  education_level: '',
  openings: 1,
  screening_questions: [],
}

export function JobFormPage() {
  const { id } = useParams<{ id: string }>()
  const jobId = id ? Number(id) : undefined
  const isEditing = jobId !== undefined
  const navigate = useNavigate()
  const toast = useToast()
  const queryClient = useQueryClient()
  const [form, setForm] = useState<FormState>(EMPTY)
  const [questions, setQuestions] = useState<ScreeningQuestionDraft[]>([])

  const {
    data: existing,
    isLoading: existingLoading,
    isError: existingError,
  } = useQuery({
    queryKey: ['job', jobId],
    queryFn: () => getJob(jobId!),
    enabled: isEditing,
  })

  // Root-cause fix: React Router does NOT remount this component when only
  // the :id param changes on the same route (e.g. navigating from editing
  // job 5 straight to editing job 8 without an intervening full navigation
  // away from /recruiter/jobs/:id/edit) — so without this, `form` would
  // keep showing job 5's already-loaded values for every render until job
  // 8's query resolves, and a submit fired in that window would write job
  // 5's field values onto job 8's record (saveMutation.mutate always uses
  // the CURRENT jobId, but `form` could still hold the PREVIOUS job's
  // data). Resetting on jobId change, synchronized with the query key
  // itself changing in the same render, guarantees the sync effect below
  // never has a chance to see stale `existing` data paired with a new id.
  useEffect(() => {
    setForm(EMPTY)
    setQuestions([])
  }, [jobId])

  // External-sync effect (server row -> local editable draft), same
  // justification as ProfilePage.tsx's identical pattern.
  useEffect(() => {
    if (!existing) return
    let skills: string[] = []
    try {
      skills = JSON.parse(existing.skills_json ?? '[]')
    } catch {
      skills = []
    }
    setForm({
      title: existing.title,
      description: existing.description,
      requirements: existing.requirements ?? '',
      job_type: existing.job_type,
      work_mode: existing.work_mode,
      location_city: existing.location_city,
      location_state: existing.location_state,
      salary_min: existing.salary_min,
      salary_max: existing.salary_max,
      salary_visible: existing.salary_visible !== 0,
      experience_min: existing.experience_min,
      experience_max: existing.experience_max,
      skillsText: skills.join(', '),
      industry: '',
      education_level: '',
      openings: 1,
      screening_questions: [],
    })
    let parsedQuestions: { question: string; required?: boolean }[] = []
    try {
      parsedQuestions = JSON.parse(existing.screening_q ?? '[]')
    } catch {
      parsedQuestions = []
    }
    setQuestions(
      Array.isArray(parsedQuestions)
        ? parsedQuestions.map((q) => ({ key: newDraftKey(), question: q.question ?? '', required: !!q.required }))
        : [],
    )
  }, [existing])

  const saveMutation = useMutation({
    mutationFn: (payload: JobFormPayload) => (isEditing ? updateJob(jobId!, payload) : createJob(payload)),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['recruiter-jobs'] })
      navigate('/recruiter/jobs')
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not save this job.'),
  })

  function field<K extends keyof FormState>(key: K, value: FormState[K]) {
    setForm((prev) => ({ ...prev, [key]: value }))
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    // Root-cause fix (states/forms audit): this was the only save form in
    // the codebase with no required-field check at all — every sibling
    // form (AdminPlansPage, RecruiterEventsPage, CommunityPage, etc.)
    // validates and shows a field-specific toast before calling mutate().
    // A blank title used to reach the server and, before the matching
    // backend fix, would have silently published an unusable job listing
    // and still spent the recruiter's posting credit.
    if (!form.title.trim()) {
      toast.error('Job title is required.')
      return
    }
    const { skillsText, ...rest } = form
    const skills = skillsText.split(',').map((s) => s.trim()).filter(Boolean)
    const screening_questions = questions
      .map((q) => ({ question: q.question.trim(), required: q.required }))
      .filter((q) => q.question.length > 0)
    saveMutation.mutate({ ...rest, skills, screening_questions })
  }

  function addQuestion() {
    setQuestions((prev) => [...prev, { key: newDraftKey(), question: '', required: false }])
  }

  function updateQuestion(key: string, patch: Partial<Omit<ScreeningQuestionDraft, 'key'>>) {
    setQuestions((prev) => prev.map((q) => (q.key === key ? { ...q, ...patch } : q)))
  }

  function removeQuestion(key: string) {
    setQuestions((prev) => prev.filter((q) => q.key !== key))
  }

  // Root-cause fix: this component had no loading/error gate for the
  // editing case at all — the form always rendered immediately from
  // whatever `form` held. On a fetch failure, `existing` stays undefined
  // forever, the sync effect below never fires, and `form` is stuck at
  // EMPTY (title '', description '', etc.) while the page still says
  // "Edit job" and a fully-enabled Submit button sits right there — one
  // click and updateJob(jobId, EMPTY-ish payload) silently overwrites the
  // real job with blank/default values. Gating on isLoading/isError closes
  // that data-loss window; the create-job path (isEditing === false) is
  // unaffected since the query is disabled there and both flags stay false.
  if (isEditing && existingLoading) {
    return (
      <div className="jp-profile-form">
        <PageHeader title="Edit job" />
        <p>Loading job details…</p>
      </div>
    )
  }

  if (isEditing && existingError) {
    return (
      <div className="jp-profile-form">
        <PageHeader title="Edit job" />
        <p className="jp-jobs-error" role="alert">
          Could not load this job. Please try again.
        </p>
      </div>
    )
  }

  return (
    <form className="jp-profile-form" onSubmit={onSubmit}>
      <PageHeader
        title={isEditing ? 'Edit job' : 'Post a new job'}
        subtitle={isEditing ? 'Update the details candidates see for this listing.' : 'Fill in the details below — you can edit this listing anytime after posting.'}
      />

      <SectionCard title="Basic details">
        <div className="jp-profile-grid">
          <Input label="Job title" value={form.title} onChange={(e) => field('title', e.target.value)} />
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="job-type">
              Job type
            </label>
            <select id="job-type" className="jp-input" value={form.job_type} onChange={(e) => field('job_type', e.target.value)}>
              <option value="full-time">Full-time</option>
              <option value="part-time">Part-time</option>
              <option value="contract">Contract</option>
              <option value="internship">Internship</option>
              <option value="freelance">Freelance</option>
            </select>
          </div>
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="work-mode">
              Work mode
            </label>
            <select id="work-mode" className="jp-input" value={form.work_mode} onChange={(e) => field('work_mode', e.target.value)}>
              <option value="onsite">On-site</option>
              <option value="remote">Remote</option>
              <option value="hybrid">Hybrid</option>
            </select>
          </div>
          <Input label="City" value={form.location_city} onChange={(e) => field('location_city', e.target.value)} />
          <Input label="State" value={form.location_state} onChange={(e) => field('location_state', e.target.value)} />
          <Input
            label="Openings"
            type="number"
            min={1}
            value={form.openings}
            onChange={(e) => field('openings', Number(e.target.value))}
          />
        </div>
      </SectionCard>

      <SectionCard title="Description & requirements">
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="description">
              Description
            </label>
            <textarea
              id="description"
              className="jp-textarea"
              rows={6}
              value={form.description}
              onChange={(e) => field('description', e.target.value)}
            />
          </div>
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="requirements">
              Requirements
            </label>
            <textarea
              id="requirements"
              className="jp-textarea"
              rows={4}
              value={form.requirements}
              onChange={(e) => field('requirements', e.target.value)}
            />
          </div>
          <Input label="Required skills (comma separated)" value={form.skillsText} onChange={(e) => field('skillsText', e.target.value)} />
      </SectionCard>

      <SectionCard title="Compensation & experience">
        <div className="jp-profile-grid">
          <Input
            label="Salary min"
            type="number"
            min={0}
            value={form.salary_min}
            onChange={(e) => field('salary_min', Number(e.target.value))}
          />
          <Input
            label="Salary max"
            type="number"
            min={0}
            value={form.salary_max}
            onChange={(e) => field('salary_max', Number(e.target.value))}
          />
          <Input
            label="Experience min (years)"
            type="number"
            min={0}
            value={form.experience_min}
            onChange={(e) => field('experience_min', Number(e.target.value))}
          />
          <Input
            label="Experience max (years)"
            type="number"
            min={0}
            value={form.experience_max}
            onChange={(e) => field('experience_max', Number(e.target.value))}
          />
        </div>
        <label className="jp-checkbox">
          <input
            type="checkbox"
            checked={form.salary_visible}
            onChange={(e) => field('salary_visible', e.target.checked)}
          />
          Show this salary range to candidates
        </label>
      </SectionCard>

      <SectionCard
        title="Screening questions"
        action={questions.length > 0 ? <Badge variant="gray">{questions.length}</Badge> : undefined}
      >
        <p className="jp-form-hint">
          Optional. Candidates answer these before submitting — mark a question required to make it mandatory.
          Screening questions help you filter applicants without opening every resume.
        </p>
        {questions.length === 0 && (
          <p className="jp-jobs-error" style={{ color: 'var(--jp-gray-600)' }}>
            No screening questions yet. Candidates will be able to apply with just a resume and cover letter.
          </p>
        )}
        {questions.map((q, i) => (
          <div key={q.key} className="jp-screening-question-row">
            <Input
              label={`Question ${i + 1}`}
              value={q.question}
              placeholder="e.g. How many years of experience do you have with React?"
              onChange={(e) => updateQuestion(q.key, { question: e.target.value })}
            />
            <label className="jp-checkbox">
              <input
                type="checkbox"
                checked={q.required}
                onChange={(e) => updateQuestion(q.key, { required: e.target.checked })}
              />
              Required
            </label>
            <Button type="button" variant="ghost" size="sm" onClick={() => removeQuestion(q.key)}>
              Remove
            </Button>
          </div>
        ))}
        <Button type="button" variant="outline" size="sm" onClick={addQuestion}>
          + Add question
        </Button>
      </SectionCard>

      <Button type="submit" variant="accent" loading={saveMutation.isPending}>
        {isEditing ? 'Save changes' : 'Post job'}
      </Button>
    </form>
  )
}
