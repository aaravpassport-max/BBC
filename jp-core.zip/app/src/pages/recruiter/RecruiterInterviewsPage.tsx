import { useState, type FormEvent } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  addPanelist,
  cancelInterview,
  listInterviews,
  listPanelists,
  removePanelist,
  scheduleInterview,
  submitInterviewFeedback,
  type InterviewFeedbackPayload,
  type InterviewRow,
} from '@/features/recruiter/interviewsApi'
import { getTeam } from '@/features/team/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { PageHeader } from '@/components/ui/PageHeader'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'

const OUTCOME_VARIANT = { pending: 'gray', passed: 'success', failed: 'error', cancelled: 'gray', no_show: 'warning' } as const
const TYPES: InterviewRow['type'][] = ['phone', 'video', 'onsite', 'technical', 'hr']
const FEEDBACK_OUTCOMES: InterviewFeedbackPayload['outcome'][] = ['passed', 'failed', 'no_show']
const EMPTY_FEEDBACK: { outcome: InterviewFeedbackPayload['outcome']; rating: string; feedback: string } = {
  outcome: 'passed',
  rating: '3',
  feedback: '',
}

const PANEL_OUTCOME_VARIANT = { pending: 'gray', passed: 'success', failed: 'error', no_show: 'warning' } as const

/**
 * Batch 26 — the multi-interviewer half of "interview panel/scorecard
 * collaboration" (batch 20 only closed single-reviewer feedback, which
 * the main page's feedbackMutation above wraps). Lets the interview's
 * owning recruiter add any active team member as a panelist and see each
 * panelist's independently-submitted scorecard once they've recorded it —
 * see class-jp-api.php's add_interview_panelist() docblock for why a
 * panelist must come from the real team roster rather than a raw id.
 */
function InterviewPanel({ interviewId }: { interviewId: number }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [selectedPanelist, setSelectedPanelist] = useState('')

  const { data: panelists, isLoading } = useQuery({
    queryKey: ['interview-panelists', interviewId],
    queryFn: () => listPanelists(interviewId),
  })
  const { data: team } = useQuery({ queryKey: ['team'], queryFn: getTeam })

  const addMutation = useMutation({
    mutationFn: (panelistId: number) => addPanelist(interviewId, panelistId),
    onSuccess: () => {
      setSelectedPanelist('')
      queryClient.invalidateQueries({ queryKey: ['interview-panelists', interviewId] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not add this panelist.'),
  })

  const removeMutation = useMutation({
    mutationFn: (panelistRowId: number) => removePanelist(interviewId, panelistRowId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['interview-panelists', interviewId] }),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not remove this panelist.'),
  })

  const availableMembers = (team?.members ?? []).filter(
    (m) => m.status === 'active' && m.user_id !== null && !panelists?.some((p) => p.panelist_id === m.user_id),
  )

  return (
    <div style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--jp-gray-200)' }}>
      <p className="jp-job-company" style={{ fontWeight: 600, marginBottom: 8 }}>
        Interview panel
      </p>
      {isLoading && <p className="jp-job-company">Loading panel…</p>}
      {!isLoading && panelists && panelists.length === 0 && (
        <p className="jp-job-company">No panelists added yet — this interview only has your own feedback above.</p>
      )}
      {panelists?.map((p) => (
        <div key={p.id} className="jp-job-row" style={{ padding: '6px 0' }}>
          <div>
            <span>{p.panelist_name ?? `User #${p.panelist_id}`}</span>
            {p.submitted_at && (
              <span className="jp-job-company">
                {' '}
                — {p.rating > 0 ? `${p.rating}/5` : ''}
                {p.feedback ? ` · ${p.feedback}` : ''}
              </span>
            )}
          </div>
          <div className="jp-job-badges">
            <Badge variant={PANEL_OUTCOME_VARIANT[p.outcome]}>
              {p.outcome === 'pending' ? 'Awaiting feedback' : p.outcome.replace('_', ' ')}
            </Badge>
            {p.outcome === 'pending' && (
              <Button
                variant="ghost"
                size="sm"
                loading={removeMutation.isPending && removeMutation.variables === p.id}
                onClick={() => removeMutation.mutate(p.id)}
              >
                Remove
              </Button>
            )}
          </div>
        </div>
      ))}
      {availableMembers.length > 0 && (
        <div className="jp-job-row" style={{ marginTop: 8, gap: 8 }}>
          <select
            className="jp-input"
            style={{ maxWidth: 240 }}
            value={selectedPanelist}
            onChange={(e) => setSelectedPanelist(e.target.value)}
            aria-label="Add a team member to this interview's panel"
          >
            <option value="">Add a panelist…</option>
            {availableMembers.map((m) => (
              <option key={m.id} value={m.user_id ?? ''}>
                {m.display_name ?? m.invited_email}
              </option>
            ))}
          </select>
          <Button
            variant="outline"
            size="sm"
            disabled={!selectedPanelist}
            loading={addMutation.isPending}
            onClick={() => addMutation.mutate(Number(selectedPanelist))}
          >
            Add
          </Button>
        </div>
      )}
    </div>
  )
}

export function RecruiterInterviewsPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [composerOpen, setComposerOpen] = useState(false)
  const [panelOpenFor, setPanelOpenFor] = useState<number | null>(null)
  const [form, setForm] = useState({
    application_id: '',
    scheduled_at: '',
    type: 'video' as InterviewRow['type'],
    meet_link: '',
    location: '',
    notes: '',
  })
  const [feedbackOpenFor, setFeedbackOpenFor] = useState<number | null>(null)
  const [feedbackForm, setFeedbackForm] = useState(EMPTY_FEEDBACK)

  const { data, isLoading, isError } = useQuery({ queryKey: ['interviews'], queryFn: listInterviews })

  const scheduleMutation = useMutation({
    mutationFn: () =>
      scheduleInterview({
        application_id: Number(form.application_id),
        scheduled_at: form.scheduled_at,
        type: form.type,
        meet_link: form.meet_link || undefined,
        location: form.location || undefined,
        notes: form.notes || undefined,
      }),
    onSuccess: (result) => {
      toast.success(result.message)
      setComposerOpen(false)
      setForm({ application_id: '', scheduled_at: '', type: 'video', meet_link: '', location: '', notes: '' })
      queryClient.invalidateQueries({ queryKey: ['interviews'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not schedule interview.'),
  })

  const cancelMutation = useMutation({
    mutationFn: cancelInterview,
    onSuccess: () => {
      toast.success('Interview cancelled.')
      queryClient.invalidateQueries({ queryKey: ['interviews'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not cancel interview.'),
  })

  const feedbackMutation = useMutation({
    mutationFn: ({ id, payload }: { id: number; payload: InterviewFeedbackPayload }) =>
      submitInterviewFeedback(id, payload),
    onSuccess: (result) => {
      toast.success(result.message)
      setFeedbackOpenFor(null)
      setFeedbackForm(EMPTY_FEEDBACK)
      queryClient.invalidateQueries({ queryKey: ['interviews'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not save interview feedback.'),
  })

  function onFeedbackSubmit(e: FormEvent, id: number) {
    e.preventDefault()
    feedbackMutation.mutate({
      id,
      payload: {
        outcome: feedbackForm.outcome,
        rating: Number(feedbackForm.rating) || 0,
        feedback: feedbackForm.feedback || undefined,
      },
    })
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!form.application_id || !form.scheduled_at) {
      toast.error('Application ID and date/time are required.')
      return
    }
    // Root-cause fix (states/forms audit — edge cases): neither this page
    // nor the backend (schedule_interview() in class-jp-api.php) rejected
    // a past date, so a typo (wrong year, AM/PM mix-up) would silently
    // notify the candidate of an interview that already happened. The
    // `min` attribute above stops most accidental past-date picks, but a
    // browser without datetime-local support or a manually-typed value can
    // still slip through, so it's checked again here before submit.
    if (new Date(form.scheduled_at).getTime() < Date.now()) {
      toast.error('Interview date/time must be in the future.')
      return
    }
    scheduleMutation.mutate()
  }

  return (
    <div>
      <PageHeader
        title="Interviews"
        subtitle={data ? `${data.length} interview${data.length === 1 ? '' : 's'} scheduled.` : undefined}
        actions={
          <Button variant="accent" onClick={() => setComposerOpen(true)}>
            Schedule interview
          </Button>
        }
      />

      {composerOpen && (
        <Card style={{ marginBottom: 16 }}>
          <CardBody>
            <form onSubmit={onSubmit} className="jp-profile-grid">
              <Input
                label="Application ID"
                type="number"
                value={form.application_id}
                onChange={(e) => setForm((f) => ({ ...f, application_id: e.target.value }))}
              />
              <Input
                label="Date & time"
                type="datetime-local"
                value={form.scheduled_at}
                min={new Date().toISOString().slice(0, 16)}
                onChange={(e) => setForm((f) => ({ ...f, scheduled_at: e.target.value }))}
              />
              <div className="jp-form-group">
                <label className="jp-label" htmlFor="interview-type">
                  Type
                </label>
                <select
                  id="interview-type"
                  className="jp-input"
                  value={form.type}
                  onChange={(e) => setForm((f) => ({ ...f, type: e.target.value as InterviewRow['type'] }))}
                >
                  {TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t}
                    </option>
                  ))}
                </select>
              </div>
              <Input
                label="Meeting link (optional)"
                value={form.meet_link}
                onChange={(e) => setForm((f) => ({ ...f, meet_link: e.target.value }))}
              />
              <Input
                label="Location (optional — for onsite interviews)"
                value={form.location}
                onChange={(e) => setForm((f) => ({ ...f, location: e.target.value }))}
              />
              <div className="jp-form-group" style={{ gridColumn: '1 / -1' }}>
                <label className="jp-label" htmlFor="interview-notes">
                  Notes (optional)
                </label>
                <textarea
                  id="interview-notes"
                  className="jp-textarea"
                  value={form.notes}
                  onChange={(e) => setForm((f) => ({ ...f, notes: e.target.value }))}
                />
              </div>
              <div style={{ alignSelf: 'end', display: 'flex', gap: 8 }}>
                <Button type="submit" variant="accent" loading={scheduleMutation.isPending}>
                  Schedule
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    // Root-cause fix (states audit — residual state on modal
                    // close): Cancel used to only hide the composer, leaving
                    // the draft in `form` untouched — reopening it showed
                    // whatever was typed before Cancel was clicked, not a
                    // fresh form.
                    setComposerOpen(false)
                    setForm({ application_id: '', scheduled_at: '', type: 'video', meet_link: '', location: '', notes: '' })
                  }}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardBody>
        </Card>
      )}

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 3 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load interviews. Please try again.
        </div>
      )}

      {!isLoading && data && data.length === 0 && (
        <EmptyState
          title="No interviews scheduled"
          description="Schedule an interview from an application's pipeline, or start one here."
          action={
            <Button variant="accent" size="sm" onClick={() => setComposerOpen(true)}>
              Schedule interview
            </Button>
          }
        />
      )}

      {!isLoading && data && data.length > 0 && (
        <div className="jp-jobs-list">
          {data.map((iv) => (
            <Card key={iv.id}>
              <CardBody>
                <div className="jp-job-row">
                  <div>
                    <p className="jp-job-title" style={{ fontSize: 14 }}>
                      {iv.candidate_name ?? `Candidate #${iv.candidate_id}`} — {iv.job_title ?? `Job #${iv.job_id}`}
                    </p>
                    <p className="jp-job-company">
                      {iv.scheduled_at ? new Date(iv.scheduled_at).toLocaleString() : 'TBD'} · {iv.type} · Round {iv.round}
                      {iv.duration_min > 0 && ` · ${iv.duration_min} min`}
                    </p>
                    {iv.location && <p className="jp-job-company">{iv.location}</p>}
                    {iv.meeting_link && (
                      <a href={iv.meeting_link} target="_blank" rel="noreferrer">
                        Meeting link
                      </a>
                    )}
                    {iv.outcome !== 'pending' && iv.outcome !== 'cancelled' && (
                      <p className="jp-job-company" style={{ marginTop: 4 }}>
                        {iv.rating > 0 && `Rating: ${iv.rating}/5`}
                        {iv.rating > 0 && iv.feedback && ' · '}
                        {iv.feedback}
                      </p>
                    )}
                    {iv.outcome === 'pending' && iv.reschedule_requested === 1 && iv.reschedule_reason && (
                      <p className="jp-job-company" style={{ marginTop: 4 }}>
                        Candidate's reason: {iv.reschedule_reason}
                      </p>
                    )}
                  </div>
                  <div className="jp-job-badges">
                    <Badge variant={OUTCOME_VARIANT[iv.outcome]}>{iv.outcome.replace('_', ' ')}</Badge>
                    {/* Batch 36 — surfaces the candidate's own response
                        (InterviewsPage.tsx) so the recruiter doesn't have to
                        ask "did they confirm?" separately. Only meaningful
                        while the interview itself is still pending. */}
                    {iv.outcome === 'pending' && iv.reschedule_requested === 1 && (
                      <Badge variant="warning">Reschedule requested</Badge>
                    )}
                    {iv.outcome === 'pending' && iv.reschedule_requested !== 1 && iv.candidate_confirmed === 1 && (
                      <Badge variant="info">Candidate confirmed</Badge>
                    )}
                    {iv.outcome !== 'cancelled' && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => setPanelOpenFor(panelOpenFor === iv.id ? null : iv.id)}
                      >
                        Panel
                      </Button>
                    )}
                    {iv.outcome === 'pending' && (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            setFeedbackOpenFor(feedbackOpenFor === iv.id ? null : iv.id)
                            setFeedbackForm(EMPTY_FEEDBACK)
                          }}
                        >
                          Record feedback
                        </Button>
                        <Button
                          variant="danger"
                          size="sm"
                          loading={cancelMutation.isPending && cancelMutation.variables === iv.id}
                          onClick={() => {
                            if (
                              window.confirm(
                                `Cancel the interview with ${iv.candidate_name ?? `Candidate #${iv.candidate_id}`}?`,
                              )
                            )
                              cancelMutation.mutate(iv.id)
                          }}
                        >
                          Cancel
                        </Button>
                      </>
                    )}
                  </div>
                </div>

                {feedbackOpenFor === iv.id && (
                  <form
                    onSubmit={(e) => onFeedbackSubmit(e, iv.id)}
                    className="jp-profile-grid"
                    style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--jp-gray-200)' }}
                  >
                    <div className="jp-form-group">
                      <label className="jp-label" htmlFor={`feedback-outcome-${iv.id}`}>
                        Outcome
                      </label>
                      <select
                        id={`feedback-outcome-${iv.id}`}
                        className="jp-input"
                        value={feedbackForm.outcome}
                        onChange={(e) =>
                          setFeedbackForm((f) => ({ ...f, outcome: e.target.value as InterviewFeedbackPayload['outcome'] }))
                        }
                      >
                        {FEEDBACK_OUTCOMES.map((o) => (
                          <option key={o} value={o}>
                            {o.replace('_', ' ')}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="jp-form-group">
                      <label className="jp-label" htmlFor={`feedback-rating-${iv.id}`}>
                        Rating (0–5)
                      </label>
                      <select
                        id={`feedback-rating-${iv.id}`}
                        className="jp-input"
                        value={feedbackForm.rating}
                        onChange={(e) => setFeedbackForm((f) => ({ ...f, rating: e.target.value }))}
                      >
                        {[0, 1, 2, 3, 4, 5].map((n) => (
                          <option key={n} value={n}>
                            {n}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="jp-form-group" style={{ gridColumn: '1 / -1' }}>
                      <label className="jp-label" htmlFor={`feedback-text-${iv.id}`}>
                        Feedback (optional)
                      </label>
                      <textarea
                        id={`feedback-text-${iv.id}`}
                        className="jp-textarea"
                        value={feedbackForm.feedback}
                        onChange={(e) => setFeedbackForm((f) => ({ ...f, feedback: e.target.value }))}
                      />
                    </div>
                    <div style={{ alignSelf: 'end', display: 'flex', gap: 8 }}>
                      <Button type="submit" variant="accent" size="sm" loading={feedbackMutation.isPending}>
                        Save feedback
                      </Button>
                      <Button type="button" variant="outline" size="sm" onClick={() => setFeedbackOpenFor(null)}>
                        Cancel
                      </Button>
                    </div>
                  </form>
                )}

                {panelOpenFor === iv.id && <InterviewPanel interviewId={iv.id} />}
              </CardBody>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
