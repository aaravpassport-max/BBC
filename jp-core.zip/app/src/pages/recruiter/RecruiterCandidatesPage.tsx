import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useMutation, useQuery } from '@tanstack/react-query'
import { getCandidateDetail, searchCandidates } from '@/features/recruiter/candidateSearchApi'
import { toggleSaveCandidate } from '@/features/recruiter/talentPoolApi'
import { createThread } from '@/features/messaging/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Modal } from '@/components/ui/Modal'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './RecruiterCandidatesPage.css'

export function RecruiterCandidatesPage() {
  const toast = useToast()
  const navigate = useNavigate()
  const [filters, setFilters] = useState({ q: '', location: '', skill: '', work_mode: '' })
  const [appliedFilters, setAppliedFilters] = useState(filters)
  const [page, setPage] = useState(1)
  const [selectedId, setSelectedId] = useState<number | null>(null)

  const { data, isLoading, isError } = useQuery({
    queryKey: ['recruiter-candidates', appliedFilters, page],
    queryFn: () => searchCandidates({ ...appliedFilters, page }),
    placeholderData: (prev) => prev,
  })

  const { data: detail, isLoading: detailLoading } = useQuery({
    queryKey: ['candidate-detail', selectedId],
    queryFn: () => getCandidateDetail(selectedId as number),
    enabled: selectedId !== null,
  })

  // Root-cause fix (batch 27): this modal had no path onward — a recruiter
  // could view a candidate's headline/skills/links here but could neither
  // open their real full public profile (badges, verified-skill scores,
  // full resume — PublicProfilePage at /profiles/:id, a real, already-built
  // route) nor start a conversation (createThread(), the same real,
  // previously-uncalled capability wired onto PublicProfilePage in batch 26).
  // Both are genuine missing links to existing capability, not new backend
  // work.
  const messageMutation = useMutation({
    mutationFn: (candidateUserId: number) => createThread(candidateUserId),
    onSuccess: (result) => navigate(`/recruiter/messages?thread=${result.thread_id}`),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not start a conversation with this candidate.'),
  })

  // Talent pool: the recruiter-side mirror of a candidate saving a job
  // (features/savedJobs/api.ts's toggleSaveJob) — lets a recruiter
  // bookmark a candidate from search results without leaving this page,
  // same as a candidate saving a job from the listing without opening it.
  const saveMutation = useMutation({
    mutationFn: (candidateUserId: number) => toggleSaveCandidate(candidateUserId),
    onSuccess: (result) => toast.success(result.message),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update your talent pool.'),
  })

  const totalPages = data ? Math.max(1, Math.ceil(data.total / 20)) : 1

  function onSearch() {
    setPage(1)
    setAppliedFilters(filters)
  }

  return (
    <div>
      <WorkspacePageHeader tone="recruiter"
        title="Find candidates"
        subtitle={data ? `${data.total.toLocaleString()} candidate${data.total === 1 ? '' : 's'} match your filters.` : 'Search the candidate database by keyword, location, skill, or work mode.'}
      />

      <SectionCard title="Search filters" className="jp-recruiter-candidates__filters">
        <div className="jp-profile-grid">
          <Input
            label="Keyword"
            placeholder="Name, title, headline"
            value={filters.q}
            onChange={(e) => setFilters((f) => ({ ...f, q: e.target.value }))}
          />
          <Input
            label="Location"
            value={filters.location}
            onChange={(e) => setFilters((f) => ({ ...f, location: e.target.value }))}
          />
          <Input
            label="Skill"
            value={filters.skill}
            onChange={(e) => setFilters((f) => ({ ...f, skill: e.target.value }))}
          />
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="work-mode-filter">
              Work mode
            </label>
            <select
              id="work-mode-filter"
              className="jp-input"
              value={filters.work_mode}
              onChange={(e) => setFilters((f) => ({ ...f, work_mode: e.target.value }))}
            >
              <option value="">Any</option>
              <option value="onsite">On-site</option>
              <option value="remote">Remote</option>
              <option value="hybrid">Hybrid</option>
            </select>
          </div>
          <div style={{ alignSelf: 'end' }}>
            <Button onClick={onSearch}>Search</Button>
          </div>
        </div>
      </SectionCard>

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load candidates. Please try again.
        </div>
      )}

      {!isLoading && data && data.candidates.length === 0 && (
        <EmptyState title="No candidates match those filters" description="Try broadening your search — remove a skill or location filter." />
      )}

      {!isLoading && data && data.candidates.length > 0 && (
        <>
          <div className="jp-jobs-list">
            {data.candidates.map((c) => (
              <Card key={c.id} clickable onClick={() => setSelectedId(c.user_id)}>
                <CardBody>
                  <div className="jp-job-row">
                    <div>
                      <h2 className="jp-job-title">{c.display_name}</h2>
                      <p className="jp-job-company">
                        {c.current_title || c.headline || 'Candidate'}
                        {c.location_city ? ` · ${c.location_city}` : ''} · {c.experience_years} yrs
                      </p>
                    </div>
                    <div className="jp-job-badges">
                      {c.is_open_to_work === 1 && <Badge variant="success">Open to work</Badge>}
                      <Badge variant="gray">Score {c.profile_score}</Badge>
                      <Button
                        variant="outline"
                        size="sm"
                        loading={saveMutation.isPending && saveMutation.variables === c.user_id}
                        onClick={(e) => {
                          e.stopPropagation()
                          saveMutation.mutate(c.user_id)
                        }}
                      >
                        Save
                      </Button>
                    </div>
                  </div>
                  {c.skills.length > 0 && (
                    <p className="jp-job-company" style={{ marginTop: 8 }}>
                      {c.skills.slice(0, 8).join(', ')}
                    </p>
                  )}
                </CardBody>
              </Card>
            ))}
          </div>

          {totalPages > 1 && (
            <div className="jp-job-row" style={{ marginTop: 16 }}>
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Previous
              </Button>
              <span className="jp-job-company">
                Page {page} of {totalPages}
              </span>
              <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                Next
              </Button>
            </div>
          )}
        </>
      )}

      <Modal open={selectedId !== null} onClose={() => setSelectedId(null)} title="Candidate profile">
        {detailLoading && <CardSkeleton />}
        {detail && (
          <div>
            <p className="jp-job-title">{detail.current_title ?? detail.headline ?? 'Candidate'}</p>
            <p className="jp-job-company">
              {detail.location_city}
              {detail.experience_years ? ` · ${detail.experience_years} yrs experience` : ''}
            </p>
            {detail.about && <p className="jp-job-company" style={{ marginTop: 8 }}>{detail.about}</p>}
            {detail.skills.length > 0 && (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
                {detail.skills.map((s) => (
                  <Badge key={s} variant="gray">
                    {s}
                  </Badge>
                ))}
              </div>
            )}
            <div className="jp-job-badges" style={{ marginTop: 12 }}>
              {detail.linkedin_url && (
                <a href={detail.linkedin_url} target="_blank" rel="noreferrer">
                  LinkedIn
                </a>
              )}
              {detail.github_url && (
                <a href={detail.github_url} target="_blank" rel="noreferrer">
                  GitHub
                </a>
              )}
              {detail.portfolio_url && (
                <a href={detail.portfolio_url} target="_blank" rel="noreferrer">
                  Portfolio
                </a>
              )}
            </div>
            <div className="jp-job-badges" style={{ marginTop: 16 }}>
              {selectedId !== null && (
                <Link to={`/profiles/${selectedId}`}>
                  <Button variant="outline" size="sm">
                    View full profile
                  </Button>
                </Link>
              )}
              <Button
                variant="outline"
                size="sm"
                loading={saveMutation.isPending && saveMutation.variables === selectedId}
                onClick={() => selectedId !== null && saveMutation.mutate(selectedId)}
              >
                Save to talent pool
              </Button>
              <Button
                size="sm"
                loading={messageMutation.isPending}
                onClick={() => selectedId !== null && messageMutation.mutate(selectedId)}
              >
                Message
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
