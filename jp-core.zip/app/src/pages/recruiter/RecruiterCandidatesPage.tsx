import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useMutation, useQuery } from '@tanstack/react-query'
import { getCandidateDetail, searchCandidates } from '@/features/recruiter/candidateSearchApi'
import { toggleSaveCandidate } from '@/features/recruiter/talentPoolApi'
import { createThread } from '@/features/messaging/api'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Modal } from '@/components/ui/Modal'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { WorkspacePagination } from '@/components/workspace/WorkspacePagination'
import { FilterBar } from '@/components/ui/FilterBar'
import { CandidateResultCard } from '@/components/recruiter/CandidateResultCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './RecruiterCandidatesPage.css'

export function RecruiterCandidatesPage() {
  const toast = useToast()
  const navigate = useNavigate()
  const [filters, setFilters] = useState({ q: '', location: '', skill: '', work_mode: '' })
  const [appliedFilters, setAppliedFilters] = useState(filters)
  const [page, setPage] = useState(1)
  const [selectedId, setSelectedId] = useState<number | null>(null)

  const { data, isLoading, isError } = useQuery({
    queryKey: ['recruiter-candidates', appliedFilters, page],
    queryFn: () => searchCandidates({ ...appliedFilters, page }),
    placeholderData: (prev) => prev,
  })

  const { data: detail, isLoading: detailLoading } = useQuery({
    queryKey: ['candidate-detail', selectedId],
    queryFn: () => getCandidateDetail(selectedId as number),
    enabled: selectedId !== null,
  })

  const messageMutation = useMutation({
    mutationFn: (candidateUserId: number) => createThread(candidateUserId),
    onSuccess: (result) => navigate(`/recruiter/messages?thread=${result.thread_id}`),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not start a conversation with this candidate.'),
  })

  const saveMutation = useMutation({
    mutationFn: (candidateUserId: number) => toggleSaveCandidate(candidateUserId),
    onSuccess: (result) => toast.success(result.message),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update your talent pool.'),
  })

  const totalPages = data ? Math.max(1, Math.ceil(data.total / 20)) : 1

  function onSearch() {
    setPage(1)
    setAppliedFilters(filters)
  }

  return (
    <div>
      <WorkspacePageHeader
        tone="recruiter"
        title="Find candidates"
        subtitle={
          data
            ? `${data.total.toLocaleString()} candidate${data.total === 1 ? '' : 's'} match your filters.`
            : 'Search the candidate database by keyword, location, skill, or work mode.'
        }
      />

      <FilterBar
        className="jp-workspace-toolbar"
        search={
          <Input
            label="Keyword"
            placeholder="Name, title, headline"
            value={filters.q}
            onChange={(e) => setFilters((f) => ({ ...f, q: e.target.value }))}
          />
        }
        filters={
          <>
            <Input
              label="Location"
              value={filters.location}
              onChange={(e) => setFilters((f) => ({ ...f, location: e.target.value }))}
            />
            <Input
              label="Skill"
              value={filters.skill}
              onChange={(e) => setFilters((f) => ({ ...f, skill: e.target.value }))}
            />
            <div className="jp-form-group">
              <label className="jp-label" htmlFor="work-mode-filter">
                Work mode
              </label>
              <select
                id="work-mode-filter"
                className="jp-input"
                value={filters.work_mode}
                onChange={(e) => setFilters((f) => ({ ...f, work_mode: e.target.value }))}
              >
                <option value="">Any</option>
                <option value="onsite">On-site</option>
                <option value="remote">Remote</option>
                <option value="hybrid">Hybrid</option>
              </select>
            </div>
            <Button onClick={onSearch}>Search</Button>
          </>
        }
      />

      {isLoading && (
        <div className="jp-workspace-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load candidates. Please try again.
        </div>
      )}

      {!isLoading && data && data.candidates.length === 0 && (
        <EmptyState title="No candidates match those filters" description="Try broadening your search — remove a skill or location filter." />
      )}

      {!isLoading && data && data.candidates.length > 0 && (
        <>
          <div className="jp-workspace-list">
            {data.candidates.map((c) => (
              <CandidateResultCard
                key={c.id}
                name={c.display_name}
                headline={c.current_title || c.headline || 'Candidate'}
                meta={[c.location_city, `${c.experience_years} yrs`, `Profile score ${c.profile_score}`]
                  .filter(Boolean)
                  .join(' · ')}
                openToWork={c.is_open_to_work === 1}
                skills={c.skills}
                onClick={() => setSelectedId(c.user_id)}
                trailing={
                  <>
                    <Badge variant="gray">Score {c.profile_score}</Badge>
                    <Button
                      variant="outline"
                      size="sm"
                      loading={saveMutation.isPending && saveMutation.variables === c.user_id}
                      onClick={(e) => {
                        e.stopPropagation()
                        saveMutation.mutate(c.user_id)
                      }}
                    >
                      Save
                    </Button>
                  </>
                }
              />
            ))}
          </div>

          <WorkspacePagination page={page} totalPages={totalPages} onPageChange={setPage} />
        </>
      )}

      <Modal open={selectedId !== null} onClose={() => setSelectedId(null)} title="Candidate profile">
        {detailLoading && <CardSkeleton />}
        {detail && (
          <div>
            <p className="jp-job-title">{detail.current_title ?? detail.headline ?? 'Candidate'}</p>
            <p className="jp-job-company">
              {detail.location_city}
              {detail.experience_years ? ` · ${detail.experience_years} yrs experience` : ''}
            </p>
            {detail.about && <p className="jp-job-company" style={{ marginTop: 8 }}>{detail.about}</p>}
            {detail.skills.length > 0 && (
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8, marginTop: 8 }}>
                {detail.skills.map((s) => (
                  <Badge key={s} variant="gray">
                    {s}
                  </Badge>
                ))}
              </div>
            )}
            <div className="jp-job-badges" style={{ marginTop: 12 }}>
              {detail.linkedin_url && (
                <a href={detail.linkedin_url} target="_blank" rel="noreferrer">
                  LinkedIn
                </a>
              )}
              {detail.github_url && (
                <a href={detail.github_url} target="_blank" rel="noreferrer">
                  GitHub
                </a>
              )}
              {detail.portfolio_url && (
                <a href={detail.portfolio_url} target="_blank" rel="noreferrer">
                  Portfolio
                </a>
              )}
            </div>
            <div className="jp-job-badges" style={{ marginTop: 16 }}>
              {selectedId !== null && (
                <Link to={`/profiles/${selectedId}`}>
                  <Button variant="outline" size="sm">
                    View full profile
                  </Button>
                </Link>
              )}
              <Button
                variant="outline"
                size="sm"
                loading={saveMutation.isPending && saveMutation.variables === selectedId}
                onClick={() => selectedId !== null && saveMutation.mutate(selectedId)}
              >
                Save to talent pool
              </Button>
              <Button
                size="sm"
                loading={messageMutation.isPending}
                onClick={() => selectedId !== null && messageMutation.mutate(selectedId)}
              >
                Message
              </Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
