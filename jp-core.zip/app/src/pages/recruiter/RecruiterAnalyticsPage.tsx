import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { getRecruiterAnalytics } from '@/features/recruiter/analyticsApi'
import { Skeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { StatCard } from '@/components/ui/StatCard'
import { EmptyState } from '@/components/ui/EmptyState'
import '../public/JobsPage.css'
import '../dashboard/ProfilePage.css'
import './RecruiterAnalyticsPage.css'

const DAY_OPTIONS = [7, 30, 90]

export function RecruiterAnalyticsPage() {
  const [days, setDays] = useState(30)
  const { data, isLoading, isError } = useQuery({
    queryKey: ['recruiter-analytics', days],
    queryFn: () => getRecruiterAnalytics(days),
    placeholderData: (prev) => prev,
  })

  return (
    <div>
      <WorkspacePageHeader tone="recruiter"
        title="Analytics"
        subtitle="Performance across your job postings and hiring pipeline."
        actions={
          <select
            className="jp-input"
            style={{ maxWidth: 160 }}
            value={days}
            onChange={(e) => setDays(Number(e.target.value))}
            aria-label="Date range"
          >
            {DAY_OPTIONS.map((d) => (
              <option key={d} value={d}>
                Last {d} days
              </option>
            ))}
          </select>
        }
      />

      {isLoading && <Skeleton height={300} width="100%" />}

      {isError && (
        <p className="jp-jobs-error" role="alert">
          Could not load analytics.
        </p>
      )}

      {data && (
        <>
          <div className="jp-profile-grid" style={{ marginBottom: 24 }}>
            <StatCard label="Active jobs" value={data.active_jobs} />
            <StatCard label="Total applications" value={data.total_apps} />
            <StatCard label="New applications" value={data.new_apps} tone="primary" />
            <StatCard label="Hired" value={data.hired} tone="success" />
            <StatCard label="Total job views" value={data.total_views} />
            <StatCard label="Avg. match score" value={`${data.avg_match}%`} />
            <StatCard
              label="Avg. time to hire"
              value={data.avg_time_to_hire_days !== null ? `${data.avg_time_to_hire_days} days` : '—'}
            />
            <StatCard
              label="Offer acceptance rate"
              value={data.offer_acceptance_rate_pct !== null ? `${data.offer_acceptance_rate_pct}%` : '—'}
            />
          </div>

          <SectionCard title="Current pipeline (where your active applications sit right now)" className="jp-recruiter-analytics__section">
            {data.funnel.length === 0 ? (
              <EmptyState title="No applications yet" description="Your pipeline breakdown will appear here once candidates start applying." />
            ) : (
              <div className="jp-recruiter-analytics__bars">
                {data.funnel.map((f) => {
                  const max = Math.max(...data.funnel.map((x) => x.cnt), 1)
                  return (
                    <div key={f.stage}>
                      <div className="jp-recruiter-analytics__bar-label">
                        <span>{f.stage.replace('_', ' ')}</span>
                        <span className="jp-recruiter-analytics__bar-value">{f.cnt}</span>
                      </div>
                      <div className="jp-recruiter-analytics__bar-track">
                        <div className="jp-recruiter-analytics__bar-fill" style={{ width: `${(f.cnt / max) * 100}%` }} />
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </SectionCard>

          <SectionCard title="Funnel (all applications, ever reached this stage)" className="jp-recruiter-analytics__section">
            <div className="jp-jobs-list">
              {data.funnel_reach.map((f) => (
                <div key={f.stage} className="jp-job-row">
                  <span className="jp-job-title" style={{ fontSize: 13, textTransform: 'capitalize' }}>
                    {f.stage.replace('_', ' ')}
                  </span>
                  <span className="jp-job-company">
                    {f.reached} {f.conversion_from_applied_pct !== null && `(${f.conversion_from_applied_pct}% of applied)`}
                  </span>
                </div>
              ))}
            </div>
          </SectionCard>

          <SectionCard title="Top performing jobs" className="jp-recruiter-analytics__section">
            {data.top_jobs.length === 0 ? (
              <EmptyState title="No job performance data yet" description="Post a job and start receiving applications to see it ranked here." />
            ) : (
              <div className="jp-jobs-list">
                {data.top_jobs.map((j) => (
                  <div key={j.title} className="jp-job-row">
                    <span className="jp-job-title" style={{ fontSize: 13 }}>
                      {j.title}
                    </span>
                    <span className="jp-job-company">
                      {j.views_count} views · {j.app_count} applications
                    </span>
                  </div>
                ))}
              </div>
            )}
          </SectionCard>
        </>
      )}
    </div>
  )
}
