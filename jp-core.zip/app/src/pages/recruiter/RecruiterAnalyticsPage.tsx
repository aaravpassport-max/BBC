import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { getRecruiterAnalytics } from '@/features/recruiter/analyticsApi'
import { Skeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { StatCard } from '@/components/ui/StatCard'
import { ListRow } from '@/components/ui/ListRow'
import { Badge } from '@/components/ui/Badge'
import { FilterBar } from '@/components/ui/FilterBar'
import { AnalyticsKpiGrid } from '@/components/recruiter/AnalyticsKpiGrid'
import { EmptyState } from '@/components/ui/EmptyState'
import '../public/JobsPage.css'
import './RecruiterAnalyticsPage.css'

const DAY_OPTIONS = [7, 30, 90]

export function RecruiterAnalyticsPage() {
  const [days, setDays] = useState(30)
  const { data, isLoading, isError } = useQuery({
    queryKey: ['recruiter-analytics', days],
    queryFn: () => getRecruiterAnalytics(days),
    placeholderData: (prev) => prev,
  })

  return (
    <div className="jp-recruiter-analytics">
      <WorkspacePageHeader
        tone="recruiter"
        title="Analytics"
        subtitle="Performance across your job postings and hiring pipeline — all metrics are computed from your real application and job data."
      />

      <FilterBar
        className="jp-workspace-toolbar"
        filters={
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="recruiter-analytics-range">
              Date range
            </label>
            <select
              id="recruiter-analytics-range"
              className="jp-input"
              value={days}
              onChange={(e) => setDays(Number(e.target.value))}
            >
              {DAY_OPTIONS.map((d) => (
                <option key={d} value={d}>
                  Last {d} days
                </option>
              ))}
            </select>
          </div>
        }
      />

      {isLoading && <Skeleton height={300} width="100%" />}

      {isError && (
        <p className="jp-jobs-error" role="alert">
          Could not load analytics.
        </p>
      )}

      {data && (
        <>
          <AnalyticsKpiGrid>
            <StatCard label="Active jobs" value={data.active_jobs} tone="primary" />
            <StatCard label="Total applications" value={data.total_apps} />
            <StatCard label="New applications" value={data.new_apps} tone="primary" />
            <StatCard label="Hired" value={data.hired} tone="success" />
            <StatCard label="Total job views" value={data.total_views} />
            <StatCard label="Avg. match score" value={`${data.avg_match}%`} />
            <StatCard
              label="Avg. time to hire"
              value={data.avg_time_to_hire_days !== null ? `${data.avg_time_to_hire_days} days` : '—'}
            />
            <StatCard
              label="Offer acceptance"
              value={data.offer_acceptance_rate_pct !== null ? `${data.offer_acceptance_rate_pct}%` : '—'}
              tone="success"
            />
          </AnalyticsKpiGrid>

          <SectionCard title="Current pipeline" className="jp-recruiter-analytics__section">
            <p className="jp-recruiter-analytics__section-lead">Where your active applications sit right now.</p>
            {data.funnel.length === 0 ? (
              <EmptyState title="No applications yet" description="Your pipeline breakdown will appear here once candidates start applying." />
            ) : (
              <div className="jp-recruiter-analytics__bars">
                {data.funnel.map((f) => {
                  const max = Math.max(...data.funnel.map((x) => x.cnt), 1)
                  return (
                    <div key={f.stage}>
                      <div className="jp-recruiter-analytics__bar-label">
                        <span>{f.stage.replace('_', ' ')}</span>
                        <span className="jp-recruiter-analytics__bar-value">{f.cnt}</span>
                      </div>
                      <div className="jp-recruiter-analytics__bar-track">
                        <div className="jp-recruiter-analytics__bar-fill" style={{ width: `${(f.cnt / max) * 100}%` }} />
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </SectionCard>

          <SectionCard title="Funnel reach" className="jp-recruiter-analytics__section">
            <p className="jp-recruiter-analytics__section-lead">All applications that ever reached each stage.</p>
            <div className="jp-recruiter-analytics__list">
              {data.funnel_reach.map((f) => (
                <ListRow
                  key={f.stage}
                  title={<span className="jp-recruiter-analytics__stage-name">{f.stage.replace('_', ' ')}</span>}
                  meta={
                    f.conversion_from_applied_pct !== null
                      ? `${f.reached} reached · ${f.conversion_from_applied_pct}% of applied`
                      : `${f.reached} reached`
                  }
                  aside={<Badge variant="gray">{f.reached}</Badge>}
                />
              ))}
            </div>
          </SectionCard>

          <SectionCard title="Top performing jobs" className="jp-recruiter-analytics__section">
            {data.top_jobs.length === 0 ? (
              <EmptyState title="No job performance data yet" description="Post a job and start receiving applications to see it ranked here." />
            ) : (
              <div className="jp-recruiter-analytics__list">
                {data.top_jobs.map((j, i) => (
                  <ListRow
                    key={j.title}
                    title={j.title}
                    meta={`${j.views_count.toLocaleString()} views · ${j.app_count.toLocaleString()} applications`}
                    aside={<Badge variant={i === 0 ? 'accent' : 'gray'}>#{i + 1}</Badge>}
                  />
                ))}
              </div>
            )}
          </SectionCard>
        </>
      )}
    </div>
  )
}
