import { useMemo, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  listTalentPool,
  toggleSaveCandidate,
  updateSavedCandidateNote,
  type SavedCandidateRow,
} from '@/features/recruiter/talentPoolApi'
import { createThread } from '@/features/messaging/api'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { PageHeader } from '@/components/ui/PageHeader'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { FilterBar } from '@/components/ui/FilterBar'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './RecruiterTalentPoolPage.css'

type SortOrder = 'recent' | 'name'

/**
 * The recruiter-side mirror of SavedJobsPage.tsx — same list/filter/sort/
 * remove pattern, on saved candidates instead of saved jobs. Added as part
 * of the "much more ground to build" pass: a candidate could already save
 * a job for later, but a recruiter had no equivalent way to bookmark a
 * promising candidate found while searching — confirmed absent via a
 * full-codebase grep for saved_candidate/bookmark/talent_pool before this
 * page, table, and API were built (see class-jp-activator.php's
 * jp_saved_candidates table docblock and class-jp-api.php's
 * toggle_save_candidate()/get_talent_pool() docblocks for the backend half).
 */
export function RecruiterTalentPoolPage() {
  const toast = useToast()
  const navigate = useNavigate()
  const queryClient = useQueryClient()
  const [sort, setSort] = useState<SortOrder>('recent')
  // Root-cause fix (schema-exists-no-writer gap): jp_saved_candidates.note
  // was already fetched here (SavedCandidateRow.note) but had no editor
  // anywhere — local drafts keyed by candidate user_id, explicit Save
  // button per row (matching the rest of this app's no-autosave pattern,
  // e.g. RecruiterCompanyPage), defaulting to the row's own saved note.
  const [noteDrafts, setNoteDrafts] = useState<Record<number, string>>({})

  const { data, isLoading, isError } = useQuery({
    queryKey: ['talent-pool'],
    queryFn: listTalentPool,
  })

  const removeMutation = useMutation({
    mutationFn: (candidateUserId: number) => toggleSaveCandidate(candidateUserId),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['talent-pool'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update your talent pool.'),
  })

  const messageMutation = useMutation({
    mutationFn: (candidateUserId: number) => createThread(candidateUserId),
    onSuccess: (result) => navigate(`/recruiter/messages?thread=${result.thread_id}`),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not start a conversation with this candidate.'),
  })

  const noteMutation = useMutation({
    mutationFn: ({ candidateUserId, note }: { candidateUserId: number; note: string }) =>
      updateSavedCandidateNote(candidateUserId, note),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['talent-pool'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not save your note.'),
  })

  const sortedRows = useMemo(() => {
    const rows: SavedCandidateRow[] = data ?? []
    const sorted = [...rows]
    if (sort === 'name') sorted.sort((a, b) => (a.display_name || '').localeCompare(b.display_name || ''))
    else sorted.sort((a, b) => new Date(b.saved_at).getTime() - new Date(a.saved_at).getTime())
    return sorted
  }, [data, sort])

  return (
    <div>
      <PageHeader
        title="Talent pool"
        subtitle={
          data && data.length > 0
            ? `${data.length} candidate${data.length === 1 ? '' : 's'} saved for later.`
            : 'Candidates you save while searching show up here.'
        }
      />

      {data && data.length > 0 && (
        <FilterBar
          sort={
            <select className="jp-input" value={sort} onChange={(e) => setSort(e.target.value as SortOrder)} aria-label="Sort talent pool">
              <option value="recent">Recently saved</option>
              <option value="name">Name (A–Z)</option>
            </select>
          }
        />
      )}

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load your talent pool.</p>}

      {!isLoading && data && data.length === 0 && (
        <EmptyState
          title="No saved candidates yet"
          description="Save a candidate while searching to come back to them later — they'll show up here."
          action={
            <Link to="/recruiter/candidates">
              <Button variant="accent">Find candidates</Button>
            </Link>
          }
        />
      )}

      {!isLoading && sortedRows.length > 0 && (
        <div className="jp-jobs-list">
          {sortedRows.map((c) => (
            <Card key={c.user_id}>
              <CardBody>
                <div className="jp-job-row">
                  <div className="jp-talent-pool__identity">
                    {c.avatar_url ? (
                      <img src={c.avatar_url} alt="" className="jp-talent-pool__avatar" />
                    ) : (
                      <div className="jp-talent-pool__avatar jp-talent-pool__avatar--placeholder">
                        {(c.display_name || '?')[0]}
                      </div>
                    )}
                    <div>
                      <h2 className="jp-job-title">
                        <Link to={`/profiles/${c.user_id}`}>{c.display_name}</Link>
                      </h2>
                      <p className="jp-job-company">
                        {c.current_title || c.headline || 'Candidate'}
                        {c.location_city ? ` · ${c.location_city}` : ''}
                        {c.experience_years ? ` · ${c.experience_years} yrs` : ''}
                      </p>
                      <p className="jp-job-company">
                        Saved {new Date(c.saved_at.replace(' ', 'T')).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div className="jp-job-badges">
                    {c.is_open_to_work === 1 && <Badge variant="success">Open to work</Badge>}
                    <Badge variant="gray">Score {c.profile_score}</Badge>
                    <Button
                      size="sm"
                      loading={messageMutation.isPending && messageMutation.variables === c.user_id}
                      onClick={() => messageMutation.mutate(c.user_id)}
                    >
                      Message
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      loading={removeMutation.isPending && removeMutation.variables === c.user_id}
                      onClick={() => removeMutation.mutate(c.user_id)}
                    >
                      Remove
                    </Button>
                  </div>
                </div>
                {c.skills.length > 0 && (
                  <p className="jp-job-company" style={{ marginTop: 8 }}>
                    {c.skills.slice(0, 8).join(', ')}
                  </p>
                )}
                <div className="jp-talent-pool__note" style={{ marginTop: 12 }}>
                  <label className="jp-label" htmlFor={`note-${c.user_id}`}>
                    Private note
                  </label>
                  <textarea
                    id={`note-${c.user_id}`}
                    className="jp-textarea"
                    rows={2}
                    maxLength={300}
                    placeholder="e.g. Great culture fit, follow up next quarter..."
                    value={noteDrafts[c.user_id] ?? c.note ?? ''}
                    onChange={(e) => setNoteDrafts((prev) => ({ ...prev, [c.user_id]: e.target.value }))}
                  />
                  {(noteDrafts[c.user_id] ?? c.note ?? '') !== (c.note ?? '') && (
                    <Button
                      variant="outline"
                      size="sm"
                      style={{ marginTop: 6 }}
                      loading={noteMutation.isPending && noteMutation.variables?.candidateUserId === c.user_id}
                      onClick={() =>
                        noteMutation.mutate({ candidateUserId: c.user_id, note: noteDrafts[c.user_id] ?? '' })
                      }
                    >
                      Save note
                    </Button>
                  )}
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
