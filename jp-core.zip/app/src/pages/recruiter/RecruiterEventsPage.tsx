import { useState, type FormEvent } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import {
  EVENT_FORMATS,
  EVENT_TYPES,
  createEvent,
  listEvents,
  updateEvent,
  type CreateEventPayload,
  type EventRow,
  type UpdateEventPayload,
} from '@/features/events/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Modal } from '@/components/ui/Modal'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './RecruiterEventsPage.css'

const STATUS_VARIANT = { draft: 'gray', published: 'success', cancelled: 'error', completed: 'gray' } as const

/**
 * Root-cause fix (batch 31): update_event() (PUT /events/{id}) has always
 * been a real, registered route but had zero SPA caller — this modal is
 * the first one. Editable fields match update_event()'s own $allowed
 * whitelist exactly (title/description/status/starts_at/ends_at/
 * meeting_url/seats_total) — no field is offered that the backend doesn't
 * actually persist.
 */
function EditEventModal({ event, onClose }: { event: EventRow; onClose: () => void }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [form, setForm] = useState<UpdateEventPayload>({
    title: event.title,
    description: event.description ?? '',
    status: event.status,
    starts_at: event.starts_at ?? '',
    ends_at: event.ends_at ?? '',
    meeting_url: event.meeting_url ?? '',
    seats_total: event.seats_total,
  })

  const updateMutation = useMutation({
    mutationFn: () => updateEvent(event.id, form),
    onSuccess: () => {
      toast.success('Event updated.')
      queryClient.invalidateQueries({ queryKey: ['events'] })
      onClose()
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update this event.'),
  })

  function field<K extends keyof UpdateEventPayload>(key: K, value: UpdateEventPayload[K]) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  return (
    <Modal open onClose={onClose} title={`Edit "${event.title}"`}>
      <form
        onSubmit={(e) => {
          e.preventDefault()
          updateMutation.mutate()
        }}
        className="jp-profile-grid"
      >
        <Input label="Title" value={form.title} onChange={(e) => field('title', e.target.value)} style={{ gridColumn: '1 / -1' }} />
        <div className="jp-form-group">
          <label className="jp-label" htmlFor="edit-event-status">
            Status
          </label>
          <select
            id="edit-event-status"
            className="jp-input"
            value={form.status}
            onChange={(e) => field('status', e.target.value as UpdateEventPayload['status'])}
          >
            <option value="draft">Draft</option>
            <option value="published">Published</option>
            <option value="cancelled">Cancelled</option>
            <option value="completed">Completed</option>
          </select>
        </div>
        <Input
          label="Total seats (0 = unlimited)"
          type="number"
          value={String(form.seats_total ?? 0)}
          onChange={(e) => field('seats_total', Number(e.target.value))}
        />
        <Input label="Starts at" type="datetime-local" value={form.starts_at} onChange={(e) => field('starts_at', e.target.value)} />
        <Input label="Ends at" type="datetime-local" value={form.ends_at} onChange={(e) => field('ends_at', e.target.value)} />
        <Input label="Meeting URL" value={form.meeting_url} onChange={(e) => field('meeting_url', e.target.value)} />
        <div className="jp-form-group" style={{ gridColumn: '1 / -1' }}>
          <label className="jp-label" htmlFor="edit-event-description">
            Description
          </label>
          <textarea
            id="edit-event-description"
            className="jp-textarea"
            value={form.description}
            onChange={(e) => field('description', e.target.value)}
          />
        </div>
        <div style={{ alignSelf: 'end' }}>
          <Button type="submit" variant="accent" loading={updateMutation.isPending}>
            Save changes
          </Button>
        </div>
      </form>
    </Modal>
  )
}

const EMPTY_FORM: CreateEventPayload = {
  title: '',
  description: '',
  event_type: 'webinar',
  format: 'online',
  starts_at: '',
  ends_at: '',
  venue: '',
  meeting_url: '',
  seats_total: 0,
  is_free: 1,
  price: 0,
  status: 'draft',
}

export function RecruiterEventsPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [composerOpen, setComposerOpen] = useState(false)
  const [form, setForm] = useState<CreateEventPayload>(EMPTY_FORM)
  const [editingEvent, setEditingEvent] = useState<EventRow | null>(null)

  // Root-cause fix (batch 31): this used to only query the public listing
  // (status='published' AND starts_at>=NOW()), so a recruiter's own drafts
  // were permanently invisible the moment they clicked "Save as draft" —
  // there was no way to ever find or finish them. mine=1 now surfaces
  // every event this recruiter's company has ever created, any status.
  const { data, isLoading, isError } = useQuery({ queryKey: ['events', 'mine'], queryFn: () => listEvents({ mine: true }) })

  const createMutation = useMutation({
    mutationFn: () => createEvent(form),
    onSuccess: (result) => {
      toast.success(result.message)
      setComposerOpen(false)
      setForm(EMPTY_FORM)
      queryClient.invalidateQueries({ queryKey: ['events'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not create event.'),
  })

  function field<K extends keyof CreateEventPayload>(key: K, value: CreateEventPayload[K]) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!form.title.trim()) {
      toast.error('Title is required.')
      return
    }
    createMutation.mutate()
  }

  return (
    <div>
      <WorkspacePageHeader tone="recruiter"
        title="Events"
        subtitle="Host webinars and career events to reach candidates directly."
        actions={
          <Button variant="accent" onClick={() => setComposerOpen(true)}>
            Host an event
          </Button>
        }
      />

      {composerOpen && (
        <Card style={{ marginBottom: 16 }}>
          <CardBody>
            <form onSubmit={onSubmit} className="jp-profile-grid">
              <Input label="Title" value={form.title} onChange={(e) => field('title', e.target.value)} style={{ gridColumn: '1 / -1' }} />
              <div className="jp-form-group">
                <label className="jp-label" htmlFor="event-type">
                  Type
                </label>
                <select id="event-type" className="jp-input" value={form.event_type} onChange={(e) => field('event_type', e.target.value as CreateEventPayload['event_type'])}>
                  {EVENT_TYPES.map((t) => (
                    <option key={t} value={t}>
                      {t.replace('_', ' ')}
                    </option>
                  ))}
                </select>
              </div>
              <div className="jp-form-group">
                <label className="jp-label" htmlFor="event-format">
                  Format
                </label>
                <select id="event-format" className="jp-input" value={form.format} onChange={(e) => field('format', e.target.value as CreateEventPayload['format'])}>
                  {EVENT_FORMATS.map((f) => (
                    <option key={f} value={f}>
                      {f}
                    </option>
                  ))}
                </select>
              </div>
              <Input
                label="Starts at"
                type="datetime-local"
                value={form.starts_at}
                onChange={(e) => field('starts_at', e.target.value)}
              />
              <Input label="Ends at" type="datetime-local" value={form.ends_at} onChange={(e) => field('ends_at', e.target.value)} />
              {form.format !== 'online' && (
                <Input label="Venue" value={form.venue} onChange={(e) => field('venue', e.target.value)} />
              )}
              {form.format !== 'offline' && (
                <Input label="Meeting URL" value={form.meeting_url} onChange={(e) => field('meeting_url', e.target.value)} />
              )}
              <Input
                label="Total seats (0 = unlimited)"
                type="number"
                value={String(form.seats_total ?? 0)}
                onChange={(e) => field('seats_total', Number(e.target.value))}
              />
              <div className="jp-form-group">
                <label className="jp-label" htmlFor="event-free">
                  Pricing
                </label>
                <select
                  id="event-free"
                  className="jp-input"
                  value={String(form.is_free ?? 1)}
                  onChange={(e) => field('is_free', Number(e.target.value))}
                >
                  <option value="1">Free</option>
                  <option value="0">Paid</option>
                </select>
              </div>
              {!form.is_free && (
                <Input
                  label="Price (₹)"
                  type="number"
                  value={String(form.price ?? 0)}
                  onChange={(e) => field('price', Number(e.target.value))}
                />
              )}
              <div className="jp-form-group" style={{ gridColumn: '1 / -1' }}>
                <label className="jp-label" htmlFor="event-description">
                  Description
                </label>
                <textarea
                  id="event-description"
                  className="jp-textarea"
                  value={form.description}
                  onChange={(e) => field('description', e.target.value)}
                />
              </div>
              <div className="jp-form-group">
                <label className="jp-label" htmlFor="event-status">
                  Status
                </label>
                <select id="event-status" className="jp-input" value={form.status} onChange={(e) => field('status', e.target.value as CreateEventPayload['status'])}>
                  <option value="draft">Save as draft</option>
                  <option value="published">Publish now</option>
                </select>
              </div>
              <div style={{ alignSelf: 'end', display: 'flex', gap: 8 }}>
                <Button type="submit" variant="accent" loading={createMutation.isPending}>
                  Save event
                </Button>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    // Root-cause fix (states audit — residual state on modal
                    // close): Cancel used to only hide the composer, leaving
                    // the unsaved draft in `form`, so reopening it showed
                    // the previous attempt's values instead of a fresh form.
                    setComposerOpen(false)
                    setForm(EMPTY_FORM)
                  }}
                >
                  Cancel
                </Button>
              </div>
            </form>
          </CardBody>
        </Card>
      )}

      <SectionCard title="Your hosted events" className="jp-recruiter-events__section">
      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 3 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load events. Please try again.
        </div>
      )}

      {!isLoading && data && data.events.length === 0 && (
        <EmptyState
          title="No events yet"
          description="Host a webinar or career event to reach candidates directly."
          action={
            <Button variant="accent" size="sm" onClick={() => setComposerOpen(true)}>
              Host an event
            </Button>
          }
        />
      )}

      {!isLoading && data && data.events.length > 0 && (
        <div className="jp-jobs-list">
          {data.events.map((evt) => (
            <Card key={evt.id}>
              <CardBody>
                <div className="jp-job-row">
                  <div>
                    <p className="jp-job-title" style={{ fontSize: 14 }}>
                      {evt.status === 'published' ? <Link to={`/events/${evt.id}`}>{evt.title}</Link> : evt.title}
                    </p>
                    <p className="jp-job-company">{evt.starts_at ? new Date(evt.starts_at).toLocaleString() : 'TBD'}</p>
                  </div>
                  <div className="jp-job-badges">
                    <Badge variant={STATUS_VARIANT[evt.status]}>{evt.status}</Badge>
                    <Badge variant="gray">{evt.event_type.replace('_', ' ')}</Badge>
                    <Badge variant="gray">{evt.format}</Badge>
                    {evt.format !== 'online' && evt.venue && (
                      <span className="jp-job-company">{evt.venue}</span>
                    )}
                    <span className="jp-job-company">
                      {evt.attendee_count}
                      {evt.seats_total > 0 ? `/${evt.seats_total}` : ''} attending
                    </span>
                    <Button variant="outline" size="sm" onClick={() => setEditingEvent(evt)}>
                      Edit
                    </Button>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}
      </SectionCard>

      {editingEvent && <EditEventModal event={editingEvent} onClose={() => setEditingEvent(null)} />}
    </div>
  )
}
