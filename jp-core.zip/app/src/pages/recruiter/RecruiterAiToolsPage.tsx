import { useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import {
  getInterviewQuestions,
  improveJobDescription,
  type InterviewQuestionsResult,
  type ImproveJdResult,
} from '@/features/ai/api'
import { listRecruiterJobs } from '@/features/recruiter/jobsApi'
import { Card, CardBody } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Badge } from '@/components/ui/Badge'
import { PageHeader } from '@/components/ui/PageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { useToast } from '@/components/ui/ToastProvider'
import '../dashboard/ProfilePage.css'
import './RecruiterAiToolsPage.css'

/**
 * Root-cause fix (batch 18): this previously asked a recruiter to type a
 * raw numeric job ID by hand — a number no UI anywhere else in the app ever
 * shows them, so in practice they'd have to go dig it out of a URL first.
 * Replaced with a real dropdown of their own job postings (listRecruiterJobs(),
 * the same endpoint RecruiterJobsPage already uses), so the tool is usable
 * without leaving the page.
 */
function InterviewQuestionsTool() {
  const [jobId, setJobId] = useState('')
  const toast = useToast()
  const { data: jobsData, isLoading: jobsLoading } = useQuery({
    queryKey: ['recruiter-jobs-picker'],
    queryFn: () => listRecruiterJobs({ page: 1 }),
  })
  const mutation = useMutation({
    mutationFn: () => getInterviewQuestions(Number(jobId)),
    onError: () => toast.error('Could not generate interview questions.'),
  })
  const result = mutation.data
  const jobs = jobsData?.jobs ?? []

  return (
    <SectionCard title="Interview question generator" className="jp-recruiter-ai-tools__tool">
      <div className="jp-form-group">
        <label className="jp-label" htmlFor="ai-tools-job-picker">
          Job posting
        </label>
        {jobsLoading ? (
          <p className="jp-job-company">Loading your job postings…</p>
        ) : jobs.length === 0 ? (
          <p className="jp-job-company">You haven't posted any jobs yet.</p>
        ) : (
          <select
            id="ai-tools-job-picker"
            className="jp-input"
            value={jobId}
            onChange={(e) => setJobId(e.target.value)}
          >
            <option value="">Select a job…</option>
            {jobs.map((j) => (
              <option key={j.id} value={j.id}>
                {j.title}
              </option>
            ))}
          </select>
        )}
      </div>
      <Button onClick={() => mutation.mutate()} loading={mutation.isPending} disabled={!jobId.trim()}>
        Generate questions
      </Button>
      {result && !result.available && (
        <p className="jp-job-company" style={{ marginTop: 8 }}>
          AI unavailable: {result.reason}
        </p>
      )}
      {result && result.available && (
        <div style={{ marginTop: 12 }}>
          <p className="jp-job-company">{(result as InterviewQuestionsResult).job_title}</p>
          <div className="jp-jobs-list" style={{ marginTop: 8 }}>
            {(result as InterviewQuestionsResult).questions.map((q, i) => (
              <Card key={i}>
                <CardBody>
                  <p className="jp-job-title" style={{ fontSize: 14 }}>
                    {q.question}
                  </p>
                  <Badge variant="gray">{q.category}</Badge>
                  <p className="jp-job-company" style={{ marginTop: 6 }}>
                    What to listen for: {q.what_to_listen_for}
                  </p>
                </CardBody>
              </Card>
            ))}
          </div>
        </div>
      )}
    </SectionCard>
  )
}

function ImproveJdTool() {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const toast = useToast()
  const mutation = useMutation({
    mutationFn: () => improveJobDescription(title, description),
    onError: () => toast.error('Could not improve job description.'),
  })
  const result = mutation.data

  return (
    <SectionCard title="Job description improver" className="jp-recruiter-ai-tools__tool">
      <Input label="Job title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Backend Engineer" />
      <div className="jp-form-group">
        <label className="jp-label" htmlFor="job-description-improver">
          Description
        </label>
        <textarea
          id="job-description-improver"
          className="jp-textarea"
          rows={8}
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          placeholder="Paste your job description..."
        />
      </div>
      <Button
        onClick={() => mutation.mutate()}
        loading={mutation.isPending}
        disabled={!title.trim() || !description.trim()}
      >
        Improve description
      </Button>
      {result && !result.available && (
        <p className="jp-job-company" style={{ marginTop: 8 }}>
          AI unavailable: {result.reason}
        </p>
      )}
      {result && result.available && (
        <div style={{ marginTop: 12 }}>
          <p className="jp-job-title">Readability score: {(result as ImproveJdResult).readability_score}</p>
          <p className="jp-job-company" style={{ whiteSpace: 'pre-wrap', marginTop: 8 }}>
            {(result as ImproveJdResult).improved_description}
          </p>
          <p className="jp-job-company" style={{ marginTop: 8 }}>
            Improvements made: {(result as ImproveJdResult).improvements_made.join(', ') || '—'}
          </p>
          <p className="jp-job-company">
            ATS keywords: {(result as ImproveJdResult).ats_keywords.join(', ') || '—'}
          </p>
        </div>
      )}
    </SectionCard>
  )
}

export function RecruiterAiToolsPage() {
  return (
    <div>
      <PageHeader title="AI tools" subtitle="AI-powered tools to help you hire faster." />
      <div className="jp-recruiter-ai-tools__grid">
        <InterviewQuestionsTool />
        <ImproveJdTool />
      </div>
    </div>
  )
}
