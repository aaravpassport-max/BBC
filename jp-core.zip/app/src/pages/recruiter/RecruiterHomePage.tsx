import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { useAuth } from '@/lib/auth/AuthContext'
import { getRecruiterAnalytics } from '@/features/recruiter/analyticsApi'
import { listRecruiterApplications } from '@/features/recruiter/applicationsApi'
import { listInterviews } from '@/features/recruiter/interviewsApi'
import type { ApplicationStage } from '@/features/applications/api'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { StatCard } from '@/components/ui/StatCard'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { ListRow } from '@/components/ui/ListRow'
import './RecruiterHomePage.css'

const STAGE_BADGE: Record<ApplicationStage, { label: string; variant: 'gray' | 'info' | 'accent' | 'success' | 'error' }> = {
  applied: { label: 'Applied', variant: 'gray' },
  viewed: { label: 'Viewed', variant: 'gray' },
  shortlisted: { label: 'Shortlisted', variant: 'info' },
  phone_screen: { label: 'Phone screen', variant: 'info' },
  assessment: { label: 'Assessment', variant: 'info' },
  interview: { label: 'Interview', variant: 'accent' },
  offer: { label: 'Offer', variant: 'accent' },
  hired: { label: 'Hired', variant: 'success' },
  rejected: { label: 'Rejected', variant: 'error' },
  withdrawn: { label: 'Withdrawn', variant: 'gray' },
}

/**
 * Batch 32 (phase 7, recruiter section) — root-cause fix. This page was a
 * documented placeholder shell ("Full build-out... is JP-PLATFORM-ROADMAP.md
 * Phase 2") showing only unread-message-count and verification status, even
 * though every data source a real recruiter workspace needs already exists
 * and is already used elsewhere in the SPA: getRecruiterAnalytics() (used by
 * RecruiterAnalyticsPage), listRecruiterApplications() (used by
 * RecruiterApplicationsPage), and listInterviews() (used by
 * RecruiterInterviewsPage). Nothing here is fabricated — it's the same real
 * endpoints, surfaced on the landing page instead of requiring a recruiter
 * to visit four different pages to see how their hiring is going.
 */
export function RecruiterHomePage() {
  const { config } = useAuth()

  const { data: analytics, isLoading: analyticsLoading, isError: analyticsError } = useQuery({
    queryKey: ['recruiter-analytics', 30],
    queryFn: () => getRecruiterAnalytics(30),
  })
  const { data: applications, isLoading: appsLoading, isError: appsError } = useQuery({
    queryKey: ['recruiter-applications-recent'],
    queryFn: () => listRecruiterApplications(),
  })
  const { data: interviews, isLoading: interviewsLoading, isError: interviewsError } = useQuery({
    queryKey: ['recruiter-interviews-upcoming'],
    queryFn: listInterviews,
  })

  const recentApplications = (applications?.applications ?? []).slice(0, 5)
  const upcomingInterviews = (interviews ?? [])
    .filter((i) => i.outcome === 'pending' && i.scheduled_at)
    .sort((a, b) => new Date(a.scheduled_at!).getTime() - new Date(b.scheduled_at!).getTime())
    .slice(0, 5)

  return (
    <div className="jp-recruiter-home">
      <WorkspacePageHeader
        tone="recruiter"
        title={`Recruiter workspace${config?.company?.name ? ` — ${config.company.name}` : ''}`}
        subtitle="Pipeline activity, upcoming interviews, and applicants who need your attention."
        actions={
          <>
            <Badge variant={config?.company?.is_verified ? 'success' : 'warning'}>
              {config?.company?.is_verified ? 'Company verified' : 'Verification pending'}
            </Badge>
            <Link to="/recruiter/jobs/new">
              <Button variant="accent">Post a job</Button>
            </Link>
          </>
        }
        stats={
          analyticsLoading ? undefined : analyticsError ? undefined : analytics ? (
            <>
              <StatCard label="Active jobs" value={analytics.active_jobs} tone="primary" />
              <StatCard label="New applications" value={analytics.new_apps} tone="success" />
              <StatCard label="Total applications" value={analytics.total_apps} />
              <StatCard label="Hired" value={analytics.hired} tone="success" />
              <StatCard label="Avg. match" value={`${Math.round(analytics.avg_match)}%`} />
              <StatCard label="Unread messages" value={config?.unread_messages ?? 0} tone={config?.unread_messages ? 'warning' : 'default'} />
            </>
          ) : undefined
        }
      />

      {analyticsLoading && <Skeleton height={100} width="100%" />}
      {analyticsError && <p className="jp-jobs-error" role="alert">Could not load your workspace stats.</p>}

      <div className="jp-recruiter-home__grid">
        <div className="jp-recruiter-home__main">
          <SectionCard title="Recent applications" action={<Link to="/recruiter/applications" className="jp-recruiter-home__see-all">See all →</Link>}>
            {appsLoading && <Skeleton height={140} width="100%" />}
            {!appsLoading && appsError && (
              <p className="jp-jobs-error" role="alert">Could not load recent applications.</p>
            )}
            {!appsLoading && !appsError && recentApplications.length === 0 && (
              <EmptyState title="No applications yet" description="Applications to your open jobs will appear here." />
            )}
            {!appsLoading && !appsError && recentApplications.length > 0 && (
              <div className="jp-jobs-list">
                {recentApplications.map((app) => {
                  const stage = STAGE_BADGE[app.stage] ?? { label: app.stage, variant: 'gray' as const }
                  return (
                    <ListRow
                      key={app.id}
                      to={`/recruiter/applications?highlight=${app.id}`}
                      title={app.candidate_name}
                      meta={`${app.job_title} · match ${app.match_score}%`}
                      aside={<Badge variant={stage.variant}>{stage.label}</Badge>}
                    />
                  )
                })}
              </div>
            )}
          </SectionCard>

          <SectionCard title="Upcoming interviews" action={<Link to="/recruiter/interviews" className="jp-recruiter-home__see-all">See all →</Link>}>
            {interviewsLoading && <Skeleton height={100} width="100%" />}
            {!interviewsLoading && interviewsError && (
              <p className="jp-jobs-error" role="alert">Could not load upcoming interviews.</p>
            )}
            {!interviewsLoading && !interviewsError && upcomingInterviews.length === 0 && (
              <EmptyState title="No interviews scheduled" description="Interviews you schedule with candidates will appear here." />
            )}
            {!interviewsLoading && !interviewsError && upcomingInterviews.length > 0 && (
              <div className="jp-jobs-list">
                {upcomingInterviews.map((iv) => (
                  <div key={iv.id} className="jp-job-row">
                    <div>
                      <p className="jp-job-title" style={{ fontSize: 14 }}>{iv.candidate_name ?? 'Candidate'}</p>
                      <p className="jp-job-company">
                        {iv.job_title ?? 'Role'} · round {iv.round} · {iv.type}
                      </p>
                    </div>
                    <span className="jp-job-company">{new Date(iv.scheduled_at!).toLocaleString()}</span>
                  </div>
                ))}
              </div>
            )}
          </SectionCard>
        </div>

        <div className="jp-recruiter-home__sidebar">
          <SectionCard title="Quick actions">
            <div className="jp-recruiter-home__quick-actions">
              <Link to="/recruiter/jobs/new">Post a new job</Link>
              <Link to="/recruiter/candidates">Search candidates</Link>
              <Link to="/recruiter/interviews">Schedule an interview</Link>
              <Link to="/recruiter/billing">Manage billing</Link>
              <Link to="/recruiter/team">Manage team</Link>
            </div>
          </SectionCard>

          {analytics && analytics.top_jobs.length > 0 && (
            <SectionCard title="Top performing jobs">
              <div className="jp-jobs-list">
                {analytics.top_jobs.slice(0, 5).map((job) => (
                  <div key={job.title} className="jp-job-row">
                    <span className="jp-job-title" style={{ fontSize: 13 }}>{job.title}</span>
                    <span className="jp-job-company">
                      {job.app_count} apps · {job.views_count} views
                    </span>
                  </div>
                ))}
              </div>
            </SectionCard>
          )}
        </div>
      </div>
    </div>
  )
}
