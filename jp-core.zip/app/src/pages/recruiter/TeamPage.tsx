import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { getTeam, inviteTeamMember, removeTeamMember } from '@/features/team/api'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './TeamPage.css'

const inviteSchema = z.object({
  email: z.string().email('Enter a valid email address.'),
  role: z.enum(['manager', 'member']),
})
type InviteForm = z.infer<typeof inviteSchema>

const STATUS_VARIANT = { active: 'success', invited: 'warning', removed: 'gray' } as const

/**
 * Root-cause fix (batch 6 — see class-jp-team.php's class docblock and
 * features/team/api.ts's docblock for the full gap trace). The first SPA
 * page this feature has ever had: seat usage, member list with role/status,
 * an invite form with seat-limit-aware disabling, and remove. Company
 * ownership/manager checks are enforced server-side in JP_Team's do_*()
 * methods (see api.ts) — this page shows what the API allows and surfaces
 * whatever error it returns, the same defense-in-depth split used
 * throughout this app (ProtectedRoute's own docblock states the principle).
 */
export function TeamPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [confirmRemoveId, setConfirmRemoveId] = useState<number | null>(null)

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ['team'],
    queryFn: getTeam,
    retry: false,
  })

  function invalidate() {
    queryClient.invalidateQueries({ queryKey: ['team'] })
  }

  const form = useForm<InviteForm>({ resolver: zodResolver(inviteSchema), defaultValues: { role: 'member' } })

  const inviteMutation = useMutation({
    mutationFn: ({ email, role }: InviteForm) => inviteTeamMember(email, role),
    onSuccess: (result) => {
      toast.success(result.message)
      form.reset({ email: '', role: 'member' })
      invalidate()
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not send invitation.'),
  })

  const removeMutation = useMutation({
    mutationFn: (memberId: number) => removeTeamMember(memberId),
    onSuccess: (result) => {
      toast.success(result.message)
      setConfirmRemoveId(null)
      invalidate()
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not remove this team member.'),
  })

  const seatsFull = data ? data.seats_used >= data.seats_limit : false

  return (
    <div>
      <WorkspacePageHeader tone="recruiter" title="Team" subtitle="Invite colleagues to help manage jobs, applicants, and interviews." />

      {isLoading && (
        <div className="jp-jobs-list">
          <CardSkeleton />
          <CardSkeleton />
        </div>
      )}

      {isError && (
        <p className="jp-jobs-error" role="alert">
          {error instanceof ApiError ? error.message : 'Could not load your team.'}
        </p>
      )}

      {!isLoading && data && (
        <>
          <SectionCard title="Invite a team member" action={<span className="jp-job-company">{data.seats_used} of {data.seats_limit} seats used</span>} className="jp-team-page__section">
              {seatsFull && (
                <p className="jp-job-company" style={{ marginBottom: 12 }}>
                  Your plan is at its seat limit. Upgrade to invite more people.
                </p>
              )}
              <form
                onSubmit={form.handleSubmit((values) => inviteMutation.mutate(values))}
                noValidate
                style={{ display: 'flex', gap: 12, alignItems: 'flex-end', flexWrap: 'wrap' }}
              >
                <div style={{ flex: '1 1 240px' }}>
                  <Input
                    label="Invite by email"
                    type="email"
                    error={form.formState.errors.email?.message}
                    {...form.register('email')}
                  />
                </div>
                <div className="jp-form-group" style={{ minWidth: 160 }}>
                  <label className="jp-label" htmlFor="role">
                    Role
                  </label>
                  <select id="role" className="jp-input" {...form.register('role')}>
                    <option value="member">Member</option>
                    <option value="manager">Manager (can invite/remove)</option>
                  </select>
                </div>
                <Button type="submit" loading={inviteMutation.isPending} disabled={seatsFull}>
                  Send invite
                </Button>
              </form>
          </SectionCard>

          <SectionCard title="Team members" className="jp-team-page__section">
          {data.members.length === 0 ? (
            <EmptyState title="No team members yet" description="Invite someone above to get started." />
          ) : (
            <div className="jp-jobs-list">
              {data.members.map((m) => (
                <Card key={m.id}>
                  <CardBody>
                    <div className="jp-job-row">
                      <div>
                        <h2 className="jp-job-title">{m.display_name ?? m.invited_email}</h2>
                        <p className="jp-job-company">
                          {m.user_email_actual ?? m.invited_email} · {m.role === 'manager' ? 'Manager' : 'Member'}
                        </p>
                        <p className="jp-job-company">
                          {m.status === 'active' && m.accepted_at
                            ? `Joined ${new Date(m.accepted_at).toLocaleDateString()}`
                            : `Invited ${new Date(m.invited_at).toLocaleDateString()}`}
                        </p>
                      </div>
                      <div className="jp-job-badges">
                        <Badge variant={STATUS_VARIANT[m.status] ?? 'gray'}>{m.status}</Badge>
                        {confirmRemoveId === m.id ? (
                          <>
                            <Button
                              size="sm"
                              variant="danger"
                              loading={removeMutation.isPending && removeMutation.variables === m.id}
                              onClick={() => removeMutation.mutate(m.id)}
                            >
                              Confirm remove
                            </Button>
                            <Button size="sm" variant="ghost" onClick={() => setConfirmRemoveId(null)}>
                              Cancel
                            </Button>
                          </>
                        ) : (
                          <Button size="sm" variant="outline" onClick={() => setConfirmRemoveId(m.id)}>
                            Remove
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardBody>
                </Card>
              ))}
            </div>
          )}
          </SectionCard>
        </>
      )}
    </div>
  )
}
