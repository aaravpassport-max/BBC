import { useState } from 'react'
import { useQueryClient, useQuery } from '@tanstack/react-query'
import { getPublicPlans } from '@/features/plans/api'
import { getMarketInsights } from '@/features/market/api'
import { createOrder, openRazorpayCheckout } from '@/features/payments/api'
import { useAuth } from '@/lib/auth/AuthContext'
import { useToast } from '@/components/ui/ToastProvider'
import { Card, CardBody } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { PublicPageHero } from '@/components/layout/PublicPageHero'
import { StatCard } from '@/components/ui/StatCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { SectionCard } from '@/components/ui/SectionCard'
import './JobsPage.css'
import './PricingPage.css'

function parseFeatures(json: string | null): string[] {
  if (!json) return []
  try {
    const parsed = JSON.parse(json)
    return Array.isArray(parsed) ? parsed.filter((f): f is string => typeof f === 'string') : []
  } catch {
    return []
  }
}

/**
 * Batch 30 — multi-currency support, phase 1. This used to read a single
 * site-wide config.currency symbol for every plan; now that a plan can be
 * priced in USD or INR independently (jp_plans.currency), the symbol has
 * to be per-plan, not global — a page showing three plans where one is
 * priced in USD must show that one plan's price with $, not ₹.
 */
function currencySymbol(currency: string): string {
  return currency === 'USD' ? '$' : '₹'
}

export function PricingPage() {
  const { config, isAuthenticated } = useAuth()
  const [cycle, setCycle] = useState<'monthly' | 'yearly'>('monthly')
  const [purchasingPlanId, setPurchasingPlanId] = useState<number | null>(null)
  const toast = useToast()
  const queryClient = useQueryClient()

  const { data: plans, isLoading, isError } = useQuery({
    queryKey: ['public-plans'],
    queryFn: getPublicPlans,
  })

  /**
   * Depth pass (Naukri/JobHai benchmarking, batch 2) — this page had zero
   * evidence of platform activity, unlike HomePage which already surfaces
   * these same market_insights() stats (see HomePage.tsx). Reused here as a
   * real trust signal rather than inventing "10,000+ companies trust us"
   * marketing copy with no backing data.
   */
  const { data: insights } = useQuery({ queryKey: ['market-insights'], queryFn: getMarketInsights })

  const isRecruiter = isAuthenticated && (config?.role === 'jp_recruiter' || config?.role === 'jp_team_manager')

  /**
   * Root-cause fix (batch 10 — see class-jp-payments.php's
   * do_create_order() docblock, class-jp-api.php's new /payments/*
   * routes, and app/src/features/payments/api.ts). This is the first and
   * only place in the whole SPA that ever calls createOrder() — before
   * this batch there was no way for an authenticated recruiter to start
   * a purchase at all, regardless of how correct the backend was.
   *
   * Batch 12 — Stripe gateway abstraction. createOrder() now returns a
   * discriminated union (see payments/api.ts's CreateOrderResult) — the
   * `order` result itself says which gateway is active, so this branches
   * on that rather than on config.payment_gateway (avoids a window where
   * the two could disagree, e.g. a setting changed between page load and
   * click). Stripe's own flow is a full-page redirect to its hosted
   * Checkout — there's no modal/onDismiss/onFailure to wire up client-side
   * the way Razorpay's checkout.js has; verification happens when Stripe
   * redirects back to /recruiter/billing (see that page's handling of
   * ?stripe_session_id=).
   */
  async function handleUpgrade(planId: number, planName: string) {
    setPurchasingPlanId(planId)
    try {
      const order = await createOrder(planId, cycle)

      if (order.gateway === 'stripe') {
        window.location.assign(order.checkout_url)
        return
      }

      await openRazorpayCheckout({
        order,
        siteName: config?.site_name ?? 'JP Core',
        planName,
        billing: cycle,
        userName: config?.user_name,
        userEmail: config?.user_email,
        onSuccess: (result) => {
          toast.success(result.message || 'Payment successful — your plan is now active.')
          queryClient.invalidateQueries({ queryKey: ['recruiter-subscription'] })
          queryClient.invalidateQueries({ queryKey: ['recruiter-invoices'] })
          setPurchasingPlanId(null)
          window.location.assign('/recruiter/billing')
        },
        onFailure: (message) => {
          toast.error(message)
          setPurchasingPlanId(null)
        },
        onDismiss: () => {
          setPurchasingPlanId(null)
        },
      })
    } catch (e) {
      toast.error(e instanceof Error ? e.message : 'Could not start checkout. Please try again.')
      setPurchasingPlanId(null)
    }
  }

  return (
    <div className="jp-public-page-shell">
      <PublicPageHero
        eyebrow="For employers"
        title="Plans for recruiters"
        subtitle="Pick a plan that fits how much you're hiring. Upgrade, downgrade, or cancel anytime."
        tone="dark"
        stats={
          insights ? (
            <>
              <StatCard label="Companies hiring" value={insights.stats.companies_hiring} />
              <StatCard label="Active jobs" value={insights.stats.active_jobs} tone="primary" />
              <StatCard label="New today" value={insights.stats.new_jobs_today} tone="success" />
            </>
          ) : undefined
        }
      />
      <div className="jp-public-page jp-public-page--raised jp-pricing-page">
      {/*
        Root-cause fix (batch 36 — Tier C interaction polish): a two-way
        toggle with no aria-pressed gave screen reader users no indication
        of which billing cycle was currently selected.
      */}
      <div className="jp-pricing-toggle" role="group" aria-label="Billing cycle">
        <button
          type="button"
          className={cycle === 'monthly' ? 'jp-pricing-toggle-active' : ''}
          aria-pressed={cycle === 'monthly'}
          onClick={() => setCycle('monthly')}
        >
          Monthly
        </button>
        <button
          type="button"
          className={cycle === 'yearly' ? 'jp-pricing-toggle-active' : ''}
          aria-pressed={cycle === 'yearly'}
          onClick={() => setCycle('yearly')}
        >
          Yearly
        </button>
      </div>

      {isLoading && (
        <div className="jp-pricing-grid">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} height={320} width="100%" />
          ))}
        </div>
      )}

      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load plans. Please try again.
        </div>
      )}

      {!isLoading && plans && plans.length === 0 && (
        <EmptyState title="No plans are available right now" description="Check back soon, or contact us for custom enterprise pricing." />
      )}

      {!isLoading && plans && plans.length > 0 && (
        <div className="jp-pricing-grid">
          {plans.map((plan) => {
            const price = cycle === 'monthly' ? plan.price_monthly : plan.price_yearly
            const features = parseFeatures(plan.features_json)
            return (
              <Card key={plan.id} className="jp-pricing-card">
                <CardBody>
                  <p className="jp-job-title" style={{ fontSize: 20 }}>
                    {plan.name}
                  </p>
                  {plan.description && <p className="jp-job-company">{plan.description}</p>}
                  <p className="jp-pricing-price">
                    {currencySymbol(plan.currency)}
                    {price.toLocaleString()}
                    <span className="jp-job-company">/{cycle === 'monthly' ? 'mo' : 'yr'}</span>
                  </p>

                  <ul className="jp-pricing-features">
                    <li>{plan.job_posts} job posts</li>
                    <li>{plan.featured_jobs} featured jobs</li>
                    <li>{plan.resume_views} resume views</li>
                    <li>{plan.candidate_msgs} candidate messages</li>
                    <li>
                      {plan.team_seats} team seat{plan.team_seats === 1 ? '' : 's'}
                    </li>
                    {features.map((f, i) => (
                      <li key={i}>{f}</li>
                    ))}
                  </ul>

                  {isRecruiter ? (
                    <>
                      <Button
                        fullWidth
                        loading={purchasingPlanId === plan.id}
                        disabled={purchasingPlanId !== null && purchasingPlanId !== plan.id}
                        onClick={() => handleUpgrade(plan.id, plan.name)}
                      >
                        Upgrade to {plan.name}
                      </Button>
                      <Button
                        fullWidth
                        variant="ghost"
                        style={{ marginTop: 8 }}
                        onClick={() => window.location.assign('/recruiter/billing')}
                      >
                        Manage subscription
                      </Button>
                    </>
                  ) : (
                    <Button fullWidth onClick={() => window.location.assign('/register?role=recruiter')}>
                      Get started
                    </Button>
                  )}
                </CardBody>
              </Card>
            )
          })}
        </div>
      )}

      {/*
        Depth pass (Naukri/JobHai benchmarking, batch 2) — root-cause fix:
        the cards above already carry every real limit (job_posts/
        featured_jobs/resume_views/candidate_msgs/team_seats) and free-text
        feature per plan, but scanning 3+ cards top-to-bottom to compare one
        limit across plans is exactly the friction a side-by-side comparison
        table exists to remove — the same depth pattern reference job boards
        use on their own pricing pages. Every cell below is the same real
        plan data already fetched for the cards, just re-laid-out; nothing
        here is new or fabricated data.
      */}
      {!isLoading && plans && plans.length > 1 && (
        <SectionCard title="Compare plans" className="jp-pricing-compare">
          <div className="jp-pricing-compare__scroll">
            <table className="jp-pricing-compare__table">
              <thead>
                <tr>
                  <th scope="col">Plan</th>
                  {plans.map((plan) => (
                    <th key={plan.id} scope="col">
                      {plan.name}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                <tr>
                  <th scope="row">Price</th>
                  {plans.map((plan) => (
                    <td key={plan.id}>
                      {currencySymbol(plan.currency)}
                      {(cycle === 'monthly' ? plan.price_monthly : plan.price_yearly).toLocaleString()}/
                      {cycle === 'monthly' ? 'mo' : 'yr'}
                    </td>
                  ))}
                </tr>
                <tr>
                  <th scope="row">Job posts</th>
                  {plans.map((plan) => (
                    <td key={plan.id}>{plan.job_posts}</td>
                  ))}
                </tr>
                <tr>
                  <th scope="row">Featured jobs</th>
                  {plans.map((plan) => (
                    <td key={plan.id}>{plan.featured_jobs}</td>
                  ))}
                </tr>
                <tr>
                  <th scope="row">Resume views</th>
                  {plans.map((plan) => (
                    <td key={plan.id}>{plan.resume_views}</td>
                  ))}
                </tr>
                <tr>
                  <th scope="row">Candidate messages</th>
                  {plans.map((plan) => (
                    <td key={plan.id}>{plan.candidate_msgs}</td>
                  ))}
                </tr>
                <tr>
                  <th scope="row">Team seats</th>
                  {plans.map((plan) => (
                    <td key={plan.id}>{plan.team_seats}</td>
                  ))}
                </tr>
                <tr>
                  <th scope="row">Additional features</th>
                  {plans.map((plan) => {
                    const features = parseFeatures(plan.features_json)
                    return (
                      <td key={plan.id}>
                        {features.length > 0 ? (
                          <ul className="jp-pricing-compare__feature-list">
                            {features.map((f, i) => (
                              <li key={i}>{f}</li>
                            ))}
                          </ul>
                        ) : (
                          '—'
                        )}
                      </td>
                    )
                  })}
                </tr>
              </tbody>
            </table>
          </div>
        </SectionCard>
      )}

      {!isRecruiter && (
        <p className="jp-job-company" style={{ marginTop: 16 }}>
          Looking for a job instead? <a href="/jobs">Browse open roles</a>.{' '}
          {!isAuthenticated && (
            <>
              Already have a recruiter account? <a href="/login">Sign in</a>.
            </>
          )}
        </p>
      )}
      </div>
    </div>
  )
}
