import { useState } from 'react'
import { Link } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { EVENT_FORMATS, EVENT_TYPES, listEvents, type EventWhen } from '@/features/events/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Input } from '@/components/ui/Input'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { PageHeader } from '@/components/ui/PageHeader'
import { EmptyState } from '@/components/ui/EmptyState'
import { FilterBar } from '@/components/ui/FilterBar'
import { Tabs } from '@/components/ui/Tabs'
import './JobsPage.css'
import './EventsPage.css'

/**
 * Phase 3 redesign (Tier A, redesign-plan §EventsPage) — was upcoming-only
 * with no way to browse anything that already happened, a hand-rolled
 * inline-styled filter row instead of the shared FilterBar, and no search
 * despite the plan's cross-cutting note that every other list page in the
 * app has one. get_events() now supports a real `when` (upcoming/past —
 * both real status/starts_at comparisons, not a fabricated archive
 * concept) and a `q` title search. Also renders each event's banner_url,
 * which was already in every row's API response but never used anywhere
 * on this page.
 */
export function EventsPage() {
  const [when, setWhen] = useState<EventWhen>('upcoming')
  const [type, setType] = useState('')
  const [format, setFormat] = useState('')
  const [q, setQ] = useState('')
  const [page, setPage] = useState(1)

  const { data, isLoading, isError } = useQuery({
    queryKey: ['events', when, type, format, q, page],
    queryFn: () => listEvents({ when, type: type || undefined, format: format || undefined, q: q || undefined, page }),
    placeholderData: (prev) => prev,
  })

  function changeWhen(next: string) {
    setWhen(next as EventWhen)
    setPage(1)
  }

  return (
    <div className="jp-public-page">
      <PageHeader title="Events" subtitle="Webinars, workshops, and hiring events from companies on the platform." />

      <Tabs
        label="Event timeframe"
        activeKey={when}
        onChange={changeWhen}
        items={[
          { key: 'upcoming', label: 'Upcoming' },
          { key: 'past', label: 'Past' },
        ]}
      />

      <FilterBar
        className="jp-events__filter-bar"
        search={
          <Input
            label="Search events"
            value={q}
            onChange={(e) => {
              setQ(e.target.value)
              setPage(1)
            }}
          />
        }
        filters={
          <>
            <select
              className="jp-input"
              value={type}
              onChange={(e) => {
                setType(e.target.value)
                setPage(1)
              }}
              aria-label="Filter by event type"
            >
              <option value="">All types</option>
              {EVENT_TYPES.map((t) => (
                <option key={t} value={t}>
                  {t.replace('_', ' ')}
                </option>
              ))}
            </select>
            <select
              className="jp-input"
              value={format}
              onChange={(e) => {
                setFormat(e.target.value)
                setPage(1)
              }}
              aria-label="Filter by event format"
            >
              <option value="">All formats</option>
              {EVENT_FORMATS.map((f) => (
                <option key={f} value={f}>
                  {f}
                </option>
              ))}
            </select>
          </>
        }
      />

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 5 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <p className="jp-jobs-error" role="alert">
          Could not load events.
        </p>
      )}

      {!isLoading && data && data.events.length === 0 && (
        <EmptyState
          title={when === 'past' ? 'No past events' : 'No upcoming events'}
          description={
            when === 'past'
              ? 'Events move here automatically once they conclude.'
              : 'Check back soon, or try a different type/format filter.'
          }
        />
      )}

      {!isLoading && data && data.events.length > 0 && (
        <>
          <div className="jp-jobs-list">
            {data.events.map((evt) => (
              <Card key={evt.id} className={evt.banner_url ? 'jp-events__event-card' : undefined}>
                {evt.banner_url && <img src={evt.banner_url} alt="" className="jp-events__banner" />}
                <CardBody>
                  <div className="jp-job-row">
                    <div>
                      <p className="jp-job-title" style={{ fontSize: 14 }}>
                        <Link to={`/events/${evt.id}`}>{evt.title}</Link>
                      </p>
                      <p className="jp-job-company">
                        {evt.company_name ?? 'Independent'} · {evt.starts_at ? new Date(evt.starts_at).toLocaleString() : 'TBD'}
                      </p>
                    </div>
                    <div className="jp-job-badges">
                      <Badge variant="gray">{evt.event_type.replace('_', ' ')}</Badge>
                      <Badge variant="gray">{evt.format}</Badge>
                      {evt.is_free ? <Badge variant="success">Free</Badge> : <Badge variant="warning">₹{evt.price}</Badge>}
                      <span className="jp-job-company">
                        {evt.attendee_count}
                        {evt.seats_total > 0 ? `/${evt.seats_total}` : ''} attending
                      </span>
                    </div>
                  </div>
                </CardBody>
              </Card>
            ))}
          </div>

          <div className="jp-jobs-pagination">
            <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>
              Previous
            </Button>
            <span>
              Page {page} of {Math.max(1, Math.ceil(data.total / 20))}
            </span>
            <Button
              variant="outline"
              size="sm"
              disabled={page >= Math.ceil(data.total / 20)}
              onClick={() => setPage((p) => p + 1)}
            >
              Next
            </Button>
          </div>
        </>
      )}
    </div>
  )
}
