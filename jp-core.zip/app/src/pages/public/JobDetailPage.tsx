import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { applyToJob, getJob, getJobApplyStatus, getSimilarJobs, type JobRow } from '@/features/jobs/api'
import { getCompany } from '@/features/companies/api'
import { listResumes } from '@/features/resumes/api'
import { toggleSaveJob } from '@/features/savedJobs/api'
import { trackEvent } from '@/features/analytics/api'
import { useDocumentTitle } from '@/lib/useDocumentTitle'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'
import { PageHeader } from '@/components/ui/PageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { useAuth } from '@/lib/auth/AuthContext'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import './JobDetailPage.css'

/**
 * Root-cause fix (batch 24): this page rendered title/company/location/
 * badges/description/requirements/apply-form but never salary, experience
 * range, or required skills — despite job.salary_min/max/currency,
 * experience_min/max, and skills_json all being present on the same
 * JobRow the JobsPage.tsx list already reads (see features/jobs/api.ts).
 * The list page correctly gates salary on salary_visible; mirrored here so
 * a recruiter who hid the salary on a job doesn't have it leak on the
 * detail page candidates actually decide from.
 */
function formatSalary(min: number, max: number, currency: string): string | null {
  if (!min && !max) return null
  const fmt = (n: number) => n.toLocaleString()
  if (min && max) return `${currency} ${fmt(min)} – ${fmt(max)} / yr`
  return `${currency} ${fmt(min || max)} / yr`
}

function parseSkills(skillsJson: string | undefined): string[] {
  if (!skillsJson) return []
  try {
    const parsed = JSON.parse(skillsJson)
    return Array.isArray(parsed) ? parsed.filter((s): s is string => typeof s === 'string') : []
  } catch {
    return []
  }
}

interface ScreeningQuestion {
  question: string
  required: boolean
}

/**
 * Batch 35 — root-cause fix. job.screening_q (screening_q column) has been
 * writable end-to-end since JP_Jobs::create()/ajax_apply() were built, but
 * no SPA page ever read it: JobFormPage.tsx had no editor for setting
 * questions, and this page's apply flow never asked for them, so a
 * candidate's answers (if a recruiter had somehow set questions directly in
 * the DB) were never even collected. Same "backend exists, no SPA caller"
 * pattern already fixed repeatedly elsewhere in this engagement.
 */
function parseScreeningQuestions(screeningJson: string | undefined): ScreeningQuestion[] {
  if (!screeningJson) return []
  try {
    const parsed = JSON.parse(screeningJson)
    if (!Array.isArray(parsed)) return []
    return parsed
      .filter((q): q is { question?: unknown; required?: unknown } => typeof q === 'object' && q !== null)
      .map((q) => ({ question: typeof q.question === 'string' ? q.question : '', required: !!q.required }))
      .filter((q) => q.question.length > 0)
  } catch {
    return []
  }
}

type ApplyStep = 'details' | 'screening' | 'review' | 'done'

/**
 * Batch 32 — platform UI/UX depth pass. Purely presentational: turns
 * job.created_at (already fetched, already on the row) into "Posted 3 days
 * ago" instead of nothing, the same kind of "data exists in the API
 * response, UI never renders it" gap the job-portal engagement's batch 24
 * fixed for salary/experience/skills on this exact page.
 */
function formatPostedAgo(createdAt: string): string {
  const then = new Date(createdAt.replace(' ', 'T') + 'Z').getTime()
  if (Number.isNaN(then)) return ''
  const days = Math.floor((Date.now() - then) / 86400000)
  if (days <= 0) return 'Posted today'
  if (days === 1) return 'Posted yesterday'
  if (days < 30) return `Posted ${days} days ago`
  const months = Math.floor(days / 30)
  return `Posted ${months} month${months === 1 ? '' : 's'} ago`
}

/**
 * Batch 32. Related-jobs sidebar card — reused for the similar-jobs list.
 * Kept intentionally compact (this is a sidebar, not the main list) but
 * still a real Link + real badges, not a plain text line.
 */
function RelatedJobCard({ job }: { job: JobRow }) {
  return (
    <Link to={`/jobs/${job.id}`} className="jp-job-detail__related-card">
      <p className="jp-job-detail__related-title">{job.title}</p>
      <p className="jp-job-detail__related-meta">
        {job.company_name} · {job.location_city || job.location_state || 'Remote'}
      </p>
      <div className="jp-job-badges">
        <Badge variant="gray">{job.job_type}</Badge>
        {job.work_mode === 'remote' && <Badge variant="info">Remote</Badge>}
      </div>
    </Link>
  )
}

export function JobDetailPage() {
  const { id } = useParams<{ id: string }>()
  const jobId = Number(id)
  const { isAuthenticated, role, config } = useAuth()
  const toast = useToast()
  const queryClient = useQueryClient()
  const [coverLetter, setCoverLetter] = useState('')
  const [resumeId, setResumeId] = useState<number | ''>('')
  const [applied, setApplied] = useState(false)
  // Batch 35 — real multi-step application journey (was a single inline
  // form with no review/consent step, and no way to ask/collect a job's
  // screening questions at all). `answers` is keyed by question index so it
  // survives the candidate going back a step to edit their resume/cover
  // letter choice without losing screening answers already entered.
  const [applyStep, setApplyStep] = useState<ApplyStep>('details')
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [consentChecked, setConsentChecked] = useState(false)

  const canApply = !isAuthenticated || role === 'jp_job_seeker'

  const { data: job, isLoading, isError } = useQuery({
    queryKey: ['job', jobId],
    queryFn: () => getJob(jobId),
    enabled: Number.isFinite(jobId) && jobId > 0,
  })

  useDocumentTitle(job ? `${job.title} at ${job.company_name} · ${config?.site_name ?? 'JP Job Portal'}` : undefined)

  const { data: resumes, isError: resumesError } = useQuery({
    queryKey: ['resumes'],
    queryFn: listResumes,
    enabled: isAuthenticated && role === 'jp_job_seeker',
  })

  const { data: applyStatus } = useQuery({
    queryKey: ['job-apply-status', jobId],
    queryFn: () => getJobApplyStatus(jobId),
    enabled: isAuthenticated && role === 'jp_job_seeker' && Number.isFinite(jobId) && jobId > 0,
  })
  const alreadyApplied = applied || !!applyStatus?.has_applied

  /**
   * Batch 32 — root-cause fix: JP_Search::get_similar_jobs() / GET
   * /jobs/{id}/similar (features/jobs/api.ts's getSimilarJobs()) has been
   * fully built and reachable since before this batch, but had ZERO
   * callers anywhere in the SPA — the exact "backend exists, no SPA
   * caller" pattern already found and fixed repeatedly elsewhere in this
   * engagement (batches 10/13/16/20/21/23/29). This is the first and only
   * place in the app that calls it.
   */
  const { data: similarJobs } = useQuery({
    queryKey: ['job-similar', jobId],
    queryFn: () => getSimilarJobs(jobId),
    enabled: Number.isFinite(jobId) && jobId > 0,
  })

  /**
   * Batch 32 — root-cause fix: GET /companies/{id} (getCompany()) already
   * exists and is used by CompanyDetailPage, but JobDetailPage — despite
   * showing job.company_name as plain text — never fetched the company
   * record itself, so industry/size/headquarters/rating/verified/logo were
   * all available data this page simply never asked for. Enabled only once
   * the job has loaded (needs job.company_id).
   */
  const { data: company } = useQuery({
    queryKey: ['company', job?.company_id],
    queryFn: () => getCompany(job!.company_id),
    enabled: !!job?.company_id,
  })

  useEffect(() => {
    if (Number.isFinite(jobId) && jobId > 0) trackEvent('job_view', jobId)
  }, [jobId])

  const screeningQuestions = parseScreeningQuestions(job?.screening_q)

  const applyMutation = useMutation({
    mutationFn: () =>
      applyToJob(jobId, {
        resume_id: Number(resumeId),
        cover_letter: coverLetter,
        // Positional, matching class-jp-jobs.php's screening_q storage order
        // — an unanswered optional question sends '' rather than being
        // omitted, keeping the answers array aligned with the questions
        // array on both sides.
        answers: screeningQuestions.map((_, i) => answers[i] ?? ''),
      }),
    onSuccess: () => {
      toast.success('Application submitted!')
      setApplied(true)
      setApplyStep('done')
      trackEvent('job_apply', jobId)
      queryClient.invalidateQueries({ queryKey: ['job', jobId] })
    },
    onError: (e) => {
      toast.error(e instanceof ApiError ? e.message : 'Could not submit your application.')
    },
  })

  const canProceedFromDetails = !!resumeId
  const missingRequiredAnswers = screeningQuestions.some((q, i) => q.required && !(answers[i] ?? '').trim())

  const saveMutation = useMutation({
    mutationFn: () => toggleSaveJob(jobId),
    onSuccess: (result) => toast.success(result.message),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update saved jobs.'),
  })

  if (isLoading) {
    return (
      <div className="jp-job-detail">
        <Skeleton height={16} width="30%" />
        <div style={{ height: 12 }} />
        <Skeleton height={32} width="60%" />
        <div style={{ height: 8 }} />
        <Skeleton height={16} width="35%" />
        <div style={{ height: 24 }} />
        <div className="jp-job-detail__grid">
          <div className="jp-job-detail__main">
            <Skeleton height={160} width="100%" />
            <div style={{ height: 16 }} />
            <Skeleton height={220} width="100%" />
          </div>
          <div className="jp-job-detail__side">
            <Skeleton height={180} width="100%" />
            <div style={{ height: 16 }} />
            <Skeleton height={140} width="100%" />
          </div>
        </div>
      </div>
    )
  }

  if (isError || !job) {
    return (
      <div className="jp-job-detail">
        <EmptyState
          title="This job could not be found"
          description="It may have been closed, filled, or removed by the recruiter."
          action={
            <Link to="/jobs">
              <Button variant="accent">Browse open jobs</Button>
            </Link>
          }
        />
      </div>
    )
  }

  const salary = job.salary_visible === 1 ? formatSalary(job.salary_min, job.salary_max, job.salary_currency) : null
  const hasExperience = job.experience_min > 0 || job.experience_max > 0
  const skills = parseSkills(job.skills_json)

  return (
    <div className="jp-job-detail">
      <PageHeader
        breadcrumbs={[
          { label: 'Jobs', to: '/jobs' },
          { label: job.company_name, to: `/companies/${job.company_id}` },
          { label: job.title },
        ]}
        title={job.title}
        subtitle={
          <>
            {job.company_name} · {job.location_city || job.location_state || 'Location not specified'}
            {job.created_at && <> · {formatPostedAgo(job.created_at)}</>}
          </>
        }
        badges={
          <>
            {job.is_featured === 1 && <Badge variant="accent">Featured</Badge>}
            {job.is_urgent === 1 && <Badge variant="warning">Urgent hiring</Badge>}
            {job.work_mode === 'remote' && <Badge variant="info">Remote</Badge>}
            <Badge variant="gray">{job.job_type}</Badge>
          </>
        }
        actions={
          isAuthenticated &&
          role === 'jp_job_seeker' && (
            <Button variant="outline" size="sm" loading={saveMutation.isPending} onClick={() => saveMutation.mutate()}>
              Save job
            </Button>
          )
        }
      />

      <div className="jp-job-detail__grid">
        <div className="jp-job-detail__main">
          {(salary || hasExperience || skills.length > 0 || job.applications_cnt > 0) && (
            <SectionCard title="Job overview">
              <ul className="jp-job-detail__facts">
                {salary && <li>💰 {salary}</li>}
                {hasExperience && (
                  <li>
                    🎯{' '}
                    {job.experience_min > 0 && job.experience_max > 0
                      ? `${job.experience_min}–${job.experience_max} years experience`
                      : `${job.experience_min || job.experience_max}+ years experience`}
                  </li>
                )}
                <li>📍 {job.location_city || job.location_state || 'Location not specified'} · {job.work_mode}</li>
                {job.applications_cnt > 0 && <li>👥 {job.applications_cnt} applicant{job.applications_cnt === 1 ? '' : 's'} so far</li>}
              </ul>
              {skills.length > 0 && (
                <div className="jp-job-badges" style={{ marginTop: 12 }}>
                  {skills.map((skill) => (
                    <Badge key={skill} variant="gray">
                      {skill}
                    </Badge>
                  ))}
                </div>
              )}
            </SectionCard>
          )}

          <SectionCard title="Description">
            <p className="jp-job-detail__text">{job.description}</p>
            {job.requirements && (
              <>
                <h3 className="jp-job-detail__subheading">Requirements</h3>
                <p className="jp-job-detail__text">{job.requirements}</p>
              </>
            )}
          </SectionCard>

          {canApply && (
            <SectionCard title="Apply for this job" className="jp-job-detail__apply">
              {alreadyApplied ? (
                <p>
                  Your application has been submitted
                  {applyStatus?.stage ? ` — current status: ${applyStatus.stage.replace('_', ' ')}.` : '.'}
                </p>
              ) : isAuthenticated ? (
                <>
                  {/* Batch 35 — step indicator. Screening step only appears
                      when the job actually has questions, so a job with none
                      still shows a short, honest 2-step flow rather than a
                      hollow middle step. */}
                  {applyStep !== 'done' && (
                    <ol className="jp-apply-steps">
                      <li className={applyStep === 'details' ? 'is-active' : 'is-done'}>Resume &amp; cover note</li>
                      {screeningQuestions.length > 0 && (
                        <li
                          className={
                            applyStep === 'screening' ? 'is-active' : applyStep === 'review' ? 'is-done' : ''
                          }
                        >
                          Screening questions
                        </li>
                      )}
                      <li className={applyStep === 'review' ? 'is-active' : ''}>Review &amp; submit</li>
                    </ol>
                  )}

                  {applyStep === 'details' && (
                    <>
                      {resumes && resumes.length > 0 ? (
                        <div className="jp-form-group">
                          <label className="jp-label" htmlFor="resume-select">
                            Choose a resume
                          </label>
                          <select
                            id="resume-select"
                            className="jp-input"
                            value={resumeId}
                            onChange={(e) => setResumeId(e.target.value ? Number(e.target.value) : '')}
                          >
                            <option value="">Select a resume…</option>
                            {resumes.map((r) => (
                              <option key={r.id} value={r.id}>
                                {r.file_name}
                                {r.is_primary === 1 ? ' (primary)' : ''}
                              </option>
                            ))}
                          </select>
                        </div>
                      ) : resumesError ? (
                        // Root-cause fix: this branch used to be unreachable on
                        // fetch failure — resumes stays undefined forever once
                        // React Query gives up retrying, so the chain fell through
                        // to the final <Skeleton> below and stayed there
                        // permanently, with the Submit button stuck disabled
                        // (resumeId can never be set) and no indication why.
                        <p className="jp-jobs-error" role="alert">
                          Could not load your resumes. Please try again.
                        </p>
                      ) : resumes ? (
                        <p>
                          You need a resume on file before applying. <Link to="/dashboard/resumes">Upload one</Link>.
                        </p>
                      ) : (
                        <Skeleton height={38} width="100%" />
                      )}

                      <div className="jp-form-group">
                        <label className="jp-label" htmlFor="cover-letter">
                          Cover note (optional)
                        </label>
                        <textarea
                          id="cover-letter"
                          className="jp-textarea"
                          placeholder="Add a short cover note explaining why you're a good fit"
                          value={coverLetter}
                          onChange={(e) => setCoverLetter(e.target.value)}
                          rows={4}
                        />
                      </div>
                      <Button
                        variant="accent"
                        disabled={!canProceedFromDetails}
                        onClick={() => setApplyStep(screeningQuestions.length > 0 ? 'screening' : 'review')}
                      >
                        {screeningQuestions.length > 0 ? 'Continue to screening questions' : 'Review application'}
                      </Button>
                    </>
                  )}

                  {applyStep === 'screening' && (
                    <>
                      <p className="jp-form-hint">
                        This employer asks a few questions before reviewing applications.
                        {screeningQuestions.some((q) => q.required) && ' Questions marked * are required.'}
                      </p>
                      {screeningQuestions.map((q, i) => (
                        <div className="jp-form-group" key={i}>
                          <label className="jp-label" htmlFor={`screening-${i}`}>
                            {q.question}
                            {q.required && ' *'}
                          </label>
                          <textarea
                            id={`screening-${i}`}
                            className="jp-textarea"
                            rows={2}
                            value={answers[i] ?? ''}
                            onChange={(e) => setAnswers((prev) => ({ ...prev, [i]: e.target.value }))}
                          />
                        </div>
                      ))}
                      <div className="jp-apply-step-actions">
                        <Button variant="outline" onClick={() => setApplyStep('details')}>
                          Back
                        </Button>
                        <Button
                          variant="accent"
                          disabled={missingRequiredAnswers}
                          onClick={() => setApplyStep('review')}
                        >
                          Review application
                        </Button>
                      </div>
                    </>
                  )}

                  {applyStep === 'review' && (
                    <>
                      <div className="jp-apply-review">
                        <div className="jp-apply-review__row">
                          <span className="jp-apply-review__label">Resume</span>
                          <span>{resumes?.find((r) => r.id === resumeId)?.file_name ?? '—'}</span>
                        </div>
                        <div className="jp-apply-review__row">
                          <span className="jp-apply-review__label">Cover note</span>
                          <span>{coverLetter.trim() || 'Not provided'}</span>
                        </div>
                        {screeningQuestions.map((q, i) => (
                          <div className="jp-apply-review__row" key={i}>
                            <span className="jp-apply-review__label">{q.question}</span>
                            <span>{(answers[i] ?? '').trim() || (q.required ? '⚠ Missing' : 'Not answered')}</span>
                          </div>
                        ))}
                      </div>
                      <label className="jp-checkbox" style={{ marginTop: 12 }}>
                        <input
                          type="checkbox"
                          checked={consentChecked}
                          onChange={(e) => setConsentChecked(e.target.checked)}
                        />
                        I confirm the information above is accurate and consent to sharing it with{' '}
                        {job.company_name} for this application.
                      </label>
                      <div className="jp-apply-step-actions">
                        <Button
                          variant="outline"
                          onClick={() => setApplyStep(screeningQuestions.length > 0 ? 'screening' : 'details')}
                        >
                          Back
                        </Button>
                        <Button
                          variant="accent"
                          loading={applyMutation.isPending}
                          disabled={!canProceedFromDetails || missingRequiredAnswers || !consentChecked}
                          onClick={() => applyMutation.mutate()}
                        >
                          Submit application
                        </Button>
                      </div>
                    </>
                  )}

                  {applyStep === 'done' && (
                    <div className="jp-apply-confirmation">
                      <p className="jp-apply-confirmation__title">✓ Application submitted</p>
                      <p>
                        {job.company_name} has received your application for {job.title}. You can track its status
                        from your applications dashboard.
                      </p>
                      <Link to="/dashboard/applications">
                        <Button variant="outline" size="sm">
                          View my applications
                        </Button>
                      </Link>
                    </div>
                  )}
                </>
              ) : (
                <Link to="/login" state={{ from: { pathname: `/jobs/${jobId}` } }}>
                  <Button variant="accent">Sign in to apply</Button>
                </Link>
              )}
            </SectionCard>
          )}
        </div>

        <div className="jp-job-detail__side">
          <SectionCard title="About the company">
            <div className="jp-job-detail__company">
              {company?.logo_url ? (
                <img src={company.logo_url} alt="" className="jp-job-detail__company-logo" />
              ) : (
                <div className="jp-job-detail__company-logo jp-job-detail__company-logo--placeholder">
                  {job.company_name.charAt(0).toUpperCase()}
                </div>
              )}
              <div>
                <p className="jp-job-detail__company-name">
                  {job.company_name}
                  {company?.is_verified === 1 && (
                    <Badge variant="success" className="jp-job-detail__verified-badge">
                      Verified
                    </Badge>
                  )}
                </p>
                {company && company.rating_avg > 0 && (
                  <p className="jp-job-detail__company-rating">
                    ⭐ {company.rating_avg.toFixed(1)} ({company.reviews_count} review{company.reviews_count === 1 ? '' : 's'})
                  </p>
                )}
              </div>
            </div>
            {company && (
              <ul className="jp-job-detail__company-facts">
                {company.industry && <li>{company.industry}</li>}
                {company.size_range && <li>{company.size_range} employees</li>}
                {company.headquarters && <li>{company.headquarters}</li>}
                {company.jobs_count > 0 && <li>{company.jobs_count} open job{company.jobs_count === 1 ? '' : 's'}</li>}
              </ul>
            )}
            <Link to={`/companies/${job.company_id}`}>
              <Button variant="outline" size="sm" fullWidth>
                View company profile
              </Button>
            </Link>
          </SectionCard>

          <SectionCard title="Share this job">
            <div className="jp-job-detail__share-row">
              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  const url = window.location.href
                  const shareData = { title: `${job.title} at ${job.company_name}`, url }
                  // Native share sheet where available (mobile browsers,
                  // most desktop browsers over HTTPS) — falls back to
                  // copy-to-clipboard everywhere else, same two-tier
                  // pattern every major job board uses for this control.
                  if (navigator.share) {
                    try {
                      await navigator.share(shareData)
                    } catch {
                      // AbortError on user-cancelled share — not a failure, no toast.
                    }
                    return
                  }
                  try {
                    await navigator.clipboard.writeText(url)
                    toast.success('Job link copied to clipboard.')
                  } catch {
                    toast.error('Could not copy the link. Please copy it from your address bar.')
                  }
                }}
              >
                Share
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={async () => {
                  try {
                    await navigator.clipboard.writeText(window.location.href)
                    toast.success('Job link copied to clipboard.')
                  } catch {
                    toast.error('Could not copy the link. Please copy it from your address bar.')
                  }
                }}
              >
                Copy link
              </Button>
            </div>
          </SectionCard>

          {similarJobs && similarJobs.length > 0 && (
            <SectionCard title="Similar jobs">
              <div className="jp-job-detail__related-list">
                {similarJobs.slice(0, 5).map((sj) => (
                  <RelatedJobCard key={sj.id} job={sj} />
                ))}
              </div>
            </SectionCard>
          )}
        </div>
      </div>
    </div>
  )
}
