import { useState, type FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { listJobs } from '@/features/jobs/api'
import { getMarketInsights } from '@/features/market/api'
import { JobCard } from '@/components/jobs/JobCard'
import { JobSearchPanel } from '@/components/jobs/JobSearchPanel'
import { Button } from '@/components/ui/Button'
import { StatCard } from '@/components/ui/StatCard'
import { SectionBand } from '@/components/ui/SectionBand'
import { Skeleton } from '@/components/ui/Skeleton'
import { EmptyState } from '@/components/ui/EmptyState'
import { useRevealOnScroll } from '@/hooks/useRevealOnScroll'
import { formatJobType } from '@/lib/jobs/format'
import './HomePage.css'

const POPULAR_SEARCHES = ['Software Engineer', 'Remote', 'Product Manager', 'Data Analyst', 'Internship']

export function HomePage() {
  const navigate = useNavigate()
  const [q, setQ] = useState('')
  const [location, setLocation] = useState('')
  const latestReveal = useRevealOnScroll()
  const companiesReveal = useRevealOnScroll()
  const journeyReveal = useRevealOnScroll()

  const { data: insights } = useQuery({ queryKey: ['market-insights'], queryFn: getMarketInsights })
  const { data: latestJobs, isLoading: jobsLoading, isError: jobsError } = useQuery({
    queryKey: ['home-latest-jobs'],
    queryFn: () => listJobs({ order_by: 'created_at', order: 'DESC', per_page: 6 }),
  })

  function onSearch(e: FormEvent) {
    e.preventDefault()
    const params = new URLSearchParams()
    if (q.trim()) params.set('q', q.trim())
    if (location.trim()) params.set('location', location.trim())
    navigate(`/jobs${params.toString() ? `?${params.toString()}` : ''}`)
  }

  return (
    <div className="jp-home">
      <section className="jp-home__hero">
        <div className="jp-home__hero-bg" aria-hidden="true" />
        <div className="jp-home__hero-inner">
          <p className="jp-home__eyebrow">Live job marketplace</p>
          <h1>
            Discover roles worth applying for — <span className="jp-home__hero-accent">today</span>
          </h1>
          <p className="jp-home__hero-lead">
            Search verified openings, explore trending skills, and track every application from one active workspace.
          </p>

          <JobSearchPanel
            q={q}
            location={location}
            onQChange={setQ}
            onLocationChange={setLocation}
            onSubmit={onSearch}
            popularSearches={POPULAR_SEARCHES}
            hint="Real-time counts below reflect jobs currently open on the platform."
          />

          {insights && (
            <div className="jp-home__stats">
              <StatCard label="Active jobs" value={insights.stats.active_jobs} tone="primary" />
              <StatCard label="Companies hiring" value={insights.stats.companies_hiring} />
              <StatCard label="New today" value={insights.stats.new_jobs_today} tone="success" />
              <StatCard label="Remote roles" value={insights.stats.remote_jobs} />
            </div>
          )}
        </div>
      </section>

      <div className={latestReveal.className} ref={latestReveal.ref}>
      <SectionBand
        title="Latest opportunities"
        subtitle="Fresh roles added by employers — updated as new posts go live."
        action={
          <Link to="/jobs" className="jp-link-arrow">
            See all jobs →
          </Link>
        }
        tone="muted"
      >
        {jobsLoading && (
          <div className="jp-home__job-grid">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} height={160} width="100%" />
            ))}
          </div>
        )}
        {!jobsLoading && latestJobs && latestJobs.jobs.length > 0 && (
          <div className="jp-home__job-grid">
            {latestJobs.jobs.map((job) => (
              <JobCard key={job.id} job={job} variant="grid" />
            ))}
          </div>
        )}
        {!jobsLoading && latestJobs && latestJobs.jobs.length === 0 && (
          <EmptyState
            title="No jobs posted yet"
            description="Be the first to explore when employers publish — or browse companies hiring on the platform."
            action={
              <Link to="/companies">
                <Button variant="primary">Browse companies</Button>
              </Link>
            }
          />
        )}
        {!jobsLoading && jobsError && (
          <p className="jp-jobs-error" role="alert">
            Could not load the latest jobs right now.
          </p>
        )}
      </SectionBand>
      </div>

      {insights && insights.trending_skills.length > 0 && (
        <SectionBand title="Trending skills" subtitle="Roles receiving attention right now — tap to search by skill.">
          <div className="jp-home__skill-rail">
            {insights.trending_skills.slice(0, 14).map((skill) => (
              <Link key={skill.name} to={`/jobs?skills=${encodeURIComponent(skill.name)}`} className="jp-home__skill-chip">
                <span className="jp-home__skill-name">{skill.name}</span>
                {skill.demand > 0 && <span className="jp-home__skill-count">{skill.demand} mentions</span>}
              </Link>
            ))}
          </div>
        </SectionBand>
      )}

      {insights && insights.top_hiring.length > 0 && (
        <div className={companiesReveal.className} ref={companiesReveal.ref}>
        <SectionBand title="Featured companies hiring" tone="primary">
          <div className="jp-home__company-grid">
            {insights.top_hiring.slice(0, 8).map((company) => (
              <Link
                key={company.name}
                to={`/jobs?q=${encodeURIComponent(company.name)}`}
                className="jp-home__company-tile"
              >
                {company.logo_url ? (
                  <img src={company.logo_url} alt="" className="jp-home__company-logo" loading="lazy" />
                ) : (
                  <div className="jp-home__company-logo jp-home__company-logo--placeholder" aria-hidden="true">
                    {company.name[0]}
                  </div>
                )}
                <span className="jp-home__company-name">{company.name}</span>
                <span className="jp-home__company-jobs">{company.jobs} open roles</span>
              </Link>
            ))}
          </div>
        </SectionBand>
        </div>
      )}

      {insights && insights.job_type_breakdown.length > 0 && (
        <SectionBand title="Browse by work type" subtitle="From full-time careers to flexible contract work.">
          <div className="jp-home__category-grid">
            {insights.job_type_breakdown.map((row) => (
              <Link
                key={row.job_type}
                to={`/jobs?job_type=${encodeURIComponent(row.job_type)}`}
                className="jp-home__category-tile"
              >
                <span className="jp-home__category-name">{formatJobType(row.job_type)}</span>
                <span className="jp-home__category-count">{row.jobs} open roles</span>
              </Link>
            ))}
          </div>
        </SectionBand>
      )}

      {insights && insights.top_locations.length > 0 && (
        <SectionBand title="Jobs near top cities" tone="accent">
          <div className="jp-home__location-grid">
            {insights.top_locations.map((row) => (
              <Link
                key={row.location_city}
                to={`/jobs?location=${encodeURIComponent(row.location_city)}`}
                className="jp-home__location-tile"
              >
                <span className="jp-home__location-city">{row.location_city}</span>
                <span className="jp-home__location-count">{row.jobs} roles</span>
              </Link>
            ))}
          </div>
        </SectionBand>
      )}

      <section className={`jp-home__journey ${journeyReveal.className}`} ref={journeyReveal.ref}>
        <div className="jp-home__journey-inner">
          <h2>Your hiring journey</h2>
          <p>Discover → Explore → Apply → Track → Get hired</p>
          <ol className="jp-home__journey-steps">
            <li>
              <strong>Discover</strong>
              <span>Search with filters that feel like a product, not a form.</span>
            </li>
            <li>
              <strong>Explore</strong>
              <span>Compare salary, mode, and company signals on rich job cards.</span>
            </li>
            <li>
              <strong>Apply</strong>
              <span>One profile, one resume library — apply without retyping.</span>
            </li>
            <li>
              <strong>Track</strong>
              <span>Dashboard updates for applications, interviews, and offers.</span>
            </li>
            <li>
              <strong>Get hired</strong>
              <span>Message recruiters and close the loop on-platform.</span>
            </li>
          </ol>
        </div>
      </section>

      <section className="jp-home__cta">
        <div className="jp-home__cta-card">
          <h3>Building your team?</h3>
          <p>Post jobs, source candidates, and run interviews from a modern recruiter workspace.</p>
          <div className="jp-home__cta-actions">
            <Link to="/pricing">
              <Button variant="accent">View employer plans</Button>
            </Link>
            <Link to="/register">
              <Button variant="outline">Create employer account</Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}
