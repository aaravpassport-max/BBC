import { useMemo } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { listCompanies, type CompanySort } from '@/features/companies/api'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Badge } from '@/components/ui/Badge'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { PublicPageHero } from '@/components/layout/PublicPageHero'
import { EmptyState } from '@/components/ui/EmptyState'
import { FilterBar, FilterChip } from '@/components/ui/FilterBar'
import '../public/JobsPage.css'
import './CompaniesPage.css'

const PER_PAGE = 20

const SORT_LABELS: Record<CompanySort, string> = {
  jobs: 'Most open jobs',
  rating: 'Highest rated',
  name: 'Name (A–Z)',
}

/**
 * Phase 3 redesign (Tier A, redesign-plan §CompaniesPage) — was keyword
 * search only, despite jp_companies already carrying real industry/
 * is_verified/rating_avg columns nothing here filtered or sorted by.
 * get_companies() now supports a real industry filter (its dropdown driven
 * by the actual distinct industries in use, returned alongside the
 * results — not a hardcoded list that could drift from the data), a
 * verified-only toggle, and a sort (jobs/rating/name), all against real
 * columns. FilterBar/FilterChip reused from Phase 2 for consistency with
 * every other list page in the app.
 */
export function CompaniesPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const page = Number(searchParams.get('page') ?? '1')
  const industry = searchParams.get('industry') ?? ''
  const verifiedOnly = searchParams.get('verified_only') === '1'
  const sort = (searchParams.get('sort') as CompanySort | null) ?? 'jobs'

  const params = useMemo(
    () => ({
      q: searchParams.get('q') ?? undefined,
      industry: industry || undefined,
      verified_only: verifiedOnly,
      sort,
      page,
      per_page: PER_PAGE,
    }),
    [searchParams, industry, verifiedOnly, sort, page],
  )

  const { data, isLoading, isError } = useQuery({
    queryKey: ['companies', params],
    queryFn: () => listCompanies(params),
    placeholderData: (prev) => prev,
  })

  function updateParam(key: string, value: string | null) {
    const next = new URLSearchParams(searchParams)
    if (value) next.set(key, value)
    else next.delete(key)
    next.delete('page')
    setSearchParams(next)
  }

  function goToPage(nextPage: number) {
    const next = new URLSearchParams(searchParams)
    next.set('page', String(nextPage))
    setSearchParams(next)
  }

  const activeChips: Array<{ key: string; label: string }> = []
  if (industry) activeChips.push({ key: 'industry', label: `Industry: ${industry}` })
  if (verifiedOnly) activeChips.push({ key: 'verified_only', label: 'Verified only' })

  return (
    <div className="jp-public-page-shell">
      <PublicPageHero
        eyebrow="Employers"
        tone="primary"
        title={data ? `${data.total.toLocaleString()} companies hiring` : 'Explore companies'}
        subtitle="Verified profiles, open role counts, and ratings — discover teams worth applying to."
      />
      <div className="jp-public-page jp-public-page--raised">
      <FilterBar
        search={<Input label="Search companies" value={searchParams.get('q') ?? ''} onChange={(e) => updateParam('q', e.target.value || null)} />}
        filters={
          <>
            <select
              className="jp-input"
              value={industry}
              onChange={(e) => updateParam('industry', e.target.value || null)}
              aria-label="Filter by industry"
            >
              <option value="">All industries</option>
              {data?.industries.map((ind) => (
                <option key={ind} value={ind}>
                  {ind}
                </option>
              ))}
            </select>
            <label className="jp-companies-page__verified-toggle">
              <input
                type="checkbox"
                checked={verifiedOnly}
                onChange={(e) => updateParam('verified_only', e.target.checked ? '1' : null)}
              />
              Verified only
            </label>
          </>
        }
        sort={
          <select className="jp-input" value={sort} onChange={(e) => updateParam('sort', e.target.value)} aria-label="Sort companies by">
            {(Object.keys(SORT_LABELS) as CompanySort[]).map((key) => (
              <option key={key} value={key}>
                {SORT_LABELS[key]}
              </option>
            ))}
          </select>
        }
        chips={
          activeChips.length > 0
            ? activeChips.map((chip) => (
                <FilterChip key={chip.key} onRemove={() => updateParam(chip.key, null)}>
                  {chip.label}
                </FilterChip>
              ))
            : undefined
        }
      />

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 6 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load companies. Please try again.</p>}

      {!isLoading && !isError && data && data.companies.length === 0 && (
        <EmptyState title="No companies match your filters" description="Try a different keyword, industry, or clear your filters." />
      )}

      {!isLoading && data && data.companies.length > 0 && (
        <>
          <div className="jp-jobs-list">
            {data.companies.map((c) => (
              <Link key={c.id} to={`/companies/${c.id}`} className="jp-jobs-link">
                <Card clickable>
                  <CardBody>
                    <div className="jp-job-row">
                      <div className="jp-companies-page__identity">
                        {c.logo_url ? (
                          <img src={c.logo_url} alt="" className="jp-companies-page__logo" />
                        ) : (
                          <div className="jp-companies-page__logo jp-companies-page__logo--placeholder">{c.name[0]}</div>
                        )}
                        <div>
                          <h2 className="jp-job-title">
                            {c.name}
                            {c.is_featured === 1 && <Badge variant="accent" style={{ marginLeft: 8 }}>Featured</Badge>}
                          </h2>
                          <p className="jp-job-company">
                            {c.industry || 'Industry not specified'} · {c.headquarters || 'Location not specified'}
                            {c.size_range && ` · ${c.size_range} employees`}
                          </p>
                          {c.reviews_count > 0 && (
                            <p className="jp-companies-page__rating">
                              ★ {c.rating_avg.toFixed(1)} ({c.reviews_count} review{c.reviews_count === 1 ? '' : 's'})
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="jp-job-badges">
                        {c.is_verified === 1 && <Badge variant="success">Verified</Badge>}
                        <Badge variant="gray">{c.jobs_count} open jobs</Badge>
                      </div>
                    </div>
                  </CardBody>
                </Card>
              </Link>
            ))}
          </div>

          {data.pages > 1 && (
            <div className="jp-jobs-pagination">
              <Button variant="outline" size="sm" disabled={page === 1} onClick={() => goToPage(page - 1)}>
                Previous
              </Button>
              <span>
                Page {page} of {data.pages}
              </span>
              <Button variant="outline" size="sm" disabled={page >= data.pages} onClick={() => goToPage(page + 1)}>
                Next
              </Button>
            </div>
          )}
        </>
      )}
      </div>
    </div>
  )
}
