import { Link, useParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { getEvent, listEvents, registerForEvent, cancelEventRegistration } from '@/features/events/api'
import { useDocumentTitle } from '@/lib/useDocumentTitle'
import { useAuth } from '@/lib/auth/AuthContext'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Skeleton } from '@/components/ui/Skeleton'
import { PublicDetailHero } from '@/components/layout/PublicDetailHero'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import './JobsPage.css'
import './EventDetailPage.css'

export function EventDetailPage() {
  const { id } = useParams<{ id: string }>()
  const eventId = Number(id)
  const toast = useToast()
  const { isAuthenticated, config } = useAuth()
  const queryClient = useQueryClient()

  const { data: event, isLoading, isError } = useQuery({
    queryKey: ['event', eventId],
    queryFn: () => getEvent(eventId),
    enabled: Number.isFinite(eventId),
  })

  useDocumentTitle(event ? `${event.title} · ${config?.site_name ?? 'JP Job Portal'}` : undefined)

  /**
   * Depth pass (Naukri/JobHai benchmarking, batch 5) — root-cause fix: this
   * was the only detail page in the app (job/company/event) with no
   * "more like this" section, despite listEvents() already existing and
   * already being used by EventsPage for exactly this kind of browsing.
   * Fetches the same real upcoming list EventsPage shows and filters
   * client-side to this event's own host_company — an honest limitation
   * (a host with events beyond the first page of results won't all be
   * found) rather than a fabricated "similar events" ranking with no real
   * basis, since there's no dedicated similar-events endpoint for events
   * the way getSimilarJobs() exists for jobs.
   */
  const { data: hostEvents } = useQuery({
    queryKey: ['events', 'upcoming', 'host', event?.host_company],
    queryFn: () => listEvents({ when: 'upcoming' }),
    enabled: !!event?.host_company,
  })
  const moreFromHost = (hostEvents?.events ?? []).filter(
    (e) => e.host_company === event?.host_company && e.id !== event?.id,
  )

  const registerMutation = useMutation({
    mutationFn: () => registerForEvent(eventId),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['event', eventId] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not register.'),
  })

  const cancelMutation = useMutation({
    mutationFn: () => cancelEventRegistration(eventId),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['event', eventId] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not cancel your registration.'),
  })

  if (isLoading) {
    return (
      <div className="jp-public-page">
        <Skeleton height={28} width="60%" />
        <div style={{ height: 16 }} />
        <Skeleton height={200} width="100%" />
      </div>
    )
  }

  if (isError) {
    return (
      <div className="jp-public-page">
        <p className="jp-jobs-error" role="alert">Could not load this event. Please try again.</p>
      </div>
    )
  }

  if (!event) {
    return (
      <div className="jp-public-page">
        <EmptyState title="Event not found" description="This event doesn't exist or may have been removed." />
      </div>
    )
  }

  const isFull = event.seats_total > 0 && event.seats_taken >= event.seats_total
  const isPast = event.status === 'completed' || event.status === 'cancelled'

  const registerBlock = isPast ? (
    <Badge variant="gray">This event has ended.</Badge>
  ) : event.is_registered ? (
    <div className="jp-event-detail__hero-actions">
      <Badge variant="success">You're registered</Badge>
      <Button
        variant="outline"
        size="sm"
        loading={cancelMutation.isPending}
        onClick={() => {
          if (window.confirm(`Cancel your registration for "${event.title}"?`)) cancelMutation.mutate()
        }}
      >
        Cancel registration
      </Button>
    </div>
  ) : isFull ? (
    <Badge variant="warning">Event full</Badge>
  ) : isAuthenticated ? (
    <Button variant="accent" loading={registerMutation.isPending} onClick={() => registerMutation.mutate()}>
      Register
    </Button>
  ) : (
    <p className="jp-event-detail__hero-hint">Log in to register for this event.</p>
  )

  return (
    <div className="jp-public-page-shell">
      <PublicDetailHero
        coverUrl={event.banner_url}
        logoUrl={event.logo_url}
        logoFallback={event.company_name?.[0] ?? 'E'}
        breadcrumbs={[{ label: 'Events', to: '/events' }, { label: event.title }]}
        title={event.title}
        meta={
          <>
            {event.company_name ?? 'Independent host'}
            {event.starts_at && <> · {new Date(event.starts_at).toLocaleString()}</>}
          </>
        }
        badges={
          <>
            <Badge variant="gray">{event.event_type.replace('_', ' ')}</Badge>
            <Badge variant="gray">{event.format}</Badge>
            {event.is_free ? <Badge variant="success">Free</Badge> : <Badge variant="warning">₹{event.price}</Badge>}
          </>
        }
        actions={registerBlock}
      />

      <div className="jp-public-page jp-public-page--raised">
      <SectionCard title="Event details">
        <p className="jp-job-company">
          {event.starts_at ? new Date(event.starts_at).toLocaleString() : 'Date TBD'}
          {event.ends_at && ` – ${new Date(event.ends_at).toLocaleString()}`} ({event.timezone})
        </p>

        {event.venue && <p className="jp-job-company">📍 {event.venue}</p>}
        {event.logo_url && (
          <p className="jp-job-company" style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 8 }}>
            <img src={event.logo_url} alt="" style={{ width: 24, height: 24, borderRadius: 4, objectFit: 'cover' }} />
            Hosted by {event.company_name ?? 'Independent'}
          </p>
        )}

        {event.description && (
          <p style={{ marginTop: 12, whiteSpace: 'pre-wrap' }}>{event.description}</p>
        )}

        <p className="jp-job-company" style={{ marginTop: 12 }}>
          {event.attendee_count}
          {event.seats_total > 0 ? ` / ${event.seats_total}` : ''} attending
        </p>

        {event.meeting_url && event.is_registered && (
          <p style={{ marginTop: 12 }}>
            <a href={event.meeting_url} target="_blank" rel="noreferrer">
              Join meeting link
            </a>
          </p>
        )}
      </SectionCard>

      {/*
        Depth pass (Naukri/JobHai benchmarking, batch 5) — mirrors
        JobDetailPage's own share-row exactly (native share sheet where
        available, clipboard fallback everywhere else) for platform-wide
        consistency — every detail page in the app now offers the same
        sharing pattern.
      */}
      <SectionCard title="Share this event">
        <div className="jp-event-detail__share-row">
          <Button
            variant="outline"
            size="sm"
            onClick={async () => {
              const url = window.location.href
              const shareData = { title: event.title, url }
              if (navigator.share) {
                try {
                  await navigator.share(shareData)
                } catch {
                  // AbortError on user-cancelled share — not a failure, no toast.
                }
                return
              }
              try {
                await navigator.clipboard.writeText(url)
                toast.success('Event link copied to clipboard.')
              } catch {
                toast.error('Could not copy the link. Please copy it from your address bar.')
              }
            }}
          >
            Share
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={async () => {
              try {
                await navigator.clipboard.writeText(window.location.href)
                toast.success('Event link copied to clipboard.')
              } catch {
                toast.error('Could not copy the link. Please copy it from your address bar.')
              }
            }}
          >
            Copy link
          </Button>
        </div>
      </SectionCard>

      {moreFromHost.length > 0 && (
        <SectionCard title={`More events from ${event.company_name ?? 'this host'}`}>
          <div className="jp-event-detail__related-list">
            {moreFromHost.slice(0, 5).map((e) => (
              <Link key={e.id} to={`/events/${e.id}`} className="jp-event-detail__related-card">
                <p className="jp-event-detail__related-title">{e.title}</p>
                <p className="jp-event-detail__related-meta">
                  {e.starts_at ? new Date(e.starts_at).toLocaleDateString() : 'Date TBD'} · {e.event_type.replace('_', ' ')}
                </p>
              </Link>
            ))}
          </div>
        </SectionCard>
      )}
      </div>
    </div>
  )
}
