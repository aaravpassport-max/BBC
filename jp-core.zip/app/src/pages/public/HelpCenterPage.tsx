import { useState, type FormEvent } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { listHelpArticles, submitHelpContact, type HelpArticle } from '@/features/help/api'
import { useAuth } from '@/lib/auth/AuthContext'
import { Card, CardBody } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { PublicPageHero } from '@/components/layout/PublicPageHero'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import './JobsPage.css'
import '../dashboard/ProfilePage.css'
import './HelpCenterPage.css'

export function HelpCenterPage() {
  const toast = useToast()
  const { config } = useAuth()
  const [q, setQ] = useState('')
  const [openId, setOpenId] = useState<number | null>(null)
  const [contact, setContact] = useState({
    name: config?.user_name ?? '',
    email: config?.user_email ?? '',
    subject: '',
    message: '',
  })

  const { data, isLoading, isError } = useQuery({
    queryKey: ['help-articles', q],
    queryFn: () => listHelpArticles(q || undefined),
    placeholderData: (prev) => prev,
  })

  const contactMutation = useMutation({
    mutationFn: () => submitHelpContact(contact),
    onSuccess: (result) => {
      toast.success(result.message)
      setContact((c) => ({ ...c, subject: '', message: '' }))
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not send message.'),
  })

  function onContactSubmit(e: FormEvent) {
    e.preventDefault()
    if (!contact.name.trim() || !contact.email.trim() || !contact.message.trim()) {
      toast.error('Name, email, and message are required.')
      return
    }
    contactMutation.mutate()
  }

  const grouped = (data ?? []).reduce<Record<string, HelpArticle[]>>((acc, article) => {
    ;(acc[article.category] ??= []).push(article)
    return acc
  }, {})

  return (
    <div className="jp-public-page-shell">
      <PublicPageHero
        eyebrow="Support"
        title="Help centre"
        subtitle="Find answers to common questions, or send our support team a message."
      />
      <div className="jp-public-page jp-public-page--raised">
      <div style={{ maxWidth: 320, marginBottom: 16 }}>
        <Input label="Search articles" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load help articles. Please try again.
        </div>
      )}

      {!isLoading && data && data.length === 0 && (
        <EmptyState title="No articles match your search" description="Try a different keyword, or contact support below." />
      )}

      {!isLoading &&
        Object.entries(grouped).map(([category, articles]) => (
          <SectionCard key={category} title={category} className="jp-help-page__section">
            <div className="jp-jobs-list">
              {articles.map((article) => (
                <Card key={article.id}>
                  <CardBody>
                    {/*
                      Root-cause fix (batch 36 — Tier C interaction polish):
                      this button reset all default button chrome including
                      the focus ring, and never applied its own — a keyboard
                      user tabbing through this list had no visible
                      indication which article they were about to expand.
                      className adds a real :focus-visible / :hover rule
                      (see HelpCenterPage.css); aria-expanded reflects the
                      real open/closed state for screen readers.
                    */}
                    <button
                      type="button"
                      className="jp-help-page__toggle"
                      onClick={() => setOpenId(openId === article.id ? null : article.id)}
                      aria-expanded={openId === article.id}
                    >
                      <p className="jp-job-title" style={{ fontSize: 14 }}>
                        {article.title}
                      </p>
                    </button>
                    {openId === article.id && <p style={{ marginTop: 8 }}>{article.body}</p>}
                  </CardBody>
                </Card>
              ))}
            </div>
          </SectionCard>
        ))}

      <SectionCard title="Contact support" className="jp-help-page__section">
        <form onSubmit={onContactSubmit} className="jp-profile-grid">
          <Input label="Name" value={contact.name} onChange={(e) => setContact((c) => ({ ...c, name: e.target.value }))} />
          <Input
            label="Email"
            type="email"
            value={contact.email}
            onChange={(e) => setContact((c) => ({ ...c, email: e.target.value }))}
          />
          <Input
            label="Subject"
            value={contact.subject}
            onChange={(e) => setContact((c) => ({ ...c, subject: e.target.value }))}
            style={{ gridColumn: '1 / -1' }}
          />
          <div className="jp-form-group" style={{ gridColumn: '1 / -1' }}>
            <label className="jp-label" htmlFor="contact-message">
              Message
            </label>
            <textarea
              id="contact-message"
              className="jp-textarea"
              value={contact.message}
              onChange={(e) => setContact((c) => ({ ...c, message: e.target.value }))}
            />
          </div>
          <Button type="submit" variant="accent" loading={contactMutation.isPending}>
            Send message
          </Button>
        </form>
      </SectionCard>
      </div>
    </div>
  )
}
