import { useState, type FormEvent } from 'react'
import { useParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { acceptCommunityReply, addCommunityReply, getCommunityPost, listCommunityReplies, toggleCommunityLike } from '@/features/community/api'
import { useDocumentTitle } from '@/lib/useDocumentTitle'
import { useAuth } from '@/lib/auth/AuthContext'
import { Card, CardBody } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Skeleton } from '@/components/ui/Skeleton'
import { PublicDetailHero } from '@/components/layout/PublicDetailHero'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import './JobsPage.css'
import './CommunityPostPage.css'

export function CommunityPostPage() {
  const { id } = useParams<{ id: string }>()
  const postId = Number(id)
  const toast = useToast()
  const { isAuthenticated, config } = useAuth()
  const queryClient = useQueryClient()
  const [replyBody, setReplyBody] = useState('')

  const { data: post, isLoading, isError } = useQuery({
    queryKey: ['community-post', postId],
    queryFn: () => getCommunityPost(postId),
    enabled: Number.isFinite(postId),
  })

  useDocumentTitle(post ? `${post.title} · ${config?.site_name ?? 'JP Job Portal'}` : undefined)

  const {
    data: replies,
    isLoading: repliesLoading,
    isError: repliesError,
  } = useQuery({
    queryKey: ['community-replies', postId],
    queryFn: () => listCommunityReplies(postId),
    enabled: Number.isFinite(postId),
  })

  const likeMutation = useMutation({
    mutationFn: () => toggleCommunityLike(postId),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['community-post', postId] }),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not like post.'),
  })

  const acceptMutation = useMutation({
    mutationFn: (replyId: number) => acceptCommunityReply(postId, replyId),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['community-replies', postId] })
      queryClient.invalidateQueries({ queryKey: ['community-post', postId] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update this reply.'),
  })

  const replyMutation = useMutation({
    mutationFn: () => addCommunityReply(postId, replyBody),
    onSuccess: () => {
      toast.success('Reply posted.')
      setReplyBody('')
      queryClient.invalidateQueries({ queryKey: ['community-replies', postId] })
      queryClient.invalidateQueries({ queryKey: ['community-post', postId] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not post reply.'),
  })

  function onReplySubmit(e: FormEvent) {
    e.preventDefault()
    if (!replyBody.trim()) {
      toast.error('Write a reply first.')
      return
    }
    replyMutation.mutate()
  }

  if (isLoading) {
    return (
      <div className="jp-public-page">
        <Skeleton height={28} width="60%" />
        <div style={{ height: 16 }} />
        <Skeleton height={120} width="100%" />
      </div>
    )
  }

  // Root-cause fix (states audit): a real fetch failure (network error, 500,
  // etc.) fell straight through to the "!post" branch below and was
  // misreported as "Post not found" instead of a transient load failure.
  if (isError) {
    return (
      <div className="jp-public-page">
        <p className="jp-jobs-error" role="alert">Could not load this post. Please try again.</p>
      </div>
    )
  }

  if (!post) {
    return (
      <div className="jp-public-page">
        <EmptyState title="Post not found" description="This community post doesn't exist or may have been removed." />
      </div>
    )
  }

  return (
    <div className="jp-public-page-shell">
      <PublicDetailHero
        breadcrumbs={[{ label: 'Community', to: '/community' }, { label: post.title }]}
        title={post.title}
        meta={`${post.display_name ?? 'Anonymous'} · ${new Date(post.created_at).toLocaleString()} · ${post.views} views · ${post.reply_count} replies`}
        badges={
          <>
            <Badge variant="gray">{post.category}</Badge>
            {Boolean(post.is_resolved) && <Badge variant="success">Resolved</Badge>}
          </>
        }
        actions={
          <Button
            variant="outline"
            size="sm"
            disabled={!isAuthenticated}
            loading={likeMutation.isPending}
            onClick={() => likeMutation.mutate()}
          >
            👍 {post.likes} helpful
          </Button>
        }
      />

      <div className="jp-public-page jp-public-page--raised">
      <SectionCard title="Discussion" className="jp-community-post__section">
        <p style={{ whiteSpace: 'pre-wrap' }}>{post.body}</p>
      </SectionCard>

      <SectionCard title={`Replies (${replies?.length ?? 0})`} className="jp-community-post__section">
        {repliesLoading && <Skeleton height={80} width="100%" />}

        {repliesError && (
          <p className="jp-jobs-error" role="alert">
            Could not load replies. Please try again.
          </p>
        )}

        {!repliesLoading && replies && replies.length === 0 && (
          <p className="jp-job-company">No replies yet — be the first to respond.</p>
        )}

        {!repliesLoading && replies && replies.length > 0 && (
          <div className="jp-jobs-list" style={{ marginBottom: 16 }}>
            {replies.map((r) => (
              <Card key={r.id}>
                <CardBody>
                  <div className="jp-job-row">
                    <p className="jp-job-company">
                      {r.display_name ?? 'Anonymous'} · {new Date(r.created_at).toLocaleString()}
                      {Boolean(r.is_accepted) && <Badge variant="success">Accepted</Badge>}
                    </p>
                    {post.user_id === config?.user_id && (
                      <Button
                        variant="outline"
                        size="sm"
                        loading={acceptMutation.isPending && acceptMutation.variables === r.id}
                        onClick={() => acceptMutation.mutate(r.id)}
                      >
                        {r.is_accepted ? 'Unmark accepted' : 'Mark as accepted'}
                      </Button>
                    )}
                  </div>
                  <p style={{ marginTop: 6, whiteSpace: 'pre-wrap' }}>{r.body}</p>
                </CardBody>
              </Card>
            ))}
          </div>
        )}

        {isAuthenticated ? (
          <form onSubmit={onReplySubmit}>
            <div className="jp-form-group">
              <label className="jp-label" htmlFor="reply-body">
                Add a reply
              </label>
              <textarea
                id="reply-body"
                className="jp-textarea"
                value={replyBody}
                onChange={(e) => setReplyBody(e.target.value)}
              />
            </div>
            <Button type="submit" variant="accent" loading={replyMutation.isPending}>
              Post reply
            </Button>
          </form>
        ) : (
          <p className="jp-job-company">Log in to reply to this post.</p>
        )}
      </SectionCard>
      </div>
    </div>
  )
}
