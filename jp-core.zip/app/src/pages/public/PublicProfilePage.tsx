import { useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { useMutation, useQuery } from '@tanstack/react-query'
import { getPublicProfile } from '@/features/candidates/publicProfileApi'
import { trackEvent } from '@/features/analytics/api'
import { createThread } from '@/features/messaging/api'
import { useAuth } from '@/lib/auth/AuthContext'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { PublicDetailHero } from '@/components/layout/PublicDetailHero'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import './JobsPage.css'
import './PublicProfilePage.css'

const SECTION_LABELS: Record<string, string> = {
  experience: 'Work experience',
  education: 'Education',
  skills: 'Skills',
  certifications: 'Certifications',
  projects: 'Projects',
  languages: 'Languages',
  awards: 'Awards',
}

interface ResumeEntryLike {
  title?: string
  subtitle?: string
  start_date?: string
  end_date?: string
  description?: string
}

function isEntryLike(item: unknown): item is ResumeEntryLike {
  return typeof item === 'object' && item !== null && 'title' in item
}

function ResumeSection({ sectionKey, items }: { sectionKey: string; items: unknown[] }) {
  if (items.length === 0) return null
  const label = SECTION_LABELS[sectionKey] ?? sectionKey
  const allTags = items.every((item) => typeof item === 'string')

  return (
    <SectionCard title={label} className="jp-public-profile__section">
      {allTags ? (
        <div className="jp-public-profile__tags">
          {(items as string[]).map((tag, i) => (
            <Badge key={i} variant="gray">
              {tag}
            </Badge>
          ))}
        </div>
      ) : (
        <div className="jp-jobs-list">
          {items.filter(isEntryLike).map((entry, i) => (
            <div key={i} className="jp-public-profile__entry">
              <p className="jp-job-title" style={{ fontSize: 14 }}>
                {entry.title}
              </p>
              {entry.subtitle && <p className="jp-job-company">{entry.subtitle}</p>}
              {(entry.start_date || entry.end_date) && (
                <p className="jp-public-profile__dates">
                  {entry.start_date || '—'} – {entry.end_date || 'Present'}
                </p>
              )}
              {entry.description && <p className="jp-public-profile__desc">{entry.description}</p>}
            </div>
          ))}
        </div>
      )}
    </SectionCard>
  )
}

export function PublicProfilePage() {
  const { id } = useParams<{ id: string }>()
  const profileId = Number(id)
  const navigate = useNavigate()
  const toast = useToast()
  const { config } = useAuth()

  useEffect(() => {
    if (Number.isFinite(profileId) && profileId > 0) trackEvent('profile_view', profileId)
  }, [profileId])

  const { data, isLoading, error } = useQuery({
    queryKey: ['public-profile', profileId],
    queryFn: () => getPublicProfile(profileId),
    enabled: Number.isFinite(profileId),
    retry: false,
  })

  // Root-cause fix (batch 26): createThread() (features/messaging/api.ts)
  // has always existed as a working, backend-verified capability (POST
  // /threads, class-jp-messaging.php) but had zero callers anywhere in the
  // app — a recruiter viewing a candidate's public profile had no way to
  // start a conversation with them short of finding an existing shared
  // job application thread. Recruiter-only (a candidate viewing their own
  // or another candidate's profile has no messaging capability toward
  // them in this app), and hidden for a recruiter viewing their own
  // profile id (can't message yourself).
  const messageMutation = useMutation({
    mutationFn: () => createThread(data!.candidate.user_id),
    onSuccess: (result) => navigate(`/recruiter/messages?thread=${result.thread_id}`),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not start a conversation with this candidate.'),
  })

  if (isLoading) {
    return (
      <div className="jp-public-page">
        <Skeleton height={28} width="40%" />
        <div style={{ height: 16 }} />
        <Skeleton height={200} width="100%" />
      </div>
    )
  }

  if (error instanceof ApiError && error.status === 403) {
    return (
      <div className="jp-public-page">
        <EmptyState title="This profile is private" description="The candidate has chosen not to make their profile publicly visible." />
      </div>
    )
  }

  // Root-cause fix (states audit): a real fetch failure (network error,
  // 500, etc. — anything other than the 403/private case above and a
  // genuine 404) fell straight through to the "!data" branch below and
  // was misreported as "Profile not found", telling the visitor the
  // candidate deleted their profile when the actual problem was the
  // request itself failing.
  if (error && !(error instanceof ApiError && error.status === 404)) {
    return (
      <div className="jp-public-page">
        <p className="jp-jobs-error" role="alert">Could not load this profile. Please try again.</p>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="jp-public-page">
        <EmptyState title="Profile not found" description="This candidate profile doesn't exist or may have been removed." />
      </div>
    )
  }

  const sectionEntries = Object.entries(data.sections ?? {}).filter(([, items]) => items.length > 0)
  const c = data.candidate
  const workModeLabel: Record<string, string> = { any: 'Open to any work mode', onsite: 'On-site', remote: 'Remote', hybrid: 'Hybrid' }
  const links = [
    c.portfolio_url && { label: 'Portfolio', href: c.portfolio_url },
    c.linkedin_url && { label: 'LinkedIn', href: c.linkedin_url },
    c.github_url && { label: 'GitHub', href: c.github_url },
  ].filter((l): l is { label: string; href: string } => Boolean(l))

  const subtitleLine = [
    c.current_title ?? c.headline,
    c.current_company,
    c.experience_years !== undefined ? `${c.experience_years} yrs experience` : undefined,
  ]
    .filter(Boolean)
    .join(' · ')

  const recruiterCanMessage = config?.role === 'jp_recruiter' && config.user_id !== c.user_id

  return (
    <div className="jp-public-page-shell">
      <PublicDetailHero
        logoUrl={c.avatar_url}
        logoFallback={data.name[0]}
        title={data.name}
        meta={subtitleLine || undefined}
        badges={c.is_open_to_work ? <Badge variant="success">Open to work</Badge> : undefined}
        actions={
          recruiterCanMessage ? (
            <Button loading={messageMutation.isPending} onClick={() => messageMutation.mutate()}>
              Message candidate
            </Button>
          ) : undefined
        }
      />

      <div className="jp-public-page jp-public-page--raised">
      {/*
        Phase 2 redesign pass — this page previously had no sidebar at all
        (a flat stacked column), which the redesign plan's Phase 1 audit
        flagged as needing the same sticky-sidebar treatment as
        JobDetailPage/CompanyDetailPage. A public candidate profile is the
        exact benchmark case (LinkedIn's profile layout: a persistent
        identity card next to a scrolling list of sections), so this is a
        real structural addition, not a cosmetic one — every field below
        (avatar_url, about, location_state, preferred_work_mode,
        willing_to_relocate, portfolio/linkedin/github_url) already exists
        on the jp_candidates row returned by public_profile(); none of it
        was rendered anywhere before this pass.
      */}
      <div className="jp-public-profile__grid">
        <div className="jp-public-profile__main">
          {c.about && (
            <SectionCard title="About" className="jp-public-profile__section">
              <p className="jp-public-profile__desc">{c.about}</p>
            </SectionCard>
          )}

          {data.badges.length > 0 && (
            <SectionCard title="Achievement badges" className="jp-public-profile__section">
              <div className="jp-public-profile__tags">
                {data.badges.map((b) => (
                  <Badge key={b} variant="gray">
                    🏅 {b}
                  </Badge>
                ))}
              </div>
            </SectionCard>
          )}

          {data.assessments.length > 0 && (
            <SectionCard title="Verified skills" className="jp-public-profile__section">
              <div className="jp-jobs-list">
                {data.assessments.map((a, i) => (
                  <div key={i} className="jp-job-row">
                    <span className="jp-job-title" style={{ fontSize: 13 }}>
                      {a.skill_name ?? 'Unknown skill'}
                    </span>
                    <Badge variant="success">
                      {a.badge_level} · {a.score}%
                    </Badge>
                  </div>
                ))}
              </div>
            </SectionCard>
          )}

          {sectionEntries.map(([key, items]) => (
            <ResumeSection key={key} sectionKey={key} items={items} />
          ))}

          {!c.about && data.badges.length === 0 && data.assessments.length === 0 && sectionEntries.length === 0 && (
            <EmptyState
              title="This candidate hasn't added any public details yet"
              description="Badges, verified skills, and resume sections will appear here once added."
            />
          )}
        </div>

        <div className="jp-public-profile__sidebar">
          <SectionCard title="Profile">
            {c.avatar_url ? (
              <img src={c.avatar_url} alt="" className="jp-public-profile__avatar" />
            ) : (
              <div className="jp-public-profile__avatar jp-public-profile__avatar--placeholder">{data.name[0]}</div>
            )}
            <dl className="jp-public-profile__facts">
              {(c.location_city || c.location_state) && (
                <div>
                  <dt>Location</dt>
                  <dd>{[c.location_city, c.location_state].filter(Boolean).join(', ')}</dd>
                </div>
              )}
              {c.preferred_work_mode && (
                <div>
                  <dt>Work mode</dt>
                  <dd>{workModeLabel[c.preferred_work_mode] ?? c.preferred_work_mode}</dd>
                </div>
              )}
              {c.willing_to_relocate === 1 && (
                <div>
                  <dt>Relocation</dt>
                  <dd>Willing to relocate</dd>
                </div>
              )}
              {c.experience_years !== undefined && (
                <div>
                  <dt>Experience</dt>
                  <dd>{c.experience_years} yrs</dd>
                </div>
              )}
            </dl>
            {links.length > 0 && (
              <div className="jp-public-profile__links">
                {links.map((l) => (
                  <a key={l.label} href={l.href} target="_blank" rel="noreferrer" className="jp-public-profile__link">
                    {l.label} ↗
                  </a>
                ))}
              </div>
            )}
          </SectionCard>
        </div>
      </div>
      </div>
    </div>
  )
}
