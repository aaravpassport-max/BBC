import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { getCompany, getCompanyJobs, getCompanyReviews, voteReviewHelpful } from '@/features/companies/api'
import { trackEvent } from '@/features/analytics/api'
import { useDocumentTitle } from '@/lib/useDocumentTitle'
import { useAuth } from '@/lib/auth/AuthContext'
import { Card, CardBody } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { PageHeader } from '@/components/ui/PageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import './CompanyDetailPage.css'

export function CompanyDetailPage() {
  const { id } = useParams<{ id: string }>()
  const { config } = useAuth()
  const siteName = config?.site_name ?? 'JP Job Portal'
  const companyId = Number(id)
  const enabled = Number.isFinite(companyId) && companyId > 0

  useEffect(() => {
    if (enabled) trackEvent('company_view', companyId)
  }, [enabled, companyId])

  const { data: company, isLoading, isError } = useQuery({
    queryKey: ['company', companyId],
    queryFn: () => getCompany(companyId),
    enabled,
  })

  useDocumentTitle(company ? `${company.name} · ${siteName}` : undefined)
  const { data: jobs, isError: jobsError } = useQuery({
    queryKey: ['company-jobs', companyId],
    queryFn: () => getCompanyJobs(companyId),
    enabled,
  })
  const { data: reviews, isError: reviewsError } = useQuery({
    queryKey: ['company-reviews', companyId],
    queryFn: () => getCompanyReviews(companyId),
    enabled,
  })

  // Root-cause fix (batch 17): "mark helpful" is now reachable — see
  // features/companies/api.ts's voteReviewHelpful() docblock for the full
  // gap trace (backend existed, no route, no SPA caller anywhere). ajax_vote()
  // itself doesn't dedupe per-user, so this session-local Set only prevents
  // the same visitor from re-clicking repeatedly in one page view — it
  // matches, rather than adds to, the backend's own behavior.
  const queryClient = useQueryClient()
  const [votedIds, setVotedIds] = useState<Set<number>>(new Set())
  const voteMutation = useMutation({
    mutationFn: voteReviewHelpful,
    onSuccess: (_result, reviewId) => {
      setVotedIds((prev) => new Set(prev).add(reviewId))
      queryClient.invalidateQueries({ queryKey: ['company-reviews', companyId] })
    },
  })

  if (isLoading) {
    return (
      <div className="jp-company-detail">
        <Skeleton height={32} width="40%" />
        <div style={{ height: 16 }} />
        <Skeleton height={120} width="100%" />
      </div>
    )
  }

  if (isError || !company) {
    return (
      <div className="jp-company-detail">
        <p role="alert">This company could not be found.</p>
        <Link to="/companies">Back to companies</Link>
      </div>
    )
  }

  return (
    <div className="jp-company-detail">
      {/*
        Depth pass (Naukri/JobHai benchmarking, batch 3) — root-cause fix:
        company.cover_url is a real column (jp_companies.cover_url,
        class-jp-activator.php) already returned by getCompany() on every
        CompanyRow, but had zero renderers anywhere in the SPA — every
        company page opened straight into text with no banner, unlike a
        real enterprise company profile. Only rendered when a company has
        actually set one — no placeholder banner is shown for companies
        that haven't uploaded a cover image, since a generic stock banner
        would be exactly the kind of fabricated content this workstream is
        avoiding.
      */}
      {company.cover_url && (
        <div className="jp-company-detail__cover">
          <img src={company.cover_url} alt="" className="jp-company-detail__cover-img" />
        </div>
      )}

      <PageHeader
        breadcrumbs={[{ label: 'Companies', to: '/companies' }, { label: company.name }]}
        title={company.name}
        badges={
          <>
            {company.is_verified === 1 && <Badge variant="success">Verified</Badge>}
            {company.is_featured === 1 && <Badge variant="accent">Featured</Badge>}
            {company.industry && <Badge variant="gray">{company.industry}</Badge>}
          </>
        }
        subtitle={
          company.headquarters
            ? `${company.headquarters}${company.reviews_count > 0 ? ` · ${company.rating_avg.toFixed(1)}★ (${company.reviews_count} reviews)` : ''}`
            : undefined
        }
      />

      <div className="jp-company-detail__grid">
        <div className="jp-company-detail__main">
          {company.description && (
            <SectionCard title="About">
              <p className="jp-job-detail__text">{company.description}</p>
            </SectionCard>
          )}

          <SectionCard title={`Open jobs (${jobs?.length ?? 0})`}>
            {jobsError ? (
              // Root-cause fix: on fetch failure, jobs stayed undefined and this
              // section silently rendered "No open jobs right now" — a false
              // empty state indistinguishable from a company that genuinely has
              // none, with no indication the request actually failed.
              <p className="jp-jobs-error" role="alert">
                Could not load open jobs. Please try again.
              </p>
            ) : jobs && jobs.length > 0 ? (
              <div className="jp-jobs-list">
                {jobs.map((job) => (
                  <Link key={job.id} to={`/jobs/${job.id}`} className="jp-jobs-link">
                    <Card clickable>
                      <CardBody>
                        <h3 className="jp-job-title">{job.title}</h3>
                        <p className="jp-job-company">
                          {job.location_city || 'Remote'} · {job.job_type}
                        </p>
                      </CardBody>
                    </Card>
                  </Link>
                ))}
              </div>
            ) : (
              <EmptyState title="No open jobs right now" description="Check back later — this company posts new roles regularly." />
            )}
          </SectionCard>

          <SectionCard title={`Reviews (${reviews?.length ?? 0})`}>
            {reviewsError ? (
              <p className="jp-jobs-error" role="alert">
                Could not load reviews. Please try again.
              </p>
            ) : reviews && reviews.length > 0 ? (
              <div className="jp-jobs-list">
                {reviews.map((rev) => (
                  <Card key={rev.id}>
                    <CardBody>
                      <div className="jp-review-header">
                        <strong>{rev.display_name}</strong>
                        <span>{rev.rating.toFixed(1)}★</span>
                      </div>
                      {rev.title && <p className="jp-review-title">{rev.title}</p>}
                      <p className="jp-job-detail__text">{rev.body}</p>
                      <div className="jp-job-badges" style={{ marginTop: 8 }}>
                        <Button
                          variant="ghost"
                          size="sm"
                          disabled={votedIds.has(rev.id)}
                          loading={voteMutation.isPending && voteMutation.variables === rev.id}
                          onClick={() => voteMutation.mutate(rev.id)}
                        >
                          {votedIds.has(rev.id) ? 'Marked helpful' : 'Helpful'}
                          {rev.helpful_count > 0 && ` (${rev.helpful_count})`}
                        </Button>
                      </div>
                    </CardBody>
                  </Card>
                ))}
              </div>
            ) : (
              <EmptyState title="No reviews yet" description="Be the first candidate to leave a review after interviewing here." />
            )}
          </SectionCard>
        </div>

        <div className="jp-company-detail__sidebar">
          <SectionCard title="Company info">
            {company.logo_url ? (
              <img src={company.logo_url} alt="" className="jp-company-detail__logo" />
            ) : (
              <div className="jp-company-detail__logo jp-company-detail__logo--placeholder">{company.name[0]}</div>
            )}
            <dl className="jp-company-detail__facts">
              {company.industry && (
                <div>
                  <dt>Industry</dt>
                  <dd>{company.industry}</dd>
                </div>
              )}
              {company.size_range && (
                <div>
                  <dt>Company size</dt>
                  <dd>{company.size_range} employees</dd>
                </div>
              )}
              {company.headquarters && (
                <div>
                  <dt>Headquarters</dt>
                  <dd>{company.headquarters}</dd>
                </div>
              )}
              <div>
                <dt>Open jobs</dt>
                <dd>{company.jobs_count}</dd>
              </div>
            </dl>
            {company.website && (
              <a href={company.website} target="_blank" rel="noreferrer" className="jp-company-detail__website">
                Visit website ↗
              </a>
            )}
          </SectionCard>
        </div>
      </div>
    </div>
  )
}
