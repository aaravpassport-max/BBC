import { useMemo, useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { getChangelog, type ChangelogEntry } from '@/features/help/api'
import { Badge } from '@/components/ui/Badge'
import { SectionCard } from '@/components/ui/SectionCard'
import { PageHeader } from '@/components/ui/PageHeader'
import { EmptyState } from '@/components/ui/EmptyState'
import { StatCard } from '@/components/ui/StatCard'
import { Tabs } from '@/components/ui/Tabs'
import { Timeline, type TimelineItem } from '@/components/ui/Timeline'
import { ListSkeleton } from '@/components/ui/Skeleton'
import './JobsPage.css'
import './ChangelogPage.css'

const TYPE_VARIANT = { major: 'accent', minor: 'primary', patch: 'gray' } as const
const TYPE_TONE: Record<ChangelogEntry['type'], TimelineItem['tone']> = { major: 'error', minor: 'primary', patch: 'default' }

/**
 * Phase 3 redesign (Tier A, redesign-plan §ChangelogPage) — was a flat,
 * unfiltered stack of cards with no way to jump to a specific release or
 * focus on breaking (major) changes only. Rebuilt as a real release-notes
 * page: filterable by change type using the new Tabs component (client-side
 * — /changelog has no server-side type param, so filtering here is genuine
 * functionality, not a decorative control calling nowhere), a summary stat
 * row (latest version, release count, most recent release date), and a
 * proper vertical Timeline (tone-coded per change type) with each entry
 * anchored by id so a version can be deep-linked/shared directly.
 */
export function ChangelogPage() {
  const { data, isLoading, isError } = useQuery({ queryKey: ['changelog'], queryFn: getChangelog })
  const [typeFilter, setTypeFilter] = useState<'all' | ChangelogEntry['type']>('all')

  const counts = useMemo(() => {
    const c = { all: data?.length ?? 0, major: 0, minor: 0, patch: 0 }
    data?.forEach((e) => {
      c[e.type] += 1
    })
    return c
  }, [data])

  const filtered = useMemo(() => {
    if (!data) return []
    return typeFilter === 'all' ? data : data.filter((e) => e.type === typeFilter)
  }, [data, typeFilter])

  const timelineItems: TimelineItem[] = filtered.map((entry) => ({
    id: entry.version,
    tone: TYPE_TONE[entry.type],
    title: (
      <a href={`#v${entry.version}`} id={`v${entry.version}`} className="jp-changelog__version-link">
        <Badge variant={TYPE_VARIANT[entry.type]}>{entry.type}</Badge>
        <span className="jp-changelog__version">v{entry.version}</span>
      </a>
    ),
    timestamp: entry.date,
    description: (
      <ul className="jp-changelog__notes">
        {entry.notes.map((note, i) => (
          <li key={i}>{note}</li>
        ))}
      </ul>
    ),
  }))

  return (
    <div className="jp-public-page">
      <PageHeader title="Changelog" subtitle="What's new and improved on the platform, release by release." />

      {data && data.length > 0 && (
        <div className="jp-changelog__stats">
          <StatCard label="Latest version" value={`v${data[0].version}`} />
          <StatCard label="Total releases" value={data.length} />
          <StatCard label="Major releases" value={counts.major} />
          <StatCard label="Last updated" value={data[0].date} />
        </div>
      )}

      <SectionCard title="Release history">
        {data && data.length > 0 && (
          <Tabs
            label="Filter by release type"
            className="jp-changelog__tabs"
            activeKey={typeFilter}
            onChange={(k) => setTypeFilter(k as typeof typeFilter)}
            items={[
              { key: 'all', label: 'All releases', count: counts.all },
              { key: 'major', label: 'Major', count: counts.major },
              { key: 'minor', label: 'Minor', count: counts.minor },
              { key: 'patch', label: 'Patch', count: counts.patch },
            ]}
          />
        )}

        {isLoading && <ListSkeleton rows={4} />}

        {isError && (
          <p className="jp-jobs-error" role="alert">
            Could not load changelog. Please try again.
          </p>
        )}

        {data && data.length === 0 && (
          <EmptyState title="No changelog entries yet" description="Release notes will appear here as new versions ship." />
        )}

        {data && data.length > 0 && filtered.length === 0 && (
          <EmptyState title={`No ${typeFilter} releases yet`} description="Try a different release-type filter above." />
        )}

        {filtered.length > 0 && <Timeline items={timelineItems} />}
      </SectionCard>
    </div>
  )
}
