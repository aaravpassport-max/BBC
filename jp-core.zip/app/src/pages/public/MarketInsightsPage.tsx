import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { getMarketInsights, getSalaryInsights } from '@/features/market/api'
import { Input } from '@/components/ui/Input'
import { Skeleton } from '@/components/ui/Skeleton'
import { PublicPageHero } from '@/components/layout/PublicPageHero'
import { SectionCard } from '@/components/ui/SectionCard'
import { StatCard } from '@/components/ui/StatCard'
import { EmptyState } from '@/components/ui/EmptyState'
import './JobsPage.css'
import '../dashboard/ProfilePage.css'
import './MarketInsightsPage.css'

export function MarketInsightsPage() {
  const [role, setRole] = useState('')
  const [location, setLocation] = useState('')

  const {
    data: market,
    isLoading: marketLoading,
    isError: marketError,
  } = useQuery({
    queryKey: ['market-insights'],
    queryFn: getMarketInsights,
  })

  const {
    data: salary,
    isLoading: salaryLoading,
    isError: salaryError,
  } = useQuery({
    queryKey: ['salary-insights', role, location],
    queryFn: () => getSalaryInsights(role || undefined, location || undefined),
    placeholderData: (prev) => prev,
  })

  return (
    <div className="jp-public-page-shell">
      <PublicPageHero
        eyebrow="Data-driven search"
        title="Market insights"
        subtitle="Real-time hiring trends, in-demand skills, and salary data across the platform."
        tone="dark"
      />
      <div className="jp-public-page jp-public-page--raised">
      {marketLoading && <Skeleton height={200} width="100%" />}

      {marketError && (
        <div className="jp-jobs-error" role="alert">
          Could not load market insights. Please try again.
        </div>
      )}

      {market && (
        <>
          <div className="jp-market-insights__stats">
            <StatCard label="Active jobs" value={market.stats.active_jobs.toLocaleString()} tone="primary" />
            <StatCard label="Companies hiring" value={market.stats.companies_hiring.toLocaleString()} />
            <StatCard label="New jobs today" value={market.stats.new_jobs_today.toLocaleString()} tone="success" />
            <StatCard label="Remote jobs" value={market.stats.remote_jobs.toLocaleString()} />
          </div>

          <div className="jp-market-insights__grid">
            <SectionCard title="Trending skills" className="jp-market-insights__section">
              {market.trending_skills.length === 0 ? (
                <EmptyState title="No trending skills yet" description="Skill demand will appear here once more jobs are posted." />
              ) : (
                <div className="jp-jobs-list">
                  {market.trending_skills.map((s) => (
                    <div key={s.name} className="jp-job-row">
                      <span className="jp-job-title" style={{ fontSize: 13 }}>
                        {s.name}
                      </span>
                      <span className="jp-job-company">{s.demand} openings</span>
                    </div>
                  ))}
                </div>
              )}
            </SectionCard>

            <SectionCard title="Top hiring companies" className="jp-market-insights__section">
              {market.top_hiring.length === 0 ? (
                <EmptyState title="No hiring activity yet" description="Companies actively hiring will appear here once jobs are posted." />
              ) : (
                <div className="jp-jobs-list">
                  {market.top_hiring.map((c) => (
                    <div key={c.name} className="jp-job-row">
                      <span className="jp-job-title" style={{ fontSize: 13 }}>
                        {c.name}
                      </span>
                      <span className="jp-job-company">{c.jobs} openings</span>
                    </div>
                  ))}
                </div>
              )}
            </SectionCard>
          </div>

          <SectionCard title="Average salary by role" className="jp-market-insights__section">
            {market.avg_salary_by_role.length === 0 ? (
              <EmptyState title="No salary data yet" description="Average salaries by role will appear here as more jobs are posted." />
            ) : (
              <div className="jp-jobs-list">
                {market.avg_salary_by_role.map((r) => (
                  <div key={r.title} className="jp-job-row">
                    <span className="jp-job-title" style={{ fontSize: 13 }}>
                      {r.title}
                    </span>
                    <span className="jp-job-company">
                      ₹{r.avg_salary.toLocaleString()}/yr · {r.openings} openings
                    </span>
                  </div>
                ))}
              </div>
            )}
          </SectionCard>

          {/*
            Depth pass (Naukri/JobHai benchmarking, batch 3) — market_insights()
            gained job_type_breakdown/top_locations aggregates in batch 1
            (added for HomePage's browse tiles), but this page — whose whole
            purpose is "hiring trends across the platform" — never rendered
            them, despite already fetching the exact same market-insights
            query (React Query dedupes it, no extra request). Rendered here
            as simple bar-style breakdowns (widths proportional to the
            largest value in each list) rather than plain numbers, matching
            the "insights" framing of the rest of the page.
          */}
          <div className="jp-market-insights__grid">
            <SectionCard title="Jobs by type" className="jp-market-insights__section">
              {market.job_type_breakdown.length === 0 ? (
                <EmptyState title="No job-type data yet" description="A breakdown by job type will appear here once jobs are posted." />
              ) : (
                <div className="jp-market-insights__bars">
                  {market.job_type_breakdown.map((row) => {
                    const max = market.job_type_breakdown[0].jobs || 1
                    return (
                      <div key={row.job_type} className="jp-market-insights__bar-row">
                        <span className="jp-market-insights__bar-label">
                          {row.job_type
                            .split('-')
                            .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
                            .join('-')}
                        </span>
                        <div className="jp-market-insights__bar-track">
                          <div className="jp-market-insights__bar-fill" style={{ width: `${(row.jobs / max) * 100}%` }} />
                        </div>
                        <span className="jp-market-insights__bar-value">{row.jobs}</span>
                      </div>
                    )
                  })}
                </div>
              )}
            </SectionCard>

            <SectionCard title="Jobs by city" className="jp-market-insights__section">
              {market.top_locations.length === 0 ? (
                <EmptyState title="No location data yet" description="A breakdown by city will appear here once jobs are posted." />
              ) : (
                <div className="jp-market-insights__bars">
                  {market.top_locations.map((row) => {
                    const max = market.top_locations[0].jobs || 1
                    return (
                      <div key={row.location_city} className="jp-market-insights__bar-row">
                        <span className="jp-market-insights__bar-label">{row.location_city}</span>
                        <div className="jp-market-insights__bar-track">
                          <div className="jp-market-insights__bar-fill" style={{ width: `${(row.jobs / max) * 100}%` }} />
                        </div>
                        <span className="jp-market-insights__bar-value">{row.jobs}</span>
                      </div>
                    )
                  })}
                </div>
              )}
            </SectionCard>
          </div>
        </>
      )}

      <SectionCard title="Salary calculator" className="jp-market-insights__section">
        <div style={{ display: 'flex', gap: 12, marginBottom: 16, flexWrap: 'wrap' }}>
          <Input label="Role" value={role} onChange={(e) => setRole(e.target.value)} placeholder="e.g. React Developer" />
          <Input label="Location" value={location} onChange={(e) => setLocation(e.target.value)} placeholder="e.g. Bangalore" />
        </div>
        {salaryLoading && <Skeleton height={60} width="100%" />}
        {salaryError && (
          <p className="jp-jobs-error" role="alert">
            Could not load salary data. Please try again.
          </p>
        )}
        {salary && (
          <p className="jp-job-company">
            {salary.sample_size > 0 ? (
              <>
                Based on {salary.sample_size} listings: ₹{salary.avg_min.toLocaleString()} – ₹
                {salary.avg_max.toLocaleString()} average, ranging ₹{salary.p25.toLocaleString()} to ₹
                {salary.p75.toLocaleString()}.
              </>
            ) : (
              'No salary data found for that role/location combination.'
            )}
          </p>
        )}
      </SectionCard>
      </div>
    </div>
  )
}
