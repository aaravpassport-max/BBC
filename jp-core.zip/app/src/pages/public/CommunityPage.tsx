import { useState, type FormEvent } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import {
  COMMUNITY_CATEGORIES,
  createCommunityPost,
  listCommunityPosts,
  type CommunityCategory,
} from '@/features/community/api'
import { useAuth } from '@/lib/auth/AuthContext'
import { Card, CardBody } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Modal } from '@/components/ui/Modal'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { PublicPageHero } from '@/components/layout/PublicPageHero'
import { EmptyState } from '@/components/ui/EmptyState'
import { FilterBar } from '@/components/ui/FilterBar'
import { Tabs } from '@/components/ui/Tabs'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import './JobsPage.css'
import './CommunityPage.css'

/**
 * Phase 3 redesign (Tier A, redesign-plan §CommunityPage) — was a fake
 * inline-styled category `<select>` (Phase 2 cross-cutting gap #4), no
 * search despite listCommunityPosts()/community_get_posts() already
 * supporting a `q` param, and never rendered is_resolved even though it's
 * a real column community_get_posts() already returns (a "resolved" Q&A
 * thread is meaningfully different from an open one to someone browsing).
 * Replaced the category select with the shared Tabs (All + the 6 real
 * categories) and added the shared FilterBar for search + sort.
 */
export function CommunityPage() {
  const toast = useToast()
  const { isAuthenticated } = useAuth()
  const queryClient = useQueryClient()
  const [category, setCategory] = useState('')
  const [q, setQ] = useState('')
  const [sort, setSort] = useState<'recent' | 'popular'>('recent')
  const [page, setPage] = useState(1)
  const [composerOpen, setComposerOpen] = useState(false)
  const [form, setForm] = useState({ title: '', body: '', category: 'general' as CommunityCategory })

  const { data, isLoading, isError } = useQuery({
    queryKey: ['community-posts', category, q, sort, page],
    queryFn: () => listCommunityPosts({ category: category || undefined, q: q || undefined, sort, page }),
    placeholderData: (prev) => prev,
  })

  const createMutation = useMutation({
    mutationFn: () => createCommunityPost(form),
    onSuccess: () => {
      toast.success('Post created.')
      setComposerOpen(false)
      setForm({ title: '', body: '', category: 'general' })
      queryClient.invalidateQueries({ queryKey: ['community-posts'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not create post.'),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!form.title.trim() || !form.body.trim()) {
      toast.error('Title and body are required.')
      return
    }
    createMutation.mutate()
  }

  return (
    <div className="jp-public-page-shell">
      <PublicPageHero
        eyebrow="Discuss & learn"
        title="Community"
        subtitle="Ask questions, share advice, and discuss job search and career topics with other candidates."
        tone="primary"
        actions={
          isAuthenticated ? (
            <Button variant="accent" onClick={() => setComposerOpen(true)}>
              New post
            </Button>
          ) : undefined
        }
      />
      <div className="jp-public-page jp-public-page--raised">
      <Tabs
        label="Community category"
        activeKey={category || 'all'}
        onChange={(key) => {
          setCategory(key === 'all' ? '' : key)
          setPage(1)
        }}
        items={[{ key: 'all', label: 'All' }, ...COMMUNITY_CATEGORIES.map((c) => ({ key: c, label: c }))]}
      />

      <FilterBar
        className="jp-community__filter-bar"
        search={
          <Input
            label="Search posts"
            value={q}
            onChange={(e) => {
              setQ(e.target.value)
              setPage(1)
            }}
          />
        }
        sort={
          <select
            className="jp-input"
            value={sort}
            onChange={(e) => {
              setSort(e.target.value as 'recent' | 'popular')
              setPage(1)
            }}
            aria-label="Sort posts"
          >
            <option value="recent">Most recent</option>
            <option value="popular">Most viewed</option>
          </select>
        }
      />

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 5 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <p className="jp-jobs-error" role="alert">
          Could not load community posts.
        </p>
      )}

      {!isLoading && data && data.posts.length === 0 && (
        <EmptyState
          title="No posts yet"
          description="Be the first to start a discussion in this category."
          action={
            isAuthenticated ? (
              <Button variant="accent" size="sm" onClick={() => setComposerOpen(true)}>
                New post
              </Button>
            ) : undefined
          }
        />
      )}

      {!isLoading && data && data.posts.length > 0 && (
        <>
          <div className="jp-jobs-list">
            {data.posts.map((post) => (
              <Card key={post.id}>
                <CardBody>
                  <div className="jp-job-row">
                    <div>
                      <p className="jp-job-title" style={{ fontSize: 14 }}>
                        <Link to={`/community/${post.id}`}>{post.title}</Link>
                        {Boolean(post.is_pinned) && <Badge variant="warning">Pinned</Badge>}
                        {Boolean(post.is_resolved) && <Badge variant="success">Resolved</Badge>}
                      </p>
                      <p className="jp-job-company">
                        {post.display_name ?? 'Anonymous'} · {new Date(post.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="jp-job-badges">
                      <Badge variant="gray">{post.category}</Badge>
                      <span className="jp-job-company">👁 {post.views}</span>
                      <span className="jp-job-company">👍 {post.likes}</span>
                      <span className="jp-job-company">💬 {post.reply_count}</span>
                    </div>
                  </div>
                </CardBody>
              </Card>
            ))}
          </div>

          <div className="jp-jobs-pagination">
            <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>
              Previous
            </Button>
            <span>
              Page {page} of {Math.max(1, Math.ceil(data.total / 20))}
            </span>
            <Button
              variant="outline"
              size="sm"
              disabled={page >= Math.ceil(data.total / 20)}
              onClick={() => setPage((p) => p + 1)}
            >
              Next
            </Button>
          </div>
        </>
      )}

      <Modal
        open={composerOpen}
        onClose={() => {
          // Root-cause fix (states audit — residual state on modal close):
          // closing without submitting used to leave the draft in `form`,
          // so reopening the composer showed the abandoned attempt instead
          // of a fresh post.
          setComposerOpen(false)
          setForm({ title: '', body: '', category: 'general' })
        }}
        title="New community post"
      >
        <form onSubmit={onSubmit} className="jp-profile-grid">
          <Input label="Title" value={form.title} onChange={(e) => setForm((f) => ({ ...f, title: e.target.value }))} />
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="post-category">
              Category
            </label>
            <select
              id="post-category"
              className="jp-input"
              value={form.category}
              onChange={(e) => setForm((f) => ({ ...f, category: e.target.value as CommunityCategory }))}
            >
              {COMMUNITY_CATEGORIES.map((c) => (
                <option key={c} value={c}>
                  {c}
                </option>
              ))}
            </select>
          </div>
          <div className="jp-form-group" style={{ gridColumn: '1 / -1' }}>
            <label className="jp-label" htmlFor="post-body">
              Body
            </label>
            <textarea
              id="post-body"
              className="jp-textarea"
              value={form.body}
              onChange={(e) => setForm((f) => ({ ...f, body: e.target.value }))}
            />
          </div>
          <Button type="submit" variant="accent" loading={createMutation.isPending}>
            Post
          </Button>
        </form>
      </Modal>
      </div>
    </div>
  )
}
