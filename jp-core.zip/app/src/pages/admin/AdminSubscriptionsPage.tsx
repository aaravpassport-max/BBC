import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  cancelSubscription,
  getAdminSubscriptions,
  type AdminSubscriptionStatus,
} from '@/features/admin/revenueApi'
import { Card, CardBody } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { EmptyState, NoResultsIcon } from '@/components/ui/EmptyState'
import { FilterBar } from '@/components/ui/FilterBar'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './AdminSubscriptionsPage.css'

const STATUS_VARIANT = {
  trial: 'warning',
  active: 'success',
  past_due: 'warning',
  cancelled: 'gray',
  expired: 'gray',
} as const

const STATUS_OPTIONS: { value: AdminSubscriptionStatus | ''; label: string }[] = [
  { value: '', label: 'All statuses' },
  { value: 'trial', label: 'Trial' },
  { value: 'active', label: 'Active' },
  { value: 'past_due', label: 'Past due' },
  { value: 'cancelled', label: 'Cancelled' },
  { value: 'expired', label: 'Expired' },
]

/**
 * Phase 3 redesign (Tier A, redesign-plan §AdminSubscriptionsPage) — was a
 * plain unfiltered list. Now has a real status filter (server-side, wired
 * to admin_subscriptions()'s new `status` param), a per-row MRR-contribution
 * figure (server-computed from the joined plan's actual price, not
 * invented), and a real cancel action wired to the new POST
 * /admin/subscriptions/{id}/cancel endpoint — the support-override tool the
 * plan called for, gated server-side on jp_manage_plans.
 */
export function AdminSubscriptionsPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [page, setPage] = useState(1)
  const [status, setStatus] = useState<AdminSubscriptionStatus | ''>('')

  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-subscriptions', page, status],
    queryFn: () => getAdminSubscriptions(page, status || undefined),
    placeholderData: (prev) => prev,
  })

  const cancelMutation = useMutation({
    mutationFn: cancelSubscription,
    onSuccess: () => {
      toast.success('Subscription cancelled.')
      queryClient.invalidateQueries({ queryKey: ['admin-subscriptions'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not cancel this subscription.'),
  })

  const totalPages = data ? Math.max(1, Math.ceil(data.total / 20)) : 1

  return (
    <div>
      <WorkspacePageHeader tone="admin"
        title="Subscriptions"
        subtitle={data ? `${data.total.toLocaleString()} subscription${data.total === 1 ? '' : 's'}.` : undefined}
      />

      <FilterBar
        filters={
          <select
            className="jp-input"
            value={status}
            onChange={(e) => {
              setStatus(e.target.value as AdminSubscriptionStatus | '')
              setPage(1)
            }}
            aria-label="Filter by status"
          >
            {STATUS_OPTIONS.map((opt) => (
              <option key={opt.value} value={opt.value}>
                {opt.label}
              </option>
            ))}
          </select>
        }
      />

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load subscriptions. Please try again.
        </div>
      )}

      {!isLoading && data && data.subscriptions.length === 0 && status === '' && (
        <EmptyState title="No subscriptions yet" description="Subscriptions will appear here once recruiters upgrade." />
      )}

      {!isLoading && data && data.subscriptions.length === 0 && status !== '' && (
        <EmptyState
          icon={<NoResultsIcon />}
          title={`No ${status.replace('_', ' ')} subscriptions`}
          description="Try a different status filter above."
        />
      )}

      {!isLoading && data && data.subscriptions.length > 0 && (
        <>
          <div className="jp-jobs-list">
            {data.subscriptions.map((sub) => {
              const isTerminal = sub.status === 'cancelled' || sub.status === 'expired'
              return (
                <Card key={sub.id}>
                  <CardBody>
                    <div className="jp-job-row">
                      <div>
                        <p className="jp-job-title" style={{ fontSize: 14 }}>
                          {sub.display_name} · {sub.plan_name}
                        </p>
                        <p className="jp-job-company">
                          {sub.user_email} · {sub.billing_cycle} · since {new Date(sub.created_at).toLocaleDateString()}
                        </p>
                        {sub.mrr_contribution > 0 && (
                          <p className="jp-admin-subs__mrr">
                            {sub.currency} {sub.mrr_contribution.toLocaleString()}/mo contribution
                          </p>
                        )}
                        {isTerminal && sub.cancelled_at ? (
                          <p className="jp-job-company">Cancelled {new Date(sub.cancelled_at).toLocaleDateString()}</p>
                        ) : (
                          sub.expires_at && (
                            <p className="jp-job-company">Renews/expires {new Date(sub.expires_at).toLocaleDateString()}</p>
                          )
                        )}
                      </div>
                      <div className="jp-admin-subs__row-actions">
                        <Badge variant={STATUS_VARIANT[sub.status]}>{sub.status.replace('_', ' ')}</Badge>
                        {!isTerminal && (
                          <Button
                            variant="ghost"
                            size="sm"
                            loading={cancelMutation.isPending && cancelMutation.variables === sub.id}
                            onClick={() => {
                              if (window.confirm(`Cancel ${sub.display_name}'s ${sub.plan_name} subscription? This cannot be undone.`)) {
                                cancelMutation.mutate(sub.id)
                              }
                            }}
                          >
                            Cancel
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardBody>
                </Card>
              )
            })}
          </div>

          {totalPages > 1 && (
            <div className="jp-job-row" style={{ marginTop: 16 }}>
              <Button variant="outline" size="sm" disabled={page <= 1} onClick={() => setPage((p) => p - 1)}>
                Previous
              </Button>
              <span className="jp-job-company">
                Page {page} of {totalPages}
              </span>
              <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
                Next
              </Button>
            </div>
          )}
        </>
      )}
    </div>
  )
}
