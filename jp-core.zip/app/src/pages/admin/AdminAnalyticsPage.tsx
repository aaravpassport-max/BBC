import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { getAnalyticsDashboard } from '@/features/analytics/api'
import { Skeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { StatCard } from '@/components/ui/StatCard'
import { ListRow } from '@/components/ui/ListRow'
import { Badge } from '@/components/ui/Badge'
import { FilterBar } from '@/components/ui/FilterBar'
import { AnalyticsKpiGrid } from '@/components/recruiter/AnalyticsKpiGrid'
import { EmptyState } from '@/components/ui/EmptyState'
import '../public/JobsPage.css'
import './AdminAnalyticsPage.css'

const RANGE_OPTIONS = [7, 30, 90]

export function AdminAnalyticsPage() {
  const [days, setDays] = useState(30)

  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-analytics-dashboard', days],
    queryFn: () => getAnalyticsDashboard(days),
  })

  const dailyMax = data?.daily.length ? Math.max(...data.daily.map((p) => p.views), 1) : 1

  return (
    <div className="jp-admin-analytics">
      <WorkspacePageHeader
        tone="admin"
        title="Platform analytics"
        subtitle="Traffic, funnel, and hiring-source trends across the platform — aggregated from real view, apply, and signup events."
      />

      <FilterBar
        className="jp-workspace-toolbar"
        filters={
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="admin-analytics-range">
              Date range
            </label>
            <select
              id="admin-analytics-range"
              className="jp-input"
              value={days}
              onChange={(e) => setDays(Number(e.target.value))}
            >
              {RANGE_OPTIONS.map((d) => (
                <option key={d} value={d}>
                  Last {d} days
                </option>
              ))}
            </select>
          </div>
        }
      />

      {isLoading && <Skeleton height={240} width="100%" />}

      {isError && (
        <p className="jp-jobs-error" role="alert">
          Could not load analytics.
        </p>
      )}

      {!isLoading && data && (
        <>
          <AnalyticsKpiGrid>
            <StatCard label="Job views" value={data.total_views.toLocaleString()} tone="primary" />
            <StatCard label="Applications" value={data.total_applies.toLocaleString()} />
            {typeof data.total_searches === 'number' && (
              <StatCard label="Searches" value={data.total_searches.toLocaleString()} />
            )}
            {typeof data.new_users === 'number' && (
              <StatCard label="New signups" value={data.new_users.toLocaleString()} tone="success" />
            )}
            {typeof data.apply_rate === 'number' && (
              <StatCard label="Apply rate" value={`${data.apply_rate}%`} />
            )}
            <StatCard
              label="Avg. time to hire"
              value={
                data.avg_time_to_hire_days !== null && typeof data.avg_time_to_hire_days !== 'undefined'
                  ? `${data.avg_time_to_hire_days} days`
                  : '—'
              }
            />
            <StatCard
              label="Offer acceptance"
              value={
                data.offer_acceptance_rate_pct !== null && typeof data.offer_acceptance_rate_pct !== 'undefined'
                  ? `${data.offer_acceptance_rate_pct}%`
                  : '—'
              }
              tone="success"
            />
          </AnalyticsKpiGrid>

          {data.daily.length === 0 ? (
            <EmptyState title="No traffic recorded yet" description="Traffic for this period will appear here once it's tracked." />
          ) : (
            <SectionCard title="Daily traffic" className="jp-admin-analytics__section">
              <p className="jp-admin-analytics__section-lead">Views and applications per day in the selected range.</p>
              <div className="jp-admin-analytics__bars">
                {data.daily.map((point) => (
                  <div key={point.period}>
                    <div className="jp-admin-analytics__bar-label">
                      <span>{new Date(point.period).toLocaleDateString()}</span>
                      <span className="jp-admin-analytics__bar-value">
                        {point.views} views · {point.applies} applies
                      </span>
                    </div>
                    <div className="jp-admin-analytics__bar-track">
                      <div className="jp-admin-analytics__bar-fill" style={{ width: `${(point.views / dailyMax) * 100}%` }} />
                    </div>
                  </div>
                ))}
              </div>
            </SectionCard>
          )}

          {data.funnel_reach && data.funnel_reach.length > 0 && (
            <SectionCard title="Platform funnel reach" className="jp-admin-analytics__section">
              <p className="jp-admin-analytics__section-lead">All applications that ever reached each stage.</p>
              <div className="jp-admin-analytics__list">
                {data.funnel_reach.map((f) => (
                  <ListRow
                    key={f.stage}
                    title={<span className="jp-admin-analytics__stage-name">{f.stage.replace('_', ' ')}</span>}
                    meta={
                      f.conversion_from_applied_pct !== null
                        ? `${f.reached} reached · ${f.conversion_from_applied_pct}% of applied`
                        : `${f.reached} reached`
                    }
                    aside={<Badge variant="gray">{f.reached}</Badge>}
                  />
                ))}
              </div>
            </SectionCard>
          )}

          {data.source_breakdown && data.source_breakdown.length > 0 && (
            <SectionCard title="Source of hire" className="jp-admin-analytics__section">
              <p className="jp-admin-analytics__section-lead">Where applications and hires originated.</p>
              <div className="jp-admin-analytics__list">
                {data.source_breakdown.map((s) => (
                  <ListRow
                    key={s.source}
                    title={<span className="jp-admin-analytics__stage-name">{s.source.replace('_', ' ')}</span>}
                    meta={`${s.applications} applications · ${s.hires} hires`}
                    aside={<Badge variant={s.hire_rate_pct >= 10 ? 'success' : 'gray'}>{s.hire_rate_pct}% hire rate</Badge>}
                  />
                ))}
              </div>
            </SectionCard>
          )}
        </>
      )}
    </div>
  )
}
