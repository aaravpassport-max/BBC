import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { getAnalyticsDashboard } from '@/features/analytics/api'
import { Skeleton } from '@/components/ui/Skeleton'
import { PageHeader } from '@/components/ui/PageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { StatCard } from '@/components/ui/StatCard'
import { EmptyState } from '@/components/ui/EmptyState'
import '../public/JobsPage.css'
import '../dashboard/ProfilePage.css'
import './AdminAnalyticsPage.css'

const RANGE_OPTIONS = [7, 30, 90]

/**
 * Platform-wide traffic dashboard — GET /analytics/dashboard, which for an
 * admin caller runs JP_Analytics::platform_summary(): daily job views/
 * applies aggregated from wp_jp_analytics_agg, plus total searches (from
 * wp_jp_search_log) and new user signups. Distinct from AdminRevenuePage
 * (money) and the dashboard-home stat cards (point-in-time counts) — this
 * is the only place platform traffic trends are visible to an admin. Was a
 * registered, fully-implemented REST route with no frontend consumer
 * anywhere in the app (see src/features/analytics/api.ts's docblock for
 * the full root-cause trace on why this pipeline was silently starved of
 * data until this pass wired up the event-tracking calls that feed it).
 *
 * Root-cause fix (batch 3): also renders funnel_reach / avg_time_to_hire_days
 * / offer_acceptance_rate_pct / source_breakdown, which platform_summary()
 * now returns via JP_Analytics::platform_funnel_and_sources() — this is the
 * platform-wide counterpart of the funnel section already shown on
 * RecruiterAnalyticsPage.tsx (per-recruiter), now backed by the same shared
 * JP_Analytics::compute_funnel_metrics() algorithm on the PHP side. Also
 * adds source-of-hire attribution (jp_applications.source), which nothing
 * anywhere in the app surfaced before this.
 */
export function AdminAnalyticsPage() {
  const [days, setDays] = useState(30)

  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-analytics-dashboard', days],
    queryFn: () => getAnalyticsDashboard(days),
  })

  return (
    <div>
      <PageHeader
        title="Platform analytics"
        subtitle="Traffic, funnel, and hiring-source trends across the platform."
        actions={
          <select
            className="jp-input"
            style={{ maxWidth: 160 }}
            value={days}
            onChange={(e) => setDays(Number(e.target.value))}
            aria-label="Date range"
          >
            {RANGE_OPTIONS.map((d) => (
              <option key={d} value={d}>
                Last {d} days
              </option>
            ))}
          </select>
        }
      />

      {isLoading && <Skeleton height={240} width="100%" />}

      {isError && (
        <p className="jp-jobs-error" role="alert">
          Could not load analytics.
        </p>
      )}

      {!isLoading && data && (
        <>
          <div className="jp-profile-grid" style={{ marginBottom: 24 }}>
            <StatCard label="Job views" value={data.total_views.toLocaleString()} />
            <StatCard label="Applications" value={data.total_applies.toLocaleString()} tone="primary" />
            {typeof data.total_searches === 'number' && (
              <StatCard label="Searches" value={data.total_searches.toLocaleString()} />
            )}
            {typeof data.new_users === 'number' && (
              <StatCard label="New signups" value={data.new_users.toLocaleString()} tone="success" />
            )}
            {typeof data.apply_rate === 'number' && (
              <StatCard label="Apply rate (applies ÷ views)" value={`${data.apply_rate}%`} />
            )}
          </div>

          {data.daily.length === 0 ? (
            <EmptyState title="No traffic recorded yet" description="Traffic for this period will appear here once it's tracked." />
          ) : (
            <SectionCard title="Daily breakdown" className="jp-admin-analytics__section">
              <div className="jp-jobs-list">
                {data.daily.map((point) => (
                  <div key={point.period} className="jp-job-row">
                    <span className="jp-job-company">{new Date(point.period).toLocaleDateString()}</span>
                    <span className="jp-job-title" style={{ fontSize: 14 }}>
                      {point.views} views · {point.applies} applies
                    </span>
                  </div>
                ))}
              </div>
            </SectionCard>
          )}

          {(typeof data.avg_time_to_hire_days !== 'undefined' || typeof data.offer_acceptance_rate_pct !== 'undefined') && (
            <div className="jp-profile-grid" style={{ marginBottom: 24 }}>
              <StatCard
                label="Avg. time to hire (platform-wide)"
                value={
                  data.avg_time_to_hire_days !== null && typeof data.avg_time_to_hire_days !== 'undefined'
                    ? `${data.avg_time_to_hire_days} days`
                    : '—'
                }
              />
              <StatCard
                label="Offer acceptance rate (platform-wide)"
                value={
                  data.offer_acceptance_rate_pct !== null && typeof data.offer_acceptance_rate_pct !== 'undefined'
                    ? `${data.offer_acceptance_rate_pct}%`
                    : '—'
                }
              />
            </div>
          )}

          {data.funnel_reach && data.funnel_reach.length > 0 && (
            <SectionCard title="Platform-wide funnel (all applications, ever reached this stage)" className="jp-admin-analytics__section">
              <div className="jp-jobs-list">
                {data.funnel_reach.map((f) => (
                  <div key={f.stage} className="jp-job-row">
                    <span className="jp-job-title" style={{ fontSize: 13, textTransform: 'capitalize' }}>
                      {f.stage.replace('_', ' ')}
                    </span>
                    <span className="jp-job-company">
                      {f.reached} {f.conversion_from_applied_pct !== null && `(${f.conversion_from_applied_pct}% of applied)`}
                    </span>
                  </div>
                ))}
              </div>
            </SectionCard>
          )}

          {data.source_breakdown && data.source_breakdown.length > 0 && (
            <SectionCard title="Source of hire">
              <div className="jp-jobs-list">
                {data.source_breakdown.map((s) => (
                  <div key={s.source} className="jp-job-row">
                    <span className="jp-job-title" style={{ fontSize: 13, textTransform: 'capitalize' }}>
                      {s.source.replace('_', ' ')}
                    </span>
                    <span className="jp-job-company">
                      {s.applications} applications · {s.hires} hires ({s.hire_rate_pct}%)
                    </span>
                  </div>
                ))}
              </div>
            </SectionCard>
          )}
        </>
      )}
    </div>
  )
}
