import { useState, type FormEvent } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { listAdminPlans, savePlan, type PlanPayload, type PlanRow } from '@/features/admin/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import '../dashboard/ProfilePage.css'
import './AdminPlansPage.css'

/** Batch 30: mirrors class-jp-payments.php's do_create_order()'s allow-list
 * exactly — Razorpay (this deployment's default gateway) is INR-only, so a
 * USD plan is only chargeable when the site's payment gateway is set to
 * Stripe. See AdminSettingsPage.tsx for that gateway toggle. */
function currencySymbol(currency: string): string {
  return currency === 'USD' ? '$' : '₹'
}

const EMPTY_FORM: PlanPayload = {
  name: '',
  slug: '',
  description: '',
  price_monthly: 0,
  price_yearly: 0,
  currency: 'INR',
  job_posts: 0,
  featured_jobs: 0,
  resume_views: 0,
  candidate_msgs: 0,
  team_seats: 1,
  is_active: 1,
  sort_order: 0,
}

function parseFeaturesText(text: string): string[] {
  return text
    .split('\n')
    .map((line) => line.trim())
    .filter(Boolean)
}

export function AdminPlansPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [editingId, setEditingId] = useState<number | undefined>(undefined)
  const [form, setForm] = useState<PlanPayload>(EMPTY_FORM)
  // Root-cause fix (batch 32): jp_plans.features_json is a real column,
  // read by the public PricingPage.tsx to render each plan's marketing
  // feature bullets, but nothing anywhere ever wrote it — every plan's
  // feature list was permanently empty. Kept as free-text (one bullet per
  // line) rather than a structured field-list, since features_json is
  // just a plain string array on the wire, matching parseFeatures()'s own
  // shape in PricingPage.tsx exactly.
  const [featuresText, setFeaturesText] = useState('')

  const { data, isLoading, isError } = useQuery({ queryKey: ['admin-plans'], queryFn: listAdminPlans })

  const saveMutation = useMutation({
    mutationFn: (payload: PlanPayload) => savePlan(editingId, payload),
    onSuccess: (result) => {
      toast.success(result.message)
      setEditingId(undefined)
      setForm(EMPTY_FORM)
      setFeaturesText('')
      queryClient.invalidateQueries({ queryKey: ['admin-plans'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not save plan.'),
  })

  function field<K extends keyof PlanPayload>(key: K, value: PlanPayload[K]) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  function startEdit(plan: PlanRow) {
    setEditingId(plan.id)
    setForm({
      name: plan.name,
      slug: plan.slug,
      description: plan.description ?? '',
      price_monthly: plan.price_monthly,
      price_yearly: plan.price_yearly,
      currency: plan.currency ?? 'INR',
      job_posts: plan.job_posts,
      featured_jobs: plan.featured_jobs,
      resume_views: plan.resume_views,
      candidate_msgs: plan.candidate_msgs,
      team_seats: plan.team_seats,
      is_active: plan.is_active ? 1 : 0,
      sort_order: plan.sort_order,
    })
    let existingFeatures: string[] = []
    if (plan.features_json) {
      try {
        const parsed = JSON.parse(plan.features_json) as unknown
        if (Array.isArray(parsed)) existingFeatures = parsed.filter((f): f is string => typeof f === 'string')
      } catch {
        // Malformed features_json is treated as "no features yet" rather than crashing the edit form.
      }
    }
    setFeaturesText(existingFeatures.join('\n'))
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!form.name?.trim() || !form.slug?.trim()) {
      toast.error('Name and slug are required.')
      return
    }
    saveMutation.mutate({ ...form, features: parseFeaturesText(featuresText) })
  }

  return (
    <div>
      <WorkspacePageHeader tone="admin" title="Subscription plans" subtitle="Manage the plans recruiters can subscribe to." />

      <SectionCard title={editingId ? 'Edit plan' : 'Create a plan'} className="jp-admin-plans__section">
          <form onSubmit={onSubmit} className="jp-profile-grid">
            <Input label="Name" value={form.name ?? ''} onChange={(e) => field('name', e.target.value)} />
            <Input label="Slug" value={form.slug ?? ''} onChange={(e) => field('slug', e.target.value)} />
            <div className="jp-form-group" style={{ gridColumn: '1 / -1' }}>
              <label className="jp-label" htmlFor="plan-description">
                Description
              </label>
              <textarea
                id="plan-description"
                className="jp-textarea"
                value={form.description ?? ''}
                onChange={(e) => field('description', e.target.value)}
              />
            </div>
            <Input
              label="Price / month"
              type="number"
              value={String(form.price_monthly ?? 0)}
              onChange={(e) => field('price_monthly', Number(e.target.value))}
            />
            <Input
              label="Price / year"
              type="number"
              value={String(form.price_yearly ?? 0)}
              onChange={(e) => field('price_yearly', Number(e.target.value))}
            />
            <div className="jp-form-group">
              <label className="jp-label" htmlFor="plan-currency">
                Currency
              </label>
              <select
                id="plan-currency"
                className="jp-input"
                value={form.currency ?? 'INR'}
                onChange={(e) => field('currency', e.target.value as PlanPayload['currency'])}
              >
                <option value="INR">INR (₹)</option>
                <option value="USD">USD ($)</option>
              </select>
            </div>
            <Input
              label="Job posts"
              type="number"
              value={String(form.job_posts ?? 0)}
              onChange={(e) => field('job_posts', Number(e.target.value))}
            />
            <Input
              label="Featured jobs"
              type="number"
              value={String(form.featured_jobs ?? 0)}
              onChange={(e) => field('featured_jobs', Number(e.target.value))}
            />
            <Input
              label="Resume views"
              type="number"
              value={String(form.resume_views ?? 0)}
              onChange={(e) => field('resume_views', Number(e.target.value))}
            />
            <Input
              label="Candidate messages"
              type="number"
              value={String(form.candidate_msgs ?? 0)}
              onChange={(e) => field('candidate_msgs', Number(e.target.value))}
            />
            <Input
              label="Team seats"
              type="number"
              value={String(form.team_seats ?? 1)}
              onChange={(e) => field('team_seats', Number(e.target.value))}
            />
            <Input
              label="Sort order"
              type="number"
              value={String(form.sort_order ?? 0)}
              onChange={(e) => field('sort_order', Number(e.target.value))}
            />
            <div className="jp-form-group" style={{ gridColumn: '1 / -1' }}>
              <label className="jp-label" htmlFor="plan-features">
                Marketing features (one per line)
              </label>
              <textarea
                id="plan-features"
                className="jp-textarea"
                placeholder={'Unlimited job posts\nPriority support\nAdvanced analytics'}
                value={featuresText}
                onChange={(e) => setFeaturesText(e.target.value)}
              />
            </div>
            <div className="jp-form-group">
              <label className="jp-label" htmlFor="plan-active">
                Active
              </label>
              <select
                id="plan-active"
                className="jp-input"
                value={String(form.is_active ?? 1)}
                onChange={(e) => field('is_active', Number(e.target.value))}
              >
                <option value="1">Active</option>
                <option value="0">Inactive</option>
              </select>
            </div>
            <div style={{ alignSelf: 'end', display: 'flex', gap: 8 }}>
              <Button type="submit" variant="accent" loading={saveMutation.isPending}>
                {editingId ? 'Save changes' : 'Create plan'}
              </Button>
              {editingId && (
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => {
                    setEditingId(undefined)
                    setForm(EMPTY_FORM)
                    setFeaturesText('')
                  }}
                >
                  Cancel
                </Button>
              )}
            </div>
          </form>
      </SectionCard>

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 3 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load plans. Please try again.
        </div>
      )}

      {!isLoading && data && data.length === 0 && (
        <EmptyState title="No plans configured" description="Create a plan above to start offering subscriptions." />
      )}

      {!isLoading && data && data.length > 0 && (
        <div className="jp-jobs-list">
          {data.map((plan) => (
            <Card key={plan.id}>
              <CardBody>
                <div className="jp-job-row">
                  <div>
                    <p className="jp-job-title" style={{ fontSize: 14 }}>
                      {plan.name} <Badge variant={plan.is_active ? 'success' : 'gray'}>{plan.is_active ? 'Active' : 'Inactive'}</Badge>
                    </p>
                    <p className="jp-job-company">
                      {currencySymbol(plan.currency)}
                      {plan.price_monthly.toLocaleString()}/mo · {currencySymbol(plan.currency)}
                      {plan.price_yearly.toLocaleString()}/yr · {plan.job_posts} job posts · {plan.team_seats} seats
                    </p>
                    {plan.features_json && (
                      <p className="jp-job-company" style={{ marginTop: 4 }}>
                        {(() => {
                          try {
                            const parsed = JSON.parse(plan.features_json) as unknown
                            return Array.isArray(parsed) ? parsed.filter((f): f is string => typeof f === 'string').join(' · ') : ''
                          } catch {
                            return ''
                          }
                        })()}
                      </p>
                    )}
                  </div>
                  <div className="jp-job-badges">
                    <Button variant="outline" size="sm" onClick={() => startEdit(plan)}>
                      Edit
                    </Button>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
