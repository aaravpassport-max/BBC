import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { approveJob, bulkApproveJobs, getPendingJobs, importJobsCsv, type PendingJobRow } from '@/features/admin/api'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Modal } from '@/components/ui/Modal'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { CsvImportPanel } from '@/components/admin/CsvImportPanel'
import '../public/JobsPage.css'
import './AdminJobModerationPage.css'

type RejectTarget = { mode: 'single'; id: number } | { mode: 'bulk'; ids: number[] }

function parseSkills(skillsJson: string | undefined): string[] {
  if (!skillsJson) return []
  try {
    const parsed = JSON.parse(skillsJson)
    return Array.isArray(parsed) ? parsed.filter((s): s is string => typeof s === 'string') : []
  } catch {
    return []
  }
}

/**
 * Phase 3 redesign (Tier A, redesign-plan §AdminJobModerationPage) — was a
 * flat approve/reject list with no inline preview, no bulk action, and no
 * way to record why a job was rejected. All three are real now:
 *  - Inline preview: expand/collapse using data already returned by
 *    admin_pending_jobs() (SELECT j.* — description, requirements, salary,
 *    location are already in the response; no extra fetch needed).
 *  - Bulk approve/reject: checkboxes + a real POST /admin/jobs/bulk-approve
 *    endpoint that reports per-id success/failure rather than assuming all
 *    succeeded.
 *  - Rejection reason: captured via a modal (works for both single and bulk
 *    reject), stored in the new jp_jobs.rejection_reason column, and used
 *    by both admin_approve_job() and admin_bulk_approve_jobs(). Found and
 *    fixed a real ghost-success bug in admin_approve_job() while wiring
 *    this — its $wpdb->update() return value was never checked.
 */
export function AdminJobModerationPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [expandedId, setExpandedId] = useState<number | null>(null)
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [rejectTarget, setRejectTarget] = useState<RejectTarget | null>(null)
  const [reason, setReason] = useState('')

  const { data, isLoading, isError } = useQuery({ queryKey: ['admin-pending-jobs'], queryFn: getPendingJobs })

  function invalidateAfterImport() {
    queryClient.invalidateQueries({ queryKey: ['admin-pending-jobs'] })
    queryClient.invalidateQueries({ queryKey: ['admin-stats'] })
  }

  function invalidateAfterDecision() {
    queryClient.invalidateQueries({ queryKey: ['admin-pending-jobs'] })
    queryClient.invalidateQueries({ queryKey: ['admin-stats'] })
  }

  const decisionMutation = useMutation({
    mutationFn: ({ id, approve, reason: r }: { id: number; approve: boolean; reason?: string }) => approveJob(id, approve, r),
    onSuccess: (result) => {
      toast.success(result.message)
      setSelected((prev) => {
        const next = new Set(prev)
        if (decisionMutation.variables) next.delete(decisionMutation.variables.id)
        return next
      })
      invalidateAfterDecision()
    },
    onError: () => toast.error('Could not record this decision.'),
  })

  const bulkMutation = useMutation({
    mutationFn: ({ ids, approve, reason: r }: { ids: number[]; approve: boolean; reason?: string }) => bulkApproveJobs(ids, approve, r),
    onSuccess: (result) => {
      if (result.failed.length > 0) {
        toast.error(`${result.message} (job IDs that failed: ${result.failed.join(', ')})`)
      } else {
        toast.success(result.message)
      }
      setSelected(new Set())
      invalidateAfterDecision()
    },
    onError: () => toast.error('Could not process the selected jobs.'),
  })

  function toggleSelect(id: number) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  function toggleSelectAll() {
    if (!data) return
    setSelected((prev) => (prev.size === data.length ? new Set() : new Set(data.map((j) => j.id))))
  }

  function openRejectModal(target: RejectTarget) {
    setReason('')
    setRejectTarget(target)
  }

  function confirmReject() {
    if (!rejectTarget) return
    if (rejectTarget.mode === 'single') {
      decisionMutation.mutate({ id: rejectTarget.id, approve: false, reason })
    } else {
      bulkMutation.mutate({ ids: rejectTarget.ids, approve: false, reason })
    }
    setRejectTarget(null)
  }

  const selectedCount = selected.size

  return (
    <div>
      <WorkspacePageHeader tone="admin"
        title="Jobs awaiting review"
        subtitle={data ? `${data.length} job${data.length === 1 ? '' : 's'} pending a decision.` : undefined}
      />

      <CsvImportPanel
        title="Bulk import jobs"
        hint="CSV columns: title, company_id or company_name, job_type, work_mode, location_city, location_state, salary_min, salary_max, experience_min, experience_max, description, skills (semicolon-separated), openings. Since you're an admin, imported jobs go live immediately (same auto-approve rule as any admin-posted job) rather than entering the review queue below."
        onImport={importJobsCsv}
        onDone={invalidateAfterImport}
      />

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 3 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load pending jobs.</p>}

      {!isLoading && data && data.length === 0 && (
        <EmptyState title="Nothing pending review" description="All submitted jobs have been reviewed." />
      )}

      {!isLoading && data && data.length > 0 && (
        <>
          <div className="jp-admin-mod__toolbar">
            <label className="jp-admin-mod__select-all">
              <input type="checkbox" checked={selectedCount === data.length} onChange={toggleSelectAll} />
              Select all ({data.length})
            </label>
            {selectedCount > 0 && (
              <div className="jp-admin-mod__bulk-actions">
                <span className="jp-admin-mod__selected-count">{selectedCount} selected</span>
                <Button
                  variant="outline"
                  size="sm"
                  loading={bulkMutation.isPending && bulkMutation.variables?.approve === false}
                  onClick={() => openRejectModal({ mode: 'bulk', ids: Array.from(selected) })}
                >
                  Reject selected
                </Button>
                <Button
                  variant="accent"
                  size="sm"
                  loading={bulkMutation.isPending && bulkMutation.variables?.approve === true}
                  onClick={() => bulkMutation.mutate({ ids: Array.from(selected), approve: true })}
                >
                  Approve selected
                </Button>
              </div>
            )}
          </div>

          <div className="jp-jobs-list">
            {data.map((job) => (
              <JobModerationRow
                key={job.id}
                job={job}
                selected={selected.has(job.id)}
                onToggleSelect={() => toggleSelect(job.id)}
                expanded={expandedId === job.id}
                onToggleExpand={() => setExpandedId(expandedId === job.id ? null : job.id)}
                approvePending={decisionMutation.isPending && decisionMutation.variables?.id === job.id && decisionMutation.variables.approve === true}
                rejectPending={decisionMutation.isPending && decisionMutation.variables?.id === job.id && decisionMutation.variables.approve === false}
                onApprove={() => decisionMutation.mutate({ id: job.id, approve: true })}
                onReject={() => openRejectModal({ mode: 'single', id: job.id })}
              />
            ))}
          </div>
        </>
      )}

      <Modal
        open={rejectTarget !== null}
        onClose={() => setRejectTarget(null)}
        title={rejectTarget?.mode === 'bulk' ? `Reject ${rejectTarget.ids.length} jobs` : 'Reject job'}
        footer={
          <>
            <Button variant="outline" onClick={() => setRejectTarget(null)}>
              Cancel
            </Button>
            <Button variant="accent" onClick={confirmReject}>
              Confirm rejection
            </Button>
          </>
        }
      >
        <label className="jp-label" htmlFor="reject-reason">
          Reason (optional, shared with the recruiter)
        </label>
        <textarea
          id="reject-reason"
          className="jp-textarea"
          rows={4}
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="e.g. Missing salary range, or duplicate of an existing listing."
        />
      </Modal>
    </div>
  )
}

function JobModerationRow({
  job,
  selected,
  onToggleSelect,
  expanded,
  onToggleExpand,
  approvePending,
  rejectPending,
  onApprove,
  onReject,
}: {
  job: PendingJobRow
  selected: boolean
  onToggleSelect: () => void
  expanded: boolean
  onToggleExpand: () => void
  approvePending: boolean
  rejectPending: boolean
  onApprove: () => void
  onReject: () => void
}) {
  return (
    <Card>
      <CardBody>
        <div className="jp-job-row">
          <div className="jp-admin-mod__row-main">
            <input type="checkbox" checked={selected} onChange={onToggleSelect} aria-label={`Select ${job.title}`} />
            <div>
              <button type="button" className="jp-admin-mod__title-btn" onClick={onToggleExpand} aria-expanded={expanded}>
                <h2 className="jp-job-title">{job.title}</h2>
              </button>
              <p className="jp-job-company">
                {job.company_name} · Posted by {job.posted_by_name ?? 'Unknown'} on{' '}
                {new Date(job.created_at).toLocaleDateString()}
              </p>
            </div>
          </div>
          <div className="jp-job-badges">
            {!!job.is_featured && <Badge variant="warning">Featured</Badge>}
            {!!job.is_urgent && <Badge variant="error">Urgent hiring</Badge>}
            <Button variant="outline" size="sm" onClick={onToggleExpand}>
              {expanded ? 'Hide preview' : 'Preview'}
            </Button>
            <Button variant="outline" size="sm" loading={rejectPending} onClick={onReject}>
              Reject
            </Button>
            <Button variant="accent" size="sm" loading={approvePending} onClick={onApprove}>
              Approve
            </Button>
          </div>
        </div>

        {expanded && (
          <div className="jp-admin-mod__preview">
            <div className="jp-admin-mod__preview-facts">
              <Badge variant="gray">{job.job_type}</Badge>
              <Badge variant="gray">{job.work_mode}</Badge>
              {job.location_city && <Badge variant="gray">{job.location_city}</Badge>}
              {job.salary_min > 0 && (
                <Badge variant="gray">
                  {job.salary_currency} {job.salary_min.toLocaleString()}–{job.salary_max.toLocaleString()}
                </Badge>
              )}
              <Badge variant="gray">
                {job.experience_min}-{job.experience_max} yrs
              </Badge>
            </div>
            {job.description && <p className="jp-admin-mod__preview-text">{job.description}</p>}
            {job.requirements && (
              <>
                <p className="jp-job-detail__subheading">Requirements</p>
                <p className="jp-admin-mod__preview-text">{job.requirements}</p>
              </>
            )}
            {parseSkills(job.skills_json).length > 0 && (
              <>
                <p className="jp-job-detail__subheading">Skills</p>
                <div className="jp-admin-mod__preview-facts">
                  {parseSkills(job.skills_json).map((skill) => (
                    <Badge key={skill} variant="gray">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </>
            )}
          </div>
        )}
      </CardBody>
    </Card>
  )
}
