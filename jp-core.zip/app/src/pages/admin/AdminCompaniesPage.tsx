import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  bulkCompanyAction,
  eraseCompany,
  exportCompanyData,
  importCompaniesCsv,
  listAdminCompanies,
  setCompanyStatus,
  verifyCompany,
  type BulkCompanyAction,
} from '@/features/admin/api'
import { CsvImportPanel } from '@/components/admin/CsvImportPanel'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'

const STATUS_VARIANT = { active: 'success', suspended: 'error', pending: 'warning' } as const

export function AdminCompaniesPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [q, setQ] = useState('')
  // Root-cause fix (batch 33): listAdminCompanies()'s status param has
  // always been real and accepted by the backend (see class-jp-api.php's
  // admin_companies() query building), but this page only ever sent `q` —
  // an admin reviewing pending/suspended companies had to scan the whole
  // unfiltered list by eye instead of filtering server-side.
  const [status, setStatus] = useState('')
  const [selected, setSelected] = useState<Set<number>>(new Set())

  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-companies', q, status],
    queryFn: () => listAdminCompanies({ q: q || undefined, status: status || undefined }),
    placeholderData: (prev) => prev,
  })

  function invalidate() {
    queryClient.invalidateQueries({ queryKey: ['admin-companies'] })
  }

  const statusMutation = useMutation({
    mutationFn: ({ id, status }: { id: number; status: 'active' | 'suspended' | 'pending' }) => setCompanyStatus(id, status),
    onSuccess: (result) => {
      toast.success(result.message)
      invalidate()
    },
    onError: () => toast.error('Could not update this company\'s status.'),
  })

  const verifyMutation = useMutation({
    mutationFn: ({ id, verify }: { id: number; verify: boolean }) => verifyCompany(id, verify),
    onSuccess: (result) => {
      toast.success(result.message)
      invalidate()
    },
    onError: () => toast.error('Could not update verification status.'),
  })

  // Root-cause fix (found while auditing the still-pending WP-Admin-only
  // settings areas — "Privacy/Offboarding"): admin company data export/
  // erase existed as backend logic (JP_Privacy) with no way to reach it
  // from this SPA at all. Added as row actions here rather than a
  // separate page since both operate on one company already listed here.
  const exportMutation = useMutation({
    mutationFn: ({ id, name }: { id: number; name: string }) => exportCompanyData(id, name),
    onSuccess: () => toast.success('Export downloaded.'),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not export company data.'),
  })

  const eraseMutation = useMutation({
    mutationFn: eraseCompany,
    onSuccess: (result) => {
      toast.success(result.message)
      invalidate()
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not erase this company.'),
  })

  // Root-cause fix (enterprise gap-analysis: bulk actions were present for
  // Jobs/Applications only). Combines status + verification into one
  // toolbar since bulkCompanyAction() dispatches both from the same route.
  const bulkMutation = useMutation({
    mutationFn: ({ ids, action }: { ids: number[]; action: BulkCompanyAction }) => bulkCompanyAction(ids, action),
    onSuccess: (result) => {
      toast.success(result.message)
      setSelected(new Set())
      invalidate()
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Bulk action failed.'),
  })

  function toggleSelected(id: number) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  return (
    <div>
      <WorkspacePageHeader tone="admin"
        title="Companies"
        subtitle={data ? `${data.companies.length} compan${data.companies.length === 1 ? 'y' : 'ies'} shown.` : undefined}
      />

      <CsvImportPanel
        title="Bulk import companies"
        hint="CSV columns: name, owner_email (required), website, industry, phone, headquarters, size_range, founded_year. An owner_email that doesn't match an existing account creates one (jp_recruiter role) and emails them login credentials; one that already owns a company is skipped."
        onImport={importCompaniesCsv}
        onDone={invalidate}
      />

      <div style={{ display: 'flex', gap: 16, marginBottom: 16, flexWrap: 'wrap' }}>
        <div style={{ maxWidth: 320, flex: '1 1 240px' }}>
          <Input label="Search by name or email" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="jp-form-group" style={{ minWidth: 160 }}>
          <label className="jp-label" htmlFor="company-status-filter">
            Status
          </label>
          <select
            id="company-status-filter"
            className="jp-input"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="">Any</option>
            <option value="active">Active</option>
            <option value="pending">Pending</option>
            <option value="suspended">Suspended</option>
          </select>
        </div>
      </div>

      {selected.size > 0 && (
        <Card style={{ marginBottom: 16 }}>
          <CardBody className="jp-job-row">
            <span className="jp-job-company">{selected.size} selected</span>
            <div className="jp-job-badges">
              <Button
                size="sm"
                variant="outline"
                loading={bulkMutation.isPending}
                onClick={() => bulkMutation.mutate({ ids: [...selected], action: 'verify' })}
              >
                Verify
              </Button>
              <Button
                size="sm"
                variant="outline"
                loading={bulkMutation.isPending}
                onClick={() => bulkMutation.mutate({ ids: [...selected], action: 'unverify' })}
              >
                Unverify
              </Button>
              <Button
                size="sm"
                variant="outline"
                loading={bulkMutation.isPending}
                onClick={() => bulkMutation.mutate({ ids: [...selected], action: 'activate' })}
              >
                Reinstate
              </Button>
              <Button
                size="sm"
                variant="danger"
                loading={bulkMutation.isPending}
                onClick={() => {
                  if (window.confirm(`Suspend ${selected.size} compan${selected.size === 1 ? 'y' : 'ies'}?`)) {
                    bulkMutation.mutate({ ids: [...selected], action: 'suspend' })
                  }
                }}
              >
                Suspend
              </Button>
            </div>
          </CardBody>
        </Card>
      )}

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load companies.</p>}

      {!isLoading && data && data.companies.length === 0 && (
        <EmptyState title="No companies match this search" description="Try a different name or email, or clear the search." />
      )}

      {!isLoading && data && data.companies.length > 0 && (
        <div className="jp-jobs-list">
          {data.companies.map((c) => (
            <Card key={c.id}>
              <CardBody>
                <div className="jp-job-row">
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                    <input
                      type="checkbox"
                      checked={selected.has(c.id)}
                      onChange={() => toggleSelected(c.id)}
                      aria-label={`Select ${c.name}`}
                      style={{ marginTop: 4 }}
                    />
                    <div>
                      <h2 className="jp-job-title">
                        {c.name}
                        {c.is_featured === 1 && (
                          <Badge variant="accent" style={{ marginLeft: 8 }}>
                            Featured
                          </Badge>
                        )}
                      </h2>
                      <p className="jp-job-company">
                        {c.owner_name} ({c.owner_email}) · {c.active_jobs} active jobs
                      </p>
                      <p className="jp-job-company">
                        {[c.industry, c.headquarters, c.size_range].filter(Boolean).join(' · ') || 'No profile details on file'}
                        {c.reviews_count > 0 && ` · ${c.rating_avg.toFixed(1)}★ (${c.reviews_count} review${c.reviews_count === 1 ? '' : 's'})`}
                      </p>
                    </div>
                  </div>
                  <div className="jp-job-badges" style={{ flexWrap: 'wrap', justifyContent: 'flex-end' }}>
                    <Badge variant={STATUS_VARIANT[c.status] ?? 'gray'}>{c.status}</Badge>
                    {c.is_verified === 1 && <Badge variant="info">Verified</Badge>}
                    <Button
                      variant="ghost"
                      size="sm"
                      loading={verifyMutation.isPending && verifyMutation.variables?.id === c.id}
                      onClick={() => verifyMutation.mutate({ id: c.id, verify: c.is_verified !== 1 })}
                    >
                      {c.is_verified === 1 ? 'Unverify' : 'Verify'}
                    </Button>
                    {c.status === 'suspended' ? (
                      <Button
                        variant="outline"
                        size="sm"
                        loading={statusMutation.isPending && statusMutation.variables?.id === c.id}
                        onClick={() => statusMutation.mutate({ id: c.id, status: 'active' })}
                      >
                        Reinstate
                      </Button>
                    ) : (
                      <Button
                        variant="danger"
                        size="sm"
                        loading={statusMutation.isPending && statusMutation.variables?.id === c.id}
                        onClick={() => {
                          if (window.confirm(`Suspend "${c.name}"?`)) statusMutation.mutate({ id: c.id, status: 'suspended' })
                        }}
                      >
                        Suspend
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      loading={exportMutation.isPending && exportMutation.variables?.id === c.id}
                      onClick={() => exportMutation.mutate({ id: c.id, name: c.name })}
                    >
                      Export data
                    </Button>
                    <Button
                      variant="danger"
                      size="sm"
                      loading={eraseMutation.isPending && eraseMutation.variables === c.id}
                      onClick={() => {
                        if (
                          window.confirm(
                            `Permanently erase "${c.name}" and ALL its jobs, applications, team members, and reviews? This cannot be undone.`,
                          )
                        ) {
                          eraseMutation.mutate(c.id)
                        }
                      }}
                    >
                      Erase (offboard)
                    </Button>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
