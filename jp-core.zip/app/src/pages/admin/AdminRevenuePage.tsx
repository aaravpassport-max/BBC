import { useMutation, useQuery } from '@tanstack/react-query'
import { getAdminRevenue } from '@/features/admin/revenueApi'
import { downloadCsvExport } from '@/features/admin/api'
import { Skeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { StatCard } from '@/components/ui/StatCard'
import { AnalyticsKpiGrid } from '@/components/recruiter/AnalyticsKpiGrid'
import { Button } from '@/components/ui/Button'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import '../dashboard/ProfilePage.css'
import './AdminRevenuePage.css'

/**
 * Phase 3 redesign (Tier A, redesign-plan §AdminRevenuePage) — was a flat
 * stat-tile grid + a plain key/value list, with no way to actually act on
 * the numbers. Revenue is a flagship admin metric, so this now groups the
 * KPIs into real sections (recurring-revenue health vs. subscription-status
 * health), turns MRR-by-plan into an actual visual breakdown (CSS bar chart
 * driven by each plan's real share of total MRR — no invented data, just a
 * width computed from the numbers already in the response), and wires the
 * "export" the plan called for to the CSV export endpoint that already
 * exists and already supports a 'payments' type (features/admin/api.ts's
 * downloadCsvExport, the same one AdminSystemPage uses) rather than a
 * decorative button with no handler. A time-series trend chart was
 * deliberately NOT added — admin_revenue_dashboard() returns point-in-time
 * aggregates only, no historical series exists in the schema to chart, and
 * fabricating one would violate the no-placeholder-content rule.
 */
export function AdminRevenuePage() {
  const toast = useToast()
  const { data, isLoading, error } = useQuery({
    queryKey: ['admin-revenue'],
    queryFn: getAdminRevenue,
    retry: false,
  })

  const exportMutation = useMutation({
    mutationFn: () => downloadCsvExport('payments'),
    onSuccess: () => toast.success('Payments export downloaded.'),
    onError: (e) => toast.error(e instanceof Error ? e.message : 'Export failed.'),
  })

  if (isLoading) {
    return (
      <div>
        <Skeleton height={28} width="30%" />
        <div style={{ height: 16 }} />
        <AnalyticsKpiGrid>
          {Array.from({ length: 8 }).map((_, i) => (
            <Skeleton key={i} height={90} width="100%" />
          ))}
        </AnalyticsKpiGrid>
      </div>
    )
  }

  if (error) {
    const message =
      error instanceof ApiError && error.status === 403
        ? "You don't have access to the revenue dashboard."
        : 'Could not load revenue data.'
    return (
      <p className="jp-jobs-error" role="alert">
        {message}
      </p>
    )
  }

  if (!data) return null

  const planEntries = Object.entries(data.mrr_by_plan).sort(([, a], [, b]) => b - a)
  const totalPlanMrr = planEntries.reduce((sum, [, amount]) => sum + amount, 0)

  return (
    <div>
      <WorkspacePageHeader tone="admin"
        title="Revenue"
        subtitle="Subscription revenue and churn across the platform."
        actions={
          <Button variant="outline" loading={exportMutation.isPending} onClick={() => exportMutation.mutate()}>
            Export payments CSV
          </Button>
        }
      />

      <h2 className="jp-revenue__section-heading">Recurring revenue</h2>
      <AnalyticsKpiGrid className="jp-revenue__stats">
        <StatCard label="MRR" value={`${data.currency} ${data.mrr.toLocaleString()}`} tone="primary" />
        <StatCard label="ARPU" value={`${data.currency} ${data.arpu.toLocaleString()}`} />
        <StatCard label="Revenue collected (30d)" value={`${data.currency} ${data.revenue_collected_30d.toLocaleString()}`} tone="success" />
        <StatCard
          label="Churn rate (30d)"
          value={`${data.churn_rate_pct_30d}%`}
          tone={data.churn_rate_pct_30d > 5 ? 'error' : data.churn_rate_pct_30d > 0 ? 'warning' : 'success'}
        />
      </AnalyticsKpiGrid>

      <h2 className="jp-revenue__section-heading">Subscription health</h2>
      <AnalyticsKpiGrid className="jp-revenue__stats">
        <StatCard label="Active subscriptions" value={data.active_subscriptions} tone="success" />
        <StatCard label="New subscriptions (30d)" value={data.new_subscriptions_30d} tone="success" />
        <StatCard label="Cancelled (30d)" value={data.cancelled_30d} tone={data.cancelled_30d > 0 ? 'warning' : 'default'} />
        <StatCard label="Trial subscriptions" value={data.trial_subscriptions} />
        <StatCard label="Past due" value={data.past_due_subscriptions} tone={data.past_due_subscriptions > 0 ? 'error' : 'default'} />
      </AnalyticsKpiGrid>

      <SectionCard title="MRR by plan">
        {planEntries.length === 0 ? (
          <EmptyState title="No plan revenue yet" description="MRR breakdown by plan will appear once subscriptions are active." />
        ) : (
          <div className="jp-revenue__bars">
            {planEntries.map(([plan, amount]) => {
              const pct = totalPlanMrr > 0 ? Math.round((amount / totalPlanMrr) * 100) : 0
              return (
                <div key={plan} className="jp-revenue__bar-row">
                  <div className="jp-revenue__bar-label">
                    <span>{plan}</span>
                    <span className="jp-revenue__bar-value">
                      {data.currency} {amount.toLocaleString()} · {pct}%
                    </span>
                  </div>
                  <div className="jp-revenue__bar-track">
                    <div className="jp-revenue__bar-fill" style={{ width: `${pct}%` }} />
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </SectionCard>

      <p className="jp-job-company" style={{ marginTop: 16, fontSize: 12 }}>
        {data.note}
      </p>
    </div>
  )
}
