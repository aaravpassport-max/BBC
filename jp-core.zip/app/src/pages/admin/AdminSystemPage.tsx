import { useState, type FormEvent } from 'react'
import { useMutation } from '@tanstack/react-query'
import { downloadCsvExport, flushCache, pushBroadcast, triggerBackup, type CsvExportType } from '@/features/admin/api'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { PageHeader } from '@/components/ui/PageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import '../dashboard/ProfilePage.css'
import './AdminSystemPage.css'

const EXPORT_TYPES: { key: CsvExportType; label: string }[] = [
  { key: 'jobs', label: 'Jobs' },
  { key: 'applications', label: 'Applications' },
  { key: 'candidates', label: 'Candidates' },
  { key: 'payments', label: 'Payments' },
]

export function AdminSystemPage() {
  const toast = useToast()
  const [broadcast, setBroadcast] = useState({ title: '', body: '', segment: 'all' })
  const [exportingType, setExportingType] = useState<CsvExportType | null>(null)

  const flushMutation = useMutation({
    mutationFn: flushCache,
    onSuccess: (result) => toast.success(result.message),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Cache flush failed.'),
  })

  const backupMutation = useMutation({
    mutationFn: triggerBackup,
    onSuccess: (result) => toast.success(result.message),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Backup trigger failed.'),
  })

  const broadcastMutation = useMutation({
    mutationFn: () => pushBroadcast(broadcast.title, broadcast.body, broadcast.segment),
    onSuccess: (result) => {
      toast.success(result.message)
      setBroadcast({ title: '', body: '', segment: 'all' })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Broadcast failed.'),
  })

  const exportMutation = useMutation({
    mutationFn: downloadCsvExport,
    onSettled: () => setExportingType(null),
    onError: (e) => toast.error(e instanceof Error ? e.message : 'Export failed.'),
  })

  function onBroadcastSubmit(e: FormEvent) {
    e.preventDefault()
    if (!broadcast.title.trim() || !broadcast.body.trim()) {
      toast.error('Title and message are required.')
      return
    }
    broadcastMutation.mutate()
  }

  function runExport(type: CsvExportType) {
    setExportingType(type)
    exportMutation.mutate(type)
  }

  return (
    <div>
      <PageHeader title="System" subtitle="Maintenance actions, data exports, and push broadcasts." />

      <SectionCard title="Maintenance" className="jp-admin-system__section">
          <div style={{ display: 'flex', gap: 12 }}>
            <Button variant="outline" loading={flushMutation.isPending} onClick={() => flushMutation.mutate()}>
              Flush cache
            </Button>
            <Button variant="outline" loading={backupMutation.isPending} onClick={() => backupMutation.mutate()}>
              Trigger backup now
            </Button>
          </div>
      </SectionCard>

      <SectionCard title="CSV export" className="jp-admin-system__section">
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
            {EXPORT_TYPES.map((t) => (
              <Button
                key={t.key}
                variant="outline"
                loading={exportingType === t.key && exportMutation.isPending}
                onClick={() => runExport(t.key)}
              >
                Export {t.label}
              </Button>
            ))}
          </div>
      </SectionCard>

      <SectionCard title="Push notification broadcast">
          <form onSubmit={onBroadcastSubmit} className="jp-profile-grid">
            <Input
              label="Title"
              value={broadcast.title}
              onChange={(e) => setBroadcast((b) => ({ ...b, title: e.target.value }))}
            />
            <div className="jp-form-group">
              <label className="jp-label" htmlFor="broadcast-segment">
                Segment
              </label>
              <select
                id="broadcast-segment"
                className="jp-input"
                value={broadcast.segment}
                onChange={(e) => setBroadcast((b) => ({ ...b, segment: e.target.value }))}
              >
                <option value="all">All subscribers</option>
                <option value="candidates">Candidates</option>
                <option value="recruiters">Recruiters</option>
              </select>
            </div>
            <div className="jp-form-group" style={{ gridColumn: '1 / -1' }}>
              <label className="jp-label" htmlFor="broadcast-body">
                Message
              </label>
              <textarea
                id="broadcast-body"
                className="jp-textarea"
                value={broadcast.body}
                onChange={(e) => setBroadcast((b) => ({ ...b, body: e.target.value }))}
              />
            </div>
            <div style={{ alignSelf: 'end' }}>
              <Button type="submit" variant="accent" loading={broadcastMutation.isPending}>
                Send broadcast
              </Button>
            </div>
          </form>
      </SectionCard>
    </div>
  )
}
