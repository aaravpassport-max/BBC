import { useEffect, useState, type FormEvent } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  getAdminSettings,
  saveAdminSettings,
  runJobFeedImport,
  getJobFeedStatus,
  type AdminSettings,
} from '@/features/admin/api'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import '../dashboard/ProfilePage.css'
import './AdminSettingsPage.css'

const SAFE_FIELDS: { key: keyof AdminSettings; label: string; type?: string }[] = [
  { key: 'jp_site_name', label: 'Site name' },
  { key: 'jp_jobs_per_page', label: 'Jobs per page', type: 'number' },
  { key: 'jp_auto_approve_jobs', label: 'Auto-approve jobs (1/0)' },
  { key: 'jp_auto_approve_reviews', label: 'Auto-approve reviews (1/0)' },
  { key: 'jp_og_default_image', label: 'Default social share image URL' },
  { key: 'jp_maintenance_mode', label: 'Maintenance mode (1/0)' },
  { key: 'jp_gst_number', label: 'GST number' },
  { key: 'jp_stripe_publishable_key', label: 'Stripe publishable key' },
  { key: 'jp_invoice_prefix', label: 'Invoice number prefix' },
  { key: 'jp_smtp_from_name', label: 'Email "from" name' },
  { key: 'jp_smtp_from_email', label: 'Email "from" address', type: 'email' },
  { key: 'jp_ga4_measurement_id', label: 'GA4 measurement ID' },
  { key: 'jp_social_twitter', label: 'Twitter/X URL' },
  { key: 'jp_social_linkedin', label: 'LinkedIn URL' },
  { key: 'jp_social_facebook', label: 'Facebook URL' },
  { key: 'jp_sms_provider', label: 'SMS provider' },
  { key: 'jp_openai_model', label: 'OpenAI model (used for resume parsing / AI features)' },
  { key: 'jp_max_login_attempts', label: 'Max login attempts', type: 'number' },
  { key: 'jp_lockout_duration', label: 'Lockout duration (seconds)', type: 'number' },
  { key: 'jp_require_2fa_admin', label: 'Require 2FA for admins (1/0)' },
  // Ghost-setting fix (write-key/read-key audit sweep): these four were
  // previously readable and consumed by real backend logic but had no
  // way to change them short of a raw database edit.
  { key: 'jp_job_expiry_days', label: 'Job auto-expiry (days)', type: 'number' },
  { key: 'jp_resume_max_size_mb', label: 'Resume upload max size (MB)', type: 'number' },
  { key: 'jp_cors_allowed_origin', label: 'CORS allowed origin (blank = same-origin only)' },
  { key: 'jp_uninstall_wipe_data', label: 'Wipe all data on plugin uninstall (1/0)' },
]

const SECRET_FIELDS: { key: keyof AdminSettings; label: string }[] = [
  { key: 'jp_razorpay_key_id', label: 'Razorpay key ID' },
  { key: 'jp_razorpay_key_secret', label: 'Razorpay key secret' },
  { key: 'jp_stripe_secret_key', label: 'Stripe secret key' },
  { key: 'jp_stripe_webhook_secret', label: 'Stripe webhook signing secret' },
  { key: 'jp_smtp_password', label: 'SMTP password' },
  { key: 'jp_openai_key', label: 'OpenAI API key' },
  { key: 'jp_sms_key', label: 'SMS provider key' },
]

// E-signature (JP_ESign — DocuSign). A dedicated block rather than folding
// into SAFE_FIELDS/SECRET_FIELDS above: it needs the provider <select> and
// an explanatory paragraph (setup is a real multi-step DocuSign account
// process, not a single API key paste), same reason jp_payment_gateway got
// its own hand-written block instead of joining SAFE_FIELDS.
const ESIGN_FIELDS: { key: keyof AdminSettings; label: string }[] = [
  { key: 'jp_docusign_account_id', label: 'DocuSign Account ID' },
  { key: 'jp_docusign_integration_key', label: 'DocuSign Integration Key (Client ID)' },
  { key: 'jp_docusign_user_id', label: 'DocuSign API Username (GUID)' },
  { key: 'jp_docusign_base_uri', label: 'DocuSign base URI (blank = demo/sandbox)' },
]
const ESIGN_SECRET_FIELDS: { key: keyof AdminSettings; label: string }[] = [
  { key: 'jp_docusign_private_key', label: 'DocuSign RSA private key (full PEM)' },
  { key: 'jp_esign_webhook_secret', label: 'Webhook shared secret (set this as the Connect callback URL\'s ?secret= value)' },
]

// Inbound job-feed import (JP_JobFeed).
const FEED_FIELDS: { key: keyof AdminSettings; label: string }[] = [
  { key: 'jp_feed_urls', label: 'Feed URLs (one per line, Indeed-schema job XML)' },
]

export function AdminSettingsPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const { data, isLoading, isError } = useQuery({ queryKey: ['admin-settings'], queryFn: getAdminSettings })
  const [form, setForm] = useState<Partial<AdminSettings>>({})

  const { data: feedStatus } = useQuery({ queryKey: ['job-feed-status'], queryFn: getJobFeedStatus })
  const runFeedMutation = useMutation({
    mutationFn: runJobFeedImport,
    onSuccess: (result) => {
      toast.success(
        `Import complete: ${result.imported} imported, ${result.updated} updated, ${result.skipped} skipped` +
          (result.errors.length ? `, ${result.errors.length} error(s).` : '.'),
      )
      queryClient.invalidateQueries({ queryKey: ['job-feed-status'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Job feed import failed.'),
  })

  // Hydrates the local editable form from server data once it loads. This is
  // an external-sync effect (server → local draft), not derivable render
  // state, so a useEffect is correct here — same pattern as ProfilePage.tsx.
  useEffect(() => {
    if (data) setForm(data)
  }, [data])

  const saveMutation = useMutation({
    mutationFn: (payload: Partial<AdminSettings>) => saveAdminSettings(payload),
    onSuccess: (result) => toast.success(result.message),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not save settings.'),
  })

  function field<K extends keyof AdminSettings>(key: K, value: AdminSettings[K]) {
    setForm((f) => ({ ...f, [key]: value }))
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    saveMutation.mutate(form)
  }

  if (isLoading) {
    return (
      <div>
        <Skeleton height={28} width="30%" />
        <div style={{ height: 16 }} />
        <Skeleton height={400} width="100%" />
      </div>
    )
  }

  // Root-cause fix: without this, a fetch failure left `data` undefined,
  // the hydration effect above never ran (its `if (data)` guard), and
  // `form` stayed at its initial `{}` — so every settings field rendered
  // blank with no error message. An admin submitting that form would
  // overwrite every real site setting with an empty value, since
  // saveAdminSettings() has no way to distinguish "intentionally cleared"
  // from "never loaded."
  if (isError) {
    return (
      <div className="jp-jobs-error" role="alert">
        Could not load site settings. Please try again.
      </div>
    )
  }

  return (
    <div>
      <WorkspacePageHeader tone="admin" title="Site settings" subtitle="Configuration, payment gateway, and integration credentials." />

      <form onSubmit={onSubmit}>
        <SectionCard title="Email delivery" className="jp-admin-settings__section">
            <p className="jp-job-company">
              {data?.jp_smtp_constants_configured
                ? 'SMTP server (host/port/credentials) is configured via wp-config.php constants.'
                : 'SMTP server is not configured. Set JP_SMTP_HOST, JP_SMTP_USER, JP_SMTP_PASS, JP_SMTP_PORT, and JP_SMTP_FROM in wp-config.php — the "from" name/address below only control the display header, not delivery.'}
            </p>
        </SectionCard>

        <SectionCard title="General & integrations" className="jp-admin-settings__section">
          <div className="jp-profile-grid">
            <div className="jp-form-group">
              <label className="jp-label" htmlFor="jp_payment_gateway">
                Active payment gateway
              </label>
              <select
                id="jp_payment_gateway"
                className="jp-input"
                value={form.jp_payment_gateway ?? 'razorpay'}
                onChange={(e) => field('jp_payment_gateway', e.target.value as never)}
              >
                <option value="razorpay">Razorpay</option>
                <option value="stripe">Stripe</option>
              </select>
            </div>
            {SAFE_FIELDS.map((f) => (
              <Input
                key={f.key}
                label={f.label}
                type={f.type ?? 'text'}
                value={String(form[f.key] ?? '')}
                onChange={(e) => field(f.key, e.target.value as never)}
              />
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Secrets & API keys" className="jp-admin-settings__section">
          <div className="jp-profile-grid">
            <p style={{ gridColumn: '1 / -1' }} className="jp-job-company">
              Secret values are shown masked. Leave a field unchanged to keep the existing secret, or enter a new value
              to replace it.
            </p>
            {SECRET_FIELDS.map((f) => (
              <Input
                key={f.key}
                label={f.label}
                type="text"
                value={String(form[f.key] ?? '')}
                onChange={(e) => field(f.key, e.target.value as never)}
              />
            ))}
          </div>
        </SectionCard>

        <SectionCard title="E-signature (offer letters)" className="jp-admin-settings__section">
          <div className="jp-profile-grid">
            <p style={{ gridColumn: '1 / -1' }} className="jp-job-company">
              {data?.jp_esign_configured
                ? 'DocuSign is configured — generated offer letters are sent for a real e-signature in addition to the in-app accept/decline flow.'
                : 'Not configured — offer letters use the in-app "I Agree" accept/decline flow only. Set a provider and all DocuSign credentials below to enable real e-signature.'}
            </p>
            <div className="jp-form-group">
              <label className="jp-label" htmlFor="jp_esign_provider">
                E-signature provider
              </label>
              <select
                id="jp_esign_provider"
                className="jp-input"
                value={form.jp_esign_provider ?? 'none'}
                onChange={(e) => field('jp_esign_provider', e.target.value as never)}
              >
                <option value="none">None (in-app accept/decline only)</option>
                <option value="docusign">DocuSign</option>
              </select>
            </div>
            {ESIGN_FIELDS.map((f) => (
              <Input
                key={f.key}
                label={f.label}
                type="text"
                value={String(form[f.key] ?? '')}
                onChange={(e) => field(f.key, e.target.value as never)}
              />
            ))}
            {ESIGN_SECRET_FIELDS.map((f) => (
              <div key={f.key} className="jp-form-group" style={{ gridColumn: '1 / -1' }}>
                <label className="jp-label" htmlFor={f.key}>
                  {f.label}
                </label>
                <textarea
                  id={f.key}
                  className="jp-textarea"
                  rows={f.key === 'jp_docusign_private_key' ? 6 : 2}
                  value={String(form[f.key] ?? '')}
                  onChange={(e) => field(f.key, e.target.value as never)}
                />
              </div>
            ))}
          </div>
        </SectionCard>

        <SectionCard title="Inbound job feed import" className="jp-admin-settings__section">
          <div className="jp-profile-grid">
            <p style={{ gridColumn: '1 / -1' }} className="jp-job-company">
              Pulls jobs from external Indeed-schema job XML feeds on an hourly cron, in addition to the site&apos;s own
              recruiter-posted listings. Imported jobs go to the moderation queue unless auto-publish is enabled below.
            </p>
            {FEED_FIELDS.map((f) => (
              <div key={f.key} className="jp-form-group" style={{ gridColumn: '1 / -1' }}>
                <label className="jp-label" htmlFor={f.key}>
                  {f.label}
                </label>
                <textarea
                  id={f.key}
                  className="jp-textarea"
                  rows={3}
                  value={String(form[f.key] ?? '')}
                  onChange={(e) => field(f.key, e.target.value as never)}
                />
              </div>
            ))}
            <label className="jp-checkbox">
              <input
                type="checkbox"
                checked={form.jp_feed_auto_publish === '1'}
                onChange={(e) => field('jp_feed_auto_publish', (e.target.checked ? '1' : '') as never)}
              />
              Auto-publish imported jobs (skip moderation queue)
            </label>
            <div style={{ gridColumn: '1 / -1', display: 'flex', alignItems: 'center', gap: 12 }}>
              <Button type="button" variant="outline" size="sm" loading={runFeedMutation.isPending} onClick={() => runFeedMutation.mutate()}>
                Run import now
              </Button>
              {feedStatus?.ran_at && (
                <span className="jp-job-company">
                  Last run: {new Date(feedStatus.ran_at).toLocaleString()} — {feedStatus.imported} imported,{' '}
                  {feedStatus.updated} updated, {feedStatus.skipped} skipped
                  {feedStatus.errors.length > 0 ? `, ${feedStatus.errors.length} error(s)` : ''}.
                </span>
              )}
            </div>
          </div>
        </SectionCard>

        <Button type="submit" variant="accent" loading={saveMutation.isPending}>
          Save settings
        </Button>
      </form>
    </div>
  )
}
