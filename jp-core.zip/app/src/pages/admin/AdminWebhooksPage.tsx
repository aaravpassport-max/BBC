import { useState, type FormEvent } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import type { WebhookDeliveryRow } from '@/features/admin/api'
import { createWebhook, deleteWebhook, listWebhooks, listWebhookDeliveries, testWebhook, WEBHOOK_EVENTS } from '@/features/admin/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './AdminWebhooksPage.css'

function deliveryVariant(status: WebhookDeliveryRow['status']): 'success' | 'error' | 'gray' {
  if (status === 'delivered') return 'success'
  if (status === 'failed') return 'error'
  return 'gray'
}

/**
 * New (batch 18): jp_webhook_deliveries has been written to on every
 * dispatch/retry attempt since it was created, but nothing ever read it
 * back — an admin could create/test/delete a webhook but never see
 * whether it was actually delivering successfully in production.
 */
function WebhookDeliveryLog({ webhookId }: { webhookId: string }) {
  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-webhook-deliveries', webhookId],
    queryFn: () => listWebhookDeliveries(webhookId),
  })

  if (isLoading) return <p className="jp-job-company">Loading delivery log…</p>
  if (isError) return <p className="jp-jobs-error" role="alert">Could not load the delivery log.</p>
  if (!data || data.length === 0) return <p className="jp-job-company">No deliveries recorded yet.</p>

  return (
    <div className="jp-admin-webhooks__log">
      {data.map((d) => (
        <div key={d.id} className="jp-admin-webhooks__log-item">
          <div className="jp-admin-webhooks__log-row">
            <Badge variant={deliveryVariant(d.status)}>{d.status}</Badge>
            <span className="jp-job-company">{d.event}</span>
            <span className="jp-job-company">{d.http_code ?? '—'}</span>
            <span className="jp-job-company">attempt {d.attempt}</span>
            <span className="jp-job-company">{new Date(d.created_at).toLocaleString()}</span>
            {d.status === 'pending' && d.next_retry_at && (
              <span className="jp-job-company">retry at {new Date(d.next_retry_at).toLocaleString()}</span>
            )}
          </div>
          {/* Root-cause fix: jp_webhook_deliveries.response_body is a real
              column (the target's raw response body, or the transport error
              message) returned by admin_webhook_deliveries()'s SELECT, but
              never shown — an admin debugging a failing endpoint had no way
              to see why it failed short of a DB query. Only shown for
              non-delivered rows, where it's actually diagnostic. */}
          {d.status !== 'delivered' && d.response_body && (
            <p className="jp-admin-webhooks__log-body">{d.response_body}</p>
          )}
        </div>
      ))}
    </div>
  )
}

export function AdminWebhooksPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [url, setUrl] = useState('')
  const [events, setEvents] = useState<string[]>([])
  const [expandedId, setExpandedId] = useState<string | null>(null)

  const { data, isLoading, isError } = useQuery({ queryKey: ['admin-webhooks'], queryFn: listWebhooks })

  const createMutation = useMutation({
    mutationFn: () => createWebhook(url, events),
    onSuccess: (result) => {
      toast.success(result.message)
      setUrl('')
      setEvents([])
      queryClient.invalidateQueries({ queryKey: ['admin-webhooks'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not create webhook.'),
  })

  const deleteMutation = useMutation({
    mutationFn: deleteWebhook,
    onSuccess: () => {
      toast.success('Webhook deleted.')
      queryClient.invalidateQueries({ queryKey: ['admin-webhooks'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not delete webhook.'),
  })

  const testMutation = useMutation({
    mutationFn: testWebhook,
    onSuccess: (result) => (result.status >= 200 && result.status < 300 ? toast.success : toast.error)(result.message),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Test delivery failed.'),
  })

  function toggleEvent(evt: string) {
    setEvents((prev) => (prev.includes(evt) ? prev.filter((e) => e !== evt) : [...prev, evt]))
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!url.trim()) {
      toast.error('Enter a target URL.')
      return
    }
    createMutation.mutate()
  }

  return (
    <div>
      <WorkspacePageHeader tone="admin" title="Webhooks" subtitle="Send platform events to external systems in real time." />

      <SectionCard title="Create a webhook" className="jp-admin-webhooks__section">
          <form onSubmit={onSubmit} className="jp-profile-grid">
            <Input
              label="Target URL"
              type="url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://example.com/webhook"
              style={{ gridColumn: '1 / -1' }}
            />
            <div className="jp-form-group" style={{ gridColumn: '1 / -1' }}>
              <span className="jp-label">Events</span>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 12 }}>
                {WEBHOOK_EVENTS.map((evt) => (
                  <label key={evt} style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 13 }}>
                    <input type="checkbox" checked={events.includes(evt)} onChange={() => toggleEvent(evt)} />
                    {evt}
                  </label>
                ))}
              </div>
            </div>
            <div style={{ alignSelf: 'end' }}>
              <Button type="submit" variant="accent" loading={createMutation.isPending}>
                Create webhook
              </Button>
            </div>
          </form>
      </SectionCard>

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 3 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load webhooks. Please try again.
        </div>
      )}

      {!isLoading && data && data.length === 0 && (
        <EmptyState title="No webhooks configured" description="Create one above to start sending platform events to an external system." />
      )}

      {!isLoading && data && data.length > 0 && (
        <div className="jp-jobs-list">
          {data.map((hook) => (
            <Card key={hook.id}>
              <CardBody>
                <div className="jp-job-row">
                  <div>
                    <p className="jp-job-title" style={{ fontSize: 14 }}>
                      {hook.url}
                    </p>
                    <p className="jp-job-company">{hook.events.join(', ') || 'No events selected'}</p>
                  </div>
                  <div className="jp-job-badges">
                    <Badge variant={hook.active ? 'success' : 'gray'}>{hook.active ? 'Active' : 'Inactive'}</Badge>
                    <Button
                      variant="outline"
                      size="sm"
                      loading={testMutation.isPending && testMutation.variables === hook.id}
                      onClick={() => testMutation.mutate(hook.id)}
                    >
                      Test
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setExpandedId((prev) => (prev === hook.id ? null : hook.id))}
                    >
                      {expandedId === hook.id ? 'Hide log' : 'Delivery log'}
                    </Button>
                    <Button
                      variant="danger"
                      size="sm"
                      loading={deleteMutation.isPending && deleteMutation.variables === hook.id}
                      onClick={() => {
                        if (window.confirm(`Delete the webhook for "${hook.url}"?`)) deleteMutation.mutate(hook.id)
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </div>
                {expandedId === hook.id && <WebhookDeliveryLog webhookId={hook.id} />}
              </CardBody>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
