import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { bulkReviewAction, listAdminReviews, reviewAction, type ReviewRow } from '@/features/admin/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { WorkspaceBulkBar } from '@/components/workspace/WorkspaceBulkBar'
import { WorkspacePagination } from '@/components/workspace/WorkspacePagination'
import { EmptyState } from '@/components/ui/EmptyState'
import { Tabs } from '@/components/ui/Tabs'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './AdminReviewsPage.css'

const TABS: { key: string; label: string }[] = [
  { key: 'pending', label: 'Pending' },
  { key: 'approved', label: 'Approved' },
  { key: 'rejected', label: 'Rejected' },
]

/** rating_wlb/growth/mgmt/pay were always in ReviewRow but only rating_overall was ever rendered. */
const SUB_RATINGS: { key: 'rating_wlb' | 'rating_growth' | 'rating_mgmt' | 'rating_pay'; label: string }[] = [
  { key: 'rating_wlb', label: 'Work-life balance' },
  { key: 'rating_growth', label: 'Career growth' },
  { key: 'rating_mgmt', label: 'Management' },
  { key: 'rating_pay', label: 'Compensation' },
]

function Stars({ value }: { value: number }) {
  return (
    <span aria-label={`${value} out of 5 stars`}>
      {'★'.repeat(Math.round(value))}
      {'☆'.repeat(5 - Math.round(value))}
    </span>
  )
}

export function AdminReviewModerationPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [status, setStatus] = useState('pending')
  const [page, setPage] = useState(1)
  const [selected, setSelected] = useState<Set<number>>(new Set())

  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-reviews', status, page],
    queryFn: () => listAdminReviews(status, page),
    placeholderData: (prev) => prev,
  })

  const actionMutation = useMutation({
    mutationFn: ({ id, action }: { id: number; action: 'approve' | 'reject' }) => reviewAction(id, action),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['admin-reviews'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update review.'),
  })

  // Root-cause fix (enterprise gap-analysis: bulk actions were present for
  // Jobs/Applications only — moderating reviews one at a time doesn't
  // scale once a queue builds up). Only meaningful on the Pending tab.
  const bulkMutation = useMutation({
    mutationFn: ({ ids, action }: { ids: number[]; action: 'approve' | 'reject' }) => bulkReviewAction(ids, action),
    onSuccess: (result) => {
      toast.success(result.message)
      setSelected(new Set())
      queryClient.invalidateQueries({ queryKey: ['admin-reviews'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Bulk action failed.'),
  })

  function toggleSelected(id: number) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  return (
    <div>
      <WorkspacePageHeader tone="admin"
        title="Review moderation"
        subtitle={data ? `${data.total.toLocaleString()} ${status} review${data.total === 1 ? '' : 's'}.` : undefined}
      />

      <Tabs
        label="Review status"
        activeKey={status}
        onChange={(key) => {
          setStatus(key)
          setPage(1)
          setSelected(new Set())
        }}
        items={TABS}
      />

      {status === 'pending' && (
        <WorkspaceBulkBar count={selected.size} onClear={() => setSelected(new Set())}>
          <Button
            size="sm"
            variant="accent"
            loading={bulkMutation.isPending}
            onClick={() => bulkMutation.mutate({ ids: [...selected], action: 'approve' })}
          >
            Approve
          </Button>
          <Button
            size="sm"
            variant="danger"
            loading={bulkMutation.isPending}
            onClick={() => bulkMutation.mutate({ ids: [...selected], action: 'reject' })}
          >
            Reject
          </Button>
        </WorkspaceBulkBar>
      )}

      {isLoading && (
        <div className="jp-workspace-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <p className="jp-jobs-error" role="alert">
          Could not load reviews.
        </p>
      )}

      {!isLoading && data && data.reviews.length === 0 && (
        <EmptyState title={`No ${status} reviews`} description="Reviews will appear here as candidates submit them." />
      )}

      {!isLoading && data && data.reviews.length > 0 && (
        <>
          <div className="jp-workspace-list">
            {data.reviews.map((r: ReviewRow) => (
              <Card key={r.id} className="jp-workspace-record jp-workspace-record--admin">
                <CardBody>
                  <div className="jp-job-row">
                    <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                      {status === 'pending' && (
                        <input
                          type="checkbox"
                          checked={selected.has(r.id)}
                          onChange={() => toggleSelected(r.id)}
                          aria-label={`Select review ${r.id}`}
                          style={{ marginTop: 4 }}
                        />
                      )}
                      <div>
                        <p className="jp-job-title" style={{ fontSize: 14 }}>
                          {r.title || '(untitled review)'} — <Stars value={r.rating_overall} />
                        </p>
                        <p className="jp-job-company">
                          {r.company_name ?? `Company #${r.company_id}`} · {r.is_anonymous ? 'Anonymous' : (r.reviewer_name ?? 'Unknown')} ·{' '}
                          {r.employment_type} {r.job_title ? `· ${r.job_title}` : ''}
                        </p>
                        <p className="jp-job-company">
                          Submitted {new Date(r.created_at).toLocaleDateString()}
                          {r.helpful_count > 0 && ` · ${r.helpful_count} found this helpful`}
                        </p>
                        {r.pros && <p className="jp-job-company">👍 {r.pros}</p>}
                        {r.cons && <p className="jp-job-company">👎 {r.cons}</p>}
                        <div className="jp-admin-reviews__sub-ratings">
                          {SUB_RATINGS.map(({ key, label }) => (
                            <span key={key} className="jp-admin-reviews__sub-rating">
                              {label}: <strong>{Number(r[key]) > 0 ? Number(r[key]).toFixed(1) : '—'}</strong>
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                    <div className="jp-job-badges">
                      <Badge variant={r.status === 'approved' ? 'success' : r.status === 'rejected' ? 'error' : 'gray'}>
                        {r.status}
                      </Badge>
                      {r.status === 'pending' && (
                        <>
                          <Button
                            variant="accent"
                            size="sm"
                            loading={actionMutation.isPending && actionMutation.variables?.id === r.id && actionMutation.variables.action === 'approve'}
                            onClick={() => actionMutation.mutate({ id: r.id, action: 'approve' })}
                          >
                            Approve
                          </Button>
                          <Button
                            variant="danger"
                            size="sm"
                            loading={actionMutation.isPending && actionMutation.variables?.id === r.id && actionMutation.variables.action === 'reject'}
                            onClick={() => actionMutation.mutate({ id: r.id, action: 'reject' })}
                          >
                            Reject
                          </Button>
                        </>
                      )}
                    </div>
                  </div>
                </CardBody>
              </Card>
            ))}
          </div>

          <WorkspacePagination
            page={page}
            totalPages={Math.max(1, Math.ceil(data.total / 20))}
            onPageChange={setPage}
          />
        </>
      )}
    </div>
  )
}
