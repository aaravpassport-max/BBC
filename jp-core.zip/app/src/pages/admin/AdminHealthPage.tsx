import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { generateVapidKeys, getAdminHealth, triggerBackup } from '@/features/admin/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Skeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import '../dashboard/ProfilePage.css'
import './AdminHealthPage.css'

function BoolBadge({ ok }: { ok: boolean }) {
  return <Badge variant={ok ? 'success' : 'error'}>{ok ? 'OK' : 'Problem'}</Badge>
}

export function AdminHealthPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-health'],
    queryFn: getAdminHealth,
    refetchInterval: 60_000,
  })

  // Root-cause fix (roadmap re-audit): class-jp-settings.php's "Security"
  // wp-admin page showed backup status (latest/count/next) and a VAPID-key
  // generator with no REST/SPA equivalent — see admin_health()'s
  // backup_* / vapid_configured fields and the new admin_generate_vapid()
  // route this pairs with.
  const backupMutation = useMutation({
    mutationFn: triggerBackup,
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['admin-health'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Backup trigger failed.'),
  })

  const vapidMutation = useMutation({
    mutationFn: generateVapidKeys,
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['admin-health'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not generate VAPID keys.'),
  })

  if (isLoading) {
    return (
      <div>
        <Skeleton height={28} width="30%" />
        <div style={{ height: 16 }} />
        <Skeleton height={200} width="100%" />
      </div>
    )
  }

  if (isError || !data) {
    return <p className="jp-jobs-error" role="alert">Could not load system health.</p>
  }

  return (
    <div>
      <WorkspacePageHeader tone="admin" title="System health" subtitle="Live status of infrastructure, integrations, and scheduled jobs." />

      <SectionCard title="Environment" className="jp-admin-health__section">
        <div className="jp-profile-grid">
          <div>
            <p className="jp-job-company">PHP</p>
            <p className="jp-job-title">{data.php_version}</p>
          </div>
          <div>
            <p className="jp-job-company">WordPress</p>
            <p className="jp-job-title">{data.wp_version}</p>
          </div>
          <div>
            <p className="jp-job-company">MySQL</p>
            <p className="jp-job-title">{data.mysql_version}</p>
          </div>
          <div>
            <p className="jp-job-company">JP Core version</p>
            <p className="jp-job-title">{data.jp_version}</p>
          </div>
          <div>
            <p className="jp-job-company">React app version</p>
            <p className="jp-job-title">
              {data.react_app_version ?? 'unknown'}{' '}
              {data.react_version_status === 'mismatch' && <Badge variant="error">Mismatch</Badge>}
              {data.react_version_status === 'in_sync' && <Badge variant="success">In sync</Badge>}
            </p>
          </div>
          <div>
            <p className="jp-job-company">Database</p>
            <BoolBadge ok={data.db_ok} />
          </div>
          <div>
            <p className="jp-job-company">Cache driver</p>
            <p className="jp-job-title">{data.cache_driver}</p>
          </div>
          <div>
            <p className="jp-job-company">Uploads writable</p>
            <BoolBadge ok={data.uploads_writable} />
          </div>
          <div>
            <p className="jp-job-company">Dead-letter queue</p>
            <p className="jp-job-title">{data.queue_dead_letters}</p>
          </div>
        </div>
      </SectionCard>

      <SectionCard
        title="Cron jobs"
        action={<Badge variant={data.cron_health === 'ok' ? 'success' : 'warning'}>{data.cron_health}</Badge>}
        className="jp-admin-health__section"
      >
        <div className="jp-jobs-list">
          {data.cron_jobs.length === 0 && <p className="jp-job-company">No cron jobs reporting.</p>}
          {data.cron_jobs.map((job) => (
            <Card key={job.job}>
              <CardBody>
                <div className="jp-job-row">
                  <div>
                    <p className="jp-job-title" style={{ fontSize: 14 }}>
                      {job.job}
                    </p>
                    <p className="jp-job-company">Last run: {job.last_run ?? 'never'}</p>
                    {job.last_error && <p className="jp-job-company">{job.last_error}</p>}
                  </div>
                  <div className="jp-job-badges">
                    {job.overdue && <Badge variant="warning">Overdue</Badge>}
                    <Badge variant={job.last_status === 'ok' ? 'success' : 'error'}>{job.last_status}</Badge>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      </SectionCard>

      <SectionCard title="Platform totals" className="jp-admin-health__section">
        <div className="jp-profile-grid">
          <div>
            <p className="jp-job-company">Active jobs</p>
            <p className="jp-job-title">{data.active_jobs}</p>
          </div>
          <div>
            <p className="jp-job-company">Total users</p>
            <p className="jp-job-title">{data.total_users}</p>
          </div>
          <div>
            <p className="jp-job-company">Total applications</p>
            <p className="jp-job-title">{data.total_applications}</p>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Integrations" className="jp-admin-health__section">
        <div className="jp-profile-grid">
          <div>
            <p className="jp-job-company">Elasticsearch</p>
            <p className="jp-job-title">{data.elasticsearch_configured ? 'Configured' : 'Not configured (MySQL fallback active)'}</p>
          </div>
          <div>
            <p className="jp-job-company">Redis</p>
            <p className="jp-job-title">{data.redis_configured ? 'Configured' : 'Not configured (transient fallback active)'}</p>
          </div>
          <div>
            <p className="jp-job-company">TCPDF</p>
            <p className="jp-job-title">{data.tcpdf_available ? 'Installed' : 'Not installed (PDF features fall back to HTML)'}</p>
          </div>
          <div>
            <p className="jp-job-company">pdftotext</p>
            <p className="jp-job-title">{data.pdftotext_available ? 'Available' : 'Not available (resume parsing falls back to manual fill)'}</p>
          </div>
          <div>
            <p className="jp-job-company">WP Cron</p>
            <p className="jp-job-title">{data.wp_cron_enabled ? 'Enabled' : 'Disabled (use server cron)'}</p>
          </div>
          <div>
            <p className="jp-job-company">SMS provider</p>
            <p className="jp-job-title">{data.sms_provider_configured ?? 'Not configured (optional)'}</p>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Backups & push keys">
        <div className="jp-profile-grid">
          <div>
            <p className="jp-job-company">Latest backup</p>
            <p className="jp-job-title">{data.backup_latest ?? 'Never'}</p>
          </div>
          <div>
            <p className="jp-job-company">Backup count</p>
            <p className="jp-job-title">{data.backup_count}</p>
          </div>
          <div>
            <p className="jp-job-company">Next scheduled</p>
            <p className="jp-job-title">{data.backup_next ?? 'Unknown'}</p>
          </div>
          <div style={{ alignSelf: 'end' }}>
            <Button variant="outline" size="sm" loading={backupMutation.isPending} onClick={() => backupMutation.mutate()}>
              Run backup now
            </Button>
          </div>
          <div>
            <p className="jp-job-company">VAPID push keys</p>
            <p className="jp-job-title">{data.vapid_configured ? 'Generated' : 'Not generated'}</p>
          </div>
          <div style={{ alignSelf: 'end' }}>
            <Button
              variant="outline"
              size="sm"
              loading={vapidMutation.isPending}
              onClick={() => {
                if (
                  !data.vapid_configured ||
                  window.confirm('Regenerate VAPID keys? Existing push subscriptions will stop working until users resubscribe.')
                ) {
                  vapidMutation.mutate()
                }
              }}
            >
              {data.vapid_configured ? 'Regenerate keys' : 'Generate keys'}
            </Button>
          </div>
        </div>
      </SectionCard>
    </div>
  )
}
