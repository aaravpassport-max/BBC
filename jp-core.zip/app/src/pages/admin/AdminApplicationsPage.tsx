import { useState } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { listAdminApplications, type AdminApplicationRow } from '@/features/admin/api'
import {
  addApplicationNote,
  getApplicationDetail,
  moveApplicationStage,
} from '@/features/recruiter/applicationsApi'
import type { ApplicationStage } from '@/features/applications/api'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { WorkspacePagination } from '@/components/workspace/WorkspacePagination'
import { FilterBar } from '@/components/ui/FilterBar'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import '../recruiter/RecruiterApplicationsPage.css'

const STAGES: ApplicationStage[] = [
  'applied', 'shortlisted', 'viewed', 'phone_screen', 'interview',
  'assessment', 'offer', 'hired', 'rejected', 'withdrawn',
]

const STAGE_VARIANT: Record<ApplicationStage, 'gray' | 'info' | 'success' | 'warning' | 'error'> = {
  applied: 'gray', shortlisted: 'info', viewed: 'gray', phone_screen: 'info',
  interview: 'info', assessment: 'info', offer: 'success', hired: 'success',
  rejected: 'error', withdrawn: 'warning',
}

/**
 * New in batch 39 (admin operations-center depth). Closes the
 * pre-delivery audit's "Support Scenario 1: record stuck in state" —
 * before this page, an admin who needed to look into or force-resolve a
 * specific application (a candidate/recruiter support ticket, a stuck
 * pipeline entry) had no way to even FIND that application without
 * already knowing its numeric id, despite every relevant write endpoint
 * (stage change, notes) already granting a full admin override
 * server-side. This page is the missing search/discovery step, not a
 * general-purpose company HR browser — it's reached via search (by
 * candidate name/email, job title, company name, or a bare numeric id),
 * not a default full listing, since browsing every company's pipeline
 * indiscriminately isn't a legitimate platform-admin use case the way
 * looking up one flagged record for support is.
 */
export function AdminApplicationsPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [q, setQ] = useState('')
  const [submittedQ, setSubmittedQ] = useState('')
  const [stage, setStage] = useState<ApplicationStage | ''>('')
  const [expandedId, setExpandedId] = useState<number | null>(null)
  const [noteDraft, setNoteDraft] = useState('')
  // Root-cause fix (batch 34): listAdminApplications()'s page param and the
  // response's real `total` count have always existed (admin_applications()
  // is a real 20-per-page LIMIT/OFFSET query server-side), but this page
  // never sent page or showed a page count — any search matching more than
  // 20 applications had every result past the first 20 permanently
  // unreachable, with no indication more even existed.
  const [page, setPage] = useState(1)

  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-applications', submittedQ, stage, page],
    queryFn: () => listAdminApplications({ q: submittedQ || undefined, stage: stage || undefined, page }),
    enabled: submittedQ !== '' || stage !== '',
    placeholderData: (prev) => prev,
  })

  const totalPages = data ? Math.max(1, Math.ceil(data.total / 20)) : 1

  const detailQuery = useQuery({
    queryKey: ['admin-application-detail', expandedId],
    queryFn: () => getApplicationDetail(expandedId as number),
    enabled: expandedId !== null,
  })

  const stageMutation = useMutation({
    mutationFn: ({ id, newStage }: { id: number; newStage: ApplicationStage }) => moveApplicationStage(id, newStage),
    onSuccess: () => {
      toast.success('Stage updated.')
      queryClient.invalidateQueries({ queryKey: ['admin-applications'] })
      queryClient.invalidateQueries({ queryKey: ['admin-application-detail'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update the stage.'),
  })

  const noteMutation = useMutation({
    mutationFn: ({ id, note }: { id: number; note: string }) => addApplicationNote(id, note),
    onSuccess: () => {
      setNoteDraft('')
      toast.success('Note added.')
      queryClient.invalidateQueries({ queryKey: ['admin-application-detail'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not add the note.'),
  })

  return (
    <div>
      <WorkspacePageHeader tone="admin"
        title="Applications"
        subtitle="Look up a specific application across the whole platform for support or moderation — search by candidate, job, company, or application id."
      />

      <form
        className="jp-workspace-toolbar"
        onSubmit={(e) => {
          e.preventDefault()
          setSubmittedQ(q.trim())
          setPage(1)
        }}
      >
        <FilterBar
          search={
            <Input
              label="Search"
              placeholder="Candidate name/email, job title, company name, or application id"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          }
          filters={
            <>
              <div className="jp-form-group">
                <label className="jp-label" htmlFor="admin-app-stage">
                  Stage
                </label>
                <select
                  id="admin-app-stage"
                  className="jp-input"
                  value={stage}
                  onChange={(e) => {
                    setStage(e.target.value as ApplicationStage | '')
                    setPage(1)
                  }}
                >
                  <option value="">Any stage</option>
                  {STAGES.map((s) => (
                    <option key={s} value={s}>
                      {s.replace('_', ' ')}
                    </option>
                  ))}
                </select>
              </div>
              <Button type="submit" variant="accent" loading={(submittedQ !== '' || stage !== '') && isLoading}>
                Search
              </Button>
            </>
          }
        />
      </form>

      {submittedQ === '' && stage === '' && (
        <EmptyState
          title="Search to find an application"
          description="Enter a candidate name/email, job title, company name, or application id, or filter by stage, to look up a specific application."
        />
      )}

      {(submittedQ !== '' || stage !== '') && isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 3 }).map((_, i) => <CardSkeleton key={i} />)}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not search applications.</p>}

      {!isLoading && data && data.applications.length === 0 && (
        <EmptyState title="No matching applications" description="Try a different search term or stage filter." />
      )}

      {!isLoading && data && data.applications.length > 0 && (
        <div className="jp-workspace-list">
          {data.applications.map((app: AdminApplicationRow) => (
            <Card key={app.id} className="jp-workspace-record jp-workspace-record--admin">
              <CardBody>
                <div className="jp-job-row">
                  <div>
                    <h2 className="jp-job-title">
                      #{app.id} — {app.candidate_name || 'Unknown candidate'}
                    </h2>
                    <p className="jp-job-company">
                      {app.candidate_email} · Applied for {app.job_title || '(deleted job)'} at {app.company_name || '(deleted company)'}
                    </p>
                    <p className="jp-app-detail__meta">
                      Applied {new Date(app.created_at.replace(' ', 'T')).toLocaleDateString()} · last updated{' '}
                      {new Date(app.updated_at.replace(' ', 'T')).toLocaleString()}
                      {typeof app.match_score === 'number' ? ` · ${app.match_score}% match` : ''}
                    </p>
                  </div>
                  <div className="jp-job-badges" style={{ flexDirection: 'column', alignItems: 'flex-end', gap: 8 }}>
                    <Badge variant={STAGE_VARIANT[app.stage]}>{app.stage.replace('_', ' ')}</Badge>
                    <Button
                      type="button"
                      variant="ghost"
                      size="sm"
                      onClick={() => setExpandedId(expandedId === app.id ? null : app.id)}
                      aria-expanded={expandedId === app.id}
                    >
                      {expandedId === app.id ? 'Hide details' : 'View / manage'}
                    </Button>
                  </div>
                </div>

                {expandedId === app.id && (
                  <div className="jp-app-detail" style={{ marginTop: 16, paddingTop: 16, borderTop: '1px solid var(--jp-gray-200)' }}>
                    {detailQuery.isLoading && <p className="jp-app-detail__loading">Loading…</p>}
                    {detailQuery.isError && <p className="jp-jobs-error" role="alert">Could not load this application.</p>}
                    {detailQuery.data && (
                      <div className="jp-app-detail__grid">
                        <section className="jp-app-detail__section">
                          <h3 className="jp-app-detail__heading">Force stage change</h3>
                          <select
                            className="jp-input"
                            value={detailQuery.data.stage}
                            disabled={stageMutation.isPending}
                            onChange={(e) => stageMutation.mutate({ id: app.id, newStage: e.target.value as ApplicationStage })}
                            aria-label="Force application stage"
                          >
                            {STAGES.map((s) => (
                              <option key={s} value={s}>{s.replace('_', ' ')}</option>
                            ))}
                          </select>
                          <p className="jp-app-detail__empty" style={{ marginTop: 6 }}>
                            Use this to unstick an application a recruiter has reported as stuck, or to correct a
                            moderation issue — this bypasses the normal recruiter pipeline.
                          </p>
                        </section>

                        <section className="jp-app-detail__section">
                          <h3 className="jp-app-detail__heading">Stage history</h3>
                          {detailQuery.data.stage_history.length > 0 ? (
                            <ol className="jp-app-detail__timeline">
                              {[...detailQuery.data.stage_history].reverse().map((h, i) => (
                                <li key={i}>
                                  <span className="jp-app-detail__timeline-stage">{h.stage.replace('_', ' ')}</span>
                                  <span className="jp-app-detail__meta">
                                    {new Date(h.timestamp.replace(' ', 'T')).toLocaleString()}
                                  </span>
                                  {h.note && <p className="jp-app-detail__text">{h.note}</p>}
                                </li>
                              ))}
                            </ol>
                          ) : (
                            <p className="jp-app-detail__empty">No stage changes recorded yet.</p>
                          )}
                        </section>

                        <section className="jp-app-detail__section jp-app-detail__section--wide">
                          <h3 className="jp-app-detail__heading">Internal notes</h3>
                          {detailQuery.data.notes.length > 0 ? (
                            <ul className="jp-app-detail__notes">
                              {detailQuery.data.notes.map((n, i) => (
                                <li key={i}>
                                  <p className="jp-app-detail__text">{n.text}</p>
                                  <span className="jp-app-detail__meta">
                                    {new Date(n.created_at.replace(' ', 'T')).toLocaleString()}
                                  </span>
                                </li>
                              ))}
                            </ul>
                          ) : (
                            <p className="jp-app-detail__empty">No internal notes yet.</p>
                          )}
                          <form
                            className="jp-app-detail__inline-form"
                            onSubmit={(e) => {
                              e.preventDefault()
                              const t = noteDraft.trim()
                              if (t) noteMutation.mutate({ id: app.id, note: t })
                            }}
                          >
                            <Input
                              aria-label="Add an internal note"
                              placeholder="Add a note visible to the recruiting team (e.g. why an admin intervened)"
                              value={noteDraft}
                              onChange={(e) => setNoteDraft(e.target.value)}
                              maxLength={2000}
                            />
                            <Button type="submit" size="sm" variant="outline" loading={noteMutation.isPending} disabled={!noteDraft.trim()}>
                              Add note
                            </Button>
                          </form>
                        </section>
                      </div>
                    )}
                  </div>
                )}
              </CardBody>
            </Card>
          ))}

          <WorkspacePagination page={page} totalPages={totalPages} onPageChange={setPage} />
        </div>
      )}
    </div>
  )
}
