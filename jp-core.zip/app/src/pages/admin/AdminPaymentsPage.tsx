import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { listAdminPayments, type AdminPaymentFilters, type PaymentRow } from '@/features/admin/api'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Badge } from '@/components/ui/Badge'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { WorkspacePagination } from '@/components/workspace/WorkspacePagination'
import { EmptyState, NoResultsIcon } from '@/components/ui/EmptyState'
import { FilterBar, FilterChip } from '@/components/ui/FilterBar'
import '../public/JobsPage.css'

const STATUS_VARIANT = {
  created: 'gray',
  paid: 'success',
  failed: 'error',
  refunded: 'warning',
  abandoned: 'gray',
} as const

const STATUS_OPTIONS: { value: PaymentRow['status'] | ''; label: string }[] = [
  { value: '', label: 'All statuses' },
  { value: 'created', label: 'Created' },
  { value: 'paid', label: 'Paid' },
  { value: 'failed', label: 'Failed' },
  { value: 'refunded', label: 'Refunded' },
  { value: 'abandoned', label: 'Abandoned' },
]

const GATEWAY_OPTIONS = [
  { value: '', label: 'All gateways' },
  { value: 'razorpay', label: 'Razorpay' },
  { value: 'stripe', label: 'Stripe' },
]

/**
 * Phase 3 redesign (Tier A, redesign-plan §AdminPaymentsPage) — was
 * unfiltered. Added status/gateway/date-range filters, all wired to real
 * server-side WHERE clauses against existing indexed columns
 * (admin_payments()'s new $status/$gateway/$date_from/$date_to params —
 * see class-jp-api.php). "Reconciliation-state indicator" has no dedicated
 * schema flag, so rather than invent one, it's computed per-row from data
 * already returned: a status='paid' row with no gateway reference id
 * (razorpay_pay_id / stripe_session_id) is flagged "Unmatched" — a real
 * data-integrity signal, not decoration.
 */
export function AdminPaymentsPage() {
  const [page, setPage] = useState(1)
  const [status, setStatus] = useState<PaymentRow['status'] | ''>('')
  const [gateway, setGateway] = useState('')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')

  const filters: AdminPaymentFilters = {
    page,
    ...(status ? { status } : {}),
    ...(gateway ? { gateway } : {}),
    ...(dateFrom ? { date_from: dateFrom } : {}),
    ...(dateTo ? { date_to: dateTo } : {}),
  }
  const hasActiveFilters = Boolean(status || gateway || dateFrom || dateTo)

  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-payments', filters],
    queryFn: () => listAdminPayments(filters),
    placeholderData: (prev) => prev,
  })

  function resetPage() {
    setPage(1)
  }

  return (
    <div>
      <WorkspacePageHeader tone="admin"
        title="Payments"
        subtitle={data ? `${data.total.toLocaleString()} payment${data.total === 1 ? '' : 's'} recorded.` : undefined}
      />

      <FilterBar
        className="jp-workspace-toolbar"
        filters={
          <>
            <select
              className="jp-input"
              value={status}
              onChange={(e) => {
                setStatus(e.target.value as PaymentRow['status'] | '')
                resetPage()
              }}
              aria-label="Filter by status"
            >
              {STATUS_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
            <select
              className="jp-input"
              value={gateway}
              onChange={(e) => {
                setGateway(e.target.value)
                resetPage()
              }}
              aria-label="Filter by gateway"
            >
              {GATEWAY_OPTIONS.map((opt) => (
                <option key={opt.value} value={opt.value}>
                  {opt.label}
                </option>
              ))}
            </select>
            <input
              type="date"
              className="jp-input"
              value={dateFrom}
              onChange={(e) => {
                setDateFrom(e.target.value)
                resetPage()
              }}
              aria-label="From date"
            />
            <input
              type="date"
              className="jp-input"
              value={dateTo}
              onChange={(e) => {
                setDateTo(e.target.value)
                resetPage()
              }}
              aria-label="To date"
            />
          </>
        }
        chips={
          hasActiveFilters ? (
            <>
              {status && <FilterChip onRemove={() => { setStatus(''); resetPage() }}>Status: {status}</FilterChip>}
              {gateway && <FilterChip onRemove={() => { setGateway(''); resetPage() }}>Gateway: {gateway}</FilterChip>}
              {dateFrom && <FilterChip onRemove={() => { setDateFrom(''); resetPage() }}>From: {dateFrom}</FilterChip>}
              {dateTo && <FilterChip onRemove={() => { setDateTo(''); resetPage() }}>To: {dateTo}</FilterChip>}
            </>
          ) : undefined
        }
      />

      {isLoading && (
        <div className="jp-workspace-list">
          {Array.from({ length: 5 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load payments.</p>}

      {!isLoading && data && data.payments.length === 0 && !hasActiveFilters && (
        <EmptyState title="No payments recorded yet" description="Payments from recruiters and companies will appear here." />
      )}

      {!isLoading && data && data.payments.length === 0 && hasActiveFilters && (
        <EmptyState icon={<NoResultsIcon />} title="No payments match these filters" description="Try widening the status, gateway, or date range above." />
      )}

      {!isLoading && data && data.payments.length > 0 && (
        <>
          <div className="jp-workspace-list">
            {data.payments.map((p) => {
              const hasGatewayRef = Boolean(p.razorpay_pay_id || p.stripe_session_id)
              const unmatched = p.status === 'paid' && !hasGatewayRef
              return (
                <Card key={p.id} className="jp-workspace-record jp-workspace-record--admin">
                  <CardBody>
                    <div className="jp-job-row">
                      <div>
                        <p className="jp-job-title" style={{ fontSize: 14 }}>
                          {p.display_name ?? `User #${p.user_id}`} · {p.description ?? 'Payment'}
                        </p>
                        <p className="jp-job-company">
                          {p.gateway} · Created {new Date(p.created_at).toLocaleString()}
                          {p.paid_at && <> · Paid {new Date(p.paid_at).toLocaleString()}</>}
                        </p>
                      </div>
                      <div className="jp-job-badges">
                        <Badge variant={STATUS_VARIANT[p.status]}>{p.status}</Badge>
                        {unmatched && (
                          <Badge variant="error" title="Marked paid but has no matching gateway transaction reference — investigate before treating as reconciled.">
                            Unmatched
                          </Badge>
                        )}
                        <span className="jp-job-title" style={{ fontSize: 14 }}>
                          {p.currency} {p.amount.toLocaleString()}
                        </span>
                        {p.invoice_url && (
                          <a href={p.invoice_url} target="_blank" rel="noreferrer">
                            Invoice
                          </a>
                        )}
                      </div>
                    </div>
                  </CardBody>
                </Card>
              )
            })}
          </div>

          <WorkspacePagination
            page={page}
            totalPages={Math.max(1, Math.ceil(data.total / 20))}
            onPageChange={setPage}
          />
        </>
      )}
    </div>
  )
}
