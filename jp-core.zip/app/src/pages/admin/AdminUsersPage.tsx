import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  bulkUserAction,
  changeUserRole,
  getUserCapabilities,
  impersonateStart,
  listAdminUsers,
  updateUserCapability,
  type BulkUserAction,
} from '@/features/admin/api'
import type { JpRole } from '@/lib/auth/types'
import { useAuth } from '@/lib/auth/AuthContext'
import { IMPERSONATION_FLAG_KEY } from '@/components/layout/ImpersonationBanner'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Badge } from '@/components/ui/Badge'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { PageHeader } from '@/components/ui/PageHeader'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'

const ROLES: JpRole[] = ['jp_job_seeker', 'jp_recruiter', 'jp_team_manager', 'jp_staff', 'jp_admin_manager', 'administrator']

/**
 * Batch 28 — custom RBAC. Renders one checkbox per capability the backend
 * will accept an override for (JP_Roles::overridable_capabilities() —
 * the most sensitive caps, e.g. jp_manage_users itself, are never offered
 * here at all, not just disabled, since the endpoint would reject them
 * anyway). "Checked" reflects the EFFECTIVE permission (role default,
 * unless this user has their own override), and a badge marks anything
 * that differs from the role default so an admin can see at a glance
 * which permissions were hand-tuned for this one person.
 */
function CapabilitiesPanel({ userId, userName }: { userId: number; userName: string }) {
  const toast = useToast()
  const queryClient = useQueryClient()
  const { data, isLoading, isError } = useQuery({
    queryKey: ['user-capabilities', userId],
    queryFn: () => getUserCapabilities(userId),
  })

  const toggleMutation = useMutation({
    mutationFn: ({ capability, action }: { capability: string; action: 'grant' | 'revoke' | 'reset' }) =>
      updateUserCapability(userId, capability, action),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['user-capabilities', userId] }),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update this permission.'),
  })

  if (isLoading) return <p className="jp-job-company">Loading permissions…</p>
  if (isError || !data) return <p className="jp-jobs-error" role="alert">Could not load permissions for {userName}.</p>

  function toggle(cap: string, isBaseDefault: boolean, currentlyEffective: boolean) {
    const desired = !currentlyEffective
    // If the desired state matches what the role would grant anyway,
    // resetting (deleting the override) is more correct than storing a
    // redundant explicit grant/deny that would silently survive a future
    // role change — see JP_Api::admin_update_capability()'s docblock.
    const action: 'grant' | 'revoke' | 'reset' = desired === isBaseDefault ? 'reset' : desired ? 'grant' : 'revoke'
    toggleMutation.mutate({ capability: cap, action })
  }

  return (
    <div className="jp-jobs-save-search-form" style={{ marginTop: 12 }}>
      <p className="jp-job-company">
        Role default permissions are pre-checked. Toggle any box to grant or revoke that one permission for{' '}
        {userName} specifically, without changing their role.
      </p>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(220px, 1fr))', gap: '4px 12px' }}>
        {data.overridable.map((cap) => {
          const isBaseDefault = data.base_caps.includes(cap)
          const hasOverride = Object.prototype.hasOwnProperty.call(data.overrides, cap)
          const effective = hasOverride ? data.overrides[cap] : isBaseDefault
          return (
            <label key={cap} style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 13 }}>
              <input
                type="checkbox"
                checked={effective}
                disabled={toggleMutation.isPending && toggleMutation.variables?.capability === cap}
                onChange={() => toggle(cap, isBaseDefault, effective)}
              />
              {cap}
              {hasOverride && <Badge variant={effective ? 'info' : 'gray'}>custom</Badge>}
            </label>
          )
        })}
      </div>
    </div>
  )
}

export function AdminUsersPage() {
  const toast = useToast()
  const navigate = useNavigate()
  const { refresh, config } = useAuth()
  const currentUserId = config?.user_id
  const queryClient = useQueryClient()
  const [q, setQ] = useState('')
  const [roleFilter, setRoleFilter] = useState('')
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [permissionsOpenFor, setPermissionsOpenFor] = useState<number | null>(null)

  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-users', q, roleFilter],
    queryFn: () => listAdminUsers({ q: q || undefined, role: roleFilter || undefined }),
    placeholderData: (prev) => prev,
  })

  function invalidate() {
    queryClient.invalidateQueries({ queryKey: ['admin-users'] })
  }

  const roleMutation = useMutation({
    mutationFn: ({ id, role }: { id: number; role: JpRole }) => changeUserRole(id, role),
    onSuccess: (result) => {
      toast.success(result.message)
      invalidate()
    },
    onError: () => toast.error('Could not update this user\'s role.'),
  })

  // Root-cause fix (enterprise gap-analysis: "AdminUsersPage lacks bulk
  // actions — an asymmetry once bulk actions exist for Jobs/Applications").
  // Mirrors RecruiterJobsPage.tsx's selection + toolbar pattern exactly.
  const bulkMutation = useMutation({
    mutationFn: ({ ids, action }: { ids: number[]; action: BulkUserAction }) => bulkUserAction(ids, action),
    onSuccess: (result) => {
      toast.success(result.message)
      setSelected(new Set())
      invalidate()
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Bulk action failed.'),
  })

  const impersonateMutation = useMutation({
    mutationFn: impersonateStart,
    onSuccess: async () => {
      sessionStorage.setItem(IMPERSONATION_FLAG_KEY, '1')
      await refresh()
      navigate('/dashboard')
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not start impersonation.'),
  })

  function toggleSelected(id: number) {
    setSelected((prev) => {
      const next = new Set(prev)
      if (next.has(id)) next.delete(id)
      else next.add(id)
      return next
    })
  }

  return (
    <div>
      <PageHeader
        title="Users"
        subtitle={data ? `${data.users.length} user${data.users.length === 1 ? '' : 's'} shown.` : undefined}
      />
      <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 16 }}>
        <div style={{ maxWidth: 320, flex: '1 1 240px' }}>
          <Input label="Search by name or email" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div style={{ width: 200 }}>
          <label className="jp-label" htmlFor="jp-role-filter">
            Filter by role
          </label>
          <select id="jp-role-filter" className="jp-input" value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)}>
            <option value="">All roles</option>
            {ROLES.map((role) => (
              <option key={role} value={role}>
                {role}
              </option>
            ))}
          </select>
        </div>
      </div>

      {selected.size > 0 && (
        <Card style={{ marginBottom: 16 }}>
          <CardBody className="jp-job-row">
            <span className="jp-job-company">{selected.size} selected</span>
            <div className="jp-job-badges">
              <Button
                size="sm"
                variant="outline"
                loading={bulkMutation.isPending}
                onClick={() => bulkMutation.mutate({ ids: [...selected], action: 'activate' })}
              >
                Reactivate
              </Button>
              <Button
                size="sm"
                variant="danger"
                loading={bulkMutation.isPending}
                onClick={() => {
                  if (window.confirm(`Suspend ${selected.size} account(s)? They will be signed out and unable to log in until reactivated.`)) {
                    bulkMutation.mutate({ ids: [...selected], action: 'suspend' })
                  }
                }}
              >
                Suspend
              </Button>
            </div>
          </CardBody>
        </Card>
      )}

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load users.</p>}

      {!isLoading && data && data.users.length === 0 && (
        <EmptyState title="No users match this search" description="Try a different name, email, or role filter." />
      )}

      {!isLoading && data && data.users.length > 0 && (
        <div className="jp-jobs-list">
          {data.users.map((u) => (
            <Card key={u.id}>
              <CardBody>
                <div className="jp-job-row">
                  <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
                    {u.id !== currentUserId && (
                      <input
                        type="checkbox"
                        checked={selected.has(u.id)}
                        onChange={() => toggleSelected(u.id)}
                        aria-label={`Select ${u.name}`}
                        style={{ marginTop: 4 }}
                      />
                    )}
                    <div>
                      <h2 className="jp-job-title">
                        {u.name} {u.is_suspended && <Badge variant="error">Suspended</Badge>}
                      </h2>
                      <p className="jp-job-company">
                        {u.email} · Joined {new Date(u.registered).toLocaleDateString()}
                      </p>
                    </div>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                    <select
                      className="jp-input"
                      style={{ width: 180, minWidth: 0 }}
                      value={ROLES.includes(u.role as JpRole) ? u.role : ''}
                      disabled={roleMutation.isPending && roleMutation.variables?.id === u.id}
                      onChange={(e) => roleMutation.mutate({ id: u.id, role: e.target.value as JpRole })}
                      aria-label={`Role for ${u.name}`}
                    >
                      {!ROLES.includes(u.role as JpRole) && <option value="">{u.role}</option>}
                      {ROLES.map((role) => (
                        <option key={role} value={role}>
                          {role}
                        </option>
                      ))}
                    </select>
                    {u.role !== 'administrator' && (
                      <Button
                        variant="outline"
                        size="sm"
                        loading={impersonateMutation.isPending && impersonateMutation.variables === u.id}
                        onClick={() => {
                          if (window.confirm(`Impersonate ${u.name}? Their session will be active for up to 30 minutes.`)) {
                            impersonateMutation.mutate(u.id)
                          }
                        }}
                      >
                        Impersonate
                      </Button>
                    )}
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setPermissionsOpenFor(permissionsOpenFor === u.id ? null : u.id)}
                    >
                      {permissionsOpenFor === u.id ? 'Hide permissions' : 'Permissions'}
                    </Button>
                  </div>
                </div>
                {permissionsOpenFor === u.id && <CapabilitiesPanel userId={u.id} userName={u.name} />}
              </CardBody>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
