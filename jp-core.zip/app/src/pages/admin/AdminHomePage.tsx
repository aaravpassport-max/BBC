import { useQuery } from '@tanstack/react-query'
import { Link } from 'react-router-dom'
import { getAdminHealth, getAdminStats, getPendingJobs } from '@/features/admin/api'
import { Skeleton } from '@/components/ui/Skeleton'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { StatCard } from '@/components/ui/StatCard'
import { Badge } from '@/components/ui/Badge'
import { EmptyState } from '@/components/ui/EmptyState'
import { ListRow } from '@/components/ui/ListRow'
import '../dashboard/DashboardHomePage.css'
import '../public/JobsPage.css'
import './AdminHomePage.css'

/**
 * Admin panel landing (jp_staff / jp_admin_manager / administrator) — the
 * replacement for wp-admin's dashboard widget per the standalone-plugin
 * mandate (JP-PLATFORM-ROADMAP.md Part 3.3). Backed by the real, 60s-cached
 * GET /admin/stats endpoint (admin_stats() in class-jp-api.php).
 */
export function AdminHomePage() {
  const { data, isLoading, isError } = useQuery({ queryKey: ['admin-stats'], queryFn: getAdminStats })
  const { data: pendingJobs, isLoading: pendingLoading } = useQuery({
    queryKey: ['admin-pending-jobs'],
    queryFn: getPendingJobs,
  })
  // Phase 3 redesign pass — the audit flagged this page as needing a real
  // KPI dashboard beyond a thin welcome, specifically calling out an
  // error/health summary. Reuses the existing /admin/health endpoint
  // (built for AdminHealthPage) rather than duplicating its logic — this
  // page just surfaces the compact signal (cron health, dead letters,
  // recent-error count), the full detail stays on AdminHealthPage.
  const { data: health, isLoading: healthLoading } = useQuery({ queryKey: ['admin-health'], queryFn: getAdminHealth })

  const tiles: { label: string; value: number | string; tone?: 'default' | 'primary' | 'success' | 'warning' | 'error' }[] = data
    ? [
        { label: 'Active jobs', value: data.total_jobs },
        { label: 'Pending jobs', value: data.pending_jobs, tone: data.pending_jobs > 0 ? 'warning' : 'default' },
        { label: 'Companies', value: data.total_companies },
        { label: 'Candidates', value: data.total_candidates },
        { label: 'Applications', value: data.total_apps },
        { label: 'New signups today', value: data.new_signups_today, tone: data.new_signups_today > 0 ? 'success' : 'default' },
        { label: 'Revenue this month', value: `₹${data.revenue_month.toLocaleString()}`, tone: 'success' },
      ]
    : []

  const healthIssues = health
    ? (health.cron_health === 'degraded' ? 1 : 0) + (health.queue_dead_letters > 0 ? 1 : 0) + (health.recent_errors.length > 0 ? 1 : 0) + (!health.db_ok ? 1 : 0)
    : 0

  return (
    <div className="jp-dashboard">
      <WorkspacePageHeader
        tone="admin"
        title="Admin overview"
        subtitle="Platform health, moderation queue, and live operational metrics."
        stats={
          isLoading ? (
            <>
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} height={72} width="100%" />
              ))}
            </>
          ) : (
            tiles.map((tile) => <StatCard key={tile.label} label={tile.label} value={tile.value} tone={tile.tone} />)
          )
        }
      />
      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load platform stats. Please try again.
        </div>
      )}

      <SectionCard
        title="System health"
        action={
          <Link to="/admin/health" className="jp-admin-home__link">
            Full health report →
          </Link>
        }
        className="jp-admin-home__section"
      >
        {healthLoading && <Skeleton height={40} width="100%" />}
        {!healthLoading && health && (
          <div className="jp-admin-home__health-row">
            <Badge variant={health.db_ok ? 'success' : 'error'}>{health.db_ok ? 'Database OK' : 'Database issue'}</Badge>
            <Badge variant={health.cron_health === 'ok' ? 'success' : 'warning'}>
              Cron {health.cron_health === 'ok' ? 'on schedule' : 'degraded'}
            </Badge>
            <Badge variant={health.queue_dead_letters > 0 ? 'warning' : 'success'}>
              {health.queue_dead_letters > 0 ? `${health.queue_dead_letters} stuck jobs` : 'No stuck jobs'}
            </Badge>
            <Badge variant={health.recent_errors.length > 0 ? 'warning' : 'success'}>
              {health.recent_errors.length > 0 ? `${health.recent_errors.length} recent errors` : 'No recent errors'}
            </Badge>
            {healthIssues === 0 && <span className="jp-admin-home__health-ok">Everything looks healthy.</span>}
          </div>
        )}
      </SectionCard>

      <SectionCard
        title="Needs attention: jobs awaiting review"
        action={
          <Link to="/admin/jobs" className="jp-admin-home__link">
            Go to moderation →
          </Link>
        }
        className="jp-admin-home__section"
      >
        {pendingLoading && <Skeleton height={80} width="100%" />}
        {!pendingLoading && pendingJobs && pendingJobs.length === 0 && (
          <EmptyState title="Nothing waiting on you" description="All submitted jobs have been reviewed." />
        )}
        {!pendingLoading && pendingJobs && pendingJobs.length > 0 && (
          <div className="jp-admin-home__pending-list">
            {pendingJobs.slice(0, 5).map((job) => (
              <ListRow
                key={job.id}
                to={`/admin/jobs`}
                title={job.title}
                meta={`${job.company_name} · posted by ${job.posted_by_name ?? 'unknown'}`}
                aside={<Badge variant="warning">Awaiting review</Badge>}
              />
            ))}
            {pendingJobs.length > 5 && (
              <p className="jp-job-company">
                +{pendingJobs.length - 5} more awaiting review — <Link to="/admin/jobs">view all</Link>
              </p>
            )}
          </div>
        )}
      </SectionCard>
    </div>
  )
}
