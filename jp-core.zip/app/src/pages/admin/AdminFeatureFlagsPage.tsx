import { useState, type FormEvent } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  deleteFeatureFlag,
  listFeatureFlags,
  saveFeatureFlag,
  type FeatureFlagRow,
} from '@/features/admin/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { PageHeader } from '@/components/ui/PageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import './AdminFeatureFlagsPage.css'

/**
 * Admin screen for JP_FeatureFlags — the last piece of the gap this class
 * was built to close (see class-jp-featureflags.php's own docblock): the
 * jp_feature_flags table and its admin CRUD logic have existed since an
 * earlier pass, but with no way to reach them from the WP-Admin-free React
 * SPA at all (only wp_ajax_* handlers existed, unreachable from here — see
 * the REST routes newly registered in class-jp-api.php this pass). Lets an
 * admin flip a flag_key on/off, optionally gated to a plan_tier, without a
 * code deploy — the actual point of this table existing in the first place.
 */
export function AdminFeatureFlagsPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [flagKey, setFlagKey] = useState('')
  const [planTier, setPlanTier] = useState('all')
  const [description, setDescription] = useState('')

  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-feature-flags'],
    queryFn: listFeatureFlags,
  })

  const saveMutation = useMutation({
    mutationFn: (vars: { flag_key: string; is_enabled: boolean; plan_tier: string; description: string }) =>
      saveFeatureFlag(vars.flag_key, vars.is_enabled, vars.plan_tier, vars.description),
    onSuccess: (result) => {
      toast.success(result.message)
      queryClient.invalidateQueries({ queryKey: ['admin-feature-flags'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not save flag.'),
  })

  const deleteMutation = useMutation({
    mutationFn: deleteFeatureFlag,
    onSuccess: () => {
      toast.success('Flag deleted.')
      queryClient.invalidateQueries({ queryKey: ['admin-feature-flags'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not delete flag.'),
  })

  function onCreate(e: FormEvent) {
    e.preventDefault()
    const key = flagKey.trim()
    if (!key) {
      toast.error('Enter a flag key.')
      return
    }
    saveMutation.mutate({ flag_key: key, is_enabled: true, plan_tier: planTier.trim() || 'all', description })
    setFlagKey('')
    setPlanTier('all')
    setDescription('')
  }

  function onToggle(flag: FeatureFlagRow) {
    saveMutation.mutate({
      flag_key: flag.flag_key,
      is_enabled: !flag.is_enabled,
      plan_tier: flag.plan_tier,
      description: flag.description,
    })
  }

  const flags = data?.flags ?? []

  return (
    <div>
      <PageHeader title="Feature flags" subtitle="Turn features on or off, optionally gated to a plan tier, without a deploy." />

      <SectionCard title="Add a flag" className="jp-admin-flags__section">
          <form onSubmit={onCreate} className="jp-profile-grid">
            <Input
              label="Flag key"
              value={flagKey}
              onChange={(e) => setFlagKey(e.target.value)}
              placeholder="e.g. new_resume_builder"
            />
            <Input
              label="Plan tier (or 'all')"
              value={planTier}
              onChange={(e) => setPlanTier(e.target.value)}
              placeholder="all"
            />
            <Input
              label="Description"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="What this flag controls"
              style={{ gridColumn: '1 / -1' }}
            />
            <div style={{ alignSelf: 'end' }}>
              <Button type="submit" variant="accent" loading={saveMutation.isPending}>
                Add flag (enabled)
              </Button>
            </div>
          </form>
      </SectionCard>

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 3 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load feature flags. Please try again.
        </div>
      )}

      {!isLoading && flags.length === 0 && (
        <EmptyState title="No feature flags defined yet" description="Add one above to control a feature without a code deploy." />
      )}

      {!isLoading && flags.length > 0 && (
        <div className="jp-jobs-list">
          {flags.map((flag) => (
            <Card key={flag.id}>
              <CardBody>
                <div className="jp-job-row">
                  <div>
                    <p className="jp-job-title" style={{ fontSize: 14 }}>
                      {flag.flag_key}
                    </p>
                    <p className="jp-job-company">
                      {flag.description || 'No description'}
                      {flag.plan_tier !== 'all' ? ` — requires plan: ${flag.plan_tier}` : ''}
                    </p>
                  </div>
                  <div className="jp-job-badges">
                    <Badge variant={flag.is_enabled ? 'success' : 'gray'}>
                      {flag.is_enabled ? 'Enabled' : 'Disabled'}
                    </Badge>
                    <Button
                      variant="outline"
                      size="sm"
                      loading={saveMutation.isPending && saveMutation.variables?.flag_key === flag.flag_key}
                      onClick={() => onToggle(flag)}
                    >
                      {flag.is_enabled ? 'Disable' : 'Enable'}
                    </Button>
                    <Button
                      variant="danger"
                      size="sm"
                      loading={deleteMutation.isPending && deleteMutation.variables === flag.flag_key}
                      onClick={() => {
                        if (window.confirm(`Delete the flag "${flag.flag_key}"?`)) deleteMutation.mutate(flag.flag_key)
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
