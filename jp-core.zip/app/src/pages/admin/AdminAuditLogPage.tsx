import { useState } from 'react'
import { useMutation, useQuery } from '@tanstack/react-query'
import { downloadAuditLogCsv, getAuditLog, listAdminUsers, verifyAuditChain, type AuditChainVerifyResult, type AuditLogFilters } from '@/features/admin/api'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import '../public/JobsPage.css'
import './AdminAuditLogPage.css'

const PER_PAGE = 30

// Root-cause fix (enterprise gap-analysis: "AdminAuditLogPage is a flat
// table with no filter-by-actor/action/date-range, no export, and no
// tamper-evidence despite being the platform's core compliance artifact").
// Filtering/export were addressed first; the third item — hash-chaining
// jp_audit_log rows for tamper-evidence — is closed in batch 14: every
// JP_Security::audit() call now writes a chained hash (class-jp-security.php),
// and the "Verify integrity" control below calls the new
// GET /admin/audit-log/verify route to surface chain-intact vs.
// tampering-detected-at-entry-#N without requiring server/DB access.
export function AdminAuditLogPage() {
  const toast = useToast()
  const [page, setPage] = useState(1)
  const [actorId, setActorId] = useState('')
  const [actorLabel, setActorLabel] = useState('')
  const [actorQuery, setActorQuery] = useState('')
  const [action, setAction] = useState('')
  const [dateFrom, setDateFrom] = useState('')
  const [dateTo, setDateTo] = useState('')
  const [verifyResult, setVerifyResult] = useState<AuditChainVerifyResult | null>(null)

  // Root-cause fix (batch 22): the old "Actor user ID" field asked an admin
  // to type a raw numeric user id by hand — a number no other UI in the app
  // surfaces, so filtering by a specific person meant going to find their id
  // first. Replaced with a real name/email search backed by listAdminUsers()
  // (the same endpoint AdminUsersPage already uses), only queried once the
  // admin has typed enough to be worth a round-trip.
  const { data: actorMatches } = useQuery({
    queryKey: ['admin-audit-log-actor-search', actorQuery],
    queryFn: () => listAdminUsers({ q: actorQuery, page: 1 }),
    enabled: actorQuery.trim().length >= 2,
  })

  const filters: AuditLogFilters = {
    page,
    actor_id: actorId ? Number(actorId) : undefined,
    action: action || undefined,
    date_from: dateFrom || undefined,
    date_to: dateTo || undefined,
  }

  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-audit-log', filters.page, filters.actor_id, filters.action, filters.date_from, filters.date_to],
    queryFn: () => getAuditLog(filters),
    placeholderData: (prev) => prev,
  })

  const exportMutation = useMutation({
    mutationFn: () => downloadAuditLogCsv({ ...filters, page: undefined }),
    onSuccess: () => toast.success('Audit log CSV downloaded.'),
    onError: () => toast.error('Could not export the audit log.'),
  })

  const verifyMutation = useMutation({
    mutationFn: verifyAuditChain,
    onSuccess: (result) => {
      setVerifyResult(result)
      if (result.valid) toast.success(result.message)
      else toast.error(result.message)
    },
    onError: () => toast.error('Could not verify the audit trail.'),
  })

  function applyFilters() {
    setPage(1)
  }

  function clearFilters() {
    setActorId('')
    setActorLabel('')
    setActorQuery('')
    setAction('')
    setDateFrom('')
    setDateTo('')
    setPage(1)
  }

  function selectActor(user: { id: number; name: string; email: string }) {
    setActorId(String(user.id))
    setActorLabel(`${user.name} (${user.email})`)
    setActorQuery('')
  }

  const totalPages = data ? Math.max(1, Math.ceil(data.total / PER_PAGE)) : 1

  return (
    <div>
      <WorkspacePageHeader tone="admin"
        title="Audit log"
        subtitle={data ? `${data.total.toLocaleString()} entr${data.total === 1 ? 'y' : 'ies'} recorded.` : undefined}
        actions={
          <div style={{ display: 'flex', gap: 8 }}>
            <Button variant="outline" size="sm" loading={verifyMutation.isPending} onClick={() => verifyMutation.mutate()}>
              Verify integrity
            </Button>
            <Button variant="outline" size="sm" loading={exportMutation.isPending} onClick={() => exportMutation.mutate()}>
              Export CSV
            </Button>
          </div>
        }
      />

      {verifyResult && (
        <Card style={{ marginBottom: 16, borderColor: verifyResult.valid ? undefined : 'var(--jp-color-error, #dc2626)' }}>
          <CardBody>
            <p className="jp-job-title" style={{ fontSize: 14 }}>
              {verifyResult.valid ? '✓ Audit trail intact' : `⚠ Tampering detected at entry #${verifyResult.first_break_id}`}
            </p>
            <p className="jp-job-company">
              {verifyResult.message} ({verifyResult.total_checked.toLocaleString()} entr
              {verifyResult.total_checked === 1 ? 'y' : 'ies'} checked)
            </p>
          </CardBody>
        </Card>
      )}

      <SectionCard title="Filters" className="jp-admin-audit__section">
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'flex-end' }}>
            <div style={{ width: 220, position: 'relative' }}>
              {actorLabel ? (
                <div className="jp-form-group">
                  <span className="jp-label">Actor</span>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span className="jp-job-company" style={{ fontSize: 13 }}>{actorLabel}</span>
                    <button
                      type="button"
                      className="jp-admin-audit__actor-clear"
                      onClick={() => {
                        setActorId('')
                        setActorLabel('')
                      }}
                      aria-label="Clear actor filter"
                    >
                      ×
                    </button>
                  </div>
                </div>
              ) : (
                <Input
                  label="Actor (search by name or email)"
                  value={actorQuery}
                  onChange={(e) => setActorQuery(e.target.value)}
                  placeholder="Start typing…"
                />
              )}
              {!actorLabel && actorQuery.trim().length >= 2 && actorMatches && actorMatches.users.length > 0 && (
                <div className="jp-admin-audit__actor-dropdown">
                  {actorMatches.users.slice(0, 8).map((u) => (
                    <button key={u.id} type="button" className="jp-admin-audit__actor-option" onClick={() => selectActor(u)}>
                      {u.name} <span className="jp-job-company">({u.email})</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div style={{ width: 200 }}>
              <Input label="Action (e.g. job_status_changed)" value={action} onChange={(e) => setAction(e.target.value)} />
            </div>
            <div style={{ width: 160 }}>
              <Input label="From date" type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
            </div>
            <div style={{ width: 160 }}>
              <Input label="To date" type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
            </div>
            <Button size="sm" onClick={applyFilters}>
              Apply filters
            </Button>
            <Button size="sm" variant="ghost" onClick={clearFilters}>
              Clear
            </Button>
          </div>
      </SectionCard>

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 5 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && <p className="jp-jobs-error" role="alert">Could not load the audit log.</p>}

      {!isLoading && data && data.entries.length === 0 && (
        <EmptyState title="No audit entries match these filters" description="Try clearing a filter or widening the date range." />
      )}

      {!isLoading && data && data.entries.length > 0 && (
        <div className="jp-jobs-list">
          {data.entries.map((entry) => (
            <Card key={entry.id}>
              <CardBody>
                <p className="jp-job-title" style={{ fontSize: 14 }}>
                  {entry.display_name ?? `User #${entry.user_id}`} · {entry.action.replace(/_/g, ' ')}
                </p>
                <p className="jp-job-company">
                  {entry.object ? `${entry.object} #${entry.object_id}` : ''} · {new Date(entry.created_at).toLocaleString()}
                  {entry.ip ? ` · ${entry.ip}` : ''}
                </p>
                {entry.detail && <p className="jp-job-company">{entry.detail}</p>}
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      <div className="jp-jobs-pagination">
        <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>
          Previous
        </Button>
        <span>
          Page {page} of {totalPages} ({data?.total ?? 0} total)
        </span>
        <Button variant="outline" size="sm" disabled={page >= totalPages} onClick={() => setPage((p) => p + 1)}>
          Next
        </Button>
      </div>
    </div>
  )
}
