import { useState, type FormEvent } from 'react'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import { addSkill, deleteSkill, listAdminSkills, mergeSkill, type SkillRow } from '@/features/admin/api'
import { Card, CardBody } from '@/components/ui/Card'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Modal } from '@/components/ui/Modal'
import { PageHeader } from '@/components/ui/PageHeader'
import { SectionCard } from '@/components/ui/SectionCard'
import { EmptyState } from '@/components/ui/EmptyState'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import '../public/JobsPage.css'
import '../dashboard/ProfilePage.css'
import './AdminSkillsPage.css'

export function AdminSkillsPage() {
  const toast = useToast()
  const queryClient = useQueryClient()
  const [q, setQ] = useState('')
  const [newSkill, setNewSkill] = useState({ name: '', category: '' })
  const [mergingSkill, setMergingSkill] = useState<SkillRow | null>(null)
  const [mergeTargetId, setMergeTargetId] = useState('')

  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-skills', q],
    queryFn: () => listAdminSkills(q || undefined),
    placeholderData: (prev) => prev,
  })

  // Separate, always-unfiltered fetch for the merge-target picker: if the
  // admin has typed a search query above, `data` only contains matches for
  // that query, which would silently hide valid merge targets outside the
  // search — the merge picker needs the full skill list regardless of what
  // the admin is currently searching for.
  const { data: allSkills } = useQuery({
    queryKey: ['admin-skills', undefined],
    queryFn: () => listAdminSkills(undefined),
  })

  const addMutation = useMutation({
    mutationFn: () => addSkill(newSkill.name, newSkill.category),
    onSuccess: (result) => {
      toast.success(result.message)
      setNewSkill({ name: '', category: '' })
      queryClient.invalidateQueries({ queryKey: ['admin-skills'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not add skill.'),
  })

  const deleteMutation = useMutation({
    mutationFn: deleteSkill,
    onSuccess: () => {
      toast.success('Skill deleted.')
      queryClient.invalidateQueries({ queryKey: ['admin-skills'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not delete skill.'),
  })

  const mergeMutation = useMutation({
    mutationFn: ({ sourceId, targetId }: { sourceId: number; targetId: number }) => mergeSkill(sourceId, targetId),
    onSuccess: (result) => {
      toast.success(result.message)
      setMergingSkill(null)
      setMergeTargetId('')
      queryClient.invalidateQueries({ queryKey: ['admin-skills'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not merge skill.'),
  })

  function onMergeSubmit(e: FormEvent) {
    e.preventDefault()
    const targetId = Number(mergeTargetId)
    if (!mergingSkill || !targetId) {
      toast.error('Choose a target skill ID to merge into.')
      return
    }
    mergeMutation.mutate({ sourceId: mergingSkill.id, targetId })
  }

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!newSkill.name.trim()) {
      toast.error('Enter a skill name.')
      return
    }
    addMutation.mutate()
  }

  return (
    <div>
      <PageHeader
        title="Skills taxonomy"
        subtitle={data ? `${data.length} skill${data.length === 1 ? '' : 's'} tracked.` : undefined}
      />

      <SectionCard title="Add a skill" className="jp-admin-skills__section">
          <form onSubmit={onSubmit} className="jp-profile-grid">
            <Input
              label="New skill name"
              value={newSkill.name}
              onChange={(e) => setNewSkill((s) => ({ ...s, name: e.target.value }))}
            />
            <Input
              label="Category (optional)"
              value={newSkill.category}
              onChange={(e) => setNewSkill((s) => ({ ...s, category: e.target.value }))}
            />
            <div style={{ alignSelf: 'end' }}>
              <Button type="submit" variant="accent" loading={addMutation.isPending}>
                Add skill
              </Button>
            </div>
          </form>
      </SectionCard>

      <div style={{ maxWidth: 320, marginBottom: 16 }}>
        <Input label="Search skills" value={q} onChange={(e) => setQ(e.target.value)} />
      </div>

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 4 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <div className="jp-jobs-error" role="alert">
          Could not load skills. Please try again.
        </div>
      )}

      {!isLoading && data && data.length === 0 && (
        <EmptyState title="No skills found" description="Try a different search, or add a new skill above." />
      )}

      {!isLoading && data && data.length > 0 && (
        <div className="jp-jobs-list">
          {data.map((skill) => (
            <Card key={skill.id}>
              <CardBody>
                <div className="jp-job-row">
                  <div>
                    <p className="jp-job-title" style={{ fontSize: 14 }}>
                      {skill.name}
                    </p>
                    <p className="jp-job-company">{skill.category || 'Uncategorized'}</p>
                  </div>
                  <div className="jp-job-badges">
                    <Badge variant="gray">{skill.jobs_count} jobs</Badge>
                    <Button variant="outline" size="sm" onClick={() => setMergingSkill(skill)}>
                      Merge into…
                    </Button>
                    <Button
                      variant="danger"
                      size="sm"
                      loading={deleteMutation.isPending && deleteMutation.variables === skill.id}
                      onClick={() => {
                        if (window.confirm(`Delete the skill "${skill.name}"?`)) deleteMutation.mutate(skill.id)
                      }}
                    >
                      Delete
                    </Button>
                  </div>
                </div>
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      <Modal
        open={mergingSkill !== null}
        onClose={() => {
          setMergingSkill(null)
          setMergeTargetId('')
        }}
        title={mergingSkill ? `Merge "${mergingSkill.name}"` : undefined}
      >
        <form onSubmit={onMergeSubmit} className="jp-profile-grid">
          <p className="jp-job-company" style={{ gridColumn: '1 / -1' }}>
            All candidate profiles, assessments, and assessment questions linked to this skill will be reassigned to
            the target skill, and this skill will be deleted. This cannot be undone.
          </p>
          {/*
            Root-cause fix (batch 29): this asked an admin to type another
            skill's raw numeric ID by hand with no way to look it up short of
            leaving the modal — the exact same friction class already fixed
            on RecruiterAiToolsPage's job picker (batch 18) and
            AdminAuditLogPage's actor picker (batch 22). The full skill list
            is already loaded via `data` (this page's own listAdminSkills()
            query) — no new request needed, just excluding the skill being
            merged from its own target list.
          */}
          <div className="jp-form-group">
            <label className="jp-label" htmlFor="merge-target">
              Target skill
            </label>
            <select
              id="merge-target"
              className="jp-input"
              value={mergeTargetId}
              onChange={(e) => setMergeTargetId(e.target.value)}
            >
              <option value="">Choose a skill…</option>
              {(allSkills ?? [])
                .filter((s) => s.id !== mergingSkill?.id)
                .map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.name} {s.category ? `(${s.category})` : ''}
                  </option>
                ))}
            </select>
          </div>
          <div style={{ alignSelf: 'end' }}>
            <Button type="submit" variant="danger" loading={mergeMutation.isPending}>
              Merge
            </Button>
          </div>
        </form>
      </Modal>
    </div>
  )
}
