import { useSearchParams } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { getErrorLog } from '@/features/admin/api'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Input } from '@/components/ui/Input'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import { EmptyState } from '@/components/ui/EmptyState'
import { FilterBar, FilterChip } from '@/components/ui/FilterBar'
import '../public/JobsPage.css'

/**
 * Admin screen for JP_ErrorLog::recent() — this class has captured every
 * PHP error/exception/fatal originating from this plugin's own code since
 * an earlier pass (see class-jp-errorlog.php's docblock), and this screen
 * already gave it a real paginated REST route and SPA viewer.
 *
 * Root-cause fix (batch 14, Tier B): the table has always carried `level`,
 * `message`, and `file` columns (jp_error_log's CREATE TABLE, with a KEY on
 * `level`), and this page already rendered a level badge per row — but
 * there was never a way to actually filter by level or search message/file,
 * so an admin with a large log had to scroll the raw unfiltered list by
 * eye. admin_error_log() and JP_ErrorLog::recent() now accept real `level`/
 * `q` params against those columns; `levels` in the response is the
 * distinct set actually present in the table, so the dropdown never offers
 * a level with zero matches. FilterBar reused from Phase 2 for consistency
 * with every other list page in the app.
 */
export function AdminErrorLogPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const page = Number(searchParams.get('page') ?? '1')
  const level = searchParams.get('level') ?? ''
  const q = searchParams.get('q') ?? ''

  const { data, isLoading, isError } = useQuery({
    queryKey: ['admin-error-log', page, level, q],
    queryFn: () => getErrorLog(page, level, q),
    placeholderData: (prev) => prev,
  })

  function updateParam(key: string, value: string | null) {
    const next = new URLSearchParams(searchParams)
    if (value) next.set(key, value)
    else next.delete(key)
    next.delete('page')
    setSearchParams(next)
  }

  function levelVariant(lvl: string): 'error' | 'gray' {
    return lvl.toLowerCase().includes('fatal') || lvl.toLowerCase().includes('error') ? 'error' : 'gray'
  }

  const rows = data?.rows ?? []
  const activeChips: Array<{ key: string; label: string }> = []
  if (level) activeChips.push({ key: 'level', label: `Level: ${level}` })
  if (q) activeChips.push({ key: 'q', label: `"${q}"` })

  return (
    <div>
      <WorkspacePageHeader tone="admin" title="Error log" subtitle="PHP errors and exceptions captured from this plugin's own code." />

      <FilterBar
        search={<Input label="Search message or file" value={q} onChange={(e) => updateParam('q', e.target.value || null)} />}
        filters={
          <select
            className="jp-input"
            value={level}
            onChange={(e) => updateParam('level', e.target.value || null)}
            aria-label="Filter by level"
          >
            <option value="">All levels</option>
            {data?.levels.map((lvl) => (
              <option key={lvl} value={lvl}>
                {lvl}
              </option>
            ))}
          </select>
        }
        chips={
          activeChips.length > 0
            ? activeChips.map((chip) => (
                <FilterChip key={chip.key} onRemove={() => updateParam(chip.key, null)}>
                  {chip.label}
                </FilterChip>
              ))
            : undefined
        }
      />

      {isLoading && (
        <div className="jp-jobs-list">
          {Array.from({ length: 5 }).map((_, i) => (
            <CardSkeleton key={i} />
          ))}
        </div>
      )}

      {isError && (
        <p className="jp-jobs-error" role="alert">
          Could not load the error log.
        </p>
      )}

      {!isLoading && data && rows.length === 0 && (
        <EmptyState
          title={level || q ? 'No errors match your filters' : page > 1 ? 'No errors on this page' : 'No errors logged'}
          description={level || q ? 'Try a different level or search term, or clear your filters.' : page > 1 ? undefined : 'PHP errors and exceptions will appear here if they occur.'}
        />
      )}

      {!isLoading && rows.length > 0 && (
        <div className="jp-jobs-list">
          {rows.map((entry) => (
            <Card key={entry.id}>
              <CardBody>
                <div className="jp-job-row">
                  <div>
                    <p className="jp-job-title" style={{ fontSize: 14 }}>
                      {entry.message ?? '(no message)'}
                    </p>
                    <p className="jp-job-company">
                      {entry.file ? `${entry.file}:${entry.line ?? '?'}` : ''} · last seen{' '}
                      {new Date(entry.last_seen_at).toLocaleString()}
                      {entry.occurrences > 1 && (
                        <> · first seen {new Date(entry.first_seen_at).toLocaleString()}</>
                      )}
                    </p>
                  </div>
                  <div className="jp-job-badges">
                    <Badge variant={levelVariant(entry.level)}>{entry.level}</Badge>
                    {entry.occurrences > 1 && <Badge variant="gray">×{entry.occurrences}</Badge>}
                  </div>
                </div>
                {entry.trace && (
                  <details style={{ marginTop: 8 }}>
                    <summary style={{ cursor: 'pointer', fontSize: 12 }}>Stack trace</summary>
                    <pre style={{ fontSize: 11, whiteSpace: 'pre-wrap', marginTop: 4 }}>{entry.trace}</pre>
                  </details>
                )}
              </CardBody>
            </Card>
          ))}
        </div>
      )}

      <div className="jp-jobs-pagination">
        <Button variant="outline" size="sm" disabled={page === 1} onClick={() => updateParam('page', page > 2 ? String(page - 1) : null)}>
          Previous
        </Button>
        <span>Page {page}</span>
        <Button variant="outline" size="sm" disabled={rows.length < 30} onClick={() => setSearchParams((prev) => { const n = new URLSearchParams(prev); n.set('page', String(page + 1)); return n })}>
          Next
        </Button>
      </div>
    </div>
  )
}
