import { useMemo, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { useQuery } from '@tanstack/react-query'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Card, CardBody } from '@/components/ui/Card'
import { useToast } from '@/components/ui/ToastProvider'
import { useAuth } from '@/lib/auth/AuthContext'
import { register, type RegisterPayload } from '@/features/auth/registerApi'
import { getMarketInsights } from '@/features/market/api'
import { ApiError } from '@/lib/apiClient'
import '../auth/LoginPage.css'
import './RegisterPage.css'

const schema = z.object({
  name: z.string().min(1, 'Enter your name.'),
  email: z.string().email('Enter a valid email address.'),
  // Root-cause fix: this was min(6) while the (now-built) backend
  // auth_register() enforces an 8-char minimum (matching the legacy
  // ajax_register() rule) — a 6-7 char password passed client-side
  // validation only to be rejected by the server with a confusing "Password
  // must be at least 8 characters" error after the user had already been
  // told their input was valid. Kept in sync with the server's own message.
  password: z.string().min(8, 'Password must be at least 8 characters.'),
  role: z.enum(['jp_job_seeker', 'jp_recruiter']),
})
type FormValues = z.infer<typeof schema>

const ROLE_PREVIEW: Record<FormValues['role'], { title: string; points: string[] }> = {
  jp_job_seeker: {
    title: "As a job seeker, you'll get:",
    points: ['A searchable profile recruiters can find', 'One-click applications with saved resumes', 'Interview scheduling and status tracking', 'Skill assessments and achievement badges'],
  },
  jp_recruiter: {
    title: "As a recruiter, you'll get:",
    points: ['Post jobs and manage your pipeline', 'Search and filter the candidate database', 'Team seats and collaborative hiring tools', 'Applicant tracking with interview scheduling'],
  },
}

/**
 * Phase 3 redesign (Tier A, redesign-plan §RegisterPage) — was a bare form
 * with no context for what either account type actually gets, no signal
 * about password quality beyond the 8-char minimum error, and nothing to
 * establish the platform is real/active before asking for an account. Three
 * additions, all backed by real data/logic rather than decoration:
 *  1. Role preview — switches with the selected role, describing actual
 *     product surfaces (matches what DashboardHomePage/RecruiterHomePage
 *     actually contain), not generic marketing copy.
 *  2. Password strength meter — a real client-side heuristic (length +
 *     character-class variety) that updates live as the user types,
 *     independent of the 8-char hard minimum already enforced by zod/server.
 *  3. Trust-signal strip — pulled from the same public /market/insights
 *     endpoint HomePage already uses (real active_jobs/companies_hiring
 *     numbers, not invented ones); renders nothing if the fetch fails
 *     rather than showing a broken or fabricated stat.
 */
function passwordStrength(pw: string): { score: 0 | 1 | 2 | 3 | 4; label: string } {
  if (!pw) return { score: 0, label: '' }
  let score = 0
  if (pw.length >= 8) score++
  if (pw.length >= 12) score++
  if (/[a-z]/.test(pw) && /[A-Z]/.test(pw)) score++
  if (/\d/.test(pw)) score++
  if (/[^A-Za-z0-9]/.test(pw)) score++
  const capped = Math.min(4, score) as 0 | 1 | 2 | 3 | 4
  const labels = ['Too short', 'Weak', 'Fair', 'Good', 'Strong']
  return { score: capped, label: labels[capped] }
}

export function RegisterPage() {
  const navigate = useNavigate()
  const toast = useToast()
  const { refresh } = useAuth()
  const [submitting, setSubmitting] = useState(false)
  const [searchParams] = useSearchParams()

  // Lets a marketing/pricing CTA like /register?role=recruiter preselect the
  // right account type instead of everyone landing on "Job seeker" by default.
  const initialRole = searchParams.get('role') === 'recruiter' ? 'jp_recruiter' : 'jp_job_seeker'

  const { data: insights } = useQuery({ queryKey: ['market-insights'], queryFn: getMarketInsights, retry: false })

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { role: initialRole },
  })

  const selectedRole = form.watch('role')
  const passwordValue = form.watch('password') ?? ''
  const strength = useMemo(() => passwordStrength(passwordValue), [passwordValue])

  async function onSubmit(values: FormValues) {
    setSubmitting(true)
    try {
      await register(values as RegisterPayload)
      toast.success('Account created! You can now sign in.')
      await refresh()
      navigate('/login', { replace: true })
    } catch (e) {
      const message = e instanceof ApiError ? e.message : 'Could not create your account. Please try again.'
      form.setError('email', { message })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="jp-auth-page">
      <div className="jp-register__layout">
        <Card className="jp-auth-card jp-register__card">
          <CardBody>
            <h1 className="jp-auth-title">Create your account</h1>

            {insights && (
              <div className="jp-register__trust-strip">
                <span>
                  <strong>{insights.stats.active_jobs.toLocaleString()}</strong> active jobs
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  <strong>{insights.stats.companies_hiring.toLocaleString()}</strong> companies hiring
                </span>
                <span aria-hidden="true">·</span>
                <span>
                  <strong>{insights.stats.new_jobs_today.toLocaleString()}</strong> posted today
                </span>
              </div>
            )}

            <form onSubmit={form.handleSubmit(onSubmit)} noValidate>
              <Input label="Full name" autoComplete="name" error={form.formState.errors.name?.message} {...form.register('name')} />
              <Input label="Email" type="email" autoComplete="email" error={form.formState.errors.email?.message} {...form.register('email')} />
              <Input
                label="Password"
                type="password"
                autoComplete="new-password"
                error={form.formState.errors.password?.message}
                {...form.register('password')}
              />
              {passwordValue.length > 0 && (
                <div className="jp-register__strength" aria-live="polite">
                  <div className="jp-register__strength-track">
                    <div className={`jp-register__strength-fill jp-register__strength-fill--${strength.score}`} style={{ width: `${(strength.score / 4) * 100}%` }} />
                  </div>
                  <span className={`jp-register__strength-label jp-register__strength-label--${strength.score}`}>{strength.label}</span>
                </div>
              )}
              <div className="jp-form-group">
                <label className="jp-label" htmlFor="role">
                  I am a
                </label>
                <select id="role" className="jp-input" {...form.register('role')}>
                  <option value="jp_job_seeker">Job seeker</option>
                  <option value="jp_recruiter">Recruiter / Employer</option>
                </select>
              </div>
              <Button type="submit" fullWidth loading={submitting}>
                Create account
              </Button>
            </form>
            <p className="jp-auth-switch">
              Already have an account? <Link to="/login">Sign in</Link>
            </p>
          </CardBody>
        </Card>

        <Card className="jp-register__preview-card">
          <CardBody>
            <p className="jp-register__preview-title">{ROLE_PREVIEW[selectedRole].title}</p>
            <ul className="jp-register__preview-list">
              {ROLE_PREVIEW[selectedRole].points.map((point) => (
                <li key={point}>
                  <span className="jp-register__preview-check" aria-hidden="true">✓</span>
                  {point}
                </li>
              ))}
            </ul>
          </CardBody>
        </Card>
      </div>
    </div>
  )
}
