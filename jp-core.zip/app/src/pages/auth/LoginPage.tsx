import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Card, CardBody } from '@/components/ui/Card'
import { useToast } from '@/components/ui/ToastProvider'
import { useAuth } from '@/lib/auth/AuthContext'
import { login } from '@/features/auth/api'
import { ApiError } from '@/lib/apiClient'
import './LoginPage.css'

const credentialsSchema = z.object({
  username: z.string().min(1, 'Enter your email or username.'),
  password: z.string().min(6, 'Password must be at least 6 characters.'),
})
type Credentials = z.infer<typeof credentialsSchema>

const codeSchema = z.object({
  code: z.string().length(6, 'Enter the 6-digit code.'),
})
type CodeForm = z.infer<typeof codeSchema>

export function LoginPage() {
  const navigate = useNavigate()
  const location = useLocation() as { state?: { from?: { pathname: string } } }
  const toast = useToast()
  const { refresh } = useAuth()

  // Two-step state machine: credentials -> (maybe) 2FA code -> done.
  // Kept as local component state rather than a global store since nothing
  // outside this page needs to know a login is "half-done."
  const [pendingCredentials, setPendingCredentials] = useState<Credentials | null>(null)
  const [submitting, setSubmitting] = useState(false)

  const credentialsForm = useForm<Credentials>({ resolver: zodResolver(credentialsSchema) })
  const codeForm = useForm<CodeForm>({ resolver: zodResolver(codeSchema) })

  async function finishLogin(nonce?: string) {
    // auth_token() (class-jp-api.php) is what actually establishes the
    // WordPress session (wp_set_auth_cookie()) — once it succeeds we
    // re-fetch our own bootstrap config (which reads is_logged/role from
    // that now-authenticated session) rather than trying to decode a token
    // client-side. The nonce returned directly in the login response has
    // to be used for this one refetch: it's bound to the session we just
    // created, whereas whatever nonce was already loaded is bound to
    // whoever/whatever was signed in (or anonymous) before this call.
    await refresh(nonce)
    navigate(location.state?.from?.pathname ?? '/', { replace: true })
  }

  async function onSubmitCredentials(values: Credentials) {
    setSubmitting(true)
    try {
      const result = await login(values)
      if (result.two_factor_required) {
        setPendingCredentials(values)
      } else {
        toast.success('Welcome back!')
        await finishLogin(result.nonce)
      }
    } catch (e) {
      const message = e instanceof ApiError ? e.message : 'Could not sign in. Please try again.'
      credentialsForm.setError('password', { message })
    } finally {
      setSubmitting(false)
    }
  }

  async function onSubmitCode(values: CodeForm) {
    if (!pendingCredentials) return
    setSubmitting(true)
    try {
      const result = await login({ ...pendingCredentials, code: values.code })
      toast.success('Welcome back!')
      await finishLogin(result.nonce)
    } catch (e) {
      const message = e instanceof ApiError ? e.message : 'Invalid code. Please try again.'
      codeForm.setError('code', { message })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="jp-auth-page">
      <Card className="jp-auth-card">
        <CardBody>
          <h1 className="jp-auth-title">Sign in</h1>

          {!pendingCredentials ? (
            <form onSubmit={credentialsForm.handleSubmit(onSubmitCredentials)} noValidate>
              <Input
                label="Email or username"
                autoComplete="username"
                error={credentialsForm.formState.errors.username?.message}
                {...credentialsForm.register('username')}
              />
              <Input
                label="Password"
                type="password"
                autoComplete="current-password"
                error={credentialsForm.formState.errors.password?.message}
                {...credentialsForm.register('password')}
              />
              {/* Root-cause fix (batch 4): this used to link straight to
                  legacy /wp-login.php?action=lostpassword — outside the SPA,
                  unstyled, and inconsistent with the rest of this auth flow
                  — because no in-app reset flow existed yet. See
                  ForgotPasswordPage.tsx / class-jp-api.php's
                  auth_forgot_password() for the now-built replacement. */}
              <Link className="jp-auth-forgot" to="/forgot-password">
                Forgot password?
              </Link>
              <Button type="submit" fullWidth loading={submitting}>
                Sign in
              </Button>
            </form>
          ) : (
            <form onSubmit={codeForm.handleSubmit(onSubmitCode)} noValidate>
              <p className="jp-auth-hint">Enter the 6-digit code from your authenticator app.</p>
              <Input
                label="Verification code"
                inputMode="numeric"
                autoComplete="one-time-code"
                maxLength={6}
                error={codeForm.formState.errors.code?.message}
                {...codeForm.register('code')}
              />
              <Button type="submit" fullWidth loading={submitting}>
                Verify &amp; sign in
              </Button>
              <button
                type="button"
                className="jp-auth-back"
                onClick={() => setPendingCredentials(null)}
              >
                ← Back
              </button>
            </form>
          )}

          <p className="jp-auth-switch">
            Don&apos;t have an account? <Link to="/register">Sign up</Link>
          </p>
        </CardBody>
      </Card>
    </div>
  )
}
