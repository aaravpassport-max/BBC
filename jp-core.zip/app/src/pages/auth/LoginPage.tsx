import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link, useLocation, useNavigate } from 'react-router-dom'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { useToast } from '@/components/ui/ToastProvider'
import { useAuth } from '@/lib/auth/AuthContext'
import { login } from '@/features/auth/api'
import { ApiError } from '@/lib/apiClient'
import { AuthShell } from '@/components/layout/AuthShell'
import './LoginPage.css'

const credentialsSchema = z.object({
  username: z.string().min(1, 'Enter your email or username.'),
  password: z.string().min(6, 'Password must be at least 6 characters.'),
})
type Credentials = z.infer<typeof credentialsSchema>

const codeSchema = z.object({
  code: z.string().length(6, 'Enter the 6-digit code.'),
})
type CodeForm = z.infer<typeof codeSchema>

export function LoginPage() {
  const navigate = useNavigate()
  const location = useLocation() as { state?: { from?: { pathname: string } } }
  const toast = useToast()
  const { refresh } = useAuth()

  const [pendingCredentials, setPendingCredentials] = useState<Credentials | null>(null)
  const [submitting, setSubmitting] = useState(false)

  const credentialsForm = useForm<Credentials>({ resolver: zodResolver(credentialsSchema) })
  const codeForm = useForm<CodeForm>({ resolver: zodResolver(codeSchema) })

  async function finishLogin(nonce?: string) {
    await refresh(nonce)
    navigate(location.state?.from?.pathname ?? '/', { replace: true })
  }

  async function onSubmitCredentials(values: Credentials) {
    setSubmitting(true)
    try {
      const result = await login(values)
      if (result.two_factor_required) {
        setPendingCredentials(values)
      } else {
        toast.success('Welcome back!')
        await finishLogin(result.nonce)
      }
    } catch (e) {
      const message = e instanceof ApiError ? e.message : 'Could not sign in. Please try again.'
      credentialsForm.setError('password', { message })
    } finally {
      setSubmitting(false)
    }
  }

  async function onSubmitCode(values: CodeForm) {
    if (!pendingCredentials) return
    setSubmitting(true)
    try {
      const result = await login({ ...pendingCredentials, code: values.code })
      toast.success('Welcome back!')
      await finishLogin(result.nonce)
    } catch (e) {
      const message = e instanceof ApiError ? e.message : 'Invalid code. Please try again.'
      codeForm.setError('code', { message })
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <AuthShell
      title="Sign in"
      lead="Access your dashboard, saved jobs, applications, and recruiter tools."
      footer={
        <p className="jp-auth-switch">
          Don&apos;t have an account? <Link to="/register">Sign up</Link>
        </p>
      }
    >
      {!pendingCredentials ? (
        <form onSubmit={credentialsForm.handleSubmit(onSubmitCredentials)} noValidate>
          <Input
            label="Email or username"
            autoComplete="username"
            error={credentialsForm.formState.errors.username?.message}
            {...credentialsForm.register('username')}
          />
          <Input
            label="Password"
            type="password"
            autoComplete="current-password"
            error={credentialsForm.formState.errors.password?.message}
            {...credentialsForm.register('password')}
          />
          <Link className="jp-auth-forgot" to="/forgot-password">
            Forgot password?
          </Link>
          <Button type="submit" fullWidth loading={submitting}>
            Sign in
          </Button>
        </form>
      ) : (
        <form onSubmit={codeForm.handleSubmit(onSubmitCode)} noValidate>
          <p className="jp-auth-hint">Enter the 6-digit code from your authenticator app.</p>
          <Input
            label="Verification code"
            inputMode="numeric"
            autoComplete="one-time-code"
            maxLength={6}
            error={codeForm.formState.errors.code?.message}
            {...codeForm.register('code')}
          />
          <Button type="submit" fullWidth loading={submitting}>
            Verify &amp; sign in
          </Button>
          <button type="button" className="jp-auth-back" onClick={() => setPendingCredentials(null)}>
            ← Back
          </button>
        </form>
      )}
    </AuthShell>
  )
}
