import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { useToast } from '@/components/ui/ToastProvider'
import { resetPassword } from '@/features/auth/api'
import { ApiError } from '@/lib/apiClient'
import { AuthShell } from '@/components/layout/AuthShell'
import './LoginPage.css'

const schema = z
  .object({
    password: z.string().min(8, 'Password must be at least 8 characters.'),
    confirmPassword: z.string(),
  })
  .refine((v) => v.password === v.confirmPassword, {
    message: 'Passwords do not match.',
    path: ['confirmPassword'],
  })
type FormValues = z.infer<typeof schema>

export function ResetPasswordPage() {
  const navigate = useNavigate()
  const toast = useToast()
  const [searchParams] = useSearchParams()
  const [submitting, setSubmitting] = useState(false)
  const [linkError, setLinkError] = useState<string | null>(null)

  const key = searchParams.get('key') ?? ''
  const login = searchParams.get('login') ?? ''
  const linkIsWellFormed = Boolean(key && login)

  const form = useForm<FormValues>({ resolver: zodResolver(schema) })

  async function onSubmit(values: FormValues) {
    setSubmitting(true)
    setLinkError(null)
    try {
      const result = await resetPassword({ key, login, password: values.password })
      toast.success(result.message)
      navigate('/login', { replace: true })
    } catch (e) {
      setLinkError(e instanceof ApiError ? e.message : 'Something went wrong. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <AuthShell
      title="Choose a new password"
      lead="Pick a strong password you have not used on this site before."
      footer={
        <p className="jp-auth-switch">
          <Link to="/login">Back to sign in</Link>
        </p>
      }
    >
      {!linkIsWellFormed || linkError ? (
        <>
          <p className="jp-auth-hint" role="alert">
            {!linkIsWellFormed ? 'This reset link is missing required information.' : linkError} Please request a new
            password reset link.
          </p>
          <Link to="/forgot-password">
            <Button variant="outline" fullWidth>
              Request a new link
            </Button>
          </Link>
        </>
      ) : (
        <form onSubmit={form.handleSubmit(onSubmit)} noValidate>
          <Input
            label="New password"
            type="password"
            autoComplete="new-password"
            error={form.formState.errors.password?.message}
            {...form.register('password')}
          />
          <Input
            label="Confirm new password"
            type="password"
            autoComplete="new-password"
            error={form.formState.errors.confirmPassword?.message}
            {...form.register('confirmPassword')}
          />
          <Button type="submit" fullWidth loading={submitting}>
            Update password
          </Button>
        </form>
      )}
    </AuthShell>
  )
}
