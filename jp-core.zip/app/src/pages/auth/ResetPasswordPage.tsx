import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link, useNavigate, useSearchParams } from 'react-router-dom'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Card, CardBody } from '@/components/ui/Card'
import { useToast } from '@/components/ui/ToastProvider'
import { resetPassword } from '@/features/auth/api'
import { ApiError } from '@/lib/apiClient'
import './LoginPage.css'

const schema = z
  .object({
    password: z.string().min(8, 'Password must be at least 8 characters.'),
    confirmPassword: z.string(),
  })
  .refine((v) => v.password === v.confirmPassword, {
    message: 'Passwords do not match.',
    path: ['confirmPassword'],
  })
type FormValues = z.infer<typeof schema>

/**
 * Root-cause fix (batch 4). Reads `key`/`login` from the query string — the
 * same two params class-jp-api.php's auth_forgot_password() puts on the
 * emailed link (home_url('/reset-password') + add_query_arg(['key',
 * 'login'])) — and POSTs them straight through to auth_reset_password()
 * along with the new password. Missing/malformed params are handled the
 * same way an invalid/expired key from the server is: a single generic
 * "invalid or expired" state with a link back to request a new one, since
 * neither case is something the user can fix by retrying this form.
 */
export function ResetPasswordPage() {
  const navigate = useNavigate()
  const toast = useToast()
  const [searchParams] = useSearchParams()
  const [submitting, setSubmitting] = useState(false)
  const [linkError, setLinkError] = useState<string | null>(null)

  const key = searchParams.get('key') ?? ''
  const login = searchParams.get('login') ?? ''
  const linkIsWellFormed = Boolean(key && login)

  const form = useForm<FormValues>({ resolver: zodResolver(schema) })

  async function onSubmit(values: FormValues) {
    setSubmitting(true)
    setLinkError(null)
    try {
      const result = await resetPassword({ key, login, password: values.password })
      toast.success(result.message)
      navigate('/login', { replace: true })
    } catch (e) {
      setLinkError(e instanceof ApiError ? e.message : 'Something went wrong. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="jp-auth-page">
      <Card className="jp-auth-card">
        <CardBody>
          <h1 className="jp-auth-title">Choose a new password</h1>

          {!linkIsWellFormed || linkError ? (
            <>
              <p className="jp-auth-hint" role="alert">
                {!linkIsWellFormed
                  ? 'This reset link is missing required information.'
                  : linkError}{' '}
                Please request a new password reset link.
              </p>
              <p className="jp-auth-switch">
                <Link to="/forgot-password">Request a new link</Link>
              </p>
            </>
          ) : (
            <form onSubmit={form.handleSubmit(onSubmit)} noValidate>
              <Input
                label="New password"
                type="password"
                autoComplete="new-password"
                error={form.formState.errors.password?.message}
                {...form.register('password')}
              />
              <Input
                label="Confirm new password"
                type="password"
                autoComplete="new-password"
                error={form.formState.errors.confirmPassword?.message}
                {...form.register('confirmPassword')}
              />
              <Button type="submit" fullWidth loading={submitting}>
                Reset password
              </Button>
            </form>
          )}

          <p className="jp-auth-switch">
            <Link to="/login">Back to sign in</Link>
          </p>
        </CardBody>
      </Card>
    </div>
  )
}
