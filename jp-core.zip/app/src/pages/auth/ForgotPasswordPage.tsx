import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link } from 'react-router-dom'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { Card, CardBody } from '@/components/ui/Card'
import { requestPasswordReset } from '@/features/auth/api'
import { ApiError } from '@/lib/apiClient'
import './LoginPage.css'

const schema = z.object({
  email: z.string().email('Enter a valid email address.'),
})
type FormValues = z.infer<typeof schema>

/**
 * Root-cause fix (batch 4 — see class-jp-api.php's auth_forgot_password()
 * docblock for the full gap trace). Always shows the same generic success
 * message the backend returns regardless of whether the email matched an
 * account — the anti-enumeration guarantee only holds end-to-end if the
 * frontend doesn't leak the distinction back to the user either.
 */
export function ForgotPasswordPage() {
  const [submitting, setSubmitting] = useState(false)
  const [sent, setSent] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  const form = useForm<FormValues>({ resolver: zodResolver(schema) })

  async function onSubmit(values: FormValues) {
    setSubmitting(true)
    setErrorMessage(null)
    try {
      const result = await requestPasswordReset(values.email)
      setSent(result.message)
    } catch (e) {
      // Only a real transport/rate-limit failure reaches here — the backend
      // itself never returns a "no such account" error (see docblock).
      setErrorMessage(e instanceof ApiError ? e.message : 'Something went wrong. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <div className="jp-auth-page">
      <Card className="jp-auth-card">
        <CardBody>
          <h1 className="jp-auth-title">Reset your password</h1>

          {sent ? (
            <>
              <p className="jp-auth-hint">{sent}</p>
              <p className="jp-auth-switch">
                <Link to="/login">Back to sign in</Link>
              </p>
            </>
          ) : (
            <>
              <p className="jp-auth-hint">Enter your email and we&apos;ll send you a link to reset your password.</p>
              <form onSubmit={form.handleSubmit(onSubmit)} noValidate>
                <Input
                  label="Email"
                  type="email"
                  autoComplete="email"
                  error={form.formState.errors.email?.message ?? errorMessage ?? undefined}
                  {...form.register('email')}
                />
                <Button type="submit" fullWidth loading={submitting}>
                  Send reset link
                </Button>
              </form>
              <p className="jp-auth-switch">
                <Link to="/login">Back to sign in</Link>
              </p>
            </>
          )}
        </CardBody>
      </Card>
    </div>
  )
}
