import { useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { z } from 'zod'
import { Link } from 'react-router-dom'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { requestPasswordReset } from '@/features/auth/api'
import { ApiError } from '@/lib/apiClient'
import { AuthShell } from '@/components/layout/AuthShell'
import './LoginPage.css'

const schema = z.object({
  email: z.string().email('Enter a valid email address.'),
})
type FormValues = z.infer<typeof schema>

export function ForgotPasswordPage() {
  const [submitting, setSubmitting] = useState(false)
  const [sent, setSent] = useState<string | null>(null)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  const form = useForm<FormValues>({ resolver: zodResolver(schema) })

  async function onSubmit(values: FormValues) {
    setSubmitting(true)
    setErrorMessage(null)
    try {
      const result = await requestPasswordReset(values.email)
      setSent(result.message)
    } catch (e) {
      setErrorMessage(e instanceof ApiError ? e.message : 'Something went wrong. Please try again.')
    } finally {
      setSubmitting(false)
    }
  }

  return (
    <AuthShell
      title="Reset your password"
      lead="We will email you a secure link to choose a new password."
      footer={
        <p className="jp-auth-switch">
          <Link to="/login">Back to sign in</Link>
        </p>
      }
    >
      {sent ? (
        <p className="jp-auth-hint">{sent}</p>
      ) : (
        <>
          <p className="jp-auth-hint">Enter the email on your account. For security, the response is the same whether or not we find a match.</p>
          <form onSubmit={form.handleSubmit(onSubmit)} noValidate>
            <Input
              label="Email"
              type="email"
              autoComplete="email"
              error={form.formState.errors.email?.message ?? errorMessage ?? undefined}
              {...form.register('email')}
            />
            <Button type="submit" fullWidth loading={submitting}>
              Send reset link
            </Button>
          </form>
        </>
      )}
    </AuthShell>
  )
}
