import { useEffect, useRef, useState, type FormEvent } from 'react'
import { useSearchParams } from 'react-router-dom'
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query'
import {
  archiveThread,
  deleteCannedResponse,
  getThreadMessages,
  listCannedResponses,
  listThreads,
  markThreadRead,
  saveCannedResponse,
  sendMessage,
} from '@/features/messaging/api'
import { useAuth } from '@/lib/auth/AuthContext'
import { Button } from '@/components/ui/Button'
import { Badge } from '@/components/ui/Badge'
import { Input } from '@/components/ui/Input'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Tabs } from '@/components/ui/Tabs'
import { useToast } from '@/components/ui/ToastProvider'
import { ApiError } from '@/lib/apiClient'
import { WorkspacePageHeader } from '@/components/layout/WorkspacePageHeader'
import '../public/JobsPage.css'
import './MessagesPage.css'

// Mirrors class-jp-api.php's require_recruiter() allow-list — the canned-
// responses endpoints are server-scoped to these roles, so gating the UI
// the same way avoids offering a control every non-recruiter would just
// get a 403 from.
const RECRUITER_ROLES = ['jp_recruiter', 'jp_team_manager', 'jp_admin_manager', 'jp_super_admin', 'administrator']

export function MessagesPage() {
  const { config, role } = useAuth()
  const isRecruiter = !!role && RECRUITER_ROLES.includes(role)
  const toast = useToast()
  const [searchParams, setSearchParams] = useSearchParams()
  const [activeThreadId, setActiveThreadId] = useState<number | null>(null)
  const [showArchived, setShowArchived] = useState(false)
  const [draft, setDraft] = useState('')
  const [templatesOpen, setTemplatesOpen] = useState(false)
  const [savingTitle, setSavingTitle] = useState('')
  const queryClient = useQueryClient()
  const scrollRef = useRef<HTMLDivElement>(null)

  // Batch 25 (messaging upgrades backlog: canned responses) — recruiter-only.
  const { data: templates } = useQuery({
    queryKey: ['canned-responses'],
    queryFn: listCannedResponses,
    enabled: isRecruiter,
  })

  const saveTemplateMutation = useMutation({
    mutationFn: () => saveCannedResponse(savingTitle.trim(), draft.trim()),
    onSuccess: () => {
      toast.success('Template saved.')
      setSavingTitle('')
      queryClient.invalidateQueries({ queryKey: ['canned-responses'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not save this template.'),
  })

  const deleteTemplateMutation = useMutation({
    mutationFn: deleteCannedResponse,
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['canned-responses'] }),
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not delete this template.'),
  })

  const { data: threads, isLoading, isError } = useQuery({
    queryKey: ['threads', showArchived],
    queryFn: () => listThreads(showArchived),
  })

  const archiveMutation = useMutation({
    mutationFn: ({ threadId, archived }: { threadId: number; archived: boolean }) => archiveThread(threadId, archived),
    onSuccess: (result, variables) => {
      toast.success(result.message)
      // The thread just left the tab currently being viewed (archived a
      // thread while viewing Active, or restored one while viewing
      // Archived) — clear the open panel if it was that thread, rather
      // than leaving a stale conversation open that no longer belongs to
      // the visible list.
      if (activeThreadId === variables.threadId) setActiveThreadId(null)
      queryClient.invalidateQueries({ queryKey: ['threads'] })
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not update this conversation.'),
  })

  const { data: messages, isLoading: messagesLoading, isError: messagesError } = useQuery({
    queryKey: ['thread-messages', activeThreadId],
    queryFn: () => getThreadMessages(activeThreadId!),
    enabled: activeThreadId !== null,
    refetchInterval: activeThreadId !== null ? 10_000 : false,
  })

  // Root-cause fix: notification/email links into messaging (see
  // class-jp-messaging.php's ajax_send()) now carry a ?thread=<id> param so
  // they can open the specific conversation they're about, not just the
  // inbox with whatever thread happened to be first. Falls back to the
  // previous first-thread behavior when there's no param, the id isn't a
  // number, or it doesn't match any thread this user actually has (e.g. a
  // stale/foreign link) — never leaves the panel on a phantom selection.
  useEffect(() => {
    if (activeThreadId || !threads || threads.length === 0) return
    const requestedId = Number(searchParams.get('thread'))
    const requested = requestedId > 0 ? threads.find((t) => t.id === requestedId) : undefined
    setActiveThreadId(requested ? requested.id : threads[0].id)
    if (searchParams.has('thread')) {
      setSearchParams((prev) => {
        const next = new URLSearchParams(prev)
        next.delete('thread')
        return next
      }, { replace: true })
    }
  }, [threads, activeThreadId, searchParams, setSearchParams])

  // Root-cause fix (batch 23): opening a thread never actually marked it
  // read — see features/messaging/api.ts's markThreadRead() docblock for
  // the full gap trace (backend existed, no route, no SPA caller). Fires
  // once per thread selection (including the auto-select above) so the
  // unread badge in the thread list actually clears, and re-fires on each
  // poll tick while a thread stays open so new incoming messages in the
  // active conversation don't sit unread either.
  useEffect(() => {
    if (activeThreadId === null) return
    markThreadRead(activeThreadId)
      .then(() => queryClient.invalidateQueries({ queryKey: ['threads'] }))
      .catch(() => {
        // Best-effort: a failed read-receipt update shouldn't block the
        // user from reading/sending in this thread, and re-fires on the
        // next poll tick or thread reselect regardless.
      })
  }, [activeThreadId, messages, queryClient])

  // Root-cause fix: switching threads previously left whatever the user had
  // typed sitting in the composer. Since sendMutation always sends to
  // whatever activeThreadId is CURRENT at send time, not the thread the
  // draft was written for, an unsent draft meant for one conversation would
  // silently go out to a different person if the user clicked over to
  // another thread before hitting send — a wrong-recipient bug, not just a
  // cosmetic one.
  function selectThread(id: number) {
    setActiveThreadId(id)
    setDraft('')
  }

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight })
  }, [messages])

  const sendMutation = useMutation({
    mutationFn: (body: string) => sendMessage(activeThreadId!, body),
    onSuccess: () => {
      setDraft('')
      queryClient.invalidateQueries({ queryKey: ['thread-messages', activeThreadId] })
      queryClient.invalidateQueries({ queryKey: ['threads'] })
    },
    // Root-cause fix: previously had no onError at all — a failed send left
    // the draft still sitting in the composer with zero indication
    // anything went wrong, which reads as "it probably sent" rather than
    // "it didn't," exactly the silent-failure pattern this send needs to
    // avoid given it's a message to another person.
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not send this message.'),
  })

  function onSubmit(e: FormEvent) {
    e.preventDefault()
    if (!draft.trim() || !activeThreadId) return
    sendMutation.mutate(draft.trim())
  }

  const otherPartyName = (t: { recruiter_id: number; recruiter_name: string | null; candidate_name: string | null }) =>
    config?.user_id === t.recruiter_id ? t.candidate_name : t.recruiter_name

  const workspaceTone = isRecruiter ? 'recruiter' : 'candidate'

  return (
    <div className="jp-messages-page">
      <WorkspacePageHeader
        tone={workspaceTone}
        title="Messages"
        subtitle="Conversations with candidates and recruiters — replies sync across devices."
      />
      <div className="jp-messages">
      <aside className="jp-messages__threads">
        <p className="jp-messages__threads-label">Inbox</p>
        <div className="jp-messages__tabs">
          <Tabs
            label="Conversation list"
            activeKey={showArchived ? 'archived' : 'active'}
            onChange={(key) => {
              setShowArchived(key === 'archived')
              setActiveThreadId(null)
            }}
            items={[
              { key: 'active', label: 'Active' },
              { key: 'archived', label: 'Archived' },
            ]}
          />
        </div>
        {isLoading && <CardSkeleton />}
        {isError && (
          <p className="jp-messages__empty" role="alert">
            Could not load conversations. Please try again.
          </p>
        )}
        {!isLoading && threads && threads.length === 0 && (
          <p className="jp-messages__empty">{showArchived ? 'No archived conversations.' : 'No conversations yet.'}</p>
        )}
        {!isLoading &&
          threads?.map((t) => (
            <div key={t.id} className={`jp-messages__thread-wrap${t.id === activeThreadId ? ' is-active' : ''}`}>
              <button type="button" className="jp-messages__thread" onClick={() => selectThread(t.id)}>
                <div className="jp-messages__thread-row">
                  <strong>{otherPartyName(t) ?? 'Unknown'}</strong>
                  {t.unread_count > 0 && <Badge variant="accent">{t.unread_count}</Badge>}
                </div>
                {t.job_title && <p className="jp-messages__thread-job">{t.job_title}</p>}
                <p className="jp-messages__thread-preview">{t.last_message ?? 'No messages yet'}</p>
              </button>
              <button
                type="button"
                className="jp-messages__thread-archive"
                title={showArchived ? 'Restore conversation' : 'Archive conversation'}
                aria-label={showArchived ? `Restore conversation with ${otherPartyName(t) ?? 'Unknown'}` : `Archive conversation with ${otherPartyName(t) ?? 'Unknown'}`}
                onClick={(e) => {
                  e.stopPropagation()
                  archiveMutation.mutate({ threadId: t.id, archived: !showArchived })
                }}
              >
                {showArchived ? '↩' : '🗄'}
              </button>
            </div>
          ))}
      </aside>

      <section className="jp-messages__panel">
        {!activeThreadId ? (
          <div className="jp-messages__empty-panel">Select a conversation</div>
        ) : (
          <>
            <div className="jp-messages__scroll" ref={scrollRef}>
              {messagesLoading && <CardSkeleton />}
              {messagesError && (
                <p className="jp-messages__empty" role="alert">
                  Could not load this conversation. Please try again.
                </p>
              )}
              {!messagesLoading &&
                messages?.map((m) => (
                  <div
                    key={m.id}
                    className={`jp-message-bubble${m.sender_id === config?.user_id ? ' is-mine' : ''}`}
                  >
                    <p>{m.body}</p>
                    <span className="jp-message-bubble__time">
                      {new Date(m.created_at).toLocaleTimeString()}
                      {m.sender_id === config?.user_id && (
                        <span className="jp-message-bubble__receipt"> · {m.is_read === 1 ? 'Seen' : 'Sent'}</span>
                      )}
                    </span>
                  </div>
                ))}
            </div>
            {isRecruiter && templatesOpen && (
              <div className="jp-messages__templates" role="region" aria-label="Saved message templates">
                {templates && templates.length === 0 && (
                  <p className="jp-messages__empty" style={{ padding: 'var(--jp-space-2)' }}>
                    No saved templates yet. Type a message below, then "Save as template".
                  </p>
                )}
                {templates?.map((t) => (
                  <div key={t.id} className="jp-messages__template-row">
                    <button
                      type="button"
                      className="jp-messages__template-use"
                      onClick={() => {
                        setDraft(t.body)
                        setTemplatesOpen(false)
                      }}
                    >
                      <strong>{t.title}</strong>
                      <span>{t.body}</span>
                    </button>
                    <Button
                      variant="ghost"
                      size="sm"
                      loading={deleteTemplateMutation.isPending && deleteTemplateMutation.variables === t.id}
                      onClick={() => deleteTemplateMutation.mutate(t.id)}
                    >
                      Delete
                    </Button>
                  </div>
                ))}
                <div className="jp-messages__template-save">
                  <Input
                    label="Save current draft as a template"
                    placeholder="Template name (e.g. Interview invite)"
                    value={savingTitle}
                    onChange={(e) => setSavingTitle(e.target.value)}
                  />
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={!savingTitle.trim() || !draft.trim()}
                    loading={saveTemplateMutation.isPending}
                    onClick={() => saveTemplateMutation.mutate()}
                  >
                    Save as template
                  </Button>
                </div>
              </div>
            )}
            <form className="jp-messages__composer" onSubmit={onSubmit}>
              {isRecruiter && (
                <Button type="button" variant="outline" onClick={() => setTemplatesOpen((o) => !o)}>
                  Templates
                </Button>
              )}
              <input
                className="jp-input"
                aria-label="Type a message"
                placeholder="Type a message…"
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
              />
              <Button type="submit" variant="accent" loading={sendMutation.isPending} disabled={!draft.trim()}>
                Send
              </Button>
            </form>
          </>
        )}
      </section>
      </div>
    </div>
  )
}
