import { Suspense } from 'react'
import { Outlet, useLocation } from 'react-router-dom'
import { PublicHeader } from '@/components/layout/PublicHeader'
import { SiteFooter } from '@/components/layout/SiteFooter'
import { ImpersonationBanner } from '@/components/layout/ImpersonationBanner'
import { useAuth } from '@/lib/auth/AuthContext'
import { FullPageSpinner } from '@/components/ui/FullPageSpinner'
import { ErrorBoundary } from '@/components/ErrorBoundary'
import { useDocumentTitle } from '@/lib/useDocumentTitle'
import './App.css'

const DEFAULT_SITE_NAME = 'JP Job Portal'

/**
 * Route-pattern → page title. Checked in order, first match wins, so a
 * longer/more specific prefix must come before a shorter one it would
 * otherwise be shadowed by (e.g. '/dashboard/profile' before '/dashboard').
 * This is a static fallback covering every route with a fixed name; pages
 * with a real entity to name (a specific job/company/event/post) call
 * useDocumentTitle() again once that data loads to override it — see that
 * hook's docblock for why the ordering between the two is safe.
 *
 * Root-cause fix: no page anywhere in this app ever changed document.title
 * away from index.html's static "JP Job Portal" — a WCAG 2.4.2 (Page
 * Titled) failure and a real usability gap (every browser tab, bookmark,
 * and history entry across the whole app was indistinguishable).
 */
const ROUTE_TITLES: Array<[string, string]> = [
  ['/dashboard/matches', 'Matches'],
  ['/dashboard/applications', 'My Applications'],
  ['/dashboard/saved-jobs', 'Saved Jobs'],
  ['/dashboard/alerts', 'Job Alerts'],
  ['/dashboard/resume-builder', 'Resume Builder'],
  ['/dashboard/resumes', 'My Resumes'],
  ['/dashboard/assessments', 'Assessments'],
  ['/dashboard/achievements', 'Achievements'],
  ['/dashboard/messages', 'Messages'],
  ['/dashboard/notifications', 'Notifications'],
  ['/dashboard/profile', 'My Profile'],
  ['/dashboard/security', 'Security & Privacy'],
  ['/dashboard/ai-hub', 'AI Career Hub'],
  ['/dashboard', 'Dashboard'],
  ['/recruiter/jobs', 'Job Postings'],
  ['/recruiter/applications', 'Applicants'],
  ['/recruiter/candidates', 'Find Candidates'],
  ['/recruiter/talent-pool', 'Talent Pool'],
  ['/recruiter/messages', 'Messages'],
  ['/recruiter/company', 'Company Profile'],
  ['/recruiter/events', 'Events'],
  ['/recruiter/analytics', 'Analytics'],
  ['/recruiter/interviews', 'Interviews'],
  ['/recruiter/billing', 'Billing'],
  ['/recruiter/ai-tools', 'AI Tools'],
  ['/recruiter', 'Recruiter Dashboard'],
  ['/admin/jobs', 'Job Moderation'],
  ['/admin/companies', 'Companies'],
  ['/admin/users', 'Users'],
  ['/admin/payments', 'Payments'],
  ['/admin/skills', 'Skills'],
  ['/admin/reviews', 'Reviews'],
  ['/admin/plans', 'Plans'],
  ['/admin/revenue', 'Revenue'],
  ['/admin/subscriptions', 'Subscriptions'],
  ['/admin/analytics', 'Platform Analytics'],
  ['/admin/audit-log', 'Audit Log'],
  ['/admin/error-log', 'Error Log'],
  ['/admin/health', 'System Health'],
  ['/admin/diagnostics', 'Diagnostics'],
  ['/admin/webhooks', 'Webhooks'],
  ['/admin/feature-flags', 'Feature Flags'],
  ['/admin/settings', 'Settings'],
  ['/admin/system', 'System'],
  ['/admin', 'Admin Dashboard'],
  ['/jobs', 'Find Jobs'],
  ['/companies', 'Companies'],
  ['/community', 'Community'],
  ['/events', 'Events'],
  ['/salary', 'Salary Insights'],
  ['/pricing', 'Pricing'],
  ['/help', 'Help Center'],
  ['/changelog', "What's New"],
  ['/login', 'Sign In'],
  ['/register', 'Create Account'],
]

/**
 * Root-cause fix: siteName used to be a hardcoded module-level constant,
 * so every route's document.title showed "JP Job Portal" regardless of
 * the "Site name" the admin actually configured on the JP Settings page
 * (config.site_name — already correctly used by PublicHeader/SiteFooter).
 * Threading it through as a parameter (instead of reading module state)
 * keeps this function pure/testable and makes the one real source of
 * truth (AuthContext's config, seeded server-side from jp_site_name)
 * explicit at every call site.
 */
function titleForPath(pathname: string, siteName: string): string {
  if (pathname === '/') return siteName
  const match = ROUTE_TITLES.find(([prefix]) => pathname === prefix || pathname.startsWith(`${prefix}/`))
  return match ? `${match[1]} · ${siteName}` : siteName
}

/**
 * Root layout. Renders the header on every route and blocks on the initial
 * auth/config bootstrap (WordPress is authoritative for is_logged/role, so
 * nothing below this should render before that first fetch resolves —
 * otherwise a logged-in recruiter could flash the logged-out header for a
 * frame, which is exactly the kind of layout-jump this rebuild set out to
 * eliminate).
 */
export function App() {
  const { loading, error, config } = useAuth()
  const location = useLocation()
  const isAuthPage = location.pathname === '/login' || location.pathname === '/register'
  const siteName = config?.site_name ?? DEFAULT_SITE_NAME

  // Must run unconditionally (before the early returns below) per the
  // rules of hooks — titleForPath('/login', siteName) etc. still resolves
  // correctly even while loading/error is true (config is undefined until
  // the bootstrap fetch resolves, so this falls back to the same default
  // the server-rendered <title> uses for an unconfigured site).
  useDocumentTitle(titleForPath(location.pathname, siteName))

  if (loading) return <FullPageSpinner />

  if (error) {
    return (
      <div className="jp-boot-error" role="alert">
        <p>{error}</p>
      </div>
    )
  }

  return (
    <div className="jp-app-shell">
      <a href="#jp-main-content" className="jp-skip-link">
        Skip to main content
      </a>
      <ImpersonationBanner />
      {!isAuthPage && <PublicHeader />}
      {/*
       * Route-level code splitting (router.tsx lazy-imports every page)
       * means a route module can genuinely still be in flight when its
       * element renders — this Suspense boundary is that fallback, not
       * decorative. FullPageSpinner is correct here specifically because
       * a route transition is a full-page-replacing navigation, not
       * in-page data loading (which always uses Skeleton instead).
       *
       * The <main> landmark + skip link above are the one page-level pair
       * for the whole app (individual pages must not render their own
       * <main> — JobsPage/CompaniesPage's inner layout divs were changed
       * from <main> to <div> for exactly this reason, to avoid two nested
       * <main> landmarks on the same page, which is invalid and confuses
       * screen-reader landmark navigation). tabIndex={-1} lets the skip
       * link's focus jump land here even though a plain <main> isn't
       * normally focusable.
       */}
      <main id="jp-main-content" tabIndex={-1}>
        {/*
         * Route-scoped, separate from the last-resort boundary main.tsx
         * wraps the whole tree in: this one contains a single page's crash
         * to the content area, so the header above stays intact and the
         * user can navigate away without a full reload. The recovery UI's
         * "Reload page"/"Go to homepage" actions are both full navigations
         * anyway, so there's no need to reset this boundary's state on
         * route change — it never has to recover in place.
         */}
        <ErrorBoundary>
          <Suspense fallback={<FullPageSpinner />}>
            <Outlet />
          </Suspense>
        </ErrorBoundary>
      </main>
      {!isAuthPage && <SiteFooter />}
    </div>
  )
}
