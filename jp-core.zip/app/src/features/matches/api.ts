import { api } from '@/lib/apiClient'

/**
 * GET /candidates/me/matches -> JP_Matching::get_matches_for_candidate().
 * The two code paths inside that method return genuinely different row
 * shapes (a known, pre-existing inconsistency, not something to "fix" here
 * since the backend is frozen): the pre-computed jp_matches path selects
 * `m.*, j.title, ...` (so `id` is the MATCH row's id, and the job id lives
 * in `job_id`); the real-time fallback path array_merges a full jp_jobs
 * row (so `id` IS the job id, and there is no `job_id` key at all). Both
 * paths do always include `title`, `company_name`, and `score`, so the
 * frontend link target is computed defensively below rather than trusting
 * either field name alone.
 */
export interface MatchRow {
  id: number
  job_id?: number
  title: string
  company_name: string
  location_city?: string
  work_mode?: string
  job_type?: string
  salary_min?: number
  salary_max?: number
  score: number
  /**
   * JSON-encoded JP_Matching::score_breakdown() output. Present on BOTH
   * response paths now (Tier A batch 5 redesign pass added it to the
   * real-time-fallback path for parity — see class-jp-matching.php) so
   * "why this match" can be shown regardless of which path served this
   * row. Still optional in the type since older cached data or an
   * unscored edge case could omit it.
   */
  score_detail?: string
}

/** Parsed shape of a decoded `score_detail` string — mirrors JP_Matching::score_breakdown(). */
export interface MatchScoreBreakdown {
  skills: number
  experience: number
  location: number
  education: number
  salary: number
  weights: { skills: number; experience: number; location: number; education: number; salary: number }
}

export function parseScoreDetail(row: MatchRow): MatchScoreBreakdown | null {
  if (!row.score_detail) return null
  try {
    return JSON.parse(row.score_detail) as MatchScoreBreakdown
  } catch {
    return null
  }
}

export function getMatches(): Promise<MatchRow[]> {
  return api.get<MatchRow[]>('/candidates/me/matches')
}

/** The job detail route id — see this file's docblock for why this can't just be `row.id`. */
export function matchJobId(row: MatchRow): number {
  return row.job_id ?? row.id
}

/**
 * POST /candidates/me/matches/:job_id/dismiss -> JP_API::dismiss_match().
 * "Not interested, stop recommending this" — distinct from saving a job.
 * Persists to jp_match_dismissals; get_matches_for_candidate() excludes
 * dismissed job_ids on the next fetch (both its pre-computed and
 * real-time-fallback paths), so we also optimistically drop the row from
 * the local list on success rather than waiting on a refetch.
 */
export function dismissMatch(jobId: number): Promise<{ message: string }> {
  return api.post<{ message: string }>(`/candidates/me/matches/${jobId}/dismiss`)
}
