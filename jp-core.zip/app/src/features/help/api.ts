import { api } from '@/lib/apiClient'

/** Transcribed from help_articles()'s default-seed array shape. */
export interface HelpArticle {
  id: number
  category: string
  title: string
  body: string
}

export function listHelpArticles(q?: string): Promise<HelpArticle[]> {
  return api.get<HelpArticle[]>('/help/articles', q ? { q } : undefined)
}

export function submitHelpContact(payload: {
  name: string
  email: string
  subject?: string
  message: string
}): Promise<{ message: string }> {
  return api.post('/help/contact', payload)
}

/** Transcribed from get_changelog()'s literal array shape. */
export interface ChangelogEntry {
  version: string
  date: string
  type: 'major' | 'minor' | 'patch'
  notes: string[]
}

export function getChangelog(): Promise<ChangelogEntry[]> {
  return api.get<ChangelogEntry[]>('/changelog')
}
