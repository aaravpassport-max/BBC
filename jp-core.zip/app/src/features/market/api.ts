import { api } from '@/lib/apiClient'

/** Transcribed from salary_insights()'s return array. */
export interface SalaryInsights {
  avg_min: number
  avg_max: number
  p25: number
  p75: number
  sample_size: number
}

export function getSalaryInsights(role?: string, location?: string): Promise<SalaryInsights> {
  const query: Record<string, string> = {}
  if (role) query.role = role
  if (location) query.location = location
  return api.get<SalaryInsights>('/salary/insights', query)
}

/** Transcribed from market_insights()'s compact()'d return shape. */
export interface TrendingSkill {
  name: string
  demand: number
}

export interface TopHiringCompany {
  name: string
  logo_url: string | null
  jobs: number
}

export interface AvgSalaryByRole {
  title: string
  avg_salary: number
  openings: number
}

/** Real GROUP BY aggregates added to market_insights() (job_type/location_city
 *  columns already existed on jp_jobs and were already used for filtering on
 *  JobsPage — this just surfaces the counts for a homepage browse section). */
export interface JobTypeBreakdown {
  job_type: string
  jobs: number
}

export interface TopLocation {
  location_city: string
  jobs: number
}

export interface MarketInsights {
  trending_skills: TrendingSkill[]
  top_hiring: TopHiringCompany[]
  avg_salary_by_role: AvgSalaryByRole[]
  stats: {
    active_jobs: number
    companies_hiring: number
    new_jobs_today: number
    remote_jobs: number
  }
  job_type_breakdown: JobTypeBreakdown[]
  top_locations: TopLocation[]
}

export function getMarketInsights(): Promise<MarketInsights> {
  return api.get<MarketInsights>('/market/insights')
}
