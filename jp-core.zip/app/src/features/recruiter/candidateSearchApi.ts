import { api } from '@/lib/apiClient'
import type { CandidateProfile } from '@/features/candidates/api'

/** get_candidates()'s row shape: jp_candidates' columns (SELECT c.*) plus the joined user fields and batched-on skills array. */
export interface CandidateSearchRow extends CandidateProfile {
  display_name: string
  user_email: string
}

export interface CandidateSearchParams {
  q?: string
  location?: string
  skill?: string
  exp_min?: number
  exp_max?: number
  work_mode?: string
  page?: number
  per_page?: number
}

export function searchCandidates(
  params: CandidateSearchParams,
): Promise<{ candidates: CandidateSearchRow[]; total: number }> {
  const query: Record<string, string | number | undefined> = { ...params }
  return api.get<{ candidates: CandidateSearchRow[]; total: number }>('/candidates', query)
}

/** get_candidate() — same row shape as CandidateProfile, with skills attached the same way get_me() does for the candidate's own profile. */
export function getCandidateDetail(id: number): Promise<CandidateProfile> {
  return api.get<CandidateProfile>(`/candidates/${id}`)
}
