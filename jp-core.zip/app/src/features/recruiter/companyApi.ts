import { api } from '@/lib/apiClient'
import type { CompanyRow } from '@/features/companies/api'

/**
 * Depth pass (Naukri/JobHai benchmarking, batch 4) — get_recruiter_company()
 * returns the raw jp_companies row (SELECT *), which includes email/phone/
 * founded_year (real columns, class-jp-activator.php's CREATE TABLE) on top
 * of everything on the public CompanyRow shape. The public getCompany()
 * endpoint doesn't expose these (correctly — they're the recruiter's own
 * contact details, not public profile fields), so CompanyRow itself is left
 * unchanged; this recruiter-only extension is additive.
 */
export interface RecruiterCompanyRow extends CompanyRow {
  email: string | null
  phone: string | null
  founded_year: number | null
}

export function getRecruiterCompany(): Promise<RecruiterCompanyRow> {
  return api.get<RecruiterCompanyRow>('/recruiter/company')
}

/** Whitelist transcribed from update_recruiter_company()'s $allowed array. */
export interface CompanyUpdatePayload {
  name?: string
  description?: string
  website?: string
  email?: string
  phone?: string
  industry?: string
  size_range?: string
  headquarters?: string
  founded_year?: number
}

export function updateRecruiterCompany(payload: CompanyUpdatePayload): Promise<{ message: string }> {
  return api.put<{ message: string }>('/recruiter/company', payload)
}
