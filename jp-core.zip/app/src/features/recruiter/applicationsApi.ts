import { api, getRuntimeConfig } from '@/lib/apiClient'
import type { ApplicationStage, OfferStatus } from '@/features/applications/api'

/** Transcribed from get_recruiter_applications()'s JOINed SELECT. */
export interface RecruiterApplicationRow {
  id: number
  job_id: number
  candidate_id: number
  stage: ApplicationStage
  match_score: number
  created_at: string
  job_title: string
  candidate_name: string
  candidate_email: string
  headline: string | null
  experience_years: number | null
  avatar_url: string | null
  location_city: string | null
  profile_score: number | null
  current_title: string | null
  offer_ctc: number
  offer_pdf_url: string | null
  offer_status: OfferStatus
  tags?: string[]
}

/** A single entry in the notes/stage_history JSON columns. */
export interface ApplicationNote {
  text: string
  user_id: number
  created_at: string
}

export interface ApplicationStageHistoryEntry {
  stage: ApplicationStage
  timestamp: string
  actor_id: number
  note: string
}

/**
 * New in batch 37 (recruiter ATS pipeline depth). Transcribed from
 * get_application()'s enriched SELECT (class-jp-api.php) — the full
 * application row plus joined display fields, with the JSON columns
 * already decoded server-side.
 */
export interface ApplicationDetail {
  id: number
  job_id: number
  candidate_id: number
  company_id: number
  resume_id: number
  cover_letter: string | null
  screening_ans: string[]
  stage: ApplicationStage
  stage_history: ApplicationStageHistoryEntry[]
  match_score: number
  notes: ApplicationNote[]
  tags: string[]
  offer_ctc: number
  offer_pdf_url: string | null
  offer_status: OfferStatus
  source: string
  created_at: string
  updated_at: string
  job_title: string | null
  company_name: string | null
  candidate_name: string | null
  candidate_email: string | null
  resume_file_name: string | null
}

export function getApplicationDetail(id: number): Promise<ApplicationDetail> {
  return api.get<ApplicationDetail>(`/applications/${id}`)
}

/**
 * The application's screening questions live on the job posting
 * (jp_jobs.screening_q), not on the application row — the candidate's
 * answers (screening_ans) are stored positionally against them. Callers
 * that need question text alongside answers should pair this with the
 * job's own screening_q (already fetched for the job elsewhere).
 */
export function addApplicationNote(id: number, note: string): Promise<{ message: string; note: ApplicationNote }> {
  return api.post<{ message: string; note: ApplicationNote }>(`/applications/${id}/note`, { note })
}

/** Replaces the application's whole tag set — see ajax_set_tags()'s docblock. */
export function setApplicationTags(id: number, tags: string[]): Promise<{ message: string; tags: string[] }> {
  return api.put<{ message: string; tags: string[] }>(`/applications/${id}/tags`, { tags })
}

/**
 * view_application_resume() streams a raw binary file, not JSON, so it
 * can't go through apiRequest() (which always calls res.json() — see
 * apiClient.ts). It's meant to be opened directly (new tab / anchor
 * href), authenticated via the WordPress cookie-auth `_wpnonce` query
 * param that WP core's rest_cookie_check_errors() accepts for exactly
 * this "plain link to a REST endpoint" case (X-WP-Nonce header isn't
 * available on a plain navigation).
 */
export function getApplicationResumeUrl(id: number): string {
  const { apiUrl, nonce } = getRuntimeConfig()
  return `${apiUrl.replace(/\/$/, '')}/applications/${id}/resume?_wpnonce=${encodeURIComponent(nonce)}`
}

export function listRecruiterApplications(params: { job_id?: number; stage?: ApplicationStage; page?: number } = {}) {
  const query: Record<string, string | number | undefined> = {}
  if (params.job_id) query.job_id = params.job_id
  if (params.stage) query.stage = params.stage
  if (params.page) query.page = params.page
  return api.get<{ applications: RecruiterApplicationRow[]; total: number }>('/recruiter/applications', query)
}

export function moveApplicationStage(id: number, stage: ApplicationStage, note?: string): Promise<{ message?: string }> {
  return api.put<{ message?: string }>(`/applications/${id}/stage`, { stage, note })
}

/** bulk_move_stage() skips (not fails) applications the caller doesn't own the job for. */
/**
 * Root-cause fix (batch 16): bulk_move_stage()'s write is now checked
 * per-item (class-jp-api.php) instead of unconditionally counting every id
 * as moved — `failed` reflects how many rows didn't actually persist, and
 * `message` already includes a "N could not be updated" suffix when > 0.
 */
export function bulkMoveStage(ids: number[], stage: ApplicationStage): Promise<{ moved: number; failed: number; message: string }> {
  return api.post<{ moved: number; failed: number; message: string }>('/applications/bulk-stage', { ids, stage })
}

/**
 * Root-cause fix (batch 21, backlog "offer-letter/e-signature workflow"):
 * JP_Applications::ajax_generate_offer() had existed with no REST route and
 * no SPA caller anywhere — a recruiter could never actually generate or
 * send an offer letter through the live app. Wraps the new
 * POST /applications/{id}/generate-offer route.
 */
export function generateOffer(id: number, offerCtc?: number): Promise<{ message: string; pdf_url: string }> {
  return api.post<{ message: string; pdf_url: string }>(`/applications/${id}/generate-offer`, {
    offer_ctc: offerCtc ?? 0,
  })
}

/**
 * Root-cause fix ("much more ground" pass): admin_csv_export() already let
 * an admin export ANY recruiter's applications, but a recruiter had no
 * self-service way to export their OWN applicant list — a standard ATS
 * capability (share a shortlist with a hiring manager, keep an offline
 * record). Mirrors downloadCsvExport() (features/admin/api.ts) exactly —
 * same fetch-blob-download pattern, since recruiter_export_applications()
 * (class-jp-api.php) returns raw text/csv, not the {success,data} envelope
 * api.get() expects.
 */
export async function downloadMyApplicationsCsv(jobId?: number): Promise<void> {
  const { apiUrl, nonce } = getRuntimeConfig()
  const endpoint =
    apiUrl.replace(/\/$/, '') + '/recruiter/applications/export' + (jobId ? `?job_id=${jobId}` : '')
  const res = await fetch(endpoint, {
    headers: { 'X-WP-Nonce': nonce },
    credentials: 'same-origin',
  })
  if (!res.ok) throw new Error(`Export failed (HTTP ${res.status}).`)
  const blob = await res.blob()
  const blobUrl = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = blobUrl
  a.download = `jp_my_applicants_${new Date().toISOString().slice(0, 10)}.csv`
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(blobUrl)
}
