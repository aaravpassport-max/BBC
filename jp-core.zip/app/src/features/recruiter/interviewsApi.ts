import { api } from '@/lib/apiClient'

/** Transcribed from jp_interviews' CREATE TABLE + get_interviews()'s JOINed columns. */
export interface InterviewRow {
  id: number
  application_id: number
  job_id: number
  candidate_id: number
  recruiter_id: number
  round: number
  type: 'phone' | 'video' | 'onsite' | 'technical' | 'hr'
  scheduled_at: string | null
  duration_min: number
  meeting_link: string | null
  location: string | null
  notes: string | null
  feedback: string | null
  rating: number
  outcome: 'pending' | 'passed' | 'failed' | 'cancelled' | 'no_show'
  /** Batch 36: candidate-side response to a scheduled interview. */
  candidate_confirmed: 0 | 1
  reschedule_requested: 0 | 1
  reschedule_reason: string | null
  created_at: string
  job_title: string | null
  candidate_name: string | null
}

export function listInterviews(): Promise<InterviewRow[]> {
  return api.get<InterviewRow[]>('/interviews')
}

/** Whitelist transcribed from schedule_interview()'s read params — application_id/scheduled_at required. */
export interface ScheduleInterviewPayload {
  application_id: number
  scheduled_at: string
  type?: InterviewRow['type']
  meet_link?: string
  location?: string
  notes?: string
}

export function scheduleInterview(payload: ScheduleInterviewPayload): Promise<{ message: string }> {
  return api.post('/interviews', payload)
}

export function cancelInterview(id: number): Promise<{ message: string }> {
  return api.delete(`/interviews/${id}`)
}

/** Whitelist transcribed from submit_interview_feedback()'s read params. */
export interface InterviewFeedbackPayload {
  outcome: 'passed' | 'failed' | 'no_show'
  rating?: number
  feedback?: string
}

export function submitInterviewFeedback(
  id: number,
  payload: InterviewFeedbackPayload,
): Promise<{ message: string }> {
  return api.put(`/interviews/${id}/feedback`, payload)
}

/**
 * Batch 26 (closes the multi-interviewer half of the "interview panel/
 * scorecard collaboration" backlog item — batch 20 only closed the
 * single-reviewer version, which submitInterviewFeedback() above wraps).
 * Several named panelists can each submit an independent scorecard on the
 * same interview. See class-jp-api.php's add_interview_panelist()
 * docblock — a panelist must be an active team member of the interview's
 * company, so this list only ever comes from a real team roster.
 */
export interface PanelistRow {
  id: number
  interview_id: number
  panelist_id: number
  added_by: number
  rating: number
  feedback: string | null
  outcome: 'pending' | 'passed' | 'failed' | 'no_show'
  submitted_at: string | null
  created_at: string
  panelist_name: string | null
}

export function listPanelists(interviewId: number): Promise<PanelistRow[]> {
  return api.get<PanelistRow[]>(`/interviews/${interviewId}/panelists`)
}

export function addPanelist(interviewId: number, panelistId: number): Promise<{ message: string; id: number }> {
  return api.post<{ message: string; id: number }>(`/interviews/${interviewId}/panelists`, { panelist_id: panelistId })
}

export function removePanelist(interviewId: number, panelistRowId: number): Promise<{ message: string }> {
  return api.delete<{ message: string }>(`/interviews/${interviewId}/panelists/${panelistRowId}`)
}

export function submitPanelistFeedback(
  interviewId: number,
  panelistRowId: number,
  payload: InterviewFeedbackPayload,
): Promise<{ message: string }> {
  return api.put<{ message: string }>(`/interviews/${interviewId}/panelists/${panelistRowId}/feedback`, payload)
}
