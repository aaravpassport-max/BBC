import { api } from '@/lib/apiClient'
import type { PlanRow } from '@/features/admin/api'

/** Transcribed from jp_subscriptions' CREATE TABLE. */
export interface SubscriptionRow {
  id: number
  user_id: number
  company_id: number
  plan_id: number
  razorpay_sub_id: string | null
  billing_cycle: 'monthly' | 'yearly'
  status: 'trial' | 'active' | 'past_due' | 'cancelled' | 'expired'
  credits_json: string | null
  starts_at: string | null
  expires_at: string | null
  cancelled_at: string | null
  created_at: string
}

/** Transcribed from get_recruiter_subscription()'s return shape — 'none' when JP_Subscriptions has no active row. */
export interface RecruiterSubscription {
  status: 'none' | SubscriptionRow['status']
  plan: PlanRow | null
  subscription?: SubscriptionRow
  credits: Record<string, number>
}

export function getRecruiterSubscription(): Promise<RecruiterSubscription> {
  return api.get<RecruiterSubscription>('/recruiter/subscription')
}

/** Transcribed from get_recruiter_invoices()'s explicit SELECT column list. */
export interface InvoiceRow {
  id: number
  amount: number
  currency: string
  status: 'created' | 'paid' | 'failed' | 'refunded' | 'abandoned'
  description: string | null
  invoice_url: string | null
  created_at: string
}

export function getRecruiterInvoices(): Promise<InvoiceRow[]> {
  return api.get<InvoiceRow[]>('/recruiter/invoices')
}
