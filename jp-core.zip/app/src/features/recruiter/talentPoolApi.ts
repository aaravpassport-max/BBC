import { api } from '@/lib/apiClient'
import type { CandidateSearchRow } from '@/features/recruiter/candidateSearchApi'

/**
 * GET /recruiter/talent-pool — bare array, joined with saved_at/note.
 * Structural mirror of features/savedJobs/api.ts's SavedJobRow, on the
 * candidate side of the relationship: a recruiter's saved candidates
 * instead of a candidate's saved jobs.
 */
export type SavedCandidateRow = CandidateSearchRow & { saved_at: string; note: string | null }

export function listTalentPool(): Promise<SavedCandidateRow[]> {
  return api.get<SavedCandidateRow[]>('/recruiter/talent-pool')
}

/** POST /candidates/:id/save toggles save state; returns the new state. */
export function toggleSaveCandidate(candidateId: number): Promise<{ saved: boolean; message: string }> {
  return api.post<{ saved: boolean; message: string }>(`/candidates/${candidateId}/save`)
}

/**
 * Root-cause fix (schema-exists-no-writer gap): jp_saved_candidates.note
 * was already SELECTed by get_talent_pool() (SavedCandidateRow.note above)
 * but had no writer anywhere — update_saved_candidate_note() (class-jp-api.php)
 * is the first and only way to actually set it.
 */
export function updateSavedCandidateNote(candidateId: number, note: string): Promise<{ message: string; note: string }> {
  return api.put<{ message: string; note: string }>(`/recruiter/talent-pool/${candidateId}/note`, { note })
}
