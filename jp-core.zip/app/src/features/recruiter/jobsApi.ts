import { api } from '@/lib/apiClient'
import type { JobRow } from '@/features/jobs/api'

export interface RecruiterJobRow extends JobRow {
  applications_cnt: number
}

export function listRecruiterJobs(params: { status?: string; page?: number } = {}): Promise<{ jobs: RecruiterJobRow[]; total: number }> {
  const query: Record<string, string | number | undefined> = {}
  if (params.status) query.status = params.status
  if (params.page) query.page = params.page
  return api.get<{ jobs: RecruiterJobRow[]; total: number }>('/recruiter/jobs', query)
}

/** Whitelist transcribed from JP_Api::extract_job_data(). */
export interface JobFormPayload {
  title: string
  description: string
  requirements?: string
  job_type: string
  work_mode: string
  location_city?: string
  location_state?: string
  salary_min?: number
  salary_max?: number
  /** Whether candidates see the salary range on the listing; jp_jobs.salary_visible defaults to 1. */
  salary_visible?: boolean
  experience_min?: number
  experience_max?: number
  skills?: string[]
  industry?: string
  education_level?: string
  openings?: number
  /** Batch 35: now actually persisted — see extract_job_data()'s docblock in class-jp-api.php. */
  screening_questions?: { question: string; required: boolean }[]
}

export function createJob(payload: JobFormPayload): Promise<{ id: number; message: string }> {
  return api.post<{ id: number; message: string }>('/jobs', payload)
}

export function updateJob(id: number, payload: JobFormPayload): Promise<{ message: string }> {
  return api.put<{ message: string }>(`/jobs/${id}`, payload)
}

export function deleteJob(id: number): Promise<{ message: string }> {
  return api.delete<{ message: string }>(`/jobs/${id}`)
}

/** repost_job() clones an expired/closed job into a fresh pending listing with a de-duplicated slug. */
export function repostJob(id: number): Promise<{ id: number; message: string }> {
  return api.post<{ id: number; message: string }>(`/jobs/${id}/repost`)
}

export type BulkJobAction = 'pause' | 'activate' | 'delete' | 'feature' | 'unfeature'

/** bulk_job_action() skips (not fails) ids the caller doesn't own — returns how many actually changed vs skipped. */
export function bulkJobAction(ids: number[], action: BulkJobAction): Promise<{ done: number; skipped: number; message: string }> {
  return api.post<{ done: number; skipped: number; message: string }>('/jobs/bulk-action', { ids, action })
}
