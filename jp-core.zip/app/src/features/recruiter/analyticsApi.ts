import { api } from '@/lib/apiClient'

export interface FunnelRow {
  stage: string
  cnt: number
}

export interface FunnelReachRow {
  stage: string
  reached: number
  conversion_from_applied_pct: number | null
}

export interface TopJobRow {
  title: string
  views_count: number
  app_count: number
}

/** Transcribed field-for-field from compute_recruiter_analytics()'s return array. */
export interface RecruiterAnalytics {
  active_jobs: number
  total_apps: number
  new_apps: number
  hired: number
  total_views: number
  avg_match: number
  funnel: FunnelRow[]
  funnel_reach: FunnelReachRow[]
  avg_time_to_hire_days: number | null
  offer_acceptance_rate_pct: number | null
  top_jobs: TopJobRow[]
  days: number
}

export function getRecruiterAnalytics(days = 30): Promise<RecruiterAnalytics> {
  return api.get<RecruiterAnalytics>('/recruiter/analytics', { days })
}
