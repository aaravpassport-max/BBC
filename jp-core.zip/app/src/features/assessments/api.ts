import { api } from '@/lib/apiClient'

/** Transcribed from get_assessments()'s JOINed SELECT (HAVING question_count >= 5). */
export interface AssessmentSkillRow {
  skill_id: number
  skill_name: string
  category: string | null
  question_count: number
  badge_level: 'gold' | 'silver' | 'bronze' | 'none' | null
  score: number | null
  taken_at: string | null
  expires_at: string | null
}

export function listAssessmentSkills(): Promise<AssessmentSkillRow[]> {
  return api.get<AssessmentSkillRow[]>('/assessments')
}

export interface AssessmentQuestion {
  id: number
  question: string
  options: string[]
}

/** take_assessment() with no `answers` param: fetches a fresh 10-question set. */
export interface AssessmentStart {
  questions: AssessmentQuestion[]
  skill_id: number
}

export function startAssessment(skillId: number): Promise<AssessmentStart> {
  return api.post<AssessmentStart>(`/assessments/${skillId}/take`, {})
}

export interface AssessmentResultItem {
  question: string
  your_answer: number
  correct: number
  explanation: string | null
  is_correct: boolean
}

/**
 * take_assessment() with `answers` submitted: scores them. Same endpoint as
 * startAssessment(). Root-cause fix (Phase 3 redesign pass): this used to
 * re-run `ORDER BY RAND() LIMIT 10` on every call, so the submit call could
 * score against a genuinely different question set than the one the
 * candidate was actually shown — silently wrong scores/badges. The backend
 * now persists the exact question-id set (in order) handed out on the
 * start call to a short-lived transient and reads it back here, so this
 * client submitting answers in the same array order they were presented
 * is guaranteed to be scored against those same questions (falls back to a
 * fresh random draw only if the transient expired — an edge case with no
 * persisted reference to score against either way).
 */
export interface AssessmentResult {
  score: number
  badge_level: 'gold' | 'silver' | 'bronze' | 'none'
  correct: number
  total: number
  results: AssessmentResultItem[]
}

export function submitAssessment(skillId: number, answers: number[]): Promise<AssessmentResult> {
  return api.post<AssessmentResult>(`/assessments/${skillId}/take`, { answers })
}
