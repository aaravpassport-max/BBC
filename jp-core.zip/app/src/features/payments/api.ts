import { api } from '@/lib/apiClient'

/**
 * Root-cause fix (batch 10 — see class-jp-payments.php's do_create_order()
 * docblock and class-jp-api.php's new /payments/* routes for the full gap
 * trace). Order creation and payment verification have always existed as
 * fully-working backend logic, but with zero REST route and zero SPA call
 * anywhere — there was never any way to actually buy a plan through the
 * live app. This wraps the two new routes, and loadRazorpayCheckout()
 * dynamically loads Razorpay's own checkout.js (their hosted payment
 * modal — card details never touch this server, same as before this
 * batch; only the missing "start a purchase" step is new).
 *
 * Batch 12 — Stripe gateway abstraction. do_create_order() (class-jp-
 * payments.php) now returns one of two shapes depending on the site's
 * active gateway (config.payment_gateway) — a Razorpay order to open in
 * checkout.js's modal, or a Stripe Checkout Session to redirect the whole
 * page to. CreateOrderResult below is that discriminated union; callers
 * branch on `gateway`.
 */
export interface RazorpayOrderResult {
  gateway: 'razorpay'
  order_id: string
  amount: number
  key_id: string
}

export interface StripeSessionResult {
  gateway: 'stripe'
  checkout_url: string
  session_id: string
}

export type CreateOrderResult = RazorpayOrderResult | StripeSessionResult

export function createOrder(planId: number, billing: 'monthly' | 'yearly'): Promise<CreateOrderResult> {
  return api.post<CreateOrderResult>('/payments/create-order', { plan_id: planId, billing })
}

export interface VerifyPaymentPayload {
  razorpay_order_id: string
  razorpay_payment_id: string
  razorpay_signature: string
}

export interface VerifyPaymentResult {
  message: string
  invoice_url?: string
}

export function verifyPayment(payload: VerifyPaymentPayload): Promise<VerifyPaymentResult> {
  return api.post<VerifyPaymentResult>('/payments/verify', payload)
}

/**
 * Batch 12 — the Stripe counterpart to verifyPayment(). Called once, after
 * Stripe redirects the browser back to success_url with
 * ?stripe_session_id=... substituted in (see do_create_stripe_session()'s
 * docblock) — RecruiterBillingPage.tsx reads that query param on mount.
 */
export function verifyStripeSession(sessionId: string): Promise<VerifyPaymentResult> {
  return api.post<VerifyPaymentResult>('/payments/verify-stripe-session', { session_id: sessionId })
}

const RAZORPAY_SCRIPT_SRC = 'https://checkout.razorpay.com/v1/checkout.js'

declare global {
  interface Window {
    Razorpay?: new (options: RazorpayOptions) => { open(): void }
  }
}

interface RazorpayOptions {
  key: string
  order_id: string
  amount: number
  currency: string
  name: string
  description: string
  handler: (response: { razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string }) => void
  modal?: { ondismiss?: () => void }
  prefill?: { name?: string; email?: string }
  theme?: { color?: string }
}

let scriptLoadPromise: Promise<void> | null = null

/** Loads checkout.js exactly once per page session, reusing the same promise on repeat calls. */
function loadRazorpayScript(): Promise<void> {
  if (window.Razorpay) return Promise.resolve()
  if (scriptLoadPromise) return scriptLoadPromise
  scriptLoadPromise = new Promise((resolve, reject) => {
    const existing = document.querySelector<HTMLScriptElement>(`script[src="${RAZORPAY_SCRIPT_SRC}"]`)
    if (existing) {
      existing.addEventListener('load', () => resolve())
      existing.addEventListener('error', () => reject(new Error('Could not load the payment library.')))
      return
    }
    const script = document.createElement('script')
    script.src = RAZORPAY_SCRIPT_SRC
    script.async = true
    script.onload = () => resolve()
    script.onerror = () => reject(new Error('Could not load the payment library.'))
    document.body.appendChild(script)
  })
  return scriptLoadPromise
}

export interface OpenCheckoutParams {
  order: RazorpayOrderResult
  siteName: string
  planName: string
  billing: 'monthly' | 'yearly'
  userName?: string
  userEmail?: string
  onSuccess: (verified: VerifyPaymentResult) => void
  onFailure: (message: string) => void
  onDismiss?: () => void
}

/**
 * Opens Razorpay's hosted checkout modal for an order already created via
 * createOrder(), then calls verifyPayment() with the result it hands back
 * in its own success handler — the same order_id/payment_id/signature
 * triple do_verify_payment() has always validated server-side.
 */
export async function openRazorpayCheckout(params: OpenCheckoutParams): Promise<void> {
  try {
    await loadRazorpayScript()
  } catch (e) {
    params.onFailure(e instanceof Error ? e.message : 'Could not load the payment library.')
    return
  }
  if (!window.Razorpay) {
    params.onFailure('Could not load the payment library.')
    return
  }

  const rzp = new window.Razorpay({
    key: params.order.key_id,
    order_id: params.order.order_id,
    amount: params.order.amount,
    currency: 'INR',
    name: params.siteName,
    description: `${params.planName} Plan (${params.billing === 'yearly' ? 'Yearly' : 'Monthly'})`,
    handler: (response) => {
      verifyPayment(response)
        .then((result) => params.onSuccess(result))
        .catch((e) => params.onFailure(e instanceof Error ? e.message : 'Payment was made but could not be verified. Please contact support.'))
    },
    modal: { ondismiss: params.onDismiss },
    prefill: { name: params.userName, email: params.userEmail },
    theme: { color: '#156BC9' },
  })
  rzp.open()
}
