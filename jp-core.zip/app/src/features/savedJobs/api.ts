import { api } from '@/lib/apiClient'
import type { JobRow } from '@/features/jobs/api'

/** GET /candidates/me/saved-jobs — bare array, joined with saved_at/note. */
export type SavedJobRow = JobRow & { saved_at: string; note: string | null }

export function listSavedJobs(): Promise<SavedJobRow[]> {
  return api.get<SavedJobRow[]>('/candidates/me/saved-jobs')
}

/** POST /jobs/:id/save toggles save state; returns the new state. */
export function toggleSaveJob(jobId: number): Promise<{ saved: boolean; message: string }> {
  return api.post<{ saved: boolean; message: string }>(`/jobs/${jobId}/save`)
}

/**
 * Root-cause fix (schema-exists-no-writer gap, same bug class fixed on the
 * recruiter talent-pool side first): jp_saved_jobs.note is now selected by
 * get_saved_jobs() but had no writer anywhere until this endpoint.
 */
export function updateSavedJobNote(jobId: number, note: string): Promise<{ message: string; note: string }> {
  return api.put<{ message: string; note: string }>(`/candidates/me/saved-jobs/${jobId}/note`, { note })
}
