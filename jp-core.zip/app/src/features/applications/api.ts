import { api, getRuntimeConfig } from '@/lib/apiClient'

export type ApplicationStage =
  | 'applied'
  | 'shortlisted'
  | 'viewed'
  | 'phone_screen'
  | 'interview'
  | 'assessment'
  | 'offer'
  | 'hired'
  | 'rejected'
  | 'withdrawn'

export type OfferStatus = 'none' | 'sent' | 'accepted' | 'declined'

/** Transcribed from jp_applications' CREATE TABLE + get_applications()'s JOINed columns. */
export interface ApplicationRow {
  id: number
  job_id: number
  candidate_id: number
  company_id: number
  resume_id: number
  cover_letter: string | null
  stage: ApplicationStage
  match_score: number
  interview_date: string | null
  offer_ctc: number
  offer_pdf_url: string | null
  offer_status: OfferStatus
  offer_responded_at: string | null
  source: string
  created_at: string
  job_title: string
  candidate_name: string
}

/**
 * GET /applications returns a bare array, NOT {items,total,...} — confirmed
 * against get_applications()'s `return $this->ok( $rows ?: [] );`.
 */
export function listApplications(params: { stage?: ApplicationStage; page?: number } = {}): Promise<ApplicationRow[]> {
  const query: Record<string, string | number | undefined> = {}
  if (params.stage) query.stage = params.stage
  if (params.page) query.page = params.page
  return api.get<ApplicationRow[]>('/applications', query)
}

export function getApplication(id: number): Promise<ApplicationRow> {
  return api.get<ApplicationRow>(`/applications/${id}`)
}

/** A candidate-safe stage_history entry — get_application() (class-jp-api.php,
 * batch 38 privacy fix) strips the internal `note`/`actor_id` fields before
 * returning stage_history to the application's own candidate, so only the
 * stage+timestamp sequence is ever present on this shape. */
export interface CandidateStageHistoryEntry {
  stage: ApplicationStage
  timestamp: string
}

/**
 * New in batch 38 (candidate application-tracking depth). Transcribed from
 * get_application()'s candidate branch — the same enriched endpoint the
 * recruiter ATS detail panel uses (features/recruiter/applicationsApi.ts's
 * ApplicationDetail), but with notes/tags always empty and stage_history
 * stripped to stage+timestamp only for this caller (see that endpoint's
 * docblock for why: internal recruiter commentary was never meant to be
 * candidate-facing).
 */
export interface CandidateApplicationDetail extends ApplicationRow {
  screening_ans: string[]
  stage_history: CandidateStageHistoryEntry[]
  resume_file_name: string | null
  company_name: string | null
}

export function getApplicationDetail(id: number): Promise<CandidateApplicationDetail> {
  return api.get<CandidateApplicationDetail>(`/applications/${id}`)
}

/**
 * Streams the candidate's own resume for this application — see
 * class-jp-api.php's view_application_resume() docblock. Returns raw
 * binary, not JSON, so (like the recruiter-side equivalent in
 * features/recruiter/applicationsApi.ts) this is a URL to open directly,
 * authenticated via the wp_rest cookie-auth `_wpnonce` query param.
 */
export function getApplicationResumeUrl(id: number): string {
  const { apiUrl, nonce } = getRuntimeConfig()
  return `${apiUrl.replace(/\/$/, '')}/applications/${id}/resume?_wpnonce=${encodeURIComponent(nonce)}`
}

/**
 * Root-cause fix (batch 16). JP_Applications::ajax_withdraw() (candidate
 * withdraws their own application — server-side scoped to their own
 * candidate_id, and refuses once an application has reached hired/rejected)
 * existed with no REST route or SPA caller anywhere: ApplicationsPage.tsx
 * has always displayed "Withdrawn" as a possible status badge with no
 * control that could ever produce it. Wraps the new
 * POST /applications/{id}/withdraw route (class-jp-api.php's
 * withdraw_application()).
 */
export interface SimpleMessageResult {
  message: string
}

export function withdrawApplication(id: number): Promise<SimpleMessageResult> {
  return api.post<SimpleMessageResult>(`/applications/${id}/withdraw`)
}

/**
 * Root-cause fix (batch 21). Wraps the new POST /applications/{id}/
 * offer-response route (class-jp-api.php's submit_offer_response() ->
 * JP_Applications::do_offer_response()) — the candidate's click-to-accept
 * response to a generated offer letter. Scoped server-side to the
 * candidate's own application, and only usable once (an offer that has
 * already been responded to cannot be re-submitted).
 */
export function respondToOffer(id: number, response: 'accepted' | 'declined'): Promise<SimpleMessageResult> {
  return api.post<SimpleMessageResult>(`/applications/${id}/offer-response`, { response })
}
