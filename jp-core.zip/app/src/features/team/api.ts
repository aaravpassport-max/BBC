import { api } from '@/lib/apiClient'

/**
 * Root-cause fix (batch 6). Wraps the new /team* REST routes
 * (class-jp-api.php's team_list/team_invite/team_accept/team_remove/
 * team_reassign_job) over JP_Team's do_*() methods (class-jp-team.php) —
 * see that class's docblock for the full gap trace: a complete,
 * seat-limited, audit-logged team-management feature existed with no
 * REST route and no SPA page anywhere, despite the jp_team_manager role
 * it's built for already being let into /recruiter by router.tsx.
 */
export interface TeamMember {
  id: number
  company_id: number
  user_id: number | null
  invited_email: string
  role: 'manager' | 'member'
  status: 'invited' | 'active' | 'removed'
  invited_at: string
  accepted_at: string | null
  display_name: string | null
  user_email_actual: string | null
}

export interface TeamListResult {
  members: TeamMember[]
  seats_used: number
  seats_limit: number
}

export function getTeam(): Promise<TeamListResult> {
  return api.get<TeamListResult>('/team')
}

export interface InviteResult {
  message: string
  seats_used: number
  seats_limit: number
}

export function inviteTeamMember(email: string, role: 'manager' | 'member'): Promise<InviteResult> {
  return api.post<InviteResult>('/team/invite', { email, role })
}

export interface AcceptResult {
  message: string
  company_id: number
}

export function acceptTeamInvite(token: string): Promise<AcceptResult> {
  return api.post<AcceptResult>('/team/accept', { token })
}

export interface SimpleMessageResult {
  message: string
}

export function removeTeamMember(memberId: number): Promise<SimpleMessageResult> {
  return api.delete<SimpleMessageResult>(`/team/${memberId}`)
}

/**
 * Root-cause fix (batch 13). do_reassign_job() (class-jp-team.php) and its
 * /team/reassign-job REST route (class-jp-api.php's team_reassign_job())
 * have existed since batch 6 with no SPA caller — noted in memory as the
 * one remaining "backend built, SPA-unreachable" item from that batch.
 * Wired into RecruiterJobsPage.tsx's per-job row for jp_team_manager users
 * (the only role with the jp_assign_jobs capability this route requires).
 */
export function reassignJob(jobId: number, userId: number): Promise<SimpleMessageResult> {
  return api.post<SimpleMessageResult>('/team/reassign-job', { job_id: jobId, user_id: userId })
}
