import { api } from '@/lib/apiClient'

/** account_export() returns a large nested object — treated as an opaque
 * downloadable JSON blob rather than typed field-by-field. */
export function exportAccountData(): Promise<Record<string, unknown>> {
  return api.get<Record<string, unknown>>('/account/export')
}

export function deleteAccount(password: string): Promise<{ message: string }> {
  return api.post('/account/delete', { password })
}
