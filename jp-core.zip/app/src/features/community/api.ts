import { api } from '@/lib/apiClient'

export const COMMUNITY_CATEGORIES = ['general', 'career', 'interview', 'salary', 'workplace', 'tech'] as const
export type CommunityCategory = (typeof COMMUNITY_CATEGORIES)[number]

/** Transcribed from jp_community_posts' CREATE TABLE + community_get_posts()'s JOINed columns. */
export interface CommunityPostRow {
  id: number
  user_id: number
  category: CommunityCategory
  title: string
  body: string
  tags_json: string | null
  views: number
  likes: number
  reply_count: number
  is_pinned: boolean | number
  is_resolved: boolean | number
  created_at: string
  updated_at: string
  display_name: string | null
}

export function listCommunityPosts(params: { category?: string; q?: string; sort?: 'popular' | 'recent'; page?: number } = {}) {
  const query: Record<string, string | number | undefined> = {}
  if (params.category) query.category = params.category
  if (params.q) query.q = params.q
  if (params.sort) query.sort = params.sort
  if (params.page) query.page = params.page
  return api.get<{ posts: CommunityPostRow[]; total: number }>('/community/posts', query)
}

export function getCommunityPost(id: number): Promise<CommunityPostRow> {
  return api.get<CommunityPostRow>(`/community/posts/${id}`)
}

export function createCommunityPost(payload: {
  title: string
  body: string
  category: CommunityCategory
  tags?: string[]
}): Promise<{ id: number; message: string }> {
  return api.post('/community/posts', payload)
}

export interface CommunityReplyRow {
  id: number
  post_id: number
  user_id: number
  body: string
  likes: number
  is_accepted: boolean | number
  created_at: string
  display_name: string | null
}

export function listCommunityReplies(postId: number): Promise<CommunityReplyRow[]> {
  return api.get<CommunityReplyRow[]>(`/community/posts/${postId}/replies`)
}

export function addCommunityReply(postId: number, body: string): Promise<{ id: number; message: string }> {
  return api.post(`/community/posts/${postId}/replies`, { body })
}

export function toggleCommunityLike(postId: number): Promise<{ likes: number; liked: boolean }> {
  return api.post(`/community/posts/${postId}/like`, {})
}

/**
 * Root-cause fix (batch 23): jp_community_replies.is_accepted and
 * jp_community_posts.is_resolved have existed since these tables were
 * created — is_accepted already drives the reply sort order and the SPA
 * already renders an "Accepted" badge for it — but no route ever wrote
 * either column, so a post's author had no way to actually mark an answer.
 * Toggles: calling this on an already-accepted reply un-accepts it.
 */
export function acceptCommunityReply(postId: number, replyId: number): Promise<{ message: string; is_accepted: boolean }> {
  return api.put(`/community/posts/${postId}/replies/${replyId}/accept`, {})
}
