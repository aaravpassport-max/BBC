import { api, apiUpload } from '@/lib/apiClient'

/** Wraps GET /wp-json/jp/v1/resumes — jp_resumes rows for the signed-in candidate. */
export interface ResumeRow {
  id: number
  user_id: number
  file_name: string
  file_url: string
  file_size?: number
  /** JSON-encoded JP_Resume::parse() output — see parseResumeDetail() below. */
  parsed_json?: string | null
  parsed_at?: string | null
  completeness?: number
  is_primary: 0 | 1
  created_at: string
}

/** Confidence for a heuristically-extracted field — only 'high' fields get auto-written to the profile (see JP_Resume::parse()'s docblock); 'low' fields are still shown here so the candidate can review them. */
export type FieldConfidence = 'high' | 'low'

export interface ParsedResumeDetail {
  name?: string
  email?: string
  phone?: string
  skills?: string[]
  experience_years?: number
  education?: string[]
  current_title?: string
  current_company?: string
  linkedin_url?: string
  raw_text_length?: number
  completeness: number
  error?: string
  field_confidence?: {
    experience_years?: FieldConfidence
    current_title?: FieldConfidence
    current_company?: FieldConfidence
  }
}

/**
 * JP_Resume::parse()'s own docblock notes this was built with "a future
 * review-before-applying UI" in mind but that no such UI existed yet
 * (out of scope for that backend pass). This is that UI's data layer —
 * ResumesPage surfaces the real parsed fields and flags low-confidence
 * ones for review, rather than silently trusting every heuristic guess.
 */
export function parseResumeDetail(resume: ResumeRow): ParsedResumeDetail | null {
  if (!resume.parsed_json) return null
  try {
    return JSON.parse(resume.parsed_json) as ParsedResumeDetail
  } catch {
    return null
  }
}

export function formatFileSize(bytes?: number): string | null {
  if (!bytes) return null
  if (bytes < 1024 * 1024) return `${Math.round(bytes / 1024)} KB`
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`
}

export function listResumes(): Promise<ResumeRow[]> {
  return api.get<ResumeRow[]>('/resumes')
}

/**
 * upload_resume() bridges to JP_Resume::ajax_upload(), which reads
 * $_FILES['resume'] and enforces PDF/DOC/DOCX + a configurable max size
 * (default 5MB) server-side — client-side we surface whatever message it
 * returns rather than duplicating that validation logic.
 */
export function uploadResume(file: File): Promise<ResumeRow> {
  return apiUpload<ResumeRow>('/resumes', 'resume', file)
}

export function deleteResume(id: number): Promise<{ message: string }> {
  return api.delete<{ message: string }>(`/resumes/${id}`)
}

export function setPrimaryResume(id: number): Promise<{ message: string }> {
  return api.put<{ message: string }>(`/resumes/${id}/primary`)
}
