import { api } from '@/lib/apiClient'

/** Transcribed from jp_notifications' CREATE TABLE. */
export interface NotificationRow {
  id: number
  user_id: number
  type: string
  title: string | null
  body: string | null
  url: string | null
  is_read: 0 | 1
  created_at: string
}

export function listNotifications(limit = 20): Promise<NotificationRow[]> {
  return api.get<NotificationRow[]>('/notifications', { limit })
}

export function markNotificationRead(id: number): Promise<{ ok: boolean }> {
  return api.put<{ ok: boolean }>(`/notifications/${id}`)
}

export function markAllNotificationsRead(): Promise<{ ok: boolean }> {
  return api.put<{ ok: boolean }>('/notifications/read-all')
}
