import { api } from '@/lib/apiClient'

/**
 * Wraps the existing POST /wp-json/jp/v1/auth/token endpoint (class-jp-api.php
 * / class-jp-security.php). Backend contract inferred from the compiled
 * SPA's observable LoginPage behavior (platform audit, Part 2.8): a login
 * attempt on a 2FA-enabled account returns a distinct "2fa_required" state
 * rather than succeeding or failing outright, so the form has a second step
 * instead of a second page.
 */
export interface LoginPayload {
  username: string
  password: string
  /** Present only on the second submit of a 2FA-gated login. */
  code?: string
}

export interface LoginResult {
  token?: string
  two_factor_required?: boolean
  /**
   * A wp_rest nonce valid for the session auth_token() just established
   * (see class-jp-api.php) — required because a nonce minted before login
   * is bound to the prior (usually anonymous) identity, and WordPress's
   * REST cookie authentication hard-rejects a mismatched nonce rather than
   * silently falling back to anonymous.
   */
  nonce?: string
}

export function login(payload: LoginPayload): Promise<LoginResult> {
  return api.post<LoginResult>('/auth/token', payload)
}

/**
 * Root-cause fix (batch 4: LoginPage's "Forgot password?" link pointed at
 * legacy /wp-login.php?action=lostpassword — outside the SPA, unstyled, and
 * inconsistent with the rest of the auth flow — while no in-app route
 * existed at all). Wraps the new POST /auth/forgot-password and
 * POST /auth/reset-password routes (class-jp-api.php's auth_forgot_password()
 * / auth_reset_password()).
 */
export interface ForgotPasswordResult {
  message: string
}

export function requestPasswordReset(email: string): Promise<ForgotPasswordResult> {
  return api.post<ForgotPasswordResult>('/auth/forgot-password', { email })
}

export interface ResetPasswordPayload {
  key: string
  login: string
  password: string
}

export interface ResetPasswordResult {
  message: string
}

export function resetPassword(payload: ResetPasswordPayload): Promise<ResetPasswordResult> {
  return api.post<ResetPasswordResult>('/auth/reset-password', payload)
}

/**
 * Root-cause fix (batch 7 — see class-jp-api.php's auth_update_password()
 * docblock). Changing your password while already signed in had no route
 * and no SPA form anywhere; the reset-password email flow above was the
 * only way, which meant signing out and waiting on an email just to change
 * a password you already know. Wraps the new POST /auth/update-password.
 */
export interface UpdatePasswordPayload {
  current_password: string
  new_password: string
}

export interface UpdatePasswordResult {
  message: string
}

export function updatePassword(payload: UpdatePasswordPayload): Promise<UpdatePasswordResult> {
  return api.post<UpdatePasswordResult>('/auth/update-password', payload)
}
