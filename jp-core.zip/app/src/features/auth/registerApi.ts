import { api } from '@/lib/apiClient'

/** Wraps POST /wp-json/jp/v1/auth/register (class-jp-api.php). */
export interface RegisterPayload {
  name: string
  email: string
  password: string
  role: 'jp_job_seeker' | 'jp_recruiter'
}

export interface RegisterResult {
  user_id: number
}

export function register(payload: RegisterPayload): Promise<RegisterResult> {
  return api.post<RegisterResult>('/auth/register', payload)
}
