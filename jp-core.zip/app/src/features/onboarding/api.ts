import { api } from '@/lib/apiClient'

export interface OnboardingStatus {
  completed_steps: string[]
  is_complete: boolean
}

export function getOnboardingStatus(): Promise<OnboardingStatus> {
  return api.get<OnboardingStatus>('/onboarding/status')
}

export function completeOnboardingStep(step: string): Promise<{ completed_steps: string[]; step_saved: string }> {
  return api.post('/onboarding/status', { step })
}
