import { api } from '@/lib/apiClient'

export const EVENT_TYPES = ['webinar', 'career_fair', 'workshop', 'hackathon', 'other'] as const
export const EVENT_FORMATS = ['online', 'offline', 'hybrid'] as const

/** Transcribed from jp_events' CREATE TABLE + get_events()'s JOINed/computed columns. */
export interface EventRow {
  id: number
  title: string
  slug: string
  description: string | null
  event_type: (typeof EVENT_TYPES)[number]
  host_company: number
  banner_url: string | null
  starts_at: string | null
  ends_at: string | null
  timezone: string
  format: (typeof EVENT_FORMATS)[number]
  venue: string | null
  meeting_url: string | null
  seats_total: number
  seats_taken: number
  is_free: boolean | number
  price: number
  status: 'draft' | 'published' | 'cancelled' | 'completed'
  created_at: string
  company_name: string | null
  logo_url: string | null
  attendee_count: number
}

export interface EventDetail extends EventRow {
  is_registered: boolean
}

export type EventWhen = 'upcoming' | 'past'

export function listEvents(
  params: { type?: string; format?: string; q?: string; when?: EventWhen; page?: number; mine?: boolean } = {}
) {
  const query: Record<string, string | number | undefined> = {}
  if (params.type) query.type = params.type
  if (params.format) query.format = params.format
  if (params.q) query.q = params.q
  if (params.when && params.when !== 'upcoming') query.when = params.when
  if (params.page) query.page = params.page
  // Root-cause fix (batch 31): get_events() always hardcoded
  // status='published' AND starts_at>=NOW() for public browsing, which made
  // a recruiter's own draft/past/cancelled events permanently unreachable
  // after creation. mine=1 scopes to the recruiter's own host_company with
  // no status/time filter (see class-jp-api.php's get_events()).
  if (params.mine) query.mine = 1
  return api.get<{ events: EventRow[]; total: number }>('/events', query)
}

export function getEvent(id: number): Promise<EventDetail> {
  return api.get<EventDetail>(`/events/${id}`)
}

/** Whitelist transcribed from create_event()'s $allowed array. */
export interface CreateEventPayload {
  title: string
  description?: string
  event_type: (typeof EVENT_TYPES)[number]
  format: (typeof EVENT_FORMATS)[number]
  starts_at?: string
  ends_at?: string
  venue?: string
  meeting_url?: string
  seats_total?: number
  is_free?: number
  price?: number
  status?: 'draft' | 'published'
  banner_url?: string
}

export function createEvent(payload: CreateEventPayload): Promise<{ id: number; message: string }> {
  return api.post('/events', payload)
}

/**
 * Root-cause fix (batch 31): PUT /events/{id} (update_event() in
 * class-jp-api.php) has always been a real, registered, recruiter-gated
 * route, but had zero SPA caller anywhere — a recruiter could create an
 * event but never edit or publish it afterward. Whitelist transcribed from
 * update_event()'s $allowed array.
 */
export interface UpdateEventPayload {
  title?: string
  description?: string
  status?: 'draft' | 'published' | 'cancelled' | 'completed'
  starts_at?: string
  ends_at?: string
  meeting_url?: string
  seats_total?: number
}

export function updateEvent(id: number, payload: UpdateEventPayload): Promise<{ message: string }> {
  return api.put(`/events/${id}`, payload)
}

export function registerForEvent(id: number): Promise<{ message: string }> {
  return api.post(`/events/${id}/register`, {})
}

/**
 * Root-cause fix (batch 15): jp_event_registrations.status has carried a
 * 'cancelled' enum value since the table was created, but no route ever
 * wrote it — once registered, a user had no way to back out. New DELETE
 * /events/{id}/register (cancel_event_registration() in class-jp-api.php).
 */
export function cancelEventRegistration(id: number): Promise<{ message: string }> {
  return api.delete(`/events/${id}/register`)
}
