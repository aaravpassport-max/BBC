import { api } from '@/lib/apiClient'
import type { PlanRow } from '@/features/admin/api'

/** Public GET /plans — same row shape as admin/plans, but only is_active=1 rows, no auth required. */
export function getPublicPlans(): Promise<PlanRow[]> {
  return api.get<PlanRow[]>('/plans')
}
