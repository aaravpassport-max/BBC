import { api } from '@/lib/apiClient'

/**
 * jp_resume_sections stores one row per (user, section) with an arbitrary
 * JSON array as `content` — get_resume_sections() returns them keyed by
 * section name, decoded. save_resume_section()'s whitelist is exactly
 * these 7 names; anything else is rejected server-side.
 */
export const RESUME_SECTION_NAMES = [
  'experience',
  'education',
  'skills',
  'certifications',
  'projects',
  'languages',
  'awards',
] as const
export type ResumeSectionName = (typeof RESUME_SECTION_NAMES)[number]

/** Generic entry shape used for the "list of dated things" sections (experience/education/certifications/projects/awards). */
export interface ResumeEntry {
  title: string
  subtitle?: string
  start_date?: string
  end_date?: string
  description?: string
}

/** skills/languages store as plain string arrays instead of ResumeEntry objects. */
export type ResumeSectionContent = ResumeEntry[] | string[]

export type ResumeSections = Partial<Record<ResumeSectionName, ResumeSectionContent>>

export function getResumeSections(): Promise<ResumeSections> {
  return api.get<ResumeSections>('/resume-sections')
}

export function saveResumeSection(section: ResumeSectionName, content: ResumeSectionContent): Promise<{ message: string }> {
  return api.post<{ message: string }>('/resume-sections', { section, content })
}
