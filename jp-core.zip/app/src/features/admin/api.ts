import { api, getRuntimeConfig } from '@/lib/apiClient'
import type { JobRow } from '@/features/jobs/api'
import type { CompanyRow } from '@/features/companies/api'
import type { JpRole } from '@/lib/auth/types'
import type { ApplicationStage } from '@/features/applications/api'

/** Transcribed from admin_stats()'s JP_Cache::remember() payload — cached 60s server-side. */
export interface AdminStats {
  total_jobs: number
  total_companies: number
  total_candidates: number
  total_apps: number
  pending_jobs: number
  revenue_month: number
  new_signups_today: number
}

export function getAdminStats(): Promise<AdminStats> {
  return api.get<AdminStats>('/admin/stats')
}

export interface PendingJobRow extends JobRow {
  posted_by_name: string | null
}

export function getPendingJobs(): Promise<PendingJobRow[]> {
  return api.get<PendingJobRow[]>('/admin/jobs/pending')
}

export function approveJob(id: number, approve: boolean, reason?: string): Promise<{ message: string }> {
  return api.post<{ message: string }>(`/admin/jobs/${id}/approve`, { approve, ...(reason ? { reason } : {}) })
}

/** Wraps POST /admin/jobs/bulk-approve (admin_bulk_approve_jobs()) — per-id success/failure, not blanket-assumed. */
export interface BulkApproveResult {
  message: string
  succeeded: number[]
  failed: number[]
}

export function bulkApproveJobs(ids: number[], approve: boolean, reason?: string): Promise<BulkApproveResult> {
  return api.post<BulkApproveResult>('/admin/jobs/bulk-approve', { ids, approve, ...(reason ? { reason } : {}) })
}

export interface AdminCompanyRow extends CompanyRow {
  owner_name: string | null
  owner_email: string | null
  active_jobs: number
  status: 'active' | 'suspended' | 'pending'
}

export function listAdminCompanies(params: { q?: string; status?: string; page?: number } = {}) {
  const query: Record<string, string | number | undefined> = {}
  if (params.q) query.q = params.q
  if (params.status) query.status = params.status
  if (params.page) query.page = params.page
  return api.get<{ companies: AdminCompanyRow[]; total: number }>('/admin/companies', query)
}

export function setCompanyStatus(id: number, status: 'active' | 'suspended' | 'pending'): Promise<{ message: string }> {
  return api.put<{ message: string }>(`/admin/companies/${id}/status`, { status })
}

/**
 * New in batch 39 (admin operations-center depth — pre-delivery audit's
 * "Support Scenario 1: record stuck in state" requires an admin to be
 * able to FIND a specific application platform-wide, not just act on one
 * they already have the id for). Transcribed from admin_applications()'s
 * JOINed SELECT (class-jp-api.php). Once found, the detail view / stage
 * change / note-adding all reuse the SAME endpoints
 * features/recruiter/applicationsApi.ts already wraps
 * (getApplicationDetail/moveApplicationStage/addApplicationNote) — those
 * endpoints already grant a manage_options/jp_manage_all_applications
 * override server-side (get_application() since batch 37,
 * can_manage_application() since the note/stage endpoints were built),
 * this module's only new job is the search/discovery step.
 */
export interface AdminApplicationRow {
  id: number
  job_id: number
  candidate_id: number
  company_id: number
  stage: ApplicationStage
  match_score: number
  created_at: string
  updated_at: string
  job_title: string | null
  company_name: string | null
  candidate_name: string | null
  candidate_email: string | null
}

export function listAdminApplications(params: { q?: string; stage?: ApplicationStage; page?: number } = {}) {
  const query: Record<string, string | number | undefined> = {}
  if (params.q) query.q = params.q
  if (params.stage) query.stage = params.stage
  if (params.page) query.page = params.page
  return api.get<{ applications: AdminApplicationRow[]; total: number }>('/admin/applications', query)
}

export function verifyCompany(id: number, verify: boolean): Promise<{ message: string }> {
  return api.post<{ message: string }>(`/admin/companies/${id}/verify`, { verify })
}

/** Root-cause fix (enterprise gap-analysis): bulk actions were present for Jobs/Applications only. */
export type BulkCompanyAction = 'activate' | 'suspend' | 'verify' | 'unverify'

export function bulkCompanyAction(
  ids: number[],
  action: BulkCompanyAction,
): Promise<{ done: number; skipped: number; message: string }> {
  return api.post('/admin/companies/bulk-action', { ids, action })
}

export interface AdminUserRow {
  id: number
  name: string
  email: string
  role: JpRole | 'subscriber'
  registered: string
  /** gap analysis: no reversible way to lock an account out existed at all — see bulkUserAction(). */
  is_suspended: boolean
}

export function listAdminUsers(params: { q?: string; role?: string; page?: number } = {}) {
  const query: Record<string, string | number | undefined> = {}
  if (params.q) query.q = params.q
  if (params.role) query.role = params.role
  if (params.page) query.page = params.page
  return api.get<{ users: AdminUserRow[]; total: number }>('/admin/users', query)
}

export function changeUserRole(id: number, role: JpRole): Promise<{ message: string }> {
  return api.put<{ message: string }>(`/admin/users/${id}/role`, { role })
}

/**
 * Batch 28 — custom RBAC (per-user capability overrides). Transcribed
 * from JP_Api::admin_get_capabilities()'s response shape: `overridable` is
 * the fixed universe of capabilities this endpoint will ever accept (see
 * JP_Roles::overridable_capabilities() — the most sensitive jp_* caps are
 * deliberately excluded server-side and never offered here at all);
 * `base_caps` are this user's role defaults; `overrides` holds only the
 * capabilities where the user's OWN grant/deny differs from (or adds to)
 * the role, keyed by capability name -> true (explicit grant) | false
 * (explicit deny of a role-granted capability).
 */
export interface UserCapabilities {
  role: string
  overridable: string[]
  base_caps: string[]
  overrides: Record<string, boolean>
}

export function getUserCapabilities(id: number): Promise<UserCapabilities> {
  return api.get<UserCapabilities>(`/admin/users/${id}/capabilities`)
}

export function updateUserCapability(
  id: number,
  capability: string,
  action: 'grant' | 'revoke' | 'reset',
): Promise<{ message: string }> {
  return api.put<{ message: string }>(`/admin/users/${id}/capabilities`, { capability, action })
}

/**
 * Root-cause fix (enterprise gap-analysis: "bulk actions exist for Jobs/
 * Applications but were never extended to Users" — mirrors bulkJobAction()
 * in features/recruiter/jobsApi.ts exactly). 'change_role' takes an
 * optional shared `role` for the whole selection (bulk-promoting/demoting
 * a filtered group at once); omit it for suspend/activate.
 */
export type BulkUserAction = 'suspend' | 'activate' | 'change_role'

export function bulkUserAction(
  ids: number[],
  action: BulkUserAction,
  role?: JpRole,
): Promise<{ done: number; skipped: number; message: string }> {
  return api.post('/admin/users/bulk-action', { ids, action, role })
}

/** Transcribed from jp_audit_log's CREATE TABLE + admin_audit_log()'s JOINed column. */
export interface AuditLogRow {
  id: number
  user_id: number
  action: string
  object: string | null
  object_id: number
  detail: string | null
  ip: string | null
  created_at: string
  display_name: string | null
}

/**
 * Root-cause fix (enterprise gap-analysis: "AdminAuditLogPage is a flat
 * table with no filter-by-actor/action/date-range, no export" — the
 * platform's core compliance artifact was unusable past a page or two of
 * rows). Response shape changed from a bare array to {entries,total} so
 * the page can paginate against a real count, matching the pattern every
 * other admin list endpoint in this file already uses.
 */
export interface AuditLogFilters {
  page?: number
  actor_id?: number
  action?: string
  date_from?: string // YYYY-MM-DD
  date_to?: string // YYYY-MM-DD
}

export function getAuditLog(filters: AuditLogFilters = {}): Promise<{ entries: AuditLogRow[]; total: number }> {
  const { page = 1, ...rest } = filters
  return api.get('/admin/audit-log', { page, ...rest })
}

/**
 * CSV export of the audit log honoring the exact same filters as
 * getAuditLog() — see admin_audit_log_export()'s docblock. Mirrors
 * downloadCsvExport()'s raw-fetch pattern below (the endpoint returns
 * text/csv, not the {success,data} envelope api.get() expects).
 */
export async function downloadAuditLogCsv(filters: AuditLogFilters = {}): Promise<void> {
  const { apiUrl, nonce } = getRuntimeConfig()
  const params = new URLSearchParams()
  if (filters.actor_id) params.set('actor_id', String(filters.actor_id))
  if (filters.action) params.set('action', filters.action)
  if (filters.date_from) params.set('date_from', filters.date_from)
  if (filters.date_to) params.set('date_to', filters.date_to)
  const qs = params.toString()
  const endpoint = apiUrl.replace(/\/$/, '') + '/admin/audit-log/export' + (qs ? `?${qs}` : '')
  const res = await fetch(endpoint, { headers: { 'X-WP-Nonce': nonce }, credentials: 'same-origin' })
  if (!res.ok) throw new Error(`Export failed (HTTP ${res.status}).`)
  const blob = await res.blob()
  const blobUrl = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = blobUrl
  a.download = `jp_audit_log_${new Date().toISOString().slice(0, 10)}.csv`
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(blobUrl)
}

/**
 * Root-cause fix (batch 14 — closes the deferred item noted in
 * AdminAuditLogPage.tsx's docblock: "hash-chaining jp_audit_log rows for
 * tamper-evidence ... deferred to a separate pass"). Wraps
 * GET /admin/audit-log/verify (class-jp-api.php's admin_audit_log_verify(),
 * backed by JP_Security::verify_audit_chain()). Shape mirrors that
 * method's return array exactly.
 */
export interface AuditChainVerifyResult {
  valid: boolean
  total_checked: number
  first_break_id: number | null
  message: string
}

export function verifyAuditChain(): Promise<AuditChainVerifyResult> {
  return api.get('/admin/audit-log/verify')
}

/** Transcribed from jp_error_log's CREATE TABLE (class-jp-activator.php). */
export interface ErrorLogRow {
  id: number
  fingerprint: string
  level: string
  message: string | null
  file: string | null
  line: number | null
  trace: string | null
  occurrences: number
  first_seen_at: string
  last_seen_at: string
}

export interface ErrorLogResult {
  rows: ErrorLogRow[]
  levels: string[]
}

/**
 * Root-cause fix (batch 14): admin_error_log() previously accepted only
 * `page` and JP_ErrorLog::recent() had no filter capability at all, so an
 * admin with thousands of rows had to scroll the raw log by eye looking
 * for a specific level or message. `level`/`q` are now real WHERE clauses
 * against the table's own `level`/`message`/`file` columns (see
 * class-jp-errorlog.php); `levels` in the response is the distinct set
 * actually present, so the filter dropdown never offers a dead option.
 */
export function getErrorLog(page = 1, level = '', q = ''): Promise<ErrorLogResult> {
  const params: Record<string, string | number> = { page }
  if (level) params.level = level
  if (q) params.q = q
  return api.get<ErrorLogResult>('/admin/error-log', params)
}

/** Transcribed directly from admin_health()'s return array. */
export interface CronJobHealth {
  job: string
  last_status: 'ok' | 'failed' | string
  last_run?: string
  overdue: boolean
  last_error?: string | null
}

export interface AdminHealth {
  php_version: string
  wp_version: string
  mysql_version: string
  jp_version: string
  react_app_version: string | null
  react_version_status: 'in_sync' | 'mismatch' | string
  db_ok: boolean
  last_cron: string
  cron_jobs: CronJobHealth[]
  cron_health: 'ok' | 'degraded'
  queue_dead_letters: number
  recent_errors: unknown[]
  cache_driver: 'external' | 'transients'
  uploads_writable: boolean
  server_time: string
  active_jobs: number
  total_users: number
  total_applications: number
  elasticsearch_configured: boolean
  redis_configured: boolean
  tcpdf_available: boolean
  pdftotext_available: boolean
  wp_cron_enabled: boolean
  sms_provider_configured: string | null
  backup_latest: string | null
  backup_count: number
  backup_next: string | null
  vapid_configured: boolean
}

export function getAdminHealth(): Promise<AdminHealth> {
  return api.get<AdminHealth>('/admin/health')
}

/** Transcribed from class-jp-diagnostics.php's check()/add_section()/generate(). */
export interface DiagnosticCheck {
  name: string
  status: 'PASS' | 'WARN' | 'FAIL' | 'INFO'
  message: string
  solution: string | null
  probe: string
  value: string
}

export interface DiagnosticSection {
  name: string
  icon: string
  pass: number
  warn: number
  fail: number
  checks: DiagnosticCheck[]
}

export interface DiagnosticReport {
  generated_at: string
  generated_by: string
  plugin_version: string
  wp_version: string
  sections: DiagnosticSection[]
  summary: { total: number; pass: number; warn: number; fail: number; info: number; duration: string }
}

/**
 * Root-cause fix (roadmap re-audit): this hits the SAME REST route
 * (GET /jp/v1/diagnostics) the wp-admin "JP Diagnostics" page's render_page()
 * called internally via generate() — not a new report, a new way to reach
 * the existing one now that the wp-admin menu is gone. Note this route is
 * NOT under /admin/* like the rest of this file's calls (see
 * class-jp-diagnostics.php's register_rest_route('jp/v1', '/diagnostics', ...)),
 * so the path is passed through as-is.
 */
export function getDiagnostics(): Promise<DiagnosticReport> {
  return api.get<DiagnosticReport>('/diagnostics')
}

/** Mirrors the legacy wp-admin "Generate VAPID Keys" button — see admin_generate_vapid(). */
export function generateVapidKeys(): Promise<{ message: string; public_key: string }> {
  return api.post('/admin/system/vapid', {})
}

/** Transcribed from jp_payments' CREATE TABLE + admin_payments()'s JOINed column. */
export interface PaymentRow {
  id: number
  user_id: number
  company_id: number
  plan_id: number
  razorpay_order: string | null
  razorpay_pay_id: string | null
  gateway: string
  stripe_session_id: string | null
  amount: number
  currency: string
  status: 'created' | 'paid' | 'failed' | 'refunded' | 'abandoned'
  description: string | null
  invoice_url: string | null
  paid_at: string | null
  created_at: string
  display_name: string | null
}

export interface AdminPaymentFilters {
  page?: number
  status?: PaymentRow['status']
  gateway?: string
  date_from?: string
  date_to?: string
}

export function listAdminPayments(filters: AdminPaymentFilters = {}): Promise<{ payments: PaymentRow[]; total: number }> {
  const { page = 1, ...rest } = filters
  return api.get<{ payments: PaymentRow[]; total: number }>('/admin/payments', { page, ...rest })
}

/** Transcribed from admin_get_skills()'s explicit SELECT column list. */
export interface SkillRow {
  id: number
  name: string
  category: string | null
  jobs_count: number
}

export function listAdminSkills(q?: string): Promise<SkillRow[]> {
  return api.get<SkillRow[]>('/admin/skills', q ? { q } : undefined)
}

export function addSkill(name: string, category?: string): Promise<{ id: number; message: string }> {
  return api.post<{ id: number; message: string }>('/admin/skills', { name, category })
}

export function deleteSkill(id: number): Promise<{ message: string }> {
  return api.delete<{ message: string }>(`/admin/skills/${id}`)
}

export function mergeSkill(sourceId: number, targetId: number): Promise<{
  message: string
  reassigned_profiles: number
  reassigned_assessments: number
  reassigned_questions: number
  dropped_duplicates: number
}> {
  return api.post(`/admin/skills/${sourceId}/merge`, { target_id: targetId })
}

/** Transcribed from jp_reviews' CREATE TABLE + admin_reviews()'s JOINed columns. */
export interface ReviewRow {
  id: number
  company_id: number
  user_id: number
  title: string | null
  pros: string | null
  cons: string | null
  rating_overall: number
  rating_wlb: number
  rating_growth: number
  rating_mgmt: number
  rating_pay: number
  employment_type: 'current' | 'former' | 'interviewer'
  job_title: string | null
  is_anonymous: boolean
  status: 'pending' | 'approved' | 'rejected'
  helpful_count: number
  created_at: string
  company_name: string | null
  reviewer_name: string | null
}

export function listAdminReviews(status = 'pending', page = 1): Promise<{ reviews: ReviewRow[]; total: number }> {
  return api.get('/admin/reviews', { status, page })
}

export function reviewAction(id: number, action: 'approve' | 'reject'): Promise<{ message: string }> {
  return api.put(`/admin/reviews/${id}`, { action })
}

/** Root-cause fix (enterprise gap-analysis): bulk actions were present for Jobs/Applications only. */
export function bulkReviewAction(
  ids: number[],
  action: 'approve' | 'reject',
): Promise<{ done: number; skipped: number; message: string }> {
  return api.post('/admin/reviews/bulk-action', { ids, action })
}

/** Transcribed field-for-field from jp_plans' CREATE TABLE. */
export interface PlanRow {
  id: number
  name: string
  slug: string
  description: string | null
  price_monthly: number
  price_yearly: number
  /** Batch 30: multi-currency support, phase 1. Additive column, defaults
   * to 'INR' on every pre-existing row. See class-jp-payments.php's
   * do_create_order() for the Razorpay-is-INR-only gate this enables. */
  currency: 'INR' | 'USD'
  job_posts: number
  featured_jobs: number
  resume_views: number
  candidate_msgs: number
  team_seats: number
  /** Present on the raw row (SELECT *) though admin_save_plan()'s whitelist excludes it from writes here. */
  features_json: string | null
  is_active: boolean | number
  sort_order: number
  created_at: string
}

/**
 * Whitelist transcribed from admin_save_plan()'s $fields array — id is
 * separate (path/omitted for create). `features` (batch 32) is a real,
 * separately-handled param: admin_save_plan() JSON-encodes it into
 * features_json, which PricingPage.tsx already reads — this closes the
 * gap of that column having a real reader but no writer anywhere.
 */
export type PlanPayload = Partial<
  Pick<
    PlanRow,
    | 'name'
    | 'slug'
    | 'description'
    | 'price_monthly'
    | 'price_yearly'
    | 'currency'
    | 'job_posts'
    | 'featured_jobs'
    | 'resume_views'
    | 'candidate_msgs'
    | 'team_seats'
    | 'is_active'
    | 'sort_order'
  >
> & { features?: string[] }

export function listAdminPlans(): Promise<PlanRow[]> {
  return api.get<PlanRow[]>('/admin/plans')
}

export function savePlan(id: number | undefined, payload: PlanPayload): Promise<{ id: number; message: string }> {
  return api.post('/admin/plans', id ? { id, ...payload } : payload)
}

export function flushCache(): Promise<{ message: string; flushed_at: string }> {
  return api.post('/admin/system/cache-flush', {})
}

export function triggerBackup(): Promise<{ message: string; triggered_at: string }> {
  return api.post('/admin/system/backup', {})
}

/**
 * Transcribed from admin_get_settings()'s two key lists. Secret values come
 * back pre-masked by the server (8 asterisks + last 4 chars, or '' if unset)
 * — the save endpoint only overwrites a secret when the submitted value does
 * NOT contain '****', so re-submitting the masked placeholder unchanged is a
 * safe no-op rather than clobbering the real secret with asterisks.
 */
export interface AdminSettings {
  jp_site_name: string
  jp_jobs_per_page: string
  jp_auto_approve_jobs: string
  jp_auto_approve_reviews: string
  jp_og_default_image: string
  jp_maintenance_mode: string
  /** Batch 12 — Stripe gateway abstraction. See jp_active_payment_gateway() in jp-core.php. */
  jp_payment_gateway: 'razorpay' | 'stripe' | string
  jp_razorpay_key_id: string
  jp_stripe_publishable_key: string
  jp_gst_number: string
  jp_invoice_prefix: string
  /**
   * Root-cause fix (roadmap re-audit): these two are the ONLY SMTP-related
   * options class-jp-smtp.php actually reads (as the mail "From" name/
   * address) — real host/port/user/pass come exclusively from wp-config.php
   * constants (JP_SMTP_HOST etc), by design. The previous jp_smtp_host /
   * jp_smtp_port / jp_smtp_user / jp_from_email / jp_from_name fields here
   * were dead options nothing in the mail pipeline ever read — a silent
   * "ghost setting" bug, now fixed.
   */
  jp_smtp_from_name: string
  jp_smtp_from_email: string
  /** Read-only: whether wp-config.php's JP_SMTP_HOST/JP_SMTP_USER constants are set. */
  jp_smtp_constants_configured: boolean
  jp_ga4_measurement_id: string
  jp_social_twitter: string
  jp_social_linkedin: string
  jp_social_facebook: string
  jp_sms_provider: string
  jp_openai_model: string
  jp_max_login_attempts: string
  jp_lockout_duration: string
  jp_require_2fa_admin: string
  jp_razorpay_key_secret: string
  jp_stripe_secret_key: string
  jp_stripe_webhook_secret: string
  jp_smtp_password: string
  jp_openai_key: string
  jp_sms_key: string
  /** JP_ESign (DocuSign) — closes the e-signature vendor-integration scope exclusion. 'none' | 'docusign'. */
  jp_esign_provider: 'none' | 'docusign' | string
  jp_docusign_account_id: string
  jp_docusign_integration_key: string
  jp_docusign_user_id: string
  jp_docusign_base_uri: string
  jp_docusign_private_key: string
  jp_esign_webhook_secret: string
  /** Read-only: whether jp_esign_provider + every required DocuSign credential are actually present. */
  jp_esign_configured: boolean
  /** JP_JobFeed — closes the inbound job-feed pull-import scope exclusion. One feed URL per line. */
  jp_feed_urls: string
  jp_feed_auto_publish: string
  /**
   * Ghost-setting fix (write-key/read-key audit sweep): all four are read
   * live by real code — jp_job_expiry_days by class-jp-jobs.php's job
   * auto-expiry, jp_resume_max_size_mb by the resume-upload size check in
   * both class-jp-resume.php and class-jp-security.php, jp_cors_allowed_origin
   * by class-jp-performance.php's CORS allow-origin header, and
   * jp_uninstall_wipe_data by class-jp-activator.php's uninstall guard —
   * but none of the four had any admin UI to change them before this fix.
   */
  jp_job_expiry_days: string
  jp_resume_max_size_mb: string
  jp_cors_allowed_origin: string
  jp_uninstall_wipe_data: string
}

export function getAdminSettings(): Promise<AdminSettings> {
  return api.get<AdminSettings>('/admin/settings')
}

export function saveAdminSettings(payload: Partial<AdminSettings>): Promise<{ message: string; updated: number }> {
  return api.put('/admin/settings', payload)
}

/** Shape of JP_JobFeed::run_import()/last_run_summary()'s return. */
export interface JobFeedRunSummary {
  feeds: number
  imported: number
  updated: number
  skipped: number
  errors: string[]
  ran_at: string | null
}

export function runJobFeedImport(): Promise<JobFeedRunSummary> {
  return api.post('/admin/job-feed/run', {})
}

export function getJobFeedStatus(): Promise<JobFeedRunSummary> {
  return api.get('/admin/job-feed/status')
}

export function pushBroadcast(
  title: string,
  body: string,
  segment: string,
): Promise<{ message: string; sent: number }> {
  return api.post('/admin/push/broadcast', { title, body, segment })
}

/** Transcribed from admin_webhooks_list()'s mapped shape. */
export interface WebhookRow {
  id: string
  url: string
  events: string[]
  active: boolean
  created_at: string
}

export const WEBHOOK_EVENTS = [
  'job.created',
  'job.approved',
  'application.created',
  'application.stage_changed',
  'payment.paid',
  'review.approved',
] as const

export function listWebhooks(): Promise<WebhookRow[]> {
  return api.get<WebhookRow[]>('/admin/webhooks')
}

export function createWebhook(url: string, events: string[]): Promise<{ id: string; message: string }> {
  return api.post('/admin/webhooks', { url, events })
}

export function deleteWebhook(id: string): Promise<{ message: string }> {
  return api.delete(`/admin/webhooks/${id}`)
}

export function testWebhook(id: string): Promise<{ status: number; message: string }> {
  return api.post(`/admin/webhooks/${id}/test`, {})
}

/** Transcribed from jp_webhook_deliveries' CREATE TABLE + admin_webhook_deliveries()'s SELECT. */
export interface WebhookDeliveryRow {
  id: number
  event: string
  status: 'pending' | 'delivered' | 'failed'
  http_code: number | null
  response_body: string | null
  attempt: number
  next_retry_at: string | null
  created_at: string
  delivered_at: string | null
}

/**
 * Root-cause fix (batch 18): JP_Webhooks::dispatch()/retry_due_deliveries()
 * have written one real row per delivery attempt to jp_webhook_deliveries
 * since that table was created, but no route ever read it back — the
 * admin webhooks screen could create/test/delete a webhook but never see
 * whether it was actually firing successfully in production.
 */
export function listWebhookDeliveries(id: string): Promise<WebhookDeliveryRow[]> {
  return api.get<WebhookDeliveryRow[]>(`/admin/webhooks/${id}/deliveries`)
}

/** Transcribed from JP_FeatureFlags::list_flags()'s row shape (jp_feature_flags table columns). */
export interface FeatureFlagRow {
  id: number
  flag_key: string
  is_enabled: 0 | 1
  plan_tier: string
  description: string
}

export function listFeatureFlags(): Promise<{ flags: FeatureFlagRow[] }> {
  return api.get('/admin/feature-flags')
}

export function saveFeatureFlag(
  flag_key: string,
  is_enabled: boolean,
  plan_tier: string,
  description: string,
): Promise<{ message: string }> {
  return api.post('/admin/feature-flags', { flag_key, is_enabled, plan_tier, description })
}

export function deleteFeatureFlag(flag_key: string): Promise<{ message: string }> {
  return api.delete(`/admin/feature-flags/${encodeURIComponent(flag_key)}`)
}

/**
 * Company offboarding export — JP_Privacy::export_company()'s return shape
 * (see class-jp-privacy.php). Unlike the CSV exports below, this goes
 * through the normal {success,data} envelope, so it's fetched with
 * api.get() and turned into a downloadable JSON file client-side.
 */
export interface CompanyExportData {
  exported_at: string
  company: Record<string, unknown> | null
  jobs: unknown[]
  applications: unknown[]
  team_members: unknown[]
  reviews: unknown[]
  subscriptions: unknown[]
}

export async function exportCompanyData(companyId: number, companyName: string): Promise<void> {
  const data = await api.get<CompanyExportData>(`/admin/companies/${companyId}/export`)
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' })
  const blobUrl = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = blobUrl
  const safeName = companyName.replace(/[^a-z0-9]+/gi, '_').toLowerCase() || 'company'
  a.download = `jp_offboarding_${safeName}_${new Date().toISOString().slice(0, 10)}.json`
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(blobUrl)
}

export function eraseCompany(companyId: number): Promise<{ message: string }> {
  return api.delete(`/admin/companies/${companyId}`)
}

export function impersonateStart(userId: number): Promise<{ message: string; expires_at: number }> {
  return api.post('/admin/impersonate/start', { user_id: userId })
}

export function impersonateStop(): Promise<{ message: string }> {
  return api.post('/admin/impersonate/stop', {})
}

/** admin_csv_export() returns raw text/csv, not the {success,data} envelope apiRequest expects. */
export type CsvExportType = 'applications' | 'candidates' | 'payments' | 'jobs'

/**
 * Root-cause fix (enterprise gap-analysis: "No CSV/bulk import anywhere —
 * export exists for admin, import does not exist for anything"). Both
 * endpoints take the raw CSV file's text content as a single JSON string
 * field (matching this file's existing api.post() JSON convention rather
 * than adding multipart/form-data handling for just these two routes) —
 * the file is read client-side via the browser's File API before posting.
 */
export interface CsvImportResult {
  created: number
  failed: number
  errors: string[]
  message: string
}

export function importJobsCsv(csv: string): Promise<CsvImportResult> {
  return api.post<CsvImportResult>('/admin/import/jobs', { csv })
}

export interface CompanyCsvImportResult extends CsvImportResult {
  invited: number
}

export function importCompaniesCsv(csv: string): Promise<CompanyCsvImportResult> {
  return api.post<CompanyCsvImportResult>('/admin/import/companies', { csv })
}

export async function downloadCsvExport(type: CsvExportType): Promise<void> {
  const { apiUrl, nonce } = getRuntimeConfig()
  const endpoint = apiUrl.replace(/\/$/, '') + '/admin/export/' + type
  const res = await fetch(endpoint, {
    headers: { 'X-WP-Nonce': nonce },
    credentials: 'same-origin',
  })
  if (!res.ok) throw new Error(`Export failed (HTTP ${res.status}).`)
  const blob = await res.blob()
  const blobUrl = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = blobUrl
  a.download = `jp_${type}_${new Date().toISOString().slice(0, 10)}.csv`
  document.body.appendChild(a)
  a.click()
  a.remove()
  URL.revokeObjectURL(blobUrl)
}
