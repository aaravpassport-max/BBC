import { api } from '@/lib/apiClient'

/** Transcribed field-for-field from admin_revenue_dashboard()'s return shape. Gated by manage_options/jp_view_revenue, not just admin-panel access. */
export interface AdminRevenue {
  mrr: number
  arpu: number
  active_subscriptions: number
  mrr_by_plan: Record<string, number>
  trial_subscriptions: number
  past_due_subscriptions: number
  new_subscriptions_30d: number
  cancelled_30d: number
  churn_rate_pct_30d: number
  revenue_collected_30d: number
  currency: string
  note: string
}

export function getAdminRevenue(): Promise<AdminRevenue> {
  return api.get<AdminRevenue>('/admin/revenue')
}

export type AdminSubscriptionStatus = 'trial' | 'active' | 'past_due' | 'cancelled' | 'expired'

/** Transcribed from admin_subscriptions()'s JOINed SELECT (jp_subscriptions + user + plan name + MRR context). */
export interface AdminSubscriptionRow {
  id: number
  user_id: number
  company_id: number
  plan_id: number
  billing_cycle: 'monthly' | 'yearly'
  status: AdminSubscriptionStatus
  starts_at: string | null
  expires_at: string | null
  cancelled_at: string | null
  created_at: string
  display_name: string
  user_email: string
  plan_name: string
  price_monthly: number
  price_yearly: number
  currency: string
  /** Server-computed monthly-equivalent revenue this row contributes (yearly ÷ 12 for annual plans). */
  mrr_contribution: number
}

export function getAdminSubscriptions(
  page = 1,
  status?: AdminSubscriptionStatus,
): Promise<{ subscriptions: AdminSubscriptionRow[]; total: number }> {
  return api.get<{ subscriptions: AdminSubscriptionRow[]; total: number }>('/admin/subscriptions', {
    page,
    ...(status ? { status } : {}),
  })
}

/** Force-cancels a subscription (jp_manage_plans-gated admin override — see class-jp-api.php's admin_cancel_subscription()). */
export function cancelSubscription(id: number): Promise<{ message: string; status: string }> {
  return api.post(`/admin/subscriptions/${id}/cancel`, {})
}
