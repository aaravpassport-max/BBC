import { api } from '@/lib/apiClient'

/** Transcribed from gamification_badges()'s return array. */
export interface EarnedBadge {
  badge: string
  awarded_at: string
}

export interface NextMilestone {
  badge: string
  description: string
  progress: number
  target: number
}

export interface GamificationStatus {
  earned: EarnedBadge[]
  profile_score: number
  applications: number
  certifications: number
  next_milestone: NextMilestone
}

/** Human-readable labels — the API only returns the raw badge slug. */
export const BADGE_LABELS: Record<string, string> = {
  profile_starter: 'Profile Starter',
  profile_pro: 'Profile Pro',
  profile_complete: 'Profile Complete',
  first_application: 'First Application',
  active_applicant: 'Active Applicant',
  power_applicant: 'Power Applicant',
  skill_certified: 'Skill Certified',
  multi_skilled: 'Multi-Skilled',
}

export function getGamificationBadges(): Promise<GamificationStatus> {
  return api.get<GamificationStatus>('/gamification/badges')
}

/** Transcribed from gamification_leaderboard()'s return shape. */
export interface LeaderboardEntry {
  rank: number
  user_id: number
  display_name: string
  badge_count: number
  profile_score: number
  is_you: boolean
}

export interface LeaderboardResponse {
  leaderboard: LeaderboardEntry[]
  your_rank: number | null
}

export function getGamificationLeaderboard(): Promise<LeaderboardResponse> {
  return api.get<LeaderboardResponse>('/gamification/leaderboard')
}
