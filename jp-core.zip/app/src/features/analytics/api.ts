/**
 * Client for the analytics event pipeline (class-jp-analytics.php /
 * POST /analytics/track + GET /analytics/dashboard).
 *
 * Root-cause fix: /analytics/track and /analytics/dashboard were both
 * registered REST routes with zero frontend callers anywhere in the app.
 * JP_Analytics::instance()->track() (which is what actually inserts rows
 * into wp_jp_analytics, the table the hourly aggregation cron reads from
 * to populate wp_jp_analytics_agg, which is what platform_summary() and
 * company_summary() query) has exactly one call site in the whole PHP
 * codebase: inside the track_event() REST handler itself. With no
 * frontend ever calling POST /analytics/track, that table — and every
 * dashboard built on top of it — was permanently empty by construction,
 * even though the whole pipeline (events, hourly cron aggregation,
 * 90-day raw-event purge, dashboard queries) was fully built server-side
 * and battle-ready. This wires the missing client side of that pipeline.
 *
 * track() is intentionally fire-and-forget: analytics must never block or
 * fail a page render, and the backend's own ajax_track() twin explicitly
 * requires no nonce ("No nonce required for tracking (public pixel)"), so
 * this makes the same trust assumption and swallows all errors silently.
 *
 * NOTE: track_event()'s PHP guard is `if ( $event && $obj_id )` — $obj_id
 * uses PHP truthiness, so an object_id of 0 is silently dropped server-side
 * no matter what the client sends. That makes a 'search' event structurally
 * untrackable through this endpoint (a search has no natural object id).
 * total_searches doesn't need it anyway — it reads from wp_jp_search_log
 * instead, a separate table already populated directly inside
 * JP_Search::search() itself, independent of this event pipeline. Left
 * unwired for 'search' since there's no real gap to close here.
 */
import { api } from '@/lib/apiClient'

export type AnalyticsEvent = 'job_view' | 'job_apply' | 'company_view' | 'profile_view' | 'job_click'

export function trackEvent(event: AnalyticsEvent, objectId: number): void {
  if (!objectId) return
  api.post('/analytics/track', { event, object_id: objectId }).catch(() => {
    // Fire-and-forget by design — see module docblock.
  })
}

export interface AnalyticsDailyPoint {
  period: string
  views: number
  applies: number
}

export interface FunnelStage {
  stage: string
  reached: number
  conversion_from_applied_pct: number | null
}

export interface SourceBreakdownRow {
  source: string
  applications: number
  hires: number
  hire_rate_pct: number
}

/**
 * Root-cause fix (batch 3: "JP_Analytics exposes only two flat aggregates,
 * no funnel, no source-of-hire attribution" — true for the platform-wide
 * view). platform_summary() (admin-facing, is_admin branch of
 * ajax_get_dashboard()) now merges these fields in via
 * JP_Analytics::platform_funnel_and_sources(); company_summary() (the
 * non-admin/recruiter branch of the SAME endpoint) does not compute them,
 * so they are optional here rather than on a separate response type.
 */
export interface AnalyticsDashboard {
  daily: AnalyticsDailyPoint[]
  total_views: number
  total_applies: number
  total_searches?: number
  new_users?: number
  apply_rate?: number
  funnel_reach?: FunnelStage[]
  avg_time_to_hire_days?: number | null
  offer_acceptance_rate_pct?: number | null
  source_breakdown?: SourceBreakdownRow[]
}

export function getAnalyticsDashboard(days = 30): Promise<AnalyticsDashboard> {
  return api.get<AnalyticsDashboard>('/analytics/dashboard', { days })
}
