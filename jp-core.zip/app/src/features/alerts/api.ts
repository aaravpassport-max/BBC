import { api } from '@/lib/apiClient'

/** Transcribed from jp_alerts' CREATE TABLE. */
export interface AlertRow {
  id: number
  user_id: number
  name: string | null
  keywords: string | null
  location: string | null
  job_type: string | null
  work_mode: string | null
  salary_min: number
  experience: number
  /** Batch 27: JSON-encoded string array, e.g. '["React","Node.js"]'. */
  skills_json: string | null
  frequency: 'instant' | 'daily' | 'weekly'
  is_active: 0 | 1
  last_sent: string | null
  created_at: string
}

/**
 * Whitelist transcribed from JP_Alerts::ajax_save()'s $_POST reads.
 * experience added batch 22 — see class-jp-alerts.php's ajax_save()
 * docblock for the gap this closes (column existed, was never written).
 * skills added batch 27, comma-separated (server splits/AND-matches it,
 * same shape as JP_Search's 'skills' filter param).
 */
export interface CreateAlertPayload {
  name: string
  keywords?: string
  location?: string
  job_type?: string
  work_mode?: string
  salary_min?: number
  experience?: number
  skills?: string
  frequency?: 'instant' | 'daily' | 'weekly'
}

export function listAlerts(): Promise<AlertRow[]> {
  return api.get<AlertRow[]>('/alerts')
}

export function createAlert(payload: CreateAlertPayload): Promise<{ message: string; id: number }> {
  return api.post<{ message: string; id: number }>('/alerts', payload)
}

export function deleteAlert(id: number): Promise<{ message: string }> {
  return api.delete<{ message: string }>(`/alerts/${id}`)
}

export function toggleAlert(id: number): Promise<{ message: string }> {
  return api.put<{ message: string }>(`/alerts/${id}`)
}
