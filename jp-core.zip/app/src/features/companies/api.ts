import { api } from '@/lib/apiClient'

/** Transcribed directly from class-jp-api.php::get_companies/get_company and jp_companies' CREATE TABLE. */
export interface CompanyRow {
  id: number
  user_id: number
  name: string
  slug: string
  description: string
  logo_url: string | null
  cover_url: string | null
  website: string | null
  industry: string | null
  size_range: string | null
  headquarters: string | null
  is_verified: 0 | 1
  is_featured: 0 | 1
  rating_avg: number
  reviews_count: number
  jobs_count: number
}

export interface CompanyListResult {
  companies: CompanyRow[]
  total: number
  pages: number
  /** Distinct real industry values currently in use — drives the industry filter dropdown. */
  industries: string[]
}

export type CompanySort = 'jobs' | 'rating' | 'name'

export function listCompanies(params: {
  q?: string
  industry?: string
  verified_only?: boolean
  sort?: CompanySort
  page?: number
  per_page?: number
}): Promise<CompanyListResult> {
  const query: Record<string, string | number | undefined> = {}
  if (params.q) query.q = params.q
  if (params.industry) query.industry = params.industry
  if (params.verified_only) query.verified_only = '1'
  if (params.sort && params.sort !== 'jobs') query.sort = params.sort
  if (params.page) query.page = params.page
  if (params.per_page) query.per_page = params.per_page
  return api.get<CompanyListResult>('/companies', query)
}

export function getCompany(id: number): Promise<CompanyRow> {
  return api.get<CompanyRow>(`/companies/${id}`)
}

export interface CompanyJobRow {
  id: number
  title: string
  job_type: string
  work_mode: string
  location_city: string
  created_at: string
}

export function getCompanyJobs(id: number): Promise<CompanyJobRow[]> {
  return api.get<CompanyJobRow[]>(`/companies/${id}/jobs`)
}

export interface CompanyReview {
  id: number
  company_id: number
  user_id: number
  display_name: string
  rating: number
  title: string
  body: string
  is_anonymous: 0 | 1
  helpful_count: number
  created_at: string
}

export function getCompanyReviews(id: number): Promise<CompanyReview[]> {
  return api.get<CompanyReview[]>(`/companies/${id}/reviews`)
}

/**
 * Root-cause fix (batch 17). JP_Reviews::ajax_vote() (a plain
 * non-deduplicated "mark helpful" counter) existed with no REST route or
 * SPA caller anywhere. Wraps the new POST /reviews/{id}/vote-helpful route
 * (class-jp-api.php's vote_review_helpful()).
 */
export function voteReviewHelpful(reviewId: number): Promise<{ message: string }> {
  return api.post<{ message: string }>(`/reviews/${reviewId}/vote-helpful`)
}
