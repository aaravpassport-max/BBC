import { api } from '@/lib/apiClient'

/**
 * Wraps GET /wp-json/jp/v1/jobs (class-jp-api.php::get_jobs -> JP_Search::search()).
 * Field/param names below are taken directly from JP_Search::search_mysql()'s
 * actual SQL and JP_Api::get_jobs()'s $r->get_param() calls — the backend is
 * frozen, so this is a transcription of the real contract, not a guess:
 * response is {jobs, total, pages, source}, NOT {items, total, page, per_page}.
 */
export interface JobListParams {
  q?: string
  location?: string
  job_type?: 'full-time' | 'part-time' | 'contract' | 'internship' | 'freelance' | ''
  work_mode?: 'onsite' | 'remote' | 'hybrid' | ''
  industry?: string
  exp?: number
  sal_min?: number
  sal_max?: number
  /** Batch 27: comma-separated skills, AND-matched server-side against skills_json. */
  skills?: string
  order_by?: 'created_at' | 'salary_max' | 'views_count' | 'applications_cnt' | 'relevance_score'
  order?: 'ASC' | 'DESC'
  page?: number
  per_page?: number
}

/** Raw row shape from jp_jobs joined to jp_companies — see class-jp-activator.php's CREATE TABLE. */
export interface JobRow {
  id: number
  company_id: number
  title: string
  slug: string
  description: string
  requirements?: string
  skills_json?: string
  /** Batch 35: `[{question: string, required: boolean}]`, JSON-encoded — see class-jp-activator.php's screening_q column. */
  screening_q?: string
  job_type: string
  work_mode: 'onsite' | 'remote' | 'hybrid'
  experience_min: number
  experience_max: number
  location_city: string
  location_state: string
  salary_min: number
  salary_max: number
  salary_currency: string
  salary_visible: 0 | 1
  status: string
  is_featured: 0 | 1
  is_urgent: 0 | 1
  views_count: number
  applications_cnt: number
  created_at: string
  company_name: string
  logo_url: string | null
  company_verified: 0 | 1
  relevance_score?: number
}

export interface JobListResult {
  jobs: JobRow[]
  total: number
  pages: number
  source: 'mysql' | 'elasticsearch'
}

export function listJobs(params: JobListParams): Promise<JobListResult> {
  const query: Record<string, string | number | boolean | undefined> = {}
  Object.entries(params).forEach(([key, value]) => {
    if (value === undefined || value === '') return
    query[key] = value
  })
  return api.get<JobListResult>('/jobs', query)
}

export function getJob(id: number): Promise<JobRow> {
  return api.get<JobRow>(`/jobs/${id}`)
}

export function getSimilarJobs(id: number): Promise<JobRow[]> {
  return api.get<JobRow[]>(`/jobs/${id}/similar`)
}

/**
 * apply_job() (class-jp-api.php) requires resume_id — it 400s without one
 * ("resume_id is required.") — so the apply flow's UI must collect/select a
 * resume before this can be called; cover_letter alone is not sufficient.
 */
export function applyToJob(
  jobId: number,
  // Batch 35: `answers` lines up positionally with the job's screening_q
  // list (see JobDetailPage.tsx's apply wizard) — apply_job() (class-jp-
  // api.php) now forwards this to ajax_apply()'s screening_ans the same way
  // resume_id/cover_letter already were.
  payload: { resume_id: number; cover_letter?: string; answers?: string[] },
): Promise<{ message: string }> {
  return api.post<{ message: string }>(`/jobs/${jobId}/apply`, payload)
}

/** job_apply_status() — lets the detail page know on load whether the signed-in candidate already applied, without re-deriving it from a full applications list. */
export function getJobApplyStatus(jobId: number): Promise<{ has_applied: boolean; stage: string | null }> {
  return api.get<{ has_applied: boolean; stage: string | null }>(`/jobs/${jobId}/apply-status`)
}
