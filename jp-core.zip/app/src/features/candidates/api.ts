import { api } from '@/lib/apiClient'

/** Transcribed from jp_candidates' CREATE TABLE (class-jp-activator.php). */
export interface CandidateProfile {
  id: number
  user_id: number
  headline: string | null
  about: string | null
  avatar_url: string | null
  phone: string | null
  location_city: string | null
  location_state: string | null
  experience_years: number
  current_title: string | null
  current_company: string | null
  current_salary: number
  expected_salary_min: number
  expected_salary_max: number
  notice_period_days: number
  willing_to_relocate: 0 | 1
  preferred_work_mode: 'any' | 'onsite' | 'remote' | 'hybrid'
  portfolio_url: string | null
  linkedin_url: string | null
  github_url: string | null
  profile_score: number
  is_open_to_work: 0 | 1
  visibility: 'public' | 'recruiters' | 'private'
  skills: string[]
}

export interface MeResult {
  id: number
  name: string
  email: string
  role: string
  plan: string
  candidate: CandidateProfile | null
}

export function getMe(): Promise<MeResult> {
  return api.get<MeResult>('/candidates/me')
}

/**
 * Whitelist transcribed from apply_profile_update()'s array_intersect_key()
 * call — any field NOT in that list is silently dropped server-side, so
 * the edit form must only ever send these (plus skills/display_name, which
 * are handled by separate code paths in the same method).
 */
export interface ProfileUpdatePayload {
  display_name?: string
  headline?: string
  about?: string
  location_city?: string
  location_state?: string
  phone?: string
  experience_years?: number
  current_title?: string
  current_company?: string
  linkedin_url?: string
  github_url?: string
  portfolio_url?: string
  current_salary?: number
  expected_salary_min?: number
  expected_salary_max?: number
  notice_period_days?: number
  preferred_work_mode?: 'any' | 'onsite' | 'remote' | 'hybrid'
  willing_to_relocate?: 0 | 1
  is_open_to_work?: 0 | 1
  visibility?: 'public' | 'recruiters' | 'private'
  skills?: string[]
}

export function updateProfile(payload: ProfileUpdatePayload): Promise<{ message: string }> {
  return api.put<{ message: string }>('/candidates/me', payload)
}
