import { api } from '@/lib/apiClient'

/** Transcribed from public_profile()'s return array. */
export interface PublicAssessment {
  skill_name: string | null
  badge_level: string
  score: number
}

export interface PublicProfile {
  id: number
  name: string
  candidate: {
    user_id: number
    headline?: string
    about?: string
    avatar_url?: string
    location_city?: string
    location_state?: string
    experience_years?: number
    current_title?: string
    current_company?: string
    preferred_work_mode?: 'any' | 'onsite' | 'remote' | 'hybrid'
    willing_to_relocate?: 0 | 1
    portfolio_url?: string
    linkedin_url?: string
    github_url?: string
    is_open_to_work?: boolean
    visibility: 'public' | 'recruiters' | 'private'
    [key: string]: unknown
  }
  sections: Record<string, unknown[]>
  badges: string[]
  assessments: PublicAssessment[]
}

export function getPublicProfile(id: number): Promise<PublicProfile> {
  return api.get<PublicProfile>(`/profiles/${id}`)
}
