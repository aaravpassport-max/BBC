import { api, apiUpload } from '@/lib/apiClient'

/** Transcribed field-for-field from candidate_analytics()'s return shape. */
export interface CandidateAnalytics {
  profile_views: number
  search_appears: number
  applications: number
  shortlisted: number
  saved_by: number
}

export function getCandidateAnalytics(days = 30): Promise<CandidateAnalytics> {
  return api.get<CandidateAnalytics>('/candidates/me/analytics', { days })
}

/** upload_avatar() reads $_FILES['file'], validates type/size server-side, writes jp_candidates.avatar_url. */
export function uploadAvatar(file: File): Promise<{ avatar_url: string }> {
  return apiUpload<{ avatar_url: string }>('/candidates/me/avatar', 'file', file)
}

/** Transcribed from get_notif_prefs()'s default shape — same keys save_notif_prefs() whitelists. */
export interface NotificationPreferences {
  email_new_match: boolean
  email_stage_change: boolean
  email_message: boolean
  email_digest: boolean
  push_new_match: boolean
  push_message: boolean
  sms_stage_change: boolean
}

export function getNotificationPreferences(): Promise<NotificationPreferences> {
  return api.get<NotificationPreferences>('/notifications/preferences')
}

export function saveNotificationPreferences(prefs: NotificationPreferences): Promise<{ message: string }> {
  return api.put<{ message: string }>('/notifications/preferences', prefs)
}

/**
 * Root-cause fix: the REST route this originally called — POST
 * /push/subscribe, class-jp-api.php's push_subscribe() — writes to a
 * column literally named 'p256dh'. The actual wp_jp_push_subscriptions
 * table (class-jp-activator.php) has no such column; it has
 * 'p256dh_key', which is what the send-side broadcast code
 * (class-jp-pwa.php, reading $sub->p256dh_key) actually consumes. Every
 * call to that REST route therefore fails its $wpdb->replace() silently
 * (wpdb suppresses SQL errors by default; the handler doesn't check the
 * return value) while still returning {message: 'Subscribed...'} —
 * a "ghost success": the browser subscribes, the UI says success, and no
 * row is ever actually saved, so no push notification could ever be sent.
 *
 * class-jp-pwa.php's own AJAX pair — wp_ajax_jp_save_push_sub /
 * wp_ajax_jp_delete_push_sub — writes/reads the correct 'p256dh_key'
 * column and is what the theme's own (root-scoped) push flow already
 * uses in production. Since the REST route is unconditionally broken and
 * the backend is frozen (can't fix the column name there), this goes
 * through the AJAX pair instead — same table, same feature, the one that
 * actually persists. POST /push/unsubscribe (a plain DELETE by user_id,
 * no column reference) has no such bug and is left as-is.
 */
export async function pushSubscribe(
  ajaxUrl: string,
  ajaxNonce: string,
  subscription: PushSubscriptionJSON,
): Promise<{ ok: boolean }> {
  const body = new URLSearchParams({
    action: 'jp_save_push_sub',
    nonce: ajaxNonce,
    subscription: JSON.stringify(subscription),
  })
  const res = await fetch(ajaxUrl, {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
  })
  if (!res.ok) throw new Error(`Failed to save push subscription (HTTP ${res.status}).`)
  const json = (await res.json()) as { success: boolean; data?: { ok?: boolean } }
  if (!json.success) throw new Error('Failed to save push subscription.')
  return { ok: Boolean(json.data?.ok) }
}

export function pushUnsubscribe(): Promise<{ message: string }> {
  return api.post<{ message: string }>('/push/unsubscribe', {})
}
