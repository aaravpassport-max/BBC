import { api } from '@/lib/apiClient'

export interface TwoFaSetup {
  secret: string
  qr_uri: string
}

export function setupTwoFa(): Promise<TwoFaSetup> {
  return api.post<TwoFaSetup>('/auth/2fa/setup', {})
}

export function verifyTwoFa(code: string): Promise<{ message: string }> {
  return api.post('/auth/2fa/verify', { code })
}

export function disableTwoFa(code: string): Promise<{ message: string }> {
  return api.post('/auth/2fa/disable', { code })
}
