import { api } from '@/lib/apiClient'

/**
 * All 9 AI endpoints share the same "graceful degradation" envelope from
 * JP_AI::unavailable_response() — {available:false, feature, reason} when
 * the OpenAI key is missing, the call failed, or the response couldn't be
 * parsed — rather than an HTTP error. Every AI_* type below is a union of
 * the specific success shape and this common failure shape so callers must
 * check `available` before reading the rest.
 */
export interface AiUnavailable {
  available: false
  feature: string
  reason: string
}

export interface ResumeScoreResult {
  available: true
  overall: number
  sections: Record<string, number>
  strengths: string[]
  improvements: string[]
  missing: string[]
}

export function getResumeScore(): Promise<ResumeScoreResult | AiUnavailable> {
  return api.get('/ai/resume-score')
}

export interface ImproveBulletResult {
  available: true
  alternatives: string[]
}

export function improveBullet(bullet: string, context?: string): Promise<ImproveBulletResult | AiUnavailable> {
  return api.post('/ai/resume-improve', { bullet, context })
}

export interface CoverLetterResult {
  available: true
  subject: string
  body: string
}

export function generateCoverLetter(jobId: number): Promise<CoverLetterResult | AiUnavailable> {
  return api.post('/ai/cover-letter', { job_id: jobId })
}

export interface InterviewPrepQuestion {
  question: string
  type: string
  tip: string
  sample_answer: string
}

export interface InterviewPrepResult {
  available: true
  job_title: string
  company: string
  questions: InterviewPrepQuestion[]
}

export function getInterviewPrep(jobId: number): Promise<InterviewPrepResult | AiUnavailable> {
  return api.post('/ai/interview-prep', { job_id: jobId })
}

export interface InterviewQuestion {
  question: string
  category: string
  what_to_listen_for: string
}

export interface InterviewQuestionsResult {
  available: true
  job_title: string
  questions: InterviewQuestion[]
}

export function getInterviewQuestions(jobId: number): Promise<InterviewQuestionsResult | AiUnavailable> {
  return api.post('/ai/interview-questions', { job_id: jobId })
}

export interface ActionStep {
  step: string
  priority: string
  timeframe: string
}

export interface RecommendedPath {
  path: string
  description: string
}

export interface CareerAdviceResult {
  available: true
  target_role: string
  readiness_percent: number
  timeline_months: number
  skill_gaps: string[]
  action_steps: ActionStep[]
  recommended_paths: RecommendedPath[]
  market_demand: string
}

export function getCareerAdvice(targetRole: string): Promise<CareerAdviceResult | AiUnavailable> {
  return api.post('/ai/career-advice', { target_role: targetRole })
}

export interface ImproveJdResult {
  available: true
  improved_description: string
  improvements_made: string[]
  ats_keywords: string[]
  readability_score: number
}

export function improveJobDescription(title: string, description: string): Promise<ImproveJdResult | AiUnavailable> {
  return api.post('/ai/improve-jd', { title, description })
}

export interface SalaryNegotiateResult {
  available: true
  offer_amount: number
  market_rate_min: number
  market_rate_max: number
  negotiation_target: number
  is_fair_offer: boolean
  opening_script: string
  counter_arguments: string[]
  non_salary_perks: string[]
  walk_away_if: string
}

export function getSalaryNegotiationAdvice(
  offerAmount: number,
  role: string,
  location: string,
): Promise<SalaryNegotiateResult | AiUnavailable> {
  return api.post('/ai/salary-negotiate', { offer_amount: offerAmount, role, location })
}

export interface LearningResource {
  name: string
  url: string
  type: string
}

export interface SkillDemandResult {
  available: true
  skill: string
  active_job_count: number
  demand_level: string
  trend: string
  description: string
  avg_salary_premium_pct: number
  top_industries: string[]
  complementary_skills: string[]
  future_outlook: string
  learning_resources: LearningResource[]
}

export function getSkillDemand(skill: string): Promise<SkillDemandResult | AiUnavailable> {
  return api.get('/ai/skill-demand', { skill })
}
