import { api } from '@/lib/apiClient'

/** Transcribed from jp_message_threads' CREATE TABLE + get_threads()'s JOINed columns. */
export interface ThreadRow {
  id: number
  job_id: number
  application_id: number
  recruiter_id: number
  candidate_id: number
  subject: string | null
  last_message: string | null
  last_at: string
  unread_count: number
  is_archived: 0 | 1
  job_title: string | null
  recruiter_name: string | null
  candidate_name: string | null
}

/** Transcribed from jp_messages' CREATE TABLE + get_thread_messages()'s JOINed columns. */
export interface MessageRow {
  id: number
  thread_id: number
  sender_id: number
  body: string
  is_read: 0 | 1
  created_at: string
  display_name: string | null
}

/**
 * Root-cause fix (Phase 3 redesign pass): jp_message_threads.is_archived
 * has always existed and been returned on every thread, but get_threads()
 * never filtered by it and no route ever wrote to it — a conversation
 * could never actually be archived. Defaults to the active list.
 */
export function listThreads(archived = false): Promise<ThreadRow[]> {
  return api.get<ThreadRow[]>('/threads', archived ? { archived: '1' } : undefined)
}

export function archiveThread(threadId: number, archived = true): Promise<{ message: string }> {
  return api.put<{ message: string }>(`/threads/${threadId}/archive`, { archived: archived ? '1' : '0' })
}

export function createThread(recipientId: number, jobId?: number): Promise<{ thread_id: number }> {
  return api.post<{ thread_id: number }>('/threads', { recipient_id: recipientId, job_id: jobId })
}

export function getThreadMessages(threadId: number, since?: string): Promise<MessageRow[]> {
  return api.get<MessageRow[]>(`/threads/${threadId}/messages`, since ? { since } : undefined)
}

export function sendMessage(threadId: number, body: string): Promise<MessageRow> {
  return api.post<MessageRow>(`/threads/${threadId}/messages`, { body })
}

/**
 * Root-cause fix (batch 23). Wraps the new PUT /threads/{id}/read route
 * (class-jp-api.php's mark_thread_read() -> JP_Messaging::ajax_mark_read(),
 * hardened against a ghost-success in batch 17) — this had zero REST route
 * and zero SPA caller until now, so opening a thread never actually marked
 * its messages read: unread badges never cleared and senders could never
 * tell whether a message had been seen. See MessagesPage.tsx.
 */
export function markThreadRead(threadId: number): Promise<{ ok: boolean }> {
  return api.put<{ ok: boolean }>(`/threads/${threadId}/read`)
}

/**
 * Batch 25 (messaging-upgrades backlog: canned responses). Recruiter-only
 * (server-scoped to jp_recruiter/jp_team_manager/jp_admin_manager/
 * jp_super_admin/administrator via require_recruiter()) saved reply
 * templates — see class-jp-messaging.php's do_list_canned()/
 * do_save_canned()/do_delete_canned() docblock. Brand-new table, so
 * there's no legacy shape to transcribe from; fields below match what
 * do_list_canned()'s SELECT * actually returns.
 */
export interface CannedResponseRow {
  id: number
  user_id: number
  title: string
  body: string
  created_at: string
}

export function listCannedResponses(): Promise<CannedResponseRow[]> {
  return api.get<CannedResponseRow[]>('/canned-responses')
}

export function saveCannedResponse(title: string, body: string): Promise<{ message: string; id: number }> {
  return api.post<{ message: string; id: number }>('/canned-responses', { title, body })
}

export function deleteCannedResponse(id: number): Promise<{ message: string }> {
  return api.delete<{ message: string }>(`/canned-responses/${id}`)
}
