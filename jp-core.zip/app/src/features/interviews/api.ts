import { api } from '@/lib/apiClient'

/**
 * Batch 36 (interview-management depth pass) — the candidate side of
 * jp_interviews. Deliberately a separate type/module from
 * features/recruiter/interviewsApi.ts's InterviewRow: that one is scoped to
 * the $rec-gated /interviews route and joins in candidate_name (irrelevant
 * here); this one hits /my-interviews (get_my_interviews() in
 * class-jp-api.php) and joins in recruiter_name instead. Same underlying
 * table/columns otherwise.
 */
export interface MyInterviewRow {
  id: number
  application_id: number
  job_id: number
  round: number
  type: 'phone' | 'video' | 'onsite' | 'technical' | 'hr'
  scheduled_at: string | null
  duration_min: number
  meeting_link: string | null
  location: string | null
  outcome: 'pending' | 'passed' | 'failed' | 'cancelled' | 'no_show'
  candidate_confirmed: 0 | 1
  reschedule_requested: 0 | 1
  reschedule_reason: string | null
  created_at: string
  job_title: string | null
  company_name: string | null
  recruiter_name: string | null
}

export function listMyInterviews(): Promise<MyInterviewRow[]> {
  return api.get<MyInterviewRow[]>('/my-interviews')
}

export function confirmInterview(id: number): Promise<{ message: string }> {
  return api.put<{ message: string }>(`/interviews/${id}/confirm`)
}

export function requestInterviewReschedule(id: number, reason: string): Promise<{ message: string }> {
  return api.put<{ message: string }>(`/interviews/${id}/request-reschedule`, { reason })
}
