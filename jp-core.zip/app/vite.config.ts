import react from '@vitejs/plugin-react'
import { defineConfig } from 'vite'
import { readFileSync } from 'node:fs'
import { fileURLToPath, URL } from 'node:url'

// The plugin version drives the output filename (jp-app.<version>.js), the
// same "bake the version into the filename" cache-busting scheme the old
// compiled SPA already used and that class-jp-react.php's asset loader
// already knows how to discover (glob for jp-app.*.js). Reading it from
// jp-core.php's JP_VERSION define keeps the two in lockstep without a
// manual version bump in two places — the exact "silent version drift"
// class of bug fixed earlier in this engagement for the old SPA.
function readPluginVersion(): string {
  try {
    const src = readFileSync(new URL('../jp-core.php', import.meta.url), 'utf-8')
    const m = src.match(/define\(\s*'JP_VERSION',\s*'([\d.]+)'/)
    if (m) return m[1]
  } catch {
    // fall through to dev fallback below
  }
  return '0.0.0-dev'
}

const APP_VERSION = readPluginVersion()

// https://vite.dev/config/
export default defineConfig({
  // Root-cause fix (confirmed via live browser console errors): with no
  // `base` set, Vite defaults to base: '/' — which is fine for the actual
  // JS module graph (dynamic import('./chunks/X.js') calls resolve
  // natively relative to the importing module's own URL regardless of
  // `base`) but is WRONG for the separate CSS/modulepreload dependency
  // list Vite's __vitePreload() runtime helper reads from: those entries
  // get baked in as absolute-from-site-root strings (e.g. "/jp-app16.css"),
  // and `new URL("/jp-app16.css", import.meta.url)` ignores the base
  // argument's path entirely once the first argument starts with "/" — it
  // only keeps import.meta.url's ORIGIN. The result: every lazy-loaded
  // page's CSS (and its modulepreload hints) request
  // "https://<site>/jp-app16.css" — literally the site root — instead of
  // the real location under .../wp-content/plugins/jp-core/app-dist/,
  // regardless of what page of the site the app is mounted on. This is a
  // WordPress-plugin-subdirectory deployment, not a root-domain SPA, so a
  // relative base is required: base: './' makes Vite emit these same
  // dependency-list entries as relative strings ("./jp-app16.css"), which
  // __vitePreload()'s import.meta.url-relative resolution then correctly
  // anchors to wherever the actual script file lives on disk — independent
  // of whichever page of the site is currently being viewed.
  base: './',
  plugins: [react()],
  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },
  define: {
    __APP_VERSION__: JSON.stringify(APP_VERSION),
  },
  build: {
    // Ships next to (not overwriting) the legacy compiled SPA during the
    // migration — class-jp-react.php is switched to point here only once
    // a phase is verified complete, per the roadmap's phased cutover.
    outDir: '../app-dist',
    emptyOutDir: true,
    sourcemap: true,
    // Root-cause fix (traced from the live "Unable to preload CSS for
    // .../jp-app16.css" ErrorBoundary crash all the way to its real cause):
    // with Vite's default per-chunk CSS splitting on, every lazily-loaded
    // route got its own CSS asset — but assetFileNames below collapses
    // every CSS asset's name to the literal string 'jp-app.css' (needed
    // because class-jp-react.php's PHP enqueue code looks for that exact
    // filename on disk). Rollup can't have 19+ files share one literal
    // name, so it silently disambiguated them as jp-app.css, jp-app2.css,
    // ... jp-app19.css — numbered, NOT content-hashed. Two compounding
    // problems followed: (1) those numbered files carry no cache-busting
    // signal of their own (unlike every other asset here, which gets a
    // real content hash) and aren't enqueued through WordPress at all, so
    // nothing ever forces a stale cached copy to be re-fetched after a
    // rebuild; (2) the number Rollup assigns to any given chunk's CSS is
    // just emission order, which can silently shift between builds (e.g.
    // adding one new route), so "jp-app8.css" is not a stable identity —
    // a cache or CDN holding an old jp-app8.css after a rebuild may now be
    // serving a completely different route's styles under that same name.
    // Disabling CSS code-splitting bundles all of the app's CSS into the
    // single jp-app.css file that already exists and is already correctly
    // cache-busted (enqueue_react_assets() uses filemtime() for it). This
    // also directly eliminates the crash itself: lazy-loaded route chunks
    // no longer have a separate CSS dependency for __vitePreload() to
    // fetch at all, so there is nothing left to 404 or fail to preload.
    // Trade-off: the full app CSS loads upfront instead of per-route,
    // acceptable for this app's bundle size and far more reliable than
    // 19 independently-cached, non-content-hashed CSS files.
    cssCodeSplit: false,
    rollupOptions: {
      output: {
        // Root-cause fix (confirmed via a live browser console error: a
        // dynamically-imported route chunk 404'd — "Failed to fetch
        // dynamically imported module: .../LoginPage-B-V51miR.js" —
        // alongside a "useNavigate() may be used only in the context of a
        // <Router> component" crash on HomePage, both traced to the same
        // cause: a live diagnostic run showed THIS entry file being served
        // with `nestify-cdn-status: HIT` from the fronting CDN — that CDN
        // layer caches by URL PATH and evidently ignores the `?ver=` query
        // string entirely (the exact risk app-dist/.htaccess's self-heal
        // in class-jp-react.php already defends against, but that defense
        // only works if the CDN honors Cache-Control headers at all — this
        // one doesn't even need to, since it never re-requests the
        // unchanged path in the first place). Every build wipes and
        // regenerates app-dist/ (emptyOutDir above) with fresh per-route
        // chunk hashes, so a browser served a CDN-cached OLD copy of this
        // entry file — same path, same query, forever a HIT — keeps trying
        // to dynamically import chunk files from the PREVIOUS build that
        // literally no longer exist on disk: a permanent 404, not a
        // transient one, and pairing that stale entry with an adjacent
        // build's differently-built router internals explains the
        // "no Router context" crash. Appending Rollup's own content hash
        // to this filename — the same technique chunkFileNames below
        // already uses, and which has never shown this symptom — means
        // the PATH itself changes whenever the content changes: the one
        // cache-invalidation signal that works even against a cache that
        // ignores query strings, headers, or both. The version number is
        // kept alongside the hash (not replaced by it), purely for
        // human/admin readability and the jp_react_app_version tracking
        // in class-jp-react.php/class-jp-diagnostics.php — the hash is
        // what actually does the cache-busting work now.
        entryFileNames: `jp-app.${APP_VERSION}-[hash].js`,
        chunkFileNames: `chunks/[name]-[hash].js`,
        assetFileNames: (assetInfo) => {
          if (assetInfo.name?.endsWith('.css')) return 'jp-app.css'
          return 'assets/[name]-[hash][extname]'
        },
      },
    },
  },
})
