<?php
/**
 * Lightweight PHPUnit bootstrap for pure-logic unit tests.
 *
 * This intentionally does NOT bring up a full WordPress test install
 * (WP_UnitTestCase / wp-env / the WP SVN test library) — that is real,
 * valuable follow-on work (see tests/README.md) but is a separate,
 * heavier piece of infrastructure than fits in this pass. What this DOES
 * give the project, starting from literally nothing (there was no tests/
 * directory, no CI, and no linting configured anywhere in this codebase
 * before this round — see the gap analysis, §"cross-cutting infrastructure"
 * and "Critical missing functionality"), is a real, runnable regression
 * suite for the pure-PHP logic this round's fixes touched, so at least
 * those specific defects can never silently reappear.
 *
 * It stubs the minimal set of WordPress functions the tested classes
 * reference at load time or in the specific methods under test, and loads
 * just the class files needed — not the whole plugin bootstrap (which
 * requires a real WP environment).
 */

if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

// ── Minimal WordPress function stubs ─────────────────────────────────────
// Only what the classes under test actually call. Each stub's behavior is
// documented so it's obvious this is a test double, not real WP behavior.

if ( ! function_exists( 'wp_send_json' ) ) {
	/**
	 * Test double: records the payload instead of emitting JSON + exit(),
	 * so jp_json_response() can be tested without terminating the process.
	 */
	function wp_send_json( $response, $status_code = null ) {
		throw new JP_Test_JsonResponseCapture( $response, $status_code );
	}
}

if ( ! function_exists( 'get_option' ) ) {
	function get_option( $name, $default = false ) {
		return $GLOBALS['jp_test_options'][ $name ] ?? $default;
	}
}

if ( ! function_exists( 'update_option' ) ) {
	function update_option( $name, $value, $autoload = null ) {
		$GLOBALS['jp_test_options'][ $name ] = $value;
		return true;
	}
}

if ( ! function_exists( 'sanitize_text_field' ) ) {
	function sanitize_text_field( $str ) { return trim( (string) $str ); }
}

if ( ! function_exists( 'wp_unslash' ) ) {
	function wp_unslash( $value ) { return $value; }
}

if ( ! function_exists( 'wp_json_encode' ) ) {
	function wp_json_encode( $data, $options = 0, $depth = 512 ) { return json_encode( $data, $options, $depth ); }
}

if ( ! function_exists( 'wp_parse_url' ) ) {
	function wp_parse_url( $url, $component = -1 ) { return parse_url( $url, $component ); }
}

// The remaining stubs exist only so jp-core.php's top-level (file-scope)
// code can execute during require — they are registration/no-op calls
// that jp_init() (never actually invoked here, since add_action() below
// is a no-op) would otherwise need a real WordPress environment for.
if ( ! function_exists( 'plugin_dir_path' ) ) {
	function plugin_dir_path( $file ) { return rtrim( dirname( $file ), '/' ) . '/'; }
}
if ( ! function_exists( 'plugin_dir_url' ) ) {
	function plugin_dir_url( $file ) { return 'http://example.test/wp-content/plugins/jp-core/'; }
}
if ( ! function_exists( 'plugin_basename' ) ) {
	function plugin_basename( $file ) { return basename( dirname( $file ) ) . '/' . basename( $file ); }
}
if ( ! function_exists( 'register_activation_hook' ) )   { function register_activation_hook( $file, $cb ) {} }
if ( ! function_exists( 'register_deactivation_hook' ) )  { function register_deactivation_hook( $file, $cb ) {} }
if ( ! function_exists( 'register_uninstall_hook' ) )     { function register_uninstall_hook( $file, $cb ) {} }
if ( ! function_exists( 'add_action' ) )                  { function add_action( ...$args ) {} }
if ( ! function_exists( 'add_filter' ) )                  { function add_filter( ...$args ) {} }
if ( ! function_exists( 'has_action' ) )                  { function has_action( ...$args ) { return false; } }
if ( ! function_exists( 'do_action' ) )                   { function do_action( ...$args ) {} }
if ( ! function_exists( 'wp_generate_password' ) )        { function wp_generate_password( $length = 12, $special_chars = true ) { return substr( bin2hex( random_bytes( (int) ceil( $length / 2 ) ) ), 0, $length ); } }
if ( ! function_exists( 'load_plugin_textdomain' ) )      { function load_plugin_textdomain( ...$args ) {} }

/**
 * Thrown by the wp_send_json() stub to let tests inspect the response
 * without needing wp_send_json()'s real behavior (echo + exit).
 */
class JP_Test_JsonResponseCapture extends \Exception {
	public array $response;
	public ?int $status_code;
	public function __construct( array $response, ?int $status_code ) {
		parent::__construct( 'json response captured' );
		$this->response    = $response;
		$this->status_code = $status_code;
	}
}

require_once __DIR__ . '/../jp-core.php';
