# jp-core test suite

## What this is

A lightweight PHPUnit suite for the highest-risk, already-fixed pure-PHP
logic in this plugin — no full WordPress test install (`WP_UnitTestCase`,
wp-env, the WP SVN test library) is used. `tests/bootstrap.php` stubs the
small set of WordPress functions the loaded classes touch at file-load time
(`add_action`, `register_activation_hook`, `get_option`, etc.) so
`jp-core.php` can be `require`d directly in a plain PHP CLI process.

This is intentionally scoped, not a substitute for real WordPress
integration testing:

- Covered: `jp_json_response()`'s argument-order normalization (the
  request-killing bug fixed in 6.11.1), `JP_Matching`'s pure scoring
  functions (`score()`, `score_breakdown()`), and `JP_Webhooks`'s SSRF
  target-URL guard (`is_safe_target_url()`).
- Not covered: anything that touches `$wpdb` (no database is stood up),
  AJAX permission/nonce flows, or any class whose constructor does real
  work against a live WordPress install. Extending coverage there requires
  either a real `$wpdb` test double with an in-memory SQLite/MySQL schema,
  or standing up `WP_UnitTestCase` — tracked as follow-on work, not done
  in this pass.

## Running locally

```bash
composer install
composer test          # = vendor/bin/phpunit --colors=always
composer lint          # = php -l across every file
```

**Known sandbox limitation (disclosed, not hidden):** in the environment
this suite was authored in, outbound access to `packagist.org` was blocked
(`curl error 56 ... 403`), so `composer install` could not actually fetch
`phpunit/phpunit` here. The test files' assertions were instead verified
logically correct via a standalone plain-PHP smoke script that requires
the same `tests/bootstrap.php`, loads the same classes, and re-implements
every assertion in the two test files with `assert()`/manual comparisons
— all 26 checks passed. The GitHub Actions workflow
(`.github/workflows/ci.yml`) runs the real PHPUnit suite on every push,
where packagist is reachable; that CI run is the authoritative pass/fail
signal for this suite, not the sandbox smoke script.

## Adding a test

Put new test classes under `tests/unit/`, extend
`PHPUnit\Framework\TestCase`, and — if the code under test calls any
WordPress function not yet stubbed — add the smallest possible stub to
`tests/bootstrap.php` with a comment explaining what real behavior it
is standing in for.
