<?php
/**
 * Regression tests for JP_Matching's pure-logic scoring engine.
 *
 * These exercise score() and score_breakdown() — both public, both pure
 * functions of two plain objects with no database or network dependency —
 * covering the skills/experience/location weighting logic and the
 * previously-dead score_detail breakdown (see class-jp-matching.php and
 * enterprise-gap-analysis.md: "jp_matches.score_detail is never written").
 */

use PHPUnit\Framework\TestCase;

final class MatchingTest extends TestCase {

	private function candidate( array $overrides = [] ): object {
		return (object) array_merge( [
			'skills_json'          => json_encode( [ 'PHP', 'MySQL', 'WordPress' ] ),
			'experience_years'     => 3,
			'preferred_work_mode'  => 'remote',
			'willing_to_relocate'  => 0,
			'location_city'        => 'Pune',
			'location_state'       => 'Maharashtra',
			'education_json'       => json_encode( [ 'degree' => 'Bachelor of Technology' ] ),
			'expected_salary'      => 0,
		], $overrides );
	}

	private function job( array $overrides = [] ): object {
		return (object) array_merge( [
			'skills_json'      => json_encode( [ 'PHP', 'MySQL' ] ),
			'experience_min'   => 2,
			'experience_max'   => 5,
			'work_mode'        => 'remote',
			'location_city'    => '',
			'location_state'   => '',
			'education_level'  => '',
			'salary_min'       => 0,
			'salary_max'       => 0,
		], $overrides );
	}

	public function test_perfect_skills_and_experience_match_scores_high(): void {
		$score = JP_Matching::instance()->score( $this->candidate(), $this->job(), false );
		$this->assertGreaterThanOrEqual( 80, $score, 'A candidate with full skill overlap, in-range experience, and a remote job should score near-perfect.' );
	}

	public function test_candidate_with_no_matching_skills_scores_lower_than_full_match(): void {
		// Skills carry a 40% weight, so a total skills mismatch must pull the
		// total meaningfully below a candidate who matches on every factor —
		// even though the other four (neutral-by-default) factors keep the
		// absolute score from collapsing to near-zero. Asserting a relative
		// drop (rather than an arbitrary absolute threshold) locks in the
		// actual weighting behavior instead of a number that happens to look
		// right for one specific set of neutral defaults.
		$fullMatch = JP_Matching::instance()->score( $this->candidate(), $this->job(), false );
		$noSkillsMatch = JP_Matching::instance()->score(
			$this->candidate( [ 'skills_json' => json_encode( [ 'Photoshop' ] ) ] ),
			$this->job(),
			false
		);
		$this->assertLessThan( $fullMatch, $noSkillsMatch );
		$this->assertLessThanOrEqual( $fullMatch - 35, $noSkillsMatch, 'A 100%-weighted-40% skills factor dropping from ~100 to 0 should reduce the total by roughly 35-40 points.' );
	}

	public function test_under_experienced_candidate_is_penalized(): void {
		$fullyQualified = JP_Matching::instance()->score( $this->candidate( [ 'experience_years' => 3 ] ), $this->job(), false );
		$underQualified = JP_Matching::instance()->score( $this->candidate( [ 'experience_years' => 0 ] ), $this->job(), false );

		$this->assertLessThan( $fullyQualified, $underQualified, 'A candidate with 0 years against a 2-5 year requirement should score lower than one within range.' );
	}

	public function test_onsite_job_penalizes_remote_only_candidate(): void {
		$score = JP_Matching::instance()->score(
			$this->candidate( [ 'preferred_work_mode' => 'remote', 'willing_to_relocate' => 0 ] ),
			$this->job( [ 'work_mode' => 'onsite', 'location_city' => 'Delhi' ] ),
			false
		);
		$remoteScore = JP_Matching::instance()->score( $this->candidate(), $this->job(), false );

		$this->assertLessThan( $remoteScore, $score );
	}

	public function test_score_is_always_within_0_to_100_bounds(): void {
		// Deliberately pathological inputs (huge experience gap, no skills at
		// all) — the score must still clamp to [0, 100], never go negative
		// or overflow, regardless of how the per-factor math combines.
		$score = JP_Matching::instance()->score(
			$this->candidate( [ 'skills_json' => '[]', 'experience_years' => 0 ] ),
			$this->job( [ 'experience_min' => 20, 'experience_max' => 25 ] ),
			false
		);
		$this->assertGreaterThanOrEqual( 0, $score );
		$this->assertLessThanOrEqual( 100, $score );
	}

	public function test_use_ai_boost_false_never_calls_external_api(): void {
		// Regression guard for the real-time-fallback fix: when $use_ai_boost
		// is false, score() must not attempt the OpenAI network call even if
		// JP_OPENAI_KEY were defined — the whole point of the parameter is to
		// let synchronous request-cycle scoring skip the network entirely.
		$score = JP_Matching::instance()->score( $this->candidate(), $this->job(), false );
		$this->assertIsInt( $score );
	}

	public function test_score_breakdown_returns_all_five_weighted_factors(): void {
		$breakdown = JP_Matching::instance()->score_breakdown( $this->candidate(), $this->job() );

		foreach ( [ 'skills', 'experience', 'location', 'education', 'salary' ] as $factor ) {
			$this->assertArrayHasKey( $factor, $breakdown );
			$this->assertIsInt( $breakdown[ $factor ] );
		}

		$this->assertEqualsWithDelta( 1.0, array_sum( $breakdown['weights'] ), 0.0001, 'The five factor weights must sum to 1.0 (100%).' );
	}
}
