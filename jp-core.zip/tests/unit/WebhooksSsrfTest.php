<?php
/**
 * Regression tests for JP_Webhooks::is_safe_target_url() — the SSRF guard
 * added when webhook dispatch was implemented (see class-jp-webhooks.php's
 * docblock and phase2-progress-report.md). Before this, a webhook's target
 * URL was saved with no validation at all: an admin (or an attacker who
 * compromised an admin session) could register a "webhook" pointed at
 * 127.0.0.1, an internal service, or a cloud metadata endpoint, and the
 * existing "test send" button would fire an authenticated, server-side
 * request at it on demand — a textbook SSRF primitive.
 *
 * These tests only exercise the static, network-free part of the guard
 * (the range-checking logic against literal IPs and localhost); the
 * DNS-resolution branch (gethostbyname() for a real hostname) is not
 * exercised here since it requires actual DNS resolution and is a thin
 * wrapper the logic below already covers once the IP is known.
 */

use PHPUnit\Framework\TestCase;

final class WebhooksSsrfTest extends TestCase {

	public function test_loopback_ip_is_rejected(): void {
		$this->assertFalse( JP_Webhooks::is_safe_target_url( 'http://127.0.0.1/webhook' ) );
	}

	public function test_localhost_hostname_is_rejected(): void {
		$this->assertFalse( JP_Webhooks::is_safe_target_url( 'http://localhost/webhook' ) );
	}

	public function test_private_range_ip_is_rejected(): void {
		$this->assertFalse( JP_Webhooks::is_safe_target_url( 'http://10.0.0.5/webhook' ) );
		$this->assertFalse( JP_Webhooks::is_safe_target_url( 'http://192.168.1.10/webhook' ) );
		$this->assertFalse( JP_Webhooks::is_safe_target_url( 'http://172.16.0.1/webhook' ) );
	}

	public function test_cloud_metadata_ip_is_rejected(): void {
		// 169.254.0.0/16 (link-local) covers the AWS/GCP/Azure metadata IP.
		$this->assertFalse( JP_Webhooks::is_safe_target_url( 'http://169.254.169.254/latest/meta-data/' ) );
	}

	public function test_metadata_hostname_is_rejected_even_if_resolvable(): void {
		$this->assertFalse( JP_Webhooks::is_safe_target_url( 'http://metadata.google.internal/computeMetadata/v1/' ) );
	}

	public function test_non_http_scheme_is_rejected(): void {
		$this->assertFalse( JP_Webhooks::is_safe_target_url( 'file:///etc/passwd' ) );
		$this->assertFalse( JP_Webhooks::is_safe_target_url( 'ftp://example.com/' ) );
		$this->assertFalse( JP_Webhooks::is_safe_target_url( 'gopher://127.0.0.1:6379/' ) );
	}

	public function test_missing_host_is_rejected(): void {
		$this->assertFalse( JP_Webhooks::is_safe_target_url( 'http:///no-host' ) );
	}

	public function test_public_ip_is_allowed(): void {
		// 8.8.8.8 is a well-known public IP; the guard should not reject it.
		$this->assertTrue( JP_Webhooks::is_safe_target_url( 'https://8.8.8.8/webhook' ) );
	}
}
