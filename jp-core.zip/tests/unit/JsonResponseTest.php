<?php
/**
 * Regression test for the jp_json_response() argument-order bug.
 *
 * ROOT CAUSE (see enterprise-gap-analysis.md and the 6.11.1 hotfix):
 * jp_json_response() was declared as
 *     function jp_json_response( $data, bool $success = true, int $status = 200 )
 * but 33+ call sites across the codebase invoke it as
 *     jp_json_response( $success_bool, $data, $status )
 * — the opposite order. Because the 2nd parameter was strictly typed `bool`,
 * PHP fatals with an uncaught TypeError whenever $data is an array, which is
 * the overwhelming majority of real calls. This is a request-killing bug on
 * production, not a cosmetic one.
 *
 * The fix makes jp_json_response() accept either argument order by
 * detecting which of the first two arguments is the boolean, so every
 * existing call site — regardless of which convention it uses — now works
 * without touching the 150+ call sites.
 *
 * This test locks in that behavior for all four calling conventions
 * observed in the codebase, so this class of bug can never silently
 * reappear.
 */

use PHPUnit\Framework\TestCase;

final class JsonResponseTest extends TestCase {

	/** @return array{0: array, 1: ?int} [captured response, captured status] */
	private function capture( callable $call ): array {
		try {
			$call();
			$this->fail( 'wp_send_json() was not invoked — jp_json_response() returned normally instead of calling it.' );
		} catch ( JP_Test_JsonResponseCapture $e ) {
			return [ $e->response, $e->status_code ];
		}
	}

	public function test_legacy_convention_success_bool_then_array_data(): void {
		// jp_json_response( true, ['id' => 5] ) — the convention used by the
		// majority of call sites in this codebase.
		[ $response, $status ] = $this->capture( fn() => jp_json_response( true, [ 'id' => 5 ] ) );

		$this->assertTrue( $response['success'] );
		$this->assertSame( [ 'id' => 5 ], $response['data'] );
		$this->assertSame( 200, $status );
	}

	public function test_legacy_convention_failure_bool_then_array_data(): void {
		[ $response, $status ] = $this->capture( fn() => jp_json_response( false, [ 'error' => 'not found' ], 404 ) );

		$this->assertFalse( $response['success'] );
		$this->assertSame( [ 'error' => 'not found' ], $response['data'] );
		$this->assertSame( 404, $status );
	}

	public function test_original_convention_data_then_success_bool(): void {
		// jp_json_response( ['id' => 5], true ) — the order the function's
		// own original signature declared, still must keep working.
		[ $response, $status ] = $this->capture( fn() => jp_json_response( [ 'id' => 5 ], true ) );

		$this->assertTrue( $response['success'] );
		$this->assertSame( [ 'id' => 5 ], $response['data'] );
	}

	public function test_data_only_defaults_to_success_true(): void {
		// jp_json_response( ['id' => 5] ) — no explicit success flag at all.
		[ $response, $status ] = $this->capture( fn() => jp_json_response( [ 'id' => 5 ] ) );

		$this->assertTrue( $response['success'] );
		$this->assertSame( [ 'id' => 5 ], $response['data'] );
		$this->assertSame( 200, $status );
	}

	public function test_data_then_integer_status_no_bool_at_all(): void {
		// jp_json_response( ['error' => 'x'], 500 ) — data + status, no bool.
		[ $response, $status ] = $this->capture( fn() => jp_json_response( [ 'error' => 'x' ], 500 ) );

		$this->assertTrue( $response['success'] );
		$this->assertSame( [ 'error' => 'x' ], $response['data'] );
		$this->assertSame( 500, $status );
	}

	public function test_scalar_data_does_not_crash(): void {
		// Guard against a regression that only handles array $data.
		[ $response, $status ] = $this->capture( fn() => jp_json_response( true, 'a message' ) );

		$this->assertTrue( $response['success'] );
		$this->assertSame( 'a message', $response['data'] );
	}
}
