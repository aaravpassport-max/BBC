#!/usr/bin/env bash
# Builds the SPA and creates jp-core.zip with full source (no node_modules).
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$ROOT/../jp-core.zip}"

echo "==> Building React app..."
cd "$ROOT/app"
if [[ ! -d node_modules ]]; then
  npm ci
fi
npm run build

echo "==> Packing full source to $OUT"
cd "$ROOT"
rm -f "$OUT"
zip -r "$OUT" . \
  -x 'app/node_modules/*' \
  -x 'app/node_modules/**' \
  -x '**/.DS_Store' \
  -x '**/*~'

echo "==> Done. Size: $(du -h "$OUT" | cut -f1)"
unzip -l "$OUT" | tail -1
