# JP Job Portal — Architecture: Two Front-Ends

Read this before touching any template, CSS, or page-routing code. This
plugin+theme ships **two separate, independently-styled front-ends** that
share one WordPress install. Not knowing this is the single most common
cause of "the CSS is broken" reports on this project — several real
incidents have come from exactly this confusion, most recently a bug
where a URL-prefix check meant for one front-end silently stripped the
other front-end's CSS from its own pages (see "Known trap" below).

## The two front-ends

### 1. The classic theme (jp-theme-fixed)
- Plain PHP templates + one hand-written stylesheet: `assets/css/main.css`.
- Design system: CSS custom properties (`--jp-*`), classes prefixed `jp-`
  (`.jp-card`, `.jp-btn--primary`, `.jp-badge--*`, etc.)
- Real, live pages rendered by this system today:
  - `front-page.php` — the homepage
  - `single-jp_job.php` — one job listing (URL: `/jobs/{job-slug}/`)
  - `single-jp_company.php` — one company profile (URL: `/companies/{company-slug}/`)
  - `404.php`
  - Any WordPress Page whose template is blank/default (About, Privacy
    Policy, Terms — see `JP_Activator::create_pages()`)
- The `page-templates/tpl-*.php` files NOT listed above (tpl-dashboard.php,
  tpl-recruiter-dash.php, tpl-admin-dash.php, tpl-staff-dash.php,
  tpl-team-dash.php, tpl-job-search.php, tpl-companies.php, etc.) exist in
  the theme but are **not assigned to any page by default** — every
  matching WordPress Page is instead assigned to the React app template
  (see below). Treat them as an alternate/legacy implementation, not the
  live one, unless you have personally re-pointed a Page's template to one
  of them in wp-admin. If you don't intend to use them, the safest long-term
  fix is to delete them so nobody edits a file that isn't actually live.

### 2. The React app (jp-core/react-app/)
- A separate, pre-built single-page app (Vite build: `jp-app.css` +
  many `*.js` chunks). Its own design system: Tailwind utility classes
  (`bg-primary`, `px-4`, `grid-cols-3`, etc.) — **not compatible with, and
  not aware of, the theme's `jp-` classes.**
- Rendered via one shared template: `templates/page-templates/tpl-react-app.php`
  (a full, self-contained HTML document — it does NOT use the theme's
  `header.php`/`footer.php` at all).
- Real, live pages rendered by this system today (see
  `JP_Activator::create_pages()` — every one of these Pages has
  `_wp_page_template = page-templates/tpl-react-app.php`):
  `/jobs/`, `/companies/`, `/candidates/`, `/salary/`, `/campus/`,
  `/pricing/`, `/login/`, `/register/`, `/my-account/`, `/recruiter/`,
  `/admin-panel/`, `/contact/`, `/help/`.
- Plus every client-side React Router path underneath those — e.g.
  `/recruiter/candidates`, `/admin/users`, `/jobs/123` — which have no
  WordPress rewrite rule of their own and are served by intentionally
  letting them 404 and then rewriting to the React app
  (`JP_React::handle_spa_routing()`).
- **The React app's source code is not in this repository.** Only the
  built output (`react-app/assets/*.css`, `*.js`) ships here. To change
  anything about how a React-rendered screen looks or behaves, you need
  the separate React app source project and must rebuild + re-export
  `react-app/` from it — editing the compiled files directly will not
  survive the next real build, and editing `jp-theme`'s `main.css` will
  have **no effect at all** on any React-rendered page.

## How to tell, for any given URL, which one renders it

1. Is it `/jobs/{something}/` or `/companies/{something}/` with a real,
   published `jp_job`/`jp_company` post at that slug? → **Theme**
   (`single-jp_job.php` / `single-jp_company.php`).
2. Otherwise, check the WordPress Page's assigned template
   (Pages → [page] → Page Attributes → Template, or
   `get_post_meta($id, '_wp_page_template', true)`):
   - `page-templates/tpl-react-app.php` → **React app**.
   - Anything else / blank → **Theme**.
3. A URL with no matching Page or Post at all (a 404) that starts with one
   of the prefixes in `JP_React::get_spa_prefixes()` → **React app**
   (client-side route).

`JP_React::get_spa_prefixes()` is the single source of truth for which URL
prefixes belong to the React app's client-side router. **Keep it in sync
with the React app's own route list** (`App.tsx` or equivalent in the
React source project) every time a route is added or removed there.

## Known trap (already fixed once — don't reintroduce it)

`get_spa_prefixes()` includes `/jobs/` and `/companies/` so that a
client-side route like `/jobs/123` (no real WP object) is correctly
recognized as belonging to the React app. But `JP_CPT::sync_post()`
gives every real job/company its OWN post at `/jobs/{slug}/` and
`/companies/{slug}/` — URLs that start with the exact same prefixes.

Any code that decides "is this a React page?" purely by matching the URL
against `get_spa_prefixes()` (`JP_React::dequeue_theme_assets()` and
`JP_React::strip_theme_head_actions()` both do this as a fallback) will
wrongly classify a real job/company single page as a React page too —
and then strip the theme's own CSS/JS from it, since only the React app's
assets are kept on a "React page". The fix in both those methods is a
guard at the top: if `$post` is already a real `jp_job` or `jp_company`
post, return immediately and never reach the prefix check.

**Rule for any future change to this URL-classification logic:** a
same-prefix collision between "a React client-side route" and "a real
WordPress post/page that happens to live under that path" must always be
resolved in favor of the real post/page. Whenever you add a new prefix to
`get_spa_prefixes()`, grep the theme for any `single-*.php`/CPT whose
permalink could start with that same prefix, and add the same kind of
post-type guard if one exists.

## Checklist before shipping any "CSS is broken" fix

1. Identify the exact failing URL.
2. Work out which front-end (theme or React) is supposed to render it,
   using the rules above — don't assume based on how the URL looks.
3. If theme: check `assets/css/main.css` for the classes actually used in
   that URL's template file.
4. If React: check whether `JP_React`'s dequeue/strip logic is correctly
   leaving `jp-app.css` in place for it and NOT wrongly stripping/keeping
   the wrong stylesheet — this is a routing/classification bug category,
   not a "missing CSS rule" category, and editing `main.css` will not fix
   it. If the classification logic looks correct and the page still looks
   wrong, the bug is inside the React app's own build (`react-app/assets/`)
   and needs the React source project, not this repository.
5. Never declare a CSS fix complete without stating, in the fix's own
   commit/comment, which front-end you traced it to and why.
