Job Portal WordPress plugin (jp-core) — FULL SOURCE PACKAGE
=========================================================

This archive contains complete plugin source code plus a production build
of the React SPA so the plugin works immediately after upload to WordPress.

WHAT IS INCLUDED
----------------
  jp-core.php              Plugin bootstrap
  includes/                PHP (REST API, CPTs, payments, etc.)
  templates/               Page templates
  assets/                  Static plugin assets
  tests/                   PHPUnit tests
  composer.json            PHP dev dependencies (optional)
  ARCHITECTURE.md          Two-front-end architecture notes

  app/                     React + TypeScript SPA (FULL SOURCE)
    src/                   All pages, components, styles
    package.json           npm dependencies manifest
    vite.config.ts         Vite build config
    tsconfig*.json         TypeScript config

  app-dist/                Built SPA output (what WordPress enqueues)
  react-app/               Legacy SPA rollback copy (not used in normal operation)

WHAT IS EXCLUDED (by design)
----------------------------
  app/node_modules/        Install locally with:  cd app && npm ci

REBUILD THE FRONTEND AFTER EDITING app/src
------------------------------------------
  cd app
  npm ci
  npm run build

Output is written to app-dist/ (see vite.config.ts).

REPACK THIS ZIP (from the jp-core folder)
-----------------------------------------
  ./scripts/pack-full-source.sh
