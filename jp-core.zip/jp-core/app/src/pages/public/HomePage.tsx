import { useState, type FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { useQuery } from '@tanstack/react-query'
import { listJobs, type JobRow } from '@/features/jobs/api'
import { getMarketInsights } from '@/features/market/api'
import { Button } from '@/components/ui/Button'
import { Input } from '@/components/ui/Input'
import { Badge } from '@/components/ui/Badge'
import { StatCard } from '@/components/ui/StatCard'
import { SectionCard } from '@/components/ui/SectionCard'
import { Skeleton } from '@/components/ui/Skeleton'
import './HomePage.css'

function formatSalary(min: number, max: number, currency: string): string | null {
  if (!min && !max) return null
  const fmt = (n: number) => `${currency === 'INR' ? '₹' : currency + ' '}${(n / 1000).toFixed(0)}k`
  if (min && max) return `${fmt(min)} – ${fmt(max)}`
  return fmt(min || max)
}

/** job_type is stored hyphenated ('full-time', 'part-time', ...) — this is
 *  the same label mapping JobsPage's own filter <select> uses (see
 *  JobsPage.tsx's job-type options), just applied generically instead of
 *  as a hardcoded option list, since the set of values here is driven by
 *  whatever the backend GROUP BY actually returns. */
function formatJobType(jobType: string): string {
  return jobType
    .split('-')
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join('-')
}

function HomeJobCard({ job }: { job: JobRow }) {
  const salary = job.salary_visible ? formatSalary(job.salary_min, job.salary_max, job.salary_currency) : null
  return (
    <Link to={`/jobs/${job.id}`} className="jp-home__job-card">
      <p className="jp-job-title" style={{ fontSize: 14 }}>
        {job.title}
      </p>
      <p className="jp-job-company">
        {job.company_name} · {job.location_city || 'Remote'}
      </p>
      <div className="jp-job-badges">
        <Badge variant="gray">{job.job_type}</Badge>
        <Badge variant="gray">{job.work_mode}</Badge>
        {salary && <Badge variant="success">{salary}</Badge>}
      </div>
    </Link>
  )
}

/**
 * Batch 32 (phase 6, public site) — root-cause fix. This page was a bare
 * hero + search box with nothing else: no proof of platform activity, no
 * way to browse without typing a query first, no path into the employer
 * side. Two already-built, already-used-elsewhere endpoints (getMarketInsights()
 * — used by MarketInsightsPage — and listJobs() — used by JobsPage) supply
 * everything below with real numbers; nothing here is fabricated content.
 */
export function HomePage() {
  const navigate = useNavigate()
  const [q, setQ] = useState('')
  const [location, setLocation] = useState('')

  const { data: insights } = useQuery({ queryKey: ['market-insights'], queryFn: getMarketInsights })
  const { data: latestJobs, isLoading: jobsLoading, isError: jobsError } = useQuery({
    queryKey: ['home-latest-jobs'],
    queryFn: () => listJobs({ order_by: 'created_at', order: 'DESC', per_page: 6 }),
  })

  function onSearch(e: FormEvent) {
    e.preventDefault()
    const params = new URLSearchParams()
    if (q.trim()) params.set('q', q.trim())
    if (location.trim()) params.set('location', location.trim())
    navigate(`/jobs${params.toString() ? `?${params.toString()}` : ''}`)
  }

  return (
    <div className="jp-home">
      <section className="jp-home__hero">
        <h1>Find your next role</h1>
        <p>Search thousands of jobs from verified companies.</p>
        <form className="jp-home__search" onSubmit={onSearch}>
          <Input
            aria-label="Job title or keyword"
            placeholder="Job title or keyword"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <Input
            aria-label="Location"
            placeholder="City or remote"
            value={location}
            onChange={(e) => setLocation(e.target.value)}
          />
          <Button type="submit" variant="accent">
            Search jobs
          </Button>
        </form>

        {insights && (
          <div className="jp-home__stats">
            <StatCard label="Active jobs" value={insights.stats.active_jobs} tone="primary" />
            <StatCard label="Companies hiring" value={insights.stats.companies_hiring} />
            <StatCard label="New today" value={insights.stats.new_jobs_today} tone="success" />
            <StatCard label="Remote jobs" value={insights.stats.remote_jobs} />
          </div>
        )}
      </section>

      <div className="jp-home__body">
        <SectionCard title="Latest opportunities" action={<Link to="/jobs" className="jp-home__see-all">See all jobs →</Link>}>
          {jobsLoading && (
            <div className="jp-home__job-grid">
              {Array.from({ length: 6 }).map((_, i) => (
                <Skeleton key={i} height={90} width="100%" />
              ))}
            </div>
          )}
          {!jobsLoading && latestJobs && latestJobs.jobs.length > 0 && (
            <div className="jp-home__job-grid">
              {latestJobs.jobs.map((job) => (
                <HomeJobCard key={job.id} job={job} />
              ))}
            </div>
          )}
          {!jobsLoading && latestJobs && latestJobs.jobs.length === 0 && (
            <p className="jp-job-company">No jobs posted yet — check back soon.</p>
          )}
          {!jobsLoading && jobsError && (
            <p className="jp-jobs-error" role="alert">Could not load the latest jobs right now.</p>
          )}
        </SectionCard>

        {insights && insights.trending_skills.length > 0 && (
          <SectionCard title="Trending skills">
            <div className="jp-home__skill-chips">
              {insights.trending_skills.slice(0, 12).map((skill) => (
                <Link key={skill.name} to={`/jobs?skills=${encodeURIComponent(skill.name)}`} className="jp-home__skill-chip">
                  {skill.name}
                </Link>
              ))}
            </div>
          </SectionCard>
        )}

        {insights && insights.top_hiring.length > 0 && (
          <SectionCard title="Top companies hiring now">
            <div className="jp-home__company-grid">
              {insights.top_hiring.slice(0, 8).map((company) => (
                <Link
                  key={company.name}
                  to={`/jobs?q=${encodeURIComponent(company.name)}`}
                  className="jp-home__company-tile"
                >
                  {company.logo_url ? (
                    <img src={company.logo_url} alt={company.name} className="jp-home__company-logo" />
                  ) : (
                    <div className="jp-home__company-logo jp-home__company-logo--placeholder">{company.name[0]}</div>
                  )}
                  <span className="jp-home__company-name">{company.name}</span>
                  <span className="jp-home__company-jobs">{company.jobs} open roles</span>
                </Link>
              ))}
            </div>
          </SectionCard>
        )}

        {insights && insights.job_type_breakdown.length > 0 && (
          <SectionCard title="Browse jobs by type">
            <div className="jp-home__category-grid">
              {insights.job_type_breakdown.map((row) => (
                <Link
                  key={row.job_type}
                  to={`/jobs?job_type=${encodeURIComponent(row.job_type)}`}
                  className="jp-home__category-tile"
                >
                  <span className="jp-home__category-name">{formatJobType(row.job_type)}</span>
                  <span className="jp-home__category-count">{row.jobs} open roles</span>
                </Link>
              ))}
            </div>
          </SectionCard>
        )}

        {insights && insights.top_locations.length > 0 && (
          <SectionCard title="Explore jobs by city">
            <div className="jp-home__skill-chips">
              {insights.top_locations.map((row) => (
                <Link
                  key={row.location_city}
                  to={`/jobs?location=${encodeURIComponent(row.location_city)}`}
                  className="jp-home__skill-chip"
                >
                  {row.location_city} <span className="jp-home__chip-count">({row.jobs})</span>
                </Link>
              ))}
            </div>
          </SectionCard>
        )}

        <section className="jp-home__how">
          <h2 className="jp-home__how-title">How it works</h2>
          <div className="jp-home__how-grid">
            <div className="jp-home__how-step">
              <span className="jp-home__how-number">1</span>
              <h3>Search & discover</h3>
              <p>Filter by role, location, skills, and salary to find roles that actually match what you want.</p>
            </div>
            <div className="jp-home__how-step">
              <span className="jp-home__how-number">2</span>
              <h3>Apply in one click</h3>
              <p>Use your saved profile and resume to apply instantly, and track every application in one dashboard.</p>
            </div>
            <div className="jp-home__how-step">
              <span className="jp-home__how-number">3</span>
              <h3>Get hired</h3>
              <p>Message recruiters, schedule interviews, and manage offers — all without leaving the platform.</p>
            </div>
          </div>
        </section>

        <section className="jp-home__cta">
          <div className="jp-home__cta-card">
            <h3>Looking for your next hire?</h3>
            <p>Post a job, build a candidate pipeline, and manage interviews from one recruiter workspace.</p>
            <Link to="/pricing">
              <Button variant="outline">View employer plans</Button>
            </Link>
          </div>
        </section>
      </div>
    </div>
  )
}
