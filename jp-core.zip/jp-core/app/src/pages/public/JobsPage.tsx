import { useMemo, useState, type FormEvent } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { useMutation, useQuery } from '@tanstack/react-query'
import { listJobs, type JobListParams } from '@/features/jobs/api'
import { createAlert } from '@/features/alerts/api'
import { trackEvent } from '@/features/analytics/api'
import { useAuth } from '@/lib/auth/AuthContext'
import { Card, CardBody } from '@/components/ui/Card'
import { CardSkeleton } from '@/components/ui/Skeleton'
import { Badge } from '@/components/ui/Badge'
import { Input } from '@/components/ui/Input'
import { Button } from '@/components/ui/Button'
import { useToast } from '@/components/ui/ToastProvider'
import { PageHeader } from '@/components/ui/PageHeader'
import { EmptyState } from '@/components/ui/EmptyState'
import { ApiError } from '@/lib/apiClient'
import './JobsPage.css'

const PER_PAGE = 20

function formatSalary(min: number, max: number, currency: string): string | null {
  if (!min && !max) return null
  const fmt = (n: number) => n.toLocaleString()
  if (min && max) return `${currency} ${fmt(min)} – ${fmt(max)}`
  return `${currency} ${fmt(min || max)}`
}

export function JobsPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const page = Number(searchParams.get('page') ?? '1')
  const { isAuthenticated, role } = useAuth()
  const toast = useToast()
  const [saveSearchOpen, setSaveSearchOpen] = useState(false)
  const [saveSearchName, setSaveSearchName] = useState('')

  // Root-cause fix (saved-searches feature): JP_Search::search_mysql() and
  // the /jobs REST route (see features/jobs/api.ts's JobListParams, a
  // transcription of the real backend contract) have always supported
  // job_type/work_mode/exp/sal_min/sal_max/order_by — this page only ever
  // exposed keyword+location, so every other working filter was reachable
  // by hand-editing the URL but not from any control in the UI.
  const params: JobListParams = useMemo(
    () => ({
      q: searchParams.get('q') ?? undefined,
      location: searchParams.get('location') ?? undefined,
      job_type: (searchParams.get('job_type') as JobListParams['job_type']) ?? undefined,
      work_mode: (searchParams.get('work_mode') as JobListParams['work_mode']) ?? undefined,
      exp: searchParams.get('exp') ? Number(searchParams.get('exp')) : undefined,
      sal_min: searchParams.get('sal_min') ? Number(searchParams.get('sal_min')) : undefined,
      skills: searchParams.get('skills') ?? undefined,
      order_by: (searchParams.get('order_by') as JobListParams['order_by']) ?? undefined,
      page,
      per_page: PER_PAGE,
    }),
    [searchParams, page],
  )

  const { data, isLoading, isError, error } = useQuery({
    queryKey: ['jobs', params],
    queryFn: () => listJobs(params),
    placeholderData: (prev) => prev,
  })

  function updateField(key: string, value: string) {
    const next = new URLSearchParams(searchParams)
    if (value) next.set(key, value)
    else next.delete(key)
    next.delete('page')
    setSearchParams(next)
  }

  function goToPage(nextPage: number) {
    const next = new URLSearchParams(searchParams)
    next.set('page', String(nextPage))
    setSearchParams(next)
  }

  const hasActiveFilters = ['q', 'location', 'job_type', 'work_mode', 'exp', 'sal_min', 'skills'].some((k) =>
    searchParams.get(k),
  )

  // Saved searches reuse the existing job-alerts infrastructure (jp_alerts —
  // see AlertsPage.tsx / class-jp-alerts.php, root-caused and fixed in batch
  // 15) rather than a second, parallel "saved search" table: an alert IS a
  // saved search with an optional notification schedule attached, and the
  // alerts backend already persists name/keywords/location/job_type/
  // work_mode/salary_min/experience (experience wired up in batch 22 — see
  // class-jp-alerts.php's ajax_save()). Defaults to a paused/quiet cadence
  // ('weekly') so
  // saving a search from this page doesn't silently opt the candidate into
  // instant emails they never asked for; they can switch it to instant/daily
  // on the Alerts page if they want notifications, or just revisit it there
  // to re-run the same search.
  const saveSearchMutation = useMutation({
    mutationFn: () =>
      createAlert({
        name: saveSearchName.trim(),
        keywords: searchParams.get('q') ?? undefined,
        location: searchParams.get('location') ?? undefined,
        job_type: searchParams.get('job_type') ?? undefined,
        work_mode: searchParams.get('work_mode') ?? undefined,
        salary_min: searchParams.get('sal_min') ? Number(searchParams.get('sal_min')) : undefined,
        experience: searchParams.get('exp') ? Number(searchParams.get('exp')) : undefined,
        skills: searchParams.get('skills') ?? undefined,
        frequency: 'weekly',
      }),
    onSuccess: () => {
      toast.success('Search saved. Find it under Job Alerts — switch it to instant or daily there if you want email notifications.')
      setSaveSearchOpen(false)
      setSaveSearchName('')
    },
    onError: (e) => toast.error(e instanceof ApiError ? e.message : 'Could not save this search. Please try again.'),
  })

  function onSaveSearchSubmit(e: FormEvent) {
    e.preventDefault()
    if (!saveSearchName.trim()) {
      toast.error('Give this search a name.')
      return
    }
    saveSearchMutation.mutate()
  }

  return (
    <div className="jp-jobs-page">
      <aside className="jp-jobs-filters">
        <Input
          label="Keyword"
          value={searchParams.get('q') ?? ''}
          onChange={(e) => updateField('q', e.target.value)}
        />
        <Input
          label="Location"
          value={searchParams.get('location') ?? ''}
          onChange={(e) => updateField('location', e.target.value)}
        />
        <div className="jp-form-group">
          <label className="jp-label" htmlFor="jobs-filter-job-type">
            Job type
          </label>
          <select
            id="jobs-filter-job-type"
            className="jp-input"
            value={searchParams.get('job_type') ?? ''}
            onChange={(e) => updateField('job_type', e.target.value)}
          >
            <option value="">Any</option>
            <option value="full-time">Full-time</option>
            <option value="part-time">Part-time</option>
            <option value="contract">Contract</option>
            <option value="internship">Internship</option>
            <option value="freelance">Freelance</option>
          </select>
        </div>
        <div className="jp-form-group">
          <label className="jp-label" htmlFor="jobs-filter-work-mode">
            Work mode
          </label>
          <select
            id="jobs-filter-work-mode"
            className="jp-input"
            value={searchParams.get('work_mode') ?? ''}
            onChange={(e) => updateField('work_mode', e.target.value)}
          >
            <option value="">Any</option>
            <option value="onsite">On-site</option>
            <option value="remote">Remote</option>
            <option value="hybrid">Hybrid</option>
          </select>
        </div>
        <Input
          label="Min. experience (years)"
          type="number"
          min={0}
          value={searchParams.get('exp') ?? ''}
          onChange={(e) => updateField('exp', e.target.value)}
        />
        <Input
          label="Min. salary"
          type="number"
          min={0}
          value={searchParams.get('sal_min') ?? ''}
          onChange={(e) => updateField('sal_min', e.target.value)}
        />
        <Input
          label="Skills (comma-separated)"
          placeholder="e.g. React, Node.js"
          value={searchParams.get('skills') ?? ''}
          onChange={(e) => updateField('skills', e.target.value)}
          hint="A job must have ALL of these skills to match."
        />
        <div className="jp-form-group">
          <label className="jp-label" htmlFor="jobs-filter-order">
            Sort by
          </label>
          <select
            id="jobs-filter-order"
            className="jp-input"
            value={searchParams.get('order_by') ?? ''}
            onChange={(e) => updateField('order_by', e.target.value)}
          >
            <option value="">Relevance (default)</option>
            <option value="created_at">Newest</option>
            <option value="salary_max">Highest salary</option>
            <option value="views_count">Most viewed</option>
            <option value="applications_cnt">Most applied</option>
          </select>
        </div>

        {isAuthenticated && role === 'jp_job_seeker' && hasActiveFilters && (
          <div className="jp-jobs-save-search">
            {!saveSearchOpen ? (
              <Button variant="outline" size="sm" onClick={() => setSaveSearchOpen(true)}>
                Save this search
              </Button>
            ) : (
              <form onSubmit={onSaveSearchSubmit} className="jp-jobs-save-search-form">
                <Input
                  label="Name this search"
                  value={saveSearchName}
                  onChange={(e) => setSaveSearchName(e.target.value)}
                  autoFocus
                />
                <div className="jp-jobs-save-search-actions">
                  <Button type="submit" variant="accent" size="sm" loading={saveSearchMutation.isPending}>
                    Save
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setSaveSearchOpen(false)
                      setSaveSearchName('')
                    }}
                  >
                    Cancel
                  </Button>
                </div>
              </form>
            )}
          </div>
        )}
      </aside>

      <div className="jp-jobs-results">
        <PageHeader
          title={data ? `${data.total.toLocaleString()} jobs found` : 'Jobs'}
          subtitle={hasActiveFilters ? 'Filtered results — adjust filters on the left to broaden or narrow your search.' : undefined}
        />

        {isLoading && (
          <div className="jp-jobs-list">
            {Array.from({ length: 6 }).map((_, i) => (
              <CardSkeleton key={i} />
            ))}
          </div>
        )}

        {isError && (
          <p className="jp-jobs-error" role="alert">
            {error instanceof Error ? error.message : 'Could not load jobs. Please try again.'}
          </p>
        )}

        {!isLoading && !isError && data && data.jobs.length === 0 && (
          <EmptyState
            title="No jobs match your search"
            description="Try broadening your filters, removing a skill requirement, or searching a wider location."
          />
        )}

        {!isLoading && data && data.jobs.length > 0 && (
          <>
            <div className="jp-jobs-list">
              {data.jobs.map((job) => {
                const salary = formatSalary(job.salary_min, job.salary_max, job.salary_currency)
                const hasExperience = job.experience_min > 0 || job.experience_max > 0
                return (
                  <Link
                    key={job.id}
                    to={`/jobs/${job.id}`}
                    className="jp-jobs-link"
                    onClick={() => trackEvent('job_click', job.id)}
                  >
                    <Card clickable>
                      <CardBody>
                        <div className="jp-job-row">
                          <div>
                            <h2 className="jp-job-title">{job.title}</h2>
                            <p className="jp-job-company">
                              {job.company_name}
                              {job.company_verified === 1 && <span title="Verified company"> ✓</span>} ·{' '}
                              {job.location_city || job.location_state || 'Location not specified'}
                            </p>
                            {hasExperience && (
                              <p className="jp-job-exp">
                                {job.experience_min > 0 && job.experience_max > 0
                                  ? `${job.experience_min}–${job.experience_max} yrs experience`
                                  : `${job.experience_min || job.experience_max}+ yrs experience`}
                              </p>
                            )}
                            {salary && job.salary_visible === 1 && <p className="jp-job-salary">{salary}</p>}
                          </div>
                          <div className="jp-job-badges">
                            {job.is_featured === 1 && <Badge variant="accent">Featured</Badge>}
                            {job.is_urgent === 1 && <Badge variant="error">Urgently hiring</Badge>}
                            {job.work_mode === 'remote' && <Badge variant="info">Remote</Badge>}
                            <Badge variant="gray">{job.job_type}</Badge>
                          </div>
                        </div>
                      </CardBody>
                    </Card>
                  </Link>
                )
              })}
            </div>

            {data.pages > 1 && (
              <div className="jp-jobs-pagination">
                <Button variant="outline" size="sm" disabled={page === 1} onClick={() => goToPage(page - 1)}>
                  Previous
                </Button>
                <span>
                  Page {page} of {data.pages}
                </span>
                <Button variant="outline" size="sm" disabled={page >= data.pages} onClick={() => goToPage(page + 1)}>
                  Next
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  )
}
