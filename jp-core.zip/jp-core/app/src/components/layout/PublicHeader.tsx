import { Link, useNavigate } from 'react-router-dom'
import { useAuth } from '@/lib/auth/AuthContext'
import { ROLE_LANDING_ROUTE } from '@/lib/auth/types'
import { Button } from '@/components/ui/Button'
import './PublicHeader.css'

/**
 * Site-wide header. Behaviorally ports jp-theme-fixed/header.php (unread
 * notification badge, user menu, mobile nav) — the LIVE theme file, not
 * one of the 16 dead ones — but as a real, typed React component instead
 * of PHP + jQuery-ish DOM manipulation.
 */
export function PublicHeader() {
  const { isAuthenticated, role, config, logout } = useAuth()
  const navigate = useNavigate()

  // Root-cause fix: login previously never created a real session (see
  // AuthContext.tsx), so a sign-out control had no purpose and none was
  // ever built — confirmed by grepping the whole app for "logout"/"sign
  // out" and finding nothing. Now that logging in actually authenticates
  // the browser, leaving no way to end that session isn't a cosmetic gap,
  // it's a real capability the app is missing.
  async function handleLogout() {
    await logout()
    navigate('/')
  }

  return (
    <header className="jp-header">
      <div className="jp-header__inner">
        <Link to="/" className="jp-header__logo" aria-label={`${config?.site_name ?? 'JP Job Portal'} home`}>
          <svg width="28" height="28" viewBox="0 0 28 28" fill="none" aria-hidden="true">
            <rect width="28" height="28" rx="7" fill="var(--jp-primary)" />
            <path
              d="M9 12h10v7a1 1 0 0 1-1 1H10a1 1 0 0 1-1-1v-7Z"
              stroke="#fff"
              strokeWidth="1.6"
            />
            <path d="M11 12V9.5A1.5 1.5 0 0 1 12.5 8h3A1.5 1.5 0 0 1 17 9.5V12" stroke="#fff" strokeWidth="1.6" />
          </svg>
          <span>{config?.site_name ?? 'JP Job Portal'}</span>
        </Link>

        <nav className="jp-header__nav">
          <Link to="/jobs">Find Jobs</Link>
          <Link to="/companies">Companies</Link>
          <Link to="/pricing">For Employers</Link>
          <Link to="/salary">Salary Explorer</Link>
          <Link to="/community">Community</Link>
          <Link to="/events">Events</Link>
          <Link to="/help">Help</Link>
        </nav>

        <div className="jp-header__actions">
          {isAuthenticated ? (
            <>
              <Link to={ROLE_LANDING_ROUTE[role]}>
                <Button variant="outline" size="sm">
                  My Dashboard
                </Button>
              </Link>
              <Button variant="ghost" size="sm" onClick={() => void handleLogout()}>
                Log out
              </Button>
            </>
          ) : (
            <>
              <Link to="/login">
                <Button variant="ghost" size="sm">
                  Log in
                </Button>
              </Link>
              <Link to="/register">
                <Button variant="primary" size="sm">
                  Sign up
                </Button>
              </Link>
            </>
          )}
        </div>
      </div>
    </header>
  )
}
