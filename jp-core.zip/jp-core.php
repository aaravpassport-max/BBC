<?php
/**
 * Plugin Name:       JP Core
 * Plugin URI:        https://yourdomain.com
 * Description:       Zero-cost custom job portal engine — jobs, ATS, dashboards, matching, payments.
 * Version:           6.59.0
 * Author:            Your Name
 * Text Domain:       jp-core
 * Domain Path:       /languages
 * Requires at least: 6.4
 * Requires PHP:      8.1
 *
 * ─────────────────────────────────────────────────────────────────────────
 * READ ARCHITECTURE.md (in this plugin's root folder) BEFORE working on any
 * template, CSS, or page-routing code. Short version: this plugin ships TWO
 * separate front-ends — the classic jp-theme PHP templates (main.css) and a
 * separately-built React/Tailwind SPA (react-app/, jp-app.css) — and which
 * one renders a given URL is not always obvious from the URL alone. Most
 * "the CSS is broken" bugs on this project turned out to be someone editing
 * or debugging the wrong one of the two. See JP_React::get_spa_prefixes()
 * and its class-level docblock for exactly how a URL is classified.
 * ─────────────────────────────────────────────────────────────────────────
 */

defined( 'ABSPATH' ) || exit;

// ── Root-cause fix: ERR_TOO_MANY_REDIRECTS behind a reverse proxy / CDN ─────
// This plugin calls is_ssl() and home_url() (which itself depends on is_ssl()
// for scheme-relative logic in some configs) in many places that redirect —
// JP_Auth::gate_pages() and JP_Auth::redirect_wp_login() run on EVERY
// request via template_redirect/login_init and build their Location header
// from home_url(), and JP_Security::send_security_headers() sends a
// year-long Strict-Transport-Security header whenever is_ssl() is true.
// is_ssl() reads $_SERVER['HTTPS'], which is only ever set by the web
// server terminating the ACTUAL TLS connection. When the site is served
// through a reverse proxy or CDN (as its hostname — a *.cdn-...* domain —
// indicates here), the proxy terminates HTTPS with the visitor and then
// forwards the request to the origin server as plain HTTP, setting
// X-Forwarded-Proto: https to say so — but nothing was reading that header,
// so is_ssl() returns FALSE at the origin even for a visitor on https.
// Effect: WordPress's own canonical-URL logic (and every home_url()-based
// redirect in this plugin) decides the request needs to be sent to the
// https:// version of the URL and issues that redirect; the proxy/CDN
// receives it, terminates HTTPS again, forwards to origin as plain HTTP
// again, origin sees is_ssl() === false again, redirects to https:// again
// — forever. This is the single most common cause of a WordPress site
// behind a CDN showing ERR_TOO_MANY_REDIRECTS on many/all pages, and it
// also means the HSTS header above was being sent incorrectly (or withheld
// incorrectly) depending on which hop's scheme WordPress happened to see.
// Fix: trust the proxy's X-Forwarded-Proto header (WordPress's own
// documented pattern for this exact situation) BEFORE any plugin code ever
// calls is_ssl(), so every subsequent scheme check in WP core and in this
// plugin agrees with what the visitor's browser actually used.
if (
    ! empty( $_SERVER['HTTP_X_FORWARDED_PROTO'] )
    && strtolower( (string) $_SERVER['HTTP_X_FORWARDED_PROTO'] ) === 'https'
    && ( empty( $_SERVER['HTTPS'] ) || strtolower( (string) $_SERVER['HTTPS'] ) !== 'on' )
) {
    $_SERVER['HTTPS'] = 'on';
}

// ── Suppress PHP error display site-wide when WP_DEBUG_DISPLAY is on ────────
// Root-cause fix (found via the live diagnostic report: WP_DEBUG_DISPLAY=true
// on this production install, flagged as an active FAIL in Environment,
// Security, and Known Bug Regression Checks). A prior fix in this codebase
// already addressed the REST API half of this problem — see the
// 'rest_api_init' hook further down — but that hook, by definition, only
// ever fires for REST requests. It does NOT run for a normal page load,
// which is exactly what renders the React app's own host page
// (templates/page-templates/tpl-react-app.php). If ANY PHP notice,
// warning, or deprecation fires while that page is rendering (this
// codebase targets PHP 8.1, which is far stricter about deprecations than
// older PHP — e.g. passing null to a string-typed parameter, a very common
// source of new warnings on upgrade), WP_DEBUG_DISPLAY=true means that
// warning text gets printed literally inline into the HTML response,
// including potentially in the MIDDLE of the inline <script> block that
// sets window.JP_CONFIG (see enqueue_react_assets() in class-jp-react.php)
// — a single stray warning there is enough to break that script's syntax
// and silently prevent JP_CONFIG from ever being set, which is
// indistinguishable from "the admin isn't recognized as logged in" or
// "the page renders thin" to anyone looking at the resulting page, even
// though the underlying PHP logic computing that data was completely
// correct. The wp-config.php constant itself can't be changed from a
// plugin (PHP constants are immutable once defined, and wp-config.php is
// outside this plugin's own files) — but overriding the ini setting it
// drives can be, as long as it happens before any output is produced.
// This runs at the very top of this file, before ANY other code in this
// plugin executes on ANY request type, front-end or REST alike — the
// earliest point a normal (non-must-use) plugin can act.
if ( defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY ) {
    // phpcs:ignore WordPress.PHP.IniSet.display_errors_Disallowed
    @ini_set( 'display_errors', '0' );
}

// ── PHP 7.4 polyfills (safe to run on PHP 8.x too - they check first) ────────
if ( ! function_exists( 'str_contains' ) ) {
    function str_contains( string $haystack, string $needle ): bool {
        return $needle === '' || strpos( $haystack, $needle ) !== false;
    }
}
if ( ! function_exists( 'str_starts_with' ) ) {
    function str_starts_with( string $haystack, string $needle ): bool {
        return $needle === '' || substr( $haystack, 0, strlen( $needle ) ) === $needle;
    }
}
if ( ! function_exists( 'str_ends_with' ) ) {
    function str_ends_with( string $haystack, string $needle ): bool {
        return $needle === '' || substr( $haystack, -strlen( $needle ) ) === $needle;
    }
}


// ── Constants ────────────────────────────────────────────────────────────────
// Batch 30: multi-currency support, phase 1 — added a currency CHAR(3) column (default 'INR') to jp_plans (class-jp-activator.php's canonical CREATE TABLE — an existing table, so bumping JP_VERSION is what makes dbDelta's own column-diffing in run_upgrade() add it to already-installed sites; no new table, so the 3-list self-heal pattern from batches 25/26 doesn't apply here) so a plan can be priced in USD as well as the previous INR-only assumption; class-jp-payments.php's Stripe path now charges in the plan's real currency (Razorpay is deliberately kept INR-only — see its docblock — and a non-INR plan is refused rather than silently charged in the wrong currency if the site's payment gateway is set to Razorpay). Also fixed admin_save_plan()'s two previously-unchecked $wpdb writes while touching that exact method to add the field.
// Batch 36: interview-management depth pass — added candidate_confirmed/reschedule_requested/reschedule_reason columns to jp_interviews (class-jp-activator.php's canonical CREATE TABLE — an existing table, so bumping JP_VERSION is what makes dbDelta's own column-diffing in run_upgrade() add them to already-installed sites; no new table, so the 3-list self-heal pattern from batches 25/26 doesn't apply here). Also fixed a severe pre-existing bug found while touching this area: schedule_interview() and add_interview_panelist() both called the non-existent JP_Notifications::send() (only create()/send_email() exist), fataling every interview-scheduling and panelist-adding request after the row was already written — switched both to the real create() API.
// Batch 37: recruiter ATS pipeline depth pass — added `tags` (LONGTEXT, JSON-encoded string array) to jp_applications (class-jp-activator.php's canonical CREATE TABLE — an existing table, so bumping JP_VERSION triggers dbDelta's column-diffing in run_upgrade() to add it to already-installed sites; no new table involved). Backs a new recruiter-facing application detail view (cover letter, screening answers, notes, stage-history timeline, tags) built on the already-existing get_application()/ajax_add_note() endpoints, which previously had no SPA caller — the "backend exists, no SPA caller" pattern recurring again (see batches 10/13/16/20/21/23/29/32/35/36). "Assign to teammate" was deliberately scoped OUT of this pass: ownership in this codebase is single-owner-per-company (can_manage_application() in class-jp-applications.php checks jp_companies.user_id), and there is no jp_team_members table — building a real multi-seat assignment feature needs that table first (already flagged as a tracked gap in can_manage_application()'s own docblock), not a dropdown with no real backing data.
// Batch (vendor-integration pass): added jp_esign_envelopes and
// jp_job_feed_imports tables (class-jp-activator.php's canonical
// create_tables() dbDelta definition + drop_tables() uninstall list + the
// $expected_tables self-heal list — all three, per the batch-25/26 lesson
// documented below) so DocuSign e-signature envelope tracking and inbound
// job-feed import dedup have real persistent storage rather than existing
// only in code with nowhere to write. Bumped so dbDelta actually creates
// both new tables on already-installed sites — see class-jp-esign.php and
// class-jp-jobfeed.php's own docblocks for what each vendor integration
// does and why it fails soft when unconfigured.
// Enterprise redesign pass, Tier A batch 4 (AdminJobModerationPage) — added
// rejection_reason VARCHAR(500) to jp_jobs (class-jp-activator.php's
// canonical CREATE TABLE — an existing table, so bumping JP_VERSION is what
// makes dbDelta's own column-diffing in run_upgrade() add it to
// already-installed sites; no new table, so the 3-list self-heal pattern
// doesn't apply here). Also fixed admin_approve_job()'s previously-unchecked
// $wpdb->update() return value (the ghost-success pattern, found again while
// touching this exact method to add reason capture) and added a real
// bulk-approve/reject endpoint (admin_bulk_approve_jobs()).
// Enterprise redesign pass, Tier A batch 5 (MatchesPage) — added a new
// jp_match_dismissals table (class-jp-activator.php's canonical
// create_tables() dbDelta definition + drop_tables() uninstall list + the
// $expected_tables self-heal list — all three, per the batch-25/26 lesson)
// so a candidate's "not interested, stop recommending this" action on a
// match has somewhere real to persist. A dedicated table rather than a
// column on jp_matches, because backfill_candidate_matches() and
// score_candidate_batch_job() both $wpdb->replace() that row on every
// re-score run, which would silently wipe a column-based dismissal flag.
// JP_Matching::get_matches_for_candidate() now excludes dismissed job_ids
// from both its pre-computed (NOT EXISTS subquery) and real-time-fallback
// (in_array skip) paths, and the fallback path now also computes
// score_detail via score_breakdown() for parity with the pre-computed path
// (which has persisted it since batches introducing score_breakdown()) —
// both paths now carry the same shape for the new "why this match" UI.
define( 'JP_VERSION',     '6.60.0' );
// Batch 31: (1) centralized the 'jp/v1' REST namespace literal, previously duplicated across 7 register_rest_route() call sites in 6 files, behind a single JP_Api::namespace_str() accessor — no schema/rewrite change, included here only for the version-history record. (2) Outbound job feed for board syndication — new /jobs-feed.xml route (class-jp-seo.php's register_job_feed_rewrite()/serve_job_feed(), standard Indeed XML schema) publishing the site's own active job listings for Indeed/ZipRecruiter/Google-for-Jobs-style crawlers to pull; filters on the same status='active' definition the public /jobs page and sitemap already use. A brand-new rewrite rule needs a flush to take effect on already-installed sites, so this bump also sets jp_needs_rewrite_flush=1 once (see the version_compare gate right after this block) — see class-jp-seo.php's build_job_feed() docblock for salary-visibility and scope notes (outbound only; inbound ATS pull integration needs vendor credentials and stays out of scope).
// Batch 14: audit-log tamper-evidence — added prev_hash/hash columns to jp_audit_log (class-jp-activator.php, both the self-heal and canonical CREATE TABLE definitions) so JP_Security::audit() can hash-chain every row and JP_Security::verify_audit_chain() can detect tampering; bumped so dbDelta's column-diffing in run_upgrade() actually reaches already-installed sites — see class-jp-security.php's audit()/verify_audit_chain() docblocks. Also fixed audit()'s previously-unchecked $wpdb->insert() return value (4th instance of the ghost-success pattern found in batches 8/9/13).
// Batch 21: offer-letter workflow — added offer_pdf_url/offer_status/offer_responded_at columns to jp_applications (class-jp-activator.php's canonical create_tables() dbDelta definition) so a generated offer letter and the candidate's accept/decline response are actually persisted instead of existing only in a one-off, never-stored PDF response. Bumped again so dbDelta's column-diffing reaches already-installed sites — see class-jp-applications.php's generate_offer_pdf()/do_offer_response() and class-jp-api.php's submit_offer_response().
// Batch 25: canned responses (messaging upgrades backlog) — added a new jp_canned_responses table (class-jp-activator.php's canonical create_tables() dbDelta definition + drop_tables() uninstall list) so recruiters can save and reuse message templates instead of retyping the same reply to every candidate. Bumped so dbDelta actually creates the new table on already-installed sites — see class-jp-messaging.php's do_list_canned()/do_save_canned()/do_delete_canned() and class-jp-api.php's canned-responses routes.
// Batch 26: true multi-interviewer panel/scorecard collaboration — added a new jp_interview_panelists table (class-jp-activator.php's canonical create_tables(), drop_tables(), AND the $expected_tables self-heal list — all three, per the batch-25 lesson) so several named reviewers can each submit an independent scorecard on the same interview, on top of the single-reviewer outcome batch 20 already wired up on jp_interviews itself. See class-jp-api.php's add_interview_panelist()/get_interview_panelists()/submit_panelist_feedback()/remove_interview_panelist().
// CRITICAL fix — analytics pipeline was silently 100% broken: added a
// session_id VARCHAR(64) column to jp_analytics (class-jp-activator.php's
// canonical CREATE TABLE — an existing table, so bumping JP_VERSION is
// what makes dbDelta's own column-diffing in run_upgrade() add it to
// already-installed sites). JP_Analytics::track() — the only place that
// ever inserts into this table, i.e. every trackEvent() call the SPA
// makes for job_view/job_apply/company_view/profile_view/job_click — had
// always included a 'session_id' key in its $wpdb->insert() that no
// column ever backed. That insert has therefore failed on every single
// call since this code was written (verified programmatically by
// diffing the real CREATE TABLE column list against track()'s actual
// insert keys), and track() never checked the return value (a 5th
// instance of the ghost-success pattern, now also fixed), so the
// failure was completely silent. This table has been permanently empty
// the whole time — starving aggregate()'s hourly cron (→ jp_analytics_agg
// → platform_summary()/company_summary() → AdminAnalyticsPage and
// RecruiterAnalyticsPage's ROI/source-of-hire reports) and
// candidate_analytics()'s direct profile_views/search_appears COUNT
// queries of all real data. See class-jp-analytics.php's track() for the
// added failure logging.
define( 'JP_PLUGIN_FILE', __FILE__ );
define( 'JP_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'JP_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'JP_PLUGIN_BASE', plugin_basename( __FILE__ ) );

// ── Shared-hosting safe defaults (override in wp-config.php) ─────────────────
if ( ! defined( 'JP_RAZORPAY_KEY_ID' ) )      define( 'JP_RAZORPAY_KEY_ID',     '' );
if ( ! defined( 'JP_RAZORPAY_KEY_SECRET' ) )  define( 'JP_RAZORPAY_KEY_SECRET', '' );
// Batch 12 — Stripe gateway, same always-defined-empty-default pattern as
// the Razorpay constants above (so a bare `defined()` check never needs a
// separate "or not defined at all" branch anywhere else in the codebase).
if ( ! defined( 'JP_STRIPE_PUBLISHABLE_KEY' ) ) define( 'JP_STRIPE_PUBLISHABLE_KEY', '' );
if ( ! defined( 'JP_STRIPE_SECRET_KEY' ) )      define( 'JP_STRIPE_SECRET_KEY',      '' );
if ( ! defined( 'JP_STRIPE_WEBHOOK_SECRET' ) )  define( 'JP_STRIPE_WEBHOOK_SECRET',  '' );
if ( ! defined( 'JP_SMTP_HOST' ) )            define( 'JP_SMTP_HOST',           '' );
if ( ! defined( 'JP_SMTP_USER' ) )            define( 'JP_SMTP_USER',           '' );
if ( ! defined( 'JP_SMTP_PASS' ) )            define( 'JP_SMTP_PASS',           '' );
if ( ! defined( 'JP_SMTP_PORT' ) )            define( 'JP_SMTP_PORT',           587 );
if ( ! defined( 'JP_OPENAI_KEY' ) )           define( 'JP_OPENAI_KEY',          '' );
// On shared hosting Redis / Elasticsearch are usually unavailable — we fall back gracefully
if ( ! defined( 'JP_REDIS_HOST' ) )           define( 'JP_REDIS_HOST',          '' );
if ( ! defined( 'JP_ELASTICSEARCH_HOST' ) )   define( 'JP_ELASTICSEARCH_HOST',  '' );

// ── Autoloader ───────────────────────────────────────────────────────────────
spl_autoload_register( function ( string $class ): void {
    // Only handle JP_ classes
    if ( strpos( $class, 'JP_' ) !== 0 ) return;

    $filename = 'class-' . strtolower( str_replace( [ 'JP_', '_' ], [ 'jp-', '-' ], $class ) ) . '.php';
    $path     = JP_PLUGIN_DIR . 'includes/' . $filename;

    if ( file_exists( $path ) ) {
        require_once $path;
    }
} );

// ── Activation / Deactivation / Uninstall hooks ──────────────────────────────
register_activation_hook(   JP_PLUGIN_FILE, [ 'JP_Activator', 'activate'   ] );
register_deactivation_hook( JP_PLUGIN_FILE, [ 'JP_Activator', 'deactivate' ] );
register_uninstall_hook(    JP_PLUGIN_FILE, [ 'JP_Activator', 'uninstall'  ] );

// ── REST API — guarantee jp/v1 namespace is always accessible ────────────────
// Security plugins (Wordfence, Disable REST API, etc.) hook rest_authentication_errors
// at priority 10 to block all REST access. We whitelist our own namespace at priority 5
// so it fires BEFORE the blocking filter.
add_filter( 'rest_authentication_errors', function( $result ) {
    // If a previous filter already authenticated (e.g. JWT), pass it through.
    if ( ! is_null( $result ) && ! is_wp_error( $result ) ) return $result;

    // Check if this is a jp/v1 request.
    $route = $GLOBALS['wp']->query_vars['rest_route'] ?? '';
    if ( str_starts_with( $route, '/jp/v1/' ) || $route === '/jp/v1' ) {
        // Returning null here tells WP to proceed with default auth.
        // The jp/v1 routes each have their own permission_callback — no bypass.
        return null;
    }

    return $result; // Let other namespaces be handled normally.
}, 5 );

// Also remove the disable_wp_rest_api option effect for our namespace.
// Some plugins use the rest_enabled filter (pre-WP6) or set the option.
add_filter( 'rest_enabled', '__return_true', 5 );

// ── Bootstrap ────────────────────────────────────────────────────────────────
// Version migration: when plugin is updated, stored version differs from code version.
// Runs silently on every request until versions match — no deactivate/reactivate needed.
add_action( 'plugins_loaded', function(): void {
    $stored = get_option( 'jp_installed_version', '' );
    if ( $stored !== JP_VERSION ) {
        update_option( 'jp_installed_version', JP_VERSION );
        update_option( 'jp_db_version',        JP_VERSION );
        // Root-cause fix: this used to blindly overwrite jp_react_app_version
        // with JP_VERSION on every bump — see class-jp-react.php's
        // enqueue_react_assets() for why that's wrong (it assumes the two
        // are always released in lockstep, which the very build shipped in
        // this codebase disproves) and where the option is now set from the
        // actual deployed build filename instead. Left unset here on
        // purpose; JP_React sets it the moment any React page is next
        // rendered, and admin_health() reports "unknown (no React page
        // visited yet)" in the meantime rather than a falsely-reassuring
        // copy of the plugin version.

        // Re-run table creation (dbDelta idempotent) and FULLTEXT indexes
        if ( class_exists( 'JP_Activator' ) ) {
            JP_Activator::run_upgrade();
        }

        // Root-cause fix: JP_Cron::schedule_all() was previously only ever
        // called from JP_Activator's activation hook — which does NOT fire
        // when an existing install is upgraded in place (only on a fresh
        // activate/deactivate-reactivate). Any cron job added to
        // JP_Cron::JOBS after a site's initial install (e.g. the
        // jp_reconcile_payments job added for gap analysis P1 #154) would
        // therefore silently never get scheduled on already-running sites —
        // the exact same "decorative until reactivated" failure mode as
        // several other bugs already fixed in this codebase. schedule_all()
        // is idempotent (guarded by wp_next_scheduled() per hook), so it's
        // safe to call here on every version bump, not just on activation.
        if ( class_exists( 'JP_Cron' ) ) {
            JP_Cron::schedule_all();
        }


        // Root-cause fix (6.10.3): jp_job/jp_company's has_archive setting
        // just changed (true → false, to stop their archive rewrite rule
        // from winning /jobs/ and /companies/ away from the real WordPress
        // Pages at those slugs — see class-jp-cpt.php). A has_archive change
        // requires a rewrite-rules flush to actually take effect; without
        // one, WordPress keeps serving the OLD cached rule set from the
        // 'rewrite_rules' option, and the /jobs//companies/ redirect loop
        // this version fixes would silently persist on any site that already
        // had permalinks generated before upgrading. Flushing is NOT done
        // here directly: this callback runs on plugins_loaded priority 1,
        // which fires BEFORE 'init' — and JP_CPT::register_post_types()
        // (which is what actually applies the corrected has_archive value)
        // runs on 'init' at the default priority 10. Flushing this early
        // would bake in a stale rule set that still has the old archive rule
        // and silently fail to fix anything. Set a flag instead; the
        // late-'init'-priority handler below performs the real flush once
        // post types are definitely registered for this request.
        update_option( 'jp_needs_rewrite_flush', 1 );
    }

    // Batch 31 (part 2): /jobs-feed.xml is a NEW rewrite rule (added in
    // JP_SEO::register_job_feed_rewrite()). Like the has_archive fix just
    // above, a brand-new rewrite rule only takes effect after
    // flush_rewrite_rules() runs — without this, an already-installed site
    // would keep serving its cached pre-upgrade rule set and /jobs-feed.xml
    // would 404 indefinitely, only working after a manual
    // deactivate/reactivate or a permalinks-settings resave. Reuses the
    // exact same flag + the priority-999 'init' flush handler below, so no
    // new flush mechanism is introduced. Gated to fire only once, on the
    // version bump that ships this rule (this request's condition — every
    // request after jp_installed_version updates below won't re-enter here).
    if ( version_compare( $stored, '6.54.0', '<' ) ) {
        update_option( 'jp_needs_rewrite_flush', 1 );
    }

    // Always run on every request: creates any tables dbDelta silently skipped.
    // Idempotent — SHOW TABLES check prevents redundant CREATE calls.
    // This self-heals missing tables without requiring deactivate/reactivate.
    if ( class_exists( 'JP_Activator' ) ) {
        JP_Activator::ensure_missing_tables();
    }

    // Phase-2 remediation: schema migrations (FK constraints, data cleanup,
    // anything dbDelta cannot express) — run AFTER dbDelta/ensure_missing_
    // tables so a migration can assume the additive schema already exists.
    // See class-jp-migrator.php's docblock (gap analysis P0: "no schema
    // migration/versioning framework"). Run on every request rather than
    // only on a version bump: already-succeeded migrations are skipped by
    // a single cheap SELECT before any information_schema work happens, so
    // this is a self-healing no-op on the common path, and a migration
    // that failed once (e.g. because a table was briefly not InnoDB) gets
    // retried automatically instead of being silently abandoned until the
    // next version bump.
    if ( class_exists( 'JP_Migrator' ) ) {
        JP_Migrator::instance()->run_pending();
    }
}, 1 );

// Root-cause fix: performs the rewrite-rules flush requested above (or by
// JP_Activator::activate(), which has the identical timing constraint — its
// own add_action('init', ...) registrations, including JP_CPT's, do not run
// during the very request that activates the plugin, since the plugin
// wasn't in the active_plugins list yet when that request bootstrapped —
// so a flush called directly inside the activation hook has the same
// staleness risk as above). Priority 999 on 'init' guarantees
// JP_CPT::register_post_types() (default priority 10) has already run.
add_action( 'init', function (): void {
    if ( ! get_option( 'jp_needs_rewrite_flush' ) ) return;
    flush_rewrite_rules( false );
    delete_option( 'jp_needs_rewrite_flush' );
}, 999 );

// ── Suppress PHP error display on REST API requests ──────────────────────────
// When WP_DEBUG_DISPLAY=true, PHP notices and warnings are prepended to every
// HTTP response including REST API JSON. React's JSON.parse() then fails on
// "Notice: undefined variable..." prefixed before the { of the JSON body.
// This filter restores correct JSON by turning off display_errors for REST requests.
// Errors are still logged to the debug.log file — this only removes screen output.
add_action( 'rest_api_init', function(): void {
    if ( defined( 'WP_DEBUG_DISPLAY' ) && WP_DEBUG_DISPLAY ) {
        // phpcs:ignore WordPress.PHP.IniSet.display_errors_Disallowed
        @ini_set( 'display_errors', '0' );
    }
}, 0 ); // Priority 0 — fires before any route handler

add_action( 'plugins_loaded', 'jp_init', 0 );

function jp_init(): void {
    // Load text domain
    load_plugin_textdomain( 'jp-core', false, JP_PLUGIN_DIR . 'languages' );

    // Phase-2 remediation: centralized error/exception capture, registered
    // FIRST so it can catch anything thrown during the rest of this
    // function's own instantiation chain (gap analysis P0 #59/#156 — see
    // class-jp-errorlog.php).
    JP_ErrorLog::instance();

    // Instantiate core systems — order matters
    JP_DB::instance();
    JP_Roles::instance();
    JP_CPT::instance();
    JP_Auth::instance();
    JP_Jobs::instance();
    JP_Search::instance();
    JP_Applications::instance();
    JP_Resume::instance();
    JP_Matching::instance();
    JP_Alerts::instance();
    JP_Messaging::instance();
    JP_Notifications::instance();
    JP_Payments::instance();
    JP_Subscriptions::instance();
    JP_Analytics::instance();
    JP_Reviews::instance();
    JP_Assessments::instance();
    JP_Backup::instance();
    JP_Security::instance();
    JP_Cache::instance();
    JP_Cron::instance();
    JP_Api::instance();
    JP_SMTP::instance();
    JP_Settings::instance();
    JP_SEO::instance();
    JP_Performance::instance();
    JP_PWA::instance();
    JP_SMS::instance();
    JP_React::instance();
    JP_AI::instance();
    JP_Diagnostics::instance();
    // Phase-2 remediation: team/multi-seat infrastructure (see
    // enterprise-gap-analysis.md §1 and remediation-round-1-status.md).
    JP_Team::instance();
    // Phase-2 remediation: webhooks were fully configurable in the admin UI
    // but never actually dispatched on any real event (see
    // enterprise-gap-analysis.md §0 P0 item and phase2-progress-report.md).
    JP_Webhooks::instance();
    // Phase-2 remediation: GDPR/data-subject-request tooling (WP-native
    // export/erase hooks), company offboarding, and audit-logged
    // impersonation — all previously entirely absent despite declared
    // capabilities (see enterprise-gap-analysis.md §0/§12/bug#19).
    JP_Privacy::instance();
    // Phase-2 remediation: a real background job queue with atomic
    // claiming, retry/backoff, and a dead-letter state, replacing the
    // previous pattern of unbounded synchronous work inside WP-Cron
    // requests (gap analysis P1: "no queue system anywhere").
    JP_Queue::instance();
    // Phase-2 remediation: feature-flag infrastructure — the
    // jp_feature_flags table existed with no implementing class anywhere
    // (gap analysis P0 #58).
    JP_FeatureFlags::instance();
    // Vendor-integration pass: closes the two long-standing deliberate
    // scope exclusions (see this file's batch-31 changelog line above) —
    // e-signature on offer letters (DocuSign, additive/fails-soft — see
    // JP_ESign's docblock) and inbound job-feed pull import (see
    // JP_JobFeed's docblock for why a generic feed URL, not a named ATS
    // API, is the real credential-free integration point).
    JP_ESign::instance();
    JP_JobFeed::instance();
}

// ── Global helper functions ───────────────────────────────────────────────────

/**
 * Get current logged-in user's JP role.
 * Returns one of: jp_job_seeker | jp_recruiter | jp_staff |
 *                 jp_team_manager | jp_admin_manager | administrator | ''
 */
function jp_current_role( int $user_id = 0 ): string {
    $user = $user_id ? get_userdata( $user_id ) : wp_get_current_user();
    if ( ! $user || ! $user->exists() ) return '';

    $jp_roles = [
        'administrator',
        'jp_admin_manager',
        'jp_team_manager',
        'jp_staff',
        'jp_recruiter',
        'jp_job_seeker',
    ];

    foreach ( $jp_roles as $role ) {
        if ( in_array( $role, (array) $user->roles, true ) ) {
            return $role;
        }
    }
    return '';
}

/**
 * Quick capability check — returns bool.
 */
function jp_can( string $cap, int $user_id = 0 ): bool {
    $user_id = $user_id ?: get_current_user_id();
    return user_can( $user_id, $cap );
}

/**
 * Sanitise and validate a positive integer.
 */
function jp_absint( $val ): int {
    return absint( $val );
}

/**
 * Return formatted INR salary string.
 */
function jp_format_salary( int $min, int $max, string $currency = 'INR' ): string {
    $symbol = $currency === 'INR' ? '₹' : $currency;

    $fmt = function ( int $n ) use ( $symbol ): string {
        if ( $n >= 100000 ) return $symbol . number_format( $n / 100000, 1 ) . 'L';
        if ( $n >= 1000 )   return $symbol . number_format( $n / 1000, 0 ) . 'K';
        return $symbol . number_format( $n );
    };

    if ( $min && $max ) return $fmt( $min ) . ' – ' . $fmt( $max ) . ' / yr';
    if ( $min )         return $fmt( $min ) . '+ / yr';
    if ( $max )         return 'Up to ' . $fmt( $max ) . ' / yr';
    return 'Not disclosed';
}

/**
 * Time ago string (e.g. "3 days ago").
 */
function jp_time_ago( string $datetime ): string {
    $diff = time() - strtotime( $datetime );
    if ( $diff < 60 )       return 'Just now';
    if ( $diff < 3600 )     return floor( $diff / 60 ) . 'm ago';
    if ( $diff < 86400 )    return floor( $diff / 3600 ) . 'h ago';
    if ( $diff < 604800 )   return floor( $diff / 86400 ) . 'd ago';
    if ( $diff < 2592000 )  return floor( $diff / 604800 ) . 'w ago';
    return date( 'j M Y', strtotime( $datetime ) );
}

/**
 * Output a JSON response and die — for AJAX handlers.
 *
 * ── ROOT-CAUSE FIX — this was the single most severe bug found in the
 *    entire codebase, more so than anything in the original gap analysis ──
 *
 * This function's signature was declared as
 *     jp_json_response( $data, bool $success = true, int $status = 200 )
 * but a large fraction of call sites across the plugin (every assessment
 * endpoint, get_matches, most of applications/reviews/messaging/alerts/
 * notifications — 33+ confirmed call sites just in a first pass) instead
 * call it as
 *     jp_json_response( $success_bool, $data_array_or_string, $status )
 * i.e. with the arguments in the OPPOSITE order from the declared
 * signature. Because the second parameter was strictly typed `bool`,
 * PHP's weak-typing coercion — which only converts between scalar types —
 * CANNOT coerce an array into it: passing an array as the second argument
 * (jp_json_response(true, ['message'=>...])) throws an uncaught
 * `TypeError` and fatals the entire request. This means every one of
 * those 33+ endpoints was completely non-functional (a hard 500/fatal
 * error), independent of and in addition to every other bug found in the
 * gap analysis — this is almost certainly the true underlying cause of
 * many "the whole feature is broken" reports.
 *
 * A smaller set of call sites (mostly in the account/auth/password-reset
 * paths) DOES call it in the originally-declared order,
 * jp_json_response($data, false, 400), and those calls worked correctly
 * before this fix. Rewriting all 150+ call sites to a single consistent
 * order would be a large, high-risk, low-value change for a purely
 * internal-response-shaping helper — so instead this function now
 * detects which calling convention was used, per call, by argument type,
 * and normalizes either order to the correct output. This fixes every
 * fatal call site immediately with zero changes required anywhere else in
 * the codebase, and preserves the calls that already worked.
 */
function jp_json_response( $arg1, $arg2 = null, int $status = 200 ): void {
    if ( is_bool( $arg1 ) ) {
        // Convention actually used by most of the codebase:
        // jp_json_response( bool $success, $data, $status = 200 )
        $success = $arg1;
        $data    = $arg2;
    } elseif ( is_bool( $arg2 ) ) {
        // Convention matching this function's original declared signature:
        // jp_json_response( $data, bool $success = true, $status = 200 )
        $data    = $arg1;
        $success = $arg2;
    } else {
        // Single-argument call: jp_json_response( $data ) — success
        // defaults to true (this matches the original signature's default
        // and is how several call sites use it, e.g. for a bare redirect
        // or message payload with no explicit success flag).
        $data    = $arg1;
        $success = true;
        if ( is_int( $arg2 ) ) $status = $arg2;
    }
    wp_send_json( [ 'success' => $success, 'data' => $data ], $status );
}

/**
 * Nonce verify helper — dies with JSON error on failure.
 */
function jp_verify_nonce( string $nonce_key ): void {
    if ( ! check_ajax_referer( $nonce_key, 'nonce', false ) ) {
        jp_json_response( __( 'Security check failed.', 'jp-core' ), false, 403 );
    }
}

/**
 * Root-cause fix (batch 11 — config-key consistency, audit rule 2.6-B).
 * jp_razorpay_key_id / jp_razorpay_key_secret are wp_options that the LIVE
 * admin settings screen (AdminSettingsPage.tsx's SECRET_FIELDS, saved via
 * class-jp-api.php's admin_save_settings()) is the only reachable UI to
 * configure Razorpay at all — class-jp-settings.php's own wp-admin
 * "Payments" page (render_payments()) has been a documented, unreachable
 * no-op since an earlier batch decommissioned the wp-admin menu in favor
 * of the SPA. But every payment code path (class-jp-payments.php's
 * do_create_order()/do_verify_payment()/handle_webhook()/
 * razorpay_request(), and class-jp-react.php's exposed
 * razorpay_enabled/razorpay_key_id config) read ONLY the wp-config.php PHP
 * constants JP_RAZORPAY_KEY_ID/JP_RAZORPAY_KEY_SECRET, never these
 * options — so an admin who fills in and saves their Razorpay keys through
 * the only settings screen that exists gets a silent no-op: payments stay
 * completely unconfigured (do_create_order() fails every order with
 * "Razorpay credentials not configured") unless they separately hand-edit
 * wp-config.php, which nothing in the product tells them to do (the old
 * wp-admin page's "add these to wp-config.php for maximum security" notice
 * is itself unreachable). Fixed by preferring the wp-config constant when
 * it's actually defined and non-empty (kept as the documented
 * more-secure option — constants aren't readable from the DB by a
 * compromised low-privilege account the way options can be) and falling
 * back to the option so the one UI that exists actually works.
 */
/**
 * Root-cause fix (user-reported: "I should not have to manually change the
 * portal name in multiple places"). jp_site_name (the "Site name" field on
 * the JP Settings page, AdminSettingsPage.tsx → admin_get_settings()/
 * admin_save_settings()) was already the single field an admin actually
 * edits for the portal's brand name, and it WAS already wired into the
 * React SPA (class-jp-react.php's config.site_name → PublicHeader,
 * SiteFooter). But every backend-generated piece of branded text —
 * password-reset emails, offer letters, interview reminders, SMS,
 * assessment-result emails, payment receipts, audit-alert emails, the
 * resume PDF footer, the 2FA/TOTP issuer string, PWA manifest name, SEO
 * meta tags (og:site_name, JobPosting/Organization structured data,
 * sitemap <publisher>), and the very first server-rendered <title> tag
 * (tpl-react-app.php, before React/useDocumentTitle ever runs) — called
 * get_bloginfo('name') directly instead, which reads WordPress's own
 * Settings → General → "Site Title" field. That is a SEPARATE setting
 * from jp_site_name with no relationship to it: an admin who set a
 * portal name here would see it in the header/footer, but every email a
 * candidate or recruiter receives, every SMS, every generated PDF, and
 * every social-share preview would silently show whatever WordPress's
 * own Site Title happens to be instead — exactly the "change it in one
 * place, forget the other" failure mode being fixed. This helper is now
 * the ONE function every branding call site in PHP goes through: it
 * prefers jp_site_name (the field the admin actually edits), and only
 * falls back to WordPress's Site Title for a brand-new install where
 * jp_site_name is still empty (matches class-jp-react.php's existing
 * get_option('jp_site_name', get_bloginfo('name')) fallback pattern, so
 * behavior for an unconfigured site is unchanged).
 */
function jp_site_name(): string {
    $name = get_option( 'jp_site_name', '' );
    return $name !== '' ? $name : get_bloginfo( 'name' );
}

function jp_razorpay_key_id(): string {
    if ( defined( 'JP_RAZORPAY_KEY_ID' ) && JP_RAZORPAY_KEY_ID ) return JP_RAZORPAY_KEY_ID;
    return (string) get_option( 'jp_razorpay_key_id', '' );
}

function jp_razorpay_key_secret(): string {
    if ( defined( 'JP_RAZORPAY_KEY_SECRET' ) && JP_RAZORPAY_KEY_SECRET ) return JP_RAZORPAY_KEY_SECRET;
    return (string) get_option( 'jp_razorpay_key_secret', '' );
}

/**
 * jp_razorpay_webhook_secret has no options-table equivalent at all (no
 * settings field was ever built for it — webhook signature verification
 * is optional/best-effort per handle_webhook()'s own `if ($secret && ...)`
 * guard), so this stays constant-only; kept as a named helper purely so
 * every Razorpay credential is read the same way from one place.
 */
function jp_razorpay_webhook_secret(): string {
    return defined( 'JP_RAZORPAY_WEBHOOK_SECRET' ) ? JP_RAZORPAY_WEBHOOK_SECRET : '';
}

/**
 * Batch 12 — Stripe gateway abstraction. Same constant-priority/option-
 * fallback shape as the Razorpay helpers above (see that docblock for why:
 * this is the only reachable settings UI, per admin_get_settings()/
 * admin_save_settings()'s jp_stripe_* keys and AdminSettingsPage.tsx's
 * Stripe fields), applied from the start this time instead of discovered
 * as a live bug after the fact.
 */
function jp_stripe_publishable_key(): string {
    if ( defined( 'JP_STRIPE_PUBLISHABLE_KEY' ) && JP_STRIPE_PUBLISHABLE_KEY ) return JP_STRIPE_PUBLISHABLE_KEY;
    return (string) get_option( 'jp_stripe_publishable_key', '' );
}

function jp_stripe_secret_key(): string {
    if ( defined( 'JP_STRIPE_SECRET_KEY' ) && JP_STRIPE_SECRET_KEY ) return JP_STRIPE_SECRET_KEY;
    return (string) get_option( 'jp_stripe_secret_key', '' );
}

function jp_stripe_webhook_secret(): string {
    if ( defined( 'JP_STRIPE_WEBHOOK_SECRET' ) && JP_STRIPE_WEBHOOK_SECRET ) return JP_STRIPE_WEBHOOK_SECRET;
    return (string) get_option( 'jp_stripe_webhook_secret', '' );
}

/**
 * Which processor is active. A single site-wide choice (not per-plan/per-
 * currency — that's the "multi-currency" half of this backlog item, left
 * for a later batch once a single working second gateway is confirmed
 * solid) — see class-jp-payments.php's do_create_order() for where this
 * is read.
 */
function jp_active_payment_gateway(): string {
    $gw = get_option( 'jp_payment_gateway', 'razorpay' );
    return in_array( $gw, [ 'razorpay', 'stripe' ], true ) ? $gw : 'razorpay';
}
