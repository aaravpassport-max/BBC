<?php
/**
 * NAS Homepage Template — full SaaS landing page
 */
if ( ! defined( 'ABSPATH' ) ) exit;

// Kill admin bar and theme chrome — this is a fully standalone page
add_filter( 'show_admin_bar', '__return_false', 999 );
remove_action( 'wp_head', '_admin_bar_bump_cb' );

$cfg    = \NAS\Core\Config::instance();
$db     = \NAS\Core\Database::instance();
$brand  = $cfg->get('brand_name', get_bloginfo('name'));
$color  = $cfg->get('brand_primary_color','#1A3A5C');
$tagline= $cfg->get('brand_tagline','Book Newspaper Ads Online — Fast, Easy, Affordable');
$phone  = $cfg->get('brand_phone','');
$walink = $cfg->get('brand_whatsapp','') ? 'https://wa.me/'.preg_replace('/[^0-9]/','', $cfg->get('brand_whatsapp','')) : '';

// Fetch counts for social proof
$total_bookings = (int) $db->row("SELECT COUNT(*) as c FROM {$db->t('bookings')} WHERE status != 'cancelled'")['c'] ?? 0;
$total_papers   = (int) $db->row("SELECT COUNT(*) as c FROM {$db->t('newspapers')} WHERE is_active=1")['c'] ?? 0;
$total_cities   = (int) $db->row("SELECT COUNT(*) as c FROM {$db->t('cities')} WHERE is_active=1")['c'] ?? 0;
$categories     = $db->select("SELECT * FROM {$db->t('categories')} WHERE is_active=1 ORDER BY sort_order ASC LIMIT 12");
$top_cities     = $db->select("SELECT * FROM {$db->t('cities')} WHERE is_active=1 ORDER BY tier ASC, name ASC LIMIT 20");
$newspapers     = $db->select("SELECT * FROM {$db->t('newspapers')} WHERE is_active=1 ORDER BY sort_order ASC, name ASC LIMIT 15");
$faqs           = $db->select("SELECT question,answer FROM {$db->t('faqs')} WHERE is_active=1 ORDER BY sort_order ASC LIMIT 8");

$booking_url  = nas_get_page_url('nas_page_booking','/book-newspaper-ad/');
$contact_url  = get_permalink(get_option('nas_page_contact')) ?: home_url('/contact-us/');
$faq_url      = get_permalink(get_option('nas_page_faq')) ?: home_url('/faq/');
$track_url    = get_permalink(get_option('nas_page_track_order')) ?: home_url('/track-order/');
$fb   = $cfg->get('social_facebook','');
$ig   = $cfg->get('social_instagram','');
$li   = $cfg->get('social_linkedin','');
$tw   = $cfg->get('social_twitter','');
$addr = $cfg->get('brand_address','');
$email= $cfg->get('brand_email','');

$cat_icons = ['📢','💍','🏠','💼','📚','⚖️','🏢','🚗','💰','🏆','🌟','🎉'];
$nonce = wp_create_nonce('nas_action');
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <meta name="description" content="<?php echo esc_attr($tagline); ?> — <?php echo esc_attr($brand); ?>">
  <title><?php echo esc_html($brand); ?> — <?php echo esc_html($tagline); ?></title>
  <?php wp_head(); ?>
  <style>
    :root{--hp-primary:<?php echo esc_js($color); ?>;--hp-primary-dark:color-mix(in srgb,<?php echo esc_js($color); ?> 80%,#000)}
    *{box-sizing:border-box;margin:0;padding:0}
    body{font-family:'Inter','Segoe UI',sans-serif;color:#1e293b;background:#fff;line-height:1.6;-webkit-font-smoothing:antialiased}
    a{text-decoration:none;color:inherit}

    /* NAV */
    .hp-nav{background:var(--hp-primary);position:sticky;top:0;z-index:1000;box-shadow:0 2px 20px rgba(0,0,0,.2)}
    .hp-nav-inner{max-width:1200px;margin:0 auto;padding:0 24px;height:64px;display:flex;align-items:center;gap:16px}
    .hp-logo{font-size:20px;font-weight:800;color:#fff;text-decoration:none;margin-right:24px;display:flex;align-items:center;gap:10px;flex-shrink:0}
    .hp-logo-badge{background:rgba(255,255,255,.2);border-radius:8px;padding:6px 8px;font-size:18px}
    .hp-nav-links{display:flex;align-items:center;gap:4px;flex:1;overflow-x:auto;scrollbar-width:none}
    .hp-nav-links::-webkit-scrollbar{display:none}
    .hp-nav-link{color:rgba(255,255,255,.75);font-size:13.5px;font-weight:500;padding:7px 13px;border-radius:8px;transition:all .2s;white-space:nowrap}
    .hp-nav-link:hover,.hp-nav-link.active{background:rgba(255,255,255,.15);color:#fff}
    .hp-nav-cta{margin-left:auto;flex-shrink:0;display:flex;align-items:center;gap:10px}
    .hp-btn{display:inline-flex;align-items:center;gap:7px;padding:9px 20px;border-radius:8px;font-size:13.5px;font-weight:600;border:none;cursor:pointer;transition:all .2s;text-decoration:none;white-space:nowrap}
    .hp-btn-white{background:#fff;color:var(--hp-primary)}
    .hp-btn-white:hover{background:#f0f9ff;transform:translateY(-1px);box-shadow:0 4px 14px rgba(0,0,0,.15)}
    .hp-btn-outline{background:transparent;color:#fff;border:1.5px solid rgba(255,255,255,.4)}
    .hp-btn-outline:hover{background:rgba(255,255,255,.1);border-color:rgba(255,255,255,.8)}
    .hp-btn-primary{background:var(--hp-primary);color:#fff}
    .hp-btn-primary:hover{background:var(--hp-primary-dark);transform:translateY(-1px);box-shadow:0 6px 20px rgba(0,0,0,.2)}
    .hp-btn-lg{padding:14px 32px;font-size:15px;border-radius:10px}
    .hp-btn-xl{padding:16px 40px;font-size:16px;border-radius:12px}
    .hp-hamburger{display:none;background:none;border:none;color:#fff;font-size:22px;cursor:pointer;padding:6px}

    /* HERO */
    .hp-hero{background:linear-gradient(135deg,var(--hp-primary) 0%,#1e3a8a 100%);padding:80px 24px 100px;position:relative;overflow:hidden}
    .hp-hero::before{content:'';position:absolute;inset:0;background:url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")}
    .hp-hero-inner{max-width:1100px;margin:0 auto;display:grid;grid-template-columns:1fr 440px;gap:64px;align-items:center;position:relative;z-index:1}
    .hp-hero-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.15);border:1px solid rgba(255,255,255,.25);color:#fff;padding:6px 16px;border-radius:99px;font-size:12.5px;font-weight:600;margin-bottom:20px}
    .hp-hero h1{font-size:48px;font-weight:800;color:#fff;line-height:1.1;margin-bottom:20px;letter-spacing:-.5px}
    .hp-hero h1 span{background:linear-gradient(90deg,#EFA414,#D7DBFF);-webkit-background-clip:text;-webkit-text-fill-color:transparent}
    .hp-hero p{font-size:17px;color:rgba(255,255,255,.8);margin-bottom:32px;line-height:1.7;max-width:480px}
    .hp-hero-actions{display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:36px}
    .hp-hero-stats{display:flex;gap:28px;flex-wrap:wrap}
    .hp-hero-stat{display:flex;flex-direction:column}
    .hp-hero-stat strong{font-size:26px;font-weight:800;color:#fff;line-height:1}
    .hp-hero-stat span{font-size:12px;color:rgba(255,255,255,.65);margin-top:3px}

    /* Hero search card */
    .hp-hero-card{background:#fff;border-radius:16px;padding:28px;box-shadow:0 20px 60px rgba(0,0,0,.25)}
    .hp-hero-card h3{font-size:17px;font-weight:700;color:#0f172a;margin-bottom:4px}
    .hp-hero-card p{font-size:13px;color:#64748b;margin-bottom:20px}
    .hp-search-group{display:flex;flex-direction:column;gap:10px;margin-bottom:16px}
    .hp-search-input,.hp-search-select{width:100%;padding:11px 14px;border:1.5px solid #e2e8f0;border-radius:8px;font-size:14px;font-family:inherit;color:#0f172a;transition:border .2s}
    .hp-search-input:focus,.hp-search-select:focus{outline:none;border-color:var(--hp-primary)}
    .hp-search-select{appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='%2394a3b8' stroke-width='2'%3E%3Cpath d='M6 9l6 6 6-6'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 10px center;padding-right:32px;cursor:pointer}
    .hp-card-submit{width:100%;padding:13px;background:var(--hp-primary);color:#fff;border:none;border-radius:8px;font-size:14.5px;font-weight:700;cursor:pointer;transition:all .2s}
    .hp-card-submit:hover{background:var(--hp-primary-dark);transform:translateY(-1px);box-shadow:0 6px 20px rgba(0,0,0,.2)}
    .hp-card-trust{display:flex;align-items:center;gap:8px;margin-top:14px;font-size:12px;color:#64748b}
    .hp-card-trust span{display:flex;align-items:center;gap:4px}

    /* SECTIONS */
    .hp-section{padding:80px 24px}
    .hp-section-inner{max-width:1200px;margin:0 auto}
    .hp-section-label{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:var(--hp-primary);margin-bottom:10px}
    .hp-section-title{font-size:36px;font-weight:800;color:#0f172a;margin-bottom:12px;line-height:1.2}
    .hp-section-subtitle{font-size:16px;color:#64748b;max-width:540px}
    .hp-section-header{margin-bottom:48px}

    /* HOW IT WORKS */
    .hp-bg-gray{background:#f8fafc}
    .hp-steps-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:28px;position:relative}
    .hp-steps-grid::before{content:'';position:absolute;top:40px;left:10%;right:10%;height:2px;background:linear-gradient(90deg,transparent,var(--hp-primary) 20%,var(--hp-primary) 80%,transparent);z-index:0}
    .hp-step-card{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:28px 20px;text-align:center;position:relative;z-index:1;box-shadow:0 2px 12px rgba(0,0,0,.04)}
    .hp-step-num{width:56px;height:56px;background:var(--hp-primary);color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:20px;font-weight:800;margin:0 auto 16px;box-shadow:0 4px 14px rgba(0,0,0,.2)}
    .hp-step-title{font-size:15px;font-weight:700;color:#0f172a;margin-bottom:8px}
    .hp-step-desc{font-size:13px;color:#64748b;line-height:1.6}

    /* CATEGORIES */
    .hp-cat-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:16px}
    .hp-cat-card{background:#fff;border:1.5px solid #e2e8f0;border-radius:14px;padding:22px 18px;text-align:center;cursor:pointer;transition:all .25s;text-decoration:none}
    .hp-cat-card:hover{border-color:var(--hp-primary);background:color-mix(in srgb,var(--hp-primary) 5%,#fff);transform:translateY(-3px);box-shadow:0 8px 24px rgba(0,0,0,.1)}
    .hp-cat-icon{font-size:32px;margin-bottom:10px}
    .hp-cat-name{font-size:13.5px;font-weight:700;color:#0f172a;margin-bottom:4px}
    .hp-cat-desc{font-size:11.5px;color:#64748b;line-height:1.4}

    /* NEWSPAPERS */
    .hp-papers-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:14px}
    .hp-paper-card{background:#fff;border:1.5px solid #e2e8f0;border-radius:12px;padding:16px;display:flex;align-items:center;gap:12px;transition:all .2s;cursor:pointer}
    .hp-paper-card:hover{border-color:var(--hp-primary);box-shadow:0 4px 16px rgba(0,0,0,.08)}
    .hp-paper-logo{width:42px;height:42px;border-radius:8px;background:#f1f5f9;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:15px;color:var(--hp-primary);flex-shrink:0}
    .hp-paper-name{font-size:12.5px;font-weight:700;color:#0f172a;line-height:1.3}
    .hp-paper-lang{font-size:11px;color:#64748b;margin-top:2px}

    /* CITIES */
    .hp-cities-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:10px}
    .hp-city-chip{background:#fff;border:1.5px solid #e2e8f0;border-radius:10px;padding:12px 14px;display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;color:#0f172a;cursor:pointer;transition:all .2s;text-decoration:none}
    .hp-city-chip:hover{border-color:var(--hp-primary);color:var(--hp-primary);background:color-mix(in srgb,var(--hp-primary) 5%,#fff)}
    .hp-tier-dot{width:7px;height:7px;border-radius:50%;background:var(--hp-primary);flex-shrink:0}
    .hp-tier-2 .hp-tier-dot{background:#0ea5e9}
    .hp-tier-3 .hp-tier-dot{background:#94a3b8}

    /* WHY US */
    .hp-why-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:24px}
    .hp-why-card{background:#fff;border:1.5px solid #e2e8f0;border-radius:16px;padding:28px;transition:all .2s}
    .hp-why-card:hover{border-color:var(--hp-primary);box-shadow:0 8px 28px rgba(0,0,0,.08);transform:translateY(-2px)}
    .hp-why-icon{width:52px;height:52px;border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:24px;margin-bottom:16px}
    .hp-why-title{font-size:16px;font-weight:700;color:#0f172a;margin-bottom:8px}
    .hp-why-desc{font-size:13.5px;color:#64748b;line-height:1.7}

    /* FAQ */
    .hp-faq-grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}
    .hp-faq-item{background:#fff;border:1.5px solid #e2e8f0;border-radius:12px;overflow:hidden}
    .hp-faq-q{padding:16px 20px;display:flex;justify-content:space-between;align-items:center;cursor:pointer;font-size:14px;font-weight:600;color:#0f172a;gap:12px;transition:background .15s}
    .hp-faq-q:hover{background:#f8fafc}
    .hp-faq-q .hp-faq-arrow{font-size:12px;color:#94a3b8;flex-shrink:0;transition:transform .25s}
    .hp-faq-item.open .hp-faq-q{background:#f8fafc}
    .hp-faq-item.open .hp-faq-arrow{transform:rotate(180deg)}
    .hp-faq-a{display:none;padding:0 20px 16px;font-size:13.5px;color:#475569;line-height:1.7}
    .hp-faq-item.open .hp-faq-a{display:block}

    /* CTA BANNER */
    .hp-cta-section{background:linear-gradient(135deg,var(--hp-primary) 0%,#1e3a8a 100%);padding:80px 24px}
    .hp-cta-inner{max-width:700px;margin:0 auto;text-align:center}
    .hp-cta-inner h2{font-size:36px;font-weight:800;color:#fff;margin-bottom:14px;line-height:1.2}
    .hp-cta-inner p{font-size:16px;color:rgba(255,255,255,.8);margin-bottom:32px}
    .hp-cta-actions{display:flex;justify-content:center;gap:14px;flex-wrap:wrap}

    /* FOOTER */
    .hp-footer{background:#0f172a;padding:60px 24px 28px}
    .hp-footer-inner{max-width:1200px;margin:0 auto}
    .hp-footer-top{display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:40px;margin-bottom:48px}
    .hp-footer-brand p{font-size:13px;color:#94a3b8;line-height:1.7;margin:12px 0 20px;max-width:280px}
    .hp-footer-social{display:flex;gap:10px}
    .hp-social-link{width:36px;height:36px;background:rgba(255,255,255,.1);border-radius:8px;display:flex;align-items:center;justify-content:center;color:rgba(255,255,255,.7);font-size:14px;font-weight:700;transition:all .2s}
    .hp-social-link:hover{background:var(--hp-primary);color:#fff}
    .hp-footer-col h4{font-size:12px;font-weight:700;text-transform:uppercase;letter-spacing:.8px;color:#64748b;margin-bottom:16px}
    .hp-footer-col ul{list-style:none}
    .hp-footer-col ul li{margin-bottom:9px}
    .hp-footer-col ul li a{font-size:13.5px;color:#94a3b8;transition:color .2s}
    .hp-footer-col ul li a:hover{color:#fff}
    .hp-footer-bottom{border-top:1px solid rgba(255,255,255,.07);padding-top:24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:12px}
    .hp-footer-copyright{font-size:12.5px;color:#64748b}
    .hp-footer-legal{display:flex;gap:16px}
    .hp-footer-legal a{font-size:12.5px;color:#64748b;transition:color .2s}
    .hp-footer-legal a:hover{color:#fff}

    /* FLOATING WA */
    .hp-wa-float{position:fixed;bottom:28px;right:28px;z-index:9000;background:#25D366;border-radius:50%;width:56px;height:56px;display:flex;align-items:center;justify-content:center;box-shadow:0 4px 20px rgba(37,211,102,.4);font-size:26px;color:#fff;text-decoration:none;transition:transform .2s}
    .hp-wa-float:hover{transform:scale(1.08)}

    /* RESPONSIVE */
    @media(max-width:1100px){
      .hp-hero-inner{grid-template-columns:1fr}
      .hp-hero-card{display:none}
      .hp-hero h1{font-size:38px}
      .hp-papers-grid{grid-template-columns:repeat(3,1fr)}
      .hp-footer-top{grid-template-columns:1fr 1fr}
    }
    @media(max-width:768px){
      .hp-hero{padding:52px 24px 64px}
      .hp-hero h1{font-size:30px}
      .hp-steps-grid{grid-template-columns:1fr 1fr;gap:16px}
      .hp-steps-grid::before{display:none}
      .hp-cat-grid{grid-template-columns:repeat(2,1fr)}
      .hp-papers-grid{grid-template-columns:repeat(2,1fr)}
      .hp-cities-grid{grid-template-columns:repeat(2,1fr)}
      .hp-why-grid{grid-template-columns:1fr}
      .hp-faq-grid{grid-template-columns:1fr}
      .hp-footer-top{grid-template-columns:1fr}
      .hp-nav-links{display:none}
      .hp-hamburger{display:flex!important}
      .hp-section{padding:52px 20px}
      .hp-section-title{font-size:26px}
    }
    @media(max-width:480px){
      .hp-cat-grid{grid-template-columns:repeat(2,1fr)}
      .hp-cities-grid{grid-template-columns:repeat(2,1fr)}
      .hp-papers-grid{grid-template-columns:1fr}
      .hp-hero-actions{flex-direction:column;align-items:flex-start}
      .hp-cta-inner h2{font-size:26px}
    }
  </style>
</head>
<body>

<!-- ═══════════════════════════ TOP NAV ═══════════════════════════ -->
<nav class="hp-nav">
  <div class="hp-nav-inner">
    <a href="<?php echo esc_url(home_url('/')); ?>" class="hp-logo">
      <span class="hp-logo-badge"><i class="fa-solid fa-newspaper"></i></span>
      <?php echo esc_html($brand); ?>
    </a>
    <div class="hp-nav-links">
      <a class="hp-nav-link active" href="<?php echo esc_url(home_url('/')); ?>">Home</a>
      <a class="hp-nav-link" href="<?php echo esc_url(home_url('/newspaper-ads/')); ?>">Newspapers</a>
      <a class="hp-nav-link" href="<?php echo esc_url(home_url('/faq/')); ?>">FAQ</a>
      <a class="hp-nav-link" href="<?php echo esc_url($contact_url); ?>">Contact</a>
      <a class="hp-nav-link" href="<?php echo esc_url($track_url); ?>">Track Order</a>
    </div>
    <div class="hp-nav-cta">
      <?php if(is_user_logged_in()): $u=wp_get_current_user(); ?>
        <a href="<?php echo esc_url(nas_get_page_url('nas_page_client_dashboard','/client-dashboard/')); ?>" class="hp-btn hp-btn-outline" style="font-size:13px">My Dashboard</a>
      <?php else: ?>
        <a href="<?php echo esc_url(home_url('/newspaper-ad-login/')); ?>" class="hp-btn hp-btn-outline" style="font-size:13px">Login</a>
      <?php endif; ?>
      <a href="<?php echo esc_url($booking_url); ?>" class="hp-btn hp-btn-white">Book an Ad →</a>
      <button class="hp-hamburger" id="hp-hamburger"><i class="fa-solid fa-bars"></i></button>
    </div>
  </div>
</nav>

<!-- Mobile nav drawer -->
<div id="hp-mobile-nav" style="display:none;position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.5)">
  <div style="background:#0f172a;width:280px;height:100%;padding:24px;display:flex;flex-direction:column;gap:12px">
    <button id="hp-nav-close" style="align-self:flex-end;background:none;border:none;color:#fff;font-size:22px;cursor:pointer;margin-bottom:8px"><i class="fa-solid fa-xmark"></i></button>
    <?php foreach([['Home',home_url('/')],['Newspapers',home_url('/newspaper-ads/')],['FAQ',$faq_url],['Contact',$contact_url],['Track Order',$track_url]] as $nl): ?>
    <a href="<?php echo esc_url($nl[1]); ?>" style="color:rgba(255,255,255,.8);font-size:15px;padding:10px 14px;border-radius:8px;transition:background .2s" onmouseover="this.style.background='rgba(255,255,255,.1)'" onmouseout="this.style.background=''"><?php echo esc_html($nl[0]); ?></a>
    <?php endforeach; ?>
    <a href="<?php echo esc_url($booking_url); ?>" style="margin-top:16px;padding:14px;background:var(--hp-primary);color:#fff;text-align:center;border-radius:8px;font-weight:700">Book an Ad →</a>
  </div>
</div>

<!-- ═══════════════════════════ HERO ═══════════════════════════ -->
<section class="hp-hero">
  <div class="hp-hero-inner">
    <div>
      <div class="hp-hero-badge"><i class="fa-solid fa-trophy"></i> India's Trusted Newspaper Ad Platform</div>
      <h1>Book <span>Newspaper Ads</span><br>Across India Online</h1>
      <p><?php echo esc_html($tagline); ?> — <?php echo ($total_papers>0 ? $total_papers.'+ newspapers' : '300+ newspapers'); ?> in <?php echo ($total_cities>0 ? $total_cities.'+ cities' : '300+ cities'); ?>.</p>
      <div class="hp-hero-actions">
        <a href="<?php echo esc_url($booking_url); ?>" class="hp-btn hp-btn-white hp-btn-xl">
          <i class="fa-solid fa-newspaper"></i> Book an Ad Now
        </a>
        <?php if($walink): ?>
        <a href="<?php echo esc_url($walink); ?>" target="_blank" class="hp-btn hp-btn-outline hp-btn-lg">
          <i class="fa-brands fa-whatsapp"></i> WhatsApp Us
        </a>
        <?php elseif($phone): ?>
        <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','',$phone)); ?>" class="hp-btn hp-btn-outline hp-btn-lg">
          <i class="fa-solid fa-phone"></i> Call Us
        </a>
        <?php endif; ?>
      </div>
      <div class="hp-hero-stats">
        <div class="hp-hero-stat"><strong><?php echo $total_papers>0 ? $total_papers.'+' : '300+'; ?></strong><span>Newspapers</span></div>
        <div class="hp-hero-stat"><strong><?php echo $total_cities>0 ? $total_cities.'+' : '200+'; ?></strong><span>Cities</span></div>
        <div class="hp-hero-stat"><strong><?php echo $total_bookings>0 ? number_format($total_bookings) : '10,000+'; ?></strong><span>Ads Placed</span></div>
        <div class="hp-hero-stat"><strong>24hrs</strong><span>Avg. Processing</span></div>
      </div>
    </div>

    <!-- Quick booking card -->
    <div class="hp-hero-card">
      <h3>Quick Book an Ad</h3>
      <p>Select your preferences and get an instant price quote</p>
      <form class="hp-search-group" id="hp-quick-book" onsubmit="return false">
        <select class="hp-search-select" id="hp-qb-city">
          <option value="">📍 Select City</option>
          <?php foreach($top_cities as $c): ?>
          <option value="<?php echo esc_attr($c['id']); ?>"><?php echo esc_html($c['name']); ?>, <?php echo esc_html($c['state']); ?></option>
          <?php endforeach; ?>
        </select>
        <select class="hp-search-select" id="hp-qb-category">
          <option value="">📋 Ad Category</option>
          <?php foreach($categories as $cat): ?>
          <option value="<?php echo esc_attr($cat['id']); ?>"><?php echo esc_html($cat['name']); ?></option>
          <?php endforeach; ?>
        </select>
        <select class="hp-search-select" id="hp-qb-newspaper">
          <option value="">📰 Select Newspaper</option>
          <?php foreach($newspapers as $np): ?>
          <option value="<?php echo esc_attr($np['id']); ?>"><?php echo esc_html($np['name']); ?></option>
          <?php endforeach; ?>
        </select>
        <button type="submit" class="hp-card-submit" onclick="hpQuickBook()">
          Get Price & Book →
        </button>
      </form>
      <div class="hp-card-trust">
        <span><i class="fa-solid fa-lock"></i> Secure</span>
        <span><i class="fa-solid fa-bolt"></i> Instant Quote</span>
        <span><i class="fa-solid fa-circle-check"></i> Verified Publishers</span>
      </div>
    </div>

  </div>
</section>

<!-- ═══════════════════════════ HOW IT WORKS ═══════════════════════════ -->
<section class="hp-section hp-bg-gray">
  <div class="hp-section-inner">
    <div class="hp-section-header" style="text-align:center">
      <div class="hp-section-label">Simple Process</div>
      <h2 class="hp-section-title" style="margin:0 auto 12px">How It Works</h2>
      <p class="hp-section-subtitle" style="margin:0 auto">Book your newspaper ad in 4 easy steps — completely online</p>
    </div>
    <div class="hp-steps-grid">
      <?php
      $how_steps = [
        ['1','Choose','Select your city, newspaper, and ad category from 300+ options'],
        ['2','Compose','Write your ad or use our AI to craft the perfect text'],
        ['3','Pay','Secure online payment via UPI, card, or net banking'],
        ['4','Published!','We submit your ad and you get a publication proof'],
      ];
      foreach($how_steps as $s):
      ?>
      <div class="hp-step-card">
        <div class="hp-step-num"><?php echo $s[0]; ?></div>
        <div class="hp-step-title"><?php echo esc_html($s[1]); ?></div>
        <div class="hp-step-desc"><?php echo esc_html($s[2]); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════ CATEGORIES ═══════════════════════════ -->
<section class="hp-section">
  <div class="hp-section-inner">
    <div class="hp-section-header">
      <div class="hp-section-label">Ad Categories</div>
      <h2 class="hp-section-title">Every Type of Newspaper Ad</h2>
      <p class="hp-section-subtitle">From classified text to full-page display — we cover every ad type</p>
    </div>
    <div class="hp-cat-grid">
      <?php if($categories): foreach($categories as $i=>$cat):
        $icon = $cat_icons[$i] ?? '📢';
        $url  = home_url('/newspaper-ads/'.($cat['slug']??sanitize_title($cat['name'])).'/');
      ?>
      <a href="<?php echo esc_url($booking_url.'?category='.urlencode($cat['id'])); ?>" class="hp-cat-card">
        <div class="hp-cat-icon"><?php echo esc_html($cat['icon'] ?: $icon); ?></div>
        <div class="hp-cat-name"><?php echo esc_html($cat['name']); ?></div>
        <div class="hp-cat-desc"><?php echo esc_html($cat['description'] ?: 'Book '.$cat['name'].' ads online'); ?></div>
      </a>
      <?php endforeach; else:
        $default_cats = [
          ['📢','Classified Text','Name change, lost & found, personal'],
          ['🖼️','Display Ads','Image + text, column based pricing'],
          ['💍','Matrimonial','Bride & groom wanted ads'],
          ['🏠','Property','Buy, sell & rent property'],
          ['💼','Recruitment','Job vacancies & career ads'],
          ['⚖️','Public Notice','Legal & government notices'],
          ['📚','Education','Admissions & results'],
          ['🌹','Obituary','Death announcements'],
        ];
        foreach($default_cats as $c):
      ?>
      <a href="<?php echo esc_url($booking_url); ?>" class="hp-cat-card">
        <div class="hp-cat-icon"><?php echo $c[0]; ?></div>
        <div class="hp-cat-name"><?php echo esc_html($c[1]); ?></div>
        <div class="hp-cat-desc"><?php echo esc_html($c[2]); ?></div>
      </a>
      <?php endforeach; endif; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════ NEWSPAPERS ═══════════════════════════ -->
<?php if($newspapers): ?>
<section class="hp-section hp-bg-gray">
  <div class="hp-section-inner">
    <div class="hp-section-header">
      <div class="hp-section-label">Our Publishers</div>
      <h2 class="hp-section-title">Top Newspapers Covered</h2>
      <p class="hp-section-subtitle">Book ads in India's most-read newspapers — English, Hindi & regional language dailies</p>
    </div>
    <div class="hp-papers-grid">
      <?php foreach($newspapers as $np):
        $initials = strtoupper(substr($np['name'],0,2));
        $url = home_url('/newspaper/'.($np['slug'] ?: sanitize_title($np['name'])).'/');
      ?>
      <a href="<?php echo esc_url($booking_url.'?newspaper='.urlencode($np['id'])); ?>" class="hp-paper-card">
        <?php if(!empty($np['logo_url'])): ?>
          <img src="<?php echo esc_url($np['logo_url']); ?>" alt="<?php echo esc_attr($np['name']); ?>" style="width:42px;height:42px;object-fit:contain;border-radius:8px;flex-shrink:0">
        <?php else: ?>
          <div class="hp-paper-logo"><?php echo esc_html($initials); ?></div>
        <?php endif; ?>
        <div>
          <div class="hp-paper-name"><?php echo esc_html($np['name']); ?></div>
          <div class="hp-paper-lang"><?php echo esc_html($np['language'] ?: 'English'); ?></div>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:32px">
      <a href="<?php echo esc_url(home_url('/newspaper-ads/')); ?>" class="hp-btn hp-btn-primary hp-btn-lg">View All Newspapers →</a>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ═══════════════════════════ CITIES ═══════════════════════════ -->
<?php if($top_cities): ?>
<section class="hp-section">
  <div class="hp-section-inner">
    <div class="hp-section-header">
      <div class="hp-section-label">Pan-India Coverage</div>
      <h2 class="hp-section-title">Available in <?php echo $total_cities>0 ? $total_cities.'+' : '200+'; ?> Cities</h2>
      <p class="hp-section-subtitle">Book newspaper ads in all major Tier 1, Tier 2 & Tier 3 Indian cities</p>
    </div>
    <div class="hp-cities-grid">
      <?php foreach($top_cities as $city):
        $tier_class = 'hp-tier-'.($city['tier'] ?: 3);
      ?>
      <a href="<?php echo esc_url($booking_url.'?city='.urlencode($city['id'])); ?>" class="hp-city-chip <?php echo esc_attr($tier_class); ?>">
        <div class="hp-tier-dot"></div>
        <?php echo esc_html($city['name']); ?>
      </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ═══════════════════════════ WHY US ═══════════════════════════ -->
<section class="hp-section hp-bg-gray">
  <div class="hp-section-inner">
    <div class="hp-section-header" style="text-align:center">
      <div class="hp-section-label">Why Choose Us</div>
      <h2 class="hp-section-title" style="margin:0 auto 12px">The Smarter Way to Book Newspaper Ads</h2>
      <p class="hp-section-subtitle" style="margin:0 auto">Everything you need to book, track and manage your newspaper ads in one place</p>
    </div>
    <div class="hp-why-grid">
      <?php
      $why = [
        ['fa-bolt','Instant Booking','No phone calls or emails needed. Book your ad online 24/7 in under 3 minutes.','rgba(42,138,250,.12)','#2A8AFA'],
        ['fa-sack-dollar','Best Rates','Direct rates from newspapers with no hidden charges. Transparent pricing with GST invoice.','rgba(239,164,20,.14)','#D68F0A'],
        ['fa-chart-line','Track Everything','Real-time status tracking from booking to publication. Get notified at every step.','rgba(47,82,88,.12)','#2F5258'],
        ['fa-wand-magic-sparkles','AI-Powered Copy','Our AI helps you write the perfect newspaper ad that fits your budget and category.','rgba(42,138,250,.12)','#2A8AFA'],
        ['fa-file-invoice','Instant Invoice','Auto-generated GST invoice immediately after payment. Download anytime from your dashboard.','rgba(239,164,20,.14)','#D68F0A'],
        ['fa-shield-halved','Secure Payments','All payments via Razorpay — India\'s most trusted payment gateway. UPI, cards, netbanking.','rgba(47,82,88,.12)','#2F5258'],
      ];
      foreach($why as $w):
      ?>
      <div class="hp-why-card">
        <div class="hp-why-icon" style="background:<?php echo $w[3]; ?>;color:<?php echo $w[4]; ?>"><i class="fa-solid <?php echo $w[0]; ?>"></i></div>
        <div class="hp-why-title"><?php echo esc_html($w[1]); ?></div>
        <div class="hp-why-desc"><?php echo esc_html($w[2]); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ═══════════════════════════ FAQ ═══════════════════════════ -->
<?php if($faqs): ?>
<section class="hp-section">
  <div class="hp-section-inner">
    <div class="hp-section-header">
      <div class="hp-section-label">Common Questions</div>
      <h2 class="hp-section-title">Frequently Asked Questions</h2>
      <p class="hp-section-subtitle">Everything you need to know about booking newspaper ads online</p>
    </div>
    <div class="hp-faq-grid">
      <?php foreach($faqs as $faq): ?>
      <div class="hp-faq-item">
        <div class="hp-faq-q" onclick="this.closest('.hp-faq-item').classList.toggle('open')">
          <?php echo esc_html($faq['question']); ?>
          <span class="hp-faq-arrow"><i class="fa-solid fa-chevron-down"></i></span>
        </div>
        <div class="hp-faq-a"><?php echo wp_kses_post($faq['answer']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:28px">
      <a href="<?php echo esc_url($faq_url); ?>" class="hp-btn hp-btn-primary">View All FAQs →</a>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ═══════════════════════════ CTA BANNER ═══════════════════════════ -->
<section class="hp-cta-section">
  <div class="hp-cta-inner">
    <h2>Ready to Place Your Newspaper Ad?</h2>
    <p>Join thousands of advertisers who trust <?php echo esc_html($brand); ?> for their newspaper advertising needs.</p>
    <div class="hp-cta-actions">
      <a href="<?php echo esc_url($booking_url); ?>" class="hp-btn hp-btn-white hp-btn-xl">Book an Ad Now →</a>
      <a href="<?php echo esc_url($contact_url); ?>" class="hp-btn hp-btn-outline hp-btn-lg">Talk to Us</a>
    </div>
  </div>
</section>

<!-- ═══════════════════════════ FOOTER ═══════════════════════════ -->
<footer class="hp-footer">
  <div class="hp-footer-inner">
    <div class="hp-footer-top">
      <div class="hp-footer-brand">
        <div style="font-size:20px;font-weight:800;color:#fff;display:flex;align-items:center;gap:10px">
          <span style="background:rgba(255,255,255,.15);border-radius:8px;padding:6px 8px;font-size:16px"><i class="fa-solid fa-newspaper"></i></span>
          <?php echo esc_html($brand); ?>
        </div>
        <p><?php echo esc_html($cfg->get('footer_tagline', 'Book newspaper ads online across India — fast, transparent, reliable.')); ?></p>
        <?php if($email||$phone): ?>
        <div style="font-size:13px;color:#94a3b8;margin-bottom:14px">
          <?php if($email): ?><div><i class="fa-solid fa-envelope"></i> <a href="mailto:<?php echo esc_attr($email); ?>" style="color:#94a3b8"><?php echo esc_html($email); ?></a></div><?php endif; ?>
          <?php if($phone): ?><div style="margin-top:4px"><i class="fa-solid fa-phone"></i> <a href="tel:<?php echo esc_attr(preg_replace('/[^0-9+]/','', $phone)); ?>" style="color:#94a3b8"><?php echo esc_html($phone); ?></a></div><?php endif; ?>
        </div>
        <?php endif; ?>
        <div class="hp-footer-social">
          <?php if($fb): ?><a href="<?php echo esc_url($fb); ?>" class="hp-social-link" target="_blank" rel="noopener"><i class="fa-brands fa-facebook-f"></i></a><?php endif; ?>
          <?php if($ig): ?><a href="<?php echo esc_url($ig); ?>" class="hp-social-link" target="_blank" rel="noopener"><i class="fa-brands fa-instagram"></i></a><?php endif; ?>
          <?php if($li): ?><a href="<?php echo esc_url($li); ?>" class="hp-social-link" target="_blank" rel="noopener"><i class="fa-brands fa-linkedin-in"></i></a><?php endif; ?>
          <?php if($tw): ?><a href="<?php echo esc_url($tw); ?>" class="hp-social-link" target="_blank" rel="noopener"><i class="fa-brands fa-x-twitter"></i></a><?php endif; ?>
          <?php if($walink): ?><a href="<?php echo esc_url($walink); ?>" class="hp-social-link" target="_blank" rel="noopener" style="color:#25D366"><i class="fa-brands fa-whatsapp"></i></a><?php endif; ?>
        </div>
      </div>
      <div class="hp-footer-col">
        <h4>Newspapers</h4>
        <ul>
          <?php foreach(array_slice($newspapers ?: [], 0, 5) as $np): ?>
          <li><a href="<?php echo esc_url($booking_url.'?newspaper='.urlencode($np['id'])); ?>"><?php echo esc_html($np['name']); ?></a></li>
          <?php endforeach; ?>
          <li><a href="<?php echo esc_url(home_url('/newspaper-ads/')); ?>">View All →</a></li>
        </ul>
      </div>
      <div class="hp-footer-col">
        <h4>Top Cities</h4>
        <ul>
          <?php foreach(array_slice($top_cities ?: [], 0, 5) as $city): ?>
          <li><a href="<?php echo esc_url($booking_url.'?city='.urlencode($city['id'])); ?>"><?php echo esc_html($city['name']); ?></a></li>
          <?php endforeach; ?>
          <li><a href="<?php echo esc_url(home_url('/newspaper-ads/')); ?>">All Cities →</a></li>
        </ul>
      </div>
      <div class="hp-footer-col">
        <h4>Support</h4>
        <ul>
          <li><a href="<?php echo esc_url($booking_url); ?>">Book an Ad</a></li>
          <li><a href="<?php echo esc_url($track_url); ?>">Track Order</a></li>
          <li><a href="<?php echo esc_url($faq_url); ?>">FAQ</a></li>
          <li><a href="<?php echo esc_url($contact_url); ?>">Contact Us</a></li>
          <li><a href="<?php echo esc_url(home_url('/about-us/')); ?>">About Us</a></li>
        </ul>
      </div>
    </div>
    <div class="hp-footer-bottom">
      <div class="hp-footer-copyright">© <?php echo date('Y'); ?> <?php echo esc_html($brand); ?>. All rights reserved.</div>
      <div class="hp-footer-legal">
        <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>">Privacy Policy</a>
        <a href="<?php echo esc_url(home_url('/terms-conditions/')); ?>">Terms</a>
        <a href="<?php echo esc_url(home_url('/refund-policy/')); ?>">Refund Policy</a>
      </div>
    </div>
  </div>
</footer>

<?php if($walink): ?>
<a href="<?php echo esc_url($walink); ?>" class="hp-wa-float" target="_blank" rel="noopener" title="Chat on WhatsApp"><i class="fa-brands fa-whatsapp"></i></a>
<?php endif; ?>

<script>
// Mobile nav
document.getElementById('hp-hamburger')?.addEventListener('click',function(){ document.getElementById('hp-mobile-nav').style.display='flex'; });
document.getElementById('hp-nav-close')?.addEventListener('click',function(){ document.getElementById('hp-mobile-nav').style.display='none'; });
document.getElementById('hp-mobile-nav')?.addEventListener('click',function(e){ if(e.target===this) this.style.display='none'; });

// Quick book redirect
function hpQuickBook(){
  var city=document.getElementById('hp-qb-city')?.value;
  var cat=document.getElementById('hp-qb-category')?.value;
  var np=document.getElementById('hp-qb-newspaper')?.value;
  var url='<?php echo esc_js($booking_url); ?>';
  var params=[];
  if(city) params.push('city='+encodeURIComponent(city));
  if(cat)  params.push('category='+encodeURIComponent(cat));
  if(np)   params.push('newspaper='+encodeURIComponent(np));
  window.location.href=url+(params.length?'?'+params.join('&'):'');
}
</script>
<?php wp_footer(); ?>
</body>
</html>
