import re

with open('fno-lab-core.js', 'r') as f:
    content = f.read()

# Replace all "const _elem_" with "let _elem_" to allow redeclaration
content = content.replace('const _elem_', 'let _elem_')

with open('fno-lab-core.js', 'w') as f:
    f.write(content)

print("Replaced const with let for _elem_ variables")
