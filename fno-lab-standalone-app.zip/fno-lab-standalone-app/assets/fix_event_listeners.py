import re

with open('fno-lab-core.js', 'r') as f:
    content = f.read()

# Pattern to match: document.getElementById('id').addEventListener(
# Replace with: const el = document.getElementById('id'); if (el) el.addEventListener(

# Line 16654: openSettingsBtn
content = re.sub(
    r"(\s+)document\.getElementById\('openSettingsBtn'\)\.addEventListener\('click', \(\) => \{",
    r"\1const openSettingsBtn = document.getElementById('openSettingsBtn'); if (openSettingsBtn) openSettingsBtn.addEventListener('click', () => {",
    content
)

# Line 16659: closeSettingsBtn
content = re.sub(
    r"(\s+)document\.getElementById\('closeSettingsBtn'\)\.addEventListener\('click', \(\) => \{",
    r"\1const closeSettingsBtn = document.getElementById('closeSettingsBtn'); if (closeSettingsBtn) closeSettingsBtn.addEventListener('click', () => {",
    content
)

# Line 16662: settingNseEnabled
content = re.sub(
    r"(\s+)document\.getElementById\('settingNseEnabled'\)\.addEventListener\('change', \(e\) => \{",
    r"\1const settingNseEnabled = document.getElementById('settingNseEnabled'); if (settingNseEnabled) settingNseEnabled.addEventListener('change', (e) => {",
    content
)

# Line 16667: settingType${type} - this is in a forEach, more complex
content = re.sub(
    r"(\s+)document\.getElementById\(`settingType\$\{type\}`\)\.addEventListener\('change', \(e\) => \{",
    r"\1const el = document.getElementById(`settingType${type}`); if (el) el.addEventListener('change', (e) => {",
    content
)

# Line 16677: settingTradeTypeSizing
content = re.sub(
    r"(\s+)document\.getElementById\('settingTradeTypeSizing'\)\.addEventListener\('change', \(e\) => \{",
    r"\1const settingTradeTypeSizing = document.getElementById('settingTradeTypeSizing'); if (settingTradeTypeSizing) settingTradeTypeSizing.addEventListener('change', (e) => {",
    content
)

# Line 16681: settingTradeTypeTargetSl
content = re.sub(
    r"(\s+)document\.getElementById\('settingTradeTypeTargetSl'\)\.addEventListener\('change', \(e\) => \{",
    r"\1const settingTradeTypeTargetSl = document.getElementById('settingTradeTypeTargetSl'); if (settingTradeTypeTargetSl) settingTradeTypeTargetSl.addEventListener('change', (e) => {",
    content
)

# Line 16685: settingAutoCalibrate
content = re.sub(
    r"(\s+)document\.getElementById\('settingAutoCalibrate'\)\.addEventListener\('change', \(e\) => \{",
    r"\1const settingAutoCalibrate = document.getElementById('settingAutoCalibrate'); if (settingAutoCalibrate) settingAutoCalibrate.addEventListener('change', (e) => {",
    content
)

# Line 16689: settingAutoCalibrateTargetWinRate
content = re.sub(
    r"(\s+)document\.getElementById\('settingAutoCalibrateTargetWinRate'\)\.addEventListener\('change', \(e\) => \{",
    r"\1const settingAutoCalibrateTargetWinRate = document.getElementById('settingAutoCalibrateTargetWinRate'); if (settingAutoCalibrateTargetWinRate) settingAutoCalibrateTargetWinRate.addEventListener('change', (e) => {",
    content
)

# Line 16824: settingAppearance${mode}
content = re.sub(
    r"(\s+)document\.getElementById\(`settingAppearance\$\{mode\}`\)\.addEventListener\('change', \(e\) => \{",
    r"\1const el = document.getElementById(`settingAppearance${mode}`); if (el) el.addEventListener('change', (e) => {",
    content
)

# Line 16828: settingSoundEntry
content = re.sub(
    r"(\s+)document\.getElementById\('settingSoundEntry'\)\.addEventListener\('change', \(e\) => fnoSettings\.set\(\{ soundEntryEnabled: e\.target\.checked \}\)\);",
    r"\1const settingSoundEntry = document.getElementById('settingSoundEntry'); if (settingSoundEntry) settingSoundEntry.addEventListener('change', (e) => fnoSettings.set({ soundEntryEnabled: e.target.checked }));",
    content
)

# Line 16829: settingSoundExit
content = re.sub(
    r"(\s+)document\.getElementById\('settingSoundExit'\)\.addEventListener\('change', \(e\) => fnoSettings\.set\(\{ soundExitEnabled: e\.target\.checked \}\)\);",
    r"\1const settingSoundExit = document.getElementById('settingSoundExit'); if (settingSoundExit) settingSoundExit.addEventListener('change', (e) => fnoSettings.set({ soundExitEnabled: e.target.checked }));",
    content
)

with open('fno-lab-core.js', 'w') as f:
    f.write(content)

print("Fixed event listener issues")
