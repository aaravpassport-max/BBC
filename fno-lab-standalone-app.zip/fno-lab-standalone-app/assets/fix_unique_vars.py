import re
import hashlib

with open('fno-lab-core.js', 'r') as f:
    content = f.read()

# Counter for unique variable names
counter = [0]

def make_unique_var(elem_id):
    counter[0] += 1
    safe_id = elem_id.replace('-', '_').replace('.', '_')
    return f"_elem_{safe_id}_{counter[0]}"

# Pattern: let _elem_xxx = document.getElementById('yyy'); if (_elem_xxx) _elem_xxx.PROP = ...
# Replace with unique variable names

def replace_elem_pattern(match):
    full_match = match.group(0)
    indent = match.group(1)
    elem_id = match.group(2)
    prop_access = match.group(3)  # e.g., ".innerHTML = " or ".textContent = " or ".style.xxx = "
    
    var_name = make_unique_var(elem_id)
    return f"{indent}let {var_name} = document.getElementById('{elem_id}'); if ({var_name}) {var_name}{prop_access}"

# Match the pattern we created: let _elem_ID = document.getElementById('ID'); if (_elem_ID) _elem_ID.PROP = 
pattern = r"(\s+)let _elem_[^=]+ = document\.getElementById\('([^']+)'\); if \([^)]+\) [^\.]+(\.\w+(?:\.\w+)?\s*=\s*)"

content = re.sub(pattern, replace_elem_pattern, content)

with open('fno-lab-core.js', 'w') as f:
    f.write(content)

print(f"Created {counter[0]} unique variable names")
