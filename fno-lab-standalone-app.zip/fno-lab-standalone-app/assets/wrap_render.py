with open('fno-lab-core.js', 'r') as f:
    lines = f.readlines()

# Find the render function and wrap its body
in_render = False
render_start = -1
brace_count = 0
insert_try = -1

for i, line in enumerate(lines):
    if 'function render(){' in line:
        in_render = True
        render_start = i
        insert_try = i + 1  # Insert try on next line
        brace_count = 1
        continue
    
    if in_render:
        # Count braces
        brace_count += line.count('{') - line.count('}')
        if brace_count == 0:
            # End of render function
            # Insert catch before the closing brace
            lines[i] = '} catch(renderErr) { console.warn("render() partial failure:", renderErr); }\n' + lines[i]
            break

# Insert try after function declaration
if insert_try > 0:
    indent = '  '
    lines[insert_try] = indent + 'try {\n' + lines[insert_try]

with open('fno-lab-core.js', 'w') as f:
    f.writelines(lines)

print("Wrapped render() function body in try-catch")
