import re

with open('fno-lab-core.js', 'r') as f:
    lines = f.readlines()

# We need to add null checks for all document.getElementById calls in loadSettingsIntoModal()
# and other places where innerHTML or properties are being set

in_load_settings = False
fixed_lines = []
i = 0

while i < len(lines):
    line = lines[i]
    
    # If we're in loadSettingsIntoModal function (around line 16540)
    if 'function loadSettingsIntoModal()' in line:
        in_load_settings = True
        fixed_lines.append(line)
        i += 1
        continue
    
    # Exit the function when we hit the closing brace at the appropriate level
    if in_load_settings and line.strip().startswith('}') and 'function' not in lines[i-1]:
        in_load_settings = False
    
    # Fix patterns like: document.getElementById('id').property = value
    # or: document.getElementById('id').property
    if in_load_settings and 'document.getElementById' in line and not line.strip().startswith('const '):
        # Match pattern: document.getElementById('xxx').yyy = zzz or .textContent = 
        match = re.match(r"(\s+)document\.getElementById\('([^']+)'\)\.(checked|textContent|value|style\.display)\s*=\s*(.+)", line)
        if match:
            indent, elem_id, prop, value = match.groups()
            # Create defensive version
            fixed_line = f"{indent}const elem_{elem_id.replace('-', '_')} = document.getElementById('{elem_id}'); if (elem_{elem_id.replace('-', '_')}) elem_{elem_id.replace('-', '_')}.{prop} = {value}"
            fixed_lines.append(fixed_line)
            i += 1
            continue
    
    fixed_lines.append(line)
    i += 1

with open('fno-lab-core.js', 'w') as f:
    f.writelines(fixed_lines)

print("Fixed loadSettingsIntoModal issues")
