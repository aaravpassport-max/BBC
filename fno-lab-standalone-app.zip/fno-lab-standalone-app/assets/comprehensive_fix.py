import re

with open('fno-lab-core.js', 'r') as f:
    content = f.read()

# Pattern 1: document.getElementById('id').innerHTML = ...
# Replace with: const el = document.getElementById('id'); if (el) el.innerHTML = ...
pattern1 = r"(\s+)(document\.getElementById\('([^']+)'\))\.innerHTML\s*=\s*"
def replace1(match):
    indent, get_elem, elem_id = match.groups()
    var_name = f"_elem_{elem_id.replace('-', '_').replace('.', '_')}"
    return f"{indent}const {var_name} = {get_elem}; if ({var_name}) {var_name}.innerHTML = "

content = re.sub(pattern1, replace1, content)

# Pattern 2: document.getElementById('id').textContent = ...
pattern2 = r"(\s+)(document\.getElementById\('([^']+)'\))\.textContent\s*=\s*"
def replace2(match):
    indent, get_elem, elem_id = match.groups()
    var_name = f"_elem_{elem_id.replace('-', '_').replace('.', '_')}"
    return f"{indent}const {var_name} = {get_elem}; if ({var_name}) {var_name}.textContent = "

content = re.sub(pattern2, replace2, content)

# Pattern 3: document.getElementById('id').style.xxx = ...
pattern3 = r"(\s+)(document\.getElementById\('([^']+)'\))\.style\.(\w+)\s*=\s*"
def replace3(match):
    indent, get_elem, elem_id, style_prop = match.groups()
    var_name = f"_elem_{elem_id.replace('-', '_').replace('.', '_')}"
    return f"{indent}const {var_name} = {get_elem}; if ({var_name}) {var_name}.style.{style_prop} = "

content = re.sub(pattern3, replace3, content)

with open('fno-lab-core.js', 'w') as f:
    f.write(content)

print("Applied comprehensive null-safety fixes")
