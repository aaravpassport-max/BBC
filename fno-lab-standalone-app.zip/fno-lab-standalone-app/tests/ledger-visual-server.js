'use strict';
/**
 * Minimal local server to visually exercise the real trade ledger UI +
 * loadTradeLedger() against a mock admin-ajax (optional slow journal_list).
 *
 *   node tests/ledger-visual-server.js
 *   open http://127.0.0.1:8767/
 */
const http = require('http');
const fs = require('fs');
const path = require('path');
const { URL } = require('url');

const ROOT = path.join(__dirname, '..');
const ASSETS = path.join(ROOT, 'assets');
const PORT = Number(process.env.FNO_LEDGER_VISUAL_PORT || 8767);
const JOURNAL_DELAY_MS = Number(process.env.FNO_MOCK_JOURNAL_DELAY_MS || 0);

let serverJournal = [];
let nextJournalId = 1;

function readAsset(name) {
  return fs.readFileSync(path.join(ASSETS, name), 'utf8');
}

function buildModuleBundle() {
  const parts = [
    readAsset('greeks-engine.js'),
    readAsset('fno-lab-core.js'),
    readAsset('trading-modes-engine.js'),
    readAsset('liquidity-behaviour-engine.js'),
    readAsset('trade-setup-engine.js'),
    readAsset('scalping-profit-engine.js'),
    readAsset('first-momentum-scalper-engine.js'),
    readAsset('strategy-diagnostic-report.js'),
  ];
  return parts.join('\n;\n');
}

const MODULE_BUNDLE = buildModuleBundle();

function harnessHtml() {
  return `<!DOCTYPE html>
<html lang="en"><head>
<meta charset="utf-8"><title>FNO Ledger visual harness</title>
<style>
body{margin:0;background:#0f172a;color:#e2e8f0;font-family:system-ui,sans-serif;padding:16px}
.card{background:#1e293b;border-radius:12px;padding:16px;margin-bottom:16px;max-width:1100px}
.btn{background:#2563eb;color:#fff;border:none;padding:8px 12px;border-radius:8px;margin-right:8px;cursor:pointer;font-weight:600}
#harnessStatus{font-size:12px;color:#94a3b8;margin-top:8px}
</style>
<link rel="stylesheet" href="data:text/css,${encodeURIComponent(`
#tradeLedgerTable{table-layout:fixed;width:100%;min-width:860px;font-size:11px;border:1px solid #1e293b;border-radius:10px;overflow:hidden}
#tradeLedgerTable thead th{font-size:10px;font-weight:700;text-transform:uppercase;color:#94a3b8;background:#0b1220}
#tradeLedgerTable td,#tradeLedgerTable th{padding:8px 6px;border-bottom:1px solid #111827}
`)}">
</head><body>
<h1>Trade ledger visual harness</h1>
<p style="color:#94a3b8;font-size:13px">Logged-in mock · journal_list delay ${JOURNAL_DELAY_MS}ms · uses real fno-lab-core.js loadTradeLedger()</p>
<div class="card">
<button type="button" class="btn" id="btnSimOpen">Simulate entry (open row)</button>
<button type="button" class="btn" id="btnSimClose">Simulate exit (closed row)</button>
<button type="button" class="btn" id="btnRefresh">Refresh ledger</button>
<div id="harnessStatus">Waiting for app boot…</div>
</div>
<div class="card">
<h3>Trade Ledger</h3>
<div id="tradeLedgerSummary" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:12px">Loading...</div>
<div style="overflow-x:auto">
<table style="width:100%;border-collapse:collapse" id="tradeLedgerTable">
<thead><tr>
<th>#</th><th>When (IST)</th><th>Symbol</th><th>Strike</th><th>Exit reason</th><th>Qty</th><th>Entry</th><th>Exit</th><th>Gross</th><th>Charges</th><th>Net</th><th>Status</th><th>Type</th>
</tr></thead>
<tbody id="tradeLedgerBody"><tr><td colspan="13" style="padding:10px;color:#64748b">Loading...</td></tr></tbody>
</table></div>
<div id="tradeLedgerFootnote" style="font-size:10px;color:#64748b;margin-top:8px"></div>
<div id="tradeLedgerChargesDetail"></div>
</div>
<select id="sym" style="display:none"><option value="NIFTY" selected>NIFTY</option></select>
<script>
window.FNO_AJAX = {
  url: 'http://127.0.0.1:${PORT}/wp-admin/admin-ajax.php',
  nonce: 'visual-harness-nonce',
  isLoggedIn: true
};
window.FNO_PLUGIN_VERSION = '16.37.34';
window.FNO_PLUGIN_INSTALL_ID = '16.37.34-ledger-instant-paint';
window.FNO_FACTORS_CATALOG = [];
localStorage.setItem('fno_mode_v8', '"paper"');
</script>
<script type="module">
${MODULE_BUNDLE}
</script>
<script>
(function(){
  const status = document.getElementById('harnessStatus');
  function waitForLedger(cb) {
    if (typeof window.__fnoLoadTradeLedger === 'function') { cb(); return; }
    setTimeout(() => waitForLedger(cb), 100);
  }
  waitForLedger(() => {
    status.textContent = 'Core loaded — use buttons to simulate trades.';
    document.getElementById('btnRefresh').onclick = () => window.__fnoLoadTradeLedger();
    document.getElementById('btnSimOpen').onclick = () => {
      const id = Date.now();
      const open = { id, symbol: 'NIFTY', strike: 25000, optionType: 'CE', entryPrice: 120, qty: 75, openedAt: Date.now(), tradingType: 'scalping' };
      localStorage.setItem('fno_autotrades_v8', JSON.stringify(open));
      const j = JSON.parse(localStorage.getItem('fno_journal_v8') || '[]');
      j.push({ ts: open.openedAt, openedAt: open.openedAt, openTradeId: id, symbol: 'NIFTY', strike: 25000, optionType: 'CE', action: 'POSITION_OPEN', entryPrice: 120, qty: 75, tradingType: 'scalping', ledgerPhase: 'open', source: 'auto', mode: 'paper' });
      localStorage.setItem('fno_journal_v8', JSON.stringify(j));
      window.__fnoLoadTradeLedger();
      status.textContent = 'Simulated OPEN — ledger refresh requested.';
    };
    document.getElementById('btnSimClose').onclick = () => {
      const open = JSON.parse(localStorage.getItem('fno_autotrades_v8') || '{}');
      const j = JSON.parse(localStorage.getItem('fno_journal_v8') || '[]');
      const filtered = j.filter(e => !(e.ledgerPhase === 'open' && e.openTradeId === open.id));
      const ts = Date.now();
      filtered.push({
        ts, openedAt: open.openedAt || ts - 60000, openTradeId: open.id,
        symbol: 'NIFTY', strike: 25000, optionType: 'CE', action: 'AUTO_TARGET_EXIT',
        entryPrice: 120, exitPrice: 135, qty: 75, pnl: 1020, grossPnl: 1125, costsTotal: 105,
        tradingType: 'scalping', id: 'local-' + ts
      });
      localStorage.setItem('fno_journal_v8', JSON.stringify(filtered));
      localStorage.setItem('fno_autotrades_v8', '{}');
      window.__fnoLoadTradeLedger();
      status.textContent = 'Simulated CLOSE — ledger refresh requested.';
    };
    window.__fnoLoadTradeLedger();
  });
})();
</script>
</body></html>`;
}

function json(res, obj) {
  res.writeHead(200, { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': '*' });
  res.end(JSON.stringify(obj));
}

const server = http.createServer((req, res) => {
  const url = new URL(req.url, `http://127.0.0.1:${PORT}`);
  if (url.pathname === '/' || url.pathname === '/index.html') {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' });
    res.end(harnessHtml());
    return;
  }
  if (url.pathname === '/wp-admin/admin-ajax.php') {
    const action = url.searchParams.get('action');
    if (action === 'fno_journal_list') {
      const run = () => json(res, { success: true, data: { journal: serverJournal } });
      if (JOURNAL_DELAY_MS > 0) setTimeout(run, JOURNAL_DELAY_MS);
      else run();
      return;
    }
    if (action === 'fno_get_paper_account') {
      json(res, { success: true, data: { startingCapital: 500000, balance: 500000 } });
      return;
    }
    json(res, { success: true, data: {} });
    return;
  }
  res.writeHead(404);
  res.end('not found');
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`Ledger visual harness: http://127.0.0.1:${PORT}/`);
  console.log(`Mock journal_list delay: ${JOURNAL_DELAY_MS}ms`);
});
