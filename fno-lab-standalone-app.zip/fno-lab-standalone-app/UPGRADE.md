# Upgrading F&O Lab (replace, do not add a new plugin)

Every release uses the **same zip name** and **same folder name** so updates replace your existing install instead of creating a second plugin.

| Item | Value |
|------|-------|
| Zip file | `fno-lab-standalone-app.zip` |
| Folder after extract | `wp-content/plugins/fno-lab-standalone-app/` |
| Version | shown in WordPress Plugins list and in the app header (not in the folder name) |
| **Expected zip size (v16.31.3+)** | **~1.9 MB (1,927,000+ bytes)** — if you see ~610 KB, the download is incomplete; use the release link below |

## Upgrade steps

1. WordPress **Plugins** → deactivate **F&O Lab - Standalone App**.
2. Delete **every** old copy under `wp-content/plugins/` whose name starts with `fno-lab-standalone-app` (including versioned folders like `fno-lab-standalone-app-v16.22.0`).
3. Upload `fno-lab-standalone-app.zip` to `wp-content/plugins/` and extract it there.
   - Correct result: `wp-content/plugins/fno-lab-standalone-app/fno-lab.php`
4. Activate **one** F&O Lab plugin.
5. Open the app and confirm the header shows the new version.

## Common mistake (creates duplicate plugins)

- Extracting a zip whose **filename** includes a version (for example `fno-lab-standalone-app-v16.22.0.zip`) into a **new** folder each time.
- WordPress then lists multiple F&O Lab plugins, which can cause fatal PHP errors (`Cannot redeclare …`).

Always use **`fno-lab-standalone-app.zip`** at the **repository root** (not a copy under `fno-lab/`) and keep a **single** folder: **`fno-lab-standalone-app`**.

## Download (v16.31.3 — use GitHub Release, not stale branch links)

**Recommended (pinned release asset):**  
https://github.com/aaravpassport-max/BBC/releases/download/v16.33.0/fno-lab-standalone-app.zip

**Alternate (commit-pinned raw):**  
https://raw.githubusercontent.com/aaravpassport-max/BBC/cursor/liquidity-trap-engine-439c/fno-lab-standalone-app.zip

Before installing, confirm the downloaded file is **~1.9 MB**. A ~610 KB file is a broken partial build and will miss `greeks-engine.js`, `fno-data-layer.php`, the autonomous driver, and other required components.

After install, WordPress **Plugins** and the app header must show the **same** version (e.g. **16.31.3**). If they differ, you installed an old zip — delete all `fno-lab-standalone-app*` folders and reinstall from the release link above.
