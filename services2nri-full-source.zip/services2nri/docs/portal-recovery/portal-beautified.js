var e = Object.create,
  t = Object.defineProperty,
  n = Object.getOwnPropertyDescriptor,
  r = Object.getOwnPropertyNames,
  i = Object.getPrototypeOf,
  a = Object.prototype.hasOwnProperty,
  o = (e, t) => () => (t || (e((t = {
    exports: {}
  }).exports, t), e = null), t.exports),
  s = (e, i, o, s) => {
    if (i && typeof i == `object` || typeof i == `function`)
      for (var c = r(i), l = 0, u = c.length, d; l < u; l++) d = c[l], !a.call(e, d) && d !== o && t(e, d, {
        get: (e => i[e]).bind(null, d),
        enumerable: !(s = n(i, d)) || s.enumerable
      });
    return e
  },
  c = (n, r, a) => (a = n == null ? {} : e(i(n)), s(r || !n || !n.__esModule ? t(a, `default`, {
    value: n,
    enumerable: !0
  }) : a, n));
(function() {
  let e = document.createElement(`link`).relList;
  if (e && e.supports && e.supports(`modulepreload`)) return;
  for (let e of document.querySelectorAll(`link[rel="modulepreload"]`)) n(e);
  new MutationObserver(e => {
    for (let t of e)
      if (t.type === `childList`)
        for (let e of t.addedNodes) e.tagName === `LINK` && e.rel === `modulepreload` && n(e)
  }).observe(document, {
    childList: !0,
    subtree: !0
  });

  function t(e) {
    let t = {};
    return e.integrity && (t.integrity = e.integrity), e.referrerPolicy && (t.referrerPolicy = e.referrerPolicy), e.crossOrigin === `use-credentials` ? t.credentials = `include` : e.crossOrigin === `anonymous` ? t.credentials = `omit` : t.credentials = `same-origin`, t
  }

  function n(e) {
    if (e.ep) return;
    e.ep = !0;
    let n = t(e);
    fetch(e.href, n)
  }
})();
var l = o((e => {
    var t = Symbol.for(`react.transitional.element`),
      n = Symbol.for(`react.portal`),
      r = Symbol.for(`react.fragment`),
      i = Symbol.for(`react.strict_mode`),
      a = Symbol.for(`react.profiler`),
      o = Symbol.for(`react.consumer`),
      s = Symbol.for(`react.context`),
      c = Symbol.for(`react.forward_ref`),
      l = Symbol.for(`react.suspense`),
      u = Symbol.for(`react.memo`),
      d = Symbol.for(`react.lazy`),
      f = Symbol.for(`react.activity`),
      p = Symbol.iterator;

    function m(e) {
      return typeof e != `object` || !e ? null : (e = p && e[p] || e[`@@iterator`], typeof e == `function` ? e : null)
    }
    var h = {
        isMounted: function() {
          return !1
        },
        enqueueForceUpdate: function() {},
        enqueueReplaceState: function() {},
        enqueueSetState: function() {}
      },
      g = Object.assign,
      _ = {};

    function v(e, t, n) {
      this.props = e, this.context = t, this.refs = _, this.updater = n || h
    }
    v.prototype.isReactComponent = {}, v.prototype.setState = function(e, t) {
      if (typeof e != `object` && typeof e != `function` && e != null) throw Error(`takes an object of state variables to update or a function which returns an object of state variables.`);
      this.updater.enqueueSetState(this, e, t, `setState`)
    }, v.prototype.forceUpdate = function(e) {
      this.updater.enqueueForceUpdate(this, e, `forceUpdate`)
    };

    function y() {}
    y.prototype = v.prototype;

    function b(e, t, n) {
      this.props = e, this.context = t, this.refs = _, this.updater = n || h
    }
    var x = b.prototype = new y;
    x.constructor = b, g(x, v.prototype), x.isPureReactComponent = !0;
    var S = Array.isArray;

    function C() {}
    var w = {
        H: null,
        A: null,
        T: null,
        S: null
      },
      T = Object.prototype.hasOwnProperty;

    function E(e, n, r) {
      var i = r.ref;
      return {
        $$typeof: t,
        type: e,
        key: n,
        ref: i === void 0 ? null : i,
        props: r
      }
    }

    function D(e, t) {
      return E(e.type, t, e.props)
    }

    function O(e) {
      return typeof e == `object` && !!e && e.$$typeof === t
    }

    function ee(e) {
      var t = {
        "=": `=0`,
        ":": `=2`
      };
      return `$` + e.replace(/[=:]/g, function(e) {
        return t[e]
      })
    }
    var te = /\/+/g;

    function k(e, t) {
      return typeof e == `object` && e && e.key != null ? ee(`` + e.key) : t.toString(36)
    }

    function ne(e) {
      switch (e.status) {
        case `fulfilled`:
          return e.value;
        case `rejected`:
          throw e.reason;
        default:
          switch (typeof e.status == `string` ? e.then(C, C) : (e.status = `pending`, e.then(function(t) {
              e.status === `pending` && (e.status = `fulfilled`, e.value = t)
            }, function(t) {
              e.status === `pending` && (e.status = `rejected`, e.reason = t)
            })), e.status) {
            case `fulfilled`:
              return e.value;
            case `rejected`:
              throw e.reason
          }
      }
      throw e
    }

    function re(e, r, i, a, o) {
      var s = typeof e;
      (s === `undefined` || s === `boolean`) && (e = null);
      var c = !1;
      if (e === null) c = !0;
      else switch (s) {
        case `bigint`:
        case `string`:
        case `number`:
          c = !0;
          break;
        case `object`:
          switch (e.$$typeof) {
            case t:
            case n:
              c = !0;
              break;
            case d:
              return c = e._init, re(c(e._payload), r, i, a, o)
          }
      }
      if (c) return o = o(e), c = a === `` ? `.` + k(e, 0) : a, S(o) ? (i = ``, c != null && (i = c.replace(te, `$&/`) + `/`), re(o, r, i, ``, function(e) {
        return e
      })) : o != null && (O(o) && (o = D(o, i + (o.key == null || e && e.key === o.key ? `` : (`` + o.key).replace(te, `$&/`) + `/`) + c)), r.push(o)), 1;
      c = 0;
      var l = a === `` ? `.` : a + `:`;
      if (S(e))
        for (var u = 0; u < e.length; u++) a = e[u], s = l + k(a, u), c += re(a, r, i, s, o);
      else if (u = m(e), typeof u == `function`)
        for (e = u.call(e), u = 0; !(a = e.next()).done;) a = a.value, s = l + k(a, u++), c += re(a, r, i, s, o);
      else if (s === `object`) {
        if (typeof e.then == `function`) return re(ne(e), r, i, a, o);
        throw r = String(e), Error(`Objects are not valid as a React child (found: ` + (r === `[object Object]` ? `object with keys {` + Object.keys(e).join(`, `) + `}` : r) + `). If you meant to render a collection of children, use an array instead.`)
      }
      return c
    }

    function ie(e, t, n) {
      if (e == null) return e;
      var r = [],
        i = 0;
      return re(e, r, ``, ``, function(e) {
        return t.call(n, e, i++)
      }), r
    }

    function ae(e) {
      if (e._status === -1) {
        var t = e._result;
        t = t(), t.then(function(t) {
          (e._status === 0 || e._status === -1) && (e._status = 1, e._result = t)
        }, function(t) {
          (e._status === 0 || e._status === -1) && (e._status = 2, e._result = t)
        }), e._status === -1 && (e._status = 0, e._result = t)
      }
      if (e._status === 1) return e._result.default;
      throw e._result
    }
    var A = typeof reportError == `function` ? reportError : function(e) {
        if (typeof window == `object` && typeof window.ErrorEvent == `function`) {
          var t = new window.ErrorEvent(`error`, {
            bubbles: !0,
            cancelable: !0,
            message: typeof e == `object` && e && typeof e.message == `string` ? String(e.message) : String(e),
            error: e
          });
          if (!window.dispatchEvent(t)) return
        } else if (typeof process == `object` && typeof process.emit == `function`) {
          process.emit(`uncaughtException`, e);
          return
        }
        console.error(e)
      },
      j = {
        map: ie,
        forEach: function(e, t, n) {
          ie(e, function() {
            t.apply(this, arguments)
          }, n)
        },
        count: function(e) {
          var t = 0;
          return ie(e, function() {
            t++
          }), t
        },
        toArray: function(e) {
          return ie(e, function(e) {
            return e
          }) || []
        },
        only: function(e) {
          if (!O(e)) throw Error(`React.Children.only expected to receive a single React element child.`);
          return e
        }
      };
    e.Activity = f, e.Children = j, e.Component = v, e.Fragment = r, e.Profiler = a, e.PureComponent = b, e.StrictMode = i, e.Suspense = l, e.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = w, e.__COMPILER_RUNTIME = {
      __proto__: null,
      c: function(e) {
        return w.H.useMemoCache(e)
      }
    }, e.cache = function(e) {
      return function() {
        return e.apply(null, arguments)
      }
    }, e.cacheSignal = function() {
      return null
    }, e.cloneElement = function(e, t, n) {
      if (e == null) throw Error(`The argument must be a React element, but you passed ` + e + `.`);
      var r = g({}, e.props),
        i = e.key;
      if (t != null)
        for (a in t.key !== void 0 && (i = `` + t.key), t) !T.call(t, a) || a === `key` || a === `__self` || a === `__source` || a === `ref` && t.ref === void 0 || (r[a] = t[a]);
      var a = arguments.length - 2;
      if (a === 1) r.children = n;
      else if (1 < a) {
        for (var o = Array(a), s = 0; s < a; s++) o[s] = arguments[s + 2];
        r.children = o
      }
      return E(e.type, i, r)
    }, e.createContext = function(e) {
      return e = {
        $$typeof: s,
        _currentValue: e,
        _currentValue2: e,
        _threadCount: 0,
        Provider: null,
        Consumer: null
      }, e.Provider = e, e.Consumer = {
        $$typeof: o,
        _context: e
      }, e
    }, e.createElement = function(e, t, n) {
      var r, i = {},
        a = null;
      if (t != null)
        for (r in t.key !== void 0 && (a = `` + t.key), t) T.call(t, r) && r !== `key` && r !== `__self` && r !== `__source` && (i[r] = t[r]);
      var o = arguments.length - 2;
      if (o === 1) i.children = n;
      else if (1 < o) {
        for (var s = Array(o), c = 0; c < o; c++) s[c] = arguments[c + 2];
        i.children = s
      }
      if (e && e.defaultProps)
        for (r in o = e.defaultProps, o) i[r] === void 0 && (i[r] = o[r]);
      return E(e, a, i)
    }, e.createRef = function() {
      return {
        current: null
      }
    }, e.forwardRef = function(e) {
      return {
        $$typeof: c,
        render: e
      }
    }, e.isValidElement = O, e.lazy = function(e) {
      return {
        $$typeof: d,
        _payload: {
          _status: -1,
          _result: e
        },
        _init: ae
      }
    }, e.memo = function(e, t) {
      return {
        $$typeof: u,
        type: e,
        compare: t === void 0 ? null : t
      }
    }, e.startTransition = function(e) {
      var t = w.T,
        n = {};
      w.T = n;
      try {
        var r = e(),
          i = w.S;
        i !== null && i(n, r), typeof r == `object` && r && typeof r.then == `function` && r.then(C, A)
      } catch (e) {
        A(e)
      } finally {
        t !== null && n.types !== null && (t.types = n.types), w.T = t
      }
    }, e.unstable_useCacheRefresh = function() {
      return w.H.useCacheRefresh()
    }, e.use = function(e) {
      return w.H.use(e)
    }, e.useActionState = function(e, t, n) {
      return w.H.useActionState(e, t, n)
    }, e.useCallback = function(e, t) {
      return w.H.useCallback(e, t)
    }, e.useContext = function(e) {
      return w.H.useContext(e)
    }, e.useDebugValue = function() {}, e.useDeferredValue = function(e, t) {
      return w.H.useDeferredValue(e, t)
    }, e.useEffect = function(e, t) {
      return w.H.useEffect(e, t)
    }, e.useEffectEvent = function(e) {
      return w.H.useEffectEvent(e)
    }, e.useId = function() {
      return w.H.useId()
    }, e.useImperativeHandle = function(e, t, n) {
      return w.H.useImperativeHandle(e, t, n)
    }, e.useInsertionEffect = function(e, t) {
      return w.H.useInsertionEffect(e, t)
    }, e.useLayoutEffect = function(e, t) {
      return w.H.useLayoutEffect(e, t)
    }, e.useMemo = function(e, t) {
      return w.H.useMemo(e, t)
    }, e.useOptimistic = function(e, t) {
      return w.H.useOptimistic(e, t)
    }, e.useReducer = function(e, t, n) {
      return w.H.useReducer(e, t, n)
    }, e.useRef = function(e) {
      return w.H.useRef(e)
    }, e.useState = function(e) {
      return w.H.useState(e)
    }, e.useSyncExternalStore = function(e, t, n) {
      return w.H.useSyncExternalStore(e, t, n)
    }, e.useTransition = function() {
      return w.H.useTransition()
    }, e.version = `19.2.7`
  })),
  u = o(((e, t) => {
    t.exports = l()
  })),
  d = o((e => {
    function t(e, t) {
      var n = e.length;
      e.push(t);
      a: for (; 0 < n;) {
        var r = n - 1 >>> 1,
          a = e[r];
        if (0 < i(a, t)) e[r] = t, e[n] = a, n = r;
        else break a
      }
    }

    function n(e) {
      return e.length === 0 ? null : e[0]
    }

    function r(e) {
      if (e.length === 0) return null;
      var t = e[0],
        n = e.pop();
      if (n !== t) {
        e[0] = n;
        a: for (var r = 0, a = e.length, o = a >>> 1; r < o;) {
          var s = 2 * (r + 1) - 1,
            c = e[s],
            l = s + 1,
            u = e[l];
          if (0 > i(c, n)) l < a && 0 > i(u, c) ? (e[r] = u, e[l] = n, r = l) : (e[r] = c, e[s] = n, r = s);
          else if (l < a && 0 > i(u, n)) e[r] = u, e[l] = n, r = l;
          else break a
        }
      }
      return t
    }

    function i(e, t) {
      var n = e.sortIndex - t.sortIndex;
      return n === 0 ? e.id - t.id : n
    }
    if (e.unstable_now = void 0, typeof performance == `object` && typeof performance.now == `function`) {
      var a = performance;
      e.unstable_now = function() {
        return a.now()
      }
    } else {
      var o = Date,
        s = o.now();
      e.unstable_now = function() {
        return o.now() - s
      }
    }
    var c = [],
      l = [],
      u = 1,
      d = null,
      f = 3,
      p = !1,
      m = !1,
      h = !1,
      g = !1,
      _ = typeof setTimeout == `function` ? setTimeout : null,
      v = typeof clearTimeout == `function` ? clearTimeout : null,
      y = typeof setImmediate < `u` ? setImmediate : null;

    function b(e) {
      for (var i = n(l); i !== null;) {
        if (i.callback === null) r(l);
        else if (i.startTime <= e) r(l), i.sortIndex = i.expirationTime, t(c, i);
        else break;
        i = n(l)
      }
    }

    function x(e) {
      if (h = !1, b(e), !m)
        if (n(c) !== null) m = !0, S || (S = !0, O());
        else {
          var t = n(l);
          t !== null && k(x, t.startTime - e)
        }
    }
    var S = !1,
      C = -1,
      w = 5,
      T = -1;

    function E() {
      return g ? !0 : !(e.unstable_now() - T < w)
    }

    function D() {
      if (g = !1, S) {
        var t = e.unstable_now();
        T = t;
        var i = !0;
        try {
          a: {
            m = !1,
            h && (h = !1, v(C), C = -1),
            p = !0;
            var a = f;
            try {
              b: {
                for (b(t), d = n(c); d !== null && !(d.expirationTime > t && E());) {
                  var o = d.callback;
                  if (typeof o == `function`) {
                    d.callback = null, f = d.priorityLevel;
                    var s = o(d.expirationTime <= t);
                    if (t = e.unstable_now(), typeof s == `function`) {
                      d.callback = s, b(t), i = !0;
                      break b
                    }
                    d === n(c) && r(c), b(t)
                  } else r(c);
                  d = n(c)
                }
                if (d !== null) i = !0;
                else {
                  var u = n(l);
                  u !== null && k(x, u.startTime - t), i = !1
                }
              }
              break a
            }
            finally {
              d = null, f = a, p = !1
            }
            i = void 0
          }
        }
        finally {
          i ? O() : S = !1
        }
      }
    }
    var O;
    if (typeof y == `function`) O = function() {
      y(D)
    };
    else if (typeof MessageChannel < `u`) {
      var ee = new MessageChannel,
        te = ee.port2;
      ee.port1.onmessage = D, O = function() {
        te.postMessage(null)
      }
    } else O = function() {
      _(D, 0)
    };

    function k(t, n) {
      C = _(function() {
        t(e.unstable_now())
      }, n)
    }
    e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(e) {
      e.callback = null
    }, e.unstable_forceFrameRate = function(e) {
      0 > e || 125 < e ? console.error(`forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported`) : w = 0 < e ? Math.floor(1e3 / e) : 5
    }, e.unstable_getCurrentPriorityLevel = function() {
      return f
    }, e.unstable_next = function(e) {
      switch (f) {
        case 1:
        case 2:
        case 3:
          var t = 3;
          break;
        default:
          t = f
      }
      var n = f;
      f = t;
      try {
        return e()
      } finally {
        f = n
      }
    }, e.unstable_requestPaint = function() {
      g = !0
    }, e.unstable_runWithPriority = function(e, t) {
      switch (e) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
          break;
        default:
          e = 3
      }
      var n = f;
      f = e;
      try {
        return t()
      } finally {
        f = n
      }
    }, e.unstable_scheduleCallback = function(r, i, a) {
      var o = e.unstable_now();
      switch (typeof a == `object` && a ? (a = a.delay, a = typeof a == `number` && 0 < a ? o + a : o) : a = o, r) {
        case 1:
          var s = -1;
          break;
        case 2:
          s = 250;
          break;
        case 5:
          s = 1073741823;
          break;
        case 4:
          s = 1e4;
          break;
        default:
          s = 5e3
      }
      return s = a + s, r = {
        id: u++,
        callback: i,
        priorityLevel: r,
        startTime: a,
        expirationTime: s,
        sortIndex: -1
      }, a > o ? (r.sortIndex = a, t(l, r), n(c) === null && r === n(l) && (h ? (v(C), C = -1) : h = !0, k(x, a - o))) : (r.sortIndex = s, t(c, r), m || p || (m = !0, S || (S = !0, O()))), r
    }, e.unstable_shouldYield = E, e.unstable_wrapCallback = function(e) {
      var t = f;
      return function() {
        var n = f;
        f = t;
        try {
          return e.apply(this, arguments)
        } finally {
          f = n
        }
      }
    }
  })),
  f = o(((e, t) => {
    t.exports = d()
  })),
  p = o((e => {
    var t = u();

    function n(e) {
      var t = `https://react.dev/errors/` + e;
      if (1 < arguments.length) {
        t += `?args[]=` + encodeURIComponent(arguments[1]);
        for (var n = 2; n < arguments.length; n++) t += `&args[]=` + encodeURIComponent(arguments[n])
      }
      return `Minified React error #` + e + `; visit ` + t + ` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`
    }

    function r() {}
    var i = {
        d: {
          f: r,
          r: function() {
            throw Error(n(522))
          },
          D: r,
          C: r,
          L: r,
          m: r,
          X: r,
          S: r,
          M: r
        },
        p: 0,
        findDOMNode: null
      },
      a = Symbol.for(`react.portal`);

    function o(e, t, n) {
      var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
      return {
        $$typeof: a,
        key: r == null ? null : `` + r,
        children: e,
        containerInfo: t,
        implementation: n
      }
    }
    var s = t.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;

    function c(e, t) {
      if (e === `font`) return ``;
      if (typeof t == `string`) return t === `use-credentials` ? t : ``
    }
    e.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = i, e.createPortal = function(e, t) {
      var r = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
      if (!t || t.nodeType !== 1 && t.nodeType !== 9 && t.nodeType !== 11) throw Error(n(299));
      return o(e, t, null, r)
    }, e.flushSync = function(e) {
      var t = s.T,
        n = i.p;
      try {
        if (s.T = null, i.p = 2, e) return e()
      } finally {
        s.T = t, i.p = n, i.d.f()
      }
    }, e.preconnect = function(e, t) {
      typeof e == `string` && (t ? (t = t.crossOrigin, t = typeof t == `string` ? t === `use-credentials` ? t : `` : void 0) : t = null, i.d.C(e, t))
    }, e.prefetchDNS = function(e) {
      typeof e == `string` && i.d.D(e)
    }, e.preinit = function(e, t) {
      if (typeof e == `string` && t && typeof t.as == `string`) {
        var n = t.as,
          r = c(n, t.crossOrigin),
          a = typeof t.integrity == `string` ? t.integrity : void 0,
          o = typeof t.fetchPriority == `string` ? t.fetchPriority : void 0;
        n === `style` ? i.d.S(e, typeof t.precedence == `string` ? t.precedence : void 0, {
          crossOrigin: r,
          integrity: a,
          fetchPriority: o
        }) : n === `script` && i.d.X(e, {
          crossOrigin: r,
          integrity: a,
          fetchPriority: o,
          nonce: typeof t.nonce == `string` ? t.nonce : void 0
        })
      }
    }, e.preinitModule = function(e, t) {
      if (typeof e == `string`)
        if (typeof t == `object` && t) {
          if (t.as == null || t.as === `script`) {
            var n = c(t.as, t.crossOrigin);
            i.d.M(e, {
              crossOrigin: n,
              integrity: typeof t.integrity == `string` ? t.integrity : void 0,
              nonce: typeof t.nonce == `string` ? t.nonce : void 0
            })
          }
        } else t ?? i.d.M(e)
    }, e.preload = function(e, t) {
      if (typeof e == `string` && typeof t == `object` && t && typeof t.as == `string`) {
        var n = t.as,
          r = c(n, t.crossOrigin);
        i.d.L(e, n, {
          crossOrigin: r,
          integrity: typeof t.integrity == `string` ? t.integrity : void 0,
          nonce: typeof t.nonce == `string` ? t.nonce : void 0,
          type: typeof t.type == `string` ? t.type : void 0,
          fetchPriority: typeof t.fetchPriority == `string` ? t.fetchPriority : void 0,
          referrerPolicy: typeof t.referrerPolicy == `string` ? t.referrerPolicy : void 0,
          imageSrcSet: typeof t.imageSrcSet == `string` ? t.imageSrcSet : void 0,
          imageSizes: typeof t.imageSizes == `string` ? t.imageSizes : void 0,
          media: typeof t.media == `string` ? t.media : void 0
        })
      }
    }, e.preloadModule = function(e, t) {
      if (typeof e == `string`)
        if (t) {
          var n = c(t.as, t.crossOrigin);
          i.d.m(e, {
            as: typeof t.as == `string` && t.as !== `script` ? t.as : void 0,
            crossOrigin: n,
            integrity: typeof t.integrity == `string` ? t.integrity : void 0
          })
        } else i.d.m(e)
    }, e.requestFormReset = function(e) {
      i.d.r(e)
    }, e.unstable_batchedUpdates = function(e, t) {
      return e(t)
    }, e.useFormState = function(e, t, n) {
      return s.H.useFormState(e, t, n)
    }, e.useFormStatus = function() {
      return s.H.useHostTransitionStatus()
    }, e.version = `19.2.7`
  })),
  m = o(((e, t) => {
    function n() {
      if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > `u` || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != `function`)) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)
      } catch (e) {
        console.error(e)
      }
    }
    n(), t.exports = p()
  })),
  h = o((e => {
    var t = f(),
      n = u(),
      r = m();

    function i(e) {
      var t = `https://react.dev/errors/` + e;
      if (1 < arguments.length) {
        t += `?args[]=` + encodeURIComponent(arguments[1]);
        for (var n = 2; n < arguments.length; n++) t += `&args[]=` + encodeURIComponent(arguments[n])
      }
      return `Minified React error #` + e + `; visit ` + t + ` for the full message or use the non-minified dev environment for full errors and additional helpful warnings.`
    }

    function a(e) {
      return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
    }

    function o(e) {
      var t = e,
        n = e;
      if (e.alternate)
        for (; t.return;) t = t.return;
      else {
        e = t;
        do t = e, t.flags & 4098 && (n = t.return), e = t.return; while (e)
      }
      return t.tag === 3 ? n : null
    }

    function s(e) {
      if (e.tag === 13) {
        var t = e.memoizedState;
        if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
      }
      return null
    }

    function c(e) {
      if (e.tag === 31) {
        var t = e.memoizedState;
        if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
      }
      return null
    }

    function l(e) {
      if (o(e) !== e) throw Error(i(188))
    }

    function d(e) {
      var t = e.alternate;
      if (!t) {
        if (t = o(e), t === null) throw Error(i(188));
        return t === e ? e : null
      }
      for (var n = e, r = t;;) {
        var a = n.return;
        if (a === null) break;
        var s = a.alternate;
        if (s === null) {
          if (r = a.return, r !== null) {
            n = r;
            continue
          }
          break
        }
        if (a.child === s.child) {
          for (s = a.child; s;) {
            if (s === n) return l(a), e;
            if (s === r) return l(a), t;
            s = s.sibling
          }
          throw Error(i(188))
        }
        if (n.return !== r.return) n = a, r = s;
        else {
          for (var c = !1, u = a.child; u;) {
            if (u === n) {
              c = !0, n = a, r = s;
              break
            }
            if (u === r) {
              c = !0, r = a, n = s;
              break
            }
            u = u.sibling
          }
          if (!c) {
            for (u = s.child; u;) {
              if (u === n) {
                c = !0, n = s, r = a;
                break
              }
              if (u === r) {
                c = !0, r = s, n = a;
                break
              }
              u = u.sibling
            }
            if (!c) throw Error(i(189))
          }
        }
        if (n.alternate !== r) throw Error(i(190))
      }
      if (n.tag !== 3) throw Error(i(188));
      return n.stateNode.current === n ? e : t
    }

    function p(e) {
      var t = e.tag;
      if (t === 5 || t === 26 || t === 27 || t === 6) return e;
      for (e = e.child; e !== null;) {
        if (t = p(e), t !== null) return t;
        e = e.sibling
      }
      return null
    }
    var h = Object.assign,
      g = Symbol.for(`react.element`),
      _ = Symbol.for(`react.transitional.element`),
      v = Symbol.for(`react.portal`),
      y = Symbol.for(`react.fragment`),
      b = Symbol.for(`react.strict_mode`),
      x = Symbol.for(`react.profiler`),
      S = Symbol.for(`react.consumer`),
      C = Symbol.for(`react.context`),
      w = Symbol.for(`react.forward_ref`),
      T = Symbol.for(`react.suspense`),
      E = Symbol.for(`react.suspense_list`),
      D = Symbol.for(`react.memo`),
      O = Symbol.for(`react.lazy`),
      ee = Symbol.for(`react.activity`),
      te = Symbol.for(`react.memo_cache_sentinel`),
      k = Symbol.iterator;

    function ne(e) {
      return typeof e != `object` || !e ? null : (e = k && e[k] || e[`@@iterator`], typeof e == `function` ? e : null)
    }
    var re = Symbol.for(`react.client.reference`);

    function ie(e) {
      if (e == null) return null;
      if (typeof e == `function`) return e.$$typeof === re ? null : e.displayName || e.name || null;
      if (typeof e == `string`) return e;
      switch (e) {
        case y:
          return `Fragment`;
        case x:
          return `Profiler`;
        case b:
          return `StrictMode`;
        case T:
          return `Suspense`;
        case E:
          return `SuspenseList`;
        case ee:
          return `Activity`
      }
      if (typeof e == `object`) switch (e.$$typeof) {
        case v:
          return `Portal`;
        case C:
          return e.displayName || `Context`;
        case S:
          return (e._context.displayName || `Context`) + `.Consumer`;
        case w:
          var t = e.render;
          return e = e.displayName, e ||= (e = t.displayName || t.name || ``, e === `` ? `ForwardRef` : `ForwardRef(` + e + `)`), e;
        case D:
          return t = e.displayName || null, t === null ? ie(e.type) || `Memo` : t;
        case O:
          t = e._payload, e = e._init;
          try {
            return ie(e(t))
          } catch {}
      }
      return null
    }
    var ae = Array.isArray,
      A = n.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
      j = r.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,
      oe = {
        pending: !1,
        data: null,
        method: null,
        action: null
      },
      se = [],
      ce = -1;

    function le(e) {
      return {
        current: e
      }
    }

    function ue(e) {
      0 > ce || (e.current = se[ce], se[ce] = null, ce--)
    }

    function M(e, t) {
      ce++, se[ce] = e.current, e.current = t
    }
    var de = le(null),
      fe = le(null),
      pe = le(null),
      me = le(null);

    function he(e, t) {
      switch (M(pe, t), M(fe, e), M(de, null), t.nodeType) {
        case 9:
        case 11:
          e = (e = t.documentElement) && (e = e.namespaceURI) ? Vd(e) : 0;
          break;
        default:
          if (e = t.tagName, t = t.namespaceURI) t = Vd(t), e = Hd(t, e);
          else switch (e) {
            case `svg`:
              e = 1;
              break;
            case `math`:
              e = 2;
              break;
            default:
              e = 0
          }
      }
      ue(de), M(de, e)
    }

    function ge() {
      ue(de), ue(fe), ue(pe)
    }

    function _e(e) {
      e.memoizedState !== null && M(me, e);
      var t = de.current,
        n = Hd(t, e.type);
      t !== n && (M(fe, e), M(de, n))
    }

    function ve(e) {
      fe.current === e && (ue(de), ue(fe)), me.current === e && (ue(me), Qf._currentValue = oe)
    }
    var ye, be;

    function xe(e) {
      if (ye === void 0) try {
        throw Error()
      } catch (e) {
        var t = e.stack.trim().match(/\n( *(at )?)/);
        ye = t && t[1] || ``, be = -1 < e.stack.indexOf(`
    at`) ? ` (<anonymous>)` : -1 < e.stack.indexOf(`@`) ? `@unknown:0:0` : ``
      }
      return `
` + ye + e + be
    }
    var Se = !1;

    function Ce(e, t) {
      if (!e || Se) return ``;
      Se = !0;
      var n = Error.prepareStackTrace;
      Error.prepareStackTrace = void 0;
      try {
        var r = {
          DetermineComponentFrameRoot: function() {
            try {
              if (t) {
                var n = function() {
                  throw Error()
                };
                if (Object.defineProperty(n.prototype, "props", {
                    set: function() {
                      throw Error()
                    }
                  }), typeof Reflect == `object` && Reflect.construct) {
                  try {
                    Reflect.construct(n, [])
                  } catch (e) {
                    var r = e
                  }
                  Reflect.construct(e, [], n)
                } else {
                  try {
                    n.call()
                  } catch (e) {
                    r = e
                  }
                  e.call(n.prototype)
                }
              } else {
                try {
                  throw Error()
                } catch (e) {
                  r = e
                }(n = e()) && typeof n.catch == `function` && n.catch(function() {})
              }
            } catch (e) {
              if (e && r && typeof e.stack == `string`) return [e.stack, r.stack]
            }
            return [null, null]
          }
        };
        r.DetermineComponentFrameRoot.displayName = `DetermineComponentFrameRoot`;
        var i = Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot, `name`);
        i && i.configurable && Object.defineProperty(r.DetermineComponentFrameRoot, "name", {
          value: `DetermineComponentFrameRoot`
        });
        var a = r.DetermineComponentFrameRoot(),
          o = a[0],
          s = a[1];
        if (o && s) {
          var c = o.split(`
`),
            l = s.split(`
`);
          for (i = r = 0; r < c.length && !c[r].includes(`DetermineComponentFrameRoot`);) r++;
          for (; i < l.length && !l[i].includes(`DetermineComponentFrameRoot`);) i++;
          if (r === c.length || i === l.length)
            for (r = c.length - 1, i = l.length - 1; 1 <= r && 0 <= i && c[r] !== l[i];) i--;
          for (; 1 <= r && 0 <= i; r--, i--)
            if (c[r] !== l[i]) {
              if (r !== 1 || i !== 1)
                do
                  if (r--, i--, 0 > i || c[r] !== l[i]) {
                    var u = `
` + c[r].replace(` at new `, ` at `);
                    return e.displayName && u.includes(`<anonymous>`) && (u = u.replace(`<anonymous>`, e.displayName)), u
                  } while (1 <= r && 0 <= i);
              break
            }
        }
      } finally {
        Se = !1, Error.prepareStackTrace = n
      }
      return (n = e ? e.displayName || e.name : ``) ? xe(n) : ``
    }

    function we(e, t) {
      switch (e.tag) {
        case 26:
        case 27:
        case 5:
          return xe(e.type);
        case 16:
          return xe(`Lazy`);
        case 13:
          return e.child !== t && t !== null ? xe(`Suspense Fallback`) : xe(`Suspense`);
        case 19:
          return xe(`SuspenseList`);
        case 0:
        case 15:
          return Ce(e.type, !1);
        case 11:
          return Ce(e.type.render, !1);
        case 1:
          return Ce(e.type, !0);
        case 31:
          return xe(`Activity`);
        default:
          return ``
      }
    }

    function Te(e) {
      try {
        var t = ``,
          n = null;
        do t += we(e, n), n = e, e = e.return; while (e);
        return t
      } catch (e) {
        return `
Error generating stack: ` + e.message + `
` + e.stack
      }
    }
    var Ee = Object.prototype.hasOwnProperty,
      De = t.unstable_scheduleCallback,
      Oe = t.unstable_cancelCallback,
      ke = t.unstable_shouldYield,
      Ae = t.unstable_requestPaint,
      je = t.unstable_now,
      Me = t.unstable_getCurrentPriorityLevel,
      Ne = t.unstable_ImmediatePriority,
      Pe = t.unstable_UserBlockingPriority,
      Fe = t.unstable_NormalPriority,
      Ie = t.unstable_LowPriority,
      Le = t.unstable_IdlePriority,
      Re = t.log,
      ze = t.unstable_setDisableYieldValue,
      Be = null,
      Ve = null;

    function He(e) {
      if (typeof Re == `function` && ze(e), Ve && typeof Ve.setStrictMode == `function`) try {
        Ve.setStrictMode(Be, e)
      } catch {}
    }
    var Ue = Math.clz32 ? Math.clz32 : Ke,
      We = Math.log,
      Ge = Math.LN2;

    function Ke(e) {
      return e >>>= 0, e === 0 ? 32 : 31 - (We(e) / Ge | 0) | 0
    }
    var qe = 256,
      Je = 262144,
      Ye = 4194304;

    function Xe(e) {
      var t = e & 42;
      if (t !== 0) return t;
      switch (e & -e) {
        case 1:
          return 1;
        case 2:
          return 2;
        case 4:
          return 4;
        case 8:
          return 8;
        case 16:
          return 16;
        case 32:
          return 32;
        case 64:
          return 64;
        case 128:
          return 128;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
          return e & 261888;
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return e & 3932160;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return e & 62914560;
        case 67108864:
          return 67108864;
        case 134217728:
          return 134217728;
        case 268435456:
          return 268435456;
        case 536870912:
          return 536870912;
        case 1073741824:
          return 0;
        default:
          return e
      }
    }

    function Ze(e, t, n) {
      var r = e.pendingLanes;
      if (r === 0) return 0;
      var i = 0,
        a = e.suspendedLanes,
        o = e.pingedLanes;
      e = e.warmLanes;
      var s = r & 134217727;
      return s === 0 ? (s = r & ~a, s === 0 ? o === 0 ? n || (n = r & ~e, n !== 0 && (i = Xe(n))) : i = Xe(o) : i = Xe(s)) : (r = s & ~a, r === 0 ? (o &= s, o === 0 ? n || (n = s & ~e, n !== 0 && (i = Xe(n))) : i = Xe(o)) : i = Xe(r)), i === 0 ? 0 : t !== 0 && t !== i && (t & a) === 0 && (a = i & -i, n = t & -t, a >= n || a === 32 && n & 4194048) ? t : i
    }

    function Qe(e, t) {
      return (e.pendingLanes & ~(e.suspendedLanes & ~e.pingedLanes) & t) === 0
    }

    function $e(e, t) {
      switch (e) {
        case 1:
        case 2:
        case 4:
        case 8:
        case 64:
          return t + 250;
        case 16:
        case 32:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
          return t + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          return -1;
        case 67108864:
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
          return -1;
        default:
          return -1
      }
    }

    function et() {
      var e = Ye;
      return Ye <<= 1, !(Ye & 62914560) && (Ye = 4194304), e
    }

    function tt(e) {
      for (var t = [], n = 0; 31 > n; n++) t.push(e);
      return t
    }

    function nt(e, t) {
      e.pendingLanes |= t, t !== 268435456 && (e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0)
    }

    function rt(e, t, n, r, i, a) {
      var o = e.pendingLanes;
      e.pendingLanes = n, e.suspendedLanes = 0, e.pingedLanes = 0, e.warmLanes = 0, e.expiredLanes &= n, e.entangledLanes &= n, e.errorRecoveryDisabledLanes &= n, e.shellSuspendCounter = 0;
      var s = e.entanglements,
        c = e.expirationTimes,
        l = e.hiddenUpdates;
      for (n = o & ~n; 0 < n;) {
        var u = 31 - Ue(n),
          d = 1 << u;
        s[u] = 0, c[u] = -1;
        var f = l[u];
        if (f !== null)
          for (l[u] = null, u = 0; u < f.length; u++) {
            var p = f[u];
            p !== null && (p.lane &= -536870913)
          }
        n &= ~d
      }
      r !== 0 && it(e, r, 0), a !== 0 && i === 0 && e.tag !== 0 && (e.suspendedLanes |= a & ~(o & ~t))
    }

    function it(e, t, n) {
      e.pendingLanes |= t, e.suspendedLanes &= ~t;
      var r = 31 - Ue(t);
      e.entangledLanes |= t, e.entanglements[r] = e.entanglements[r] | 1073741824 | n & 261930
    }

    function at(e, t) {
      var n = e.entangledLanes |= t;
      for (e = e.entanglements; n;) {
        var r = 31 - Ue(n),
          i = 1 << r;
        i & t | e[r] & t && (e[r] |= t), n &= ~i
      }
    }

    function ot(e, t) {
      var n = t & -t;
      return n = n & 42 ? 1 : st(n), (n & (e.suspendedLanes | t)) === 0 ? n : 0
    }

    function st(e) {
      switch (e) {
        case 2:
          e = 1;
          break;
        case 8:
          e = 4;
          break;
        case 32:
          e = 16;
          break;
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
          e = 128;
          break;
        case 268435456:
          e = 134217728;
          break;
        default:
          e = 0
      }
      return e
    }

    function ct(e) {
      return e &= -e, 2 < e ? 8 < e ? e & 134217727 ? 32 : 268435456 : 8 : 2
    }

    function lt() {
      var e = j.p;
      return e === 0 ? (e = window.event, e === void 0 ? 32 : mp(e.type)) : e
    }

    function ut(e, t) {
      var n = j.p;
      try {
        return j.p = e, t()
      } finally {
        j.p = n
      }
    }
    var dt = Math.random().toString(36).slice(2),
      ft = `__reactFiber$` + dt,
      pt = `__reactProps$` + dt,
      mt = `__reactContainer$` + dt,
      ht = `__reactEvents$` + dt,
      gt = `__reactListeners$` + dt,
      _t = `__reactHandles$` + dt,
      vt = `__reactResources$` + dt,
      yt = `__reactMarker$` + dt;

    function bt(e) {
      delete e[ft], delete e[pt], delete e[ht], delete e[gt], delete e[_t]
    }

    function xt(e) {
      var t = e[ft];
      if (t) return t;
      for (var n = e.parentNode; n;) {
        if (t = n[mt] || n[ft]) {
          if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
            for (e = df(e); e !== null;) {
              if (n = e[ft]) return n;
              e = df(e)
            }
          return t
        }
        e = n, n = e.parentNode
      }
      return null
    }

    function St(e) {
      if (e = e[ft] || e[mt]) {
        var t = e.tag;
        if (t === 5 || t === 6 || t === 13 || t === 31 || t === 26 || t === 27 || t === 3) return e
      }
      return null
    }

    function Ct(e) {
      var t = e.tag;
      if (t === 5 || t === 26 || t === 27 || t === 6) return e.stateNode;
      throw Error(i(33))
    }

    function wt(e) {
      var t = e[vt];
      return t ||= e[vt] = {
        hoistableStyles: new Map,
        hoistableScripts: new Map
      }, t
    }

    function Tt(e) {
      e[yt] = !0
    }
    var Et = new Set,
      Dt = {};

    function Ot(e, t) {
      kt(e, t), kt(e + `Capture`, t)
    }

    function kt(e, t) {
      for (Dt[e] = t, e = 0; e < t.length; e++) Et.add(t[e])
    }
    var At = RegExp(`^[:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD][:A-Z_a-z\\u00C0-\\u00D6\\u00D8-\\u00F6\\u00F8-\\u02FF\\u0370-\\u037D\\u037F-\\u1FFF\\u200C-\\u200D\\u2070-\\u218F\\u2C00-\\u2FEF\\u3001-\\uD7FF\\uF900-\\uFDCF\\uFDF0-\\uFFFD\\-.0-9\\u00B7\\u0300-\\u036F\\u203F-\\u2040]*$`),
      jt = {},
      Mt = {};

    function Nt(e) {
      return Ee.call(Mt, e) ? !0 : Ee.call(jt, e) ? !1 : At.test(e) ? Mt[e] = !0 : (jt[e] = !0, !1)
    }

    function Pt(e, t, n) {
      if (Nt(t))
        if (n === null) e.removeAttribute(t);
        else {
          switch (typeof n) {
            case `undefined`:
            case `function`:
            case `symbol`:
              e.removeAttribute(t);
              return;
            case `boolean`:
              var r = t.toLowerCase().slice(0, 5);
              if (r !== `data-` && r !== `aria-`) {
                e.removeAttribute(t);
                return
              }
          }
          e.setAttribute(t, `` + n)
        }
    }

    function Ft(e, t, n) {
      if (n === null) e.removeAttribute(t);
      else {
        switch (typeof n) {
          case `undefined`:
          case `function`:
          case `symbol`:
          case `boolean`:
            e.removeAttribute(t);
            return
        }
        e.setAttribute(t, `` + n)
      }
    }

    function It(e, t, n, r) {
      if (r === null) e.removeAttribute(n);
      else {
        switch (typeof r) {
          case `undefined`:
          case `function`:
          case `symbol`:
          case `boolean`:
            e.removeAttribute(n);
            return
        }
        e.setAttributeNS(t, n, `` + r)
      }
    }

    function Lt(e) {
      switch (typeof e) {
        case `bigint`:
        case `boolean`:
        case `number`:
        case `string`:
        case `undefined`:
          return e;
        case `object`:
          return e;
        default:
          return ``
      }
    }

    function Rt(e) {
      var t = e.type;
      return (e = e.nodeName) && e.toLowerCase() === `input` && (t === `checkbox` || t === `radio`)
    }

    function zt(e, t, n) {
      var r = Object.getOwnPropertyDescriptor(e.constructor.prototype, t);
      if (!e.hasOwnProperty(t) && r !== void 0 && typeof r.get == `function` && typeof r.set == `function`) {
        var i = r.get,
          a = r.set;
        return Object.defineProperty(e, t, {
          configurable: !0,
          get: function() {
            return i.call(this)
          },
          set: function(e) {
            n = `` + e, a.call(this, e)
          }
        }), Object.defineProperty(e, t, {
          enumerable: r.enumerable
        }), {
          getValue: function() {
            return n
          },
          setValue: function(e) {
            n = `` + e
          },
          stopTracking: function() {
            e._valueTracker = null, delete e[t]
          }
        }
      }
    }

    function Bt(e) {
      if (!e._valueTracker) {
        var t = Rt(e) ? `checked` : `value`;
        e._valueTracker = zt(e, t, `` + e[t])
      }
    }

    function Vt(e) {
      if (!e) return !1;
      var t = e._valueTracker;
      if (!t) return !0;
      var n = t.getValue(),
        r = ``;
      return e && (r = Rt(e) ? e.checked ? `true` : `false` : e.value), e = r, e === n ? !1 : (t.setValue(e), !0)
    }

    function Ht(e) {
      if (e ||= typeof document < `u` ? document : void 0, e === void 0) return null;
      try {
        return e.activeElement || e.body
      } catch {
        return e.body
      }
    }
    var Ut = /[\n"\\]/g;

    function Wt(e) {
      return e.replace(Ut, function(e) {
        return `\\` + e.charCodeAt(0).toString(16) + ` `
      })
    }

    function Gt(e, t, n, r, i, a, o, s) {
      e.name = ``, o != null && typeof o != `function` && typeof o != `symbol` && typeof o != `boolean` ? e.type = o : e.removeAttribute(`type`), t == null ? o !== `submit` && o !== `reset` || e.removeAttribute(`value`) : o === `number` ? (t === 0 && e.value === `` || e.value != t) && (e.value = `` + Lt(t)) : e.value !== `` + Lt(t) && (e.value = `` + Lt(t)), t == null ? n == null ? r != null && e.removeAttribute(`value`) : qt(e, o, Lt(n)) : qt(e, o, Lt(t)), i == null && a != null && (e.defaultChecked = !!a), i != null && (e.checked = i && typeof i != `function` && typeof i != `symbol`), s != null && typeof s != `function` && typeof s != `symbol` && typeof s != `boolean` ? e.name = `` + Lt(s) : e.removeAttribute(`name`)
    }

    function Kt(e, t, n, r, i, a, o, s) {
      if (a != null && typeof a != `function` && typeof a != `symbol` && typeof a != `boolean` && (e.type = a), t != null || n != null) {
        if (!(a !== `submit` && a !== `reset` || t != null)) {
          Bt(e);
          return
        }
        n = n == null ? `` : `` + Lt(n), t = t == null ? n : `` + Lt(t), s || t === e.value || (e.value = t), e.defaultValue = t
      }
      r ??= i, r = typeof r != `function` && typeof r != `symbol` && !!r, e.checked = s ? e.checked : !!r, e.defaultChecked = !!r, o != null && typeof o != `function` && typeof o != `symbol` && typeof o != `boolean` && (e.name = o), Bt(e)
    }

    function qt(e, t, n) {
      t === `number` && Ht(e.ownerDocument) === e || e.defaultValue === `` + n || (e.defaultValue = `` + n)
    }

    function Jt(e, t, n, r) {
      if (e = e.options, t) {
        t = {};
        for (var i = 0; i < n.length; i++) t[`$` + n[i]] = !0;
        for (n = 0; n < e.length; n++) i = t.hasOwnProperty(`$` + e[n].value), e[n].selected !== i && (e[n].selected = i), i && r && (e[n].defaultSelected = !0)
      } else {
        for (n = `` + Lt(n), t = null, i = 0; i < e.length; i++) {
          if (e[i].value === n) {
            e[i].selected = !0, r && (e[i].defaultSelected = !0);
            return
          }
          t !== null || e[i].disabled || (t = e[i])
        }
        t !== null && (t.selected = !0)
      }
    }

    function Yt(e, t, n) {
      if (t != null && (t = `` + Lt(t), t !== e.value && (e.value = t), n == null)) {
        e.defaultValue !== t && (e.defaultValue = t);
        return
      }
      e.defaultValue = n == null ? `` : `` + Lt(n)
    }

    function Xt(e, t, n, r) {
      if (t == null) {
        if (r != null) {
          if (n != null) throw Error(i(92));
          if (ae(r)) {
            if (1 < r.length) throw Error(i(93));
            r = r[0]
          }
          n = r
        }
        n ??= ``, t = n
      }
      n = Lt(t), e.defaultValue = n, r = e.textContent, r === n && r !== `` && r !== null && (e.value = r), Bt(e)
    }

    function Zt(e, t) {
      if (t) {
        var n = e.firstChild;
        if (n && n === e.lastChild && n.nodeType === 3) {
          n.nodeValue = t;
          return
        }
      }
      e.textContent = t
    }
    var Qt = new Set(`animationIterationCount aspectRatio borderImageOutset borderImageSlice borderImageWidth boxFlex boxFlexGroup boxOrdinalGroup columnCount columns flex flexGrow flexPositive flexShrink flexNegative flexOrder gridArea gridRow gridRowEnd gridRowSpan gridRowStart gridColumn gridColumnEnd gridColumnSpan gridColumnStart fontWeight lineClamp lineHeight opacity order orphans scale tabSize widows zIndex zoom fillOpacity floodOpacity stopOpacity strokeDasharray strokeDashoffset strokeMiterlimit strokeOpacity strokeWidth MozAnimationIterationCount MozBoxFlex MozBoxFlexGroup MozLineClamp msAnimationIterationCount msFlex msZoom msFlexGrow msFlexNegative msFlexOrder msFlexPositive msFlexShrink msGridColumn msGridColumnSpan msGridRow msGridRowSpan WebkitAnimationIterationCount WebkitBoxFlex WebKitBoxFlexGroup WebkitBoxOrdinalGroup WebkitColumnCount WebkitColumns WebkitFlex WebkitFlexGrow WebkitFlexPositive WebkitFlexShrink WebkitLineClamp`.split(` `));

    function $t(e, t, n) {
      var r = t.indexOf(`--`) === 0;
      n == null || typeof n == `boolean` || n === `` ? r ? e.setProperty(t, ``) : t === `float` ? e.cssFloat = `` : e[t] = `` : r ? e.setProperty(t, n) : typeof n != `number` || n === 0 || Qt.has(t) ? t === `float` ? e.cssFloat = n : e[t] = (`` + n).trim() : e[t] = n + `px`
    }

    function en(e, t, n) {
      if (t != null && typeof t != `object`) throw Error(i(62));
      if (e = e.style, n != null) {
        for (var r in n) !n.hasOwnProperty(r) || t != null && t.hasOwnProperty(r) || (r.indexOf(`--`) === 0 ? e.setProperty(r, ``) : r === `float` ? e.cssFloat = `` : e[r] = ``);
        for (var a in t) r = t[a], t.hasOwnProperty(a) && n[a] !== r && $t(e, a, r)
      } else
        for (var o in t) t.hasOwnProperty(o) && $t(e, o, t[o])
    }

    function tn(e) {
      if (e.indexOf(`-`) === -1) return !1;
      switch (e) {
        case `annotation-xml`:
        case `color-profile`:
        case `font-face`:
        case `font-face-src`:
        case `font-face-uri`:
        case `font-face-format`:
        case `font-face-name`:
        case `missing-glyph`:
          return !1;
        default:
          return !0
      }
    }
    var nn = new Map([
        [`acceptCharset`, `accept-charset`],
        [`htmlFor`, `for`],
        [`httpEquiv`, `http-equiv`],
        [`crossOrigin`, `crossorigin`],
        [`accentHeight`, `accent-height`],
        [`alignmentBaseline`, `alignment-baseline`],
        [`arabicForm`, `arabic-form`],
        [`baselineShift`, `baseline-shift`],
        [`capHeight`, `cap-height`],
        [`clipPath`, `clip-path`],
        [`clipRule`, `clip-rule`],
        [`colorInterpolation`, `color-interpolation`],
        [`colorInterpolationFilters`, `color-interpolation-filters`],
        [`colorProfile`, `color-profile`],
        [`colorRendering`, `color-rendering`],
        [`dominantBaseline`, `dominant-baseline`],
        [`enableBackground`, `enable-background`],
        [`fillOpacity`, `fill-opacity`],
        [`fillRule`, `fill-rule`],
        [`floodColor`, `flood-color`],
        [`floodOpacity`, `flood-opacity`],
        [`fontFamily`, `font-family`],
        [`fontSize`, `font-size`],
        [`fontSizeAdjust`, `font-size-adjust`],
        [`fontStretch`, `font-stretch`],
        [`fontStyle`, `font-style`],
        [`fontVariant`, `font-variant`],
        [`fontWeight`, `font-weight`],
        [`glyphName`, `glyph-name`],
        [`glyphOrientationHorizontal`, `glyph-orientation-horizontal`],
        [`glyphOrientationVertical`, `glyph-orientation-vertical`],
        [`horizAdvX`, `horiz-adv-x`],
        [`horizOriginX`, `horiz-origin-x`],
        [`imageRendering`, `image-rendering`],
        [`letterSpacing`, `letter-spacing`],
        [`lightingColor`, `lighting-color`],
        [`markerEnd`, `marker-end`],
        [`markerMid`, `marker-mid`],
        [`markerStart`, `marker-start`],
        [`overlinePosition`, `overline-position`],
        [`overlineThickness`, `overline-thickness`],
        [`paintOrder`, `paint-order`],
        [`panose-1`, `panose-1`],
        [`pointerEvents`, `pointer-events`],
        [`renderingIntent`, `rendering-intent`],
        [`shapeRendering`, `shape-rendering`],
        [`stopColor`, `stop-color`],
        [`stopOpacity`, `stop-opacity`],
        [`strikethroughPosition`, `strikethrough-position`],
        [`strikethroughThickness`, `strikethrough-thickness`],
        [`strokeDasharray`, `stroke-dasharray`],
        [`strokeDashoffset`, `stroke-dashoffset`],
        [`strokeLinecap`, `stroke-linecap`],
        [`strokeLinejoin`, `stroke-linejoin`],
        [`strokeMiterlimit`, `stroke-miterlimit`],
        [`strokeOpacity`, `stroke-opacity`],
        [`strokeWidth`, `stroke-width`],
        [`textAnchor`, `text-anchor`],
        [`textDecoration`, `text-decoration`],
        [`textRendering`, `text-rendering`],
        [`transformOrigin`, `transform-origin`],
        [`underlinePosition`, `underline-position`],
        [`underlineThickness`, `underline-thickness`],
        [`unicodeBidi`, `unicode-bidi`],
        [`unicodeRange`, `unicode-range`],
        [`unitsPerEm`, `units-per-em`],
        [`vAlphabetic`, `v-alphabetic`],
        [`vHanging`, `v-hanging`],
        [`vIdeographic`, `v-ideographic`],
        [`vMathematical`, `v-mathematical`],
        [`vectorEffect`, `vector-effect`],
        [`vertAdvY`, `vert-adv-y`],
        [`vertOriginX`, `vert-origin-x`],
        [`vertOriginY`, `vert-origin-y`],
        [`wordSpacing`, `word-spacing`],
        [`writingMode`, `writing-mode`],
        [`xmlnsXlink`, `xmlns:xlink`],
        [`xHeight`, `x-height`]
      ]),
      rn = /^[\u0000-\u001F ]*j[\r\n\t]*a[\r\n\t]*v[\r\n\t]*a[\r\n\t]*s[\r\n\t]*c[\r\n\t]*r[\r\n\t]*i[\r\n\t]*p[\r\n\t]*t[\r\n\t]*:/i;

    function an(e) {
      return rn.test(`` + e) ? `javascript:throw new Error('React has blocked a javascript: URL as a security precaution.')` : e
    }

    function on() {}
    var sn = null;

    function cn(e) {
      return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e
    }
    var ln = null,
      un = null;

    function dn(e) {
      var t = St(e);
      if (t && (e = t.stateNode)) {
        var n = e[pt] || null;
        a: switch (e = t.stateNode, t.type) {
          case `input`:
            if (Gt(e, n.value, n.defaultValue, n.defaultValue, n.checked, n.defaultChecked, n.type, n.name), t = n.name, n.type === `radio` && t != null) {
              for (n = e; n.parentNode;) n = n.parentNode;
              for (n = n.querySelectorAll(`input[name="` + Wt(`` + t) + `"][type="radio"]`), t = 0; t < n.length; t++) {
                var r = n[t];
                if (r !== e && r.form === e.form) {
                  var a = r[pt] || null;
                  if (!a) throw Error(i(90));
                  Gt(r, a.value, a.defaultValue, a.defaultValue, a.checked, a.defaultChecked, a.type, a.name)
                }
              }
              for (t = 0; t < n.length; t++) r = n[t], r.form === e.form && Vt(r)
            }
            break a;
          case `textarea`:
            Yt(e, n.value, n.defaultValue);
            break a;
          case `select`:
            t = n.value, t != null && Jt(e, !!n.multiple, t, !1)
        }
      }
    }
    var fn = !1;

    function pn(e, t, n) {
      if (fn) return e(t, n);
      fn = !0;
      try {
        return e(t)
      } finally {
        if (fn = !1, (ln !== null || un !== null) && (bu(), ln && (t = ln, e = un, un = ln = null, dn(t), e)))
          for (t = 0; t < e.length; t++) dn(e[t])
      }
    }

    function mn(e, t) {
      var n = e.stateNode;
      if (n === null) return null;
      var r = n[pt] || null;
      if (r === null) return null;
      n = r[t];
      a: switch (t) {
        case `onClick`:
        case `onClickCapture`:
        case `onDoubleClick`:
        case `onDoubleClickCapture`:
        case `onMouseDown`:
        case `onMouseDownCapture`:
        case `onMouseMove`:
        case `onMouseMoveCapture`:
        case `onMouseUp`:
        case `onMouseUpCapture`:
        case `onMouseEnter`:
          (r = !r.disabled) || (e = e.type, r = !(e === `button` || e === `input` || e === `select` || e === `textarea`)), e = !r;
          break a;
        default:
          e = !1
      }
      if (e) return null;
      if (n && typeof n != `function`) throw Error(i(231, t, typeof n));
      return n
    }
    var hn = !(typeof window > `u` || window.document === void 0 || window.document.createElement === void 0),
      gn = !1;
    if (hn) try {
      var _n = {};
      Object.defineProperty(_n, "passive", {
        get: function() {
          gn = !0
        }
      }), window.addEventListener(`test`, _n, _n), window.removeEventListener(`test`, _n, _n)
    } catch {
      gn = !1
    }
    var vn = null,
      yn = null,
      bn = null;

    function xn() {
      if (bn) return bn;
      var e, t = yn,
        n = t.length,
        r, i = `value` in vn ? vn.value : vn.textContent,
        a = i.length;
      for (e = 0; e < n && t[e] === i[e]; e++);
      var o = n - e;
      for (r = 1; r <= o && t[n - r] === i[a - r]; r++);
      return bn = i.slice(e, 1 < r ? 1 - r : void 0)
    }

    function Sn(e) {
      var t = e.keyCode;
      return `charCode` in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0
    }

    function Cn() {
      return !0
    }

    function wn() {
      return !1
    }

    function Tn(e) {
      function t(t, n, r, i, a) {
        for (var o in this._reactName = t, this._targetInst = r, this.type = n, this.nativeEvent = i, this.target = a, this.currentTarget = null, e) e.hasOwnProperty(o) && (t = e[o], this[o] = t ? t(i) : i[o]);
        return this.isDefaultPrevented = (i.defaultPrevented == null ? !1 === i.returnValue : i.defaultPrevented) ? Cn : wn, this.isPropagationStopped = wn, this
      }
      return h(t.prototype, {
        preventDefault: function() {
          this.defaultPrevented = !0;
          var e = this.nativeEvent;
          e && (e.preventDefault ? e.preventDefault() : typeof e.returnValue != `unknown` && (e.returnValue = !1), this.isDefaultPrevented = Cn)
        },
        stopPropagation: function() {
          var e = this.nativeEvent;
          e && (e.stopPropagation ? e.stopPropagation() : typeof e.cancelBubble != `unknown` && (e.cancelBubble = !0), this.isPropagationStopped = Cn)
        },
        persist: function() {},
        isPersistent: Cn
      }), t
    }
    var En = {
        eventPhase: 0,
        bubbles: 0,
        cancelable: 0,
        timeStamp: function(e) {
          return e.timeStamp || Date.now()
        },
        defaultPrevented: 0,
        isTrusted: 0
      },
      Dn = Tn(En),
      On = h({}, En, {
        view: 0,
        detail: 0
      }),
      kn = Tn(On),
      An, jn, Mn, Nn = h({}, On, {
        screenX: 0,
        screenY: 0,
        clientX: 0,
        clientY: 0,
        pageX: 0,
        pageY: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        getModifierState: Wn,
        button: 0,
        buttons: 0,
        relatedTarget: function(e) {
          return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
        },
        movementX: function(e) {
          return `movementX` in e ? e.movementX : (e !== Mn && (Mn && e.type === `mousemove` ? (An = e.screenX - Mn.screenX, jn = e.screenY - Mn.screenY) : jn = An = 0, Mn = e), An)
        },
        movementY: function(e) {
          return `movementY` in e ? e.movementY : jn
        }
      }),
      Pn = Tn(Nn),
      Fn = Tn(h({}, Nn, {
        dataTransfer: 0
      })),
      In = Tn(h({}, On, {
        relatedTarget: 0
      })),
      Ln = Tn(h({}, En, {
        animationName: 0,
        elapsedTime: 0,
        pseudoElement: 0
      })),
      Rn = Tn(h({}, En, {
        clipboardData: function(e) {
          return `clipboardData` in e ? e.clipboardData : window.clipboardData
        }
      })),
      zn = Tn(h({}, En, {
        data: 0
      })),
      Bn = {
        Esc: `Escape`,
        Spacebar: ` `,
        Left: `ArrowLeft`,
        Up: `ArrowUp`,
        Right: `ArrowRight`,
        Down: `ArrowDown`,
        Del: `Delete`,
        Win: `OS`,
        Menu: `ContextMenu`,
        Apps: `ContextMenu`,
        Scroll: `ScrollLock`,
        MozPrintableKey: `Unidentified`
      },
      Vn = {
        8: `Backspace`,
        9: `Tab`,
        12: `Clear`,
        13: `Enter`,
        16: `Shift`,
        17: `Control`,
        18: `Alt`,
        19: `Pause`,
        20: `CapsLock`,
        27: `Escape`,
        32: ` `,
        33: `PageUp`,
        34: `PageDown`,
        35: `End`,
        36: `Home`,
        37: `ArrowLeft`,
        38: `ArrowUp`,
        39: `ArrowRight`,
        40: `ArrowDown`,
        45: `Insert`,
        46: `Delete`,
        112: `F1`,
        113: `F2`,
        114: `F3`,
        115: `F4`,
        116: `F5`,
        117: `F6`,
        118: `F7`,
        119: `F8`,
        120: `F9`,
        121: `F10`,
        122: `F11`,
        123: `F12`,
        144: `NumLock`,
        145: `ScrollLock`,
        224: `Meta`
      },
      Hn = {
        Alt: `altKey`,
        Control: `ctrlKey`,
        Meta: `metaKey`,
        Shift: `shiftKey`
      };

    function Un(e) {
      var t = this.nativeEvent;
      return t.getModifierState ? t.getModifierState(e) : (e = Hn[e]) ? !!t[e] : !1
    }

    function Wn() {
      return Un
    }
    var Gn = Tn(h({}, On, {
        key: function(e) {
          if (e.key) {
            var t = Bn[e.key] || e.key;
            if (t !== `Unidentified`) return t
          }
          return e.type === `keypress` ? (e = Sn(e), e === 13 ? `Enter` : String.fromCharCode(e)) : e.type === `keydown` || e.type === `keyup` ? Vn[e.keyCode] || `Unidentified` : ``
        },
        code: 0,
        location: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        repeat: 0,
        locale: 0,
        getModifierState: Wn,
        charCode: function(e) {
          return e.type === `keypress` ? Sn(e) : 0
        },
        keyCode: function(e) {
          return e.type === `keydown` || e.type === `keyup` ? e.keyCode : 0
        },
        which: function(e) {
          return e.type === `keypress` ? Sn(e) : e.type === `keydown` || e.type === `keyup` ? e.keyCode : 0
        }
      })),
      Kn = Tn(h({}, Nn, {
        pointerId: 0,
        width: 0,
        height: 0,
        pressure: 0,
        tangentialPressure: 0,
        tiltX: 0,
        tiltY: 0,
        twist: 0,
        pointerType: 0,
        isPrimary: 0
      })),
      qn = Tn(h({}, On, {
        touches: 0,
        targetTouches: 0,
        changedTouches: 0,
        altKey: 0,
        metaKey: 0,
        ctrlKey: 0,
        shiftKey: 0,
        getModifierState: Wn
      })),
      Jn = Tn(h({}, En, {
        propertyName: 0,
        elapsedTime: 0,
        pseudoElement: 0
      })),
      Yn = Tn(h({}, Nn, {
        deltaX: function(e) {
          return `deltaX` in e ? e.deltaX : `wheelDeltaX` in e ? -e.wheelDeltaX : 0
        },
        deltaY: function(e) {
          return `deltaY` in e ? e.deltaY : `wheelDeltaY` in e ? -e.wheelDeltaY : `wheelDelta` in e ? -e.wheelDelta : 0
        },
        deltaZ: 0,
        deltaMode: 0
      })),
      Xn = Tn(h({}, En, {
        newState: 0,
        oldState: 0
      })),
      Zn = [9, 13, 27, 32],
      Qn = hn && `CompositionEvent` in window,
      $n = null;
    hn && `documentMode` in document && ($n = document.documentMode);
    var er = hn && `TextEvent` in window && !$n,
      tr = hn && (!Qn || $n && 8 < $n && 11 >= $n),
      N = ` `,
      P = !1;

    function nr(e, t) {
      switch (e) {
        case `keyup`:
          return Zn.indexOf(t.keyCode) !== -1;
        case `keydown`:
          return t.keyCode !== 229;
        case `keypress`:
        case `mousedown`:
        case `focusout`:
          return !0;
        default:
          return !1
      }
    }

    function rr(e) {
      return e = e.detail, typeof e == `object` && `data` in e ? e.data : null
    }
    var ir = !1;

    function ar(e, t) {
      switch (e) {
        case `compositionend`:
          return rr(t);
        case `keypress`:
          return t.which === 32 ? (P = !0, N) : null;
        case `textInput`:
          return e = t.data, e === N && P ? null : e;
        default:
          return null
      }
    }

    function or(e, t) {
      if (ir) return e === `compositionend` || !Qn && nr(e, t) ? (e = xn(), bn = yn = vn = null, ir = !1, e) : null;
      switch (e) {
        case `paste`:
          return null;
        case `keypress`:
          if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
            if (t.char && 1 < t.char.length) return t.char;
            if (t.which) return String.fromCharCode(t.which)
          }
          return null;
        case `compositionend`:
          return tr && t.locale !== `ko` ? null : t.data;
        default:
          return null
      }
    }
    var sr = {
      color: !0,
      date: !0,
      datetime: !0,
      "datetime-local": !0,
      email: !0,
      month: !0,
      number: !0,
      password: !0,
      range: !0,
      search: !0,
      tel: !0,
      text: !0,
      time: !0,
      url: !0,
      week: !0
    };

    function cr(e) {
      var t = e && e.nodeName && e.nodeName.toLowerCase();
      return t === `input` ? !!sr[e.type] : t === `textarea`
    }

    function lr(e, t, n, r) {
      ln ? un ? un.push(r) : un = [r] : ln = r, t = Ed(t, `onChange`), 0 < t.length && (n = new Dn(`onChange`, `change`, null, n, r), e.push({
        event: n,
        listeners: t
      }))
    }
    var ur = null,
      dr = null;

    function fr(e) {
      yd(e, 0)
    }

    function pr(e) {
      if (Vt(Ct(e))) return e
    }

    function mr(e, t) {
      if (e === `change`) return t
    }
    var hr = !1;
    if (hn) {
      var gr;
      if (hn) {
        var _r = `oninput` in document;
        if (!_r) {
          var vr = document.createElement(`div`);
          vr.setAttribute(`oninput`, `return;`), _r = typeof vr.oninput == `function`
        }
        gr = _r
      } else gr = !1;
      hr = gr && (!document.documentMode || 9 < document.documentMode)
    }

    function yr() {
      ur && (ur.detachEvent(`onpropertychange`, br), dr = ur = null)
    }

    function br(e) {
      if (e.propertyName === `value` && pr(dr)) {
        var t = [];
        lr(t, dr, e, cn(e)), pn(fr, t)
      }
    }

    function xr(e, t, n) {
      e === `focusin` ? (yr(), ur = t, dr = n, ur.attachEvent(`onpropertychange`, br)) : e === `focusout` && yr()
    }

    function Sr(e) {
      if (e === `selectionchange` || e === `keyup` || e === `keydown`) return pr(dr)
    }

    function Cr(e, t) {
      if (e === `click`) return pr(t)
    }

    function wr(e, t) {
      if (e === `input` || e === `change`) return pr(t)
    }

    function Tr(e, t) {
      return e === t && (e !== 0 || 1 / e == 1 / t) || e !== e && t !== t
    }
    var Er = typeof Object.is == `function` ? Object.is : Tr;

    function F(e, t) {
      if (Er(e, t)) return !0;
      if (typeof e != `object` || !e || typeof t != `object` || !t) return !1;
      var n = Object.keys(e),
        r = Object.keys(t);
      if (n.length !== r.length) return !1;
      for (r = 0; r < n.length; r++) {
        var i = n[r];
        if (!Ee.call(t, i) || !Er(e[i], t[i])) return !1
      }
      return !0
    }

    function Dr(e) {
      for (; e && e.firstChild;) e = e.firstChild;
      return e
    }

    function Or(e, t) {
      var n = Dr(e);
      e = 0;
      for (var r; n;) {
        if (n.nodeType === 3) {
          if (r = e + n.textContent.length, e <= t && r >= t) return {
            node: n,
            offset: t - e
          };
          e = r
        }
        a: {
          for (; n;) {
            if (n.nextSibling) {
              n = n.nextSibling;
              break a
            }
            n = n.parentNode
          }
          n = void 0
        }
        n = Dr(n)
      }
    }

    function kr(e, t) {
      return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? kr(e, t.parentNode) : `contains` in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1
    }

    function Ar(e) {
      e = e != null && e.ownerDocument != null && e.ownerDocument.defaultView != null ? e.ownerDocument.defaultView : window;
      for (var t = Ht(e.document); t instanceof e.HTMLIFrameElement;) {
        try {
          var n = typeof t.contentWindow.location.href == `string`
        } catch {
          n = !1
        }
        if (n) e = t.contentWindow;
        else break;
        t = Ht(e.document)
      }
      return t
    }

    function jr(e) {
      var t = e && e.nodeName && e.nodeName.toLowerCase();
      return t && (t === `input` && (e.type === `text` || e.type === `search` || e.type === `tel` || e.type === `url` || e.type === `password`) || t === `textarea` || e.contentEditable === `true`)
    }
    var Mr = hn && `documentMode` in document && 11 >= document.documentMode,
      Nr = null,
      Pr = null,
      Fr = null,
      Ir = !1;

    function Lr(e, t, n) {
      var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
      Ir || Nr == null || Nr !== Ht(r) || (r = Nr, `selectionStart` in r && jr(r) ? r = {
        start: r.selectionStart,
        end: r.selectionEnd
      } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = {
        anchorNode: r.anchorNode,
        anchorOffset: r.anchorOffset,
        focusNode: r.focusNode,
        focusOffset: r.focusOffset
      }), Fr && F(Fr, r) || (Fr = r, r = Ed(Pr, `onSelect`), 0 < r.length && (t = new Dn(`onSelect`, `select`, null, t, n), e.push({
        event: t,
        listeners: r
      }), t.target = Nr)))
    }

    function Rr(e, t) {
      var n = {};
      return n[e.toLowerCase()] = t.toLowerCase(), n[`Webkit` + e] = `webkit` + t, n[`Moz` + e] = `moz` + t, n
    }
    var I = {
        animationend: Rr(`Animation`, `AnimationEnd`),
        animationiteration: Rr(`Animation`, `AnimationIteration`),
        animationstart: Rr(`Animation`, `AnimationStart`),
        transitionrun: Rr(`Transition`, `TransitionRun`),
        transitionstart: Rr(`Transition`, `TransitionStart`),
        transitioncancel: Rr(`Transition`, `TransitionCancel`),
        transitionend: Rr(`Transition`, `TransitionEnd`)
      },
      zr = {},
      Br = {};
    hn && (Br = document.createElement(`div`).style, `AnimationEvent` in window || (delete I.animationend.animation, delete I.animationiteration.animation, delete I.animationstart.animation), `TransitionEvent` in window || delete I.transitionend.transition);

    function Vr(e) {
      if (zr[e]) return zr[e];
      if (!I[e]) return e;
      var t = I[e],
        n;
      for (n in t)
        if (t.hasOwnProperty(n) && n in Br) return zr[e] = t[n];
      return e
    }
    var Hr = Vr(`animationend`),
      Ur = Vr(`animationiteration`),
      Wr = Vr(`animationstart`),
      Gr = Vr(`transitionrun`),
      Kr = Vr(`transitionstart`),
      qr = Vr(`transitioncancel`),
      Jr = Vr(`transitionend`),
      Yr = new Map,
      Xr = `abort auxClick beforeToggle cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel`.split(` `);
    Xr.push(`scrollEnd`);

    function Zr(e, t) {
      Yr.set(e, t), Ot(t, [e])
    }
    var Qr = typeof reportError == `function` ? reportError : function(e) {
        if (typeof window == `object` && typeof window.ErrorEvent == `function`) {
          var t = new window.ErrorEvent(`error`, {
            bubbles: !0,
            cancelable: !0,
            message: typeof e == `object` && e && typeof e.message == `string` ? String(e.message) : String(e),
            error: e
          });
          if (!window.dispatchEvent(t)) return
        } else if (typeof process == `object` && typeof process.emit == `function`) {
          process.emit(`uncaughtException`, e);
          return
        }
        console.error(e)
      },
      $r = [],
      ei = 0,
      ti = 0;

    function ni() {
      for (var e = ei, t = ti = ei = 0; t < e;) {
        var n = $r[t];
        $r[t++] = null;
        var r = $r[t];
        $r[t++] = null;
        var i = $r[t];
        $r[t++] = null;
        var a = $r[t];
        if ($r[t++] = null, r !== null && i !== null) {
          var o = r.pending;
          o === null ? i.next = i : (i.next = o.next, o.next = i), r.pending = i
        }
        a !== 0 && oi(n, i, a)
      }
    }

    function ri(e, t, n, r) {
      $r[ei++] = e, $r[ei++] = t, $r[ei++] = n, $r[ei++] = r, ti |= r, e.lanes |= r, e = e.alternate, e !== null && (e.lanes |= r)
    }

    function ii(e, t, n, r) {
      return ri(e, t, n, r), si(e)
    }

    function ai(e, t) {
      return ri(e, null, null, t), si(e)
    }

    function oi(e, t, n) {
      e.lanes |= n;
      var r = e.alternate;
      r !== null && (r.lanes |= n);
      for (var i = !1, a = e.return; a !== null;) a.childLanes |= n, r = a.alternate, r !== null && (r.childLanes |= n), a.tag === 22 && (e = a.stateNode, e === null || e._visibility & 1 || (i = !0)), e = a, a = a.return;
      return e.tag === 3 ? (a = e.stateNode, i && t !== null && (i = 31 - Ue(n), e = a.hiddenUpdates, r = e[i], r === null ? e[i] = [t] : r.push(t), t.lane = n | 536870912), a) : null
    }

    function si(e) {
      if (50 < du) throw du = 0, fu = null, Error(i(185));
      for (var t = e.return; t !== null;) e = t, t = e.return;
      return e.tag === 3 ? e.stateNode : null
    }
    var ci = {};

    function li(e, t, n, r) {
      this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.refCleanup = this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
    }

    function ui(e, t, n, r) {
      return new li(e, t, n, r)
    }

    function di(e) {
      return e = e.prototype, !(!e || !e.isReactComponent)
    }

    function fi(e, t) {
      var n = e.alternate;
      return n === null ? (n = ui(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 65011712, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
      }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n.refCleanup = e.refCleanup, n
    }

    function pi(e, t) {
      e.flags &= 65011714;
      var n = e.alternate;
      return n === null ? (e.childLanes = 0, e.lanes = t, e.child = null, e.subtreeFlags = 0, e.memoizedProps = null, e.memoizedState = null, e.updateQueue = null, e.dependencies = null, e.stateNode = null) : (e.childLanes = n.childLanes, e.lanes = n.lanes, e.child = n.child, e.subtreeFlags = 0, e.deletions = null, e.memoizedProps = n.memoizedProps, e.memoizedState = n.memoizedState, e.updateQueue = n.updateQueue, e.type = n.type, t = n.dependencies, e.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
      }), e
    }

    function mi(e, t, n, r, a, o) {
      var s = 0;
      if (r = e, typeof e == `function`) di(e) && (s = 1);
      else if (typeof e == `string`) s = Uf(e, n, de.current) ? 26 : e === `html` || e === `head` || e === `body` ? 27 : 5;
      else a: switch (e) {
        case ee:
          return e = ui(31, n, t, a), e.elementType = ee, e.lanes = o, e;
        case y:
          return hi(n.children, a, o, t);
        case b:
          s = 8, a |= 24;
          break;
        case x:
          return e = ui(12, n, t, a | 2), e.elementType = x, e.lanes = o, e;
        case T:
          return e = ui(13, n, t, a), e.elementType = T, e.lanes = o, e;
        case E:
          return e = ui(19, n, t, a), e.elementType = E, e.lanes = o, e;
        default:
          if (typeof e == `object` && e) switch (e.$$typeof) {
            case C:
              s = 10;
              break a;
            case S:
              s = 9;
              break a;
            case w:
              s = 11;
              break a;
            case D:
              s = 14;
              break a;
            case O:
              s = 16, r = null;
              break a
          }
          s = 29, n = Error(i(130, e === null ? `null` : typeof e, ``)), r = null
      }
      return t = ui(s, n, t, a), t.elementType = e, t.type = r, t.lanes = o, t
    }

    function hi(e, t, n, r) {
      return e = ui(7, e, r, t), e.lanes = n, e
    }

    function gi(e, t, n) {
      return e = ui(6, e, null, t), e.lanes = n, e
    }

    function _i(e) {
      var t = ui(18, null, null, 0);
      return t.stateNode = e, t
    }

    function vi(e, t, n) {
      return t = ui(4, e.children === null ? [] : e.children, e.key, t), t.lanes = n, t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation
      }, t
    }
    var yi = new WeakMap;

    function bi(e, t) {
      if (typeof e == `object` && e) {
        var n = yi.get(e);
        return n === void 0 ? (t = {
          value: e,
          source: t,
          stack: Te(t)
        }, yi.set(e, t), t) : n
      }
      return {
        value: e,
        source: t,
        stack: Te(t)
      }
    }
    var xi = [],
      Si = 0,
      Ci = null,
      wi = 0,
      Ti = [],
      Ei = 0,
      Di = null,
      Oi = 1,
      ki = ``;

    function Ai(e, t) {
      xi[Si++] = wi, xi[Si++] = Ci, Ci = e, wi = t
    }

    function ji(e, t, n) {
      Ti[Ei++] = Oi, Ti[Ei++] = ki, Ti[Ei++] = Di, Di = e;
      var r = Oi;
      e = ki;
      var i = 32 - Ue(r) - 1;
      r &= ~(1 << i), n += 1;
      var a = 32 - Ue(t) + i;
      if (30 < a) {
        var o = i - i % 5;
        a = (r & (1 << o) - 1).toString(32), r >>= o, i -= o, Oi = 1 << 32 - Ue(t) + i | n << i | r, ki = a + e
      } else Oi = 1 << a | n << i | r, ki = e
    }

    function Mi(e) {
      e.return !== null && (Ai(e, 1), ji(e, 1, 0))
    }

    function Ni(e) {
      for (; e === Ci;) Ci = xi[--Si], xi[Si] = null, wi = xi[--Si], xi[Si] = null;
      for (; e === Di;) Di = Ti[--Ei], Ti[Ei] = null, ki = Ti[--Ei], Ti[Ei] = null, Oi = Ti[--Ei], Ti[Ei] = null
    }

    function Pi(e, t) {
      Ti[Ei++] = Oi, Ti[Ei++] = ki, Ti[Ei++] = Di, Oi = t.id, ki = t.overflow, Di = e
    }
    var Fi = null,
      Ii = null,
      L = !1,
      Li = null,
      Ri = !1,
      zi = Error(i(519));

    function Bi(e) {
      throw Gi(bi(Error(i(418, 1 < arguments.length && arguments[1] !== void 0 && arguments[1] ? `text` : `HTML`, ``)), e)), zi
    }

    function Vi(e) {
      var t = e.stateNode,
        n = e.type,
        r = e.memoizedProps;
      switch (t[ft] = e, t[pt] = r, n) {
        case `dialog`:
          Q(`cancel`, t), Q(`close`, t);
          break;
        case `iframe`:
        case `object`:
        case `embed`:
          Q(`load`, t);
          break;
        case `video`:
        case `audio`:
          for (n = 0; n < _d.length; n++) Q(_d[n], t);
          break;
        case `source`:
          Q(`error`, t);
          break;
        case `img`:
        case `image`:
        case `link`:
          Q(`error`, t), Q(`load`, t);
          break;
        case `details`:
          Q(`toggle`, t);
          break;
        case `input`:
          Q(`invalid`, t), Kt(t, r.value, r.defaultValue, r.checked, r.defaultChecked, r.type, r.name, !0);
          break;
        case `select`:
          Q(`invalid`, t);
          break;
        case `textarea`:
          Q(`invalid`, t), Xt(t, r.value, r.defaultValue, r.children)
      }
      n = r.children, typeof n != `string` && typeof n != `number` && typeof n != `bigint` || t.textContent === `` + n || !0 === r.suppressHydrationWarning || Md(t.textContent, n) ? (r.popover != null && (Q(`beforetoggle`, t), Q(`toggle`, t)), r.onScroll != null && Q(`scroll`, t), r.onScrollEnd != null && Q(`scrollend`, t), r.onClick != null && (t.onclick = on), t = !0) : t = !1, t || Bi(e, !0)
    }

    function Hi(e) {
      for (Fi = e.return; Fi;) switch (Fi.tag) {
        case 5:
        case 31:
        case 13:
          Ri = !1;
          return;
        case 27:
        case 3:
          Ri = !0;
          return;
        default:
          Fi = Fi.return
      }
    }

    function Ui(e) {
      if (e !== Fi) return !1;
      if (!L) return Hi(e), L = !0, !1;
      var t = e.tag,
        n;
      if ((n = t !== 3 && t !== 27) && ((n = t === 5) && (n = e.type, n = !(n !== `form` && n !== `button`) || Ud(e.type, e.memoizedProps)), n = !n), n && Ii && Bi(e), Hi(e), t === 13) {
        if (e = e.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(i(317));
        Ii = uf(e)
      } else if (t === 31) {
        if (e = e.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(i(317));
        Ii = uf(e)
      } else t === 27 ? (t = Ii, Zd(e.type) ? (e = lf, lf = null, Ii = e) : Ii = t) : Ii = Fi ? cf(e.stateNode.nextSibling) : null;
      return !0
    }

    function R() {
      Ii = Fi = null, L = !1
    }

    function Wi() {
      var e = Li;
      return e !== null && (Zl === null ? Zl = e : Zl.push.apply(Zl, e), Li = null), e
    }

    function Gi(e) {
      Li === null ? Li = [e] : Li.push(e)
    }
    var Ki = le(null),
      z = null,
      qi = null;

    function Ji(e, t, n) {
      M(Ki, t._currentValue), t._currentValue = n
    }

    function B(e) {
      e._currentValue = Ki.current, ue(Ki)
    }

    function Yi(e, t, n) {
      for (; e !== null;) {
        var r = e.alternate;
        if ((e.childLanes & t) === t ? r !== null && (r.childLanes & t) !== t && (r.childLanes |= t) : (e.childLanes |= t, r !== null && (r.childLanes |= t)), e === n) break;
        e = e.return
      }
    }

    function Xi(e, t, n, r) {
      var a = e.child;
      for (a !== null && (a.return = e); a !== null;) {
        var o = a.dependencies;
        if (o !== null) {
          var s = a.child;
          o = o.firstContext;
          a: for (; o !== null;) {
            var c = o;
            o = a;
            for (var l = 0; l < t.length; l++)
              if (c.context === t[l]) {
                o.lanes |= n, c = o.alternate, c !== null && (c.lanes |= n), Yi(o.return, n, e), r || (s = null);
                break a
              } o = c.next
          }
        } else if (a.tag === 18) {
          if (s = a.return, s === null) throw Error(i(341));
          s.lanes |= n, o = s.alternate, o !== null && (o.lanes |= n), Yi(s, n, e), s = null
        } else s = a.child;
        if (s !== null) s.return = a;
        else
          for (s = a; s !== null;) {
            if (s === e) {
              s = null;
              break
            }
            if (a = s.sibling, a !== null) {
              a.return = s.return, s = a;
              break
            }
            s = s.return
          }
        a = s
      }
    }

    function Zi(e, t, n, r) {
      e = null;
      for (var a = t, o = !1; a !== null;) {
        if (!o) {
          if (a.flags & 524288) o = !0;
          else if (a.flags & 262144) break
        }
        if (a.tag === 10) {
          var s = a.alternate;
          if (s === null) throw Error(i(387));
          if (s = s.memoizedProps, s !== null) {
            var c = a.type;
            Er(a.pendingProps.value, s.value) || (e === null ? e = [c] : e.push(c))
          }
        } else if (a === me.current) {
          if (s = a.alternate, s === null) throw Error(i(387));
          s.memoizedState.memoizedState !== a.memoizedState.memoizedState && (e === null ? e = [Qf] : e.push(Qf))
        }
        a = a.return
      }
      e !== null && Xi(t, e, n, r), t.flags |= 262144
    }

    function Qi(e) {
      for (e = e.firstContext; e !== null;) {
        if (!Er(e.context._currentValue, e.memoizedValue)) return !0;
        e = e.next
      }
      return !1
    }

    function $i(e) {
      z = e, qi = null, e = e.dependencies, e !== null && (e.firstContext = null)
    }

    function ea(e) {
      return na(z, e)
    }

    function ta(e, t) {
      return z === null && $i(e), na(e, t)
    }

    function na(e, t) {
      var n = t._currentValue;
      if (t = {
          context: t,
          memoizedValue: n,
          next: null
        }, qi === null) {
        if (e === null) throw Error(i(308));
        qi = t, e.dependencies = {
          lanes: 0,
          firstContext: t
        }, e.flags |= 524288
      } else qi = qi.next = t;
      return n
    }
    var ra = typeof AbortController < `u` ? AbortController : function() {
        var e = [],
          t = this.signal = {
            aborted: !1,
            addEventListener: function(t, n) {
              e.push(n)
            }
          };
        this.abort = function() {
          t.aborted = !0, e.forEach(function(e) {
            return e()
          })
        }
      },
      ia = t.unstable_scheduleCallback,
      aa = t.unstable_NormalPriority,
      oa = {
        $$typeof: C,
        Consumer: null,
        Provider: null,
        _currentValue: null,
        _currentValue2: null,
        _threadCount: 0
      };

    function sa() {
      return {
        controller: new ra,
        data: new Map,
        refCount: 0
      }
    }

    function ca(e) {
      e.refCount--, e.refCount === 0 && ia(aa, function() {
        e.controller.abort()
      })
    }
    var la = null,
      ua = 0,
      da = 0,
      fa = null;

    function pa(e, t) {
      if (la === null) {
        var n = la = [];
        ua = 0, da = dd(), fa = {
          status: `pending`,
          value: void 0,
          then: function(e) {
            n.push(e)
          }
        }
      }
      return ua++, t.then(ma, ma), t
    }

    function ma() {
      if (--ua === 0 && la !== null) {
        fa !== null && (fa.status = `fulfilled`);
        var e = la;
        la = null, da = 0, fa = null;
        for (var t = 0; t < e.length; t++)(0, e[t])()
      }
    }

    function ha(e, t) {
      var n = [],
        r = {
          status: `pending`,
          value: null,
          reason: null,
          then: function(e) {
            n.push(e)
          }
        };
      return e.then(function() {
        r.status = `fulfilled`, r.value = t;
        for (var e = 0; e < n.length; e++)(0, n[e])(t)
      }, function(e) {
        for (r.status = `rejected`, r.reason = e, e = 0; e < n.length; e++)(0, n[e])(void 0)
      }), r
    }
    var ga = A.S;
    A.S = function(e, t) {
      eu = je(), typeof t == `object` && t && typeof t.then == `function` && pa(e, t), ga !== null && ga(e, t)
    };
    var _a = le(null);

    function va() {
      var e = _a.current;
      return e === null ? Rl.pooledCache : e
    }

    function ya(e, t) {
      t === null ? M(_a, _a.current) : M(_a, t.pool)
    }

    function ba() {
      var e = va();
      return e === null ? null : {
        parent: oa._currentValue,
        pool: e
      }
    }
    var xa = Error(i(460)),
      Sa = Error(i(474)),
      Ca = Error(i(542)),
      wa = {
        then: function() {}
      };

    function Ta(e) {
      return e = e.status, e === `fulfilled` || e === `rejected`
    }

    function Ea(e, t, n) {
      switch (n = e[n], n === void 0 ? e.push(t) : n !== t && (t.then(on, on), t = n), t.status) {
        case `fulfilled`:
          return t.value;
        case `rejected`:
          throw e = t.reason, Aa(e), e;
        default:
          if (typeof t.status == `string`) t.then(on, on);
          else {
            if (e = Rl, e !== null && 100 < e.shellSuspendCounter) throw Error(i(482));
            e = t, e.status = `pending`, e.then(function(e) {
              if (t.status === `pending`) {
                var n = t;
                n.status = `fulfilled`, n.value = e
              }
            }, function(e) {
              if (t.status === `pending`) {
                var n = t;
                n.status = `rejected`, n.reason = e
              }
            })
          }
          switch (t.status) {
            case `fulfilled`:
              return t.value;
            case `rejected`:
              throw e = t.reason, Aa(e), e
          }
          throw Oa = t, xa
      }
    }

    function Da(e) {
      try {
        var t = e._init;
        return t(e._payload)
      } catch (e) {
        throw typeof e == `object` && e && typeof e.then == `function` ? (Oa = e, xa) : e
      }
    }
    var Oa = null;

    function ka() {
      if (Oa === null) throw Error(i(459));
      var e = Oa;
      return Oa = null, e
    }

    function Aa(e) {
      if (e === xa || e === Ca) throw Error(i(483))
    }
    var ja = null,
      Ma = 0;

    function Na(e) {
      var t = Ma;
      return Ma += 1, ja === null && (ja = []), Ea(ja, e, t)
    }

    function Pa(e, t) {
      t = t.props.ref, e.ref = t === void 0 ? null : t
    }

    function Fa(e, t) {
      throw t.$$typeof === g ? Error(i(525)) : (e = Object.prototype.toString.call(t), Error(i(31, e === `[object Object]` ? `object with keys {` + Object.keys(t).join(`, `) + `}` : e)))
    }

    function Ia(e) {
      function t(t, n) {
        if (e) {
          var r = t.deletions;
          r === null ? (t.deletions = [n], t.flags |= 16) : r.push(n)
        }
      }

      function n(n, r) {
        if (!e) return null;
        for (; r !== null;) t(n, r), r = r.sibling;
        return null
      }

      function r(e) {
        for (var t = new Map; e !== null;) e.key === null ? t.set(e.index, e) : t.set(e.key, e), e = e.sibling;
        return t
      }

      function a(e, t) {
        return e = fi(e, t), e.index = 0, e.sibling = null, e
      }

      function o(t, n, r) {
        return t.index = r, e ? (r = t.alternate, r === null ? (t.flags |= 67108866, n) : (r = r.index, r < n ? (t.flags |= 67108866, n) : r)) : (t.flags |= 1048576, n)
      }

      function s(t) {
        return e && t.alternate === null && (t.flags |= 67108866), t
      }

      function c(e, t, n, r) {
        return t === null || t.tag !== 6 ? (t = gi(n, e.mode, r), t.return = e, t) : (t = a(t, n), t.return = e, t)
      }

      function l(e, t, n, r) {
        var i = n.type;
        return i === y ? d(e, t, n.props.children, r, n.key) : t !== null && (t.elementType === i || typeof i == `object` && i && i.$$typeof === O && Da(i) === t.type) ? (t = a(t, n.props), Pa(t, n), t.return = e, t) : (t = mi(n.type, n.key, n.props, null, e.mode, r), Pa(t, n), t.return = e, t)
      }

      function u(e, t, n, r) {
        return t === null || t.tag !== 4 || t.stateNode.containerInfo !== n.containerInfo || t.stateNode.implementation !== n.implementation ? (t = vi(n, e.mode, r), t.return = e, t) : (t = a(t, n.children || []), t.return = e, t)
      }

      function d(e, t, n, r, i) {
        return t === null || t.tag !== 7 ? (t = hi(n, e.mode, r, i), t.return = e, t) : (t = a(t, n), t.return = e, t)
      }

      function f(e, t, n) {
        if (typeof t == `string` && t !== `` || typeof t == `number` || typeof t == `bigint`) return t = gi(`` + t, e.mode, n), t.return = e, t;
        if (typeof t == `object` && t) {
          switch (t.$$typeof) {
            case _:
              return n = mi(t.type, t.key, t.props, null, e.mode, n), Pa(n, t), n.return = e, n;
            case v:
              return t = vi(t, e.mode, n), t.return = e, t;
            case O:
              return t = Da(t), f(e, t, n)
          }
          if (ae(t) || ne(t)) return t = hi(t, e.mode, n, null), t.return = e, t;
          if (typeof t.then == `function`) return f(e, Na(t), n);
          if (t.$$typeof === C) return f(e, ta(e, t), n);
          Fa(e, t)
        }
        return null
      }

      function p(e, t, n, r) {
        var i = t === null ? null : t.key;
        if (typeof n == `string` && n !== `` || typeof n == `number` || typeof n == `bigint`) return i === null ? c(e, t, `` + n, r) : null;
        if (typeof n == `object` && n) {
          switch (n.$$typeof) {
            case _:
              return n.key === i ? l(e, t, n, r) : null;
            case v:
              return n.key === i ? u(e, t, n, r) : null;
            case O:
              return n = Da(n), p(e, t, n, r)
          }
          if (ae(n) || ne(n)) return i === null ? d(e, t, n, r, null) : null;
          if (typeof n.then == `function`) return p(e, t, Na(n), r);
          if (n.$$typeof === C) return p(e, t, ta(e, n), r);
          Fa(e, n)
        }
        return null
      }

      function m(e, t, n, r, i) {
        if (typeof r == `string` && r !== `` || typeof r == `number` || typeof r == `bigint`) return e = e.get(n) || null, c(t, e, `` + r, i);
        if (typeof r == `object` && r) {
          switch (r.$$typeof) {
            case _:
              return e = e.get(r.key === null ? n : r.key) || null, l(t, e, r, i);
            case v:
              return e = e.get(r.key === null ? n : r.key) || null, u(t, e, r, i);
            case O:
              return r = Da(r), m(e, t, n, r, i)
          }
          if (ae(r) || ne(r)) return e = e.get(n) || null, d(t, e, r, i, null);
          if (typeof r.then == `function`) return m(e, t, n, Na(r), i);
          if (r.$$typeof === C) return m(e, t, n, ta(t, r), i);
          Fa(t, r)
        }
        return null
      }

      function h(i, a, s, c) {
        for (var l = null, u = null, d = a, h = a = 0, g = null; d !== null && h < s.length; h++) {
          d.index > h ? (g = d, d = null) : g = d.sibling;
          var _ = p(i, d, s[h], c);
          if (_ === null) {
            d === null && (d = g);
            break
          }
          e && d && _.alternate === null && t(i, d), a = o(_, a, h), u === null ? l = _ : u.sibling = _, u = _, d = g
        }
        if (h === s.length) return n(i, d), L && Ai(i, h), l;
        if (d === null) {
          for (; h < s.length; h++) d = f(i, s[h], c), d !== null && (a = o(d, a, h), u === null ? l = d : u.sibling = d, u = d);
          return L && Ai(i, h), l
        }
        for (d = r(d); h < s.length; h++) g = m(d, i, h, s[h], c), g !== null && (e && g.alternate !== null && d.delete(g.key === null ? h : g.key), a = o(g, a, h), u === null ? l = g : u.sibling = g, u = g);
        return e && d.forEach(function(e) {
          return t(i, e)
        }), L && Ai(i, h), l
      }

      function g(a, s, c, l) {
        if (c == null) throw Error(i(151));
        for (var u = null, d = null, h = s, g = s = 0, _ = null, v = c.next(); h !== null && !v.done; g++, v = c.next()) {
          h.index > g ? (_ = h, h = null) : _ = h.sibling;
          var y = p(a, h, v.value, l);
          if (y === null) {
            h === null && (h = _);
            break
          }
          e && h && y.alternate === null && t(a, h), s = o(y, s, g), d === null ? u = y : d.sibling = y, d = y, h = _
        }
        if (v.done) return n(a, h), L && Ai(a, g), u;
        if (h === null) {
          for (; !v.done; g++, v = c.next()) v = f(a, v.value, l), v !== null && (s = o(v, s, g), d === null ? u = v : d.sibling = v, d = v);
          return L && Ai(a, g), u
        }
        for (h = r(h); !v.done; g++, v = c.next()) v = m(h, a, g, v.value, l), v !== null && (e && v.alternate !== null && h.delete(v.key === null ? g : v.key), s = o(v, s, g), d === null ? u = v : d.sibling = v, d = v);
        return e && h.forEach(function(e) {
          return t(a, e)
        }), L && Ai(a, g), u
      }

      function b(e, r, o, c) {
        if (typeof o == `object` && o && o.type === y && o.key === null && (o = o.props.children), typeof o == `object` && o) {
          switch (o.$$typeof) {
            case _:
              a: {
                for (var l = o.key; r !== null;) {
                  if (r.key === l) {
                    if (l = o.type, l === y) {
                      if (r.tag === 7) {
                        n(e, r.sibling), c = a(r, o.props.children), c.return = e, e = c;
                        break a
                      }
                    } else if (r.elementType === l || typeof l == `object` && l && l.$$typeof === O && Da(l) === r.type) {
                      n(e, r.sibling), c = a(r, o.props), Pa(c, o), c.return = e, e = c;
                      break a
                    }
                    n(e, r);
                    break
                  } else t(e, r);
                  r = r.sibling
                }
                o.type === y ? (c = hi(o.props.children, e.mode, c, o.key), c.return = e, e = c) : (c = mi(o.type, o.key, o.props, null, e.mode, c), Pa(c, o), c.return = e, e = c)
              }
              return s(e);
            case v:
              a: {
                for (l = o.key; r !== null;) {
                  if (r.key === l)
                    if (r.tag === 4 && r.stateNode.containerInfo === o.containerInfo && r.stateNode.implementation === o.implementation) {
                      n(e, r.sibling), c = a(r, o.children || []), c.return = e, e = c;
                      break a
                    } else {
                      n(e, r);
                      break
                    }
                  else t(e, r);
                  r = r.sibling
                }
                c = vi(o, e.mode, c),
                c.return = e,
                e = c
              }
              return s(e);
            case O:
              return o = Da(o), b(e, r, o, c)
          }
          if (ae(o)) return h(e, r, o, c);
          if (ne(o)) {
            if (l = ne(o), typeof l != `function`) throw Error(i(150));
            return o = l.call(o), g(e, r, o, c)
          }
          if (typeof o.then == `function`) return b(e, r, Na(o), c);
          if (o.$$typeof === C) return b(e, r, ta(e, o), c);
          Fa(e, o)
        }
        return typeof o == `string` && o !== `` || typeof o == `number` || typeof o == `bigint` ? (o = `` + o, r !== null && r.tag === 6 ? (n(e, r.sibling), c = a(r, o), c.return = e, e = c) : (n(e, r), c = gi(o, e.mode, c), c.return = e, e = c), s(e)) : n(e, r)
      }
      return function(e, t, n, r) {
        try {
          Ma = 0;
          var i = b(e, t, n, r);
          return ja = null, i
        } catch (t) {
          if (t === xa || t === Ca) throw t;
          var a = ui(29, t, null, e.mode);
          return a.lanes = r, a.return = e, a
        }
      }
    }
    var La = Ia(!0),
      Ra = Ia(!1),
      za = !1;

    function Ba(e) {
      e.updateQueue = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
          pending: null,
          lanes: 0,
          hiddenCallbacks: null
        },
        callbacks: null
      }
    }

    function Va(e, t) {
      e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        callbacks: null
      })
    }

    function Ha(e) {
      return {
        lane: e,
        tag: 0,
        payload: null,
        callback: null,
        next: null
      }
    }

    function Ua(e, t, n) {
      var r = e.updateQueue;
      if (r === null) return null;
      if (r = r.shared, q & 2) {
        var i = r.pending;
        return i === null ? t.next = t : (t.next = i.next, i.next = t), r.pending = t, t = si(e), oi(e, null, n), t
      }
      return ri(e, r, t, n), si(e)
    }

    function Wa(e, t, n) {
      if (t = t.updateQueue, t !== null && (t = t.shared, n & 4194048)) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, at(e, n)
      }
    }

    function Ga(e, t) {
      var n = e.updateQueue,
        r = e.alternate;
      if (r !== null && (r = r.updateQueue, n === r)) {
        var i = null,
          a = null;
        if (n = n.firstBaseUpdate, n !== null) {
          do {
            var o = {
              lane: n.lane,
              tag: n.tag,
              payload: n.payload,
              callback: null,
              next: null
            };
            a === null ? i = a = o : a = a.next = o, n = n.next
          } while (n !== null);
          a === null ? i = a = t : a = a.next = t
        } else i = a = t;
        n = {
          baseState: r.baseState,
          firstBaseUpdate: i,
          lastBaseUpdate: a,
          shared: r.shared,
          callbacks: r.callbacks
        }, e.updateQueue = n;
        return
      }
      e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
    }
    var Ka = !1;

    function qa() {
      if (Ka) {
        var e = fa;
        if (e !== null) throw e
      }
    }

    function Ja(e, t, n, r) {
      Ka = !1;
      var i = e.updateQueue;
      za = !1;
      var a = i.firstBaseUpdate,
        o = i.lastBaseUpdate,
        s = i.shared.pending;
      if (s !== null) {
        i.shared.pending = null;
        var c = s,
          l = c.next;
        c.next = null, o === null ? a = l : o.next = l, o = c;
        var u = e.alternate;
        u !== null && (u = u.updateQueue, s = u.lastBaseUpdate, s !== o && (s === null ? u.firstBaseUpdate = l : s.next = l, u.lastBaseUpdate = c))
      }
      if (a !== null) {
        var d = i.baseState;
        o = 0, u = l = c = null, s = a;
        do {
          var f = s.lane & -536870913,
            p = f !== s.lane;
          if (p ? (Y & f) === f : (r & f) === f) {
            f !== 0 && f === da && (Ka = !0), u !== null && (u = u.next = {
              lane: 0,
              tag: s.tag,
              payload: s.payload,
              callback: null,
              next: null
            });
            a: {
              var m = e,
                g = s;f = t;
              var _ = n;
              switch (g.tag) {
                case 1:
                  if (m = g.payload, typeof m == `function`) {
                    d = m.call(_, d, f);
                    break a
                  }
                  d = m;
                  break a;
                case 3:
                  m.flags = m.flags & -65537 | 128;
                case 0:
                  if (m = g.payload, f = typeof m == `function` ? m.call(_, d, f) : m, f == null) break a;
                  d = h({}, d, f);
                  break a;
                case 2:
                  za = !0
              }
            }
            f = s.callback, f !== null && (e.flags |= 64, p && (e.flags |= 8192), p = i.callbacks, p === null ? i.callbacks = [f] : p.push(f))
          } else p = {
            lane: f,
            tag: s.tag,
            payload: s.payload,
            callback: s.callback,
            next: null
          }, u === null ? (l = u = p, c = d) : u = u.next = p, o |= f;
          if (s = s.next, s === null) {
            if (s = i.shared.pending, s === null) break;
            p = s, s = p.next, p.next = null, i.lastBaseUpdate = p, i.shared.pending = null
          }
        } while (1);
        u === null && (c = d), i.baseState = c, i.firstBaseUpdate = l, i.lastBaseUpdate = u, a === null && (i.shared.lanes = 0), Gl |= o, e.lanes = o, e.memoizedState = d
      }
    }

    function Ya(e, t) {
      if (typeof e != `function`) throw Error(i(191, e));
      e.call(t)
    }

    function Xa(e, t) {
      var n = e.callbacks;
      if (n !== null)
        for (e.callbacks = null, e = 0; e < n.length; e++) Ya(n[e], t)
    }
    var Za = le(null),
      Qa = le(0);

    function $a(e, t) {
      e = Ul, M(Qa, e), M(Za, t), Ul = e | t.baseLanes
    }

    function V() {
      M(Qa, Ul), M(Za, Za.current)
    }

    function eo() {
      Ul = Qa.current, ue(Za), ue(Qa)
    }
    var to = le(null),
      no = null;

    function ro(e) {
      var t = e.alternate;
      M(co, co.current & 1), M(to, e), no === null && (t === null || Za.current !== null || t.memoizedState !== null) && (no = e)
    }

    function io(e) {
      M(co, co.current), M(to, e), no === null && (no = e)
    }

    function ao(e) {
      e.tag === 22 ? (M(co, co.current), M(to, e), no === null && (no = e)) : oo(e)
    }

    function oo() {
      M(co, co.current), M(to, to.current)
    }

    function so(e) {
      ue(to), no === e && (no = null), ue(co)
    }
    var co = le(0);

    function lo(e) {
      for (var t = e; t !== null;) {
        if (t.tag === 13) {
          var n = t.memoizedState;
          if (n !== null && (n = n.dehydrated, n === null || af(n) || of(n))) return t
        } else if (t.tag === 19 && (t.memoizedProps.revealOrder === `forwards` || t.memoizedProps.revealOrder === `backwards` || t.memoizedProps.revealOrder === `unstable_legacy-backwards` || t.memoizedProps.revealOrder === `together`)) {
          if (t.flags & 128) return t
        } else if (t.child !== null) {
          t.child.return = t, t = t.child;
          continue
        }
        if (t === e) break;
        for (; t.sibling === null;) {
          if (t.return === null || t.return === e) return null;
          t = t.return
        }
        t.sibling.return = t.return, t = t.sibling
      }
      return null
    }
    var uo = 0,
      H = null,
      U = null,
      fo = null,
      po = !1,
      mo = !1,
      ho = !1,
      go = 0,
      _o = 0,
      vo = null,
      yo = 0;

    function bo() {
      throw Error(i(321))
    }

    function xo(e, t) {
      if (t === null) return !1;
      for (var n = 0; n < t.length && n < e.length; n++)
        if (!Er(e[n], t[n])) return !1;
      return !0
    }

    function So(e, t, n, r, i, a) {
      return uo = a, H = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, A.H = e === null || e.memoizedState === null ? Is : Ls, ho = !1, a = n(r, i), ho = !1, mo && (a = Co(t, n, r, i)), W(e), a
    }

    function W(e) {
      A.H = Fs;
      var t = U !== null && U.next !== null;
      if (uo = 0, fo = U = H = null, po = !1, _o = 0, vo = null, t) throw Error(i(300));
      e === null || ec || (e = e.dependencies, e !== null && Qi(e) && (ec = !0))
    }

    function Co(e, t, n, r) {
      H = e;
      var a = 0;
      do {
        if (mo && (vo = null), _o = 0, mo = !1, 25 <= a) throw Error(i(301));
        if (a += 1, fo = U = null, e.updateQueue != null) {
          var o = e.updateQueue;
          o.lastEffect = null, o.events = null, o.stores = null, o.memoCache != null && (o.memoCache.index = 0)
        }
        A.H = Rs, o = t(n, r)
      } while (mo);
      return o
    }

    function wo() {
      var e = A.H,
        t = e.useState()[0];
      return t = typeof t.then == `function` ? jo(t) : t, e = e.useState()[0], (U === null ? null : U.memoizedState) !== e && (H.flags |= 1024), t
    }

    function To() {
      var e = go !== 0;
      return go = 0, e
    }

    function Eo(e, t, n) {
      t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~n
    }

    function Do(e) {
      if (po) {
        for (e = e.memoizedState; e !== null;) {
          var t = e.queue;
          t !== null && (t.pending = null), e = e.next
        }
        po = !1
      }
      uo = 0, fo = U = H = null, mo = !1, _o = go = 0, vo = null
    }

    function Oo() {
      var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
      };
      return fo === null ? H.memoizedState = fo = e : fo = fo.next = e, fo
    }

    function ko() {
      if (U === null) {
        var e = H.alternate;
        e = e === null ? null : e.memoizedState
      } else e = U.next;
      var t = fo === null ? H.memoizedState : fo.next;
      if (t !== null) fo = t, U = e;
      else {
        if (e === null) throw H.alternate === null ? Error(i(467)) : Error(i(310));
        U = e, e = {
          memoizedState: U.memoizedState,
          baseState: U.baseState,
          baseQueue: U.baseQueue,
          queue: U.queue,
          next: null
        }, fo === null ? H.memoizedState = fo = e : fo = fo.next = e
      }
      return fo
    }

    function Ao() {
      return {
        lastEffect: null,
        events: null,
        stores: null,
        memoCache: null
      }
    }

    function jo(e) {
      var t = _o;
      return _o += 1, vo === null && (vo = []), e = Ea(vo, e, t), t = H, (fo === null ? t.memoizedState : fo.next) === null && (t = t.alternate, A.H = t === null || t.memoizedState === null ? Is : Ls), e
    }

    function G(e) {
      if (typeof e == `object` && e) {
        if (typeof e.then == `function`) return jo(e);
        if (e.$$typeof === C) return ea(e)
      }
      throw Error(i(438, String(e)))
    }

    function K(e) {
      var t = null,
        n = H.updateQueue;
      if (n !== null && (t = n.memoCache), t == null) {
        var r = H.alternate;
        r !== null && (r = r.updateQueue, r !== null && (r = r.memoCache, r != null && (t = {
          data: r.data.map(function(e) {
            return e.slice()
          }),
          index: 0
        })))
      }
      if (t ??= {
          data: [],
          index: 0
        }, n === null && (n = Ao(), H.updateQueue = n), n.memoCache = t, n = t.data[t.index], n === void 0)
        for (n = t.data[t.index] = Array(e), r = 0; r < e; r++) n[r] = te;
      return t.index++, n
    }

    function Mo(e, t) {
      return typeof t == `function` ? t(e) : t
    }

    function No(e) {
      return Po(ko(), U, e)
    }

    function Po(e, t, n) {
      var r = e.queue;
      if (r === null) throw Error(i(311));
      r.lastRenderedReducer = n;
      var a = e.baseQueue,
        o = r.pending;
      if (o !== null) {
        if (a !== null) {
          var s = a.next;
          a.next = o.next, o.next = s
        }
        t.baseQueue = a = o, r.pending = null
      }
      if (o = e.baseState, a === null) e.memoizedState = o;
      else {
        t = a.next;
        var c = s = null,
          l = null,
          u = t,
          d = !1;
        do {
          var f = u.lane & -536870913;
          if (f === u.lane ? (uo & f) === f : (Y & f) === f) {
            var p = u.revertLane;
            if (p === 0) l !== null && (l = l.next = {
              lane: 0,
              revertLane: 0,
              gesture: null,
              action: u.action,
              hasEagerState: u.hasEagerState,
              eagerState: u.eagerState,
              next: null
            }), f === da && (d = !0);
            else if ((uo & p) === p) {
              u = u.next, p === da && (d = !0);
              continue
            } else f = {
              lane: 0,
              revertLane: u.revertLane,
              gesture: null,
              action: u.action,
              hasEagerState: u.hasEagerState,
              eagerState: u.eagerState,
              next: null
            }, l === null ? (c = l = f, s = o) : l = l.next = f, H.lanes |= p, Gl |= p;
            f = u.action, ho && n(o, f), o = u.hasEagerState ? u.eagerState : n(o, f)
          } else p = {
            lane: f,
            revertLane: u.revertLane,
            gesture: u.gesture,
            action: u.action,
            hasEagerState: u.hasEagerState,
            eagerState: u.eagerState,
            next: null
          }, l === null ? (c = l = p, s = o) : l = l.next = p, H.lanes |= f, Gl |= f;
          u = u.next
        } while (u !== null && u !== t);
        if (l === null ? s = o : l.next = c, !Er(o, e.memoizedState) && (ec = !0, d && (n = fa, n !== null))) throw n;
        e.memoizedState = o, e.baseState = s, e.baseQueue = l, r.lastRenderedState = o
      }
      return a === null && (r.lanes = 0), [e.memoizedState, r.dispatch]
    }

    function Fo(e) {
      var t = ko(),
        n = t.queue;
      if (n === null) throw Error(i(311));
      n.lastRenderedReducer = e;
      var r = n.dispatch,
        a = n.pending,
        o = t.memoizedState;
      if (a !== null) {
        n.pending = null;
        var s = a = a.next;
        do o = e(o, s.action), s = s.next; while (s !== a);
        Er(o, t.memoizedState) || (ec = !0), t.memoizedState = o, t.baseQueue === null && (t.baseState = o), n.lastRenderedState = o
      }
      return [o, r]
    }

    function Io(e, t, n) {
      var r = H,
        a = ko(),
        o = L;
      if (o) {
        if (n === void 0) throw Error(i(407));
        n = n()
      } else n = t();
      var s = !Er((U || a).memoizedState, n);
      if (s && (a.memoizedState = n, ec = !0), a = a.queue, ss(zo.bind(null, r, a, e), [e]), a.getSnapshot !== t || s || fo !== null && fo.memoizedState.tag & 1) {
        if (r.flags |= 2048, ns(9, {
            destroy: void 0
          }, Ro.bind(null, r, a, n, t), null), Rl === null) throw Error(i(349));
        o || uo & 127 || Lo(r, t, n)
      }
      return n
    }

    function Lo(e, t, n) {
      e.flags |= 16384, e = {
        getSnapshot: t,
        value: n
      }, t = H.updateQueue, t === null ? (t = Ao(), H.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e))
    }

    function Ro(e, t, n, r) {
      t.value = n, t.getSnapshot = r, Bo(t) && Vo(e)
    }

    function zo(e, t, n) {
      return n(function() {
        Bo(t) && Vo(e)
      })
    }

    function Bo(e) {
      var t = e.getSnapshot;
      e = e.value;
      try {
        var n = t();
        return !Er(e, n)
      } catch {
        return !0
      }
    }

    function Vo(e) {
      var t = ai(e, 2);
      t !== null && hu(t, e, 2)
    }

    function Ho(e) {
      var t = Oo();
      if (typeof e == `function`) {
        var n = e;
        if (e = n(), ho) {
          He(!0);
          try {
            n()
          } finally {
            He(!1)
          }
        }
      }
      return t.memoizedState = t.baseState = e, t.queue = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Mo,
        lastRenderedState: e
      }, t
    }

    function Uo(e, t, n, r) {
      return e.baseState = n, Po(e, U, typeof r == `function` ? r : Mo)
    }

    function Wo(e, t, n, r, a) {
      if (Ms(e)) throw Error(i(485));
      if (e = t.action, e !== null) {
        var o = {
          payload: a,
          action: e,
          next: null,
          isTransition: !0,
          status: `pending`,
          value: null,
          reason: null,
          listeners: [],
          then: function(e) {
            o.listeners.push(e)
          }
        };
        A.T === null ? o.isTransition = !1 : n(!0), r(o), n = t.pending, n === null ? (o.next = t.pending = o, Go(t, o)) : (o.next = n.next, t.pending = n.next = o)
      }
    }

    function Go(e, t) {
      var n = t.action,
        r = t.payload,
        i = e.state;
      if (t.isTransition) {
        var a = A.T,
          o = {};
        A.T = o;
        try {
          var s = n(i, r),
            c = A.S;
          c !== null && c(o, s), Ko(e, t, s)
        } catch (n) {
          Jo(e, t, n)
        } finally {
          a !== null && o.types !== null && (a.types = o.types), A.T = a
        }
      } else try {
        a = n(i, r), Ko(e, t, a)
      } catch (n) {
        Jo(e, t, n)
      }
    }

    function Ko(e, t, n) {
      typeof n == `object` && n && typeof n.then == `function` ? n.then(function(n) {
        qo(e, t, n)
      }, function(n) {
        return Jo(e, t, n)
      }) : qo(e, t, n)
    }

    function qo(e, t, n) {
      t.status = `fulfilled`, t.value = n, Yo(t), e.state = n, t = e.pending, t !== null && (n = t.next, n === t ? e.pending = null : (n = n.next, t.next = n, Go(e, n)))
    }

    function Jo(e, t, n) {
      var r = e.pending;
      if (e.pending = null, r !== null) {
        r = r.next;
        do t.status = `rejected`, t.reason = n, Yo(t), t = t.next; while (t !== r)
      }
      e.action = null
    }

    function Yo(e) {
      e = e.listeners;
      for (var t = 0; t < e.length; t++)(0, e[t])()
    }

    function Xo(e, t) {
      return t
    }

    function Zo(e, t) {
      if (L) {
        var n = Rl.formState;
        if (n !== null) {
          a: {
            var r = H;
            if (L) {
              if (Ii) {
                b: {
                  for (var i = Ii, a = Ri; i.nodeType !== 8;) {
                    if (!a) {
                      i = null;
                      break b
                    }
                    if (i = cf(i.nextSibling), i === null) {
                      i = null;
                      break b
                    }
                  }
                  a = i.data,
                  i = a === `F!` || a === `F` ? i : null
                }
                if (i) {
                  Ii = cf(i.nextSibling), r = i.data === `F!`;
                  break a
                }
              }
              Bi(r)
            }
            r = !1
          }
          r && (t = n[0])
        }
      }
      return n = Oo(), n.memoizedState = n.baseState = t, r = {
        pending: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: Xo,
        lastRenderedState: t
      }, n.queue = r, n = ks.bind(null, H, r), r.dispatch = n, r = Ho(!1), a = js.bind(null, H, !1, r.queue), r = Oo(), i = {
        state: t,
        dispatch: null,
        action: e,
        pending: null
      }, r.queue = i, n = Wo.bind(null, H, i, a, n), i.dispatch = n, r.memoizedState = e, [t, n, !1]
    }

    function Qo(e) {
      return $o(ko(), U, e)
    }

    function $o(e, t, n) {
      if (t = Po(e, t, Xo)[0], e = No(Mo)[0], typeof t == `object` && t && typeof t.then == `function`) try {
        var r = jo(t)
      } catch (e) {
        throw e === xa ? Ca : e
      } else r = t;
      t = ko();
      var i = t.queue,
        a = i.dispatch;
      return n !== t.memoizedState && (H.flags |= 2048, ns(9, {
        destroy: void 0
      }, es.bind(null, i, n), null)), [r, a, e]
    }

    function es(e, t) {
      e.action = t
    }

    function ts(e) {
      var t = ko(),
        n = U;
      if (n !== null) return $o(t, n, e);
      ko(), t = t.memoizedState, n = ko();
      var r = n.queue.dispatch;
      return n.memoizedState = e, [t, r, !1]
    }

    function ns(e, t, n, r) {
      return e = {
        tag: e,
        create: n,
        deps: r,
        inst: t,
        next: null
      }, t = H.updateQueue, t === null && (t = Ao(), H.updateQueue = t), n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e), e
    }

    function rs() {
      return ko().memoizedState
    }

    function is(e, t, n, r) {
      var i = Oo();
      H.flags |= e, i.memoizedState = ns(1 | t, {
        destroy: void 0
      }, n, r === void 0 ? null : r)
    }

    function as(e, t, n, r) {
      var i = ko();
      r = r === void 0 ? null : r;
      var a = i.memoizedState.inst;
      U !== null && r !== null && xo(r, U.memoizedState.deps) ? i.memoizedState = ns(t, a, n, r) : (H.flags |= e, i.memoizedState = ns(1 | t, a, n, r))
    }

    function os(e, t) {
      is(8390656, 8, e, t)
    }

    function ss(e, t) {
      as(2048, 8, e, t)
    }

    function cs(e) {
      H.flags |= 4;
      var t = H.updateQueue;
      if (t === null) t = Ao(), H.updateQueue = t, t.events = [e];
      else {
        var n = t.events;
        n === null ? t.events = [e] : n.push(e)
      }
    }

    function ls(e) {
      var t = ko().memoizedState;
      return cs({
          ref: t,
          nextImpl: e
        }),
        function() {
          if (q & 2) throw Error(i(440));
          return t.impl.apply(void 0, arguments)
        }
    }

    function us(e, t) {
      return as(4, 2, e, t)
    }

    function ds(e, t) {
      return as(4, 4, e, t)
    }

    function fs(e, t) {
      if (typeof t == `function`) {
        e = e();
        var n = t(e);
        return function() {
          typeof n == `function` ? n() : t(null)
        }
      }
      if (t != null) return e = e(), t.current = e,
        function() {
          t.current = null
        }
    }

    function ps(e, t, n) {
      n = n == null ? null : n.concat([e]), as(4, 4, fs.bind(null, t, e), n)
    }

    function ms() {}

    function hs(e, t) {
      var n = ko();
      t = t === void 0 ? null : t;
      var r = n.memoizedState;
      return t !== null && xo(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
    }

    function gs(e, t) {
      var n = ko();
      t = t === void 0 ? null : t;
      var r = n.memoizedState;
      if (t !== null && xo(t, r[1])) return r[0];
      if (r = e(), ho) {
        He(!0);
        try {
          e()
        } finally {
          He(!1)
        }
      }
      return n.memoizedState = [r, t], r
    }

    function _s(e, t, n) {
      return n === void 0 || uo & 1073741824 && !(Y & 261930) ? e.memoizedState = t : (e.memoizedState = n, e = mu(), H.lanes |= e, Gl |= e, n)
    }

    function vs(e, t, n, r) {
      return Er(n, t) ? n : Za.current === null ? !(uo & 42) || uo & 1073741824 && !(Y & 261930) ? (ec = !0, e.memoizedState = n) : (e = mu(), H.lanes |= e, Gl |= e, t) : (e = _s(e, n, r), Er(e, t) || (ec = !0), e)
    }

    function ys(e, t, n, r, i) {
      var a = j.p;
      j.p = a !== 0 && 8 > a ? a : 8;
      var o = A.T,
        s = {};
      A.T = s, js(e, !1, t, n);
      try {
        var c = i(),
          l = A.S;
        l !== null && l(s, c), typeof c == `object` && c && typeof c.then == `function` ? As(e, t, ha(c, r), pu(e)) : As(e, t, r, pu(e))
      } catch (n) {
        As(e, t, {
          then: function() {},
          status: `rejected`,
          reason: n
        }, pu())
      } finally {
        j.p = a, o !== null && s.types !== null && (o.types = s.types), A.T = o
      }
    }

    function bs() {}

    function xs(e, t, n, r) {
      if (e.tag !== 5) throw Error(i(476));
      var a = Ss(e).queue;
      ys(e, a, t, oe, n === null ? bs : function() {
        return Cs(e), n(r)
      })
    }

    function Ss(e) {
      var t = e.memoizedState;
      if (t !== null) return t;
      t = {
        memoizedState: oe,
        baseState: oe,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: Mo,
          lastRenderedState: oe
        },
        next: null
      };
      var n = {};
      return t.next = {
        memoizedState: n,
        baseState: n,
        baseQueue: null,
        queue: {
          pending: null,
          lanes: 0,
          dispatch: null,
          lastRenderedReducer: Mo,
          lastRenderedState: n
        },
        next: null
      }, e.memoizedState = t, e = e.alternate, e !== null && (e.memoizedState = t), t
    }

    function Cs(e) {
      var t = Ss(e);
      t.next === null && (t = e.alternate.memoizedState), As(e, t.next.queue, {}, pu())
    }

    function ws() {
      return ea(Qf)
    }

    function Ts() {
      return ko().memoizedState
    }

    function Es() {
      return ko().memoizedState
    }

    function Ds(e) {
      for (var t = e.return; t !== null;) {
        switch (t.tag) {
          case 24:
          case 3:
            var n = pu();
            e = Ha(n);
            var r = Ua(t, e, n);
            r !== null && (hu(r, t, n), Wa(r, t, n)), t = {
              cache: sa()
            }, e.payload = t;
            return
        }
        t = t.return
      }
    }

    function Os(e, t, n) {
      var r = pu();
      n = {
        lane: r,
        revertLane: 0,
        gesture: null,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null
      }, Ms(e) ? Ns(t, n) : (n = ii(e, t, n, r), n !== null && (hu(n, e, r), Ps(n, t, r)))
    }

    function ks(e, t, n) {
      As(e, t, n, pu())
    }

    function As(e, t, n, r) {
      var i = {
        lane: r,
        revertLane: 0,
        gesture: null,
        action: n,
        hasEagerState: !1,
        eagerState: null,
        next: null
      };
      if (Ms(e)) Ns(t, i);
      else {
        var a = e.alternate;
        if (e.lanes === 0 && (a === null || a.lanes === 0) && (a = t.lastRenderedReducer, a !== null)) try {
          var o = t.lastRenderedState,
            s = a(o, n);
          if (i.hasEagerState = !0, i.eagerState = s, Er(s, o)) return ri(e, t, i, 0), Rl === null && ni(), !1
        } catch {}
        if (n = ii(e, t, i, r), n !== null) return hu(n, e, r), Ps(n, t, r), !0
      }
      return !1
    }

    function js(e, t, n, r) {
      if (r = {
          lane: 2,
          revertLane: dd(),
          gesture: null,
          action: r,
          hasEagerState: !1,
          eagerState: null,
          next: null
        }, Ms(e)) {
        if (t) throw Error(i(479))
      } else t = ii(e, n, r, 2), t !== null && hu(t, e, 2)
    }

    function Ms(e) {
      var t = e.alternate;
      return e === H || t !== null && t === H
    }

    function Ns(e, t) {
      mo = po = !0;
      var n = e.pending;
      n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
    }

    function Ps(e, t, n) {
      if (n & 4194048) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, at(e, n)
      }
    }
    var Fs = {
      readContext: ea,
      use: G,
      useCallback: bo,
      useContext: bo,
      useEffect: bo,
      useImperativeHandle: bo,
      useLayoutEffect: bo,
      useInsertionEffect: bo,
      useMemo: bo,
      useReducer: bo,
      useRef: bo,
      useState: bo,
      useDebugValue: bo,
      useDeferredValue: bo,
      useTransition: bo,
      useSyncExternalStore: bo,
      useId: bo,
      useHostTransitionStatus: bo,
      useFormState: bo,
      useActionState: bo,
      useOptimistic: bo,
      useMemoCache: bo,
      useCacheRefresh: bo
    };
    Fs.useEffectEvent = bo;
    var Is = {
        readContext: ea,
        use: G,
        useCallback: function(e, t) {
          return Oo().memoizedState = [e, t === void 0 ? null : t], e
        },
        useContext: ea,
        useEffect: os,
        useImperativeHandle: function(e, t, n) {
          n = n == null ? null : n.concat([e]), is(4194308, 4, fs.bind(null, t, e), n)
        },
        useLayoutEffect: function(e, t) {
          return is(4194308, 4, e, t)
        },
        useInsertionEffect: function(e, t) {
          is(4, 2, e, t)
        },
        useMemo: function(e, t) {
          var n = Oo();
          t = t === void 0 ? null : t;
          var r = e();
          if (ho) {
            He(!0);
            try {
              e()
            } finally {
              He(!1)
            }
          }
          return n.memoizedState = [r, t], r
        },
        useReducer: function(e, t, n) {
          var r = Oo();
          if (n !== void 0) {
            var i = n(t);
            if (ho) {
              He(!0);
              try {
                n(t)
              } finally {
                He(!1)
              }
            }
          } else i = t;
          return r.memoizedState = r.baseState = i, e = {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: e,
            lastRenderedState: i
          }, r.queue = e, e = e.dispatch = Os.bind(null, H, e), [r.memoizedState, e]
        },
        useRef: function(e) {
          var t = Oo();
          return e = {
            current: e
          }, t.memoizedState = e
        },
        useState: function(e) {
          e = Ho(e);
          var t = e.queue,
            n = ks.bind(null, H, t);
          return t.dispatch = n, [e.memoizedState, n]
        },
        useDebugValue: ms,
        useDeferredValue: function(e, t) {
          return _s(Oo(), e, t)
        },
        useTransition: function() {
          var e = Ho(!1);
          return e = ys.bind(null, H, e.queue, !0, !1), Oo().memoizedState = e, [!1, e]
        },
        useSyncExternalStore: function(e, t, n) {
          var r = H,
            a = Oo();
          if (L) {
            if (n === void 0) throw Error(i(407));
            n = n()
          } else {
            if (n = t(), Rl === null) throw Error(i(349));
            Y & 127 || Lo(r, t, n)
          }
          a.memoizedState = n;
          var o = {
            value: n,
            getSnapshot: t
          };
          return a.queue = o, os(zo.bind(null, r, o, e), [e]), r.flags |= 2048, ns(9, {
            destroy: void 0
          }, Ro.bind(null, r, o, n, t), null), n
        },
        useId: function() {
          var e = Oo(),
            t = Rl.identifierPrefix;
          if (L) {
            var n = ki,
              r = Oi;
            n = (r & ~(1 << 32 - Ue(r) - 1)).toString(32) + n, t = `_` + t + `R_` + n, n = go++, 0 < n && (t += `H` + n.toString(32)), t += `_`
          } else n = yo++, t = `_` + t + `r_` + n.toString(32) + `_`;
          return e.memoizedState = t
        },
        useHostTransitionStatus: ws,
        useFormState: Zo,
        useActionState: Zo,
        useOptimistic: function(e) {
          var t = Oo();
          t.memoizedState = t.baseState = e;
          var n = {
            pending: null,
            lanes: 0,
            dispatch: null,
            lastRenderedReducer: null,
            lastRenderedState: null
          };
          return t.queue = n, t = js.bind(null, H, !0, n), n.dispatch = t, [e, t]
        },
        useMemoCache: K,
        useCacheRefresh: function() {
          return Oo().memoizedState = Ds.bind(null, H)
        },
        useEffectEvent: function(e) {
          var t = Oo(),
            n = {
              impl: e
            };
          return t.memoizedState = n,
            function() {
              if (q & 2) throw Error(i(440));
              return n.impl.apply(void 0, arguments)
            }
        }
      },
      Ls = {
        readContext: ea,
        use: G,
        useCallback: hs,
        useContext: ea,
        useEffect: ss,
        useImperativeHandle: ps,
        useInsertionEffect: us,
        useLayoutEffect: ds,
        useMemo: gs,
        useReducer: No,
        useRef: rs,
        useState: function() {
          return No(Mo)
        },
        useDebugValue: ms,
        useDeferredValue: function(e, t) {
          return vs(ko(), U.memoizedState, e, t)
        },
        useTransition: function() {
          var e = No(Mo)[0],
            t = ko().memoizedState;
          return [typeof e == `boolean` ? e : jo(e), t]
        },
        useSyncExternalStore: Io,
        useId: Ts,
        useHostTransitionStatus: ws,
        useFormState: Qo,
        useActionState: Qo,
        useOptimistic: function(e, t) {
          return Uo(ko(), U, e, t)
        },
        useMemoCache: K,
        useCacheRefresh: Es
      };
    Ls.useEffectEvent = ls;
    var Rs = {
      readContext: ea,
      use: G,
      useCallback: hs,
      useContext: ea,
      useEffect: ss,
      useImperativeHandle: ps,
      useInsertionEffect: us,
      useLayoutEffect: ds,
      useMemo: gs,
      useReducer: Fo,
      useRef: rs,
      useState: function() {
        return Fo(Mo)
      },
      useDebugValue: ms,
      useDeferredValue: function(e, t) {
        var n = ko();
        return U === null ? _s(n, e, t) : vs(n, U.memoizedState, e, t)
      },
      useTransition: function() {
        var e = Fo(Mo)[0],
          t = ko().memoizedState;
        return [typeof e == `boolean` ? e : jo(e), t]
      },
      useSyncExternalStore: Io,
      useId: Ts,
      useHostTransitionStatus: ws,
      useFormState: ts,
      useActionState: ts,
      useOptimistic: function(e, t) {
        var n = ko();
        return U === null ? (n.baseState = e, [e, n.queue.dispatch]) : Uo(n, U, e, t)
      },
      useMemoCache: K,
      useCacheRefresh: Es
    };
    Rs.useEffectEvent = ls;

    function zs(e, t, n, r) {
      t = e.memoizedState, n = n(r, t), n = n == null ? t : h({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n)
    }
    var Bs = {
      enqueueSetState: function(e, t, n) {
        e = e._reactInternals;
        var r = pu(),
          i = Ha(r);
        i.payload = t, n != null && (i.callback = n), t = Ua(e, i, r), t !== null && (hu(t, e, r), Wa(t, e, r))
      },
      enqueueReplaceState: function(e, t, n) {
        e = e._reactInternals;
        var r = pu(),
          i = Ha(r);
        i.tag = 1, i.payload = t, n != null && (i.callback = n), t = Ua(e, i, r), t !== null && (hu(t, e, r), Wa(t, e, r))
      },
      enqueueForceUpdate: function(e, t) {
        e = e._reactInternals;
        var n = pu(),
          r = Ha(n);
        r.tag = 2, t != null && (r.callback = t), t = Ua(e, r, n), t !== null && (hu(t, e, n), Wa(t, e, n))
      }
    };

    function Vs(e, t, n, r, i, a, o) {
      return e = e.stateNode, typeof e.shouldComponentUpdate == `function` ? e.shouldComponentUpdate(r, a, o) : t.prototype && t.prototype.isPureReactComponent ? !F(n, r) || !F(i, a) : !0
    }

    function Hs(e, t, n, r) {
      e = t.state, typeof t.componentWillReceiveProps == `function` && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == `function` && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && Bs.enqueueReplaceState(t, t.state, null)
    }

    function Us(e, t) {
      var n = t;
      if (`ref` in t)
        for (var r in n = {}, t) r !== `ref` && (n[r] = t[r]);
      if (e = e.defaultProps)
        for (var i in n === t && (n = h({}, n)), e) n[i] === void 0 && (n[i] = e[i]);
      return n
    }

    function Ws(e) {
      Qr(e)
    }

    function Gs(e) {
      console.error(e)
    }

    function Ks(e) {
      Qr(e)
    }

    function qs(e, t) {
      try {
        var n = e.onUncaughtError;
        n(t.value, {
          componentStack: t.stack
        })
      } catch (e) {
        setTimeout(function() {
          throw e
        })
      }
    }

    function Js(e, t, n) {
      try {
        var r = e.onCaughtError;
        r(n.value, {
          componentStack: n.stack,
          errorBoundary: t.tag === 1 ? t.stateNode : null
        })
      } catch (e) {
        setTimeout(function() {
          throw e
        })
      }
    }

    function Ys(e, t, n) {
      return n = Ha(n), n.tag = 3, n.payload = {
        element: null
      }, n.callback = function() {
        qs(e, t)
      }, n
    }

    function Xs(e) {
      return e = Ha(e), e.tag = 3, e
    }

    function Zs(e, t, n, r) {
      var i = n.type.getDerivedStateFromError;
      if (typeof i == `function`) {
        var a = r.value;
        e.payload = function() {
          return i(a)
        }, e.callback = function() {
          Js(t, n, r)
        }
      }
      var o = n.stateNode;
      o !== null && typeof o.componentDidCatch == `function` && (e.callback = function() {
        Js(t, n, r), typeof i != `function` && (ru === null ? ru = new Set([this]) : ru.add(this));
        var e = r.stack;
        this.componentDidCatch(r.value, {
          componentStack: e === null ? `` : e
        })
      })
    }

    function Qs(e, t, n, r, a) {
      if (n.flags |= 32768, typeof r == `object` && r && typeof r.then == `function`) {
        if (t = n.alternate, t !== null && Zi(t, n, a, !0), n = to.current, n !== null) {
          switch (n.tag) {
            case 31:
            case 13:
              return no === null ? Du() : n.alternate === null && Wl === 0 && (Wl = 3), n.flags &= -257, n.flags |= 65536, n.lanes = a, r === wa ? n.flags |= 16384 : (t = n.updateQueue, t === null ? n.updateQueue = new Set([r]) : t.add(r), Gu(e, r, a)), !1;
            case 22:
              return n.flags |= 65536, r === wa ? n.flags |= 16384 : (t = n.updateQueue, t === null ? (t = {
                transitions: null,
                markerInstances: null,
                retryQueue: new Set([r])
              }, n.updateQueue = t) : (n = t.retryQueue, n === null ? t.retryQueue = new Set([r]) : n.add(r)), Gu(e, r, a)), !1
          }
          throw Error(i(435, n.tag))
        }
        return Gu(e, r, a), Du(), !1
      }
      if (L) return t = to.current, t === null ? (r !== zi && (t = Error(i(423), {
        cause: r
      }), Gi(bi(t, n))), e = e.current.alternate, e.flags |= 65536, a &= -a, e.lanes |= a, r = bi(r, n), a = Ys(e.stateNode, r, a), Ga(e, a), Wl !== 4 && (Wl = 2)) : (!(t.flags & 65536) && (t.flags |= 256), t.flags |= 65536, t.lanes = a, r !== zi && (e = Error(i(422), {
        cause: r
      }), Gi(bi(e, n)))), !1;
      var o = Error(i(520), {
        cause: r
      });
      if (o = bi(o, n), Xl === null ? Xl = [o] : Xl.push(o), Wl !== 4 && (Wl = 2), t === null) return !0;
      r = bi(r, n), n = t;
      do {
        switch (n.tag) {
          case 3:
            return n.flags |= 65536, e = a & -a, n.lanes |= e, e = Ys(n.stateNode, r, e), Ga(n, e), !1;
          case 1:
            if (t = n.type, o = n.stateNode, !(n.flags & 128) && (typeof t.getDerivedStateFromError == `function` || o !== null && typeof o.componentDidCatch == `function` && (ru === null || !ru.has(o)))) return n.flags |= 65536, a &= -a, n.lanes |= a, a = Xs(a), Zs(a, e, n, r), Ga(n, a), !1
        }
        n = n.return
      } while (n !== null);
      return !1
    }
    var $s = Error(i(461)),
      ec = !1;

    function tc(e, t, n, r) {
      t.child = e === null ? Ra(t, null, n, r) : La(t, e.child, n, r)
    }

    function nc(e, t, n, r, i) {
      n = n.render;
      var a = t.ref;
      if (`ref` in r) {
        var o = {};
        for (var s in r) s !== `ref` && (o[s] = r[s])
      } else o = r;
      return $i(t), r = So(e, t, n, o, a, i), s = To(), e !== null && !ec ? (Eo(e, t, i), Ec(e, t, i)) : (L && s && Mi(t), t.flags |= 1, tc(e, t, r, i), t.child)
    }

    function rc(e, t, n, r, i) {
      if (e === null) {
        var a = n.type;
        return typeof a == `function` && !di(a) && a.defaultProps === void 0 && n.compare === null ? (t.tag = 15, t.type = a, ic(e, t, a, r, i)) : (e = mi(n.type, null, r, t, t.mode, i), e.ref = t.ref, e.return = t, t.child = e)
      }
      if (a = e.child, !Dc(e, i)) {
        var o = a.memoizedProps;
        if (n = n.compare, n = n === null ? F : n, n(o, r) && e.ref === t.ref) return Ec(e, t, i)
      }
      return t.flags |= 1, e = fi(a, r), e.ref = t.ref, e.return = t, t.child = e
    }

    function ic(e, t, n, r, i) {
      if (e !== null) {
        var a = e.memoizedProps;
        if (F(a, r) && e.ref === t.ref)
          if (ec = !1, t.pendingProps = r = a, Dc(e, i)) e.flags & 131072 && (ec = !0);
          else return t.lanes = e.lanes, Ec(e, t, i)
      }
      return fc(e, t, n, r, i)
    }

    function ac(e, t, n, r) {
      var i = r.children,
        a = e === null ? null : e.memoizedState;
      if (e === null && t.stateNode === null && (t.stateNode = {
          _visibility: 1,
          _pendingMarkers: null,
          _retryCache: null,
          _transitions: null
        }), r.mode === `hidden`) {
        if (t.flags & 128) {
          if (a = a === null ? n : a.baseLanes | n, e !== null) {
            for (r = t.child = e.child, i = 0; r !== null;) i = i | r.lanes | r.childLanes, r = r.sibling;
            r = i & ~a
          } else r = 0, t.child = null;
          return sc(e, t, a, n, r)
        }
        if (n & 536870912) t.memoizedState = {
          baseLanes: 0,
          cachePool: null
        }, e !== null && ya(t, a === null ? null : a.cachePool), a === null ? V() : $a(t, a), ao(t);
        else return r = t.lanes = 536870912, sc(e, t, a === null ? n : a.baseLanes | n, n, r)
      } else a === null ? (e !== null && ya(t, null), V(), oo(t)) : (ya(t, a.cachePool), $a(t, a), oo(t), t.memoizedState = null);
      return tc(e, t, i, n), t.child
    }

    function oc(e, t) {
      return e !== null && e.tag === 22 || t.stateNode !== null || (t.stateNode = {
        _visibility: 1,
        _pendingMarkers: null,
        _retryCache: null,
        _transitions: null
      }), t.sibling
    }

    function sc(e, t, n, r, i) {
      var a = va();
      return a = a === null ? null : {
        parent: oa._currentValue,
        pool: a
      }, t.memoizedState = {
        baseLanes: n,
        cachePool: a
      }, e !== null && ya(t, null), V(), ao(t), e !== null && Zi(e, t, r, !0), t.childLanes = i, null
    }

    function cc(e, t) {
      return t = xc({
        mode: t.mode,
        children: t.children
      }, e.mode), t.ref = e.ref, e.child = t, t.return = e, t
    }

    function lc(e, t, n) {
      return La(t, e.child, null, n), e = cc(t, t.pendingProps), e.flags |= 2, so(t), t.memoizedState = null, e
    }

    function uc(e, t, n) {
      var r = t.pendingProps,
        a = (t.flags & 128) != 0;
      if (t.flags &= -129, e === null) {
        if (L) {
          if (r.mode === `hidden`) return e = cc(t, r), t.lanes = 536870912, oc(null, e);
          if (io(t), (e = Ii) ? (e = rf(e, Ri), e = e !== null && e.data === `&` ? e : null, e !== null && (t.memoizedState = {
              dehydrated: e,
              treeContext: Di === null ? null : {
                id: Oi,
                overflow: ki
              },
              retryLane: 536870912,
              hydrationErrors: null
            }, n = _i(e), n.return = t, t.child = n, Fi = t, Ii = null)) : e = null, e === null) throw Bi(t);
          return t.lanes = 536870912, null
        }
        return cc(t, r)
      }
      var o = e.memoizedState;
      if (o !== null) {
        var s = o.dehydrated;
        if (io(t), a)
          if (t.flags & 256) t.flags &= -257, t = lc(e, t, n);
          else if (t.memoizedState !== null) t.child = e.child, t.flags |= 128, t = null;
        else throw Error(i(558));
        else if (ec || Zi(e, t, n, !1), a = (n & e.childLanes) !== 0, ec || a) {
          if (r = Rl, r !== null && (s = ot(r, n), s !== 0 && s !== o.retryLane)) throw o.retryLane = s, ai(e, s), hu(r, e, s), $s;
          Du(), t = lc(e, t, n)
        } else e = o.treeContext, Ii = cf(s.nextSibling), Fi = t, L = !0, Li = null, Ri = !1, e !== null && Pi(t, e), t = cc(t, r), t.flags |= 4096;
        return t
      }
      return e = fi(e.child, {
        mode: r.mode,
        children: r.children
      }), e.ref = t.ref, t.child = e, e.return = t, e
    }

    function dc(e, t) {
      var n = t.ref;
      if (n === null) e !== null && e.ref !== null && (t.flags |= 4194816);
      else {
        if (typeof n != `function` && typeof n != `object`) throw Error(i(284));
        (e === null || e.ref !== n) && (t.flags |= 4194816)
      }
    }

    function fc(e, t, n, r, i) {
      return $i(t), n = So(e, t, n, r, void 0, i), r = To(), e !== null && !ec ? (Eo(e, t, i), Ec(e, t, i)) : (L && r && Mi(t), t.flags |= 1, tc(e, t, n, i), t.child)
    }

    function pc(e, t, n, r, i, a) {
      return $i(t), t.updateQueue = null, n = Co(t, r, n, i), W(e), r = To(), e !== null && !ec ? (Eo(e, t, a), Ec(e, t, a)) : (L && r && Mi(t), t.flags |= 1, tc(e, t, n, a), t.child)
    }

    function mc(e, t, n, r, i) {
      if ($i(t), t.stateNode === null) {
        var a = ci,
          o = n.contextType;
        typeof o == `object` && o && (a = ea(o)), a = new n(r, a), t.memoizedState = a.state !== null && a.state !== void 0 ? a.state : null, a.updater = Bs, t.stateNode = a, a._reactInternals = t, a = t.stateNode, a.props = r, a.state = t.memoizedState, a.refs = {}, Ba(t), o = n.contextType, a.context = typeof o == `object` && o ? ea(o) : ci, a.state = t.memoizedState, o = n.getDerivedStateFromProps, typeof o == `function` && (zs(t, n, o, r), a.state = t.memoizedState), typeof n.getDerivedStateFromProps == `function` || typeof a.getSnapshotBeforeUpdate == `function` || typeof a.UNSAFE_componentWillMount != `function` && typeof a.componentWillMount != `function` || (o = a.state, typeof a.componentWillMount == `function` && a.componentWillMount(), typeof a.UNSAFE_componentWillMount == `function` && a.UNSAFE_componentWillMount(), o !== a.state && Bs.enqueueReplaceState(a, a.state, null), Ja(t, r, a, i), qa(), a.state = t.memoizedState), typeof a.componentDidMount == `function` && (t.flags |= 4194308), r = !0
      } else if (e === null) {
        a = t.stateNode;
        var s = t.memoizedProps,
          c = Us(n, s);
        a.props = c;
        var l = a.context,
          u = n.contextType;
        o = ci, typeof u == `object` && u && (o = ea(u));
        var d = n.getDerivedStateFromProps;
        u = typeof d == `function` || typeof a.getSnapshotBeforeUpdate == `function`, s = t.pendingProps !== s, u || typeof a.UNSAFE_componentWillReceiveProps != `function` && typeof a.componentWillReceiveProps != `function` || (s || l !== o) && Hs(t, a, r, o), za = !1;
        var f = t.memoizedState;
        a.state = f, Ja(t, r, a, i), qa(), l = t.memoizedState, s || f !== l || za ? (typeof d == `function` && (zs(t, n, d, r), l = t.memoizedState), (c = za || Vs(t, n, c, r, f, l, o)) ? (u || typeof a.UNSAFE_componentWillMount != `function` && typeof a.componentWillMount != `function` || (typeof a.componentWillMount == `function` && a.componentWillMount(), typeof a.UNSAFE_componentWillMount == `function` && a.UNSAFE_componentWillMount()), typeof a.componentDidMount == `function` && (t.flags |= 4194308)) : (typeof a.componentDidMount == `function` && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = l), a.props = r, a.state = l, a.context = o, r = c) : (typeof a.componentDidMount == `function` && (t.flags |= 4194308), r = !1)
      } else {
        a = t.stateNode, Va(e, t), o = t.memoizedProps, u = Us(n, o), a.props = u, d = t.pendingProps, f = a.context, l = n.contextType, c = ci, typeof l == `object` && l && (c = ea(l)), s = n.getDerivedStateFromProps, (l = typeof s == `function` || typeof a.getSnapshotBeforeUpdate == `function`) || typeof a.UNSAFE_componentWillReceiveProps != `function` && typeof a.componentWillReceiveProps != `function` || (o !== d || f !== c) && Hs(t, a, r, c), za = !1, f = t.memoizedState, a.state = f, Ja(t, r, a, i), qa();
        var p = t.memoizedState;
        o !== d || f !== p || za || e !== null && e.dependencies !== null && Qi(e.dependencies) ? (typeof s == `function` && (zs(t, n, s, r), p = t.memoizedState), (u = za || Vs(t, n, u, r, f, p, c) || e !== null && e.dependencies !== null && Qi(e.dependencies)) ? (l || typeof a.UNSAFE_componentWillUpdate != `function` && typeof a.componentWillUpdate != `function` || (typeof a.componentWillUpdate == `function` && a.componentWillUpdate(r, p, c), typeof a.UNSAFE_componentWillUpdate == `function` && a.UNSAFE_componentWillUpdate(r, p, c)), typeof a.componentDidUpdate == `function` && (t.flags |= 4), typeof a.getSnapshotBeforeUpdate == `function` && (t.flags |= 1024)) : (typeof a.componentDidUpdate != `function` || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != `function` || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = p), a.props = r, a.state = p, a.context = c, r = u) : (typeof a.componentDidUpdate != `function` || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof a.getSnapshotBeforeUpdate != `function` || o === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), r = !1)
      }
      return a = r, dc(e, t), r = (t.flags & 128) != 0, a || r ? (a = t.stateNode, n = r && typeof n.getDerivedStateFromError != `function` ? null : a.render(), t.flags |= 1, e !== null && r ? (t.child = La(t, e.child, null, i), t.child = La(t, null, n, i)) : tc(e, t, n, i), t.memoizedState = a.state, e = t.child) : e = Ec(e, t, i), e
    }

    function hc(e, t, n, r) {
      return R(), t.flags |= 256, tc(e, t, n, r), t.child
    }
    var gc = {
      dehydrated: null,
      treeContext: null,
      retryLane: 0,
      hydrationErrors: null
    };

    function _c(e) {
      return {
        baseLanes: e,
        cachePool: ba()
      }
    }

    function vc(e, t, n) {
      return e = e === null ? 0 : e.childLanes & ~n, t && (e |= Jl), e
    }

    function yc(e, t, n) {
      var r = t.pendingProps,
        a = !1,
        o = (t.flags & 128) != 0,
        s;
      if ((s = o) || (s = e !== null && e.memoizedState === null ? !1 : (co.current & 2) != 0), s && (a = !0, t.flags &= -129), s = (t.flags & 32) != 0, t.flags &= -33, e === null) {
        if (L) {
          if (a ? ro(t) : oo(t), (e = Ii) ? (e = rf(e, Ri), e = e !== null && e.data !== `&` ? e : null, e !== null && (t.memoizedState = {
              dehydrated: e,
              treeContext: Di === null ? null : {
                id: Oi,
                overflow: ki
              },
              retryLane: 536870912,
              hydrationErrors: null
            }, n = _i(e), n.return = t, t.child = n, Fi = t, Ii = null)) : e = null, e === null) throw Bi(t);
          return of(e) ? t.lanes = 32 : t.lanes = 536870912, null
        }
        var c = r.children;
        return r = r.fallback, a ? (oo(t), a = t.mode, c = xc({
          mode: `hidden`,
          children: c
        }, a), r = hi(r, a, n, null), c.return = t, r.return = t, c.sibling = r, t.child = c, r = t.child, r.memoizedState = _c(n), r.childLanes = vc(e, s, n), t.memoizedState = gc, oc(null, r)) : (ro(t), bc(t, c))
      }
      var l = e.memoizedState;
      if (l !== null && (c = l.dehydrated, c !== null)) {
        if (o) t.flags & 256 ? (ro(t), t.flags &= -257, t = Sc(e, t, n)) : t.memoizedState === null ? (oo(t), c = r.fallback, a = t.mode, r = xc({
          mode: `visible`,
          children: r.children
        }, a), c = hi(c, a, n, null), c.flags |= 2, r.return = t, c.return = t, r.sibling = c, t.child = r, La(t, e.child, null, n), r = t.child, r.memoizedState = _c(n), r.childLanes = vc(e, s, n), t.memoizedState = gc, t = oc(null, r)) : (oo(t), t.child = e.child, t.flags |= 128, t = null);
        else if (ro(t), of(c)) {
          if (s = c.nextSibling && c.nextSibling.dataset, s) var u = s.dgst;
          s = u, r = Error(i(419)), r.stack = ``, r.digest = s, Gi({
            value: r,
            source: null,
            stack: null
          }), t = Sc(e, t, n)
        } else if (ec || Zi(e, t, n, !1), s = (n & e.childLanes) !== 0, ec || s) {
          if (s = Rl, s !== null && (r = ot(s, n), r !== 0 && r !== l.retryLane)) throw l.retryLane = r, ai(e, r), hu(s, e, r), $s;
          af(c) || Du(), t = Sc(e, t, n)
        } else af(c) ? (t.flags |= 192, t.child = e.child, t = null) : (e = l.treeContext, Ii = cf(c.nextSibling), Fi = t, L = !0, Li = null, Ri = !1, e !== null && Pi(t, e), t = bc(t, r.children), t.flags |= 4096);
        return t
      }
      return a ? (oo(t), c = r.fallback, a = t.mode, l = e.child, u = l.sibling, r = fi(l, {
        mode: `hidden`,
        children: r.children
      }), r.subtreeFlags = l.subtreeFlags & 65011712, u === null ? (c = hi(c, a, n, null), c.flags |= 2) : c = fi(u, c), c.return = t, r.return = t, r.sibling = c, t.child = r, oc(null, r), r = t.child, c = e.child.memoizedState, c === null ? c = _c(n) : (a = c.cachePool, a === null ? a = ba() : (l = oa._currentValue, a = a.parent === l ? a : {
        parent: l,
        pool: l
      }), c = {
        baseLanes: c.baseLanes | n,
        cachePool: a
      }), r.memoizedState = c, r.childLanes = vc(e, s, n), t.memoizedState = gc, oc(e.child, r)) : (ro(t), n = e.child, e = n.sibling, n = fi(n, {
        mode: `visible`,
        children: r.children
      }), n.return = t, n.sibling = null, e !== null && (s = t.deletions, s === null ? (t.deletions = [e], t.flags |= 16) : s.push(e)), t.child = n, t.memoizedState = null, n)
    }

    function bc(e, t) {
      return t = xc({
        mode: `visible`,
        children: t
      }, e.mode), t.return = e, e.child = t
    }

    function xc(e, t) {
      return e = ui(22, e, null, t), e.lanes = 0, e
    }

    function Sc(e, t, n) {
      return La(t, e.child, null, n), e = bc(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e
    }

    function Cc(e, t, n) {
      e.lanes |= t;
      var r = e.alternate;
      r !== null && (r.lanes |= t), Yi(e.return, t, n)
    }

    function wc(e, t, n, r, i, a) {
      var o = e.memoizedState;
      o === null ? e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: r,
        tail: n,
        tailMode: i,
        treeForkCount: a
      } : (o.isBackwards = t, o.rendering = null, o.renderingStartTime = 0, o.last = r, o.tail = n, o.tailMode = i, o.treeForkCount = a)
    }

    function Tc(e, t, n) {
      var r = t.pendingProps,
        i = r.revealOrder,
        a = r.tail;
      r = r.children;
      var o = co.current,
        s = (o & 2) != 0;
      if (s ? (o = o & 1 | 2, t.flags |= 128) : o &= 1, M(co, o), tc(e, t, r, n), r = L ? wi : 0, !s && e !== null && e.flags & 128) a: for (e = t.child; e !== null;) {
        if (e.tag === 13) e.memoizedState !== null && Cc(e, n, t);
        else if (e.tag === 19) Cc(e, n, t);
        else if (e.child !== null) {
          e.child.return = e, e = e.child;
          continue
        }
        if (e === t) break a;
        for (; e.sibling === null;) {
          if (e.return === null || e.return === t) break a;
          e = e.return
        }
        e.sibling.return = e.return, e = e.sibling
      }
      switch (i) {
        case `forwards`:
          for (n = t.child, i = null; n !== null;) e = n.alternate, e !== null && lo(e) === null && (i = n), n = n.sibling;
          n = i, n === null ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null), wc(t, !1, i, n, a, r);
          break;
        case `backwards`:
        case `unstable_legacy-backwards`:
          for (n = null, i = t.child, t.child = null; i !== null;) {
            if (e = i.alternate, e !== null && lo(e) === null) {
              t.child = i;
              break
            }
            e = i.sibling, i.sibling = n, n = i, i = e
          }
          wc(t, !0, n, null, a, r);
          break;
        case `together`:
          wc(t, !1, null, null, void 0, r);
          break;
        default:
          t.memoizedState = null
      }
      return t.child
    }

    function Ec(e, t, n) {
      if (e !== null && (t.dependencies = e.dependencies), Gl |= t.lanes, (n & t.childLanes) === 0)
        if (e !== null) {
          if (Zi(e, t, n, !1), (n & t.childLanes) === 0) return null
        } else return null;
      if (e !== null && t.child !== e.child) throw Error(i(153));
      if (t.child !== null) {
        for (e = t.child, n = fi(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = fi(e, e.pendingProps), n.return = t;
        n.sibling = null
      }
      return t.child
    }

    function Dc(e, t) {
      return (e.lanes & t) === 0 ? (e = e.dependencies, !!(e !== null && Qi(e))) : !0
    }

    function Oc(e, t, n) {
      switch (t.tag) {
        case 3:
          he(t, t.stateNode.containerInfo), Ji(t, oa, e.memoizedState.cache), R();
          break;
        case 27:
        case 5:
          _e(t);
          break;
        case 4:
          he(t, t.stateNode.containerInfo);
          break;
        case 10:
          Ji(t, t.type, t.memoizedProps.value);
          break;
        case 31:
          if (t.memoizedState !== null) return t.flags |= 128, io(t), null;
          break;
        case 13:
          var r = t.memoizedState;
          if (r !== null) return r.dehydrated === null ? (n & t.child.childLanes) === 0 ? (ro(t), e = Ec(e, t, n), e === null ? null : e.sibling) : yc(e, t, n) : (ro(t), t.flags |= 128, null);
          ro(t);
          break;
        case 19:
          var i = (e.flags & 128) != 0;
          if (r = (n & t.childLanes) !== 0, r ||= (Zi(e, t, n, !1), (n & t.childLanes) !== 0), i) {
            if (r) return Tc(e, t, n);
            t.flags |= 128
          }
          if (i = t.memoizedState, i !== null && (i.rendering = null, i.tail = null, i.lastEffect = null), M(co, co.current), r) break;
          return null;
        case 22:
          return t.lanes = 0, ac(e, t, n, t.pendingProps);
        case 24:
          Ji(t, oa, e.memoizedState.cache)
      }
      return Ec(e, t, n)
    }

    function kc(e, t, n) {
      if (e !== null)
        if (e.memoizedProps !== t.pendingProps) ec = !0;
        else {
          if (!Dc(e, n) && !(t.flags & 128)) return ec = !1, Oc(e, t, n);
          ec = !!(e.flags & 131072)
        }
      else ec = !1, L && t.flags & 1048576 && ji(t, wi, t.index);
      switch (t.lanes = 0, t.tag) {
        case 16:
          a: {
            var r = t.pendingProps;
            if (e = Da(t.elementType), t.type = e, typeof e == `function`) di(e) ? (r = Us(e, r), t.tag = 1, t = mc(null, t, e, r, n)) : (t.tag = 0, t = fc(null, t, e, r, n));
            else {
              if (e != null) {
                var a = e.$$typeof;
                if (a === w) {
                  t.tag = 11, t = nc(null, t, e, r, n);
                  break a
                } else if (a === D) {
                  t.tag = 14, t = rc(null, t, e, r, n);
                  break a
                }
              }
              throw t = ie(e) || e, Error(i(306, t, ``))
            }
          }
          return t;
        case 0:
          return fc(e, t, t.type, t.pendingProps, n);
        case 1:
          return r = t.type, a = Us(r, t.pendingProps), mc(e, t, r, a, n);
        case 3:
          a: {
            if (he(t, t.stateNode.containerInfo), e === null) throw Error(i(387));r = t.pendingProps;
            var o = t.memoizedState;a = o.element,
            Va(e, t),
            Ja(t, r, null, n);
            var s = t.memoizedState;
            if (r = s.cache, Ji(t, oa, r), r !== o.cache && Xi(t, [oa], n, !0), qa(), r = s.element, o.isDehydrated)
              if (o = {
                  element: r,
                  isDehydrated: !1,
                  cache: s.cache
                }, t.updateQueue.baseState = o, t.memoizedState = o, t.flags & 256) {
                t = hc(e, t, r, n);
                break a
              } else if (r !== a) {
              a = bi(Error(i(424)), t), Gi(a), t = hc(e, t, r, n);
              break a
            } else {
              switch (e = t.stateNode.containerInfo, e.nodeType) {
                case 9:
                  e = e.body;
                  break;
                default:
                  e = e.nodeName === `HTML` ? e.ownerDocument.body : e
              }
              for (Ii = cf(e.firstChild), Fi = t, L = !0, Li = null, Ri = !0, n = Ra(t, null, r, n), t.child = n; n;) n.flags = n.flags & -3 | 4096, n = n.sibling
            } else {
              if (R(), r === a) {
                t = Ec(e, t, n);
                break a
              }
              tc(e, t, r, n)
            }
            t = t.child
          }
          return t;
        case 26:
          return dc(e, t), e === null ? (n = kf(t.type, null, t.pendingProps, null)) ? t.memoizedState = n : L || (n = t.type, e = t.pendingProps, r = Bd(pe.current).createElement(n), r[ft] = t, r[pt] = e, Pd(r, n, e), Tt(r), t.stateNode = r) : t.memoizedState = kf(t.type, e.memoizedProps, t.pendingProps, e.memoizedState), null;
        case 27:
          return _e(t), e === null && L && (r = t.stateNode = ff(t.type, t.pendingProps, pe.current), Fi = t, Ri = !0, a = Ii, Zd(t.type) ? (lf = a, Ii = cf(r.firstChild)) : Ii = a), tc(e, t, t.pendingProps.children, n), dc(e, t), e === null && (t.flags |= 4194304), t.child;
        case 5:
          return e === null && L && ((a = r = Ii) && (r = tf(r, t.type, t.pendingProps, Ri), r === null ? a = !1 : (t.stateNode = r, Fi = t, Ii = cf(r.firstChild), Ri = !1, a = !0)), a || Bi(t)), _e(t), a = t.type, o = t.pendingProps, s = e === null ? null : e.memoizedProps, r = o.children, Ud(a, o) ? r = null : s !== null && Ud(a, s) && (t.flags |= 32), t.memoizedState !== null && (a = So(e, t, wo, null, null, n), Qf._currentValue = a), dc(e, t), tc(e, t, r, n), t.child;
        case 6:
          return e === null && L && ((e = n = Ii) && (n = nf(n, t.pendingProps, Ri), n === null ? e = !1 : (t.stateNode = n, Fi = t, Ii = null, e = !0)), e || Bi(t)), null;
        case 13:
          return yc(e, t, n);
        case 4:
          return he(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = La(t, null, r, n) : tc(e, t, r, n), t.child;
        case 11:
          return nc(e, t, t.type, t.pendingProps, n);
        case 7:
          return tc(e, t, t.pendingProps, n), t.child;
        case 8:
          return tc(e, t, t.pendingProps.children, n), t.child;
        case 12:
          return tc(e, t, t.pendingProps.children, n), t.child;
        case 10:
          return r = t.pendingProps, Ji(t, t.type, r.value), tc(e, t, r.children, n), t.child;
        case 9:
          return a = t.type._context, r = t.pendingProps.children, $i(t), a = ea(a), r = r(a), t.flags |= 1, tc(e, t, r, n), t.child;
        case 14:
          return rc(e, t, t.type, t.pendingProps, n);
        case 15:
          return ic(e, t, t.type, t.pendingProps, n);
        case 19:
          return Tc(e, t, n);
        case 31:
          return uc(e, t, n);
        case 22:
          return ac(e, t, n, t.pendingProps);
        case 24:
          return $i(t), r = ea(oa), e === null ? (a = va(), a === null && (a = Rl, o = sa(), a.pooledCache = o, o.refCount++, o !== null && (a.pooledCacheLanes |= n), a = o), t.memoizedState = {
            parent: r,
            cache: a
          }, Ba(t), Ji(t, oa, a)) : ((e.lanes & n) !== 0 && (Va(e, t), Ja(t, null, null, n), qa()), a = e.memoizedState, o = t.memoizedState, a.parent === r ? (r = o.cache, Ji(t, oa, r), r !== a.cache && Xi(t, [oa], n, !0)) : (a = {
            parent: r,
            cache: r
          }, t.memoizedState = a, t.lanes === 0 && (t.memoizedState = t.updateQueue.baseState = a), Ji(t, oa, r))), tc(e, t, t.pendingProps.children, n), t.child;
        case 29:
          throw t.pendingProps
      }
      throw Error(i(156, t.tag))
    }

    function Ac(e) {
      e.flags |= 4
    }

    function jc(e, t, n, r, i) {
      if ((t = (e.mode & 32) != 0) && (t = !1), t) {
        if (e.flags |= 16777216, (i & 335544128) === i)
          if (e.stateNode.complete) e.flags |= 8192;
          else if (wu()) e.flags |= 8192;
        else throw Oa = wa, Sa
      } else e.flags &= -16777217
    }

    function Mc(e, t) {
      if (t.type !== `stylesheet` || t.state.loading & 4) e.flags &= -16777217;
      else if (e.flags |= 16777216, !Wf(t))
        if (wu()) e.flags |= 8192;
        else throw Oa = wa, Sa
    }

    function Nc(e, t) {
      t !== null && (e.flags |= 4), e.flags & 16384 && (t = e.tag === 22 ? 536870912 : et(), e.lanes |= t, Yl |= t)
    }

    function Pc(e, t) {
      if (!L) switch (e.tailMode) {
        case `hidden`:
          t = e.tail;
          for (var n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
          n === null ? e.tail = null : n.sibling = null;
          break;
        case `collapsed`:
          n = e.tail;
          for (var r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
          r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null
      }
    }

    function Fc(e) {
      var t = e.alternate !== null && e.alternate.child === e.child,
        n = 0,
        r = 0;
      if (t)
        for (var i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags & 65011712, r |= i.flags & 65011712, i.return = e, i = i.sibling;
      else
        for (i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags, r |= i.flags, i.return = e, i = i.sibling;
      return e.subtreeFlags |= r, e.childLanes = n, t
    }

    function Ic(e, t, n) {
      var r = t.pendingProps;
      switch (Ni(t), t.tag) {
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
          return Fc(t), null;
        case 1:
          return Fc(t), null;
        case 3:
          return n = t.stateNode, r = null, e !== null && (r = e.memoizedState.cache), t.memoizedState.cache !== r && (t.flags |= 2048), B(oa), ge(), n.pendingContext && (n.context = n.pendingContext, n.pendingContext = null), (e === null || e.child === null) && (Ui(t) ? Ac(t) : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, Wi())), Fc(t), null;
        case 26:
          var a = t.type,
            o = t.memoizedState;
          return e === null ? (Ac(t), o === null ? (Fc(t), jc(t, a, null, r, n)) : (Fc(t), Mc(t, o))) : o ? o === e.memoizedState ? (Fc(t), t.flags &= -16777217) : (Ac(t), Fc(t), Mc(t, o)) : (e = e.memoizedProps, e !== r && Ac(t), Fc(t), jc(t, a, e, r, n)), null;
        case 27:
          if (ve(t), n = pe.current, a = t.type, e !== null && t.stateNode != null) e.memoizedProps !== r && Ac(t);
          else {
            if (!r) {
              if (t.stateNode === null) throw Error(i(166));
              return Fc(t), null
            }
            e = de.current, Ui(t) ? Vi(t, e) : (e = ff(a, r, n), t.stateNode = e, Ac(t))
          }
          return Fc(t), null;
        case 5:
          if (ve(t), a = t.type, e !== null && t.stateNode != null) e.memoizedProps !== r && Ac(t);
          else {
            if (!r) {
              if (t.stateNode === null) throw Error(i(166));
              return Fc(t), null
            }
            if (o = de.current, Ui(t)) Vi(t, o);
            else {
              var s = Bd(pe.current);
              switch (o) {
                case 1:
                  o = s.createElementNS(`http://www.w3.org/2000/svg`, a);
                  break;
                case 2:
                  o = s.createElementNS(`http://www.w3.org/1998/Math/MathML`, a);
                  break;
                default:
                  switch (a) {
                    case `svg`:
                      o = s.createElementNS(`http://www.w3.org/2000/svg`, a);
                      break;
                    case `math`:
                      o = s.createElementNS(`http://www.w3.org/1998/Math/MathML`, a);
                      break;
                    case `script`:
                      o = s.createElement(`div`), o.innerHTML = `<script><\/script>`, o = o.removeChild(o.firstChild);
                      break;
                    case `select`:
                      o = typeof r.is == `string` ? s.createElement(`select`, {
                        is: r.is
                      }) : s.createElement(`select`), r.multiple ? o.multiple = !0 : r.size && (o.size = r.size);
                      break;
                    default:
                      o = typeof r.is == `string` ? s.createElement(a, {
                        is: r.is
                      }) : s.createElement(a)
                  }
              }
              o[ft] = t, o[pt] = r;
              a: for (s = t.child; s !== null;) {
                if (s.tag === 5 || s.tag === 6) o.appendChild(s.stateNode);
                else if (s.tag !== 4 && s.tag !== 27 && s.child !== null) {
                  s.child.return = s, s = s.child;
                  continue
                }
                if (s === t) break a;
                for (; s.sibling === null;) {
                  if (s.return === null || s.return === t) break a;
                  s = s.return
                }
                s.sibling.return = s.return, s = s.sibling
              }
              t.stateNode = o;
              a: switch (Pd(o, a, r), a) {
                case `button`:
                case `input`:
                case `select`:
                case `textarea`:
                  r = !!r.autoFocus;
                  break a;
                case `img`:
                  r = !0;
                  break a;
                default:
                  r = !1
              }
              r && Ac(t)
            }
          }
          return Fc(t), jc(t, t.type, e === null ? null : e.memoizedProps, t.pendingProps, n), null;
        case 6:
          if (e && t.stateNode != null) e.memoizedProps !== r && Ac(t);
          else {
            if (typeof r != `string` && t.stateNode === null) throw Error(i(166));
            if (e = pe.current, Ui(t)) {
              if (e = t.stateNode, n = t.memoizedProps, r = null, a = Fi, a !== null) switch (a.tag) {
                case 27:
                case 5:
                  r = a.memoizedProps
              }
              e[ft] = t, e = !!(e.nodeValue === n || r !== null && !0 === r.suppressHydrationWarning || Md(e.nodeValue, n)), e || Bi(t, !0)
            } else e = Bd(e).createTextNode(r), e[ft] = t, t.stateNode = e
          }
          return Fc(t), null;
        case 31:
          if (n = t.memoizedState, e === null || e.memoizedState !== null) {
            if (r = Ui(t), n !== null) {
              if (e === null) {
                if (!r) throw Error(i(318));
                if (e = t.memoizedState, e = e === null ? null : e.dehydrated, !e) throw Error(i(557));
                e[ft] = t
              } else R(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
              Fc(t), e = !1
            } else n = Wi(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = n), e = !0;
            if (!e) return t.flags & 256 ? (so(t), t) : (so(t), null);
            if (t.flags & 128) throw Error(i(558))
          }
          return Fc(t), null;
        case 13:
          if (r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
            if (a = Ui(t), r !== null && r.dehydrated !== null) {
              if (e === null) {
                if (!a) throw Error(i(318));
                if (a = t.memoizedState, a = a === null ? null : a.dehydrated, !a) throw Error(i(317));
                a[ft] = t
              } else R(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
              Fc(t), a = !1
            } else a = Wi(), e !== null && e.memoizedState !== null && (e.memoizedState.hydrationErrors = a), a = !0;
            if (!a) return t.flags & 256 ? (so(t), t) : (so(t), null)
          }
          return so(t), t.flags & 128 ? (t.lanes = n, t) : (n = r !== null, e = e !== null && e.memoizedState !== null, n && (r = t.child, a = null, r.alternate !== null && r.alternate.memoizedState !== null && r.alternate.memoizedState.cachePool !== null && (a = r.alternate.memoizedState.cachePool.pool), o = null, r.memoizedState !== null && r.memoizedState.cachePool !== null && (o = r.memoizedState.cachePool.pool), o !== a && (r.flags |= 2048)), n !== e && n && (t.child.flags |= 8192), Nc(t, t.updateQueue), Fc(t), null);
        case 4:
          return ge(), e === null && Sd(t.stateNode.containerInfo), Fc(t), null;
        case 10:
          return B(t.type), Fc(t), null;
        case 19:
          if (ue(co), r = t.memoizedState, r === null) return Fc(t), null;
          if (a = (t.flags & 128) != 0, o = r.rendering, o === null)
            if (a) Pc(r, !1);
            else {
              if (Wl !== 0 || e !== null && e.flags & 128)
                for (e = t.child; e !== null;) {
                  if (o = lo(e), o !== null) {
                    for (t.flags |= 128, Pc(r, !1), e = o.updateQueue, t.updateQueue = e, Nc(t, e), t.subtreeFlags = 0, e = n, n = t.child; n !== null;) pi(n, e), n = n.sibling;
                    return M(co, co.current & 1 | 2), L && Ai(t, r.treeForkCount), t.child
                  }
                  e = e.sibling
                }
              r.tail !== null && je() > tu && (t.flags |= 128, a = !0, Pc(r, !1), t.lanes = 4194304)
            }
          else {
            if (!a)
              if (e = lo(o), e !== null) {
                if (t.flags |= 128, a = !0, e = e.updateQueue, t.updateQueue = e, Nc(t, e), Pc(r, !0), r.tail === null && r.tailMode === `hidden` && !o.alternate && !L) return Fc(t), null
              } else 2 * je() - r.renderingStartTime > tu && n !== 536870912 && (t.flags |= 128, a = !0, Pc(r, !1), t.lanes = 4194304);
            r.isBackwards ? (o.sibling = t.child, t.child = o) : (e = r.last, e === null ? t.child = o : e.sibling = o, r.last = o)
          }
          return r.tail === null ? (Fc(t), null) : (e = r.tail, r.rendering = e, r.tail = e.sibling, r.renderingStartTime = je(), e.sibling = null, n = co.current, M(co, a ? n & 1 | 2 : n & 1), L && Ai(t, r.treeForkCount), e);
        case 22:
        case 23:
          return so(t), eo(), r = t.memoizedState !== null, e === null ? r && (t.flags |= 8192) : e.memoizedState !== null !== r && (t.flags |= 8192), r ? n & 536870912 && !(t.flags & 128) && (Fc(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : Fc(t), n = t.updateQueue, n !== null && Nc(t, n.retryQueue), n = null, e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), r = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (r = t.memoizedState.cachePool.pool), r !== n && (t.flags |= 2048), e !== null && ue(_a), null;
        case 24:
          return n = null, e !== null && (n = e.memoizedState.cache), t.memoizedState.cache !== n && (t.flags |= 2048), B(oa), Fc(t), null;
        case 25:
          return null;
        case 30:
          return null
      }
      throw Error(i(156, t.tag))
    }

    function Lc(e, t) {
      switch (Ni(t), t.tag) {
        case 1:
          return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 3:
          return B(oa), ge(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
        case 26:
        case 27:
        case 5:
          return ve(t), null;
        case 31:
          if (t.memoizedState !== null) {
            if (so(t), t.alternate === null) throw Error(i(340));
            R()
          }
          return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 13:
          if (so(t), e = t.memoizedState, e !== null && e.dehydrated !== null) {
            if (t.alternate === null) throw Error(i(340));
            R()
          }
          return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 19:
          return ue(co), null;
        case 4:
          return ge(), null;
        case 10:
          return B(t.type), null;
        case 22:
        case 23:
          return so(t), eo(), e !== null && ue(_a), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 24:
          return B(oa), null;
        case 25:
          return null;
        default:
          return null
      }
    }

    function Rc(e, t) {
      switch (Ni(t), t.tag) {
        case 3:
          B(oa), ge();
          break;
        case 26:
        case 27:
        case 5:
          ve(t);
          break;
        case 4:
          ge();
          break;
        case 31:
          t.memoizedState !== null && so(t);
          break;
        case 13:
          so(t);
          break;
        case 19:
          ue(co);
          break;
        case 10:
          B(t.type);
          break;
        case 22:
        case 23:
          so(t), eo(), e !== null && ue(_a);
          break;
        case 24:
          B(oa)
      }
    }

    function zc(e, t) {
      try {
        var n = t.updateQueue,
          r = n === null ? null : n.lastEffect;
        if (r !== null) {
          var i = r.next;
          n = i;
          do {
            if ((n.tag & e) === e) {
              r = void 0;
              var a = n.create,
                o = n.inst;
              r = a(), o.destroy = r
            }
            n = n.next
          } while (n !== i)
        }
      } catch (e) {
        Z(t, t.return, e)
      }
    }

    function Bc(e, t, n) {
      try {
        var r = t.updateQueue,
          i = r === null ? null : r.lastEffect;
        if (i !== null) {
          var a = i.next;
          r = a;
          do {
            if ((r.tag & e) === e) {
              var o = r.inst,
                s = o.destroy;
              if (s !== void 0) {
                o.destroy = void 0, i = t;
                var c = n,
                  l = s;
                try {
                  l()
                } catch (e) {
                  Z(i, c, e)
                }
              }
            }
            r = r.next
          } while (r !== a)
        }
      } catch (e) {
        Z(t, t.return, e)
      }
    }

    function Vc(e) {
      var t = e.updateQueue;
      if (t !== null) {
        var n = e.stateNode;
        try {
          Xa(t, n)
        } catch (t) {
          Z(e, e.return, t)
        }
      }
    }

    function Hc(e, t, n) {
      n.props = Us(e.type, e.memoizedProps), n.state = e.memoizedState;
      try {
        n.componentWillUnmount()
      } catch (n) {
        Z(e, t, n)
      }
    }

    function Uc(e, t) {
      try {
        var n = e.ref;
        if (n !== null) {
          switch (e.tag) {
            case 26:
            case 27:
            case 5:
              var r = e.stateNode;
              break;
            case 30:
              r = e.stateNode;
              break;
            default:
              r = e.stateNode
          }
          typeof n == `function` ? e.refCleanup = n(r) : n.current = r
        }
      } catch (n) {
        Z(e, t, n)
      }
    }

    function Wc(e, t) {
      var n = e.ref,
        r = e.refCleanup;
      if (n !== null)
        if (typeof r == `function`) try {
          r()
        } catch (n) {
          Z(e, t, n)
        } finally {
          e.refCleanup = null, e = e.alternate, e != null && (e.refCleanup = null)
        } else if (typeof n == `function`) try {
          n(null)
        } catch (n) {
          Z(e, t, n)
        } else n.current = null
    }

    function Gc(e) {
      var t = e.type,
        n = e.memoizedProps,
        r = e.stateNode;
      try {
        a: switch (t) {
          case `button`:
          case `input`:
          case `select`:
          case `textarea`:
            n.autoFocus && r.focus();
            break a;
          case `img`:
            n.src ? r.src = n.src : n.srcSet && (r.srcset = n.srcSet)
        }
      }
      catch (t) {
        Z(e, e.return, t)
      }
    }

    function Kc(e, t, n) {
      try {
        var r = e.stateNode;
        Fd(r, e.type, n, t), r[pt] = t
      } catch (t) {
        Z(e, e.return, t)
      }
    }

    function qc(e) {
      return e.tag === 5 || e.tag === 3 || e.tag === 26 || e.tag === 27 && Zd(e.type) || e.tag === 4
    }

    function Jc(e) {
      a: for (;;) {
        for (; e.sibling === null;) {
          if (e.return === null || qc(e.return)) return null;
          e = e.return
        }
        for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
          if (e.tag === 27 && Zd(e.type) || e.flags & 2 || e.child === null || e.tag === 4) continue a;
          e.child.return = e, e = e.child
        }
        if (!(e.flags & 2)) return e.stateNode
      }
    }

    function Yc(e, t, n) {
      var r = e.tag;
      if (r === 5 || r === 6) e = e.stateNode, t ? (n.nodeType === 9 ? n.body : n.nodeName === `HTML` ? n.ownerDocument.body : n).insertBefore(e, t) : (t = n.nodeType === 9 ? n.body : n.nodeName === `HTML` ? n.ownerDocument.body : n, t.appendChild(e), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = on));
      else if (r !== 4 && (r === 27 && Zd(e.type) && (n = e.stateNode, t = null), e = e.child, e !== null))
        for (Yc(e, t, n), e = e.sibling; e !== null;) Yc(e, t, n), e = e.sibling
    }

    function Xc(e, t, n) {
      var r = e.tag;
      if (r === 5 || r === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
      else if (r !== 4 && (r === 27 && Zd(e.type) && (n = e.stateNode), e = e.child, e !== null))
        for (Xc(e, t, n), e = e.sibling; e !== null;) Xc(e, t, n), e = e.sibling
    }

    function Zc(e) {
      var t = e.stateNode,
        n = e.memoizedProps;
      try {
        for (var r = e.type, i = t.attributes; i.length;) t.removeAttributeNode(i[0]);
        Pd(t, r, n), t[ft] = e, t[pt] = n
      } catch (t) {
        Z(e, e.return, t)
      }
    }
    var Qc = !1,
      $c = !1,
      el = !1,
      tl = typeof WeakSet == `function` ? WeakSet : Set,
      nl = null;

    function rl(e, t) {
      if (e = e.containerInfo, Rd = sp, e = Ar(e), jr(e)) {
        if (`selectionStart` in e) var n = {
          start: e.selectionStart,
          end: e.selectionEnd
        };
        else a: {
          n = (n = e.ownerDocument) && n.defaultView || window;
          var r = n.getSelection && n.getSelection();
          if (r && r.rangeCount !== 0) {
            n = r.anchorNode;
            var a = r.anchorOffset,
              o = r.focusNode;
            r = r.focusOffset;
            try {
              n.nodeType, o.nodeType
            } catch {
              n = null;
              break a
            }
            var s = 0,
              c = -1,
              l = -1,
              u = 0,
              d = 0,
              f = e,
              p = null;
            b: for (;;) {
              for (var m; f !== n || a !== 0 && f.nodeType !== 3 || (c = s + a), f !== o || r !== 0 && f.nodeType !== 3 || (l = s + r), f.nodeType === 3 && (s += f.nodeValue.length), (m = f.firstChild) !== null;) p = f, f = m;
              for (;;) {
                if (f === e) break b;
                if (p === n && ++u === a && (c = s), p === o && ++d === r && (l = s), (m = f.nextSibling) !== null) break;
                f = p, p = f.parentNode
              }
              f = m
            }
            n = c === -1 || l === -1 ? null : {
              start: c,
              end: l
            }
          } else n = null
        }
        n ||= {
          start: 0,
          end: 0
        }
      } else n = null;
      for (zd = {
          focusedElem: e,
          selectionRange: n
        }, sp = !1, nl = t; nl !== null;)
        if (t = nl, e = t.child, t.subtreeFlags & 1028 && e !== null) e.return = t, nl = e;
        else
          for (; nl !== null;) {
            switch (t = nl, o = t.alternate, e = t.flags, t.tag) {
              case 0:
                if (e & 4 && (e = t.updateQueue, e = e === null ? null : e.events, e !== null))
                  for (n = 0; n < e.length; n++) a = e[n], a.ref.impl = a.nextImpl;
                break;
              case 11:
              case 15:
                break;
              case 1:
                if (e & 1024 && o !== null) {
                  e = void 0, n = t, a = o.memoizedProps, o = o.memoizedState, r = n.stateNode;
                  try {
                    var h = Us(n.type, a);
                    e = r.getSnapshotBeforeUpdate(h, o), r.__reactInternalSnapshotBeforeUpdate = e
                  } catch (e) {
                    Z(n, n.return, e)
                  }
                }
                break;
              case 3:
                if (e & 1024) {
                  if (e = t.stateNode.containerInfo, n = e.nodeType, n === 9) ef(e);
                  else if (n === 1) switch (e.nodeName) {
                    case `HEAD`:
                    case `HTML`:
                    case `BODY`:
                      ef(e);
                      break;
                    default:
                      e.textContent = ``
                  }
                }
                break;
              case 5:
              case 26:
              case 27:
              case 6:
              case 4:
              case 17:
                break;
              default:
                if (e & 1024) throw Error(i(163))
            }
            if (e = t.sibling, e !== null) {
              e.return = t.return, nl = e;
              break
            }
            nl = t.return
          }
    }

    function il(e, t, n) {
      var r = n.flags;
      switch (n.tag) {
        case 0:
        case 11:
        case 15:
          yl(e, n), r & 4 && zc(5, n);
          break;
        case 1:
          if (yl(e, n), r & 4)
            if (e = n.stateNode, t === null) try {
              e.componentDidMount()
            } catch (e) {
              Z(n, n.return, e)
            } else {
              var i = Us(n.type, t.memoizedProps);
              t = t.memoizedState;
              try {
                e.componentDidUpdate(i, t, e.__reactInternalSnapshotBeforeUpdate)
              } catch (e) {
                Z(n, n.return, e)
              }
            }
          r & 64 && Vc(n), r & 512 && Uc(n, n.return);
          break;
        case 3:
          if (yl(e, n), r & 64 && (e = n.updateQueue, e !== null)) {
            if (t = null, n.child !== null) switch (n.child.tag) {
              case 27:
              case 5:
                t = n.child.stateNode;
                break;
              case 1:
                t = n.child.stateNode
            }
            try {
              Xa(e, t)
            } catch (e) {
              Z(n, n.return, e)
            }
          }
          break;
        case 27:
          t === null && r & 4 && Zc(n);
        case 26:
        case 5:
          yl(e, n), t === null && r & 4 && Gc(n), r & 512 && Uc(n, n.return);
          break;
        case 12:
          yl(e, n);
          break;
        case 31:
          yl(e, n), r & 4 && ul(e, n);
          break;
        case 13:
          yl(e, n), r & 4 && dl(e, n), r & 64 && (e = n.memoizedState, e !== null && (e = e.dehydrated, e !== null && (n = Ju.bind(null, n), sf(e, n))));
          break;
        case 22:
          if (r = n.memoizedState !== null || Qc, !r) {
            t = t !== null && t.memoizedState !== null || $c, i = Qc;
            var a = $c;
            Qc = r, ($c = t) && !a ? xl(e, n, (n.subtreeFlags & 8772) != 0) : yl(e, n), Qc = i, $c = a
          }
          break;
        case 30:
          break;
        default:
          yl(e, n)
      }
    }

    function al(e) {
      var t = e.alternate;
      t !== null && (e.alternate = null, al(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && bt(t)), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
    }
    var ol = null,
      sl = !1;

    function cl(e, t, n) {
      for (n = n.child; n !== null;) ll(e, t, n), n = n.sibling
    }

    function ll(e, t, n) {
      if (Ve && typeof Ve.onCommitFiberUnmount == `function`) try {
        Ve.onCommitFiberUnmount(Be, n)
      } catch {}
      switch (n.tag) {
        case 26:
          $c || Wc(n, t), cl(e, t, n), n.memoizedState ? n.memoizedState.count-- : n.stateNode && (n = n.stateNode, n.parentNode.removeChild(n));
          break;
        case 27:
          $c || Wc(n, t);
          var r = ol,
            i = sl;
          Zd(n.type) && (ol = n.stateNode, sl = !1), cl(e, t, n), pf(n.stateNode), ol = r, sl = i;
          break;
        case 5:
          $c || Wc(n, t);
        case 6:
          if (r = ol, i = sl, ol = null, cl(e, t, n), ol = r, sl = i, ol !== null)
            if (sl) try {
              (ol.nodeType === 9 ? ol.body : ol.nodeName === `HTML` ? ol.ownerDocument.body : ol).removeChild(n.stateNode)
            } catch (e) {
              Z(n, t, e)
            } else try {
              ol.removeChild(n.stateNode)
            } catch (e) {
              Z(n, t, e)
            }
          break;
        case 18:
          ol !== null && (sl ? (e = ol, Qd(e.nodeType === 9 ? e.body : e.nodeName === `HTML` ? e.ownerDocument.body : e, n.stateNode), Np(e)) : Qd(ol, n.stateNode));
          break;
        case 4:
          r = ol, i = sl, ol = n.stateNode.containerInfo, sl = !0, cl(e, t, n), ol = r, sl = i;
          break;
        case 0:
        case 11:
        case 14:
        case 15:
          Bc(2, n, t), $c || Bc(4, n, t), cl(e, t, n);
          break;
        case 1:
          $c || (Wc(n, t), r = n.stateNode, typeof r.componentWillUnmount == `function` && Hc(n, t, r)), cl(e, t, n);
          break;
        case 21:
          cl(e, t, n);
          break;
        case 22:
          $c = (r = $c) || n.memoizedState !== null, cl(e, t, n), $c = r;
          break;
        default:
          cl(e, t, n)
      }
    }

    function ul(e, t) {
      if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null))) {
        e = e.dehydrated;
        try {
          Np(e)
        } catch (e) {
          Z(t, t.return, e)
        }
      }
    }

    function dl(e, t) {
      if (t.memoizedState === null && (e = t.alternate, e !== null && (e = e.memoizedState, e !== null && (e = e.dehydrated, e !== null)))) try {
        Np(e)
      } catch (e) {
        Z(t, t.return, e)
      }
    }

    function fl(e) {
      switch (e.tag) {
        case 31:
        case 13:
        case 19:
          var t = e.stateNode;
          return t === null && (t = e.stateNode = new tl), t;
        case 22:
          return e = e.stateNode, t = e._retryCache, t === null && (t = e._retryCache = new tl), t;
        default:
          throw Error(i(435, e.tag))
      }
    }

    function pl(e, t) {
      var n = fl(e);
      t.forEach(function(t) {
        if (!n.has(t)) {
          n.add(t);
          var r = Yu.bind(null, e, t);
          t.then(r, r)
        }
      })
    }

    function ml(e, t) {
      var n = t.deletions;
      if (n !== null)
        for (var r = 0; r < n.length; r++) {
          var a = n[r],
            o = e,
            s = t,
            c = s;
          a: for (; c !== null;) {
            switch (c.tag) {
              case 27:
                if (Zd(c.type)) {
                  ol = c.stateNode, sl = !1;
                  break a
                }
                break;
              case 5:
                ol = c.stateNode, sl = !1;
                break a;
              case 3:
              case 4:
                ol = c.stateNode.containerInfo, sl = !0;
                break a
            }
            c = c.return
          }
          if (ol === null) throw Error(i(160));
          ll(o, s, a), ol = null, sl = !1, o = a.alternate, o !== null && (o.return = null), a.return = null
        }
      if (t.subtreeFlags & 13886)
        for (t = t.child; t !== null;) gl(t, e), t = t.sibling
    }
    var hl = null;

    function gl(e, t) {
      var n = e.alternate,
        r = e.flags;
      switch (e.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
          ml(t, e), _l(e), r & 4 && (Bc(3, e, e.return), zc(3, e), Bc(5, e, e.return));
          break;
        case 1:
          ml(t, e), _l(e), r & 512 && ($c || n === null || Wc(n, n.return)), r & 64 && Qc && (e = e.updateQueue, e !== null && (r = e.callbacks, r !== null && (n = e.shared.hiddenCallbacks, e.shared.hiddenCallbacks = n === null ? r : n.concat(r))));
          break;
        case 26:
          var a = hl;
          if (ml(t, e), _l(e), r & 512 && ($c || n === null || Wc(n, n.return)), r & 4) {
            var o = n === null ? null : n.memoizedState;
            if (r = e.memoizedState, n === null)
              if (r === null)
                if (e.stateNode === null) {
                  a: {
                    r = e.type,
                    n = e.memoizedProps,
                    a = a.ownerDocument || a;b: switch (r) {
                      case `title`:
                        o = a.getElementsByTagName(`title`)[0], (!o || o[yt] || o[ft] || o.namespaceURI === `http://www.w3.org/2000/svg` || o.hasAttribute(`itemprop`)) && (o = a.createElement(r), a.head.insertBefore(o, a.querySelector(`head > title`))), Pd(o, r, n), o[ft] = e, Tt(o), r = o;
                        break a;
                      case `link`:
                        var s = Vf(`link`, `href`, a).get(r + (n.href || ``));
                        if (s) {
                          for (var c = 0; c < s.length; c++)
                            if (o = s[c], o.getAttribute(`href`) === (n.href == null || n.href === `` ? null : n.href) && o.getAttribute(`rel`) === (n.rel == null ? null : n.rel) && o.getAttribute(`title`) === (n.title == null ? null : n.title) && o.getAttribute(`crossorigin`) === (n.crossOrigin == null ? null : n.crossOrigin)) {
                              s.splice(c, 1);
                              break b
                            }
                        }
                        o = a.createElement(r), Pd(o, r, n), a.head.appendChild(o);
                        break;
                      case `meta`:
                        if (s = Vf(`meta`, `content`, a).get(r + (n.content || ``))) {
                          for (c = 0; c < s.length; c++)
                            if (o = s[c], o.getAttribute(`content`) === (n.content == null ? null : `` + n.content) && o.getAttribute(`name`) === (n.name == null ? null : n.name) && o.getAttribute(`property`) === (n.property == null ? null : n.property) && o.getAttribute(`http-equiv`) === (n.httpEquiv == null ? null : n.httpEquiv) && o.getAttribute(`charset`) === (n.charSet == null ? null : n.charSet)) {
                              s.splice(c, 1);
                              break b
                            }
                        }
                        o = a.createElement(r), Pd(o, r, n), a.head.appendChild(o);
                        break;
                      default:
                        throw Error(i(468, r))
                    }
                    o[ft] = e,
                    Tt(o),
                    r = o
                  }
                  e.stateNode = r
                }
            else Hf(a, e.type, e.stateNode);
            else e.stateNode = If(a, r, e.memoizedProps);
            else o === r ? r === null && e.stateNode !== null && Kc(e, e.memoizedProps, n.memoizedProps) : (o === null ? n.stateNode !== null && (n = n.stateNode, n.parentNode.removeChild(n)) : o.count--, r === null ? Hf(a, e.type, e.stateNode) : If(a, r, e.memoizedProps))
          }
          break;
        case 27:
          ml(t, e), _l(e), r & 512 && ($c || n === null || Wc(n, n.return)), n !== null && r & 4 && Kc(e, e.memoizedProps, n.memoizedProps);
          break;
        case 5:
          if (ml(t, e), _l(e), r & 512 && ($c || n === null || Wc(n, n.return)), e.flags & 32) {
            a = e.stateNode;
            try {
              Zt(a, ``)
            } catch (t) {
              Z(e, e.return, t)
            }
          }
          r & 4 && e.stateNode != null && (a = e.memoizedProps, Kc(e, a, n === null ? a : n.memoizedProps)), r & 1024 && (el = !0);
          break;
        case 6:
          if (ml(t, e), _l(e), r & 4) {
            if (e.stateNode === null) throw Error(i(162));
            r = e.memoizedProps, n = e.stateNode;
            try {
              n.nodeValue = r
            } catch (t) {
              Z(e, e.return, t)
            }
          }
          break;
        case 3:
          if (Bf = null, a = hl, hl = gf(t.containerInfo), ml(t, e), hl = a, _l(e), r & 4 && n !== null && n.memoizedState.isDehydrated) try {
            Np(t.containerInfo)
          } catch (t) {
            Z(e, e.return, t)
          }
          el && (el = !1, vl(e));
          break;
        case 4:
          r = hl, hl = gf(e.stateNode.containerInfo), ml(t, e), _l(e), hl = r;
          break;
        case 12:
          ml(t, e), _l(e);
          break;
        case 31:
          ml(t, e), _l(e), r & 4 && (r = e.updateQueue, r !== null && (e.updateQueue = null, pl(e, r)));
          break;
        case 13:
          ml(t, e), _l(e), e.child.flags & 8192 && e.memoizedState !== null != (n !== null && n.memoizedState !== null) && ($l = je()), r & 4 && (r = e.updateQueue, r !== null && (e.updateQueue = null, pl(e, r)));
          break;
        case 22:
          a = e.memoizedState !== null;
          var l = n !== null && n.memoizedState !== null,
            u = Qc,
            d = $c;
          if (Qc = u || a, $c = d || l, ml(t, e), $c = d, Qc = u, _l(e), r & 8192) a: for (t = e.stateNode, t._visibility = a ? t._visibility & -2 : t._visibility | 1, a && (n === null || l || Qc || $c || bl(e)), n = null, t = e;;) {
            if (t.tag === 5 || t.tag === 26) {
              if (n === null) {
                l = n = t;
                try {
                  if (o = l.stateNode, a) s = o.style, typeof s.setProperty == `function` ? s.setProperty(`display`, `none`, `important`) : s.display = `none`;
                  else {
                    c = l.stateNode;
                    var f = l.memoizedProps.style,
                      p = f != null && f.hasOwnProperty(`display`) ? f.display : null;
                    c.style.display = p == null || typeof p == `boolean` ? `` : (`` + p).trim()
                  }
                } catch (e) {
                  Z(l, l.return, e)
                }
              }
            } else if (t.tag === 6) {
              if (n === null) {
                l = t;
                try {
                  l.stateNode.nodeValue = a ? `` : l.memoizedProps
                } catch (e) {
                  Z(l, l.return, e)
                }
              }
            } else if (t.tag === 18) {
              if (n === null) {
                l = t;
                try {
                  var m = l.stateNode;
                  a ? $d(m, !0) : $d(l.stateNode, !1)
                } catch (e) {
                  Z(l, l.return, e)
                }
              }
            } else if ((t.tag !== 22 && t.tag !== 23 || t.memoizedState === null || t === e) && t.child !== null) {
              t.child.return = t, t = t.child;
              continue
            }
            if (t === e) break a;
            for (; t.sibling === null;) {
              if (t.return === null || t.return === e) break a;
              n === t && (n = null), t = t.return
            }
            n === t && (n = null), t.sibling.return = t.return, t = t.sibling
          }
          r & 4 && (r = e.updateQueue, r !== null && (n = r.retryQueue, n !== null && (r.retryQueue = null, pl(e, n))));
          break;
        case 19:
          ml(t, e), _l(e), r & 4 && (r = e.updateQueue, r !== null && (e.updateQueue = null, pl(e, r)));
          break;
        case 30:
          break;
        case 21:
          break;
        default:
          ml(t, e), _l(e)
      }
    }

    function _l(e) {
      var t = e.flags;
      if (t & 2) {
        try {
          for (var n, r = e.return; r !== null;) {
            if (qc(r)) {
              n = r;
              break
            }
            r = r.return
          }
          if (n == null) throw Error(i(160));
          switch (n.tag) {
            case 27:
              var a = n.stateNode;
              Xc(e, Jc(e), a);
              break;
            case 5:
              var o = n.stateNode;
              n.flags & 32 && (Zt(o, ``), n.flags &= -33), Xc(e, Jc(e), o);
              break;
            case 3:
            case 4:
              var s = n.stateNode.containerInfo;
              Yc(e, Jc(e), s);
              break;
            default:
              throw Error(i(161))
          }
        } catch (t) {
          Z(e, e.return, t)
        }
        e.flags &= -3
      }
      t & 4096 && (e.flags &= -4097)
    }

    function vl(e) {
      if (e.subtreeFlags & 1024)
        for (e = e.child; e !== null;) {
          var t = e;
          vl(t), t.tag === 5 && t.flags & 1024 && t.stateNode.reset(), e = e.sibling
        }
    }

    function yl(e, t) {
      if (t.subtreeFlags & 8772)
        for (t = t.child; t !== null;) il(e, t.alternate, t), t = t.sibling
    }

    function bl(e) {
      for (e = e.child; e !== null;) {
        var t = e;
        switch (t.tag) {
          case 0:
          case 11:
          case 14:
          case 15:
            Bc(4, t, t.return), bl(t);
            break;
          case 1:
            Wc(t, t.return);
            var n = t.stateNode;
            typeof n.componentWillUnmount == `function` && Hc(t, t.return, n), bl(t);
            break;
          case 27:
            pf(t.stateNode);
          case 26:
          case 5:
            Wc(t, t.return), bl(t);
            break;
          case 22:
            t.memoizedState === null && bl(t);
            break;
          case 30:
            bl(t);
            break;
          default:
            bl(t)
        }
        e = e.sibling
      }
    }

    function xl(e, t, n) {
      for (n &&= (t.subtreeFlags & 8772) != 0, t = t.child; t !== null;) {
        var r = t.alternate,
          i = e,
          a = t,
          o = a.flags;
        switch (a.tag) {
          case 0:
          case 11:
          case 15:
            xl(i, a, n), zc(4, a);
            break;
          case 1:
            if (xl(i, a, n), r = a, i = r.stateNode, typeof i.componentDidMount == `function`) try {
              i.componentDidMount()
            } catch (e) {
              Z(r, r.return, e)
            }
            if (r = a, i = r.updateQueue, i !== null) {
              var s = r.stateNode;
              try {
                var c = i.shared.hiddenCallbacks;
                if (c !== null)
                  for (i.shared.hiddenCallbacks = null, i = 0; i < c.length; i++) Ya(c[i], s)
              } catch (e) {
                Z(r, r.return, e)
              }
            }
            n && o & 64 && Vc(a), Uc(a, a.return);
            break;
          case 27:
            Zc(a);
          case 26:
          case 5:
            xl(i, a, n), n && r === null && o & 4 && Gc(a), Uc(a, a.return);
            break;
          case 12:
            xl(i, a, n);
            break;
          case 31:
            xl(i, a, n), n && o & 4 && ul(i, a);
            break;
          case 13:
            xl(i, a, n), n && o & 4 && dl(i, a);
            break;
          case 22:
            a.memoizedState === null && xl(i, a, n), Uc(a, a.return);
            break;
          case 30:
            break;
          default:
            xl(i, a, n)
        }
        t = t.sibling
      }
    }

    function Sl(e, t) {
      var n = null;
      e !== null && e.memoizedState !== null && e.memoizedState.cachePool !== null && (n = e.memoizedState.cachePool.pool), e = null, t.memoizedState !== null && t.memoizedState.cachePool !== null && (e = t.memoizedState.cachePool.pool), e !== n && (e != null && e.refCount++, n != null && ca(n))
    }

    function Cl(e, t) {
      e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && ca(e))
    }

    function wl(e, t, n, r) {
      if (t.subtreeFlags & 10256)
        for (t = t.child; t !== null;) Tl(e, t, n, r), t = t.sibling
    }

    function Tl(e, t, n, r) {
      var i = t.flags;
      switch (t.tag) {
        case 0:
        case 11:
        case 15:
          wl(e, t, n, r), i & 2048 && zc(9, t);
          break;
        case 1:
          wl(e, t, n, r);
          break;
        case 3:
          wl(e, t, n, r), i & 2048 && (e = null, t.alternate !== null && (e = t.alternate.memoizedState.cache), t = t.memoizedState.cache, t !== e && (t.refCount++, e != null && ca(e)));
          break;
        case 12:
          if (i & 2048) {
            wl(e, t, n, r), e = t.stateNode;
            try {
              var a = t.memoizedProps,
                o = a.id,
                s = a.onPostCommit;
              typeof s == `function` && s(o, t.alternate === null ? `mount` : `update`, e.passiveEffectDuration, -0)
            } catch (e) {
              Z(t, t.return, e)
            }
          } else wl(e, t, n, r);
          break;
        case 31:
          wl(e, t, n, r);
          break;
        case 13:
          wl(e, t, n, r);
          break;
        case 23:
          break;
        case 22:
          a = t.stateNode, o = t.alternate, t.memoizedState === null ? a._visibility & 2 ? wl(e, t, n, r) : (a._visibility |= 2, El(e, t, n, r, (t.subtreeFlags & 10256) != 0 || !1)) : a._visibility & 2 ? wl(e, t, n, r) : Dl(e, t), i & 2048 && Sl(o, t);
          break;
        case 24:
          wl(e, t, n, r), i & 2048 && Cl(t.alternate, t);
          break;
        default:
          wl(e, t, n, r)
      }
    }

    function El(e, t, n, r, i) {
      for (i &&= (t.subtreeFlags & 10256) != 0 || !1, t = t.child; t !== null;) {
        var a = e,
          o = t,
          s = n,
          c = r,
          l = o.flags;
        switch (o.tag) {
          case 0:
          case 11:
          case 15:
            El(a, o, s, c, i), zc(8, o);
            break;
          case 23:
            break;
          case 22:
            var u = o.stateNode;
            o.memoizedState === null ? (u._visibility |= 2, El(a, o, s, c, i)) : u._visibility & 2 ? El(a, o, s, c, i) : Dl(a, o), i && l & 2048 && Sl(o.alternate, o);
            break;
          case 24:
            El(a, o, s, c, i), i && l & 2048 && Cl(o.alternate, o);
            break;
          default:
            El(a, o, s, c, i)
        }
        t = t.sibling
      }
    }

    function Dl(e, t) {
      if (t.subtreeFlags & 10256)
        for (t = t.child; t !== null;) {
          var n = e,
            r = t,
            i = r.flags;
          switch (r.tag) {
            case 22:
              Dl(n, r), i & 2048 && Sl(r.alternate, r);
              break;
            case 24:
              Dl(n, r), i & 2048 && Cl(r.alternate, r);
              break;
            default:
              Dl(n, r)
          }
          t = t.sibling
        }
    }
    var Ol = 8192;

    function kl(e, t, n) {
      if (e.subtreeFlags & Ol)
        for (e = e.child; e !== null;) Al(e, t, n), e = e.sibling
    }

    function Al(e, t, n) {
      switch (e.tag) {
        case 26:
          kl(e, t, n), e.flags & Ol && e.memoizedState !== null && Gf(n, hl, e.memoizedState, e.memoizedProps);
          break;
        case 5:
          kl(e, t, n);
          break;
        case 3:
        case 4:
          var r = hl;
          hl = gf(e.stateNode.containerInfo), kl(e, t, n), hl = r;
          break;
        case 22:
          e.memoizedState === null && (r = e.alternate, r !== null && r.memoizedState !== null ? (r = Ol, Ol = 16777216, kl(e, t, n), Ol = r) : kl(e, t, n));
          break;
        default:
          kl(e, t, n)
      }
    }

    function jl(e) {
      var t = e.alternate;
      if (t !== null && (e = t.child, e !== null)) {
        t.child = null;
        do t = e.sibling, e.sibling = null, e = t; while (e !== null)
      }
    }

    function Ml(e) {
      var t = e.deletions;
      if (e.flags & 16) {
        if (t !== null)
          for (var n = 0; n < t.length; n++) {
            var r = t[n];
            nl = r, Fl(r, e)
          }
        jl(e)
      }
      if (e.subtreeFlags & 10256)
        for (e = e.child; e !== null;) Nl(e), e = e.sibling
    }

    function Nl(e) {
      switch (e.tag) {
        case 0:
        case 11:
        case 15:
          Ml(e), e.flags & 2048 && Bc(9, e, e.return);
          break;
        case 3:
          Ml(e);
          break;
        case 12:
          Ml(e);
          break;
        case 22:
          var t = e.stateNode;
          e.memoizedState !== null && t._visibility & 2 && (e.return === null || e.return.tag !== 13) ? (t._visibility &= -3, Pl(e)) : Ml(e);
          break;
        default:
          Ml(e)
      }
    }

    function Pl(e) {
      var t = e.deletions;
      if (e.flags & 16) {
        if (t !== null)
          for (var n = 0; n < t.length; n++) {
            var r = t[n];
            nl = r, Fl(r, e)
          }
        jl(e)
      }
      for (e = e.child; e !== null;) {
        switch (t = e, t.tag) {
          case 0:
          case 11:
          case 15:
            Bc(8, t, t.return), Pl(t);
            break;
          case 22:
            n = t.stateNode, n._visibility & 2 && (n._visibility &= -3, Pl(t));
            break;
          default:
            Pl(t)
        }
        e = e.sibling
      }
    }

    function Fl(e, t) {
      for (; nl !== null;) {
        var n = nl;
        switch (n.tag) {
          case 0:
          case 11:
          case 15:
            Bc(8, n, t);
            break;
          case 23:
          case 22:
            if (n.memoizedState !== null && n.memoizedState.cachePool !== null) {
              var r = n.memoizedState.cachePool.pool;
              r != null && r.refCount++
            }
            break;
          case 24:
            ca(n.memoizedState.cache)
        }
        if (r = n.child, r !== null) r.return = n, nl = r;
        else a: for (n = e; nl !== null;) {
          r = nl;
          var i = r.sibling,
            a = r.return;
          if (al(r), r === n) {
            nl = null;
            break a
          }
          if (i !== null) {
            i.return = a, nl = i;
            break a
          }
          nl = a
        }
      }
    }
    var Il = {
        getCacheForType: function(e) {
          var t = ea(oa),
            n = t.data.get(e);
          return n === void 0 && (n = e(), t.data.set(e, n)), n
        },
        cacheSignal: function() {
          return ea(oa).controller.signal
        }
      },
      Ll = typeof WeakMap == `function` ? WeakMap : Map,
      q = 0,
      Rl = null,
      J = null,
      Y = 0,
      X = 0,
      zl = null,
      Bl = !1,
      Vl = !1,
      Hl = !1,
      Ul = 0,
      Wl = 0,
      Gl = 0,
      Kl = 0,
      ql = 0,
      Jl = 0,
      Yl = 0,
      Xl = null,
      Zl = null,
      Ql = !1,
      $l = 0,
      eu = 0,
      tu = 1 / 0,
      nu = null,
      ru = null,
      iu = 0,
      au = null,
      ou = null,
      su = 0,
      cu = 0,
      lu = null,
      uu = null,
      du = 0,
      fu = null;

    function pu() {
      return q & 2 && Y !== 0 ? Y & -Y : A.T === null ? lt() : dd()
    }

    function mu() {
      if (Jl === 0)
        if (!(Y & 536870912) || L) {
          var e = Je;
          Je <<= 1, !(Je & 3932160) && (Je = 262144), Jl = e
        } else Jl = 536870912;
      return e = to.current, e !== null && (e.flags |= 32), Jl
    }

    function hu(e, t, n) {
      (e === Rl && (X === 2 || X === 9) || e.cancelPendingCommit !== null) && (Su(e, 0), yu(e, Y, Jl, !1)), nt(e, n), (!(q & 2) || e !== Rl) && (e === Rl && (!(q & 2) && (Kl |= n), Wl === 4 && yu(e, Y, Jl, !1)), rd(e))
    }

    function gu(e, t, n) {
      if (q & 6) throw Error(i(327));
      var r = !n && (t & 127) == 0 && (t & e.expiredLanes) === 0 || Qe(e, t),
        a = r ? Au(e, t) : Ou(e, t, !0),
        o = r;
      do {
        if (a === 0) {
          Vl && !r && yu(e, t, 0, !1);
          break
        } else {
          if (n = e.current.alternate, o && !vu(n)) {
            a = Ou(e, t, !1), o = !1;
            continue
          }
          if (a === 2) {
            if (o = t, e.errorRecoveryDisabledLanes & o) var s = 0;
            else s = e.pendingLanes & -536870913, s = s === 0 ? s & 536870912 ? 536870912 : 0 : s;
            if (s !== 0) {
              t = s;
              a: {
                var c = e;a = Xl;
                var l = c.current.memoizedState.isDehydrated;
                if (l && (Su(c, s).flags |= 256), s = Ou(c, s, !1), s !== 2) {
                  if (Hl && !l) {
                    c.errorRecoveryDisabledLanes |= o, Kl |= o, a = 4;
                    break a
                  }
                  o = Zl, Zl = a, o !== null && (Zl === null ? Zl = o : Zl.push.apply(Zl, o))
                }
                a = s
              }
              if (o = !1, a !== 2) continue
            }
          }
          if (a === 1) {
            Su(e, 0), yu(e, t, 0, !0);
            break
          }
          a: {
            switch (r = e, o = a, o) {
              case 0:
              case 1:
                throw Error(i(345));
              case 4:
                if ((t & 4194048) !== t) break;
              case 6:
                yu(r, t, Jl, !Bl);
                break a;
              case 2:
                Zl = null;
                break;
              case 3:
              case 5:
                break;
              default:
                throw Error(i(329))
            }
            if ((t & 62914560) === t && (a = $l + 300 - je(), 10 < a)) {
              if (yu(r, t, Jl, !Bl), Ze(r, 0, !0) !== 0) break a;
              su = t, r.timeoutHandle = Kd(_u.bind(null, r, n, Zl, nu, Ql, t, Jl, Kl, Yl, Bl, o, `Throttled`, -0, 0), a);
              break a
            }
            _u(r, n, Zl, nu, Ql, t, Jl, Kl, Yl, Bl, o, null, -0, 0)
          }
        }
        break
      } while (1);
      rd(e)
    }

    function _u(e, t, n, r, i, a, o, s, c, l, u, d, f, p) {
      if (e.timeoutHandle = -1, d = t.subtreeFlags, d & 8192 || (d & 16785408) == 16785408) {
        d = {
          stylesheets: null,
          count: 0,
          imgCount: 0,
          imgBytes: 0,
          suspenseyImages: [],
          waitingForImages: !0,
          waitingForViewTransition: !1,
          unsuspend: on
        }, Al(t, a, d);
        var m = (a & 62914560) === a ? $l - je() : (a & 4194048) === a ? eu - je() : 0;
        if (m = qf(d, m), m !== null) {
          su = a, e.cancelPendingCommit = m(Lu.bind(null, e, t, a, n, r, i, o, s, c, u, d, null, f, p)), yu(e, a, o, !l);
          return
        }
      }
      Lu(e, t, a, n, r, i, o, s, c)
    }

    function vu(e) {
      for (var t = e;;) {
        var n = t.tag;
        if ((n === 0 || n === 11 || n === 15) && t.flags & 16384 && (n = t.updateQueue, n !== null && (n = n.stores, n !== null)))
          for (var r = 0; r < n.length; r++) {
            var i = n[r],
              a = i.getSnapshot;
            i = i.value;
            try {
              if (!Er(a(), i)) return !1
            } catch {
              return !1
            }
          }
        if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
        else {
          if (t === e) break;
          for (; t.sibling === null;) {
            if (t.return === null || t.return === e) return !0;
            t = t.return
          }
          t.sibling.return = t.return, t = t.sibling
        }
      }
      return !0
    }

    function yu(e, t, n, r) {
      t &= ~ql, t &= ~Kl, e.suspendedLanes |= t, e.pingedLanes &= ~t, r && (e.warmLanes |= t), r = e.expirationTimes;
      for (var i = t; 0 < i;) {
        var a = 31 - Ue(i),
          o = 1 << a;
        r[a] = -1, i &= ~o
      }
      n !== 0 && it(e, n, t)
    }

    function bu() {
      return q & 6 ? !0 : (id(0, !1), !1)
    }

    function xu() {
      if (J !== null) {
        if (X === 0) var e = J.return;
        else e = J, qi = z = null, Do(e), ja = null, Ma = 0, e = J;
        for (; e !== null;) Rc(e.alternate, e), e = e.return;
        J = null
      }
    }

    function Su(e, t) {
      var n = e.timeoutHandle;
      n !== -1 && (e.timeoutHandle = -1, qd(n)), n = e.cancelPendingCommit, n !== null && (e.cancelPendingCommit = null, n()), su = 0, xu(), Rl = e, J = n = fi(e.current, null), Y = t, X = 0, zl = null, Bl = !1, Vl = Qe(e, t), Hl = !1, Yl = Jl = ql = Kl = Gl = Wl = 0, Zl = Xl = null, Ql = !1, t & 8 && (t |= t & 32);
      var r = e.entangledLanes;
      if (r !== 0)
        for (e = e.entanglements, r &= t; 0 < r;) {
          var i = 31 - Ue(r),
            a = 1 << i;
          t |= e[i], r &= ~a
        }
      return Ul = t, ni(), n
    }

    function Cu(e, t) {
      H = null, A.H = Fs, t === xa || t === Ca ? (t = ka(), X = 3) : t === Sa ? (t = ka(), X = 4) : X = t === $s ? 8 : typeof t == `object` && t && typeof t.then == `function` ? 6 : 1, zl = t, J === null && (Wl = 1, qs(e, bi(t, e.current)))
    }

    function wu() {
      var e = to.current;
      return e === null ? !0 : (Y & 4194048) === Y ? no === null : (Y & 62914560) === Y || Y & 536870912 ? e === no : !1
    }

    function Tu() {
      var e = A.H;
      return A.H = Fs, e === null ? Fs : e
    }

    function Eu() {
      var e = A.A;
      return A.A = Il, e
    }

    function Du() {
      Wl = 4, Bl || (Y & 4194048) !== Y && to.current !== null || (Vl = !0), !(Gl & 134217727) && !(Kl & 134217727) || Rl === null || yu(Rl, Y, Jl, !1)
    }

    function Ou(e, t, n) {
      var r = q;
      q |= 2;
      var i = Tu(),
        a = Eu();
      (Rl !== e || Y !== t) && (nu = null, Su(e, t)), t = !1;
      var o = Wl;
      a: do try {
          if (X !== 0 && J !== null) {
            var s = J,
              c = zl;
            switch (X) {
              case 8:
                xu(), o = 6;
                break a;
              case 3:
              case 2:
              case 9:
              case 6:
                to.current === null && (t = !0);
                var l = X;
                if (X = 0, zl = null, Pu(e, s, c, l), n && Vl) {
                  o = 0;
                  break a
                }
                break;
              default:
                l = X, X = 0, zl = null, Pu(e, s, c, l)
            }
          }
          ku(), o = Wl;
          break
        } catch (t) {
          Cu(e, t)
        }
        while (1);
        return t && e.shellSuspendCounter++, qi = z = null, q = r, A.H = i, A.A = a, J === null && (Rl = null, Y = 0, ni()), o
    }

    function ku() {
      for (; J !== null;) Mu(J)
    }

    function Au(e, t) {
      var n = q;
      q |= 2;
      var r = Tu(),
        a = Eu();
      Rl !== e || Y !== t ? (nu = null, tu = je() + 500, Su(e, t)) : Vl = Qe(e, t);
      a: do try {
          if (X !== 0 && J !== null) {
            t = J;
            var o = zl;
            b: switch (X) {
              case 1:
                X = 0, zl = null, Pu(e, t, o, 1);
                break;
              case 2:
              case 9:
                if (Ta(o)) {
                  X = 0, zl = null, Nu(t);
                  break
                }
                t = function() {
                  X !== 2 && X !== 9 || Rl !== e || (X = 7), rd(e)
                }, o.then(t, t);
                break a;
              case 3:
                X = 7;
                break a;
              case 4:
                X = 5;
                break a;
              case 7:
                Ta(o) ? (X = 0, zl = null, Nu(t)) : (X = 0, zl = null, Pu(e, t, o, 7));
                break;
              case 5:
                var s = null;
                switch (J.tag) {
                  case 26:
                    s = J.memoizedState;
                  case 5:
                  case 27:
                    var c = J;
                    if (s ? Wf(s) : c.stateNode.complete) {
                      X = 0, zl = null;
                      var l = c.sibling;
                      if (l !== null) J = l;
                      else {
                        var u = c.return;
                        u === null ? J = null : (J = u, Fu(u))
                      }
                      break b
                    }
                }
                X = 0, zl = null, Pu(e, t, o, 5);
                break;
              case 6:
                X = 0, zl = null, Pu(e, t, o, 6);
                break;
              case 8:
                xu(), Wl = 6;
                break a;
              default:
                throw Error(i(462))
            }
          }
          ju();
          break
        } catch (t) {
          Cu(e, t)
        }
        while (1);
        return qi = z = null, A.H = r, A.A = a, q = n, J === null ? (Rl = null, Y = 0, ni(), Wl) : 0
    }

    function ju() {
      for (; J !== null && !ke();) Mu(J)
    }

    function Mu(e) {
      var t = kc(e.alternate, e, Ul);
      e.memoizedProps = e.pendingProps, t === null ? Fu(e) : J = t
    }

    function Nu(e) {
      var t = e,
        n = t.alternate;
      switch (t.tag) {
        case 15:
        case 0:
          t = pc(n, t, t.pendingProps, t.type, void 0, Y);
          break;
        case 11:
          t = pc(n, t, t.pendingProps, t.type.render, t.ref, Y);
          break;
        case 5:
          Do(t);
        default:
          Rc(n, t), t = J = pi(t, Ul), t = kc(n, t, Ul)
      }
      e.memoizedProps = e.pendingProps, t === null ? Fu(e) : J = t
    }

    function Pu(e, t, n, r) {
      qi = z = null, Do(t), ja = null, Ma = 0;
      var i = t.return;
      try {
        if (Qs(e, i, t, n, Y)) {
          Wl = 1, qs(e, bi(n, e.current)), J = null;
          return
        }
      } catch (t) {
        if (i !== null) throw J = i, t;
        Wl = 1, qs(e, bi(n, e.current)), J = null;
        return
      }
      t.flags & 32768 ? (L || r === 1 ? e = !0 : Vl || Y & 536870912 ? e = !1 : (Bl = e = !0, (r === 2 || r === 9 || r === 3 || r === 6) && (r = to.current, r !== null && r.tag === 13 && (r.flags |= 16384))), Iu(t, e)) : Fu(t)
    }

    function Fu(e) {
      var t = e;
      do {
        if (t.flags & 32768) {
          Iu(t, Bl);
          return
        }
        e = t.return;
        var n = Ic(t.alternate, t, Ul);
        if (n !== null) {
          J = n;
          return
        }
        if (t = t.sibling, t !== null) {
          J = t;
          return
        }
        J = t = e
      } while (t !== null);
      Wl === 0 && (Wl = 5)
    }

    function Iu(e, t) {
      do {
        var n = Lc(e.alternate, e);
        if (n !== null) {
          n.flags &= 32767, J = n;
          return
        }
        if (n = e.return, n !== null && (n.flags |= 32768, n.subtreeFlags = 0, n.deletions = null), !t && (e = e.sibling, e !== null)) {
          J = e;
          return
        }
        J = e = n
      } while (e !== null);
      Wl = 6, J = null
    }

    function Lu(e, t, n, r, a, o, s, c, l) {
      e.cancelPendingCommit = null;
      do Hu(); while (iu !== 0);
      if (q & 6) throw Error(i(327));
      if (t !== null) {
        if (t === e.current) throw Error(i(177));
        if (o = t.lanes | t.childLanes, o |= ti, rt(e, n, o, s, c, l), e === Rl && (J = Rl = null, Y = 0), ou = t, au = e, su = n, cu = o, lu = a, uu = r, t.subtreeFlags & 10256 || t.flags & 10256 ? (e.callbackNode = null, e.callbackPriority = 0, Xu(Fe, function() {
            return Uu(), null
          })) : (e.callbackNode = null, e.callbackPriority = 0), r = (t.flags & 13878) != 0, t.subtreeFlags & 13878 || r) {
          r = A.T, A.T = null, a = j.p, j.p = 2, s = q, q |= 4;
          try {
            rl(e, t, n)
          } finally {
            q = s, j.p = a, A.T = r
          }
        }
        iu = 1, Ru(), zu(), Bu()
      }
    }

    function Ru() {
      if (iu === 1) {
        iu = 0;
        var e = au,
          t = ou,
          n = (t.flags & 13878) != 0;
        if (t.subtreeFlags & 13878 || n) {
          n = A.T, A.T = null;
          var r = j.p;
          j.p = 2;
          var i = q;
          q |= 4;
          try {
            gl(t, e);
            var a = zd,
              o = Ar(e.containerInfo),
              s = a.focusedElem,
              c = a.selectionRange;
            if (o !== s && s && s.ownerDocument && kr(s.ownerDocument.documentElement, s)) {
              if (c !== null && jr(s)) {
                var l = c.start,
                  u = c.end;
                if (u === void 0 && (u = l), `selectionStart` in s) s.selectionStart = l, s.selectionEnd = Math.min(u, s.value.length);
                else {
                  var d = s.ownerDocument || document,
                    f = d && d.defaultView || window;
                  if (f.getSelection) {
                    var p = f.getSelection(),
                      m = s.textContent.length,
                      h = Math.min(c.start, m),
                      g = c.end === void 0 ? h : Math.min(c.end, m);
                    !p.extend && h > g && (o = g, g = h, h = o);
                    var _ = Or(s, h),
                      v = Or(s, g);
                    if (_ && v && (p.rangeCount !== 1 || p.anchorNode !== _.node || p.anchorOffset !== _.offset || p.focusNode !== v.node || p.focusOffset !== v.offset)) {
                      var y = d.createRange();
                      y.setStart(_.node, _.offset), p.removeAllRanges(), h > g ? (p.addRange(y), p.extend(v.node, v.offset)) : (y.setEnd(v.node, v.offset), p.addRange(y))
                    }
                  }
                }
              }
              for (d = [], p = s; p = p.parentNode;) p.nodeType === 1 && d.push({
                element: p,
                left: p.scrollLeft,
                top: p.scrollTop
              });
              for (typeof s.focus == `function` && s.focus(), s = 0; s < d.length; s++) {
                var b = d[s];
                b.element.scrollLeft = b.left, b.element.scrollTop = b.top
              }
            }
            sp = !!Rd, zd = Rd = null
          } finally {
            q = i, j.p = r, A.T = n
          }
        }
        e.current = t, iu = 2
      }
    }

    function zu() {
      if (iu === 2) {
        iu = 0;
        var e = au,
          t = ou,
          n = (t.flags & 8772) != 0;
        if (t.subtreeFlags & 8772 || n) {
          n = A.T, A.T = null;
          var r = j.p;
          j.p = 2;
          var i = q;
          q |= 4;
          try {
            il(e, t.alternate, t)
          } finally {
            q = i, j.p = r, A.T = n
          }
        }
        iu = 3
      }
    }

    function Bu() {
      if (iu === 4 || iu === 3) {
        iu = 0, Ae();
        var e = au,
          t = ou,
          n = su,
          r = uu;
        t.subtreeFlags & 10256 || t.flags & 10256 ? iu = 5 : (iu = 0, ou = au = null, Vu(e, e.pendingLanes));
        var i = e.pendingLanes;
        if (i === 0 && (ru = null), ct(n), t = t.stateNode, Ve && typeof Ve.onCommitFiberRoot == `function`) try {
          Ve.onCommitFiberRoot(Be, t, void 0, (t.current.flags & 128) == 128)
        } catch {}
        if (r !== null) {
          t = A.T, i = j.p, j.p = 2, A.T = null;
          try {
            for (var a = e.onRecoverableError, o = 0; o < r.length; o++) {
              var s = r[o];
              a(s.value, {
                componentStack: s.stack
              })
            }
          } finally {
            A.T = t, j.p = i
          }
        }
        su & 3 && Hu(), rd(e), i = e.pendingLanes, n & 261930 && i & 42 ? e === fu ? du++ : (du = 0, fu = e) : du = 0, id(0, !1)
      }
    }

    function Vu(e, t) {
      (e.pooledCacheLanes &= t) === 0 && (t = e.pooledCache, t != null && (e.pooledCache = null, ca(t)))
    }

    function Hu() {
      return Ru(), zu(), Bu(), Uu()
    }

    function Uu() {
      if (iu !== 5) return !1;
      var e = au,
        t = cu;
      cu = 0;
      var n = ct(su),
        r = A.T,
        a = j.p;
      try {
        j.p = 32 > n ? 32 : n, A.T = null, n = lu, lu = null;
        var o = au,
          s = su;
        if (iu = 0, ou = au = null, su = 0, q & 6) throw Error(i(331));
        var c = q;
        if (q |= 4, Nl(o.current), Tl(o, o.current, s, n), q = c, id(0, !1), Ve && typeof Ve.onPostCommitFiberRoot == `function`) try {
          Ve.onPostCommitFiberRoot(Be, o)
        } catch {}
        return !0
      } finally {
        j.p = a, A.T = r, Vu(e, t)
      }
    }

    function Wu(e, t, n) {
      t = bi(n, t), t = Ys(e.stateNode, t, 2), e = Ua(e, t, 2), e !== null && (nt(e, 2), rd(e))
    }

    function Z(e, t, n) {
      if (e.tag === 3) Wu(e, e, n);
      else
        for (; t !== null;) {
          if (t.tag === 3) {
            Wu(t, e, n);
            break
          } else if (t.tag === 1) {
            var r = t.stateNode;
            if (typeof t.type.getDerivedStateFromError == `function` || typeof r.componentDidCatch == `function` && (ru === null || !ru.has(r))) {
              e = bi(n, e), n = Xs(2), r = Ua(t, n, 2), r !== null && (Zs(n, r, t, e), nt(r, 2), rd(r));
              break
            }
          }
          t = t.return
        }
    }

    function Gu(e, t, n) {
      var r = e.pingCache;
      if (r === null) {
        r = e.pingCache = new Ll;
        var i = new Set;
        r.set(t, i)
      } else i = r.get(t), i === void 0 && (i = new Set, r.set(t, i));
      i.has(n) || (Hl = !0, i.add(n), e = Ku.bind(null, e, t, n), t.then(e, e))
    }

    function Ku(e, t, n) {
      var r = e.pingCache;
      r !== null && r.delete(t), e.pingedLanes |= e.suspendedLanes & n, e.warmLanes &= ~n, Rl === e && (Y & n) === n && (Wl === 4 || Wl === 3 && (Y & 62914560) === Y && 300 > je() - $l ? !(q & 2) && Su(e, 0) : ql |= n, Yl === Y && (Yl = 0)), rd(e)
    }

    function qu(e, t) {
      t === 0 && (t = et()), e = ai(e, t), e !== null && (nt(e, t), rd(e))
    }

    function Ju(e) {
      var t = e.memoizedState,
        n = 0;
      t !== null && (n = t.retryLane), qu(e, n)
    }

    function Yu(e, t) {
      var n = 0;
      switch (e.tag) {
        case 31:
        case 13:
          var r = e.stateNode,
            a = e.memoizedState;
          a !== null && (n = a.retryLane);
          break;
        case 19:
          r = e.stateNode;
          break;
        case 22:
          r = e.stateNode._retryCache;
          break;
        default:
          throw Error(i(314))
      }
      r !== null && r.delete(t), qu(e, n)
    }

    function Xu(e, t) {
      return De(e, t)
    }
    var Zu = null,
      Qu = null,
      $u = !1,
      ed = !1,
      td = !1,
      nd = 0;

    function rd(e) {
      e !== Qu && e.next === null && (Qu === null ? Zu = Qu = e : Qu = Qu.next = e), ed = !0, $u || ($u = !0, ud())
    }

    function id(e, t) {
      if (!td && ed) {
        td = !0;
        do
          for (var n = !1, r = Zu; r !== null;) {
            if (!t)
              if (e !== 0) {
                var i = r.pendingLanes;
                if (i === 0) var a = 0;
                else {
                  var o = r.suspendedLanes,
                    s = r.pingedLanes;
                  a = (1 << 31 - Ue(42 | e) + 1) - 1, a &= i & ~(o & ~s), a = a & 201326741 ? a & 201326741 | 1 : a ? a | 2 : 0
                }
                a !== 0 && (n = !0, ld(r, a))
              } else a = Y, a = Ze(r, r === Rl ? a : 0, r.cancelPendingCommit !== null || r.timeoutHandle !== -1), !(a & 3) || Qe(r, a) || (n = !0, ld(r, a));
            r = r.next
          }
        while (n);
        td = !1
      }
    }

    function ad() {
      od()
    }

    function od() {
      ed = $u = !1;
      var e = 0;
      nd !== 0 && Gd() && (e = nd);
      for (var t = je(), n = null, r = Zu; r !== null;) {
        var i = r.next,
          a = sd(r, t);
        a === 0 ? (r.next = null, n === null ? Zu = i : n.next = i, i === null && (Qu = n)) : (n = r, (e !== 0 || a & 3) && (ed = !0)), r = i
      }
      iu !== 0 && iu !== 5 || id(e, !1), nd !== 0 && (nd = 0)
    }

    function sd(e, t) {
      for (var n = e.suspendedLanes, r = e.pingedLanes, i = e.expirationTimes, a = e.pendingLanes & -62914561; 0 < a;) {
        var o = 31 - Ue(a),
          s = 1 << o,
          c = i[o];
        c === -1 ? ((s & n) === 0 || (s & r) !== 0) && (i[o] = $e(s, t)) : c <= t && (e.expiredLanes |= s), a &= ~s
      }
      if (t = Rl, n = Y, n = Ze(e, e === t ? n : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== -1), r = e.callbackNode, n === 0 || e === t && (X === 2 || X === 9) || e.cancelPendingCommit !== null) return r !== null && r !== null && Oe(r), e.callbackNode = null, e.callbackPriority = 0;
      if (!(n & 3) || Qe(e, n)) {
        if (t = n & -n, t === e.callbackPriority) return t;
        switch (r !== null && Oe(r), ct(n)) {
          case 2:
          case 8:
            n = Pe;
            break;
          case 32:
            n = Fe;
            break;
          case 268435456:
            n = Le;
            break;
          default:
            n = Fe
        }
        return r = cd.bind(null, e), n = De(n, r), e.callbackPriority = t, e.callbackNode = n, t
      }
      return r !== null && r !== null && Oe(r), e.callbackPriority = 2, e.callbackNode = null, 2
    }

    function cd(e, t) {
      if (iu !== 0 && iu !== 5) return e.callbackNode = null, e.callbackPriority = 0, null;
      var n = e.callbackNode;
      if (Hu() && e.callbackNode !== n) return null;
      var r = Y;
      return r = Ze(e, e === Rl ? r : 0, e.cancelPendingCommit !== null || e.timeoutHandle !== -1), r === 0 ? null : (gu(e, r, t), sd(e, je()), e.callbackNode != null && e.callbackNode === n ? cd.bind(null, e) : null)
    }

    function ld(e, t) {
      if (Hu()) return null;
      gu(e, t, !0)
    }

    function ud() {
      Yd(function() {
        q & 6 ? De(Ne, ad) : od()
      })
    }

    function dd() {
      if (nd === 0) {
        var e = da;
        e === 0 && (e = qe, qe <<= 1, !(qe & 261888) && (qe = 256)), nd = e
      }
      return nd
    }

    function fd(e) {
      return e == null || typeof e == `symbol` || typeof e == `boolean` ? null : typeof e == `function` ? e : an(`` + e)
    }

    function pd(e, t) {
      var n = t.ownerDocument.createElement(`input`);
      return n.name = t.name, n.value = t.value, e.id && n.setAttribute(`form`, e.id), t.parentNode.insertBefore(n, t), e = new FormData(e), n.parentNode.removeChild(n), e
    }

    function md(e, t, n, r, i) {
      if (t === `submit` && n && n.stateNode === i) {
        var a = fd((i[pt] || null).action),
          o = r.submitter;
        o && (t = (t = o[pt] || null) ? fd(t.formAction) : o.getAttribute(`formAction`), t !== null && (a = t, o = null));
        var s = new Dn(`action`, `action`, null, r, i);
        e.push({
          event: s,
          listeners: [{
            instance: null,
            listener: function() {
              if (r.defaultPrevented) {
                if (nd !== 0) {
                  var e = o ? pd(i, o) : new FormData(i);
                  xs(n, {
                    pending: !0,
                    data: e,
                    method: i.method,
                    action: a
                  }, null, e)
                }
              } else typeof a == `function` && (s.preventDefault(), e = o ? pd(i, o) : new FormData(i), xs(n, {
                pending: !0,
                data: e,
                method: i.method,
                action: a
              }, a, e))
            },
            currentTarget: i
          }]
        })
      }
    }
    for (var hd = 0; hd < Xr.length; hd++) {
      var gd = Xr[hd];
      Zr(gd.toLowerCase(), `on` + (gd[0].toUpperCase() + gd.slice(1)))
    }
    Zr(Hr, `onAnimationEnd`), Zr(Ur, `onAnimationIteration`), Zr(Wr, `onAnimationStart`), Zr(`dblclick`, `onDoubleClick`), Zr(`focusin`, `onFocus`), Zr(`focusout`, `onBlur`), Zr(Gr, `onTransitionRun`), Zr(Kr, `onTransitionStart`), Zr(qr, `onTransitionCancel`), Zr(Jr, `onTransitionEnd`), kt(`onMouseEnter`, [`mouseout`, `mouseover`]), kt(`onMouseLeave`, [`mouseout`, `mouseover`]), kt(`onPointerEnter`, [`pointerout`, `pointerover`]), kt(`onPointerLeave`, [`pointerout`, `pointerover`]), Ot(`onChange`, `change click focusin focusout input keydown keyup selectionchange`.split(` `)), Ot(`onSelect`, `focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange`.split(` `)), Ot(`onBeforeInput`, [`compositionend`, `keypress`, `textInput`, `paste`]), Ot(`onCompositionEnd`, `compositionend focusout keydown keypress keyup mousedown`.split(` `)), Ot(`onCompositionStart`, `compositionstart focusout keydown keypress keyup mousedown`.split(` `)), Ot(`onCompositionUpdate`, `compositionupdate focusout keydown keypress keyup mousedown`.split(` `));
    var _d = `abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting`.split(` `),
      vd = new Set(`beforetoggle cancel close invalid load scroll scrollend toggle`.split(` `).concat(_d));

    function yd(e, t) {
      t = (t & 4) != 0;
      for (var n = 0; n < e.length; n++) {
        var r = e[n],
          i = r.event;
        r = r.listeners;
        a: {
          var a = void 0;
          if (t)
            for (var o = r.length - 1; 0 <= o; o--) {
              var s = r[o],
                c = s.instance,
                l = s.currentTarget;
              if (s = s.listener, c !== a && i.isPropagationStopped()) break a;
              a = s, i.currentTarget = l;
              try {
                a(i)
              } catch (e) {
                Qr(e)
              }
              i.currentTarget = null, a = c
            } else
              for (o = 0; o < r.length; o++) {
                if (s = r[o], c = s.instance, l = s.currentTarget, s = s.listener, c !== a && i.isPropagationStopped()) break a;
                a = s, i.currentTarget = l;
                try {
                  a(i)
                } catch (e) {
                  Qr(e)
                }
                i.currentTarget = null, a = c
              }
        }
      }
    }

    function Q(e, t) {
      var n = t[ht];
      n === void 0 && (n = t[ht] = new Set);
      var r = e + `__bubble`;
      n.has(r) || (Cd(t, e, 2, !1), n.add(r))
    }

    function bd(e, t, n) {
      var r = 0;
      t && (r |= 4), Cd(n, e, r, t)
    }
    var xd = `_reactListening` + Math.random().toString(36).slice(2);

    function Sd(e) {
      if (!e[xd]) {
        e[xd] = !0, Et.forEach(function(t) {
          t !== `selectionchange` && (vd.has(t) || bd(t, !1, e), bd(t, !0, e))
        });
        var t = e.nodeType === 9 ? e : e.ownerDocument;
        t === null || t[xd] || (t[xd] = !0, bd(`selectionchange`, !1, t))
      }
    }

    function Cd(e, t, n, r) {
      switch (mp(t)) {
        case 2:
          var i = cp;
          break;
        case 8:
          i = lp;
          break;
        default:
          i = up
      }
      n = i.bind(null, t, n, e), i = void 0, !gn || t !== `touchstart` && t !== `touchmove` && t !== `wheel` || (i = !0), r ? i === void 0 ? e.addEventListener(t, n, !0) : e.addEventListener(t, n, {
        capture: !0,
        passive: i
      }) : i === void 0 ? e.addEventListener(t, n, !1) : e.addEventListener(t, n, {
        passive: i
      })
    }

    function wd(e, t, n, r, i) {
      var a = r;
      if (!(t & 1) && !(t & 2) && r !== null) a: for (;;) {
        if (r === null) return;
        var s = r.tag;
        if (s === 3 || s === 4) {
          var c = r.stateNode.containerInfo;
          if (c === i) break;
          if (s === 4)
            for (s = r.return; s !== null;) {
              var l = s.tag;
              if ((l === 3 || l === 4) && s.stateNode.containerInfo === i) return;
              s = s.return
            }
          for (; c !== null;) {
            if (s = xt(c), s === null) return;
            if (l = s.tag, l === 5 || l === 6 || l === 26 || l === 27) {
              r = a = s;
              continue a
            }
            c = c.parentNode
          }
        }
        r = r.return
      }
      pn(function() {
        var r = a,
          i = cn(n),
          s = [];
        a: {
          var c = Yr.get(e);
          if (c !== void 0) {
            var l = Dn,
              u = e;
            switch (e) {
              case `keypress`:
                if (Sn(n) === 0) break a;
              case `keydown`:
              case `keyup`:
                l = Gn;
                break;
              case `focusin`:
                u = `focus`, l = In;
                break;
              case `focusout`:
                u = `blur`, l = In;
                break;
              case `beforeblur`:
              case `afterblur`:
                l = In;
                break;
              case `click`:
                if (n.button === 2) break a;
              case `auxclick`:
              case `dblclick`:
              case `mousedown`:
              case `mousemove`:
              case `mouseup`:
              case `mouseout`:
              case `mouseover`:
              case `contextmenu`:
                l = Pn;
                break;
              case `drag`:
              case `dragend`:
              case `dragenter`:
              case `dragexit`:
              case `dragleave`:
              case `dragover`:
              case `dragstart`:
              case `drop`:
                l = Fn;
                break;
              case `touchcancel`:
              case `touchend`:
              case `touchmove`:
              case `touchstart`:
                l = qn;
                break;
              case Hr:
              case Ur:
              case Wr:
                l = Ln;
                break;
              case Jr:
                l = Jn;
                break;
              case `scroll`:
              case `scrollend`:
                l = kn;
                break;
              case `wheel`:
                l = Yn;
                break;
              case `copy`:
              case `cut`:
              case `paste`:
                l = Rn;
                break;
              case `gotpointercapture`:
              case `lostpointercapture`:
              case `pointercancel`:
              case `pointerdown`:
              case `pointermove`:
              case `pointerout`:
              case `pointerover`:
              case `pointerup`:
                l = Kn;
                break;
              case `toggle`:
              case `beforetoggle`:
                l = Xn
            }
            var d = (t & 4) != 0,
              f = !d && (e === `scroll` || e === `scrollend`),
              p = d ? c === null ? null : c + `Capture` : c;
            d = [];
            for (var m = r, h; m !== null;) {
              var g = m;
              if (h = g.stateNode, g = g.tag, g !== 5 && g !== 26 && g !== 27 || h === null || p === null || (g = mn(m, p), g != null && d.push(Td(m, g, h))), f) break;
              m = m.return
            }
            0 < d.length && (c = new l(c, u, null, n, i), s.push({
              event: c,
              listeners: d
            }))
          }
        }
        if (!(t & 7)) {
          a: {
            if (c = e === `mouseover` || e === `pointerover`, l = e === `mouseout` || e === `pointerout`, c && n !== sn && (u = n.relatedTarget || n.fromElement) && (xt(u) || u[mt])) break a;
            if ((l || c) && (c = i.window === i ? i : (c = i.ownerDocument) ? c.defaultView || c.parentWindow : window, l ? (u = n.relatedTarget || n.toElement, l = r, u = u ? xt(u) : null, u !== null && (f = o(u), d = u.tag, u !== f || d !== 5 && d !== 27 && d !== 6) && (u = null)) : (l = null, u = r), l !== u)) {
              if (d = Pn, g = `onMouseLeave`, p = `onMouseEnter`, m = `mouse`, (e === `pointerout` || e === `pointerover`) && (d = Kn, g = `onPointerLeave`, p = `onPointerEnter`, m = `pointer`), f = l == null ? c : Ct(l), h = u == null ? c : Ct(u), c = new d(g, m + `leave`, l, n, i), c.target = f, c.relatedTarget = h, g = null, xt(i) === r && (d = new d(p, m + `enter`, u, n, i), d.target = h, d.relatedTarget = f, g = d), f = g, l && u) b: {
                for (d = Dd, p = l, m = u, h = 0, g = p; g; g = d(g)) h++;g = 0;
                for (var _ = m; _; _ = d(_)) g++;
                for (; 0 < h - g;) p = d(p),
                h--;
                for (; 0 < g - h;) m = d(m),
                g--;
                for (; h--;) {
                  if (p === m || m !== null && p === m.alternate) {
                    d = p;
                    break b
                  }
                  p = d(p), m = d(m)
                }
                d = null
              }
              else d = null;
              l !== null && Od(s, c, l, d, !1), u !== null && f !== null && Od(s, f, u, d, !0)
            }
          }
          a: {
            if (c = r ? Ct(r) : window, l = c.nodeName && c.nodeName.toLowerCase(), l === `select` || l === `input` && c.type === `file`) var v = mr;
            else if (cr(c))
              if (hr) v = wr;
              else {
                v = Sr;
                var y = xr
              }
            else l = c.nodeName,
            !l || l.toLowerCase() !== `input` || c.type !== `checkbox` && c.type !== `radio` ? r && tn(r.elementType) && (v = mr) : v = Cr;
            if (v &&= v(e, r)) {
              lr(s, v, n, i);
              break a
            }
            y && y(e, c, r),
            e === `focusout` && r && c.type === `number` && r.memoizedProps.value != null && qt(c, `number`, c.value)
          }
          switch (y = r ? Ct(r) : window, e) {
            case `focusin`:
              (cr(y) || y.contentEditable === `true`) && (Nr = y, Pr = r, Fr = null);
              break;
            case `focusout`:
              Fr = Pr = Nr = null;
              break;
            case `mousedown`:
              Ir = !0;
              break;
            case `contextmenu`:
            case `mouseup`:
            case `dragend`:
              Ir = !1, Lr(s, n, i);
              break;
            case `selectionchange`:
              if (Mr) break;
            case `keydown`:
            case `keyup`:
              Lr(s, n, i)
          }
          var b;
          if (Qn) b: {
            switch (e) {
              case `compositionstart`:
                var x = `onCompositionStart`;
                break b;
              case `compositionend`:
                x = `onCompositionEnd`;
                break b;
              case `compositionupdate`:
                x = `onCompositionUpdate`;
                break b
            }
            x = void 0
          }
          else ir ? nr(e, n) && (x = `onCompositionEnd`) : e === `keydown` && n.keyCode === 229 && (x = `onCompositionStart`);x && (tr && n.locale !== `ko` && (ir || x !== `onCompositionStart` ? x === `onCompositionEnd` && ir && (b = xn()) : (vn = i, yn = `value` in vn ? vn.value : vn.textContent, ir = !0)), y = Ed(r, x), 0 < y.length && (x = new zn(x, e, null, n, i), s.push({
            event: x,
            listeners: y
          }), b ? x.data = b : (b = rr(n), b !== null && (x.data = b)))),
          (b = er ? ar(e, n) : or(e, n)) && (x = Ed(r, `onBeforeInput`), 0 < x.length && (y = new zn(`onBeforeInput`, `beforeinput`, null, n, i), s.push({
            event: y,
            listeners: x
          }), y.data = b)),
          md(s, e, r, n, i)
        }
        yd(s, t)
      })
    }

    function Td(e, t, n) {
      return {
        instance: e,
        listener: t,
        currentTarget: n
      }
    }

    function Ed(e, t) {
      for (var n = t + `Capture`, r = []; e !== null;) {
        var i = e,
          a = i.stateNode;
        if (i = i.tag, i !== 5 && i !== 26 && i !== 27 || a === null || (i = mn(e, n), i != null && r.unshift(Td(e, i, a)), i = mn(e, t), i != null && r.push(Td(e, i, a))), e.tag === 3) return r;
        e = e.return
      }
      return []
    }

    function Dd(e) {
      if (e === null) return null;
      do e = e.return; while (e && e.tag !== 5 && e.tag !== 27);
      return e || null
    }

    function Od(e, t, n, r, i) {
      for (var a = t._reactName, o = []; n !== null && n !== r;) {
        var s = n,
          c = s.alternate,
          l = s.stateNode;
        if (s = s.tag, c !== null && c === r) break;
        s !== 5 && s !== 26 && s !== 27 || l === null || (c = l, i ? (l = mn(n, a), l != null && o.unshift(Td(n, l, c))) : i || (l = mn(n, a), l != null && o.push(Td(n, l, c)))), n = n.return
      }
      o.length !== 0 && e.push({
        event: t,
        listeners: o
      })
    }
    var kd = /\r\n?/g,
      Ad = /\u0000|\uFFFD/g;

    function jd(e) {
      return (typeof e == `string` ? e : `` + e).replace(kd, `
`).replace(Ad, ``)
    }

    function Md(e, t) {
      return t = jd(t), jd(e) === t
    }

    function $(e, t, n, r, a, o) {
      switch (n) {
        case `children`:
          typeof r == `string` ? t === `body` || t === `textarea` && r === `` || Zt(e, r) : (typeof r == `number` || typeof r == `bigint`) && t !== `body` && Zt(e, `` + r);
          break;
        case `className`:
          Ft(e, `class`, r);
          break;
        case `tabIndex`:
          Ft(e, `tabindex`, r);
          break;
        case `dir`:
        case `role`:
        case `viewBox`:
        case `width`:
        case `height`:
          Ft(e, n, r);
          break;
        case `style`:
          en(e, r, o);
          break;
        case `data`:
          if (t !== `object`) {
            Ft(e, `data`, r);
            break
          }
        case `src`:
        case `href`:
          if (r === `` && (t !== `a` || n !== `href`)) {
            e.removeAttribute(n);
            break
          }
          if (r == null || typeof r == `function` || typeof r == `symbol` || typeof r == `boolean`) {
            e.removeAttribute(n);
            break
          }
          r = an(`` + r), e.setAttribute(n, r);
          break;
        case `action`:
        case `formAction`:
          if (typeof r == `function`) {
            e.setAttribute(n, `javascript:throw new Error('A React form was unexpectedly submitted. If you called form.submit() manually, consider using form.requestSubmit() instead. If you\\'re trying to use event.stopPropagation() in a submit event handler, consider also calling event.preventDefault().')`);
            break
          } else typeof o == `function` && (n === `formAction` ? (t !== `input` && $(e, t, `name`, a.name, a, null), $(e, t, `formEncType`, a.formEncType, a, null), $(e, t, `formMethod`, a.formMethod, a, null), $(e, t, `formTarget`, a.formTarget, a, null)) : ($(e, t, `encType`, a.encType, a, null), $(e, t, `method`, a.method, a, null), $(e, t, `target`, a.target, a, null)));
          if (r == null || typeof r == `symbol` || typeof r == `boolean`) {
            e.removeAttribute(n);
            break
          }
          r = an(`` + r), e.setAttribute(n, r);
          break;
        case `onClick`:
          r != null && (e.onclick = on);
          break;
        case `onScroll`:
          r != null && Q(`scroll`, e);
          break;
        case `onScrollEnd`:
          r != null && Q(`scrollend`, e);
          break;
        case `dangerouslySetInnerHTML`:
          if (r != null) {
            if (typeof r != `object` || !(`__html` in r)) throw Error(i(61));
            if (n = r.__html, n != null) {
              if (a.children != null) throw Error(i(60));
              e.innerHTML = n
            }
          }
          break;
        case `multiple`:
          e.multiple = r && typeof r != `function` && typeof r != `symbol`;
          break;
        case `muted`:
          e.muted = r && typeof r != `function` && typeof r != `symbol`;
          break;
        case `suppressContentEditableWarning`:
        case `suppressHydrationWarning`:
        case `defaultValue`:
        case `defaultChecked`:
        case `innerHTML`:
        case `ref`:
          break;
        case `autoFocus`:
          break;
        case `xlinkHref`:
          if (r == null || typeof r == `function` || typeof r == `boolean` || typeof r == `symbol`) {
            e.removeAttribute(`xlink:href`);
            break
          }
          n = an(`` + r), e.setAttributeNS(`http://www.w3.org/1999/xlink`, `xlink:href`, n);
          break;
        case `contentEditable`:
        case `spellCheck`:
        case `draggable`:
        case `value`:
        case `autoReverse`:
        case `externalResourcesRequired`:
        case `focusable`:
        case `preserveAlpha`:
          r != null && typeof r != `function` && typeof r != `symbol` ? e.setAttribute(n, `` + r) : e.removeAttribute(n);
          break;
        case `inert`:
        case `allowFullScreen`:
        case `async`:
        case `autoPlay`:
        case `controls`:
        case `default`:
        case `defer`:
        case `disabled`:
        case `disablePictureInPicture`:
        case `disableRemotePlayback`:
        case `formNoValidate`:
        case `hidden`:
        case `loop`:
        case `noModule`:
        case `noValidate`:
        case `open`:
        case `playsInline`:
        case `readOnly`:
        case `required`:
        case `reversed`:
        case `scoped`:
        case `seamless`:
        case `itemScope`:
          r && typeof r != `function` && typeof r != `symbol` ? e.setAttribute(n, ``) : e.removeAttribute(n);
          break;
        case `capture`:
        case `download`:
          !0 === r ? e.setAttribute(n, ``) : !1 !== r && r != null && typeof r != `function` && typeof r != `symbol` ? e.setAttribute(n, r) : e.removeAttribute(n);
          break;
        case `cols`:
        case `rows`:
        case `size`:
        case `span`:
          r != null && typeof r != `function` && typeof r != `symbol` && !isNaN(r) && 1 <= r ? e.setAttribute(n, r) : e.removeAttribute(n);
          break;
        case `rowSpan`:
        case `start`:
          r == null || typeof r == `function` || typeof r == `symbol` || isNaN(r) ? e.removeAttribute(n) : e.setAttribute(n, r);
          break;
        case `popover`:
          Q(`beforetoggle`, e), Q(`toggle`, e), Pt(e, `popover`, r);
          break;
        case `xlinkActuate`:
          It(e, `http://www.w3.org/1999/xlink`, `xlink:actuate`, r);
          break;
        case `xlinkArcrole`:
          It(e, `http://www.w3.org/1999/xlink`, `xlink:arcrole`, r);
          break;
        case `xlinkRole`:
          It(e, `http://www.w3.org/1999/xlink`, `xlink:role`, r);
          break;
        case `xlinkShow`:
          It(e, `http://www.w3.org/1999/xlink`, `xlink:show`, r);
          break;
        case `xlinkTitle`:
          It(e, `http://www.w3.org/1999/xlink`, `xlink:title`, r);
          break;
        case `xlinkType`:
          It(e, `http://www.w3.org/1999/xlink`, `xlink:type`, r);
          break;
        case `xmlBase`:
          It(e, `http://www.w3.org/XML/1998/namespace`, `xml:base`, r);
          break;
        case `xmlLang`:
          It(e, `http://www.w3.org/XML/1998/namespace`, `xml:lang`, r);
          break;
        case `xmlSpace`:
          It(e, `http://www.w3.org/XML/1998/namespace`, `xml:space`, r);
          break;
        case `is`:
          Pt(e, `is`, r);
          break;
        case `innerText`:
        case `textContent`:
          break;
        default:
          (!(2 < n.length) || n[0] !== `o` && n[0] !== `O` || n[1] !== `n` && n[1] !== `N`) && (n = nn.get(n) || n, Pt(e, n, r))
      }
    }

    function Nd(e, t, n, r, a, o) {
      switch (n) {
        case `style`:
          en(e, r, o);
          break;
        case `dangerouslySetInnerHTML`:
          if (r != null) {
            if (typeof r != `object` || !(`__html` in r)) throw Error(i(61));
            if (n = r.__html, n != null) {
              if (a.children != null) throw Error(i(60));
              e.innerHTML = n
            }
          }
          break;
        case `children`:
          typeof r == `string` ? Zt(e, r) : (typeof r == `number` || typeof r == `bigint`) && Zt(e, `` + r);
          break;
        case `onScroll`:
          r != null && Q(`scroll`, e);
          break;
        case `onScrollEnd`:
          r != null && Q(`scrollend`, e);
          break;
        case `onClick`:
          r != null && (e.onclick = on);
          break;
        case `suppressContentEditableWarning`:
        case `suppressHydrationWarning`:
        case `innerHTML`:
        case `ref`:
          break;
        case `innerText`:
        case `textContent`:
          break;
        default:
          if (!Dt.hasOwnProperty(n)) a: {
            if (n[0] === `o` && n[1] === `n` && (a = n.endsWith(`Capture`), t = n.slice(2, a ? n.length - 7 : void 0), o = e[pt] || null, o = o == null ? null : o[n], typeof o == `function` && e.removeEventListener(t, o, a), typeof r == `function`)) {
              typeof o != `function` && o !== null && (n in e ? e[n] = null : e.hasAttribute(n) && e.removeAttribute(n)), e.addEventListener(t, r, a);
              break a
            }
            n in e ? e[n] = r : !0 === r ? e.setAttribute(n, ``) : Pt(e, n, r)
          }
      }
    }

    function Pd(e, t, n) {
      switch (t) {
        case `div`:
        case `span`:
        case `svg`:
        case `path`:
        case `a`:
        case `g`:
        case `p`:
        case `li`:
          break;
        case `img`:
          Q(`error`, e), Q(`load`, e);
          var r = !1,
            a = !1,
            o;
          for (o in n)
            if (n.hasOwnProperty(o)) {
              var s = n[o];
              if (s != null) switch (o) {
                case `src`:
                  r = !0;
                  break;
                case `srcSet`:
                  a = !0;
                  break;
                case `children`:
                case `dangerouslySetInnerHTML`:
                  throw Error(i(137, t));
                default:
                  $(e, t, o, s, n, null)
              }
            } a && $(e, t, `srcSet`, n.srcSet, n, null), r && $(e, t, `src`, n.src, n, null);
          return;
        case `input`:
          Q(`invalid`, e);
          var c = o = s = a = null,
            l = null,
            u = null;
          for (r in n)
            if (n.hasOwnProperty(r)) {
              var d = n[r];
              if (d != null) switch (r) {
                case `name`:
                  a = d;
                  break;
                case `type`:
                  s = d;
                  break;
                case `checked`:
                  l = d;
                  break;
                case `defaultChecked`:
                  u = d;
                  break;
                case `value`:
                  o = d;
                  break;
                case `defaultValue`:
                  c = d;
                  break;
                case `children`:
                case `dangerouslySetInnerHTML`:
                  if (d != null) throw Error(i(137, t));
                  break;
                default:
                  $(e, t, r, d, n, null)
              }
            } Kt(e, o, c, l, u, s, a, !1);
          return;
        case `select`:
          for (a in Q(`invalid`, e), r = s = o = null, n)
            if (n.hasOwnProperty(a) && (c = n[a], c != null)) switch (a) {
              case `value`:
                o = c;
                break;
              case `defaultValue`:
                s = c;
                break;
              case `multiple`:
                r = c;
              default:
                $(e, t, a, c, n, null)
            }
          t = o, n = s, e.multiple = !!r, t == null ? n != null && Jt(e, !!r, n, !0) : Jt(e, !!r, t, !1);
          return;
        case `textarea`:
          for (s in Q(`invalid`, e), o = a = r = null, n)
            if (n.hasOwnProperty(s) && (c = n[s], c != null)) switch (s) {
              case `value`:
                r = c;
                break;
              case `defaultValue`:
                a = c;
                break;
              case `children`:
                o = c;
                break;
              case `dangerouslySetInnerHTML`:
                if (c != null) throw Error(i(91));
                break;
              default:
                $(e, t, s, c, n, null)
            }
          Xt(e, r, a, o);
          return;
        case `option`:
          for (l in n)
            if (n.hasOwnProperty(l) && (r = n[l], r != null)) switch (l) {
              case `selected`:
                e.selected = r && typeof r != `function` && typeof r != `symbol`;
                break;
              default:
                $(e, t, l, r, n, null)
            }
          return;
        case `dialog`:
          Q(`beforetoggle`, e), Q(`toggle`, e), Q(`cancel`, e), Q(`close`, e);
          break;
        case `iframe`:
        case `object`:
          Q(`load`, e);
          break;
        case `video`:
        case `audio`:
          for (r = 0; r < _d.length; r++) Q(_d[r], e);
          break;
        case `image`:
          Q(`error`, e), Q(`load`, e);
          break;
        case `details`:
          Q(`toggle`, e);
          break;
        case `embed`:
        case `source`:
        case `link`:
          Q(`error`, e), Q(`load`, e);
        case `area`:
        case `base`:
        case `br`:
        case `col`:
        case `hr`:
        case `keygen`:
        case `meta`:
        case `param`:
        case `track`:
        case `wbr`:
        case `menuitem`:
          for (u in n)
            if (n.hasOwnProperty(u) && (r = n[u], r != null)) switch (u) {
              case `children`:
              case `dangerouslySetInnerHTML`:
                throw Error(i(137, t));
              default:
                $(e, t, u, r, n, null)
            }
          return;
        default:
          if (tn(t)) {
            for (d in n) n.hasOwnProperty(d) && (r = n[d], r !== void 0 && Nd(e, t, d, r, n, void 0));
            return
          }
      }
      for (c in n) n.hasOwnProperty(c) && (r = n[c], r != null && $(e, t, c, r, n, null))
    }

    function Fd(e, t, n, r) {
      switch (t) {
        case `div`:
        case `span`:
        case `svg`:
        case `path`:
        case `a`:
        case `g`:
        case `p`:
        case `li`:
          break;
        case `input`:
          var a = null,
            o = null,
            s = null,
            c = null,
            l = null,
            u = null,
            d = null;
          for (m in n) {
            var f = n[m];
            if (n.hasOwnProperty(m) && f != null) switch (m) {
              case `checked`:
                break;
              case `value`:
                break;
              case `defaultValue`:
                l = f;
              default:
                r.hasOwnProperty(m) || $(e, t, m, null, r, f)
            }
          }
          for (var p in r) {
            var m = r[p];
            if (f = n[p], r.hasOwnProperty(p) && (m != null || f != null)) switch (p) {
              case `type`:
                o = m;
                break;
              case `name`:
                a = m;
                break;
              case `checked`:
                u = m;
                break;
              case `defaultChecked`:
                d = m;
                break;
              case `value`:
                s = m;
                break;
              case `defaultValue`:
                c = m;
                break;
              case `children`:
              case `dangerouslySetInnerHTML`:
                if (m != null) throw Error(i(137, t));
                break;
              default:
                m !== f && $(e, t, p, m, r, f)
            }
          }
          Gt(e, s, c, l, u, d, o, a);
          return;
        case `select`:
          for (o in m = s = c = p = null, n)
            if (l = n[o], n.hasOwnProperty(o) && l != null) switch (o) {
              case `value`:
                break;
              case `multiple`:
                m = l;
              default:
                r.hasOwnProperty(o) || $(e, t, o, null, r, l)
            }
          for (a in r)
            if (o = r[a], l = n[a], r.hasOwnProperty(a) && (o != null || l != null)) switch (a) {
              case `value`:
                p = o;
                break;
              case `defaultValue`:
                c = o;
                break;
              case `multiple`:
                s = o;
              default:
                o !== l && $(e, t, a, o, r, l)
            }
          t = c, n = s, r = m, p == null ? !!r != !!n && (t == null ? Jt(e, !!n, n ? [] : ``, !1) : Jt(e, !!n, t, !0)) : Jt(e, !!n, p, !1);
          return;
        case `textarea`:
          for (c in m = p = null, n)
            if (a = n[c], n.hasOwnProperty(c) && a != null && !r.hasOwnProperty(c)) switch (c) {
              case `value`:
                break;
              case `children`:
                break;
              default:
                $(e, t, c, null, r, a)
            }
          for (s in r)
            if (a = r[s], o = n[s], r.hasOwnProperty(s) && (a != null || o != null)) switch (s) {
              case `value`:
                p = a;
                break;
              case `defaultValue`:
                m = a;
                break;
              case `children`:
                break;
              case `dangerouslySetInnerHTML`:
                if (a != null) throw Error(i(91));
                break;
              default:
                a !== o && $(e, t, s, a, r, o)
            }
          Yt(e, p, m);
          return;
        case `option`:
          for (var h in n)
            if (p = n[h], n.hasOwnProperty(h) && p != null && !r.hasOwnProperty(h)) switch (h) {
              case `selected`:
                e.selected = !1;
                break;
              default:
                $(e, t, h, null, r, p)
            }
          for (l in r)
            if (p = r[l], m = n[l], r.hasOwnProperty(l) && p !== m && (p != null || m != null)) switch (l) {
              case `selected`:
                e.selected = p && typeof p != `function` && typeof p != `symbol`;
                break;
              default:
                $(e, t, l, p, r, m)
            }
          return;
        case `img`:
        case `link`:
        case `area`:
        case `base`:
        case `br`:
        case `col`:
        case `embed`:
        case `hr`:
        case `keygen`:
        case `meta`:
        case `param`:
        case `source`:
        case `track`:
        case `wbr`:
        case `menuitem`:
          for (var g in n) p = n[g], n.hasOwnProperty(g) && p != null && !r.hasOwnProperty(g) && $(e, t, g, null, r, p);
          for (u in r)
            if (p = r[u], m = n[u], r.hasOwnProperty(u) && p !== m && (p != null || m != null)) switch (u) {
              case `children`:
              case `dangerouslySetInnerHTML`:
                if (p != null) throw Error(i(137, t));
                break;
              default:
                $(e, t, u, p, r, m)
            }
          return;
        default:
          if (tn(t)) {
            for (var _ in n) p = n[_], n.hasOwnProperty(_) && p !== void 0 && !r.hasOwnProperty(_) && Nd(e, t, _, void 0, r, p);
            for (d in r) p = r[d], m = n[d], !r.hasOwnProperty(d) || p === m || p === void 0 && m === void 0 || Nd(e, t, d, p, r, m);
            return
          }
      }
      for (var v in n) p = n[v], n.hasOwnProperty(v) && p != null && !r.hasOwnProperty(v) && $(e, t, v, null, r, p);
      for (f in r) p = r[f], m = n[f], !r.hasOwnProperty(f) || p === m || p == null && m == null || $(e, t, f, p, r, m)
    }

    function Id(e) {
      switch (e) {
        case `css`:
        case `script`:
        case `font`:
        case `img`:
        case `image`:
        case `input`:
        case `link`:
          return !0;
        default:
          return !1
      }
    }

    function Ld() {
      if (typeof performance.getEntriesByType == `function`) {
        for (var e = 0, t = 0, n = performance.getEntriesByType(`resource`), r = 0; r < n.length; r++) {
          var i = n[r],
            a = i.transferSize,
            o = i.initiatorType,
            s = i.duration;
          if (a && s && Id(o)) {
            for (o = 0, s = i.responseEnd, r += 1; r < n.length; r++) {
              var c = n[r],
                l = c.startTime;
              if (l > s) break;
              var u = c.transferSize,
                d = c.initiatorType;
              u && Id(d) && (c = c.responseEnd, o += u * (c < s ? 1 : (s - l) / (c - l)))
            }
            if (--r, t += 8 * (a + o) / (i.duration / 1e3), e++, 10 < e) break
          }
        }
        if (0 < e) return t / e / 1e6
      }
      return navigator.connection && (e = navigator.connection.downlink, typeof e == `number`) ? e : 5
    }
    var Rd = null,
      zd = null;

    function Bd(e) {
      return e.nodeType === 9 ? e : e.ownerDocument
    }

    function Vd(e) {
      switch (e) {
        case `http://www.w3.org/2000/svg`:
          return 1;
        case `http://www.w3.org/1998/Math/MathML`:
          return 2;
        default:
          return 0
      }
    }

    function Hd(e, t) {
      if (e === 0) switch (t) {
        case `svg`:
          return 1;
        case `math`:
          return 2;
        default:
          return 0
      }
      return e === 1 && t === `foreignObject` ? 0 : e
    }

    function Ud(e, t) {
      return e === `textarea` || e === `noscript` || typeof t.children == `string` || typeof t.children == `number` || typeof t.children == `bigint` || typeof t.dangerouslySetInnerHTML == `object` && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
    }
    var Wd = null;

    function Gd() {
      var e = window.event;
      return e && e.type === `popstate` ? e === Wd ? !1 : (Wd = e, !0) : (Wd = null, !1)
    }
    var Kd = typeof setTimeout == `function` ? setTimeout : void 0,
      qd = typeof clearTimeout == `function` ? clearTimeout : void 0,
      Jd = typeof Promise == `function` ? Promise : void 0,
      Yd = typeof queueMicrotask == `function` ? queueMicrotask : Jd === void 0 ? Kd : function(e) {
        return Jd.resolve(null).then(e).catch(Xd)
      };

    function Xd(e) {
      setTimeout(function() {
        throw e
      })
    }

    function Zd(e) {
      return e === `head`
    }

    function Qd(e, t) {
      var n = t,
        r = 0;
      do {
        var i = n.nextSibling;
        if (e.removeChild(n), i && i.nodeType === 8)
          if (n = i.data, n === `/$` || n === `/&`) {
            if (r === 0) {
              e.removeChild(i), Np(t);
              return
            }
            r--
          } else if (n === `$` || n === `$?` || n === `$~` || n === `$!` || n === `&`) r++;
        else if (n === `html`) pf(e.ownerDocument.documentElement);
        else if (n === `head`) {
          n = e.ownerDocument.head, pf(n);
          for (var a = n.firstChild; a;) {
            var o = a.nextSibling,
              s = a.nodeName;
            a[yt] || s === `SCRIPT` || s === `STYLE` || s === `LINK` && a.rel.toLowerCase() === `stylesheet` || n.removeChild(a), a = o
          }
        } else n === `body` && pf(e.ownerDocument.body);
        n = i
      } while (n);
      Np(t)
    }

    function $d(e, t) {
      var n = e;
      e = 0;
      do {
        var r = n.nextSibling;
        if (n.nodeType === 1 ? t ? (n._stashedDisplay = n.style.display, n.style.display = `none`) : (n.style.display = n._stashedDisplay || ``, n.getAttribute(`style`) === `` && n.removeAttribute(`style`)) : n.nodeType === 3 && (t ? (n._stashedText = n.nodeValue, n.nodeValue = ``) : n.nodeValue = n._stashedText || ``), r && r.nodeType === 8)
          if (n = r.data, n === `/$`) {
            if (e === 0) break;
            e--
          } else n !== `$` && n !== `$?` && n !== `$~` && n !== `$!` || e++;
        n = r
      } while (n)
    }

    function ef(e) {
      var t = e.firstChild;
      for (t && t.nodeType === 10 && (t = t.nextSibling); t;) {
        var n = t;
        switch (t = t.nextSibling, n.nodeName) {
          case `HTML`:
          case `HEAD`:
          case `BODY`:
            ef(n), bt(n);
            continue;
          case `SCRIPT`:
          case `STYLE`:
            continue;
          case `LINK`:
            if (n.rel.toLowerCase() === `stylesheet`) continue
        }
        e.removeChild(n)
      }
    }

    function tf(e, t, n, r) {
      for (; e.nodeType === 1;) {
        var i = n;
        if (e.nodeName.toLowerCase() !== t.toLowerCase()) {
          if (!r && (e.nodeName !== `INPUT` || e.type !== `hidden`)) break
        } else if (!r)
          if (t === `input` && e.type === `hidden`) {
            var a = i.name == null ? null : `` + i.name;
            if (i.type === `hidden` && e.getAttribute(`name`) === a) return e
          } else return e;
        else if (!e[yt]) switch (t) {
          case `meta`:
            if (!e.hasAttribute(`itemprop`)) break;
            return e;
          case `link`:
            if (a = e.getAttribute(`rel`), a === `stylesheet` && e.hasAttribute(`data-precedence`) || a !== i.rel || e.getAttribute(`href`) !== (i.href == null || i.href === `` ? null : i.href) || e.getAttribute(`crossorigin`) !== (i.crossOrigin == null ? null : i.crossOrigin) || e.getAttribute(`title`) !== (i.title == null ? null : i.title)) break;
            return e;
          case `style`:
            if (e.hasAttribute(`data-precedence`)) break;
            return e;
          case `script`:
            if (a = e.getAttribute(`src`), (a !== (i.src == null ? null : i.src) || e.getAttribute(`type`) !== (i.type == null ? null : i.type) || e.getAttribute(`crossorigin`) !== (i.crossOrigin == null ? null : i.crossOrigin)) && a && e.hasAttribute(`async`) && !e.hasAttribute(`itemprop`)) break;
            return e;
          default:
            return e
        }
        if (e = cf(e.nextSibling), e === null) break
      }
      return null
    }

    function nf(e, t, n) {
      if (t === ``) return null;
      for (; e.nodeType !== 3;)
        if ((e.nodeType !== 1 || e.nodeName !== `INPUT` || e.type !== `hidden`) && !n || (e = cf(e.nextSibling), e === null)) return null;
      return e
    }

    function rf(e, t) {
      for (; e.nodeType !== 8;)
        if ((e.nodeType !== 1 || e.nodeName !== `INPUT` || e.type !== `hidden`) && !t || (e = cf(e.nextSibling), e === null)) return null;
      return e
    }

    function af(e) {
      return e.data === `$?` || e.data === `$~`
    }

    function of(e) {
      return e.data === `$!` || e.data === `$?` && e.ownerDocument.readyState !== `loading`
    }

    function sf(e, t) {
      var n = e.ownerDocument;
      if (e.data === `$~`) e._reactRetry = t;
      else if (e.data !== `$?` || n.readyState !== `loading`) t();
      else {
        var r = function() {
          t(), n.removeEventListener(`DOMContentLoaded`, r)
        };
        n.addEventListener(`DOMContentLoaded`, r), e._reactRetry = r
      }
    }

    function cf(e) {
      for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === 1 || t === 3) break;
        if (t === 8) {
          if (t = e.data, t === `$` || t === `$!` || t === `$?` || t === `$~` || t === `&` || t === `F!` || t === `F`) break;
          if (t === `/$` || t === `/&`) return null
        }
      }
      return e
    }
    var lf = null;

    function uf(e) {
      e = e.nextSibling;
      for (var t = 0; e;) {
        if (e.nodeType === 8) {
          var n = e.data;
          if (n === `/$` || n === `/&`) {
            if (t === 0) return cf(e.nextSibling);
            t--
          } else n !== `$` && n !== `$!` && n !== `$?` && n !== `$~` && n !== `&` || t++
        }
        e = e.nextSibling
      }
      return null
    }

    function df(e) {
      e = e.previousSibling;
      for (var t = 0; e;) {
        if (e.nodeType === 8) {
          var n = e.data;
          if (n === `$` || n === `$!` || n === `$?` || n === `$~` || n === `&`) {
            if (t === 0) return e;
            t--
          } else n !== `/$` && n !== `/&` || t++
        }
        e = e.previousSibling
      }
      return null
    }

    function ff(e, t, n) {
      switch (t = Bd(n), e) {
        case `html`:
          if (e = t.documentElement, !e) throw Error(i(452));
          return e;
        case `head`:
          if (e = t.head, !e) throw Error(i(453));
          return e;
        case `body`:
          if (e = t.body, !e) throw Error(i(454));
          return e;
        default:
          throw Error(i(451))
      }
    }

    function pf(e) {
      for (var t = e.attributes; t.length;) e.removeAttributeNode(t[0]);
      bt(e)
    }
    var mf = new Map,
      hf = new Set;

    function gf(e) {
      return typeof e.getRootNode == `function` ? e.getRootNode() : e.nodeType === 9 ? e : e.ownerDocument
    }
    var _f = j.d;
    j.d = {
      f: vf,
      r: yf,
      D: Sf,
      C: Cf,
      L: wf,
      m: Tf,
      X: Df,
      S: Ef,
      M: Of
    };

    function vf() {
      var e = _f.f(),
        t = bu();
      return e || t
    }

    function yf(e) {
      var t = St(e);
      t !== null && t.tag === 5 && t.type === `form` ? Cs(t) : _f.r(e)
    }
    var bf = typeof document > `u` ? null : document;

    function xf(e, t, n) {
      var r = bf;
      if (r && typeof t == `string` && t) {
        var i = Wt(t);
        i = `link[rel="` + e + `"][href="` + i + `"]`, typeof n == `string` && (i += `[crossorigin="` + n + `"]`), hf.has(i) || (hf.add(i), e = {
          rel: e,
          crossOrigin: n,
          href: t
        }, r.querySelector(i) === null && (t = r.createElement(`link`), Pd(t, `link`, e), Tt(t), r.head.appendChild(t)))
      }
    }

    function Sf(e) {
      _f.D(e), xf(`dns-prefetch`, e, null)
    }

    function Cf(e, t) {
      _f.C(e, t), xf(`preconnect`, e, t)
    }

    function wf(e, t, n) {
      _f.L(e, t, n);
      var r = bf;
      if (r && e && t) {
        var i = `link[rel="preload"][as="` + Wt(t) + `"]`;
        t === `image` && n && n.imageSrcSet ? (i += `[imagesrcset="` + Wt(n.imageSrcSet) + `"]`, typeof n.imageSizes == `string` && (i += `[imagesizes="` + Wt(n.imageSizes) + `"]`)) : i += `[href="` + Wt(e) + `"]`;
        var a = i;
        switch (t) {
          case `style`:
            a = Af(e);
            break;
          case `script`:
            a = Pf(e)
        }
        mf.has(a) || (e = h({
          rel: `preload`,
          href: t === `image` && n && n.imageSrcSet ? void 0 : e,
          as: t
        }, n), mf.set(a, e), r.querySelector(i) !== null || t === `style` && r.querySelector(jf(a)) || t === `script` && r.querySelector(Ff(a)) || (t = r.createElement(`link`), Pd(t, `link`, e), Tt(t), r.head.appendChild(t)))
      }
    }

    function Tf(e, t) {
      _f.m(e, t);
      var n = bf;
      if (n && e) {
        var r = t && typeof t.as == `string` ? t.as : `script`,
          i = `link[rel="modulepreload"][as="` + Wt(r) + `"][href="` + Wt(e) + `"]`,
          a = i;
        switch (r) {
          case `audioworklet`:
          case `paintworklet`:
          case `serviceworker`:
          case `sharedworker`:
          case `worker`:
          case `script`:
            a = Pf(e)
        }
        if (!mf.has(a) && (e = h({
            rel: `modulepreload`,
            href: e
          }, t), mf.set(a, e), n.querySelector(i) === null)) {
          switch (r) {
            case `audioworklet`:
            case `paintworklet`:
            case `serviceworker`:
            case `sharedworker`:
            case `worker`:
            case `script`:
              if (n.querySelector(Ff(a))) return
          }
          r = n.createElement(`link`), Pd(r, `link`, e), Tt(r), n.head.appendChild(r)
        }
      }
    }

    function Ef(e, t, n) {
      _f.S(e, t, n);
      var r = bf;
      if (r && e) {
        var i = wt(r).hoistableStyles,
          a = Af(e);
        t ||= `default`;
        var o = i.get(a);
        if (!o) {
          var s = {
            loading: 0,
            preload: null
          };
          if (o = r.querySelector(jf(a))) s.loading = 5;
          else {
            e = h({
              rel: `stylesheet`,
              href: e,
              "data-precedence": t
            }, n), (n = mf.get(a)) && Rf(e, n);
            var c = o = r.createElement(`link`);
            Tt(c), Pd(c, `link`, e), c._p = new Promise(function(e, t) {
              c.onload = e, c.onerror = t
            }), c.addEventListener(`load`, function() {
              s.loading |= 1
            }), c.addEventListener(`error`, function() {
              s.loading |= 2
            }), s.loading |= 4, Lf(o, t, r)
          }
          o = {
            type: `stylesheet`,
            instance: o,
            count: 1,
            state: s
          }, i.set(a, o)
        }
      }
    }

    function Df(e, t) {
      _f.X(e, t);
      var n = bf;
      if (n && e) {
        var r = wt(n).hoistableScripts,
          i = Pf(e),
          a = r.get(i);
        a || (a = n.querySelector(Ff(i)), a || (e = h({
          src: e,
          async: !0
        }, t), (t = mf.get(i)) && zf(e, t), a = n.createElement(`script`), Tt(a), Pd(a, `link`, e), n.head.appendChild(a)), a = {
          type: `script`,
          instance: a,
          count: 1,
          state: null
        }, r.set(i, a))
      }
    }

    function Of(e, t) {
      _f.M(e, t);
      var n = bf;
      if (n && e) {
        var r = wt(n).hoistableScripts,
          i = Pf(e),
          a = r.get(i);
        a || (a = n.querySelector(Ff(i)), a || (e = h({
          src: e,
          async: !0,
          type: `module`
        }, t), (t = mf.get(i)) && zf(e, t), a = n.createElement(`script`), Tt(a), Pd(a, `link`, e), n.head.appendChild(a)), a = {
          type: `script`,
          instance: a,
          count: 1,
          state: null
        }, r.set(i, a))
      }
    }

    function kf(e, t, n, r) {
      var a = (a = pe.current) ? gf(a) : null;
      if (!a) throw Error(i(446));
      switch (e) {
        case `meta`:
        case `title`:
          return null;
        case `style`:
          return typeof n.precedence == `string` && typeof n.href == `string` ? (t = Af(n.href), n = wt(a).hoistableStyles, r = n.get(t), r || (r = {
            type: `style`,
            instance: null,
            count: 0,
            state: null
          }, n.set(t, r)), r) : {
            type: `void`,
            instance: null,
            count: 0,
            state: null
          };
        case `link`:
          if (n.rel === `stylesheet` && typeof n.href == `string` && typeof n.precedence == `string`) {
            e = Af(n.href);
            var o = wt(a).hoistableStyles,
              s = o.get(e);
            if (s || (a = a.ownerDocument || a, s = {
                type: `stylesheet`,
                instance: null,
                count: 0,
                state: {
                  loading: 0,
                  preload: null
                }
              }, o.set(e, s), (o = a.querySelector(jf(e))) && !o._p && (s.instance = o, s.state.loading = 5), mf.has(e) || (n = {
                rel: `preload`,
                as: `style`,
                href: n.href,
                crossOrigin: n.crossOrigin,
                integrity: n.integrity,
                media: n.media,
                hrefLang: n.hrefLang,
                referrerPolicy: n.referrerPolicy
              }, mf.set(e, n), o || Nf(a, e, n, s.state))), t && r === null) throw Error(i(528, ``));
            return s
          }
          if (t && r !== null) throw Error(i(529, ``));
          return null;
        case `script`:
          return t = n.async, n = n.src, typeof n == `string` && t && typeof t != `function` && typeof t != `symbol` ? (t = Pf(n), n = wt(a).hoistableScripts, r = n.get(t), r || (r = {
            type: `script`,
            instance: null,
            count: 0,
            state: null
          }, n.set(t, r)), r) : {
            type: `void`,
            instance: null,
            count: 0,
            state: null
          };
        default:
          throw Error(i(444, e))
      }
    }

    function Af(e) {
      return `href="` + Wt(e) + `"`
    }

    function jf(e) {
      return `link[rel="stylesheet"][` + e + `]`
    }

    function Mf(e) {
      return h({}, e, {
        "data-precedence": e.precedence,
        precedence: null
      })
    }

    function Nf(e, t, n, r) {
      e.querySelector(`link[rel="preload"][as="style"][` + t + `]`) ? r.loading = 1 : (t = e.createElement(`link`), r.preload = t, t.addEventListener(`load`, function() {
        return r.loading |= 1
      }), t.addEventListener(`error`, function() {
        return r.loading |= 2
      }), Pd(t, `link`, n), Tt(t), e.head.appendChild(t))
    }

    function Pf(e) {
      return `[src="` + Wt(e) + `"]`
    }

    function Ff(e) {
      return `script[async]` + e
    }

    function If(e, t, n) {
      if (t.count++, t.instance === null) switch (t.type) {
        case `style`:
          var r = e.querySelector(`style[data-href~="` + Wt(n.href) + `"]`);
          if (r) return t.instance = r, Tt(r), r;
          var a = h({}, n, {
            "data-href": n.href,
            "data-precedence": n.precedence,
            href: null,
            precedence: null
          });
          return r = (e.ownerDocument || e).createElement(`style`), Tt(r), Pd(r, `style`, a), Lf(r, n.precedence, e), t.instance = r;
        case `stylesheet`:
          a = Af(n.href);
          var o = e.querySelector(jf(a));
          if (o) return t.state.loading |= 4, t.instance = o, Tt(o), o;
          r = Mf(n), (a = mf.get(a)) && Rf(r, a), o = (e.ownerDocument || e).createElement(`link`), Tt(o);
          var s = o;
          return s._p = new Promise(function(e, t) {
            s.onload = e, s.onerror = t
          }), Pd(o, `link`, r), t.state.loading |= 4, Lf(o, n.precedence, e), t.instance = o;
        case `script`:
          return o = Pf(n.src), (a = e.querySelector(Ff(o))) ? (t.instance = a, Tt(a), a) : (r = n, (a = mf.get(o)) && (r = h({}, n), zf(r, a)), e = e.ownerDocument || e, a = e.createElement(`script`), Tt(a), Pd(a, `link`, r), e.head.appendChild(a), t.instance = a);
        case `void`:
          return null;
        default:
          throw Error(i(443, t.type))
      } else t.type === `stylesheet` && !(t.state.loading & 4) && (r = t.instance, t.state.loading |= 4, Lf(r, n.precedence, e));
      return t.instance
    }

    function Lf(e, t, n) {
      for (var r = n.querySelectorAll(`link[rel="stylesheet"][data-precedence],style[data-precedence]`), i = r.length ? r[r.length - 1] : null, a = i, o = 0; o < r.length; o++) {
        var s = r[o];
        if (s.dataset.precedence === t) a = s;
        else if (a !== i) break
      }
      a ? a.parentNode.insertBefore(e, a.nextSibling) : (t = n.nodeType === 9 ? n.head : n, t.insertBefore(e, t.firstChild))
    }

    function Rf(e, t) {
      e.crossOrigin ??= t.crossOrigin, e.referrerPolicy ??= t.referrerPolicy, e.title ??= t.title
    }

    function zf(e, t) {
      e.crossOrigin ??= t.crossOrigin, e.referrerPolicy ??= t.referrerPolicy, e.integrity ??= t.integrity
    }
    var Bf = null;

    function Vf(e, t, n) {
      if (Bf === null) {
        var r = new Map,
          i = Bf = new Map;
        i.set(n, r)
      } else i = Bf, r = i.get(n), r || (r = new Map, i.set(n, r));
      if (r.has(e)) return r;
      for (r.set(e, null), n = n.getElementsByTagName(e), i = 0; i < n.length; i++) {
        var a = n[i];
        if (!(a[yt] || a[ft] || e === `link` && a.getAttribute(`rel`) === `stylesheet`) && a.namespaceURI !== `http://www.w3.org/2000/svg`) {
          var o = a.getAttribute(t) || ``;
          o = e + o;
          var s = r.get(o);
          s ? s.push(a) : r.set(o, [a])
        }
      }
      return r
    }

    function Hf(e, t, n) {
      e = e.ownerDocument || e, e.head.insertBefore(n, t === `title` ? e.querySelector(`head > title`) : null)
    }

    function Uf(e, t, n) {
      if (n === 1 || t.itemProp != null) return !1;
      switch (e) {
        case `meta`:
        case `title`:
          return !0;
        case `style`:
          if (typeof t.precedence != `string` || typeof t.href != `string` || t.href === ``) break;
          return !0;
        case `link`:
          if (typeof t.rel != `string` || typeof t.href != `string` || t.href === `` || t.onLoad || t.onError) break;
          switch (t.rel) {
            case `stylesheet`:
              return e = t.disabled, typeof t.precedence == `string` && e == null;
            default:
              return !0
          }
        case `script`:
          if (t.async && typeof t.async != `function` && typeof t.async != `symbol` && !t.onLoad && !t.onError && t.src && typeof t.src == `string`) return !0
      }
      return !1
    }

    function Wf(e) {
      return !(e.type === `stylesheet` && !(e.state.loading & 3))
    }

    function Gf(e, t, n, r) {
      if (n.type === `stylesheet` && (typeof r.media != `string` || !1 !== matchMedia(r.media).matches) && !(n.state.loading & 4)) {
        if (n.instance === null) {
          var i = Af(r.href),
            a = t.querySelector(jf(i));
          if (a) {
            t = a._p, typeof t == `object` && t && typeof t.then == `function` && (e.count++, e = Jf.bind(e), t.then(e, e)), n.state.loading |= 4, n.instance = a, Tt(a);
            return
          }
          a = t.ownerDocument || t, r = Mf(r), (i = mf.get(i)) && Rf(r, i), a = a.createElement(`link`), Tt(a);
          var o = a;
          o._p = new Promise(function(e, t) {
            o.onload = e, o.onerror = t
          }), Pd(a, `link`, r), n.instance = a
        }
        e.stylesheets === null && (e.stylesheets = new Map), e.stylesheets.set(n, t), (t = n.state.preload) && !(n.state.loading & 3) && (e.count++, n = Jf.bind(e), t.addEventListener(`load`, n), t.addEventListener(`error`, n))
      }
    }
    var Kf = 0;

    function qf(e, t) {
      return e.stylesheets && e.count === 0 && Xf(e, e.stylesheets), 0 < e.count || 0 < e.imgCount ? function(n) {
        var r = setTimeout(function() {
          if (e.stylesheets && Xf(e, e.stylesheets), e.unsuspend) {
            var t = e.unsuspend;
            e.unsuspend = null, t()
          }
        }, 6e4 + t);
        0 < e.imgBytes && Kf === 0 && (Kf = 62500 * Ld());
        var i = setTimeout(function() {
          if (e.waitingForImages = !1, e.count === 0 && (e.stylesheets && Xf(e, e.stylesheets), e.unsuspend)) {
            var t = e.unsuspend;
            e.unsuspend = null, t()
          }
        }, (e.imgBytes > Kf ? 50 : 800) + t);
        return e.unsuspend = n,
          function() {
            e.unsuspend = null, clearTimeout(r), clearTimeout(i)
          }
      } : null
    }

    function Jf() {
      if (this.count--, this.count === 0 && (this.imgCount === 0 || !this.waitingForImages)) {
        if (this.stylesheets) Xf(this, this.stylesheets);
        else if (this.unsuspend) {
          var e = this.unsuspend;
          this.unsuspend = null, e()
        }
      }
    }
    var Yf = null;

    function Xf(e, t) {
      e.stylesheets = null, e.unsuspend !== null && (e.count++, Yf = new Map, t.forEach(Zf, e), Yf = null, Jf.call(e))
    }

    function Zf(e, t) {
      if (!(t.state.loading & 4)) {
        var n = Yf.get(e);
        if (n) var r = n.get(null);
        else {
          n = new Map, Yf.set(e, n);
          for (var i = e.querySelectorAll(`link[data-precedence],style[data-precedence]`), a = 0; a < i.length; a++) {
            var o = i[a];
            (o.nodeName === `LINK` || o.getAttribute(`media`) !== `not all`) && (n.set(o.dataset.precedence, o), r = o)
          }
          r && n.set(null, r)
        }
        i = t.instance, o = i.getAttribute(`data-precedence`), a = n.get(o) || r, a === r && n.set(null, i), n.set(o, i), this.count++, r = Jf.bind(this), i.addEventListener(`load`, r), i.addEventListener(`error`, r), a ? a.parentNode.insertBefore(i, a.nextSibling) : (e = e.nodeType === 9 ? e.head : e, e.insertBefore(i, e.firstChild)), t.state.loading |= 4
      }
    }
    var Qf = {
      $$typeof: C,
      Provider: null,
      Consumer: null,
      _currentValue: oe,
      _currentValue2: oe,
      _threadCount: 0
    };

    function $f(e, t, n, r, i, a, o, s, c) {
      this.tag = 1, this.containerInfo = e, this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.next = this.pendingContext = this.context = this.cancelPendingCommit = null, this.callbackPriority = 0, this.expirationTimes = tt(-1), this.entangledLanes = this.shellSuspendCounter = this.errorRecoveryDisabledLanes = this.expiredLanes = this.warmLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = tt(0), this.hiddenUpdates = tt(null), this.identifierPrefix = r, this.onUncaughtError = i, this.onCaughtError = a, this.onRecoverableError = o, this.pooledCache = null, this.pooledCacheLanes = 0, this.formState = c, this.incompleteTransitions = new Map
    }

    function ep(e, t, n, r, i, a, o, s, c, l, u, d) {
      return e = new $f(e, t, n, o, c, l, u, d, s), t = 1, !0 === a && (t |= 24), a = ui(3, null, null, t), e.current = a, a.stateNode = e, t = sa(), t.refCount++, e.pooledCache = t, t.refCount++, a.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: t
      }, Ba(a), e
    }

    function tp(e) {
      return e ? (e = ci, e) : ci
    }

    function np(e, t, n, r, i, a) {
      i = tp(i), r.context === null ? r.context = i : r.pendingContext = i, r = Ha(t), r.payload = {
        element: n
      }, a = a === void 0 ? null : a, a !== null && (r.callback = a), n = Ua(e, r, t), n !== null && (hu(n, e, t), Wa(n, e, t))
    }

    function rp(e, t) {
      if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
        var n = e.retryLane;
        e.retryLane = n !== 0 && n < t ? n : t
      }
    }

    function ip(e, t) {
      rp(e, t), (e = e.alternate) && rp(e, t)
    }

    function ap(e) {
      if (e.tag === 13 || e.tag === 31) {
        var t = ai(e, 67108864);
        t !== null && hu(t, e, 67108864), ip(e, 67108864)
      }
    }

    function op(e) {
      if (e.tag === 13 || e.tag === 31) {
        var t = pu();
        t = st(t);
        var n = ai(e, t);
        n !== null && hu(n, e, t), ip(e, t)
      }
    }
    var sp = !0;

    function cp(e, t, n, r) {
      var i = A.T;
      A.T = null;
      var a = j.p;
      try {
        j.p = 2, up(e, t, n, r)
      } finally {
        j.p = a, A.T = i
      }
    }

    function lp(e, t, n, r) {
      var i = A.T;
      A.T = null;
      var a = j.p;
      try {
        j.p = 8, up(e, t, n, r)
      } finally {
        j.p = a, A.T = i
      }
    }

    function up(e, t, n, r) {
      if (sp) {
        var i = dp(r);
        if (i === null) wd(e, t, r, fp, n), Cp(e, r);
        else if (Tp(i, e, t, n, r)) r.stopPropagation();
        else if (Cp(e, r), t & 4 && -1 < Sp.indexOf(e)) {
          for (; i !== null;) {
            var a = St(i);
            if (a !== null) switch (a.tag) {
              case 3:
                if (a = a.stateNode, a.current.memoizedState.isDehydrated) {
                  var o = Xe(a.pendingLanes);
                  if (o !== 0) {
                    var s = a;
                    for (s.pendingLanes |= 2, s.entangledLanes |= 2; o;) {
                      var c = 1 << 31 - Ue(o);
                      s.entanglements[1] |= c, o &= ~c
                    }
                    rd(a), !(q & 6) && (tu = je() + 500, id(0, !1))
                  }
                }
                break;
              case 31:
              case 13:
                s = ai(a, 2), s !== null && hu(s, a, 2), bu(), ip(a, 2)
            }
            if (a = dp(r), a === null && wd(e, t, r, fp, n), a === i) break;
            i = a
          }
          i !== null && r.stopPropagation()
        } else wd(e, t, r, null, n)
      }
    }

    function dp(e) {
      return e = cn(e), pp(e)
    }
    var fp = null;

    function pp(e) {
      if (fp = null, e = xt(e), e !== null) {
        var t = o(e);
        if (t === null) e = null;
        else {
          var n = t.tag;
          if (n === 13) {
            if (e = s(t), e !== null) return e;
            e = null
          } else if (n === 31) {
            if (e = c(t), e !== null) return e;
            e = null
          } else if (n === 3) {
            if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
            e = null
          } else t !== e && (e = null)
        }
      }
      return fp = e, null
    }

    function mp(e) {
      switch (e) {
        case `beforetoggle`:
        case `cancel`:
        case `click`:
        case `close`:
        case `contextmenu`:
        case `copy`:
        case `cut`:
        case `auxclick`:
        case `dblclick`:
        case `dragend`:
        case `dragstart`:
        case `drop`:
        case `focusin`:
        case `focusout`:
        case `input`:
        case `invalid`:
        case `keydown`:
        case `keypress`:
        case `keyup`:
        case `mousedown`:
        case `mouseup`:
        case `paste`:
        case `pause`:
        case `play`:
        case `pointercancel`:
        case `pointerdown`:
        case `pointerup`:
        case `ratechange`:
        case `reset`:
        case `resize`:
        case `seeked`:
        case `submit`:
        case `toggle`:
        case `touchcancel`:
        case `touchend`:
        case `touchstart`:
        case `volumechange`:
        case `change`:
        case `selectionchange`:
        case `textInput`:
        case `compositionstart`:
        case `compositionend`:
        case `compositionupdate`:
        case `beforeblur`:
        case `afterblur`:
        case `beforeinput`:
        case `blur`:
        case `fullscreenchange`:
        case `focus`:
        case `hashchange`:
        case `popstate`:
        case `select`:
        case `selectstart`:
          return 2;
        case `drag`:
        case `dragenter`:
        case `dragexit`:
        case `dragleave`:
        case `dragover`:
        case `mousemove`:
        case `mouseout`:
        case `mouseover`:
        case `pointermove`:
        case `pointerout`:
        case `pointerover`:
        case `scroll`:
        case `touchmove`:
        case `wheel`:
        case `mouseenter`:
        case `mouseleave`:
        case `pointerenter`:
        case `pointerleave`:
          return 8;
        case `message`:
          switch (Me()) {
            case Ne:
              return 2;
            case Pe:
              return 8;
            case Fe:
            case Ie:
              return 32;
            case Le:
              return 268435456;
            default:
              return 32
          }
        default:
          return 32
      }
    }
    var hp = !1,
      gp = null,
      _p = null,
      vp = null,
      yp = new Map,
      bp = new Map,
      xp = [],
      Sp = `mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset`.split(` `);

    function Cp(e, t) {
      switch (e) {
        case `focusin`:
        case `focusout`:
          gp = null;
          break;
        case `dragenter`:
        case `dragleave`:
          _p = null;
          break;
        case `mouseover`:
        case `mouseout`:
          vp = null;
          break;
        case `pointerover`:
        case `pointerout`:
          yp.delete(t.pointerId);
          break;
        case `gotpointercapture`:
        case `lostpointercapture`:
          bp.delete(t.pointerId)
      }
    }

    function wp(e, t, n, r, i, a) {
      return e === null || e.nativeEvent !== a ? (e = {
        blockedOn: t,
        domEventName: n,
        eventSystemFlags: r,
        nativeEvent: a,
        targetContainers: [i]
      }, t !== null && (t = St(t), t !== null && ap(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, i !== null && t.indexOf(i) === -1 && t.push(i), e)
    }

    function Tp(e, t, n, r, i) {
      switch (t) {
        case `focusin`:
          return gp = wp(gp, e, t, n, r, i), !0;
        case `dragenter`:
          return _p = wp(_p, e, t, n, r, i), !0;
        case `mouseover`:
          return vp = wp(vp, e, t, n, r, i), !0;
        case `pointerover`:
          var a = i.pointerId;
          return yp.set(a, wp(yp.get(a) || null, e, t, n, r, i)), !0;
        case `gotpointercapture`:
          return a = i.pointerId, bp.set(a, wp(bp.get(a) || null, e, t, n, r, i)), !0
      }
      return !1
    }

    function Ep(e) {
      var t = xt(e.target);
      if (t !== null) {
        var n = o(t);
        if (n !== null) {
          if (t = n.tag, t === 13) {
            if (t = s(n), t !== null) {
              e.blockedOn = t, ut(e.priority, function() {
                op(n)
              });
              return
            }
          } else if (t === 31) {
            if (t = c(n), t !== null) {
              e.blockedOn = t, ut(e.priority, function() {
                op(n)
              });
              return
            }
          } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
            e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
            return
          }
        }
      }
      e.blockedOn = null
    }

    function Dp(e) {
      if (e.blockedOn !== null) return !1;
      for (var t = e.targetContainers; 0 < t.length;) {
        var n = dp(e.nativeEvent);
        if (n === null) {
          n = e.nativeEvent;
          var r = new n.constructor(n.type, n);
          sn = r, n.target.dispatchEvent(r), sn = null
        } else return t = St(n), t !== null && ap(t), e.blockedOn = n, !1;
        t.shift()
      }
      return !0
    }

    function Op(e, t, n) {
      Dp(e) && n.delete(t)
    }

    function kp() {
      hp = !1, gp !== null && Dp(gp) && (gp = null), _p !== null && Dp(_p) && (_p = null), vp !== null && Dp(vp) && (vp = null), yp.forEach(Op), bp.forEach(Op)
    }

    function Ap(e, n) {
      e.blockedOn === n && (e.blockedOn = null, hp || (hp = !0, t.unstable_scheduleCallback(t.unstable_NormalPriority, kp)))
    }
    var jp = null;

    function Mp(e) {
      jp !== e && (jp = e, t.unstable_scheduleCallback(t.unstable_NormalPriority, function() {
        jp === e && (jp = null);
        for (var t = 0; t < e.length; t += 3) {
          var n = e[t],
            r = e[t + 1],
            i = e[t + 2];
          if (typeof r != `function`) {
            if (pp(r || n) === null) continue;
            break
          }
          var a = St(n);
          a !== null && (e.splice(t, 3), t -= 3, xs(a, {
            pending: !0,
            data: i,
            method: n.method,
            action: r
          }, r, i))
        }
      }))
    }

    function Np(e) {
      function t(t) {
        return Ap(t, e)
      }
      gp !== null && Ap(gp, e), _p !== null && Ap(_p, e), vp !== null && Ap(vp, e), yp.forEach(t), bp.forEach(t);
      for (var n = 0; n < xp.length; n++) {
        var r = xp[n];
        r.blockedOn === e && (r.blockedOn = null)
      }
      for (; 0 < xp.length && (n = xp[0], n.blockedOn === null);) Ep(n), n.blockedOn === null && xp.shift();
      if (n = (e.ownerDocument || e).$$reactFormReplay, n != null)
        for (r = 0; r < n.length; r += 3) {
          var i = n[r],
            a = n[r + 1],
            o = i[pt] || null;
          if (typeof a == `function`) o || Mp(n);
          else if (o) {
            var s = null;
            if (a && a.hasAttribute(`formAction`)) {
              if (i = a, o = a[pt] || null) s = o.formAction;
              else if (pp(i) !== null) continue
            } else s = o.action;
            typeof s == `function` ? n[r + 1] = s : (n.splice(r, 3), r -= 3), Mp(n)
          }
        }
    }

    function Pp() {
      function e(e) {
        e.canIntercept && e.info === `react-transition` && e.intercept({
          handler: function() {
            return new Promise(function(e) {
              return i = e
            })
          },
          focusReset: `manual`,
          scroll: `manual`
        })
      }

      function t() {
        i !== null && (i(), i = null), r || setTimeout(n, 20)
      }

      function n() {
        if (!r && !navigation.transition) {
          var e = navigation.currentEntry;
          e && e.url != null && navigation.navigate(e.url, {
            state: e.getState(),
            info: `react-transition`,
            history: `replace`
          })
        }
      }
      if (typeof navigation == `object`) {
        var r = !1,
          i = null;
        return navigation.addEventListener(`navigate`, e), navigation.addEventListener(`navigatesuccess`, t), navigation.addEventListener(`navigateerror`, t), setTimeout(n, 100),
          function() {
            r = !0, navigation.removeEventListener(`navigate`, e), navigation.removeEventListener(`navigatesuccess`, t), navigation.removeEventListener(`navigateerror`, t), i !== null && (i(), i = null)
          }
      }
    }

    function Fp(e) {
      this._internalRoot = e
    }
    Ip.prototype.render = Fp.prototype.render = function(e) {
      var t = this._internalRoot;
      if (t === null) throw Error(i(409));
      var n = t.current;
      np(n, pu(), e, t, null, null)
    }, Ip.prototype.unmount = Fp.prototype.unmount = function() {
      var e = this._internalRoot;
      if (e !== null) {
        this._internalRoot = null;
        var t = e.containerInfo;
        np(e.current, 2, null, e, null, null), bu(), t[mt] = null
      }
    };

    function Ip(e) {
      this._internalRoot = e
    }
    Ip.prototype.unstable_scheduleHydration = function(e) {
      if (e) {
        var t = lt();
        e = {
          blockedOn: null,
          target: e,
          priority: t
        };
        for (var n = 0; n < xp.length && t !== 0 && t < xp[n].priority; n++);
        xp.splice(n, 0, e), n === 0 && Ep(e)
      }
    };
    var Lp = n.version;
    if (Lp !== `19.2.7`) throw Error(i(527, Lp, `19.2.7`));
    j.findDOMNode = function(e) {
      var t = e._reactInternals;
      if (t === void 0) throw typeof e.render == `function` ? Error(i(188)) : (e = Object.keys(e).join(`,`), Error(i(268, e)));
      return e = d(t), e = e === null ? null : p(e), e = e === null ? null : e.stateNode, e
    };
    var Rp = {
      bundleType: 0,
      version: `19.2.7`,
      rendererPackageName: `react-dom`,
      currentDispatcherRef: A,
      reconcilerVersion: `19.2.7`
    };
    if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < `u`) {
      var zp = __REACT_DEVTOOLS_GLOBAL_HOOK__;
      if (!zp.isDisabled && zp.supportsFiber) try {
        Be = zp.inject(Rp), Ve = zp
      } catch {}
    }
    e.createRoot = function(e, t) {
      if (!a(e)) throw Error(i(299));
      var n = !1,
        r = ``,
        o = Ws,
        s = Gs,
        c = Ks;
      return t != null && (!0 === t.unstable_strictMode && (n = !0), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onUncaughtError !== void 0 && (o = t.onUncaughtError), t.onCaughtError !== void 0 && (s = t.onCaughtError), t.onRecoverableError !== void 0 && (c = t.onRecoverableError)), t = ep(e, 1, !1, null, null, n, r, null, o, s, c, Pp), e[mt] = t.current, Sd(e), new Fp(t)
    }
  })),
  g = o(((e, t) => {
    function n() {
      if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > `u` || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != `function`)) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(n)
      } catch (e) {
        console.error(e)
      }
    }
    n(), t.exports = h()
  })),
  _ = c(u(), 1),
  v = g(),
  y = `modulepreload`,
  b = function(e, t) {
    return new URL(e, t).href
  },
  x = {},
  S = function(e, t, n) {
    let r = Promise.resolve();
    if (t && t.length > 0) {
      let e = document.getElementsByTagName(`link`),
        i = document.querySelector(`meta[property=csp-nonce]`),
        a = i?.nonce || i?.getAttribute(`nonce`);

      function o(e) {
        return Promise.all(e.map(e => Promise.resolve(e).then(e => ({
          status: `fulfilled`,
          value: e
        }), e => ({
          status: `rejected`,
          reason: e
        }))))
      }
      r = o(t.map(t => {
        if (t = b(t, n), t in x) return;
        x[t] = !0;
        let r = t.endsWith(`.css`),
          i = r ? `[rel="stylesheet"]` : ``;
        if (n)
          for (let n = e.length - 1; n >= 0; n--) {
            let i = e[n];
            if (i.href === t && (!r || i.rel === `stylesheet`)) return
          } else if (document.querySelector(`link[href="${t}"]${i}`)) return;
        let o = document.createElement(`link`);
        if (o.rel = r ? `stylesheet` : y, r || (o.as = `script`), o.crossOrigin = ``, o.href = t, a && o.setAttribute(`nonce`, a), document.head.appendChild(o), r) return new Promise((e, n) => {
          o.addEventListener(`load`, e), o.addEventListener(`error`, () => n(Error(`Unable to preload CSS for ${t}`)))
        })
      }))
    }

    function i(e) {
      let t = new Event(`vite:preloadError`, {
        cancelable: !0
      });
      if (t.payload = e, window.dispatchEvent(t), !t.defaultPrevented) throw e
    }
    return r.then(t => {
      for (let e of t || []) e.status === `rejected` && i(e.reason);
      return e().catch(i)
    })
  },
  C = `popstate`;

function w(e) {
  return typeof e == `object` && !!e && `pathname` in e && `search` in e && `hash` in e && `state` in e && `key` in e
}

function T(e = {}) {
  function t(e, t) {
    let n = t.state?.masked,
      {
        pathname: r,
        search: i,
        hash: a
      } = n || e.location;
    return te(``, {
      pathname: r,
      search: i,
      hash: a
    }, t.state && t.state.usr || null, t.state && t.state.key || `default`, n ? {
      pathname: e.location.pathname,
      search: e.location.search,
      hash: e.location.hash
    } : void 0)
  }

  function n(e, t) {
    return typeof t == `string` ? t : k(t)
  }
  return re(t, n, null, e)
}

function E(e, t) {
  if (e === !1 || e == null) throw Error(t)
}

function D(e, t) {
  if (!e) {
    typeof console < `u` && console.warn(t);
    try {
      throw Error(t)
    } catch {}
  }
}

function O() {
  return Math.random().toString(36).substring(2, 10)
}

function ee(e, t) {
  return {
    usr: e.state,
    key: e.key,
    idx: t,
    masked: e.mask ? {
      pathname: e.pathname,
      search: e.search,
      hash: e.hash
    } : void 0
  }
}

function te(e, t, n = null, r, i) {
  return {
    pathname: typeof e == `string` ? e : e.pathname,
    search: ``,
    hash: ``,
    ...typeof t == `string` ? ne(t) : t,
    state: n,
    key: t && t.key || r || O(),
    mask: i
  }
}

function k({
  pathname: e = `/`,
  search: t = ``,
  hash: n = ``
}) {
  return t && t !== `?` && (e += t.charAt(0) === `?` ? t : `?` + t), n && n !== `#` && (e += n.charAt(0) === `#` ? n : `#` + n), e
}

function ne(e) {
  let t = {};
  if (e) {
    let n = e.indexOf(`#`);
    n >= 0 && (t.hash = e.substring(n), e = e.substring(0, n));
    let r = e.indexOf(`?`);
    r >= 0 && (t.search = e.substring(r), e = e.substring(0, r)), e && (t.pathname = e)
  }
  return t
}

function re(e, t, n, r = {}) {
  let {
    window: i = document.defaultView,
    v5Compat: a = !1
  } = r, o = i.history, s = `POP`, c = null, l = u();
  l ?? (l = 0, o.replaceState({
    ...o.state,
    idx: l
  }, ``));

  function u() {
    return (o.state || {
      idx: null
    }).idx
  }

  function d() {
    s = `POP`;
    let e = u(),
      t = e == null ? null : e - l;
    l = e, c && c({
      action: s,
      location: h.location,
      delta: t
    })
  }

  function f(e, t) {
    s = `PUSH`;
    let r = w(e) ? e : te(h.location, e, t);
    n && n(r, e), l = u() + 1;
    let d = ee(r, l),
      f = h.createHref(r.mask || r);
    try {
      o.pushState(d, ``, f)
    } catch (e) {
      if (e instanceof DOMException && e.name === `DataCloneError`) throw e;
      i.location.assign(f)
    }
    a && c && c({
      action: s,
      location: h.location,
      delta: 1
    })
  }

  function p(e, t) {
    s = `REPLACE`;
    let r = w(e) ? e : te(h.location, e, t);
    n && n(r, e), l = u();
    let i = ee(r, l),
      d = h.createHref(r.mask || r);
    o.replaceState(i, ``, d), a && c && c({
      action: s,
      location: h.location,
      delta: 0
    })
  }

  function m(e) {
    return ie(i, e)
  }
  let h = {
    get action() {
      return s
    },
    get location() {
      return e(i, o)
    },
    listen(e) {
      if (c) throw Error(`A history only accepts one active listener`);
      return i.addEventListener(C, d), c = e, () => {
        i.removeEventListener(C, d), c = null
      }
    },
    createHref(e) {
      return t(i, e)
    },
    createURL: m,
    encodeLocation(e) {
      let t = m(e);
      return {
        pathname: t.pathname,
        search: t.search,
        hash: t.hash
      }
    },
    push: f,
    replace: p,
    go(e) {
      return o.go(e)
    }
  };
  return h
}

function ie(e, t, n = !1) {
  let r = `http://localhost`;
  e && (r = e.location.origin === `null` ? e.location.href : e.location.origin), E(r, `No window.location.(origin|href) available to create URL`);
  let i = typeof t == `string` ? t : k(t);
  return i = i.replace(/ $/, `%20`), !n && i.startsWith(`//`) && (i = r + i), new URL(i, r)
}

function ae(e, t, n = `/`) {
  return A(e, t, n, !1)
}

function A(e, t, n, r, i) {
  let a = Se((typeof t == `string` ? ne(t) : t).pathname || `/`, n);
  if (a == null) return null;
  let o = i ?? oe(e),
    s = null,
    c = xe(a);
  for (let e = 0; s == null && e < o.length; ++e) s = ve(o[e], c, r);
  return s
}

function j(e, t) {
  let {
    route: n,
    pathname: r,
    params: i
  } = e;
  return {
    id: n.id,
    pathname: r,
    params: i,
    data: t[n.id],
    loaderData: t[n.id],
    handle: n.handle
  }
}

function oe(e) {
  let t = se(e);
  return le(t), t
}

function se(e, t = [], n = [], r = ``, i = !1) {
  let a = (e, a, o = i, s) => {
    let c = {
      relativePath: s === void 0 ? e.path || `` : s,
      caseSensitive: e.caseSensitive === !0,
      childrenIndex: a,
      route: e
    };
    if (c.relativePath.startsWith(`/`)) {
      if (!c.relativePath.startsWith(r) && o) return;
      E(c.relativePath.startsWith(r), `Absolute route path "${c.relativePath}" nested under path "${r}" is not valid. An absolute child route path must start with the combined path of all its parent routes.`), c.relativePath = c.relativePath.slice(r.length)
    }
    let l = je([r, c.relativePath]),
      u = n.concat(c);
    e.children && e.children.length > 0 && (E(e.index !== !0, `Index routes must not have child routes. Please remove all child routes from route path "${l}".`), se(e.children, t, u, l, o)), !(e.path == null && !e.index) && t.push({
      path: l,
      score: ge(l, e.index),
      routesMeta: u
    })
  };
  return e.forEach((e, t) => {
    if (e.path === `` || !e.path?.includes(`?`)) a(e, t);
    else
      for (let n of ce(e.path)) a(e, t, !0, n)
  }), t
}

function ce(e) {
  let t = e.split(`/`);
  if (t.length === 0) return [];
  let [n, ...r] = t, i = n.endsWith(`?`), a = n.replace(/\?$/, ``);
  if (r.length === 0) return i ? [a, ``] : [a];
  let o = ce(r.join(`/`)),
    s = [];
  return s.push(...o.map(e => e === `` ? a : [a, e].join(`/`))), i && s.push(...o), s.map(t => e.startsWith(`/`) && t === `` ? `/` : t)
}

function le(e) {
  e.sort((e, t) => e.score === t.score ? _e(e.routesMeta.map(e => e.childrenIndex), t.routesMeta.map(e => e.childrenIndex)) : t.score - e.score)
}
var ue = /^:[\w-]+$/,
  M = 3,
  de = 2,
  fe = 1,
  pe = 10,
  me = -2,
  he = e => e === `*`;

function ge(e, t) {
  let n = e.split(`/`),
    r = n.length;
  return n.some(he) && (r += me), t && (r += de), n.filter(e => !he(e)).reduce((e, t) => e + (ue.test(t) ? M : t === `` ? fe : pe), r)
}

function _e(e, t) {
  return e.length === t.length && e.slice(0, -1).every((e, n) => e === t[n]) ? e[e.length - 1] - t[t.length - 1] : 0
}

function ve(e, t, n = !1) {
  let {
    routesMeta: r
  } = e, i = {}, a = `/`, o = [];
  for (let e = 0; e < r.length; ++e) {
    let s = r[e],
      c = e === r.length - 1,
      l = a === `/` ? t : t.slice(a.length) || `/`,
      u = ye({
        path: s.relativePath,
        caseSensitive: s.caseSensitive,
        end: c
      }, l),
      d = s.route;
    if (!u && c && n && !r[r.length - 1].route.index && (u = ye({
        path: s.relativePath,
        caseSensitive: s.caseSensitive,
        end: !1
      }, l)), !u) return null;
    Object.assign(i, u.params), o.push({
      params: i,
      pathname: je([a, u.pathname]),
      pathnameBase: Ne(je([a, u.pathnameBase])),
      route: d
    }), u.pathnameBase !== `/` && (a = je([a, u.pathnameBase]))
  }
  return o
}

function ye(e, t) {
  typeof e == `string` && (e = {
    path: e,
    caseSensitive: !1,
    end: !0
  });
  let [n, r] = be(e.path, e.caseSensitive, e.end), i = t.match(n);
  if (!i) return null;
  let a = i[0],
    o = a.replace(/(.)\/+$/, `$1`),
    s = i.slice(1);
  return {
    params: r.reduce((e, {
      paramName: t,
      isOptional: n
    }, r) => {
      if (t === `*`) {
        let e = s[r] || ``;
        o = a.slice(0, a.length - e.length).replace(/(.)\/+$/, `$1`)
      }
      let i = s[r];
      return n && !i ? e[t] = void 0 : e[t] = (i || ``).replace(/%2F/g, `/`), e
    }, {}),
    pathname: a,
    pathnameBase: o,
    pattern: e
  }
}

function be(e, t = !1, n = !0) {
  D(e === `*` || !e.endsWith(`*`) || e.endsWith(`/*`), `Route path "${e}" will be treated as if it were "${e.replace(/\*$/,`/*`)}" because the \`*\` character must always follow a \`/\` in the pattern. To get rid of this warning, please change the route path to "${e.replace(/\*$/,`/*`)}".`);
  let r = [],
    i = `^` + e.replace(/\/*\*?$/, ``).replace(/^\/*/, `/`).replace(/[\\.*+^${}|()[\]]/g, `\\$&`).replace(/\/:([\w-]+)(\?)?/g, (e, t, n, i, a) => {
      if (r.push({
          paramName: t,
          isOptional: n != null
        }), n) {
        let t = a.charAt(i + e.length);
        return t && t !== `/` ? `/([^\\/]*)` : `(?:/([^\\/]*))?`
      }
      return `/([^\\/]+)`
    }).replace(/\/([\w-]+)\?(\/|$)/g, `(/$1)?$2`);
  return e.endsWith(`*`) ? (r.push({
    paramName: `*`
  }), i += e === `*` || e === `/*` ? `(.*)$` : `(?:\\/(.+)|\\/*)$`) : n ? i += `\\/*$` : e !== `` && e !== `/` && (i += `(?:(?=\\/|$))`), [new RegExp(i, t ? void 0 : `i`), r]
}

function xe(e) {
  try {
    return e.split(`/`).map(e => decodeURIComponent(e).replace(/\//g, `%2F`)).join(`/`)
  } catch (t) {
    return D(!1, `The URL path "${e}" could not be decoded because it is a malformed URL segment. This is probably due to a bad percent encoding (${t}).`), e
  }
}

function Se(e, t) {
  if (t === `/`) return e;
  if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
  let n = t.endsWith(`/`) ? t.length - 1 : t.length,
    r = e.charAt(n);
  return r && r !== `/` ? null : e.slice(n) || `/`
}
var Ce = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i;

function we(e, t = `/`) {
  let {
    pathname: n,
    search: r = ``,
    hash: i = ``
  } = typeof e == `string` ? ne(e) : e, a;
  return n ? (n = Ae(n), a = n.startsWith(`/`) ? Te(n.substring(1), `/`) : Te(n, t)) : a = t, {
    pathname: a,
    search: Pe(r),
    hash: Fe(i)
  }
}

function Te(e, t) {
  let n = Me(t).split(`/`);
  return e.split(`/`).forEach(e => {
    e === `..` ? n.length > 1 && n.pop() : e !== `.` && n.push(e)
  }), n.length > 1 ? n.join(`/`) : `/`
}

function Ee(e, t, n, r) {
  return `Cannot include a '${e}' character in a manually specified \`to.${t}\` field [${JSON.stringify(r)}].  Please separate it out to the \`to.${n}\` field. Alternatively you may provide the full path as a string in <Link to="..."> and the router will parse it for you.`
}

function De(e) {
  return e.filter((e, t) => t === 0 || e.route.path && e.route.path.length > 0)
}

function Oe(e) {
  let t = De(e);
  return t.map((e, n) => n === t.length - 1 ? e.pathname : e.pathnameBase)
}

function ke(e, t, n, r = !1) {
  let i;
  typeof e == `string` ? i = ne(e) : (i = {
    ...e
  }, E(!i.pathname || !i.pathname.includes(`?`), Ee(`?`, `pathname`, `search`, i)), E(!i.pathname || !i.pathname.includes(`#`), Ee(`#`, `pathname`, `hash`, i)), E(!i.search || !i.search.includes(`#`), Ee(`#`, `search`, `hash`, i)));
  let a = e === `` || i.pathname === ``,
    o = a ? `/` : i.pathname,
    s;
  if (o == null) s = n;
  else {
    let e = t.length - 1;
    if (!r && o.startsWith(`..`)) {
      let t = o.split(`/`);
      for (; t[0] === `..`;) t.shift(), --e;
      i.pathname = t.join(`/`)
    }
    s = e >= 0 ? t[e] : `/`
  }
  let c = we(i, s),
    l = o && o !== `/` && o.endsWith(`/`),
    u = (a || o === `.`) && n.endsWith(`/`);
  return !c.pathname.endsWith(`/`) && (l || u) && (c.pathname += `/`), c
}
var Ae = e => e.replace(/\/\/+/g, `/`),
  je = e => Ae(e.join(`/`)),
  Me = e => e.replace(/\/+$/, ``),
  Ne = e => Me(e).replace(/^\/*/, `/`),
  Pe = e => !e || e === `?` ? `` : e.startsWith(`?`) ? e : `?` + e,
  Fe = e => !e || e === `#` ? `` : e.startsWith(`#`) ? e : `#` + e,
  Ie = class {
    constructor(e, t, n, r = !1) {
      this.status = e, this.statusText = t || ``, this.internal = r, n instanceof Error ? (this.data = n.toString(), this.error = n) : this.data = n
    }
  };

function Le(e) {
  return e != null && typeof e.status == `number` && typeof e.statusText == `string` && typeof e.internal == `boolean` && `data` in e
}

function Re(e) {
  return je(e.map(e => e.route.path).filter(Boolean)) || `/`
}
var ze = typeof window < `u` && window.document !== void 0 && window.document.createElement !== void 0;

function Be(e, t) {
  let n = e;
  if (typeof n != `string` || !Ce.test(n)) return {
    absoluteURL: void 0,
    isExternal: !1,
    to: n
  };
  let r = n,
    i = !1;
  if (ze) try {
    let e = new URL(window.location.href),
      r = n.startsWith(`//`) ? new URL(e.protocol + n) : new URL(n),
      a = Se(r.pathname, t);
    r.origin === e.origin && a != null ? n = a + r.search + r.hash : i = !0
  } catch {
    D(!1, `<Link to="${n}"> contains an invalid URL which will probably break when clicked - please update to a valid URL path.`)
  }
  return {
    absoluteURL: r,
    isExternal: i,
    to: n
  }
}
Object.getOwnPropertyNames(Object.prototype).sort().join(`\0`);
var Ve = [`POST`, `PUT`, `PATCH`, `DELETE`];
new Set(Ve);
var He = [`GET`, ...Ve];
new Set(He);
var Ue = _.createContext(null);
Ue.displayName = `DataRouter`;
var We = _.createContext(null);
We.displayName = `DataRouterState`;
var Ge = _.createContext(!1);

function Ke() {
  return _.useContext(Ge)
}
var qe = _.createContext({
  isTransitioning: !1
});
qe.displayName = `ViewTransition`;
var Je = _.createContext(new Map);
Je.displayName = `Fetchers`;
var Ye = _.createContext(null);
Ye.displayName = `Await`;
var Xe = _.createContext(null);
Xe.displayName = `Navigation`;
var Ze = _.createContext(null);
Ze.displayName = `Location`;
var Qe = _.createContext({
  outlet: null,
  matches: [],
  isDataRoute: !1
});
Qe.displayName = `Route`;
var $e = _.createContext(null);
$e.displayName = `RouteError`;
var et = `REACT_ROUTER_ERROR`,
  tt = `REDIRECT`,
  nt = `ROUTE_ERROR_RESPONSE`;

function rt(e) {
  if (e.startsWith(`${et}:${tt}:{`)) try {
    let t = JSON.parse(e.slice(28));
    if (typeof t == `object` && t && typeof t.status == `number` && typeof t.statusText == `string` && typeof t.location == `string` && typeof t.reloadDocument == `boolean` && typeof t.replace == `boolean`) return t
  } catch {}
}

function it(e) {
  if (e.startsWith(`${et}:${nt}:{`)) try {
    let t = JSON.parse(e.slice(40));
    if (typeof t == `object` && t && typeof t.status == `number` && typeof t.statusText == `string`) return new Ie(t.status, t.statusText, t.data)
  } catch {}
}

function at(e, {
  relative: t
} = {}) {
  E(ot(), `useHref() may be used only in the context of a <Router> component.`);
  let {
    basename: n,
    navigator: r
  } = _.useContext(Xe), {
    hash: i,
    pathname: a,
    search: o
  } = ht(e, {
    relative: t
  }), s = a;
  return n !== `/` && (s = a === `/` ? n : je([n, a])), r.createHref({
    pathname: s,
    search: o,
    hash: i
  })
}

function ot() {
  return _.useContext(Ze) != null
}

function st() {
  return E(ot(), `useLocation() may be used only in the context of a <Router> component.`), _.useContext(Ze).location
}
var ct = `You should call navigate() in a React.useEffect(), not when your component is first rendered.`;

function lt(e) {
  _.useContext(Xe).static || _.useLayoutEffect(e)
}

function ut() {
  let {
    isDataRoute: e
  } = _.useContext(Qe);
  return e ? Pt() : dt()
}

function dt() {
  E(ot(), `useNavigate() may be used only in the context of a <Router> component.`);
  let e = _.useContext(Ue),
    {
      basename: t,
      navigator: n
    } = _.useContext(Xe),
    {
      matches: r
    } = _.useContext(Qe),
    {
      pathname: i
    } = st(),
    a = JSON.stringify(Oe(r)),
    o = _.useRef(!1);
  return lt(() => {
    o.current = !0
  }), _.useCallback((r, s = {}) => {
    if (D(o.current, ct), !o.current) return;
    if (typeof r == `number`) {
      n.go(r);
      return
    }
    let c = ke(r, JSON.parse(a), i, s.relative === `path`);
    e == null && t !== `/` && (c.pathname = c.pathname === `/` ? t : je([t, c.pathname])), (s.replace ? n.replace : n.push)(c, s.state, s)
  }, [t, n, a, i, e])
}
var ft = _.createContext(null);

function pt(e) {
  let t = _.useContext(Qe).outlet;
  return _.useMemo(() => t && _.createElement(ft.Provider, {
    value: e
  }, t), [t, e])
}

function mt() {
  let {
    matches: e
  } = _.useContext(Qe);
  return e[e.length - 1]?.params ?? {}
}

function ht(e, {
  relative: t
} = {}) {
  let {
    matches: n
  } = _.useContext(Qe), {
    pathname: r
  } = st(), i = JSON.stringify(Oe(n));
  return _.useMemo(() => ke(e, JSON.parse(i), r, t === `path`), [e, i, r, t])
}

function gt(e, t) {
  return _t(e, t)
}

function _t(e, t, n) {
  E(ot(), `useRoutes() may be used only in the context of a <Router> component.`);
  let {
    navigator: r
  } = _.useContext(Xe), {
    matches: i
  } = _.useContext(Qe), a = i[i.length - 1], o = a ? a.params : {}, s = a ? a.pathname : `/`, c = a ? a.pathnameBase : `/`, l = a && a.route;
  {
    let e = l && l.path || ``;
    It(s, !l || e.endsWith(`*`) || e.endsWith(`*?`), `You rendered descendant <Routes> (or called \`useRoutes()\`) at "${s}" (under <Route path="${e}">) but the parent route path has no trailing "*". This means if you navigate deeper, the parent won't match anymore and therefore the child routes will never render.

Please change the parent <Route path="${e}"> to <Route path="${e===`/`?`*`:`${e}/*`}">.`)
  }
  let u = st(),
    d;
  if (t) {
    let e = typeof t == `string` ? ne(t) : t;
    E(c === `/` || e.pathname?.startsWith(c), `When overriding the location using \`<Routes location>\` or \`useRoutes(routes, location)\`, the location pathname must begin with the portion of the URL pathname that was matched by all parent routes. The current pathname base is "${c}" but pathname "${e.pathname}" was given in the \`location\` prop.`), d = e
  } else d = u;
  let f = d.pathname || `/`,
    p = f;
  if (c !== `/`) {
    let e = c.replace(/^\//, ``).split(`/`);
    p = `/` + f.replace(/^\//, ``).split(`/`).slice(e.length).join(`/`)
  }
  let m = n && n.state.matches.length ? n.state.matches.map(e => Object.assign(e, {
    route: n.manifest[e.route.id] || e.route
  })) : ae(e, {
    pathname: p
  });
  D(l || m != null, `No routes matched location "${d.pathname}${d.search}${d.hash}" `), D(m == null || m[m.length - 1].route.element !== void 0 || m[m.length - 1].route.Component !== void 0 || m[m.length - 1].route.lazy !== void 0, `Matched leaf route at location "${d.pathname}${d.search}${d.hash}" does not have an element or Component. This means it will render an <Outlet /> with a null value by default resulting in an "empty" page.`);
  let h = wt(m && m.map(e => Object.assign({}, e, {
    params: Object.assign({}, o, e.params),
    pathname: je([c, r.encodeLocation ? r.encodeLocation(e.pathname.replace(/%/g, `%25`).replace(/\?/g, `%3F`).replace(/#/g, `%23`)).pathname : e.pathname]),
    pathnameBase: e.pathnameBase === `/` ? c : je([c, r.encodeLocation ? r.encodeLocation(e.pathnameBase.replace(/%/g, `%25`).replace(/\?/g, `%3F`).replace(/#/g, `%23`)).pathname : e.pathnameBase])
  })), i, n);
  return t && h ? _.createElement(Ze.Provider, {
    value: {
      location: {
        pathname: `/`,
        search: ``,
        hash: ``,
        state: null,
        key: `default`,
        mask: void 0,
        ...d
      },
      navigationType: `POP`
    }
  }, h) : h
}

function vt() {
  let e = Nt(),
    t = Le(e) ? `${e.status} ${e.statusText}` : e instanceof Error ? e.message : JSON.stringify(e),
    n = e instanceof Error ? e.stack : null,
    r = `rgba(200,200,200, 0.5)`,
    i = {
      padding: `0.5rem`,
      backgroundColor: r
    },
    a = {
      padding: `2px 4px`,
      backgroundColor: r
    },
    o = null;
  return console.error(`Error handled by React Router default ErrorBoundary:`, e), o = _.createElement(_.Fragment, null, _.createElement(`p`, null, `💿 Hey developer 👋`), _.createElement(`p`, null, `You can provide a way better UX than this when your app throws errors by providing your own `, _.createElement(`code`, {
    style: a
  }, `ErrorBoundary`), ` or`, ` `, _.createElement(`code`, {
    style: a
  }, `errorElement`), ` prop on your route.`)), _.createElement(_.Fragment, null, _.createElement(`h2`, null, `Unexpected Application Error!`), _.createElement(`h3`, {
    style: {
      fontStyle: `italic`
    }
  }, t), n ? _.createElement(`pre`, {
    style: i
  }, n) : null, o)
}
var yt = _.createElement(vt, null),
  bt = class extends _.Component {
    constructor(e) {
      super(e), this.state = {
        location: e.location,
        revalidation: e.revalidation,
        error: e.error
      }
    }
    static getDerivedStateFromError(e) {
      return {
        error: e
      }
    }
    static getDerivedStateFromProps(e, t) {
      return t.location !== e.location || t.revalidation !== `idle` && e.revalidation === `idle` ? {
        error: e.error,
        location: e.location,
        revalidation: e.revalidation
      } : {
        error: e.error === void 0 ? t.error : e.error,
        location: t.location,
        revalidation: e.revalidation || t.revalidation
      }
    }
    componentDidCatch(e, t) {
      this.props.onError ? this.props.onError(e, t) : console.error(`React Router caught the following error during render`, e)
    }
    render() {
      let e = this.state.error;
      if (this.context && typeof e == `object` && e && `digest` in e && typeof e.digest == `string`) {
        let t = it(e.digest);
        t && (e = t)
      }
      let t = e === void 0 ? this.props.children : _.createElement(Qe.Provider, {
        value: this.props.routeContext
      }, _.createElement($e.Provider, {
        value: e,
        children: this.props.component
      }));
      return this.context ? _.createElement(St, {
        error: e
      }, t) : t
    }
  };
bt.contextType = Ge;
var xt = new WeakMap;

function St({
  children: e,
  error: t
}) {
  let {
    basename: n
  } = _.useContext(Xe);
  if (typeof t == `object` && t && `digest` in t && typeof t.digest == `string`) {
    let e = rt(t.digest);
    if (e) {
      let r = xt.get(t);
      if (r) throw r;
      let i = Be(e.location, n);
      if (ze && !xt.get(t))
        if (i.isExternal || e.reloadDocument) window.location.href = i.absoluteURL || i.to;
        else {
          let n = Promise.resolve().then(() => window.__reactRouterDataRouter.navigate(i.to, {
            replace: e.replace
          }));
          throw xt.set(t, n), n
        } return _.createElement(`meta`, {
        httpEquiv: `refresh`,
        content: `0;url=${i.absoluteURL||i.to}`
      })
    }
  }
  return e
}

function Ct({
  routeContext: e,
  match: t,
  children: n
}) {
  let r = _.useContext(Ue);
  return r && r.static && r.staticContext && (t.route.errorElement || t.route.ErrorBoundary) && (r.staticContext._deepestRenderedBoundaryId = t.route.id), _.createElement(Qe.Provider, {
    value: e
  }, n)
}

function wt(e, t = [], n) {
  let r = n?.state;
  if (e == null) {
    if (!r) return null;
    if (r.errors) e = r.matches;
    else if (t.length === 0 && !r.initialized && r.matches.length > 0) e = r.matches;
    else return null
  }
  let i = e,
    a = r?.errors;
  if (a != null) {
    let e = i.findIndex(e => e.route.id && a?.[e.route.id] !== void 0);
    E(e >= 0, `Could not find a matching route for errors on route IDs: ${Object.keys(a).join(`,`)}`), i = i.slice(0, Math.min(i.length, e + 1))
  }
  let o = !1,
    s = -1;
  if (n && r) {
    o = r.renderFallback;
    for (let e = 0; e < i.length; e++) {
      let t = i[e];
      if ((t.route.HydrateFallback || t.route.hydrateFallbackElement) && (s = e), t.route.id) {
        let {
          loaderData: e,
          errors: a
        } = r, c = t.route.loader && !e.hasOwnProperty(t.route.id) && (!a || a[t.route.id] === void 0);
        if (t.route.lazy || c) {
          n.isStatic && (o = !0), i = s >= 0 ? i.slice(0, s + 1) : [i[0]];
          break
        }
      }
    }
  }
  let c = n?.onError,
    l = r && c ? (e, t) => {
      c(e, {
        location: r.location,
        params: r.matches?.[0]?.params ?? {},
        pattern: Re(r.matches),
        errorInfo: t
      })
    } : void 0;
  return i.reduceRight((e, n, c) => {
    let u, d = !1,
      f = null,
      p = null;
    r && (u = a && n.route.id ? a[n.route.id] : void 0, f = n.route.errorElement || yt, o && (s < 0 && c === 0 ? (It(`route-fallback`, !1, "No `HydrateFallback` element provided to render during initial hydration"), d = !0, p = null) : s === c && (d = !0, p = n.route.hydrateFallbackElement || null)));
    let m = t.concat(i.slice(0, c + 1)),
      h = () => {
        let t;
        return t = u ? f : d ? p : n.route.Component ? _.createElement(n.route.Component, null) : n.route.element ? n.route.element : e, _.createElement(Ct, {
          match: n,
          routeContext: {
            outlet: e,
            matches: m,
            isDataRoute: r != null
          },
          children: t
        })
      };
    return r && (n.route.ErrorBoundary || n.route.errorElement || c === 0) ? _.createElement(bt, {
      location: r.location,
      revalidation: r.revalidation,
      component: f,
      error: u,
      children: h(),
      routeContext: {
        outlet: null,
        matches: m,
        isDataRoute: !0
      },
      onError: l
    }) : h()
  }, null)
}

function Tt(e) {
  return `${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`
}

function Et(e) {
  let t = _.useContext(Ue);
  return E(t, Tt(e)), t
}

function Dt(e) {
  let t = _.useContext(We);
  return E(t, Tt(e)), t
}

function Ot(e) {
  let t = _.useContext(Qe);
  return E(t, Tt(e)), t
}

function kt(e) {
  let t = Ot(e),
    n = t.matches[t.matches.length - 1];
  return E(n.route.id, `${e} can only be used on routes that contain a unique "id"`), n.route.id
}

function At() {
  return kt(`useRouteId`)
}

function jt() {
  let e = Dt(`useNavigation`);
  return _.useMemo(() => {
    let {
      matches: t,
      historyAction: n,
      ...r
    } = e.navigation;
    return r
  }, [e.navigation])
}

function Mt() {
  let {
    matches: e,
    loaderData: t
  } = Dt(`useMatches`);
  return _.useMemo(() => e.map(e => j(e, t)), [e, t])
}

function Nt() {
  let e = _.useContext($e),
    t = Dt(`useRouteError`),
    n = kt(`useRouteError`);
  return e === void 0 ? t.errors?.[n] : e
}

function Pt() {
  let {
    router: e
  } = Et(`useNavigate`), t = kt(`useNavigate`), n = _.useRef(!1);
  return lt(() => {
    n.current = !0
  }), _.useCallback(async (r, i = {}) => {
    D(n.current, ct), n.current && (typeof r == `number` ? await e.navigate(r) : await e.navigate(r, {
      fromRouteId: t,
      ...i
    }))
  }, [e, t])
}
var Ft = {};

function It(e, t, n) {
  !t && !Ft[e] && (Ft[e] = !0, D(!1, n))
}
_.memo(Lt);

function Lt({
  routes: e,
  manifest: t,
  future: n,
  state: r,
  isStatic: i,
  onError: a
}) {
  return _t(e, void 0, {
    manifest: t,
    state: r,
    isStatic: i,
    onError: a,
    future: n
  })
}

function Rt({
  to: e,
  replace: t,
  state: n,
  relative: r
}) {
  E(ot(), `<Navigate> may be used only in the context of a <Router> component.`);
  let {
    static: i
  } = _.useContext(Xe);
  D(!i, `<Navigate> must not be used on the initial render in a <StaticRouter>. This is a no-op, but you should modify your code so the <Navigate> is only ever rendered in response to some user interaction or state change.`);
  let {
    matches: a
  } = _.useContext(Qe), {
    pathname: o
  } = st(), s = ut(), c = ke(e, Oe(a), o, r === `path`), l = JSON.stringify(c);
  return _.useEffect(() => {
    s(JSON.parse(l), {
      replace: t,
      state: n,
      relative: r
    })
  }, [s, l, r, t, n]), null
}

function zt(e) {
  return pt(e.context)
}

function Bt(e) {
  E(!1, `A <Route> is only ever to be used as the child of <Routes> element, never rendered directly. Please wrap your <Route> in a <Routes>.`)
}

function Vt({
  basename: e = `/`,
  children: t = null,
  location: n,
  navigationType: r = `POP`,
  navigator: i,
  static: a = !1,
  useTransitions: o
}) {
  E(!ot(), `You cannot render a <Router> inside another <Router>. You should never have more than one in your app.`);
  let s = e.replace(/^\/*/, `/`),
    c = _.useMemo(() => ({
      basename: s,
      navigator: i,
      static: a,
      useTransitions: o,
      future: {}
    }), [s, i, a, o]);
  typeof n == `string` && (n = ne(n));
  let {
    pathname: l = `/`,
    search: u = ``,
    hash: d = ``,
    state: f = null,
    key: p = `default`,
    mask: m
  } = n, h = _.useMemo(() => {
    let e = Se(l, s);
    return e == null ? null : {
      location: {
        pathname: e,
        search: u,
        hash: d,
        state: f,
        key: p,
        mask: m
      },
      navigationType: r
    }
  }, [s, l, u, d, f, p, r, m]);
  return D(h != null, `<Router basename="${s}"> is not able to match the URL "${l}${u}${d}" because it does not start with the basename, so the <Router> won't render anything.`), h == null ? null : _.createElement(Xe.Provider, {
    value: c
  }, _.createElement(Ze.Provider, {
    children: t,
    value: h
  }))
}

function Ht({
  children: e,
  location: t
}) {
  return gt(Ut(e), t)
}
_.Component;

function Ut(e, t = []) {
  let n = [];
  return _.Children.forEach(e, (e, r) => {
    if (!_.isValidElement(e)) return;
    let i = [...t, r];
    if (e.type === _.Fragment) {
      n.push.apply(n, Ut(e.props.children, i));
      return
    }
    E(e.type === Bt, `[${typeof e.type==`string`?e.type:e.type.name}] is not a <Route> component. All component children of <Routes> must be a <Route> or <React.Fragment>`), E(!e.props.index || !e.props.children, `An index route cannot have child routes.`);
    let a = {
      id: e.props.id || i.join(`-`),
      caseSensitive: e.props.caseSensitive,
      element: e.props.element,
      Component: e.props.Component,
      index: e.props.index,
      path: e.props.path,
      middleware: e.props.middleware,
      loader: e.props.loader,
      action: e.props.action,
      hydrateFallbackElement: e.props.hydrateFallbackElement,
      HydrateFallback: e.props.HydrateFallback,
      errorElement: e.props.errorElement,
      ErrorBoundary: e.props.ErrorBoundary,
      hasErrorBoundary: e.props.hasErrorBoundary === !0 || e.props.ErrorBoundary != null || e.props.errorElement != null,
      shouldRevalidate: e.props.shouldRevalidate,
      handle: e.props.handle,
      lazy: e.props.lazy
    };
    e.props.children && (a.children = Ut(e.props.children, i)), n.push(a)
  }), n
}
var Wt = `get`,
  Gt = `application/x-www-form-urlencoded`;

function Kt(e) {
  return typeof HTMLElement < `u` && e instanceof HTMLElement
}

function qt(e) {
  return Kt(e) && e.tagName.toLowerCase() === `button`
}

function Jt(e) {
  return Kt(e) && e.tagName.toLowerCase() === `form`
}

function Yt(e) {
  return Kt(e) && e.tagName.toLowerCase() === `input`
}

function Xt(e) {
  return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey)
}

function Zt(e, t) {
  return e.button === 0 && (!t || t === `_self`) && !Xt(e)
}

function Qt(e = ``) {
  return new URLSearchParams(typeof e == `string` || Array.isArray(e) || e instanceof URLSearchParams ? e : Object.keys(e).reduce((t, n) => {
    let r = e[n];
    return t.concat(Array.isArray(r) ? r.map(e => [n, e]) : [
      [n, r]
    ])
  }, []))
}

function $t(e, t) {
  let n = Qt(e);
  return t && t.forEach((e, r) => {
    n.has(r) || t.getAll(r).forEach(e => {
      n.append(r, e)
    })
  }), n
}
var en = null;

function tn() {
  if (en === null) try {
    new FormData(document.createElement(`form`), 0), en = !1
  } catch {
    en = !0
  }
  return en
}
var nn = new Set([`application/x-www-form-urlencoded`, `multipart/form-data`, `text/plain`]);

function rn(e) {
  return e != null && !nn.has(e) ? (D(!1, `"${e}" is not a valid \`encType\` for \`<Form>\`/\`<fetcher.Form>\` and will default to "${Gt}"`), null) : e
}

function an(e, t) {
  let n, r, i, a, o;
  if (Jt(e)) {
    let o = e.getAttribute(`action`);
    r = o ? Se(o, t) : null, n = e.getAttribute(`method`) || Wt, i = rn(e.getAttribute(`enctype`)) || Gt, a = new FormData(e)
  } else if (qt(e) || Yt(e) && (e.type === `submit` || e.type === `image`)) {
    let o = e.form;
    if (o == null) throw Error(`Cannot submit a <button> or <input type="submit"> without a <form>`);
    let s = e.getAttribute(`formaction`) || o.getAttribute(`action`);
    if (r = s ? Se(s, t) : null, n = e.getAttribute(`formmethod`) || o.getAttribute(`method`) || Wt, i = rn(e.getAttribute(`formenctype`)) || rn(o.getAttribute(`enctype`)) || Gt, a = new FormData(o, e), !tn()) {
      let {
        name: t,
        type: n,
        value: r
      } = e;
      if (n === `image`) {
        let e = t ? `${t}.` : ``;
        a.append(`${e}x`, `0`), a.append(`${e}y`, `0`)
      } else t && a.append(t, r)
    }
  } else if (Kt(e)) throw Error(`Cannot submit element that is not <form>, <button>, or <input type="submit|image">`);
  else n = Wt, r = null, i = Gt, o = e;
  return a && i === `text/plain` && (o = a, a = void 0), {
    action: r,
    method: n.toLowerCase(),
    encType: i,
    formData: a,
    body: o
  }
}
Object.getOwnPropertyNames(Object.prototype).sort().join(`\0`);
var on = {
    "&": `\\u0026`,
    ">": `\\u003e`,
    "<": `\\u003c`,
    "\u2028": `\\u2028`,
    "\u2029": `\\u2029`
  },
  sn = /[&><\u2028\u2029]/g;

function cn(e) {
  return e.replace(sn, e => on[e])
}

function ln(e, t) {
  if (e === !1 || e == null) throw Error(t)
}

function un(e, t, n, r) {
  let i = typeof e == `string` ? new URL(e, typeof window > `u` ? `server://singlefetch/` : window.location.origin) : e;
  return n ? i.pathname.endsWith(`/`) ? i.pathname = `${i.pathname}_.${r}` : i.pathname = `${i.pathname}.${r}` : i.pathname === `/` ? i.pathname = `_root.${r}` : t && Se(i.pathname, t) === `/` ? i.pathname = `${Me(t)}/_root.${r}` : i.pathname = `${Me(i.pathname)}.${r}`, i
}
async function dn(e, t) {
  if (e.id in t) return t[e.id];
  try {
    let n = await S(() => import(e.module), [], import.meta.url);
    return t[e.id] = n, n
  } catch (t) {
    return console.error(`Error loading route module \`${e.module}\`, reloading page...`), console.error(t), window.__reactRouterContext && window.__reactRouterContext.isSpaMode, window.location.reload(), new Promise(() => {})
  }
}

function fn(e) {
  return e != null && typeof e.page == `string`
}

function pn(e) {
  return e == null ? !1 : e.href == null ? e.rel === `preload` && typeof e.imageSrcSet == `string` && typeof e.imageSizes == `string` : typeof e.rel == `string` && typeof e.href == `string`
}
async function mn(e, t, n) {
  return yn((await Promise.all(e.map(async e => {
    let r = t.routes[e.route.id];
    if (r) {
      let e = await dn(r, n);
      return e.links ? e.links() : []
    }
    return []
  }))).flat(1).filter(pn).filter(e => e.rel === `stylesheet` || e.rel === `preload`).map(e => e.rel === `stylesheet` ? {
    ...e,
    rel: `prefetch`,
    as: `style`
  } : {
    ...e,
    rel: `prefetch`
  }))
}

function hn(e, t, n, r, i, a) {
  let o = (e, t) => n[t] ? e.route.id !== n[t].route.id : !0,
    s = (e, t) => n[t].pathname !== e.pathname || n[t].route.path?.endsWith(`*`) && n[t].params[`*`] !== e.params[`*`];
  return a === `assets` ? t.filter((e, t) => o(e, t) || s(e, t)) : a === `data` ? t.filter((t, a) => {
    let c = r.routes[t.route.id];
    if (!c || !c.hasLoader) return !1;
    if (o(t, a) || s(t, a)) return !0;
    if (t.route.shouldRevalidate) {
      let r = t.route.shouldRevalidate({
        currentUrl: new URL(i.pathname + i.search + i.hash, window.origin),
        currentParams: n[0]?.params || {},
        nextUrl: new URL(e, window.origin),
        nextParams: t.params,
        defaultShouldRevalidate: !0
      });
      if (typeof r == `boolean`) return r
    }
    return !0
  }) : []
}

function gn(e, t, {
  includeHydrateFallback: n
} = {}) {
  return _n(e.map(e => {
    let r = t.routes[e.route.id];
    if (!r) return [];
    let i = [r.module];
    return r.clientActionModule && (i = i.concat(r.clientActionModule)), r.clientLoaderModule && (i = i.concat(r.clientLoaderModule)), n && r.hydrateFallbackModule && (i = i.concat(r.hydrateFallbackModule)), r.imports && (i = i.concat(r.imports)), i
  }).flat(1))
}

function _n(e) {
  return [...new Set(e)]
}

function vn(e) {
  let t = {},
    n = Object.keys(e).sort();
  for (let r of n) t[r] = e[r];
  return t
}

function yn(e, t) {
  let n = new Set,
    r = new Set(t);
  return e.reduce((e, i) => {
    if (t && !fn(i) && i.as === `script` && i.href && r.has(i.href)) return e;
    let a = JSON.stringify(vn(i));
    return n.has(a) || (n.add(a), e.push({
      key: a,
      link: i
    })), e
  }, [])
}

function bn() {
  let e = _.useContext(Ue);
  return ln(e, `You must render this element inside a <DataRouterContext.Provider> element`), e
}

function xn() {
  let e = _.useContext(We);
  return ln(e, `You must render this element inside a <DataRouterStateContext.Provider> element`), e
}
var Sn = _.createContext(void 0);
Sn.displayName = `FrameworkContext`;

function Cn() {
  let e = _.useContext(Sn);
  return ln(e, `You must render this element inside a <HydratedRouter> element`), e
}

function wn(e, t) {
  let n = _.useContext(Sn),
    [r, i] = _.useState(!1),
    [a, o] = _.useState(!1),
    {
      onFocus: s,
      onBlur: c,
      onMouseEnter: l,
      onMouseLeave: u,
      onTouchStart: d
    } = t,
    f = _.useRef(null);
  _.useEffect(() => {
    if (e === `render` && o(!0), e === `viewport`) {
      let e = new IntersectionObserver(e => {
        e.forEach(e => {
          o(e.isIntersecting)
        })
      }, {
        threshold: .5
      });
      return f.current && e.observe(f.current), () => {
        e.disconnect()
      }
    }
  }, [e]), _.useEffect(() => {
    if (r) {
      let e = setTimeout(() => {
        o(!0)
      }, 100);
      return () => {
        clearTimeout(e)
      }
    }
  }, [r]);
  let p = () => {
      i(!0)
    },
    m = () => {
      i(!1), o(!1)
    };
  return n ? e === `intent` ? [a, f, {
    onFocus: Tn(s, p),
    onBlur: Tn(c, m),
    onMouseEnter: Tn(l, p),
    onMouseLeave: Tn(u, m),
    onTouchStart: Tn(d, p)
  }] : [a, f, {}] : [!1, f, {}]
}

function Tn(e, t) {
  return n => {
    e && e(n), n.defaultPrevented || t(n)
  }
}

function En({
  page: e,
  ...t
}) {
  let n = Ke(),
    {
      router: r
    } = bn(),
    i = _.useMemo(() => ae(r.routes, e, r.basename), [r.routes, e, r.basename]);
  return i ? n ? _.createElement(On, {
    page: e,
    matches: i,
    ...t
  }) : _.createElement(kn, {
    page: e,
    matches: i,
    ...t
  }) : null
}

function Dn(e) {
  let {
    manifest: t,
    routeModules: n
  } = Cn(), [r, i] = _.useState([]);
  return _.useEffect(() => {
    let r = !1;
    return mn(e, t, n).then(e => {
      r || i(e)
    }), () => {
      r = !0
    }
  }, [e, t, n]), r
}

function On({
  page: e,
  matches: t,
  ...n
}) {
  let r = st(),
    {
      future: i
    } = Cn(),
    {
      basename: a
    } = bn(),
    o = _.useMemo(() => {
      if (e === r.pathname + r.search + r.hash) return [];
      let n = un(e, a, i.v8_trailingSlashAwareDataRequests, `rsc`),
        o = !1,
        s = [];
      for (let e of t) typeof e.route.shouldRevalidate == `function` ? o = !0 : s.push(e.route.id);
      return o && s.length > 0 && n.searchParams.set(`_routes`, s.join(`,`)), [n.pathname + n.search]
    }, [a, i.v8_trailingSlashAwareDataRequests, e, r, t]);
  return _.createElement(_.Fragment, null, o.map(e => _.createElement(`link`, {
    key: e,
    rel: `prefetch`,
    as: `fetch`,
    href: e,
    ...n
  })))
}

function kn({
  page: e,
  matches: t,
  ...n
}) {
  let r = st(),
    {
      future: i,
      manifest: a,
      routeModules: o
    } = Cn(),
    {
      basename: s
    } = bn(),
    {
      loaderData: c,
      matches: l
    } = xn(),
    u = _.useMemo(() => hn(e, t, l, a, r, `data`), [e, t, l, a, r]),
    d = _.useMemo(() => hn(e, t, l, a, r, `assets`), [e, t, l, a, r]),
    f = _.useMemo(() => {
      if (e === r.pathname + r.search + r.hash) return [];
      let n = new Set,
        l = !1;
      if (t.forEach(e => {
          let t = a.routes[e.route.id];
          !t || !t.hasLoader || (!u.some(t => t.route.id === e.route.id) && e.route.id in c && o[e.route.id]?.shouldRevalidate || t.hasClientLoader ? l = !0 : n.add(e.route.id))
        }), n.size === 0) return [];
      let d = un(e, s, i.v8_trailingSlashAwareDataRequests, `data`);
      return l && n.size > 0 && d.searchParams.set(`_routes`, t.filter(e => n.has(e.route.id)).map(e => e.route.id).join(`,`)), [d.pathname + d.search]
    }, [s, i.v8_trailingSlashAwareDataRequests, c, r, a, u, t, e, o]),
    p = _.useMemo(() => gn(d, a), [d, a]),
    m = Dn(d);
  return _.createElement(_.Fragment, null, f.map(e => _.createElement(`link`, {
    key: e,
    rel: `prefetch`,
    as: `fetch`,
    href: e,
    ...n
  })), p.map(e => _.createElement(`link`, {
    key: e,
    rel: `modulepreload`,
    href: e,
    ...n
  })), m.map(({
    key: e,
    link: t
  }) => _.createElement(`link`, {
    key: e,
    nonce: n.nonce,
    ...t,
    crossOrigin: t.crossOrigin ?? n.crossOrigin
  })))
}

function An(...e) {
  return t => {
    e.forEach(e => {
      typeof e == `function` ? e(t) : e != null && (e.current = t)
    })
  }
}
_.Component;
var jn = typeof window < `u` && window.document !== void 0 && window.document.createElement !== void 0;
try {
  jn && (window.__reactRouterVersion = `7.17.0`)
} catch {}

function Mn({
  basename: e,
  children: t,
  useTransitions: n,
  window: r
}) {
  let i = _.useRef();
  i.current ??= T({
    window: r,
    v5Compat: !0
  });
  let a = i.current,
    [o, s] = _.useState({
      action: a.action,
      location: a.location
    }),
    c = _.useCallback(e => {
      n === !1 ? s(e) : _.startTransition(() => s(e))
    }, [n]);
  return _.useLayoutEffect(() => a.listen(c), [a, c]), _.createElement(Vt, {
    basename: e,
    children: t,
    location: o.location,
    navigationType: o.action,
    navigator: a,
    useTransitions: n
  })
}

function Nn({
  basename: e,
  children: t,
  history: n,
  useTransitions: r
}) {
  let [i, a] = _.useState({
    action: n.action,
    location: n.location
  }), o = _.useCallback(e => {
    r === !1 ? a(e) : _.startTransition(() => a(e))
  }, [r]);
  return _.useLayoutEffect(() => n.listen(o), [n, o]), _.createElement(Vt, {
    basename: e,
    children: t,
    location: i.location,
    navigationType: i.action,
    navigator: n,
    useTransitions: r
  })
}
Nn.displayName = `unstable_HistoryRouter`;
var Pn = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
  Fn = _.forwardRef(function({
    onClick: e,
    discover: t = `render`,
    prefetch: n = `none`,
    relative: r,
    reloadDocument: i,
    replace: a,
    mask: o,
    state: s,
    target: c,
    to: l,
    preventScrollReset: u,
    viewTransition: d,
    defaultShouldRevalidate: f,
    ...p
  }, m) {
    let {
      basename: h,
      navigator: g,
      useTransitions: v
    } = _.useContext(Xe), y = typeof l == `string` && Pn.test(l), b = Be(l, h);
    l = b.to;
    let x = at(l, {
        relative: r
      }),
      S = st(),
      C = null;
    if (o) {
      let e = ke(o, [], S.mask ? S.mask.pathname : `/`, !0);
      h !== `/` && (e.pathname = e.pathname === `/` ? h : je([h, e.pathname])), C = g.createHref(e)
    }
    let [w, T, E] = wn(n, p), D = Hn(l, {
      replace: a,
      mask: o,
      state: s,
      target: c,
      preventScrollReset: u,
      relative: r,
      viewTransition: d,
      defaultShouldRevalidate: f,
      useTransitions: v
    });

    function O(t) {
      e && e(t), t.defaultPrevented || D(t)
    }
    let ee = !(b.isExternal || i),
      te = _.createElement(`a`, {
        ...p,
        ...E,
        href: (ee ? C : void 0) || b.absoluteURL || x,
        onClick: ee ? O : e,
        ref: An(m, T),
        target: c,
        "data-discover": !y && t === `render` ? `true` : void 0
      });
    return w && !y ? _.createElement(_.Fragment, null, te, _.createElement(En, {
      page: x
    })) : te
  });
Fn.displayName = `Link`;
var In = _.forwardRef(function({
  "aria-current": e = `page`,
  caseSensitive: t = !1,
  className: n = ``,
  end: r = !1,
  style: i,
  to: a,
  viewTransition: o,
  children: s,
  ...c
}, l) {
  let u = ht(a, {
      relative: c.relative
    }),
    d = st(),
    f = _.useContext(We),
    {
      navigator: p,
      basename: m
    } = _.useContext(Xe),
    h = f != null && $n(u) && o === !0,
    g = p.encodeLocation ? p.encodeLocation(u).pathname : u.pathname,
    v = d.pathname,
    y = f && f.navigation && f.navigation.location ? f.navigation.location.pathname : null;
  t || (v = v.toLowerCase(), y = y ? y.toLowerCase() : null, g = g.toLowerCase()), y && m && (y = Se(y, m) || y);
  let b = g !== `/` && g.endsWith(`/`) ? g.length - 1 : g.length,
    x = v === g || !r && v.startsWith(g) && v.charAt(b) === `/`,
    S = y != null && (y === g || !r && y.startsWith(g) && y.charAt(g.length) === `/`),
    C = {
      isActive: x,
      isPending: S,
      isTransitioning: h
    },
    w = x ? e : void 0,
    T;
  T = typeof n == `function` ? n(C) : [n, x ? `active` : null, S ? `pending` : null, h ? `transitioning` : null].filter(Boolean).join(` `);
  let E = typeof i == `function` ? i(C) : i;
  return _.createElement(Fn, {
    ...c,
    "aria-current": w,
    className: T,
    ref: l,
    style: E,
    to: a,
    viewTransition: o
  }, typeof s == `function` ? s(C) : s)
});
In.displayName = `NavLink`;
var Ln = _.forwardRef(({
  discover: e = `render`,
  fetcherKey: t,
  navigate: n,
  reloadDocument: r,
  replace: i,
  state: a,
  method: o = Wt,
  action: s,
  onSubmit: c,
  relative: l,
  preventScrollReset: u,
  viewTransition: d,
  defaultShouldRevalidate: f,
  ...p
}, m) => {
  let {
    useTransitions: h
  } = _.useContext(Xe), g = Kn(), v = qn(s, {
    relative: l
  }), y = o.toLowerCase() === `get` ? `get` : `post`, b = typeof s == `string` && Pn.test(s);
  return _.createElement(`form`, {
    ref: m,
    method: y,
    action: v,
    onSubmit: r ? c : e => {
      if (c && c(e), e.defaultPrevented) return;
      e.preventDefault();
      let r = e.nativeEvent.submitter,
        s = r?.getAttribute(`formmethod`) || o,
        p = () => g(r || e.currentTarget, {
          fetcherKey: t,
          method: s,
          navigate: n,
          replace: i,
          state: a,
          relative: l,
          preventScrollReset: u,
          viewTransition: d,
          defaultShouldRevalidate: f
        });
      h && n !== !1 ? _.startTransition(() => p()) : p()
    },
    ...p,
    "data-discover": !b && e === `render` ? `true` : void 0
  })
});
Ln.displayName = `Form`;

function Rn({
  getKey: e,
  storageKey: t,
  ...n
}) {
  let r = _.useContext(Sn),
    {
      basename: i
    } = _.useContext(Xe),
    a = st(),
    o = Mt();
  Zn({
    getKey: e,
    storageKey: t
  });
  let s = _.useMemo(() => {
    if (!r || !e) return null;
    let t = Xn(a, o, i, e);
    return t === a.key ? null : t
  }, []);
  if (!r || r.isSpaMode) return null;
  let c = ((e, t) => {
    if (!window.history.state || !window.history.state.key) {
      let e = Math.random().toString(32).slice(2);
      window.history.replaceState({
        key: e
      }, ``)
    }
    try {
      let n = JSON.parse(sessionStorage.getItem(e) || `{}`)[t || window.history.state.key];
      typeof n == `number` && window.scrollTo(0, n)
    } catch (t) {
      console.error(t), sessionStorage.removeItem(e)
    }
  }).toString();
  return _.createElement(`script`, {
    ...n,
    suppressHydrationWarning: !0,
    dangerouslySetInnerHTML: {
      __html: `(${c})(${cn(JSON.stringify(t||Jn))}, ${cn(JSON.stringify(s))})`
    }
  })
}
Rn.displayName = `ScrollRestoration`;

function zn(e) {
  return `${e} must be used within a data router.  See https://reactrouter.com/en/main/routers/picking-a-router.`
}

function Bn(e) {
  let t = _.useContext(Ue);
  return E(t, zn(e)), t
}

function Vn(e) {
  let t = _.useContext(We);
  return E(t, zn(e)), t
}

function Hn(e, {
  target: t,
  replace: n,
  mask: r,
  state: i,
  preventScrollReset: a,
  relative: o,
  viewTransition: s,
  defaultShouldRevalidate: c,
  useTransitions: l
} = {}) {
  let u = ut(),
    d = st(),
    f = ht(e, {
      relative: o
    });
  return _.useCallback(p => {
    if (Zt(p, t)) {
      p.preventDefault();
      let t = n === void 0 ? k(d) === k(f) : n,
        m = () => u(e, {
          replace: t,
          mask: r,
          state: i,
          preventScrollReset: a,
          relative: o,
          viewTransition: s,
          defaultShouldRevalidate: c
        });
      l ? _.startTransition(() => m()) : m()
    }
  }, [d, u, f, n, r, i, t, e, a, o, s, c, l])
}

function Un(e) {
  D(typeof URLSearchParams < `u`, "You cannot use the `useSearchParams` hook in a browser that does not support the URLSearchParams API. If you need to support Internet Explorer 11, we recommend you load a polyfill such as https://github.com/ungap/url-search-params.");
  let t = _.useRef(Qt(e)),
    n = _.useRef(!1),
    r = st(),
    i = _.useMemo(() => $t(r.search, n.current ? null : t.current), [r.search]),
    a = ut();
  return [i, _.useCallback((e, t) => {
    let r = Qt(typeof e == `function` ? e(new URLSearchParams(i)) : e);
    n.current = !0, a(`?` + r, t)
  }, [a, i])]
}
var Wn = 0,
  Gn = () => `__${String(++Wn)}__`;

function Kn() {
  let {
    router: e
  } = Bn(`useSubmit`), {
    basename: t
  } = _.useContext(Xe), n = At(), r = e.fetch, i = e.navigate;
  return _.useCallback(async (e, a = {}) => {
    let {
      action: o,
      method: s,
      encType: c,
      formData: l,
      body: u
    } = an(e, t);
    a.navigate === !1 ? await r(a.fetcherKey || Gn(), n, a.action || o, {
      defaultShouldRevalidate: a.defaultShouldRevalidate,
      preventScrollReset: a.preventScrollReset,
      formData: l,
      body: u,
      formMethod: a.method || s,
      formEncType: a.encType || c,
      flushSync: a.flushSync
    }) : await i(a.action || o, {
      defaultShouldRevalidate: a.defaultShouldRevalidate,
      preventScrollReset: a.preventScrollReset,
      formData: l,
      body: u,
      formMethod: a.method || s,
      formEncType: a.encType || c,
      replace: a.replace,
      state: a.state,
      fromRouteId: n,
      flushSync: a.flushSync,
      viewTransition: a.viewTransition
    })
  }, [r, i, t, n])
}

function qn(e, {
  relative: t
} = {}) {
  let {
    basename: n
  } = _.useContext(Xe), r = _.useContext(Qe);
  E(r, `useFormAction must be used inside a RouteContext`);
  let [i] = r.matches.slice(-1), a = {
    ...ht(e || `.`, {
      relative: t
    })
  }, o = st();
  if (e == null) {
    a.search = o.search;
    let e = new URLSearchParams(a.search),
      t = e.getAll(`index`);
    if (t.some(e => e === ``)) {
      e.delete(`index`), t.filter(e => e).forEach(t => e.append(`index`, t));
      let n = e.toString();
      a.search = n ? `?${n}` : ``
    }
  }
  return (!e || e === `.`) && i.route.index && (a.search = a.search ? a.search.replace(/^\?/, `?index&`) : `?index`), n !== `/` && (a.pathname = a.pathname === `/` ? n : je([n, a.pathname])), k(a)
}
var Jn = `react-router-scroll-positions`,
  Yn = {};

function Xn(e, t, n, r) {
  let i = null;
  return r && (i = r(n === `/` ? e : {
    ...e,
    pathname: Se(e.pathname, n) || e.pathname
  }, t)), i ??= e.key, i
}

function Zn({
  getKey: e,
  storageKey: t
} = {}) {
  let {
    router: n
  } = Bn(`useScrollRestoration`), {
    restoreScrollPosition: r,
    preventScrollReset: i
  } = Vn(`useScrollRestoration`), {
    basename: a
  } = _.useContext(Xe), o = st(), s = Mt(), c = jt();
  _.useEffect(() => (window.history.scrollRestoration = `manual`, () => {
    window.history.scrollRestoration = `auto`
  }), []), Qn(_.useCallback(() => {
    if (c.state === `idle`) {
      let t = Xn(o, s, a, e);
      Yn[t] = window.scrollY
    }
    try {
      sessionStorage.setItem(t || Jn, JSON.stringify(Yn))
    } catch (e) {
      D(!1, `Failed to save scroll positions in sessionStorage, <ScrollRestoration /> will not work properly (${e}).`)
    }
    window.history.scrollRestoration = `auto`
  }, [c.state, e, a, o, s, t])), typeof document < `u` && (_.useLayoutEffect(() => {
    try {
      let e = sessionStorage.getItem(t || Jn);
      e && (Yn = JSON.parse(e))
    } catch {}
  }, [t]), _.useLayoutEffect(() => {
    let t = n?.enableScrollRestoration(Yn, () => window.scrollY, e ? (t, n) => Xn(t, n, a, e) : void 0);
    return () => t && t()
  }, [n, a, e]), _.useLayoutEffect(() => {
    if (r !== !1) {
      if (typeof r == `number`) {
        window.scrollTo(0, r);
        return
      }
      try {
        if (o.hash) {
          let e = document.getElementById(decodeURIComponent(o.hash.slice(1)));
          if (e) {
            e.scrollIntoView();
            return
          }
        }
      } catch {
        D(!1, `"${o.hash.slice(1)}" is not a decodable element ID. The view will not scroll to it.`)
      }
      i !== !0 && window.scrollTo(0, 0)
    }
  }, [o, r, i]))
}

function Qn(e, t) {
  let {
    capture: n
  } = t || {};
  _.useEffect(() => {
    let t = n == null ? void 0 : {
      capture: n
    };
    return window.addEventListener(`pagehide`, e, t), () => {
      window.removeEventListener(`pagehide`, e, t)
    }
  }, [e, n])
}

function $n(e, {
  relative: t
} = {}) {
  let n = _.useContext(qe);
  E(n != null, "`useViewTransitionState` must be used within `react-router-dom`'s `RouterProvider`.  Did you accidentally import `RouterProvider` from `react-router`?");
  let {
    basename: r
  } = Bn(`useViewTransitionState`), i = ht(e, {
    relative: t
  });
  if (!n.isTransitioning) return !1;
  let a = Se(n.currentLocation.pathname, r) || n.currentLocation.pathname,
    o = Se(n.nextLocation.pathname, r) || n.nextLocation.pathname;
  return ye(i.pathname, o) != null || ye(i.pathname, a) != null
}
var er = () => window.S2NRI_CFG || {
  base: `/wp-json/s2nri/v1`,
  nonce: ``
};
async function tr(e, t, n, r) {
  let {
    base: i,
    nonce: a
  } = er(), o = n instanceof FormData, s = {
    "X-WP-Nonce": a
  };
  o || (s[`Content-Type`] = `application/json`);
  let q = null,
    qt = null,
    z = r;
  if (!z) {
    q = new AbortController();
    qt = setTimeout(() => q.abort(), 30000);
    z = q.signal
  }
  try {
    let c = await fetch(`${i}${t}`, {
        method: e,
        headers: s,
        body: n ? o ? n : JSON.stringify(n) : void 0,
        credentials: `include`,
        signal: z
      }),
      l = await c.json().catch(() => ({}));
    if (!c.ok) throw Object.assign(Error(l.error || l.message || `HTTP ${c.status}`), {
      status: c.status,
      data: l
    });
    return l
  } finally {
    qt && clearTimeout(qt)
  }
}
var N = (e, t) => tr(`GET`, e, null, t),
  P = (e, t, n) => tr(`POST`, e, t, n),
  nr = (e, t, n) => tr(`PUT`, e, t, n),
  rr = (e, t, n) => tr(`PATCH`, e, t, n),
  ir = (e, t, n) => tr(`DELETE`, e, t, n),
  ar = {
    login: e => P(`/auth/login`, e),
    magicLink: e => P(`/auth/magic-link`, e),
    logout: () => P(`/auth/logout`),
    me: e => N(`/auth/me`, e)
  },
  or = {
    list: (e, t) => N(`/bookings?page=${e}&per_page=12`, t),
    get: (e, t) => N(`/bookings/${e}`, t),
    create: e => P(`/bookings`, e),
    messages: (e, t) => N(`/bookings/${e}/messages`, t),
    sendMsg: (e, t) => P(`/bookings/${e}/messages`, t),
    approve: e => P(`/bookings/${e}/approve-quote`),
    reject: (e, t) => P(`/bookings/${e}/reject-quote`, t),
    uploadDoc: (e, t) => P(`/bookings/${e}/documents`, t),
    tickets: (e, t) => N(`/bookings/${e}/tickets`, t),
    createTicket: (e, t) => P(`/bookings/${e}/tickets`, t)
  },
  sr = {
    get: e => N(`/profile`, e),
    update: e => nr(`/profile`, e),
    stats: e => N(`/customer/dashboard-stats`, e),
    notifPrefs: e => N(`/profile/notification-preferences`, e),
    updatePrefs: e => nr(`/profile/notification-preferences`, e),
    dataExport: () => N(`/profile/data-export`)
  },
  cr = {
    list: (e, t) => N(`/admin/bookings?${new URLSearchParams(Object.fromEntries(Object.entries(e).filter(([,v])=>v!==``&&v!==null&&v!==void 0)))}`, t),
    get: (e, t) => N(`/admin/bookings/${e}`, t),
    updateStatus: (e, t) => rr(`/admin/bookings/${e}/status`, t),
    assign: (e, t) => rr(`/admin/bookings/${e}/assign`, t),
    assignVendor: (e, t) => rr(`/admin/bookings/${e}/vendor`, t),
    delivery: (e, t) => rr(`/admin/bookings/${e}/delivery`, t),
    secStatus: (e, t) => rr(`/admin/bookings/${e}/secondary-status`, t),
    sendMsg: (e, t) => P(`/admin/bookings/${e}/send-message`, t),
    addNote: (e, t) => P(`/admin/bookings/${e}/notes`, t),
    notesHistory: (e, t) => N(`/admin/bookings/${e}/notes-history`, t),
    sendQuote: (e, t) => P(`/admin/bookings/${e}/send-quote`, t),
    eventEmail: (e, t) => P(`/admin/bookings/${e}/event-email`, t),
    uploadDoc: (e, t) => P(`/admin/bookings/${e}/documents`, t),
    auditTrail: (e, t) => N(`/admin/bookings/${e}/audit-trail`, t),
    tickets: (e, t, n) => N(`/admin/bookings/${e}/tickets?search=${t||``}`, n),
    bulkStatus: e => P(`/admin/bookings/bulk-status`, e),
    del: (e, t) => ir(`/admin/bookings/${e}${t?`?hard=true`:``}`),
    assignedInfo: (e, t) => N(`/admin/bookings/${e}/assigned-info`, t),
    formSubs: (e, t) => N(`/admin/form-submissions?${new URLSearchParams(e)}`, t)
  },
  lr = {
    send: (e, t) => P(`/admin/bookings/${e}/send-quote`, t),
    list: (e, t) => N(`/admin/quotes?${new URLSearchParams(e)}`, t)
  },
  ur = {
    list: (e, t) => N(`/admin/customers?${new URLSearchParams(e)}`, t),
    get: (e, t) => N(`/admin/customers/${e}`, t),
    dataExport: (e, t) => N(`/admin/customers/${e}/data-export?format=${t}`),
    erase: (e, t) => ir(`/admin/customers/${e}/data`, t),
    duplicates: e => N(`/admin/customers/duplicates`, e)
  },
  dr = {
    list: e => N(`/admin/services`, e),
    get: (e, t) => N(`/admin/services/${e}`, t),
    create: e => P(`/admin/services`, e),
    update: (e, t) => nr(`/admin/services/${e}`, t),
    del: e => ir(`/admin/services/${e}`),
    formFields: (e, t) => N(`/admin/services/${e}/form-fields`, t),
    addField: (e, t) => P(`/admin/services/${e}/form-fields`, t),
    updateField: (e, t, n) => nr(`/admin/services/${e}/form-fields/${t}`, n),
    delField: (e, t) => ir(`/admin/services/${e}/form-fields/${t}`),
    reorderFields: (e, t) => rr(`/admin/services/${e}/form-fields/reorder`, t)
  },
  fr = {
    dashboard: e => N(`/admin/dashboard`, e),
    extended: e => N(`/admin/dashboard/extended`, e),
    services: (e, t) => N(`/admin/analytics/services?days=${e||90}`, t),
    staff: (e, t) => N(`/admin/analytics/staff?days=${e||90}`, t),
    funnel: (e, t) => N(`/admin/analytics/funnel?days=${e||90}`, t),
    revenueTrend: (e, t) => N(`/admin/analytics/revenue-trend?months=${e||12}`, t),
    customers: (e, t) => N(`/admin/analytics/customers?days=${e||90}`, t)
  },
  pr = {
    getAll: e => N(`/admin/settings`, e),
    getPublic: e => N(`/settings/public`, e),
    update: e => P(`/admin/settings`, e),
    smtpTest: e => N(`/admin/smtp-test?to=${encodeURIComponent(e)}`),
    waTest: e => P(`/admin/whatsapp/test`, e)
  },
  mr = {
    health: e => N(`/admin/platform-health`, e),
    phase3: e => N(`/admin/settings/phase3`, e)
  },
  hr = {
    csv: e => P(`/admin/export/bookings/bulk`, {
      ids: e
    }),
    json: e => P(`/admin/export/bookings/bulk-json`, {
      ids: e
    })
  },
  gr = {
    list: e => N(`/admin/email-templates`, e),
    update: (e, t) => tr(`PUT`, `/admin/email-templates/${e}`, t),
    reset: e => P(`/admin/email-templates/${e}/reset`),
    duplicate: e => P(`/admin/email-templates/${e}/duplicate`),
    testEmail: (e, t) => P(`/admin/email-templates/${e}/test-email`, {
      to: t
    }),
    create: e => P(`/admin/email-templates`, e),
    del: e => ir(`/admin/email-templates/${e}`)
  },
  _r = {
    list: (e, t) => N(`/admin/holidays?year=${e||new Date().getFullYear()}`, t),
    create: e => P(`/admin/holidays`, e),
    del: e => ir(`/admin/holidays/${e}`),
    calculate: e => P(`/admin/holidays/calculate`, e)
  },
  vr = {
    list: e => N(`/admin/quick-replies`, e),
    create: e => P(`/admin/quick-replies`, e),
    update: (e, t) => tr(`PUT`, `/admin/quick-replies/${e}`, t),
    del: e => ir(`/admin/quick-replies/${e}`)
  },
  yr = {
    history: (e, t) => N(`/admin/bookings/${e}/communications`, t),
    send: (e, t) => P(`/admin/bookings/${e}/communications`, t)
  },
  br = {
    list: (e, t) => N(`/admin/form-submissions?${new URLSearchParams(e)}`, t),
    export: (e, t) => `${er().base}/admin/form-submissions/${e}/export?format=${t}&_nonce=${er().nonce}`
  },
  xr = {
    list: (e, t) => N(`/admin/vendors?search=${encodeURIComponent(e||``)}`, t),
    create: e => P(`/admin/vendors`, e),
    update: (e, t) => tr(`PUT`, `/admin/vendors/${e}`, t),
    del: e => ir(`/admin/vendors/${e}`)
  },
  Sr = {
    list: e => N(`/request-types`, e)
  },
  Cr = {
    list: e => N(`/admin/request-types`, e),
    create: e => P(`/admin/request-types`, e),
    update: (e, t) => tr(`PUT`, `/admin/request-types/${e}`, t),
    toggle: e => tr(`PATCH`, `/admin/request-types/${e}/toggle`),
    del: e => ir(`/admin/request-types/${e}`)
  },
  wr = {
    list: (e, t, n) => N(`/admin/form-fields/${e}/options?${new URLSearchParams(t||{})}`, n),
    create: (e, t) => P(`/admin/form-fields/${e}/options`, t),
    update: (e, t, n) => tr(`PUT`, `/admin/form-fields/${e}/options/${t}`, n),
    del: (e, t) => ir(`/admin/form-fields/${e}/options/${t}`),
    bulkDelete: (e, t) => P(`/admin/form-fields/${e}/options/bulk-delete`, t),
    bulkImport: (e, t) => P(`/admin/form-fields/${e}/options/bulk-import`, t),
    search: (e, t, n) => N(`/form-fields/${e}/options/search?q=${encodeURIComponent(t)}`, n)
  },
  Tr = {
    json: e => P(`/admin/export/bookings/bulk-json`, {
      ids: e
    })
  },
  Er = o((e => {
    var t = Symbol.for(`react.transitional.element`),
      n = Symbol.for(`react.fragment`);

    function r(e, n, r) {
      var i = null;
      if (r !== void 0 && (i = `` + r), n.key !== void 0 && (i = `` + n.key), `key` in n)
        for (var a in r = {}, n) a !== `key` && (r[a] = n[a]);
      else r = n;
      return n = r.ref, {
        $$typeof: t,
        type: e,
        key: i,
        ref: n === void 0 ? null : n,
        props: r
      }
    }
    e.Fragment = n, e.jsx = r, e.jsxs = r
  })),
  F = o(((e, t) => {
    t.exports = Er()
  }))(),
  Dr = (0, _.createContext)(null);

function Or({
  children: e
}) {
  let [t, n] = (0, _.useState)(void 0), [r, i] = (0, _.useState)(!0), a = (0, _.useCallback)(async () => {
    try {
      let e = await ar.me();
      n(e.user || e)
    } catch {
      n(null)
    } finally {
      i(!1)
    }
  }, []);
  return (0, _.useEffect)(() => {
    a()
  }, [a]), (0, F.jsx)(Dr.Provider, {
    value: {
      user: t,
      loading: r,
      login: async e => {
        let t = await ar.login(e);
        return await a(), t
      },
      logout: async () => {
        await ar.logout().catch(() => {}), n(null);
        let e = window.S2NRI_CFG?.loginUrl,
          t = window.S2NRI_CFG?.basePath || `/`;
        window.location.href = e || t + `/login`
      },
      refetch: a
    },
    children: e
  })
}
var kr = () => (0, _.useContext)(Dr),
  Ar = (...e) => e.filter((e, t, n) => !!e && e.trim() !== `` && n.indexOf(e) === t).join(` `).trim(),
  jr = e => e.replace(/([a-z0-9])([A-Z])/g, `$1-$2`).toLowerCase(),
  Mr = e => e.replace(/^([A-Z])|[\s-_]+(\w)/g, (e, t, n) => n ? n.toUpperCase() : t.toLowerCase()),
  Nr = e => {
    let t = Mr(e);
    return t.charAt(0).toUpperCase() + t.slice(1)
  },
  Pr = {
    xmlns: `http://www.w3.org/2000/svg`,
    width: 24,
    height: 24,
    viewBox: `0 0 24 24`,
    fill: `none`,
    stroke: `currentColor`,
    strokeWidth: 2,
    strokeLinecap: `round`,
    strokeLinejoin: `round`
  },
  Fr = e => {
    for (let t in e)
      if (t.startsWith(`aria-`) || t === `role` || t === `title`) return !0;
    return !1
  },
  Ir = (0, _.createContext)({}),
  Lr = () => (0, _.useContext)(Ir),
  Rr = (0, _.forwardRef)(({
    color: e,
    size: t,
    strokeWidth: n,
    absoluteStrokeWidth: r,
    className: i = ``,
    children: a,
    iconNode: o,
    ...s
  }, c) => {
    let {
      size: l = 24,
      strokeWidth: u = 2,
      absoluteStrokeWidth: d = !1,
      color: f = `currentColor`,
      className: p = ``
    } = Lr() ?? {}, m = r ?? d ? Number(n ?? u) * 24 / Number(t ?? l) : n ?? u;
    return (0, _.createElement)(`svg`, {
      ref: c,
      ...Pr,
      width: t ?? l ?? Pr.width,
      height: t ?? l ?? Pr.height,
      stroke: e ?? f,
      strokeWidth: m,
      className: Ar(`lucide`, p, i),
      ...!a && !Fr(s) && {
        "aria-hidden": `true`
      },
      ...s
    }, [...o.map(([e, t]) => (0, _.createElement)(e, t)), ...Array.isArray(a) ? a : [a]])
  }),
  I = (e, t) => {
    let n = (0, _.forwardRef)(({
      className: n,
      ...r
    }, i) => (0, _.createElement)(Rr, {
      ref: i,
      iconNode: t,
      className: Ar(`lucide-${jr(Nr(e))}`, `lucide-${e}`, n),
      ...r
    }));
    return n.displayName = Nr(e), n
  },
  zr = I(`arrow-left`, [
    [`path`, {
      d: `m12 19-7-7 7-7`,
      key: `1l729n`
    }],
    [`path`, {
      d: `M19 12H5`,
      key: `x3x0zl`
    }]
  ]),
  Br = I(`arrow-right`, [
    [`path`, {
      d: `M5 12h14`,
      key: `1ays0h`
    }],
    [`path`, {
      d: `m12 5 7 7-7 7`,
      key: `xquz4c`
    }]
  ]),
  Vr = I(`at-sign`, [
    [`circle`, {
      cx: `12`,
      cy: `12`,
      r: `4`,
      key: `4exip2`
    }],
    [`path`, {
      d: `M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-4 8`,
      key: `7n84p3`
    }]
  ]),
  Hr = I(`bell`, [
    [`path`, {
      d: `M10.268 21a2 2 0 0 0 3.464 0`,
      key: `vwvbt9`
    }],
    [`path`, {
      d: `M3.262 15.326A1 1 0 0 0 4 17h16a1 1 0 0 0 .74-1.673C19.41 13.956 18 12.499 18 8A6 6 0 0 0 6 8c0 4.499-1.411 5.956-2.738 7.326`,
      key: `11g9vi`
    }]
  ]),
  Ur = I(`building-2`, [
    [`path`, {
      d: `M10 12h4`,
      key: `a56b0p`
    }],
    [`path`, {
      d: `M10 8h4`,
      key: `1sr2af`
    }],
    [`path`, {
      d: `M14 21v-3a2 2 0 0 0-4 0v3`,
      key: `1rgiei`
    }],
    [`path`, {
      d: `M6 10H4a2 2 0 0 0-2 2v7a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-2`,
      key: `secmi2`
    }],
    [`path`, {
      d: `M6 21V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v16`,
      key: `16ra0t`
    }]
  ]),
  Wr = I(`calculator`, [
    [`rect`, {
      width: `16`,
      height: `20`,
      x: `4`,
      y: `2`,
      rx: `2`,
      key: `1nb95v`
    }],
    [`line`, {
      x1: `8`,
      x2: `16`,
      y1: `6`,
      y2: `6`,
      key: `x4nwl0`
    }],
    [`line`, {
      x1: `16`,
      x2: `16`,
      y1: `14`,
      y2: `18`,
      key: `wjye3r`
    }],
    [`path`, {
      d: `M16 10h.01`,
      key: `1m94wz`
    }],
    [`path`, {
      d: `M12 10h.01`,
      key: `1nrarc`
    }],
    [`path`, {
      d: `M8 10h.01`,
      key: `19clt8`
    }],
    [`path`, {
      d: `M12 14h.01`,
      key: `1etili`
    }],
    [`path`, {
      d: `M8 14h.01`,
      key: `6423bh`
    }],
    [`path`, {
      d: `M12 18h.01`,
      key: `mhygvu`
    }],
    [`path`, {
      d: `M8 18h.01`,
      key: `lrp35t`
    }]
  ]),
  Gr = I(`calendar`, [
    [`path`, {
      d: `M8 2v4`,
      key: `1cmpym`
    }],
    [`path`, {
      d: `M16 2v4`,
      key: `4m81vk`
    }],
    [`rect`, {
      width: `18`,
      height: `18`,
      x: `3`,
      y: `4`,
      rx: `2`,
      key: `1hopcy`
    }],
    [`path`, {
      d: `M3 10h18`,
      key: `8toen8`
    }]
  ]),
  Kr = I(`chart-column`, [
    [`path`, {
      d: `M3 3v16a2 2 0 0 0 2 2h16`,
      key: `c24i48`
    }],
    [`path`, {
      d: `M18 17V9`,
      key: `2bz60n`
    }],
    [`path`, {
      d: `M13 17V5`,
      key: `1frdt8`
    }],
    [`path`, {
      d: `M8 17v-3`,
      key: `17ska0`
    }]
  ]),
  qr = I(`chevron-down`, [
    [`path`, {
      d: `m6 9 6 6 6-6`,
      key: `qrunsl`
    }]
  ]),
  Jr = I(`chevron-left`, [
    [`path`, {
      d: `m15 18-6-6 6-6`,
      key: `1wnfg3`
    }]
  ]),
  Yr = I(`chevron-right`, [
    [`path`, {
      d: `m9 18 6-6-6-6`,
      key: `mthhwq`
    }]
  ]),
  Xr = I(`chevron-up`, [
    [`path`, {
      d: `m18 15-6-6-6 6`,
      key: `153udz`
    }]
  ]),
  Zr = I(`circle-alert`, [
    [`circle`, {
      cx: `12`,
      cy: `12`,
      r: `10`,
      key: `1mglay`
    }],
    [`line`, {
      x1: `12`,
      x2: `12`,
      y1: `8`,
      y2: `12`,
      key: `1pkeuh`
    }],
    [`line`, {
      x1: `12`,
      x2: `12.01`,
      y1: `16`,
      y2: `16`,
      key: `4dfq90`
    }]
  ]),
  Qr = I(`circle-check-big`, [
    [`path`, {
      d: `M21.801 10A10 10 0 1 1 17 3.335`,
      key: `yps3ct`
    }],
    [`path`, {
      d: `m9 11 3 3L22 4`,
      key: `1pflzl`
    }]
  ]),
  $r = I(`circle-x`, [
    [`circle`, {
      cx: `12`,
      cy: `12`,
      r: `10`,
      key: `1mglay`
    }],
    [`path`, {
      d: `m15 9-6 6`,
      key: `1uzhvr`
    }],
    [`path`, {
      d: `m9 9 6 6`,
      key: `z0biqf`
    }]
  ]),
  ei = I(`clipboard-list`, [
    [`rect`, {
      width: `8`,
      height: `4`,
      x: `8`,
      y: `2`,
      rx: `1`,
      ry: `1`,
      key: `tgr4d6`
    }],
    [`path`, {
      d: `M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2`,
      key: `116196`
    }],
    [`path`, {
      d: `M12 11h4`,
      key: `1jrz19`
    }],
    [`path`, {
      d: `M12 16h4`,
      key: `n85exb`
    }],
    [`path`, {
      d: `M8 11h.01`,
      key: `1dfujw`
    }],
    [`path`, {
      d: `M8 16h.01`,
      key: `18s6g9`
    }]
  ]),
  ti = I(`clock`, [
    [`circle`, {
      cx: `12`,
      cy: `12`,
      r: `10`,
      key: `1mglay`
    }],
    [`path`, {
      d: `M12 6v6l4 2`,
      key: `mmk7yg`
    }]
  ]),
  ni = I(`copy`, [
    [`rect`, {
      width: `14`,
      height: `14`,
      x: `8`,
      y: `8`,
      rx: `2`,
      ry: `2`,
      key: `17jyea`
    }],
    [`path`, {
      d: `M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2`,
      key: `zix9uf`
    }]
  ]),
  ri = I(`credit-card`, [
    [`rect`, {
      width: `20`,
      height: `14`,
      x: `2`,
      y: `5`,
      rx: `2`,
      key: `ynyp8z`
    }],
    [`line`, {
      x1: `2`,
      x2: `22`,
      y1: `10`,
      y2: `10`,
      key: `1b3vmo`
    }]
  ]),
  ii = I(`dollar-sign`, [
    [`line`, {
      x1: `12`,
      x2: `12`,
      y1: `2`,
      y2: `22`,
      key: `7eqyqh`
    }],
    [`path`, {
      d: `M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6`,
      key: `1b0p4s`
    }]
  ]),
  ai = I(`download`, [
    [`path`, {
      d: `M12 15V3`,
      key: `m9g1x1`
    }],
    [`path`, {
      d: `M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4`,
      key: `ih7n3h`
    }],
    [`path`, {
      d: `m7 10 5 5 5-5`,
      key: `brsn70`
    }]
  ]),
  oi = I(`file-text`, [
    [`path`, {
      d: `M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z`,
      key: `1oefj6`
    }],
    [`path`, {
      d: `M14 2v5a1 1 0 0 0 1 1h5`,
      key: `wfsgrz`
    }],
    [`path`, {
      d: `M10 9H8`,
      key: `b1mrlr`
    }],
    [`path`, {
      d: `M16 13H8`,
      key: `t4e002`
    }],
    [`path`, {
      d: `M16 17H8`,
      key: `z1uh3a`
    }]
  ]),
  si = I(`grip-vertical`, [
    [`circle`, {
      cx: `9`,
      cy: `12`,
      r: `1`,
      key: `1vctgf`
    }],
    [`circle`, {
      cx: `9`,
      cy: `5`,
      r: `1`,
      key: `hp0tcf`
    }],
    [`circle`, {
      cx: `9`,
      cy: `19`,
      r: `1`,
      key: `fkjjf6`
    }],
    [`circle`, {
      cx: `15`,
      cy: `12`,
      r: `1`,
      key: `1tmaij`
    }],
    [`circle`, {
      cx: `15`,
      cy: `5`,
      r: `1`,
      key: `19l28e`
    }],
    [`circle`, {
      cx: `15`,
      cy: `19`,
      r: `1`,
      key: `f4zoj3`
    }]
  ]),
  ci = I(`info`, [
    [`circle`, {
      cx: `12`,
      cy: `12`,
      r: `10`,
      key: `1mglay`
    }],
    [`path`, {
      d: `M12 16v-4`,
      key: `1dtifu`
    }],
    [`path`, {
      d: `M12 8h.01`,
      key: `e9boi3`
    }]
  ]),
  li = I(`layout-dashboard`, [
    [`rect`, {
      width: `7`,
      height: `9`,
      x: `3`,
      y: `3`,
      rx: `1`,
      key: `10lvy0`
    }],
    [`rect`, {
      width: `7`,
      height: `5`,
      x: `14`,
      y: `3`,
      rx: `1`,
      key: `16une8`
    }],
    [`rect`, {
      width: `7`,
      height: `9`,
      x: `14`,
      y: `12`,
      rx: `1`,
      key: `1hutg5`
    }],
    [`rect`, {
      width: `7`,
      height: `5`,
      x: `3`,
      y: `16`,
      rx: `1`,
      key: `ldoo1y`
    }]
  ]),
  ui = I(`loader-circle`, [
    [`path`, {
      d: `M21 12a9 9 0 1 1-6.219-8.56`,
      key: `13zald`
    }]
  ]),
  di = I(`lock`, [
    [`rect`, {
      width: `18`,
      height: `11`,
      x: `3`,
      y: `11`,
      rx: `2`,
      ry: `2`,
      key: `1w4ew1`
    }],
    [`path`, {
      d: `M7 11V7a5 5 0 0 1 10 0v4`,
      key: `fwvmzm`
    }]
  ]),
  fi = I(`log-out`, [
    [`path`, {
      d: `m16 17 5-5-5-5`,
      key: `1bji2h`
    }],
    [`path`, {
      d: `M21 12H9`,
      key: `dn1m92`
    }],
    [`path`, {
      d: `M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4`,
      key: `1uf3rs`
    }]
  ]),
  pi = I(`mail`, [
    [`path`, {
      d: `m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7`,
      key: `132q7q`
    }],
    [`rect`, {
      x: `2`,
      y: `4`,
      width: `20`,
      height: `16`,
      rx: `2`,
      key: `izxlao`
    }]
  ]),
  mi = I(`menu`, [
    [`path`, {
      d: `M4 5h16`,
      key: `1tepv9`
    }],
    [`path`, {
      d: `M4 12h16`,
      key: `1lakjw`
    }],
    [`path`, {
      d: `M4 19h16`,
      key: `1djgab`
    }]
  ]),
  hi = I(`message-square`, [
    [`path`, {
      d: `M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z`,
      key: `18887p`
    }]
  ]),
  gi = I(`package`, [
    [`path`, {
      d: `M11 21.73a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73z`,
      key: `1a0edw`
    }],
    [`path`, {
      d: `M12 22V12`,
      key: `d0xqtd`
    }],
    [`polyline`, {
      points: `3.29 7 12 12 20.71 7`,
      key: `ousv84`
    }],
    [`path`, {
      d: `m7.5 4.27 9 5.15`,
      key: `1c824w`
    }]
  ]),
  _i = I(`pen`, [
    [`path`, {
      d: `M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z`,
      key: `1a8usu`
    }]
  ]),
  vi = I(`phone`, [
    [`path`, {
      d: `M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384`,
      key: `9njp5v`
    }]
  ]),
  yi = I(`plus`, [
    [`path`, {
      d: `M5 12h14`,
      key: `1ays0h`
    }],
    [`path`, {
      d: `M12 5v14`,
      key: `s699le`
    }]
  ]),
  bi = I(`refresh-cw`, [
    [`path`, {
      d: `M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8`,
      key: `v9h5vc`
    }],
    [`path`, {
      d: `M21 3v5h-5`,
      key: `1q7to0`
    }],
    [`path`, {
      d: `M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16`,
      key: `3uifl3`
    }],
    [`path`, {
      d: `M8 16H3v5`,
      key: `1cv678`
    }]
  ]),
  xi = I(`rotate-ccw`, [
    [`path`, {
      d: `M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8`,
      key: `1357e3`
    }],
    [`path`, {
      d: `M3 3v5h5`,
      key: `1xhq8a`
    }]
  ]),
  Si = I(`save`, [
    [`path`, {
      d: `M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z`,
      key: `1c8476`
    }],
    [`path`, {
      d: `M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7`,
      key: `1ydtos`
    }],
    [`path`, {
      d: `M7 3v4a1 1 0 0 0 1 1h7`,
      key: `t51u73`
    }]
  ]),
  Ci = I(`search`, [
    [`path`, {
      d: `m21 21-4.34-4.34`,
      key: `14j7rj`
    }],
    [`circle`, {
      cx: `11`,
      cy: `11`,
      r: `8`,
      key: `4ej97u`
    }]
  ]),
  wi = I(`send`, [
    [`path`, {
      d: `M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z`,
      key: `1ffxy3`
    }],
    [`path`, {
      d: `m21.854 2.147-10.94 10.939`,
      key: `12cjpa`
    }]
  ]),
  Ti = I(`settings`, [
    [`path`, {
      d: `M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915`,
      key: `1i5ecw`
    }],
    [`circle`, {
      cx: `12`,
      cy: `12`,
      r: `3`,
      key: `1v7zrd`
    }]
  ]),
  Ei = I(`settings-2`, [
    [`path`, {
      d: `M14 17H5`,
      key: `gfn3mx`
    }],
    [`path`, {
      d: `M19 7h-9`,
      key: `6i9tg`
    }],
    [`circle`, {
      cx: `17`,
      cy: `17`,
      r: `3`,
      key: `18b49y`
    }],
    [`circle`, {
      cx: `7`,
      cy: `7`,
      r: `3`,
      key: `dfmy0x`
    }]
  ]),
  Di = I(`square-check-big`, [
    [`path`, {
      d: `M21 10.656V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12.344`,
      key: `2acyp4`
    }],
    [`path`, {
      d: `m9 11 3 3L22 4`,
      key: `1pflzl`
    }]
  ]),
  Oi = I(`tag`, [
    [`path`, {
      d: `M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z`,
      key: `vktsd0`
    }],
    [`circle`, {
      cx: `7.5`,
      cy: `7.5`,
      r: `.5`,
      fill: `currentColor`,
      key: `kqv944`
    }]
  ]),
  ki = I(`ticket`, [
    [`path`, {
      d: `M2 9a3 3 0 0 1 0 6v2a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-2a3 3 0 0 1 0-6V7a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z`,
      key: `qn84l0`
    }],
    [`path`, {
      d: `M13 5v2`,
      key: `dyzc3o`
    }],
    [`path`, {
      d: `M13 17v2`,
      key: `1ont0d`
    }],
    [`path`, {
      d: `M13 11v2`,
      key: `1wjjxi`
    }]
  ]),
  Ai = I(`toggle-left`, [
    [`circle`, {
      cx: `9`,
      cy: `12`,
      r: `3`,
      key: `u3jwor`
    }],
    [`rect`, {
      width: `20`,
      height: `14`,
      x: `2`,
      y: `5`,
      rx: `7`,
      key: `g7kal2`
    }]
  ]),
  ji = I(`toggle-right`, [
    [`circle`, {
      cx: `15`,
      cy: `12`,
      r: `3`,
      key: `1afu0r`
    }],
    [`rect`, {
      width: `20`,
      height: `14`,
      x: `2`,
      y: `5`,
      rx: `7`,
      key: `g7kal2`
    }]
  ]),
  Mi = I(`trash-2`, [
    [`path`, {
      d: `M10 11v6`,
      key: `nco0om`
    }],
    [`path`, {
      d: `M14 11v6`,
      key: `outv1u`
    }],
    [`path`, {
      d: `M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6`,
      key: `miytrc`
    }],
    [`path`, {
      d: `M3 6h18`,
      key: `d0wm0j`
    }],
    [`path`, {
      d: `M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2`,
      key: `e791ji`
    }]
  ]),
  Ni = I(`triangle-alert`, [
    [`path`, {
      d: `m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3`,
      key: `wmoenq`
    }],
    [`path`, {
      d: `M12 9v4`,
      key: `juzpu7`
    }],
    [`path`, {
      d: `M12 17h.01`,
      key: `p32p05`
    }]
  ]),
  Pi = I(`truck`, [
    [`path`, {
      d: `M14 18V6a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2v11a1 1 0 0 0 1 1h2`,
      key: `wrbu53`
    }],
    [`path`, {
      d: `M15 18H9`,
      key: `1lyqi6`
    }],
    [`path`, {
      d: `M19 18h2a1 1 0 0 0 1-1v-3.65a1 1 0 0 0-.22-.624l-3.48-4.35A1 1 0 0 0 17.52 8H14`,
      key: `lysw3i`
    }],
    [`circle`, {
      cx: `17`,
      cy: `18`,
      r: `2`,
      key: `332jqn`
    }],
    [`circle`, {
      cx: `7`,
      cy: `18`,
      r: `2`,
      key: `19iecd`
    }]
  ]),
  Fi = I(`upload`, [
    [`path`, {
      d: `M12 3v12`,
      key: `1x0j5s`
    }],
    [`path`, {
      d: `m17 8-5-5-5 5`,
      key: `7q97r8`
    }],
    [`path`, {
      d: `M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4`,
      key: `ih7n3h`
    }]
  ]),
  Ii = I(`users`, [
    [`path`, {
      d: `M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2`,
      key: `1yyitq`
    }],
    [`path`, {
      d: `M16 3.128a4 4 0 0 1 0 7.744`,
      key: `16gr8j`
    }],
    [`path`, {
      d: `M22 21v-2a4 4 0 0 0-3-3.87`,
      key: `kshegd`
    }],
    [`circle`, {
      cx: `9`,
      cy: `7`,
      r: `4`,
      key: `nufk8`
    }]
  ]),
  L = I(`wrench`, [
    [`path`, {
      d: `M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.106-3.105c.32-.322.863-.22.983.218a6 6 0 0 1-8.259 7.057l-7.91 7.91a1 1 0 0 1-2.999-3l7.91-7.91a6 6 0 0 1 7.057-8.259c.438.12.54.662.219.984z`,
      key: `1ngwbx`
    }]
  ]),
  Li = I(`x`, [
    [`path`, {
      d: `M18 6 6 18`,
      key: `1bl5f8`
    }],
    [`path`, {
      d: `m6 6 12 12`,
      key: `d8bk6v`
    }]
  ]),
  Ri = I(`zap`, [
    [`path`, {
      d: `M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z`,
      key: `1xq2db`
    }]
  ]),
  zi = (0, _.createContext)(null),
  Bi = {
    success: (0, F.jsx)(Qr, {
      size: 16
    }),
    error: (0, F.jsx)(Zr, {
      size: 16
    }),
    info: (0, F.jsx)(ci, {
      size: 16
    })
  },
  Vi = {
    success: {
      bg: `var(--green-bg)`,
      border: `var(--green-border)`,
      color: `var(--green-dark)`
    },
    error: {
      bg: `var(--red-bg)`,
      border: `var(--red-border)`,
      color: `var(--red-dark)`
    },
    info: {
      bg: `var(--brand-light)`,
      border: `var(--brand-mid)`,
      color: `var(--brand-dark)`
    }
  };

function Hi({
  id: e,
  type: t = `info`,
  message: n,
  onDismiss: r
}) {
  (0, _.useEffect)(() => {
    let t = setTimeout(() => r(e), 4e3);
    return () => clearTimeout(t)
  }, [e, r]);
  let i = Vi[t] || Vi.info;
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      alignItems: `flex-start`,
      gap: 10,
      background: i.bg,
      border: `1px solid ${i.border}`,
      color: i.color,
      borderRadius: `var(--r)`,
      padding: `12px 14px`,
      boxShadow: `var(--shadow-md)`,
      fontSize: 14,
      fontWeight: 500,
      animation: `slideUp 200ms ease both`,
      pointerEvents: `all`,
      maxWidth: 340,
      minWidth: 220
    },
    children: [(0, F.jsx)(`span`, {
      style: {
        flexShrink: 0,
        marginTop: 1
      },
      children: Bi[t]
    }), (0, F.jsx)(`span`, {
      style: {
        flex: 1,
        lineHeight: 1.4
      },
      children: n
    }), (0, F.jsx)(`button`, {
      onClick: () => r(e),
      style: {
        background: `none`,
        border: `none`,
        cursor: `pointer`,
        color: `inherit`,
        opacity: .6,
        padding: 0,
        marginTop: 1,
        flexShrink: 0
      },
      "aria-label": `Dismiss`,
      children: (0, F.jsx)(Li, {
        size: 14
      })
    })]
  })
}

function Ui({
  children: e
}) {
  let [t, n] = (0, _.useState)([]), r = (0, _.useCallback)(e => n(t => t.filter(t => t.id !== e)), []), i = (0, _.useCallback)((e, t = `info`) => {
    let r = Date.now() + Math.random();
    n(n => [...n.slice(-4), {
      id: r,
      message: e,
      type: t
    }])
  }, []);
  return (0, F.jsxs)(zi.Provider, {
    value: i,
    children: [e, (0, F.jsx)(`div`, {
      id: `toast-root`,
      "aria-live": `polite`,
      children: t.map(e => (0, F.jsx)(Hi, {
        ...e,
        onDismiss: r
      }, e.id))
    })]
  })
}
var R = () => (0, _.useContext)(zi);

function Wi({
  size: e = 18,
  color: t = `var(--brand)`
}) {
  return (0, F.jsx)(ui, {
    size: e,
    style: {
      color: t,
      animation: `spin 0.8s linear infinite`
    },
    "aria-label": `Loading`
  })
}
var Gi = {
    primary: {
      background: `var(--brand)`,
      color: `#fff`,
      border: `none`
    },
    secondary: {
      background: `var(--surface)`,
      color: `var(--text)`,
      border: `1px solid var(--border)`
    },
    danger: {
      background: `var(--red)`,
      color: `#fff`,
      border: `none`
    },
    ghost: {
      background: `transparent`,
      color: `var(--muted)`,
      border: `1px solid var(--border)`
    },
    outline: {
      background: `transparent`,
      color: `var(--brand)`,
      border: `1px solid var(--brand)`
    },
    success: {
      background: `var(--green)`,
      color: `#fff`,
      border: `none`
    }
  },
  Ki = {
    sm: {
      padding: `6px 12px`,
      fontSize: 13,
      gap: 5
    },
    md: {
      padding: `9px 18px`,
      fontSize: 14,
      gap: 6
    },
    lg: {
      padding: `12px 24px`,
      fontSize: 15,
      gap: 7
    }
  };

function z({
  children: e,
  variant: t = `primary`,
  size: n = `md`,
  loading: r,
  disabled: i,
  icon: a,
  fullWidth: o,
  style: s,
  ...c
}) {
  let l = Gi[t] || Gi.primary,
    u = Ki[n];
  return (0, F.jsxs)(`button`, {
    disabled: i || r,
    style: {
      display: `inline-flex`,
      alignItems: `center`,
      justifyContent: `center`,
      gap: u.gap,
      padding: u.padding,
      fontSize: u.fontSize,
      fontWeight: 600,
      lineHeight: 1.4,
      borderRadius: `var(--r)`,
      cursor: i || r ? `not-allowed` : `pointer`,
      opacity: i || r ? .65 : 1,
      transition: `var(--t)`,
      whiteSpace: `nowrap`,
      width: o ? `100%` : void 0,
      fontFamily: `inherit`,
      ...l,
      ...s
    },
    ...c,
    children: [r ? (0, F.jsx)(Wi, {
      size: 14,
      color: `currentColor`
    }) : a, e]
  })
}
var qi = {
  submitted: {
    bg: `var(--brand-light)`,
    color: `var(--brand-dark)`
  },
  under_review: {
    bg: `var(--amber-bg)`,
    color: `var(--amber-dark)`
  },
  quote_sent: {
    bg: `var(--purple-bg)`,
    color: `var(--purple)`
  },
  quote_approved: {
    bg: `var(--teal-bg)`,
    color: `var(--teal)`
  },
  in_progress: {
    bg: `var(--brand-light)`,
    color: `var(--brand)`
  },
  docs_requested: {
    bg: `var(--orange-bg)`,
    color: `var(--orange)`
  },
  docs_received: {
    bg: `var(--teal-bg)`,
    color: `var(--teal-dark, #096b67)`
  },
  processing: {
    bg: `var(--purple-bg)`,
    color: `var(--purple)`
  },
  completed: {
    bg: `var(--green-bg)`,
    color: `var(--green-dark)`
  },
  cancelled: {
    bg: `var(--red-bg)`,
    color: `var(--red-dark)`
  },
  on_hold: {
    bg: `var(--surface-3)`,
    color: `var(--muted)`
  },
  service_not_available: {
    bg: `var(--surface-3)`,
    color: `var(--muted)`
  },
  pending: {
    bg: `var(--amber-bg)`,
    color: `var(--amber-dark)`
  },
  verified: {
    bg: `var(--green-bg)`,
    color: `var(--green-dark)`
  },
  failed: {
    bg: `var(--red-bg)`,
    color: `var(--red-dark)`
  },
  bank_transfer_pending: {
    bg: `var(--orange-bg)`,
    color: `var(--orange)`
  }
};

function Ji({
  status: e,
  size: t = `sm`
}) {
  let n = qi[e] || {
      bg: `var(--surface-2)`,
      color: `var(--muted)`
    },
    r = (e || ``).replace(/_/g, ` `).replace(/\b\w/g, e => e.toUpperCase());
  return (0, F.jsx)(`span`, {
    style: {
      display: `inline-block`,
      padding: t === `lg` ? `5px 14px` : `3px 10px`,
      fontSize: t === `lg` ? 13 : 11,
      fontWeight: 600,
      lineHeight: 1.4,
      borderRadius: `var(--r-full)`,
      whiteSpace: `nowrap`,
      background: n.bg,
      color: n.color
    },
    children: r
  })
}

function B({
  children: e,
  style: t,
  padding: n = `20px`,
  ...r
}) {
  return (0, F.jsx)(`div`, {
    style: {
      background: `var(--surface)`,
      border: `1px solid var(--border)`,
      borderRadius: `var(--r-lg)`,
      boxShadow: `var(--shadow)`,
      padding: n,
      ...t
    },
    ...r,
    children: e
  })
}
var Yi = {
  padding: `9px 13px`,
  fontSize: 14,
  borderRadius: `var(--r)`,
  color: `var(--text)`,
  background: `var(--surface)`,
  width: `100%`,
  fontFamily: `inherit`,
  transition: `border-color var(--t)`,
  outline: `none`
};

function Xi({
  label: e,
  hint: t,
  error: n,
  required: r,
  style: i,
  inputStyle: a,
  as: o,
  rows: s,
  ...c
}) {
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      gap: 5,
      ...i
    },
    children: [e && (0, F.jsxs)(`label`, {
      style: {
        fontSize: 13,
        fontWeight: 600,
        color: `var(--text-2)`
      },
      children: [e, r && (0, F.jsx)(`span`, {
        style: {
          color: `var(--red)`,
          marginLeft: 2
        },
        children: `*`
      })]
    }), o === `textarea` ? (0, F.jsx)(`textarea`, {
      rows: s || 3,
      style: {
        ...Yi,
        border: `1px solid ${n?`var(--red)`:`var(--border)`}`,
        resize: `vertical`,
        ...a
      },
      ...c
    }) : (0, F.jsx)(`input`, {
      style: {
        ...Yi,
        border: `1px solid ${n?`var(--red)`:`var(--border)`}`,
        ...a
      },
      ...c
    }), t && !n && (0, F.jsx)(`span`, {
      style: {
        fontSize: 12,
        color: `var(--muted)`
      },
      children: t
    }), n && (0, F.jsx)(`span`, {
      style: {
        fontSize: 12,
        color: `var(--red)`
      },
      children: n
    })]
  })
}

function Zi({
  label: e,
  hint: t,
  error: n,
  required: r,
  options: i = [],
  placeholder: a,
  style: o,
  ...s
}) {
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      gap: 5,
      ...o
    },
    children: [e && (0, F.jsxs)(`label`, {
      style: {
        fontSize: 13,
        fontWeight: 600,
        color: `var(--text-2)`
      },
      children: [e, r && (0, F.jsx)(`span`, {
        style: {
          color: `var(--red)`,
          marginLeft: 2
        },
        children: `*`
      })]
    }), (0, F.jsxs)(`select`, {
      style: {
        ...Yi,
        border: `1px solid ${n?`var(--red)`:`var(--border)`}`,
        appearance: `none`,
        cursor: `pointer`,
        paddingRight: 32,
        backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%235a7290' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E")`,
        backgroundRepeat: `no-repeat`,
        backgroundPosition: `right 12px center`
      },
      ...s,
      children: [a && (0, F.jsx)(`option`, {
        value: ``,
        children: a
      }), i.map(e => (0, F.jsx)(`option`, {
        value: e.value ?? e,
        children: e.label ?? e
      }, e.value ?? e))]
    }), t && !n && (0, F.jsx)(`span`, {
      style: {
        fontSize: 12,
        color: `var(--muted)`
      },
      children: t
    }), n && (0, F.jsx)(`span`, {
      style: {
        fontSize: 12,
        color: `var(--red)`
      },
      children: n
    })]
  })
}

function Qi({
  icon: e,
  title: t,
  desc: n,
  action: r
}) {
  return (0, F.jsxs)(`div`, {
    style: {
      textAlign: `center`,
      padding: `48px 24px`,
      color: `var(--muted)`
    },
    children: [e && (0, F.jsx)(`div`, {
      style: {
        fontSize: 40,
        marginBottom: 12
      },
      children: e
    }), (0, F.jsx)(`p`, {
      style: {
        fontWeight: 700,
        fontSize: 16,
        color: `var(--text-2)`,
        marginBottom: 6
      },
      children: t
    }), n && (0, F.jsx)(`p`, {
      style: {
        fontSize: 14,
        color: `var(--muted)`,
        marginBottom: 20,
        maxWidth: 320,
        margin: `0 auto 20px`
      },
      children: n
    }), r]
  })
}

function $i({
  open: e,
  onClose: t,
  title: n,
  children: r,
  maxWidth: i = 560,
  footer: a
}) {
  return e ? (0, F.jsx)(`div`, {
    className: `modal-backdrop`,
    onClick: e => e.target === e.currentTarget && t(),
    children: (0, F.jsxs)(`div`, {
      style: {
        background: `var(--surface)`,
        borderRadius: `var(--r-xl)`,
        boxShadow: `var(--shadow-lg)`,
        width: `100%`,
        maxWidth: i,
        maxHeight: `90vh`,
        display: `flex`,
        flexDirection: `column`
      },
      role: `dialog`,
      "aria-modal": `true`,
      children: [(0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          justifyContent: `space-between`,
          padding: `18px 24px`,
          borderBottom: `1px solid var(--border)`
        },
        children: [(0, F.jsx)(`h3`, {
          style: {
            fontSize: 16,
            fontWeight: 700
          },
          children: n
        }), (0, F.jsx)(`button`, {
          onClick: t,
          style: {
            background: `none`,
            border: `none`,
            cursor: `pointer`,
            color: `var(--muted)`,
            padding: 4,
            borderRadius: `var(--r)`,
            display: `flex`,
            alignItems: `center`
          },
          "aria-label": `Close`,
          children: (0, F.jsx)(Li, {
            size: 18
          })
        })]
      }), (0, F.jsx)(`div`, {
        style: {
          flex: 1,
          overflowY: `auto`,
          padding: `20px 24px`
        },
        children: r
      }), a && (0, F.jsx)(`div`, {
        style: {
          padding: `16px 24px`,
          borderTop: `1px solid var(--border)`,
          display: `flex`,
          justifyContent: `flex-end`,
          gap: 10
        },
        children: a
      })]
    })
  }) : null
}

function ea({
  name: e = ``,
  size: t = 32
}) {
  let n = e.split(` `).filter(Boolean).slice(0, 2).map(e => e[0].toUpperCase()).join(``);
  return (0, F.jsx)(`div`, {
    "aria-label": e,
    style: {
      width: t,
      height: t,
      borderRadius: `50%`,
      background: `var(--brand)`,
      color: `#fff`,
      display: `flex`,
      alignItems: `center`,
      justifyContent: `center`,
      fontSize: t < 28 ? 10 : t < 40 ? 12 : 14,
      fontWeight: 700,
      flexShrink: 0,
      userSelect: `none`
    },
    children: n || `?`
  })
}

function ta({
  label: e,
  value: t,
  icon: n,
  color: r = `var(--brand)`,
  onClick: i,
  sub: a
}) {
  return (0, F.jsxs)(`div`, {
    onClick: i,
    style: {
      flex: `1 1 120px`,
      background: `var(--surface)`,
      border: `1px solid var(--border)`,
      borderLeft: `4px solid ${r}`,
      borderRadius: `var(--r-lg)`,
      padding: `16px 18px`,
      cursor: i ? `pointer` : `default`,
      transition: `var(--t)`,
      boxShadow: `var(--shadow)`
    },
    onMouseEnter: e => i && (e.currentTarget.style.transform = `translateY(-1px)`),
    onMouseLeave: e => i && (e.currentTarget.style.transform = ``),
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        marginBottom: 6
      },
      children: [(0, F.jsx)(`span`, {
        style: {
          fontSize: 12,
          color: `var(--muted)`,
          fontWeight: 600,
          textTransform: `uppercase`,
          letterSpacing: `.04em`
        },
        children: e
      }), (0, F.jsx)(`span`, {
        style: {
          color: r
        },
        children: n
      })]
    }), (0, F.jsx)(`div`, {
      style: {
        fontSize: 28,
        fontWeight: 800,
        color: r,
        lineHeight: 1
      },
      children: t
    }), a && (0, F.jsx)(`div`, {
      style: {
        fontSize: 11,
        color: `var(--muted)`,
        marginTop: 4
      },
      children: a
    })]
  })
}

function na({
  h: e = 20,
  w: t,
  style: n
}) {
  return (0, F.jsx)(`div`, {
    className: `skeleton`,
    style: {
      height: e,
      width: t || `100%`,
      ...n
    }
  })
}

function ra({
  label: e,
  style: t
}) {
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      alignItems: `center`,
      gap: 12,
      ...t
    },
    children: [(0, F.jsx)(`div`, {
      style: {
        flex: 1,
        height: 1,
        background: `var(--border)`
      }
    }), e && (0, F.jsx)(`span`, {
      style: {
        fontSize: 11,
        color: `var(--muted)`,
        fontWeight: 600,
        textTransform: `uppercase`,
        letterSpacing: `.06em`,
        whiteSpace: `nowrap`
      },
      children: e
    }), (0, F.jsx)(`div`, {
      style: {
        flex: 1,
        height: 1,
        background: `var(--border)`
      }
    })]
  })
}

function ia({
  tabs: e = [],
  active: t,
  onChange: n,
  style: r
}) {
  return (0, F.jsx)(`div`, {
    style: {
      display: `flex`,
      gap: 2,
      borderBottom: `2px solid var(--border)`,
      ...r
    },
    children: e.map(e => (0, F.jsx)(`button`, {
      onClick: () => n(e.key ?? e.value ?? e),
      style: {
        padding: `9px 16px`,
        fontSize: 13,
        fontWeight: 600,
        background: `none`,
        border: `none`,
        cursor: `pointer`,
        color: t === (e.key ?? e.value ?? e) ? `var(--brand)` : `var(--muted)`,
        borderBottom: `2px solid ${t===(e.key??e.value??e)?`var(--brand)`:`transparent`}`,
        marginBottom: -2,
        transition: `var(--t)`,
        fontFamily: `inherit`
      },
      children: e.label ?? e
    }, e.value ?? e))
  })
}

function aa({
  columns: e = [],
  rows: t = [],
  loading: n,
  empty: r,
  onRowClick: i,
  stickyHeader: a
}) {
  return (0, F.jsx)(`div`, {
    style: {
      overflowX: `auto`
    },
    children: (0, F.jsxs)(`table`, {
      style: {
        width: `100%`,
        borderCollapse: `collapse`,
        fontSize: 13
      },
      children: [(0, F.jsx)(`thead`, {
        children: (0, F.jsx)(`tr`, {
          style: {
            background: `var(--surface-2)`,
            position: a ? `sticky` : void 0,
            top: a ? 0 : void 0,
            zIndex: a ? 1 : void 0
          },
          children: e.map((e, t) => (0, F.jsx)(`th`, {
            style: {
              padding: `10px 14px`,
              textAlign: e.align || `left`,
              fontWeight: 700,
              color: `var(--text-2)`,
              borderBottom: `1px solid var(--border)`,
              whiteSpace: `nowrap`,
              fontSize: 12,
              letterSpacing: `.03em`,
              textTransform: `uppercase`
            },
            children: e.label
          }, t))
        })
      }), (0, F.jsx)(`tbody`, {
        children: n ? (0, F.jsx)(`tr`, {
          children: (0, F.jsx)(`td`, {
            colSpan: e.length,
            className: `tbl-loading-cell`,
            children: `Loading…`
          })
        }) : t.length === 0 ? (0, F.jsx)(`tr`, {
          children: (0, F.jsx)(`td`, {
            colSpan: e.length,
            className: `tbl-empty-cell`,
            children: r || `No records found.`
          })
        }) : t.map((t, n) => (0, F.jsx)(`tr`, {
          onClick: () => i?.(t),
          style: {
            borderBottom: `1px solid var(--border)`,
            cursor: i ? `pointer` : `default`,
            transition: `background var(--t)`
          },
          onMouseEnter: e => i && (e.currentTarget.style.background = `var(--surface-2)`),
          onMouseLeave: e => i && (e.currentTarget.style.background = ``),
          children: e.map((e, n) => (0, F.jsx)(`td`, {
            style: {
              padding: `12px 14px`,
              color: `var(--text)`,
              textAlign: e.align || `left`,
              verticalAlign: `middle`
            },
            children: e.render ? e.render(t) : t[e.key]
          }, n))
        }, n))
      })]
    })
  })
}

function oa() {
  let {
    user: e,
    logout: t
  } = kr(), n = ut(), r = st(), [i, a] = (0, _.useState)(!1), o = window.S2NRI_CFG?.platformName || `Services2NRI`, s = e?.name || e?.display_name || `there`, c = (e, t = !1) => t ? r.pathname === e || r.pathname === e + `/` : r.pathname.startsWith(e), l = [{
    to: `/`,
    label: `Dashboard`,
    exact: !0
  }, {
    to: `/bookings`,
    label: `My Requests`
  }, {
    to: `/profile`,
    label: `Profile`
  }];
  return (0, F.jsxs)(`div`, {
    style: {
      background: `var(--bg)`,
      minHeight: `100vh`,
      padding: `0 0 48px`
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        background: `var(--sidebar-bg)`,
        borderBottom: `1px solid rgba(255,255,255,.06)`,
        position: `sticky`,
        top: 0,
        zIndex: 100,
        boxShadow: `0 1px 8px rgba(13,28,46,.25)`
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          maxWidth: 1100,
          margin: `0 auto`,
          padding: `0 24px`,
          display: `flex`,
          alignItems: `center`,
          justifyContent: `space-between`,
          height: 58,
          gap: 16
        },
        children: [(0, F.jsxs)(`button`, {
          onClick: () => n(`/`),
          style: {
            background: `none`,
            border: `none`,
            cursor: `pointer`,
            padding: 0,
            display: `flex`,
            alignItems: `center`,
            gap: 10,
            flexShrink: 0
          },
          children: [(0, F.jsx)(`div`, {
            style: {
              width: 32,
              height: 32,
              borderRadius: `var(--r)`,
              background: `var(--brand)`,
              display: `flex`,
              alignItems: `center`,
              justifyContent: `center`,
              flexShrink: 0
            },
            children: (0, F.jsx)(`span`, {
              style: {
                color: `#fff`,
                fontWeight: 900,
                fontSize: 15,
                lineHeight: 1
              },
              children: `S`
            })
          }), (0, F.jsx)(`span`, {
            style: {
              fontWeight: 800,
              fontSize: 15,
              color: `#fff`,
              letterSpacing: `-.3px`,
              whiteSpace: `nowrap`
            },
            children: o
          })]
        }), (0, F.jsx)(`nav`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 2,
            flex: 1
          },
          className: `desktop-nav`,
          children: l.map(e => {
            let t = e.exact ? c(e.to, !0) : c(e.to);
            return (0, F.jsx)(In, {
              to: e.to,
              end: e.exact,
              style: {
                padding: `7px 14px`,
                borderRadius: `var(--r)`,
                fontSize: 13,
                fontWeight: t ? 700 : 500,
                textDecoration: `none`,
                color: t ? `#fff` : `var(--sidebar-text)`,
                background: t ? `rgba(255,255,255,.12)` : `none`,
                transition: `var(--t)`,
                whiteSpace: `nowrap`
              },
              children: e.label
            }, e.to)
          })
        }), (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 8,
            flexShrink: 0
          },
          children: [(0, F.jsx)(`button`, {
            onClick: () => n(`/new-request`),
            style: {
              padding: `7px 16px`,
              borderRadius: `var(--r)`,
              fontSize: 13,
              fontWeight: 700,
              background: `var(--brand)`,
              color: `#fff`,
              border: `none`,
              cursor: `pointer`,
              whiteSpace: `nowrap`,
              fontFamily: `inherit`,
              transition: `background var(--t)`
            },
            onMouseEnter: e => e.currentTarget.style.background = `var(--brand-dark)`,
            onMouseLeave: e => e.currentTarget.style.background = `var(--brand)`,
            children: `+ New Request`
          }), (0, F.jsxs)(`div`, {
            style: {
              position: `relative`
            },
            children: [(0, F.jsx)(`button`, {
              onClick: () => a(e => !e),
              style: {
                background: `rgba(255,255,255,.1)`,
                border: `1px solid rgba(255,255,255,.15)`,
                cursor: `pointer`,
                padding: 3,
                borderRadius: `var(--r-full)`,
                display: `flex`,
                alignItems: `center`,
                transition: `var(--t)`
              },
              onMouseEnter: e => e.currentTarget.style.background = `rgba(255,255,255,.18)`,
              onMouseLeave: e => e.currentTarget.style.background = `rgba(255,255,255,.1)`,
              children: (0, F.jsx)(ea, {
                name: s,
                size: 28
              })
            }), i && (0, F.jsxs)(F.Fragment, {
              children: [(0, F.jsx)(`div`, {
                onClick: () => a(!1),
                style: {
                  position: `fixed`,
                  inset: 0,
                  zIndex: 200
                }
              }), (0, F.jsxs)(`div`, {
                style: {
                  position: `absolute`,
                  right: 0,
                  top: `calc(100% + 8px)`,
                  zIndex: 300,
                  background: `var(--surface)`,
                  border: `1px solid var(--border)`,
                  borderRadius: `var(--r-lg)`,
                  boxShadow: `var(--shadow-lg)`,
                  minWidth: 192,
                  padding: `8px 0`,
                  overflow: `hidden`
                },
                children: [(0, F.jsxs)(`div`, {
                  style: {
                    padding: `10px 16px 10px`,
                    borderBottom: `1px solid var(--border)`
                  },
                  children: [(0, F.jsx)(`div`, {
                    style: {
                      fontSize: 13,
                      fontWeight: 700,
                      color: `var(--text)`
                    },
                    children: s
                  }), (0, F.jsx)(`div`, {
                    style: {
                      fontSize: 11,
                      color: `var(--muted)`,
                      marginTop: 2
                    },
                    children: e?.email || e?.user_email || ``
                  })]
                }), (0, F.jsx)(`button`, {
                  onClick: () => {
                    a(!1), n(`/profile`)
                  },
                  style: {
                    display: `flex`,
                    alignItems: `center`,
                    gap: 8,
                    width: `100%`,
                    padding: `10px 16px`,
                    background: `none`,
                    border: `none`,
                    cursor: `pointer`,
                    fontSize: 13,
                    color: `var(--text)`,
                    fontFamily: `inherit`,
                    textAlign: `left`
                  },
                  onMouseEnter: e => e.currentTarget.style.background = `var(--surface-2)`,
                  onMouseLeave: e => e.currentTarget.style.background = `none`,
                  children: `👤 My Profile`
                }), (0, F.jsxs)(`button`, {
                  onClick: () => {
                    a(!1), t()
                  },
                  style: {
                    display: `flex`,
                    alignItems: `center`,
                    gap: 8,
                    width: `100%`,
                    padding: `10px 16px`,
                    background: `none`,
                    border: `none`,
                    cursor: `pointer`,
                    fontSize: 13,
                    color: `var(--red)`,
                    fontFamily: `inherit`,
                    textAlign: `left`
                  },
                  onMouseEnter: e => e.currentTarget.style.background = `var(--red-bg)`,
                  onMouseLeave: e => e.currentTarget.style.background = `none`,
                  children: [(0, F.jsx)(fi, {
                    size: 13
                  }), ` Sign out`]
                })]
              })]
            })]
          }), (0, F.jsx)(`button`, {
            onClick: () => a(e => !e),
            style: {
              display: `none`,
              background: `none`,
              border: `none`,
              cursor: `pointer`,
              color: `var(--sidebar-text)`
            },
            className: `mobile-menu-btn`,
            children: (0, F.jsx)(mi, {
              size: 20
            })
          })]
        })]
      }), i && (0, F.jsxs)(`div`, {
        style: {
          borderTop: `1px solid rgba(255,255,255,.08)`,
          padding: `8px 24px 12px`,
          display: `none`,
          background: `var(--sidebar-bg)`
        },
        className: `mobile-nav`,
        children: [l.map(e => (0, F.jsx)(In, {
          to: e.to,
          end: e.exact,
          onClick: () => a(!1),
          style: ({
            isActive: e
          }) => ({
            display: `block`,
            padding: `10px 0`,
            fontSize: 14,
            fontWeight: e ? 700 : 500,
            textDecoration: `none`,
            color: e ? `#fff` : `var(--sidebar-text)`,
            borderBottom: `1px solid rgba(255,255,255,.08)`
          }),
          children: e.label
        }, e.to)), (0, F.jsxs)(`button`, {
          onClick: t,
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 6,
            padding: `10px 0`,
            background: `none`,
            border: `none`,
            cursor: `pointer`,
            fontSize: 13,
            color: `var(--red)`,
            fontFamily: `inherit`,
            width: `100%`
          },
          children: [(0, F.jsx)(fi, {
            size: 14
          }), ` Sign out`]
        })]
      })]
    }), (0, F.jsx)(`main`, {
      style: {
        maxWidth: 1100,
        margin: `0 auto`,
        padding: `28px 24px`
      },
      children: (0, F.jsx)(zt, {})
    }), (0, F.jsx)(`style`, {
      children: `
        @media (max-width: 640px) {
          .desktop-nav { display: none !important; }
          .mobile-menu-btn { display: flex !important; }
          .mobile-nav { display: block !important; }
        }
      `
    })]
  })
}
var sa = `var(--brand)`,
  ca = `var(--sidebar-bg)`,
  la = [{
    to: `/`,
    label: `Dashboard`,
    icon: (0, F.jsx)(li, {
      size: 16
    }),
    exact: !0
  }, {
    to: `/requests`,
    label: `Requests`,
    icon: (0, F.jsx)(oi, {
      size: 16
    })
  }, {
    to: `/customers`,
    label: `Customers`,
    icon: (0, F.jsx)(Ii, {
      size: 16
    })
  }, {
    to: `/analytics`,
    label: `Analytics`,
    icon: (0, F.jsx)(Kr, {
      size: 16
    })
  }, {
    to: `/services`,
    label: `Services`,
    icon: (0, F.jsx)(gi, {
      size: 16
    })
  }, {
    to: `/form-submissions`,
    label: `Submissions`,
    icon: (0, F.jsx)(ei, {
      size: 16
    })
  }, {
    to: `/vendors`,
    label: `Vendors`,
    icon: (0, F.jsx)(Pi, {
      size: 16
    })
  }, {
    to: `/request-types`,
    label: `Req. Types`,
    icon: (0, F.jsx)(Oi, {
      size: 16
    })
  }, {
    to: `/settings`,
    label: `Settings`,
    icon: (0, F.jsx)(Ti, {
      size: 16
    })
  }, {
    to: `/health`,
    label: `System`,
    icon: (0, F.jsx)(L, {
      size: 16
    })
  }];

function ua() {
  let {
    user: e,
    logout: t
  } = kr(), [n, r] = (0, _.useState)(!1), i = window.S2NRI_CFG?.platformName || `Services2NRI`, a = () => (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      height: `100%`,
      background: ca
    },
    children: [(0, F.jsx)(`div`, {
      style: {
        padding: `20px 18px 16px`,
        borderBottom: `1px solid rgba(255,255,255,.08)`
      },
      children: (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          gap: 10
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            width: 34,
            height: 34,
            borderRadius: 8,
            background: sa,
            display: `flex`,
            alignItems: `center`,
            justifyContent: `center`,
            flexShrink: 0
          },
          children: (0, F.jsx)(`span`, {
            style: {
              color: `#fff`,
              fontWeight: 800,
              fontSize: 14
            },
            children: `S`
          })
        }), (0, F.jsxs)(`div`, {
          children: [(0, F.jsx)(`div`, {
            style: {
              fontWeight: 800,
              fontSize: 13,
              color: `#fff`
            },
            children: i
          }), (0, F.jsx)(`div`, {
            style: {
              fontSize: 10,
              color: `rgba(255,255,255,.4)`
            },
            children: `Admin Panel`
          })]
        })]
      })
    }), (0, F.jsx)(`nav`, {
      style: {
        flex: 1,
        padding: `10px 10px`,
        overflowY: `auto`
      },
      children: la.map(e => (0, F.jsxs)(In, {
        to: e.to,
        end: e.exact,
        onClick: () => r(!1),
        style: ({
          isActive: e
        }) => ({
          display: `flex`,
          alignItems: `center`,
          gap: 10,
          padding: `10px 12px`,
          borderRadius: 8,
          fontSize: 13,
          fontWeight: 600,
          textDecoration: `none`,
          marginBottom: 2,
          transition: `var(--t)`,
          color: e ? `#fff` : `rgba(255,255,255,.5)`,
          background: e ? sa : `transparent`
        }),
        children: [e.icon, e.label]
      }, e.to))
    }), (0, F.jsxs)(`div`, {
      style: {
        padding: `12px 14px`,
        borderTop: `1px solid rgba(255,255,255,.08)`
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          gap: 10,
          marginBottom: 8
        },
        children: [(0, F.jsx)(ea, {
          name: e?.name || e?.display_name || `Admin`,
          size: 28,
          color: sa
        }), (0, F.jsxs)(`div`, {
          style: {
            flex: 1,
            minWidth: 0
          },
          children: [(0, F.jsx)(`div`, {
            style: {
              fontSize: 12,
              fontWeight: 700,
              color: `#fff`,
              overflow: `hidden`,
              whiteSpace: `nowrap`,
              textOverflow: `ellipsis`
            },
            children: e?.name || e?.display_name
          }), (0, F.jsx)(`div`, {
            style: {
              fontSize: 10,
              color: `rgba(255,255,255,.4)`
            },
            children: e?.s2nri_role || `Staff`
          })]
        })]
      }), (0, F.jsxs)(`button`, {
        onClick: t,
        style: {
          display: `flex`,
          alignItems: `center`,
          gap: 8,
          width: `100%`,
          padding: `7px 10px`,
          borderRadius: 7,
          border: `none`,
          background: `rgba(255,255,255,.06)`,
          cursor: `pointer`,
          fontSize: 12,
          color: `rgba(255,255,255,.5)`,
          fontFamily: `inherit`,
          transition: `var(--t)`
        },
        onMouseEnter: e => {
          e.currentTarget.style.background = `rgba(239,68,68,.2)`, e.currentTarget.style.color = `var(--red-border)`
        },
        onMouseLeave: e => {
          e.currentTarget.style.background = `rgba(255,255,255,.06)`, e.currentTarget.style.color = `rgba(255,255,255,.5)`
        },
        children: [(0, F.jsx)(fi, {
          size: 13
        }), ` Sign out`]
      })]
    })]
  });
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      minHeight: `100vh`
    },
    children: [(0, F.jsx)(`div`, {
      style: {
        width: 220,
        flexShrink: 0,
        position: `fixed`,
        top: 0,
        left: 0,
        height: `100vh`,
        zIndex: 100
      },
      children: (0, F.jsx)(a, {})
    }), n && (0, F.jsx)(`div`, {
      style: {
        position: `fixed`,
        inset: 0,
        background: `rgba(0,0,0,.7)`,
        zIndex: 200
      },
      onClick: () => r(!1),
      children: (0, F.jsxs)(`div`, {
        style: {
          width: 240,
          height: `100%`
        },
        onClick: e => e.stopPropagation(),
        children: [(0, F.jsx)(`div`, {
          style: {
            display: `flex`,
            justifyContent: `flex-end`,
            padding: `10px 12px`,
            background: ca
          },
          children: (0, F.jsx)(`button`, {
            onClick: () => r(!1),
            style: {
              background: `none`,
              border: `none`,
              cursor: `pointer`,
              color: `rgba(255,255,255,.5)`
            },
            children: (0, F.jsx)(Li, {
              size: 18
            })
          })
        }), (0, F.jsx)(a, {})]
      })
    }), (0, F.jsxs)(`div`, {
      style: {
        flex: 1,
        marginLeft: 220,
        display: `flex`,
        flexDirection: `column`,
        minWidth: 0
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          background: `var(--sidebar-bg)`,
          borderBottom: `1px solid rgba(255,255,255,.08)`,
          padding: `0 24px`,
          height: 52,
          display: `flex`,
          alignItems: `center`,
          justifyContent: `space-between`,
          position: `sticky`,
          top: 0,
          zIndex: 50,
          boxShadow: `0 1px 8px rgba(13,28,46,.25)`
        },
        children: [(0, F.jsx)(`button`, {
          onClick: () => r(!0),
          style: {
            background: `none`,
            border: `none`,
            cursor: `pointer`,
            color: `var(--sidebar-text)`
          },
          children: (0, F.jsx)(mi, {
            size: 20
          })
        }), (0, F.jsx)(`div`, {
          style: {
            flex: 1
          }
        }), (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 8
          },
          children: [(0, F.jsx)(`button`, {
            style: {
              background: `none`,
              border: `none`,
              cursor: `pointer`,
              color: `var(--sidebar-text)`,
              padding: 6
            },
            children: (0, F.jsx)(Hr, {
              size: 17
            })
          }), (0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              alignItems: `center`,
              gap: 8,
              padding: `4px 10px`,
              borderRadius: `var(--r)`,
              background: `rgba(255,255,255,.1)`,
              border: `1px solid rgba(255,255,255,.15)`,
              fontSize: 13,
              fontWeight: 600,
              color: `#fff`
            },
            children: [(0, F.jsx)(ea, {
              name: e?.name || e?.display_name || ``,
              size: 22,
              color: sa
            }), e?.name || e?.display_name]
          })]
        })]
      }), (0, F.jsx)(`main`, {
        style: {
          flex: 1,
          padding: `24px`,
          background: `var(--bg)`
        },
        children: (0, F.jsx)(zt, {})
      })]
    }), (0, F.jsx)(`style`, {
      children: `
        @media(max-width:767px){
          div[style*="margin-left: 220px"]{margin-left:0!important}
          div[style*="width: 220px"][style*="position: fixed"]{display:none!important}
        }
      `
    })]
  })
}
var da = `var(--brand)`;

function fa() {
  let {
    login: e
  } = kr(), t = R(), n = ut(), [r] = Un(), i = r.get(`redirect`) || (window.S2NRI_CFG?.isAdmin ? `/admin` : `/`), a = window.S2NRI_CFG?.platformName || `Services2NRI`, [o, s] = (0, _.useState)(`password`), [c, l] = (0, _.useState)(!1), [u, d] = (0, _.useState)(!1), [f, p] = (0, _.useState)({
    email: ``,
    password: ``
  }), [m, h] = (0, _.useState)(!1), g = e => t => p(n => ({
    ...n,
    [e]: t.target.value
  })), v = {
    width: `100%`,
    padding: `10px 13px 10px 38px`,
    fontSize: 14,
    border: `1px solid var(--border)`,
    borderRadius: `var(--r)`,
    fontFamily: `inherit`,
    outline: `none`,
    boxSizing: `border-box`,
    color: `var(--text)`,
    background: `#fff`,
    transition: `border-color var(--t)`
  };
  async function y(r) {
    if (r.preventDefault(), !f.email || !f.password) return t(`Please enter email and password`, `error`);
    l(!0);
    try {
      await e({
        email: f.email,
        password: f.password
      }), n(i, {
        replace: !0
      })
    } catch (e) {
      t(e.message || `Login failed`, `error`)
    } finally {
      l(!1)
    }
  }
  async function b(e) {
    if (e.preventDefault(), !f.email) return t(`Enter your email`, `error`);
    l(!0);
    try {
      await ar.magicLink({
        email: f.email
      }), d(!0)
    } catch (e) {
      t(e.message || `Could not send link`, `error`)
    } finally {
      l(!1)
    }
  }
  return (0, F.jsxs)(`div`, {
    style: {
      minHeight: `100vh`,
      display: `flex`,
      alignItems: `center`,
      justifyContent: `center`,
      background: `var(--bg)`,
      padding: 16
    },
    children: [(0, F.jsx)(`div`, {
      style: {
        position: `fixed`,
        top: -100,
        left: -100,
        width: 400,
        height: 400,
        borderRadius: `50%`,
        background: `${da}10`,
        pointerEvents: `none`
      }
    }), (0, F.jsx)(`div`, {
      style: {
        position: `fixed`,
        bottom: -80,
        right: -80,
        width: 300,
        height: 300,
        borderRadius: `50%`,
        background: `${da}08`,
        pointerEvents: `none`
      }
    }), (0, F.jsxs)(`div`, {
      style: {
        background: `#fff`,
        borderRadius: 20,
        padding: `40px 36px`,
        width: `100%`,
        maxWidth: 440,
        boxShadow: `0 8px 40px rgba(74,111,165,.12), 0 1px 4px rgba(0,0,0,.06)`,
        animation: `slideUp 250ms ease both`,
        position: `relative`,
        zIndex: 1
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          textAlign: `center`,
          marginBottom: 28
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            width: 52,
            height: 52,
            borderRadius: 14,
            background: `linear-gradient(135deg,${da},#1E2D40)`,
            display: `flex`,
            alignItems: `center`,
            justifyContent: `center`,
            margin: `0 auto 14px`,
            boxShadow: `0 4px 16px ${da}40`
          },
          children: (0, F.jsx)(`span`, {
            style: {
              color: `#fff`,
              fontWeight: 900,
              fontSize: 22
            },
            children: `S`
          })
        }), (0, F.jsx)(`h1`, {
          style: {
            fontSize: 22,
            fontWeight: 800,
            color: `var(--text)`,
            marginBottom: 4
          },
          children: a
        }), (0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`
          },
          children: `Sign in to your account`
        })]
      }), (0, F.jsx)(`div`, {
        style: {
          display: `flex`,
          background: `var(--surface-2)`,
          borderRadius: `var(--r)`,
          padding: 4,
          marginBottom: 24
        },
        children: [
          [`password`, `🔐 Password`],
          [`magic`, `✉️ Magic Link`]
        ].map(([e, t]) => (0, F.jsx)(`button`, {
          onClick: () => {
            s(e), d(!1)
          },
          style: {
            flex: 1,
            padding: `8px 12px`,
            fontSize: 13,
            fontWeight: 600,
            borderRadius: 8,
            border: `none`,
            cursor: `pointer`,
            transition: `var(--t)`,
            background: o === e ? `#fff` : `transparent`,
            color: o === e ? da : `var(--muted)`,
            boxShadow: o === e ? `var(--shadow-sm)` : `none`
          },
          children: t
        }, e))
      }), o === `password` ? (0, F.jsxs)(`form`, {
        onSubmit: y,
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            flexDirection: `column`,
            gap: 16,
            marginBottom: 20
          },
          children: [(0, F.jsxs)(`div`, {
            children: [(0, F.jsx)(`label`, {
              style: {
                fontSize: 13,
                fontWeight: 600,
                color: `var(--text-2)`,
                display: `block`,
                marginBottom: 6
              },
              children: `Email address`
            }), (0, F.jsxs)(`div`, {
              style: {
                position: `relative`
              },
              children: [(0, F.jsx)(pi, {
                size: 15,
                style: {
                  position: `absolute`,
                  left: 12,
                  top: `50%`,
                  transform: `translateY(-50%)`,
                  color: `var(--muted)`,
                  pointerEvents: `none`
                }
              }), (0, F.jsx)(`input`, {
                type: `email`,
                value: f.email,
                onChange: g(`email`),
                placeholder: `you@example.com`,
                required: !0,
                autoFocus: !0,
                style: v,
                onFocus: e => e.target.style.borderColor = da,
                onBlur: e => e.target.style.borderColor = `var(--border)`
              })]
            })]
          }), (0, F.jsxs)(`div`, {
            children: [(0, F.jsx)(`label`, {
              style: {
                fontSize: 13,
                fontWeight: 600,
                color: `var(--text-2)`,
                display: `block`,
                marginBottom: 6
              },
              children: `Password`
            }), (0, F.jsxs)(`div`, {
              style: {
                position: `relative`
              },
              children: [(0, F.jsx)(di, {
                size: 15,
                style: {
                  position: `absolute`,
                  left: 12,
                  top: `50%`,
                  transform: `translateY(-50%)`,
                  color: `var(--muted)`,
                  pointerEvents: `none`
                }
              }), (0, F.jsx)(`input`, {
                type: m ? `text` : `password`,
                value: f.password,
                onChange: g(`password`),
                placeholder: `Your password`,
                required: !0,
                style: {
                  ...v,
                  paddingRight: 60
                },
                onFocus: e => e.target.style.borderColor = da,
                onBlur: e => e.target.style.borderColor = `var(--border)`
              }), (0, F.jsx)(`button`, {
                type: `button`,
                onClick: () => h(e => !e),
                style: {
                  position: `absolute`,
                  right: 12,
                  top: `50%`,
                  transform: `translateY(-50%)`,
                  background: `none`,
                  border: `none`,
                  cursor: `pointer`,
                  fontSize: 12,
                  color: `var(--muted)`,
                  fontFamily: `inherit`
                },
                children: m ? `Hide` : `Show`
              })]
            })]
          })]
        }), (0, F.jsx)(z, {
          type: `submit`,
          fullWidth: !0,
          loading: c,
          icon: (0, F.jsx)(Br, {
            size: 16
          }),
          style: {
            background: `linear-gradient(135deg,${da},#1E2D40)`,
            fontSize: 15,
            padding: `12px 24px`
          },
          children: `Sign in`
        })]
      }) : u ? (0, F.jsxs)(`div`, {
        style: {
          textAlign: `center`,
          padding: `20px 0`
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            fontSize: 48,
            marginBottom: 14
          },
          children: `✉️`
        }), (0, F.jsx)(`h3`, {
          style: {
            fontSize: 17,
            marginBottom: 8
          },
          children: `Check your inbox`
        }), (0, F.jsxs)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`,
            lineHeight: 1.6
          },
          children: [`We sent a sign-in link to `, (0, F.jsx)(`strong`, {
            children: f.email
          }), `. It expires in 15 minutes.`]
        }), (0, F.jsx)(`button`, {
          onClick: () => d(!1),
          style: {
            marginTop: 20,
            fontSize: 13,
            color: da,
            background: `none`,
            border: `none`,
            cursor: `pointer`
          },
          children: `← Use a different email`
        })]
      }) : (0, F.jsxs)(`form`, {
        onSubmit: b,
        children: [(0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`,
            marginBottom: 18,
            lineHeight: 1.6
          },
          children: `Enter your email and we'll send a one-click sign-in link.`
        }), (0, F.jsxs)(`div`, {
          style: {
            position: `relative`,
            marginBottom: 20
          },
          children: [(0, F.jsx)(pi, {
            size: 15,
            style: {
              position: `absolute`,
              left: 12,
              top: `50%`,
              transform: `translateY(-50%)`,
              color: `var(--muted)`,
              pointerEvents: `none`
            }
          }), (0, F.jsx)(`input`, {
            type: `email`,
            value: f.email,
            onChange: g(`email`),
            placeholder: `you@example.com`,
            required: !0,
            autoFocus: !0,
            style: v,
            onFocus: e => e.target.style.borderColor = da,
            onBlur: e => e.target.style.borderColor = `var(--border)`
          })]
        }), (0, F.jsx)(z, {
          type: `submit`,
          fullWidth: !0,
          loading: c,
          style: {
            background: `linear-gradient(135deg,${da},#1E2D40)`,
            fontSize: 15,
            padding: `12px 24px`
          },
          children: `Send magic link`
        })]
      }), o === `password` && (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(ra, {
          label: `or`,
          style: {
            margin: `20px 0`
          }
        }), (0, F.jsx)(`button`, {
          onClick: () => {
            s(`magic`), d(!1)
          },
          style: {
            width: `100%`,
            padding: `10px`,
            fontSize: 14,
            color: `var(--muted)`,
            background: `var(--surface-2)`,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r)`,
            cursor: `pointer`,
            fontFamily: `inherit`
          },
          children: `Sign in with a magic link instead`
        })]
      })]
    })]
  })
}
var pa = `var(--brand)`;

function ma(e) {
  return e ? new Date(e).toLocaleDateString(`en-IN`, {
    day: `numeric`,
    month: `short`,
    year: `numeric`
  }) : `—`
}

function ha({
  booking: e,
  onClick: t
}) {
  return (0, F.jsxs)(`div`, {
    onClick: t,
    style: {
      background: `#fff`,
      border: `1px solid var(--border)`,
      borderRadius: `var(--r-lg)`,
      padding: `16px 18px`,
      cursor: `pointer`,
      transition: `all var(--t)`,
      display: `flex`,
      flexDirection: `column`,
      gap: 10
    },
    onMouseEnter: e => {
      e.currentTarget.style.boxShadow = `var(--shadow-md)`, e.currentTarget.style.transform = `translateY(-2px)`
    },
    onMouseLeave: e => {
      e.currentTarget.style.boxShadow = ``, e.currentTarget.style.transform = ``
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        justifyContent: `space-between`,
        alignItems: `flex-start`,
        gap: 10
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          minWidth: 0
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            fontWeight: 700,
            fontSize: 15,
            color: `var(--text)`,
            marginBottom: 3,
            overflow: `hidden`,
            whiteSpace: `nowrap`,
            textOverflow: `ellipsis`
          },
          children: e.service_name || `Service Request`
        }), (0, F.jsx)(`div`, {
          style: {
            fontSize: 12,
            color: pa,
            fontWeight: 700,
            fontFamily: `monospace`,
            letterSpacing: `.03em`
          },
          children: e.booking_ref
        })]
      }), (0, F.jsx)(Ji, {
        status: e.status
      })]
    }), e.secondary_status && (0, F.jsx)(`div`, {
      style: {
        fontSize: 12,
        color: `var(--muted)`,
        background: `var(--surface-3)`,
        borderRadius: `var(--r-sm)`,
        padding: `4px 8px`,
        fontStyle: `italic`
      },
      children: e.secondary_status
    }), e.due_date && (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        gap: 5,
        fontSize: 12,
        color: `var(--brand-dark)`,
        fontWeight: 600
      },
      children: [(0, F.jsx)(Gr, {
        size: 12
      }), `Est. delivery: `, ma(e.due_date), e.delivery_working_days && (0, F.jsxs)(`span`, {
        style: {
          fontWeight: 400,
          color: `var(--muted)`
        },
        children: [`· `, e.delivery_working_days, ` working days`]
      })]
    }), (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        justifyContent: `space-between`,
        alignItems: `center`,
        fontSize: 12,
        color: `var(--muted)`,
        borderTop: `1px solid var(--border)`,
        paddingTop: 8
      },
      children: [(0, F.jsxs)(`span`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          gap: 4
        },
        children: [(0, F.jsx)(ti, {
          size: 11
        }), ` `, ma(e.created_at)]
      }), e.quoted_amount && (0, F.jsxs)(`span`, {
        style: {
          fontWeight: 700,
          color: `var(--text-2)`
        },
        children: [`₹`, Number(e.quoted_amount).toLocaleString(`en-IN`)]
      })]
    }), e.payment_status === `pending` && e.quoted_amount && (0, F.jsxs)(`div`, {
      style: {
        background: `var(--amber-bg)`,
        border: `1px solid var(--amber-border)`,
        borderRadius: `var(--r)`,
        padding: `8px 12px`,
        fontSize: 12,
        color: `var(--amber-dark)`,
        fontWeight: 600,
        display: `flex`,
        alignItems: `center`,
        gap: 6
      },
      children: [(0, F.jsx)(ri, {
        size: 13
      }), ` Payment of ₹`, Number(e.quoted_amount).toLocaleString(`en-IN`), ` is pending`]
    })]
  })
}

function ga({
  status: e
}) {
  let t = [`submitted`, `under_review`, `quote_sent`, `in_progress`, `completed`],
    n = t.indexOf(e),
    r = n === -1 ? 0 : n;
  return (0, F.jsx)(`div`, {
    style: {
      display: `flex`,
      alignItems: `center`,
      justifyContent: `center`,
      gap: 0,
      overflowX: `auto`,
      padding: `4px 0`
    },
    children: t.map((e, n) => {
      let i = n < r,
        a = n === r,
        o = e.replace(/_/g, ` `).replace(/\b\w/g, e => e.toUpperCase());
      return (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          alignItems: `center`
        },
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            flexDirection: `column`,
            alignItems: `center`,
            gap: 6,
            minWidth: 70
          },
          children: [(0, F.jsx)(`div`, {
            style: {
              width: 28,
              height: 28,
              borderRadius: `50%`,
              display: `flex`,
              alignItems: `center`,
              justifyContent: `center`,
              fontSize: 11,
              fontWeight: 700,
              color: `#fff`,
              transition: `var(--t-slow)`,
              background: i || a ? pa : `var(--border)`,
              boxShadow: a ? `0 0 0 4px ${pa}30` : `none`
            },
            children: i ? `✓` : n + 1
          }), (0, F.jsx)(`span`, {
            style: {
              fontSize: 10,
              fontWeight: 600,
              color: i || a ? pa : `var(--muted)`,
              textAlign: `center`,
              lineHeight: 1.3
            },
            children: o
          })]
        }), n < t.length - 1 && (0, F.jsx)(`div`, {
          style: {
            width: 40,
            height: 3,
            background: n < r ? pa : `var(--border)`,
            transition: `var(--t-slow)`,
            flexShrink: 0
          }
        })]
      }, e)
    })
  })
}

function _a() {
  let {
    user: e
  } = kr(), t = ut(), [n, r] = (0, _.useState)(null), [i, a] = (0, _.useState)([]), [o, s] = (0, _.useState)(!0), c = e?.name || e?.display_name || `there`, l = (0, _.useCallback)(async () => {
    s(!0);
    try {
      let [e, t] = await Promise.all([sr.stats(), or.list(1)]);
      r(e), a((t.bookings || t.rows || []).slice(0, 5))
    } catch {} finally {
      s(!1)
    }
  }, []);
  return (0, _.useEffect)(() => {
    l()
  }, [l]), (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      gap: 24
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        flexWrap: `wrap`,
        gap: 12
      },
      children: [(0, F.jsxs)(`div`, {
        children: [(0, F.jsxs)(`h1`, {
          style: {
            fontSize: 24,
            fontWeight: 800,
            marginBottom: 4
          },
          children: [`Good `, va(), `, `, c.split(` `)[0], ` 👋`]
        }), (0, F.jsx)(`p`, {
          style: {
            color: `var(--muted)`,
            fontSize: 14
          },
          children: `Here's what's happening with your requests`
        })]
      }), (0, F.jsx)(z, {
        icon: (0, F.jsx)(yi, {
          size: 16
        }),
        onClick: () => t(`/new-request`),
        style: {
          background: `var(--brand)`,
          color: `#fff`,
          fontWeight: 800
        },
        children: `New Request`
      })]
    }), (0, F.jsx)(`div`, {
      style: {
        display: `flex`,
        gap: 12,
        flexWrap: `wrap`
      },
      children: o ? [1, 2, 3, 4].map(e => (0, F.jsx)(na, {
        h: 90,
        style: {
          flex: 1,
          minWidth: 120,
          borderRadius: `var(--r-lg)`
        }
      }, e)) : (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(ta, {
          label: `Total`,
          value: n?.total ?? 0,
          icon: (0, F.jsx)(oi, {
            size: 18
          }),
          color: pa,
          onClick: () => t(`/bookings`)
        }), (0, F.jsx)(ta, {
          label: `Active`,
          value: n?.active ?? 0,
          icon: (0, F.jsx)(ti, {
            size: 18
          }),
          color: `var(--amber)`,
          onClick: () => t(`/bookings?status=active`)
        }), (0, F.jsx)(ta, {
          label: `Completed`,
          value: n?.completed ?? 0,
          icon: (0, F.jsx)(Qr, {
            size: 18
          }),
          color: `var(--green)`
        }), n?.pending_payment > 0 && (0, F.jsx)(ta, {
          label: `Awaiting Payment`,
          value: n.pending_payment,
          icon: (0, F.jsx)(ri, {
            size: 18
          }),
          color: `var(--red)`,
          onClick: () => t(`/bookings?payment=pending`),
          sub: `Action needed`
        })]
      })
    }), (0, F.jsxs)(B, {
      padding: `0`,
      style: {
        overflow: `hidden`
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          padding: `16px 20px`,
          borderBottom: `1px solid var(--border)`,
          display: `flex`,
          alignItems: `center`,
          justifyContent: `space-between`
        },
        children: [(0, F.jsx)(`h2`, {
          style: {
            fontSize: 16
          },
          children: `Recent Requests`
        }), (0, F.jsxs)(`button`, {
          onClick: () => t(`/bookings`),
          style: {
            fontSize: 13,
            color: pa,
            background: `none`,
            border: `none`,
            cursor: `pointer`,
            display: `flex`,
            alignItems: `center`,
            gap: 4,
            fontFamily: `inherit`,
            fontWeight: 600
          },
          children: [`View all `, (0, F.jsx)(Br, {
            size: 14
          })]
        })]
      }), o ? (0, F.jsx)(`div`, {
        style: {
          padding: 20,
          display: `flex`,
          flexDirection: `column`,
          gap: 12
        },
        children: [1, 2, 3].map(e => (0, F.jsx)(na, {
          h: 90
        }, e))
      }) : i.length === 0 ? (0, F.jsx)(Qi, {
        icon: `📋`,
        title: `No requests yet`,
        desc: `Submit your first service request and we'll get started right away.`,
        action: (0, F.jsx)(z, {
          icon: (0, F.jsx)(yi, {
            size: 16
          }),
          onClick: () => t(`/new-request`),
          style: {
            background: `var(--brand)`,
            color: `#fff`,
            fontWeight: 800
          },
          children: `New Request`
        })
      }) : (0, F.jsx)(`div`, {
        style: {
          padding: 16,
          display: `flex`,
          flexDirection: `column`,
          gap: 10
        },
        children: i.map(e => (0, F.jsx)(ha, {
          booking: e,
          onClick: () => t(`/bookings/${e.id}`)
        }, e.id))
      })]
    }), !o && n?.active > 0 && i[0] && (0, F.jsxs)(B, {
      children: [(0, F.jsxs)(`div`, {
        style: {
          marginBottom: 14
        },
        children: [(0, F.jsx)(`h3`, {
          style: {
            fontSize: 14,
            marginBottom: 3
          },
          children: `Your latest request status`
        }), (0, F.jsxs)(`p`, {
          style: {
            fontSize: 12,
            color: `var(--muted)`
          },
          children: [i[0].booking_ref, ` — `, i[0].service_name]
        })]
      }), (0, F.jsx)(ga, {
        status: i[0].status
      })]
    })]
  })
}

function va() {
  let e = new Date().getHours();
  return e < 12 ? `morning` : e < 17 ? `afternoon` : `evening`
}
var ya = `var(--brand)`;

function ba(e) {
  return e ? new Date(e).toLocaleDateString(`en-IN`, {
    day: `numeric`,
    month: `short`,
    year: `numeric`
  }) : null
}
var xa = [{
  value: ``,
  label: `All statuses`
}, {
  value: `submitted`,
  label: `Received`
}, {
  value: `under_review`,
  label: `Under Review`
}, {
  value: `quote_sent`,
  label: `Ready to Process`
}, {
  value: `quote_approved`,
  label: `Quote Sent`
}, {
  value: `in_progress`,
  label: `Approved`
}, {
  value: `processing`,
  label: `In Progress`
}, {
  value: `completed`,
  label: `Completed`
}, {
  value: `cancelled`,
  label: `Cancelled`
}];

function Sa({
  ref: e
}) {
  return (0, F.jsx)(`span`, {
    style: {
      fontSize: 12,
      color: ya,
      fontWeight: 700,
      fontFamily: `monospace`,
      letterSpacing: `.03em`
    },
    children: e || `—`
  })
}

function Ca({
  dueDate: e,
  workingDays: t
}) {
  if (!e) return null;
  let n = ba(e),
    r = t ? ` · ${t} working days` : ``;
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      alignItems: `center`,
      gap: 5,
      fontSize: 12,
      color: `var(--brand-dark)`,
      fontWeight: 600
    },
    children: [(0, F.jsx)(Gr, {
      size: 12
    }), `Est. delivery: `, n, r]
  })
}

function wa({
  b: e,
  onClick: t
}) {
  return (0, F.jsxs)(`div`, {
    onClick: t,
    style: {
      background: `#fff`,
      border: `1px solid var(--border)`,
      borderRadius: `var(--r-lg)`,
      padding: `16px 18px`,
      cursor: `pointer`,
      transition: `all var(--t)`,
      display: `flex`,
      flexDirection: `column`,
      gap: 10
    },
    onMouseEnter: e => {
      e.currentTarget.style.boxShadow = `var(--shadow-md)`, e.currentTarget.style.transform = `translateY(-2px)`
    },
    onMouseLeave: e => {
      e.currentTarget.style.boxShadow = ``, e.currentTarget.style.transform = ``
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        justifyContent: `space-between`,
        alignItems: `flex-start`,
        gap: 10
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          minWidth: 0
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            fontWeight: 700,
            fontSize: 15,
            color: `var(--text)`,
            marginBottom: 3,
            overflow: `hidden`,
            whiteSpace: `nowrap`,
            textOverflow: `ellipsis`
          },
          children: e.service_name || `Service Request`
        }), (0, F.jsx)(Sa, {
          ref: e.booking_ref
        })]
      }), (0, F.jsx)(Ji, {
        status: e.status
      })]
    }), e.secondary_status && (0, F.jsx)(`div`, {
      style: {
        fontSize: 12,
        color: `var(--muted)`,
        background: `var(--surface-3)`,
        borderRadius: `var(--r-sm)`,
        padding: `4px 8px`,
        fontStyle: `italic`
      },
      children: e.secondary_status
    }), (0, F.jsx)(Ca, {
      dueDate: e.due_date,
      workingDays: e.delivery_working_days
    }), (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        justifyContent: `space-between`,
        alignItems: `center`,
        fontSize: 12,
        color: `var(--muted)`,
        borderTop: `1px solid var(--border)`,
        paddingTop: 8
      },
      children: [(0, F.jsxs)(`span`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          gap: 4
        },
        children: [(0, F.jsx)(ti, {
          size: 11
        }), ` `, ba(e.created_at)]
      }), e.updated_at && e.updated_at !== e.created_at && (0, F.jsxs)(`span`, {
        style: {
          color: `var(--muted-2)`,
          fontSize: 11
        },
        children: [`Updated `, ba(e.updated_at)]
      }), e.quoted_amount && (0, F.jsxs)(`span`, {
        style: {
          fontWeight: 700,
          color: `var(--text-2)`
        },
        children: [`₹`, Number(e.quoted_amount).toLocaleString(`en-IN`)]
      })]
    })]
  })
}

function Ta() {
  let e = ut(),
    [t, n] = (0, _.useState)({
      rows: [],
      total: 0
    }),
    [r, i] = (0, _.useState)(!0),
    [a, o] = (0, _.useState)(``),
    [s, c] = (0, _.useState)(``),
    [l, u] = (0, _.useState)(1),
    d = (0, _.useCallback)(async () => {
      i(!0);
      try {
        let e = await or.list(l);
        n({
          rows: e.bookings || e.rows || [],
          total: e.total || 0
        })
      } catch {} finally {
        i(!1)
      }
    }, [l]);
  (0, _.useEffect)(() => {
    d()
  }, [d]);
  let f = t.rows.filter(e => {
      let t = a.toLowerCase(),
        n = !t || e.booking_ref?.toLowerCase().includes(t) || e.service_name?.toLowerCase().includes(t),
        r = !s || e.status === s;
      return n && r
    }),
    p = Math.max(1, Math.ceil(t.total / 12));
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      gap: 20
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        flexWrap: `wrap`,
        gap: 12
      },
      children: [(0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(`h1`, {
          style: {
            fontSize: 22,
            fontWeight: 800
          },
          children: `My Requests`
        }), (0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`,
            marginTop: 3
          },
          children: r ? `Loading…` : `${t.total} request${t.total===1?``:`s`} total`
        })]
      }), (0, F.jsx)(z, {
        icon: (0, F.jsx)(yi, {
          size: 16
        }),
        onClick: () => e(`/new-request`),
        children: `New Request`
      })]
    }), (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        gap: 10,
        flexWrap: `wrap`
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          position: `relative`,
          flex: 1,
          minWidth: 200
        },
        children: [(0, F.jsx)(Ci, {
          size: 15,
          style: {
            position: `absolute`,
            left: 11,
            top: `50%`,
            transform: `translateY(-50%)`,
            color: `var(--muted)`,
            pointerEvents: `none`
          }
        }), (0, F.jsx)(`input`, {
          value: a,
          onChange: e => o(e.target.value),
          placeholder: `Search by order ID or service…`,
          style: {
            width: `100%`,
            padding: `9px 13px 9px 34px`,
            fontSize: 14,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r)`,
            fontFamily: `inherit`,
            outline: `none`,
            boxSizing: `border-box`,
            background: `#fff`
          }
        })]
      }), (0, F.jsx)(Zi, {
        value: s,
        onChange: e => c(e.target.value),
        options: xa,
        style: {
          minWidth: 180
        }
      })]
    }), r ? (0, F.jsx)(`div`, {
      style: {
        display: `grid`,
        gridTemplateColumns: `repeat(auto-fill, minmax(300px, 1fr))`,
        gap: 14
      },
      children: [1, 2, 3, 4, 5, 6].map(e => (0, F.jsx)(na, {
        h: 140,
        style: {
          borderRadius: `var(--r-lg)`
        }
      }, e))
    }) : f.length === 0 ? (0, F.jsx)(`div`, {
      style: {
        background: `#fff`,
        border: `1px solid var(--border)`,
        borderRadius: `var(--r-lg)`,
        padding: 32
      },
      children: (0, F.jsx)(Qi, {
        icon: `🔍`,
        title: a || s ? `No matching requests` : `No requests yet`,
        desc: a || s ? `Try clearing the filters.` : `Submit your first service request to get started.`,
        action: !a && !s && (0, F.jsx)(z, {
          icon: (0, F.jsx)(yi, {
            size: 16
          }),
          onClick: () => e(`/new-request`),
          children: `New Request`
        })
      })
    }) : (0, F.jsx)(`div`, {
      style: {
        display: `grid`,
        gridTemplateColumns: `repeat(auto-fill, minmax(300px, 1fr))`,
        gap: 14
      },
      children: f.map(t => (0, F.jsx)(wa, {
        b: t,
        onClick: () => e(`/bookings/${t.id}`)
      }, t.id))
    }), p > 1 && (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `center`,
        gap: 10
      },
      children: [(0, F.jsxs)(`button`, {
        onClick: () => u(e => Math.max(1, e - 1)),
        disabled: l === 1,
        style: {
          background: `none`,
          border: `1px solid var(--border)`,
          borderRadius: `var(--r)`,
          padding: `7px 14px`,
          cursor: l === 1 ? `not-allowed` : `pointer`,
          color: l === 1 ? `var(--muted)` : `var(--text)`,
          display: `flex`,
          alignItems: `center`,
          gap: 4,
          fontSize: 13
        },
        children: [(0, F.jsx)(Jr, {
          size: 14
        }), ` Prev`]
      }), (0, F.jsxs)(`span`, {
        style: {
          fontSize: 13,
          color: `var(--muted)`
        },
        children: [`Page `, l, ` of `, p]
      }), (0, F.jsxs)(`button`, {
        onClick: () => u(e => Math.min(p, e + 1)),
        disabled: l === p,
        style: {
          background: `none`,
          border: `1px solid var(--border)`,
          borderRadius: `var(--r)`,
          padding: `7px 14px`,
          cursor: l === p ? `not-allowed` : `pointer`,
          color: l === p ? `var(--muted)` : `var(--text)`,
          display: `flex`,
          alignItems: `center`,
          gap: 4,
          fontSize: 13
        },
        children: [`Next `, (0, F.jsx)(Yr, {
          size: 14
        })]
      })]
    })]
  })
}
var Ea = `var(--brand)`,
  Da = [{
    key: `submitted`,
    label: `Received`
  }, {
    key: `under_review`,
    label: `Under Review`
  }, {
    key: `quote_sent`,
    label: `Quote Sent`
  }, {
    key: `quote_approved`,
    label: `Approved`
  }, {
    key: `in_progress`,
    label: `In Progress`
  }, {
    key: `processing`,
    label: `Processing`
  }, {
    key: `completed`,
    label: `Completed`
  }];

function Oa({
  status: e
}) {
  let t = e === `service_not_available`,
    n = t ? 1 : Da.findIndex(t => t.key === e);
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      alignItems: `center`,
      overflowX: `auto`,
      padding: `20px 24px`,
      background: `#fff`,
      border: `1px solid var(--border)`,
      borderRadius: `var(--r-lg)`,
      marginBottom: 12,
      boxShadow: `var(--shadow)`
    },
    children: [Da.map((e, r) => {
      let i = t && r > 1,
        a = !i && r <= n,
        o = !i && r === n && !t;
      return (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          flex: r < Da.length - 1 ? 1 : void 0
        },
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            flexDirection: `column`,
            alignItems: `center`,
            gap: 7,
            minWidth: 72
          },
          children: [(0, F.jsx)(`div`, {
            style: {
              width: 32,
              height: 32,
              borderRadius: `50%`,
              display: `flex`,
              alignItems: `center`,
              justifyContent: `center`,
              fontSize: 12,
              fontWeight: 700,
              transition: `all .3s`,
              flexShrink: 0,
              background: i ? `var(--border)` : a ? Ea : `var(--border)`,
              border: `3px solid ${i?`var(--border)`:a?Ea:`var(--border)`}`,
              color: a ? `#fff` : `var(--muted)`,
              boxShadow: o ? `0 0 0 4px ${Ea}30` : `none`,
              opacity: i ? .35 : 1
            },
            children: a && !o ? `✓` : ``
          }), (0, F.jsx)(`div`, {
            style: {
              fontSize: 10,
              fontWeight: 600,
              textAlign: `center`,
              lineHeight: 1.3,
              color: a && !i ? Ea : `var(--muted)`,
              opacity: i ? .35 : 1
            },
            children: e.label
          })]
        }), r < Da.length - 1 && (0, F.jsx)(`div`, {
          style: {
            flex: 1,
            height: 3,
            margin: `0 4px`,
            marginBottom: 22,
            minWidth: 16,
            background: !i && r < n ? Ea : `var(--border)`,
            transition: `background .3s`
          }
        })]
      }, e.key)
    }), t && (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        flexDirection: `column`,
        alignItems: `center`,
        gap: 7,
        minWidth: 72,
        marginLeft: 8
      },
      children: [(0, F.jsx)(`div`, {
        style: {
          width: 32,
          height: 32,
          borderRadius: `50%`,
          background: `var(--red)`,
          color: `#fff`,
          display: `flex`,
          alignItems: `center`,
          justifyContent: `center`,
          fontSize: 14,
          fontWeight: 800
        },
        children: `✗`
      }), (0, F.jsx)(`div`, {
        style: {
          fontSize: 10,
          fontWeight: 600,
          color: `var(--red)`,
          textAlign: `center`,
          lineHeight: 1.3
        },
        children: `Not Available`
      })]
    })]
  })
}

function ka({
  b: e
}) {
  let t = parseFloat(e.service_charges || e.quoted_amount || 0),
    n = parseFloat(e.shipping_charges || 0),
    r = t + n,
    i = t > 0 || n > 0;
  return (0, F.jsx)(`div`, {
    style: {
      display: `flex`,
      flexWrap: `wrap`,
      alignItems: `stretch`,
      background: `#fff`,
      border: `1px solid var(--border)`,
      borderRadius: `var(--r-lg)`,
      marginBottom: 12,
      boxShadow: `var(--shadow)`,
      overflow: `hidden`
    },
    children: [i && {
      label: `Service Charges`,
      value: `INR ${t.toLocaleString(`en-IN`,{minimumFractionDigits:2})}`
    }, i && {
      label: `Shipping Charges`,
      value: `INR ${n.toLocaleString(`en-IN`,{minimumFractionDigits:2})}`
    }, {
      label: `Total Amount`,
      value: i ? (0, F.jsxs)(`strong`, {
        children: [`INR `, r.toLocaleString(`en-IN`, {
          minimumFractionDigits: 2
        })]
      }) : `To be updated`
    }, {
      label: `Estimated Delivery`,
      value: e.delivery_info ? e.delivery_info.split(` (`)[0] : e.due_date ? new Date(e.due_date).toLocaleDateString(`en-IN`, {
        day: `numeric`,
        month: `short`,
        year: `numeric`
      }) : `To be updated`,
      sub: e.delivery_working_days ? `${e.delivery_working_days} working days — excl. Sat, Sun & Govt Holidays` : e.delivery_info && e.delivery_info.includes(`working days`) ? e.delivery_info.split(`(`)[1]?.replace(`)`, ``) : null
    }, {
      label: `Secondary Status`,
      value: e.secondary_status || `To be updated`
    }].filter(Boolean).map((e, t) => (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`
      },
      children: [t > 0 && (0, F.jsx)(`div`, {
        style: {
          width: 1,
          alignSelf: `stretch`,
          background: `var(--border)`,
          margin: `12px 0`
        }
      }), (0, F.jsxs)(`div`, {
        style: {
          padding: `14px 20px`,
          flex: 1
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            fontSize: 11,
            fontWeight: 700,
            color: `var(--muted)`,
            textTransform: `uppercase`,
            letterSpacing: `.05em`,
            marginBottom: 4
          },
          children: e.label
        }), (0, F.jsx)(`div`, {
          style: {
            fontSize: 14,
            fontWeight: 700,
            color: `var(--text)`
          },
          children: e.value
        }), e.sub && (0, F.jsx)(`div`, {
          style: {
            fontSize: 11,
            color: `var(--muted-2)`,
            marginTop: 2
          },
          children: e.sub
        })]
      })]
    }, t))
  })
}

function Aa({
  contact: e
}) {
  return !e || !e.name ? null : (0, F.jsxs)(`div`, {
    style: {
      background: `#fff`,
      border: `1px solid var(--border)`,
      borderRadius: `var(--r-lg)`,
      padding: `14px 20px`,
      marginBottom: 12,
      boxShadow: `var(--shadow)`,
      display: `flex`,
      alignItems: `center`,
      gap: 16
    },
    children: [(0, F.jsx)(`div`, {
      style: {
        width: 44,
        height: 44,
        borderRadius: `50%`,
        background: `linear-gradient(135deg, ${Ea}, #1E2D40)`,
        color: `#fff`,
        display: `flex`,
        alignItems: `center`,
        justifyContent: `center`,
        fontSize: 17,
        fontWeight: 800,
        flexShrink: 0
      },
      children: e.name[0].toUpperCase()
    }), (0, F.jsxs)(`div`, {
      style: {
        flex: 1,
        minWidth: 0
      },
      children: [(0, F.jsx)(`div`, {
        style: {
          fontSize: 11,
          fontWeight: 700,
          color: `var(--muted)`,
          textTransform: `uppercase`,
          letterSpacing: `.05em`,
          marginBottom: 3
        },
        children: `Contact Order Manager`
      }), (0, F.jsx)(`div`, {
        style: {
          fontSize: 15,
          fontWeight: 700,
          color: `var(--text)`,
          marginBottom: 4
        },
        children: e.name
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          flexWrap: `wrap`,
          gap: `4px 16px`
        },
        children: [e.phone && (0, F.jsxs)(`a`, {
          href: `tel:${e.phone}`,
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 5,
            fontSize: 13,
            color: Ea,
            textDecoration: `none`,
            fontWeight: 600
          },
          children: [(0, F.jsx)(vi, {
            size: 13
          }), ` `, e.phone]
        }), e.email && (0, F.jsxs)(`a`, {
          href: `mailto:${e.email}`,
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 5,
            fontSize: 13,
            color: Ea,
            textDecoration: `none`,
            fontWeight: 600
          },
          children: [(0, F.jsx)(Vr, {
            size: 13
          }), ` `, e.email]
        })]
      })]
    })]
  })
}

function ja({
  m: e,
  curUid: t
}) {
  let n = String(e.sender_id) === String(t),
    r = e.sender_type === `staff` || e.is_staff_message,
    i = n ? `You` : r ? `Support Team` : e.sender_name || `Support`;
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      alignItems: n ? `flex-end` : `flex-start`,
      marginBottom: 16
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        gap: 8,
        marginBottom: 4,
        flexDirection: n ? `row-reverse` : `row`
      },
      children: [(0, F.jsx)(`span`, {
        style: {
          fontSize: 12,
          fontWeight: 700,
          color: n ? Ea : `var(--muted)`
        },
        children: i
      }), (0, F.jsx)(`span`, {
        style: {
          fontSize: 11,
          color: `var(--muted-2)`
        },
        children: new Date(e.created_at).toLocaleString(`en-IN`, {
          day: `numeric`,
          month: `short`,
          hour: `2-digit`,
          minute: `2-digit`
        })
      }), Number(e.is_email_sent) === 1 && (0, F.jsx)(`span`, {
        style: {
          fontSize: 10,
          fontWeight: 700,
          padding: `1px 6px`,
          background: `var(--brand-light)`,
          border: `1px solid #bae6fd`,
          color: `var(--brand-dark)`,
          borderRadius: 4,
          display: `inline-flex`,
          alignItems: `center`,
          gap: 3,
          whiteSpace: `nowrap`
        },
        children: `✉ Sent via Email`
      })]
    }), (0, F.jsx)(`div`, {
      style: {
        background: n ? Ea : `var(--surface-3)`,
        color: n ? `#fff` : `var(--text)`,
        borderRadius: n ? `12px 12px 2px 12px` : `2px 12px 12px 12px`,
        padding: `11px 16px`,
        fontSize: 13,
        lineHeight: 1.65,
        maxWidth: `88%`,
        whiteSpace: `pre-wrap`,
        wordBreak: `break-word`
      },
      children: e.message
    })]
  })
}

function Ma({
  title: e,
  docs: t,
  defaultOpen: n,
  onUpload: r,
  bookingId: i
}) {
  let [a, o] = (0, _.useState)(n), [s, c] = (0, _.useState)([]), [l, u] = (0, _.useState)(!1), d = R(), f = t.map(e => e.id), p = f.length > 0 && f.every(e => s.includes(e));

  function m() {
    c(p ? [] : f)
  }

  function h(e) {
    c(t => t.includes(e) ? t.filter(t => t !== e) : [...t, e])
  }
  async function g(e) {
    if (e.length !== 0) {
      u(!0);
      try {
        let t = window.S2NRI_CFG || {},
          n = await fetch(`${t.base}/bookings/${i}/documents/download-zip`, {
            method: `POST`,
            credentials: `include`,
            headers: {
              "X-WP-Nonce": t.nonce,
              "Content-Type": `application/json`
            },
            body: JSON.stringify({
              doc_ids: e
            })
          });
        if (!n.ok) throw Error(`Download failed`);
        let r = await n.blob(),
          a = URL.createObjectURL(r),
          o = document.createElement(`a`);
        o.href = a, o.download = `documents-${i}.zip`, o.click(), URL.revokeObjectURL(a), d(`Download started`, `success`)
      } catch (e) {
        d(e.message || `Download failed`, `error`)
      } finally {
        u(!1)
      }
    }
  }
  async function v(e) {
    if (window.confirm(`Delete this document?`)) try {
      let t = window.S2NRI_CFG || {};
      await fetch(`${t.base}/bookings/${i}/documents/${e}`, {
        method: `DELETE`,
        credentials: `include`,
        headers: {
          "X-WP-Nonce": t.nonce
        }
      }), d(`Document deleted`, `success`), window.location.reload()
    } catch {
      d(`Delete failed`, `error`)
    }
  }
  return (0, F.jsxs)(`div`, {
    style: {
      borderBottom: `1px solid var(--border)`
    },
    children: [(0, F.jsxs)(`button`, {
      onClick: () => o(e => !e),
      style: {
        width: `100%`,
        textAlign: `left`,
        padding: `12px 16px`,
        background: `var(--surface-2)`,
        border: `none`,
        cursor: `pointer`,
        fontSize: 13,
        fontWeight: 700,
        color: `var(--text)`,
        display: `flex`,
        justifyContent: `space-between`,
        alignItems: `center`,
        fontFamily: `inherit`
      },
      children: [(0, F.jsxs)(`span`, {
        children: [e, ` `, (0, F.jsxs)(`span`, {
          style: {
            fontWeight: 400,
            color: `var(--muted)`
          },
          children: [`(`, t.length, `)`]
        })]
      }), (0, F.jsx)(`span`, {
        style: {
          fontSize: 10,
          color: `var(--muted)`
        },
        children: a ? `▴` : `▾`
      })]
    }), a && (0, F.jsxs)(`div`, {
      children: [t.length === 0 ? (0, F.jsx)(`p`, {
        style: {
          padding: `12px 16px`,
          color: `var(--muted)`,
          fontSize: 13,
          margin: 0
        },
        children: `No documents yet.`
      }) : (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 8,
            padding: `8px 16px`,
            background: `var(--surface-3)`,
            borderBottom: `1px solid var(--border)`,
            flexWrap: `wrap`
          },
          children: [(0, F.jsxs)(`label`, {
            style: {
              display: `flex`,
              alignItems: `center`,
              gap: 6,
              fontSize: 13,
              color: `var(--muted)`,
              cursor: `pointer`
            },
            children: [(0, F.jsx)(`input`, {
              type: `checkbox`,
              checked: p,
              onChange: m,
              style: {
                width: 15,
                height: 15
              }
            }), `Select All`]
          }), s.length > 0 && (0, F.jsxs)(`button`, {
            onClick: () => g(s),
            disabled: l,
            style: {
              padding: `4px 12px`,
              fontSize: 12,
              fontWeight: 600,
              cursor: `pointer`,
              border: `1px solid ${Ea}`,
              borderRadius: `var(--r-sm)`,
              background: `#fff`,
              color: Ea,
              fontFamily: `inherit`
            },
            children: [`↓ Download Selected (`, s.length, `)`]
          }), (0, F.jsx)(`button`, {
            onClick: () => g(f),
            disabled: l,
            style: {
              padding: `4px 12px`,
              fontSize: 12,
              fontWeight: 600,
              cursor: `pointer`,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r-sm)`,
              background: `var(--surface-2)`,
              color: `var(--text-2)`,
              fontFamily: `inherit`,
              marginLeft: `auto`
            },
            children: `↓ Download All`
          })]
        }), t.map(e => {
          let t = e.download_url || window.S2NRI_CFG?.base + `/bookings/${i}/documents/${e.id}/download`;
          return (0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              alignItems: `center`,
              gap: 10,
              padding: `10px 16px`,
              borderBottom: `1px solid #f1f5f9`,
              fontSize: 13
            },
            children: [(0, F.jsx)(`input`, {
              type: `checkbox`,
              checked: s.includes(e.id),
              onChange: () => h(e.id),
              style: {
                width: 15,
                height: 15,
                flexShrink: 0
              }
            }), (0, F.jsxs)(`div`, {
              style: {
                flex: 1,
                minWidth: 0
              },
              children: [(0, F.jsx)(`div`, {
                style: {
                  fontWeight: 600,
                  color: `var(--text)`,
                  overflow: `hidden`,
                  textOverflow: `ellipsis`,
                  whiteSpace: `nowrap`
                },
                children: e.doc_type || e.original_name || `Document`
              }), (0, F.jsxs)(`div`, {
                style: {
                  fontSize: 11,
                  color: `var(--muted)`,
                  marginTop: 2
                },
                children: [e.uploaded_by_name || (e.is_from_staff ? `Support Team` : `You`), e.created_at && ` · ${new Date(e.created_at).toLocaleDateString(`en-IN`)}`]
              })]
            }), (0, F.jsxs)(`div`, {
              style: {
                display: `flex`,
                gap: 8,
                alignItems: `center`,
                flexShrink: 0
              },
              children: [(0, F.jsxs)(`a`, {
                href: t,
                target: `_blank`,
                rel: `noopener noreferrer`,
                style: {
                  display: `flex`,
                  alignItems: `center`,
                  gap: 4,
                  padding: `5px 10px`,
                  background: `${Ea}15`,
                  color: Ea,
                  borderRadius: `var(--r-sm)`,
                  textDecoration: `none`,
                  fontSize: 12,
                  fontWeight: 600
                },
                children: [(0, F.jsx)(ai, {
                  size: 13
                }), ` Download`]
              }), !e.is_from_staff && (0, F.jsx)(`button`, {
                onClick: () => v(e.id),
                style: {
                  background: `none`,
                  border: `none`,
                  cursor: `pointer`,
                  color: `var(--red)`,
                  padding: `4px 6px`,
                  fontSize: 16,
                  lineHeight: 1
                },
                children: `🗑`
              })]
            })]
          }, e.id)
        })]
      }), r && (0, F.jsx)(`div`, {
        style: {
          padding: `10px 16px`
        },
        children: (0, F.jsx)(z, {
          size: `sm`,
          variant: `outline`,
          icon: (0, F.jsx)(Fi, {
            size: 13
          }),
          onClick: r,
          children: `Upload Document`
        })
      })]
    })]
  })
}

function Na() {
  let {
    id: e
  } = mt(), t = ut(), n = R(), [r, i] = (0, _.useState)(null), [a, o] = (0, _.useState)(!0), [s, c] = (0, _.useState)(`messages`), [l, u] = (0, _.useState)(``), [d, f] = (0, _.useState)(!1), [ql, qf] = (0, _.useState)(!1), p = (0, _.useRef)(null), m = (0, _.useRef)(null), [h, g] = (0, _.useState)(!1), [v, y] = (0, _.useState)(``), [b, x] = (0, _.useState)(null), [S, C] = (0, _.useState)(!1), [w, T] = (0, _.useState)(0), E = (0, _.useRef)(null), [D, O] = (0, _.useState)(!1), [ee, te] = (0, _.useState)(``), [k, ne] = (0, _.useState)(``), [re, ie] = (0, _.useState)(!1), [ae, A] = (0, _.useState)([]), j = r?.customer?.wp_user_id || window.S2NRI_CFG?.user_id, oe = (0, _.useCallback)(async () => {
    try {
      let t = await or.get(e);
      i(t.booking || t)
    } catch (e) {
      n(e?.message || `Could not load request. Please try again.`, `error`), t(`/bookings`)
    } finally {
      o(!1)
    }
  }, [e]);
  (0, _.useEffect)(() => {
    oe()
  }, [oe]), (0, _.useEffect)(() => {
    p.current && (p.current.scrollTop = p.current.scrollHeight)
  }, [r?.messages?.length]), (0, _.useEffect)(() => (m.current = setInterval(async () => {
    try {
      let t = await or.get(e);
      i(e => e && {
        ...e,
        messages: t.booking?.messages || t.messages || e.messages
      })
    } catch {}
  }, 4e3), () => clearInterval(m.current)), [e]);
  async function se(t = !1) {
    if (!l.trim()) {
      n(`Type a message first`, `error`);
      return
    }
    t ? qf(!0) : f(!0);
    try {
      await or.sendMsg(e, {
        message: l,
        send_email: t
      }), u(``), await oe()
    } catch (e) {
      n(e.message || `Send failed`, `error`)
    } finally {
      t ? qf(!1) : f(!1)
    }
  }
  async function ce() {
    if (!b) {
      n(`Select a file first`, `error`);
      return
    }
    if (b.size > 10 * 1024 * 1024) {
      n(`File exceeds 10 MB`, `error`);
      return
    }
    C(!0), T(0);
    try {
      let t = new FormData;
      t.append(`file`, b), t.append(`doc_type`, v || `Document`), t.append(`booking_id`, e);
      let r = window.S2NRI_CFG?.base || ``,
        i = window.S2NRI_CFG?.nonce || ``,
        a = localStorage.getItem(`s2nri_portal_token`) || ``,
        o = {
          "X-WP-Nonce": i
        };
      a && (o[`X-S2NRI-Token`] = a), await new Promise((n, i) => {
        let a = new XMLHttpRequest;
        a.upload.addEventListener(`progress`, e => {
          e.lengthComputable && T(Math.round(e.loaded / e.total * 100))
        }), a.open(`POST`, `${r}/bookings/${e}/documents`), Object.entries(o).forEach(([e, t]) => a.setRequestHeader(e, t)), a.withCredentials = !0, a.onload = () => a.status < 300 ? n() : i(Error(`Upload failed`)), a.onerror = () => i(Error(`Network error`)), a.send(t)
      }), n(`Document uploaded!`, `success`), x(null), y(``), g(!1), T(0), await oe()
    } catch (e) {
      n(e.message || `Upload failed`, `error`)
    } finally {
      C(!1)
    }
  }
  async function le() {
    if (!ee) {
      n(`Select a category`, `error`);
      return
    }
    ie(!0);
    try {
      await or.createTicket(e, {
        category: ee,
        notes: k
      }), n(`Request submitted!`, `success`), O(!1), te(``), ne(``), await oe()
    } catch (e) {
      n(e.message || `Submission failed`, `error`)
    } finally {
      ie(!1)
    }
  }
  async function ue() {
    if (O(!0), ae.length === 0) try {
      let e = await Sr.list(),
        t = e.types || e.request_types || [];
      t.length > 0 && A(t.map(e => e.name))
    } catch {
      A([`Refund`, `Shipping`, `Order Status`, `Payment Issue`, `Login / Sign Up`, `Other`])
    }
  }
  if (a) return (0, F.jsx)(`div`, {
    style: {
      display: `flex`,
      justifyContent: `center`,
      padding: 60
    },
    children: (0, F.jsx)(Wi, {
      size: 32
    })
  });
  if (!r) return null;
  let M = r,
    de = (M.messages || []).filter(e => !String(e.message || ``).startsWith(`[Email] `)),
    fe = M.user_documents || (M.documents || []).filter(e => !e.is_from_staff),
    pe = M.provider_documents || (M.documents || []).filter(e => e.is_from_staff),
    me = M.tickets || [],
    he = typeof M.field_data == `string` ? JSON.parse(M.field_data || `{}`) : M.field_data || {},
    ge = M.manager_contact || (M.assigned_name ? {
      name: M.assigned_name,
      email: M.assigned_email,
      phone: M.assigned_phone
    } : null),
    _e = [{
      key: `messages`,
      label: `Messages`,
      icon: (0, F.jsx)(hi, {
        size: 14
      }),
      count: de.length
    }, {
      key: `documents`,
      label: `Documents`,
      icon: (0, F.jsx)(oi, {
        size: 14
      }),
      count: fe.length + pe.length
    }, {
      key: `details`,
      label: `Form Details`,
      icon: (0, F.jsx)(ci, {
        size: 14
      })
    }, {
      key: `tickets`,
      label: `Service Requests`,
      icon: (0, F.jsx)(ki, {
        size: 14
      }),
      count: me.length
    }];
  return (0, F.jsxs)(`div`, {
    style: {
      maxWidth: 900,
      margin: `0 auto`,
      animation: `fadeIn 200ms ease both`
    },
    children: [(0, F.jsxs)(`button`, {
      onClick: () => t(`/bookings`),
      style: {
        display: `flex`,
        alignItems: `center`,
        gap: 6,
        background: `none`,
        border: `none`,
        cursor: `pointer`,
        fontSize: 14,
        color: `var(--muted)`,
        fontFamily: `inherit`,
        padding: 0,
        marginBottom: 16
      },
      children: [(0, F.jsx)(zr, {
        size: 16
      }), ` Back to My Requests`]
    }), (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `flex-start`,
        justifyContent: `space-between`,
        flexWrap: `wrap`,
        gap: 12,
        marginBottom: 16
      },
      children: [(0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(`div`, {
          style: {
            fontSize: 12,
            fontWeight: 700,
            color: `var(--muted)`,
            textTransform: `uppercase`,
            letterSpacing: `.06em`,
            marginBottom: 4
          },
          children: `Order Reference`
        }), (0, F.jsx)(`h1`, {
          style: {
            fontSize: 22,
            fontWeight: 800,
            margin: `0 0 4px`,
            fontFamily: `monospace`,
            letterSpacing: `.03em`
          },
          children: M.booking_ref || `#${M.id}`
        }), (0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`,
            margin: 0
          },
          children: M.service_name || `Service Request`
        })]
      }), (0, F.jsx)(Ji, {
        status: M.status,
        size: `lg`
      })]
    }), (0, F.jsx)(Oa, {
      status: M.status
    }), (0, F.jsx)(ka, {
      b: M
    }), (0, F.jsx)(Aa, {
      contact: ge
    }), (0, F.jsxs)(B, {
      padding: `0`,
      style: {
        overflow: `hidden`
      },
      children: [(0, F.jsx)(ia, {
        tabs: _e,
        active: s,
        onChange: c
      }), s === `messages` && (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          flexDirection: `column`,
          height: 500
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            padding: `10px 16px 0`,
            display: `flex`,
            justifyContent: `flex-end`
          },
          children: (0, F.jsx)(`button`, {
            onClick: oe,
            style: {
              display: `flex`,
              alignItems: `center`,
              gap: 5,
              fontSize: 12,
              color: `var(--muted)`,
              background: `none`,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r-sm)`,
              padding: `4px 10px`,
              cursor: `pointer`,
              fontFamily: `inherit`,
              transition: `var(--t)`
            },
            onMouseEnter: e => {
              e.currentTarget.style.color = Ea, e.currentTarget.style.borderColor = Ea
            },
            onMouseLeave: e => {
              e.currentTarget.style.color = `var(--muted)`, e.currentTarget.style.borderColor = `var(--border)`
            },
            children: `↻ Refresh`
          })
        }), (0, F.jsx)(`div`, {
          ref: p,
          style: {
            flex: 1,
            overflowY: `auto`,
            padding: `8px 20px 0`
          },
          children: de.length === 0 ? (0, F.jsxs)(`div`, {
            style: {
              textAlign: `center`,
              padding: `40px 0`,
              color: `var(--muted)`
            },
            children: [(0, F.jsx)(hi, {
              size: 32,
              style: {
                opacity: .3,
                marginBottom: 8
              }
            }), (0, F.jsx)(`p`, {
              style: {
                margin: 0,
                fontSize: 14
              },
              children: `No messages yet. Send one below.`
            })]
          }) : de.map(e => (0, F.jsx)(ja, {
            m: e,
            curUid: j
          }, e.id))
        }), (0, F.jsxs)(`div`, {
          style: {
            borderTop: `1px solid var(--border)`,
            padding: 16
          },
          children: [(0, F.jsx)(`textarea`, {
            value: l,
            onChange: e => u(e.target.value),
            placeholder: `Type your message here…`,
            rows: 3,
            onKeyDown: e => {
              e.key === `Enter` && !e.shiftKey && (e.preventDefault(), se(!1))
            },
            style: {
              width: `100%`,
              padding: `9px 13px`,
              fontSize: 13,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              fontFamily: `inherit`,
              outline: `none`,
              resize: `none`,
              marginBottom: 10,
              boxSizing: `border-box`
            },
            onFocus: e => e.target.style.borderColor = Ea,
            onBlur: e => e.target.style.borderColor = `var(--border)`
          }), (0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              alignItems: `center`,
              justifyContent: `space-between`,
              gap: 8,
              flexWrap: `wrap`
            },
            children: [(0, F.jsx)(`p`, {
              style: {
                fontSize: 11,
                color: `var(--muted-2)`,
                margin: 0
              },
              children: `"Send" saves to chat only. "Send via Email" saves here + sends you an email notification.`
            }), (0, F.jsxs)(`div`, {
              style: {
                display: `flex`,
                gap: 8
              },
              children: [(0, F.jsx)(z, {
                size: `sm`,
                variant: `ghost`,
                loading: d,
                disabled: ql,
                icon: (0, F.jsx)(wi, {
                  size: 13
                }),
                onClick: () => se(!1),
                children: `Send`
              }), (0, F.jsx)(z, {
                size: `sm`,
                variant: `outline`,
                loading: ql,
                disabled: d,
                icon: (0, F.jsx)(pi, {
                  size: 13
                }),
                onClick: () => se(!0),
                children: `Send via Email`
              })]
            })]
          })]
        })]
      }), s === `documents` && (0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(Ma, {
          title: `Your Documents`,
          docs: fe,
          defaultOpen: !0,
          bookingId: e,
          onUpload: () => g(!0)
        }), (0, F.jsx)(Ma, {
          title: `Documents from Support Team`,
          docs: pe,
          defaultOpen: !1,
          bookingId: e
        }), h && (0, F.jsxs)(`div`, {
          style: {
            padding: 16,
            background: `var(--surface-2)`,
            borderTop: `1px solid var(--border)`
          },
          children: [(0, F.jsx)(`div`, {
            style: {
              fontWeight: 700,
              fontSize: 14,
              marginBottom: 12
            },
            children: `Upload a Document`
          }), (0, F.jsxs)(`div`, {
            style: {
              marginBottom: 10
            },
            children: [(0, F.jsx)(`label`, {
              style: {
                display: `block`,
                fontSize: 13,
                fontWeight: 600,
                marginBottom: 5
              },
              children: `Document Name`
            }), (0, F.jsx)(`input`, {
              value: v,
              onChange: e => y(e.target.value),
              placeholder: `e.g. Passport Copy`,
              style: {
                width: `100%`,
                padding: `8px 12px`,
                fontSize: 14,
                border: `1px solid var(--border)`,
                borderRadius: `var(--r)`,
                fontFamily: `inherit`,
                outline: `none`,
                boxSizing: `border-box`
              }
            })]
          }), (0, F.jsxs)(`div`, {
            onClick: () => E.current?.click(),
            onDragOver: e => {
              e.preventDefault(), e.currentTarget.style.borderColor = Ea
            },
            onDragLeave: e => {
              e.currentTarget.style.borderColor = `var(--border)`
            },
            onDrop: e => {
              e.preventDefault(), e.currentTarget.style.borderColor = `var(--border)`;
              let t = e.dataTransfer.files[0];
              t && x(t)
            },
            style: {
              border: `2px dashed ${b?Ea:`var(--border)`}`,
              borderRadius: `var(--r)`,
              padding: 24,
              textAlign: `center`,
              cursor: `pointer`,
              background: b ? `${Ea}08` : `var(--surface-2)`,
              marginBottom: 10
            },
            children: [(0, F.jsx)(`input`, {
              ref: E,
              type: `file`,
              accept: `.pdf,.jpg,.jpeg,.png`,
              style: {
                display: `none`
              },
              onChange: e => x(e.target.files[0] || null)
            }), (0, F.jsx)(Fi, {
              size: 22,
              style: {
                color: `var(--muted)`,
                marginBottom: 8
              }
            }), (0, F.jsx)(`p`, {
              style: {
                margin: 0,
                fontSize: 13,
                color: `var(--muted)`
              },
              children: b ? b.name : `Drop file here or click to browse (PDF / JPG / PNG, max 10 MB)`
            })]
          }), w > 0 && w < 100 && (0, F.jsx)(`div`, {
            style: {
              background: `var(--border)`,
              borderRadius: 3,
              height: 6,
              overflow: `hidden`,
              marginBottom: 10
            },
            children: (0, F.jsx)(`div`, {
              style: {
                width: `${w}%`,
                height: `100%`,
                background: Ea,
                transition: `width .2s`
              }
            })
          }), (0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              gap: 8
            },
            children: [(0, F.jsx)(z, {
              size: `sm`,
              loading: S,
              icon: (0, F.jsx)(Fi, {
                size: 13
              }),
              onClick: ce,
              children: `Upload`
            }), (0, F.jsx)(z, {
              size: `sm`,
              variant: `ghost`,
              onClick: () => {
                g(!1), x(null), y(``)
              },
              children: `Cancel`
            })]
          })]
        })]
      }), s === `details` && (0, F.jsxs)(`div`, {
        style: {
          padding: 20
        },
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            justifyContent: `space-between`,
            alignItems: `center`,
            marginBottom: 16,
            flexWrap: `wrap`,
            gap: 10
          },
          children: [(0, F.jsx)(`h3`, {
            style: {
              margin: 0,
              fontSize: 15
            },
            children: `Submitted Form Data`
          }), (0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              gap: 8
            },
            children: [(0, F.jsx)(`button`, {
              onClick: () => {
                let e = window.S2NRI_CFG || {};
                window.open(`${e.base}/admin/form-submissions/${M.id}/export?format=pdf&_wpnonce=${e.nonce}`, `_blank`)
              },
              style: {
                padding: `6px 14px`,
                fontSize: 12,
                fontWeight: 600,
                cursor: `pointer`,
                border: `1px solid ${Ea}`,
                borderRadius: `var(--r-sm)`,
                background: Ea,
                color: `#fff`,
                fontFamily: `inherit`
              },
              children: `📄 PDF`
            }), (0, F.jsx)(`button`, {
              onClick: () => {
                let e = window.S2NRI_CFG || {};
                window.open(`${e.base}/admin/form-submissions/${M.id}/export?format=png&_wpnonce=${e.nonce}`, `_blank`)
              },
              style: {
                padding: `6px 14px`,
                fontSize: 12,
                fontWeight: 600,
                cursor: `pointer`,
                border: `1px solid var(--border)`,
                borderRadius: `var(--r-sm)`,
                background: `#fff`,
                color: `var(--text-2)`,
                fontFamily: `inherit`
              },
              children: `🖼 PNG / Image`
            })]
          })]
        }), Object.keys(he).filter(e => !e.startsWith(`__`)).length === 0 ? (0, F.jsx)(`p`, {
          style: {
            color: `var(--muted)`,
            fontSize: 14,
            margin: 0
          },
          children: `No form data available.`
        }) : (0, F.jsx)(`table`, {
          style: {
            width: `100%`,
            fontSize: 14,
            borderCollapse: `collapse`
          },
          children: (0, F.jsx)(`tbody`, {
            children: Object.entries(he).filter(([e]) => !e.startsWith(`__`)).map(([e, t]) => (0, F.jsxs)(`tr`, {
              style: {
                borderBottom: `1px solid var(--border)`
              },
              children: [(0, F.jsx)(`td`, {
                style: {
                  padding: `10px 14px`,
                  fontWeight: 600,
                  color: `var(--text-2)`,
                  width: `40%`,
                  background: `var(--surface-2)`,
                  textTransform: `capitalize`
                },
                children: e.replace(/_/g, ` `)
              }), (0, F.jsx)(`td`, {
                style: {
                  padding: `10px 14px`,
                  color: `var(--text)`
                },
                children: String(t || `—`)
              })]
            }, e))
          })
        })]
      }), s === `tickets` && (0, F.jsxs)(`div`, {
        style: {
          padding: 16
        },
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            justifyContent: `space-between`,
            alignItems: `center`,
            marginBottom: 12,
            flexWrap: `wrap`,
            gap: 8
          },
          children: [(0, F.jsx)(`h3`, {
            style: {
              margin: 0,
              fontSize: 15
            },
            children: `Service Requests`
          }), (0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              gap: 8,
              alignItems: `center`
            },
            children: [me.length > 0 && (0, F.jsx)(`input`, {
              placeholder: `Search tickets…`,
              onChange: e => {
                let t = e.target.value.toLowerCase();
                document.querySelectorAll(`.ticket-row`).forEach(e => {
                  e.style.display = !t || e.textContent.toLowerCase().includes(t) ? `` : `none`
                })
              },
              style: {
                padding: `6px 12px`,
                fontSize: 13,
                border: `1px solid var(--border)`,
                borderRadius: `var(--r)`,
                fontFamily: `inherit`,
                outline: `none`,
                width: 160
              }
            }), (0, F.jsx)(z, {
              size: `sm`,
              onClick: ue,
              children: `⊕ New Request`
            })]
          })]
        }), me.length === 0 ? (0, F.jsx)(Qi, {
          icon: `🎫`,
          title: `No service requests yet`,
          desc: `Use this to raise a query, request a status update, or ask for additional assistance.`
        }) : (0, F.jsx)(`div`, {
          style: {
            overflowX: `auto`
          },
          children: (0, F.jsxs)(`table`, {
            style: {
              width: `100%`,
              fontSize: 13,
              borderCollapse: `collapse`
            },
            children: [(0, F.jsx)(`thead`, {
              children: (0, F.jsx)(`tr`, {
                style: {
                  background: `var(--surface-2)`
                },
                children: [`Ticket ID`, `Category`, `Status`, `Created`, `Updated`].map(e => (0, F.jsx)(`th`, {
                  style: {
                    padding: `10px 12px`,
                    textAlign: `left`,
                    fontSize: 12,
                    fontWeight: 700,
                    color: `var(--muted)`,
                    textTransform: `uppercase`,
                    letterSpacing: `.04em`,
                    borderBottom: `1px solid var(--border)`,
                    whiteSpace: `nowrap`
                  },
                  children: e
                }, e))
              })
            }), (0, F.jsx)(`tbody`, {
              children: me.map(e => (0, F.jsxs)(`tr`, {
                className: `ticket-row`,
                style: {
                  borderBottom: `1px solid var(--border)`
                },
                children: [(0, F.jsxs)(`td`, {
                  style: {
                    padding: `11px 12px`,
                    fontWeight: 700
                  },
                  children: [`#T-`, String(e.id).padStart(4, `0`)]
                }), (0, F.jsx)(`td`, {
                  style: {
                    padding: `11px 12px`
                  },
                  children: e.category
                }), (0, F.jsx)(`td`, {
                  style: {
                    padding: `11px 12px`
                  },
                  children: (0, F.jsx)(`span`, {
                    style: {
                      padding: `3px 10px`,
                      borderRadius: `var(--r-full)`,
                      fontSize: 11,
                      fontWeight: 700,
                      background: [`resolved`, `closed`].includes(e.status) ? `var(--green-bg)` : `var(--amber-bg)`,
                      color: [`resolved`, `closed`].includes(e.status) ? `var(--green)` : `var(--amber)`
                    },
                    children: (e.status || ``).replace(/_/g, ` `).replace(/\b\w/g, e => e.toUpperCase())
                  })
                }), (0, F.jsx)(`td`, {
                  style: {
                    padding: `11px 12px`,
                    color: `var(--muted)`
                  },
                  children: new Date(e.created_at).toLocaleDateString(`en-IN`)
                }), (0, F.jsx)(`td`, {
                  style: {
                    padding: `11px 12px`,
                    color: `var(--muted)`
                  },
                  children: new Date(e.updated_at).toLocaleDateString(`en-IN`)
                })]
              }, e.id))
            })]
          })
        })]
      })]
    }), (0, F.jsx)($i, {
      open: D,
      onClose: () => O(!1),
      title: `Other Service Request`,
      footer: (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(z, {
          variant: `ghost`,
          onClick: () => O(!1),
          children: `Cancel`
        }), (0, F.jsx)(z, {
          loading: re,
          onClick: le,
          children: `Submit`
        })]
      }),
      children: (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          flexDirection: `column`,
          gap: 14
        },
        children: [(0, F.jsxs)(`div`, {
          children: [(0, F.jsxs)(`label`, {
            style: {
              display: `block`,
              fontSize: 13,
              fontWeight: 600,
              marginBottom: 5
            },
            children: [`Category `, (0, F.jsx)(`span`, {
              style: {
                color: `var(--red)`
              },
              children: `*`
            })]
          }), (0, F.jsxs)(`select`, {
            value: ee,
            onChange: e => te(e.target.value),
            style: {
              width: `100%`,
              padding: `9px 12px`,
              fontSize: 14,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              fontFamily: `inherit`,
              outline: `none`,
              appearance: `none`,
              cursor: `pointer`,
              boxSizing: `border-box`
            },
            children: [(0, F.jsx)(`option`, {
              value: ``,
              children: `-- Select Category --`
            }), (ae.length > 0 ? ae : [`Refund`, `Shipping`, `Order Status`, `Payment Issue`, `Login / Sign Up`, `Other`]).map(e => (0, F.jsx)(`option`, {
              value: e,
              children: e
            }, e))]
          })]
        }), (0, F.jsxs)(`div`, {
          children: [(0, F.jsx)(`label`, {
            style: {
              display: `block`,
              fontSize: 13,
              fontWeight: 600,
              marginBottom: 5
            },
            children: `Notes`
          }), (0, F.jsx)(`textarea`, {
            value: k,
            onChange: e => ne(e.target.value),
            rows: 4,
            placeholder: `Describe your request in detail…`,
            style: {
              width: `100%`,
              padding: `9px 12px`,
              fontSize: 14,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              fontFamily: `inherit`,
              outline: `none`,
              resize: `vertical`,
              boxSizing: `border-box`
            }
          })]
        })]
      })
    })]
  })
}
var Pa = `var(--brand)`;

function Fa(e, t) {
  let n = e.conditions;
  if (!n) return !0;
  if (n.show_if && typeof n.show_if == `object`) return Object.entries(n.show_if).every(([e, n]) => {
    let r = t[e];
    return r !== void 0 && String(r) === String(n)
  });
  if (n.rules && Array.isArray(n.rules)) {
    if (n.rules.length === 0) return !0;
    let e = n.rules.map(e => {
      let n = String(t[e.field] || ``),
        r = String(e.value || ``);
      switch (e.operator) {
        case `equals`:
          return n === r;
        case `not_equals`:
          return n !== r;
        case `contains`:
          return n.toLowerCase().includes(r.toLowerCase());
        default:
          return n === r
      }
    });
    return n.action === `any` ? e.some(Boolean) : e.every(Boolean)
  }
  return !0
}

function Ia({
  field: e,
  value: t,
  onChange: n,
  error: r,
  allValues: i = {}
}) {
  let a = `sf_${e.key}`;
  if (!Fa(e, i)) return null;
  let o = e.eligibility_rule,
    s = o && t && String(t) === String(o.warn_if),
    c = s ? o.message : null,
    l = s && o.severity === `hard`,
    u = e.description || e.hint || ``,
    d = (0, F.jsxs)(`label`, {
      htmlFor: a,
      style: {
        display: `block`,
        fontSize: 13,
        fontWeight: 600,
        color: `var(--text-2)`,
        marginBottom: 5
      },
      children: [e.label, e.required && (0, F.jsx)(`span`, {
        style: {
          color: `var(--red)`,
          marginLeft: 2
        },
        children: `*`
      })]
    }),
    f = {
      width: `100%`,
      padding: `9px 13px`,
      fontSize: 14,
      borderRadius: `var(--r)`,
      border: `1px solid ${r?`var(--red)`:`var(--border)`}`,
      color: `var(--text)`,
      background: r ? `var(--red-bg)` : `#fff`,
      fontFamily: `inherit`,
      outline: `none`,
      transition: `border-color var(--t)`,
      boxSizing: `border-box`
    },
    p = e => (0, F.jsxs)(`div`, {
      style: {
        marginBottom: 14
      },
      children: [d, e, u && !r && !c && (0, F.jsx)(`p`, {
        style: {
          fontSize: 12,
          color: `var(--muted)`,
          margin: `4px 0 0`,
          lineHeight: 1.5
        },
        children: u
      }), r && (0, F.jsx)(`p`, {
        style: {
          fontSize: 12,
          color: `var(--red)`,
          margin: `4px 0 0`
        },
        children: r
      }), c && (0, F.jsxs)(`div`, {
        style: {
          marginTop: 6,
          padding: `10px 12px`,
          borderRadius: `var(--r)`,
          background: l ? `var(--red-bg)` : `var(--amber-bg)`,
          border: `1px solid ${l?`var(--red-border)`:`var(--amber-border)`}`,
          fontSize: 12,
          color: l ? `var(--red-dark)` : `var(--amber-dark)`,
          lineHeight: 1.5
        },
        children: [l ? `⛔` : `⚠️`, ` `, c]
      })]
    });
  switch (e.type === `select` ? `dropdown` : e.type || `text`) {
    case `textarea`:
      return p((0, F.jsx)(`textarea`, {
        id: a,
        rows: 4,
        value: t || ``,
        onChange: e => n(e.target.value),
        placeholder: e.placeholder || ``,
        required: e.required,
        style: {
          ...f,
          resize: `vertical`
        }
      }));
    case `select`:
    case `dropdown`:
      return p((0, F.jsxs)(`select`, {
        id: a,
        value: t || ``,
        onChange: e => n(e.target.value),
        required: e.required,
        style: {
          ...f,
          appearance: `none`,
          cursor: `pointer`,
          paddingRight: 32,
          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%2364748b' stroke-width='1.5' fill='none' stroke-linecap='round'/%3E%3C/svg%3E")`,
          backgroundRepeat: `no-repeat`,
          backgroundPosition: `right 12px center`
        },
        children: [(0, F.jsx)(`option`, {
          value: ``,
          children: `-- Select --`
        }), (e.options || []).map(e => (0, F.jsx)(`option`, {
          value: e,
          children: e
        }, e))]
      }));
    case `radio`:
      return p((0, F.jsx)(`div`, {
        style: {
          display: `flex`,
          gap: 10,
          flexWrap: `wrap`,
          marginTop: 4
        },
        children: (e.options || []).map(e => (0, F.jsxs)(`label`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 8,
            padding: `8px 14px`,
            border: `1px solid ${t===e?Pa:`var(--border)`}`,
            borderRadius: `var(--r)`,
            cursor: `pointer`,
            fontSize: 13,
            background: t === e ? `${Pa}10` : `#fff`,
            transition: `all var(--t)`
          },
          children: [(0, F.jsx)(`input`, {
            type: `radio`,
            name: a,
            value: e,
            checked: t === e,
            onChange: () => n(e),
            style: {
              accentColor: Pa
            }
          }), e]
        }, e))
      }));
    case `phone`:
      return p((0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          gap: 8
        },
        children: [(0, F.jsx)(`select`, {
          value: (t || {}).code || `+91`,
          onChange: e => n({
            ...t || {},
            code: e.target.value
          }),
          style: {
            ...f,
            width: 110,
            flex: `0 0 110px`,
            paddingRight: 8
          },
          children: [`+91 IN`, `+1 US`, `+44 UK`, `+61 AU`, `+971 UAE`, `+65 SG`, `+49 DE`, `+81 JP`].map(e => {
            let [t, n] = e.split(` `);
            return (0, F.jsxs)(`option`, {
              value: t,
              children: [n, ` `, t]
            }, t)
          })
        }), (0, F.jsx)(`input`, {
          type: `tel`,
          value: (t || {}).number || ``,
          onChange: e => n({
            ...t || {},
            number: e.target.value
          }),
          placeholder: `Mobile number`,
          pattern: `[0-9]{6,15}`,
          required: e.required,
          style: {
            ...f,
            flex: 1,
            minWidth: 0
          }
        })]
      }));
    case `checkbox`:
      return p((0, F.jsx)(`div`, {
        style: {
          display: `flex`,
          flexDirection: `column`,
          gap: 8,
          marginTop: 4
        },
        children: (e.options || []).map(e => {
          let r = Array.isArray(t) ? t.includes(e) : !1;
          return (0, F.jsxs)(`label`, {
            style: {
              display: `flex`,
              alignItems: `flex-start`,
              gap: 10,
              padding: `10px 14px`,
              cursor: `pointer`,
              fontSize: 13,
              border: `1px solid ${r?`var(--brand)`:`var(--border)`}`,
              borderRadius: `var(--r)`,
              background: r ? `var(--brand-light)` : `#fff`,
              transition: `all var(--t)`,
              lineHeight: 1.4
            },
            children: [(0, F.jsx)(`input`, {
              type: `checkbox`,
              checked: r,
              onChange: () => {
                let i = Array.isArray(t) ? t : [];
                n(r ? i.filter(t => t !== e) : [...i, e])
              },
              style: {
                marginTop: 1,
                accentColor: `var(--brand)`,
                flexShrink: 0
              }
            }), e]
          }, e)
        })
      }));
    case `number`:
      return p((0, F.jsx)(`input`, {
        type: `number`,
        id: a,
        value: t || ``,
        onChange: e => n(e.target.value),
        placeholder: e.placeholder || ``,
        required: e.required,
        style: f
      }));
    case `email`:
      return p((0, F.jsx)(`input`, {
        type: `email`,
        id: a,
        value: t || ``,
        onChange: e => n(e.target.value),
        placeholder: e.placeholder || ``,
        required: e.required,
        style: f
      }));
    case `date`:
      return p((0, F.jsx)(`input`, {
        type: `date`,
        id: a,
        value: t || ``,
        onChange: e => n(e.target.value),
        required: e.required,
        style: f
      }));
    case `file`:
      return p((0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(`input`, {
          type: `file`,
          id: a,
          onChange: e => n(e.target.files[0] || null),
          accept: `.pdf,.jpg,.jpeg,.png`,
          style: {
            display: `none`
          }
        }), (0, F.jsxs)(`div`, {
          style: {
            border: `2px dashed var(--border)`,
            borderRadius: `var(--r)`,
            padding: `16px`,
            textAlign: `center`,
            cursor: `pointer`,
            background: `var(--surface-2)`
          },
          onClick: () => document.getElementById(a).click(),
          children: [(0, F.jsx)(Fi, {
            size: 20,
            style: {
              color: `var(--muted)`,
              marginBottom: 6
            }
          }), (0, F.jsx)(`p`, {
            style: {
              fontSize: 13,
              color: `var(--muted)`,
              margin: 0
            },
            children: t ? t.name : `Click to upload PDF/JPG/PNG`
          })]
        })]
      }));
    case `searchable`: {
      let [r, i] = (0, _.useState)(t || ``), [o, s] = (0, _.useState)(!1), [c, l] = (0, _.useState)([]), u = (0, _.useRef)(null);
      (0, _.useEffect)(() => {
        if (!e.key || r.length < 1) {
          l([]);
          return
        }
        clearTimeout(u.current), u.current = setTimeout(async () => {
          try {
            let t = window.S2NRI_CFG || {},
              n = await fetch(`${t.base}/form-fields/${encodeURIComponent(e.key)}/options/search?q=${encodeURIComponent(r)}`, {
                credentials: `include`,
                headers: {
                  "X-WP-Nonce": t.nonce
                }
              });
            n.ok && l((await n.json()).options || [])
          } catch {}
        }, 250)
      }, [r, e.key]);
      let d = (e.options || []).filter(e => !r || e.toLowerCase().includes(r.toLowerCase())),
        m = [...new Set([...d, ...c.map(e => e.option_value || e)])];
      return p((0, F.jsxs)(`div`, {
        style: {
          position: `relative`
        },
        children: [(0, F.jsx)(`input`, {
          id: a,
          value: r,
          onChange: e => {
            i(e.target.value), n(e.target.value), s(!0)
          },
          onFocus: () => s(!0),
          placeholder: e.placeholder || `Type to search…`,
          required: e.required,
          style: {
            ...f
          },
          autoComplete: `off`
        }), o && m.length > 0 && (0, F.jsxs)(F.Fragment, {
          children: [(0, F.jsx)(`div`, {
            onClick: () => s(!1),
            style: {
              position: `fixed`,
              inset: 0,
              zIndex: 10
            }
          }), (0, F.jsx)(`div`, {
            style: {
              position: `absolute`,
              top: `calc(100% + 4px)`,
              left: 0,
              right: 0,
              background: `#fff`,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              maxHeight: 200,
              overflowY: `auto`,
              zIndex: 20,
              boxShadow: `var(--shadow-md)`
            },
            children: m.map(e => (0, F.jsx)(`div`, {
              onClick: () => {
                n(e), i(e), s(!1)
              },
              style: {
                padding: `9px 13px`,
                fontSize: 14,
                cursor: `pointer`,
                color: `var(--text)`
              },
              onMouseEnter: e => e.target.style.background = `var(--surface-2)`,
              onMouseLeave: e => e.target.style.background = ``,
              children: e
            }, e))
          })]
        })]
      }))
    }
    default:
      return p((0, F.jsx)(`input`, {
        type: `text`,
        id: a,
        value: t || ``,
        onChange: e => n(e.target.value),
        placeholder: e.placeholder || ``,
        required: e.required,
        style: f
      }))
  }
}

function La({
  service: e,
  onBack: t,
  onSuccess: n
}) {
  let r = R(),
    [i, a] = (0, _.useState)(1),
    [o, s] = (0, _.useState)({}),
    [c, l] = (0, _.useState)({}),
    [u, d] = (0, _.useState)(!1),
    f = e.form_schema || [],
    p = {};
  f.some(e => e.step && e.step > 0) ? f.forEach(e => {
    let t = e.step || 1;
    p[t] || (p[t] = []), p[t].push(e)
  }) : f.forEach((e, t) => {
    let n = Math.floor(t / 5) + 1;
    p[n] || (p[n] = []), p[n].push(e)
  });
  let m = Object.keys(p).map(Number).sort((e, t) => e - t),
    h = m.length + 1;

  function g(e) {
    let t = {};
    return (p[m[e]] || []).forEach(e => {
      if (!Fa(e, o)) return;
      if (e.required) {
        let n = o[e.key],
          r = e.type === `select` ? `dropdown` : e.type || `text`;
        (n == null || typeof n == `string` && !n.trim() || r === `phone` && !n?.number || r === `checkbox` && (!Array.isArray(n) || n.length === 0) || r === `file` && !n) && (t[e.key] = `${e.label} is required`)
      }
      let n = e.eligibility_rule;
      if (n && n.severity === `hard`) {
        let r = o[e.key];
        r && String(r) === String(n.warn_if) && (t[e.key] = n.message || `This selection prevents proceeding.`)
      }
    }), l(t), Object.keys(t).length === 0
  }

  function v() {
    g(i - 1) && a(e => e + 1)
  }
  async function y() {
    d(!0);
    try {
      let t = {};
      Object.entries(o).forEach(([e, n]) => {
        n != null && (n && typeof n == `object` && n.code && n.number ? t[e] = `${n.code} ${n.number}` : Array.isArray(n) ? t[e] = n.join(`, `) : n instanceof File ? t[e] = n.name : t[e] = n)
      });
      let r = await or.create({
        service_id: e.id,
        field_data: t,
        priority: `normal`
      });
      n(r.booking?.id || r.id)
    } catch (e) {
      r(e?.message || `Submission failed. Please try again.`, `error`)
    } finally {
      d(!1)
    }
  }
  let b = {
      1: `Service Details`,
      2: `Location & Record Info`,
      3: `Your Requirements`,
      4: `Documents & Delivery`,
      98: `Contact Details`,
      99: `Upload Documents`
    },
    x = m[i - 1],
    S = p[x] || [],
    C = i === h,
    w = b[x] || `Step ${i}`;
  return (0, F.jsxs)(`div`, {
    style: {
      animation: `slideUp 200ms ease both`
    },
    children: [(0, F.jsx)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        padding: `20px 24px`,
        borderBottom: `1px solid var(--border)`,
        background: `var(--surface)`,
        borderRadius: `var(--r-lg) var(--r-lg) 0 0`,
        overflowX: `auto`
      },
      children: Array.from({
        length: h
      }).map((e, t) => {
        let n = m[t],
          r = t === h - 1 ? `Review` : b[n] || `Step ${t+1}`;
        return (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            flex: t < h - 1 ? 1 : void 0,
            minWidth: `fit-content`
          },
          children: [(0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              flexDirection: `column`,
              alignItems: `center`,
              gap: 6
            },
            children: [(0, F.jsx)(`div`, {
              style: {
                width: 32,
                height: 32,
                borderRadius: `50%`,
                display: `flex`,
                alignItems: `center`,
                justifyContent: `center`,
                fontSize: 12,
                fontWeight: 700,
                flexShrink: 0,
                background: t < i - 1 ? `var(--green)` : t === i - 1 ? Pa : `var(--border)`,
                color: t < i || t === i - 1 ? `#fff` : `var(--muted)`,
                boxShadow: t === i - 1 ? `0 0 0 4px ${Pa}30` : `none`,
                transition: `all 0.3s`
              },
              children: t < i - 1 ? `✓` : t + 1
            }), (0, F.jsx)(`span`, {
              style: {
                fontSize: 10,
                fontWeight: 600,
                color: t <= i - 1 ? Pa : `var(--muted)`,
                whiteSpace: `nowrap`,
                textAlign: `center`,
                maxWidth: 80,
                lineHeight: 1.3
              },
              children: r
            })]
          }), t < h - 1 && (0, F.jsx)(`div`, {
            style: {
              flex: 1,
              height: 3,
              margin: `0 6px`,
              marginBottom: 18,
              background: t < i - 1 ? `var(--green)` : `var(--border)`,
              transition: `background 0.3s`,
              minWidth: 16
            }
          })]
        }, t)
      })
    }), (0, F.jsxs)(`div`, {
      style: {
        padding: `24px`,
        background: `#fff`,
        borderRadius: `0 0 var(--r-lg) var(--r-lg)`
      },
      children: [C ? (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(`h3`, {
          style: {
            fontSize: 16,
            marginBottom: 16
          },
          children: `Review & Submit`
        }), (0, F.jsxs)(`div`, {
          style: {
            background: `var(--surface-2)`,
            borderRadius: `var(--r)`,
            padding: `16px`,
            marginBottom: 20
          },
          children: [(0, F.jsx)(`div`, {
            style: {
              fontWeight: 700,
              marginBottom: 8,
              color: Pa
            },
            children: e.name
          }), Object.entries(o).filter(([, e]) => e).map(([e, t]) => (0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              gap: 8,
              fontSize: 13,
              padding: `4px 0`,
              borderBottom: `1px solid var(--border)`
            },
            children: [(0, F.jsxs)(`span`, {
              style: {
                fontWeight: 600,
                color: `var(--text-2)`,
                minWidth: 140,
                textTransform: `capitalize`
              },
              children: [e.replace(/_/g, ` `), `:`]
            }), (0, F.jsx)(`span`, {
              style: {
                color: `var(--text)`
              },
              children: typeof t == `object` ? t.number ? `${t.code} ${t.number}` : JSON.stringify(t) : String(t)
            })]
          }, e))]
        })]
      }) : (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(`h3`, {
          style: {
            fontSize: 16,
            fontWeight: 700,
            marginBottom: 4,
            color: `var(--text)`
          },
          children: i === 1 ? e.name : w
        }), (0, F.jsx)(`p`, {
          style: {
            fontSize: 13,
            color: `var(--muted)`,
            marginBottom: 20
          },
          children: i === 1 ? e.short_desc || `Fill in the details below to get started` : `Step ${i} of ${h-1} — ${w}`
        }), S.map(e => (0, F.jsx)(Ia, {
          field: e,
          value: o[e.key],
          onChange: t => s(n => ({
            ...n,
            [e.key]: t
          })),
          error: c[e.key],
          allValues: o
        }, e.key)), f.length === 0 && (0, F.jsxs)(`div`, {
          style: {
            marginBottom: 14
          },
          children: [(0, F.jsxs)(`label`, {
            style: {
              display: `block`,
              fontSize: 13,
              fontWeight: 600,
              color: `var(--text-2)`,
              marginBottom: 5
            },
            children: [`Message / Requirements `, (0, F.jsx)(`span`, {
              style: {
                color: `var(--red)`
              },
              children: `*`
            })]
          }), (0, F.jsx)(`textarea`, {
            rows: 5,
            value: o.message || ``,
            onChange: e => s(t => ({
              ...t,
              message: e.target.value
            })),
            placeholder: `Describe what you need for ${e.name}...`,
            style: {
              width: `100%`,
              padding: `9px 13px`,
              fontSize: 14,
              borderRadius: `var(--r)`,
              border: `1px solid var(--border)`,
              fontFamily: `inherit`,
              outline: `none`,
              resize: `vertical`,
              boxSizing: `border-box`
            }
          })]
        })]
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          gap: 10,
          justifyContent: `space-between`,
          marginTop: 8
        },
        children: [(0, F.jsx)(z, {
          variant: `ghost`,
          icon: (0, F.jsx)(Jr, {
            size: 15
          }),
          onClick: () => i === 1 ? t() : a(e => e - 1),
          children: i === 1 ? `Back to services` : `Previous`
        }), C ? (0, F.jsx)(z, {
          loading: u,
          icon: (0, F.jsx)(Qr, {
            size: 15
          }),
          onClick: y,
          style: {
            background: Pa
          },
          children: `Submit Application`
        }) : (0, F.jsx)(z, {
          icon: (0, F.jsx)(Yr, {
            size: 15
          }),
          onClick: v,
          style: {
            background: Pa
          },
          children: i === h - 1 ? `Review` : `Next →`
        })]
      })]
    })]
  })
}

function Ra() {
  function e(e) {
    let t = window.S2NRI_CFG || {};
    return fetch(`${t.base||``}${e}`, {
      credentials: `include`,
      headers: {
        "X-WP-Nonce": t.nonce || ``
      }
    }).then(e => e.json())
  }
  let t = ut(),
    n = R(),
    [r, i] = (0, _.useState)([]),
    [a, o] = (0, _.useState)({}),
    [s, c] = (0, _.useState)(!0),
    [l, u] = (0, _.useState)(null),
    [d, f] = (0, _.useState)(null),
    [p, m] = (0, _.useState)(null),
    [h, g] = (0, _.useState)(``),
    [v, y] = (0, _.useState)(null),
    [b, x] = (0, _.useState)(!1);
  (0, _.useEffect)(() => {
    Promise.all([e(`/categories`), e(`/services?per_page=200`)]).then(([e, t]) => {
      let n = e.categories || [],
        r = t.services || [],
        a = {};
      n.forEach(e => {
        a[e.id] = []
      }), r.forEach(e => {
        a[e.category_id] !== void 0 && a[e.category_id].push(e)
      }), i(n), o(a), n.length > 0 && u(n[0].id), c(!1)
    }).catch(() => {
      n(`Failed to load services`, `error`), c(!1)
    })
  }, []);
  async function S(t) {
    x(!0);
    try {
      y((await e(`/services/${t.slug}`)).service || t)
    } catch {
      y(t)
    } finally {
      x(!1), f(t)
    }
  }
  if (s) return (0, F.jsx)(`div`, {
    style: {
      display: `flex`,
      justifyContent: `center`,
      padding: 60
    },
    children: (0, F.jsx)(Wi, {
      size: 32
    })
  });
  if (p) return (0, F.jsxs)(`div`, {
    style: {
      maxWidth: 560,
      margin: `0 auto`,
      padding: `40px 0`,
      textAlign: `center`,
      animation: `slideUp 250ms ease both`
    },
    children: [(0, F.jsx)(`div`, {
      style: {
        width: 72,
        height: 72,
        borderRadius: `50%`,
        background: `${Pa}15`,
        display: `flex`,
        alignItems: `center`,
        justifyContent: `center`,
        margin: `0 auto 20px`,
        fontSize: 36
      },
      children: `🎉`
    }), (0, F.jsx)(`h2`, {
      style: {
        fontSize: 22,
        marginBottom: 8
      },
      children: `Application Submitted!`
    }), (0, F.jsx)(`p`, {
      style: {
        color: `var(--muted)`,
        marginBottom: 24,
        lineHeight: 1.6
      },
      children: `Your request has been received. Our team will review it and send you a detailed quote within 24 hours.`
    }), (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        gap: 10,
        justifyContent: `center`
      },
      children: [(0, F.jsx)(z, {
        onClick: () => t(`/bookings/${p}`),
        children: `View My Request`
      }), (0, F.jsx)(z, {
        variant: `ghost`,
        onClick: () => {
          m(null), f(null), y(null)
        },
        children: `Submit Another`
      })]
    })]
  });
  if (d && v) return (0, F.jsxs)(`div`, {
    style: {
      maxWidth: 680,
      margin: `0 auto`
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        marginBottom: 20
      },
      children: [(0, F.jsx)(`h1`, {
        style: {
          fontSize: 22,
          fontWeight: 700,
          margin: `0 0 4px`
        },
        children: `New Request`
      }), (0, F.jsx)(`p`, {
        style: {
          fontSize: 14,
          color: `var(--muted)`
        },
        children: `Complete the form below and we'll send you a quote`
      })]
    }), (0, F.jsx)(B, {
      padding: `0`,
      style: {
        overflow: `hidden`
      },
      children: (0, F.jsx)(La, {
        service: v,
        onBack: () => {
          f(null), y(null)
        },
        onSuccess: e => m(e)
      })
    })]
  });
  if (b) return (0, F.jsx)(`div`, {
    style: {
      display: `flex`,
      justifyContent: `center`,
      padding: 60
    },
    children: (0, F.jsx)(Wi, {
      size: 32
    })
  });
  let C = (a[l] || []).filter(e => !h || e.name.toLowerCase().includes(h.toLowerCase())),
    w = h ? Object.values(a).flat().filter(e => e.name.toLowerCase().includes(h.toLowerCase())) : [];
  return (0, F.jsxs)(`div`, {
    children: [(0, F.jsxs)(`div`, {
      style: {
        marginBottom: 24
      },
      children: [(0, F.jsx)(`h1`, {
        style: {
          fontSize: 22,
          fontWeight: 700,
          margin: `0 0 4px`
        },
        children: `New Request`
      }), (0, F.jsx)(`p`, {
        style: {
          fontSize: 14,
          color: `var(--muted)`
        },
        children: `Select a service to get started`
      })]
    }), (0, F.jsxs)(`div`, {
      style: {
        position: `relative`,
        marginBottom: 20
      },
      children: [(0, F.jsx)(Ci, {
        size: 16,
        style: {
          position: `absolute`,
          left: 12,
          top: `50%`,
          transform: `translateY(-50%)`,
          color: `var(--muted)`,
          pointerEvents: `none`
        }
      }), (0, F.jsx)(`input`, {
        value: h,
        onChange: e => g(e.target.value),
        placeholder: `Search services...`,
        style: {
          width: `100%`,
          padding: `10px 13px 10px 38px`,
          fontSize: 14,
          border: `1px solid var(--border)`,
          borderRadius: `var(--r)`,
          fontFamily: `inherit`,
          outline: `none`,
          boxSizing: `border-box`
        },
        onFocus: e => e.target.style.borderColor = Pa,
        onBlur: e => e.target.style.borderColor = `var(--border)`
      }), h && (0, F.jsx)(`button`, {
        onClick: () => g(``),
        style: {
          position: `absolute`,
          right: 10,
          top: `50%`,
          transform: `translateY(-50%)`,
          background: `none`,
          border: `none`,
          cursor: `pointer`,
          color: `var(--muted)`
        },
        children: (0, F.jsx)(Li, {
          size: 16
        })
      })]
    }), h ? (0, F.jsxs)(B, {
      children: [(0, F.jsxs)(`div`, {
        style: {
          fontSize: 13,
          fontWeight: 600,
          color: `var(--muted)`,
          marginBottom: 12
        },
        children: [w.length, ` results for "`, h, `"`]
      }), w.length === 0 ? (0, F.jsx)(Qi, {
        icon: `🔍`,
        title: `No services found`,
        desc: `Try a different search term`
      }) : (0, F.jsx)(`div`, {
        style: {
          display: `flex`,
          flexDirection: `column`,
          gap: 2
        },
        children: w.map(e => (0, F.jsx)(za, {
          svc: e,
          onSelect: () => S(e)
        }, e.id))
      })]
    }) : (0, F.jsxs)(B, {
      padding: `0`,
      style: {
        overflow: `hidden`
      },
      children: [(0, F.jsx)(`div`, {
        style: {
          display: `flex`,
          borderBottom: `1px solid var(--border)`,
          overflowX: `auto`,
          background: `var(--surface-2)`
        },
        children: r.map(e => (0, F.jsxs)(`button`, {
          onClick: () => u(e.id),
          style: {
            padding: `10px 18px`,
            fontSize: 13,
            fontWeight: 600,
            whiteSpace: `nowrap`,
            background: `none`,
            border: `none`,
            cursor: `pointer`,
            color: l === e.id ? Pa : `var(--muted)`,
            borderBottom: `2px solid ${l===e.id?Pa:`transparent`}`,
            marginBottom: -1,
            transition: `var(--t)`,
            display: `flex`,
            alignItems: `center`,
            gap: 6
          },
          children: [e.icon && (0, F.jsx)(`span`, {
            style: {
              fontSize: 16
            },
            children: e.icon
          }), e.name, (a[e.id] || []).length > 0 && (0, F.jsx)(`span`, {
            style: {
              fontSize: 11,
              background: l === e.id ? Pa : `var(--border)`,
              color: l === e.id ? `#fff` : `var(--muted)`,
              borderRadius: `var(--r-full)`,
              padding: `1px 7px`,
              fontWeight: 700
            },
            children: (a[e.id] || []).length
          })]
        }, e.id))
      }), (0, F.jsx)(`div`, {
        style: {
          padding: `8px 0`
        },
        children: C.length === 0 ? (0, F.jsx)(Qi, {
          icon: `📋`,
          title: `No services in this category`,
          desc: `More coming soon`
        }) : C.map(e => (0, F.jsx)(za, {
          svc: e,
          onSelect: () => S(e)
        }, e.id))
      })]
    })]
  })
}

function za({
  svc: e,
  onSelect: t
}) {
  return (0, F.jsxs)(`button`, {
    onClick: t,
    style: {
      display: `flex`,
      alignItems: `center`,
      justifyContent: `space-between`,
      width: `100%`,
      padding: `14px 20px`,
      background: `none`,
      border: `none`,
      borderBottom: `1px solid var(--border)`,
      cursor: `pointer`,
      textAlign: `left`,
      transition: `background var(--t)`,
      fontFamily: `inherit`
    },
    onMouseEnter: e => e.currentTarget.style.background = `var(--surface-2)`,
    onMouseLeave: e => e.currentTarget.style.background = `none`,
    children: [(0, F.jsxs)(`div`, {
      children: [(0, F.jsx)(`div`, {
        style: {
          fontSize: 14,
          fontWeight: 600,
          color: `var(--text)`,
          marginBottom: 2
        },
        children: e.name
      }), e.short_desc && (0, F.jsx)(`div`, {
        style: {
          fontSize: 12,
          color: `var(--muted)`
        },
        children: e.short_desc
      })]
    }), (0, F.jsx)(Yr, {
      size: 16,
      style: {
        color: `var(--muted)`,
        flexShrink: 0
      }
    })]
  })
}
var Ba = `var(--brand)`;

function Va({
  label: e,
  desc: t,
  checked: n,
  onChange: r
}) {
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      alignItems: `flex-start`,
      justifyContent: `space-between`,
      gap: 16,
      padding: `14px 0`,
      borderBottom: `1px solid #f1f5f9`
    },
    children: [(0, F.jsxs)(`div`, {
      children: [(0, F.jsx)(`div`, {
        style: {
          fontSize: 14,
          fontWeight: 600,
          color: `var(--text)`,
          marginBottom: 2
        },
        children: e
      }), t && (0, F.jsx)(`div`, {
        style: {
          fontSize: 12,
          color: `var(--muted)`
        },
        children: t
      })]
    }), (0, F.jsx)(`button`, {
      role: `switch`,
      "aria-checked": n,
      onClick: () => r(!n),
      style: {
        width: 44,
        height: 24,
        borderRadius: 12,
        border: `none`,
        cursor: `pointer`,
        background: n ? Ba : `var(--border)`,
        transition: `background 0.2s`,
        position: `relative`,
        flexShrink: 0
      },
      children: (0, F.jsx)(`span`, {
        style: {
          position: `absolute`,
          top: 3,
          left: n ? 23 : 3,
          width: 18,
          height: 18,
          borderRadius: `50%`,
          background: `#fff`,
          transition: `left 0.2s`,
          boxShadow: `0 1px 3px rgba(0,0,0,.2)`
        }
      })
    })]
  })
}

function Ha() {
  let e = R(),
    [t, n] = (0, _.useState)(`profile`),
    [r, i] = (0, _.useState)(null),
    [a, o] = (0, _.useState)(null),
    [s, c] = (0, _.useState)(!0),
    [l, u] = (0, _.useState)(!1),
    [d, f] = (0, _.useState)(!1),
    [p, m] = (0, _.useState)({
      name: ``,
      phone: ``,
      city: ``,
      country: ``
    });
  (0, _.useEffect)(() => {
    Promise.all([sr.get(), sr.notifPrefs()]).then(([e, t]) => {
      i(e.user || e), m({
        name: e.user?.name || e.name || ``,
        phone: e.user?.phone || e.phone || ``,
        city: e.user?.city || e.city || ``,
        country: e.user?.country || e.country || ``
      }), o(t.preferences || t)
    }).catch(() => {}).finally(() => c(!1))
  }, []);
  let h = e => t => m(n => ({
    ...n,
    [e]: t.target.value
  }));
  async function g(t) {
    t.preventDefault(), u(!0);
    try {
      await sr.update(p), e(`Profile updated`, `success`)
    } catch (t) {
      e(t.message || `Save failed`, `error`)
    } finally {
      u(!1)
    }
  }
  async function v() {
    u(!0);
    try {
      await sr.updatePrefs(a), e(`Notification preferences saved`, `success`)
    } catch (t) {
      e(t.message || `Save failed`, `error`)
    } finally {
      u(!1)
    }
  }
  async function y() {
    f(!0);
    try {
      let t = await sr.dataExport(),
        n = new Blob([JSON.stringify(t, null, 2)], {
          type: `application/json`
        }),
        r = URL.createObjectURL(n),
        i = document.createElement(`a`);
      i.href = r, i.download = `my-data-${Date.now()}.json`, i.click(), URL.revokeObjectURL(r), e(`Data exported`, `success`)
    } catch (t) {
      e(t.message || `Export failed`, `error`)
    } finally {
      f(!1)
    }
  }
  let b = (e, t) => o(n => ({
    ...n,
    [e]: {
      ...n[e] || {},
      [t]: !n?.[e]?.[t]
    }
  }));
  return (0, F.jsxs)(`div`, {
    style: {
      maxWidth: 660,
      display: `flex`,
      flexDirection: `column`,
      gap: 20
    },
    children: [(0, F.jsxs)(`div`, {
      children: [(0, F.jsx)(`h1`, {
        style: {
          fontSize: 22,
          fontWeight: 800
        },
        children: `My Profile`
      }), (0, F.jsx)(`p`, {
        style: {
          fontSize: 14,
          color: `var(--muted)`,
          marginTop: 3
        },
        children: `Manage your account information and preferences`
      })]
    }), (0, F.jsxs)(B, {
      padding: `0`,
      children: [(0, F.jsx)(ia, {
        tabs: [{
          key: `profile`,
          label: `Personal Info`
        }, {
          key: `notifs`,
          label: `Notifications`,
          icon: (0, F.jsx)(Hr, {
            size: 14
          })
        }, {
          key: `data`,
          label: `My Data`
        }],
        active: t,
        onChange: n
      }), t === `profile` && (0, F.jsx)(`div`, {
        style: {
          padding: 20
        },
        children: s ? (0, F.jsx)(`div`, {
          style: {
            display: `flex`,
            flexDirection: `column`,
            gap: 14
          },
          children: [1, 2, 3, 4].map(e => (0, F.jsx)(na, {
            h: 56
          }, e))
        }) : (0, F.jsxs)(`form`, {
          onSubmit: g,
          children: [(0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              flexDirection: `column`,
              gap: 16,
              marginBottom: 20
            },
            children: [(0, F.jsx)(Xi, {
              label: `Full Name`,
              value: p.name,
              onChange: h(`name`),
              placeholder: `Your full name`,
              required: !0
            }), (0, F.jsxs)(`div`, {
              children: [(0, F.jsx)(`label`, {
                style: {
                  fontSize: 13,
                  fontWeight: 600,
                  color: `var(--text-2)`,
                  display: `block`,
                  marginBottom: 6
                },
                children: `Email address`
              }), (0, F.jsx)(`input`, {
                value: r?.email || ``,
                disabled: !0,
                style: {
                  width: `100%`,
                  padding: `10px 13px`,
                  fontSize: 14,
                  border: `1px solid var(--border)`,
                  borderRadius: `var(--r)`,
                  background: `var(--surface-2)`,
                  color: `var(--muted)`,
                  boxSizing: `border-box`
                }
              }), (0, F.jsx)(`span`, {
                style: {
                  fontSize: 12,
                  color: `var(--muted)`,
                  marginTop: 4,
                  display: `block`
                },
                children: `Email cannot be changed here — contact support`
              })]
            }), (0, F.jsx)(Xi, {
              label: `Phone number`,
              value: p.phone,
              onChange: h(`phone`),
              placeholder: `+91 98765 43210`,
              type: `tel`
            }), (0, F.jsxs)(`div`, {
              style: {
                display: `grid`,
                gridTemplateColumns: `1fr 1fr`,
                gap: 12
              },
              children: [(0, F.jsx)(Xi, {
                label: `City`,
                value: p.city,
                onChange: h(`city`),
                placeholder: `Mumbai`
              }), (0, F.jsx)(Xi, {
                label: `Country`,
                value: p.country,
                onChange: h(`country`),
                placeholder: `India`
              })]
            })]
          }), (0, F.jsx)(z, {
            type: `submit`,
            loading: l,
            icon: (0, F.jsx)(Si, {
              size: 15
            }),
            style: {
              background: Ba
            },
            children: `Save changes`
          })]
        })
      }), t === `notifs` && (0, F.jsxs)(`div`, {
        style: {
          padding: 20
        },
        children: [(0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`,
            marginBottom: 20,
            lineHeight: 1.6
          },
          children: `Choose how you'd like to be notified about your requests.`
        }), s ? (0, F.jsx)(`div`, {
          style: {
            display: `flex`,
            flexDirection: `column`,
            gap: 10
          },
          children: [1, 2, 3, 4].map(e => (0, F.jsx)(na, {
            h: 50
          }, e))
        }) : (0, F.jsxs)(`div`, {
          children: [(0, F.jsx)(`div`, {
            style: {
              fontSize: 12,
              fontWeight: 700,
              color: `var(--muted)`,
              textTransform: `uppercase`,
              letterSpacing: `.04em`,
              marginBottom: 8
            },
            children: `Email notifications`
          }), (0, F.jsx)(Va, {
            label: `Status updates`,
            desc: `When your request status changes`,
            checked: a?.email?.status_updates ?? !0,
            onChange: e => b(`email`, `status_updates`)
          }), (0, F.jsx)(Va, {
            label: `Quote received`,
            desc: `When we send you a quote to review`,
            checked: a?.email?.quote_received ?? !0,
            onChange: e => b(`email`, `quote_received`)
          }), (0, F.jsx)(Va, {
            label: `Payment confirmed`,
            desc: `When your payment is verified`,
            checked: a?.email?.payment_confirmed ?? !0,
            onChange: e => b(`email`, `payment_confirmed`)
          }), (0, F.jsx)(Va, {
            label: `Document requests`,
            desc: `When we need additional documents from you`,
            checked: a?.email?.doc_requested ?? !0,
            onChange: e => b(`email`, `doc_requested`)
          }), (0, F.jsx)(Va, {
            label: `Completion`,
            desc: `When your request is completed`,
            checked: a?.email?.completion ?? !0,
            onChange: e => b(`email`, `completion`)
          }), (0, F.jsx)(`div`, {
            style: {
              marginTop: 20
            },
            children: (0, F.jsx)(z, {
              onClick: v,
              loading: l,
              icon: (0, F.jsx)(Si, {
                size: 15
              }),
              style: {
                background: Ba
              },
              children: `Save preferences`
            })
          })]
        })]
      }), t === `data` && (0, F.jsxs)(`div`, {
        style: {
          padding: 20
        },
        children: [(0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`,
            lineHeight: 1.7,
            marginBottom: 24
          },
          children: `You can download a copy of all the data we hold about you, or request its deletion in accordance with GDPR / data protection regulations.`
        }), (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            flexDirection: `column`,
            gap: 16
          },
          children: [(0, F.jsxs)(B, {
            style: {
              background: `var(--surface-2)`
            },
            children: [(0, F.jsx)(`div`, {
              style: {
                fontWeight: 700,
                fontSize: 14,
                marginBottom: 6
              },
              children: `Download my data`
            }), (0, F.jsx)(`p`, {
              style: {
                fontSize: 13,
                color: `var(--muted)`,
                marginBottom: 14,
                lineHeight: 1.6
              },
              children: `Get a JSON file containing all your profile information, booking history, and communications.`
            }), (0, F.jsx)(z, {
              variant: `secondary`,
              loading: d,
              icon: (0, F.jsx)(ai, {
                size: 15
              }),
              onClick: y,
              children: `Export my data`
            })]
          }), (0, F.jsxs)(B, {
            style: {
              background: `var(--red-bg)`,
              border: `1px solid var(--red-border)`
            },
            children: [(0, F.jsx)(`div`, {
              style: {
                fontWeight: 700,
                fontSize: 14,
                color: `var(--red)`,
                marginBottom: 6
              },
              children: `Delete my account`
            }), (0, F.jsx)(`p`, {
              style: {
                fontSize: 13,
                color: `var(--red-dark)`,
                marginBottom: 14,
                lineHeight: 1.6
              },
              children: `This will permanently delete your account and all associated data. Active requests will be cancelled. This cannot be undone.`
            }), (0, F.jsx)(z, {
              variant: `danger`,
              size: `sm`,
              onClick: () => e(`Please contact support to delete your account`, `info`),
              children: `Request account deletion`
            })]
          })]
        })]
      })]
    })]
  })
}
var Ua = `var(--brand)`;

function Wa(e) {
  return e ? new Date(e).toLocaleDateString(`en-IN`, {
    day: `numeric`,
    month: `short`,
    year: `numeric`
  }) : `—`
}

function Ga(e) {
  return e >= 1e7 ? `₹${(e/1e6).toFixed(1)}Cr` : e >= 1e5 ? `₹${(e/1e5).toFixed(1)}L` : `₹${Number(e).toLocaleString(`en-IN`,{minimumFractionDigits:0})}`
}

function Ka() {
  let e = ut(),
    [t, n] = (0, _.useState)(null),
    [r, i] = (0, _.useState)(null),
    [a, o] = (0, _.useState)([]),
    [s, c] = (0, _.useState)(!0),
    [l, u] = (0, _.useState)(``),
    d = (0, _.useCallback)(async () => {
      c(!0), u(``);
      try {
        let [e, t, r] = await Promise.all([fr.dashboard(), fr.extended(), cr.list({
          per_page: 5,
          sort: `updated`
        })]);
        n(e), i(t), o(r.bookings || r.rows || [])
      } catch (e) {
        u(e.message || `Failed to load dashboard`)
      } finally {
        c(!1)
      }
    }, []);
  return (0, _.useEffect)(() => {
    d()
  }, [d]), (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      gap: 24
    },
    children: [(0, F.jsxs)(`div`, {
      children: [(0, F.jsx)(`h1`, {
        style: {
          fontSize: 24,
          fontWeight: 800
        },
        children: `Dashboard`
      }), (0, F.jsx)(`p`, {
        style: {
          color: `var(--muted)`,
          fontSize: 14,
          marginTop: 3
        },
        children: new Date().toLocaleDateString(`en-IN`, {
          weekday: `long`,
          day: `numeric`,
          month: `long`,
          year: `numeric`
        })
      })]
    }), l && (0, F.jsxs)(`div`, {
      style: {
        padding: `12px 16px`,
        background: `#fef2f2`,
        border: `1px solid #fecaca`,
        borderRadius: 8,
        color: `#b91c1c`,
        fontSize: 14
      },
      children: [`⚠️ `, l, ` — `, (0, F.jsx)(`button`, {
        onClick: d,
        style: {
          background: `none`,
          border: `none`,
          cursor: `pointer`,
          color: `#b91c1c`,
          textDecoration: `underline`,
          fontSize: 14,
          fontFamily: `inherit`
        },
        children: `Retry`
      })]
    }), (0, F.jsx)(`div`, {
      style: {
        display: `grid`,
        gridTemplateColumns: `repeat(auto-fill, minmax(160px, 1fr))`,
        gap: 14
      },
      children: s ? [1, 2, 3, 4, 5].map(e => (0, F.jsx)(na, {
        h: 96
      }, e)) : (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(ta, {
          label: `Total Requests`,
          value: t?.stats?.total_bookings ?? `—`,
          icon: (0, F.jsx)(oi, {
            size: 18
          }),
          color: Ua,
          onClick: () => e(`/requests`)
        }), (0, F.jsx)(ta, {
          label: `Active`,
          value: t?.stats?.active ?? `—`,
          icon: (0, F.jsx)(ti, {
            size: 18
          }),
          color: `var(--amber)`,
          onClick: () => e(`/requests?status=active`)
        }), (0, F.jsx)(ta, {
          label: `Completed`,
          value: t?.stats?.completed ?? `—`,
          icon: (0, F.jsx)(Qr, {
            size: 18
          }),
          color: `var(--green)`
        }), (0, F.jsx)(ta, {
          label: `Revenue (total)`,
          value: r?.revenue_summary?.total_approved_amount ? Ga(r.revenue_summary.total_approved_amount) : `—`,
          icon: (0, F.jsx)(ii, {
            size: 18
          }),
          color: `var(--teal)`
        }), (0, F.jsx)(ta, {
          label: `Customers`,
          value: t?.stats?.total_customers ?? `—`,
          icon: (0, F.jsx)(Ii, {
            size: 18
          }),
          color: `var(--purple)`,
          onClick: () => e(`/customers`)
        })]
      })
    }), !s && r && (0, F.jsxs)(`div`, {
      style: {
        display: `grid`,
        gridTemplateColumns: `repeat(auto-fill, minmax(200px, 1fr))`,
        gap: 14
      },
      children: [(0, F.jsxs)(B, {
        children: [(0, F.jsx)(`div`, {
          style: {
            fontSize: 12,
            fontWeight: 700,
            color: `var(--muted)`,
            textTransform: `uppercase`,
            letterSpacing: `.04em`,
            marginBottom: 10
          },
          children: `Today's Activity`
        }), [
          [`New requests`, r.today_activity?.submitted_today, Ua],
          [`Status updates`, r.today_activity?.status_updates_today, `var(--purple)`],
          [`Emails sent`, r.today_activity?.emails_sent_today, `var(--green)`],
          [`Payments verified`, r.today_activity?.payments_verified_today, `var(--amber)`]
        ].map(([e, t, n]) => (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            justifyContent: `space-between`,
            alignItems: `center`,
            padding: `6px 0`,
            borderBottom: `1px solid #f1f5f9`
          },
          children: [(0, F.jsx)(`span`, {
            style: {
              fontSize: 13,
              color: `var(--text-2)`
            },
            children: e
          }), (0, F.jsx)(`span`, {
            style: {
              fontSize: 16,
              fontWeight: 800,
              color: n
            },
            children: t ?? 0
          })]
        }, e))]
      }), (0, F.jsxs)(B, {
        children: [(0, F.jsx)(`div`, {
          style: {
            fontSize: 12,
            fontWeight: 700,
            color: `var(--muted)`,
            textTransform: `uppercase`,
            letterSpacing: `.04em`,
            marginBottom: 10
          },
          children: `Revenue Snapshot`
        }), [
          [`Total quoted`, r.revenue_summary?.total_quotes_sent],
          [`Collected`, r.revenue_summary?.total_approved_amount],
          [`Pending payment`, r.revenue_summary?.pending_payment_value]
        ].map(([e, t]) => (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            justifyContent: `space-between`,
            alignItems: `center`,
            padding: `6px 0`,
            borderBottom: `1px solid #f1f5f9`
          },
          children: [(0, F.jsx)(`span`, {
            style: {
              fontSize: 13,
              color: `var(--text-2)`
            },
            children: e
          }), (0, F.jsx)(`span`, {
            style: {
              fontSize: 14,
              fontWeight: 700,
              color: `var(--text)`
            },
            children: t ? Ga(t) : `₹0`
          })]
        }, e))]
      }), r.due_this_week?.count > 0 && (0, F.jsxs)(B, {
        style: {
          borderLeft: `3px solid ${Ua}`
        },
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 8,
            marginBottom: 10
          },
          children: [(0, F.jsx)(Gr, {
            size: 16,
            style: {
              color: Ua
            }
          }), (0, F.jsx)(`span`, {
            style: {
              fontSize: 12,
              fontWeight: 700,
              color: Ua,
              textTransform: `uppercase`,
              letterSpacing: `.04em`
            },
            children: `Due This Week`
          })]
        }), (0, F.jsx)(`div`, {
          style: {
            fontSize: 32,
            fontWeight: 900,
            color: Ua,
            lineHeight: 1,
            marginBottom: 4
          },
          children: r.due_this_week.count
        }), (0, F.jsxs)(`div`, {
          style: {
            fontSize: 12,
            color: `var(--muted)`
          },
          children: [`request`, r.due_this_week.count === 1 ? `` : `s`, ` due in 7 days`]
        })]
      })]
    }), !s && r?.overdue?.count > 0 && (0, F.jsxs)(B, {
      style: {
        borderLeft: `3px solid var(--red)`
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          gap: 10,
          marginBottom: 12
        },
        children: [(0, F.jsx)(Ni, {
          size: 18,
          style: {
            color: `var(--red)`
          }
        }), (0, F.jsxs)(`h3`, {
          style: {
            fontSize: 15,
            color: `var(--red)`
          },
          children: [r.overdue.count, ` overdue request`, r.overdue.count === 1 ? `` : `s`, ` — no activity for `, r.overdue.threshold_days, `+ days`]
        })]
      }), (0, F.jsx)(`div`, {
        style: {
          display: `flex`,
          flexDirection: `column`,
          gap: 8
        },
        children: r.overdue.bookings.slice(0, 5).map(t => (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            justifyContent: `space-between`,
            padding: `8px 12px`,
            background: `var(--red-bg)`,
            borderRadius: `var(--r)`,
            fontSize: 13,
            flexWrap: `wrap`,
            gap: 8
          },
          children: [(0, F.jsxs)(`div`, {
            children: [(0, F.jsx)(`span`, {
              style: {
                fontWeight: 700,
                color: `var(--text)`
              },
              children: t.booking_ref
            }), (0, F.jsx)(`span`, {
              style: {
                color: `var(--muted)`,
                marginLeft: 8
              },
              children: t.customer_name
            })]
          }), (0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              alignItems: `center`,
              gap: 10
            },
            children: [(0, F.jsx)(Ji, {
              status: t.status
            }), (0, F.jsxs)(`span`, {
              style: {
                color: `var(--red)`,
                fontWeight: 600
              },
              children: [t.days_since_update, `d ago`]
            }), (0, F.jsx)(`button`, {
              onClick: () => e(`/requests/${t.id}`),
              style: {
                background: `none`,
                border: `none`,
                cursor: `pointer`,
                color: Ua,
                fontSize: 12,
                fontFamily: `inherit`,
                fontWeight: 600
              },
              children: `View →`
            })]
          })]
        }, t.id))
      }), r.overdue.count > 5 && (0, F.jsxs)(z, {
        variant: `ghost`,
        size: `sm`,
        onClick: () => e(`/requests?overdue=true`),
        style: {
          marginTop: 10
        },
        children: [`View all `, r.overdue.count, ` overdue requests`]
      })]
    }), (0, F.jsxs)(B, {
      padding: `0`,
      children: [(0, F.jsxs)(`div`, {
        style: {
          padding: `16px 20px`,
          borderBottom: `1px solid var(--border)`,
          display: `flex`,
          alignItems: `center`,
          justifyContent: `space-between`
        },
        children: [(0, F.jsx)(`h2`, {
          style: {
            fontSize: 16
          },
          children: `Recent Requests`
        }), (0, F.jsx)(`button`, {
          onClick: () => e(`/requests`),
          style: {
            fontSize: 13,
            color: Ua,
            background: `none`,
            border: `none`,
            cursor: `pointer`,
            fontFamily: `inherit`,
            fontWeight: 600
          },
          children: `View all →`
        })]
      }), s ? (0, F.jsx)(`div`, {
        style: {
          padding: 16,
          display: `flex`,
          flexDirection: `column`,
          gap: 10
        },
        children: [1, 2, 3].map(e => (0, F.jsx)(na, {
          h: 54
        }, e))
      }) : a.length === 0 ? (0, F.jsx)(Qi, {
        icon: `📋`,
        title: `No requests yet`
      }) : (0, F.jsx)(`div`, {
        children: a.map((t, n) => (0, F.jsxs)(`div`, {
          onClick: () => e(`/requests/${t.id}`),
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 14,
            padding: `13px 20px`,
            cursor: `pointer`,
            borderBottom: n < a.length - 1 ? `1px solid #f1f5f9` : `none`,
            transition: `var(--t)`
          },
          onMouseEnter: e => e.currentTarget.style.background = `var(--surface-2)`,
          onMouseLeave: e => e.currentTarget.style.background = ``,
          children: [(0, F.jsxs)(`div`, {
            style: {
              flex: 1,
              minWidth: 0
            },
            children: [(0, F.jsxs)(`div`, {
              style: {
                fontWeight: 700,
                fontSize: 14,
                color: `var(--text)`,
                overflow: `hidden`,
                whiteSpace: `nowrap`,
                textOverflow: `ellipsis`
              },
              children: [t.booking_ref, ` — `, t.customer_name || t.service_name]
            }), (0, F.jsxs)(`div`, {
              style: {
                fontSize: 12,
                color: `var(--muted)`
              },
              children: [t.service_name, ` · `, Wa(t.updated_at || t.created_at)]
            })]
          }), (0, F.jsx)(Ji, {
            status: t.status
          })]
        }, t.id))
      })]
    })]
  })
}
var qa = `var(--brand)`,
  Ja = 20,
  Ya = [{
    value: ``,
    label: `All statuses`
  }, {
    value: `submitted`,
    label: `Received`
  }, {
    value: `under_review`,
    label: `Under Review`
  }, {
    value: `quote_sent`,
    label: `Ready to Process`
  }, {
    value: `quote_approved`,
    label: `Quote Sent`
  }, {
    value: `in_progress`,
    label: `Approved`
  }, {
    value: `docs_requested`,
    label: `Docs Requested`
  }, {
    value: `processing`,
    label: `In Progress`
  }, {
    value: `completed`,
    label: `Completed`
  }, {
    value: `cancelled`,
    label: `Cancelled`
  }, {
    value: `on_hold`,
    label: `On Hold`
  }, {
    value: `service_not_available`,
    label: `Not Able to Serve`
  }];

function Xa(e) {
  return e ? new Date(e).toLocaleDateString(`en-IN`, {
    day: `numeric`,
    month: `short`
  }) : `—`
}
var Za = {
  submitted: `var(--brand)`,
  under_review: `var(--amber)`,
  quote_sent: `var(--purple)`,
  quote_approved: `var(--teal)`,
  in_progress: `var(--brand)`,
  docs_requested: `var(--orange)`,
  docs_received: `var(--teal)`,
  processing: `var(--purple)`,
  completed: `var(--green)`,
  cancelled: `var(--red)`,
  on_hold: `var(--muted-2)`,
  service_not_available: `var(--muted)`
};

function Qa({
  currentStatus: e,
  onFilter: t
}) {
  let [n, r] = (0, _.useState)({}), [i, a] = (0, _.useState)(!0);
  (0, _.useEffect)(() => {
    async function e() {
      try {
        let e = await Promise.all([`submitted`, `under_review`, `quote_sent`, `quote_approved`, `in_progress`, `docs_requested`, `processing`, `completed`, `cancelled`, `on_hold`].map(e => cr.list({
          status: e,
          per_page: 1,
          page: 1
        }).then(t => [e, t.total || 0]).catch(() => [e, 0])));
        r(Object.fromEntries(e))
      } catch {} finally {
        a(!1)
      }
    }
    e()
  }, []);
  let o = [{
    value: `submitted`,
    label: `Submitted`
  }, {
    value: `under_review`,
    label: `Under Review`
  }, {
    value: `in_progress`,
    label: `In Progress`
  }, {
    value: `processing`,
    label: `Processing`
  }, {
    value: `completed`,
    label: `Completed`
  }, {
    value: `cancelled`,
    label: `Cancelled`
  }];
  return i ? (0, F.jsx)(`div`, {
    style: {
      display: `flex`,
      gap: 10,
      flexWrap: `wrap`
    },
    children: o.map(e => (0, F.jsx)(`div`, {
      style: {
        flex: `1 1 100px`,
        height: 60,
        background: `var(--surface-2)`,
        borderRadius: `var(--r)`,
        animation: `pulse 1.5s infinite`
      }
    }, e.value))
  }) : (0, F.jsx)(`div`, {
    style: {
      display: `flex`,
      gap: 10,
      flexWrap: `wrap`
    },
    children: o.map(({
      value: r,
      label: i
    }) => {
      let a = Za[r] || qa,
        o = e === r;
      return (0, F.jsxs)(`div`, {
        onClick: () => t(o ? `` : r),
        style: {
          flex: `1 1 100px`,
          padding: `12px 16px`,
          background: `#fff`,
          border: `1px solid var(--border)`,
          borderLeft: `4px solid ${a}`,
          borderRadius: `var(--r)`,
          cursor: `pointer`,
          boxShadow: o ? `0 0 0 2px ${a}40, var(--shadow)` : `var(--shadow)`,
          transform: o ? `translateY(-1px)` : ``,
          transition: `all .15s`,
          userSelect: `none`
        },
        onMouseEnter: e => {
          o || (e.currentTarget.style.transform = `translateY(-1px)`)
        },
        onMouseLeave: e => {
          o || (e.currentTarget.style.transform = ``)
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            fontSize: 22,
            fontWeight: 800,
            lineHeight: 1,
            color: a,
            marginBottom: 3
          },
          children: n[r] ?? 0
        }), (0, F.jsx)(`div`, {
          style: {
            fontSize: 12,
            color: `var(--muted)`,
            fontWeight: 500
          },
          children: i
        })]
      }, r)
    })
  })
}

function $a() {
  let e = ut(),
    t = R(),
    [n] = Un(),
    [r, i] = (0, _.useState)({
      rows: [],
      total: 0
    }),
    [a, o] = (0, _.useState)(!0),
    [s, c] = (0, _.useState)(n.get(`search`) || ``),
    [l, u] = (0, _.useState)(n.get(`status`) || ``),
    [d, f] = (0, _.useState)(1),
    [p, m] = (0, _.useState)(new Set),
    [h, g] = (0, _.useState)(!1),
    [v, y] = (0, _.useState)(``),
    [b, x] = (0, _.useState)(``),
    [C, w] = (0, _.useState)(!1),
    T = (0, _.useRef)(null),
    [E, D] = (0, _.useState)(``),
    O = (0, _.useCallback)(async () => {
      o(!0), D(``);
      try {
        let e = await cr.list({
          page: d,
          per_page: Ja,
          sort: `updated`,
          ...(s && {
            search: s
          }),
          ...(l && {
            status: l
          })
        });
        i({
          rows: e.bookings || e.rows || [],
          total: e.total || 0
        })
      } catch (e) {
        D(e.message || `Failed to load requests`)
      } finally {
        o(!1)
      }
    }, [d, s, l]);
  (0, _.useEffect)(() => {
    O()
  }, [O]);
  let ee = e => {
      c(e), f(1)
    },
    te = e => m(t => {
      let n = new Set(t);
      return n.has(e) ? n.delete(e) : n.add(e), n
    }),
    k = () => m(e => e.size === r.rows.length ? new Set : new Set(r.rows.map(e => e.id)));
  async function ne() {
    if (!v) return t(`Choose a status`, `error`);
    w(!0);
    try {
      t(`Updated ${(await cr.bulkStatus({ids:[...p],status:v,note:b})).updated} requests`, `success`), g(!1), m(new Set), y(``), x(``), O()
    } catch (e) {
      t(e.message, `error`)
    } finally {
      w(!1)
    }
  }
  async function re(e = `csv`) {
    try {
      let t = p.size > 0 ? [...p] : r.rows.map(e => e.id);
      if (e === `xlsx`) {
        let e = await Tr.json(t),
          {
            utils: n,
            writeFile: r
          } = await S(async () => {
            let {
              utils: e,
              writeFile: t
            } = await import(`./s2nri-portal-xlsx.Di0UmS3c.js`);
            return {
              utils: e,
              writeFile: t
            }
          }, [], import.meta.url),
          i = n.json_to_sheet(e.rows || []),
          a = n.book_new();
        n.book_append_sheet(a, i, `Bookings`), r(a, `bookings-export-${Date.now()}.xlsx`);
        return
      }
      let n = await hr.csv(t),
        i = new Blob([n], {
          type: `text/csv`
        }),
        a = URL.createObjectURL(i),
        o = document.createElement(`a`);
      o.href = a, o.download = `requests-export-${Date.now()}.csv`, o.click(), URL.revokeObjectURL(a)
    } catch (e) {
      t(e.message || `Export failed`, `error`)
    }
  }
  let ie = Math.max(1, Math.ceil(r.total / Ja));
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      gap: 20
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        flexWrap: `wrap`,
        gap: 12
      },
      children: [(0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(`h1`, {
          style: {
            fontSize: 22,
            fontWeight: 800
          },
          children: `Requests`
        }), (0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`,
            marginTop: 3
          },
          children: a ? `…` : `${r.total.toLocaleString()} total`
        })]
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          gap: 10
        },
        children: [p.size > 0 && (0, F.jsxs)(F.Fragment, {
          children: [(0, F.jsxs)(z, {
            variant: `secondary`,
            size: `sm`,
            icon: (0, F.jsx)(Di, {
              size: 14
            }),
            onClick: () => g(!0),
            children: [`Update Status (`, p.size, `)`]
          }), (0, F.jsx)(z, {
            variant: `secondary`,
            size: `sm`,
            icon: (0, F.jsx)(ai, {
              size: 14
            }),
            onClick: () => re(`xlsx`),
            children: `Export Selected (Excel)`
          })]
        }), (0, F.jsx)(z, {
          variant: `secondary`,
          size: `sm`,
          icon: (0, F.jsx)(ai, {
            size: 14
          }),
          onClick: () => re(`xlsx`),
          children: `Export All`
        })]
      })]
    }), E && (0, F.jsxs)(`div`, {
      style: {
        padding: `12px 16px`,
        background: `#fef2f2`,
        border: `1px solid #fecaca`,
        borderRadius: `var(--r)`,
        color: `#b91c1c`,
        fontSize: 14
      },
      children: [`⚠️ `, E, ` — `, (0, F.jsx)(`button`, {
        onClick: O,
        style: {
          background: `none`,
          border: `none`,
          cursor: `pointer`,
          color: `#b91c1c`,
          textDecoration: `underline`,
          fontSize: 14,
          fontFamily: `inherit`
        },
        children: `Retry`
      })]
    }), (0, F.jsx)(Qa, {
      currentStatus: l,
      onFilter: e => {
        u(e), f(1)
      }
    }), (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        gap: 10,
        flexWrap: `wrap`
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          position: `relative`,
          flex: 1,
          minWidth: 220
        },
        children: [(0, F.jsx)(Ci, {
          size: 15,
          style: {
            position: `absolute`,
            left: 11,
            top: `50%`,
            transform: `translateY(-50%)`,
            color: `var(--muted)`,
            pointerEvents: `none`
          }
        }), (0, F.jsx)(`input`, {
          defaultValue: s,
          onChange: e => {
            clearTimeout(T.current), T.current = setTimeout(() => ee(e.target.value), 350)
          },
          placeholder: `Search ref, customer, service…`,
          style: {
            width: `100%`,
            padding: `9px 13px 9px 34px`,
            fontSize: 14,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r)`,
            fontFamily: `inherit`,
            outline: `none`,
            background: `#fff`,
            boxSizing: `border-box`
          }
        })]
      }), (0, F.jsx)(Zi, {
        value: l,
        onChange: e => {
          u(e.target.value), f(1)
        },
        options: Ya,
        style: {
          minWidth: 180
        }
      }), (s || l) && (0, F.jsx)(z, {
        variant: `ghost`,
        size: `md`,
        icon: (0, F.jsx)(Li, {
          size: 14
        }),
        onClick: () => {
          c(``), u(``), f(1)
        },
        children: `Clear`
      })]
    }), p.size > 0 && (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        gap: 12,
        padding: `8px 14px`,
        background: `${qa}12`,
        borderRadius: `var(--r)`,
        fontSize: 13
      },
      children: [(0, F.jsxs)(`span`, {
        style: {
          color: qa,
          fontWeight: 600
        },
        children: [p.size, ` selected`]
      }), (0, F.jsx)(`button`, {
        onClick: k,
        style: {
          background: `none`,
          border: `none`,
          cursor: `pointer`,
          color: `var(--muted)`,
          fontSize: 13,
          fontFamily: `inherit`
        },
        children: p.size === r.rows.length ? `Deselect all` : `Select all ${r.rows.length}`
      }), (0, F.jsxs)(`button`, {
        onClick: () => m(new Set),
        style: {
          background: `none`,
          border: `none`,
          cursor: `pointer`,
          color: `var(--muted)`,
          marginLeft: `auto`,
          display: `flex`,
          alignItems: `center`,
          gap: 4,
          fontFamily: `inherit`,
          fontSize: 13
        },
        children: [(0, F.jsx)(Li, {
          size: 13
        }), ` Clear`]
      })]
    }), (0, F.jsx)(aa, {
      columns: [{
        key: `_chk`,
        label: ``,
        width: 36,
        render: (row) => (0, F.jsx)(`input`, {
          type: `checkbox`,
          checked: p.has(row.id),
          onChange: () => te(row.id),
          onClick: e => e.stopPropagation(),
          style: {
            cursor: `pointer`,
            accentColor: qa
          }
        })
      }, {
        key: `booking_ref`,
        label: `Reference`,
        render: (row) => (0, F.jsx)(`span`, {
          style: {
            fontFamily: `monospace`,
            fontWeight: 700,
            fontSize: 13,
            color: qa
          },
          children: row.booking_ref
        })
      }, {
        key: `customer_name`,
        label: `Customer`,
        noWrap: !0
      }, {
        key: `service_name`,
        label: `Service`,
        noWrap: !0
      }, {
        key: `status`,
        label: `Status`,
        render: (row) => (0, F.jsx)(Ji, {
          status: row.status
        })
      }, {
        key: `payment_status`,
        label: `Payment`,
        render: (row) => row.payment_status ? (0, F.jsx)(Ji, {
          status: row.payment_status
        }) : `—`
      }, {
        key: `quoted_amount`,
        label: `Quote`,
        render: (row) => row.quoted_amount ? `₹${Number(row.quoted_amount).toLocaleString(`en-IN`)}` : `—`,
        noWrap: !0
      }, {
        key: `created_at`,
        label: `Date`,
        render: (row) => Xa(row.created_at),
        noWrap: !0
      }, {
        key: `_assigned`,
        label: `Assigned`,
        render: (row) => row.assigned_name || (0, F.jsx)(`span`, {
          style: {
            color: `var(--muted)`
          },
          children: `—`
        })
      }],
      rows: r.rows,
      loading: a,
      onRowClick: t => e(`/requests/${t.id}`),
      empty: (0, F.jsx)(Qi, {
        icon: `📋`,
        title: `No requests found`,
        desc: s || l ? `Try clearing the filters.` : `No requests yet.`
      })
    }), ie > 1 && (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        fontSize: 13,
        color: `var(--muted)`
      },
      children: [(0, F.jsxs)(`span`, {
        children: [`Page `, d, ` of `, ie, ` · `, r.total, ` total`]
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          gap: 8
        },
        children: [(0, F.jsx)(z, {
          variant: `secondary`,
          size: `sm`,
          icon: (0, F.jsx)(Jr, {
            size: 14
          }),
          disabled: d === 1,
          onClick: () => f(e => e - 1),
          children: `Prev`
        }), (0, F.jsxs)(z, {
          variant: `secondary`,
          size: `sm`,
          disabled: d === ie,
          onClick: () => f(e => e + 1),
          children: [`Next `, (0, F.jsx)(Yr, {
            size: 14
          })]
        })]
      })]
    }), (0, F.jsx)($i, {
      open: h,
      onClose: () => g(!1),
      title: `Update status for ${p.size} requests`,
      footer: (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(z, {
          variant: `secondary`,
          onClick: () => g(!1),
          children: `Cancel`
        }), (0, F.jsx)(z, {
          loading: C,
          onClick: ne,
          style: {
            background: qa
          },
          children: `Apply to all`
        })]
      }),
      children: (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          flexDirection: `column`,
          gap: 14
        },
        children: [(0, F.jsx)(Zi, {
          label: `New status`,
          value: v,
          onChange: e => y(e.target.value),
          required: !0,
          options: Ya.filter(e => e.value),
          placeholder: `Choose status…`
        }), (0, F.jsx)(Xi, {
          label: `Note (optional)`,
          value: b,
          onChange: e => x(e.target.value),
          placeholder: `Reason for status change…`,
          as: `textarea`,
          rows: 2
        })]
      })
    })]
  })
}
var V = `var(--brand)`;

function eo(e) {
  return e ? new Date(e).toLocaleDateString(`en-IN`, {
    day: `numeric`,
    month: `short`,
    year: `numeric`
  }) : `—`
}

function to(e) {
  return e ? new Date(e).toLocaleString(`en-IN`, {
    day: `numeric`,
    month: `short`,
    hour: `2-digit`,
    minute: `2-digit`,
    hour12: !0
  }) : ``
}
var no = [`submitted`, `under_review`, `quote_sent`, `quote_approved`, `in_progress`, `docs_requested`, `docs_received`, `processing`, `completed`, `cancelled`, `on_hold`, `service_not_available`],
  ro = [{
    key: `submitted`,
    label: `Received`
  }, {
    key: `under_review`,
    label: `Under Review`
  }, {
    key: `quote_sent`,
    label: `Ready to Process`
  }, {
    key: `quote_approved`,
    label: `Quote Sent`
  }, {
    key: `in_progress`,
    label: `Approved`
  }, {
    key: `processing`,
    label: `In Progress`
  }, {
    key: `completed`,
    label: `Completed`
  }];

function io({
  b: e
}) {
  let t = e.manager_contact,
    n = [e.city_india, e.address_india].filter(Boolean).join(`, `) || `Karnataka India`;
  return (0, F.jsxs)(`div`, {
    style: {
      background: `#fff`,
      border: `1px solid #e5e7eb`,
      borderRadius: 8,
      padding: `18px 22px`,
      marginBottom: 12,
      display: `grid`,
      gridTemplateColumns: `auto 1fr 1fr 1fr`,
      gap: `0 24px`,
      alignItems: `start`
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        flexDirection: `column`,
        alignItems: `center`,
        gap: 6,
        minWidth: 90
      },
      children: [(0, F.jsx)(`div`, {
        style: {
          width: 54,
          height: 54,
          background: `#f3f4f6`,
          borderRadius: 8,
          display: `flex`,
          alignItems: `center`,
          justifyContent: `center`,
          fontSize: 24
        },
        children: e.cat_icon || `📄`
      }), (0, F.jsx)(`div`, {
        style: {
          fontSize: 12,
          fontWeight: 700,
          color: `#374151`,
          textAlign: `center`,
          lineHeight: 1.4
        },
        children: e.service_name || `Service`
      })]
    }), (0, F.jsxs)(`div`, {
      children: [(0, F.jsx)(`div`, {
        style: {
          fontSize: 11,
          fontWeight: 700,
          color: `#6b7280`,
          textTransform: `uppercase`,
          letterSpacing: `.05em`,
          marginBottom: 8
        },
        children: `Customer Details`
      }), (0, F.jsx)(`div`, {
        style: {
          fontSize: 14,
          fontWeight: 800,
          color: `#111827`,
          textTransform: `uppercase`,
          marginBottom: 4
        },
        children: e.customer_name || `—`
      }), e.customer_phone && (0, F.jsxs)(`div`, {
        style: {
          fontSize: 13,
          color: `#374151`,
          marginBottom: 2
        },
        children: [`+`, e.customer_phone]
      }), e.customer_email && (0, F.jsx)(`div`, {
        style: {
          fontSize: 13,
          color: `#374151`,
          wordBreak: `break-all`
        },
        children: e.customer_email
      })]
    }), (0, F.jsxs)(`div`, {
      children: [(0, F.jsx)(`div`, {
        style: {
          fontSize: 11,
          fontWeight: 700,
          color: `#6b7280`,
          textTransform: `uppercase`,
          letterSpacing: `.05em`,
          marginBottom: 8
        },
        children: `Shipping Address`
      }), (0, F.jsx)(`div`, {
        style: {
          fontSize: 13,
          color: `#374151`,
          lineHeight: 1.6
        },
        children: n
      })]
    }), (0, F.jsxs)(`div`, {
      children: [(0, F.jsx)(`div`, {
        style: {
          fontSize: 11,
          fontWeight: 700,
          color: `#6b7280`,
          textTransform: `uppercase`,
          letterSpacing: `.05em`,
          marginBottom: 8
        },
        children: `Contact Order Manager`
      }), t ? (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(`div`, {
          style: {
            fontSize: 14,
            fontWeight: 800,
            color: `#111827`,
            marginBottom: 4
          },
          children: t.name
        }), t.phone && (0, F.jsxs)(`div`, {
          style: {
            fontSize: 13,
            color: `#374151`,
            marginBottom: 2
          },
          children: [`Phone: `, t.phone]
        }), t.email && (0, F.jsxs)(`div`, {
          style: {
            fontSize: 13,
            color: `#374151`
          },
          children: [`Email: `, t.email]
        })]
      }) : (0, F.jsx)(`div`, {
        style: {
          fontSize: 13,
          color: `#9ca3af`,
          fontStyle: `italic`
        },
        children: `Not assigned yet`
      })]
    })]
  })
}

function ao({
  b: e
}) {
  let t = parseFloat(e.service_charges || e.quoted_amount || 0) + parseFloat(e.shipping_charges || 0),
    n = [{
      label: `Total Amount`,
      value: t > 0 ? `INR ${t.toLocaleString(`en-IN`,{minimumFractionDigits:2})}` : `To be Updated`
    }, {
      label: `Timeline`,
      value: e.delivery_info || `To be Updated`
    }, {
      label: `Secondary Status`,
      value: e.secondary_status || `To be Updated`
    }];
  return (0, F.jsx)(`div`, {
    style: {
      background: `#fff`,
      border: `1px solid #e5e7eb`,
      borderRadius: 8,
      padding: `12px 0`,
      marginBottom: 12,
      display: `flex`
    },
    children: n.map((e, t) => (0, F.jsxs)(`div`, {
      style: {
        flex: 1,
        padding: `4px 24px`,
        borderRight: t < n.length - 1 ? `1px solid #e5e7eb` : `none`
      },
      children: [(0, F.jsxs)(`span`, {
        style: {
          fontSize: 13,
          color: `#6b7280`
        },
        children: [e.label, ` : `]
      }), (0, F.jsx)(`span`, {
        style: {
          fontSize: 13,
          fontWeight: 700,
          color: `#111827`
        },
        children: e.value
      })]
    }, t))
  })
}

function oo({
  status: e
}) {
  let t = ro.findIndex(t => t.key === e),
    n = t === -1 ? 0 : t;
  return (0, F.jsx)(`div`, {
    style: {
      background: `#fff`,
      border: `1px solid #e5e7eb`,
      borderRadius: 8,
      padding: `20px 28px`,
      marginBottom: 12,
      display: `flex`,
      alignItems: `center`,
      overflowX: `auto`
    },
    children: ro.map((e, t) => {
      let r = t <= n,
        i = t === n;
      return (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          flex: t < ro.length - 1 ? 1 : `none`
        },
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            flexDirection: `column`,
            alignItems: `center`,
            gap: 7,
            minWidth: 72
          },
          children: [(0, F.jsx)(`div`, {
            style: {
              width: 28,
              height: 28,
              borderRadius: `50%`,
              background: r ? V : `#e5e7eb`,
              border: `3px solid ${r?V:`#e5e7eb`}`,
              boxShadow: i ? `0 0 0 4px var(--brand-light)` : `none`,
              transition: `all .3s`,
              flexShrink: 0
            }
          }), (0, F.jsx)(`div`, {
            style: {
              fontSize: 11,
              fontWeight: 600,
              textAlign: `center`,
              color: r ? V : `#9ca3af`,
              lineHeight: 1.3
            },
            children: e.label
          })]
        }), t < ro.length - 1 && (0, F.jsx)(`div`, {
          style: {
            flex: 1,
            height: 2,
            background: t < n ? V : `#e5e7eb`,
            margin: `0 4px`,
            marginBottom: 20,
            minWidth: 20,
            transition: `background .3s`
          }
        })]
      }, e.key)
    })
  })
}

function so({
  booking: e,
  onRefresh: t
}) {
  let n = R(),
    [r, i] = (0, _.useState)(!0),
    [a, o] = (0, _.useState)(e.status),
    [s, c] = (0, _.useState)(``),
    [l, u] = (0, _.useState)(e.service_charges || ``),
    [d, f] = (0, _.useState)(e.shipping_charges || ``),
    [p, m] = (0, _.useState)(`Domestic`),
    [h, g] = (0, _.useState)(`days`),
    [v, y] = (0, _.useState)(e.delivery_working_days || 30),
    [b, x] = (0, _.useState)(e.due_date?.split(`T`)[0] || ``),
    [S, C] = (0, _.useState)(e.secondary_status || ``),
    [w, T] = (0, _.useState)(e.assigned_to || ``),
    [E, D] = (0, _.useState)(e.vendor_id || ``),
    [O, ee] = (0, _.useState)(``),
    [te, k] = (0, _.useState)({}),
    ne = (e, r) => async () => {
      k(t => ({
        ...t,
        [e]: !0
      }));
      try {
        await r(), n(`Saved`, `success`), t()
      } catch (e) {
        n(e.message || `Save failed`, `error`)
      } finally {
        k(t => ({
          ...t,
          [e]: !1
        }))
      }
    }, re = e.staff_list || [], ie = e.vendor_list || [];
  (parseFloat(l) || 0) + (parseFloat(d) || 0);
  let ae = e => (0, F.jsx)(`div`, {
      style: {
        fontSize: 11,
        fontWeight: 700,
        color: `#6b7280`,
        textTransform: `uppercase`,
        letterSpacing: `.06em`,
        marginBottom: 8,
        marginTop: 4
      },
      children: e
    }),
    A = {
      width: `100%`,
      padding: `8px 12px`,
      fontSize: 13,
      border: `1px solid #d1d5db`,
      borderRadius: 6,
      fontFamily: `inherit`,
      outline: `none`,
      boxSizing: `border-box`
    },
    j = (e, t, n, r) => (0, F.jsxs)(`button`, {
      onClick: ne(n, t),
      disabled: !!te[n],
      style: {
        width: `100%`,
        padding: `9px`,
        fontSize: 13,
        fontWeight: 600,
        background: V,
        color: `#fff`,
        border: `none`,
        borderRadius: 6,
        cursor: `pointer`,
        fontFamily: `inherit`,
        display: `flex`,
        alignItems: `center`,
        justifyContent: `center`,
        gap: 6,
        opacity: te[n] ? .6 : 1
      },
      children: [r && (0, F.jsx)(`span`, {
        children: r
      }), e]
    }),
    oe = (e, t, n) => (0, F.jsx)(`button`, {
      onClick: ne(n, t),
      disabled: !!te[n],
      style: {
        width: `100%`,
        padding: `8px`,
        fontSize: 12,
        fontWeight: 600,
        background: `#fff`,
        color: `#374151`,
        border: `1px solid #d1d5db`,
        borderRadius: 6,
        cursor: `pointer`,
        fontFamily: `inherit`,
        opacity: te[n] ? .6 : 1
      },
      children: e
    });
  return (0, F.jsxs)(`div`, {
    style: {
      background: `#fff`,
      border: `1px solid #e5e7eb`,
      borderRadius: 8,
      marginBottom: 12
    },
    children: [(0, F.jsxs)(`button`, {
      onClick: () => i(e => !e),
      style: {
        width: `100%`,
        padding: `14px 20px`,
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        background: `none`,
        border: `none`,
        cursor: `pointer`,
        fontFamily: `inherit`
      },
      children: [(0, F.jsxs)(`span`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          gap: 8,
          fontSize: 14,
          fontWeight: 700,
          color: `#111827`
        },
        children: [(0, F.jsx)(`span`, {
          children: `⚙`
        }), ` Staff Controls`]
      }), (0, F.jsx)(`span`, {
        style: {
          fontSize: 12,
          color: `#9ca3af`
        },
        children: r ? `▲` : `▼`
      })]
    }), r && (0, F.jsx)(`div`, {
      style: {
        padding: `0 20px 20px`,
        borderTop: `1px solid #f3f4f6`
      },
      children: (0, F.jsxs)(`div`, {
        style: {
          display: `grid`,
          gridTemplateColumns: `1fr 1fr`,
          gap: 24,
          paddingTop: 16
        },
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            flexDirection: `column`,
            gap: 16
          },
          children: [(0, F.jsxs)(`div`, {
            children: [ae(`UPDATE STATUS`), (0, F.jsx)(`select`, {
              value: a,
              onChange: e => o(e.target.value),
              style: {
                ...A,
                marginBottom: 8
              },
              children: no.map(e => (0, F.jsx)(`option`, {
                value: e,
                children: e.replace(/_/g, ` `).replace(/\b\w/g, e => e.toUpperCase())
              }, e))
            }), (0, F.jsx)(`input`, {
              value: s,
              onChange: e => c(e.target.value),
              placeholder: `Note (optional)`,
              style: {
                ...A,
                marginBottom: 8
              }
            }), j(`Update Status`, () => cr.updateStatus(e.id, {
              status: a,
              note: s
            }), `status`)]
          }), (0, F.jsxs)(`div`, {
            children: [ae(`💰 QUOTATION`), (0, F.jsxs)(`div`, {
              style: {
                marginBottom: 8
              },
              children: [(0, F.jsx)(`label`, {
                style: {
                  fontSize: 12,
                  color: `#6b7280`,
                  display: `block`,
                  marginBottom: 4
                },
                children: `Service Charges (INR)`
              }), (0, F.jsxs)(`div`, {
                style: {
                  display: `flex`,
                  gap: 6
                },
                children: [(0, F.jsx)(`input`, {
                  type: `number`,
                  value: l,
                  onChange: e => u(e.target.value),
                  placeholder: `0.00`,
                  style: {
                    ...A,
                    flex: 1
                  }
                }), (0, F.jsx)(`button`, {
                  onClick: ne(`svc`, async () => {
                    parseFloat(l) > 0 && await lr.send(e.id, {
                      amount: parseFloat(l),
                      line_items: [{
                        description: `Service charges`,
                        amount: parseFloat(l),
                        type: `service`
                      }],
                      valid_days: 7
                    })
                  }),
                  style: {
                    padding: `8px 12px`,
                    background: V,
                    color: `#fff`,
                    border: `none`,
                    borderRadius: 6,
                    cursor: `pointer`,
                    fontWeight: 700,
                    fontSize: 13
                  },
                  children: `Save`
                })]
              })]
            }), (0, F.jsxs)(`div`, {
              style: {
                marginBottom: 12
              },
              children: [(0, F.jsx)(`label`, {
                style: {
                  fontSize: 12,
                  color: `#6b7280`,
                  display: `block`,
                  marginBottom: 4
                },
                children: `Shipping Charges (INR)`
              }), (0, F.jsxs)(`div`, {
                style: {
                  display: `flex`,
                  gap: 6
                },
                children: [(0, F.jsx)(`input`, {
                  type: `number`,
                  value: d,
                  onChange: e => f(e.target.value),
                  placeholder: `0.00`,
                  style: {
                    ...A,
                    flex: 1
                  }
                }), (0, F.jsxs)(`select`, {
                  value: p,
                  onChange: e => m(e.target.value),
                  style: {
                    padding: `8px`,
                    border: `1px solid #d1d5db`,
                    borderRadius: 6,
                    fontFamily: `inherit`,
                    fontSize: 13,
                    outline: `none`
                  },
                  children: [(0, F.jsx)(`option`, {
                    children: `Domestic`
                  }), (0, F.jsx)(`option`, {
                    children: `International`
                  })]
                }), (0, F.jsx)(`button`, {
                  onClick: ne(`ship`, () => {}),
                  style: {
                    padding: `8px 12px`,
                    background: V,
                    color: `#fff`,
                    border: `none`,
                    borderRadius: 6,
                    cursor: `pointer`,
                    fontWeight: 700,
                    fontSize: 13
                  },
                  children: `Save`
                })]
              })]
            }), (0, F.jsxs)(`div`, {
              style: {
                borderTop: `1px solid #e5e7eb`,
                paddingTop: 10
              },
              children: [(0, F.jsx)(`div`, {
                style: {
                  fontSize: 12,
                  fontWeight: 700,
                  color: `#374151`,
                  marginBottom: 8
                },
                children: `📧 Send Quotation Email`
              }), (0, F.jsxs)(`label`, {
                style: {
                  display: `flex`,
                  alignItems: `center`,
                  gap: 6,
                  fontSize: 13,
                  cursor: `pointer`,
                  marginBottom: 8
                },
                children: [(0, F.jsx)(`input`, {
                  type: `checkbox`,
                  style: {
                    accentColor: V
                  }
                }), `Include Terms & Conditions`]
              }), j(`📧 Send Quotation Email to Client`, () => yr.send(e.id, {
                to_email: e.customer_email,
                subject: `Quotation — ${e.booking_ref}`,
                body: `Please find the quotation attached.`
              }), `quote_email`, null)]
            })]
          }), (0, F.jsxs)(`div`, {
            children: [ae(`SECONDARY STATUS`), (0, F.jsxs)(`div`, {
              style: {
                display: `flex`,
                gap: 6
              },
              children: [(0, F.jsx)(`input`, {
                value: S,
                onChange: e => C(e.target.value),
                placeholder: `e.g. Documents pending`,
                style: {
                  ...A,
                  flex: 1
                }
              }), (0, F.jsx)(`button`, {
                onClick: ne(`sec`, () => cr.secStatus(e.id, {
                  value: S
                })),
                style: {
                  padding: `8px 14px`,
                  background: V,
                  color: `#fff`,
                  border: `none`,
                  borderRadius: 6,
                  cursor: `pointer`,
                  fontWeight: 700
                },
                children: `Set`
              })]
            })]
          }), (0, F.jsxs)(`div`, {
            children: [ae(`ASSIGN MANAGER`), (0, F.jsxs)(`div`, {
              style: {
                display: `flex`,
                gap: 6,
                marginBottom: 4
              },
              children: [(0, F.jsxs)(`select`, {
                value: w,
                onChange: e => T(e.target.value),
                style: {
                  ...A,
                  flex: 1
                },
                children: [(0, F.jsx)(`option`, {
                  value: ``,
                  children: `- Select Manager -`
                }), re.map(e => (0, F.jsx)(`option`, {
                  value: e.id,
                  children: e.name
                }, e.id))]
              }), (0, F.jsx)(`button`, {
                onClick: ne(`mgr`, () => cr.assign(e.id, {
                  user_id: w
                })),
                style: {
                  padding: `8px 12px`,
                  background: V,
                  color: `#fff`,
                  border: `none`,
                  borderRadius: 6,
                  cursor: `pointer`,
                  fontWeight: 700
                },
                children: `Save Manager`
              })]
            }), (0, F.jsxs)(`div`, {
              style: {
                fontSize: 12,
                color: `#9ca3af`
              },
              children: [`Currently assigned - `, e.manager_contact?.name || `—`]
            })]
          }), (0, F.jsxs)(`div`, {
            children: [ae(`ASSIGN VENDOR`), (0, F.jsxs)(`div`, {
              style: {
                display: `flex`,
                gap: 6,
                marginBottom: 4
              },
              children: [(0, F.jsxs)(`select`, {
                value: E,
                onChange: e => D(e.target.value),
                style: {
                  ...A,
                  flex: 1
                },
                children: [(0, F.jsx)(`option`, {
                  value: ``,
                  children: `- Select Vendor -`
                }), ie.map(e => (0, F.jsx)(`option`, {
                  value: e.id,
                  children: e.name
                }, e.id))]
              }), (0, F.jsx)(`button`, {
                onClick: ne(`vnd`, () => cr.assignVendor(e.id, {
                  vendor_id: E
                })),
                style: {
                  padding: `8px 12px`,
                  background: V,
                  color: `#fff`,
                  border: `none`,
                  borderRadius: 6,
                  cursor: `pointer`,
                  fontWeight: 700
                },
                children: `Save Vendor`
              })]
            }), (0, F.jsxs)(`div`, {
              style: {
                fontSize: 12,
                color: `#9ca3af`
              },
              children: [`Currently assigned - `, e.vendor?.name || `—`]
            })]
          })]
        }), (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            flexDirection: `column`,
            gap: 16
          },
          children: [(0, F.jsxs)(`div`, {
            children: [ae(`SET DELIVERY DATE`), (0, F.jsxs)(`div`, {
              style: {
                display: `flex`,
                gap: 6,
                marginBottom: 8
              },
              children: [(0, F.jsx)(`button`, {
                onClick: () => g(`days`),
                style: {
                  flex: 1,
                  padding: `8px`,
                  fontSize: 12,
                  fontWeight: 700,
                  background: h === `days` ? V : `#fff`,
                  color: h === `days` ? `#fff` : `#374151`,
                  border: `1px solid var(--border)`,
                  borderRadius: 6,
                  cursor: `pointer`,
                  fontFamily: `inherit`
                },
                children: `By Days`
              }), (0, F.jsx)(`button`, {
                onClick: () => g(`date`),
                style: {
                  flex: 1,
                  padding: `8px`,
                  fontSize: 12,
                  fontWeight: 700,
                  background: h === `date` ? V : `#fff`,
                  color: h === `date` ? `#fff` : `#374151`,
                  border: `1px solid var(--border)`,
                  borderRadius: 6,
                  cursor: `pointer`,
                  fontFamily: `inherit`
                },
                children: `Fixed Date`
              })]
            }), h === `days` ? (0, F.jsxs)(`div`, {
              style: {
                marginBottom: 8
              },
              children: [(0, F.jsx)(`input`, {
                type: `number`,
                value: v,
                onChange: e => y(e.target.value),
                style: {
                  ...A,
                  marginBottom: 4
                }
              }), (0, F.jsxs)(`div`, {
                style: {
                  fontSize: 12,
                  color: `#6b7280`
                },
                children: [`Working Days`, (0, F.jsx)(`br`, {}), `(Excludes Sat, Sun & Govt Holidays)`]
              })]
            }) : (0, F.jsx)(`input`, {
              type: `date`,
              value: b,
              onChange: e => x(e.target.value),
              style: {
                ...A,
                marginBottom: 8
              }
            }), (0, F.jsx)(`input`, {
              placeholder: `Note (optional)`,
              style: {
                ...A,
                marginBottom: 8
              }
            }), j(`Set Timeline`, () => cr.delivery(e.id, h === `days` ? {
              mode: `days`,
              days: v
            } : {
              mode: `date`,
              date: b
            }), `delivery`)]
          }), (0, F.jsxs)(`div`, {
            children: [ae(`QUICK EMAIL ACTIONS`), (0, F.jsxs)(`div`, {
              style: {
                display: `flex`,
                flexDirection: `column`,
                gap: 8
              },
              children: [oe(`📩 Send Document Reminder Email`, () => cr.eventEmail(e.id, {
                event: `document_reminder`
              }), `doc_reminder`), oe(`📧 Send Status Update Email`, () => cr.eventEmail(e.id, {
                event: `status_update`
              }), `status_email`)]
            })]
          }), (0, F.jsxs)(`div`, {
            children: [ae(`INTERNAL NOTES (NOT VISIBLE TO CLIENT)`), (0, F.jsx)(`textarea`, {
              value: O,
              onChange: e => ee(e.target.value),
              rows: 5,
              style: {
                ...A,
                resize: `vertical`,
                marginBottom: 8
              }
            }), (0, F.jsx)(`button`, {
              onClick: ne(`note`, () => cr.addNote(e.id, {
                note: O,
                is_internal: !0
              })),
              style: {
                padding: `8px 16px`,
                background: `#fff`,
                color: `#374151`,
                border: `1px solid #d1d5db`,
                borderRadius: 6,
                cursor: `pointer`,
                fontSize: 13,
                fontFamily: `inherit`
              },
              children: `Save Note`
            })]
          })]
        })]
      })
    })]
  })
}

function co({
  bookingId: e,
  booking: t
}) {
  let n = R(),
    [r, i] = (0, _.useState)(t.messages || []),
    [a, o] = (0, _.useState)([]),
    [s, c] = (0, _.useState)([]),
    [l, u] = (0, _.useState)([]),
    [d, f] = (0, _.useState)(!1),
    [p, m] = (0, _.useState)(``),
    [h, g] = (0, _.useState)(!1),
    [v, y] = (0, _.useState)(!1),
    [b, x] = (0, _.useState)(!1),
    [S, C] = (0, _.useState)(`Update — ${t.booking_ref||``}`),
    [w, T] = (0, _.useState)(``),
    [E, D] = (0, _.useState)(!1),
    [O, ee] = (0, _.useState)(`messages`),
    te = (0, _.useRef)(null),
    k = (0, _.useCallback)(async () => {
      try {
        i((await cr.get(e)).booking?.messages || []), setTimeout(() => te.current?.scrollTo(0, te.current.scrollHeight), 50)
      } catch {}
    }, [e]);
  (0, _.useEffect)(() => {
    k();
    let e = setInterval(k, 6e3);
    return () => clearInterval(e)
  }, [k]), (0, _.useEffect)(() => {
    O === `compose` && !d && (f(!0), vr.list().then(e => c(e.replies || [])).catch(() => {}), gr.list().then(e => u(e.templates || [])).catch(() => {}), yr.history(e).then(e => o(e.history || [])).catch(() => {}))
  }, [O, e, d]);
  async function ne() {
    if (p.trim()) {
      x(!0);
      try {
        await cr.sendMsg(e, {
          message: p,
          is_internal: v,
          send_via_email: h
        }), m(``), n(h ? `Message + email sent` : `Message sent`, `success`), k()
      } catch (e) {
        n(e.message || `Send failed`, `error`)
      } finally {
        x(!1)
      }
    }
  }
  async function re() {
    if (!S || !w) {
      n(`Subject and body required`, `error`);
      return
    }
    D(!0);
    try {
      await yr.send(e, {
        to_email: t.customer_email,
        subject: S,
        body: w,
        log_only: !1
      }), n(`Email sent!`, `success`), T(``), C(`Update — ${t.booking_ref||``}`), yr.history(e).then(e => o(e.history || [])).catch(() => {})
    } catch (e) {
      n(e.message || `Send failed`, `error`)
    } finally {
      D(!1)
    }
  }
  let ie = e => ({
    padding: `10px 16px`,
    fontSize: 13,
    fontWeight: 600,
    background: `none`,
    border: `none`,
    cursor: `pointer`,
    fontFamily: `inherit`,
    color: O === e ? V : `#6b7280`,
    borderBottom: `2px solid ${O===e?V:`transparent`}`,
    marginBottom: -1,
    transition: `all .2s`
  });
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      minHeight: 420
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        borderBottom: `1px solid #e5e7eb`,
        background: `#f9fafb`
      },
      children: [(0, F.jsx)(`button`, {
        style: ie(`messages`),
        onClick: () => ee(`messages`),
        children: `💬 Messages`
      }), (0, F.jsx)(`button`, {
        style: ie(`compose`),
        onClick: () => ee(`compose`),
        children: `📧 Compose Email`
      }), (0, F.jsx)(`button`, {
        style: ie(`history`),
        onClick: () => ee(`history`),
        children: `📋 Email History`
      })]
    }), O === `messages` && (0, F.jsxs)(F.Fragment, {
      children: [(0, F.jsx)(`div`, {
        ref: te,
        style: {
          flex: 1,
          overflowY: `auto`,
          padding: `14px 18px`,
          display: `flex`,
          flexDirection: `column`,
          gap: 12,
          minHeight: 280
        },
        children: r.length === 0 ? (0, F.jsx)(`div`, {
          style: {
            textAlign: `center`,
            padding: `40px 0`,
            color: `#9ca3af`,
            fontSize: 14
          },
          children: `No messages yet. Send a message below.`
        }) : r.map(e => {
          let t = e.sender_type === `staff`;
          return e.is_internal ? (0, F.jsxs)(`div`, {
            style: {
              background: `#fffbeb`,
              border: `1px dashed #fde68a`,
              borderRadius: 6,
              padding: `8px 12px`,
              fontSize: 12
            },
            children: [(0, F.jsx)(`span`, {
              style: {
                fontWeight: 700,
                color: `#92400e`
              },
              children: `📝 Internal note`
            }), (0, F.jsx)(`span`, {
              style: {
                color: `#78350f`,
                marginLeft: 8
              },
              children: e.sender_name
            }), (0, F.jsx)(`span`, {
              style: {
                color: `#b45309`,
                marginLeft: 8,
                fontSize: 11
              },
              children: to(e.created_at)
            }), (0, F.jsx)(`div`, {
              style: {
                marginTop: 6,
                color: `#78350f`,
                lineHeight: 1.5,
                whiteSpace: `pre-wrap`
              },
              children: e.message
            })]
          }, e.id) : (0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              flexDirection: `column`,
              alignItems: t ? `flex-end` : `flex-start`
            },
            children: [(0, F.jsxs)(`div`, {
              style: {
                fontSize: 11,
                color: `#6b7280`,
                marginBottom: 4,
                display: `flex`,
                alignItems: `center`,
                gap: 6
              },
              children: [(0, F.jsx)(ea, {
                name: e.sender_name || `?`,
                size: 18,
                color: t ? V : `#94a3b8`
              }), (0, F.jsx)(`span`, {
                style: {
                  fontWeight: 600
                },
                children: e.sender_name || (t ? `Staff` : `Customer`)
              }), (0, F.jsx)(`span`, {
                children: to(e.created_at)
              }), Number(e.is_email_sent) === 1 && (0, F.jsx)(`span`, {
                style: {
                  background: `#f0f9ff`,
                  border: `1px solid #bae6fd`,
                  color: `#0369a1`,
                  borderRadius: 4,
                  padding: `1px 5px`,
                  fontSize: 10,
                  fontWeight: 700
                },
                children: `✉ Email`
              })]
            }), (0, F.jsx)(`div`, {
              style: {
                maxWidth: `80%`,
                padding: `10px 14px`,
                fontSize: 13,
                lineHeight: 1.6,
                borderRadius: t ? `12px 12px 2px 12px` : `2px 12px 12px 12px`,
                background: t ? V : `#f1f5f9`,
                color: t ? `#fff` : `#111827`,
                whiteSpace: `pre-wrap`
              },
              children: e.message
            })]
          }, e.id)
        })
      }), (0, F.jsxs)(`div`, {
        style: {
          padding: `12px 18px`,
          borderTop: `1px solid #e5e7eb`
        },
        children: [(0, F.jsx)(`textarea`, {
          value: p,
          onChange: e => m(e.target.value),
          rows: 3,
          placeholder: `Type your message here…`,
          onKeyDown: e => {
            e.key === `Enter` && !e.shiftKey && !e.ctrlKey && (e.preventDefault(), ne())
          },
          style: {
            width: `100%`,
            padding: `9px 12px`,
            fontSize: 13,
            border: `1px solid #d1d5db`,
            borderRadius: 6,
            fontFamily: `inherit`,
            resize: `none`,
            outline: `none`,
            boxSizing: `border-box`,
            marginBottom: 10
          }
        }), (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 10,
            flexWrap: `wrap`
          },
          children: [(0, F.jsxs)(`label`, {
            style: {
              display: `flex`,
              alignItems: `center`,
              gap: 6,
              fontSize: 13,
              cursor: `pointer`,
              color: `#6b7280`
            },
            children: [(0, F.jsx)(`input`, {
              type: `checkbox`,
              checked: h,
              onChange: e => g(e.target.checked),
              style: {
                accentColor: V
              }
            }), `Send via Email`]
          }), (0, F.jsxs)(`label`, {
            style: {
              display: `flex`,
              alignItems: `center`,
              gap: 6,
              fontSize: 13,
              cursor: `pointer`,
              color: `#92400e`
            },
            children: [(0, F.jsx)(`input`, {
              type: `checkbox`,
              checked: v,
              onChange: e => y(e.target.checked),
              style: {
                accentColor: `#f59e0b`
              }
            }), `Internal note`]
          }), (0, F.jsxs)(`button`, {
            onClick: () => ne(),
            disabled: b || !p.trim(),
            style: {
              marginLeft: `auto`,
              padding: `8px 20px`,
              background: V,
              color: `#fff`,
              border: `none`,
              borderRadius: 6,
              fontWeight: 700,
              cursor: `pointer`,
              fontSize: 13,
              fontFamily: `inherit`,
              display: `flex`,
              alignItems: `center`,
              gap: 6,
              opacity: b ? .6 : 1
            },
            children: [(0, F.jsx)(wi, {
              size: 14
            }), ` `, b ? `Sending…` : h ? `Send + Email` : v ? `Add Note` : `Send`]
          })]
        }), (0, F.jsx)(`div`, {
          style: {
            fontSize: 11,
            color: `#9ca3af`,
            marginTop: 6
          },
          children: `Send = saved to this chat. Send via Email = saved here + also sends an email notification.`
        })]
      })]
    }), O === `compose` && (0, F.jsxs)(`div`, {
      style: {
        padding: 18,
        display: `flex`,
        flexDirection: `column`,
        gap: 12
      },
      children: [(0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(`label`, {
          style: {
            fontSize: 12,
            fontWeight: 600,
            color: `#374151`,
            display: `block`,
            marginBottom: 4
          },
          children: `Subject`
        }), (0, F.jsx)(`input`, {
          value: S,
          onChange: e => C(e.target.value),
          style: {
            width: `100%`,
            padding: `8px 12px`,
            fontSize: 13,
            border: `1px solid #d1d5db`,
            borderRadius: 6,
            fontFamily: `inherit`,
            outline: `none`,
            boxSizing: `border-box`
          }
        })]
      }), s.length > 0 && (0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(`div`, {
          style: {
            fontSize: 11,
            fontWeight: 700,
            color: `#6b7280`,
            textTransform: `uppercase`,
            letterSpacing: `.05em`,
            marginBottom: 6
          },
          children: `Quick Replies`
        }), (0, F.jsx)(`div`, {
          style: {
            display: `flex`,
            gap: 6,
            flexWrap: `wrap`
          },
          children: s.map(e => (0, F.jsx)(`button`, {
            onClick: () => T(t => t + (t ? `

` : ``) + e.content),
            style: {
              fontSize: 12,
              padding: `4px 10px`,
              borderRadius: 20,
              border: `1px solid #e5e7eb`,
              background: `#fff`,
              cursor: `pointer`,
              color: `#374151`,
              fontFamily: `inherit`
            },
            children: e.title
          }, e.id))
        })]
      }), (0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(`label`, {
          style: {
            fontSize: 12,
            fontWeight: 600,
            color: `#374151`,
            display: `block`,
            marginBottom: 4
          },
          children: `Message`
        }), (0, F.jsx)(`textarea`, {
          value: w,
          onChange: e => T(e.target.value),
          rows: 8,
          placeholder: `Type your email message here…`,
          style: {
            width: `100%`,
            padding: `9px 12px`,
            fontSize: 13,
            border: `1px solid #d1d5db`,
            borderRadius: 6,
            fontFamily: `inherit`,
            resize: `vertical`,
            outline: `none`,
            boxSizing: `border-box`,
            lineHeight: 1.6
          }
        })]
      }), (0, F.jsx)(`div`, {
        style: {
          display: `flex`,
          gap: 10
        },
        children: (0, F.jsxs)(`button`, {
          onClick: re,
          disabled: E,
          style: {
            padding: `9px 20px`,
            background: V,
            color: `#fff`,
            border: `none`,
            borderRadius: 6,
            fontWeight: 700,
            cursor: `pointer`,
            fontSize: 13,
            fontFamily: `inherit`,
            display: `flex`,
            alignItems: `center`,
            gap: 6
          },
          children: [(0, F.jsx)(pi, {
            size: 14
          }), ` `, E ? `Sending…` : `✉ Send Email`]
        })
      })]
    }), O === `history` && (0, F.jsx)(`div`, {
      style: {
        padding: 18
      },
      children: a.length === 0 ? (0, F.jsx)(`div`, {
        style: {
          textAlign: `center`,
          padding: `40px 0`,
          color: `#9ca3af`,
          fontSize: 14
        },
        children: `No emails sent yet.`
      }) : a.map(e => (0, F.jsx)(`div`, {
        style: {
          border: `1px solid #e5e7eb`,
          borderRadius: 6,
          marginBottom: 10,
          overflow: `hidden`
        },
        children: (0, F.jsxs)(`div`, {
          style: {
            padding: `10px 14px`,
            background: `#f9fafb`,
            fontSize: 13
          },
          children: [(0, F.jsx)(`strong`, {
            children: e.sender_name || `Staff`
          }), ` · `, to(e.created_at), e.subject && (0, F.jsxs)(F.Fragment, {
            children: [` · `, (0, F.jsx)(`em`, {
              children: e.subject
            })]
          })]
        })
      }, e.id))
    })]
  })
}

function lo({
  booking: e,
  bookingId: t,
  onRefresh: n
}) {
  let r = R(),
    [i, a] = (0, _.useState)(!1),
    [o, s] = (0, _.useState)(`Document`),
    [c, l] = (0, _.useState)(!1),
    [u, d] = (0, _.useState)([]),
    f = (0, _.useRef)(null),
    p = e.user_documents || (e.documents || []).filter(e => !e.is_from_staff),
    m = e.provider_documents || (e.documents || []).filter(e => e.is_from_staff),
    h = [...p, ...m].map(e => e.id),
    g = h.length > 0 && h.every(e => u.includes(e));

  function v() {
    d(g ? [] : h)
  }

  function y(e) {
    d(t => t.includes(e) ? t.filter(t => t !== e) : [...t, e])
  }
  async function b(e) {
    let i = e.target.files?.[0];
    if (!i) return;
    if (i.size > 10 * 1024 * 1024) {
      r(`File exceeds 10MB`, `error`);
      return
    }
    a(!0);
    let s = new FormData;
    s.append(`file`, i), s.append(`doc_type`, o), s.append(`is_from_staff`, c ? `1` : `0`);
    try {
      await cr.uploadDoc(t, s), r(`Uploaded`, `success`), n(), f.current.value = ``
    } catch (e) {
      r(e.message, `error`)
    } finally {
      a(!1)
    }
  }
  let x = {
      display: `flex`,
      alignItems: `center`,
      gap: 10,
      padding: `10px 14px`,
      borderBottom: `1px solid #f3f4f6`,
      fontSize: 13
    },
    S = ({
      doc: e
    }) => (0, F.jsxs)(`div`, {
      style: x,
      children: [(0, F.jsx)(`input`, {
        type: `checkbox`,
        checked: u.includes(e.id),
        onChange: () => y(e.id),
        style: {
          width: 14,
          height: 14,
          flexShrink: 0
        }
      }), (0, F.jsxs)(`div`, {
        style: {
          flex: 1,
          minWidth: 0
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            fontWeight: 600,
            color: `#111827`,
            overflow: `hidden`,
            textOverflow: `ellipsis`,
            whiteSpace: `nowrap`
          },
          children: e.file_name || e.doc_type
        }), (0, F.jsxs)(`div`, {
          style: {
            fontSize: 11,
            color: `#9ca3af`
          },
          children: [`By `, e.is_from_staff ? `Staff` : `Client`, ` · `, eo(e.created_at)]
        })]
      }), (0, F.jsx)(`a`, {
        href: `/wp-json/s2nri/v1/documents/${e.id}/view`,
        target: `_blank`,
        rel: `noopener noreferrer`,
        style: {
          padding: `4px 10px`,
          background: `#f3f4f6`,
          color: `#374151`,
          borderRadius: 4,
          textDecoration: `none`,
          fontSize: 12,
          fontWeight: 600
        },
        children: `↓`
      }), (0, F.jsx)(`a`, {
        href: `/wp-json/s2nri/v1/documents/${e.id}/download`,
        style: {
          padding: `4px`,
          color: `#9ca3af`,
          fontSize: 16
        },
        children: `🗑`
      })]
    });
  return (0, F.jsxs)(`div`, {
    style: {
      padding: 16
    },
    children: [(0, F.jsx)(`div`, {
      style: {
        background: `#f9fafb`,
        border: `1px solid #e5e7eb`,
        borderRadius: 6,
        padding: 14,
        marginBottom: 16
      },
      children: (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          gap: 8,
          alignItems: `center`,
          flexWrap: `wrap`
        },
        children: [(0, F.jsx)(`input`, {
          value: o,
          onChange: e => s(e.target.value),
          placeholder: `Document type`,
          style: {
            padding: `7px 10px`,
            fontSize: 13,
            border: `1px solid #d1d5db`,
            borderRadius: 6,
            fontFamily: `inherit`,
            outline: `none`,
            flex: 1
          }
        }), (0, F.jsxs)(`label`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 6,
            fontSize: 13,
            cursor: `pointer`
          },
          children: [(0, F.jsx)(`input`, {
            type: `checkbox`,
            checked: c,
            onChange: e => l(e.target.checked),
            style: {
              accentColor: V
            }
          }), ` Staff doc`]
        }), (0, F.jsx)(`input`, {
          ref: f,
          type: `file`,
          onChange: b,
          style: {
            display: `none`
          },
          id: `admin-doc-up`
        }), (0, F.jsx)(`label`, {
          htmlFor: `admin-doc-up`,
          style: {
            padding: `7px 14px`,
            background: V,
            color: `#fff`,
            borderRadius: 6,
            cursor: `pointer`,
            fontSize: 13,
            fontWeight: 700
          },
          children: i ? `Uploading…` : `+ Upload`
        })]
      })
    }), (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        gap: 10,
        padding: `8px 14px`,
        background: `#f3f4f6`,
        borderRadius: 6,
        marginBottom: 8
      },
      children: [(0, F.jsxs)(`label`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          gap: 6,
          fontSize: 13,
          cursor: `pointer`
        },
        children: [(0, F.jsx)(`input`, {
          type: `checkbox`,
          checked: g,
          onChange: v,
          style: {
            width: 14,
            height: 14
          }
        }), `Select All`]
      }), (0, F.jsx)(`span`, {
        style: {
          fontSize: 13,
          color: `#9ca3af`
        },
        children: `| ↓ Download All`
      })]
    }), (0, F.jsxs)(`div`, {
      style: {
        border: `1px solid #e5e7eb`,
        borderRadius: 6,
        overflow: `hidden`,
        marginBottom: 12
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          padding: `10px 14px`,
          background: `#f9fafb`,
          fontWeight: 700,
          fontSize: 13,
          color: `#374151`,
          display: `flex`,
          justifyContent: `space-between`
        },
        children: [`User Documents `, (0, F.jsx)(`span`, {
          style: {
            color: `#9ca3af`
          },
          children: `▲`
        })]
      }), p.map(e => (0, F.jsx)(S, {
        doc: e
      }, e.id)), p.length === 0 && (0, F.jsx)(`div`, {
        style: {
          padding: `14px`,
          color: `#9ca3af`,
          fontSize: 13
        },
        children: `No user documents`
      })]
    }), (0, F.jsxs)(`div`, {
      style: {
        border: `1px solid #e5e7eb`,
        borderRadius: 6,
        overflow: `hidden`
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          padding: `10px 14px`,
          background: `#f9fafb`,
          fontWeight: 700,
          fontSize: 13,
          color: `#374151`,
          display: `flex`,
          justifyContent: `space-between`
        },
        children: [`Service Provider Documents `, (0, F.jsx)(`span`, {
          style: {
            color: `#9ca3af`
          },
          children: `▼`
        })]
      }), m.map(e => (0, F.jsx)(S, {
        doc: e
      }, e.id)), m.length === 0 && (0, F.jsx)(`div`, {
        style: {
          padding: `14px`,
          color: `#9ca3af`,
          fontSize: 13
        },
        children: `No provider documents`
      })]
    })]
  })
}

function uo({
  booking: e
}) {
  let t = typeof e.field_data == `string` ? JSON.parse(e.field_data || `{}`) : e.field_data || {},
    n = Object.entries(t).filter(([e]) => !e.startsWith(`__`));

  function r(t) {
    let n = window.S2NRI_CFG || {};
    window.open(`${n.base}/admin/form-submissions/${e.id}/export?format=${t}`)
  }
  return (0, F.jsxs)(`div`, {
    style: {
      padding: 16
    },
    children: [(0, F.jsx)(`div`, {
      style: {
        display: `flex`,
        gap: 8,
        marginBottom: 14,
        flexWrap: `wrap`
      },
      children: [
        [`pdf`, `📄 PDF`],
        [`png`, `🖼 PNG / Image`],
        [`docx`, `📝 Word (.docx)`],
        [`xlsx`, `📊 Excel (.xlsx)`]
      ].map(([e, t]) => (0, F.jsx)(`button`, {
        onClick: () => r(e),
        style: {
          padding: `6px 14px`,
          fontSize: 12,
          fontWeight: 600,
          border: `1px solid #d1d5db`,
          borderRadius: 6,
          background: e === `pdf` ? V : `#fff`,
          color: e === `pdf` ? `#fff` : `#374151`,
          cursor: `pointer`,
          fontFamily: `inherit`
        },
        children: t
      }, e))
    }), n.length === 0 ? (0, F.jsx)(`div`, {
      style: {
        color: `#9ca3af`,
        fontSize: 14
      },
      children: `No form data available.`
    }) : (0, F.jsx)(`div`, {
      style: {
        display: `grid`,
        gridTemplateColumns: `repeat(auto-fill, minmax(200px, 1fr))`,
        gap: 10
      },
      children: n.map(([e, t]) => (0, F.jsxs)(`div`, {
        style: {
          background: `#f9fafb`,
          borderRadius: 6,
          padding: `12px 14px`,
          border: `1px solid #e5e7eb`
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            fontSize: 11,
            fontWeight: 700,
            color: `#6b7280`,
            textTransform: `uppercase`,
            letterSpacing: `.04em`,
            marginBottom: 4
          },
          children: e.replace(/_/g, ` `).replace(/\b\w/g, e => e.toUpperCase())
        }), (0, F.jsx)(`div`, {
          style: {
            fontSize: 13,
            fontWeight: 600,
            color: `#111827`,
            wordBreak: `break-word`
          },
          children: Array.isArray(t) ? t.join(`, `) : String(t || `—`)
        })]
      }, e))
    })]
  })
}

function H({
  booking: e,
  bookingId: t
}) {
  let n = R(),
    [r, i] = (0, _.useState)(!1),
    [a, o] = (0, _.useState)(``),
    [s, c] = (0, _.useState)(``),
    [l, u] = (0, _.useState)(!1),
    d = e.tickets || [];
  async function f() {
    if (!a) {
      n(`Select category`, `error`);
      return
    }
    u(!0);
    try {
      await fetch(`${window.S2NRI_CFG?.base}/admin/bookings/${t}/tickets`, {
        method: `POST`,
        credentials: `include`,
        headers: {
          "X-WP-Nonce": window.S2NRI_CFG?.nonce,
          "Content-Type": `application/json`
        },
        body: JSON.stringify({
          category: a,
          notes: s
        })
      }), n(`Ticket created`, `success`), i(!1), o(``), c(``)
    } catch {
      n(`Failed`, `error`)
    } finally {
      u(!1)
    }
  }
  return (0, F.jsxs)(`div`, {
    style: {
      padding: 16
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        justifyContent: `space-between`,
        alignItems: `center`,
        marginBottom: 14
      },
      children: [(0, F.jsx)(`div`, {
        style: {
          fontSize: 14,
          fontWeight: 700
        },
        children: `Service Requests`
      }), (0, F.jsx)(`button`, {
        onClick: () => i(!0),
        style: {
          padding: `7px 14px`,
          background: V,
          color: `#fff`,
          border: `none`,
          borderRadius: 6,
          cursor: `pointer`,
          fontWeight: 700,
          fontSize: 13,
          fontFamily: `inherit`
        },
        children: `⊕ New Request`
      })]
    }), d.length === 0 ? (0, F.jsx)(`div`, {
      style: {
        textAlign: `center`,
        padding: `30px 0`,
        color: `#9ca3af`,
        fontSize: 14
      },
      children: `No service requests yet`
    }) : (0, F.jsxs)(`table`, {
      style: {
        width: `100%`,
        fontSize: 13,
        borderCollapse: `collapse`
      },
      children: [(0, F.jsx)(`thead`, {
        children: (0, F.jsx)(`tr`, {
          style: {
            background: `#f9fafb`
          },
          children: [`Ticket ID`, `Category`, `Status`, `Created`].map(e => (0, F.jsx)(`th`, {
            style: {
              padding: `10px 12px`,
              textAlign: `left`,
              fontSize: 11,
              fontWeight: 700,
              color: `#6b7280`,
              textTransform: `uppercase`,
              letterSpacing: `.04em`,
              borderBottom: `1px solid #e5e7eb`
            },
            children: e
          }, e))
        })
      }), (0, F.jsx)(`tbody`, {
        children: d.map(e => (0, F.jsxs)(`tr`, {
          style: {
            borderBottom: `1px solid #f3f4f6`
          },
          children: [(0, F.jsxs)(`td`, {
            style: {
              padding: `10px 12px`,
              fontWeight: 700
            },
            children: [`#T-`, String(e.id).padStart(4, `0`)]
          }), (0, F.jsx)(`td`, {
            style: {
              padding: `10px 12px`
            },
            children: e.category
          }), (0, F.jsx)(`td`, {
            style: {
              padding: `10px 12px`
            },
            children: e.status
          }), (0, F.jsx)(`td`, {
            style: {
              padding: `10px 12px`,
              color: `#6b7280`
            },
            children: eo(e.created_at)
          })]
        }, e.id))
      })]
    }), r && (0, F.jsx)(`div`, {
      style: {
        position: `fixed`,
        inset: 0,
        background: `rgba(0,0,0,.5)`,
        zIndex: 1e3,
        display: `flex`,
        alignItems: `center`,
        justifyContent: `center`
      },
      children: (0, F.jsxs)(`div`, {
        style: {
          background: `#fff`,
          borderRadius: 10,
          padding: 24,
          width: 400,
          boxShadow: `0 20px 40px rgba(0,0,0,.15)`
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            fontSize: 16,
            fontWeight: 700,
            marginBottom: 16
          },
          children: `New Service Request`
        }), (0, F.jsxs)(`select`, {
          value: a,
          onChange: e => o(e.target.value),
          style: {
            width: `100%`,
            padding: `9px 12px`,
            fontSize: 13,
            border: `1px solid #d1d5db`,
            borderRadius: 6,
            fontFamily: `inherit`,
            outline: `none`,
            marginBottom: 12,
            boxSizing: `border-box`
          },
          children: [(0, F.jsx)(`option`, {
            value: ``,
            children: `-- Select Category --`
          }), [`Refund`, `Shipping`, `Order Status`, `Payment Issue`, `Other`].map(e => (0, F.jsx)(`option`, {
            value: e,
            children: e
          }, e))]
        }), (0, F.jsx)(`textarea`, {
          value: s,
          onChange: e => c(e.target.value),
          rows: 4,
          placeholder: `Notes…`,
          style: {
            width: `100%`,
            padding: `9px 12px`,
            fontSize: 13,
            border: `1px solid #d1d5db`,
            borderRadius: 6,
            fontFamily: `inherit`,
            resize: `vertical`,
            outline: `none`,
            marginBottom: 12,
            boxSizing: `border-box`
          }
        }), (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            gap: 8,
            justifyContent: `flex-end`
          },
          children: [(0, F.jsx)(`button`, {
            onClick: () => i(!1),
            style: {
              padding: `8px 18px`,
              background: `#f3f4f6`,
              color: `#374151`,
              border: `none`,
              borderRadius: 6,
              cursor: `pointer`,
              fontWeight: 600
            },
            children: `Cancel`
          }), (0, F.jsx)(`button`, {
            onClick: f,
            disabled: l,
            style: {
              padding: `8px 18px`,
              background: V,
              color: `#fff`,
              border: `none`,
              borderRadius: 6,
              cursor: `pointer`,
              fontWeight: 700
            },
            children: `Submit`
          })]
        })]
      })
    })]
  })
}

function U() {
  let {
    id: e
  } = mt(), t = ut(), n = R(), [r, i] = (0, _.useState)(null), [a, o] = (0, _.useState)(!0), [s, c] = (0, _.useState)(`docs`), [l, u] = (0, _.useState)(!1), d = (0, _.useCallback)(async () => {
    try {
      let t = await cr.get(e);
      i(t.booking || t)
    } catch (e) {
      n(e?.message || `Could not load request`, `error`), t(`/requests`)
    } finally {
      o(!1)
    }
  }, [e, t]);
  (0, _.useEffect)(() => {
    d()
  }, [d]);
  async function f(r) {
    try {
      await cr.del(e, r), n(r ? `Permanently deleted` : `Cancelled`, r ? `info` : `success`), u(!1), t(`/requests`)
    } catch (e) {
      n(e.message, `error`)
    }
  }
  if (a) return (0, F.jsx)(`div`, {
    style: {
      display: `flex`,
      justifyContent: `center`,
      padding: 60
    },
    children: (0, F.jsx)(Wi, {
      size: 32
    })
  });
  if (!r) return null;
  let p = [{
      key: `docs`,
      label: `Documents & Order History`
    }, {
      key: `form`,
      label: `Form Details & Export`
    }, {
      key: `tickets`,
      label: `Service Request`
    }, {
      key: `comms`,
      label: `📶 Communication`
    }],
    m = e => ({
      padding: `12px 18px`,
      fontSize: 13,
      fontWeight: 600,
      background: `none`,
      border: `none`,
      borderBottom: `3px solid ${s===e?V:`transparent`}`,
      cursor: `pointer`,
      fontFamily: `inherit`,
      color: s === e ? V : `#6b7280`,
      transition: `color .2s`
    });
  return (0, F.jsxs)(`div`, {
    style: {
      maxWidth: 1100,
      margin: `0 auto`
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        marginBottom: 14
      },
      children: [(0, F.jsxs)(`button`, {
        onClick: () => t(`/requests`),
        style: {
          display: `flex`,
          alignItems: `center`,
          gap: 6,
          background: `none`,
          border: `none`,
          cursor: `pointer`,
          fontSize: 14,
          color: `var(--muted)`,
          fontFamily: `inherit`,
          padding: 0
        },
        children: [(0, F.jsx)(zr, {
          size: 15
        }), ` All Requests`]
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          gap: 10
        },
        children: [(0, F.jsxs)(`div`, {
          style: {
            fontSize: 18,
            fontWeight: 800,
            color: V
          },
          children: [`Order #`, r.booking_ref]
        }), (0, F.jsx)(Ji, {
          status: r.status,
          size: `sm`
        }), (0, F.jsx)(`button`, {
          onClick: () => u(!0),
          style: {
            padding: `6px 14px`,
            background: `#dc2626`,
            color: `#fff`,
            border: `none`,
            borderRadius: 6,
            cursor: `pointer`,
            fontWeight: 700,
            fontSize: 13,
            fontFamily: `inherit`
          },
          children: `🗑 Delete`
        })]
      })]
    }), (0, F.jsx)(io, {
      b: r
    }), (0, F.jsx)(ao, {
      b: r
    }), (0, F.jsx)(oo, {
      status: r.status
    }), (0, F.jsxs)(`div`, {
      style: {
        background: `#fff`,
        border: `1px solid #e5e7eb`,
        borderRadius: 8,
        marginBottom: 12,
        overflow: `hidden`
      },
      children: [(0, F.jsx)(`div`, {
        style: {
          display: `flex`,
          borderBottom: `1px solid #e5e7eb`,
          background: `#fff`
        },
        children: p.map(e => (0, F.jsx)(`button`, {
          onClick: () => c(e.key),
          style: m(e.key),
          children: e.label
        }, e.key))
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `grid`,
          gridTemplateColumns: s === `comms` ? `1fr` : `1fr 1fr`,
          minHeight: 420
        },
        children: [(0, F.jsxs)(`div`, {
          style: {
            borderRight: s === `comms` ? `none` : `1px solid #e5e7eb`
          },
          children: [s === `docs` && (0, F.jsx)(lo, {
            booking: r,
            bookingId: e,
            onRefresh: d
          }), s === `form` && (0, F.jsx)(uo, {
            booking: r
          }), s === `tickets` && (0, F.jsx)(H, {
            booking: r,
            bookingId: e
          }), s === `comms` && (0, F.jsx)(co, {
            bookingId: e,
            booking: r
          })]
        }), s !== `comms` && (0, F.jsx)(`div`, {
          children: (0, F.jsx)(co, {
            bookingId: e,
            booking: r
          })
        })]
      })]
    }), (0, F.jsx)(so, {
      booking: r,
      onRefresh: d
    }), (0, F.jsx)($i, {
      open: l,
      onClose: () => u(!1),
      title: `Delete ${r.booking_ref}?`,
      footer: (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(z, {
          variant: `secondary`,
          onClick: () => u(!1),
          children: `Cancel`
        }), (0, F.jsx)(z, {
          variant: `danger`,
          onClick: () => f(!1),
          icon: (0, F.jsx)(xi, {
            size: 14
          }),
          children: `Cancel (soft)`
        }), (0, F.jsx)(z, {
          variant: `danger`,
          onClick: () => f(!0),
          icon: (0, F.jsx)(Mi, {
            size: 14
          }),
          children: `Delete forever`
        })]
      }),
      children: (0, F.jsxs)(`p`, {
        style: {
          fontSize: 14,
          color: `var(--muted)`,
          lineHeight: 1.6
        },
        children: [(0, F.jsx)(`strong`, {
          children: `Cancel (soft)`
        }), ` marks as cancelled, keeps all records.`, (0, F.jsx)(`br`, {}), (0, F.jsx)(`br`, {}), (0, F.jsx)(`strong`, {
          children: `Delete forever`
        }), ` permanently removes all data. Cannot be undone.`]
      })
    })]
  })
}
var fo = `var(--brand)`,
  po = 20;

function mo(e) {
  return e ? new Date(e).toLocaleDateString(`en-IN`, {
    day: `numeric`,
    month: `short`,
    year: `numeric`
  }) : `—`
}

function ho() {
  let e = ut(),
    t = R(),
    [n, r] = (0, _.useState)({
      rows: [],
      total: 0
    }),
    [i, a] = (0, _.useState)(!0),
    [o, s] = (0, _.useState)(``),
    [c, l] = (0, _.useState)(1),
    [u, d] = (0, _.useState)(null),
    [f, p] = (0, _.useState)(!1),
    [m, h] = (0, _.useState)(null),
    g = (0, _.useRef)(null),
    [v, y] = (0, _.useState)(``),
    b = (0, _.useCallback)(async () => {
      a(!0), y(``);
      try {
        let e = await ur.list({
          page: c,
          per_page: po,
          search: o
        });
        r({
          rows: e.customers || e.rows || [],
          total: e.total || 0
        })
      } catch (e) {
        y(e.message || `Failed to load customers`)
      } finally {
        a(!1)
      }
    }, [c, o]);
  (0, _.useEffect)(() => {
    b()
  }, [b]);
  async function x(e, n) {
    h(e.id);
    try {
      let r = await ur.dataExport(e.id, n),
        i = new Blob([JSON.stringify(r, null, 2)], {
          type: `application/json`
        }),
        a = URL.createObjectURL(i),
        o = document.createElement(`a`);
      o.href = a, o.download = `customer-${e.id}-data.json`, o.click(), URL.revokeObjectURL(a), t(`Data exported`, `success`)
    } catch (e) {
      t(e.message, `error`)
    } finally {
      h(null)
    }
  }
  async function S() {
    p(!0);
    try {
      await ur.erase(u.id, {
        confirm: !0
      }), t(`Customer data erased`, `success`), d(null), b()
    } catch (e) {
      t(e.message, `error`)
    } finally {
      p(!1)
    }
  }
  let C = Math.max(1, Math.ceil(n.total / po));
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      gap: 20
    },
    children: [(0, F.jsxs)(`div`, {
      children: [(0, F.jsx)(`h1`, {
        style: {
          fontSize: 22,
          fontWeight: 800
        },
        children: `Customers`
      }), (0, F.jsx)(`p`, {
        style: {
          fontSize: 14,
          color: `var(--muted)`,
          marginTop: 3
        },
        children: i ? `…` : `${n.total.toLocaleString()} customers`
      })]
    }), (0, F.jsxs)(`div`, {
      style: {
        position: `relative`,
        maxWidth: 400
      },
      children: [(0, F.jsx)(Ci, {
        size: 15,
        style: {
          position: `absolute`,
          left: 11,
          top: `50%`,
          transform: `translateY(-50%)`,
          color: `var(--muted)`,
          pointerEvents: `none`
        }
      }), (0, F.jsx)(`input`, {
        defaultValue: o,
        onChange: e => {
          clearTimeout(g.current), g.current = setTimeout(() => {
            s(e.target.value), l(1)
          }, 350)
        },
        placeholder: `Search by name, email or phone…`,
        style: {
          width: `100%`,
          padding: `9px 13px 9px 34px`,
          fontSize: 14,
          border: `1px solid var(--border)`,
          borderRadius: `var(--r)`,
          fontFamily: `inherit`,
          outline: `none`,
          background: `#fff`,
          boxSizing: `border-box`
        }
      })]
    }), (0, F.jsx)(aa, {
      columns: [{
        key: `name`,
        label: `Name`,
        render: (e, t) => (0, F.jsx)(`span`, {
          style: {
            fontWeight: 700
          },
          children: e || t.display_name
        })
      }, {
        key: `email`,
        label: `Email`,
        render: e => (0, F.jsx)(`span`, {
          style: {
            fontSize: 13,
            color: `var(--muted)`
          },
          children: e
        })
      }, {
        key: `phone`,
        label: `Phone`
      }, {
        key: `bookings_count`,
        label: `Requests`,
        render: e => (0, F.jsx)(`span`, {
          style: {
            fontWeight: 700,
            color: fo
          },
          children: e ?? 0
        })
      }, {
        key: `total_paid`,
        label: `Total Paid`,
        render: e => e ? `₹${Number(e).toLocaleString(`en-IN`)}` : `₹0`
      }, {
        key: `registered_at`,
        label: `Joined`,
        render: e => mo(e),
        noWrap: !0
      }, {
        key: `_actions`,
        label: ``,
        render: (e, t) => (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            gap: 6
          },
          onClick: e => e.stopPropagation(),
          children: [(0, F.jsx)(z, {
            variant: `secondary`,
            size: `sm`,
            icon: (0, F.jsx)(oi, {
              size: 12
            }),
            loading: m === t.id,
            onClick: () => x(t, `json`),
            children: `Export`
          }), (0, F.jsx)(z, {
            variant: `danger`,
            size: `sm`,
            icon: (0, F.jsx)(Mi, {
              size: 12
            }),
            onClick: () => d(t),
            children: `Erase`
          })]
        })
      }],
      data: n.rows,
      loading: i,
      onRow: t => e(`/requests?customer=${t.id}`),
      empty: (0, F.jsx)(Qi, {
        icon: `👥`,
        title: `No customers found`,
        desc: o ? `Try a different search.` : `Customers will appear here once they submit requests.`
      })
    }), C > 1 && (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        fontSize: 13,
        color: `var(--muted)`
      },
      children: [(0, F.jsxs)(`span`, {
        children: [`Page `, c, ` of `, C]
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          gap: 8
        },
        children: [(0, F.jsx)(z, {
          variant: `secondary`,
          size: `sm`,
          disabled: c === 1,
          onClick: () => l(e => e - 1),
          children: `← Prev`
        }), (0, F.jsx)(z, {
          variant: `secondary`,
          size: `sm`,
          disabled: c === C,
          onClick: () => l(e => e + 1),
          children: `Next →`
        })]
      })]
    }), (0, F.jsxs)($i, {
      open: !!u,
      onClose: () => d(null),
      title: `Erase data for ${u?.name||u?.email}?`,
      footer: (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(z, {
          variant: `secondary`,
          onClick: () => d(null),
          children: `Cancel`
        }), (0, F.jsx)(z, {
          variant: `danger`,
          loading: f,
          onClick: S,
          icon: (0, F.jsx)(Mi, {
            size: 14
          }),
          children: `Permanently erase`
        })]
      }),
      children: [(0, F.jsx)(`div`, {
        style: {
          background: `var(--red-bg)`,
          border: `1px solid var(--red-border)`,
          borderRadius: `var(--r)`,
          padding: `12px 14px`,
          marginBottom: 14
        },
        children: (0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--red-dark)`,
            fontWeight: 600,
            margin: 0
          },
          children: `⚠️ This action cannot be undone`
        })
      }), (0, F.jsxs)(`p`, {
        style: {
          fontSize: 14,
          color: `var(--muted)`,
          lineHeight: 1.7
        },
        children: [`This will permanently delete all personal data for `, (0, F.jsx)(`strong`, {
          children: u?.name || u?.email
        }), `, including their profile, contact information, and booking history records. Anonymised statistical records will be retained.`]
      })]
    })]
  })
}
var go = `var(--brand)`,
  _o = [go, `var(--green)`, `var(--amber)`, `var(--purple)`, `var(--red)`, `var(--teal)`, `var(--orange)`, `var(--brand)`];

function vo(e) {
  return e ? (e = Number(e), e >= 1e7 ? `₹${(e/1e6).toFixed(1)}Cr` : e >= 1e5 ? `₹${(e/1e5).toFixed(1)}L` : `₹${e.toLocaleString(`en-IN`)}`) : `₹0`
}

function yo({
  data: e,
  valueKey: t = `value`,
  labelKey: n = `label`,
  colorKey: r,
  height: i = 200,
  formatVal: a
}) {
  if (!e?.length) return (0, F.jsx)(`div`, {
    style: {
      height: i,
      display: `flex`,
      alignItems: `center`,
      justifyContent: `center`,
      color: `var(--muted)`,
      fontSize: 14
    },
    children: `No data`
  });
  let o = Math.max(...e.map(e => e[t] || 0)) || 1,
    s = a || (e => e);
  return (0, F.jsx)(`div`, {
    style: {
      display: `flex`,
      alignItems: `flex-end`,
      gap: 6,
      height: i,
      paddingBottom: 24,
      position: `relative`
    },
    children: e.map((i, a) => {
      let c = (i[t] || 0) / o * 100,
        l = r ? _o[a % _o.length] : go;
      return (0, F.jsxs)(`div`, {
        style: {
          flex: 1,
          display: `flex`,
          flexDirection: `column`,
          alignItems: `center`,
          height: `100%`,
          justifyContent: `flex-end`,
          gap: 4
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            fontSize: 10,
            fontWeight: 700,
            color: `var(--muted)`,
            textAlign: `center`
          },
          children: s(i[t])
        }), (0, F.jsx)(`div`, {
          style: {
            width: `100%`,
            minWidth: 12,
            borderRadius: `4px 4px 0 0`,
            background: l,
            transition: `height 0.4s ease`,
            height: `${Math.max(c,2)}%`,
            opacity: .85
          }
        }), (0, F.jsx)(`div`, {
          style: {
            fontSize: 9,
            color: `var(--muted)`,
            textAlign: `center`,
            position: `absolute`,
            bottom: 2,
            width: `calc(100% / ${e.length})`,
            overflow: `hidden`,
            whiteSpace: `nowrap`,
            textOverflow: `ellipsis`
          },
          children: i[n]
        })]
      }, a)
    })
  })
}

function bo({
  data: e,
  valueKey: t = `revenue`,
  labelKey: n = `month`,
  height: r = 180
}) {
  if (!e?.length) return (0, F.jsx)(`div`, {
    style: {
      height: r,
      display: `flex`,
      alignItems: `center`,
      justifyContent: `center`,
      color: `var(--muted)`,
      fontSize: 14
    },
    children: `No data`
  });
  let i = e.map(e => e[t] || 0),
    a = Math.max(...i) || 1,
    o = Math.min(...i),
    s = r,
    c = e.map((n, r) => `${10+r/(e.length-1||1)*580},${s-10-(n[t]-o)/(a-o||1)*(s-20)}`).join(` `),
    l = `M10,${s} ` + e.map((n, r) => `L${10+r/(e.length-1||1)*580},${s-10-(n[t]-o)/(a-o||1)*(s-20)}`).join(` `) + ` L590,${s} Z`;
  return (0, F.jsx)(`div`, {
    style: {
      width: `100%`,
      overflowX: `auto`
    },
    children: (0, F.jsxs)(`svg`, {
      viewBox: `0 0 600 ${s+20}`,
      style: {
        width: `100%`,
        minWidth: 300
      },
      children: [(0, F.jsx)(`defs`, {
        children: (0, F.jsxs)(`linearGradient`, {
          id: `areaGrad`,
          x1: `0`,
          y1: `0`,
          x2: `0`,
          y2: `1`,
          children: [(0, F.jsx)(`stop`, {
            offset: `0%`,
            stopColor: go,
            stopOpacity: `0.25`
          }), (0, F.jsx)(`stop`, {
            offset: `100%`,
            stopColor: go,
            stopOpacity: `0.02`
          })]
        })
      }), (0, F.jsx)(`path`, {
        d: l,
        fill: `url(#areaGrad)`
      }), (0, F.jsx)(`polyline`, {
        points: c,
        fill: `none`,
        stroke: go,
        strokeWidth: `2.5`,
        strokeLinejoin: `round`,
        strokeLinecap: `round`
      }), e.map((n, r) => (0, F.jsx)(`circle`, {
        cx: 10 + r / (e.length - 1 || 1) * 580,
        cy: s - 10 - (n[t] - o) / (a - o || 1) * (s - 20),
        r: `4`,
        fill: go,
        stroke: `#fff`,
        strokeWidth: `2`
      }, r)), e.map((t, r) => (0, F.jsx)(`text`, {
        x: 10 + r / (e.length - 1 || 1) * 580,
        y: s + 16,
        fontSize: `10`,
        fill: `var(--muted-2)`,
        textAnchor: `middle`,
        children: t[n]
      }, r))]
    })
  })
}

function xo({
  stages: e
}) {
  if (!e?.length) return (0, F.jsx)(`div`, {
    style: {
      color: `var(--muted)`,
      fontSize: 14,
      textAlign: `center`,
      padding: 20
    },
    children: `No data`
  });
  let t = e[0]?.count || 1;
  return (0, F.jsx)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      gap: 6
    },
    children: e.map((n, r) => {
      let i = (n.count || 0) / t * 100,
        a = r > 0 ? (n.count / (e[r - 1]?.count || 1) * 100).toFixed(1) : null;
      return (0, F.jsxs)(`div`, {
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            justifyContent: `space-between`,
            fontSize: 12,
            marginBottom: 4,
            fontWeight: 600
          },
          children: [(0, F.jsx)(`span`, {
            style: {
              color: `var(--text-2)`
            },
            children: n.stage || n.label
          }), (0, F.jsxs)(`span`, {
            style: {
              color: go
            },
            children: [(n.count || 0).toLocaleString(), ` `, a && (0, F.jsxs)(`span`, {
              style: {
                color: `var(--muted)`,
                fontWeight: 400
              },
              children: [`(`, a, `%)`]
            })]
          })]
        }), (0, F.jsx)(`div`, {
          style: {
            height: 28,
            borderRadius: 6,
            background: `var(--border)`,
            overflow: `hidden`
          },
          children: (0, F.jsx)(`div`, {
            style: {
              height: `100%`,
              width: `${Math.max(i,2)}%`,
              background: _o[r % _o.length],
              borderRadius: 6,
              transition: `width 0.5s ease`,
              opacity: .85
            }
          })
        })]
      }, r)
    })
  })
}

function So() {
  let [e, t] = (0, _.useState)(90), [n, r] = (0, _.useState)(12), [i, a] = (0, _.useState)({}), [o, s] = (0, _.useState)(!0), c = (0, _.useCallback)(async () => {
    s(!0);
    try {
      let [t, r, i, o, s] = await Promise.all([fr.services(e), fr.staff(e), fr.funnel(e), fr.revenueTrend(n), fr.customers(e)]);
      a({
        svc: t,
        staff: r,
        funnel: i,
        revenue: o,
        customers: s
      })
    } catch {} finally {
      s(!1)
    }
  }, [e, n]);
  (0, _.useEffect)(() => {
    c()
  }, [c]);
  let l = i.svc?.services || [],
    u = i.staff?.staff || [],
    d = i.funnel?.stages || [],
    f = i.revenue?.months || i.revenue?.trend || [],
    p = i.customers;
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      gap: 24
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        flexWrap: `wrap`,
        gap: 12
      },
      children: [(0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(`h1`, {
          style: {
            fontSize: 22,
            fontWeight: 800
          },
          children: `Analytics`
        }), (0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`,
            marginTop: 3
          },
          children: `Business performance overview`
        })]
      }), (0, F.jsx)(`div`, {
        style: {
          display: `flex`,
          gap: 10
        },
        children: (0, F.jsx)(Zi, {
          value: e,
          onChange: e => t(Number(e.target.value)),
          options: [{
            value: 30,
            label: `Last 30 days`
          }, {
            value: 60,
            label: `Last 60 days`
          }, {
            value: 90,
            label: `Last 90 days`
          }, {
            value: 180,
            label: `Last 6 months`
          }, {
            value: 365,
            label: `Last 12 months`
          }],
          style: {
            minWidth: 160
          }
        })
      })]
    }), o ? (0, F.jsx)(`div`, {
      style: {
        display: `grid`,
        gridTemplateColumns: `repeat(auto-fill, minmax(160px, 1fr))`,
        gap: 14
      },
      children: [1, 2, 3, 4].map(e => (0, F.jsx)(na, {
        h: 90
      }, e))
    }) : (0, F.jsxs)(`div`, {
      style: {
        display: `grid`,
        gridTemplateColumns: `repeat(auto-fill, minmax(160px, 1fr))`,
        gap: 14
      },
      children: [(0, F.jsx)(ta, {
        label: `New customers`,
        value: p?.new_customers ?? `—`,
        color: go
      }), (0, F.jsx)(ta, {
        label: `Returning`,
        value: p?.returning_customers ?? `—`,
        color: `var(--teal)`
      }), (0, F.jsx)(ta, {
        label: `Avg requests`,
        value: p?.avg_requests_per_customer == null ? `—` : p.avg_requests_per_customer.toFixed(1),
        color: `var(--purple)`
      }), (0, F.jsx)(ta, {
        label: `Avg order value`,
        value: p?.avg_order_value ? vo(p.avg_order_value) : `—`,
        color: `var(--green)`
      })]
    }), (0, F.jsxs)(B, {
      children: [(0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          justifyContent: `space-between`,
          marginBottom: 20,
          flexWrap: `wrap`,
          gap: 10
        },
        children: [(0, F.jsx)(`h2`, {
          style: {
            fontSize: 16
          },
          children: `Revenue Trend`
        }), (0, F.jsx)(Zi, {
          value: n,
          onChange: e => r(Number(e.target.value)),
          options: [{
            value: 6,
            label: `6 months`
          }, {
            value: 12,
            label: `12 months`
          }, {
            value: 24,
            label: `24 months`
          }],
          style: {
            minWidth: 130
          }
        })]
      }), o ? (0, F.jsx)(na, {
        h: 180
      }) : (0, F.jsx)(bo, {
        data: f,
        valueKey: `revenue`,
        labelKey: `month`,
        height: 180
      })]
    }), (0, F.jsxs)(`div`, {
      style: {
        display: `grid`,
        gridTemplateColumns: `repeat(auto-fill, minmax(340px, 1fr))`,
        gap: 20
      },
      children: [(0, F.jsxs)(B, {
        children: [(0, F.jsx)(`h2`, {
          style: {
            fontSize: 16,
            marginBottom: 20
          },
          children: `Requests by Service`
        }), o ? (0, F.jsx)(na, {
          h: 200
        }) : (0, F.jsx)(yo, {
          data: l.map(e => ({
            label: e.service_name,
            value: e.total_bookings
          })),
          labelKey: `label`,
          valueKey: `value`,
          colorKey: !0,
          height: 200
        })]
      }), (0, F.jsxs)(B, {
        children: [(0, F.jsx)(`h2`, {
          style: {
            fontSize: 16,
            marginBottom: 20
          },
          children: `Revenue by Service`
        }), o ? (0, F.jsx)(na, {
          h: 200
        }) : (0, F.jsx)(yo, {
          data: l.map(e => ({
            label: e.service_name,
            value: e.total_revenue || 0
          })),
          labelKey: `label`,
          valueKey: `value`,
          colorKey: !0,
          height: 200,
          formatVal: vo
        })]
      })]
    }), (0, F.jsxs)(B, {
      children: [(0, F.jsx)(`h2`, {
        style: {
          fontSize: 16,
          marginBottom: 20
        },
        children: `Conversion Funnel`
      }), o ? (0, F.jsx)(na, {
        h: 220
      }) : (0, F.jsx)(xo, {
        stages: d
      })]
    }), (0, F.jsxs)(B, {
      children: [(0, F.jsx)(`h2`, {
        style: {
          fontSize: 16,
          marginBottom: 20
        },
        children: `Staff Performance`
      }), o ? (0, F.jsx)(`div`, {
        style: {
          display: `flex`,
          flexDirection: `column`,
          gap: 8
        },
        children: [1, 2, 3].map(e => (0, F.jsx)(na, {
          h: 44
        }, e))
      }) : u.length === 0 ? (0, F.jsx)(`p`, {
        style: {
          color: `var(--muted)`,
          fontSize: 14,
          textAlign: `center`,
          padding: 20
        },
        children: `No staff data`
      }) : (0, F.jsx)(`div`, {
        style: {
          overflowX: `auto`
        },
        children: (0, F.jsxs)(`table`, {
          style: {
            width: `100%`,
            borderCollapse: `collapse`,
            fontSize: 14
          },
          children: [(0, F.jsx)(`thead`, {
            children: (0, F.jsx)(`tr`, {
              children: [`Staff member`, `Assigned`, `Completed`, `Avg response`, `Revenue managed`].map(e => (0, F.jsx)(`th`, {
                style: {
                  padding: `10px 14px`,
                  textAlign: `left`,
                  fontSize: 12,
                  fontWeight: 700,
                  color: `var(--muted)`,
                  textTransform: `uppercase`,
                  letterSpacing: `.04em`,
                  background: `var(--surface-2)`,
                  borderBottom: `1px solid var(--border)`,
                  whiteSpace: `nowrap`
                },
                children: e
              }, e))
            })
          }), (0, F.jsx)(`tbody`, {
            children: u.map((e, t) => (0, F.jsxs)(`tr`, {
              children: [(0, F.jsx)(`td`, {
                style: {
                  padding: `12px 14px`,
                  fontWeight: 700,
                  borderBottom: `1px solid #f1f5f9`
                },
                children: e.staff_name || e.name
              }), (0, F.jsx)(`td`, {
                style: {
                  padding: `12px 14px`,
                  borderBottom: `1px solid #f1f5f9`,
                  color: go,
                  fontWeight: 700
                },
                children: e.assigned_count ?? e.total_bookings ?? 0
              }), (0, F.jsx)(`td`, {
                style: {
                  padding: `12px 14px`,
                  borderBottom: `1px solid #f1f5f9`,
                  color: `var(--green)`,
                  fontWeight: 700
                },
                children: e.completed_count ?? 0
              }), (0, F.jsx)(`td`, {
                style: {
                  padding: `12px 14px`,
                  borderBottom: `1px solid #f1f5f9`,
                  color: `var(--muted)`
                },
                children: e.avg_response_hours ? `${e.avg_response_hours}h` : `—`
              }), (0, F.jsx)(`td`, {
                style: {
                  padding: `12px 14px`,
                  borderBottom: `1px solid #f1f5f9`,
                  fontWeight: 700
                },
                children: e.revenue_managed ? vo(e.revenue_managed) : `—`
              })]
            }, t))
          })]
        })
      })]
    }), !o && l.length > 0 && (0, F.jsxs)(B, {
      children: [(0, F.jsx)(`h2`, {
        style: {
          fontSize: 16,
          marginBottom: 20
        },
        children: `Service Breakdown`
      }), (0, F.jsx)(`div`, {
        style: {
          overflowX: `auto`
        },
        children: (0, F.jsxs)(`table`, {
          style: {
            width: `100%`,
            borderCollapse: `collapse`,
            fontSize: 14
          },
          children: [(0, F.jsx)(`thead`, {
            children: (0, F.jsx)(`tr`, {
              children: [`Service`, `Requests`, `Completed`, `Conversion`, `Revenue`, `Avg value`].map(e => (0, F.jsx)(`th`, {
                style: {
                  padding: `10px 14px`,
                  textAlign: `left`,
                  fontSize: 12,
                  fontWeight: 700,
                  color: `var(--muted)`,
                  textTransform: `uppercase`,
                  letterSpacing: `.04em`,
                  background: `var(--surface-2)`,
                  borderBottom: `1px solid var(--border)`,
                  whiteSpace: `nowrap`
                },
                children: e
              }, e))
            })
          }), (0, F.jsx)(`tbody`, {
            children: l.map((e, t) => {
              let n = e.total_bookings > 0 ? ((e.completed_count || 0) / e.total_bookings * 100).toFixed(0) : 0;
              return (0, F.jsxs)(`tr`, {
                children: [(0, F.jsx)(`td`, {
                  style: {
                    padding: `12px 14px`,
                    fontWeight: 700,
                    borderBottom: `1px solid #f1f5f9`
                  },
                  children: e.service_name
                }), (0, F.jsx)(`td`, {
                  style: {
                    padding: `12px 14px`,
                    borderBottom: `1px solid #f1f5f9`,
                    color: go,
                    fontWeight: 700
                  },
                  children: e.total_bookings
                }), (0, F.jsx)(`td`, {
                  style: {
                    padding: `12px 14px`,
                    borderBottom: `1px solid #f1f5f9`
                  },
                  children: e.completed_count ?? 0
                }), (0, F.jsx)(`td`, {
                  style: {
                    padding: `12px 14px`,
                    borderBottom: `1px solid #f1f5f9`
                  },
                  children: (0, F.jsxs)(`div`, {
                    style: {
                      display: `flex`,
                      alignItems: `center`,
                      gap: 8
                    },
                    children: [(0, F.jsx)(`div`, {
                      style: {
                        flex: 1,
                        height: 6,
                        background: `var(--border)`,
                        borderRadius: 3,
                        overflow: `hidden`,
                        minWidth: 50
                      },
                      children: (0, F.jsx)(`div`, {
                        style: {
                          height: `100%`,
                          width: `${n}%`,
                          background: `var(--green)`
                        }
                      })
                    }), (0, F.jsxs)(`span`, {
                      style: {
                        fontSize: 12,
                        color: `var(--muted)`,
                        flexShrink: 0
                      },
                      children: [n, `%`]
                    })]
                  })
                }), (0, F.jsx)(`td`, {
                  style: {
                    padding: `12px 14px`,
                    borderBottom: `1px solid #f1f5f9`,
                    fontWeight: 700
                  },
                  children: vo(e.total_revenue)
                }), (0, F.jsx)(`td`, {
                  style: {
                    padding: `12px 14px`,
                    borderBottom: `1px solid #f1f5f9`,
                    color: `var(--muted)`
                  },
                  children: vo(e.avg_value)
                })]
              }, t)
            })
          })]
        })
      })]
    })]
  })
}
var W = `var(--brand)`,
  Co = [{
    value: `text`,
    label: `Text input`
  }, {
    value: `textarea`,
    label: `Long text`
  }, {
    value: `email`,
    label: `Email`
  }, {
    value: `number`,
    label: `Number`
  }, {
    value: `phone`,
    label: `Phone`
  }, {
    value: `date`,
    label: `Date`
  }, {
    value: `dropdown`,
    label: `Dropdown / Select`
  }, {
    value: `radio`,
    label: `Radio buttons`
  }, {
    value: `checkbox`,
    label: `Checkboxes (multi-select)`
  }, {
    value: `searchable`,
    label: `Searchable dropdown`
  }, {
    value: `file`,
    label: `File upload`
  }],
  wo = [{
    value: 1,
    label: `Step 1 — Service Details`
  }, {
    value: 2,
    label: `Step 2 — Record / Academic Info`
  }, {
    value: 3,
    label: `Step 3 — Your Details / Requirements`
  }, {
    value: 4,
    label: `Step 4 — Documents & Delivery`
  }, {
    value: 98,
    label: `Step 98 — Contact Details (phone/email/country)`
  }, {
    value: 99,
    label: `Step 99 — File Uploads`
  }];

function To({
  field: e,
  onEdit: t,
  onDelete: n,
  onDuplicate: r,
  onMoveUp: i,
  onMoveDown: a,
  isFirst: o,
  isLast: s
}) {
  let c = wo.find(t => t.value === Number(e.wizard_step || e.step))?.label?.split(`—`)[0].trim() || `Step ${e.wizard_step||e.step||1}`,
    l = e.conditions && Object.keys(e.conditions).length > 0;
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      alignItems: `center`,
      gap: 10,
      padding: `10px 14px`,
      background: `#fff`,
      border: `1px solid var(--border)`,
      borderRadius: `var(--r)`,
      marginBottom: 6
    },
    children: [(0, F.jsx)(si, {
      size: 14,
      style: {
        color: `var(--muted)`,
        flexShrink: 0,
        cursor: `grab`
      }
    }), (0, F.jsxs)(`div`, {
      style: {
        flex: 1,
        minWidth: 0
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          fontWeight: 700,
          fontSize: 14,
          color: `var(--text)`,
          display: `flex`,
          alignItems: `center`,
          gap: 6
        },
        children: [e.label, e.is_required && (0, F.jsx)(`span`, {
          style: {
            color: `var(--red)`,
            marginLeft: 2
          },
          children: `*`
        }), l && (0, F.jsx)(`span`, {
          style: {
            fontSize: 10,
            padding: `1px 6px`,
            borderRadius: `var(--r-full)`,
            background: `var(--purple-bg)`,
            color: `var(--purple)`,
            fontWeight: 700
          },
          children: `CONDITIONAL`
        })]
      }), (0, F.jsxs)(`div`, {
        style: {
          fontSize: 12,
          color: `var(--muted)`
        },
        children: [e.field_type, ` · key: `, (0, F.jsx)(`code`, {
          style: {
            background: `var(--surface-2)`,
            padding: `0 4px`,
            borderRadius: 3
          },
          children: e.field_key
        }), ` · `, c]
      })]
    }), (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        gap: 4,
        flexShrink: 0
      },
      children: [(0, F.jsx)(`button`, {
        disabled: o,
        onClick: i,
        style: {
          background: `none`,
          border: `none`,
          cursor: o ? `not-allowed` : `pointer`,
          color: o ? `var(--border)` : `var(--muted)`,
          padding: 4
        },
        children: (0, F.jsx)(Xr, {
          size: 14
        })
      }), (0, F.jsx)(`button`, {
        disabled: s,
        onClick: a,
        style: {
          background: `none`,
          border: `none`,
          cursor: s ? `not-allowed` : `pointer`,
          color: s ? `var(--border)` : `var(--muted)`,
          padding: 4
        },
        children: (0, F.jsx)(qr, {
          size: 14
        })
      }), (0, F.jsx)(`button`, {
        onClick: r,
        title: `Duplicate`,
        style: {
          background: `none`,
          border: `none`,
          cursor: `pointer`,
          color: `var(--muted)`,
          padding: 4,
          fontSize: 13
        },
        children: `⧉`
      }), (0, F.jsx)(`button`, {
        onClick: t,
        style: {
          background: `none`,
          border: `none`,
          cursor: `pointer`,
          color: W,
          padding: 4
        },
        children: (0, F.jsx)(_i, {
          size: 14
        })
      }), (0, F.jsx)(`button`, {
        onClick: n,
        style: {
          background: `none`,
          border: `none`,
          cursor: `pointer`,
          color: `var(--red)`,
          padding: 4
        },
        children: (0, F.jsx)(Mi, {
          size: 14
        })
      })]
    })]
  })
}

function Eo({
  open: e,
  onClose: t,
  onSave: n,
  initial: r,
  allFieldKeys: i = []
}) {
  let a = {
      label: ``,
      field_key: ``,
      field_type: `text`,
      placeholder: ``,
      help_text: ``,
      is_required: !0,
      wizard_step: 1,
      options: ``,
      conditions: null
    },
    [o, s] = (0, _.useState)(r || a),
    [c, l] = (0, _.useState)(!1),
    [u, d] = (0, _.useState)(``),
    [f, p] = (0, _.useState)(``);
  (0, _.useEffect)(() => {
    let e = r || a;
    s(e);
    let t = e.conditions;
    if (t && t.show_if && Object.keys(t.show_if).length > 0) {
      let [e, n] = Object.entries(t.show_if)[0];
      l(!0), d(e), p(n)
    } else l(!1), d(``), p(``)
  }, [r, e]);
  let m = e => t => s(n => ({
      ...n,
      [e]: t
    })),
    h = [`dropdown`, `radio`, `searchable`, `checkbox`].includes(o.field_type);

  function g() {
    let e = c && u && f ? {
      show_if: {
        [u]: f
      }
    } : null;
    n({
      ...o,
      conditions: e
    })
  }
  return (0, F.jsx)($i, {
    open: e,
    onClose: t,
    title: r ? `Edit: ${r.label}` : `Add new field`,
    maxWidth: 560,
    footer: (0, F.jsxs)(F.Fragment, {
      children: [(0, F.jsx)(z, {
        variant: `secondary`,
        onClick: t,
        children: `Cancel`
      }), (0, F.jsx)(z, {
        onClick: g,
        style: {
          background: W
        },
        children: r ? `Save changes` : `Add field`
      })]
    }),
    children: (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        flexDirection: `column`,
        gap: 14
      },
      children: [(0, F.jsx)(Xi, {
        label: `Field label`,
        value: o.label,
        onChange: e => {
          let t = e.target.value,
            n = t.toLowerCase().replace(/[^a-z0-9]+/g, `_`).replace(/^_|_$/g, ``);
          s(e => ({
            ...e,
            label: t,
            field_key: r ? e.field_key : n
          }))
        },
        required: !0,
        placeholder: `e.g. Passport Number`
      }), (0, F.jsx)(Xi, {
        label: `Field key (unique)`,
        value: o.field_key,
        onChange: e => m(`field_key`)(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, ``)),
        hint: `Auto-generated. Lowercase, numbers, underscores only. Must be unique per service.`,
        required: !0
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `grid`,
          gridTemplateColumns: `1fr 1fr`,
          gap: 12
        },
        children: [(0, F.jsxs)(`div`, {
          children: [(0, F.jsx)(`label`, {
            style: {
              fontSize: 13,
              fontWeight: 600,
              color: `var(--text-2)`,
              display: `block`,
              marginBottom: 5
            },
            children: `Field type`
          }), (0, F.jsx)(`select`, {
            value: o.field_type,
            onChange: e => m(`field_type`)(e.target.value),
            style: {
              width: `100%`,
              padding: `9px 13px`,
              fontSize: 14,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              fontFamily: `inherit`,
              outline: `none`,
              boxSizing: `border-box`
            },
            children: Co.map(e => (0, F.jsx)(`option`, {
              value: e.value,
              children: e.label
            }, e.value))
          })]
        }), (0, F.jsxs)(`div`, {
          children: [(0, F.jsx)(`label`, {
            style: {
              fontSize: 13,
              fontWeight: 600,
              color: `var(--text-2)`,
              display: `block`,
              marginBottom: 5
            },
            children: `Wizard step`
          }), (0, F.jsx)(`select`, {
            value: o.wizard_step,
            onChange: e => m(`wizard_step`)(Number(e.target.value)),
            style: {
              width: `100%`,
              padding: `9px 13px`,
              fontSize: 14,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              fontFamily: `inherit`,
              outline: `none`,
              boxSizing: `border-box`
            },
            children: wo.map(e => (0, F.jsx)(`option`, {
              value: e.value,
              children: e.label
            }, e.value))
          })]
        })]
      }), (0, F.jsx)(Xi, {
        label: `Placeholder text`,
        value: o.placeholder,
        onChange: e => m(`placeholder`)(e.target.value),
        placeholder: `e.g. Enter your passport number`
      }), (0, F.jsx)(Xi, {
        label: `Help text (shown below field)`,
        value: o.help_text,
        onChange: e => m(`help_text`)(e.target.value),
        placeholder: `Additional guidance for the customer`
      }), h && (0, F.jsxs)(`div`, {
        children: [(0, F.jsxs)(`label`, {
          style: {
            fontSize: 13,
            fontWeight: 600,
            color: `var(--text-2)`,
            display: `block`,
            marginBottom: 6
          },
          children: [`Options `, (0, F.jsx)(`span`, {
            style: {
              fontWeight: 400,
              color: `var(--muted)`
            },
            children: `(one per line)`
          })]
        }), (0, F.jsx)(`textarea`, {
          value: typeof o.options == `string` ? o.options : Array.isArray(o.options) ? o.options.join(`
`) : ``,
          onChange: e => m(`options`)(e.target.value),
          rows: 5,
          placeholder: `Option 1
Option 2
Option 3`,
          style: {
            width: `100%`,
            padding: `9px 13px`,
            fontSize: 14,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r)`,
            fontFamily: `inherit`,
            resize: `vertical`,
            outline: `none`,
            boxSizing: `border-box`
          }
        })]
      }), (0, F.jsxs)(`label`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          gap: 10,
          fontSize: 14,
          cursor: `pointer`
        },
        children: [(0, F.jsx)(`input`, {
          type: `checkbox`,
          checked: !!o.is_required,
          onChange: e => m(`is_required`)(e.target.checked),
          style: {
            accentColor: W,
            width: 16,
            height: 16
          }
        }), `Required field`]
      }), (0, F.jsxs)(`div`, {
        style: {
          border: `1px solid var(--border)`,
          borderRadius: `var(--r)`,
          padding: 14,
          background: c ? `var(--purple-bg)` : `var(--surface-2)`
        },
        children: [(0, F.jsxs)(`label`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 10,
            fontSize: 14,
            cursor: `pointer`,
            marginBottom: c ? 12 : 0
          },
          children: [(0, F.jsx)(`input`, {
            type: `checkbox`,
            checked: c,
            onChange: e => l(e.target.checked),
            style: {
              accentColor: `var(--purple)`,
              width: 16,
              height: 16
            }
          }), (0, F.jsx)(`span`, {
            style: {
              fontWeight: 700,
              color: `var(--purple)`
            },
            children: `🔀 Conditional visibility`
          }), (0, F.jsx)(`span`, {
            style: {
              fontSize: 12,
              color: `var(--muted)`,
              fontWeight: 400
            },
            children: `Show only when another field equals a specific value`
          })]
        }), c && (0, F.jsxs)(`div`, {
          style: {
            display: `grid`,
            gridTemplateColumns: `1fr 1fr`,
            gap: 10
          },
          children: [(0, F.jsxs)(`div`, {
            children: [(0, F.jsx)(`label`, {
              style: {
                fontSize: 12,
                fontWeight: 600,
                color: `var(--text-2)`,
                display: `block`,
                marginBottom: 4
              },
              children: `Show when field key:`
            }), (0, F.jsx)(`input`, {
              value: u,
              onChange: e => d(e.target.value),
              placeholder: `e.g. service_type`,
              list: `field-keys-list`,
              style: {
                width: `100%`,
                padding: `8px 12px`,
                fontSize: 13,
                border: `1px solid #c4b5fd`,
                borderRadius: `var(--r)`,
                fontFamily: `inherit`,
                outline: `none`,
                boxSizing: `border-box`
              }
            }), (0, F.jsx)(`datalist`, {
              id: `field-keys-list`,
              children: i.map(e => (0, F.jsx)(`option`, {
                value: e
              }, e))
            })]
          }), (0, F.jsxs)(`div`, {
            children: [(0, F.jsx)(`label`, {
              style: {
                fontSize: 12,
                fontWeight: 600,
                color: `var(--text-2)`,
                display: `block`,
                marginBottom: 4
              },
              children: `equals this value:`
            }), (0, F.jsx)(`input`, {
              value: f,
              onChange: e => p(e.target.value),
              placeholder: `e.g. Apostille`,
              style: {
                width: `100%`,
                padding: `8px 12px`,
                fontSize: 13,
                border: `1px solid #c4b5fd`,
                borderRadius: `var(--r)`,
                fontFamily: `inherit`,
                outline: `none`,
                boxSizing: `border-box`
              }
            })]
          }), (0, F.jsxs)(`div`, {
            style: {
              gridColumn: `1/-1`,
              fontSize: 12,
              color: `var(--purple)`,
              background: `#fff`,
              padding: `8px 10px`,
              borderRadius: `var(--r-sm)`
            },
            children: [`Field shows only when `, (0, F.jsx)(`strong`, {
              children: u || `[field key]`
            }), ` = `, (0, F.jsx)(`strong`, {
              children: f || `[value]`
            })]
          })]
        })]
      })]
    })
  })
}

function Do({
  svcId: e
}) {
  let t = R(),
    [n, r] = (0, _.useState)([]),
    [i, a] = (0, _.useState)(!0),
    [o, s] = (0, _.useState)(!1),
    [c, l] = (0, _.useState)(null),
    u = (0, _.useCallback)(async () => {
      a(!0);
      try {
        let t = await dr.formFields(e);
        r(t.fields || t || [])
      } catch {} finally {
        a(!1)
      }
    }, [e]);
  (0, _.useEffect)(() => {
    u()
  }, [u]);
  async function d(n) {
    try {
      c?.id ? (await dr.updateField(e, c.id, n), t(`Field updated`, `success`)) : (await dr.addField(e, n), t(`Field added`, `success`)), s(!1), l(null), u()
    } catch (e) {
      t(e.message, `error`)
    }
  }
  async function f(n) {
    if (confirm(`Delete field "${n.label}"?`)) try {
      await dr.delField(e, n.id), t(`Field deleted`, `success`), u()
    } catch (e) {
      t(e.message, `error`)
    }
  }
  async function p(i, a) {
    let o = [...n],
      s = i + a;
    if (!(s < 0 || s >= o.length)) {
      [o[i], o[s]] = [o[s], o[i]], r(o);
      try {
        await dr.reorderFields(e, {
          order: o.map(e => e.id)
        })
      } catch (e) {
        t(e.message, `error`), u()
      }
    }
  }
  async function m(n) {
    let r = {
      ...n,
      label: n.label + ` (copy)`,
      field_key: n.field_key + `_copy`
    };
    delete r.id;
    try {
      await dr.addField(e, r), t(`Field duplicated`, `success`), u()
    } catch (e) {
      t(e.message, `error`)
    }
  }
  let h = n.map(e => e.field_key);
  return (0, F.jsxs)(`div`, {
    style: {
      padding: `16px 0`
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        justifyContent: `space-between`,
        alignItems: `center`,
        marginBottom: 14
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          fontSize: 13,
          fontWeight: 700,
          color: `var(--muted)`,
          textTransform: `uppercase`,
          letterSpacing: `.04em`
        },
        children: [`Form Fields (`, n.length, `)`]
      }), (0, F.jsx)(z, {
        icon: (0, F.jsx)(yi, {
          size: 15
        }),
        size: `sm`,
        onClick: () => {
          l(null), s(!0)
        },
        style: {
          background: W
        },
        children: `Add field`
      })]
    }), i ? [1, 2, 3].map(e => (0, F.jsx)(na, {
      h: 56,
      style: {
        marginBottom: 6
      }
    }, e)) : n.length === 0 ? (0, F.jsx)(Qi, {
      icon: `📝`,
      title: `No form fields`,
      desc: `Add fields to collect information from customers when they submit this service.`,
      action: (0, F.jsx)(z, {
        icon: (0, F.jsx)(yi, {
          size: 15
        }),
        onClick: () => s(!0),
        style: {
          background: W
        },
        children: `Add first field`
      })
    }) : n.map((e, t) => (0, F.jsx)(To, {
      field: e,
      onEdit: () => {
        l(e), s(!0)
      },
      onDelete: () => f(e),
      onDuplicate: () => m(e),
      onMoveUp: () => p(t, -1),
      onMoveDown: () => p(t, 1),
      isFirst: t === 0,
      isLast: t === n.length - 1
    }, e.id)), (0, F.jsx)(Eo, {
      open: o,
      onClose: () => {
        s(!1), l(null)
      },
      onSave: d,
      initial: c,
      allFieldKeys: h
    })]
  })
}

function Oo({
  services: e
}) {
  let t = R(),
    [n, r] = (0, _.useState)([]),
    [i, a] = (0, _.useState)(!0),
    [o, s] = (0, _.useState)(``),
    [c, l] = (0, _.useState)([]),
    [u, d] = (0, _.useState)(0),
    [f, p] = (0, _.useState)(1),
    [m, h] = (0, _.useState)(``),
    [g, v] = (0, _.useState)(!1),
    [y, b] = (0, _.useState)([]),
    [x, S] = (0, _.useState)(``),
    [C, w] = (0, _.useState)(!1),
    [T, E] = (0, _.useState)(null),
    [D, O] = (0, _.useState)(``),
    [ee, te] = (0, _.useState)(!1);
  (0, _.useEffect)(() => {
    async function t() {
      a(!0);
      try {
        let t = [];
        for (let n of e) {
          let e = await dr.formFields(n.id),
            r = e.fields || e || [];
          for (let e of r)[`dropdown`, `searchable`, `radio`].includes(e.field_type) && t.push({
            ...e,
            service_name: n.name,
            service_id: n.id
          })
        }
        r(t)
      } catch {} finally {
        a(!1)
      }
    }
    e.length > 0 && t()
  }, [e]);
  async function k(e, n = 1, r = ``) {
    if (e) {
      v(!0);
      try {
        let t = await wr.list(e, {
          page: n,
          per_page: 50,
          search: r
        });
        l(t.options || []), d(t.total || 0), p(n)
      } catch (e) {
        t(e.message || `Load failed`, `error`)
      } finally {
        v(!1)
      }
    }
  }

  function ne(e) {
    s(e), b([]), h(``), l([]), S(``), E(null), e && k(e, 1, ``)
  }
  async function re() {
    if (x.trim()) {
      w(!0);
      try {
        await wr.create(o, {
          value: x.trim()
        }), S(``), t(`Option added`, `success`), k(o, f, m)
      } catch (e) {
        t(e.message, `error`)
      } finally {
        w(!1)
      }
    }
  }
  async function ie(e) {
    if (D.trim()) {
      te(!0);
      try {
        await wr.update(o, e, {
          value: D.trim()
        }), E(null), O(``), t(`Updated`, `success`), k(o, f, m)
      } catch (e) {
        t(e.message, `error`)
      } finally {
        te(!1)
      }
    }
  }
  async function ae(e) {
    if (confirm(`Delete this option?`)) try {
      await wr.del(o, e), t(`Deleted`, `success`), k(o, f, m)
    } catch (e) {
      t(e.message, `error`)
    }
  }
  async function A() {
    if (y.length !== 0 && confirm(`Delete ${y.length} option(s)?`)) try {
      await wr.bulkDelete(o, {
        ids: y
      }), b([]), t(`Deleted`, `success`), k(o, f, m)
    } catch (e) {
      t(e.message, `error`)
    }
  }
  let j = c.length > 0 && c.every(e => y.includes(e.id));
  return (0, F.jsxs)(`div`, {
    children: [(0, F.jsx)(`div`, {
      style: {
        fontSize: 14,
        color: `var(--muted)`,
        marginBottom: 16
      },
      children: `Manage the options for dropdown, searchable, and radio button fields across all services.`
    }), (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        gap: 10,
        marginBottom: 16,
        flexWrap: `wrap`,
        alignItems: `flex-end`
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          flex: 1,
          minWidth: 220
        },
        children: [(0, F.jsx)(`label`, {
          style: {
            fontSize: 12,
            fontWeight: 700,
            color: `var(--text-2)`,
            display: `block`,
            marginBottom: 5
          },
          children: `Target Field`
        }), i ? (0, F.jsx)(na, {
          h: 38
        }) : (0, F.jsxs)(`select`, {
          value: o,
          onChange: e => ne(e.target.value),
          style: {
            width: `100%`,
            padding: `9px 13px`,
            fontSize: 13,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r)`,
            fontFamily: `inherit`,
            outline: `none`
          },
          children: [(0, F.jsx)(`option`, {
            value: ``,
            children: `-- Select Field --`
          }), n.map(e => (0, F.jsxs)(`option`, {
            value: e.id,
            children: [e.label, ` (`, e.field_type, `) — `, e.service_name]
          }, e.id))]
        })]
      }), o && (0, F.jsxs)(`div`, {
        style: {
          flex: 1,
          minWidth: 180
        },
        children: [(0, F.jsx)(`label`, {
          style: {
            fontSize: 12,
            fontWeight: 700,
            color: `var(--text-2)`,
            display: `block`,
            marginBottom: 5
          },
          children: `Search Options`
        }), (0, F.jsx)(`input`, {
          value: m,
          onChange: e => h(e.target.value),
          onKeyDown: e => {
            e.key === `Enter` && k(o, 1, m)
          },
          placeholder: `Search…`,
          style: {
            width: `100%`,
            padding: `9px 13px`,
            fontSize: 13,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r)`,
            fontFamily: `inherit`,
            outline: `none`,
            boxSizing: `border-box`
          }
        })]
      })]
    }), o ? (0, F.jsxs)(F.Fragment, {
      children: [(0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          gap: 8,
          marginBottom: 14
        },
        children: [(0, F.jsx)(`input`, {
          value: x,
          onChange: e => S(e.target.value),
          onKeyDown: e => {
            e.key === `Enter` && re()
          },
          placeholder: `New option value…`,
          style: {
            flex: 1,
            padding: `9px 13px`,
            fontSize: 13,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r)`,
            fontFamily: `inherit`,
            outline: `none`
          }
        }), (0, F.jsx)(z, {
          loading: C,
          onClick: re,
          style: {
            background: W
          },
          children: `+ Add Option`
        })]
      }), y.length > 0 && (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          gap: 10,
          padding: `8px 14px`,
          background: `var(--orange-bg)`,
          border: `1px solid #fed7aa`,
          borderRadius: `var(--r)`,
          marginBottom: 12
        },
        children: [(0, F.jsxs)(`span`, {
          style: {
            fontSize: 13,
            fontWeight: 600,
            color: `var(--amber-dark)`
          },
          children: [y.length, ` selected`]
        }), (0, F.jsx)(z, {
          size: `sm`,
          variant: `danger`,
          onClick: A,
          children: `🗑 Delete Selected`
        }), (0, F.jsx)(`button`, {
          onClick: () => b([]),
          style: {
            background: `none`,
            border: `none`,
            cursor: `pointer`,
            fontSize: 12,
            color: `var(--muted)`,
            fontFamily: `inherit`
          },
          children: `Clear`
        })]
      }), (0, F.jsx)(`div`, {
        style: {
          border: `1px solid var(--border)`,
          borderRadius: `var(--r)`,
          overflow: `hidden`
        },
        children: (0, F.jsxs)(`table`, {
          style: {
            width: `100%`,
            borderCollapse: `collapse`,
            fontSize: 13
          },
          children: [(0, F.jsx)(`thead`, {
            children: (0, F.jsxs)(`tr`, {
              style: {
                background: `var(--surface-2)`,
                borderBottom: `1px solid var(--border)`
              },
              children: [(0, F.jsx)(`th`, {
                style: {
                  padding: `10px 12px`,
                  textAlign: `left`,
                  width: 36
                },
                children: (0, F.jsx)(`input`, {
                  type: `checkbox`,
                  checked: j,
                  onChange: () => b(j ? [] : c.map(e => e.id)),
                  style: {
                    width: 15,
                    height: 15
                  }
                })
              }), (0, F.jsx)(`th`, {
                style: {
                  padding: `10px 12px`,
                  textAlign: `left`,
                  fontWeight: 700,
                  color: `var(--muted)`,
                  textTransform: `uppercase`,
                  letterSpacing: `.04em`,
                  fontSize: 11
                },
                children: `#`
              }), (0, F.jsx)(`th`, {
                style: {
                  padding: `10px 12px`,
                  textAlign: `left`,
                  fontWeight: 700,
                  color: `var(--muted)`,
                  textTransform: `uppercase`,
                  letterSpacing: `.04em`,
                  fontSize: 11
                },
                children: `Option Value`
              }), (0, F.jsx)(`th`, {
                style: {
                  padding: `10px 12px`,
                  textAlign: `left`,
                  width: 140
                }
              })]
            })
          }), (0, F.jsx)(`tbody`, {
            children: g ? (0, F.jsx)(`tr`, {
              children: (0, F.jsx)(`td`, {
                colSpan: 4,
                style: {
                  padding: 20,
                  textAlign: `center`,
                  color: `var(--muted)`
                },
                children: `Loading…`
              })
            }) : c.length === 0 ? (0, F.jsx)(`tr`, {
              children: (0, F.jsx)(`td`, {
                colSpan: 4,
                style: {
                  padding: 30,
                  textAlign: `center`,
                  color: `var(--muted)`
                },
                children: `No options yet. Add one above.`
              })
            }) : c.map((e, t) => (0, F.jsxs)(`tr`, {
              style: {
                borderBottom: `1px solid #f1f5f9`
              },
              children: [(0, F.jsx)(`td`, {
                style: {
                  padding: `10px 12px`
                },
                children: (0, F.jsx)(`input`, {
                  type: `checkbox`,
                  checked: y.includes(e.id),
                  onChange: () => b(t => t.includes(e.id) ? t.filter(t => t !== e.id) : [...t, e.id]),
                  style: {
                    width: 15,
                    height: 15
                  }
                })
              }), (0, F.jsx)(`td`, {
                style: {
                  padding: `10px 12px`,
                  color: `var(--muted)`
                },
                children: (f - 1) * 50 + t + 1
              }), (0, F.jsx)(`td`, {
                style: {
                  padding: `10px 12px`
                },
                children: T === e.id ? (0, F.jsx)(`input`, {
                  value: D,
                  onChange: e => O(e.target.value),
                  onKeyDown: t => {
                    t.key === `Enter` && ie(e.id), t.key === `Escape` && E(null)
                  },
                  autoFocus: !0,
                  style: {
                    width: `100%`,
                    padding: `6px 10px`,
                    fontSize: 13,
                    border: `1px solid ${W}`,
                    borderRadius: `var(--r-sm)`,
                    fontFamily: `inherit`,
                    outline: `none`
                  }
                }) : (0, F.jsx)(`span`, {
                  style: {
                    fontWeight: 500
                  },
                  children: e.option_value
                })
              }), (0, F.jsx)(`td`, {
                style: {
                  padding: `10px 12px`
                },
                children: (0, F.jsx)(`div`, {
                  style: {
                    display: `flex`,
                    gap: 6
                  },
                  children: T === e.id ? (0, F.jsxs)(F.Fragment, {
                    children: [(0, F.jsx)(z, {
                      size: `sm`,
                      loading: ee,
                      onClick: () => ie(e.id),
                      style: {
                        background: W
                      },
                      children: `Save`
                    }), (0, F.jsx)(z, {
                      size: `sm`,
                      variant: `ghost`,
                      onClick: () => E(null),
                      children: `Cancel`
                    })]
                  }) : (0, F.jsxs)(F.Fragment, {
                    children: [(0, F.jsx)(z, {
                      size: `sm`,
                      variant: `outline`,
                      onClick: () => {
                        E(e.id), O(e.option_value)
                      },
                      children: `Edit`
                    }), (0, F.jsx)(z, {
                      size: `sm`,
                      variant: `danger`,
                      onClick: () => ae(e.id),
                      children: `Del`
                    })]
                  })
                })
              })]
            }, e.id))
          })]
        })
      }), u > 50 && (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          gap: 8,
          marginTop: 12,
          alignItems: `center`
        },
        children: [(0, F.jsxs)(`span`, {
          style: {
            fontSize: 13,
            color: `var(--muted)`
          },
          children: [u, ` total`]
        }), Array.from({
          length: Math.ceil(u / 50)
        }, (e, t) => (0, F.jsx)(`button`, {
          onClick: () => k(o, t + 1, m),
          style: {
            padding: `4px 10px`,
            fontSize: 12,
            fontWeight: 600,
            cursor: `pointer`,
            borderRadius: `var(--r-sm)`,
            border: `1px solid var(--border)`,
            background: f === t + 1 ? W : `#fff`,
            color: f === t + 1 ? `#fff` : `var(--text-2)`,
            fontFamily: `inherit`
          },
          children: t + 1
        }, t))]
      })]
    }) : (0, F.jsx)(`div`, {
      style: {
        padding: 40,
        textAlign: `center`,
        color: `var(--muted)`,
        fontSize: 14
      },
      children: `Select a field above to manage its options`
    })]
  })
}

function ko({
  services: e
}) {
  let t = R(),
    [n, r] = (0, _.useState)([]),
    [i, a] = (0, _.useState)(!0),
    [o, s] = (0, _.useState)(``),
    [c, l] = (0, _.useState)(`append`),
    [u, d] = (0, _.useState)(`paste`),
    [f, p] = (0, _.useState)(``),
    [m, h] = (0, _.useState)(`lines`),
    [g, v] = (0, _.useState)([]),
    [y, b] = (0, _.useState)(null),
    [x, S] = (0, _.useState)([]),
    [C, w] = (0, _.useState)(!1),
    [T, E] = (0, _.useState)(null);
  (0, _.useEffect)(() => {
    async function t() {
      a(!0);
      try {
        let t = [];
        for (let n of e) {
          let e = await dr.formFields(n.id),
            r = e.fields || e || [];
          for (let e of r)[`dropdown`, `searchable`, `radio`].includes(e.field_type) && t.push({
            ...e,
            service_name: n.name
          })
        }
        r(t)
      } catch {} finally {
        a(!1)
      }
    }
    e.length > 0 && t()
  }, [e]);

  function D() {
    let e = [];
    try {
      if (m === `json`) {
        if (e = JSON.parse(f), !Array.isArray(e)) throw Error(`Not an array`)
      } else e = m === `comma` ? f.split(`,`).map(e => e.trim()).filter(Boolean) : f.split(`
`).map(e => e.trim()).filter(Boolean)
    } catch {
      t(`Invalid format. Check your data.`, `error`);
      return
    }
    v(e.slice(0, 20)), t(`Parsed ${e.length} value(s)`, `success`)
  }

  function O(e) {
    let t = e.target.files?.[0];
    if (!t) return;
    b(t);
    let n = new FileReader;
    n.onload = e => {
      S((e.target.result || ``).split(`
`).map(e => e.trim()).filter(Boolean).slice(0, 20))
    }, n.readAsText(t)
  }
  async function ee() {
    if (!o) return t(`Select a target field`, `error`);
    w(!0), E(null);
    try {
      let e = [];
      if (u === `paste`) e = m === `json` ? JSON.parse(f) : m === `comma` ? f.split(`,`).map(e => e.trim()).filter(Boolean) : f.split(`
`).map(e => e.trim()).filter(Boolean);
      else {
        if (!y) return t(`Select a CSV file`, `error`);
        e = (await y.text()).split(`
`).map(e => e.trim()).filter(Boolean)
      }
      let n = await wr.bulkImport(o, {
        values: e.join(`
`),
        mode: c
      });
      E({
        inserted: n.inserted,
        total: n.total_submitted
      }), t(`Imported ${n.inserted} of ${n.total_submitted} options`, `success`), p(``), v([]), b(null), S([])
    } catch (e) {
      t(e.message || `Import failed`, `error`)
    } finally {
      w(!1)
    }
  }
  return (0, F.jsxs)(`div`, {
    children: [(0, F.jsx)(`div`, {
      style: {
        fontSize: 14,
        color: `var(--muted)`,
        marginBottom: 16
      },
      children: `Bulk import options for dropdown, searchable, or radio fields from CSV or paste.`
    }), (0, F.jsx)(B, {
      style: {
        marginBottom: 16
      },
      children: (0, F.jsxs)(`div`, {
        style: {
          display: `grid`,
          gridTemplateColumns: `1fr 1fr`,
          gap: 14
        },
        children: [(0, F.jsxs)(`div`, {
          children: [(0, F.jsx)(`label`, {
            style: {
              fontSize: 12,
              fontWeight: 700,
              color: `var(--text-2)`,
              display: `block`,
              marginBottom: 5
            },
            children: `Target Field *`
          }), i ? (0, F.jsx)(na, {
            h: 38
          }) : (0, F.jsxs)(`select`, {
            value: o,
            onChange: e => s(e.target.value),
            style: {
              width: `100%`,
              padding: `9px 13px`,
              fontSize: 13,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              fontFamily: `inherit`,
              outline: `none`
            },
            children: [(0, F.jsx)(`option`, {
              value: ``,
              children: `-- Select --`
            }), n.map(e => (0, F.jsxs)(`option`, {
              value: e.id,
              children: [e.label, ` — `, e.service_name]
            }, e.id))]
          })]
        }), (0, F.jsxs)(`div`, {
          children: [(0, F.jsx)(`label`, {
            style: {
              fontSize: 12,
              fontWeight: 700,
              color: `var(--text-2)`,
              display: `block`,
              marginBottom: 5
            },
            children: `Import Mode`
          }), (0, F.jsxs)(`select`, {
            value: c,
            onChange: e => l(e.target.value),
            style: {
              width: `100%`,
              padding: `9px 13px`,
              fontSize: 13,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              fontFamily: `inherit`,
              outline: `none`
            },
            children: [(0, F.jsx)(`option`, {
              value: `append`,
              children: `Append to existing`
            }), (0, F.jsx)(`option`, {
              value: `replace`,
              children: `Replace all existing`
            })]
          })]
        })]
      })
    }), (0, F.jsx)(`div`, {
      style: {
        display: `flex`,
        borderBottom: `1px solid var(--border)`,
        marginBottom: 16
      },
      children: [
        [`paste`, `Paste Data`],
        [`csv`, `Upload CSV`]
      ].map(([e, t]) => (0, F.jsx)(`button`, {
        onClick: () => d(e),
        style: {
          padding: `9px 16px`,
          fontSize: 13,
          fontWeight: 600,
          background: `none`,
          border: `none`,
          cursor: `pointer`,
          fontFamily: `inherit`,
          color: u === e ? W : `var(--muted)`,
          borderBottom: `2px solid ${u===e?W:`transparent`}`,
          marginBottom: -1
        },
        children: t
      }, e))
    }), u === `paste` && (0, F.jsxs)(B, {
      children: [(0, F.jsx)(`div`, {
        style: {
          display: `flex`,
          gap: 8,
          marginBottom: 12
        },
        children: [
          [`lines`, `One per line`],
          [`comma`, `Comma-separated`],
          [`json`, `JSON array`]
        ].map(([e, t]) => (0, F.jsx)(`button`, {
          onClick: () => h(e),
          style: {
            padding: `5px 12px`,
            fontSize: 12,
            fontWeight: 600,
            cursor: `pointer`,
            borderRadius: `var(--r-full)`,
            border: `1px solid var(--border)`,
            background: m === e ? W : `#fff`,
            color: m === e ? `#fff` : `var(--text-2)`,
            fontFamily: `inherit`
          },
          children: t
        }, e))
      }), (0, F.jsx)(`label`, {
        style: {
          fontSize: 12,
          fontWeight: 700,
          color: `var(--text-2)`,
          display: `block`,
          marginBottom: 6
        },
        children: `Paste data here:`
      }), (0, F.jsx)(`textarea`, {
        value: f,
        onChange: e => p(e.target.value),
        rows: 8,
        placeholder: m === `json` ? `["Option A", "Option B", "Option C"]` : m === `comma` ? `Option A, Option B, Option C` : `Option A
Option B
Option C`,
        style: {
          width: `100%`,
          padding: `9px 13px`,
          fontSize: 13,
          border: `1px solid var(--border)`,
          borderRadius: `var(--r)`,
          fontFamily: `inherit`,
          outline: `none`,
          resize: `vertical`,
          boxSizing: `border-box`
        }
      }), (0, F.jsx)(`div`, {
        style: {
          display: `flex`,
          gap: 10,
          marginTop: 12
        },
        children: (0, F.jsx)(z, {
          variant: `outline`,
          size: `sm`,
          onClick: D,
          children: `Parse & Preview`
        })
      }), g.length > 0 && (0, F.jsxs)(`div`, {
        style: {
          marginTop: 12,
          padding: 12,
          background: `var(--surface-2)`,
          borderRadius: `var(--r)`,
          fontSize: 13
        },
        children: [(0, F.jsxs)(`strong`, {
          children: [`Preview (`, g.length, ` shown):`]
        }), (0, F.jsx)(`div`, {
          style: {
            marginTop: 6,
            color: `var(--text-2)`,
            maxHeight: 120,
            overflowY: `auto`
          },
          children: g.map((e, t) => (0, F.jsxs)(`div`, {
            style: {
              padding: `2px 0`
            },
            children: [t + 1, `. `, e]
          }, t))
        })]
      })]
    }), u === `csv` && (0, F.jsxs)(B, {
      children: [(0, F.jsx)(`p`, {
        style: {
          fontSize: 13,
          color: `var(--muted)`,
          marginBottom: 16
        },
        children: `Upload a CSV file — one value per row, no header required.`
      }), (0, F.jsxs)(`div`, {
        onClick: () => document.getElementById(`bulk-csv-input`).click(),
        onDragOver: e => {
          e.preventDefault(), e.currentTarget.style.borderColor = W
        },
        onDragLeave: e => {
          e.currentTarget.style.borderColor = `var(--border)`
        },
        onDrop: e => {
          e.preventDefault(), e.currentTarget.style.borderColor = `var(--border)`;
          let t = e.dataTransfer.files[0];
          if (t) {
            b(t);
            let e = new FileReader;
            e.onload = e => {
              S((e.target.result || ``).split(`
`).map(e => e.trim()).filter(Boolean).slice(0, 20))
            }, e.readAsText(t)
          }
        },
        style: {
          border: `2px dashed ${y?W:`var(--border)`}`,
          borderRadius: `var(--r)`,
          padding: 32,
          textAlign: `center`,
          cursor: `pointer`,
          background: y ? `${W}08` : `var(--surface-2)`
        },
        children: [(0, F.jsx)(`input`, {
          id: `bulk-csv-input`,
          type: `file`,
          accept: `.csv,.txt`,
          style: {
            display: `none`
          },
          onChange: O
        }), (0, F.jsx)(`div`, {
          style: {
            fontSize: 28,
            marginBottom: 8
          },
          children: `📊`
        }), (0, F.jsx)(`p`, {
          style: {
            margin: 0,
            fontSize: 13,
            color: `var(--muted)`
          },
          children: y ? y.name : `Drop CSV here or click to browse`
        })]
      }), x.length > 0 && (0, F.jsxs)(`div`, {
        style: {
          marginTop: 12,
          padding: 12,
          background: `var(--surface-2)`,
          borderRadius: `var(--r)`,
          fontSize: 13
        },
        children: [(0, F.jsxs)(`strong`, {
          children: [`Preview (first `, x.length, ` rows):`]
        }), (0, F.jsx)(`div`, {
          style: {
            marginTop: 6,
            color: `var(--text-2)`,
            maxHeight: 100,
            overflowY: `auto`
          },
          children: x.map((e, t) => (0, F.jsxs)(`div`, {
            style: {
              padding: `2px 0`
            },
            children: [t + 1, `. `, e]
          }, t))
        })]
      }), (0, F.jsx)(`div`, {
        style: {
          marginTop: 14,
          display: `flex`,
          gap: 10
        },
        children: (0, F.jsx)(`a`, {
          href: `data:text/csv;charset=utf-8,University+of+Delhi%0AUniversity+of+Mumbai%0AAnna+University`,
          download: `sample.csv`,
          style: {
            padding: `6px 14px`,
            fontSize: 12,
            fontWeight: 600,
            color: W,
            border: `1px solid ${W}`,
            borderRadius: `var(--r-sm)`,
            textDecoration: `none`,
            background: `#fff`
          },
          children: `↓ Sample CSV`
        })
      })]
    }), (0, F.jsx)(`div`, {
      style: {
        marginTop: 16
      },
      children: (0, F.jsx)(z, {
        fullWidth: !0,
        loading: C,
        onClick: ee,
        style: {
          background: W,
          fontSize: 14
        },
        children: `Import Options`
      })
    }), T && (0, F.jsxs)(`div`, {
      style: {
        marginTop: 12,
        padding: 14,
        background: `var(--green-bg)`,
        border: `1px solid var(--green-border)`,
        borderRadius: `var(--r)`,
        fontSize: 13,
        color: `var(--green)`,
        fontWeight: 600
      },
      children: [`✅ Imported `, T.inserted, ` of `, T.total, ` options successfully.`]
    })]
  })
}

function Ao() {
  let e = R(),
    [t, n] = (0, _.useState)([]),
    [r, i] = (0, _.useState)(!0),
    [a, o] = (0, _.useState)(null),
    [s, c] = (0, _.useState)(!1),
    [l, u] = (0, _.useState)(null),
    [d, f] = (0, _.useState)({
      name: ``,
      icon: `📋`,
      description: ``
    }),
    [p, m] = (0, _.useState)(!1),
    [h, g] = (0, _.useState)(`services`),
    v = (0, _.useCallback)(async () => {
      i(!0);
      try {
        let e = await dr.list();
        n(e.services || e || [])
      } catch {} finally {
        i(!1)
      }
    }, []);
  (0, _.useEffect)(() => {
    v()
  }, [v]);
  async function y() {
    m(!0);
    try {
      l?.id ? (await dr.update(l.id, d), e(`Service updated`, `success`)) : (await dr.create(d), e(`Service created`, `success`)), c(!1), u(null), v()
    } catch (t) {
      e(t.message, `error`)
    } finally {
      m(!1)
    }
  }
  async function b(t) {
    if (confirm(`Delete service "${t.name}"? This will also delete all associated form fields.`)) try {
      await dr.del(t.id), e(`Service deleted`, `success`), a?.id === t.id && o(null), v()
    } catch (t) {
      e(t.message, `error`)
    }
  }
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      gap: 20
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`
      },
      children: [(0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(`h1`, {
          style: {
            fontSize: 22,
            fontWeight: 800
          },
          children: `Services & Form Fields`
        }), (0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`,
            marginTop: 3
          },
          children: `Manage services, intake forms, dropdown options, and bulk imports`
        })]
      }), h === `services` && (0, F.jsx)(z, {
        icon: (0, F.jsx)(yi, {
          size: 16
        }),
        onClick: () => {
          u(null), f({
            name: ``,
            icon: `📋`,
            description: ``
          }), c(!0)
        },
        style: {
          background: W
        },
        children: `Add Service`
      })]
    }), (0, F.jsx)(`div`, {
      style: {
        display: `flex`,
        borderBottom: `1px solid var(--border)`,
        background: `#fff`,
        borderRadius: `var(--r-lg) var(--r-lg) 0 0`,
        border: `1px solid var(--border)`
      },
      children: [{
        key: `services`,
        label: `📋 Services & Form Fields`
      }, {
        key: `dropdowns`,
        label: `🗂 Dropdown Data Manager`
      }, {
        key: `bulk`,
        label: `📥 Bulk Import`
      }].map(e => (0, F.jsx)(`button`, {
        onClick: () => g(e.key),
        style: {
          padding: `13px 20px`,
          fontSize: 13,
          fontWeight: 600,
          background: `none`,
          border: `none`,
          cursor: `pointer`,
          fontFamily: `inherit`,
          color: h === e.key ? W : `var(--muted)`,
          borderBottom: `2px solid ${h===e.key?W:`transparent`}`,
          marginBottom: -2,
          whiteSpace: `nowrap`,
          transition: `var(--t)`
        },
        children: e.label
      }, e.key))
    }), h === `services` && (0, F.jsxs)(`div`, {
      style: {
        display: `grid`,
        gridTemplateColumns: a ? `280px 1fr` : `1fr`,
        gap: 20,
        alignItems: `start`
      },
      children: [(0, F.jsx)(B, {
        padding: `0`,
        children: r ? (0, F.jsx)(`div`, {
          style: {
            padding: 16,
            display: `flex`,
            flexDirection: `column`,
            gap: 8
          },
          children: [1, 2, 3].map(e => (0, F.jsx)(na, {
            h: 60
          }, e))
        }) : t.length === 0 ? (0, F.jsx)(Qi, {
          icon: `📋`,
          title: `No services yet`,
          action: (0, F.jsx)(z, {
            icon: (0, F.jsx)(yi, {
              size: 15
            }),
            onClick: () => c(!0),
            style: {
              background: W
            },
            children: `Add Service`
          })
        }) : t.map(e => (0, F.jsxs)(`div`, {
          onClick: () => o(e),
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 12,
            padding: `13px 16px`,
            cursor: `pointer`,
            borderBottom: `1px solid #f1f5f9`,
            background: a?.id === e.id ? `${W}10` : `#fff`,
            borderLeft: a?.id === e.id ? `3px solid ${W}` : `3px solid transparent`,
            transition: `all 0.15s`
          },
          onMouseEnter: t => {
            a?.id !== e.id && (t.currentTarget.style.background = `var(--surface-2)`)
          },
          onMouseLeave: t => {
            a?.id !== e.id && (t.currentTarget.style.background = `#fff`)
          },
          children: [(0, F.jsx)(`span`, {
            style: {
              fontSize: 22
            },
            children: e.icon || `📋`
          }), (0, F.jsxs)(`div`, {
            style: {
              flex: 1,
              minWidth: 0
            },
            children: [(0, F.jsx)(`div`, {
              style: {
                fontWeight: 700,
                fontSize: 14,
                color: `var(--text)`,
                overflow: `hidden`,
                whiteSpace: `nowrap`,
                textOverflow: `ellipsis`
              },
              children: e.name
            }), e.description && (0, F.jsx)(`div`, {
              style: {
                fontSize: 12,
                color: `var(--muted)`,
                overflow: `hidden`,
                whiteSpace: `nowrap`,
                textOverflow: `ellipsis`
              },
              children: e.description
            })]
          }), (0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              gap: 4,
              flexShrink: 0
            },
            onClick: e => e.stopPropagation(),
            children: [(0, F.jsx)(`button`, {
              onClick: () => {
                u(e), f({
                  name: e.name,
                  icon: e.icon || `📋`,
                  description: e.description || ``
                }), c(!0)
              },
              style: {
                background: `none`,
                border: `none`,
                cursor: `pointer`,
                color: W,
                padding: 4
              },
              children: (0, F.jsx)(_i, {
                size: 13
              })
            }), (0, F.jsx)(`button`, {
              onClick: () => b(e),
              style: {
                background: `none`,
                border: `none`,
                cursor: `pointer`,
                color: `var(--red)`,
                padding: 4
              },
              children: (0, F.jsx)(Mi, {
                size: 13
              })
            })]
          })]
        }, e.id))
      }), a && (0, F.jsxs)(B, {
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 10,
            marginBottom: 4
          },
          children: [(0, F.jsx)(`span`, {
            style: {
              fontSize: 22
            },
            children: a.icon
          }), (0, F.jsx)(`h2`, {
            style: {
              fontSize: 17
            },
            children: a.name
          }), (0, F.jsx)(`button`, {
            onClick: () => o(null),
            style: {
              background: `none`,
              border: `none`,
              cursor: `pointer`,
              color: `var(--muted)`,
              marginLeft: `auto`,
              padding: 4
            },
            children: (0, F.jsx)(Li, {
              size: 18
            })
          })]
        }), a.description && (0, F.jsx)(`p`, {
          style: {
            fontSize: 13,
            color: `var(--muted)`,
            marginBottom: 4
          },
          children: a.description
        }), (0, F.jsx)(Do, {
          svcId: a.id
        })]
      })]
    }), h === `dropdowns` && (0, F.jsxs)(B, {
      children: [(0, F.jsx)(`div`, {
        style: {
          fontSize: 16,
          fontWeight: 700,
          marginBottom: 16
        },
        children: `🗂 Dropdown Data Manager`
      }), r ? (0, F.jsx)(na, {
        h: 200
      }) : (0, F.jsx)(Oo, {
        services: t
      })]
    }), h === `bulk` && (0, F.jsxs)(B, {
      children: [(0, F.jsx)(`div`, {
        style: {
          fontSize: 16,
          fontWeight: 700,
          marginBottom: 16
        },
        children: `📥 Bulk Import for Dropdown Options`
      }), r ? (0, F.jsx)(na, {
        h: 200
      }) : (0, F.jsx)(ko, {
        services: t
      })]
    }), (0, F.jsx)($i, {
      open: s,
      onClose: () => {
        c(!1), u(null)
      },
      title: l ? `Edit service` : `Add service`,
      maxWidth: 460,
      footer: (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(z, {
          variant: `secondary`,
          onClick: () => c(!1),
          children: `Cancel`
        }), (0, F.jsx)(z, {
          loading: p,
          onClick: y,
          style: {
            background: W
          },
          children: `Save service`
        })]
      }),
      children: (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          flexDirection: `column`,
          gap: 14
        },
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            gap: 12
          },
          children: [(0, F.jsx)(Xi, {
            label: `Icon (emoji)`,
            value: d.icon,
            onChange: e => f(t => ({
              ...t,
              icon: e.target.value
            })),
            placeholder: `📋`,
            inputStyle: {
              textAlign: `center`,
              fontSize: 20
            },
            style: {
              width: 80,
              flexShrink: 0
            }
          }), (0, F.jsx)(Xi, {
            label: `Service name`,
            value: d.name,
            onChange: e => f(t => ({
              ...t,
              name: e.target.value
            })),
            required: !0,
            placeholder: `e.g. Passport Renewal`,
            style: {
              flex: 1
            }
          })]
        }), (0, F.jsx)(Xi, {
          label: `Description`,
          value: d.description,
          onChange: e => f(t => ({
            ...t,
            description: e.target.value
          })),
          placeholder: `Brief description shown to customers`,
          as: `textarea`,
          rows: 2
        })]
      })
    })]
  })
}
var jo = `var(--brand)`;

function G({
  label: e,
  hint: t,
  children: n,
  required: r
}) {
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      gap: 5,
      marginBottom: 16
    },
    children: [e && (0, F.jsxs)(`label`, {
      style: {
        fontSize: 13,
        fontWeight: 600,
        color: `var(--text-2)`
      },
      children: [e, r && (0, F.jsx)(`span`, {
        style: {
          color: `var(--red)`,
          marginLeft: 2
        },
        children: `*`
      })]
    }), n, t && (0, F.jsx)(`span`, {
      style: {
        fontSize: 12,
        color: `var(--muted)`
      },
      children: t
    })]
  })
}

function K({
  value: e,
  onChange: t,
  ...n
}) {
  let r = {
    padding: `9px 13px`,
    fontSize: 14,
    border: `1px solid var(--border)`,
    borderRadius: `var(--r)`,
    fontFamily: `inherit`,
    outline: `none`,
    width: `100%`,
    boxSizing: `border-box`,
    color: `var(--text)`
  };
  if (n.as === `textarea`) {
    let {
      as: i,
      ...a
    } = n;
    return (0, F.jsx)(`textarea`, {
      style: {
        ...r,
        resize: `vertical`
      },
      value: e || ``,
      onChange: e => t(e.target.value),
      ...a
    })
  }
  return (0, F.jsx)(`input`, {
    style: r,
    value: e || ``,
    onChange: e => t(e.target.value),
    ...n
  })
}

function Mo({
  value: e,
  onChange: t,
  label: n
}) {
  return (0, F.jsxs)(`label`, {
    style: {
      display: `flex`,
      alignItems: `center`,
      gap: 10,
      cursor: `pointer`,
      fontSize: 14
    },
    children: [(0, F.jsx)(`div`, {
      onClick: () => t(!e),
      style: {
        width: 44,
        height: 24,
        borderRadius: 12,
        background: e ? jo : `var(--border)`,
        position: `relative`,
        cursor: `pointer`,
        transition: `background .2s`,
        flexShrink: 0
      },
      children: (0, F.jsx)(`div`, {
        style: {
          width: 20,
          height: 20,
          borderRadius: `50%`,
          background: `#fff`,
          position: `absolute`,
          top: 2,
          left: e ? 22 : 2,
          transition: `left .2s`,
          boxShadow: `0 1px 3px rgba(0,0,0,.2)`
        }
      })
    }), n]
  })
}
var No = [`{CUSTOMER_NAME}`, `{BOOKING_REF}`, `{SERVICE_NAME}`, `{PLATFORM_NAME}`, `{DASHBOARD_URL}`, `{STATUS}`, `{SECONDARY_STATUS}`, `{DOCUMENT_TYPE}`, `{SERVICE_CHARGES}`, `{SHIPPING_CHARGES}`, `{TOTAL_AMOUNT}`, `{DELIVERY_DATE}`, `{SUBMITTED_DATE}`, `{QUOTE_VALID_UNTIL}`],
  Po = [`Documents`, `Status`, `General`, `Follow-up`],
  Fo = [`National`, `State`, `University`],
  Io = [`Jan`, `Feb`, `Mar`, `Apr`, `May`, `Jun`, `Jul`, `Aug`, `Sep`, `Oct`, `Nov`, `Dec`];

function Lo() {
  let e = R(),
    [t, n] = (0, _.useState)([]),
    [r, i] = (0, _.useState)(!0),
    [a, o] = (0, _.useState)(null),
    [s, c] = (0, _.useState)(!1),
    [l, u] = (0, _.useState)(!1),
    [d, f] = (0, _.useState)(``),
    [p, m] = (0, _.useState)(!1),
    [h, g] = (0, _.useState)(!1),
    [v, y] = (0, _.useState)(!1),
    [b, x] = (0, _.useState)(``),
    [S, C] = (0, _.useState)(``),
    [w, T] = (0, _.useState)(!1),
    E = (0, _.useRef)(null),
    D = (0, _.useCallback)(async () => {
      i(!0);
      try {
        let e = await gr.list();
        n(e.templates || []), !a && e.templates?.length && o(e.templates[0])
      } catch {
        e(`Failed to load templates`, `error`)
      } finally {
        i(!1)
      }
    }, []);
  (0, _.useEffect)(() => {
    D()
  }, [D]), (0, _.useEffect)(() => {
    if (h && E.current && a?.body) {
      let e = E.current;
      e.srcdoc = a.body
    }
  }, [h, a?.body]);
  async function O() {
    if (a) {
      c(!0);
      try {
        await gr.update(a.id, {
          subject: a.subject,
          body: a.body
        }), e(`Template saved`, `success`), n(e => e.map(e => e.id === a.id ? {
          ...e,
          ...a
        } : e))
      } catch (t) {
        e(t.message || `Save failed`, `error`)
      } finally {
        c(!1)
      }
    }
  }
  async function ee() {
    if (!(!a || !a.is_builtin) && window.confirm(`Reset to default? Your edits will be lost.`)) {
      u(!0);
      try {
        let t = await gr.reset(a.id);
        o(e => ({
          ...e,
          subject: t.subject,
          body: t.body
        })), n(e => e.map(e => e.id === a.id ? {
          ...e,
          subject: t.subject,
          body: t.body
        } : e)), e(`Reset to default`, `success`)
      } catch (t) {
        e(t.message || `Reset failed`, `error`)
      } finally {
        u(!1)
      }
    }
  }
  async function te() {
    if (a) try {
      await gr.duplicate(a.id), e(`Duplicated`, `success`), await D()
    } catch (t) {
      e(t.message || `Failed`, `error`)
    }
  }
  async function k() {
    if (!d) {
      e(`Enter test email address`, `error`);
      return
    }
    m(!0);
    try {
      e((await gr.testEmail(a.id, d)).message || `Test email sent`, `success`)
    } catch (t) {
      e(t.message || `Send failed`, `error`)
    } finally {
      m(!1)
    }
  }
  async function ne() {
    if (!(!a || a.is_builtin) && window.confirm(`Delete "${a.name}"? This cannot be undone.`)) try {
      await gr.del(a.id), e(`Deleted`, `success`), await D(), o(null)
    } catch (t) {
      e(t.message || `Delete failed`, `error`)
    }
  }
  async function re() {
    if (!b || !S) {
      e(`Name and subject required`, `error`);
      return
    }
    T(!0);
    try {
      await gr.create({
        name: b,
        subject: S,
        body: `<p>Template body here.</p>`
      }), e(`Template created`, `success`), y(!1), x(``), C(``), await D()
    } catch (t) {
      e(t.message || `Failed`, `error`)
    } finally {
      T(!1)
    }
  }

  function ie(e) {
    let t = document.getElementById(`tpl-body`);
    if (!t) {
      o(t => ({
        ...t,
        body: (t?.body || ``) + e
      }));
      return
    }
    let n = t.selectionStart,
      r = t.selectionEnd,
      i = (a?.body || ``).slice(0, n) + e + (a?.body || ``).slice(r);
    o(e => ({
      ...e,
      body: i
    })), setTimeout(() => {
      t.focus(), t.setSelectionRange(n + e.length, n + e.length)
    }, 0)
  }
  let ae = t.filter(e => e.is_builtin == 1),
    A = t.filter(e => e.is_builtin != 1);
  return r ? (0, F.jsx)(`div`, {
    style: {
      padding: 40,
      textAlign: `center`
    },
    children: (0, F.jsx)(Wi, {
      size: 24
    })
  }) : (0, F.jsxs)(`div`, {
    style: {
      display: `grid`,
      gridTemplateColumns: `220px 1fr`,
      gap: 0,
      minHeight: 560
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        borderRight: `1px solid var(--border)`,
        display: `flex`,
        flexDirection: `column`
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          padding: `12px 14px`,
          fontSize: 11,
          fontWeight: 700,
          color: `var(--muted)`,
          textTransform: `uppercase`,
          letterSpacing: `.06em`,
          borderBottom: `1px solid var(--border)`,
          display: `flex`,
          justifyContent: `space-between`,
          alignItems: `center`
        },
        children: [`Templates`, (0, F.jsx)(`button`, {
          onClick: () => y(!0),
          title: `New template`,
          style: {
            background: `none`,
            border: `none`,
            cursor: `pointer`,
            color: jo,
            padding: 2
          },
          children: (0, F.jsx)(yi, {
            size: 16
          })
        })]
      }), ae.length > 0 && (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(`div`, {
          style: {
            padding: `8px 14px 4px`,
            fontSize: 10,
            fontWeight: 700,
            color: `var(--muted-2)`,
            textTransform: `uppercase`,
            letterSpacing: `.05em`
          },
          children: `Built-in`
        }), ae.map(e => (0, F.jsx)(Ro, {
          t: e,
          active: a?.id === e.id,
          onClick: () => o(e)
        }, e.id))]
      }), A.length > 0 && (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(`div`, {
          style: {
            padding: `8px 14px 4px`,
            fontSize: 10,
            fontWeight: 700,
            color: `var(--muted-2)`,
            textTransform: `uppercase`,
            letterSpacing: `.05em`
          },
          children: `Custom`
        }), A.map(e => (0, F.jsx)(Ro, {
          t: e,
          active: a?.id === e.id,
          onClick: () => o(e)
        }, e.id))]
      })]
    }), a ? (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        flexDirection: `column`
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          padding: `12px 20px`,
          borderBottom: `1px solid var(--border)`,
          display: `flex`,
          alignItems: `center`,
          justifyContent: `space-between`,
          flexWrap: `wrap`,
          gap: 8
        },
        children: [(0, F.jsxs)(`div`, {
          children: [(0, F.jsx)(`div`, {
            style: {
              fontSize: 15,
              fontWeight: 700
            },
            children: a.name
          }), (0, F.jsx)(`div`, {
            style: {
              fontSize: 11,
              color: `var(--muted)`
            },
            children: a.is_builtin ? `🔒 Built-in` : `✏ Custom`
          })]
        }), (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            gap: 6,
            flexWrap: `wrap`
          },
          children: [(0, F.jsx)(z, {
            size: `sm`,
            variant: `ghost`,
            icon: (0, F.jsx)(ni, {
              size: 13
            }),
            onClick: te,
            children: `Duplicate`
          }), !a.is_builtin && (0, F.jsx)(z, {
            size: `sm`,
            variant: `ghost`,
            icon: (0, F.jsx)(Mi, {
              size: 13
            }),
            style: {
              color: `var(--red)`
            },
            onClick: ne,
            children: `Delete`
          }), a.is_builtin && (0, F.jsx)(z, {
            size: `sm`,
            variant: `ghost`,
            icon: (0, F.jsx)(bi, {
              size: 13
            }),
            loading: l,
            onClick: ee,
            children: `Reset`
          }), (0, F.jsx)(z, {
            size: `sm`,
            variant: h ? `primary` : `ghost`,
            onClick: () => g(e => !e),
            children: h ? `Edit` : `Preview`
          }), (0, F.jsx)(z, {
            size: `sm`,
            loading: s,
            icon: (0, F.jsx)(Si, {
              size: 13
            }),
            onClick: O,
            children: `Save`
          })]
        })]
      }), (0, F.jsxs)(`div`, {
        style: {
          padding: 20,
          flex: 1,
          overflowY: `auto`
        },
        children: [(0, F.jsx)(G, {
          label: `Subject`,
          required: !0,
          children: (0, F.jsx)(K, {
            value: a.subject,
            onChange: e => o(t => ({
              ...t,
              subject: e
            }))
          })
        }), (0, F.jsxs)(`div`, {
          style: {
            marginBottom: 12
          },
          children: [(0, F.jsx)(`div`, {
            style: {
              fontSize: 12,
              fontWeight: 600,
              color: `var(--muted)`,
              marginBottom: 6
            },
            children: `Insert variable:`
          }), (0, F.jsx)(`div`, {
            style: {
              display: `flex`,
              flexWrap: `wrap`,
              gap: 4
            },
            children: No.map(e => (0, F.jsx)(`button`, {
              onClick: () => ie(e),
              style: {
                padding: `2px 8px`,
                fontSize: 11,
                borderRadius: `var(--r-sm)`,
                border: `1px solid var(--border)`,
                background: `var(--surface-2)`,
                cursor: `pointer`,
                fontFamily: `monospace`,
                color: `var(--text-2)`,
                transition: `all var(--t)`
              },
              onMouseEnter: e => {
                e.target.style.background = `var(--brand)15`, e.target.style.borderColor = jo
              },
              onMouseLeave: e => {
                e.target.style.background = `var(--surface-2)`, e.target.style.borderColor = `var(--border)`
              },
              children: e
            }, e))
          })]
        }), h ? (0, F.jsxs)(`div`, {
          children: [(0, F.jsx)(`div`, {
            style: {
              fontSize: 12,
              color: `var(--muted)`,
              marginBottom: 6
            },
            children: `Rendered preview (sandboxed)`
          }), (0, F.jsx)(`iframe`, {
            ref: E,
            srcDoc: a.body,
            style: {
              width: `100%`,
              height: 400,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              background: `#fff`
            },
            sandbox: `allow-same-origin`,
            title: `Email preview`
          })]
        }) : (0, F.jsx)(G, {
          label: `Body (HTML)`,
          children: (0, F.jsx)(`textarea`, {
            id: `tpl-body`,
            value: a.body || ``,
            rows: 18,
            onChange: e => o(t => ({
              ...t,
              body: e.target.value
            })),
            style: {
              width: `100%`,
              padding: `9px 13px`,
              fontSize: 13,
              fontFamily: `monospace`,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              outline: `none`,
              resize: `vertical`,
              boxSizing: `border-box`,
              lineHeight: 1.5
            }
          })
        }), (0, F.jsxs)(`div`, {
          style: {
            marginTop: 12,
            paddingTop: 16,
            borderTop: `1px solid var(--border)`,
            display: `flex`,
            gap: 8,
            alignItems: `flex-end`
          },
          children: [(0, F.jsx)(G, {
            label: `Send test email`,
            style: {
              flex: 1,
              marginBottom: 0
            },
            children: (0, F.jsx)(K, {
              value: d,
              onChange: f,
              type: `email`,
              placeholder: `test@example.com`
            })
          }), (0, F.jsx)(z, {
            size: `sm`,
            loading: p,
            icon: (0, F.jsx)(wi, {
              size: 13
            }),
            onClick: k,
            style: {
              marginBottom: 0,
              flexShrink: 0
            },
            children: `Send Test`
          })]
        })]
      })]
    }) : (0, F.jsx)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `center`
      },
      children: (0, F.jsx)(Qi, {
        icon: `📧`,
        title: `Select a template`,
        desc: `Choose a template from the left to edit it.`
      })
    }), (0, F.jsxs)($i, {
      open: v,
      onClose: () => y(!1),
      title: `New Email Template`,
      footer: (0, F.jsxs)(F.Fragment, {
        children: [(0, F.jsx)(z, {
          variant: `ghost`,
          onClick: () => y(!1),
          children: `Cancel`
        }), (0, F.jsx)(z, {
          loading: w,
          onClick: re,
          children: `Create`
        })]
      }),
      children: [(0, F.jsx)(G, {
        label: `Template name`,
        required: !0,
        children: (0, F.jsx)(K, {
          value: b,
          onChange: x,
          placeholder: `e.g. Renewal Reminder`
        })
      }), (0, F.jsx)(G, {
        label: `Subject`,
        required: !0,
        children: (0, F.jsx)(K, {
          value: S,
          onChange: C,
          placeholder: `Subject line…`
        })
      })]
    })]
  })
}

function Ro({
  t: e,
  active: t,
  onClick: n
}) {
  return (0, F.jsxs)(`button`, {
    onClick: n,
    style: {
      width: `100%`,
      textAlign: `left`,
      padding: `9px 14px`,
      background: `none`,
      border: `none`,
      borderLeft: `3px solid ${t?jo:`transparent`}`,
      cursor: `pointer`,
      fontFamily: `inherit`,
      background: t ? `${jo}10` : `none`
    },
    children: [(0, F.jsx)(`div`, {
      style: {
        fontSize: 13,
        fontWeight: t ? 700 : 500,
        color: t ? jo : `var(--text)`
      },
      children: e.name
    }), e.subject && (0, F.jsx)(`div`, {
      style: {
        fontSize: 11,
        color: `var(--muted)`,
        marginTop: 2,
        overflow: `hidden`,
        whiteSpace: `nowrap`,
        textOverflow: `ellipsis`
      },
      children: e.subject
    })]
  })
}

function zo() {
  let e = R(),
    [t, n] = (0, _.useState)([]),
    [r, i] = (0, _.useState)(!0),
    [a, o] = (0, _.useState)(null),
    [s, c] = (0, _.useState)({
      title: ``,
      category: `general`,
      content: ``
    }),
    [l, u] = (0, _.useState)(!1),
    d = (0, _.useCallback)(async () => {
      i(!0);
      try {
        n((await vr.list()).replies || [])
      } catch {
        e(`Failed to load`, `error`)
      } finally {
        i(!1)
      }
    }, []);
  (0, _.useEffect)(() => {
    d()
  }, [d]);
  async function f() {
    if (!s.title || !s.content) {
      e(`Title and content required`, `error`);
      return
    }
    u(!0);
    try {
      a ? (await vr.update(a, s), e(`Updated`, `success`)) : (await vr.create(s), e(`Created`, `success`)), o(null), c({
        title: ``,
        category: `general`,
        content: ``
      }), await d()
    } catch (t) {
      e(t.message || `Failed`, `error`)
    } finally {
      u(!1)
    }
  }
  async function p(t) {
    if (window.confirm(`Delete this quick reply?`)) try {
      await vr.del(t), e(`Deleted`, `success`), await d()
    } catch (t) {
      e(t.message || `Failed`, `error`)
    }
  }

  function m(e) {
    o(e.id), c({
      title: e.title,
      category: e.category || `general`,
      content: e.content
    })
  }

  function h() {
    o(null), c({
      title: ``,
      category: `general`,
      content: ``
    })
  }
  let g = Po.reduce((e, n) => (e[n.toLowerCase()] = t.filter(e => e.category?.toLowerCase() === n.toLowerCase()), e), {});
  return (0, F.jsxs)(`div`, {
    children: [(0, F.jsxs)(`div`, {
      style: {
        marginBottom: 24,
        padding: 20,
        background: `var(--surface-2)`,
        border: `1px solid var(--border)`,
        borderRadius: `var(--r-lg)`
      },
      children: [(0, F.jsx)(`div`, {
        style: {
          fontSize: 14,
          fontWeight: 700,
          marginBottom: 14
        },
        children: a ? `Edit Quick Reply` : `Add Quick Reply`
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `grid`,
          gridTemplateColumns: `1fr 1fr`,
          gap: 12,
          marginBottom: 12
        },
        children: [(0, F.jsx)(G, {
          label: `Title`,
          required: !0,
          style: {
            marginBottom: 0
          },
          children: (0, F.jsx)(K, {
            value: s.title,
            onChange: e => c(t => ({
              ...t,
              title: e
            })),
            placeholder: `e.g. Documents Pending`
          })
        }), (0, F.jsx)(G, {
          label: `Category`,
          style: {
            marginBottom: 0
          },
          children: (0, F.jsx)(`select`, {
            value: s.category,
            onChange: e => c(t => ({
              ...t,
              category: e.target.value
            })),
            style: {
              padding: `9px 13px`,
              fontSize: 14,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              fontFamily: `inherit`,
              outline: `none`,
              width: `100%`,
              appearance: `none`,
              cursor: `pointer`,
              boxSizing: `border-box`
            },
            children: Po.map(e => (0, F.jsx)(`option`, {
              value: e.toLowerCase(),
              children: e
            }, e))
          })
        })]
      }), (0, F.jsx)(G, {
        label: `Message content`,
        required: !0,
        style: {
          marginBottom: 12
        },
        children: (0, F.jsx)(K, {
          value: s.content,
          onChange: e => c(t => ({
            ...t,
            content: e
          })),
          as: `textarea`,
          rows: 4,
          placeholder: `Type the quick reply message. Use {CUSTOMER_NAME}, {BOOKING_REF} etc.`
        })
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          gap: 8
        },
        children: [(0, F.jsx)(z, {
          size: `sm`,
          loading: l,
          icon: (0, F.jsx)(Si, {
            size: 13
          }),
          onClick: f,
          children: a ? `Update` : `Add Reply`
        }), a && (0, F.jsx)(z, {
          size: `sm`,
          variant: `ghost`,
          onClick: h,
          children: `Cancel`
        })]
      })]
    }), r ? (0, F.jsx)(`div`, {
      style: {
        textAlign: `center`,
        padding: 32
      },
      children: (0, F.jsx)(Wi, {
        size: 20
      })
    }) : t.length === 0 ? (0, F.jsx)(Qi, {
      icon: `💬`,
      title: `No quick replies yet`,
      desc: `Add preset messages to use in the communication panel.`
    }) : Po.map(e => {
      let t = g[e.toLowerCase()] || [];
      return t.length ? (0, F.jsxs)(`div`, {
        style: {
          marginBottom: 20
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            fontSize: 11,
            fontWeight: 700,
            color: `var(--muted)`,
            textTransform: `uppercase`,
            letterSpacing: `.06em`,
            marginBottom: 8
          },
          children: e
        }), t.map(e => (0, F.jsxs)(`div`, {
          style: {
            border: `1px solid var(--border)`,
            borderRadius: `var(--r)`,
            padding: `12px 14px`,
            marginBottom: 8,
            background: `#fff`,
            display: `flex`,
            justifyContent: `space-between`,
            alignItems: `flex-start`,
            gap: 10
          },
          children: [(0, F.jsxs)(`div`, {
            style: {
              flex: 1,
              minWidth: 0
            },
            children: [(0, F.jsx)(`div`, {
              style: {
                fontWeight: 600,
                fontSize: 13,
                marginBottom: 4
              },
              children: e.title
            }), (0, F.jsx)(`div`, {
              style: {
                fontSize: 12,
                color: `var(--muted)`,
                lineHeight: 1.5
              },
              children: e.content
            })]
          }), (0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              gap: 6,
              flexShrink: 0
            },
            children: [(0, F.jsx)(`button`, {
              onClick: () => m(e),
              style: {
                background: `none`,
                border: `none`,
                cursor: `pointer`,
                color: jo,
                fontSize: 12,
                fontWeight: 600,
                padding: `3px 8px`,
                border: `1px solid ${jo}`,
                borderRadius: `var(--r-sm)`
              },
              children: `Edit`
            }), (0, F.jsx)(`button`, {
              onClick: () => p(e.id),
              style: {
                background: `none`,
                border: `1px solid var(--red-border)`,
                cursor: `pointer`,
                color: `var(--red)`,
                fontSize: 12,
                fontWeight: 600,
                padding: `3px 8px`,
                borderRadius: `var(--r-sm)`
              },
              children: `Delete`
            })]
          })]
        }, e.id))]
      }, e) : null
    })]
  })
}

function Bo() {
  let e = R(),
    [t, n] = (0, _.useState)(new Date().getFullYear()),
    [r, i] = (0, _.useState)([]),
    [a, o] = (0, _.useState)(!0),
    [s, c] = (0, _.useState)({
      holiday_date: ``,
      holiday_name: ``,
      holiday_type: `national`
    }),
    [l, u] = (0, _.useState)(!1),
    [d, f] = (0, _.useState)(`30`),
    [p, m] = (0, _.useState)(new Date().toISOString().slice(0, 10)),
    [h, g] = (0, _.useState)(null),
    [v, y] = (0, _.useState)(!1),
    b = (0, _.useCallback)(async () => {
      o(!0);
      try {
        i((await _r.list(t)).holidays || [])
      } catch {
        e(`Failed to load holidays`, `error`)
      } finally {
        o(!1)
      }
    }, [t]);
  (0, _.useEffect)(() => {
    b()
  }, [b]);
  async function x() {
    if (!s.holiday_date || !s.holiday_name) {
      e(`Date and name required`, `error`);
      return
    }
    u(!0);
    try {
      await _r.create(s), e(`Holiday added`, `success`), c({
        holiday_date: ``,
        holiday_name: ``,
        holiday_type: `national`
      }), await b()
    } catch (t) {
      e(t.message || `Failed`, `error`)
    } finally {
      u(!1)
    }
  }
  async function S(t) {
    if (window.confirm(`Remove this holiday?`)) try {
      await _r.del(t), e(`Removed`, `success`), await b()
    } catch (t) {
      e(t.message || `Failed`, `error`)
    }
  }
  async function C() {
    y(!0);
    try {
      g(await _r.calculate({
        working_days: parseInt(d) || 30,
        from_date: p
      }))
    } catch (t) {
      e(t.message || `Calculation failed`, `error`)
    } finally {
      y(!1)
    }
  }
  let w = {
      national: {
        bg: `var(--red-bg)`,
        color: `var(--red)`
      },
      state: {
        bg: `var(--brand-light)`,
        color: `var(--brand)`
      },
      university: {
        bg: `var(--purple-bg)`,
        color: `var(--purple)`
      }
    },
    T = {};
  return r.forEach(e => {
    let t = new Date(e.holiday_date).getMonth();
    T[t] || (T[t] = []), T[t].push(e)
  }), (0, F.jsxs)(`div`, {
    children: [(0, F.jsxs)(`div`, {
      style: {
        marginBottom: 20,
        padding: 20,
        background: `var(--surface-2)`,
        border: `1px solid var(--border)`,
        borderRadius: `var(--r-lg)`
      },
      children: [(0, F.jsx)(`div`, {
        style: {
          fontSize: 14,
          fontWeight: 700,
          marginBottom: 14
        },
        children: `Add Holiday`
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `grid`,
          gridTemplateColumns: `1fr 1fr 1fr auto`,
          gap: 10,
          alignItems: `flex-end`
        },
        children: [(0, F.jsx)(G, {
          label: `Date`,
          required: !0,
          style: {
            marginBottom: 0
          },
          children: (0, F.jsx)(K, {
            type: `date`,
            value: s.holiday_date,
            onChange: e => c(t => ({
              ...t,
              holiday_date: e
            }))
          })
        }), (0, F.jsx)(G, {
          label: `Name`,
          required: !0,
          style: {
            marginBottom: 0
          },
          children: (0, F.jsx)(K, {
            value: s.holiday_name,
            onChange: e => c(t => ({
              ...t,
              holiday_name: e
            })),
            placeholder: `e.g. Republic Day`
          })
        }), (0, F.jsx)(G, {
          label: `Type`,
          style: {
            marginBottom: 0
          },
          children: (0, F.jsx)(`select`, {
            value: s.holiday_type,
            onChange: e => c(t => ({
              ...t,
              holiday_type: e.target.value
            })),
            style: {
              padding: `9px 13px`,
              fontSize: 14,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              fontFamily: `inherit`,
              outline: `none`,
              appearance: `none`,
              cursor: `pointer`,
              boxSizing: `border-box`
            },
            children: Fo.map(e => (0, F.jsx)(`option`, {
              value: e.toLowerCase(),
              children: e
            }, e))
          })
        }), (0, F.jsx)(z, {
          size: `sm`,
          loading: l,
          icon: (0, F.jsx)(yi, {
            size: 13
          }),
          onClick: x,
          style: {
            marginBottom: 0,
            flexShrink: 0,
            alignSelf: `flex-end`,
            padding: `10px 16px`
          },
          children: `Add`
        })]
      })]
    }), (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        marginBottom: 16
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          fontWeight: 700,
          fontSize: 16
        },
        children: [t, ` Holidays (`, r.length, `)`]
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          gap: 8
        },
        children: [(0, F.jsxs)(`button`, {
          onClick: () => n(e => e - 1),
          style: {
            padding: `5px 12px`,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r-sm)`,
            background: `#fff`,
            cursor: `pointer`,
            fontSize: 13
          },
          children: [`← `, t - 1]
        }), (0, F.jsx)(`button`, {
          onClick: () => n(new Date().getFullYear()),
          style: {
            padding: `5px 12px`,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r-sm)`,
            background: `#fff`,
            cursor: `pointer`,
            fontSize: 13
          },
          children: `Today`
        }), (0, F.jsxs)(`button`, {
          onClick: () => n(e => e + 1),
          style: {
            padding: `5px 12px`,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r-sm)`,
            background: `#fff`,
            cursor: `pointer`,
            fontSize: 13
          },
          children: [t + 1, ` →`]
        })]
      })]
    }), a ? (0, F.jsx)(`div`, {
      style: {
        textAlign: `center`,
        padding: 32
      },
      children: (0, F.jsx)(Wi, {
        size: 20
      })
    }) : r.length === 0 ? (0, F.jsx)(Qi, {
      icon: `📅`,
      title: `No holidays for ${t}`,
      desc: `Add public holidays above.`
    }) : Object.entries(T).sort(([e], [t]) => e - t).map(([e, t]) => (0, F.jsxs)(`div`, {
      style: {
        marginBottom: 16
      },
      children: [(0, F.jsx)(`div`, {
        style: {
          fontSize: 11,
          fontWeight: 700,
          color: `var(--muted)`,
          textTransform: `uppercase`,
          letterSpacing: `.06em`,
          marginBottom: 6
        },
        children: Io[parseInt(e)]
      }), t.map(e => {
        let t = w[e.holiday_type] || w.national,
          n = new Date(e.holiday_date),
          r = [`Sun`, `Mon`, `Tue`, `Wed`, `Thu`, `Fri`, `Sat`][n.getDay()];
        return (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            justifyContent: `space-between`,
            padding: `10px 14px`,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r)`,
            background: `#fff`,
            marginBottom: 6
          },
          children: [(0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              alignItems: `center`,
              gap: 12
            },
            children: [(0, F.jsxs)(`div`, {
              style: {
                textAlign: `center`,
                minWidth: 36
              },
              children: [(0, F.jsx)(`div`, {
                style: {
                  fontSize: 18,
                  fontWeight: 800,
                  lineHeight: 1
                },
                children: String(n.getDate()).padStart(2, `0`)
              }), (0, F.jsx)(`div`, {
                style: {
                  fontSize: 10,
                  color: `var(--muted)`
                },
                children: r
              })]
            }), (0, F.jsxs)(`div`, {
              children: [(0, F.jsx)(`div`, {
                style: {
                  fontWeight: 600,
                  fontSize: 13
                },
                children: e.holiday_name
              }), (0, F.jsx)(`span`, {
                style: {
                  fontSize: 11,
                  padding: `1px 7px`,
                  borderRadius: `var(--r-full)`,
                  fontWeight: 600,
                  ...t
                },
                children: e.holiday_type
              })]
            })]
          }), (0, F.jsx)(`button`, {
            onClick: () => S(e.id),
            style: {
              background: `none`,
              border: `none`,
              cursor: `pointer`,
              color: `var(--red)`,
              fontSize: 18,
              padding: `2px 6px`
            },
            children: `🗑`
          })]
        }, e.id)
      })]
    }, e)), (0, F.jsxs)(`div`, {
      style: {
        marginTop: 28,
        padding: 20,
        background: `var(--surface-2)`,
        border: `1px solid var(--border)`,
        borderRadius: `var(--r-lg)`
      },
      children: [(0, F.jsxs)(`div`, {
        style: {
          fontSize: 14,
          fontWeight: 700,
          marginBottom: 4,
          display: `flex`,
          alignItems: `center`,
          gap: 8
        },
        children: [(0, F.jsx)(Wr, {
          size: 16,
          style: {
            color: jo
          }
        }), ` Delivery Date Calculator`]
      }), (0, F.jsx)(`div`, {
        style: {
          fontSize: 13,
          color: `var(--muted)`,
          marginBottom: 14
        },
        children: `Calculate the expected delivery date based on working days, excluding weekends and the holidays above.`
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `grid`,
          gridTemplateColumns: `1fr 1fr auto`,
          gap: 10,
          alignItems: `flex-end`
        },
        children: [(0, F.jsx)(G, {
          label: `From date`,
          style: {
            marginBottom: 0
          },
          children: (0, F.jsx)(K, {
            type: `date`,
            value: p,
            onChange: m
          })
        }), (0, F.jsx)(G, {
          label: `Working days`,
          style: {
            marginBottom: 0
          },
          children: (0, F.jsx)(K, {
            type: `number`,
            value: d,
            onChange: f,
            placeholder: `30`,
            min: `1`,
            max: `365`
          })
        }), (0, F.jsx)(z, {
          size: `sm`,
          loading: v,
          icon: (0, F.jsx)(Wr, {
            size: 13
          }),
          onClick: C,
          style: {
            flexShrink: 0,
            alignSelf: `flex-end`,
            padding: `10px 16px`
          },
          children: `Calculate`
        })]
      }), h && (0, F.jsx)(`div`, {
        style: {
          marginTop: 16,
          padding: 16,
          background: `#fff`,
          border: `1px solid var(--green-border)`,
          borderRadius: `var(--r)`
        },
        children: (0, F.jsx)(`div`, {
          style: {
            display: `grid`,
            gridTemplateColumns: `1fr 1fr 1fr 1fr`,
            gap: 12
          },
          children: [
            [`Delivery Date`, h.delivery_date || `—`],
            [`Working Days`, h.working_days || d],
            [`Calendar Days`, h.calendar_days || `—`],
            [`Holidays Excluded`, h.holidays_excluded ?? `—`]
          ].map(([e, t]) => (0, F.jsxs)(`div`, {
            style: {
              textAlign: `center`
            },
            children: [(0, F.jsx)(`div`, {
              style: {
                fontSize: 11,
                fontWeight: 700,
                color: `var(--muted)`,
                textTransform: `uppercase`,
                letterSpacing: `.05em`,
                marginBottom: 4
              },
              children: e
            }), (0, F.jsx)(`div`, {
              style: {
                fontSize: 15,
                fontWeight: 800,
                color: e === `Delivery Date` ? jo : `var(--text)`
              },
              children: t
            })]
          }, e))
        })
      })]
    })]
  })
}
var Vo = [{
  key: `platform`,
  label: `⚙ Platform`,
  icon: (0, F.jsx)(Ei, {
    size: 14
  })
}, {
  key: `smtp`,
  label: `📧 Email / SMTP`,
  icon: (0, F.jsx)(pi, {
    size: 14
  })
}, {
  key: `templates`,
  label: `📋 Email Templates`,
  icon: (0, F.jsx)(pi, {
    size: 14
  })
}, {
  key: `replies`,
  label: `💬 Quick Replies`,
  icon: (0, F.jsx)(hi, {
    size: 14
  })
}, {
  key: `holidays`,
  label: `📅 Holidays`,
  icon: (0, F.jsx)(Gr, {
    size: 14
  })
}, {
  key: `whatsapp`,
  label: `📱 WhatsApp`,
  icon: (0, F.jsx)(Ri, {
    size: 14
  })
}, {
  key: `payment`,
  label: `💳 Payment`,
  icon: (0, F.jsx)(ri, {
    size: 14
  })
}];

function Ho() {
  let e = R(),
    [t, n] = (0, _.useState)(null),
    [r, i] = (0, _.useState)(!0),
    [a, o] = (0, _.useState)({}),
    [s, c] = (0, _.useState)(`platform`),
    [l, u] = (0, _.useState)(``),
    [d, f] = (0, _.useState)(!1),
    p = (0, _.useCallback)(async () => {
      i(!0);
      try {
        let e = await pr.getAll();
        n(e.settings || e)
      } catch {
        e(`Failed to load settings`, `error`)
      } finally {
        i(!1)
      }
    }, []);
  (0, _.useEffect)(() => {
    p()
  }, [p]);

  function m(e) {
    return t => n(n => ({
      ...n,
      [e]: t
    }))
  }
  async function h(n, r) {
    o(e => ({
      ...e,
      [n]: !0
    }));
    try {
      let n = {};
      r.forEach(e => {
        t?.[e] !== void 0 && (n[e] = t[e])
      }), await pr.update(n), e(`Settings saved`, `success`)
    } catch (t) {
      e(t.message || `Save failed`, `error`)
    } finally {
      o(e => ({
        ...e,
        [n]: !1
      }))
    }
  }
  async function g() {
    if (!l) return e(`Enter a test email address`, `error`);
    f(!0);
    try {
      e((await pr.smtpTest(l)).message || `Test email sent`, `success`)
    } catch (t) {
      e(t.message || `SMTP test failed`, `error`)
    } finally {
      f(!1)
    }
  }
  let v = ({
    group: e,
    keys: t,
    label: n
  }) => (0, F.jsx)(`div`, {
    style: {
      paddingTop: 8
    },
    children: (0, F.jsx)(z, {
      loading: a[e],
      onClick: () => h(e, t),
      icon: (0, F.jsx)(Si, {
        size: 15
      }),
      children: n || `Save changes`
    })
  });
  return (0, F.jsxs)(`div`, {
    children: [(0, F.jsxs)(`div`, {
      style: {
        marginBottom: 24
      },
      children: [(0, F.jsx)(`h1`, {
        style: {
          fontSize: 22,
          fontWeight: 800
        },
        children: `Settings`
      }), (0, F.jsx)(`p`, {
        style: {
          fontSize: 14,
          color: `var(--muted)`,
          marginTop: 3
        },
        children: `Configure platform behaviour`
      })]
    }), (0, F.jsx)(`div`, {
      style: {
        display: `flex`,
        borderBottom: `2px solid var(--border)`,
        overflowX: `auto`,
        background: `var(--surface)`,
        marginBottom: 0,
        border: `1px solid var(--border)`,
        borderRadius: `var(--r-lg) var(--r-lg) 0 0`
      },
      children: Vo.map(e => (0, F.jsx)(`button`, {
        onClick: () => c(e.key),
        style: {
          padding: `12px 18px`,
          fontSize: 13,
          fontWeight: 600,
          whiteSpace: `nowrap`,
          background: `none`,
          border: `none`,
          cursor: `pointer`,
          color: s === e.key ? jo : `var(--muted)`,
          borderBottom: `2px solid ${s===e.key?jo:`transparent`}`,
          marginBottom: -1,
          transition: `var(--t)`
        },
        children: e.label
      }, e.key))
    }), (0, F.jsx)(`div`, {
      style: {
        background: `#fff`,
        border: `1px solid var(--border)`,
        borderTop: `none`,
        borderRadius: `0 0 var(--r-lg) var(--r-lg)`,
        padding: [`templates`, `replies`, `holidays`].includes(s) ? 0 : 24
      },
      children: r && s !== `templates` && s !== `replies` && s !== `holidays` ? (0, F.jsx)(`div`, {
        style: {
          textAlign: `center`,
          padding: 40
        },
        children: (0, F.jsx)(Wi, {
          size: 24
        })
      }) : (0, F.jsxs)(F.Fragment, {
        children: [s === `platform` && (0, F.jsxs)(`div`, {
          children: [(0, F.jsx)(G, {
            label: `Platform name`,
            children: (0, F.jsx)(K, {
              value: t?.platform_name,
              onChange: m(`platform_name`),
              placeholder: `Services2NRI`
            })
          }), (0, F.jsx)(G, {
            label: `Support email`,
            children: (0, F.jsx)(K, {
              value: t?.support_email,
              onChange: m(`support_email`),
              type: `email`,
              placeholder: `support@example.com`
            })
          }), (0, F.jsx)(G, {
            label: `Support phone`,
            children: (0, F.jsx)(K, {
              value: t?.support_phone,
              onChange: m(`support_phone`),
              placeholder: `+91 98765 43210`
            })
          }), (0, F.jsx)(G, {
            label: `Manager name`,
            hint: `Shown on customer emails when no manager is assigned`,
            children: (0, F.jsx)(K, {
              value: t?.manager_name,
              onChange: m(`manager_name`),
              placeholder: `NRI Support Team`
            })
          }), (0, F.jsx)(G, {
            label: `Manager email`,
            children: (0, F.jsx)(K, {
              value: t?.manager_email,
              onChange: m(`manager_email`),
              type: `email`
            })
          }), (0, F.jsx)(v, {
            group: `platform`,
            keys: [`platform_name`, `support_email`, `support_phone`, `manager_name`, `manager_email`]
          })]
        }), s === `smtp` && (0, F.jsxs)(`div`, {
          children: [(0, F.jsx)(G, {
            label: `From name`,
            children: (0, F.jsx)(K, {
              value: t?.smtp_from_name,
              onChange: m(`smtp_from_name`),
              placeholder: `Services2NRI`
            })
          }), (0, F.jsx)(G, {
            label: `From email`,
            children: (0, F.jsx)(K, {
              value: t?.smtp_from_email,
              onChange: m(`smtp_from_email`),
              type: `email`,
              placeholder: `noreply@example.com`
            })
          }), (0, F.jsx)(G, {
            label: `SMTP host`,
            children: (0, F.jsx)(K, {
              value: t?.smtp_host,
              onChange: m(`smtp_host`),
              placeholder: `smtp.gmail.com`
            })
          }), (0, F.jsxs)(`div`, {
            style: {
              display: `grid`,
              gridTemplateColumns: `1fr 1fr`,
              gap: 12
            },
            children: [(0, F.jsx)(G, {
              label: `Port`,
              children: (0, F.jsx)(K, {
                value: t?.smtp_port,
                onChange: m(`smtp_port`),
                type: `number`,
                placeholder: `587`
              })
            }), (0, F.jsx)(G, {
              label: `Encryption`,
              children: (0, F.jsxs)(`select`, {
                value: t?.smtp_encryption || `tls`,
                onChange: e => m(`smtp_encryption`)(e.target.value),
                style: {
                  padding: `9px 13px`,
                  fontSize: 14,
                  border: `1px solid var(--border)`,
                  borderRadius: `var(--r)`,
                  fontFamily: `inherit`,
                  outline: `none`,
                  appearance: `none`,
                  cursor: `pointer`,
                  width: `100%`,
                  boxSizing: `border-box`
                },
                children: [(0, F.jsx)(`option`, {
                  value: `tls`,
                  children: `TLS`
                }), (0, F.jsx)(`option`, {
                  value: `ssl`,
                  children: `SSL`
                }), (0, F.jsx)(`option`, {
                  value: `none`,
                  children: `None`
                })]
              })
            })]
          }), (0, F.jsx)(G, {
            label: `SMTP username`,
            children: (0, F.jsx)(K, {
              value: t?.smtp_username,
              onChange: m(`smtp_username`),
              placeholder: `your@email.com`
            })
          }), (0, F.jsx)(G, {
            label: `SMTP password`,
            children: (0, F.jsx)(K, {
              value: t?.smtp_password,
              onChange: m(`smtp_password`),
              type: `password`,
              placeholder: `••••••••`
            })
          }), (0, F.jsx)(v, {
            group: `smtp`,
            keys: [`smtp_from_name`, `smtp_from_email`, `smtp_host`, `smtp_port`, `smtp_encryption`, `smtp_username`, `smtp_password`]
          }), (0, F.jsxs)(`div`, {
            style: {
              marginTop: 20,
              paddingTop: 20,
              borderTop: `1px solid var(--border)`
            },
            children: [(0, F.jsx)(`div`, {
              style: {
                fontSize: 14,
                fontWeight: 700,
                marginBottom: 12
              },
              children: `Test connection`
            }), (0, F.jsxs)(`div`, {
              style: {
                display: `flex`,
                gap: 10
              },
              children: [(0, F.jsx)(K, {
                value: l,
                onChange: u,
                type: `email`,
                placeholder: `Send test to this address…`,
                style: {
                  flex: 1
                }
              }), (0, F.jsx)(z, {
                loading: d,
                onClick: g,
                icon: (0, F.jsx)(wi, {
                  size: 14
                }),
                style: {
                  flexShrink: 0
                },
                children: `Send Test`
              })]
            })]
          })]
        }), s === `templates` && (0, F.jsx)(Lo, {}), s === `replies` && (0, F.jsxs)(`div`, {
          style: {
            padding: 24
          },
          children: [(0, F.jsxs)(`div`, {
            style: {
              marginBottom: 20
            },
            children: [(0, F.jsx)(`div`, {
              style: {
                fontSize: 15,
                fontWeight: 700
              },
              children: `Quick Replies`
            }), (0, F.jsx)(`div`, {
              style: {
                fontSize: 13,
                color: `var(--muted)`,
                marginTop: 3
              },
              children: `Preset messages that appear as one-click buttons in the communication panel.`
            })]
          }), (0, F.jsx)(zo, {})]
        }), s === `holidays` && (0, F.jsxs)(`div`, {
          style: {
            padding: 24
          },
          children: [(0, F.jsxs)(`div`, {
            style: {
              marginBottom: 20
            },
            children: [(0, F.jsx)(`div`, {
              style: {
                fontSize: 15,
                fontWeight: 700
              },
              children: `Holidays & Delivery Calculator`
            }), (0, F.jsx)(`div`, {
              style: {
                fontSize: 13,
                color: `var(--muted)`,
                marginTop: 3
              },
              children: `Public holidays are excluded when calculating working-day delivery timelines.`
            })]
          }), (0, F.jsx)(Bo, {})]
        }), s === `whatsapp` && (0, F.jsxs)(`div`, {
          children: [(0, F.jsxs)(`div`, {
            style: {
              background: `var(--green-bg)`,
              border: `1px solid var(--green-border)`,
              borderRadius: `var(--r)`,
              padding: `12px 14px`,
              marginBottom: 20,
              fontSize: 13
            },
            children: [`Uses `, (0, F.jsx)(`strong`, {
              children: `CallMeBot`
            }), ` for WhatsApp notifications. Register at callmebot.com to get your API key.`]
          }), (0, F.jsx)(G, {
            label: `WhatsApp phone number`,
            hint: `Include country code e.g. +919876543210`,
            children: (0, F.jsx)(K, {
              value: t?.whatsapp_phone,
              onChange: m(`whatsapp_phone`),
              placeholder: `+919876543210`
            })
          }), (0, F.jsx)(G, {
            label: `CallMeBot API key`,
            children: (0, F.jsx)(K, {
              value: t?.callmebot_api_key,
              onChange: m(`callmebot_api_key`)
            })
          }), (0, F.jsx)(G, {
            label: `Notify on`,
            children: (0, F.jsx)(`div`, {
              style: {
                display: `flex`,
                flexDirection: `column`,
                gap: 10
              },
              children: [
                [`whatsapp_notify_submission`, `New booking submitted`],
                [`whatsapp_notify_quote_approved`, `Quote approved by customer`],
                [`whatsapp_notify_payment`, `Payment received`]
              ].map(([e, n]) => (0, F.jsx)(Mo, {
                value: t?.[e] === `1`,
                onChange: t => m(e)(t ? `1` : `0`),
                label: n
              }, e))
            })
          }), (0, F.jsx)(v, {
            group: `whatsapp`,
            keys: [`whatsapp_phone`, `callmebot_api_key`, `whatsapp_notify_submission`, `whatsapp_notify_quote_approved`, `whatsapp_notify_payment`]
          })]
        }), s === `payment` && (0, F.jsxs)(`div`, {
          children: [(0, F.jsx)(G, {
            label: `Razorpay Key ID`,
            children: (0, F.jsx)(K, {
              value: t?.razorpay_key_id,
              onChange: m(`razorpay_key_id`),
              placeholder: `rzp_live_…`
            })
          }), (0, F.jsx)(G, {
            label: `Razorpay Key Secret`,
            children: (0, F.jsx)(K, {
              value: t?.razorpay_key_secret,
              onChange: m(`razorpay_key_secret`),
              type: `password`
            })
          }), (0, F.jsx)(G, {
            label: `Currency`,
            children: (0, F.jsx)(K, {
              value: t?.currency || `INR`,
              onChange: m(`currency`),
              placeholder: `INR`
            })
          }), (0, F.jsx)(G, {
            label: `Bank transfer instructions`,
            children: (0, F.jsx)(K, {
              value: t?.bank_transfer_instructions,
              onChange: m(`bank_transfer_instructions`),
              as: `textarea`,
              rows: 4,
              placeholder: `Bank: HDFC
Account: 123
IFSC: HDFC001`
            })
          }), (0, F.jsx)(G, {
            label: `Payment terms`,
            hint: `Appended to quotation emails when 'Include T&C' is checked`,
            children: (0, F.jsx)(K, {
              value: t?.payment_terms,
              onChange: m(`payment_terms`),
              as: `textarea`,
              rows: 3,
              placeholder: `Payment due within 7 days of quote acceptance.`
            })
          }), (0, F.jsx)(v, {
            group: `payment`,
            keys: [`razorpay_key_id`, `razorpay_key_secret`, `currency`, `bank_transfer_instructions`, `payment_terms`]
          })]
        })]
      })
    })]
  })
}

function Uo({
  status: e
}) {
  return e === `pass` || e === `ok` || e === `healthy` ? (0, F.jsx)(Qr, {
    size: 18,
    color: `var(--green)`
  }) : e === `fail` || e === `error` || e === `critical` ? (0, F.jsx)($r, {
    size: 18,
    color: `var(--red)`
  }) : e === `warn` || e === `warning` ? (0, F.jsx)(Ni, {
    size: 18,
    color: `var(--amber)`
  }) : (0, F.jsx)(ti, {
    size: 18,
    color: `var(--muted)`
  })
}

function Wo(e) {
  return e === `pass` || e === `ok` || e === `healthy` ? {
    bg: `var(--green-bg)`,
    border: `var(--green-border)`,
    color: `var(--green-dark)`
  } : e === `fail` || e === `error` || e === `critical` ? {
    bg: `var(--red-bg)`,
    border: `var(--red-border)`,
    color: `var(--red-dark)`
  } : e === `warn` || e === `warning` ? {
    bg: `var(--amber-bg)`,
    border: `var(--amber-border)`,
    color: `var(--amber-dark)`
  } : {
    bg: `var(--surface-2)`,
    border: `var(--border)`,
    color: `var(--muted)`
  }
}

function Go({
  check: e
}) {
  let t = (e.status || `unknown`).toLowerCase(),
    n = Wo(t);
  return (0, F.jsx)(`div`, {
    style: {
      background: `#fff`,
      border: `1px solid ${n.border}`,
      borderRadius: `var(--r-lg)`,
      padding: `16px 18px`,
      borderLeft: `4px solid ${n.border}`
    },
    children: (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `flex-start`,
        gap: 12
      },
      children: [(0, F.jsx)(`div`, {
        style: {
          marginTop: 1
        },
        children: (0, F.jsx)(Uo, {
          status: t
        })
      }), (0, F.jsxs)(`div`, {
        style: {
          flex: 1,
          minWidth: 0
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            fontWeight: 700,
            fontSize: 14,
            color: `var(--text)`,
            marginBottom: 3
          },
          children: e.label || e.name || e.check
        }), e.message && (0, F.jsx)(`div`, {
          style: {
            fontSize: 13,
            color: `var(--text-2)`,
            lineHeight: 1.5,
            marginBottom: e.detail ? 8 : 0
          },
          children: e.message
        }), e.detail && (0, F.jsx)(`div`, {
          style: {
            fontSize: 12,
            color: n.color,
            background: n.bg,
            borderRadius: `var(--r)`,
            padding: `6px 10px`,
            fontFamily: `monospace`,
            wordBreak: `break-word`
          },
          children: e.detail
        }), e.value != null && (0, F.jsxs)(`div`, {
          style: {
            fontSize: 13,
            color: `var(--muted)`,
            marginTop: 4
          },
          children: [`Value: `, (0, F.jsx)(`strong`, {
            children: String(e.value)
          }), e.threshold && (0, F.jsxs)(`span`, {
            style: {
              marginLeft: 6
            },
            children: [`· Threshold: `, e.threshold]
          })]
        })]
      }), (0, F.jsx)(`span`, {
        style: {
          fontSize: 11,
          fontWeight: 700,
          textTransform: `uppercase`,
          letterSpacing: `.05em`,
          padding: `3px 10px`,
          borderRadius: `var(--r-full)`,
          background: n.bg,
          color: n.color,
          flexShrink: 0
        },
        children: t
      })]
    })
  })
}

function Ko() {
  let [e, t] = (0, _.useState)(null), [n, r] = (0, _.useState)(!0), [i, a] = (0, _.useState)(!1), o = (0, _.useCallback)(async (e = !1) => {
    e ? a(!0) : r(!0);
    try {
      t(await mr.health())
    } catch {} finally {
      r(!1), a(!1)
    }
  }, []);
  (0, _.useEffect)(() => {
    o()
  }, [o]);
  let s = e?.checks || [],
    c = s.filter(e => [`pass`, `ok`, `healthy`].includes((e.status || ``).toLowerCase())).length,
    l = s.filter(e => [`fail`, `error`, `critical`].includes((e.status || ``).toLowerCase())).length,
    u = s.filter(e => [`warn`, `warning`].includes((e.status || ``).toLowerCase())).length,
    d = l > 0 ? `critical` : u > 0 ? `warn` : `pass`;
  return (0, F.jsxs)(`div`, {
    style: {
      display: `flex`,
      flexDirection: `column`,
      gap: 20
    },
    children: [(0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        flexWrap: `wrap`,
        gap: 12
      },
      children: [(0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(`h1`, {
          style: {
            fontSize: 22,
            fontWeight: 800
          },
          children: `System Health`
        }), (0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`,
            marginTop: 3
          },
          children: e?.checked_at ? `Last checked: ${new Date(e.checked_at).toLocaleString(`en-IN`)}` : `Platform diagnostics`
        })]
      }), (0, F.jsx)(z, {
        variant: `secondary`,
        loading: i,
        icon: (0, F.jsx)(bi, {
          size: 15
        }),
        onClick: () => o(!0),
        children: `Re-run checks`
      })]
    }), !n && s.length > 0 && (0, F.jsx)(B, {
      style: {
        background: d === `pass` ? `var(--green-bg)` : d === `critical` ? `var(--red-bg)` : `var(--amber-bg)`,
        border: `1px solid ${d===`pass`?`var(--green-border)`:d===`critical`?`var(--red-border)`:`var(--amber-border)`}`
      },
      children: (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          alignItems: `center`,
          gap: 14,
          flexWrap: `wrap`
        },
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            alignItems: `center`,
            gap: 8
          },
          children: [(0, F.jsx)(Uo, {
            status: d
          }), (0, F.jsx)(`span`, {
            style: {
              fontWeight: 800,
              fontSize: 16,
              color: d === `pass` ? `var(--green-dark)` : d === `critical` ? `var(--red-dark)` : `var(--amber-dark)`
            },
            children: d === `pass` ? `All systems operational` : d === `critical` ? `${l} check${l===1?``:`s`} failing` : `${u} warning${u===1?``:`s`}`
          })]
        }), (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            gap: 16,
            marginLeft: `auto`,
            fontSize: 13
          },
          children: [(0, F.jsxs)(`span`, {
            style: {
              color: `var(--green-dark)`,
              fontWeight: 600
            },
            children: [`✓ `, c, ` passing`]
          }), u > 0 && (0, F.jsxs)(`span`, {
            style: {
              color: `var(--amber-dark)`,
              fontWeight: 600
            },
            children: [`⚠ `, u, ` warning`]
          }), l > 0 && (0, F.jsxs)(`span`, {
            style: {
              color: `var(--red-dark)`,
              fontWeight: 600
            },
            children: [`✗ `, l, ` failing`]
          })]
        })]
      })
    }), n ? (0, F.jsx)(`div`, {
      style: {
        display: `grid`,
        gridTemplateColumns: `repeat(auto-fill, minmax(320px, 1fr))`,
        gap: 14
      },
      children: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(e => (0, F.jsx)(na, {
        h: 90
      }, e))
    }) : s.length === 0 ? (0, F.jsx)(B, {
      children: (0, F.jsxs)(`div`, {
        style: {
          textAlign: `center`,
          padding: `40px 24px`,
          color: `var(--muted)`
        },
        children: [(0, F.jsx)(`div`, {
          style: {
            fontSize: 36,
            marginBottom: 12
          },
          children: `🔍`
        }), (0, F.jsx)(`div`, {
          style: {
            fontSize: 16,
            fontWeight: 700,
            color: `var(--text)`
          },
          children: `No health data`
        }), (0, F.jsx)(`div`, {
          style: {
            fontSize: 14,
            marginTop: 6
          },
          children: `Health check returned no results. Try re-running.`
        })]
      })
    }) : (0, F.jsx)(`div`, {
      style: {
        display: `grid`,
        gridTemplateColumns: `repeat(auto-fill, minmax(320px, 1fr))`,
        gap: 14
      },
      children: [...s.filter(e => [`fail`, `error`, `critical`].includes((e.status || ``).toLowerCase())), ...s.filter(e => [`warn`, `warning`].includes((e.status || ``).toLowerCase())), ...s.filter(e => ![`fail`, `error`, `critical`, `warn`, `warning`].includes((e.status || ``).toLowerCase()))].map((e, t) => (0, F.jsx)(Go, {
        check: e
      }, t))
    }), e?.system_info && (0, F.jsxs)(B, {
      children: [(0, F.jsx)(`h3`, {
        style: {
          fontSize: 14,
          marginBottom: 14
        },
        children: `System Information`
      }), (0, F.jsx)(`div`, {
        style: {
          display: `grid`,
          gridTemplateColumns: `repeat(auto-fill, minmax(200px, 1fr))`,
          gap: 10
        },
        children: Object.entries(e.system_info).map(([e, t]) => (0, F.jsxs)(`div`, {
          style: {
            background: `var(--surface-2)`,
            borderRadius: `var(--r)`,
            padding: `10px 12px`
          },
          children: [(0, F.jsx)(`div`, {
            style: {
              fontSize: 11,
              fontWeight: 700,
              color: `var(--muted)`,
              textTransform: `uppercase`,
              letterSpacing: `.04em`,
              marginBottom: 3
            },
            children: e.replace(/_/g, ` `).replace(/\b\w/g, e => e.toUpperCase())
          }), (0, F.jsx)(`div`, {
            style: {
              fontSize: 13,
              fontWeight: 600,
              fontFamily: `monospace`,
              color: `var(--text)`
            },
            children: String(t)
          })]
        }, e))
      })]
    })]
  })
}
var qo = `var(--brand)`;

function Jo(e) {
  return e ? new Date(e).toLocaleDateString(`en-IN`, {
    day: `numeric`,
    month: `short`,
    year: `numeric`
  }) : `—`
}

function Yo({
  bookingId: e,
  bookingRef: t
}) {
  let [n, r] = (0, _.useState)(!1), i = window.S2NRI_CFG || {}, a = i.base || ``;
  i.nonce;

  function o(t) {
    let n = `${a}/admin/form-submissions/${e}/export?format=${t}`,
      i = document.createElement(`a`);
    i.href = n, i.target = `_blank`, i.rel = `noopener noreferrer`, i.click(), r(!1)
  }
  return (0, F.jsxs)(`div`, {
    style: {
      position: `relative`,
      display: `inline-block`
    },
    children: [(0, F.jsxs)(z, {
      size: `sm`,
      variant: `outline`,
      icon: (0, F.jsx)(ai, {
        size: 13
      }),
      onClick: () => r(e => !e),
      style: {
        gap: 4
      },
      children: [`Export `, (0, F.jsx)(qr, {
        size: 11
      })]
    }), n && (0, F.jsxs)(F.Fragment, {
      children: [(0, F.jsx)(`div`, {
        onClick: () => r(!1),
        style: {
          position: `fixed`,
          inset: 0,
          zIndex: 100
        }
      }), (0, F.jsx)(`div`, {
        style: {
          position: `absolute`,
          right: 0,
          top: `calc(100% + 4px)`,
          zIndex: 200,
          background: `#fff`,
          border: `1px solid var(--border)`,
          borderRadius: `var(--r)`,
          boxShadow: `var(--shadow-md)`,
          minWidth: 150
        },
        children: [
          [`csv`, `📊 CSV Spreadsheet`],
          [`txt`, `📄 Plain Text`],
          [`html`, `🖨 Printable HTML`]
        ].map(([e, t]) => (0, F.jsx)(`button`, {
          onClick: () => o(e),
          style: {
            display: `block`,
            width: `100%`,
            textAlign: `left`,
            padding: `9px 14px`,
            fontSize: 13,
            fontFamily: `inherit`,
            background: `none`,
            border: `none`,
            cursor: `pointer`,
            color: `var(--text)`
          },
          onMouseEnter: e => e.target.style.background = `var(--surface-2)`,
          onMouseLeave: e => e.target.style.background = `none`,
          children: t
        }, e))
      })]
    })]
  })
}

function Xo({
  fields: e
}) {
  let [t, n] = (0, _.useState)(!1), r = Object.entries(e || {}).filter(([e]) => !e.startsWith(`__`));
  if (!r.length) return (0, F.jsx)(`span`, {
    style: {
      color: `var(--muted)`,
      fontSize: 12
    },
    children: `No form data`
  });
  let i = r.slice(0, 2).map(([e, t]) => `${e}: ${t}`).join(`, `);
  return (0, F.jsxs)(`div`, {
    children: [(0, F.jsx)(`div`, {
      style: {
        fontSize: 12,
        color: `var(--text-2)`,
        marginBottom: t ? 6 : 0
      },
      children: t ? null : (0, F.jsxs)(`span`, {
        style: {
          overflow: `hidden`,
          whiteSpace: `nowrap`,
          textOverflow: `ellipsis`,
          display: `block`,
          maxWidth: 300
        },
        children: [i, r.length > 2 ? ` +${r.length-2} more` : ``]
      })
    }), t && (0, F.jsx)(`div`, {
      style: {
        background: `var(--surface-2)`,
        borderRadius: `var(--r-sm)`,
        padding: `8px 10px`,
        marginBottom: 4
      },
      children: r.map(([e, t]) => (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          gap: 8,
          fontSize: 12,
          padding: `2px 0`,
          borderBottom: `1px solid var(--border)`
        },
        children: [(0, F.jsx)(`span`, {
          style: {
            fontWeight: 600,
            color: `var(--text-2)`,
            minWidth: 140,
            flexShrink: 0,
            textTransform: `capitalize`
          },
          children: e.replace(/_/g, ` `)
        }), (0, F.jsx)(`span`, {
          style: {
            color: `var(--text)`
          },
          children: String(t || `—`)
        })]
      }, e))
    }), (0, F.jsx)(`button`, {
      onClick: () => n(e => !e),
      style: {
        fontSize: 11,
        color: qo,
        background: `none`,
        border: `none`,
        cursor: `pointer`,
        padding: 0,
        fontFamily: `inherit`,
        fontWeight: 600
      },
      children: t ? `▲ Collapse` : `▼ View all fields`
    })]
  })
}

function Zo() {
  let e = R(),
    [t, n] = (0, _.useState)({
      rows: [],
      total: 0
    }),
    [r, i] = (0, _.useState)(!0),
    [a, o] = (0, _.useState)(``),
    [s, c] = (0, _.useState)(1),
    l = (0, _.useCallback)(async () => {
      i(!0);
      try {
        let e = await br.list({
          search: a,
          page: s,
          per_page: 20
        });
        n({
          rows: e.rows || [],
          total: e.total || 0
        })
      } catch (t) {
        e(t.message || `Failed to load`, `error`)
      } finally {
        i(!1)
      }
    }, [a, s]);
  (0, _.useEffect)(() => {
    l()
  }, [l]);
  let u = Math.max(1, Math.ceil(t.total / 20));
  return (0, F.jsxs)(`div`, {
    children: [(0, F.jsx)(`div`, {
      style: {
        marginBottom: 20,
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        flexWrap: `wrap`,
        gap: 12
      },
      children: (0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(`h1`, {
          style: {
            fontSize: 22,
            fontWeight: 800,
            margin: `0 0 4px`
          },
          children: `Form Submissions`
        }), (0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`,
            margin: 0
          },
          children: r ? `Loading…` : `${t.total} submission${t.total===1?``:`s`}`
        })]
      })
    }), (0, F.jsxs)(`div`, {
      style: {
        position: `relative`,
        marginBottom: 16,
        maxWidth: 400
      },
      children: [(0, F.jsx)(Ci, {
        size: 15,
        style: {
          position: `absolute`,
          left: 11,
          top: `50%`,
          transform: `translateY(-50%)`,
          color: `var(--muted)`,
          pointerEvents: `none`
        }
      }), (0, F.jsx)(`input`, {
        value: a,
        onChange: e => {
          o(e.target.value), c(1)
        },
        placeholder: `Search by reference, customer or service…`,
        style: {
          width: `100%`,
          padding: `9px 13px 9px 34px`,
          fontSize: 14,
          border: `1px solid var(--border)`,
          borderRadius: `var(--r)`,
          fontFamily: `inherit`,
          outline: `none`,
          boxSizing: `border-box`
        }
      })]
    }), (0, F.jsx)(B, {
      padding: `0`,
      style: {
        overflow: `hidden`
      },
      children: (0, F.jsx)(`div`, {
        style: {
          overflowX: `auto`
        },
        children: (0, F.jsxs)(`table`, {
          style: {
            width: `100%`,
            borderCollapse: `collapse`,
            fontSize: 13
          },
          children: [(0, F.jsx)(`thead`, {
            children: (0, F.jsx)(`tr`, {
              style: {
                background: `var(--surface-2)`
              },
              children: [`Reference`, `Customer`, `Service`, `Status`, `Submitted`, `Form Data`, `Export`].map(e => (0, F.jsx)(`th`, {
                style: {
                  padding: `10px 14px`,
                  textAlign: `left`,
                  fontSize: 11,
                  fontWeight: 700,
                  color: `var(--muted)`,
                  textTransform: `uppercase`,
                  letterSpacing: `.04em`,
                  borderBottom: `1px solid var(--border)`,
                  whiteSpace: `nowrap`
                },
                children: e
              }, e))
            })
          }), (0, F.jsx)(`tbody`, {
            children: r ? (0, F.jsx)(`tr`, {
              children: (0, F.jsx)(`td`, {
                colSpan: 7,
                style: {
                  padding: 48,
                  textAlign: `center`
                },
                children: (0, F.jsx)(Wi, {
                  size: 24
                })
              })
            }) : t.rows.length === 0 ? (0, F.jsx)(`tr`, {
              children: (0, F.jsx)(`td`, {
                colSpan: 7,
                style: {
                  padding: 0
                },
                children: (0, F.jsx)(Qi, {
                  icon: `📋`,
                  title: `No submissions found`,
                  desc: a ? `Try a different search term.` : `Submissions appear here once customers fill service forms.`
                })
              })
            }) : t.rows.map((e, n) => (0, F.jsxs)(`tr`, {
              style: {
                borderBottom: n < t.rows.length - 1 ? `1px solid #f1f5f9` : `none`
              },
              onMouseEnter: e => e.currentTarget.style.background = `var(--surface-2)`,
              onMouseLeave: e => e.currentTarget.style.background = ``,
              children: [(0, F.jsx)(`td`, {
                style: {
                  padding: `12px 14px`,
                  fontWeight: 700,
                  fontFamily: `monospace`,
                  fontSize: 12,
                  color: qo,
                  whiteSpace: `nowrap`
                },
                children: e.booking_ref
              }), (0, F.jsxs)(`td`, {
                style: {
                  padding: `12px 14px`
                },
                children: [(0, F.jsx)(`div`, {
                  style: {
                    fontWeight: 600,
                    fontSize: 13
                  },
                  children: e.customer_name || `—`
                }), (0, F.jsx)(`div`, {
                  style: {
                    fontSize: 11,
                    color: `var(--muted)`
                  },
                  children: e.customer_email
                })]
              }), (0, F.jsx)(`td`, {
                style: {
                  padding: `12px 14px`,
                  color: `var(--text-2)`,
                  whiteSpace: `nowrap`
                },
                children: e.service_name
              }), (0, F.jsx)(`td`, {
                style: {
                  padding: `12px 14px`
                },
                children: (0, F.jsx)(Ji, {
                  status: e.status
                })
              }), (0, F.jsx)(`td`, {
                style: {
                  padding: `12px 14px`,
                  color: `var(--muted)`,
                  whiteSpace: `nowrap`,
                  fontSize: 12
                },
                children: Jo(e.created_at)
              }), (0, F.jsx)(`td`, {
                style: {
                  padding: `12px 14px`,
                  maxWidth: 320
                },
                children: (0, F.jsx)(Xo, {
                  fields: e.field_data
                })
              }), (0, F.jsx)(`td`, {
                style: {
                  padding: `12px 14px`
                },
                children: (0, F.jsx)(Yo, {
                  bookingId: e.id,
                  bookingRef: e.booking_ref
                })
              })]
            }, e.id))
          })]
        })
      })
    }), u > 1 && (0, F.jsxs)(`div`, {
      style: {
        display: `flex`,
        alignItems: `center`,
        justifyContent: `center`,
        gap: 10,
        marginTop: 16
      },
      children: [(0, F.jsxs)(`button`, {
        onClick: () => c(e => Math.max(1, e - 1)),
        disabled: s === 1,
        style: {
          padding: `7px 14px`,
          border: `1px solid var(--border)`,
          borderRadius: `var(--r)`,
          background: `none`,
          cursor: s === 1 ? `not-allowed` : `pointer`,
          color: s === 1 ? `var(--muted)` : `var(--text)`,
          display: `flex`,
          alignItems: `center`,
          gap: 4,
          fontSize: 13
        },
        children: [(0, F.jsx)(Jr, {
          size: 14
        }), ` Prev`]
      }), (0, F.jsxs)(`span`, {
        style: {
          fontSize: 13,
          color: `var(--muted)`
        },
        children: [`Page `, s, ` of `, u]
      }), (0, F.jsxs)(`button`, {
        onClick: () => c(e => Math.min(u, e + 1)),
        disabled: s === u,
        style: {
          padding: `7px 14px`,
          border: `1px solid var(--border)`,
          borderRadius: `var(--r)`,
          background: `none`,
          cursor: s === u ? `not-allowed` : `pointer`,
          color: s === u ? `var(--muted)` : `var(--text)`,
          display: `flex`,
          alignItems: `center`,
          gap: 4,
          fontSize: 13
        },
        children: [`Next `, (0, F.jsx)(Yr, {
          size: 14
        })]
      })]
    })]
  })
}
var Qo = `var(--brand)`,
  $o = {
    name: ``,
    email: ``,
    phone: ``,
    whatsapp: ``,
    company: ``,
    work_types: ``,
    notes: ``,
    status: `active`
  };

function es({
  vendor: e,
  onClose: t,
  onSaved: n
}) {
  let r = R(),
    [i, a] = (0, _.useState)(e ? {
      ...e
    } : {
      ...$o
    }),
    [o, s] = (0, _.useState)(!1),
    c = !!e,
    l = e => t => a(n => ({
      ...n,
      [e]: t
    }));
  async function u() {
    if (!i.name) {
      r(`Vendor name is required`, `error`);
      return
    }
    s(!0);
    try {
      c ? await xr.update(e.id, i) : await xr.create(i), r(c ? `Vendor updated` : `Vendor added`, `success`), n()
    } catch (e) {
      r(e.message || `Save failed`, `error`)
    } finally {
      s(!1)
    }
  }
  let d = ({
    label: e,
    k: t,
    type: n = `text`,
    placeholder: r = ``
  }) => (0, F.jsxs)(`div`, {
    style: {
      marginBottom: 12
    },
    children: [(0, F.jsx)(`label`, {
      style: {
        fontSize: 13,
        fontWeight: 600,
        color: `var(--text-2)`,
        display: `block`,
        marginBottom: 5
      },
      children: e
    }), (0, F.jsx)(`input`, {
      type: n,
      value: i[t] || ``,
      onChange: e => l(t)(e.target.value),
      placeholder: r,
      style: {
        width: `100%`,
        padding: `9px 13px`,
        fontSize: 14,
        border: `1px solid var(--border)`,
        borderRadius: `var(--r)`,
        fontFamily: `inherit`,
        outline: `none`,
        boxSizing: `border-box`
      }
    })]
  });
  return (0, F.jsx)($i, {
    open: !0,
    title: c ? `Edit Vendor` : `Add Vendor`,
    onClose: t,
    maxWidth: 560,
    footer: (0, F.jsxs)(F.Fragment, {
      children: [(0, F.jsx)(z, {
        variant: `ghost`,
        onClick: t,
        children: `Cancel`
      }), (0, F.jsx)(z, {
        loading: o,
        icon: (0, F.jsx)(Si, {
          size: 14
        }),
        onClick: u,
        children: c ? `Update` : `Add Vendor`
      })]
    }),
    children: (0, F.jsxs)(`div`, {
      style: {
        display: `grid`,
        gridTemplateColumns: `1fr 1fr`,
        gap: 12
      },
      children: [(0, F.jsx)(`div`, {
        style: {
          gridColumn: `1/-1`
        },
        children: (0, F.jsx)(d, {
          label: `Vendor Name *`,
          k: `name`,
          placeholder: `ABC Services Pvt Ltd`
        })
      }), (0, F.jsx)(d, {
        label: `Email`,
        k: `email`,
        type: `email`,
        placeholder: `vendor@example.com`
      }), (0, F.jsx)(d, {
        label: `Phone`,
        k: `phone`,
        placeholder: `+91 98765 43210`
      }), (0, F.jsx)(d, {
        label: `WhatsApp`,
        k: `whatsapp`,
        placeholder: `+91 98765 43210`
      }), (0, F.jsx)(d, {
        label: `Company`,
        k: `company`,
        placeholder: `Company name`
      }), (0, F.jsxs)(`div`, {
        style: {
          gridColumn: `1/-1`
        },
        children: [(0, F.jsx)(`label`, {
          style: {
            fontSize: 13,
            fontWeight: 600,
            color: `var(--text-2)`,
            display: `block`,
            marginBottom: 5
          },
          children: `Work Types`
        }), (0, F.jsx)(`textarea`, {
          value: i.work_types || ``,
          onChange: e => l(`work_types`)(e.target.value),
          rows: 2,
          placeholder: `e.g. Document retrieval, Affidavit, Notary…`,
          style: {
            width: `100%`,
            padding: `9px 13px`,
            fontSize: 14,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r)`,
            fontFamily: `inherit`,
            outline: `none`,
            resize: `vertical`,
            boxSizing: `border-box`
          }
        })]
      }), (0, F.jsxs)(`div`, {
        style: {
          gridColumn: `1/-1`
        },
        children: [(0, F.jsx)(`label`, {
          style: {
            fontSize: 13,
            fontWeight: 600,
            color: `var(--text-2)`,
            display: `block`,
            marginBottom: 5
          },
          children: `Notes (internal)`
        }), (0, F.jsx)(`textarea`, {
          value: i.notes || ``,
          onChange: e => l(`notes`)(e.target.value),
          rows: 2,
          placeholder: `Internal notes about this vendor…`,
          style: {
            width: `100%`,
            padding: `9px 13px`,
            fontSize: 14,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r)`,
            fontFamily: `inherit`,
            outline: `none`,
            resize: `vertical`,
            boxSizing: `border-box`
          }
        })]
      }), (0, F.jsxs)(`div`, {
        style: {
          gridColumn: `1/-1`
        },
        children: [(0, F.jsx)(`label`, {
          style: {
            fontSize: 13,
            fontWeight: 600,
            color: `var(--text-2)`,
            display: `block`,
            marginBottom: 5
          },
          children: `Status`
        }), (0, F.jsxs)(`select`, {
          value: i.status || `active`,
          onChange: e => l(`status`)(e.target.value),
          style: {
            width: `100%`,
            padding: `9px 13px`,
            fontSize: 14,
            border: `1px solid var(--border)`,
            borderRadius: `var(--r)`,
            fontFamily: `inherit`,
            outline: `none`,
            appearance: `none`,
            cursor: `pointer`,
            boxSizing: `border-box`
          },
          children: [(0, F.jsx)(`option`, {
            value: `active`,
            children: `Active`
          }), (0, F.jsx)(`option`, {
            value: `inactive`,
            children: `Inactive`
          })]
        })]
      })]
    })
  })
}

function ts() {
  let e = R(),
    [t, n] = (0, _.useState)([]),
    [r, i] = (0, _.useState)(!0),
    [a, o] = (0, _.useState)(``),
    [s, c] = (0, _.useState)(null),
    l = (0, _.useCallback)(async () => {
      i(!0);
      try {
        n((await xr.list(a)).vendors || [])
      } catch (t) {
        e(t.message || `Failed to load`, `error`)
      } finally {
        i(!1)
      }
    }, [a]);
  (0, _.useEffect)(() => {
    l()
  }, [l]);
  async function u(t) {
    if (window.confirm(`Delete vendor "${t.name}"? This cannot be undone.`)) try {
      await xr.del(t.id), e(`Vendor deleted`, `success`), l()
    } catch (t) {
      e(t.message || `Delete failed`, `error`)
    }
  }
  return (0, F.jsxs)(`div`, {
    children: [(0, F.jsxs)(`div`, {
      style: {
        marginBottom: 20,
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        flexWrap: `wrap`,
        gap: 12
      },
      children: [(0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(`h1`, {
          style: {
            fontSize: 22,
            fontWeight: 800,
            margin: `0 0 4px`
          },
          children: `Vendors`
        }), (0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`,
            margin: 0
          },
          children: `Manage service delivery partners`
        })]
      }), (0, F.jsx)(z, {
        icon: (0, F.jsx)(yi, {
          size: 15
        }),
        onClick: () => c(`add`),
        children: `Add Vendor`
      })]
    }), (0, F.jsxs)(`div`, {
      style: {
        position: `relative`,
        marginBottom: 16,
        maxWidth: 380
      },
      children: [(0, F.jsx)(Ci, {
        size: 15,
        style: {
          position: `absolute`,
          left: 11,
          top: `50%`,
          transform: `translateY(-50%)`,
          color: `var(--muted)`,
          pointerEvents: `none`
        }
      }), (0, F.jsx)(`input`, {
        value: a,
        onChange: e => o(e.target.value),
        placeholder: `Search vendors…`,
        style: {
          width: `100%`,
          padding: `9px 13px 9px 34px`,
          fontSize: 14,
          border: `1px solid var(--border)`,
          borderRadius: `var(--r)`,
          fontFamily: `inherit`,
          outline: `none`,
          boxSizing: `border-box`
        }
      })]
    }), r ? (0, F.jsx)(`div`, {
      style: {
        textAlign: `center`,
        padding: 48
      },
      children: (0, F.jsx)(Wi, {
        size: 24
      })
    }) : t.length === 0 ? (0, F.jsx)(B, {
      children: (0, F.jsx)(Qi, {
        icon: `🏢`,
        title: `No vendors yet`,
        desc: `Add your first vendor partner to assign them to service requests.`,
        action: (0, F.jsx)(z, {
          icon: (0, F.jsx)(yi, {
            size: 15
          }),
          onClick: () => c(`add`),
          children: `Add Vendor`
        })
      })
    }) : (0, F.jsx)(`div`, {
      style: {
        display: `grid`,
        gridTemplateColumns: `repeat(auto-fill,minmax(320px,1fr))`,
        gap: 14
      },
      children: t.map(e => (0, F.jsxs)(B, {
        padding: `18px`,
        children: [(0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            justifyContent: `space-between`,
            alignItems: `flex-start`,
            marginBottom: 12
          },
          children: [(0, F.jsxs)(`div`, {
            style: {
              display: `flex`,
              alignItems: `center`,
              gap: 12
            },
            children: [(0, F.jsx)(`div`, {
              style: {
                width: 44,
                height: 44,
                borderRadius: `50%`,
                background: `${Qo}15`,
                color: Qo,
                display: `flex`,
                alignItems: `center`,
                justifyContent: `center`,
                fontSize: 18,
                fontWeight: 700,
                flexShrink: 0
              },
              children: (e.name || `?`)[0].toUpperCase()
            }), (0, F.jsxs)(`div`, {
              children: [(0, F.jsx)(`div`, {
                style: {
                  fontWeight: 700,
                  fontSize: 15
                },
                children: e.name
              }), e.company && (0, F.jsxs)(`div`, {
                style: {
                  fontSize: 12,
                  color: `var(--muted)`,
                  display: `flex`,
                  alignItems: `center`,
                  gap: 4,
                  marginTop: 2
                },
                children: [(0, F.jsx)(Ur, {
                  size: 11
                }), ` `, e.company]
              })]
            })]
          }), (0, F.jsx)(`span`, {
            style: {
              fontSize: 11,
              padding: `2px 8px`,
              borderRadius: `var(--r-full)`,
              fontWeight: 700,
              background: e.status === `active` ? `var(--green-bg)` : `var(--surface-2)`,
              color: e.status === `active` ? `var(--green)` : `var(--muted)`
            },
            children: e.status
          })]
        }), (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            flexDirection: `column`,
            gap: 5,
            marginBottom: 12
          },
          children: [e.email && (0, F.jsxs)(`a`, {
            href: `mailto:${e.email}`,
            style: {
              display: `flex`,
              alignItems: `center`,
              gap: 7,
              fontSize: 13,
              color: `var(--text-2)`,
              textDecoration: `none`
            },
            children: [(0, F.jsx)(pi, {
              size: 13,
              style: {
                color: `var(--muted)`
              }
            }), ` `, e.email]
          }), e.phone && (0, F.jsxs)(`a`, {
            href: `tel:${e.phone}`,
            style: {
              display: `flex`,
              alignItems: `center`,
              gap: 7,
              fontSize: 13,
              color: `var(--text-2)`,
              textDecoration: `none`
            },
            children: [(0, F.jsx)(vi, {
              size: 13,
              style: {
                color: `var(--muted)`
              }
            }), ` `, e.phone]
          }), e.whatsapp && (0, F.jsxs)(`a`, {
            href: `https://wa.me/${e.whatsapp.replace(/\D/g,``)}`,
            target: `_blank`,
            rel: `noopener noreferrer`,
            style: {
              display: `flex`,
              alignItems: `center`,
              gap: 7,
              fontSize: 13,
              color: `var(--green-dark)`,
              textDecoration: `none`,
              fontWeight: 600
            },
            children: [`📱 WhatsApp: `, e.whatsapp]
          })]
        }), e.work_types && (0, F.jsx)(`div`, {
          style: {
            fontSize: 12,
            color: `var(--muted)`,
            marginBottom: 12,
            background: `var(--surface-2)`,
            borderRadius: `var(--r-sm)`,
            padding: `6px 8px`
          },
          children: e.work_types
        }), (0, F.jsxs)(`div`, {
          style: {
            display: `flex`,
            gap: 8,
            paddingTop: 10,
            borderTop: `1px solid var(--border)`
          },
          children: [(0, F.jsx)(z, {
            size: `sm`,
            variant: `ghost`,
            icon: (0, F.jsx)(_i, {
              size: 13
            }),
            onClick: () => c(e),
            children: `Edit`
          }), (0, F.jsx)(z, {
            size: `sm`,
            variant: `ghost`,
            icon: (0, F.jsx)(Mi, {
              size: 13
            }),
            style: {
              color: `var(--red)`
            },
            onClick: () => u(e),
            children: `Delete`
          })]
        })]
      }, e.id))
    }), s && (0, F.jsx)(es, {
      vendor: s === `add` ? null : s,
      onClose: () => c(null),
      onSaved: () => {
        c(null), l()
      }
    })]
  })
}
var ns = `var(--brand)`;

function rs() {
  let e = R(),
    [t, n] = (0, _.useState)([]),
    [r, i] = (0, _.useState)(!0),
    [a, o] = (0, _.useState)(null),
    [s, c] = (0, _.useState)({
      name: ``,
      description: ``
    }),
    [l, u] = (0, _.useState)(!1),
    [d, f] = (0, _.useState)(!1),
    p = (0, _.useCallback)(async () => {
      i(!0);
      try {
        n((await Cr.list()).types || [])
      } catch (t) {
        e(t.message || `Failed to load`, `error`)
      } finally {
        i(!1)
      }
    }, []);
  (0, _.useEffect)(() => {
    p()
  }, [p]);

  function m() {
    o(null), c({
      name: ``,
      description: ``
    }), f(!0)
  }

  function h(e) {
    o(e.id), c({
      name: e.name,
      description: e.description || ``
    }), f(!0)
  }

  function g() {
    f(!1), o(null), c({
      name: ``,
      description: ``
    })
  }
  async function v() {
    if (!s.name.trim()) {
      e(`Name is required`, `error`);
      return
    }
    u(!0);
    try {
      a ? await Cr.update(a, s) : await Cr.create(s), e(a ? `Updated` : `Created`, `success`), g(), p()
    } catch (t) {
      e(t.message || `Save failed`, `error`)
    } finally {
      u(!1)
    }
  }
  async function y(t) {
    try {
      await Cr.toggle(t.id), p()
    } catch (t) {
      e(t.message || `Failed`, `error`)
    }
  }
  async function b(t) {
    if (window.confirm(`Delete "${t.name}"?`)) try {
      await Cr.del(t.id), e(`Deleted`, `success`), p()
    } catch (t) {
      e(t.message || `Delete failed`, `error`)
    }
  }
  return (0, F.jsxs)(`div`, {
    children: [(0, F.jsxs)(`div`, {
      style: {
        marginBottom: 20,
        display: `flex`,
        alignItems: `center`,
        justifyContent: `space-between`,
        flexWrap: `wrap`,
        gap: 12
      },
      children: [(0, F.jsxs)(`div`, {
        children: [(0, F.jsx)(`h1`, {
          style: {
            fontSize: 22,
            fontWeight: 800,
            margin: `0 0 4px`
          },
          children: `Request Types`
        }), (0, F.jsx)(`p`, {
          style: {
            fontSize: 14,
            color: `var(--muted)`,
            margin: 0
          },
          children: `Categories shown in the "Other Service Request" modal on booking detail pages.`
        })]
      }), (0, F.jsx)(z, {
        icon: (0, F.jsx)(yi, {
          size: 15
        }),
        onClick: m,
        children: `Add Type`
      })]
    }), d && (0, F.jsxs)(B, {
      style: {
        marginBottom: 20,
        border: `1px solid ${ns}40`
      },
      children: [(0, F.jsx)(`div`, {
        style: {
          fontSize: 14,
          fontWeight: 700,
          marginBottom: 14
        },
        children: a ? `Edit Request Type` : `New Request Type`
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          gap: 12,
          marginBottom: 12,
          flexWrap: `wrap`
        },
        children: [(0, F.jsxs)(`div`, {
          style: {
            flex: 1,
            minWidth: 200
          },
          children: [(0, F.jsxs)(`label`, {
            style: {
              fontSize: 13,
              fontWeight: 600,
              color: `var(--text-2)`,
              display: `block`,
              marginBottom: 5
            },
            children: [`Name `, (0, F.jsx)(`span`, {
              style: {
                color: `var(--red)`
              },
              children: `*`
            })]
          }), (0, F.jsx)(`input`, {
            value: s.name,
            onChange: e => c(t => ({
              ...t,
              name: e.target.value
            })),
            placeholder: `e.g. Refund Request`,
            style: {
              width: `100%`,
              padding: `9px 13px`,
              fontSize: 14,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              fontFamily: `inherit`,
              outline: `none`,
              boxSizing: `border-box`
            }
          })]
        }), (0, F.jsxs)(`div`, {
          style: {
            flex: 2,
            minWidth: 280
          },
          children: [(0, F.jsx)(`label`, {
            style: {
              fontSize: 13,
              fontWeight: 600,
              color: `var(--text-2)`,
              display: `block`,
              marginBottom: 5
            },
            children: `Description`
          }), (0, F.jsx)(`input`, {
            value: s.description,
            onChange: e => c(t => ({
              ...t,
              description: e.target.value
            })),
            placeholder: `Brief description (optional)`,
            style: {
              width: `100%`,
              padding: `9px 13px`,
              fontSize: 14,
              border: `1px solid var(--border)`,
              borderRadius: `var(--r)`,
              fontFamily: `inherit`,
              outline: `none`,
              boxSizing: `border-box`
            }
          })]
        })]
      }), (0, F.jsxs)(`div`, {
        style: {
          display: `flex`,
          gap: 8
        },
        children: [(0, F.jsx)(z, {
          size: `sm`,
          loading: l,
          icon: (0, F.jsx)(Si, {
            size: 13
          }),
          onClick: v,
          children: a ? `Update` : `Create`
        }), (0, F.jsx)(z, {
          size: `sm`,
          variant: `ghost`,
          onClick: g,
          children: `Cancel`
        })]
      })]
    }), r ? (0, F.jsx)(`div`, {
      style: {
        textAlign: `center`,
        padding: 48
      },
      children: (0, F.jsx)(Wi, {
        size: 24
      })
    }) : t.length === 0 ? (0, F.jsx)(B, {
      children: (0, F.jsx)(Qi, {
        icon: `🎫`,
        title: `No request types yet`,
        desc: `Add categories for the support ticket modal (e.g. Refund, Shipping, Order Status).`,
        action: (0, F.jsx)(z, {
          icon: (0, F.jsx)(yi, {
            size: 15
          }),
          onClick: m,
          children: `Add First Type`
        })
      })
    }) : (0, F.jsx)(B, {
      padding: `0`,
      style: {
        overflow: `hidden`
      },
      children: (0, F.jsxs)(`table`, {
        style: {
          width: `100%`,
          borderCollapse: `collapse`,
          fontSize: 14
        },
        children: [(0, F.jsx)(`thead`, {
          children: (0, F.jsx)(`tr`, {
            style: {
              background: `var(--surface-2)`
            },
            children: [`Name`, `Description`, `Status`, `Actions`].map(e => (0, F.jsx)(`th`, {
              style: {
                padding: `10px 14px`,
                textAlign: `left`,
                fontSize: 11,
                fontWeight: 700,
                color: `var(--muted)`,
                textTransform: `uppercase`,
                letterSpacing: `.04em`,
                borderBottom: `1px solid var(--border)`
              },
              children: e
            }, e))
          })
        }), (0, F.jsx)(`tbody`, {
          children: t.map((e, n) => (0, F.jsxs)(`tr`, {
            style: {
              borderBottom: n < t.length - 1 ? `1px solid #f1f5f9` : `none`,
              opacity: e.is_active == 0 ? .5 : 1
            },
            children: [(0, F.jsx)(`td`, {
              style: {
                padding: `12px 14px`,
                fontWeight: 600
              },
              children: e.name
            }), (0, F.jsx)(`td`, {
              style: {
                padding: `12px 14px`,
                color: `var(--muted)`,
                fontSize: 13
              },
              children: e.description || `—`
            }), (0, F.jsx)(`td`, {
              style: {
                padding: `12px 14px`
              },
              children: (0, F.jsxs)(`button`, {
                onClick: () => y(e),
                style: {
                  background: `none`,
                  border: `none`,
                  cursor: `pointer`,
                  display: `flex`,
                  alignItems: `center`,
                  gap: 5,
                  fontSize: 12,
                  fontWeight: 600,
                  color: e.is_active ? `var(--green)` : `var(--muted)`
                },
                children: [e.is_active ? (0, F.jsx)(ji, {
                  size: 18,
                  color: `var(--green)`
                }) : (0, F.jsx)(Ai, {
                  size: 18
                }), e.is_active ? `Active` : `Inactive`]
              })
            }), (0, F.jsx)(`td`, {
              style: {
                padding: `12px 14px`
              },
              children: (0, F.jsxs)(`div`, {
                style: {
                  display: `flex`,
                  gap: 6
                },
                children: [(0, F.jsx)(z, {
                  size: `sm`,
                  variant: `ghost`,
                  icon: (0, F.jsx)(_i, {
                    size: 12
                  }),
                  onClick: () => h(e),
                  children: `Edit`
                }), (0, F.jsx)(z, {
                  size: `sm`,
                  variant: `ghost`,
                  icon: (0, F.jsx)(Mi, {
                    size: 12
                  }),
                  style: {
                    color: `var(--red)`
                  },
                  onClick: () => b(e),
                  children: `Delete`
                })]
              })
            })]
          }, e.id))
        })]
      })
    })]
  })
}

function is({
  role: e,
  children: t
}) {
  let {
    user: n,
    loading: r
  } = kr();
  if (r) return (0, F.jsx)(`div`, {
    style: {
      display: `flex`,
      justifyContent: `center`,
      alignItems: `center`,
      height: `100vh`,
      background: `var(--bg)`
    },
    children: (0, F.jsx)(Wi, {
      size: 36
    })
  });
  if (!n) return (0, F.jsx)(Rt, {
    to: `/login`,
    replace: !0
  });
  if (e === `admin` && ![`super_admin`, `manager`, `agent`, `finance`].includes(n.s2nri_role)) {
    let e = (window.S2NRI_CFG?.basePath || ``).replace(`/s2nri-admin`, `/portal`).replace(`/admin`, `/portal`);
    return window.location.href = e || `/`, null
  }
  return t
}

function as() {
  let e = window.S2NRI_CFG?.basePath || `/`,
    t = window.S2NRI_CFG?.isAdmin === !0;
  return (0, F.jsx)(Or, {
    children: (0, F.jsx)(Ui, {
      children: (0, F.jsx)(Mn, {
        basename: e,
        children: (0, F.jsxs)(Ht, {
          children: [(0, F.jsx)(Bt, {
            path: `/login`,
            element: (0, F.jsx)(fa, {})
          }), t ? (0, F.jsxs)(Bt, {
            path: `/`,
            element: (0, F.jsx)(is, {
              role: `admin`,
              children: (0, F.jsx)(ua, {})
            }),
            children: [(0, F.jsx)(Bt, {
              index: !0,
              element: (0, F.jsx)(Ka, {})
            }), (0, F.jsx)(Bt, {
              path: `requests`,
              element: (0, F.jsx)($a, {})
            }), (0, F.jsx)(Bt, {
              path: `requests/:id`,
              element: (0, F.jsx)(U, {})
            }), (0, F.jsx)(Bt, {
              path: `bookings`,
              element: (0, F.jsx)($a, {})
            }), (0, F.jsx)(Bt, {
              path: `bookings/:id`,
              element: (0, F.jsx)(U, {})
            }), (0, F.jsx)(Bt, {
              path: `customers`,
              element: (0, F.jsx)(ho, {})
            }), (0, F.jsx)(Bt, {
              path: `analytics`,
              element: (0, F.jsx)(So, {})
            }), (0, F.jsx)(Bt, {
              path: `services`,
              element: (0, F.jsx)(Ao, {})
            }), (0, F.jsx)(Bt, {
              path: `settings`,
              element: (0, F.jsx)(Ho, {})
            }), (0, F.jsx)(Bt, {
              path: `health`,
              element: (0, F.jsx)(Ko, {})
            }), (0, F.jsx)(Bt, {
              path: `form-submissions`,
              element: (0, F.jsx)(Zo, {})
            }), (0, F.jsx)(Bt, {
              path: `vendors`,
              element: (0, F.jsx)(ts, {})
            }), (0, F.jsx)(Bt, {
              path: `request-types`,
              element: (0, F.jsx)(rs, {})
            }), (0, F.jsx)(Bt, {
              path: `*`,
              element: (0, F.jsx)(Rt, {
                to: `/`,
                replace: !0
              })
            })]
          }) : (0, F.jsxs)(Bt, {
            path: `/`,
            element: (0, F.jsx)(is, {
              children: (0, F.jsx)(oa, {})
            }),
            children: [(0, F.jsx)(Bt, {
              index: !0,
              element: (0, F.jsx)(_a, {})
            }), (0, F.jsx)(Bt, {
              path: `bookings`,
              element: (0, F.jsx)(Ta, {})
            }), (0, F.jsx)(Bt, {
              path: `bookings/:id`,
              element: (0, F.jsx)(Na, {})
            }), (0, F.jsx)(Bt, {
              path: `new-request`,
              element: (0, F.jsx)(Ra, {})
            }), (0, F.jsx)(Bt, {
              path: `profile`,
              element: (0, F.jsx)(Ha, {})
            }), (0, F.jsx)(Bt, {
              path: `*`,
              element: (0, F.jsx)(Rt, {
                to: `/`,
                replace: !0
              })
            })]
          })]
        })
      })
    })
  })
}(0, v.createRoot)(document.getElementById(`s2nri-root`)).render((0, F.jsx)(_.StrictMode, {
  children: (0, F.jsx)(as, {})
}));