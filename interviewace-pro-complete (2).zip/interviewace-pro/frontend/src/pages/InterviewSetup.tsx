import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { interviewsApi } from '@/api/interviews';
import { ErrorBlock } from '@/components/StateViews';
import type { ApiError } from '@/types';

const TYPES: { label: string; roundType: 'technical' | 'hr' | 'behavioral' | 'general' }[] = [
  { label: 'Software Engineer', roundType: 'technical' },
  { label: 'Product Manager', roundType: 'behavioral' },
  { label: 'Data Analyst', roundType: 'technical' },
  { label: 'Sales', roundType: 'behavioral' },
  { label: 'HR / Recruiter', roundType: 'hr' },
  { label: 'Customer Support', roundType: 'behavioral' },
];

export default function InterviewSetup() {
  const nav = useNavigate();
  const [typeIndex, setTypeIndex] = useState(0);
  const [language, setLanguage] = useState<'english' | 'hinglish'>('english');
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);

  async function onStart() {
    setCreating(true);
    setError(null);
    try {
      const selected = TYPES[typeIndex];
      const r = await interviewsApi.create({
        type: selected.label,
        language_mode: language,
        // round_type feeds the gamification badge checks (hr_specialist/
        // tech_specialist/multi_round) — see api/class-api-interviews.php
        // and includes/class-activator.php for the backend side of this.
        round_type: selected.roundType,
      });
      nav(`/interview/${r.interview_id}`, { state: { openingLine: r.opening_line, plan: r.plan, maxMinutes: r.max_minutes } });
    } catch (err) {
      setError(err as ApiError);
    } finally {
      setCreating(false);
    }
  }

  return (
    <div className="ia-page">
      <h1>Set up your interview</h1>
      <div className="ia-field">
        <label htmlFor="type">Interview type</label>
        <select id="type" className="ia-input" value={typeIndex} onChange={(e) => setTypeIndex(Number(e.target.value))}>
          {TYPES.map((t, i) => <option key={t.label} value={i}>{t.label}</option>)}
        </select>
      </div>
      <div className="ia-field">
        <label htmlFor="lang">Language</label>
        <select id="lang" className="ia-input" value={language} onChange={(e) => setLanguage(e.target.value as 'english' | 'hinglish')}>
          <option value="english">English</option>
          <option value="hinglish">Hinglish</option>
        </select>
      </div>

      {error && (
        <div style={{ marginBottom: 'var(--ia-space-4)' }}>
          {error.code === 'ia_limit' ? (
            <div className="ia-state ia-state-error" style={{ padding: 'var(--ia-space-4)' }}>
              <p>{error.message}</p>
              {/* ROOT-CAUSE FIX: was a raw <a href="/billing"> — outside the SPA's /app
                  basename (same broken-link class fixed across the backend this pass)
                  and a hard page reload besides. A router Link to the real in-app route
                  keeps the SPA session intact. */}
              <Link to="/billing" className="ia-btn ia-btn-primary">Upgrade plan</Link>
            </div>
          ) : (
            <ErrorBlock error={error} onRetry={onStart} />
          )}
        </div>
      )}

      <button className="ia-btn ia-btn-primary ia-btn-block" onClick={onStart} disabled={creating}>
        {creating ? 'Preparing your interview…' : 'Start interview'}
      </button>
      {creating && (
        <p className="ia-state-hint" style={{ textAlign: 'center', marginTop: 'var(--ia-space-3)' }}>
          Generating your question plan — this can take a few seconds.
        </p>
      )}
    </div>
  );
}
