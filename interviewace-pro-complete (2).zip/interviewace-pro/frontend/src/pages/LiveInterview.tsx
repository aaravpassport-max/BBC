import { useCallback, useEffect, useRef, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { interviewsApi } from '@/api/interviews';
import { apiFetch } from '@/api/client';
import { ErrorBlock } from '@/components/StateViews';
import type { ApiError, InterviewQuestion } from '@/types';

interface ChatTurn { turnNumber: number; role: 'ai' | 'user'; text: string }
interface LocationState { openingLine?: string; plan?: InterviewQuestion[]; maxMinutes?: number }

/**
 * The single highest-risk screen per the audit (A1: every AI turn is a
 * blocking, non-streaming Claude call). Until true SSE streaming lands
 * server-side, the honest fix here is an explicit, unmissable "Priya is
 * thinking" state — never a silent hang — plus retry semantics that are
 * actually safe to use because turnNumber never changes across a retry
 * (see api/interviews.ts — this is what makes the backend's
 * uk_interview_turn_role idempotency guarantee usable from the UI).
 */
export default function LiveInterview() {
  const { id } = useParams<{ id: string }>();
  const interviewId = Number(id);
  const location = useLocation();
  const nav = useNavigate();
  const state = (location.state as LocationState) || {};

  const [turns, setTurns] = useState<ChatTurn[]>(
    state.openingLine ? [{ turnNumber: 0, role: 'ai', text: state.openingLine }] : []
  );
  const [draft, setDraft] = useState('');
  const [pendingTurnNumber, setPendingTurnNumber] = useState<number | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<ApiError | null>(null);
  const [ending, setEnding] = useState(false);
  const [complete, setComplete] = useState(false);
  const [recording, setRecording] = useState(false);
  const [transcribing, setTranscribing] = useState(false);
  const nextTurnNumber = useRef(1);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const listEndRef = useRef<HTMLDivElement | null>(null);

  const maxMinutes = state.maxMinutes ?? 60;

  useEffect(() => {
    interviewsApi.start(interviewId).catch(() => {
      // Non-fatal: start() is idempotent server-side (returns success if
      // already active) — a failure here just means the first turn submit
      // will surface any real problem instead.
    });
  }, [interviewId]);

  useEffect(() => {
    listEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [turns]);

  const submitTurn = useCallback(
    async (transcript: string, turnNumber: number) => {
      setSubmitting(true);
      setError(null);
      try {
        const r = await interviewsApi.submitTurn(interviewId, { transcript, turn_number: turnNumber });
        setTurns((prev) => [
          ...prev,
          { turnNumber, role: 'user', text: transcript },
          { turnNumber: turnNumber + 1, role: 'ai', text: r.ai_response },
        ]);
        setPendingTurnNumber(null);
        setDraft('');
        nextTurnNumber.current = turnNumber + 2;
        if (r.is_complete) {
          setComplete(true);
          void interviewsApi.reportCost(interviewId, {});
          if (r.report_id) {
            nav(`/report/${r.report_id}`, { replace: true });
          }
        }
      } catch (err) {
        // Deliberately keep `draft`/pendingTurnNumber intact on failure —
        // the whole point of the idempotency fix is that retrying with the
        // SAME turn number and text is always safe, so we never discard
        // what the user just said.
        setError(err as ApiError);
      } finally {
        setSubmitting(false);
      }
    },
    [interviewId, nav]
  );

  function onSend() {
    const text = draft.trim();
    if (!text || submitting) return;
    const turnNumber = pendingTurnNumber ?? nextTurnNumber.current;
    setPendingTurnNumber(turnNumber);
    void submitTurn(text, turnNumber);
  }

  function onRetry() {
    if (pendingTurnNumber == null) return;
    void submitTurn(draft.trim(), pendingTurnNumber);
  }

  async function onEndEarly() {
    if (!window.confirm('End this interview now? You can still view your report for what you’ve completed so far.')) return;
    setEnding(true);
    try {
      const r = await interviewsApi.end(interviewId);
      nav(`/report/${r.report_id}`, { replace: true });
    } catch (err) {
      setError(err as ApiError);
      setEnding(false);
    }
  }

  // Voice capture is optional — typed answers work everywhere with no
  // browser permission prompts, which the audit flagged as necessary
  // (permission-denial / mic-failure is a real edge case this sidesteps
  // entirely as a fallback rather than a dead end).
  async function toggleRecording() {
    if (recording) {
      mediaRecorderRef.current?.stop();
      setRecording(false);
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mr = new MediaRecorder(stream);
      chunksRef.current = [];
      mr.ondataavailable = (e) => chunksRef.current.push(e.data);
      mr.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        setTranscribing(true);
        try {
          const form = new FormData();
          form.append('audio', blob, 'answer.webm');
          form.append('interview_id', String(interviewId));
          const r = await apiFetch<{ transcript: string }>('/speech/stt', { method: 'POST', body: form });
          setDraft((prev) => (prev ? `${prev} ${r.transcript}` : r.transcript));
        } catch (err) {
          setError(err as ApiError);
        } finally {
          setTranscribing(false);
        }
      };
      mr.start();
      mediaRecorderRef.current = mr;
      setRecording(true);
    } catch {
      setError({ code: 'ia_mic', message: 'Microphone access was denied. You can still type your answer below.', status: 0, retryable: false });
    }
  }

  if (!interviewId) return <ErrorBlock error={{ code: 'ia_bad_route', message: 'Invalid interview.', status: 400, retryable: false }} />;

  return (
    <div className="ia-page-wide" style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
      <header className="ia-topbar">
        <strong>Live interview</strong>
        <div style={{ display: 'flex', gap: 'var(--ia-space-3)', alignItems: 'center' }}>
          <span className="ia-badge ia-badge-info">Up to {maxMinutes} min</span>
          <button className="ia-btn ia-btn-ghost" onClick={() => void onEndEarly()} disabled={ending || complete}>
            {ending ? 'Ending…' : 'End interview'}
          </button>
        </div>
      </header>

      <div style={{ flex: 1, overflowY: 'auto', padding: 'var(--ia-space-4) 0' }}>
        {turns.map((t) => (
          <div
            key={`${t.turnNumber}-${t.role}`}
            style={{
              display: 'flex',
              justifyContent: t.role === 'ai' ? 'flex-start' : 'flex-end',
              marginBottom: 'var(--ia-space-3)',
            }}
          >
            <div
              className="ia-card"
              style={{
                maxWidth: '75%',
                padding: 'var(--ia-space-3) var(--ia-space-4)',
                background: t.role === 'ai' ? 'var(--ia-bg-elevated)' : 'var(--ia-accent-bg)',
              }}
            >
              {t.role === 'ai' && <div className="ia-state-hint" style={{ marginBottom: 4 }}>Priya (AI Interviewer)</div>}
              <p style={{ margin: 0 }}>{t.text}</p>
            </div>
          </div>
        ))}

        {submitting && (
          <div style={{ display: 'flex', alignItems: 'center', gap: 'var(--ia-space-2)', color: 'var(--ia-text-secondary)' }} role="status" aria-live="polite">
            <span className="ia-spinner" style={{ width: 18, height: 18, borderWidth: 2 }} />
            <span>Priya is thinking…</span>
          </div>
        )}

        {error && (
          <div style={{ margin: 'var(--ia-space-3) 0' }}>
            <ErrorBlock error={error} onRetry={pendingTurnNumber != null ? onRetry : undefined} />
          </div>
        )}

        <div ref={listEndRef} />
      </div>

      {!complete && (
        <div style={{ borderTop: '1px solid var(--ia-border)', paddingTop: 'var(--ia-space-4)' }}>
          <div className="ia-field">
            <textarea
              className="ia-input"
              rows={3}
              placeholder="Type your answer, or use the mic…"
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              disabled={submitting}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); onSend(); }
              }}
            />
          </div>
          <div style={{ display: 'flex', gap: 'var(--ia-space-3)' }}>
            <button
              className={`ia-btn ${recording ? 'ia-btn-danger' : 'ia-btn-secondary'}`}
              onClick={() => void toggleRecording()}
              disabled={submitting || transcribing}
              aria-pressed={recording}
              aria-label={recording ? 'Stop recording' : 'Record your answer'}
            >
              {transcribing ? 'Transcribing…' : recording ? '● Stop' : '🎤 Record'}
            </button>
            <button className="ia-btn ia-btn-primary" style={{ flex: 1 }} onClick={onSend} disabled={submitting || !draft.trim()}>
              {submitting ? 'Sending…' : 'Send answer'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
