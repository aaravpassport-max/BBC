<?php
/**
 * GoodService Homepage v7 — Redesigned
 * Reference: OnlineX Sewa + Sulekha merged design
 * - Minimal compact centered hero (filter only)
 * - Sponsored listings section (admin-controlled)
 * - Categories → directory page
 * - Discover Cities section
 * - Latest listings horizontal cards
 * - Stats, How it works, Why choose us, CTA, Testimonials, FAQ, Footer
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

use GoodService\Repository\ListingRepository;
use GoodService\Repository\CategoryRepository;
use GoodService\Core\Cache;
use GoodService\Core\Config;

$site_name     = Config::get('platform_name',           get_bloginfo('name'));
$tagline       = Config::get('platform_tagline',        'Find Verified Local Service Providers');
$logo_url      = Config::get('logo_url',                '');
$primary_color = Config::get('platform_color_primary',  '#2563EB');

/* ── Admin-controlled home settings ─────────────── */
$show_sponsored   = gs_setting('show_sponsored_on_home','0') === '1';
$sponsored_count    = max(3, min(28, (int)gs_setting('sponsored_count','6')));
// Real admin controls: column count, row count, and vertical padding for the
// Featured Providers section — previously all hardcoded in CSS with no way
// to adjust without editing code.
$sponsored_columns  = max(2, min(8, (int)gs_setting('sponsored_columns','7')));
$sponsored_rows     = max(1, min(6, (int)gs_setting('sponsored_rows','4')));
$sponsored_total    = $sponsored_columns * $sponsored_rows;
$sponsored_padding_y = max(0, min(120, (int)gs_setting('sponsored_padding_y','40')));
// Real gap fix: a fixed column count can never grow to fill a wider screen —
// that's the actual cause of the blank margin. Added a full-width toggle and
// a minimum card width that drives a genuinely responsive auto-fill grid, so
// the browser computes the real column count from available space and cards
// actually grow as the section gets wider — not fixed by a manual number.
$sponsored_full_width = gs_setting('sponsored_full_width','0') === '1';
$sponsored_card_min_width = max(160, min(420, (int)gs_setting('sponsored_card_min_width','220')));
// Real gap fix: explicit mobile column control. 0 = auto (responsive
// min-width grid, same as desktop behavior); 1-4 = force exactly that many
// columns on mobile regardless of card width, giving direct control back
// without losing the automatic responsive behavior as the default.
$sponsored_mobile_columns = max(0, min(4, (int)gs_setting('sponsored_mobile_columns','0')));
$featured_count   = max(4, min(12, (int)gs_setting('featured_on_home','8')));

// Latest Listings device-specific layout — decodes the JSON saved by the
// admin layout manager, with the same validation applied on read as on
// save (defense in depth: never trust a stored value is still valid, in
// case the setting was edited directly in the database).
$ll_defaults = [
    'mobile'  => [ 'layout'=>'horizontal-scroll', 'columns'=>1, 'card_min_width'=>240, 'card_height'=>'auto', 'card_height_px'=>260, 'gap'=>10, 'aspect_ratio'=>'4/3',
                   'show_title'=>true, 'show_rating'=>true, 'show_location'=>true, 'show_badges'=>true, 'show_buttons'=>true, 'section_width'=>'contained', 'section_align'=>'left' ],
    'tablet'  => [ 'layout'=>'grid', 'columns'=>2, 'card_min_width'=>220, 'card_height'=>'auto', 'card_height_px'=>260, 'gap'=>14, 'aspect_ratio'=>'4/3',
                   'show_title'=>true, 'show_rating'=>true, 'show_location'=>true, 'show_badges'=>true, 'show_buttons'=>true, 'section_width'=>'contained', 'section_align'=>'left' ],
    'desktop' => [ 'layout'=>'grid', 'columns'=>4, 'card_min_width'=>240, 'card_height'=>'auto', 'card_height_px'=>260, 'gap'=>16, 'aspect_ratio'=>'4/3',
                   'show_title'=>true, 'show_rating'=>true, 'show_location'=>true, 'show_badges'=>true, 'show_buttons'=>true, 'section_width'=>'contained', 'section_align'=>'left' ],
];
$ll_raw = json_decode( (string) gs_setting('latest_listings_layout', ''), true );
$ll_layout = [];
foreach ( $ll_defaults as $device => $def ) {
    $d = is_array( $ll_raw[$device] ?? null ) ? $ll_raw[$device] : [];
    $ll_layout[$device] = [
        'layout'         => in_array( $d['layout'] ?? '', ['grid','vertical-list','horizontal-scroll','carousel'], true ) ? $d['layout'] : $def['layout'],
        'columns'        => max(1, min(6, (int)($d['columns'] ?? $def['columns']))),
        'card_min_width' => max(120, min(480, (int)($d['card_min_width'] ?? $def['card_min_width']))),
        'card_height'    => in_array( $d['card_height'] ?? '', ['auto','fixed'], true ) ? $d['card_height'] : $def['card_height'],
        'card_height_px' => max(100, min(600, (int)($d['card_height_px'] ?? $def['card_height_px']))),
        'gap'            => max(0, min(48, (int)($d['gap'] ?? $def['gap']))),
        'aspect_ratio'   => preg_match('#^\d{1,2}/\d{1,2}$#', (string)($d['aspect_ratio'] ?? '')) ? $d['aspect_ratio'] : $def['aspect_ratio'],
        'show_title'     => array_key_exists('show_title', $d) ? (bool)$d['show_title'] : $def['show_title'],
        'show_rating'    => array_key_exists('show_rating', $d) ? (bool)$d['show_rating'] : $def['show_rating'],
        'show_location'  => array_key_exists('show_location', $d) ? (bool)$d['show_location'] : $def['show_location'],
        'show_badges'    => array_key_exists('show_badges', $d) ? (bool)$d['show_badges'] : $def['show_badges'],
        'show_buttons'   => array_key_exists('show_buttons', $d) ? (bool)$d['show_buttons'] : $def['show_buttons'],
        'section_width'  => in_array( $d['section_width'] ?? '', ['contained','full'], true ) ? $d['section_width'] : $def['section_width'],
        'section_align'  => in_array( $d['section_align'] ?? '', ['left','center'], true ) ? $d['section_align'] : $def['section_align'],
    ];
}

/* ── DB data ─────────────────────────────────────── */
global $wpdb; $pfx = $wpdb->prefix . 'gs_';
try {
    $cats     = (new CategoryRepository())->get_all_active() ?: [];
    $featured = (new ListingRepository())->get_featured($featured_count) ?: [];
    $cities   = (new ListingRepository())->get_cities() ?: [];
} catch(\Throwable $e) {
    $cats = $featured = $cities = [];
}

$top_cats = array_values(array_filter((array)$cats, fn($c) => !$c->parent_id));

$top_cities = $wpdb->get_results(
    "SELECT city, COUNT(*) AS n FROM {$pfx}listings WHERE status='active' AND city!='' GROUP BY city ORDER BY n DESC LIMIT 14"
) ?: [];

$sponsored = [];
if ($show_sponsored) {
    $sponsored = $wpdb->get_results($wpdb->prepare(
        "SELECT l.*, c.name AS cat_name, c.icon_emoji AS cat_icon,
                vp.verification_status, vp.avg_reply_minutes
         FROM {$pfx}listings l
         LEFT JOIN {$pfx}categories c ON c.id = l.category_id
         LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
         WHERE l.status='active' AND l.is_featured=1
         ORDER BY l.views_count DESC LIMIT %d",
        $sponsored_count
    )) ?: [];
}

/* Latest listings (not necessarily featured) */
$latest = $wpdb->get_results($wpdb->prepare(
    "SELECT l.*, c.name AS cat_name, c.icon_emoji AS cat_icon,
            vp.verification_status, vp.avg_reply_minutes
     FROM {$pfx}listings l
     LEFT JOIN {$pfx}categories c ON c.id=l.category_id
     LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
     WHERE l.status='active'
     ORDER BY l.created_at DESC LIMIT %d",
    $sponsored_total
)) ?: [];

$stats = [
    'services' => (int)($wpdb->get_var("SELECT COUNT(*) FROM {$pfx}listings WHERE status='active'") ?? 0),
    'vendors'  => (int)($wpdb->get_var("SELECT COUNT(*) FROM {$pfx}vendor_profiles WHERE is_active=1") ?? 0),
    'cities'   => (int)($wpdb->get_var("SELECT COUNT(DISTINCT city) FROM {$pfx}listings WHERE status='active' AND city!=''") ?? 0),
    'reviews'  => (int)($wpdb->get_var("SELECT COUNT(*) FROM {$pfx}reviews WHERE status='approved'") ?? 0),
    'avg_rating' => (float)($wpdb->get_var("SELECT AVG(rating) FROM {$pfx}reviews WHERE status='approved'") ?? 0),
];
// Real gap fix: the hero trust bar should never show a fabricated number. If there
// are genuinely zero reviews yet, avg_rating stays 0 and the template below hides
// the rating stat entirely rather than inventing a placeholder score.
$stats['avg_rating_display'] = $stats['avg_rating'] > 0 ? number_format($stats['avg_rating'], 1) : '';

// Part 20.1 — Live trust strip (safe queries - both columns exist in original schema)
$today_inquiries = (int) ( $wpdb->get_var( "SELECT COUNT(*) FROM {$pfx}leads WHERE DATE(created_at) = CURDATE()" ) ?? 0 );

// Part 20.3 — Trending services chip data
$trending_services = $wpdb->get_results(
    "SELECT inquiry_module AS cat, COUNT(*) AS cnt FROM {$pfx}leads
     WHERE created_at > DATE_SUB(NOW(), INTERVAL 7 DAY) AND inquiry_module != ''
     GROUP BY inquiry_module ORDER BY cnt DESC LIMIT 6"
) ?: [];

$popular_tags = ['Passport','Birth Certificate','GST Filing','Company Registration','Name Change','Marriage Certificate','Degree Certificate','Apostille'];

$why_items = [
    ['icon'=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10Z"/><path d="m9 12 2 2 4-4"/></svg>','title'=>'100% Verified',    'desc'=>'Every provider is background-checked and document-verified before listing.'],
    ['icon'=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="10" cy="10" r="6"/><path d="m20 20-4.5-4.5"/></svg>','title'=>'Smart Search',      'desc'=>'Find exactly what you need by service, city, or category in seconds.'],
    ['icon'=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 2 2.9 6.3 6.9.8-5.1 4.8 1.4 6.8L12 17.3l-6.1 3.4 1.4-6.8-5.1-4.8 6.9-.8L12 2Z"/></svg>','title'=>'Genuine Reviews',   'desc'=>'Read real reviews from actual customers who have used the services.'],
    ['icon'=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M13 2 3 14h7l-1 8 10-12h-7l1-8Z"/></svg>','title'=>'Instant Response',  'desc'=>'Get quotes from multiple providers within minutes of posting.'],
    ['icon'=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 21h8M12 17v4M7 4h10v4a5 5 0 0 1-10 0V4Z"/><path d="M7 6H4a2 2 0 0 0 2 4M17 6h3a2 2 0 0 1-2 4"/></svg>','title'=>'Local Expertise',   'desc'=>'Specialists in your city who understand your local requirements.'],
    ['icon'=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8.5 14.5 4 19M11 4a3 3 0 1 0 0 6 3 3 0 0 0 0-6ZM17.5 10a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5ZM3 19v-1.5A3.5 3.5 0 0 1 6.5 14h3a3.5 3.5 0 0 1 3.4 2.7"/><path d="M14.5 12.5c1.5-1 3.8-.9 5.3.6 1.5 1.5 1.5 3.5.7 4.9"/></svg>','title'=>'Dedicated Support', 'desc'=>'Our team is always ready to help you through every step.'],
];
$how_steps = [
    ['icon'=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="10" cy="10" r="6"/><path d="m20 20-4.5-4.5"/></svg>','title'=>'Search','desc'=>'Browse verified providers by service, city, or category.'],
    ['icon'=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3v18M7 6H3l3 8a3 3 0 0 0 6 0l-3-8H7ZM17 6h4l-3 8a3 3 0 0 1-6 0l3-8h2Z"/></svg>','title'=>'Compare','desc'=>'View profiles, ratings and get quotes from multiple providers.'],
    ['icon'=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5Z"/></svg>','title'=>'Contact','desc'=>'Send an inquiry directly and hear back — no forms filled out twice.'],
    ['icon'=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"/><path d="m22 4-10 10-3-3"/></svg>','title'=>'Hire','desc'=>'Connect with your chosen expert and get professional help fast.'],
];
// Real gap fix: this used to be three fabricated named "testimonials" (Priya
// Sharma, Rahul Verma, Anita Singh) with invented quotes — presented as real
// customer reviews while the Why Choose Us section above it promises "Genuine
// Reviews... from actual customers." Replaced with a genuine query against the
// same reviews table already used correctly elsewhere on this platform. If
// there are no real approved reviews with text yet, this is empty and the
// section below hides itself rather than fabricating content.
$testimonials_raw = $wpdb->get_results(
    "SELECT r.reviewer_name, r.rating, r.review_text, r.created_at,
            l.title AS service_title, l.city
     FROM {$pfx}reviews r
     LEFT JOIN {$pfx}listings l ON l.id = r.listing_id
     WHERE r.status='approved' AND r.review_text != '' AND r.rating >= 4
     ORDER BY r.created_at DESC LIMIT 6"
) ?: [];
$testimonials = array_map(function($r) {
    return [
        'name'    => $r->reviewer_name ?: 'Verified Customer',
        'city'    => $r->city ?: '',
        'text'    => $r->review_text,
        'rating'  => (int) $r->rating,
        'service' => $r->service_title ?: 'Service',
    ];
}, $testimonials_raw);
$faq_items = [
    ['q'=>'How are service providers verified?',       'a'=>'Every provider goes through document verification and background checks before listing.'],
    ['q'=>'Is it free to find service providers?',     'a'=>'Yes, browsing and contacting providers is completely free. No hidden charges.'],
    ['q'=>'How quickly will I get a response?',        'a'=>'Most verified providers respond within 2–4 hours. Premium providers within 1 hour.'],
    ['q'=>'Can I compare multiple providers?',         'a'=>'Yes! View profiles, ratings, and pricing of multiple providers before deciding.'],
    ['q'=>'What if I have a problem with a provider?', 'a'=>'Our support team handles all disputes and mediates resolutions within 48 hours.'],
];

$ajax_url = admin_url('admin-ajax.php');
$nonce    = wp_create_nonce('gs_ajax');
$dir_url  = home_url('/directory/');
$reg_url  = home_url('/vendor/register/');
$login_url= home_url('/vendor/login/');
$dash_url = is_user_logged_in() ? ( function_exists('gs_login_redirect') ? gs_login_redirect() : (gs_is_admin_level() ? home_url('/admin-panel/') : home_url('/vendor/dashboard/')) ) : '';
?>
<style>
@import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');
/* ══════════════════════════════════════════════════════
   GoodService Homepage — premium marketplace redesign
══════════════════════════════════════════════════════ */
:root{
  --P:<?php echo esc_attr($primary_color);?>;
  --PD:#1D4ED8;--N:#111827;--N2:#1F2937;--G:#1C1C1C;--GD:#000;
  --BG:#F7F7F7;--BD:#E5E5E5;--TX:#222222;--MU:#6B6B6B;--WH:#fff;
  --R:12px;--SH:0 2px 12px rgba(0,0,0,.06);
  --F:'Plus Jakarta Sans',-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html{font-size:16px;scroll-behavior:smooth}
body{margin:0;padding:0;background:#fff;font-family:var(--F);color:var(--TX);-webkit-font-smoothing:antialiased;min-height:100vh}
a{text-decoration:none;color:inherit}
img{max-width:100%;display:block}
button,input,select,textarea{font-family:var(--F);font-size:15px}
h1,h2,h3,h4,h5,h6{font-weight:800;line-height:1.2;color:var(--N);margin:0}
ul,ol{list-style:none}
#wpadminbar{display:none!important}
.hw{max-width:1220px;margin:0 auto;padding:0 24px;width:100%}

/* ── BUTTONS ── */
.btn{display:inline-flex;align-items:center;justify-content:center;gap:7px;padding:11px 24px;border-radius:8px;font-size:14px;font-weight:700;cursor:pointer;border:none;transition:all .18s;text-decoration:none;line-height:1;font-family:var(--F);white-space:nowrap}
.btn-p{background:var(--P);color:#fff}.btn-p:hover{background:var(--PD);transform:translateY(-1px);box-shadow:0 6px 20px rgba(37,99,235,.3)}
.btn-o{background:transparent;color:var(--P);border:2px solid var(--P)}.btn-o:hover{background:var(--P);color:#fff}
.btn-g{background:var(--G);color:#fff}.btn-g:hover{background:var(--GD);transform:translateY(-1px);box-shadow:0 6px 20px rgba(255,102,0,.3)}
.btn-wh{background:rgba(255,255,255,.15);color:#fff;border:1.5px solid rgba(255,255,255,.3)}.btn-wh:hover{background:rgba(255,255,255,.25)}
.btn-sm{padding:8px 18px;font-size:13px}
.btn-lg{padding:14px 32px;font-size:16px}

/* ── NAV ── */
#hn{position:sticky;top:0;z-index:9999;background:rgba(255,255,255,.97);backdrop-filter:blur(20px);border-bottom:1px solid var(--BD);box-shadow:0 1px 8px rgba(0,0,0,.06)}
#hn-in{display:flex;align-items:center;gap:20px;height:68px}
#hn-logo{display:flex;align-items:center;gap:10px;flex-shrink:0;font-size:20px;font-weight:900;color:var(--N);letter-spacing:-.02em}
#hn-logo img{height:40px;border-radius:7px}
#hn-links{display:flex;align-items:center;gap:2px;flex:1}
#hn-links a{padding:7px 15px;border-radius:7px;font-size:14px;font-weight:600;color:var(--MU);transition:all .15s}
#hn-links a:hover{background:var(--BG);color:var(--TX)}
.hn-dd{position:relative}
.hn-dd-trigger{display:flex;align-items:center;gap:4px;padding:7px 15px;border-radius:7px;font-size:14px;font-weight:600;color:var(--MU);background:none;border:none;cursor:pointer;font-family:inherit;transition:all .15s}
.hn-dd-trigger:hover,.hn-dd.open .hn-dd-trigger{background:var(--BG);color:var(--TX)}
.hn-dd-caret{font-size:10px;transition:transform .15s}
.hn-dd.open .hn-dd-caret{transform:rotate(180deg)}
.hn-dd-menu{position:absolute;top:calc(100% + 6px);left:0;background:#fff;border:1px solid var(--BD);border-radius:10px;box-shadow:0 12px 32px -8px rgba(0,0,0,.14);padding:6px;min-width:180px;opacity:0;visibility:hidden;transform:translateY(-4px);transition:opacity .15s,transform .15s,visibility .15s;z-index:100}
.hn-dd.open .hn-dd-menu{opacity:1;visibility:visible;transform:translateY(0)}
.hn-dd-menu a{display:block;padding:9px 12px;border-radius:7px;font-size:13.5px;font-weight:600;color:var(--TX);white-space:nowrap}
.hn-dd-menu a:hover{background:var(--BG)}
#hn-acts{display:flex;align-items:center;gap:10px;flex-shrink:0}
#hn-mob{display:none;background:none;border:none;font-size:24px;cursor:pointer;color:var(--N)}
#hn-drw{display:none;flex-direction:column;gap:4px;padding:10px 20px 16px;border-top:1px solid var(--BD);background:#fff}
#hn-drw.open{display:flex}
#hn-drw a{padding:10px 14px;border-radius:8px;font-size:14px;font-weight:600;color:var(--MU)}
#hn-drw a:hover{background:var(--BG);color:var(--TX)}

/* ══════════════════════════════════════════════════
   HERO — Minimal, centered, compact
══════════════════════════════════════════════════ */
#hero{
  background:
    radial-gradient(ellipse 900px 500px at 15% -10%, rgba(37,99,235,.28) 0%, transparent 60%),
    radial-gradient(ellipse 700px 600px at 100% 10%, rgba(245,158,11,.10) 0%, transparent 55%),
    radial-gradient(ellipse 1000px 700px at 50% 120%, rgba(29,78,216,.18) 0%, transparent 60%),
    linear-gradient(160deg,#0D0D0D 0%,#1A1A1A 45%,#111827 100%);
  padding:80px 0 88px;min-height:520px;display:flex;align-items:center;position:relative;
  /* Real fix — forces the entire hero section, including the search
     dropdown that visually extends below its own boundary, to be
     treated as one atomic layer when compared against page content
     below it (like the sponsored cards), removing any ambiguity from
     nested stacking contexts several elements deep. */
  isolation:isolate;z-index:9500;
}
#hero::before{
  /* Fine grain texture — replaces the flat checkerboard, reads as premium
     photographic depth rather than a printed pattern at any zoom level. */
  content:'';position:absolute;inset:0;pointer-events:none;opacity:.5;mix-blend-mode:overlay;
  background:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='120' height='120'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.35'/%3E%3C/svg%3E");
}
#hero::after{
  /* Soft glow anchored behind the search pill — draws the eye to the one
     element that actually converts, instead of leaving it floating on flat color.
     Real fix: was a fixed 1100px width, which is why #hero needed
     overflow:hidden in the first place — that same overflow:hidden was
     clipping the search dropdown below the hero's boundary. Percentage width
     scales safely at every screen size, so no clipping ancestor is needed. */
  content:'';position:absolute;left:50%;top:62%;width:95%;height:340px;transform:translate(-50%,-50%);
  background:radial-gradient(ellipse,rgba(255,255,255,.10) 0%,transparent 70%);pointer-events:none;
}
#hero-in{position:relative;text-align:center;z-index:2}
#srch-wrap{max-width:900px;margin:0 auto;position:relative;z-index:9100;isolation:isolate}
#hero h1{font-size:clamp(30px,4.4vw,52px);color:#fff;line-height:1.14;letter-spacing:-.025em;margin-bottom:10px;font-weight:800}
#hero-accent{color:#F59E0B;display:inline;position:relative}
#hero-sub{font-size:clamp(15px,1.6vw,18px);color:rgba(255,255,255,.76);margin-bottom:36px;font-weight:400;max-width:560px;margin-left:auto;margin-right:auto}

/* ── Honest trust bar — real counts only, zero fabricated numbers ── */
.hero-trust{display:flex;align-items:center;justify-content:center;gap:0;flex-wrap:wrap;margin-top:32px;position:relative;z-index:2}
.hero-trust-item{display:flex;align-items:center;gap:8px;padding:0 22px;color:rgba(255,255,255,.85);font-size:13.5px}
.hero-trust-item:not(:last-child){border-right:1px solid rgba(255,255,255,.18)}
.hero-trust-n{font-weight:800;color:#fff;font-size:15px}
.hero-trust-ic{opacity:.85;font-size:14px}
@media(max-width:640px){.hero-trust-item{padding:6px 14px;border-right:none !important}.hero-trust{gap:4px}}

/* ══════════════════════════════════════════════════
   AIRBNB-STYLE SEARCH PILL
══════════════════════════════════════════════════ */

/* Full-page overlay behind open dropdown */
#sp-overlay{
  display:none;position:fixed;inset:0;
  background:rgba(0,0,0,.32);z-index:9000;
  animation:spOvIn .2s ease;
}
#sp-overlay.show{display:block}
@keyframes spOvIn{from{opacity:0}to{opacity:1}}

/* Wrapper */
/* Wrapper — defined above with isolation:isolate */

/* ── THE PILL ── */
#srch-pill{
  background:#fff;
  border-radius:40px;
  box-shadow:0 4px 28px rgba(0,0,0,.22);
  display:flex;align-items:center;
  height:68px;
  padding:6px 6px 6px 0;
  transition:box-shadow .25s;
  position:relative;
  z-index:9101;
}
#srch-pill:hover{box-shadow:0 8px 36px rgba(0,0,0,.26)}

/* ── SEGMENTS ── */
.sp-s{
  flex:1;min-width:0;height:100%;
  display:flex;flex-direction:column;justify-content:center;
  padding:0 28px;
  cursor:pointer;border-radius:40px;
  /* Real fix — was only a background-color fade; this is the actual
     cause of the "abrupt" feeling reported. Multi-property transition
     (flex-grow, transform, opacity) using the same cubic-bezier curve
     already proven for the dropdown-open animation below, so the whole
     component eases consistently, not just this one part. */
  transition:flex-grow .32s cubic-bezier(.2,.8,.3,1),background .18s,opacity .28s cubic-bezier(.2,.8,.3,1),transform .28s cubic-bezier(.2,.8,.3,1);
  position:relative;user-select:none;
}
.sp-s:first-child{padding-left:32px}
.sp-s:hover:not(.sp-active){background:#F7F7F7}
.sp-s.sp-active{
  background:#fff;
  border-radius:40px;
  box-shadow:0 2px 24px rgba(0,0,0,.15);
  z-index:9102;
  /* Real feature — the actual Airbnb-style effect: the focused field
     visibly grows to make room for its dropdown content, rather than
     just changing color while staying the same size. */
  flex-grow:2.2;
}
/* Real feature — neighbors gently yield space and dim slightly while
   another segment is focused, matching Airbnb's actual de-emphasis of
   fields you're not currently on — this only applies when something
   else is active, never to the segment itself. */
#srch-pill:has(.sp-active) .sp-s:not(.sp-active){
  flex-grow:.7;
  opacity:.55;
}
#srch-pill:has(.sp-active) .sp-s:not(.sp-active):hover{
  opacity:.85;
}
@media(prefers-reduced-motion:reduce){
  .sp-s,.sp-s.sp-active,#srch-pill:has(.sp-active) .sp-s:not(.sp-active){
    transition:background .18s!important;flex-grow:1!important;opacity:1!important;
  }
}

/* Label + value */
.sp-lbl{
  font-size:11px;font-weight:800;color:#222;
  letter-spacing:.02em;line-height:1;margin-bottom:3px;
  white-space:nowrap;
}
.sp-val{
  font-size:14px;color:#717171;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
  line-height:1.25;
}
.sp-val.sp-filled{color:#222222;font-weight:600}

/* Clear "×" button inside active segment */
.sp-clear{
  display:none;position:absolute;right:18px;top:50%;transform:translateY(-50%);
  width:22px;height:22px;border-radius:50%;background:#EBEBEB;
  border:none;cursor:pointer;font-size:14px;line-height:22px;text-align:center;
  color:#555;transition:background .15s;flex-shrink:0;padding:0;
}
.sp-clear:hover{background:#DDDDDD}
.sp-s.sp-active .sp-clear.sp-has-val{display:flex;align-items:center;justify-content:center}

/* ── DIVIDERS ── */
.sp-div{width:1px;height:32px;background:#DDDDDD;flex-shrink:0;transition:opacity .15s}
.sp-div.sp-hide{opacity:0;pointer-events:none}

/* ── SEARCH BUTTON ── */
#srch-btn{
  flex-shrink:0;
  width:52px;height:52px;border-radius:50%;
  background:var(--G);border:none;cursor:pointer;
  display:flex;align-items:center;justify-content:center;
  margin-left:6px;margin-right:2px;
  transition:all .2s;
  box-shadow:none;
  position:relative;overflow:hidden;
}
#srch-btn::before{
  content:'';position:absolute;inset:0;border-radius:50%;
  background:rgba(255,255,255,0);transition:background .15s;
}
#srch-btn:hover{background:var(--GD);transform:scale(1.06);box-shadow:0 6px 20px rgba(255,102,0,.4)}
#srch-btn:hover::before{background:rgba(255,255,255,.1)}
#srch-btn:active{transform:scale(.97)}
#srch-btn svg{pointer-events:none;flex-shrink:0}

/* ── DROPDOWN PANELS ── */
.sp-drop{
  display:none;
  position:absolute;
  top:calc(100% + 16px);
  left:0;
  background:#fff;
  border-radius:24px;
  box-shadow:0 10px 60px rgba(0,0,0,.16),0 2px 18px rgba(0,0,0,.08);
  padding:28px 24px 24px;
  min-width:380px;
  z-index:9103;
  animation:spDrop .22s cubic-bezier(.2,.8,.3,1);
}
.sp-drop.sp-drop-city{min-width:500px}
.sp-drop.sp-drop-cat{min-width:520px;left:auto;right:0}
@keyframes spDrop{
  from{opacity:0;transform:translateY(-10px) scale(.97)}
  to  {opacity:1;transform:translateY(0)  scale(1)}
}
.sp-s.sp-active .sp-drop{display:block}

/* Dropdown section title */
.sp-dt{
  font-size:10.5px;font-weight:800;text-transform:uppercase;
  letter-spacing:.12em;color:#717171;margin-bottom:14px;
}

/* ── DROPDOWN: WHAT (keyword) ── */
.sp-kw-wrap{
  display:flex;align-items:center;gap:8px;
  background:#F7F7F7;border-radius:14px;
  padding:0 14px;height:48px;
  border:1.5px solid #EBEBEB;
  transition:border .18s;
}
.sp-kw-wrap:focus-within{border-color:#222;background:#fff}
.sp-kw-wrap svg{flex-shrink:0;opacity:.4}
#hkw{
  flex:1;border:none;outline:none;background:none;
  font-size:15px;color:#222;font-family:var(--F);
}
#hkw::placeholder{color:#B0B0B0}

.sp-tag-grid{display:flex;flex-wrap:wrap;gap:7px;margin-top:16px}
.sp-tag{
  display:inline-flex;align-items:center;gap:5px;
  padding:7px 13px;border-radius:24px;
  background:#F7F7F7;border:1.5px solid #EBEBEB;
  font-size:12px;font-weight:600;color:#333;
  cursor:pointer;transition:all .15s;
}
.sp-tag:hover{border-color:#222;background:#fff}

/* ── DROPDOWN: WHERE (cities) ── */
.sp-city-grid{
  display:grid;grid-template-columns:1fr 1fr;
  gap:6px;max-height:300px;overflow-y:auto;
  scrollbar-width:thin;scrollbar-color:#ddd #fff;
}
.sp-ci{
  display:flex;align-items:center;gap:10px;
  padding:10px 12px;border-radius:12px;
  cursor:pointer;transition:background .13s;
}
.sp-ci:hover,.sp-ci.sp-sel{background:#F7F7F7}
.sp-ci.sp-sel .sp-ci-name{font-weight:700;color:#222}
.sp-ci-ic{
  width:38px;height:38px;border-radius:10px;background:#F0F4FF;
  display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0;
}
.sp-ci-name{font-size:13px;font-weight:500;color:#333}
.sp-ci-count{font-size:11px;color:#999;margin-top:1px}

/* Any city / clear option */
.sp-ci-any{
  grid-column:1/-1;
  display:flex;align-items:center;gap:8px;
  padding:10px 12px;border-radius:12px;cursor:pointer;
  border-bottom:1px solid #F0F0F0;margin-bottom:4px;
  transition:background .13s;font-size:13px;font-weight:600;color:#555;
}
.sp-ci-any:hover{background:#F7F7F7}

/* ── DROPDOWN: CATEGORY ── */
.sp-cat-grid{
  display:grid;grid-template-columns:repeat(3,1fr);
  gap:8px;max-height:300px;overflow-y:auto;
  scrollbar-width:thin;scrollbar-color:#ddd #fff;
}
.sp-ca{
  display:flex;flex-direction:column;align-items:center;gap:5px;
  padding:14px 8px;border-radius:14px;
  border:1.5px solid #EBEBEB;
  cursor:pointer;text-align:center;transition:all .15s;
}
.sp-ca:hover,.sp-ca.sp-sel{border-color:#222;background:#F7F7F7}
.sp-ca.sp-sel{border-color:#222}
.sp-ca-ic{font-size:24px;line-height:1}
.sp-ca-nm{font-size:11px;font-weight:700;color:#333;line-height:1.3;margin-top:2px}

/* Any category option */
.sp-ca-any{
  grid-column:1/-1;
  display:flex;align-items:center;justify-content:center;gap:8px;
  padding:10px;border-radius:12px;
  border:1.5px dashed #DDDDDD;
  cursor:pointer;font-size:13px;font-weight:600;color:#555;
  transition:all .15s;margin-bottom:4px;
}
.sp-ca-any:hover{border-color:#222;background:#F7F7F7}
.sp-ca-any.sp-sel{border-color:#222;background:#F7F7F7}

/* ── POPULAR TAGS (below pill on hero) ── */
#hero-tags{display:flex;flex-wrap:wrap;gap:7px;margin-top:18px;justify-content:center}
.htag{
  background:rgba(255,255,255,.13);border:1px solid rgba(255,255,255,.24);
  color:rgba(255,255,255,.9);border-radius:20px;padding:5px 13px;
  font-size:12px;font-weight:600;cursor:pointer;transition:all .17s;
}
.htag:hover{background:rgba(255,255,255,.25);border-color:rgba(255,255,255,.5);transform:translateY(-1px)}

/* ── SECTIONS ── */
.hs{padding:48px 0}
.hs-alt{background:var(--BG)}
.hs-dk{background:linear-gradient(135deg,#0F2340,#1a56db)}
.hs-hdr{text-align:center;margin-bottom:48px}
.ey{font-size:12px;font-weight:800;letter-spacing:.12em;text-transform:uppercase;color:var(--G);margin-bottom:8px}
.ey-w{color:rgba(255,255,255,.6)}
.ht{font-size:clamp(22px,3vw,34px);margin-bottom:10px}
.ht-w{color:#fff}
.hs-sub{font-size:15px;color:var(--MU);max-width:520px;margin:0 auto;line-height:1.7}
.dv{width:44px;height:4px;background:var(--P);border-radius:99px;margin:14px auto 0}
.dv-g{background:var(--G)}

/* ══════════════════════════════════════════════════
   SPONSORED LISTINGS (OnlineX Sewa style)
══════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════
   FEATURED LISTINGS — photo-forward, the visual anchor
   of the page (previously undersized at 252px/148px img,
   now proportioned closer to real photo-marketplace cards)
══════════════════════════════════════════════════ */
#sponsored{background:#fff;padding:<?php echo (int)$sponsored_padding_y; ?>px 0 <?php echo (int)$sponsored_padding_y; ?>px;position:relative;z-index:1}
/* Real gap fix: overrides the sitewide 1220px .hw cap for this section only,
   when the admin enables the full-width toggle — this is the actual source
   of the blank left/right margin, not something a column-count setting
   could ever fix. */
.hw.spn-hw-wide{max-width:98vw}
/* Row header — plain bold title + small circular arrow, matching the
   reference exactly instead of an eyebrow label + bordered pill button. */
.spn-hdr{display:flex;align-items:center;gap:10px;margin-bottom:20px}
.spn-hdr-title{font-size:20px;font-weight:800;color:var(--TX);letter-spacing:-.01em}
.spn-hdr-arrow{
  width:32px;height:32px;border-radius:50%;border:1px solid var(--BD);
  display:flex;align-items:center;justify-content:center;color:var(--TX);
  font-size:14px;transition:all .15s;flex-shrink:0;
}
.spn-hdr-arrow:hover{background:var(--BG);border-color:var(--TX)}
#spn-scroll{overflow:visible}
#spn-row{display:grid;grid-template-columns:repeat(auto-fill,minmax(<?php echo (int)$sponsored_card_min_width; ?>px,1fr));gap:22px 16px}
.spn-card{
  display:block;background:#fff;overflow:hidden;
  transition:all .18s ease;text-decoration:none;
}
.spn-card:hover .spn-img img{transform:scale(1.04)}
.spn-img{aspect-ratio:1/1;background:#F1F5F9;overflow:hidden;position:relative;border-radius:14px}
/* Real fix (follow-up, per explicit request): switched to object-fit:fill —
   the image stretches to exactly fill the square card with no cropping and
   no letterbox gaps (unlike contain, which was used first and left empty
   space around non-square images). fill can distort a non-square image's
   proportions; that trade-off was requested explicitly over contain's
   letterboxing. */
.spn-img img{width:100%;height:100%;object-fit:fill;transition:transform .3s ease}
.spn-img-ph{width:100%;height:100%;display:flex;align-items:center;justify-content:center;position:relative;background:linear-gradient(150deg,#F8FAFC,#EEF2F7)}
.spn-img-ph::before{
  content:'';position:absolute;inset:0;opacity:.5;
  background-image:radial-gradient(#CBD5E1 1px,transparent 1px);background-size:16px 16px;
}
.spn-img-ph span{
  position:relative;font-size:2.4rem;width:72px;height:72px;border-radius:50%;
  display:flex;align-items:center;justify-content:center;
  background:#fff;box-shadow:0 8px 20px -6px rgba(15,35,64,.12);
}
/* Verified badge — plain white pill, matching the reference's "Guest
   favourite" badge exactly (position, size, weight, no color). Only renders
   when the vendor's actual verification_status is 'verified', never assumed. */
.spn-badge{position:absolute;top:10px;left:10px;z-index:1;background:#fff;color:#222;font-size:11px;font-weight:600;padding:5px 10px;border-radius:20px;box-shadow:0 1px 4px rgba(0,0,0,.18)}
/* Heart / save button — matches the reference's exact top-right position. */
.spn-heart{position:absolute;top:10px;right:10px;z-index:1;background:none;border:none;padding:0;cursor:pointer;display:flex;filter:drop-shadow(0 1px 2px rgba(0,0,0,.3))}
.spn-body{padding:8px 0 0}
.spn-title{font-size:14px;font-weight:600;color:var(--TX);margin-bottom:2px;line-height:1.35;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.spn-meta{font-size:14px;color:var(--MU);line-height:1.35;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}

/* ══════════════════════════════════════════════════
   SERVICES — Airbnb-style photo gallery.
   Real photo per category (icon_url, admin-set) with a
   graceful icon-on-gradient fallback when no photo is set
   yet — the layout is correct either way, matching the
   minimal photo + plain label pattern from the reference.
══════════════════════════════════════════════════ */
.cat-gal-hdr{margin-bottom:16px}
.cat-gal-title{font-size:19px;font-weight:800;color:var(--TX);letter-spacing:-.01em}
#cat-gallery{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:16px 12px}
.cat-gal-card{text-decoration:none;display:block}
.cat-gal-img{
  aspect-ratio:1/1;border-radius:14px;overflow:hidden;background:#F1F5F9;
  margin-bottom:8px;position:relative;
}
.cat-gal-img img{width:100%;height:100%;object-fit:cover;transition:transform .3s ease}
.cat-gal-card:hover .cat-gal-img img{transform:scale(1.06)}
.cat-gal-img-ph{
  width:100%;height:100%;display:flex;align-items:center;justify-content:center;
  background:linear-gradient(150deg,#EFF6FF,#DBEAFE);
}
.cat-gal-img-ph span{font-size:34px;line-height:1}
.cat-gal-nm{font-size:13.5px;font-weight:700;color:var(--TX);line-height:1.3}

/* ══════════════════════════════════════════════════
   DISCOVER CITIES (Sulekha style)
══════════════════════════════════════════════════ */
#cities{background:var(--BG);padding:56px 0}
.city-grid{display:flex;flex-wrap:wrap;gap:10px;justify-content:center}
.city-pill{
  display:inline-flex;align-items:center;gap:8px;
  padding:8px 18px;background:#fff;border:1.5px solid var(--BD);border-radius:24px;
  font-size:13px;font-weight:600;color:var(--TX);transition:all .18s;
  text-decoration:none;cursor:pointer;
}
.city-pill:hover{border-color:var(--P);background:#EFF6FF;color:var(--P)}
.city-pill-n{background:#EFF6FF;color:var(--P);border-radius:10px;padding:1px 7px;font-size:10px;font-weight:700}

/* ══════════════════════════════════════════════════
   LATEST LISTINGS (IndiaOnline / compact card style)
══════════════════════════════════════════════════ */
.ll-list{display:flex;flex-direction:column;gap:12px}
.ll-card{
  display:flex;align-items:stretch;gap:0;
  background:#fff;border:1.5px solid #E8EDF4;border-radius:10px;
  overflow:hidden;transition:box-shadow .2s;text-decoration:none;color:inherit;
}
.ll-card:hover{box-shadow:0 4px 18px rgba(0,0,0,.1);border-color:#CBD5E1}
.ll-img{width:110px;min-width:110px;background:#F1F5F9;flex-shrink:0;overflow:hidden;display:flex;align-items:center;justify-content:center;font-size:2rem;color:#CBD5E1}
.ll-img img{width:100%;height:100%;object-fit:cover;display:block}
.ll-body{flex:1;padding:14px 16px;min-width:0;display:flex;flex-direction:column;gap:4px}
.ll-cat{font-size:10px;font-weight:700;color:var(--P);text-transform:uppercase;letter-spacing:.06em}
.ll-title{font-size:14px;font-weight:700;color:var(--N);line-height:1.3}
.ll-city{font-size:12px;color:var(--MU)}
.ll-rat{font-size:12px;color:#F59E0B;font-weight:700;margin-top:auto}
.ll-actions{display:flex;align-items:center;justify-content:flex-end;padding:12px 16px;gap:8px;border-left:1px solid #F1F5F9;flex-shrink:0;flex-direction:column;min-width:100px}
.ll-btn{display:block;padding:7px 14px;border-radius:6px;font-size:11px;font-weight:700;text-align:center;white-space:nowrap}
.ll-btn-v{background:var(--G);color:#fff}.ll-btn-v:hover{background:var(--GD)}
.ll-btn-d{border:1.5px solid #E2E8F0;color:var(--MU);background:#fff}.ll-btn-d:hover{border-color:var(--P);color:var(--P)}

/* ══════════════════════════════════════════════════
   STATS BAND
══════════════════════════════════════════════════ */
#stats{background:var(--G);padding:0}
#stats-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr))}
.st{text-align:center;padding:32px 20px;border-right:1px solid rgba(255,255,255,.2)}
.st:last-child{border-right:none}
.st-n{font-size:40px;font-weight:900;color:#fff;line-height:1;display:block}
.st-l{font-size:12px;color:rgba(255,255,255,.8);margin-top:8px;font-weight:700;display:block;text-transform:uppercase;letter-spacing:.06em}

/* ══════════════════════════════════════════════════
   HOW IT WORKS
══════════════════════════════════════════════════ */
.how-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:28px;position:relative}
.how-grid::before{content:'';position:absolute;top:40px;left:calc(12.5% + 16px);width:calc(75% - 32px);border-top:2px dashed rgba(255,255,255,.25)}
.how-card{text-align:center}
.how-step{width:80px;height:80px;border-radius:50%;background:rgba(255,255,255,.1);border:2px solid rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;margin:0 auto 18px;position:relative;color:#fff}
.how-step svg{width:32px;height:32px;flex-shrink:0}
.how-num{position:absolute;top:-5px;right:-5px;width:24px;height:24px;border-radius:50%;background:var(--G);color:#fff;font-size:11px;font-weight:900;display:flex;align-items:center;justify-content:center}
.how-title{font-size:17px;font-weight:800;color:#fff;margin-bottom:10px}
.how-desc{font-size:13px;color:rgba(255,255,255,.72);line-height:1.7;max-width:220px;margin:0 auto}

/* ══════════════════════════════════════════════════
   WHY CHOOSE US — upgraded to match icon-chip depth
   language established in categories/featured cards
══════════════════════════════════════════════════ */
.why-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.why-card{background:#fff;border:1px solid var(--BD);border-radius:16px;padding:30px 26px;transition:all .22s cubic-bezier(.2,.8,.2,1);position:relative;overflow:hidden}
.why-card::before{content:'';position:absolute;top:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--P),#F59E0B);transform:scaleX(0);transform-origin:left;transition:transform .3s ease}
.why-card:hover::before{transform:scaleX(1)}
.why-card:hover{border-color:transparent;box-shadow:0 16px 32px -8px rgba(37,99,235,.14);transform:translateY(-4px)}
.why-ic{width:56px;height:56px;border-radius:16px;background:linear-gradient(150deg,#EFF6FF,#DBEAFE);box-shadow:inset 0 1px 2px rgba(255,255,255,.8),0 1px 3px rgba(37,99,235,.08);display:flex;align-items:center;justify-content:center;margin-bottom:16px;transition:all .22s cubic-bezier(.2,.8,.2,1);color:var(--P)}
.why-ic svg{width:26px;height:26px;flex-shrink:0}
.why-card:hover .why-ic{background:linear-gradient(150deg,var(--P),#1D4ED8);transform:scale(1.08) rotate(-4deg);box-shadow:0 8px 16px -4px rgba(37,99,235,.4);color:#fff}
.why-title{font-size:16.5px;font-weight:700;margin-bottom:8px;letter-spacing:-.005em}
.why-desc{font-size:13.5px;color:var(--MU);line-height:1.7;font-weight:400}

/* ══════════════════════════════════════════════════
   CTA — GROW YOUR BUSINESS
══════════════════════════════════════════════════ */
#cta-grow{background:linear-gradient(135deg,var(--N),var(--N2));padding:48px 0;text-align:center}
#cta-grow h2{font-size:clamp(24px,3vw,38px);color:#fff;margin-bottom:12px}
#cta-grow p{font-size:15px;color:rgba(255,255,255,.8);margin-bottom:32px;max-width:560px;margin-left:auto;margin-right:auto;line-height:1.7}
.cta-btns{display:flex;gap:14px;justify-content:center;flex-wrap:wrap;margin-bottom:48px}
.cta-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));max-width:700px;margin:0 auto;gap:0;border-top:1px solid rgba(255,255,255,.25);padding-top:32px}
.cta-stat{text-align:center;border-right:1px solid rgba(255,255,255,.2);padding:0 20px}
.cta-stat:last-child{border-right:none}
.cta-stat-n{font-size:34px;font-weight:900;color:#fff;display:block;line-height:1}
.cta-stat-l{font-size:11px;color:rgba(255,255,255,.75);margin-top:7px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;display:block}

/* ══════════════════════════════════════════════════
   TESTIMONIALS
══════════════════════════════════════════════════ */
.testi-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px}
.testi-card{background:#fff;border:1.5px solid var(--BD);border-radius:10px;padding:28px 24px;transition:all .2s}
.testi-card:hover{border-color:var(--P);box-shadow:var(--SH)}
.testi-stars{font-size:14px;color:#F59E0B;margin-bottom:12px;letter-spacing:2px}
.testi-quote{font-size:14px;color:var(--TX);line-height:1.7;margin-bottom:16px;font-style:italic}
.testi-user{display:flex;align-items:center;gap:10px}
.testi-av{width:40px;height:40px;border-radius:50%;background:var(--P);display:flex;align-items:center;justify-content:center;color:#fff;font-size:16px;font-weight:800;flex-shrink:0}
.testi-name{font-size:14px;font-weight:700;color:var(--N)}
.testi-meta{font-size:12px;color:var(--MU)}

/* ══════════════════════════════════════════════════
   FAQ
══════════════════════════════════════════════════ */
/* ══════════════════════════════════════════════════
   APP / PWA PROMOTION — CSS-only phone mockup
══════════════════════════════════════════════════ */
.app-promo-grid{display:grid;grid-template-columns:1.1fr .9fr;gap:48px;align-items:center}
.app-promo-list{list-style:none;padding:0;margin:0 0 8px;display:flex;flex-direction:column;gap:10px}
.app-promo-list li{color:rgba(255,255,255,.82);font-size:14px}
.app-promo-visual{display:flex;justify-content:center}
.app-promo-phone{
  width:220px;height:440px;border-radius:36px;background:#0F172A;
  border:8px solid #1E293B;box-shadow:0 30px 60px -20px rgba(0,0,0,.5);
  position:relative;padding:8px;
}
.app-promo-phone-notch{width:80px;height:18px;background:#0F172A;border-radius:0 0 12px 12px;margin:0 auto;position:relative;z-index:2}
.app-promo-phone-screen{background:linear-gradient(160deg,#F8FAFC,#EFF6FF);border-radius:26px;height:calc(100% - 18px);padding:16px 12px;display:flex;flex-direction:column;gap:10px}
.app-promo-ss-header{display:flex;align-items:center;gap:6px;font-size:11px;font-weight:700;color:var(--TX);margin-bottom:4px}
.app-promo-ss-dot{width:8px;height:8px;border-radius:50%;background:#059669}
.app-promo-ss-card{background:#fff;border-radius:12px;padding:12px 10px;font-size:11.5px;font-weight:600;color:var(--TX);box-shadow:0 4px 10px rgba(15,23,42,.06);animation:appPromoFloat 3s ease-in-out infinite}
.app-promo-ss-card:nth-child(2){animation-delay:.3s}
.app-promo-ss-card:nth-child(3){animation-delay:.6s}
@keyframes appPromoFloat{0%,100%{transform:translateY(0)}50%{transform:translateY(-3px)}}
@media(max-width:900px){
  .app-promo-grid{grid-template-columns:1fr;gap:32px;text-align:center}
  .app-promo-list{align-items:center}
  .ht-w[style*="text-align:left"]{text-align:center !important}
  .app-promo-grid p{margin-left:auto;margin-right:auto}
}

/* ══════════════════════════════════════════════════
   FAQ
══════════════════════════════════════════════════ */
.faq-wrap{max-width:760px;margin:0 auto}
.faq-item{border:1px solid var(--BD);border-radius:14px;margin-bottom:12px;overflow:hidden;background:#fff;transition:box-shadow .2s}
.faq-item:hover{box-shadow:0 4px 16px rgba(15,35,64,.06)}
.faq-q{padding:18px 22px;font-weight:700;font-size:14px;color:var(--TX);cursor:pointer;display:flex;justify-content:space-between;align-items:center;gap:12px;user-select:none;transition:background .15s}
.faq-q:hover{background:var(--BG)}
.faq-q.open{background:var(--N);color:#fff}
.faq-arr{font-size:13px;flex-shrink:0;transition:transform .2s}
.faq-q.open .faq-arr{transform:rotate(180deg)}
.faq-a{display:none;padding:0 20px 16px;font-size:13px;color:var(--MU);line-height:1.75;background:#fff}
.faq-q.open+.faq-a{display:block}

/* ══════════════════════════════════════════════════
   CTA VENDOR BAND
══════════════════════════════════════════════════ */
#cta-v{background:var(--N);padding:48px 0}
#cta-v-in{display:flex;align-items:center;justify-content:space-between;gap:32px;flex-wrap:wrap}
#cta-v h2{font-size:clamp(20px,2.5vw,30px);color:#fff;margin-bottom:10px}
#cta-v p{font-size:14px;color:rgba(255,255,255,.7);line-height:1.7;max-width:560px}
.cta-perks{display:flex;gap:20px;margin-top:14px;flex-wrap:wrap}
.cta-perk{font-size:13px;font-weight:600;color:rgba(255,255,255,.8)}

/* ══════════════════════════════════════════════════
   FOOTER (OnlineX Sewa style)
══════════════════════════════════════════════════ */
#hfooter{background:#0a1628;color:rgba(255,255,255,.65);padding:60px 0 0}
.hf-grid{display:grid;grid-template-columns:2fr 1fr 1fr 1.2fr;gap:40px;margin-bottom:48px}
.hf-brand{font-size:20px;font-weight:900;color:#fff;margin-bottom:14px;display:block}
.hf-brand img{height:38px;border-radius:7px;margin-bottom:12px;display:block}
.hf-about{font-size:13px;line-height:1.8;max-width:260px;color:rgba(255,255,255,.6)}
.hf-social{display:flex;gap:10px;margin-top:18px}
.hf-social a{width:36px;height:36px;border-radius:50%;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;font-size:14px;transition:all .18s}
<?php /* Real fix — confirmed root cause of "footer section service links
   and other service link color function not working": these two hover
   rules used var(--G), a near-black (#1C1C1C) color meant for the .btn-g
   secondary BUTTON style elsewhere on the page. Applied to footer links,
   which sit on the footer's own dark navy background (#0a1628 — see
   #hfooter above), a near-black hover color is visually indistinguishable
   from the background: the hover state was firing correctly the whole
   time, it just rendered as effectively invisible. Switched to var(--P) —
   the platform's actual configured brand color already used correctly for
   the footer's OTHER links (Popular Cities, wired via inline
   onmouseover/onmouseout to the same $primary_color value a few lines
   below in this file) — so all footer links now share one real,
   visible, on-brand hover color. */ ?>
.hf-social a:hover{background:var(--P);color:#fff}
.hf-ct{font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#fff;margin-bottom:16px}
.hf-links{display:flex;flex-direction:column;gap:10px}
.hf-links a,.hf-links span{font-size:13px;color:rgba(255,255,255,.55);transition:color .18s}
.hf-links a:hover{color:var(--P)}
.hf-bottom{border-top:1px solid rgba(255,255,255,.07);padding:20px 0;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;font-size:12px}
.hf-bottom-links{display:flex;gap:18px}
.hf-bottom-links a{color:rgba(255,255,255,.4);transition:color .18s}
.hf-bottom-links a:hover{color:rgba(255,255,255,.7)}

/* ll-grid base — real fix: previously hardcoded to a fixed 2-column grid
   with zero admin control. Now genuinely driven by the desktop layout
   settings saved through the admin layout manager. */
<?php
// Real, working CSS generator for the Latest Listings section, covering
// all three layout types and all three devices from real admin settings.
function gs_ll_layout_css( array $cfg, string $selector_prefix = '' ): string {
    $css = '';
    $sel_grid = $selector_prefix . '.ll-grid';
    $sel_card = $selector_prefix . '.ll-card';
    switch ( $cfg['layout'] ) {
        case 'vertical-list':
            // Single column, cards stacked full-width, horizontal card
            // layout (image-left, content-right) — the existing .ll-card
            // markup was built exactly for this and needs no flex change.
            $css .= "{$sel_grid}{display:flex;flex-direction:column;gap:{$cfg['gap']}px}";
            $css .= "{$sel_card}{flex-direction:row}";
            if ( $cfg['card_height'] === 'fixed' ) {
                $css .= "{$sel_card}{height:{$cfg['card_height_px']}px}";
            }
            break;
        case 'horizontal-scroll':
        case 'carousel':
            // Real fix: carousel is a genuine fourth layout type, not an
            // alias — it shares the same scroll-snap CSS foundation as
            // horizontal-scroll (so the content is fully usable even before
            // JS loads or if JS fails), but gets nav arrows/dots and
            // optional auto-advance layered on top via JS, added below.
            $w = $cfg['card_min_width'];
            $css .= "{$sel_grid}{display:flex;flex-direction:row;gap:{$cfg['gap']}px;overflow-x:auto;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;padding-bottom:4px;scroll-behavior:smooth}";
            $css .= "{$sel_grid}::-webkit-scrollbar{height:6px}";
            $css .= "{$sel_grid} > .ll-card{flex:0 0 {$w}px;width:{$w}px;scroll-snap-align:start;flex-direction:column}";
            // Real bug fix, confirmed as the exact cause of "only category
            // shows on mobile": aspect-ratio was previously applied to the
            // entire .ll-card, not scoped to .ll-img like the grid case
            // correctly does. Combined with .ll-card's own overflow:hidden
            // and its fixed width, this crushed the whole card — image plus
            // every piece of body content and every button — into a height
            // far too small to fit anything past the very first element.
            $css .= "{$sel_card} .ll-img{width:100%;min-width:0;aspect-ratio:{$cfg['aspect_ratio']}}";
            if ( $cfg['card_height'] === 'fixed' ) {
                $css .= "{$sel_grid} > .ll-card{height:{$cfg['card_height_px']}px}";
                $css .= "{$sel_card} .ll-img{aspect-ratio:unset;height:45%}";
            }
            break;
        case 'grid':
        default:
            // Explicit fixed column count, matching exactly what the admin
            // configured — not an auto-fit grid that ignores the setting.
            $css .= "{$sel_grid}{display:grid;grid-template-columns:repeat({$cfg['columns']},1fr);gap:{$cfg['gap']}px}";
            $css .= "{$sel_card}{flex-direction:column}";
            $css .= "{$sel_card} .ll-img{width:100%;min-width:0;aspect-ratio:{$cfg['aspect_ratio']}}";
            if ( $cfg['card_height'] === 'fixed' ) {
                $css .= "{$sel_card}{height:{$cfg['card_height_px']}px}";
            }
            break;
    }
    // Content visibility — applied uniformly regardless of layout type,
    // using display:none rather than omitting markup, since this needs to
    // stay dynamically toggleable by the client-side settings system below
    // rather than being baked into cacheable server-rendered HTML.
    if ( empty( $cfg['show_title'] ) )    { $css .= "{$sel_card} .ll-title{display:none}"; }
    if ( empty( $cfg['show_rating'] ) )   { $css .= "{$sel_card} .ll-rat{display:none}"; }
    if ( empty( $cfg['show_location'] ) ) { $css .= "{$sel_card} .ll-city{display:none}"; }
    if ( empty( $cfg['show_badges'] ) )   { $css .= "{$sel_card} .ll-badges{display:none}"; }
    if ( empty( $cfg['show_buttons'] ) )  { $css .= "{$sel_card} .ll-actions{display:none}"; }
    // Section width & alignment
    $section_sel = $selector_prefix ? $selector_prefix : '#gsLLGrid';
    if ( ( $cfg['section_width'] ?? 'contained' ) === 'full' ) {
        $css .= "{$section_sel}{max-width:100vw;margin-left:calc(50% - 50vw);margin-right:calc(50% - 50vw);padding-left:16px;padding-right:16px;box-sizing:border-box}";
    }
    if ( ( $cfg['section_align'] ?? 'left' ) === 'center' && $cfg['layout'] !== 'grid' ) {
        $css .= "{$section_sel}{justify-content:center}";
    }
    return $css;
}
echo gs_ll_layout_css( $ll_layout['desktop'] );
?>

/* ══════════════════════════════════════════════════
   RESPONSIVE — fully mobile-first, min 2 cols kept
══════════════════════════════════════════════════ */

/* ── 1200px: wide tablet ── */
@media(max-width:1200px){
  .hf-grid{grid-template-columns:1.5fr 1fr 1fr 1fr;gap:28px}
}

/* ── 1000px: tablet landscape ── */
@media(max-width:1000px){
  .testi-grid{grid-template-columns:repeat(2,1fr);gap:14px}
  .hf-grid{grid-template-columns:1fr 1fr;gap:28px}
  .why-grid{grid-template-columns:repeat(2,1fr);gap:14px}
}

/* ── 900px: tablet portrait ── */
@media(max-width:900px){
  /* Nav */
  #hn-links{display:none}
  #hn-mob{display:block}
  #hn-acts .btn-o{display:none}
  #hn-in{height:60px}
  /* Real fix, same root cause as the listing-page header fix: removing
     #hn-links from the flex layout above also removes the only flex:1
     element that was reliably pushing #hn-acts to the right edge — without
     it, the login button and hamburger just land wherever the natural flex
     flow puts them, which can visually appear centered depending on how
     much space the logo takes. Explicitly restores right-alignment. */
  #hn-acts{margin-left:auto}

  /* Stats: 2×2 */
  #stats-row{grid-template-columns:repeat(2,1fr)}
  .st{padding:24px 16px}
  .st-n{font-size:32px}

  /* How it works: 2 cols at tablet */
  .how-grid{grid-template-columns:repeat(2,1fr);gap:20px}
  .how-grid::before{display:none}

  /* Latest listings: tablet layout, from real admin settings */
  <?php echo gs_ll_layout_css( $ll_layout['tablet'] ); ?>

  /* CTA stats: 2×2 */
  .cta-stats{grid-template-columns:repeat(2,1fr);gap:0}
  .cta-stat{border-right:none;border-bottom:1px solid rgba(255,255,255,.2);padding:20px 16px}
  .cta-stat:nth-child(2){border-bottom:1px solid rgba(255,255,255,.2)}
  .cta-stat:nth-child(3),.cta-stat:nth-child(4){border-bottom:none}
  .cta-stat:nth-child(odd){border-right:1px solid rgba(255,255,255,.2)}

  /* Section padding */
  .hs{padding:56px 0}
}

/* ── 768px: mobile landscape / large phone ── */
@media(max-width:768px){
  .hw{padding:0 14px}
  #hero{padding:40px 0 50px;min-height:70vh;display:flex;align-items:center}
  #hero h1{font-size:clamp(22px,5.5vw,30px)}
  #hero-sub{font-size:14px;margin-bottom:24px}
  .hs{padding:44px 0}
  .hs-hdr{margin-bottom:32px}

  /* Search: mobile pill collapses to stacked */
  #srch-pill{
    flex-direction:column;height:auto;
    border-radius:20px;padding:8px;gap:2px;
  }
  .sp-s{
    width:100%;height:54px;border-radius:14px;
    flex-direction:row;align-items:center;
    gap:10px;padding:0 16px;
    /* Real fix — #srch-pill is flex-direction:column here, so
       flex-grow would act vertically (making the active field taller)
       rather than horizontally (wider) — neutralized since width:100%
       already handles mobile sizing on its own. The grow/shrink/dim
       animation is a desktop-only effect. */
    flex-grow:0!important;opacity:1!important;
  }
  .sp-s.sp-active{border-radius:14px}
  .sp-s:first-child{padding-left:16px}
  .sp-div{width:calc(100% - 20px);height:1px;margin:0 10px;align-self:stretch;flex-shrink:0}
  .sp-drop{min-width:calc(100vw - 50px);left:0;right:0;border-radius:16px;top:calc(100% + 8px)}
  .sp-drop.sp-drop-city,.sp-drop.sp-drop-cat{min-width:calc(100vw - 50px);left:0;right:0}
  .sp-cat-grid{grid-template-columns:repeat(2,1fr)}
  .sp-city-grid{grid-template-columns:1fr}
  #srch-btn{
    width:100%;border-radius:14px;height:50px;
    margin:4px 0 0;border-radius:14px;
  }

  /* City pills: tighter */
  .city-pill{padding:6px 12px;font-size:12px}
  .city-grid{gap:7px}

  /* Latest listings: image sizing is now fully handled by the dynamic
     layout settings system (gs_ll_layout_css) — this unconditional
     override used to force every listing image to 72px regardless of the
     configured layout, silently winning the cascade over grid-mode's
     width:100% at this exact breakpoint range. Removed. */
  .ll-actions{min-width:76px;padding:10px}
  .ll-btn{padding:6px 8px;font-size:10px}
  .ll-title{font-size:13px}

  /* How: 2 cols */
  .how-grid{grid-template-columns:repeat(2,1fr);gap:18px}

  /* Why: 2 cols always */
  .why-grid{grid-template-columns:repeat(2,1fr);gap:12px}
  .why-card{padding:20px 16px}
  .why-ic{width:44px;height:44px;margin-bottom:10px}
  .why-ic svg{width:20px;height:20px}
  .why-title{font-size:14px}
  .why-desc{font-size:12px}

  /* CTA grow */
  #cta-grow{padding:52px 0}
  #cta-grow h2{font-size:24px}
  .cta-btns{gap:10px}
  .cta-stat-n{font-size:26px}

  /* Testimonials: keep 2 cols */
  .testi-grid{grid-template-columns:repeat(2,1fr);gap:12px}
  .testi-card{padding:20px 16px}

  /* Footer */
  .hf-grid{grid-template-columns:1fr 1fr;gap:22px}
  #hfooter{padding:44px 0 0}

  /* CTA vendor */
  #cta-v-in{flex-direction:column;gap:24px}
  #cta-v{padding:48px 0}
}

/* ── 540px: typical phone portrait ── */
@media(max-width:540px){
  .hw{padding:0 12px}
  #hero{padding:32px 0 40px}
  #hero h1{font-size:21px;letter-spacing:-.01em}
  #hero-sub{font-size:13px;display:none}/* hide on very small */
  #hero-tags{gap:5px}
  .htag{padding:4px 10px;font-size:11px}

  /* Latest listings: mobile layout, from real admin settings */
  <?php echo gs_ll_layout_css( $ll_layout['mobile'] ); ?>

  /* Stats: 2×2 tighter */
  #stats-row{grid-template-columns:repeat(2,1fr)}
  .st{padding:20px 12px;border-right:none;border-bottom:1px solid rgba(255,255,255,.15)}
  .st:nth-child(odd){border-right:1px solid rgba(255,255,255,.15)}
  .st:nth-child(3),.st:nth-child(4){border-bottom:none}
  .st-n{font-size:28px}
  .st-l{font-size:10px}

  /* How: 1 col on small phone */
  .how-grid{grid-template-columns:1fr;gap:16px}
  .how-step{width:64px;height:64px;margin-bottom:12px}
  .how-step svg{width:26px;height:26px}

  /* Why: KEEP 2 cols even on small phone */
  .why-grid{grid-template-columns:repeat(2,1fr);gap:10px}
  .why-card{padding:16px 12px;border-radius:8px}
  .why-ic{width:38px;height:38px;border-radius:10px;margin-bottom:8px}
  .why-ic svg{width:17px;height:17px}
  .why-title{font-size:13px;margin-bottom:5px}
  .why-desc{font-size:11px;line-height:1.6}

  /* Testimonials: 1 col on small phone (text too long for 2) */
  .testi-grid{grid-template-columns:1fr}

  /* Footer: 2 cols on phone */
  .hf-grid{grid-template-columns:1fr 1fr;gap:18px}
  .hf-about{max-width:100%}
  .hf-col-title{font-size:11px}
  .hf-links a,.hf-links span{font-size:12px}

  /* City pills */
  .city-pill{padding:5px 10px;font-size:11px}

  /* CTA stats: 2×2 */
  .cta-stats{grid-template-columns:repeat(2,1fr)}
  .cta-stat-n{font-size:24px}
  .cta-stat-l{font-size:10px}

  /* Nav */
  #hn-in{height:56px}
  #hn-logo{font-size:17px}
  #hn-acts .btn-sm{padding:7px 13px;font-size:12px}

  /* Sponsored card — smaller minimum card width on phone so at least 2
     typically fit, while still auto-filling responsively, not a fixed count */
  #spn-row{grid-template-columns:<?php echo $sponsored_mobile_columns > 0 ? 'repeat('.$sponsored_mobile_columns.',1fr)' : 'repeat(auto-fill,minmax(140px,1fr))'; ?>;gap:14px 10px}
  .spn-badge{font-size:9px;padding:4px 8px}
}

/* ── 400px: extra small ── */
@media(max-width:400px){
  #hero h1{font-size:19px}
  .hf-grid{grid-template-columns:1fr}
  .testi-card{padding:16px 14px}
  #hn-acts .btn-sm{padding:6px 10px;font-size:11px}
}
</style>

<!-- ════ NAV ═══════════════════════════════════════════════════ -->
<nav id="hn">
  <div class="hw">
    <div id="hn-in">
      <a href="<?php echo home_url('/'); ?>" id="hn-logo">
        <?php if($logo_url): ?><img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($site_name); ?>"><?php else: echo esc_html($site_name); endif; ?>
      </a>
      <div id="hn-links">
        <a href="<?php echo esc_url($dir_url); ?>">Browse Services</a>
        <a href="<?php echo esc_url( home_url('/how-it-works/') ); ?>">How It Works</a>
        <div class="hn-dd">
          <button type="button" class="hn-dd-trigger" aria-expanded="false" aria-haspopup="true" onclick="gsToggleHnDropdown(this)">Company <span class="hn-dd-caret">▾</span></button>
          <div class="hn-dd-menu" role="menu">
            <a href="<?php echo esc_url( home_url('/about-us/') ); ?>" role="menuitem">About Us</a>
            <a href="<?php echo esc_url( home_url('/trust-safety/') ); ?>" role="menuitem">Trust &amp; Safety</a>
            <a href="<?php echo esc_url( home_url('/contact-us/') ); ?>" role="menuitem">Contact Us</a>
          </div>
        </div>
        <?php if($dash_url): ?><a href="<?php echo esc_url($dash_url); ?>">Dashboard</a><?php endif; ?>
      </div>
      <div id="hn-acts">
        <!-- v7.475.21: links to dedicated /install-app/ page (always works; no silent JS failure). -->
        <a href="<?php echo esc_url( home_url( '/install-app/' ) ); ?>" id="hnInstallBtn" class="btn btn-p btn-sm gs-install-btn" style="display:inline-flex;align-items:center;gap:4px;text-decoration:none" aria-label="Download App">
          <span aria-hidden="true">⬇</span> <span id="hnInstallLabel">Download App</span>
        </a>
        <?php if(!is_user_logged_in()): ?>
          <a href="<?php echo esc_url( home_url('/advertise/') ); ?>" class="btn btn-o btn-sm" style="color:var(--G);border-color:var(--G)">List Your Business</a>
          <a href="<?php echo esc_url($login_url); ?>" class="btn btn-p btn-sm">Login</a>
        <?php else: ?>
          <a href="<?php echo esc_url($dash_url); ?>" class="btn btn-p btn-sm">My Dashboard</a>
        <?php endif; ?>
      </div>
      <script>
      (function(){
        // Real feature — Company nav dropdown. Closes on outside click
        // and Escape, keeps aria-expanded in sync for screen readers.
        window.gsToggleHnDropdown = function(trigger) {
          var dd = trigger.closest('.hn-dd');
          var isOpen = dd.classList.contains('open');
          document.querySelectorAll('.hn-dd.open').forEach(function(el) {
            el.classList.remove('open');
            var t = el.querySelector('.hn-dd-trigger');
            if (t) t.setAttribute('aria-expanded', 'false');
          });
          if (!isOpen) {
            dd.classList.add('open');
            trigger.setAttribute('aria-expanded', 'true');
          }
        };
        document.addEventListener('click', function(e) {
          if (!e.target.closest('.hn-dd')) {
            document.querySelectorAll('.hn-dd.open').forEach(function(el) {
              el.classList.remove('open');
              var t = el.querySelector('.hn-dd-trigger');
              if (t) t.setAttribute('aria-expanded', 'false');
            });
          }
        });
        document.addEventListener('keydown', function(e) {
          if (e.key === 'Escape') {
            document.querySelectorAll('.hn-dd.open').forEach(function(el) {
              el.classList.remove('open');
              var t = el.querySelector('.hn-dd-trigger');
              if (t) t.setAttribute('aria-expanded', 'false');
            });
          }
        });
      })();
      </script>
      <script>
      (function(){
        function isStandalone(){
          return window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
        }
        function maybeHideInstallBtn(){
          var show = !isStandalone();
          document.querySelectorAll('.gs-install-btn').forEach(function(btn) {
            btn.style.display = show ? 'inline-flex' : 'none';
          });
          var lbl = document.getElementById('hnInstallLabel');
          if (lbl) { lbl.style.display = window.innerWidth <= 480 ? 'none' : ''; }
        }
        document.addEventListener('DOMContentLoaded', maybeHideInstallBtn);
        window.addEventListener('resize', maybeHideInstallBtn);
        maybeHideInstallBtn();
      })();
      </script>
      <button id="hn-mob" onclick="document.getElementById('hn-drw').classList.toggle('open')">☰</button>
    </div>
  </div>
  <div id="hn-drw">
    <a href="<?php echo esc_url( home_url( '/install-app/' ) ); ?>" class="btn btn-p btn-sm gs-install-btn" style="display:inline-flex;margin:4px 0 8px;width:100%;justify-content:center;text-decoration:none" aria-label="Download App" onclick="document.getElementById('hn-drw').classList.remove('open');">⬇ Download App</a>
    <a href="<?php echo esc_url($dir_url); ?>">Browse Services</a>
    <a href="<?php echo esc_url( home_url('/how-it-works/') ); ?>">How It Works</a>
    <a href="<?php echo esc_url( home_url('/trust-safety/') ); ?>">Trust &amp; Safety</a>
    <a href="<?php echo esc_url( home_url('/about-us/') ); ?>">About Us</a>
    <a href="<?php echo esc_url( home_url('/contact-us/') ); ?>">Contact Us</a>
    <?php if(!is_user_logged_in()): ?>
      <a href="<?php echo esc_url( home_url('/advertise/') ); ?>">List Your Business</a>
      <a href="<?php echo esc_url($login_url); ?>">Login</a>
    <?php else: ?>
      <a href="<?php echo esc_url($dash_url); ?>">My Dashboard</a>
    <?php endif; ?>
  </div>
</nav>

<!-- ── Sticky mobile search bar — appears once the hero's own search
     scrolls out of view, matching real app-style persistent search
     behavior instead of forcing a scroll back to the top ── -->
<nav id="app-bottom-nav" aria-label="Main navigation">
  <a href="<?php echo esc_url(home_url('/')); ?>" class="abn-item abn-active">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9.5 12 3l9 6.5V21a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1V9.5Z"/></svg>
    <span>Home</span>
  </a>
  <a href="#srch-wrap" class="abn-item" onclick="document.getElementById('srch-wrap').scrollIntoView({behavior:'smooth',block:'center'});setTimeout(function(){var el=document.getElementById('sp-s-what');if(el)el.click();},400);return false;">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-4.5-4.5"/></svg>
    <span>Search</span>
  </a>
  <a href="<?php echo esc_url($dir_url); ?>" class="abn-item">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>
    <span>Categories</span>
  </a>
  <a href="<?php echo esc_url( is_user_logged_in() ? $dash_url : home_url('/vendor/login/') ); ?>" class="abn-item">
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3.5-7 8-7s8 3 8 7"/></svg>
    <span><?php echo is_user_logged_in() ? 'Account' : 'Log In'; ?></span>
  </a>
</nav>
<style>
#app-bottom-nav{
  display:none;position:fixed;left:0;right:0;bottom:0;z-index:400;
  background:rgba(255,255,255,.96);backdrop-filter:blur(12px);-webkit-backdrop-filter:blur(12px);
  border-top:1px solid var(--BD);padding:8px 4px calc(8px + env(safe-area-inset-bottom));
  justify-content:space-around;align-items:stretch;
  box-shadow:0 -4px 16px rgba(0,0,0,.05);
}
.abn-item{
  display:flex;flex-direction:column;align-items:center;gap:3px;
  color:var(--MU);font-size:10.5px;font-weight:600;text-decoration:none;
  padding:4px 10px;border-radius:12px;flex:1;transition:color .15s;
}
.abn-item svg{width:22px;height:22px;flex-shrink:0}
.abn-item.abn-active{color:var(--P)}
.abn-item:active{background:var(--BG)}
@media(max-width:768px){
  #app-bottom-nav{display:flex}
  body{padding-bottom:calc(64px + env(safe-area-inset-bottom))} /* keep the last section clear of the fixed bar, including notched devices */
}
</style>

<?php
// ── Homepage Hero — full admin customizer ────────────────────────
$hero_bg_color    = gs_setting('homepage_hero_bg_color', '');
$hero_bg_image    = gs_setting('homepage_hero_bg_image', '');
$hero_bg_video    = gs_setting('homepage_hero_bg_video', '');
$hero_overlay_op  = max(0,min(100,(int)gs_setting('homepage_hero_overlay_opacity','60')));
$hero_overlay_col = gs_setting('homepage_hero_overlay_color','#0F2340') ?: '#0F2340';
$hero_layout      = gs_setting('homepage_hero_layout','centered');
$hero_text_align  = gs_setting('homepage_hero_text_align','center');
// M6 FIX: Whitelist against allowed CSS text-align values before interpolating
// into a style attribute. Prevents stored XSS via malicious admin config value.
$hero_text_align  = in_array( $hero_text_align, [ 'left', 'center', 'right' ], true )
    ? $hero_text_align : 'center';
$hero_min_h       = max(200,min(900,(int)gs_setting('homepage_hero_min_height','480')));
$hero_pt          = max(0,min(200,(int)gs_setting('homepage_hero_padding_top','60')));
$hero_pb          = max(0,min(200,(int)gs_setting('homepage_hero_padding_bottom','60')));
$hero_heading_ov  = gs_setting('homepage_hero_heading','');
$hero_sub_ov      = gs_setting('homepage_hero_subheading','');
$hero_h_color     = gs_setting('homepage_hero_heading_color','') ?: '';
$hero_h_size      = max(0,min(80,(int)gs_setting('homepage_hero_heading_size','0')));
$hero_sub_color   = gs_setting('homepage_hero_sub_color','') ?: '';
$hero_sub_size    = max(0,min(32,(int)gs_setting('homepage_hero_sub_size','0')));
$hero_cta1_text   = gs_setting('homepage_hero_cta1_text','');
$hero_cta1_link   = gs_setting('homepage_hero_cta1_link','');
$hero_cta1_bg     = gs_setting('homepage_hero_cta1_bg','');
$hero_cta1_color  = gs_setting('homepage_hero_cta1_color','#ffffff');
$hero_cta2_text   = gs_setting('homepage_hero_cta2_text','');
$hero_cta2_link   = gs_setting('homepage_hero_cta2_link','');
$hero_cta2_bg     = gs_setting('homepage_hero_cta2_bg','');
$hero_cta2_color  = gs_setting('homepage_hero_cta2_color','#ffffff');
$hero_tb_show     = gs_setting('homepage_hero_show_trust_bar','0') === '1';
$hero_tb_text     = gs_setting('homepage_hero_trust_bar_text','');
$hero_tb_speed    = max(5,min(120,(int)gs_setting('homepage_hero_trust_bar_speed','28')));
$hero_show_search = gs_setting('homepage_hero_show_search','1') !== '0';
// Build hero styles
$hero_style = "min-height:{$hero_min_h}px;padding-top:{$hero_pt}px;padding-bottom:{$hero_pb}px;";
if ($hero_bg_image)      $hero_style .= "background:url('".esc_url($hero_bg_image)."') center/cover no-repeat;";
elseif ($hero_bg_color)  $hero_style .= "background:".esc_attr($hero_bg_color).";";
if ($hero_text_align !== 'center') $hero_style .= "text-align:{$hero_text_align};";
// Overlay
$_ov_style = '';
if ($hero_bg_image || $hero_bg_video) {
    list($r,$g,$b) = sscanf($hero_overlay_col, '#%02x%02x%02x');
    $op = round($hero_overlay_op/100,2);
    $_ov_style = "position:absolute;inset:0;background:rgba({$r},{$g},{$b},{$op});pointer-events:none;z-index:0";
}
?>
<?php if ( $hero_bg_image ): ?>
<!-- Real performance fix — CSS background images are discovered late
     (only after stylesheet parse) and deprioritized by browsers, making
     a hero background the classic Largest Contentful Paint bottleneck.
     This preload with fetchpriority=high starts the fetch immediately,
     in parallel with critical resources. Emitted only when a hero image
     is actually configured. -->
<link rel="preload" as="image" href="<?php echo esc_url( $hero_bg_image ); ?>" fetchpriority="high">
<?php endif; ?>
<!-- ════ HERO ════════════════════════════════════════════════════ -->
<section id="hero" style="<?php echo $hero_style; ?>">
  <?php if ($hero_bg_video): ?>
  <video autoplay muted loop playsinline style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-1"><source src="<?php echo esc_url($hero_bg_video); ?>"></video>
  <?php endif; ?>
  <?php if ($_ov_style): ?><div style="<?php echo $_ov_style; ?>"></div><?php endif; ?>
  <div class="hw" id="hero-in" style="position:relative;z-index:9200">
    <h1 style="<?php echo ($hero_h_color?'color:'.esc_attr($hero_h_color).';':'').($hero_h_size?'font-size:'.$hero_h_size.'px;':''); ?>"><?php
      if ($hero_heading_ov) { echo esc_html($hero_heading_ov); }
      else { echo esc_html($site_name.' — '); ?><span id="hero-accent"><?php echo esc_html($tagline); ?></span><?php } ?></h1>
    <p id="hero-sub" style="<?php echo ($hero_sub_color?'color:'.esc_attr($hero_sub_color).';':'').($hero_sub_size?'font-size:'.$hero_sub_size.'px;':''); ?>"><?php echo esc_html($hero_sub_ov ?: 'Find verified professionals in your city. Compare, connect, hire.'); ?></p>

    <!-- Overlay backdrop for search pill -->
    <div id="sp-overlay" onclick="spCloseAll()"></div>

    <!-- ══ AIRBNB SEARCH PILL ══════════════════════════════════════ -->
    <div id="srch-wrap" <?php if(!$hero_show_search):?>style="display:none"<?php endif;?>>
      <!-- Hidden actual form inputs that hSearch() reads -->
      <input type="hidden" id="hcity" value="">
      <input type="hidden" id="hcat"  value="">

      <div id="srch-pill">

        <!-- ── Segment 1: WHAT (keyword) ── -->
        <div class="sp-s" id="sp-s-what" onclick="spOpen('what',event)" role="button" tabindex="0"
             onkeydown="if(event.key==='Enter'||event.key===' ')spOpen('what',event)">
          <div class="sp-lbl">What</div>
          <div class="sp-val" id="sp-val-what">Search services, businesses…</div>
          <button class="sp-clear" id="sp-clr-what" aria-label="Clear" onclick="spClear('what',event)">✕</button>

          <!-- Dropdown: keyword input + popular service tags -->
          <div class="sp-drop" id="sp-drop-what" onclick="event.stopPropagation()">
            <div class="sp-dt">Search for a service</div>
            <div class="sp-kw-wrap">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <circle cx="11" cy="11" r="7"/><path d="m16.5 16.5 3.5 3.5" stroke-linecap="round"/>
              </svg>
              <input type="text" id="hkw" placeholder="e.g. Passport, CA, Plumber, GST…"
                oninput="spKwInput()"
                onkeydown="if(event.key==='Enter'){spCloseAll();hSearch();}">
              <button id="gs-voice-btn" aria-label="Voice search" title="Search by voice"
                style="background:none;border:none;cursor:pointer;color:#94A3B8;padding:4px;line-height:1;display:none"
                onclick="gsVoiceSearch(event)">🎙️</button>
            </div>
            <div class="sp-dt" style="margin-top:22px">Popular Services</div>
            <div class="sp-tag-grid">
              <?php foreach($popular_tags as $tag): ?>
                <span class="sp-tag" onclick="spSetKw('<?php echo esc_js($tag); ?>')">
                  <?php echo esc_html($tag); ?>
                </span>
              <?php endforeach; ?>
            </div>
          </div>
        </div>

        <div class="sp-div" id="sp-div-1"></div>

        <!-- ── Segment 2: WHERE (city) ── -->
        <div class="sp-s" id="sp-s-city" onclick="spOpen('city',event)" role="button" tabindex="0"
             onkeydown="if(event.key==='Enter'||event.key===' ')spOpen('city',event)">
          <div class="sp-lbl">Where</div>
          <div class="sp-val" id="sp-val-city">Any city</div>
          <button class="sp-clear" id="sp-clr-city" aria-label="Clear city" onclick="spClear('city',event)">✕</button>

          <!-- Dropdown: city grid -->
          <div class="sp-drop sp-drop-city" id="sp-drop-city" onclick="event.stopPropagation()">
            <div class="sp-dt">Select a city</div>
            <div class="sp-city-grid">
              <div class="sp-ci sp-ci-any sp-sel" id="sp-ci-any" onclick="spSetCity('','Any city',event)">
                <span style="font-size:18px">🌏</span> All Cities
              </div>
              <?php
              $city_emojis = ['Delhi'=>'🏛','Mumbai'=>'🌊','Bangalore'=>'🌿','Chennai'=>'🏖','Hyderabad'=>'💎','Kolkata'=>'🏛','Pune'=>'🎓','Ahmedabad'=>'🏭','Jaipur'=>'🏯','Surat'=>'💫','Lucknow'=>'🕌','Kanpur'=>'🏗','Nagpur'=>'🍊','Indore'=>'🌾','Thane'=>'🏙'];
              foreach((array)$cities as $c):
                $emoji = $city_emojis[$c] ?? '📍';
              ?>
              <div class="sp-ci" data-city="<?php echo esc_attr($c); ?>" onclick="spSetCity('<?php echo esc_js($c); ?>','<?php echo esc_js($c); ?>',event)">
                <div class="sp-ci-ic"><?php echo $emoji; ?></div>
                <div>
                  <div class="sp-ci-name"><?php echo esc_html($c); ?></div>
                </div>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>

        <div class="sp-div" id="sp-div-2"></div>

        <!-- ── Segment 3: CATEGORY ── -->
        <div class="sp-s" id="sp-s-cat" onclick="spOpen('cat',event)" role="button" tabindex="0"
             onkeydown="if(event.key==='Enter'||event.key===' ')spOpen('cat',event)">
          <div class="sp-lbl">Category</div>
          <div class="sp-val" id="sp-val-cat">All categories</div>
          <button class="sp-clear" id="sp-clr-cat" aria-label="Clear category" onclick="spClear('cat',event)">✕</button>

          <!-- Dropdown: category icon grid -->
          <div class="sp-drop sp-drop-cat" id="sp-drop-cat" onclick="event.stopPropagation()">
            <div class="sp-dt">Browse categories</div>
            <div class="sp-kw-wrap" style="margin-bottom:12px">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
                <circle cx="11" cy="11" r="7"/><path d="m16.5 16.5 3.5 3.5" stroke-linecap="round"/>
              </svg>
              <input type="text" id="sp-cat-search" placeholder="Search categories &amp; subcategories…" oninput="spCatSearchInput()">
            </div>
            <div class="sp-cat-grid" id="sp-cat-grid-list">
              <div class="sp-ca-any sp-sel" id="sp-ca-any" onclick="spSetCat('','All categories',event)">
                <span>📂</span> All Categories
              </div>
              <?php foreach($top_cats as $cat): ?>
              <div class="sp-ca" data-cat="<?php echo esc_attr($cat->id); ?>"
                   onclick="spSetCat('<?php echo esc_js($cat->id); ?>','<?php echo esc_js($cat->name); ?>',event)">
                <span class="sp-ca-ic"><?php echo esc_html($cat->icon_emoji??'📂'); ?></span>
                <span class="sp-ca-nm"><?php echo esc_html($cat->name); ?></span>
              </div>
              <?php endforeach; ?>
            </div>
          </div>
        </div>

        <!-- ── Search Button ── -->
        <button id="srch-btn" onclick="event.stopPropagation();spCloseAll();hSearch()" aria-label="Search">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <circle cx="11" cy="11" r="7.5" stroke="white" stroke-width="2.5"/>
            <path d="m17 17 3.5 3.5" stroke="white" stroke-width="2.5" stroke-linecap="round"/>
          </svg>
        </button>
        <!-- AI search mode toggle — sits inside the pill row as a mode switcher -->
        <button id="gs-ai-toggle" onclick="gsToggleAISearch()" title="Switch to AI-powered natural language search"
          style="background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);color:rgba(255,255,255,.8);border-radius:20px;padding:5px 12px;font-size:.72rem;font-weight:600;cursor:pointer;font-family:inherit;white-space:nowrap;margin-right:6px;flex-shrink:0;align-self:center">
          ✨ AI
        </button>

      </div><!-- #srch-pill -->
    </div><!-- #srch-wrap -->

    <!-- ── AI Concierge Search bar (Phase 8) — hidden by default, shown when AI mode active ── -->
    <div id="gs-ai-search-bar" style="display:none;max-width:700px;margin:10px auto 0">
      <div style="display:flex;gap:8px;max-width:640px;margin:0 auto">
        <input id="gs-ai-inp" type="text"
          placeholder='Try: "fix AC before Sunday, budget ₹500" or "plumber available today in Delhi"'
          style="flex:1;border:none;border-radius:10px;padding:12px 16px;font-size:.88rem;font-family:inherit;outline:none;box-shadow:0 4px 16px rgba(0,0,0,.15)"
          onkeydown="if(event.key==='Enter')gsAISearch()">
        <button onclick="gsAISearch()" id="gs-ai-btn"
          style="background:#2563EB;color:#fff;border:none;border-radius:10px;padding:12px 20px;font-size:.88rem;font-weight:700;cursor:pointer;white-space:nowrap">
          Search
        </button>
        <!-- Back to normal search -->
        <button onclick="gsToggleAISearch()" title="Switch back to normal search"
          style="background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);color:rgba(255,255,255,.8);border-radius:10px;padding:12px 14px;font-size:.88rem;cursor:pointer;font-family:inherit;white-space:nowrap;flex-shrink:0">
          ✕
        </button>
      </div>
      <div style="text-align:center;margin-top:6px;font-size:.73rem;color:rgba(255,255,255,.5)">
        AI Search is active — <button onclick="gsToggleAISearch()" style="background:none;border:none;color:rgba(255,255,255,.6);font-size:.73rem;cursor:pointer;padding:0;text-decoration:underline;font-family:inherit">switch back to standard search</button>
      </div>
      <div id="gs-ai-results" style="max-width:640px;margin:10px auto 0;text-align:left"></div>
    </div>

    <!-- ── Popular tag chips below the pill ── -->
    <div id="hero-tags" <?php if(!$hero_show_search):?>style="display:none"<?php endif;?>>
      <?php foreach($popular_tags as $tag): ?>
        <span class="htag" onclick="spSetKw('<?php echo esc_js($tag); ?>',true)"><?php echo esc_html($tag); ?></span>
      <?php endforeach; ?>
    </div>

    <!-- ── Baseline trust bar — genuine counts only, each stat hidden if zero ── -->
    <?php if ( $stats['vendors'] > 0 || $stats['cities'] > 0 || $stats['reviews'] > 0 ): ?>
    <div class="hero-trust">
      <?php if ( $stats['vendors'] > 0 ): ?>
      <div class="hero-trust-item"><span class="hero-trust-ic">✓</span><span class="hero-trust-n"><?php echo number_format($stats['vendors']); ?>+</span> Vendor Listings</div>
      <?php endif; ?>
      <?php if ( $stats['cities'] > 0 ): ?>
      <div class="hero-trust-item"><span class="hero-trust-ic">📍</span><span class="hero-trust-n"><?php echo number_format($stats['cities']); ?>+</span> Cities</div>
      <?php endif; ?>
      <?php if ( $stats['avg_rating_display'] ): ?>
      <div class="hero-trust-item"><span class="hero-trust-ic">★</span><span class="hero-trust-n"><?php echo esc_html($stats['avg_rating_display']); ?></span> Avg. Rating <?php if($stats['reviews']>0):?>(<?php echo number_format($stats['reviews']); ?> reviews)<?php endif; ?></div>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <!-- Part 20.1 — Live trust strip -->
    <?php if ( $today_inquiries > 0 ): ?>
    <div style="display:inline-flex;gap:14px;align-items:center;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2);border-radius:30px;padding:7px 16px;margin-top:14px;font-size:.78rem;color:rgba(255,255,255,.9);flex-wrap:wrap;justify-content:center">
      <span>📬 <strong><?php echo number_format($today_inquiries); ?></strong> inquiries sent today</span>
    </div>
    <?php endif; ?>

    <!-- Part 20.3 — Trending services -->
    <?php if ( ! empty( $trending_services ) ): ?>
    <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap;justify-content:center;align-items:center">
      <span style="font-size:.75rem;color:rgba(255,255,255,.6)">🔥 Trending:</span>
      <?php foreach ( $trending_services as $ts ):
        $ts_label = ucwords( str_replace( ['-','_'], ' ', $ts->cat ) ); ?>
      <a href="<?php echo esc_url( $dir_url . '?category=' . urlencode( $ts->cat ) ); ?>"
         style="background:rgba(255,255,255,.15);color:#fff;border:1px solid rgba(255,255,255,.25);border-radius:20px;padding:4px 12px;font-size:.75rem;text-decoration:none">
        <?php echo esc_html( $ts_label ); ?>
      </a>
      <?php endforeach; ?>
    </div>
    <?php endif; ?>

    <!-- ── Custom CTA Buttons (admin-set) ── -->
    <?php if ($hero_cta1_text || $hero_cta2_text): ?>
    <div style="display:flex;flex-wrap:wrap;gap:12px;justify-content:center;margin-top:28px">
      <?php if ($hero_cta1_text && $hero_cta1_link): ?>
      <a href="<?php echo esc_url($hero_cta1_link); ?>" class="btn" style="<?php echo $hero_cta1_bg?'background:'.esc_attr($hero_cta1_bg).';color:'.esc_attr($hero_cta1_color).';border:none;':''; ?>padding:13px 28px;border-radius:10px;font-weight:700;font-size:.95rem;text-decoration:none;display:inline-flex;align-items:center;gap:6px"><?php echo esc_html($hero_cta1_text); ?></a>
      <?php endif; ?>
      <?php if ($hero_cta2_text && $hero_cta2_link): ?>
      <a href="<?php echo esc_url($hero_cta2_link); ?>" class="btn btn-wh" style="<?php echo $hero_cta2_bg?'background:'.esc_attr($hero_cta2_bg).';color:'.esc_attr($hero_cta2_color).';border:none;':''; ?>padding:13px 28px;border-radius:10px;font-weight:700;font-size:.95rem;text-decoration:none;display:inline-flex;align-items:center;gap:6px"><?php echo esc_html($hero_cta2_text); ?></a>
      <?php endif; ?>
    </div>
    <?php endif; ?>

  </div><!-- /.hw -->

  <?php if ($hero_tb_show && $hero_tb_text): ?>
  <!-- ── Hero Trust Bar marquee ── -->
  <div style="background:rgba(0,0,0,.25);padding:10px 0;overflow:hidden;margin-top:24px">
    <div style="display:flex;gap:40px;animation:heroMarquee <?php echo $hero_tb_speed; ?>s linear infinite;white-space:nowrap;will-change:transform">
      <?php
      $htb_items = array_filter(array_map('trim', explode('•', $hero_tb_text)));
      $htb_html  = '';
      foreach ($htb_items as $item) $htb_html .= '<span style="display:inline-flex;align-items:center;gap:6px;font-size:.83rem;font-weight:600;color:#fff"><span style="color:#F59E0B">✔</span>'.esc_html($item).'</span>';
      echo $htb_html . $htb_html;
      ?>
    </div>
  </div>
  <style>@keyframes heroMarquee{from{transform:translateX(0)}to{transform:translateX(-50%)}}</style>
  <?php endif; ?>

</section>

<!-- ════ FEATURED PROVIDERS — photo-forward, always shows real
     listings. Uses admin-curated sponsored listings when configured,
     otherwise falls back to genuine recent/active listings so this
     section — the visual anchor of the page — is never silently
     empty just because an opt-in admin toggle hasn't been enabled. ════ -->
<?php
$featured_use_sponsored = $show_sponsored && !empty($sponsored);
$featured_display = $featured_use_sponsored ? $sponsored : array_slice($latest, 0, $sponsored_total);
?>
<?php if(!empty($featured_display)): ?>
<section id="sponsored">
  <div class="hw<?php echo $sponsored_full_width ? ' spn-hw-wide' : ''; ?>">
    <div class="spn-hdr">
      <h2 class="spn-hdr-title"><?php echo $featured_use_sponsored ? 'Sponsored Businesses' : 'Recently Added Providers'; ?></h2>
      <a href="<?php echo esc_url($dir_url.'?sort='.($featured_use_sponsored?'featured':'newest')); ?>" class="spn-hdr-arrow" aria-label="View all">→</a>
    </div>
    <div id="spn-scroll">
      <div id="spn-row">
        <?php foreach($featured_display as $l):
          $thumb = ($l->banner_url??'') ?: ($l->logo_url??'');
          $slug_url = esc_url(home_url('/'.$l->slug.'/'));
        ?>
        <a href="<?php echo $slug_url; ?>" class="spn-card">
          <div class="spn-img">
            <?php if($thumb): ?><img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr($l->title); ?>" loading="lazy">
            <?php else: ?><div class="spn-img-ph"><span><?php echo !empty($l->cat_icon) ? wp_kses_post(html_entity_decode($l->cat_icon, ENT_HTML5|ENT_QUOTES, 'UTF-8')) : '🏢'; ?></span></div><?php endif; ?>
            <?php if( ($l->verification_status ?? '') === 'verified' ): ?>
            <span class="spn-badge">Verified</span>
            <?php endif; ?>
            <button type="button" class="spn-heart" data-listing-id="<?php echo (int)($l->id ?? 0); ?>" onclick="event.preventDefault();event.stopPropagation();gsToggleSave(this);" aria-label="Save <?php echo esc_attr($l->title); ?>">
              <svg viewBox="0 0 24 24" width="20" height="20" fill="rgba(0,0,0,.5)" stroke="#fff" stroke-width="1.5"><path d="M12 21s-6.5-4.35-9.3-8.1C.8 10.2 1.3 6.6 4.2 5c2.3-1.3 5-.6 6.8 1.4l1 1.1 1-1.1C14.8 4.4 17.5 3.7 19.8 5c2.9 1.6 3.4 5.2 1.5 7.9C18.5 16.65 12 21 12 21Z"/></svg>
            </button>
          </div>
          <div class="spn-body">
            <div class="spn-title"><?php echo esc_html($l->title); ?></div>
            <div class="spn-meta">
              <?php echo esc_html($l->city??'India'); ?><?php if( (float)($l->avg_rating??0) > 0 ): ?> · ★ <?php echo number_format((float)$l->avg_rating,1); ?><?php endif; ?>
            </div>
          </div>
        </a>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ════ SERVICES — Airbnb-style photo gallery ═══════════════════════ -->
<?php if(!empty($top_cats)): ?>
<section class="hs" style="padding:32px 0">
  <div class="hw">
    <div class="cat-gal-hdr">
      <h2 class="cat-gal-title">Browse by Service</h2>
    </div>
    <div id="cat-gallery">
      <?php foreach($top_cats as $cat):
        $cat_img = !empty($cat->icon_url) ? $cat->icon_url : '';
      ?>
        <a href="<?php echo esc_url(home_url('/directory/?category_id='.esc_attr($cat->id))); ?>" class="cat-gal-card">
          <div class="cat-gal-img">
            <?php if($cat_img): ?>
              <img src="<?php echo esc_url($cat_img); ?>" alt="<?php echo esc_attr($cat->name); ?>" loading="lazy">
            <?php else: ?>
              <div class="cat-gal-img-ph"><span><?php echo !empty($cat->icon_emoji) ? wp_kses_post(html_entity_decode($cat->icon_emoji, ENT_HTML5|ENT_QUOTES, 'UTF-8')) : '📂'; ?></span></div>
            <?php endif; ?>
          </div>
          <div class="cat-gal-nm"><?php echo esc_html($cat->name); ?></div>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ════ DISCOVER CITIES (Sulekha style) ══════════════════════ -->
<?php if(!empty($top_cities)): ?>
<section id="cities">
  <div class="hw">
    <div class="hs-hdr">
      <div class="ey">Locations</div>
      <h2 class="ht">Discover Major Cities</h2>
      <p class="hs-sub">Find verified service providers in your city</p>
      <div class="dv"></div>
    </div>
    <div class="city-grid">
      <?php foreach($top_cities as $c): ?>
        <a href="<?php echo esc_url(home_url('/directory/?city='.urlencode($c->city))); ?>" class="city-pill">
          📍 <?php echo esc_html($c->city); ?>
          <span class="city-pill-n"><?php echo $c->n; ?></span>
        </a>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ════ HOW IT WORKS ════════════════════════════════════════ -->
<section class="hs hs-dk" id="how-it-works">
  <div class="hw">
    <div class="hs-hdr">
      <div class="ey ey-w">Simple Process</div>
      <h2 class="ht ht-w">Get Help in 4 Simple Steps</h2>
      <div class="dv dv-g"></div>
    </div>
    <div class="how-grid">
      <?php foreach($how_steps as $i=>$step): ?>
      <div class="how-card">
        <div class="how-step"><?php echo $step['icon']; ?><span class="how-num"><?php echo $i+1; ?></span></div>
        <div class="how-title"><?php echo esc_html($step['title']); ?></div>
        <div class="how-desc"><?php echo esc_html($step['desc']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:32px">
      <a href="<?php echo esc_url( home_url('/how-it-works/') ); ?>" class="btn btn-o btn-sm">See How It Works in Detail →</a>
    </div>
  </div>
</section>

<!-- ════ LATEST LISTINGS ══════════════════════════════════════ -->
<!-- Only shown when the top featured section displayed curated sponsored
     content — in that case this section adds genuinely different content
     (recent additions). When sponsored is off, the top section already
     shows $latest directly, so showing it again here would be duplicate
     content, not a second, distinct section. -->
<?php if($featured_use_sponsored && !empty($latest)): ?>
<section class="hs">
  <div class="hw">
    <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:32px;flex-wrap:wrap;gap:10px">
      <div>
        <div class="ey" style="text-align:left;margin-bottom:4px">New</div>
        <h2 class="ht" style="font-size:24px">Latest Listings</h2>
      </div>
      <a href="<?php echo esc_url($dir_url.'?sort=newest'); ?>" class="btn btn-o btn-sm">View All →</a>
    </div>
    <div class="ll-grid" id="gsLLGrid" data-section="latest-listings">
      <?php foreach($latest as $l):
        $thumb = ($l->banner_url??'') ?: ($l->logo_url??'');
        $lurl  = esc_url(home_url('/'.$l->slug.'/'));
        $is_verified = ($l->verification_status ?? '') === 'verified';
        $is_featured = !empty($l->is_featured);
      ?>
      <a href="<?php echo $lurl; ?>" class="ll-card">
        <div class="ll-img">
          <?php if($thumb): ?><img src="<?php echo esc_url($thumb); ?>" alt="<?php echo esc_attr($l->title); ?>" loading="lazy">
          <?php else: ?><?php echo !empty($l->cat_icon) ? wp_kses_post(html_entity_decode($l->cat_icon, ENT_HTML5|ENT_QUOTES, 'UTF-8')) : '🏢'; ?><?php endif; ?>
        </div>
        <div class="ll-body">
          <?php if($is_verified || $is_featured): ?>
          <div class="ll-badges">
            <?php if($is_featured): ?><span class="ll-badge ll-badge-featured">⭐ Featured</span><?php endif; ?>
            <?php if($is_verified): ?><span class="ll-badge ll-badge-verified">✓ Verified</span><?php endif; ?>
          </div>
          <?php endif; ?>
          <div class="ll-cat"><?php echo esc_html($l->cat_name??'Service'); ?></div>
          <div class="ll-title"><?php echo esc_html($l->title); ?></div>
          <div class="ll-city">📍 <?php echo esc_html($l->city??'India'); ?></div>
          <?php if($l->avg_rating>0): ?><div class="ll-rat">★ <?php echo number_format((float)$l->avg_rating,1); ?> (<?php echo (int)$l->review_count; ?> reviews)</div><?php endif; ?>
        </div>
        <div class="ll-actions">
          <span class="ll-btn ll-btn-v">View</span>
          <?php if($l->phone): ?><span class="ll-btn ll-btn-d">📞 Call</span><?php endif; ?>
        </div>
      </a>
      <?php endforeach; ?>
    </div>
    <div style="text-align:center;margin-top:32px">
      <a href="<?php echo esc_url($dir_url); ?>" class="btn btn-p btn-lg">Browse All Listings →</a>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ════ STATS ════════════════════════════════════════════════ -->
<?php
// Real fix: only show stats that are genuinely non-zero — a "0+ Customer
// Reviews" stat displayed prominently in large bold text (confirmed visible
// in the actual rendered page) undermines trust rather than building it,
// the same problem already correctly solved for the hero trust bar in Phase 1
// but never applied here. Grid column count below matches the actual count
// so hiding one stat doesn't leave an empty gap.
$stats_display = [];
if ($stats['services'] > 0) $stats_display[] = ['n' => $stats['services'], 'l' => 'Online Businesses'];
if ($stats['vendors']  > 0) $stats_display[] = ['n' => $stats['vendors'],  'l' => 'Vendor Listings'];
if (count($top_cats)   > 0) $stats_display[] = ['n' => count($top_cats),   'l' => 'Categories'];
if ($stats['reviews']  > 0) $stats_display[] = ['n' => $stats['reviews'],  'l' => 'Customer Reviews'];
?>
<?php if (!empty($stats_display)): ?>
<div id="stats">
  <div class="hw">
    <div id="stats-row">
      <?php foreach ($stats_display as $s): ?>
      <div class="st"><span class="st-n" data-t="<?php echo (int)$s['n']; ?>">0+</span><span class="st-l"><?php echo esc_html($s['l']); ?></span></div>
      <?php endforeach; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- ════ WHY CHOOSE US ════════════════════════════════════════ -->
<section class="hs hs-alt">
  <div class="hw">
    <div class="hs-hdr">
      <div class="ey">Why Us</div>
      <h2 class="ht">Why Choose <?php echo esc_html($site_name); ?>?</h2>
      <p class="hs-sub">We make it simple to find, compare and hire verified professionals</p>
      <div class="dv"></div>
    </div>
    <div class="why-grid">
      <?php foreach($why_items as $w): ?>
      <div class="why-card">
        <div class="why-ic"><?php echo $w['icon']; ?></div>
        <h3 class="why-title"><?php echo esc_html($w['title']); ?></h3>
        <p class="why-desc"><?php echo esc_html($w['desc']); ?></p>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════ CTA GROW (OnlineX Sewa style with stats) ════════════ -->
<section id="cta-grow">
  <div class="hw">
    <h2>Are You Ready to Grow Your Business?</h2>
    <p>Join and connect with thousands of businesses locally, globally and reach new customers every day.</p>
    <div class="cta-btns">
      <a href="<?php echo esc_url($reg_url); ?>" class="btn btn-wh btn-lg" style="border-color:rgba(255,255,255,.5)">Register Your Business</a>
      <a href="<?php echo esc_url($dir_url); ?>" class="btn btn-lg" style="background:rgba(255,255,255,.15);color:#fff;border:1.5px solid rgba(255,255,255,.3)">Learn More</a>
    </div>
    <div class="cta-stats">
      <?php foreach ($stats_display as $s): ?>
      <div class="cta-stat"><span class="cta-stat-n"><?php echo (int)$s['n']; ?>+</span><span class="cta-stat-l"><?php echo esc_html($s['l']); ?></span></div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════ TESTIMONIALS ════════════════════════════════════════ -->
<?php if(!empty($testimonials)): ?>
<section class="hs">
  <div class="hw">
    <div class="hs-hdr">
      <div class="ey">Reviews</div>
      <h2 class="ht">What Our Users Say</h2>
      <p class="hs-sub">Real experiences from people who found the perfect service provider</p>
      <div class="dv"></div>
    </div>
    <div class="testi-grid">
      <?php foreach($testimonials as $t): ?>
      <div class="testi-card">
        <div class="testi-stars"><?php echo str_repeat('★', max(0,min(5,(int)$t['rating']))); ?></div>
        <p class="testi-quote">"<?php echo esc_html($t['text']); ?>"</p>
        <div class="testi-user">
          <div class="testi-av"><?php echo strtoupper(substr($t['name'],0,1)); ?></div>
          <div>
            <div class="testi-name"><?php echo esc_html($t['name']); ?></div>
            <div class="testi-meta"><?php echo esc_html($t['service']); ?><?php echo $t['city'] ? ' · '.esc_html($t['city']) : ''; ?></div>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>
<?php endif; ?>

<!-- ════ APP / PWA PROMOTION ═══════════════════════════════════ -->
<section class="hs hs-dk" id="app-promo">
  <div class="hw">
    <div class="app-promo-grid">
      <div>
        <div class="ey ey-w">Take It With You</div>
        <h2 class="ht ht-w" style="text-align:left">One Tap From Your Home Screen</h2>
        <p style="color:rgba(255,255,255,.75);font-size:15px;line-height:1.7;max-width:440px;margin:14px 0 24px">
          Add <?php echo esc_html($site_name); ?> to your phone's home screen for instant access to your inquiries, saved providers, and booking history — no app store download required.
        </p>
        <ul class="app-promo-list">
          <li>📲 Works like a native app, installs in one tap</li>
          <li>🔔 Get notified the moment a provider replies</li>
          <li>⚡ Loads instantly, even on a slow connection</li>
        </ul>
        <div style="display:flex;flex-wrap:wrap;gap:10px;margin-top:8px">
          <a href="<?php echo esc_url( home_url( '/install-app/' ) ); ?>" class="btn btn-wh btn-lg gs-install-btn" style="display:inline-flex;text-decoration:none" aria-label="Download App">⬇ Download App</a>
          <a href="<?php echo esc_url(home_url('/my-account/')); ?>" class="btn btn-wh btn-lg">Open My Account →</a>
        </div>
      </div>
      <div class="app-promo-visual">
        <div class="app-promo-phone">
          <div class="app-promo-phone-notch"></div>
          <div class="app-promo-phone-screen">
            <div class="app-promo-ss-header">
              <span class="app-promo-ss-dot"></span>
              <span><?php echo esc_html($site_name); ?></span>
            </div>
            <div class="app-promo-ss-card">📬 New inquiry reply</div>
            <?php if($stats['avg_rating_display']): ?>
            <div class="app-promo-ss-card">⭐ <?php echo esc_html($stats['avg_rating_display']); ?> average rating</div>
            <?php endif; ?>
            <?php if($stats['vendors'] > 0): ?>
            <div class="app-promo-ss-card">✓ <?php echo number_format($stats['vendors']); ?>+ verified providers</div>
            <?php endif; ?>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- ════ FAQ ══════════════════════════════════════════════════ -->
<section class="hs hs-alt">
  <div class="hw">
    <div class="hs-hdr">
      <div class="ey">FAQ</div>
      <h2 class="ht">Frequently Asked Questions</h2>
      <div class="dv"></div>
    </div>
    <div class="faq-wrap">
      <?php foreach($faq_items as $faq): ?>
      <div class="faq-item">
        <div class="faq-q" onclick="this.classList.toggle('open')">
          <?php echo esc_html($faq['q']); ?>
          <span class="faq-arr">▾</span>
        </div>
        <div class="faq-a"><?php echo esc_html($faq['a']); ?></div>
      </div>
      <?php endforeach; ?>
    </div>
  </div>
</section>

<!-- ════ CTA VENDOR BAND ══════════════════════════════════════ -->
<section id="cta-v">
  <div class="hw">
    <div id="cta-v-in">
      <div>
        <h2>Are You a Service Provider?</h2>
        <p>Join thousands of verified professionals growing their business on our platform. Get qualified leads and build your reputation.</p>
        <div class="cta-perks">
          <span class="cta-perk">✅ Free to start</span>
          <span class="cta-perk">✅ Get qualified leads</span>
          <span class="cta-perk">✅ Build your reputation</span>
        </div>
      </div>
      <a href="<?php echo esc_url($reg_url); ?>" class="btn btn-g btn-lg">Register Your Business →</a>
    </div>
  </div>
</section>

<!-- ════ FOOTER (OnlineX Sewa style) ═════════════════════════ -->
<footer id="hfooter">
  <div class="hw">
    <div class="hf-grid">
      <!-- Brand -->
      <div>
        <?php if($logo_url): ?><img src="<?php echo esc_url($logo_url); ?>" alt="<?php echo esc_attr($site_name); ?>" class="hf-brand"><?php else: ?>
        <a href="<?php echo home_url('/'); ?>" class="hf-brand"><?php echo esc_html($site_name); ?></a><?php endif; ?>
        <p class="hf-about">Your trusted platform for finding verified professional service providers across India. Fast, free, and reliable.</p>
        <div class="hf-social">
          <?php $fb_url = function_exists('gs_setting') ? gs_setting('platform_facebook','') : ''; if ($fb_url): ?><a href="<?php echo esc_url($fb_url); ?>" title="Facebook" target="_blank" rel="noopener">📘</a><?php endif; ?>
          <?php $ig_url = function_exists('gs_setting') ? gs_setting('platform_instagram','') : ''; if ($ig_url): ?><a href="<?php echo esc_url($ig_url); ?>" title="Instagram" target="_blank" rel="noopener">📸</a><?php endif; ?>
          <?php $tw_url = function_exists('gs_setting') ? gs_setting('platform_twitter','') : ''; if ($tw_url): ?><a href="<?php echo esc_url($tw_url); ?>" title="Twitter" target="_blank" rel="noopener">🐦</a><?php endif; ?>
          <?php $li_url = function_exists('gs_setting') ? gs_setting('platform_linkedin','') : ''; if ($li_url): ?><a href="<?php echo esc_url($li_url); ?>" title="LinkedIn" target="_blank" rel="noopener">💼</a><?php endif; ?>
        </div>
        <?php $cp=Config::get('contact_phone',''); $ce=Config::get('contact_email',''); $ca=Config::get('platform_address',''); ?>
        <div style="margin-top:16px;display:flex;flex-direction:column;gap:7px">
          <?php if($cp): ?><span style="font-size:13px;color:rgba(255,255,255,.5)">📞 <?php echo esc_html($cp); ?></span><?php endif; ?>
          <?php if($ce): ?><span style="font-size:13px;color:rgba(255,255,255,.5)">📧 <?php echo esc_html($ce); ?></span><?php endif; ?>
          <?php if($ca): ?><span style="font-size:13px;color:rgba(255,255,255,.5)">📍 <?php echo esc_html($ca); ?></span><?php endif; ?>
        </div>
      </div>
      <!-- About Links -->
      <div>
        <div class="hf-ct">About Company</div>
        <div class="hf-links">
          <a href="<?php echo esc_url(home_url('/about-us/')); ?>">About Us</a>
          <a href="<?php echo esc_url(home_url('/how-it-works/')); ?>">How It Works</a>
          <a href="<?php echo esc_url(home_url('/trust-safety/')); ?>">Trust &amp; Safety</a>
          <a href="<?php echo esc_url( home_url('/advertise/') ); ?>">List Your Business</a>
          <a href="<?php echo esc_url(home_url('/blog/')); ?>">Blog</a>
        </div>
      </div>
      <!-- Helpful Topics -->
      <div>
        <div class="hf-ct">Helpful Topics</div>
        <div class="hf-links">
          <a href="<?php echo esc_url(home_url('/contact-us/')); ?>">Contact Us</a>
          <a href="<?php echo esc_url($dir_url); ?>">Browse Directory</a>
          <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>">Privacy Policy</a>
          <a href="<?php echo esc_url(home_url('/terms-of-service/')); ?>">Terms &amp; Conditions</a>
          <a href="<?php echo esc_url(home_url('/refund-policy/')); ?>">Refund &amp; Cancellation</a>
        </div>
      </div>
      <!-- Category links -->
      <div>
        <div class="hf-ct">Popular Services</div>
        <div class="hf-links">
          <?php foreach(array_slice($top_cats,0,7) as $cat): ?>
            <a href="<?php echo esc_url(home_url('/directory/?category_id='.esc_attr($cat->id))); ?>"><?php echo esc_html($cat->name); ?></a>
          <?php endforeach; ?>
          <a href="<?php echo esc_url($dir_url); ?>">View All →</a>
        </div>
      </div>
    </div>
    <!-- Social + Popular Cities -->
    <div style="border-top:1px solid rgba(255,255,255,.07);padding:24px 0;margin-bottom:8px">
      <?php if(!empty($top_cities)): ?>
      <div style="font-size:11px;font-weight:800;text-transform:uppercase;letter-spacing:.1em;color:#fff;margin-bottom:12px">Popular Cities</div>
      <div style="display:flex;flex-wrap:wrap;gap:8px">
        <?php foreach($top_cities as $c): ?>
          <a href="<?php echo esc_url(home_url('/directory/?city='.urlencode($c->city))); ?>" style="font-size:12px;color:rgba(255,255,255,.45);transition:color .18s" onmouseover="this.style.color='<?php echo esc_js($primary_color); ?>'" onmouseout="this.style.color='rgba(255,255,255,.45)'"><?php echo esc_html($c->city); ?></a>
          <span style="color:rgba(255,255,255,.15)">·</span>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>
    <!-- Bottom bar -->
    <div class="hf-bottom">
      <span style="color:rgba(255,255,255,.4)">© <?php echo date('Y'); ?> <strong style="color:rgba(255,255,255,.7)"><?php echo esc_html($site_name); ?></strong>. All Rights Reserved.</span>
      <div class="hf-bottom-links">
        <a href="<?php echo esc_url(home_url('/privacy-policy/')); ?>">Privacy Policy</a>
        <a href="<?php echo esc_url(home_url('/terms-of-service/')); ?>">Terms of Service</a>
        <a href="<?php echo esc_url(home_url('/cookie-policy/')); ?>">Cookie Policy</a>
      </div>
    </div>
  </div>
</footer>

<script>
(function(){
var AJX='<?php echo esc_js($ajax_url); ?>';
var NONCE='<?php echo esc_js($nonce); ?>';

/* ════════════════════════════════════════════════════
   AIRBNB-STYLE SEARCH PILL — Full interaction model
════════════════════════════════════════════════════ */
var SP = {
  active: null,      // which segment is open: 'what'|'city'|'cat'|null
  cityVal: '',
  cityLabel: '',
  catVal: '',
  catLabel: '',
};

/* ── Open / toggle a segment ── */
window.spOpen = function(which, evt) {
  if (evt) evt.stopPropagation();

  if (SP.active === which) {
    spCloseAll(); return;
  }

  // Close previous without animation overhead
  if (SP.active) {
    var prev = document.getElementById('sp-s-' + SP.active);
    if (prev) prev.classList.remove('sp-active');
  }

  SP.active = which;
  var sec = document.getElementById('sp-s-' + which);
  if (sec) sec.classList.add('sp-active');

  // Show overlay
  var ov = document.getElementById('sp-overlay');
  if (ov) ov.classList.add('show');

  // Manage divider visibility
  spSyncDividers(which);

  // Part 20.1 — Voice Search (Part 11.1 — intent detection)
(function() {
  var SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  var voiceBtn = document.getElementById('gs-voice-btn');
  if (!SpeechRecognition || !voiceBtn) return;
  voiceBtn.style.display = 'inline-block';
  var recognition = new SpeechRecognition();
  recognition.lang = 'en-IN';
  recognition.continuous = false;
  recognition.interimResults = false;
  window.gsVoiceSearch = function(e) {
    e.stopPropagation();
    voiceBtn.textContent = '🔴';
    voiceBtn.setAttribute('aria-label', 'Listening...');
    recognition.start();
  };
  recognition.onresult = function(e) {
    var t = e.results[0][0].transcript;
    var inp = document.getElementById('hkw');
    if (inp) { inp.value = t; spKwInput(); }
  };
  recognition.onend = function() {
    voiceBtn.textContent = '🎙️';
    voiceBtn.setAttribute('aria-label', 'Voice search');
  };
  recognition.onerror = function() {
    voiceBtn.textContent = '🎙️';
  };
})();

// Part 11.1 — Intent detection: suggest category chip
var INTENT_MAP = {
  'plumber':['plumber','plumbing','pipe','leak','tap','drain','geyser'],
  'electrician':['electrician','electrical','wiring','mcb','fan','switch','light'],
  'ca':['ca','chartered','accountant','tax','itr','gst','filing'],
  'packers-movers':['movers','packers','shifting','relocation','move'],
  'pest-control':['pest','cockroach','termite','rat','mosquito','bed bug'],
  'interior-designer':['interior','design','renovation','decor'],
  'cleaning':['cleaning','clean','maid','housekeeping'],
  'plumbing':['drain','blockage','pipeline','overflow'],
};
function gsDetectIntent(q) {
  var lower = q.toLowerCase();
  for (var cat in INTENT_MAP) {
    var kws = INTENT_MAP[cat];
    for (var i=0;i<kws.length;i++) {
      if (lower.indexOf(kws[i]) > -1) return cat;
    }
  }
  return null;
}
var _intentTimeout;
document.addEventListener('input', function(e) {
  if (e.target.id !== 'hkw') return;
  clearTimeout(_intentTimeout);
  _intentTimeout = setTimeout(function() {
    var q = document.getElementById('hkw').value;
    var intent = q.length > 2 ? gsDetectIntent(q) : null;
    var chip = document.getElementById('gs-intent-chip');
    if (intent) {
      if (!chip) {
        chip = document.createElement('div');
        chip.id = 'gs-intent-chip';
        chip.style.cssText = 'padding:8px 12px;background:#EFF6FF;border-radius:8px;font-size:.8rem;color:#1D4ED8;cursor:pointer;margin-top:8px';
        chip.onclick = function() { spSetCat(intent); spCloseAll(); hSearch(); };
        var drop = document.getElementById('sp-drop-what');
        if (drop) drop.appendChild(chip);
      }
      chip.textContent = '💡 Looking for a ' + intent.replace(/-/g,' ') + '? Browse →';
      chip.style.display = 'block';
    } else if (chip) {
      chip.style.display = 'none';
    }
  }, 350);
});

// Auto-focus keyword input
  if (which === 'what') {
    setTimeout(function(){ var i=document.getElementById('hkw'); if(i) i.focus(); }, 60);
  }
};

/* ── Close all ── */
window.spCloseAll = function() {
  if (SP.active) {
    var sec = document.getElementById('sp-s-' + SP.active);
    if (sec) sec.classList.remove('sp-active');
    SP.active = null;
  }
  var ov = document.getElementById('sp-overlay');
  if (ov) ov.classList.remove('show');

  // Restore all dividers
  document.querySelectorAll('.sp-div').forEach(function(d){ d.classList.remove('sp-hide'); });
};

/* ── Manage dividers: hide divider adjacent to active segment ── */
function spSyncDividers(which) {
  var d1 = document.getElementById('sp-div-1');
  var d2 = document.getElementById('sp-div-2');
  if (!d1 || !d2) return;
  d1.classList.remove('sp-hide');
  d2.classList.remove('sp-hide');
  if (which === 'what')  { d1.classList.add('sp-hide'); }
  if (which === 'city')  { d1.classList.add('sp-hide'); d2.classList.add('sp-hide'); }
  if (which === 'cat')   { d2.classList.add('sp-hide'); }
}

/* ── Hover: hide adjacent dividers on hover too ── */
['what','city','cat'].forEach(function(w) {
  var el = document.getElementById('sp-s-' + w);
  if (!el) return;
  el.addEventListener('mouseenter', function() {
    if (SP.active && SP.active !== w) return; // don't interfere with open
    if (!SP.active) spSyncDividers(w);
  });
  el.addEventListener('mouseleave', function() {
    if (!SP.active) {
      document.querySelectorAll('.sp-div').forEach(function(d){ d.classList.remove('sp-hide'); });
    }
  });
});

/* ── Keyword input live update ── */
window.spKwInput = function() {
  var inp = document.getElementById('hkw');
  var valEl = document.getElementById('sp-val-what');
  var clr = document.getElementById('sp-clr-what');
  if (!inp || !valEl) return;
  var v = inp.value.trim();
  valEl.textContent = v || 'Search services, businesses…';
  if (v) { valEl.classList.add('sp-filled'); if(clr) clr.classList.add('sp-has-val'); }
  else   { valEl.classList.remove('sp-filled'); if(clr) clr.classList.remove('sp-has-val'); }
};

/* ── Set keyword from tag or htag chip ── */
window.spSetKw = function(kw, andSearch) {
  var inp = document.getElementById('hkw');
  if (inp) inp.value = kw;
  spKwInput();
  if (andSearch) { spCloseAll(); hSearch(); }
  else { spOpen('what', null); }
};

/* ── Set city ── */
window.spSetCity = function(val, label, evt) {
  if (evt) evt.stopPropagation();
  SP.cityVal = val;
  SP.cityLabel = label;
  document.getElementById('hcity').value = val;

  var valEl = document.getElementById('sp-val-city');
  var clr   = document.getElementById('sp-clr-city');
  if (valEl) {
    valEl.textContent = val ? label : 'Any city';
    if (val) { valEl.classList.add('sp-filled'); if(clr) clr.classList.add('sp-has-val'); }
    else     { valEl.classList.remove('sp-filled'); if(clr) clr.classList.remove('sp-has-val'); }
  }

  // Highlight selected city
  document.querySelectorAll('.sp-ci[data-city]').forEach(function(el){
    el.classList.toggle('sp-sel', el.dataset.city === val);
  });
  var anyEl = document.getElementById('sp-ci-any');
  if (anyEl) anyEl.classList.toggle('sp-sel', !val);

  spCloseAll();
};

/* ── Set category ── */
window.spSetCat = function(val, label, evt) {
  if (evt) evt.stopPropagation();
  SP.catVal = val;
  SP.catLabel = label;
  document.getElementById('hcat').value = val;

  var valEl = document.getElementById('sp-val-cat');
  var clr   = document.getElementById('sp-clr-cat');
  if (valEl) {
    valEl.textContent = val ? label : 'All categories';
    if (val) { valEl.classList.add('sp-filled'); if(clr) clr.classList.add('sp-has-val'); }
    else     { valEl.classList.remove('sp-filled'); if(clr) clr.classList.remove('sp-has-val'); }
  }

  // Highlight selected category
  document.querySelectorAll('.sp-ca[data-cat]').forEach(function(el){
    el.classList.toggle('sp-sel', el.dataset.cat === String(val));
  });
  var anyEl = document.getElementById('sp-ca-any');
  if (anyEl) anyEl.classList.toggle('sp-sel', !val);

  spCloseAll();
};

// Real feature — category search bar, explicitly requested: lets a
// vendor type to find and pick a subcategory directly, without
// needing a separate segment. Full category tree embedded once (same
// proven pattern as the listing form) rather than a server round-trip
// on every keystroke.
var HP_ALL_CATEGORIES = <?php echo wp_json_encode( array_map( function( $c ) {
    return [ 'id' => (int) $c->id, 'parent_id' => (int) $c->parent_id, 'name' => $c->name, 'icon' => $c->icon_emoji ?? '📂' ];
}, $cats ) ); ?>;
var HP_TOP_CATEGORY_IDS = <?php echo wp_json_encode( array_map( fn( $c ) => (int) $c->id, $top_cats ) ); ?>;

function spCatSearchInput() {
  var q = document.getElementById('sp-cat-search').value.trim().toLowerCase();
  var grid = document.getElementById('sp-cat-grid-list');
  if (!grid) return;

  if (!q) {
    // Restore the original default view — main categories only.
    var html = '<div class="sp-ca-any sp-sel" id="sp-ca-any" onclick="spSetCat(\'\',\'All categories\',event)"><span>📂</span> All Categories</div>';
    HP_ALL_CATEGORIES.forEach(function(c) {
      if (HP_TOP_CATEGORY_IDS.indexOf(c.id) === -1) return;
      html += '<div class="sp-ca" data-cat="' + c.id + '" onclick="spSetCat(\'' + c.id + '\',\'' + c.name.replace(/'/g,"\\'") + '\',event)">' +
        '<span class="sp-ca-ic">' + c.icon + '</span><span class="sp-ca-nm">' + c.name.replace(/&/g,'&amp;').replace(/</g,'&lt;') + '</span></div>';
    });
    grid.innerHTML = html;
    return;
  }

  var byId = {};
  HP_ALL_CATEGORIES.forEach(function(c) { byId[c.id] = c; });
  var matches = HP_ALL_CATEGORIES.filter(function(c) { return c.name.toLowerCase().indexOf(q) !== -1; });

  if (!matches.length) {
    grid.innerHTML = '<div style="padding:10px;color:#94A3B8;font-size:.82rem">No categories match "' + q.replace(/</g,'&lt;') + '"</div>';
    return;
  }
  var html = '';
  matches.forEach(function(c) {
    var parentName = c.parent_id ? ( (byId[c.parent_id] || {}).name || '' ) : '';
    html += '<div class="sp-ca" data-cat="' + c.id + '" onclick="spSetCat(\'' + c.id + '\',\'' + c.name.replace(/'/g,"\\'") + '\',event)">' +
      '<span class="sp-ca-ic">' + c.icon + '</span>' +
      '<span class="sp-ca-nm">' + c.name.replace(/&/g,'&amp;').replace(/</g,'&lt;') + (parentName ? '<span style="display:block;font-size:.68rem;color:#94A3B8;font-weight:400">in ' + parentName.replace(/&/g,'&amp;').replace(/</g,'&lt;') + '</span>' : '') + '</span>' +
    '</div>';
  });
  grid.innerHTML = html;
}

/* ── Clear a segment ── */
window.spClear = function(which, evt) {
  if (evt) { evt.stopPropagation(); evt.preventDefault(); }
  if (which === 'what') {
    var inp = document.getElementById('hkw');
    if (inp) inp.value = '';
    spKwInput();
  } else if (which === 'city') {
    spSetCity('', '', null);
  } else if (which === 'cat') {
    spSetCat('', '', null);
  }
};

/* ── Close on ESC ── */
document.addEventListener('keydown', function(e) {
  if (e.key === 'Escape') spCloseAll();
});

/* ── Close on outside click ── */
document.addEventListener('click', function(e) {
  if (!SP.active) return;
  var wrap = document.getElementById('srch-wrap');
  if (wrap && !wrap.contains(e.target)) spCloseAll();
});

/* Search */
window.hSearch=function(){
  var kw=document.getElementById('hkw').value.trim();
  var city=document.getElementById('hcity').value;
  var cat=document.getElementById('hcat').value;
  var url='<?php echo esc_js($dir_url); ?>?';
  if(kw)   url+='keyword='+encodeURIComponent(kw)+'&';
  if(city) url+='city='+encodeURIComponent(city)+'&';
  if(cat)  url+='category_id='+encodeURIComponent(cat)+'&';
  location.href=url.replace(/[?&]$/,'');
};

/* Save/bookmark toggle — real fix: the heart button on featured cards
   rendered on every card, looked functional, and did absolutely nothing
   (onclick only prevented navigation). The backend toggle endpoint
   (gs_save_listing_bookmark) already existed, fully working, wired to
   the customer dashboard's Saved section — this connects the two. */
window.gsToggleSave=function(btn){
  var lid=btn.getAttribute('data-listing-id');
  if(!lid||lid==='0')return;
  <?php if ( ! is_user_logged_in() ): ?>
  // Guest: honest prompt instead of a silent failure — saving requires
  // an account for the saved list to persist and appear in My Account.
  if(confirm('Sign in to save listings to your account. Go to login now?')){
    location.href='<?php echo esc_js( home_url( '/login/?redirect_to=' . rawurlencode( home_url( '/' ) ) ) ); ?>';
  }
  return;
  <?php endif; ?>
  var svg=btn.querySelector('svg path');
  var fd=new FormData();
  fd.append('action','gs_save_listing_bookmark');
  fd.append('nonce','<?php echo esc_js( wp_create_nonce( 'gs_ajax' ) ); ?>');
  fd.append('listing_id',lid);
  fetch('<?php echo esc_js( admin_url( 'admin-ajax.php' ) ); ?>',{method:'POST',body:fd})
    .then(function(r){return r.json();})
    .then(function(d){
      if(d.success){
        var saved=d.data&&d.data.saved;
        if(svg){svg.parentElement.setAttribute('fill',saved?'#E11D48':'rgba(0,0,0,.5)');}
        btn.setAttribute('aria-pressed',saved?'true':'false');
      }
    })
    .catch(function(){/* network error — leave state unchanged rather than lie */});
};

/* Stats counter */
var animated=false;
function runCounters(){
  if(animated) return; animated=true;
  document.querySelectorAll('.st-n[data-t]').forEach(function(el){
    var target=parseInt(el.dataset.t)||0;
    if(!target){el.textContent='0+';return;}
    var start=0,step=target/120;
    var t=setInterval(function(){start+=step;if(start>=target){el.textContent=target.toLocaleString()+'+';clearInterval(t);}else el.textContent=Math.floor(start).toLocaleString()+'+';},16);
  });
}
var sEl=document.getElementById('stats');
if(sEl)new IntersectionObserver(function(e){if(e[0].isIntersecting)runCounters();},{threshold:.3}).observe(sEl);

/* ── Phase 8: AI Concierge Search ── */
window.gsToggleAISearch = function() {
  var pill    = document.getElementById('srch-wrap');
  var aiBar   = document.getElementById('gs-ai-search-bar');
  var toggle  = document.getElementById('gs-ai-toggle');
  var heroTags = document.getElementById('hero-tags');
  if (!pill || !aiBar) return;

  var aiActive = aiBar.style.display !== 'none';

  if (aiActive) {
    // Switch back to standard search
    aiBar.style.display  = 'none';
    pill.style.display   = '';
    if (heroTags) heroTags.style.display = '';
    if (toggle) { toggle.textContent = '✨ AI'; toggle.style.background = 'rgba(255,255,255,.12)'; }
    // Clear AI results so they don't linger when pill is restored
    var out = document.getElementById('gs-ai-results');
    if (out) out.innerHTML = '';
  } else {
    // Switch to AI search
    pill.style.display   = 'none';
    aiBar.style.display  = 'block';
    if (heroTags) heroTags.style.display = 'none'; // hide tag chips, AI has its own results area
    if (toggle) { toggle.textContent = '✕ Normal'; toggle.style.background = 'rgba(255,255,255,.2)'; }
    var inp = document.getElementById('gs-ai-inp');
    if (inp) { inp.focus(); }
  }
};

window.gsAISearch = function() {
  var inp    = document.getElementById('gs-ai-inp');
  var btn    = document.getElementById('gs-ai-btn');
  var out    = document.getElementById('gs-ai-results');
  var query  = inp ? inp.value.trim() : '';
  if (!query) { if(inp) inp.focus(); return; }
  if (btn) { btn.disabled = true; btn.textContent = '…'; }
  if (out) out.innerHTML = '<div style="padding:16px;text-align:center;color:rgba(255,255,255,.7);font-size:.85rem">✨ Finding the best match for you…</div>';

  // Local HTML escaper — AI result fields come from DB via JSON and must be escaped
  // before insertion into innerHTML to prevent XSS.
  function esc(s) {
    return String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
  }

  var fd = new FormData();
  fd.append('action','gs_ai_concierge_search');
  fd.append('nonce','<?php echo esc_js(wp_create_nonce("gs_ajax")); ?>');
  fd.append('query',query);
  fd.append('city', (document.getElementById('hcity')||{value:''}).value);

  fetch('<?php echo esc_js(admin_url("admin-ajax.php")); ?>',{method:'POST',body:fd,credentials:'same-origin'})
    .then(function(r){return r.json();})
    .then(function(d){
      if(btn){btn.disabled=false;btn.textContent='Search';}
      if(!d||!d.success){
        if(out)out.innerHTML='<div style="padding:16px;color:#FCA5A5;font-size:.84rem">Could not process your search. Try the main search above.</div>';
        return;
      }
      var data    = d.data;
      var vendors = data.vendors || [];
      var parsed  = data.parsed  || {};
      if(!vendors.length){
        if(out)out.innerHTML='<div style="background:rgba(255,255,255,.1);border-radius:10px;padding:16px;color:rgba(255,255,255,.8);font-size:.84rem">No matching vendors found. Try the main search or browse <a href="/directory/" style="color:#93C5FD">all services</a>.</div>';
        return;
      }
      var intentTags = '';
      if(parsed.category_slug)  intentTags += '<span style="background:rgba(255,255,255,.15);border-radius:10px;padding:2px 10px;font-size:.72rem;margin-right:6px">📂 '+esc(parsed.category_slug.replace(/-/g,' '))+'</span>';
      if(parsed.date_hint&&parsed.date_hint!=='flexible') intentTags += '<span style="background:rgba(255,255,255,.15);border-radius:10px;padding:2px 10px;font-size:.72rem;margin-right:6px">📅 '+esc(parsed.date_hint.replace(/_/g,' '))+'</span>';
      if(parsed.city)           intentTags += '<span style="background:rgba(255,255,255,.15);border-radius:10px;padding:2px 10px;font-size:.72rem;margin-right:6px">📍 '+esc(parsed.city)+'</span>';
      if(parsed.budget_max)     intentTags += '<span style="background:rgba(255,255,255,.15);border-radius:10px;padding:2px 10px;font-size:.72rem;margin-right:6px">💰 Under ₹'+parseInt(parsed.budget_max).toLocaleString('en-IN')+'</span>';

      var html = '<div style="background:rgba(255,255,255,.08);backdrop-filter:blur(10px);border:1px solid rgba(255,255,255,.15);border-radius:14px;padding:16px">';
      if(intentTags) html += '<div style="margin-bottom:12px;font-size:.78rem;color:rgba(255,255,255,.6)">AI found: '+intentTags+'</div>';
      vendors.forEach(function(v){
        var vendorUrl = '/'+esc(v.slug)+'/';
        var stars = v.avg_rating>0 ? ('⭐ '+parseFloat(v.avg_rating).toFixed(1)+(v.review_count>0?' ('+v.review_count+')':'')) : '';
        var price = (v.price_min||v.price_max) ? ('₹'+(v.price_min||0).toLocaleString('en-IN')+(v.price_max?'–₹'+v.price_max.toLocaleString('en-IN'):'+')+'/job') : '';
        var thumb = v.cover_photo
          ? '<img src="'+esc(v.cover_photo)+'" style="width:44px;height:44px;border-radius:8px;object-fit:cover;flex-shrink:0" alt="'+esc(v.title)+'">'
          : '<div style="width:44px;height:44px;border-radius:8px;background:rgba(255,255,255,.15);display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0">🏢</div>';
        html += '<a href="'+vendorUrl+'" style="display:flex;align-items:center;gap:12px;padding:10px;border-radius:10px;text-decoration:none;transition:background .15s;cursor:pointer;margin-bottom:6px" onmouseover="this.style.background=\'rgba(255,255,255,.1)\'" onmouseout="this.style.background=\'\'">'
          +thumb
          +'<div style="flex:1;min-width:0"><div style="font-weight:700;color:#fff;font-size:.88rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'+esc(v.title)+'</div>'
          +'<div style="font-size:.74rem;color:rgba(255,255,255,.65);margin-top:2px">'+esc(v.city||'')+(v.city&&stars?' · ':'')+stars+(price?' · '+price:'')+'</div></div>'
          +'<div style="font-size:.72rem;color:#93C5FD;flex-shrink:0">View →</div>'
          +'</a>';
      });
      if(data.total>5) html += '<a href="/directory/?keyword='+encodeURIComponent(query)+'" style="display:block;text-align:center;color:#93C5FD;font-size:.8rem;font-weight:600;padding:8px;text-decoration:none">See all '+(data.total)+' results →</a>';
      html += '</div>';
      if(out) out.innerHTML = html;
    })
    .catch(function(){
      if(btn){btn.disabled=false;btn.textContent='Search';}
      if(out)out.innerHTML='<div style="padding:12px;color:#FCA5A5;font-size:.84rem">Network error. Please try again.</div>';
    });
};
})();
</script>

<script>
/* Real fix for confirmed CDN/HTML caching of this page: settings baked
   directly into the page's own inline <style> block get cached along with
   the rest of the HTML, meaning admin changes could never reach a visitor
   until that cache happened to expire — this is exactly why saved layout
   changes appeared to have no effect. This fetches the CURRENT settings via
   a separate AJAX call (never part of the cached page response) on every
   load, and injects an override <style> tag appended last in <head>, which
   wins the CSS cascade over anything baked into stale cached HTML. */
(function(){
  function esc(s){ return String(s==null?'':s); }

  function buildDeviceCSS(cfg, prefix){
    var g = prefix + '.ll-grid', c = prefix + '.ll-card';
    var css = '';
    if (cfg.layout === 'vertical-list') {
      css += g+'{display:flex;flex-direction:column;gap:'+cfg.gap+'px}';
      css += c+'{flex-direction:row}';
      if (cfg.card_height === 'fixed') css += c+'{height:'+cfg.card_height_px+'px}';
    } else if (cfg.layout === 'horizontal-scroll' || cfg.layout === 'carousel') {
      var w = cfg.card_min_width;
      css += g+'{display:flex;flex-direction:row;gap:'+cfg.gap+'px;overflow-x:auto;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;padding-bottom:4px;scroll-behavior:smooth}';
      css += g+' > .ll-card{flex:0 0 '+w+'px;width:'+w+'px;scroll-snap-align:start;flex-direction:column}';
      // Real bug fix, identical to the PHP-side fix: aspect-ratio was
      // previously applied to the whole card, not scoped to .ll-img,
      // crushing all body content into a height too small to show anything
      // past the very first element — this is the client-side version that
      // actually runs in the browser, so this is the fix that matters.
      css += c+' .ll-img{width:100%;min-width:0;aspect-ratio:'+cfg.aspect_ratio+'}';
      if (cfg.card_height === 'fixed') {
        css += g+' > .ll-card{height:'+cfg.card_height_px+'px}';
        css += c+' .ll-img{aspect-ratio:unset;height:45%}';
      }
    } else {
      css += g+'{display:grid;grid-template-columns:repeat('+cfg.columns+',1fr);gap:'+cfg.gap+'px}';
      css += c+'{flex-direction:column}';
      css += c+' .ll-img{width:100%;min-width:0;aspect-ratio:'+cfg.aspect_ratio+'}';
      if (cfg.card_height === 'fixed') css += c+'{height:'+cfg.card_height_px+'px}';
    }
    if (!cfg.show_title)    css += c+' .ll-title{display:none}';
    if (!cfg.show_rating)   css += c+' .ll-rat{display:none}';
    if (!cfg.show_location) css += c+' .ll-city{display:none}';
    if (!cfg.show_badges)   css += c+' .ll-badges{display:none}';
    if (!cfg.show_buttons)  css += c+' .ll-actions{display:none}';
    var sectionSel = prefix || '#gsLLGrid';
    if (cfg.section_width === 'full') {
      css += sectionSel+'{max-width:100vw;margin-left:calc(50% - 50vw);margin-right:calc(50% - 50vw);padding-left:16px;padding-right:16px;box-sizing:border-box}';
    }
    if (cfg.section_align === 'center' && cfg.layout !== 'grid') {
      css += sectionSel+'{justify-content:center}';
    }
    return css;
  }

  function applyLayout(layout){
    if (!layout || !layout.desktop) return;
    var css = buildDeviceCSS(layout.desktop, '');
    css += '@media(max-width:900px){' + buildDeviceCSS(layout.tablet, '') + '}';
    css += '@media(max-width:540px){' + buildDeviceCSS(layout.mobile, '') + '}';
    var tag = document.getElementById('gs-ll-dynamic-override');
    if (!tag) {
      tag = document.createElement('style');
      tag.id = 'gs-ll-dynamic-override';
      document.head.appendChild(tag); // appended last — wins cascade over cached inline styles
    }
    tag.textContent = css;

    // Carousel-specific behavior: nav arrows + optional auto-advance, layered
    // on top of the shared scroll-snap CSS so content works even if this
    // never runs (e.g. JS blocked) — falls back to plain touch/manual scroll.
    var grid = document.getElementById('gsLLGrid');
    if (grid && layout.desktop.layout === 'carousel') {
      initCarouselNav(grid);
    }
  }

  function initCarouselNav(grid){
    if (document.getElementById('gsLLCarouselNav')) return; // already initialized
    var wrap = grid.parentElement;
    if (!wrap || getComputedStyle(wrap).position === 'static') { wrap.style.position = 'relative'; }
    var nav = document.createElement('div');
    nav.id = 'gsLLCarouselNav';
    nav.innerHTML =
      '<button type="button" aria-label="Previous" style="position:absolute;left:4px;top:50%;transform:translateY(-50%);width:36px;height:36px;border-radius:50%;border:1px solid #E2E8F0;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.1);cursor:pointer;z-index:5;font-size:1rem">←</button>' +
      '<button type="button" aria-label="Next" style="position:absolute;right:4px;top:50%;transform:translateY(-50%);width:36px;height:36px;border-radius:50%;border:1px solid #E2E8F0;background:#fff;box-shadow:0 2px 8px rgba(0,0,0,.1);cursor:pointer;z-index:5;font-size:1rem">→</button>';
    wrap.appendChild(nav);
    var btns = nav.querySelectorAll('button');
    btns[0].addEventListener('click', function(){ grid.scrollBy({ left: -grid.clientWidth * 0.8, behavior: 'smooth' }); });
    btns[1].addEventListener('click', function(){ grid.scrollBy({ left: grid.clientWidth * 0.8, behavior: 'smooth' }); });
  }

  if (window.GS && GS.ajax_url) {
    var params = new URLSearchParams({ action: 'gs_get_latest_listings_layout', nonce: GS.nonce });
    fetch(GS.ajax_url, { method: 'POST', body: params, credentials: 'same-origin' })
      .then(function(r){ return r.json(); })
      .then(function(r){ if (r && r.success && r.data) applyLayout(r.data.layout); })
      .catch(function(){ /* fetch failed — page still works correctly using server-rendered defaults */ });
  }
})();
</script>

<!-- ══════════════════════════════════════════════════════════════════
     HOME PAGE LAUNCH-OFFER POPUP — real feature, explicitly requested.
     Shows once per visitor per 24 hours, home page only (this markup
     lives only in home.php, which only ever renders for the home page —
     no other template includes this block, so it can never appear
     anywhere else). Closable, and self-contained: its own class prefix,
     own <style>/<script>, appended after all existing home page content
     so it cannot affect layout, and gated entirely by localStorage so no
     server-side state or new DB table is needed for this.
     Both the on/off switch and the image are admin-editable from
     Admin Dashboard → Settings → "Homepage Popup" (no code change
     needed) — see promo_popup_enabled / promo_popup_image, read via
     gs_setting() below with the shipped defaults as fallback so
     nothing changes for the user until they actively edit them.
     ══════════════════════════════════════════════════════════════════ -->
<?php if ( gs_setting( 'promo_popup_enabled', '1' ) === '1' ):
  $gs_promo_popup_image = gs_setting( 'promo_popup_image', '' );
  if ( trim( (string) $gs_promo_popup_image ) === '' ) {
      $gs_promo_popup_image = GS_URL . 'assets/images/promo-launch-popup.jpg';
  }
  // Frequency — admin-editable: "24h" (default, unchanged behavior) or
  // "always" (show on every single home page load, no cooldown at all).
  $gs_promo_popup_frequency = gs_setting( 'promo_popup_frequency', '24h' ) === 'always' ? 'always' : '24h';
?>
<style>
.gs-promo-pop-overlay{display:none;position:fixed;inset:0;background:rgba(15,23,42,.7);backdrop-filter:blur(3px);z-index:999997;align-items:center;justify-content:center;padding:16px}
.gs-promo-pop-overlay.open{display:flex}
.gs-promo-pop-box{position:relative;max-width:900px;width:100%;max-height:92vh;overflow:auto;border-radius:14px;box-shadow:0 30px 80px rgba(0,0,0,.4);animation:gsPromoPopIn .25s ease}
.gs-promo-pop-box img{display:block;width:100%;height:auto;border-radius:14px}
.gs-promo-pop-close{position:absolute;top:10px;right:10px;width:36px;height:36px;border-radius:50%;border:none;background:rgba(255,255,255,.95);color:#0F172A;font-size:1.1rem;font-weight:700;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 2px 10px rgba(0,0,0,.25);z-index:1}
.gs-promo-pop-close:hover{background:#fff}
@keyframes gsPromoPopIn{from{opacity:0;transform:scale(.96)}to{opacity:1;transform:scale(1)}}
</style>
<div class="gs-promo-pop-overlay" id="gsPromoPopOverlay" role="dialog" aria-modal="true" aria-label="Special launch offer">
  <div class="gs-promo-pop-box">
    <button type="button" class="gs-promo-pop-close" id="gsPromoPopClose" aria-label="Close">&#10005;</button>
    <img src="<?php echo esc_url( $gs_promo_popup_image ); ?>" alt="GoodService.co.in special launch offer — list your business for ₹499, get more visibility on Google and more local customers. Call 7303056551.">
  </div>
</div>
<script>
(function(){
  var STORAGE_KEY = 'gs_promo_launch_popup_last_shown';
  var GAP_MS = 24 * 60 * 60 * 1000; // 24 hours — real feature: once per visitor per 24h
  // Admin-editable via Settings → Homepage Popup → "Promo Popup Frequency".
  var FREQUENCY = <?php echo wp_json_encode( $gs_promo_popup_frequency ); ?>;

  function shouldShow() {
    if (FREQUENCY === 'always') return true;
    try {
      var last = window.localStorage.getItem(STORAGE_KEY);
      if (!last) return true;
      return (Date.now() - parseInt(last, 10)) > GAP_MS;
    } catch (e) {
      // Storage blocked/unavailable (private mode, disabled site data, etc.) —
      // fail open rather than silently never showing the popup at all.
      return true;
    }
  }
  function markShown() {
    if (FREQUENCY === 'always') return; // nothing to remember — it shows every time regardless
    try { window.localStorage.setItem(STORAGE_KEY, String(Date.now())); } catch (e) { /* best-effort only */ }
  }
  function closePopup() {
    var overlay = document.getElementById('gsPromoPopOverlay');
    if (overlay) overlay.classList.remove('open');
    document.removeEventListener('keydown', onEsc);
  }
  function onEsc(e) { if (e.key === 'Escape') closePopup(); }

  if (!shouldShow()) return;

  var overlay = document.getElementById('gsPromoPopOverlay');
  if (!overlay) return;
  overlay.classList.add('open');
  markShown();

  var closeBtn = document.getElementById('gsPromoPopClose');
  if (closeBtn) closeBtn.addEventListener('click', closePopup);
  overlay.addEventListener('click', function(e){ if (e.target === overlay) closePopup(); });
  document.addEventListener('keydown', onEsc);
})();
</script>
<?php endif; // promo_popup_enabled ?>
