/**
 * Business OS Desktop — Electron Main Process
 *
 * Lifecycle:
 *   1. Find free ports for PHP server and MariaDB
 *   2. Start MariaDB (mysqld) — wait for it to accept connections
 *   3. Start PHP built-in server pointing at server/public/
 *   4. Open BrowserWindow at http://127.0.0.1:{phpPort}/business/
 *   5. On quit: kill PHP → kill MariaDB → exit
 *
 * All child processes are tracked and killed cleanly.
 * If MariaDB or PHP fail to start, a human-readable error dialog is shown.
 */

const { app, BrowserWindow, dialog, shell, Menu, Tray, nativeImage } = require('electron');
const path   = require('path');
const fs     = require('fs');
const net    = require('net');
const { spawn, execSync } = require('child_process');

// ── Paths ─────────────────────────────────────────────────────────────────
const IS_DEV      = !app.isPackaged;
const APP_DIR     = IS_DEV ? path.join(__dirname, '..') : path.join(process.resourcesPath, 'app');
const PHP_DIR     = IS_DEV
  ? path.join(__dirname, '..', 'php')                      // dev: download manually
  : path.join(process.resourcesPath, 'php');               // prod: bundled by installer
const MARIADB_DIR = IS_DEV
  ? path.join(__dirname, '..', 'mariadb')
  : path.join(process.resourcesPath, 'mariadb');
const DATA_DIR    = path.join(app.getPath('userData'), 'BusinessOS');
const DB_DATA_DIR = path.join(DATA_DIR, 'mysql');
const LOG_DIR     = path.join(DATA_DIR, 'logs');
const DB_CFG_FILE = path.join(DATA_DIR, 'db.json');

[DATA_DIR, DB_DATA_DIR, LOG_DIR].forEach(d => { if (!fs.existsSync(d)) fs.mkdirSync(d, { recursive: true }); });

// ── Process handles ───────────────────────────────────────────────────────
let phpProcess    = null;
let mariaProcess  = null;
let mainWindow    = null;
let tray          = null;
let phpPort       = 9753;
let dbPort        = 3307;
let appReady      = false;

// ── Find a free TCP port ──────────────────────────────────────────────────
function findFreePort(preferred) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(preferred, '127.0.0.1', () => {
      const port = server.address().port;
      server.close(() => resolve(port));
    });
    server.on('error', () => {
      const s2 = net.createServer();
      s2.listen(0, '127.0.0.1', () => {
        const port = s2.address().port;
        s2.close(() => resolve(port));
      });
    });
  });
}

// ── Wait until a TCP port accepts connections ─────────────────────────────
function waitForPort(port, timeout = 30000) {
  return new Promise((resolve, reject) => {
    const start = Date.now();
    function attempt() {
      const sock = new net.Socket();
      sock.setTimeout(1000);
      sock.connect(port, '127.0.0.1', () => {
        sock.destroy();
        resolve();
      });
      sock.on('error', () => {
        sock.destroy();
        if (Date.now() - start > timeout) {
          reject(new Error(`Port ${port} did not open within ${timeout}ms`));
        } else {
          setTimeout(attempt, 500);
        }
      });
      sock.on('timeout', () => {
        sock.destroy();
        setTimeout(attempt, 500);
      });
    }
    attempt();
  });
}

// ── Write MariaDB config ───────────────────────────────────────────────────
function writeMariaConfig(port) {
  const myIni = `
[mysqld]
port=${port}
datadir="${DB_DATA_DIR.replace(/\\/g, '/')}"
socket=mysql.sock
character-set-server=utf8mb4
collation-server=utf8mb4_unicode_ci
skip-networking=0
bind-address=127.0.0.1
max_allowed_packet=64M
innodb_buffer_pool_size=128M
log_error="${path.join(LOG_DIR, 'mariadb.err').replace(/\\/g, '/')}"
slow_query_log=0
general_log=0
[client]
port=${port}
character-set-server=utf8mb4
`;
  fs.writeFileSync(path.join(DATA_DIR, 'my.ini'), myIni);
}

// ── Write DB connection config for PHP ─────────────────────────────────────
function writeDbConfig(port) {
  const pass = readOrGenerateDbPassword();
  fs.writeFileSync(DB_CFG_FILE, JSON.stringify({
    host: '127.0.0.1',
    port: String(port),
    name: 'businessos',
    user: 'bosuser',
    pass: pass,
  }, null, 2));
  return pass;
}

function readOrGenerateDbPassword() {
  if (fs.existsSync(DB_CFG_FILE)) {
    try {
      const cfg = JSON.parse(fs.readFileSync(DB_CFG_FILE, 'utf8'));
      if (cfg.pass && cfg.pass.length > 8) return cfg.pass;
    } catch {}
  }
  return 'bos_' + require('crypto').randomBytes(16).toString('hex');
}

// ── Initialize MariaDB data directory (first run only) ─────────────────────
function initMariaDbIfNeeded(dbPass) {
  const mysqlFolder = path.join(DB_DATA_DIR, 'mysql');
  if (fs.existsSync(mysqlFolder)) return; // Already initialized

  const mysqld = path.join(MARIADB_DIR, 'bin', 'mysqld.exe');
  if (!fs.existsSync(mysqld)) throw new Error('MariaDB not found at: ' + mysqld);

  // mysql_install_db equivalent on Windows: --initialize-insecure
  execSync(`"${mysqld}" --initialize-insecure --datadir="${DB_DATA_DIR}" --basedir="${MARIADB_DIR}"`, {
    timeout: 60000,
    stdio: 'pipe',
  });
  // Start temporarily to create DB and user
  const tempProc = spawn(mysqld, [
    `--defaults-file=${path.join(DATA_DIR, 'my.ini')}`,
    `--basedir=${MARIADB_DIR}`,
  ], { stdio: 'ignore', detached: false });

  // Wait a few seconds for it to start, then create DB
  execSync('ping -n 5 127.0.0.1 > nul', { shell: true }); // Windows sleep 5s

  try {
    const mysql = path.join(MARIADB_DIR, 'bin', 'mysql.exe');
    const sql = [
      `CREATE DATABASE IF NOT EXISTS businessos CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;`,
      `CREATE USER IF NOT EXISTS 'bosuser'@'127.0.0.1' IDENTIFIED BY '${dbPass}';`,
      `GRANT ALL PRIVILEGES ON businessos.* TO 'bosuser'@'127.0.0.1';`,
      `FLUSH PRIVILEGES;`,
    ].join('\n');
    execSync(`"${mysql}" -u root --execute="${sql.replace(/"/g, '\\"')}"`, { timeout: 15000, stdio: 'pipe' });
  } catch (e) {
    // DB may already exist; log and continue
    fs.appendFileSync(path.join(LOG_DIR, 'init.log'), e.message + '\n');
  }

  tempProc.kill();
}

// ── Start MariaDB ──────────────────────────────────────────────────────────
async function startMariaDB(port) {
  const mysqld = path.join(MARIADB_DIR, 'bin', 'mysqld.exe');
  if (!fs.existsSync(mysqld)) {
    showFatalError('MariaDB not found', `Expected: ${mysqld}\n\nPlease reinstall Business OS.`);
    return false;
  }

  writeMariaConfig(port);
  const dbPass = writeDbConfig(port);

  try {
    initMariaDbIfNeeded(dbPass);
  } catch (e) {
    fs.appendFileSync(path.join(LOG_DIR, 'init.log'), 'Init error: ' + e.message + '\n');
  }

  mariaProcess = spawn(mysqld, [
    `--defaults-file=${path.join(DATA_DIR, 'my.ini')}`,
    `--basedir=${MARIADB_DIR}`,
    `--datadir=${DB_DATA_DIR}`,
  ], {
    stdio: ['ignore', 'pipe', 'pipe'],
    detached: false,
  });

  mariaProcess.stderr.on('data', (d) => {
    fs.appendFileSync(path.join(LOG_DIR, 'mariadb.log'), d.toString());
  });

  try {
    await waitForPort(port, 45000);
    return true;
  } catch (e) {
    showFatalError('Database failed to start', `MariaDB did not respond within 45 seconds.\n\nCheck: ${path.join(LOG_DIR, 'mariadb.log')}`);
    return false;
  }
}

// ── Start PHP server ───────────────────────────────────────────────────────
async function startPhpServer(port) {
  const php = path.join(PHP_DIR, 'php.exe');
  if (!fs.existsSync(php)) {
    showFatalError('PHP not found', `Expected: ${php}\n\nPlease reinstall Business OS.`);
    return false;
  }

  const serverRoot = path.join(APP_DIR, 'server', 'public');
  const appDir     = path.join(APP_DIR, 'app');

  phpProcess = spawn(php, [
    '-S', `127.0.0.1:${port}`,
    '-t', serverRoot,
    path.join(serverRoot, 'index.php'),
  ], {
    env: {
      ...process.env,
      BOS_PORT:     String(port),
      BOS_DATA_DIR: DATA_DIR,
      BOS_DB_PORT:  String(dbPort),
      BOS_DB_PASS:  JSON.parse(fs.readFileSync(DB_CFG_FILE, 'utf8')).pass,
      BOS_APP_DIR:  appDir,
    },
    stdio: ['ignore', 'pipe', 'pipe'],
    detached: false,
  });

  phpProcess.stderr.on('data', (d) => {
    const msg = d.toString();
    // PHP built-in server logs requests to stderr — only log actual errors
    if (msg.includes('Fatal') || msg.includes('Parse error')) {
      fs.appendFileSync(path.join(LOG_DIR, 'php.log'), msg);
    }
  });

  phpProcess.on('exit', (code) => {
    fs.appendFileSync(path.join(LOG_DIR, 'php.log'), `PHP exited with code ${code}\n`);
  });

  try {
    await waitForPort(port, 15000);
    return true;
  } catch (e) {
    showFatalError('Server failed to start', `PHP did not respond within 15 seconds.\n\nCheck: ${path.join(LOG_DIR, 'php.log')}`);
    return false;
  }
}

// ── Create the main window ─────────────────────────────────────────────────
function createWindow() {
  mainWindow = new BrowserWindow({
    width:  1280,
    height: 800,
    minWidth:  900,
    minHeight: 600,
    title: 'Business OS',
    icon:  path.join(APP_DIR, 'app', 'favicon.ico'),
    webPreferences: {
      preload:           path.join(__dirname, 'preload.js'),
      contextIsolation:  true,
      nodeIntegration:   false,
      webSecurity:       true,
    },
    show: false,
    backgroundColor: '#0f172a',
  });

  mainWindow.loadURL(`http://127.0.0.1:${phpPort}/business/`);

  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    appReady = true;
  });

  // Open external links in OS browser
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http://127.0.0.1')) return { action: 'allow' };
    shell.openExternal(url);
    return { action: 'deny' };
  });

  mainWindow.on('closed', () => { mainWindow = null; });

  // Simple menu
  const menu = Menu.buildFromTemplate([
    {
      label: 'Business OS',
      submenu: [
        { label: 'Open Data Folder', click: () => shell.openPath(DATA_DIR) },
        { label: 'Open Log Folder',  click: () => shell.openPath(LOG_DIR) },
        { type: 'separator' },
        { label: 'Reload', accelerator: 'CmdOrCtrl+R', click: () => mainWindow?.reload() },
        { type: 'separator' },
        { label: 'Quit', accelerator: 'CmdOrCtrl+Q', role: 'quit' },
      ],
    },
    {
      label: 'View',
      submenu: [
        { label: 'Zoom In',  accelerator: 'CmdOrCtrl+Plus',  role: 'zoomIn' },
        { label: 'Zoom Out', accelerator: 'CmdOrCtrl+-',     role: 'zoomOut' },
        { label: 'Reset Zoom', accelerator: 'CmdOrCtrl+0',  role: 'resetZoom' },
        { type: 'separator' },
        ...(IS_DEV ? [{ label: 'DevTools', accelerator: 'F12', role: 'toggleDevTools' }] : []),
      ],
    },
  ]);
  Menu.setApplicationMenu(menu);
}

// ── Fatal error dialog ─────────────────────────────────────────────────────
function showFatalError(title, detail) {
  dialog.showErrorBox(`Business OS — ${title}`, detail);
}

// ── Cleanup all child processes ────────────────────────────────────────────
function cleanup() {
  if (phpProcess) {
    try { phpProcess.kill('SIGTERM'); } catch {}
    phpProcess = null;
  }
  if (mariaProcess) {
    // Give MariaDB a graceful shutdown
    try {
      const mysql = path.join(MARIADB_DIR, 'bin', 'mysqladmin.exe');
      if (fs.existsSync(mysql) && fs.existsSync(DB_CFG_FILE)) {
        const cfg = JSON.parse(fs.readFileSync(DB_CFG_FILE, 'utf8'));
        execSync(`"${mysql}" -u bosuser -p${cfg.pass} -P${dbPort} -h127.0.0.1 shutdown`, { timeout: 5000, stdio: 'ignore' });
      }
    } catch {}
    try { mariaProcess.kill('SIGTERM'); } catch {}
    mariaProcess = null;
  }
}

// ── Electron app lifecycle ─────────────────────────────────────────────────
app.on('ready', async () => {
  // Prevent second instance
  if (!app.requestSingleInstanceLock()) {
    app.quit();
    return;
  }

  // Find available ports
  phpPort = await findFreePort(9753);
  dbPort  = await findFreePort(3307);

  // Show splash-like loading window while starting services
  const splash = new BrowserWindow({
    width: 400, height: 220, frame: false, center: true,
    resizable: false, alwaysOnTop: true, backgroundColor: '#0f172a',
    webPreferences: { contextIsolation: true, nodeIntegration: false },
  });
  splash.loadURL('data:text/html,<body style="margin:0;background:#0f172a;display:flex;align-items:center;justify-content:center;height:100vh;flex-direction:column;font-family:sans-serif;color:#fff"><div style="font-size:22px;font-weight:700;margin-bottom:12px">Business OS</div><div style="color:#94a3b8;font-size:13px">Starting services…</div></body>');

  const dbOk  = await startMariaDB(dbPort);
  if (!dbOk) { splash.close(); app.quit(); return; }

  const phpOk = await startPhpServer(phpPort);
  if (!phpOk) { splash.close(); app.quit(); return; }

  splash.close();
  createWindow();
});

app.on('second-instance', () => {
  if (mainWindow) { if (mainWindow.isMinimized()) mainWindow.restore(); mainWindow.focus(); }
});

app.on('window-all-closed', () => {
  cleanup();
  app.quit();
});

app.on('before-quit', cleanup);

process.on('exit', cleanup);
process.on('SIGINT', () => { cleanup(); process.exit(0); });
process.on('SIGTERM', () => { cleanup(); process.exit(0); });
