<?php
/**
 * Runs when the plugin is DELETED from the Plugins screen (not on deactivate).
 *
 * - NSH requests, users and roles are never touched: they are customer records.
 * - Blog data (own tables + own uploads folder + blog options) is removed ONLY if the admin ticked
 *   "Delete all blog data when the plugin is deleted" in Blog → Settings.
 * - WordPress posts, pages and the posts table are never read or written here.
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }

// TRACE: plugin delete → WP_UNINSTALL_PLUGIN set → read blog settings → flag off: stop; flag on: drop 8 blog tables, delete options, cron, own uploads folder → blog data gone, wp_posts unchanged
$settings = get_option( 'nsh_blog_settings', array() );
if ( empty( $settings['delete_on_uninstall'] ) ) { return; }

global $wpdb;
foreach ( array( 'posts', 'terms', 'post_terms', 'media', 'revisions', 'authors', 'access', 'audit' ) as $t ) {
    $wpdb->query( 'DROP TABLE IF EXISTS `' . esc_sql( $wpdb->prefix . 'nsh_blog_' . $t ) . '`' );
}
foreach ( array( 'nsh_blog_settings', 'nsh_blog_db_version', 'nsh_blog_retired_notice' ) as $o ) { delete_option( $o ); }
wp_clear_scheduled_hook( 'nsh_blog_publish_due' );

$up  = wp_upload_dir( null, false );
$dir = trailingslashit( $up['basedir'] ) . 'nsh-blog';
if ( is_dir( $dir ) && strpos( realpath( $dir ), realpath( $up['basedir'] ) ) === 0 ) {
    $it = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $dir, FilesystemIterator::SKIP_DOTS ), RecursiveIteratorIterator::CHILD_FIRST );
    foreach ( $it as $f ) { $f->isDir() ? @rmdir( $f->getPathname() ) : @unlink( $f->getPathname() ); }
    @rmdir( $dir );
}
