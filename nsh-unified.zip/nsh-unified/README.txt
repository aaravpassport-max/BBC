=== NRI Services Hub — Unified (Services + Blog CMS + Standalone Dashboards) ===
Version 2.0.0 · Requires WordPress 6.0+, PHP 7.4+

WordPress is only the vehicle: it hosts the plugin and signs people in. Every screen — sign-in, the three
dashboards, the blog CMS and the public blog — is rendered by this plugin, independent of your theme.

INSTALL
1. Plugins → Add New → Upload → nri-services-hub-unified.zip → Activate.
   (If the old "Staff Blog Manager" plugin is active, deactivate it: this plugin replaces it. An admin notice reminds you.)
2. Settings → permalinks are flushed automatically on activation. If a URL ever 404s, open Settings → Permalinks and press Save.
3. Existing NSH requests, users and roles are kept as they are. Nothing is imported.

ONE LOGIN, ONE SESSION
  {site}/login/ is the only sign-in page (password or magic link). After sign-in people land on their own dashboard:
  administrator / NSH admin → Admin dashboard · NSH manager, Staff Blog / Moderator roles → Staff dashboard · NSH client → Client dashboard.
  Sign out from any dashboard ends the single WordPress session everywhere. wp-admin can be blocked for non-admins (setting below).

DASHBOARD URLS (configurable)
  Admin dashboard → Settings → "Dashboards & Access": sign-in, client, admin, staff and blog URL names, which roles are
  admin or staff, which tabs staff see, wp-admin blocking, admin-bar hiding. Reserved or duplicate names are rejected with a message;
  rewrite rules are flushed on save. Old nsh-* addresses redirect (301) to the new ones.
  Defaults: /login/  /client-dashboard/  /staff-dashboard/  /admin-dashboard/  (blog CMS at /{admin|staff}-dashboard/blog/).

THE BLOG (fully self-contained)
  The blog never reads, lists, imports or changes WordPress posts, pages, categories or media. It has its own tables
  ({prefix}nsh_blog_posts, _terms, _post_terms, _media, _revisions, _authors, _access, _audit) and its own uploads folder (uploads/nsh-blog).
  Public URLs (base configurable, default "insights"):  /insights/  /insights/{slug}/  /insights/category/{slug}/  /insights/tag/{slug}/
  /insights/author/{slug}/  /insights/sitemap.xml
  CMS: Admin or Staff dashboard → Blog → New article opens the QUICK FORM: labelled boxes (title, summary, category, image, intro, main text,
  steps, info cards, checklist, FAQs, links, testimonials, form service). Fill what you need and press Save as draft / Publish now / Submit for review
  (staff without publish rights submit for review). The full design, both request forms and the contents list are added automatically.
  "Use advanced editor" opens the block editor. Title, slug, intro, content blocks (12 types), featured/inline images with alt text and captions,
  categories, tags, author, status (draft / pending / scheduled / published / unpublished / trash), SEO + social metadata, preview, revisions.
  Two request forms: both placements use [nsh_standalone_form] through the normal NSH pipeline (hero and sidebar); each can be moved/hidden per article.
  Inline editing: signed-in users with edit permission see "Edit this page" on the real article; text, lists, sections and images are edited in place,
  then Save (working copy) / Preview / Publish. Visitors never receive any editor code.
  Permissions: administrators and the Moderator role have everything; Staff need an enabled access row (Blog → Team) with any of
  create, edit, edit all, publish, delete, media, SEO, taxonomy.

CREATING ACCOUNTS
  Users → Add New. Roles: nsh_client, nsh_manager, nsh_admin, sbm_staff (blog staff), sbm_moderator (blog moderator).
  Give blog staff access under Blog → Team.

UNINSTALL
  Deactivating keeps everything. Deleting the plugin keeps NSH data. Blog data is removed only if "Delete all blog data when the plugin is
  deleted" is ticked in Blog → Settings. WordPress posts and pages are never touched.

REQUEST FORM SHORTCODE
  [nsh_standalone_form] can still be placed in any page; the blog uses it twice per article with unique IDs and isolated state.

CLASSIC TEMPLATE AND EXTRA SECTIONS
-----------------------------------
New articles use the "Classic" page design (header, banner with three info boxes and counters,
search band, contents menu | article | request form, FAQ, popular list, reviews, latest articles,
footer). Site header/footer text (logo, phone, social links, footer columns, locations, copyright)
is edited under Blog > Settings > "Site header and footer".
In Blog > New article the form has a "Top of the page" part (banner heading, keywords, info boxes,
counters) and, at the bottom, "9. Add more sections": pick any section type (text, steps, cards,
checklist, image, callout, quote, FAQ, popular links, popular list in columns, testimonials,
banner, request form), add it, move it up/down or remove it. Each in-article section has an optional
"Short menu label" shown in the "On this page" menu.
