(function () {
  'use strict';
  // TRACE: DOM ready → mobile menu button + TOC scroll-spy; no globals leaked; each part is guarded so a missing element is a no-op
  function ready(fn) { if (document.readyState !== 'loading') { fn(); } else { document.addEventListener('DOMContentLoaded', fn); } }
  ready(function () {
    var burger = document.querySelector('.nb-burger'), nav = document.getElementById('nb-nav');
    if (burger && nav) {
      burger.addEventListener('click', function () {
        var open = nav.classList.toggle('is-open');
        burger.setAttribute('aria-expanded', open ? 'true' : 'false');
      });
    }
    var links = [].slice.call(document.querySelectorAll('.nb-toc a[href^="#"], .nbc-toc a[href^="#"]'));
    if (links.length && 'IntersectionObserver' in window) {
      var map = {};
      links.forEach(function (a) { var t = document.getElementById(a.getAttribute('href').slice(1)); if (t) { map[t.id] = a; } });
      var io = new IntersectionObserver(function (es) {
        es.forEach(function (e) {
          if (e.isIntersecting && map[e.target.id]) { links.forEach(function (l) { l.classList.remove('is-active'); }); map[e.target.id].classList.add('is-active'); }
        });
      }, { rootMargin: '-20% 0px -70% 0px' });
      Object.keys(map).forEach(function (id) { io.observe(document.getElementById(id)); });
    }
    // TRACE: reviews carousel → .nb-tgrid with cards → one dot per card; scrolling highlights the first visible card, a dot click scrolls that card into view; no-op without JS or cards
    [].forEach.call(document.querySelectorAll('.nb-tgrid'), function (g) {
      var cards = [].slice.call(g.children), dots = g.parentNode.querySelector('.nb-dots');
      if (!dots || cards.length < 2) { return; }
      cards.forEach(function (c, i) { var d = document.createElement('i'); d.addEventListener('click', function () { g.scrollTo({ left: c.offsetLeft - g.offsetLeft, behavior: 'smooth' }); }); dots.appendChild(d); });
      dots.removeAttribute('aria-hidden');
      var on = function () { var x = g.scrollLeft, k = 0; cards.forEach(function (c, i) { if (c.offsetLeft - g.offsetLeft <= x + 8) { k = i; } }); [].forEach.call(dots.children, function (d, i) { d.classList.toggle('is-on', i === k); }); };
      g.addEventListener('scroll', on, { passive: true }); on();
    });
  });
})();
