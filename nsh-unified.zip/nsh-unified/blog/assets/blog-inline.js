/* Inline editor — loaded ONLY for signed-in accounts allowed to edit this article (see Inline::assets). Edits the real front-end layout in place. */
(function () {
  'use strict';
  var C = window.NSHINLINE;
  if (!C) { return; }
  var main = document.getElementById('nsh-main');
  if (!main) { return; }

  function h(tag, a, kids) {
    var e = document.createElement(tag); a = a || {};
    Object.keys(a).forEach(function (k) {
      var v = a[k]; if (v === null || v === undefined || v === false) { return; }
      if (k === 'class') { e.className = v; } else if (k === 'text') { e.textContent = v; }
      else if (k.indexOf('on') === 0 && typeof v === 'function') { e.addEventListener(k.slice(2), v); }
      else if (k === 'value') { e.value = v; } else if (k === 'checked') { e.checked = !!v; } else { e.setAttribute(k, v === true ? '' : v); }
    });
    (kids || []).forEach(function (c) { if (c !== null && c !== undefined && c !== false) { e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); } });
    return e;
  }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function uid() { return 'b' + Math.random().toString(36).slice(2, 10); }
  var S = { on: false, P: null, cat: null, services: [], icons: [], dirty: false, busy: false, bar: null, orig: null };

  // TRACE: server call → op, data → Promise of data; rejects with {message, code, data}; network/JSON failure → readable message
  function api(op, data, file) {
    var fd = new FormData(); fd.append('action', 'nsh_blog'); fd.append('nonce', C.nonce); fd.append('op', op);
    Object.keys(data || {}).forEach(function (k) { var v = data[k]; fd.append(k, typeof v === 'object' && v !== null ? JSON.stringify(v) : v); });
    if (file) { fd.append('file', file); }
    return fetch(C.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) { return r.json().catch(function () { return { success: false, data: { message: 'Unexpected server response.' } }; }); }, function () { return { success: false, data: { message: 'Network problem. Check your connection.' } }; })
      .then(function (j) { if (j && j.success) { return j.data; } var d = (j && j.data) || {}; if (d.code === 'auth' || d.code === 'nonce') { d.message = 'Your session expired. Reload the page and sign in again.'; } throw d; });
  }
  var toasts;
  function toast(msg, err) { if (!toasts) { toasts = h('div', { class: 'nbi-toasts', role: 'status', 'aria-live': 'polite' }); document.body.appendChild(toasts); } var t = h('div', { class: 'nbi-toast' + (err ? ' is-err' : ''), text: msg }); toasts.appendChild(t); setTimeout(function () { if (t.parentNode) { t.parentNode.removeChild(t); } }, err ? 7000 : 3000); }
  function fail(e) { toast((e && e.message) || 'Something went wrong.', true); }

  // TRACE: dialogs → title, body node, buttons → Promise of the chosen value (Esc/backdrop → null); focus trapped and restored
  function modal(title, body, buttons, wide) {
    return new Promise(function (res) {
      var prev = document.activeElement, ov = h('div', { class: 'nbi-ov' }), box = h('div', { class: 'nbi-modal' + (wide ? ' is-wide' : ''), role: 'dialog', 'aria-modal': 'true', 'aria-label': title });
      function done(v) { document.removeEventListener('keydown', key, true); if (ov.parentNode) { ov.parentNode.removeChild(ov); } if (prev && prev.focus) { prev.focus(); } res(v); }
      function key(e) { if (e.key === 'Escape') { e.stopPropagation(); done(null); } if (e.key === 'Tab') { var f = box.querySelectorAll('button,input,select,textarea'); if (!f.length) { return; } var a = f[0], z = f[f.length - 1]; if (e.shiftKey && document.activeElement === a) { e.preventDefault(); z.focus(); } else if (!e.shiftKey && document.activeElement === z) { e.preventDefault(); a.focus(); } } }
      box.appendChild(h('h2', { text: title })); var b = h('div', { class: 'nbi-mb' }); if (typeof body === 'string') { b.textContent = body; } else if (body) { b.appendChild(body); } box.appendChild(b);
      var f = h('div', { class: 'nbi-mf' }); buttons.forEach(function (bt) { f.appendChild(h('button', { type: 'button', class: 'nbi-btn ' + (bt.cls || ''), text: bt.label, onclick: function () { done(typeof bt.value === 'function' ? bt.value() : bt.value); } })); });
      box.appendChild(f); ov.appendChild(box); ov.addEventListener('mousedown', function (e) { if (e.target === ov) { done(null); } });
      document.body.appendChild(ov); document.addEventListener('keydown', key, true); (box.querySelector('input,select,textarea') || box.querySelector('.nbi-btn.is-primary') || box.querySelector('button')).focus();
    });
  }
  function ask(title, text, ok, danger) { return modal(title, text, [{ label: 'Cancel', value: false }, { label: ok, value: true, cls: danger ? 'is-danger' : 'is-primary' }]).then(function (v) { return v === true; }); }
  var fid = 0;
  function fld(label, input) { var id = 'nbif' + (++fid); input.id = id; return h('div', { class: 'nbi-f' }, [h('label', { for: id, text: label }), input]); }
  function txt(v, on, type) { return h('input', { type: type || 'text', value: v === null || v === undefined ? '' : v, oninput: function () { on(this.value); } }); }
  function sel(v, opts, on) { var s = h('select', { onchange: function () { on(this.value); } }, opts.map(function (o) { return h('option', { value: o[0], text: o[1] }); })); s.value = String(v === null || v === undefined ? '' : v); return s; }
  function chk(label, v, on) { return h('label', { class: 'nbi-chk' }, [h('input', { type: 'checkbox', checked: !!v, onchange: function () { on(this.checked); } }), h('span', { text: label })]); }

  // ───────── model helpers ─────────
  function setDirty(v) { S.dirty = v; if (S.bar) { var d = S.bar.querySelector('.nbi-dirty'); if (d) { d.hidden = !v; } if (S.P) { barState(); } } }
  // TRACE: dotted path ("items.2.title", "layout.hero.eyebrow") → walks the model (arrays by index) → the parent object and last key, or null when a segment is missing
  function walk(root, path) { var parts = path.split('.'), o = root; for (var i = 0; i < parts.length - 1; i++) { o = o[/^\d+$/.test(parts[i]) ? +parts[i] : parts[i]]; if (o === undefined || o === null) { return null; } } var k = parts[parts.length - 1]; return { o: o, k: /^\d+$/.test(k) ? +k : k }; }
  function blockOf(el) { var s = el.closest('[data-block]'); if (!s) { return null; } var id = s.getAttribute('data-block'); for (var i = 0; i < S.P.blocks.length; i++) { if (S.P.blocks[i].id === id) { return S.P.blocks[i]; } } return null; }
  // TRACE: input on an editable element → writes its text (plain) or HTML (rich) into the model at its data-f path; layout.* paths live on P.layout, others in the owning block's data or P itself
  function commit(el) {
    var path = el.getAttribute('data-f'), rich = el.hasAttribute('data-rich');
    var val = rich ? el.innerHTML : el.textContent.replace(/\s+/g, ' ').trim();
    var root, rel = path;
    if (path.indexOf('layout.') === 0) { root = S.P; }
    else if (['title', 'subtitle', 'intro'].indexOf(path) > -1) { root = S.P; }
    else { var b = blockOf(el); if (!b) { return; } root = b.data; }
    var w = walk(root, rel); if (!w) { return; } w.o[w.k] = val; setDirty(true);
  }
  function listOf(el) { // the array an item element belongs to
    var lst = el.closest('[data-list]');
    if (lst) { var w = walk(S.P, lst.getAttribute('data-list') + '.x'); return w ? w.o : null; }
    var b = blockOf(el); return b ? b.data.items : null;
  }

  // ───────── rendering ─────────
  function payload() { var P = S.P; return { title: P.title, subtitle: P.subtitle, intro: P.intro, blocks: P.blocks.map(function (b) { var c = clone(b); delete c.data._url; return c; }), layout: P.layout, featured_media: P.featured_media }; }
  // TRACE: structural change → sends the unsaved model to the server renderer (no DB write) → swaps the page body with the edit-mode markup, keeps scroll position, re-attaches controls
  function rerender(keepY) {
    var y = window.scrollY;
    return api('inline_render', { id: C.post, data: payload() }).then(function (r) {
      var m = r.model; S.P.title = m.title; S.P.subtitle = m.subtitle; S.P.intro = m.intro; S.P.blocks = m.blocks; S.P.layout = m.layout; S.P.featured_media = m.featured_media;
      mount(r.html); if (keepY !== false) { window.scrollTo(0, y); }
    }).catch(fail);
  }
  function mount(html) {
    main.innerHTML = html; // HTML comes from Render::article (escaped/whitelisted server-side) for the signed-in editor
    attach();
  }

  // ───────── attach controls ─────────
  function attach() {
    [].forEach.call(main.querySelectorAll('[data-f]'), function (el) {
      el.setAttribute('contenteditable', 'true'); el.setAttribute('spellcheck', 'true'); el.setAttribute('role', 'textbox');
      var rich = el.hasAttribute('data-rich');
      el.addEventListener('input', function () { commit(el); });
      el.addEventListener('keydown', function (e) { if (e.key === 'Enter' && !rich) { e.preventDefault(); el.blur(); } });
      el.addEventListener('paste', function (e) { e.preventDefault(); var t = (e.clipboardData || window.clipboardData).getData('text/plain'); document.execCommand('insertText', false, rich ? t : t.replace(/\s+/g, ' ')); });
      el.addEventListener('focus', function () { S.focus = el; syncFmt(); }); el.addEventListener('blur', function () { setTimeout(syncFmt, 50); });
    });
    // links must not navigate while editing
    [].forEach.call(main.querySelectorAll('a'), function (a) { a.addEventListener('click', function (e) { if (S.on && !a.closest('.nbi-ctl')) { e.preventDefault(); } }); a.setAttribute('tabindex', '-1'); });
    // block toolbars + insertion points
    var blocks = [].slice.call(main.querySelectorAll('.nb-block'));
    blocks.forEach(function (sec) {
      var b = blockOf(sec); if (!b) { return; }
      var i = S.P.blocks.indexOf(b);
      var bar = h('div', { class: 'nbi-ctl nbi-tools', contenteditable: 'false' }, [h('span', { class: 'nbi-tl', text: label(b.type) }),
        tb('↑', 'Move section up', function () { move(i, -1); }, i === 0), tb('↓', 'Move section down', function () { move(i, 1); }, i === S.P.blocks.length - 1),
        tb('⧉', 'Duplicate section', function () { var c = clone(b); c.id = uid(); S.P.blocks.splice(i + 1, 0, c); setDirty(true); rerender(); }), tb('⚙', 'Section settings', function () { settings(b); }),
        tb('🗑', 'Delete section', function () { ask('Delete this section?', 'The “' + label(b.type) + '” section will be removed from the article.', 'Delete section', true).then(function (ok) { if (ok) { S.P.blocks.splice(S.P.blocks.indexOf(b), 1); setDirty(true); rerender(); } }); })]);
      sec.classList.add('nbi-has'); sec.insertBefore(bar, sec.firstChild);
      var band = sec.parentNode.classList.contains('nb-band') ? sec.parentNode : null;
      var addb = addBar(i + 1); (band || sec).parentNode.insertBefore(addb, (band || sec).nextSibling);
    });
    var art = main.querySelector('.nb-article'); if (art) { var tags = art.querySelector('.nb-tags'); var addEnd = addBar(S.P.blocks.length, true); art.insertBefore(addEnd, tags || null); }
    // list items: remove + add
    [].forEach.call(main.querySelectorAll('[data-item]'), function (it) {
      var x = h('button', { type: 'button', class: 'nbi-ctl nbi-x', 'aria-label': 'Remove this item', text: '×', contenteditable: 'false', onclick: function (e) { e.preventDefault(); e.stopPropagation(); var arr = listOf(it); if (arr && arr.length > 0) { var idx = +it.getAttribute('data-item'); var min = it.closest('[data-list]') ? 0 : 1; if (arr.length <= min) { toast('At least one item is needed here.', true); return; } arr.splice(idx, 1); setDirty(true); rerender(); } } });
      it.classList.add('nbi-item'); it.appendChild(x);
    });
    var lists = [].slice.call(main.querySelectorAll('[data-list]')).concat([].slice.call(main.querySelectorAll('.nb-steps,.nb-cards,.nb-check,.nb-faq,.nb-linkgrid,.nb-tgrid')));
    lists.forEach(function (ul) {
      var first = ul.querySelector('[data-item]');
      var add = h('button', { type: 'button', class: 'nbi-ctl nbi-addi', contenteditable: 'false', text: '+ Add item', onclick: function () {
        var arr = first ? listOf(first) : null; if (!arr) { var lp = ul.getAttribute('data-list'); if (lp) { var w = walk(S.P, lp + '.x'); arr = w && w.o; } }
        if (!arr) { return; }
        var tpl = arr.length ? clone(arr[arr.length - 1]) : (typeof arr[0] === 'string' ? 'New item' : {});
        if (typeof tpl === 'string') { tpl = 'New item'; } else { Object.keys(tpl).forEach(function (k) { if (typeof tpl[k] === 'string' && k !== 'icon' && k !== 'url') { tpl[k] = 'New ' + k; } }); if (ul.getAttribute('data-list') === 'layout.hero.chips') { tpl = 'New highlight'; } }
        if (ul.getAttribute('data-list') === 'layout.hero.chips') { tpl = 'New highlight'; }
        arr.push(tpl); setDirty(true); rerender(); } });
      ul.parentNode.insertBefore(add, ul.nextSibling);
    });
    // images
    [].forEach.call(main.querySelectorAll('.nb-b-image .nb-fig, .nb-b-image .nb-img-empty'), function (f) {
      var sec = f.closest('.nb-block'), b = blockOf(sec); if (!b) { return; }
      var btn = h('button', { type: 'button', class: 'nbi-ctl nbi-imgb', contenteditable: 'false', text: b.data.media ? 'Replace image' : 'Choose image', onclick: function () { pick().then(function (m) { if (m) { b.data.media = m.id; if (!b.data.alt) { b.data.alt = m.alt || ''; } setDirty(true); rerender(); } }); } });
      f.appendChild(btn);
    });
    var feat = main.querySelector('.nb-featured, [data-featured-empty]');
    if (feat) { feat.style.position = 'relative'; feat.appendChild(h('button', { type: 'button', class: 'nbi-ctl nbi-imgb', contenteditable: 'false', text: S.P.featured_media ? 'Replace featured image' : 'Choose featured image', onclick: function () { pick().then(function (m) { if (m) { S.P.featured_media = m.id; setDirty(true); rerender(); } }); } })); }
    // forms (placeholders in edit mode) → layout settings
    [].forEach.call(main.querySelectorAll('[data-form-slot]'), function (ph) {
      var k = ph.getAttribute('data-form-slot'); ph.appendChild(h('button', { type: 'button', class: 'nbi-ctl nbi-btn is-sm', contenteditable: 'false', text: 'Form settings', onclick: function () { if (k === 'hero' || k === 'aside') { layoutDlg(); } else { var b = blockOf(ph); if (b) { settings(b); } } } }));
    });
    var hc = main.querySelector('.nb-hero-cta'); if (hc) { hc.appendChild(h('button', { type: 'button', class: 'nbi-ctl nbi-btn is-sm', contenteditable: 'false', text: 'Edit buttons', onclick: layoutDlg })); }
  }
  function tb(t, aria, on, dis) { return h('button', { type: 'button', class: 'nbi-tb', 'aria-label': aria, title: aria, text: t, disabled: dis || null, onclick: function (e) { e.preventDefault(); e.stopPropagation(); on(); } }); }
  var NAMES = { text: 'Text', steps: 'Steps', cards: 'Cards', checklist: 'Checklist', image: 'Image', callout: 'Callout', quote: 'Quote', faq: 'FAQ', links: 'Links', testimonials: 'Testimonials', cta: 'Call to action', form: 'Request form' };
  function label(t) { return NAMES[t] || t; }
  function move(i, d) { var j = i + d; if (j < 0 || j >= S.P.blocks.length) { return; } S.P.blocks.splice(j, 0, S.P.blocks.splice(i, 1)[0]); setDirty(true); rerender(); }
  function addBar(at, end) { return h('div', { class: 'nbi-ctl nbi-add' + (end ? ' is-end' : ''), contenteditable: 'false' }, [h('button', { type: 'button', class: 'nbi-btn is-sm', text: '+ Add section', onclick: function () { addDlg(at); } })]); }
  // TRACE: "+ Add section" → insertion index → type picker → inserts a fresh block from the server catalogue (new id) and re-renders; nothing is saved until Save
  function addDlg(at) {
    var chosen = null, box = h('div', { class: 'nbi-types' });
    Object.keys(NAMES).forEach(function (t) { box.appendChild(h('button', { type: 'button', class: 'nbi-btn', text: NAMES[t], onclick: function () { chosen = t; this.closest('.nbi-modal').querySelector('.nbi-mf button').click(); } })); });
    modal('Add a section', box, [{ label: 'Close', value: function () { return chosen; } }]).then(function (t) {
      if (!t) { return; }
      var m = clone(S.cat[t]); m.id = uid(); S.P.blocks.splice(at, 0, m); setDirty(true);
      rerender().then(function () { var el = main.querySelector('[data-block="' + m.id + '"]'); if (el) { el.scrollIntoView({ block: 'center', behavior: 'smooth' }); } });
    });
  }

  // ───────── dialogs ─────────
  var ICONS = function () { return S.icons.map(function (i) { return [i, i]; }); };
  var SVCS = function () { return [['', 'Visitor chooses the service']].concat(S.services.map(function (s) { return [s.slug, s.name]; })); };
  // TRACE: ⚙ on a section → that block → modal of the properties that are not plain text (style, links, icons, image alt…) → applied to the model on "Apply", then re-rendered
  function settings(b) {
    var d = clone(b.data), body = h('div'), a = function (x) { body.appendChild(x); };
    switch (b.type) {
      case 'text': a(fld('Heading level', sel(d.level, [['h2', 'Main (H2)'], ['h3', 'Sub (H3)']], function (v) { d.level = v; }))); break;
      case 'cards': a(fld('Columns', sel(d.columns, [[2, '2'], [3, '3']], function (v) { d.columns = parseInt(v, 10); }))); d.items.forEach(function (it, i) { a(fld('Icon for card ' + (i + 1), sel(it.icon, ICONS(), function (v) { it.icon = v; }))); }); break;
      case 'image': a(fld('Alt text (describe the image)', txt(d.alt, function (v) { d.alt = v; }))); a(fld('Link address (optional)', txt(d.link, function (v) { d.link = v; }))); a(fld('Width', sel(d.width, [['content', 'Article width'], ['wide', 'Wide']], function (v) { d.width = v; }))); break;
      case 'callout': a(fld('Style', sel(d.tone, [['info', 'Information'], ['warn', 'Warning'], ['success', 'Success']], function (v) { d.tone = v; }))); break;
      case 'cta': a(fld('Button label', txt(d.button_label, function (v) { d.button_label = v; }))); a(fld('Button address', txt(d.button_url, function (v) { d.button_url = v; }))); a(fld('Second button label', txt(d.button2_label, function (v) { d.button2_label = v; }))); a(fld('Second button address', txt(d.button2_url, function (v) { d.button2_url = v; }))); break;
      case 'links': d.items.forEach(function (it, i) { a(fld('Address for “' + it.label + '”', txt(it.url, function (v) { it.url = v; }))); }); break;
      case 'form': a(fld('Form heading', txt(d.title, function (v) { d.title = v; }))); a(fld('Service', sel(d.service, SVCS(), function (v) { d.service = v; }))); break;
      default: a(h('p', { text: 'Edit the text directly on the page. Use the arrows to reorder or the bin to delete.' }));
    }
    modal(label(b.type) + ' settings', body, [{ label: 'Cancel', value: false }, { label: 'Apply', value: true, cls: 'is-primary' }]).then(function (ok) { if (ok) { b.data = d; setDirty(true); rerender(); } });
  }
  // TRACE: "Edit buttons" / "Form settings" → page-level layout (hero buttons, both request forms, contents list, latest articles) → applied to P.layout on Apply
  function layoutDlg() {
    var L = clone(S.P.layout), body = h('div'), a = function (x) { body.appendChild(x); };
    a(fld('Hero button 1 label', txt(L.hero.cta1.label, function (v) { L.hero.cta1.label = v; }))); a(fld('Hero button 1 address', txt(L.hero.cta1.url, function (v) { L.hero.cta1.url = v; })));
    a(fld('Hero button 2 label', txt(L.hero.cta2.label, function (v) { L.hero.cta2.label = v; }))); a(fld('Hero button 2 address', txt(L.hero.cta2.url, function (v) { L.hero.cta2.url = v; })));
    [['hero', 'Hero form'], ['aside', 'Sidebar form']].forEach(function (k) { var f = L.forms[k[0]]; a(h('hr')); a(chk('Show the ' + k[1].toLowerCase(), f.enabled, function (v) { f.enabled = v ? 1 : 0; })); a(fld(k[1] + ' heading', txt(f.title, function (v) { f.title = v; }))); a(fld(k[1] + ' service', sel(f.service, SVCS(), function (v) { f.service = v; }))); });
    a(h('hr')); a(chk('Show “On this page” contents list', L.toc, function (v) { L.toc = v ? 1 : 0; })); a(chk('Show latest articles at the bottom', L.latest.show, function (v) { L.latest.show = v ? 1 : 0; }));
    modal('Page layout', body, [{ label: 'Cancel', value: false }, { label: 'Apply', value: true, cls: 'is-primary' }]).then(function (ok) { if (ok) { S.P.layout = L; setDirty(true); rerender(); } });
  }
  // TRACE: image fields → opens the blog library (upload, search, choose) → Promise of the chosen item or null
  function pick() {
    return new Promise(function (res) {
      var grid = h('div', { class: 'nbi-mgrid' }), chosen = null, q = '';
      function load() { grid.textContent = 'Loading…'; api('media_list', { q: q, page: 1 }).then(function (r) { grid.textContent = ''; if (!r.items.length) { grid.textContent = 'No images yet — upload one.'; } r.items.forEach(function (it) { grid.appendChild(h('button', { type: 'button', class: 'nbi-mi', 'aria-label': 'Select ' + (it.title || it.file), onclick: function () { chosen = it; [].forEach.call(grid.children, function (c) { c.classList.remove('is-on'); }); this.classList.add('is-on'); } }, [h('img', { src: it.thumb || it.url, alt: '' })])); }); }).catch(fail); }
      var file = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/gif,image/webp', hidden: true, onchange: function () { var f = this.files[0]; this.value = ''; if (!f) { return; } if (f.size > C.maxUpload) { toast('Images can be at most 10 MB.', true); return; } toast('Uploading…'); api('media_upload', {}, f).then(function (r) { chosen = r.item; load(); toast('Uploaded.'); }).catch(fail); } });
      var top = h('div', { class: 'nbi-mbar' }, [C.canMedia ? h('button', { type: 'button', class: 'nbi-btn is-primary', text: 'Upload image', onclick: function () { file.click(); } }) : null, file, h('input', { type: 'search', placeholder: 'Search images', 'aria-label': 'Search images', oninput: function () { q = this.value; clearTimeout(top._t); top._t = setTimeout(load, 300); } })]);
      var body = h('div'); body.appendChild(top); body.appendChild(grid); load();
      modal('Choose an image', body, [{ label: 'Cancel', value: null }, { label: 'Use this image', cls: 'is-primary', value: function () { return chosen; } }], true).then(function (v) { res(v || null); });
    });
  }

  // ───────── top bar ─────────
  function syncFmt() { if (!S.bar) { return; } var on = !!(S.focus && document.activeElement === S.focus && S.focus.hasAttribute('data-rich')); [].forEach.call(S.bar.querySelectorAll('[data-fmt]'), function (b) { b.disabled = !on; }); }
  function fmt(c) { if (!S.focus) { return; } S.focus.focus(); if (c === 'link') { var u = window.prompt('Link address (https://…)'); if (!u) { return; } document.execCommand('createLink', false, u); } else { document.execCommand(c, false, null); } commit(S.focus); }
  function save() {
    if (S.busy) { return Promise.reject(); }
    if (!S.P.title.trim()) { toast('The title cannot be empty.', true); return Promise.reject(); }
    S.busy = true; busyUi();
    var d = payload(); d.id = C.post; d.version = S.P.version;
    return api('post_save', { data: d }).then(function (r) { S.busy = false; S.P.version = r.post.version; S.P.status = r.post.status; S.P.has_working = r.post.has_working; setDirty(false); busyUi(); barState(); toast(S.P.status === 'published' ? 'Saved. Changes go live when you publish them.' : 'Saved.'); return r.post; })
      .catch(function (e) { S.busy = false; busyUi(); if (e && e.code === 'conflict') { modal('This article changed elsewhere', 'Someone saved a newer version. Reload to get it (your unsaved edits will be lost), or keep editing and copy your text first.', [{ label: 'Keep editing', value: false }, { label: 'Reload latest', value: true, cls: 'is-primary' }]).then(function (v) { if (v) { setDirty(false); leave(); } }); } else { fail(e); } throw e; });
  }
  function busyUi() { if (!S.bar) { return; } [].forEach.call(S.bar.querySelectorAll('[data-act]'), function (b) { b.disabled = S.busy; }); }
  function preview() { (S.dirty ? save() : Promise.resolve()).then(function () { var u = S.P.url + (S.P.url.indexOf('?') > -1 ? '&' : '?') + 'preview=1'; window.open(u, '_blank', 'noopener'); }).catch(function () {}); }
  function publish() {
    (S.dirty ? save() : Promise.resolve()).then(function () {
      if (S.P.status === 'published') { return api('post_publish_working', { id: C.post }); }
      return api('post_transition', { id: C.post, to: 'published' });
    }).then(function (r) { S.P.status = r.post.status; S.P.has_working = r.post.has_working; S.P.version = r.post.version; toast('Published. The page is live.'); if (S.bar) { barState(); } }).catch(function (e) { if (e && e.message) { fail(e); } });
  }
  function submitReview() { (S.dirty ? save() : Promise.resolve()).then(function () { return api('post_transition', { id: C.post, to: 'pending' }); }).then(function (r) { S.P.status = r.post.status; toast('Submitted for review.'); barState(); }).catch(function (e) { if (e && e.message) { fail(e); } }); }
  function leave() { var u = new URL(location.href); u.searchParams.delete('edit'); location.href = u.toString(); }
  function cancel() { if (!S.dirty) { leave(); return; } ask('Discard your changes?', 'You have unsaved edits. Leaving now discards them.', 'Discard and exit', true).then(function (ok) { if (ok) { setDirty(false); leave(); } }); }
  function barState() {
    var pill = S.bar.querySelector('.nbi-st'); pill.textContent = ({ draft: 'Draft', pending: 'Pending review', scheduled: 'Scheduled', published: 'Published', archived: 'Archived' })[S.P.status] + (S.P.has_working ? ' · unpublished changes' : '');
    var pb = S.bar.querySelector('[data-act=publish]'); if (pb) { pb.textContent = S.P.status === 'published' ? 'Publish changes' : 'Publish'; pb.hidden = !C.canPublish || (S.P.status === 'published' && !S.P.has_working && !S.dirty); }
    var sr = S.bar.querySelector('[data-act=review]'); if (sr) { sr.hidden = C.canPublish || S.P.status !== 'draft'; }
  }
  function buildBar() {
    var bar = h('div', { class: 'nbi-bar nbi-ctl', role: 'toolbar', 'aria-label': 'Page editor' }, [
      h('strong', { class: 'nbi-t', text: 'Editing page' }), h('span', { class: 'nbi-st' }), h('span', { class: 'nbi-dirty', hidden: true, text: 'Unsaved changes' }),
      h('span', { class: 'nbi-fmt' }, [fb('B', 'bold', 'Bold'), fb('I', 'italic', 'Italic'), fb('• List', 'insertUnorderedList', 'Bulleted list'), fb('Link', 'link', 'Link')]),
      h('span', { class: 'nbi-sp' }),
      h('button', { type: 'button', class: 'nbi-btn', 'data-act': 'layout', text: 'Page layout', onclick: layoutDlg }),
      h('button', { type: 'button', class: 'nbi-btn', 'data-act': 'preview', text: 'Preview', onclick: preview }),
      h('button', { type: 'button', class: 'nbi-btn is-primary', 'data-act': 'save', text: 'Save', onclick: function () { save().catch(function () {}); } }),
      h('button', { type: 'button', class: 'nbi-btn is-success', 'data-act': 'publish', text: 'Publish', onclick: publish }),
      h('button', { type: 'button', class: 'nbi-btn', 'data-act': 'review', text: 'Submit for review', onclick: submitReview }),
      h('a', { class: 'nbi-btn', href: C.fullEditor, text: 'Full editor' }),
      h('button', { type: 'button', class: 'nbi-btn', 'data-act': 'cancel', text: 'Exit', onclick: cancel })]);
    return bar;
  }
  function fb(t, c, aria) { return h('button', { type: 'button', class: 'nbi-btn is-sm', 'data-fmt': c, 'aria-label': aria, disabled: true, text: t, onmousedown: function (e) { e.preventDefault(); }, onclick: function () { fmt(c); } }); }

  // ───────── enter / leave edit mode ─────────
  // TRACE: "Edit this page" → loads the editable model (permission re-checked server-side) → renders edit mode in place, shows the editor bar, installs the unsaved-changes guard and Ctrl/Cmd+S
  function start() {
    if (S.on) { return; }
    var b = document.getElementById('nbi-launch'); if (b) { b.disabled = true; b.textContent = 'Loading editor…'; }
    api('inline_boot', { id: C.post }).then(function (r) {
      S.P = r.post; S.cat = r.catalogue; S.services = r.services || []; S.icons = r.icons || []; S.on = true;
      document.documentElement.classList.add('nbi-on'); S.bar = buildBar(); document.body.insertBefore(S.bar, document.body.firstChild); barState();
      if (b) { b.parentNode.removeChild(b); }
      var pv = main.querySelector('.nb-previewbar'); if (pv) { pv.parentNode.removeChild(pv); }
      return rerender(false);
    }).then(function () { if (S.on) { var t = main.querySelector('[data-f="title"]'); if (t) { t.focus(); } } }).catch(function (e) { fail(e); if (b) { b.disabled = false; b.textContent = 'Edit this page'; } });
  }
  window.addEventListener('beforeunload', function (e) { if (S.on && S.dirty) { e.preventDefault(); e.returnValue = ''; } });
  document.addEventListener('keydown', function (e) { if (S.on && (e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); save().catch(function () {}); } });
  var launch = h('button', { type: 'button', id: 'nbi-launch', class: 'nbi-launch', text: 'Edit this page', onclick: start });
  document.body.appendChild(launch);
  if (C.startEdit) { start(); }
})();
