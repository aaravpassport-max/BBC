/* Blog CMS app — vanilla JS single-page app. All text is inserted with textContent / attribute setters (never innerHTML with user data). */
(function () {
  'use strict';
  var CFG = window.NSHBLOG || {};
  var root = document.getElementById('nba-root');
  if (!root) { return; }

  // ───────────────────────── helpers ─────────────────────────
  // TRACE: any UI builder → tag, attrs {class,text,on*,…}, children → a DOM element; attrs set via setAttribute/textContent only
  function h(tag, a, kids) {
    var e = document.createElement(tag);
    a = a || {};
    Object.keys(a).forEach(function (k) {
      var v = a[k];
      if (v === null || v === undefined || v === false) { return; }
      if (k === 'class') { e.className = v; }
      else if (k === 'text') { e.textContent = v; }
      else if (k.indexOf('on') === 0 && typeof v === 'function') { e.addEventListener(k.slice(2), v); }
      else if (k === 'value') { e.value = v; }
      else if (k === 'checked') { e.checked = !!v; }
      else { e.setAttribute(k, v === true ? '' : v); }
    });
    (kids || []).forEach(function (c) { if (c === null || c === undefined || c === false) { return; } e.appendChild(typeof c === 'string' ? document.createTextNode(c) : c); });
    return e;
  }
  function clear(n) { while (n.firstChild) { n.removeChild(n.firstChild); } return n; }
  function clone(o) { return JSON.parse(JSON.stringify(o)); }
  function esc(s) { return String(s === null || s === undefined ? '' : s); }
  function uid() { return 'b' + Math.random().toString(36).slice(2, 10); }
  var state = { boot: null, dirty: false, view: null, post: null, tab: 'publish', busy: 0 };

  // TRACE: every server call → op name, plain object (arrays/objects sent as JSON strings), optional File → Promise of data; rejects with {message, code, data}
  //        edge: network failure / non-JSON → generic message so the UI never hangs; 401/nonce → asks to reload
  function api(op, data, file) {
    var fd = new FormData();
    fd.append('action', 'nsh_blog'); fd.append('nonce', CFG.nonce); fd.append('op', op);
    Object.keys(data || {}).forEach(function (k) { var v = data[k]; fd.append(k, typeof v === 'object' && v !== null ? JSON.stringify(v) : v); });
    if (file) { fd.append('file', file); }
    return fetch(CFG.ajax, { method: 'POST', body: fd, credentials: 'same-origin' }).then(function (r) {
      return r.json().catch(function () { return { success: false, data: { message: 'The server sent an unexpected response.' } }; });
    }, function () { return { success: false, data: { message: 'Network problem. Check your connection and try again.' } }; }).then(function (j) {
      if (j && j.success) { return j.data; }
      var d = (j && j.data) || {};
      if (d.code === 'auth' || d.code === 'nonce') { d.message = 'Your session expired. Reload the page to sign in again.'; }
      throw d;
    });
  }
  var toastEl;
  // TRACE: any outcome → message, kind (ok|err) → a transient status toast announced to screen readers
  function toast(msg, kind) {
    if (!toastEl) { toastEl = h('div', { class: 'nba-toasts', role: 'status', 'aria-live': 'polite' }); document.body.appendChild(toastEl); }
    var t = h('div', { class: 'nba-toast ' + (kind === 'err' ? 'is-err' : 'is-ok'), text: msg });
    toastEl.appendChild(t); setTimeout(function () { if (t.parentNode) { t.parentNode.removeChild(t); } }, kind === 'err' ? 7000 : 3500);
  }
  function fail(e) { toast((e && e.message) || 'Something went wrong.', 'err'); }

  // TRACE: modal dialogs → title/body/buttons → Promise resolving to the chosen button value (Esc/backdrop = null); focus is trapped and restored
  function modal(title, body, buttons, opts) {
    return new Promise(function (resolve) {
      var prev = document.activeElement;
      var ov = h('div', { class: 'nba-ov' });
      var box = h('div', { class: 'nba-modal' + (opts && opts.wide ? ' is-wide' : ''), role: 'dialog', 'aria-modal': 'true', 'aria-label': title });
      function done(v) { document.removeEventListener('keydown', key, true); if (ov.parentNode) { ov.parentNode.removeChild(ov); } if (prev && prev.focus) { prev.focus(); } resolve(v); }
      function key(e) {
        if (e.key === 'Escape') { e.stopPropagation(); done(null); }
        if (e.key === 'Tab') { var f = box.querySelectorAll('button,input,select,textarea,a[href]'); if (!f.length) { return; } var first = f[0], last = f[f.length - 1]; if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); } else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); } }
      }
      box.appendChild(h('h2', { text: title }));
      var b = h('div', { class: 'nba-modal-b' }); if (typeof body === 'string') { b.textContent = body; } else if (body) { b.appendChild(body); } box.appendChild(b);
      var bar = h('div', { class: 'nba-modal-f' });
      (buttons || []).forEach(function (bt) { bar.appendChild(h('button', { type: 'button', class: 'nba-btn ' + (bt.cls || ''), text: bt.label, onclick: function () { done(typeof bt.value === 'function' ? bt.value() : bt.value); } })); });
      box.appendChild(bar); ov.appendChild(box);
      ov.addEventListener('mousedown', function (e) { if (e.target === ov) { done(null); } });
      document.body.appendChild(ov); document.addEventListener('keydown', key, true);
      var f0 = box.querySelector('input,select,textarea') || box.querySelector('.nba-btn.is-primary') || box.querySelector('button'); if (f0) { f0.focus(); }
    });
  }
  function confirmBox(title, text, ok, danger) { return modal(title, text, [{ label: 'Cancel', value: false }, { label: ok || 'OK', value: true, cls: danger ? 'is-danger' : 'is-primary' }]).then(function (v) { return v === true; }); }

  // TRACE: label+control → a labelled form row (label bound with for/id) → element
  var fid = 0;
  function field(label, input, hint) { var id = 'nbaf' + (++fid); input.id = id; return h('div', { class: 'nba-f' }, [h('label', { for: id, text: label }), input, hint ? h('small', { text: hint }) : null]); }
  function inp(val, on, a) { a = a || {}; a.type = a.type || 'text'; a.value = esc(val); a.oninput = function () { on(this.value); }; return h('input', a); }
  function area(val, on, rows) { return h('textarea', { rows: rows || 3, value: esc(val), oninput: function () { on(this.value); } }); }
  function sel(val, opts, on) { var s = h('select', { onchange: function () { on(this.value); } }, opts.map(function (o) { return h('option', { value: o[0], text: o[1] }); })); s.value = esc(val); return s; }
  function check(label, val, on) { return h('label', { class: 'nba-chk' }, [h('input', { type: 'checkbox', checked: !!val, onchange: function () { on(this.checked); } }), h('span', { text: label })]); }
  function btn(label, on, cls, a) { a = a || {}; a.type = 'button'; a.class = 'nba-btn ' + (cls || ''); a.text = label; a.onclick = on; return h('button', a); }
  function when(iso) { if (!iso) { return '—'; } var d = new Date(iso.replace(' ', 'T') + 'Z'); return isNaN(d) ? iso : d.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' }); }
  function setDirty(v) { state.dirty = v; var b = document.getElementById('nba-dirty'); if (b) { b.hidden = !v; } }
  window.addEventListener('beforeunload', function (e) { if (state.dirty) { e.preventDefault(); e.returnValue = ''; } });

  // ───────────────────────── media picker ─────────────────────────
  // TRACE: any image field → current id → opens the library modal; upload, search, pick, edit alt/caption → Promise of the chosen media item (or null)
  function pickMedia() {
    return new Promise(function (resolve) {
      var wrap = h('div', { class: 'nba-media' }), grid = h('div', { class: 'nba-mgrid' }), q = '', page = 1, chosen = null, info = h('div', { class: 'nba-minfo' }, [h('p', { class: 'nba-muted', text: 'Select an image.' })]);
      function load() {
        clear(grid).appendChild(h('p', { class: 'nba-muted', text: 'Loading…' }));
        api('media_list', { q: q, page: page }).then(function (r) {
          clear(grid);
          if (!r.items.length) { grid.appendChild(h('p', { class: 'nba-empty', text: 'No images yet. Upload your first image.' })); }
          r.items.forEach(function (it) {
            grid.appendChild(h('button', { type: 'button', class: 'nba-mi' + (chosen && chosen.id === it.id ? ' is-on' : ''), 'aria-label': 'Select ' + (it.title || it.file), onclick: function () { chosen = it; show(); [].forEach.call(grid.children, function (c) { c.classList.remove('is-on'); }); this.classList.add('is-on'); } }, [h('img', { src: it.thumb || it.url, alt: '', loading: 'lazy' })]));
          });
          if (r.pages > 1) { var pg = h('div', { class: 'nba-pager' }); pg.appendChild(btn('‹ Prev', function () { if (page > 1) { page--; load(); } }, '', { disabled: page <= 1 })); pg.appendChild(h('span', { text: 'Page ' + page + ' of ' + r.pages })); pg.appendChild(btn('Next ›', function () { if (page < r.pages) { page++; load(); } }, '', { disabled: page >= r.pages })); grid.appendChild(pg); }
        }).catch(fail);
      }
      function show() {
        clear(info);
        if (!chosen) { return; }
        info.appendChild(h('img', { src: chosen.thumb || chosen.url, alt: '' }));
        info.appendChild(field('Alt text (describe the image)', inp(chosen.alt, function (v) { chosen.alt = v; })));
        info.appendChild(field('Caption', inp(chosen.caption, function (v) { chosen.caption = v; })));
        info.appendChild(btn('Save details', function () { api('media_update', { id: chosen.id, data: { title: chosen.title, alt: chosen.alt, caption: chosen.caption } }).then(function (r) { chosen = r.item; toast('Image details saved.'); }).catch(fail); }, ''));
      }
      var file = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/gif,image/webp', hidden: true, onchange: function () {
        var f = this.files[0]; this.value = ''; if (!f) { return; }
        if (f.size > (CFG.maxUpload || 10485760)) { toast('Images can be at most 10 MB.', 'err'); return; }
        toast('Uploading…'); api('media_upload', {}, f).then(function (r) { chosen = r.item; page = 1; q = ''; load(); show(); toast('Image uploaded.'); }).catch(fail);
      } });
      var bar = h('div', { class: 'nba-mbar' }, [btn('Upload image', function () { file.click(); }, 'is-primary'), file, h('input', { type: 'search', placeholder: 'Search images', 'aria-label': 'Search images', oninput: function () { q = this.value; page = 1; clearTimeout(bar._t); bar._t = setTimeout(load, 300); } })]);
      wrap.appendChild(bar); wrap.appendChild(h('div', { class: 'nba-mcols' }, [grid, info]));
      load();
      modal('Image library', wrap, [{ label: 'Cancel', value: null }, { label: 'Use this image', cls: 'is-primary', value: function () { return chosen; } }], { wide: true }).then(function (v) { resolve(v || null); });
    });
  }

  // ───────────────────────── rich text (small, safe) ─────────────────────────
  // TRACE: rich fields → initial HTML, change callback → a toolbar + contenteditable; output HTML is sanitised again on the server (wp_kses whitelist)
  function rte(val, on, label) {
    var ed = h('div', { class: 'nba-rte-ed', contenteditable: 'true', role: 'textbox', 'aria-multiline': 'true', 'aria-label': label || 'Content' });
    ed.innerHTML = esc(val); // value originates from the server's already-whitelisted HTML (Blocks::html)
    function cmd(c, v) { ed.focus(); document.execCommand(c, false, v || null); on(ed.innerHTML); }
    var tb = h('div', { class: 'nba-rte-tb', role: 'toolbar', 'aria-label': 'Formatting' }, [
      btn('B', function () { cmd('bold'); }, 'is-sm', { 'aria-label': 'Bold' }), btn('I', function () { cmd('italic'); }, 'is-sm', { 'aria-label': 'Italic' }),
      btn('• List', function () { cmd('insertUnorderedList'); }, 'is-sm'), btn('1. List', function () { cmd('insertOrderedList'); }, 'is-sm'),
      btn('Link', function () { var u = prompt('Link address (https://…)'); if (u) { cmd('createLink', u); } }, 'is-sm'), btn('Clear', function () { cmd('removeFormat'); }, 'is-sm')]);
    ed.addEventListener('input', function () { on(ed.innerHTML); });
    ed.addEventListener('paste', function (e) { e.preventDefault(); var t = (e.clipboardData || window.clipboardData).getData('text/plain'); document.execCommand('insertText', false, t); });
    return h('div', { class: 'nba-rte' }, [tb, ed]);
  }

  // ───────────────────────── shell & routing ─────────────────────────
  var NAV = [['#/', 'Articles'], ['#/quick', 'New article'], ['#/taxonomy', 'Categories & tags'], ['#/media', 'Media library'], ['#/profile', 'My author profile'], ['#/team', 'Team access', 'admin'], ['#/settings', 'Blog settings', 'admin']];
  var main, side;
  function shell() {
    clear(root);
    var admin = state.boot.me.admin;
    var nav = h('nav', { class: 'nba-nav', 'aria-label': 'Blog editor' });
    NAV.forEach(function (n) { if (n[2] === 'admin' && !admin) { return; } nav.appendChild(h('a', { href: n[0], text: n[1], 'data-r': n[0] })); });
    side = h('aside', { class: 'nba-side' }, [h('div', { class: 'nba-brand', text: CFG.brand + ' · Blog' }), nav,
      h('div', { class: 'nba-sidef' }, [h('a', { href: CFG.dash, text: '← Back to dashboard' }), h('a', { href: CFG.home, target: '_blank', rel: 'noopener', text: 'View public blog ↗' }), h('a', { href: CFG.logout, text: 'Sign out' })])]);
    main = h('main', { class: 'nba-main', id: 'nba-main', tabindex: '-1' });
    var top = h('header', { class: 'nba-top' }, [h('button', { type: 'button', class: 'nba-burger', 'aria-label': 'Menu', onclick: function () { side.classList.toggle('is-open'); } }, ['☰']), h('strong', { text: 'Blog editor' }), h('span', { id: 'nba-dirty', class: 'nba-dirty', hidden: true, text: 'Unsaved changes' })]);
    root.appendChild(top); root.appendChild(side); root.appendChild(main);
    side.addEventListener('click', function (e) { if (e.target.tagName === 'A') { side.classList.remove('is-open'); } });
  }
  var lastHash = '#/';
  // TRACE: hashchange → target view → blocks navigation (restoring the previous hash) while there are unsaved changes and the user declines → otherwise renders the view
  function route(initial) {
    var hash = location.hash || '#/';
    if (!initial && state.dirty && hash !== lastHash) {
      var go = hash; history.replaceState(null, '', lastHash);
      confirmBox('Leave without saving?', 'You have unsaved changes in this article. If you leave now they will be lost.', 'Leave and discard', true).then(function (ok) { if (ok) { setDirty(false); lastHash = go; history.replaceState(null, '', go); route(true); } });
      return;
    }
    lastHash = hash; var m;
    [].forEach.call(side.querySelectorAll('.nba-nav a'), function (a) { a.classList.toggle('is-on', a.getAttribute('data-r') === (hash.indexOf('#/edit') === 0 && hash !== '#/edit/new' ? '#/' : hash)); });
    clear(main); main.scrollTop = 0; window.scrollTo(0, 0);
    if ((m = hash.match(/^#\/edit\/(new|\d+)$/))) { return viewEditor(m[1]); }
    if (hash === '#/quick') { return viewQuick(); }
    if (hash === '#/taxonomy') { return viewTax(); }
    if (hash === '#/media') { return viewMedia(); }
    if (hash === '#/profile') { return viewProfile(); }
    if (hash === '#/team' && state.boot.me.admin) { return viewTeam(); }
    if (hash === '#/settings' && state.boot.me.admin) { return viewSettings(); }
    return viewList();
  }
  window.addEventListener('hashchange', function () { if (state.boot && side) { route(false); } });


  // ───────────────────────── quick article (guided form) ─────────────────────────
  // TRACE: #/quick → empty answers → one labelled form (title, intro, content, steps, cards, checklist, FAQs, links, testimonials, form service) → "Save draft" / "Submit" builds the standard blocks from the filled sections only (blank sections are skipped) and sends post_save (+ post_transition) → article exists with the full design applied; the list opens
  //        preconditions: create permission; postconditions: a draft/pending/published article with the complete layout, hero form and sidebar form; edge: blank title blocked, blank sections omitted, double-click blocked while saving
  function viewQuick() {
    var perms = state.boot.me.perms, can = function (p) { return state.boot.me.admin || perms.indexOf(p) > -1; };
    if (!can('create')) { main.appendChild(h('div', { class: 'nba-empty' }, [h('h2', { text: 'You cannot create articles' }), h('p', { text: 'Ask an administrator to give you the "create" permission.' })])); return; }
    var canPublish = can('publish'), busy = false, A = { title: '', subtitle: '', category_id: 0, tags: '', img: { featured_media: 0, _url: '' }, intro: '', heading: '', body: '', steps_h: 'How it works', steps: [{ title: '', text: '' }, { title: '', text: '' }, { title: '', text: '' }], cards_h: 'Good to know', cards: [{ icon: 'info', title: '', text: '' }, { icon: 'info', title: '', text: '' }, { icon: 'info', title: '', text: '' }], check_h: 'What you need', check: '', faq_h: 'Frequently asked questions', faq: [{ q: '', a: '' }, { q: '', a: '' }, { q: '', a: '' }], links_h: 'Popular links', links: [{ label: '', url: '' }, { label: '', url: '' }], tm_h: 'What clients say', tm: [{ quote: '', name: '', role: '' }], service: '', meta: '', hero: { heading: '', keywords: '', boxes: [{ title: 'Timeline and Cost', items: '' }, { title: 'Our Services', items: '' }, { title: 'Documents Required', items: '' }], stats: [{ value: '', label: '' }, { value: '', label: '' }, { value: '', label: '' }, { value: '', label: '' }] }, extra: [] };
    var noop = function () {}, T = function (label, key, hint, req) { return field(label + (req ? ' *' : ''), inp(A[key], function (v) { A[key] = v; setDirty(true); }), hint); };
    var R = function (label, key, hint) { return h('div', { class: 'nba-f' }, [h('label', { text: label }), rte(A[key], function (v) { A[key] = v; setDirty(true); }, label), hint ? h('small', { text: hint }) : null]); };
    function section(title, hint, kids) { return h('section', { class: 'nba-card nba-quick-s' }, [h('h2', { text: title }), hint ? h('p', { class: 'nba-muted', text: hint }) : null].concat(kids)); }
    var dirty = function () { setDirty(true); };
    var cats = [[0, 'No category']].concat(state.boot.terms.categories.map(function (c) { return [c.id, c.name]; }));
    // TRACE: "Add section" button → clone catalogue default of the chosen type → push into A.extra → redraw list; up/down/remove edit order; blocks are appended after the numbered sections, in this order
    var extraList = h('div', { class: 'nba-quick-extra' });
    function drawExtra() {
      clear(extraList);
      if (!A.extra.length) { extraList.appendChild(h('p', { class: 'nba-muted', text: 'No extra sections yet. Pick one below to add it to the article.' })); }
      A.extra.forEach(function (b, i) {
        extraList.appendChild(h('div', { class: 'nba-card nba-quick-x' }, [h('div', { class: 'nba-bh' }, [h('strong', { text: (BLOCK_NAMES[b.type] || b.type) + (WIDE[b.type] ? ' (full-width band)' : '') }), h('span', { class: 'nba-bt-act' }, [
          btn('Move up', function () { if (i > 0) { A.extra.splice(i - 1, 0, A.extra.splice(i, 1)[0]); dirty(); drawExtra(); } }, 'is-sm', { 'aria-label': 'Move section up', disabled: i === 0 }),
          btn('Move down', function () { if (i < A.extra.length - 1) { A.extra.splice(i + 1, 0, A.extra.splice(i, 1)[0]); dirty(); drawExtra(); } }, 'is-sm', { 'aria-label': 'Move section down', disabled: i === A.extra.length - 1 }),
          btn('Remove', function () { confirmBox('Remove this section?', 'The “' + (BLOCK_NAMES[b.type] || b.type) + '” section you added will be removed.', 'Remove section', true).then(function (ok) { if (ok) { A.extra.splice(i, 1); dirty(); drawExtra(); } }); }, 'is-sm is-danger-o', { 'aria-label': 'Remove section: ' + (BLOCK_NAMES[b.type] || b.type) })])]), blockForm(b, dirty)]));
      });
    }
    var pickSel = sel('', [['', 'Choose a section type…']].concat(Object.keys(BLOCK_NAMES).map(function (t) { return [t, BLOCK_NAMES[t]]; })), function () {});
    var extraSection = section('9. Add more sections', 'Add any extra section you like: text, steps, cards, checklist, image, callout, quote, FAQ, popular list, testimonials, banner or a request form. They appear at the end of the article, in this order.', [extraList, h('div', { class: 'nba-quick-add' }, [pickSel, btn('Add section', function () { var t = pickSel.value; var cat = state.boot.catalogue || {}; if (!t || !cat[t]) { toast('Choose a section type first.', 'err'); return; } var m = clone(cat[t]); m.id = uid(); A.extra.push(m); pickSel.value = ''; dirty(); drawExtra(); }, 'is-primary')])]);
    drawExtra();
    var form = h('div', { class: 'nba-quick' }, [
      section('Top of the page (optional)', 'The big banner at the top. Leave blank to use the article title.', [field('Banner heading', inp(A.hero.heading, function (v) { A.hero.heading = v; dirty(); })), field('Highlighted keywords (shown in the banner)', inp(A.hero.keywords, function (v) { A.hero.keywords = v; dirty(); })), listEd(A.hero.boxes, function () { return { title: '', items: '' }; }, function (it, i, c) { return h('div', null, [field('Info box ' + (i + 1) + ' title', inp(it.title, function (v) { it.title = v; c(); dirty(); })), field('Lines (one per line)', area(it.items, function (v) { it.items = v; c(); dirty(); }, 3))]); }, noop, 'Add info box', 0), listEd(A.hero.stats, function () { return { value: '', label: '' }; }, function (it, i, c) { return h('div', { class: 'nba-two' }, [field('Number ' + (i + 1) + ' (e.g. 10k+)', inp(it.value, function (v) { it.value = v; c(); dirty(); })), field('Label', inp(it.label, function (v) { it.label = v; c(); dirty(); }))]); }, noop, 'Add number', 0)]),
      section('1. Basics', 'The title and a one-line summary appear at the top of the page.', [T('Article title', 'title', 'Example: Apostille Services for NRIs', true), T('Short summary (shown under the title)', 'subtitle'), h('div', { class: 'nba-two' }, [field('Category', sel(A.category_id, cats, function (v) { A.category_id = parseInt(v, 10) || 0; dirty(); })), T('Tags', 'tags', 'Separate with commas')]), imageField(A.img, dirty, 'featured_media'), R('Introduction', 'intro', 'Two or three sentences that open the article.')]),
      section('2. Main content', 'Optional. A heading and the main text of the article.', [T('Section heading', 'heading'), R('Text', 'body')]),
      section('3. Steps', 'Optional. Leave a step blank and it is skipped.', [T('Steps heading', 'steps_h'), listEd(A.steps, function () { return { title: '', text: '' }; }, function (it, i, c) { return h('div', null, [field('Step ' + (i + 1) + ' title', inp(it.title, function (v) { it.title = v; c(); dirty(); })), field('What happens', area(it.text, function (v) { it.text = v; c(); dirty(); }, 2))]); }, noop, 'Add step')]),
      section('4. Info cards', 'Optional. Short boxes such as documents, timelines or charges.', [T('Cards heading', 'cards_h'), listEd(A.cards, function () { return { icon: 'info', title: '', text: '' }; }, function (it, i, c) { return h('div', null, [h('div', { class: 'nba-two' }, [field('Card title', inp(it.title, function (v) { it.title = v; c(); dirty(); })), field('Icon', sel(it.icon, ICONS(), function (v) { it.icon = v; c(); dirty(); }))]), field('Text', area(it.text, function (v) { it.text = v; c(); dirty(); }, 2))]); }, noop, 'Add card')]),
      section('5. Checklist', 'Optional. One requirement per line.', [T('Checklist heading', 'check_h'), field('Items (one per line)', area(A.check, function (v) { A.check = v; dirty(); }, 5))]),
      section('6. Questions and answers', 'Optional. Also helps the article show in Google.', [T('FAQ heading', 'faq_h'), listEd(A.faq, function () { return { q: '', a: '' }; }, function (it, i, c) { return h('div', null, [field('Question', inp(it.q, function (v) { it.q = v; c(); dirty(); })), field('Answer', area(it.a, function (v) { it.a = v; c(); dirty(); }, 2))]); }, noop, 'Add question')]),
      section('7. Popular links and testimonials', 'Optional.', [T('Links heading', 'links_h'), listEd(A.links, function () { return { label: '', url: '' }; }, function (it, i, c) { return h('div', { class: 'nba-two' }, [field('Label', inp(it.label, function (v) { it.label = v; c(); dirty(); })), field('Address (https://… or /page/)', inp(it.url, function (v) { it.url = v; c(); dirty(); }))]); }, noop, 'Add link'), T('Testimonials heading', 'tm_h'), listEd(A.tm, function () { return { quote: '', name: '', role: '' }; }, function (it, i, c) { return h('div', null, [field('Quote', area(it.quote, function (v) { it.quote = v; c(); dirty(); }, 2)), h('div', { class: 'nba-two' }, [field('Name', inp(it.name, function (v) { it.name = v; c(); dirty(); })), field('City or role', inp(it.role, function (v) { it.role = v; c(); dirty(); }))])]); }, noop, 'Add testimonial')]),
      extraSection,
      section('8. Request form and search', 'The request form appears twice on the page automatically (top and sidebar).', [field('Service shown in the forms', serviceSel(A.service, function (v) { A.service = v; dirty(); }), 'Pre-select a service, or leave open so visitors choose.'), field('Google description (optional, up to 160 characters)', area(A.meta, function (v) { A.meta = v; dirty(); }, 2))])
    ]);
    var msg = h('p', { class: 'nba-muted', id: 'nba-quick-msg', role: 'status' });
    // TRACE: filled answers → ordered block list (skipping empty sections) → array of blocks in the same shape the full editor saves
    function build() {
      var B = [], lines = function (t) { return String(t || '').split(/\r?\n/).map(function (x) { return x.trim(); }).filter(Boolean); }, plain = function (h2) { return String(h2 || '').replace(/<[^>]*>/g, '').trim(); };
      if (A.heading.trim() || plain(A.body)) { B.push({ id: '', type: 'text', data: { heading: A.heading.trim(), level: 'h2', body: A.body } }); }
      var st = A.steps.filter(function (x) { return x.title.trim(); }); if (st.length) { B.push({ id: '', type: 'steps', data: { heading: A.steps_h.trim(), intro: '', items: st.map(function (x) { return { title: x.title.trim(), text: x.text.trim() }; }) } }); }
      var cd = A.cards.filter(function (x) { return x.title.trim(); }); if (cd.length) { B.push({ id: '', type: 'cards', data: { heading: A.cards_h.trim(), intro: '', columns: cd.length === 2 ? 2 : 3, items: cd.map(function (x) { return { icon: x.icon, title: x.title.trim(), text: x.text.trim() }; }) } }); }
      var ck = lines(A.check); if (ck.length) { B.push({ id: '', type: 'checklist', data: { heading: A.check_h.trim(), items: ck } }); }
      var fq = A.faq.filter(function (x) { return x.q.trim() && x.a.trim(); }); if (fq.length) { B.push({ id: '', type: 'faq', data: { heading: A.faq_h.trim(), items: fq.map(function (x) { return { q: x.q.trim(), a: x.a.trim() }; }) } }); }
      var lk = A.links.filter(function (x) { return x.label.trim() && x.url.trim(); }); if (lk.length) { B.push({ id: '', type: 'links', data: { heading: A.links_h.trim(), items: lk.map(function (x) { return { label: x.label.trim(), url: x.url.trim() }; }) } }); }
      var tm = A.tm.filter(function (x) { return x.quote.trim() && x.name.trim(); }); if (tm.length) { B.push({ id: '', type: 'testimonials', data: { heading: A.tm_h.trim(), items: tm.map(function (x) { return { quote: x.quote.trim(), name: x.name.trim(), role: x.role.trim() }; }) } }); }
      A.extra.forEach(function (b) { var c = clone(b); delete c._open; B.push(c); });
      return B;
    }
    // TRACE: button → validate title → post_save (new article, full default layout, chosen service on both forms) → optional post_transition (pending or published) → clears dirty flag → opens the list; any failure leaves the answers on screen
    function submit(to) {
      if (busy) { return; }
      if (!A.title.trim()) { toast('Add the article title first.', 'err'); var t = main.querySelector('input'); if (t) { t.focus(); } return; }
      busy = true; [].forEach.call(main.querySelectorAll('.nba-quick-bar button'), function (b) { b.disabled = true; }); msg.textContent = 'Saving…';
      var layout = clone(state.boot.layout_defaults); layout.forms = layout.forms || {}; ['hero', 'aside'].forEach(function (k) { layout.forms[k] = layout.forms[k] || { enabled: 1, title: 'Get Estimated Quote Instantly' }; layout.forms[k].service = A.service; });
      layout.hero = layout.hero || {}; layout.hero.heading = A.hero.heading.trim(); layout.hero.keywords = A.hero.keywords.trim(); var bx = A.hero.boxes.map(function (x) { return { title: x.title.trim(), items: String(x.items || '').split(/\r?\n/).map(function (l) { return l.trim(); }).filter(Boolean) }; }).filter(function (x) { return x.title || x.items.length; }); if (bx.length) { layout.hero.boxes = bx; } layout.hero.stats = A.hero.stats.map(function (x) { return { value: x.value.trim(), label: x.label.trim() }; }).filter(function (x) { return x.value || x.label; });
      var seo = { title: '', description: A.meta.trim().slice(0, 160), canonical: '', og_title: '', og_description: '', og_image: 0, twitter_card: 'summary_large_image', noindex: 0, focus: '' };
      var data = { id: 0, version: 0, title: A.title.trim(), subtitle: A.subtitle.trim(), slug: '', intro: A.intro, blocks: build(), layout: layout, seo: seo, featured_media: A.img.featured_media || 0, category_id: A.category_id, tag_ids: [], new_tags: A.tags.split(',').map(function (x) { return x.trim(); }).filter(Boolean) };
      api('post_save', { data: data }).then(function (r) {
        if (!to) { return r; }
        return api('post_transition', { id: r.post.id, to: to }).then(function () { return r; });
      }).then(function (r) { setDirty(false); toast(to === 'published' ? 'Published.' : to === 'pending' ? 'Submitted for review.' : 'Draft saved.'); location.hash = '#/'; })
        .catch(function (e) { busy = false; [].forEach.call(main.querySelectorAll('.nba-quick-bar button'), function (b) { b.disabled = false; }); msg.textContent = ''; fail(e); });
    }
    var bar = h('div', { class: 'nba-quick-bar' }, [btn('Save as draft', function () { submit(''); }), canPublish ? btn('Publish now', function () { submit('published'); }, 'is-primary') : btn('Submit for review', function () { submit('pending'); }, 'is-primary'), h('a', { class: 'nba-btn', href: '#/edit/new', text: 'Use advanced editor' }), msg]);
    main.appendChild(h('div', { class: 'nba-head' }, [h('h1', { text: 'New article' })]));
    main.appendChild(h('p', { class: 'nba-muted', text: 'Fill in the boxes below and press the button at the end. The full page design, the request forms, the table of contents and the layout are added for you. Skip any section you do not need.' }));
    main.appendChild(form); main.appendChild(bar);
  }

  // ───────────────────────── articles list ─────────────────────────
  var LQ = { status: 'all', q: '', category: 0, page: 1 };
  // TRACE: #/ → LQ filters → list from the server (own articles only unless "edit all") with tabs/search/category/bulk/pagination; empty and error states shown
  function viewList() {
    var perms = state.boot.me.perms, can = function (p) { return perms.indexOf(p) > -1 || state.boot.me.admin; };
    var head = h('div', { class: 'nba-head' }, [h('h1', { text: 'Articles' }), can('create') ? h('a', { class: 'nba-btn is-primary', href: '#/quick', text: 'New article' }) : null]);
    var tabs = h('div', { class: 'nba-tabs', role: 'tablist' }), tools = h('div', { class: 'nba-tools' }), body = h('div', { class: 'nba-card' }), selected = {};
    main.appendChild(head); main.appendChild(tabs); main.appendChild(tools); main.appendChild(body);
    var cat = sel(LQ.category, [[0, 'All categories']].concat(state.boot.terms.categories.map(function (c) { return [c.id, c.name]; })), function (v) { LQ.category = parseInt(v, 10) || 0; LQ.page = 1; load(); });
    var search = h('input', { type: 'search', placeholder: 'Search articles', 'aria-label': 'Search articles', value: LQ.q, oninput: function () { LQ.q = this.value; LQ.page = 1; clearTimeout(search._t); search._t = setTimeout(load, 300); } });
    var bulk = h('select', { 'aria-label': 'Bulk action', onchange: function () { var a = this.value; this.value = ''; if (a) { runBulk(a); } } }, [h('option', { value: '', text: 'Bulk actions' }), h('option', { value: 'draft', text: 'Move to draft' }), h('option', { value: 'pending', text: 'Submit for review' }), h('option', { value: 'published', text: 'Publish' }), h('option', { value: 'archived', text: 'Archive' }), h('option', { value: 'trash', text: 'Move to trash' }), h('option', { value: 'restore', text: 'Restore from trash' })]);
    tools.appendChild(search); tools.appendChild(cat); tools.appendChild(bulk);
    function runBulk(a) {
      var ids = Object.keys(selected).filter(function (k) { return selected[k]; }).map(Number);
      if (!ids.length) { toast('Select at least one article first.', 'err'); return; }
      (a === 'trash' ? confirmBox('Move to trash?', ids.length + ' article(s) will be moved to the trash. You can restore them later.', 'Move to trash', true) : Promise.resolve(true)).then(function (ok) {
        if (!ok) { return; }
        api('bulk', { action: a, ids: ids }).then(function (r) { toast(r.done + ' updated' + (r.failed.length ? ', ' + r.failed.length + ' skipped: ' + r.failed[0].message : '') + '.', r.failed.length ? 'err' : 'ok'); load(); }).catch(fail);
      });
    }
    function load() {
      clear(body).appendChild(h('p', { class: 'nba-muted', text: 'Loading articles…' }));
      api('posts', LQ).then(function (r) {
        clear(tabs);
        [['all', 'All'], ['draft', 'Drafts'], ['pending', 'Pending'], ['scheduled', 'Scheduled'], ['published', 'Published'], ['archived', 'Archived'], ['trash', 'Trash']].forEach(function (t) {
          tabs.appendChild(h('button', { type: 'button', role: 'tab', 'aria-selected': LQ.status === t[0] ? 'true' : 'false', class: 'nba-tab' + (LQ.status === t[0] ? ' is-on' : ''), onclick: function () { LQ.status = t[0]; LQ.page = 1; load(); } }, [t[1] + ' ', h('small', { text: String(r.counts[t[0]] || 0) })]));
        });
        clear(body); selected = {};
        if (!r.items.length) { body.appendChild(h('div', { class: 'nba-empty' }, [h('h2', { text: LQ.q || LQ.status !== 'all' || LQ.category ? 'No articles match' : 'No articles yet' }), h('p', { text: LQ.q || LQ.status !== 'all' || LQ.category ? 'Try another filter or search.' : 'Create your first article to get started.' }), can('create') && !LQ.q ? h('a', { class: 'nba-btn is-primary', href: '#/edit/new', text: 'Write your first article' }) : null])); return; }
        var t = h('table', { class: 'nba-table' }), thead = h('thead'), tr = h('tr');
        tr.appendChild(h('th', null, [h('input', { type: 'checkbox', 'aria-label': 'Select all', onchange: function () { var on = this.checked; [].forEach.call(t.querySelectorAll('tbody input'), function (c) { c.checked = on; c.onchange(); }); } })]));
        ['Title', 'Status', 'Category', 'Author', 'Updated', ''].forEach(function (x) { tr.appendChild(h('th', { text: x })); }); thead.appendChild(tr); t.appendChild(thead);
        var tb = h('tbody');
        r.items.forEach(function (p) {
          var row = h('tr', null, [h('td', null, [h('input', { type: 'checkbox', 'aria-label': 'Select ' + p.title, onchange: function () { selected[p.id] = this.checked; } })]),
            h('td', { 'data-l': 'Title' }, [h('a', { class: 'nba-ttl', href: '#/edit/' + p.id, text: p.title }), p.has_working ? h('span', { class: 'nba-pill is-warn', text: 'Unpublished changes' }) : null]),
            h('td', { 'data-l': 'Status' }, [h('span', { class: 'nba-pill is-' + p.status, text: p.deleted_at ? 'Trash' : state.boot.statuses[p.status] || p.status })]),
            h('td', { 'data-l': 'Category', text: p.category ? p.category.name : '—' }), h('td', { 'data-l': 'Author', text: p.author ? p.author.name : '—' }), h('td', { 'data-l': 'Updated', text: when(p.updated_at) }),
            h('td', { class: 'nba-act' }, [p.status === 'published' && !p.deleted_at ? h('a', { href: p.url, target: '_blank', rel: 'noopener', 'aria-label': 'View ' + p.title, text: 'View' }) : null, !p.deleted_at ? btn('Duplicate', function () { api('post_duplicate', { id: p.id }).then(function (x) { toast('Duplicated as a draft.'); location.hash = '#/edit/' + x.post.id; }).catch(fail); }, 'is-sm', { 'aria-label': 'Duplicate ' + p.title }) : btn('Restore', function () { api('post_restore', { id: p.id }).then(function () { toast('Restored.'); load(); }).catch(fail); }, 'is-sm', { 'aria-label': 'Restore ' + p.title }),
              !p.deleted_at ? btn('Trash', function () { confirmBox('Move “' + p.title + '” to trash?', 'It will no longer be visible on the public blog. You can restore it from the Trash tab.', 'Move to trash', true).then(function (ok) { if (ok) { api('post_trash', { id: p.id }).then(function () { toast('Moved to trash.'); load(); }).catch(fail); } }); }, 'is-sm is-danger-o', { 'aria-label': 'Trash ' + p.title }) : (can('delete') ? btn('Delete forever', function () { confirmBox('Permanently delete “' + p.title + '”?', 'This cannot be undone.', 'Delete forever', true).then(function (ok) { if (ok) { api('post_purge', { id: p.id }).then(function () { toast('Deleted.'); load(); }).catch(fail); } }); }, 'is-sm is-danger-o', { 'aria-label': 'Delete ' + p.title + ' forever' }) : null)])]);
          tb.appendChild(row);
        });
        t.appendChild(tb); body.appendChild(h('div', { class: 'nba-tw' }, [t]));
        if (r.pages > 1) { var pg = h('div', { class: 'nba-pager' }); pg.appendChild(btn('‹ Prev', function () { LQ.page--; load(); }, '', { disabled: LQ.page <= 1 })); pg.appendChild(h('span', { text: 'Page ' + LQ.page + ' of ' + r.pages + ' · ' + r.total + ' articles' })); pg.appendChild(btn('Next ›', function () { LQ.page++; load(); }, '', { disabled: LQ.page >= r.pages })); body.appendChild(pg); }
      }).catch(function (e) { clear(body).appendChild(h('div', { class: 'nba-empty' }, [h('h2', { text: 'Could not load articles' }), h('p', { text: (e && e.message) || '' }), btn('Try again', load, 'is-primary')])); });
    }
    load();
  }

  // ───────────────────────── block editors ─────────────────────────
  var BLOCK_NAMES = { text: 'Text section', steps: 'Numbered steps', cards: 'Info cards', checklist: 'Checklist', image: 'Image', callout: 'Callout', quote: 'Quote', faq: 'FAQ', links: 'Popular links', testimonials: 'Testimonials', listcols: 'Popular list (columns)', cta: 'Call-to-action band', form: 'Request form' };
  var WIDE = { testimonials: 1, links: 1, cta: 1, listcols: 1 };
  var CAT = null;
  // TRACE: an items[] editor → items, factory for a new row, row renderer, onchange → add / remove / reorder controls around each row
  function listEd(items, make, render, on, addLabel, min) {
    var wrap = h('div', { class: 'nba-items' });
    function draw() {
      clear(wrap);
      items.forEach(function (it, i) {
        var row = h('div', { class: 'nba-item' }, [h('div', { class: 'nba-item-b' }, [render(it, i, function () { on(); })]), h('div', { class: 'nba-item-c' }, [
          btn('↑', function () { if (i > 0) { items.splice(i - 1, 0, items.splice(i, 1)[0]); on(); draw(); } }, 'is-sm', { 'aria-label': 'Move up', disabled: i === 0 }),
          btn('↓', function () { if (i < items.length - 1) { items.splice(i + 1, 0, items.splice(i, 1)[0]); on(); draw(); } }, 'is-sm', { 'aria-label': 'Move down', disabled: i === items.length - 1 }),
          btn('✕', function () { if (items.length > (min || 0)) { items.splice(i, 1); on(); draw(); } }, 'is-sm is-danger-o', { 'aria-label': 'Remove item', disabled: items.length <= (min || 0) })])]);
        wrap.appendChild(row);
      });
      wrap.appendChild(btn('+ ' + (addLabel || 'Add item'), function () { items.push(make()); on(); draw(); }, 'is-sm'));
    }
    draw(); return wrap;
  }
  var ICONS = function () { return state.boot.icons.map(function (i) { return [i, i]; }); };
  // TRACE: block editor → one block object, change callback → the type-specific form (mutates block.data in place and calls on())
  function blockForm(b, on) {
    var d = b.data, f = document.createDocumentFragment(), add = function (x) { f.appendChild(x); };
    var T = function (label, key, hint) { return field(label, inp(d[key], function (v) { d[key] = v; on(); }), hint); };
    var R = function (label, key) { return h('div', { class: 'nba-f' }, [h('label', { text: label }), rte(d[key], function (v) { d[key] = v; on(); }, label)]); };
    switch (b.type) {
      case 'text': add(T('Heading', 'heading')); add(field('Heading level', sel(d.level, [['h2', 'Main (H2)'], ['h3', 'Sub (H3)']], function (v) { d.level = v; on(); }))); add(R('Content', 'body')); break;
      case 'steps': add(T('Heading', 'heading')); add(T('Intro line', 'intro')); add(listEd(d.items, function () { return { title: 'New step', text: '' }; }, function (it, i, c) { return h('div', null, [field('Step title', inp(it.title, function (v) { it.title = v; c(); })), h('div', { class: 'nba-f' }, [h('label', { text: 'Step details' }), rte(it.text, function (v) { it.text = v; c(); }, 'Step details')])]); }, on, 'Add step', 1)); break;
      case 'cards': add(T('Heading', 'heading')); add(T('Intro line', 'intro')); add(field('Columns', sel(d.columns, [[2, '2'], [3, '3']], function (v) { d.columns = parseInt(v, 10); on(); }))); add(listEd(d.items, function () { return { icon: 'info', title: 'Card title', text: '' }; }, function (it, i, c) { return h('div', null, [field('Icon', sel(it.icon, ICONS(), function (v) { it.icon = v; c(); })), field('Title', inp(it.title, function (v) { it.title = v; c(); })), field('Text', area(it.text, function (v) { it.text = v; c(); }, 2))]); }, on, 'Add card', 1)); break;
      case 'checklist': add(T('Heading', 'heading')); add(listEd(d.items, function () { return ''; }, function (it, i, c) { return field('Item', inp(it, function (v) { d.items[i] = v; c(); })); }, on, 'Add item', 1)); break;
      case 'image': add(imageField(d, on)); add(field('Width', sel(d.width, [['content', 'Article width'], ['wide', 'Wide']], function (v) { d.width = v; on(); }))); add(T('Alt text', 'alt', 'Describe the image for people who cannot see it. Leave blank to use the library alt text.')); add(T('Caption', 'caption')); add(T('Link (optional)', 'link')); break;
      case 'callout': add(field('Style', sel(d.tone, [['info', 'Information'], ['warn', 'Warning'], ['success', 'Success']], function (v) { d.tone = v; on(); }))); add(T('Title', 'title')); add(R('Text', 'text')); break;
      case 'quote': add(field('Quote', area(d.text, function (v) { d.text = v; on(); }, 3))); add(T('Attribution', 'cite')); break;
      case 'faq': add(T('Heading', 'heading')); add(listEd(d.items, function () { return { q: 'New question?', a: '' }; }, function (it, i, c) { return h('div', null, [field('Question', inp(it.q, function (v) { it.q = v; c(); })), h('div', { class: 'nba-f' }, [h('label', { text: 'Answer' }), rte(it.a, function (v) { it.a = v; c(); }, 'Answer')])]); }, on, 'Add question', 1)); break;
      case 'links': add(T('Heading', 'heading')); add(listEd(d.items, function () { return { label: 'New link', url: '/' }; }, function (it, i, c) { return h('div', { class: 'nba-two' }, [field('Label', inp(it.label, function (v) { it.label = v; c(); })), field('Address', inp(it.url, function (v) { it.url = v; c(); }))]); }, on, 'Add link', 1)); break;
      case 'listcols': add(T('Heading', 'heading')); add(field('Columns', sel(d.columns, [[2, '2'], [3, '3'], [4, '4']], function (v) { d.columns = parseInt(v, 10); on(); }))); add(listEd(d.items, function () { return { label: 'New name', url: '' }; }, function (it, i, c) { return h('div', { class: 'nba-two' }, [field('Name', inp(it.label, function (v) { it.label = v; c(); })), field('Address (optional)', inp(it.url, function (v) { it.url = v; c(); }))]); }, on, 'Add name', 1)); add(h('div', { class: 'nba-two' }, [T('Button label', 'button_label'), T('Button address', 'button_url')])); break;
      case 'testimonials': add(T('Small line above heading', 'kicker')); add(T('Heading', 'heading')); add(listEd(d.items, function () { return { quote: '', name: '', role: '' }; }, function (it, i, c) { return h('div', null, [field('Quote', area(it.quote, function (v) { it.quote = v; c(); }, 2)), h('div', { class: 'nba-two' }, [field('Name', inp(it.name, function (v) { it.name = v; c(); })), field('Role / city', inp(it.role, function (v) { it.role = v; c(); }))])]); }, on, 'Add testimonial', 1)); break;
      case 'cta': add(T('Heading', 'heading')); add(field('Text', area(d.text, function (v) { d.text = v; on(); }, 2))); add(h('div', { class: 'nba-two' }, [T('Button label', 'button_label'), T('Button address', 'button_url')])); add(h('div', { class: 'nba-two' }, [T('Second button label', 'button2_label'), T('Second button address', 'button2_url')])); break;
      case 'form': add(T('Form heading', 'title')); add(field('Service', serviceSel(d.service, function (v) { d.service = v; on(); }), 'Pre-select a service, or leave open for visitors to choose.')); break;
    }
    if (!WIDE[b.type]) { add(field('Short menu label (optional)', inp(b.toc || '', function (v) { b.toc = v; on(); }), 'Shown in the “On this page” menu instead of the heading. Example: PRICING')); }
    return f;
  }
  function serviceSel(val, on) { return sel(val || '', [['', 'Visitor chooses the service']].concat((state.boot.services || []).map(function (s) { return [s.slug, s.name]; })), on); }
  // TRACE: image fields → data object holding {media}, change callback → preview + Choose/Remove buttons that open the library
  function imageField(d, on, key) {
    key = key || 'media'; var pv = h('div', { class: 'nba-imgpv' });
    function draw() {
      clear(pv);
      if (d[key]) { pv.appendChild(h('img', { src: d._url || '', alt: '' })); }
      pv.appendChild(btn(d[key] ? 'Replace image' : 'Choose image', function () { pickMedia().then(function (m) { if (m) { d[key] = m.id; d._url = m.thumb || m.url; if (!d.alt && key === 'media' && m.alt) { d.alt = m.alt; } on(); draw(); } }); }, 'is-sm'));
      if (d[key]) { pv.appendChild(btn('Remove', function () { d[key] = 0; d._url = ''; on(); draw(); }, 'is-sm is-danger-o')); }
    }
    draw(); return h('div', { class: 'nba-f' }, [h('label', { text: 'Image' }), pv]);
  }

  // ───────────────────────── editor ─────────────────────────
  // TRACE: #/edit/new|ID → loads (or creates an empty model) → full editor: content, blocks, layout, SEO, organize, publish, history; every change sets the dirty flag
  function viewEditor(id) {
    var P, can = function (p) { return state.boot.me.admin || state.boot.me.perms.indexOf(p) > -1; }, canPublish = can('publish'), tab = 'publish', mainCol, sideCol, titleEl;
    main.appendChild(h('p', { class: 'nba-muted', text: 'Loading…' }));
    var start = id === 'new' ? Promise.resolve({ post: { id: 0, version: 0, status: 'draft', title: '', subtitle: '', slug: '', intro: '', blocks: [], layout: clone(state.boot.layout_defaults), seo: { title: '', description: '', canonical: '', og_title: '', og_description: '', og_image: 0, twitter_card: 'summary_large_image', noindex: 0, focus: '' }, featured_media: 0, category_id: 0, tag_ids: [], author_user: 0, featured: null, category: null, tags: [], has_working: false, url: '' }, can_edit: true }) : api('post_get', { id: id });
    start.then(function (r) { P = r.post; if (!r.can_edit && P.id) { toast('You can view this article but not edit it.', 'err'); } P.new_tags = []; build(); }).catch(function (e) { clear(main).appendChild(h('div', { class: 'nba-empty' }, [h('h2', { text: 'Article not available' }), h('p', { text: (e && e.message) || '' }), h('a', { class: 'nba-btn', href: '#/', text: 'Back to articles' })])); });
    function touch() { setDirty(true); }
    function payload() { return { id: P.id, version: P.version, title: P.title, subtitle: P.subtitle, slug: P.slug, intro: P.intro, blocks: P.blocks.map(function (b) { var c = clone(b); delete c.data._url; return c; }), layout: P.layout, seo: P.seo, featured_media: P.featured_media, category_id: P.category_id, tag_ids: P.tag_ids, new_tags: P.new_tags }; }
    // TRACE: Save → payload → server (permission + optimistic lock) → replaces local model, clears dirty flag; on a version conflict offers reload
    function save(thenFn) {
      if (!P.title.trim()) { toast('Add a title first.', 'err'); titleEl.focus(); return Promise.reject(); }
      return api('post_save', { data: payload() }).then(function (r) { var wasNew = !P.id; P = r.post; P.new_tags = []; setDirty(false); toast(P.status === 'published' ? 'Changes saved (not live until you publish them).' : 'Saved.'); if (wasNew) { lastHash = '#/edit/' + P.id; history.replaceState(null, '', lastHash); } build(); if (thenFn) { thenFn(); } return P; })
        .catch(function (e) { if (e && e.code === 'conflict') { modal('This article changed elsewhere', 'Someone else saved a newer version while you were editing. Reload to see theirs (your unsaved edits will be lost), or keep editing and copy your text first.', [{ label: 'Keep editing', value: false }, { label: 'Reload latest', value: true, cls: 'is-primary' }]).then(function (v) { if (v) { setDirty(false); route(true); } }); } else { fail(e); } throw e; });
    }
    function status(to, extra) { return function () { (state.dirty || !P.id ? save() : Promise.resolve()).then(function () { return api('post_transition', Object.assign({ id: P.id, to: to }, extra || {})); }).then(function (r) { P = r.post; P.new_tags = []; setDirty(false); toast('Status: ' + (state.boot.statuses[P.status] || P.status) + '.'); build(); }).catch(function (e) { if (e && e.message) { fail(e); } }); }; }
    function build() {
      clear(main);
      var ro = P.id && !can('edit');
      var bar = h('div', { class: 'nba-bar' }, [h('a', { href: '#/', class: 'nba-back', text: '← Articles' }), h('span', { class: 'nba-pill is-' + P.status, text: P.id ? state.boot.statuses[P.status] : 'New draft' }), P.has_working ? h('span', { class: 'nba-pill is-warn', text: 'Unpublished changes' }) : null]);
      main.appendChild(bar);
      var cols = h('div', { class: 'nba-cols' }); mainCol = h('div', { class: 'nba-colm' }); sideCol = h('div', { class: 'nba-cols-s' }); cols.appendChild(mainCol); cols.appendChild(sideCol); main.appendChild(cols);
      titleEl = inp(P.title, function (v) { P.title = v; touch(); }, { class: 'nba-title', placeholder: 'Article title', 'aria-label': 'Article title', maxlength: 300 });
      mainCol.appendChild(h('div', { class: 'nba-card' }, [titleEl, inp(P.subtitle, function (v) { P.subtitle = v; touch(); }, { class: 'nba-subtitle', placeholder: 'Short subtitle shown under the title', 'aria-label': 'Subtitle', maxlength: 500 }),
        h('div', { class: 'nba-slugrow' }, [h('span', { text: state.boot.public_base ? '/' + state.boot.public_base + '/' : '/' }), inp(P.slug, function (v) { P.slug = v; touch(); }, { placeholder: 'url-slug (generated from the title)', 'aria-label': 'URL slug' })]),
        h('div', { class: 'nba-f' }, [h('label', { text: 'Introduction' }), rte(P.intro, function (v) { P.intro = v; touch(); }, 'Introduction')])]));
      var bl = h('div', { class: 'nba-blocks' }); mainCol.appendChild(bl);
      function drawBlocks() {
        clear(bl);
        if (!P.blocks.length) { bl.appendChild(h('div', { class: 'nba-empty' }, [h('p', { text: 'No sections yet. Add your first section below.' })])); }
        P.blocks.forEach(function (b, i) {
          var open = b._open !== false;
          var head = h('div', { class: 'nba-bh' }, [h('button', { type: 'button', class: 'nba-bt', 'aria-expanded': open ? 'true' : 'false', onclick: function () { b._open = !open; drawBlocks(); } }, [h('span', { text: BLOCK_NAMES[b.type] || b.type }), h('small', { text: WIDE[b.type] ? 'Full-width band' : 'In article' })]),
            h('span', { class: 'nba-bc' }, [btn('↑', function () { if (i) { P.blocks.splice(i - 1, 0, P.blocks.splice(i, 1)[0]); touch(); drawBlocks(); } }, 'is-sm', { 'aria-label': 'Move section up', disabled: !i }), btn('↓', function () { if (i < P.blocks.length - 1) { P.blocks.splice(i + 1, 0, P.blocks.splice(i, 1)[0]); touch(); drawBlocks(); } }, 'is-sm', { 'aria-label': 'Move section down', disabled: i === P.blocks.length - 1 }),
              btn('Duplicate', function () { var c = clone(b); c.id = uid(); P.blocks.splice(i + 1, 0, c); touch(); drawBlocks(); }, 'is-sm', { 'aria-label': 'Duplicate section' }), btn('Delete', function () { confirmBox('Delete this section?', 'The “' + (BLOCK_NAMES[b.type] || b.type) + '” section will be removed from the article.', 'Delete section', true).then(function (ok) { if (ok) { P.blocks.splice(i, 1); touch(); drawBlocks(); } }); }, 'is-sm is-danger-o', { 'aria-label': 'Delete section' })])]);
          var card = h('div', { class: 'nba-card nba-block' }, [head]);
          if (open) { var body = h('div', { class: 'nba-bb' }); body.appendChild(blockForm(b, touch)); card.appendChild(body); }
          bl.appendChild(card);
        });
        var menu = h('div', { class: 'nba-addrow' }, [h('strong', { text: 'Add a section' })]);
        Object.keys(BLOCK_NAMES).forEach(function (t) { menu.appendChild(btn(BLOCK_NAMES[t], function () { var m = clone(CAT[t]); m.id = uid(); P.blocks.push(m); touch(); drawBlocks(); }, 'is-sm')); });
        bl.appendChild(menu);
      }
      CAT = state.boot.catalogue;
      drawBlocks();
      panel();
    }
    function panel() {
      clear(sideCol);
      var tabs = h('div', { class: 'nba-ptabs', role: 'tablist' }), body = h('div', { class: 'nba-card nba-pbody' });
      [['publish', 'Publish'], ['organize', 'Organize'], ['layout', 'Layout'], ['seo', 'SEO'], ['history', 'History']].forEach(function (t) { tabs.appendChild(h('button', { type: 'button', role: 'tab', 'aria-selected': tab === t[0] ? 'true' : 'false', class: 'nba-ptab' + (tab === t[0] ? ' is-on' : ''), text: t[1], onclick: function () { tab = t[0]; panel(); } })); });
      sideCol.appendChild(tabs); sideCol.appendChild(body);
      ({ publish: pPublish, organize: pOrganize, layout: pLayout, seo: pSeo, history: pHistory })[tab](body);
    }
    function pPublish(b) {
      var live = P.status === 'published';
      b.appendChild(h('p', { class: 'nba-muted', text: P.id ? 'Status: ' + state.boot.statuses[P.status] + (P.published_at ? ' · ' + when(P.published_at) : '') : 'Not saved yet.' }));
      var act = h('div', { class: 'nba-actions' });
      act.appendChild(btn(live ? 'Save changes' : 'Save draft', function () { save().catch(function () {}); }, 'is-primary'));
      if (P.id) { act.appendChild(h('a', { class: 'nba-btn', target: '_blank', rel: 'noopener', href: P.url + (P.url.indexOf('?') > -1 ? '&' : '?') + 'preview=1', text: 'Preview', onclick: function (e) { if (state.dirty) { e.preventDefault(); save().then(function () { window.open(P.url + (P.url.indexOf('?') > -1 ? '&' : '?') + 'preview=1', '_blank', 'noopener'); }).catch(function () {}); } } })); }
      if (P.id && can('edit')) { act.appendChild(h('a', { class: 'nba-btn', target: '_blank', rel: 'noopener', href: P.url + (P.url.indexOf('?') > -1 ? '&' : '?') + 'preview=1&edit=1', text: 'Edit on page' })); }
      if (P.id) {
        if (live) {
          if (P.has_working && canPublish) { act.appendChild(btn('Publish changes', function () { (state.dirty ? save() : Promise.resolve()).then(function () { return api('post_publish_working', { id: P.id }); }).then(function (r) { P = r.post; P.new_tags = []; setDirty(false); toast('Changes are now live.'); build(); }).catch(function (e) { if (e && e.message) { fail(e); } }); }, 'is-success')); }
          if (P.has_working) { act.appendChild(btn('Discard changes', function () { confirmBox('Discard unpublished changes?', 'The live article stays as it is; your saved edits are removed.', 'Discard', true).then(function (ok) { if (ok) { api('post_discard_working', { id: P.id }).then(function (r) { P = r.post; P.new_tags = []; setDirty(false); toast('Changes discarded.'); build(); }).catch(fail); } }); }, 'is-danger-o')); }
          act.appendChild(h('a', { class: 'nba-btn', target: '_blank', rel: 'noopener', href: P.url, text: 'View live' }));
          if (canPublish) { act.appendChild(btn('Unpublish', function () { confirmBox('Unpublish this article?', 'It will disappear from the public blog and return to draft.', 'Unpublish', true).then(function (ok) { if (ok) { status('draft')(); } }); }, 'is-danger-o')); }
        } else {
          if (canPublish) { act.appendChild(btn('Publish now', status('published'), 'is-success')); b.appendChild(act); var dt = h('input', { type: 'datetime-local', 'aria-label': 'Schedule date and time' }); b.appendChild(field('Or schedule', dt, 'Uses your browser’s time zone.')); b.appendChild(btn('Schedule', function () { if (!dt.value) { toast('Choose a date and time.', 'err'); return; } var d = new Date(dt.value); if (isNaN(d) || d <= new Date()) { toast('Choose a time in the future.', 'err'); return; } status('scheduled', { scheduled_at: d.toISOString().slice(0, 19).replace('T', ' ') })(); }, '')); return pExtra(b); }
          else if (P.status === 'draft') { act.appendChild(btn('Submit for review', status('pending'), '')); }
          if (P.status === 'scheduled' && canPublish) { act.appendChild(btn('Unschedule', status('draft'), '')); }
          if (P.status === 'pending' && canPublish) { act.appendChild(btn('Back to draft', status('draft'), '')); }
        }
      }
      b.appendChild(act); pExtra(b);
    }
    function pExtra(b) { if (P.id && can('delete') || P.id) { b.appendChild(h('hr')); b.appendChild(btn('Move to trash', function () { confirmBox('Move to trash?', '“' + P.title + '” will be removed from the public blog. You can restore it from the Trash tab.', 'Move to trash', true).then(function (ok) { if (ok) { api('post_trash', { id: P.id }).then(function () { setDirty(false); toast('Moved to trash.'); location.hash = '#/'; }).catch(fail); } }); }, 'is-danger-o')); } }
    function pOrganize(b) {
      var T = state.boot.terms;
      var cs = sel(P.category_id || 0, [[0, 'No category']].concat(T.categories.map(function (c) { return [c.id, c.name]; })), function (v) { P.category_id = parseInt(v, 10) || 0; touch(); });
      b.appendChild(field('Category', cs));
      if (can('taxonomy')) { var nc = h('input', { type: 'text', placeholder: 'New category name', 'aria-label': 'New category name' }); b.appendChild(h('div', { class: 'nba-inline' }, [nc, btn('Add', function () { if (!nc.value.trim()) { return; } api('term_save', { data: { type: 'category', name: nc.value } }).then(function (r) { state.boot.terms = { categories: r.categories, tags: r.tags }; P.category_id = r.term.id; touch(); panel(); }).catch(fail); }, 'is-sm')])); }
      var tg = h('div', { class: 'nba-tags' });
      T.tags.forEach(function (t) { tg.appendChild(check(t.name, P.tag_ids.indexOf(t.id) > -1, function (on) { var i = P.tag_ids.indexOf(t.id); if (on && i < 0) { P.tag_ids.push(t.id); } if (!on && i > -1) { P.tag_ids.splice(i, 1); } touch(); })); });
      b.appendChild(h('div', { class: 'nba-f' }, [h('label', { text: 'Tags' }), tg.childNodes.length ? tg : h('small', { text: 'No tags yet.' })]));
      var nt = h('input', { type: 'text', placeholder: 'Add new tags (comma separated)', 'aria-label': 'New tags', value: P.new_tags.join(', '), oninput: function () { P.new_tags = this.value.split(',').map(function (s) { return s.trim(); }).filter(Boolean); touch(); } }); b.appendChild(nt);
      var fi = { media: P.featured_media, _url: P.featured ? (P.featured.thumb || P.featured.url) : '' };
      b.appendChild(h('hr')); b.appendChild(h('strong', { text: 'Featured image' })); b.appendChild(imageField(fi, function () { P.featured_media = fi.media; touch(); }));
      b.appendChild(h('small', { class: 'nba-muted', text: 'Alt text and caption come from the image library (edit them in the picker).' }));
      b.appendChild(h('p', { class: 'nba-muted', text: 'Author: ' + (P.author ? P.author.name : 'you') }));
    }
    function pLayout(b) {
      var L = P.layout, hero = L.hero, F = L.forms;
      b.appendChild(h('strong', { text: 'Hero' })); b.appendChild(field('Small label above the title', inp(hero.eyebrow, function (v) { hero.eyebrow = v; touch(); }), 'Leave blank to show the category.'));
      b.appendChild(h('div', { class: 'nba-f' }, [h('label', { text: 'Highlight chips' }), listEd(hero.chips, function () { return 'New highlight'; }, function (it, i, c) { return inp(it, function (v) { hero.chips[i] = v; c(); }, { 'aria-label': 'Chip ' + (i + 1) }); }, touch, 'Add chip', 0)]));
      b.appendChild(h('div', { class: 'nba-two' }, [field('Button 1 label', inp(hero.cta1.label, function (v) { hero.cta1.label = v; touch(); })), field('Button 1 address', inp(hero.cta1.url, function (v) { hero.cta1.url = v; touch(); }))]));
      b.appendChild(h('div', { class: 'nba-two' }, [field('Button 2 label', inp(hero.cta2.label, function (v) { hero.cta2.label = v; touch(); })), field('Button 2 address', inp(hero.cta2.url, function (v) { hero.cta2.url = v; touch(); }))]));
      b.appendChild(h('hr')); b.appendChild(h('strong', { text: 'Request forms' }));
      [['hero', 'Form in the hero (right of the title)'], ['aside', 'Form in the sidebar']].forEach(function (k) { var f = F[k[0]]; b.appendChild(h('div', { class: 'nba-sub' }, [check(k[1], f.enabled, function (v) { f.enabled = v ? 1 : 0; touch(); }), field('Form heading', inp(f.title, function (v) { f.title = v; touch(); })), field('Service', serviceSel(f.service, function (v) { f.service = v; touch(); }))])); });
      b.appendChild(h('hr')); b.appendChild(h('strong', { text: 'Trust strip' }));
      b.appendChild(listEd(L.trust, function () { return { icon: 'shield', text: 'New point' }; }, function (it, i, c) { return h('div', { class: 'nba-two' }, [field('Icon', sel(it.icon, ICONS(), function (v) { it.icon = v; c(); })), field('Text', inp(it.text, function (v) { it.text = v; c(); }))]); }, touch, 'Add point', 0));
      b.appendChild(h('hr')); b.appendChild(check('Show “On this page” contents list', L.toc, function (v) { L.toc = v ? 1 : 0; touch(); }));
      b.appendChild(h('hr')); b.appendChild(h('strong', { text: 'Why choose us (sidebar)' })); b.appendChild(field('Heading', inp(L.why.title, function (v) { L.why.title = v; touch(); })));
      b.appendChild(listEd(L.why.items, function () { return { icon: 'check', text: 'New point' }; }, function (it, i, c) { return inp(it.text, function (v) { it.text = v; c(); }, { 'aria-label': 'Point ' + (i + 1) }); }, touch, 'Add point', 0));
      b.appendChild(h('hr')); b.appendChild(h('strong', { text: 'Latest articles' })); b.appendChild(check('Show latest articles at the bottom', L.latest.show, function (v) { L.latest.show = v ? 1 : 0; touch(); })); b.appendChild(field('Heading', inp(L.latest.title, function (v) { L.latest.title = v; touch(); }))); b.appendChild(field('How many', sel(L.latest.count, [[3, '3'], [6, '6']], function (v) { L.latest.count = parseInt(v, 10); touch(); })));
    }
    function pSeo(b) {
      if (!can('seo')) { b.appendChild(h('p', { class: 'nba-muted', text: 'You do not have permission to edit SEO settings.' })); return; }
      var S = P.seo, ser = h('div', { class: 'nba-serp' });
      function drawSerp() { clear(ser); ser.appendChild(h('div', { class: 'nba-serp-t', text: (S.title || P.title || 'Article title').slice(0, 70) })); ser.appendChild(h('div', { class: 'nba-serp-u', text: location.origin + '/' + (state.boot.public_base || '') + '/' + (P.slug || 'url-slug') + '/' })); ser.appendChild(h('div', { class: 'nba-serp-d', text: (S.description || P.subtitle || '').slice(0, 160) })); }
      b.appendChild(ser); drawSerp();
      b.appendChild(field('SEO title', inp(S.title, function (v) { S.title = v; drawSerp(); touch(); }, { maxlength: 70 }), 'Up to 70 characters. Blank uses the article title.'));
      b.appendChild(field('Meta description', area(S.description, function (v) { S.description = v; drawSerp(); touch(); }, 3), 'Up to 160 characters is best.'));
      b.appendChild(field('Canonical address', inp(S.canonical, function (v) { S.canonical = v; touch(); }, { type: 'url', placeholder: 'https://…' }), 'Only change this if the same article lives at another address.'));
      b.appendChild(field('Focus keyword', inp(S.focus, function (v) { S.focus = v; touch(); })));
      b.appendChild(h('hr')); b.appendChild(h('strong', { text: 'Social sharing' }));
      b.appendChild(field('Share title', inp(S.og_title, function (v) { S.og_title = v; touch(); }))); b.appendChild(field('Share description', area(S.og_description, function (v) { S.og_description = v; touch(); }, 2)));
      var og = { og_image: S.og_image, _url: '' }; b.appendChild(imageField(og, function () { S.og_image = og.og_image; touch(); }, 'og_image'));
      b.appendChild(field('Card style', sel(S.twitter_card, [['summary_large_image', 'Large image'], ['summary', 'Small summary']], function (v) { S.twitter_card = v; touch(); })));
      b.appendChild(check('Ask search engines not to index this article', S.noindex, function (v) { S.noindex = v ? 1 : 0; touch(); }));
    }
    function pHistory(b) {
      if (!P.id) { b.appendChild(h('p', { class: 'nba-muted', text: 'Save the article to start its history.' })); return; }
      var box = h('div'); b.appendChild(box); box.appendChild(h('p', { class: 'nba-muted', text: 'Loading…' }));
      Promise.all([api('post_revisions', { id: P.id }), api('post_audit', { id: P.id })]).then(function (r) {
        clear(box); box.appendChild(h('strong', { text: 'Saved versions' }));
        if (!r[0].items.length) { box.appendChild(h('p', { class: 'nba-muted', text: 'No saved versions yet.' })); }
        r[0].items.forEach(function (v) { box.appendChild(h('div', { class: 'nba-rev' }, [h('span', { text: 'v' + v.rev_no + ' · ' + when(v.created_at) + ' · ' + v.user }), can('edit') ? btn('Restore', function () { confirmBox('Restore version ' + v.rev_no + '?', 'This replaces the current text with that version (as an unpublished change).', 'Restore', false).then(function (ok) { if (ok) { api('post_restore_revision', { rev: v.id }).then(function (x) { P = x.post; P.new_tags = []; setDirty(false); toast('Version restored.'); build(); }).catch(fail); } }); }, 'is-sm') : null])); });
        box.appendChild(h('hr')); box.appendChild(h('strong', { text: 'Activity' }));
        r[1].items.forEach(function (a) { box.appendChild(h('div', { class: 'nba-log', text: when(a.created_at) + ' · ' + (a.user || a.user_name || 'System') + ' · ' + a.action + (a.detail ? ' · ' + a.detail : '') })); });
      }).catch(fail);
    }
  }

  // ───────────────────────── taxonomy ─────────────────────────
  // TRACE: #/taxonomy → categories and tags with add / rename / delete (delete confirmed; articles keep existing but lose that term) → live list
  function viewTax() {
    var can = state.boot.me.admin || state.boot.me.perms.indexOf('taxonomy') > -1;
    main.appendChild(h('div', { class: 'nba-head' }, [h('h1', { text: 'Categories & tags' })]));
    var wrap = h('div', { class: 'nba-two nba-top' }); main.appendChild(wrap);
    function box(type, title) {
      var card = h('div', { class: 'nba-card' }); wrap.appendChild(card);
      function draw() {
        clear(card); card.appendChild(h('h2', { text: title }));
        var list = state.boot.terms[type === 'category' ? 'categories' : 'tags'];
        if (!list.length) { card.appendChild(h('p', { class: 'nba-muted', text: 'Nothing here yet.' })); }
        list.forEach(function (t) {
          var nm = h('input', { type: 'text', value: t.name, 'aria-label': 'Name', disabled: !can }), saved = t.name;
          card.appendChild(h('div', { class: 'nba-trow' }, [nm, h('small', { text: t.cnt + ' live' }), can ? btn('Save', function () { api('term_save', { data: { id: t.id, type: type, name: nm.value, slug: t.slug } }).then(function (r) { state.boot.terms = { categories: r.categories, tags: r.tags }; toast('Saved.'); draw(); }).catch(fail); }, 'is-sm') : null, can ? btn('Delete', function () { confirmBox('Delete “' + saved + '”?', 'Articles keep their content but lose this ' + type + '.', 'Delete', true).then(function (ok) { if (ok) { api('term_delete', { id: t.id }).then(function (r) { state.boot.terms = { categories: r.categories, tags: r.tags }; toast('Deleted.'); draw(); }).catch(fail); } }); }, 'is-sm is-danger-o', { 'aria-label': 'Delete ' + saved }) : null]));
        });
        if (can) { var n = h('input', { type: 'text', placeholder: 'New ' + type + ' name', 'aria-label': 'New ' + type + ' name' }); card.appendChild(h('div', { class: 'nba-inline' }, [n, btn('Add', function () { if (!n.value.trim()) { toast('Enter a name.', 'err'); return; } api('term_save', { data: { type: type, name: n.value } }).then(function (r) { state.boot.terms = { categories: r.categories, tags: r.tags }; toast('Added.'); draw(); }).catch(fail); }, 'is-primary')])); }
      }
      draw();
    }
    box('category', 'Categories'); box('tag', 'Tags');
  }

  // ───────────────────────── media ─────────────────────────
  // TRACE: #/media → upload, search, edit alt/caption, delete (refused while used by an article, with the server's reason shown)
  function viewMedia() {
    var can = state.boot.me.admin || state.boot.me.perms.indexOf('media') > -1, q = '', page = 1, grid = h('div', { class: 'nba-mgrid is-big' }), file = h('input', { type: 'file', accept: 'image/jpeg,image/png,image/gif,image/webp', hidden: true, multiple: true });
    main.appendChild(h('div', { class: 'nba-head' }, [h('h1', { text: 'Media library' }), can ? btn('Upload images', function () { file.click(); }, 'is-primary') : null, file]));
    main.appendChild(h('div', { class: 'nba-tools' }, [h('input', { type: 'search', placeholder: 'Search images', 'aria-label': 'Search images', oninput: function () { q = this.value; page = 1; clearTimeout(grid._t); grid._t = setTimeout(load, 300); } })]));
    main.appendChild(h('div', { class: 'nba-card' }, [grid]));
    file.addEventListener('change', function () {
      var fs = [].slice.call(file.files); file.value = ''; var chain = Promise.resolve();
      fs.forEach(function (f) { chain = chain.then(function () { if (f.size > CFG.maxUpload) { toast(f.name + ' is larger than 10 MB.', 'err'); return; } return api('media_upload', {}, f).then(function () { toast(f.name + ' uploaded.'); }).catch(function (e) { toast(f.name + ': ' + ((e && e.message) || 'failed'), 'err'); }); }); });
      chain.then(function () { page = 1; load(); });
    });
    function load() {
      clear(grid).appendChild(h('p', { class: 'nba-muted', text: 'Loading…' }));
      api('media_list', { q: q, page: page }).then(function (r) {
        clear(grid); if (!r.items.length) { grid.appendChild(h('div', { class: 'nba-empty' }, [h('h2', { text: 'No images yet' }), h('p', { text: 'Upload images to use them in articles.' })])); return; }
        r.items.forEach(function (it) {
          var al = h('input', { type: 'text', value: it.alt || '', placeholder: 'Alt text', 'aria-label': 'Alt text for ' + (it.title || it.file), disabled: !can }), cp = h('input', { type: 'text', value: it.caption || '', placeholder: 'Caption', 'aria-label': 'Caption', disabled: !can });
          grid.appendChild(h('div', { class: 'nba-mcard' }, [h('img', { src: it.thumb || it.url, alt: '', loading: 'lazy' }), al, cp, can ? h('div', { class: 'nba-inline' }, [btn('Save', function () { api('media_update', { id: it.id, data: { title: it.title, alt: al.value, caption: cp.value } }).then(function () { toast('Saved.'); }).catch(fail); }, 'is-sm'), btn('Delete', function () { confirmBox('Delete this image?', 'It will be removed from the library. This is refused while an article still uses it.', 'Delete', true).then(function (ok) { if (ok) { api('media_delete', { id: it.id }).then(function () { toast('Deleted.'); load(); }).catch(fail); } }); }, 'is-sm is-danger-o')]) : null]));
        });
        if (r.pages > 1) { var pg = h('div', { class: 'nba-pager' }); pg.appendChild(btn('‹ Prev', function () { page--; load(); }, '', { disabled: page <= 1 })); pg.appendChild(h('span', { text: 'Page ' + page + ' of ' + r.pages })); pg.appendChild(btn('Next ›', function () { page++; load(); }, '', { disabled: page >= r.pages })); grid.appendChild(pg); }
      }).catch(fail);
    }
    load();
  }

  // ───────────────────────── profile ─────────────────────────
  function viewProfile() {
    var p = clone(state.boot.me.profile);
    main.appendChild(h('div', { class: 'nba-head' }, [h('h1', { text: 'My author profile' })]));
    var av = { avatar_media: 0, _url: p.avatar || '' };
    var c = h('div', { class: 'nba-card nba-narrow' }, [field('Display name', inp(p.name, function (v) { p.name = v; })), field('Job title', inp(p.title, function (v) { p.title = v; })), field('Short bio', area(p.bio, function (v) { p.bio = v; }, 4)), imageField(av, function () {}, 'avatar_media'),
      btn('Save profile', function () { var d = { name: p.name, job_title: p.title, bio: p.bio }; if (av.avatar_media) { d.avatar_media = av.avatar_media; } api('profile_save', { data: d }).then(function (r) { state.boot.me.profile = r.profile; toast('Profile saved.'); }).catch(fail); }, 'is-primary')]);
    main.appendChild(c);
  }

  // ───────────────────────── team (admin) ─────────────────────────
  // TRACE: #/team → staff accounts with a per-person blog switch and permission checkboxes; add a person (e-mails a set-password link); resend; admins/moderators shown as always-on
  function viewTeam() {
    main.appendChild(h('div', { class: 'nba-head' }, [h('h1', { text: 'Team access' }), btn('Add a person', addPerson, 'is-primary')]));
    var card = h('div', { class: 'nba-card' }), PERMS = {}; main.appendChild(card);
    function load() { clear(card).appendChild(h('p', { class: 'nba-muted', text: 'Loading…' })); api('team').then(function (r) { PERMS = r.perms; draw(r.items); }).catch(fail); }
    function draw(items) {
      clear(card);
      if (!items.length) { card.appendChild(h('div', { class: 'nba-empty' }, [h('h2', { text: 'No staff accounts yet' }), h('p', { text: 'Add a person to give them blog access.' })])); return; }
      items.forEach(function (u) {
        var perms = u.perms.slice(), row = h('div', { class: 'nba-team' }), on = u.enabled;
        var head = h('div', { class: 'nba-team-h' }, [h('div', null, [h('strong', { text: u.name }), h('small', { text: ' ' + u.email + ' · ' + u.role + (u.last_login ? ' · last sign-in ' + when(u.last_login) : '') })])]);
        row.appendChild(head);
        if (u.locked) { row.appendChild(h('p', { class: 'nba-muted', text: u.group === 'admin' ? 'Administrators always have full blog access.' : 'Moderators always have full blog access.' })); }
        else {
          row.appendChild(check('Can use the blog editor', on, function (v) { on = v; }));
          var pp = h('div', { class: 'nba-perms' }); Object.keys(PERMS).forEach(function (k) { pp.appendChild(check(PERMS[k], perms.indexOf(k) > -1, function (v) { var i = perms.indexOf(k); if (v && i < 0) { perms.push(k); } if (!v && i > -1) { perms.splice(i, 1); } })); }); row.appendChild(pp);
          row.appendChild(h('div', { class: 'nba-inline' }, [btn('Save access', function () { api('team_save', { data: { id: u.id, enabled: on, perms: perms } }).then(function (r) { toast('Access saved for ' + u.name + '.'); draw(r.items); }).catch(fail); }, 'is-sm is-primary'), btn('Resend sign-in e-mail', function () { api('team_resend', { id: u.id }).then(function (r) { toast(r.sent ? 'E-mail sent.' : 'The e-mail could not be sent.', r.sent ? 'ok' : 'err'); }).catch(fail); }, 'is-sm')]));
        }
        card.appendChild(row);
      });
    }
    function addPerson() {
      var f = { name: '', login: '', email: '', role: 'sbm_staff' };
      var b = h('div', null, [field('Full name', inp('', function (v) { f.name = v; })), field('Username', inp('', function (v) { f.login = v; })), field('E-mail', inp('', function (v) { f.email = v; }, { type: 'email' })), field('Role', sel(f.role, [['sbm_staff', 'Blog staff (limited by the permissions you choose)'], ['sbm_moderator', 'Moderator (full blog access)']], function (v) { f.role = v; }))]);
      modal('Add a person', b, [{ label: 'Cancel', value: false }, { label: 'Create and e-mail', value: true, cls: 'is-primary' }]).then(function (ok) { if (ok) { api('team_create', { data: f }).then(function (r) { toast('Account created. A set-password e-mail was sent.'); draw(r.items); }).catch(fail); } });
    }
    load();
  }

  // ───────────────────────── settings (admin) ─────────────────────────
  // TRACE: #/settings → blog-level options (public address, title, tagline, per page, accent colour, footer text, menu links, default share image, uninstall behaviour) → saved with server-side validation of the public address
  function viewSettings() {
    main.appendChild(h('div', { class: 'nba-head' }, [h('h1', { text: 'Blog settings' })]));
    var card = h('div', { class: 'nba-card nba-narrow' }); main.appendChild(card);
    api('settings_get').then(function (r) {
      var s = r.settings, og = { og: s.default_og_image, _url: '' };
      card.appendChild(field('Public blog address', inp(s.public_base, function (v) { s.public_base = v; }), 'Your blog lives at yoursite/' + s.public_base + '/. It must not match an existing page, category or dashboard address.'));
      card.appendChild(field('Blog name', inp(s.site_title, function (v) { s.site_title = v; }), 'Shown in the header, titles and footer. Blank uses the site name.'));
      card.appendChild(field('Tagline', inp(s.tagline, function (v) { s.tagline = v; })));
      card.appendChild(field('Articles per page', inp(s.per_page, function (v) { s.per_page = parseInt(v, 10) || 9; }, { type: 'number', min: 3, max: 30 })));
      card.appendChild(field('Accent colour', inp(s.accent, function (v) { s.accent = v; }, { type: 'color' })));
      card.appendChild(field('Footer text', area(s.footer_text, function (v) { s.footer_text = v; }, 2)));
      card.appendChild(h('div', { class: 'nba-f' }, [h('label', { text: 'Header menu links' }), listEd(s.nav_links = s.nav_links || [], function () { return { label: '', url: '' }; }, function (it, i, c) { return h('div', { class: 'nba-two' }, [field('Label', inp(it.label, function (v) { it.label = v; c(); })), field('Address', inp(it.url, function (v) { it.url = v; c(); }))]); }, function () {}, 'Add link', 0)]));
      card.appendChild(imageField(og, function () { s.default_og_image = og.og; }, 'og'));
      var c = s.chrome = s.chrome || {}; c.social = c.social || []; c.links = c.links || []; c.col2 = c.col2 || []; c.col3 = c.col3 || []; c.locations = c.locations || [];
      var lg = { og: c.logo || 0, _url: '' };
      var linkEd = function (arr) { return listEd(arr, function () { return { label: '', url: '' }; }, function (it, i, cc) { return h('div', { class: 'nba-two' }, [field('Label', inp(it.label, function (v) { it.label = v; cc(); })), field('Address', inp(it.url, function (v) { it.url = v; cc(); }))]); }, function () {}, 'Add link', 0); };
      var SOC = [['facebook', 'Facebook'], ['twitter', 'X / Twitter'], ['youtube', 'YouTube'], ['instagram', 'Instagram'], ['linkedin', 'LinkedIn'], ['whatsapp', 'WhatsApp']];
      card.appendChild(h('h2', { text: 'Site header and footer (Classic design)' }));
      card.appendChild(h('p', { class: 'nba-muted', text: 'The top bar and the footer shown on every public blog page.' }));
      card.appendChild(imageField(lg, function () { c.logo = lg.og; }, 'og'));
      card.appendChild(h('div', { class: 'nba-two' }, [field('Phone', inp(c.phone, function (v) { c.phone = v; })), field('Opening hours', inp(c.hours, function (v) { c.hours = v; }))]));
      card.appendChild(field('WhatsApp number (digits with country code)', inp(c.whatsapp, function (v) { c.whatsapp = v; }), 'Shows the floating WhatsApp button. Leave blank to hide it.'));
      card.appendChild(h('div', { class: 'nba-f' }, [h('label', { text: 'Social links' }), listEd(c.social, function () { return { type: 'facebook', url: '' }; }, function (it, i, cc) { return h('div', { class: 'nba-two' }, [field('Network', sel(it.type, SOC, function (v) { it.type = v; cc(); })), field('Address', inp(it.url, function (v) { it.url = v; cc(); }))]); }, function () {}, 'Add social link', 0)]));
      card.appendChild(field('First footer column title', inp(c.links_title, function (v) { c.links_title = v; }))); card.appendChild(linkEd(c.links));
      card.appendChild(field('Second column title', inp(c.col2_title, function (v) { c.col2_title = v; }))); card.appendChild(linkEd(c.col2));
      card.appendChild(field('Third column title', inp(c.col3_title, function (v) { c.col3_title = v; }))); card.appendChild(linkEd(c.col3));
      card.appendChild(h('div', { class: 'nba-two' }, [field('Subscribe title', inp(c.subscribe_title, function (v) { c.subscribe_title = v; })), field('Subscribe text', inp(c.subscribe_text, function (v) { c.subscribe_text = v; }))]));
      card.appendChild(field('Locations title', inp(c.locations_title, function (v) { c.locations_title = v; })));
      card.appendChild(listEd(c.locations, function () { return { city: '', address: '' }; }, function (it, i, cc) { return h('div', null, [field('City', inp(it.city, function (v) { it.city = v; cc(); })), field('Address', area(it.address, function (v) { it.address = v; cc(); }, 2))]); }, function () {}, 'Add location', 0));
      card.appendChild(field('Copyright line', inp(c.copyright, function (v) { c.copyright = v; })));
      card.appendChild(check('Delete all blog data when the plugin is deleted', s.delete_on_uninstall, function (v) { s.delete_on_uninstall = v ? 1 : 0; }));
      card.appendChild(btn('Save settings', function () { api('settings_save', { data: s }).then(function (r) { state.boot.public_base = r.settings.public_base; CFG.home = r.home_url; toast('Settings saved.'); }).catch(fail); }, 'is-primary'));
    }).catch(fail);
  }

  // ───────────────────────── start ─────────────────────────
  api('boot').then(function (b) { state.boot = b; shell(); route(true); }).catch(function (e) { clear(root).appendChild(h('div', { class: 'nba-empty' }, [h('h2', { text: 'The blog editor could not start' }), h('p', { text: (e && e.message) || 'Please reload the page.' }), btn('Reload', function () { location.reload(); }, 'is-primary')])); });
})();
