<?php
/**
 * Blog platform bootstrap — an independent publishing system inside the Services Hub plugin.
 * Own tables (nsh_blog_*), own media, own taxonomy, own URLs. It never reads, writes or lists wp_posts.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'NSH_BLOG_DIR', NSH_DIR . 'blog/' );

foreach ( array( 'db', 'access', 'audit', 'authors', 'terms', 'media', 'blocks', 'posts', 'settings', 'front', 'render', 'ajax', 'app', 'inline' ) as $nsh_blog_f ) {
    if ( file_exists( NSH_BLOG_DIR . 'includes/class-' . $nsh_blog_f . '.php' ) ) { require_once NSH_BLOG_DIR . 'includes/class-' . $nsh_blog_f . '.php'; }
}
unset( $nsh_blog_f );

// TRACE: plugin activation / version change → none → creates or upgrades the blog tables, registers the two blog roles, schedules publishing of due articles → void
function nsh_blog_install() {
    \NSH\Blog\DB::install();
    \NSH\Blog\Access::install_roles();
    if ( ! wp_next_scheduled( 'nsh_blog_publish_due' ) ) { wp_schedule_event( time() + 300, 'hourly', 'nsh_blog_publish_due' ); }
    update_option( 'nsh_flush_needed', 1, false );
}

// TRACE: init@1 → none → DB::ensure() installs/upgrades the tables only when the stored schema version differs from the code (upgrades without re-activation); roles re-asserted → void
add_action( 'init', function () {
    \NSH\Blog\DB::ensure();
    \NSH\Blog\Access::install_roles();
}, 1 );

add_action( 'nsh_blog_publish_due', array( '\NSH\Blog\Posts', 'publish_due' ) );

// TRACE: platform auth → staff role list → adds the roles of the existing Staff Blog Manager accounts so those users keep a staff dashboard login → array
add_filter( 'nsh_plat_staff_roles', function ( $roles ) { return array_values( array_unique( array_merge( (array) $roles, array( \NSH\Blog\Access::STAFF, \NSH\Blog\Access::MODERATOR ) ) ) ); } );

// TRACE: platform nav/redirect → user id → true when that account may use the blog CMS (admin group, moderator, or an enabled access row) → bool
function nsh_plat_blog_enabled_for( $uid = 0 ) { return \NSH\Blog\Access::enabled( (int) $uid ); }

add_action( 'nsh_plat_register_routes', array( '\NSH\Blog\Front', 'rewrite' ) );
add_filter( 'nsh_plat_route_signature', function ( $s ) { return $s . '|blog:' . \NSH\Blog\Settings::get( 'public_base' ); } );

// TRACE: platform router (/{admin|staff}-dashboard/blog/…) → route name → renders the blog CMS app; exits
function nsh_blog_render_app( $route ) { \NSH\Blog\App::render( $route === 'admin' ? 'admin' : 'staff' ); }

// TRACE: activation → none → switches off the stand-alone "Staff Blog Manager" plugin if it is active (this plugin replaces it; its data and WordPress posts are NOT touched, and it can be re-enabled from Plugins) → void
function nsh_blog_retire_legacy() {
    $legacy = 'staff-blog-manager/staff-blog-manager.php';
    if ( ! function_exists( 'is_plugin_active' ) ) { require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
    if ( is_plugin_active( $legacy ) ) { deactivate_plugins( $legacy, true ); update_option( 'nsh_legacy_sbm_retired', 1, false ); }
}
// TRACE: wp-admin → none → if the legacy plugin was re-enabled alongside this one, tells administrators to switch it off because both register the same blog staff roles and sign-in rules → prints a notice
add_action( 'admin_notices', function () {
    if ( ! current_user_can( 'activate_plugins' ) ) { return; }
    if ( ! function_exists( 'is_plugin_active' ) ) { require_once ABSPATH . 'wp-admin/includes/plugin.php'; }
    if ( is_plugin_active( 'staff-blog-manager/staff-blog-manager.php' ) ) { echo '<div class="notice notice-warning"><p><strong>Services Hub:</strong> the separate “Staff Blog Manager” plugin is active. Services Hub now includes its own blog platform, and running both blocks blog staff from signing in. Please deactivate “Staff Blog Manager” (your existing WordPress posts are not affected).</p></div>'; }
} );
