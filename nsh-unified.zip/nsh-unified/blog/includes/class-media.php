<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Media — the blog's own image library. Files live in uploads/nsh-blog/YYYY/MM/ and are tracked in nsh_blog_media;
 * nothing is added to the WordPress Media Library and no wp_posts attachment is created.
 */
final class Media {
    public const MAX_BYTES  = 10485760;
    public const MAX_PIXELS = 60000000;
    public const SIZES = array( 'thumb' => array( 400, 400, true ), 'medium' => array( 800, 0, false ), 'large' => array( 1600, 0, false ) );
    private const TYPES = array( 'image/jpeg' => 'jpg', 'image/png' => 'png', 'image/gif' => 'gif', 'image/webp' => 'webp' );

    // TRACE: storage → none → array( base dir, base url ) of the blog's upload folder, created with an index.php guard → array
    public static function dirs() {
        $u = wp_upload_dir( null, false );
        $dir = trailingslashit( $u['basedir'] ) . 'nsh-blog';
        if ( ! is_dir( $dir ) ) { wp_mkdir_p( $dir ); @file_put_contents( $dir . '/index.php', "<?php // Silence is golden.\n" ); }
        return array( $dir, trailingslashit( $u['baseurl'] ) . 'nsh-blog' );
    }

    // TRACE: upload endpoint → $_FILES entry, acting user → validates size, real MIME (finfo, not the client's claim), extension and pixel count → stores a randomised file, builds thumb/medium/large copies (re-encoded, so EXIF/GPS is dropped) → media item array | WP_Error
    //        edge: SVG/PDF/HTML/PHP rejected; unreadable images rejected; failed copy cleans up the row and file
    public static function upload( $file, $uid ) {
        global $wpdb;
        if ( empty( $file['tmp_name'] ) || ! is_uploaded_file( $file['tmp_name'] ) && ! ( defined( 'NSH_BLOG_TESTING' ) && NSH_BLOG_TESTING ) ) { return new \WP_Error( 'nsh_blog_up', 'No file was received.' ); }
        if ( ! empty( $file['error'] ) ) { return new \WP_Error( 'nsh_blog_up', 'The upload failed (code ' . (int) $file['error'] . ').' ); }
        if ( (int) $file['size'] > self::MAX_BYTES ) { return new \WP_Error( 'nsh_blog_up', 'Images can be at most 10 MB.' ); }
        $mime = function_exists( 'finfo_open' ) ? (string) finfo_file( finfo_open( FILEINFO_MIME_TYPE ), $file['tmp_name'] ) : '';
        if ( ! isset( self::TYPES[ $mime ] ) ) { return new \WP_Error( 'nsh_blog_up', 'Only JPG, PNG, GIF and WebP images are allowed.' ); }
        $info = @getimagesize( $file['tmp_name'] );
        if ( ! $info || $info[0] < 1 || $info[1] < 1 ) { return new \WP_Error( 'nsh_blog_up', 'That file is not a readable image.' ); }
        if ( $info[0] * $info[1] > self::MAX_PIXELS ) { return new \WP_Error( 'nsh_blog_up', 'That image is too large (over 60 megapixels).' ); }
        list( $dir, $url ) = self::dirs();
        $sub = gmdate( 'Y/m' );
        wp_mkdir_p( "$dir/$sub" );
        $stem = sanitize_file_name( pathinfo( (string) $file['name'], PATHINFO_FILENAME ) );
        $stem = substr( $stem !== '' ? $stem : 'image', 0, 60 );
        $base = $stem . '-' . wp_generate_password( 8, false, false );
        $ext  = self::TYPES[ $mime ];
        $rel  = "$sub/$base.$ext";
        $abs  = "$dir/$rel";
        if ( ! @copy( $file['tmp_name'], $abs ) ) { return new \WP_Error( 'nsh_blog_up', 'Could not store the file.' ); }
        @chmod( $abs, 0644 );
        $sizes = array();
        foreach ( self::SIZES as $key => $s ) {
            $ed = wp_get_image_editor( $abs );
            if ( is_wp_error( $ed ) ) { break; }
            $cur = $ed->get_size();
            if ( $cur['width'] <= $s[0] && ( ! $s[2] ) ) { continue; }
            $ed->resize( $s[0], $s[1] ?: null, $s[2] );
            $out = "$dir/$sub/$base-$key.$ext";
            $saved = $ed->save( $out, $mime );
            if ( ! is_wp_error( $saved ) ) { $sizes[ $key ] = array( 'file' => "$sub/" . basename( $saved['path'] ), 'w' => (int) $saved['width'], 'h' => (int) $saved['height'] ); }
        }
        $ok = $wpdb->insert( DB::t( 'media' ), array( 'file' => $rel, 'mime' => $mime, 'width' => (int) $info[0], 'height' => (int) $info[1], 'bytes' => (int) filesize( $abs ), 'title' => sanitize_text_field( $stem ), 'alt' => '', 'caption' => '', 'sizes' => wp_json_encode( $sizes ), 'uploaded_by' => (int) $uid, 'created_at' => DB::now() ) );
        if ( ! $ok ) {
            @unlink( $abs ); foreach ( $sizes as $s ) { @unlink( "$dir/" . $s['file'] ); }
            return new \WP_Error( 'nsh_blog_db', 'Could not record the image.' );
        }
        $id = (int) $wpdb->insert_id;
        Audit::log( 0, 'media_upload', '#' . $id . ' ' . $rel );
        return self::item( $id );
    }

    private static function row( $id ) { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . DB::t( 'media' ) . ' WHERE id=%d', (int) $id ), ARRAY_A ); }

    // TRACE: library/editor/render → media id → {id,url,thumb,medium,large,width,height,alt,caption,title,bytes,mime,uploaded_at} or null → array|null
    public static function item( $id ) {
        $r = self::row( $id );
        if ( ! $r ) { return null; }
        list( , $url ) = self::dirs();
        $sizes = json_decode( (string) $r['sizes'], true ) ?: array();
        $o = array( 'id' => (int) $r['id'], 'url' => "$url/" . $r['file'], 'width' => (int) $r['width'], 'height' => (int) $r['height'], 'alt' => $r['alt'], 'caption' => $r['caption'], 'title' => $r['title'], 'bytes' => (int) $r['bytes'], 'mime' => $r['mime'], 'created_at' => $r['created_at'], 'sizes' => array() );
        foreach ( self::SIZES as $k => $_ ) {
            $o[ $k ] = isset( $sizes[ $k ] ) ? "$url/" . $sizes[ $k ]['file'] : $o['url'];
            $o['sizes'][ $k ] = isset( $sizes[ $k ] ) ? array( 'url' => "$url/" . $sizes[ $k ]['file'], 'w' => $sizes[ $k ]['w'], 'h' => $sizes[ $k ]['h'] ) : array( 'url' => $o['url'], 'w' => $o['width'], 'h' => $o['height'] );
        }
        return $o;
    }
    // TRACE: renderers → media id, size key → URL of that size (falls back to the original) or '' → string
    public static function url( $id, $size = 'large' ) { $i = self::item( $id ); return $i ? ( isset( $i[ $size ] ) ? $i[ $size ] : $i['url'] ) : ''; }

    // TRACE: public/editor rendering → media id, options {size, alt, class, eager, sizes_attr, caption} → escaped <img> (with srcset and intrinsic width/height) or '' → string
    public static function img( $id, $o = array() ) {
        $i = self::item( $id );
        if ( ! $i ) { return ''; }
        $size = isset( $o['size'] ) ? $o['size'] : 'large';
        $s = isset( $i['sizes'][ $size ] ) ? $i['sizes'][ $size ] : array( 'url' => $i['url'], 'w' => $i['width'], 'h' => $i['height'] );
        $set = array(); foreach ( array( 'thumb', 'medium', 'large' ) as $k ) { if ( ! empty( $i['sizes'][ $k ]['w'] ) ) { $set[ $i['sizes'][ $k ]['w'] ] = esc_url( $i['sizes'][ $k ]['url'] ) . ' ' . (int) $i['sizes'][ $k ]['w'] . 'w'; } }
        $alt = isset( $o['alt'] ) ? (string) $o['alt'] : (string) $i['alt'];
        $h = '<img src="' . esc_url( $s['url'] ) . '" width="' . (int) $s['w'] . '" height="' . (int) $s['h'] . '" alt="' . esc_attr( $alt ) . '" data-media="' . (int) $id . '"';
        if ( count( $set ) > 1 ) { $h .= ' srcset="' . implode( ', ', $set ) . '" sizes="' . esc_attr( isset( $o['sizes_attr'] ) ? $o['sizes_attr'] : '(max-width: 800px) 100vw, 800px' ) . '"'; }
        $h .= ' loading="' . ( ! empty( $o['eager'] ) ? 'eager' : 'lazy' ) . '" decoding="async"' . ( ! empty( $o['class'] ) ? ' class="' . esc_attr( $o['class'] ) . '"' : '' ) . '>';
        return $h;
    }

    // TRACE: library → search text, page, per-page → newest-first items + total → array( items, total, pages )
    public static function lib( $search = '', $page = 1, $per = 24 ) {
        global $wpdb;
        $t = DB::t( 'media' ); $where = '1=1'; $args = array();
        if ( $search !== '' ) { $like = '%' . $wpdb->esc_like( $search ) . '%'; $where .= ' AND (title LIKE %s OR alt LIKE %s OR caption LIKE %s OR file LIKE %s)'; $args = array( $like, $like, $like, $like ); }
        $total = (int) ( $args ? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE $where", $args ) ) : $wpdb->get_var( "SELECT COUNT(*) FROM $t" ) );
        $page = max( 1, (int) $page ); $per = max( 1, min( 100, (int) $per ) );
        $a2 = array_merge( $args, array( $per, ( $page - 1 ) * $per ) );
        $ids = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $t WHERE $where ORDER BY id DESC LIMIT %d OFFSET %d", $a2 ) ) ?: array();
        return array( 'items' => array_values( array_filter( array_map( array( __CLASS__, 'item' ), $ids ) ) ), 'total' => $total, 'pages' => max( 1, (int) ceil( $total / $per ) ) );
    }

    // TRACE: media details form → id, {title, alt, caption} → saves the descriptive fields (alt text stays reusable everywhere the image is placed unless overridden in a block) → item | WP_Error
    public static function update( $id, $in ) {
        global $wpdb;
        if ( ! self::row( $id ) ) { return new \WP_Error( 'nsh_blog_media', 'Image not found.' ); }
        $ok = $wpdb->update( DB::t( 'media' ), array( 'title' => sanitize_text_field( (string) ( isset( $in['title'] ) ? $in['title'] : '' ) ), 'alt' => mb_substr( sanitize_text_field( (string) ( isset( $in['alt'] ) ? $in['alt'] : '' ) ), 0, 300 ), 'caption' => mb_substr( sanitize_text_field( (string) ( isset( $in['caption'] ) ? $in['caption'] : '' ) ), 0, 500 ) ), array( 'id' => (int) $id ) );
        if ( $ok === false ) { return new \WP_Error( 'nsh_blog_db', 'Could not save.' ); }
        return self::item( $id );
    }

    // TRACE: where-used scan → media id → number of non-deleted articles that reference this image (featured, block data, layout, SEO image) → int
    public static function usage( $id ) {
        global $wpdb;
        $id = (int) $id; $p = DB::t( 'posts' );
        // word-boundary match so media 1 never matches media 12: "<key>":12 or "<key>":"12" followed by a non-digit
        $re = '"(media|image|og_image|avatar)":"?' . $id . '"?([^0-9]|$)';
        return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $p WHERE deleted_at IS NULL AND (featured_media=%d OR blocks REGEXP %s OR layout REGEXP %s OR seo REGEXP %s)", $id, $re, $re, $re ) );
    }

    // TRACE: library "delete" → id → refuses while the image is still used by an article; otherwise removes row and all files → true | WP_Error
    public static function delete( $id ) {
        global $wpdb;
        $r = self::row( $id );
        if ( ! $r ) { return new \WP_Error( 'nsh_blog_media', 'Image not found.' ); }
        $n = self::usage( $id );
        if ( $n > 0 ) { return new \WP_Error( 'nsh_blog_media_used', 'This image is used in ' . $n . ' article' . ( $n > 1 ? 's' : '' ) . '. Replace it there first.' ); }
        list( $dir ) = self::dirs();
        $sizes = json_decode( (string) $r['sizes'], true ) ?: array();
        $ok = $wpdb->delete( DB::t( 'media' ), array( 'id' => (int) $id ) );
        if ( ! $ok ) { return new \WP_Error( 'nsh_blog_db', 'Could not delete the image.' ); }
        @unlink( "$dir/" . $r['file'] ); foreach ( $sizes as $s ) { @unlink( "$dir/" . $s['file'] ); }
        Audit::log( 0, 'media_delete', '#' . (int) $id );
        return true;
    }
}
