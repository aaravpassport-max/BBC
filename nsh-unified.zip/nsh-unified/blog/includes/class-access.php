<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Access — who may do what in the blog CMS. Sign-in itself is the platform's unified login; this class only answers permission questions.
 * Admin group (administrator, nsh_admin, configured admin roles) → everything. Staff group → only when switched on for them, with the permissions chosen in Team.
 */
final class Access {
    public const STAFF = 'sbm_staff';
    public const MODERATOR = 'sbm_moderator';
    public const PERMS = array(
        'create'   => 'Write new articles',
        'edit'     => 'Edit their own articles',
        'edit_all' => 'Edit everyone\'s articles',
        'publish'  => 'Publish, schedule and unpublish',
        'delete'   => 'Delete articles',
        'media'    => 'Upload and manage media',
        'seo'      => 'Edit SEO and social settings',
        'taxonomy' => 'Manage categories and tags',
    );
    public const DEFAULT_PERMS = array( 'create', 'edit', 'media', 'seo' );
    private static $rows = array();

    // TRACE: install → none → registers the two blog roles (kept from the earlier Staff Blog Manager so existing accounts keep working) → void
    public static function install_roles() {
        if ( ! get_role( self::STAFF ) )     { add_role( self::STAFF, 'Blog Staff', array( 'read' => true ) ); }
        if ( ! get_role( self::MODERATOR ) ) { add_role( self::MODERATOR, 'Blog Moderator', array( 'read' => true ) ); }
    }

    // TRACE: every check → user id (0 = current) → true for the platform's admin group → bool
    public static function is_admin( $uid = 0 ) { return function_exists( 'nsh_plat_group' ) && nsh_plat_group( $uid ) === 'admin'; }

    private static function row( $uid ) {
        if ( ! isset( self::$rows[ $uid ] ) ) {
            global $wpdb;
            self::$rows[ $uid ] = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . DB::t( 'access' ) . ' WHERE user_id=%d', $uid ), ARRAY_A ) ?: array();
        }
        return self::$rows[ $uid ];
    }
    public static function flush() { self::$rows = array(); }

    private static function has_role( $uid, $role ) { $u = get_userdata( $uid ); return $u && in_array( $role, (array) $u->roles, true ); }

    // TRACE: dashboards nav + gates → user id → true when this account may open the Blog CMS at all → bool
    //        edge: moderators are always on; staff need their access row switched on; clients and role-less accounts never
    public static function enabled( $uid = 0 ) {
        $uid = $uid ? (int) $uid : get_current_user_id();
        if ( ! $uid ) { return false; }
        if ( self::is_admin( $uid ) ) { return true; }
        if ( ! function_exists( 'nsh_plat_group' ) || nsh_plat_group( $uid ) !== 'staff' ) { return false; }
        if ( self::has_role( $uid, self::MODERATOR ) ) { return true; }
        $r = self::row( $uid );
        return ! empty( $r['enabled'] );
    }

    // TRACE: permission checks → permission key, user id → effective permission list evaluated (admin: all; moderator: everything except none; staff: row perms) → bool
    public static function can( $perm, $uid = 0 ) {
        $uid = $uid ? (int) $uid : get_current_user_id();
        if ( ! self::enabled( $uid ) ) { return false; }
        if ( self::is_admin( $uid ) ) { return true; }
        if ( self::has_role( $uid, self::MODERATOR ) ) { return true; }
        $r = self::row( $uid );
        $p = ! empty( $r['perms'] ) ? json_decode( $r['perms'], true ) : self::DEFAULT_PERMS;
        return is_array( $p ) && in_array( $perm, $p, true );
    }
    public static function perms_of( $uid ) {
        if ( self::is_admin( $uid ) || self::has_role( $uid, self::MODERATOR ) ) { return array_keys( self::PERMS ); }
        $r = self::row( $uid );
        $p = ! empty( $r['perms'] ) ? json_decode( $r['perms'], true ) : self::DEFAULT_PERMS;
        return is_array( $p ) ? array_values( array_intersect( $p, array_keys( self::PERMS ) ) ) : array();
    }

    // TRACE: AJAX/route guard → permission → exits with 403 JSON when the signed-in account lacks it → void
    public static function guard( $perm = 'edit' ) {
        if ( ! is_user_logged_in() ) { wp_send_json_error( array( 'message' => 'Please sign in again.', 'code' => 'auth' ), 401 ); }
        $ok = $perm === 'admin' ? self::is_admin() : ( $perm === 'any' ? self::enabled() : self::can( $perm ) );
        if ( ! $ok ) { wp_send_json_error( array( 'message' => 'You do not have permission to do that.', 'code' => 'perm' ), 403 ); }
    }

    // TRACE: editor/list → post array, user id → whether the user may edit THIS article (own with "edit", any with "edit_all") → bool
    public static function can_edit_post( $post, $uid = 0 ) {
        $uid = $uid ? (int) $uid : get_current_user_id();
        if ( self::can( 'edit_all', $uid ) ) { return true; }
        return self::can( 'edit', $uid ) && (int) $post['created_by'] === $uid;
    }
    public static function can_see_post( $post, $uid = 0 ) { return self::can_edit_post( $post, $uid ); }

    // TRACE: list queries → user id → SQL fragment limiting a staff member without "edit_all" to articles they created → array( sql, args )
    public static function visibility_sql( $uid = 0 ) {
        $uid = $uid ? (int) $uid : get_current_user_id();
        if ( self::can( 'edit_all', $uid ) ) { return array( '', array() ); }
        return array( ' AND p.created_by = %d', array( $uid ) );
    }

    // TRACE: Team screen → none → every staff-group and admin-group account with its blog switch + permissions → array of rows
    public static function team() {
        $roles = array_merge( array( 'administrator', 'nsh_admin', 'nsh_manager', self::STAFF, self::MODERATOR ), (array) nsh_plat_get( 'admin_roles' ), (array) nsh_plat_get( 'staff_roles' ) );
        $out = array();
        foreach ( get_users( array( 'role__in' => array_values( array_unique( $roles ) ), 'orderby' => 'display_name', 'number' => 500 ) ) as $u ) {
            $g = nsh_plat_group( $u->ID );
            if ( $g === '' ) { continue; }
            $r = self::row( $u->ID );
            $locked = $g === 'admin' || self::has_role( $u->ID, self::MODERATOR );
            $out[] = array(
                'id' => (int) $u->ID, 'name' => $u->display_name, 'email' => $u->user_email, 'login' => $u->user_login,
                'role' => implode( ', ', array_map( function ( $x ) { $o = get_role( $x ); return isset( wp_roles()->role_names[ $x ] ) ? translate_user_role( wp_roles()->role_names[ $x ] ) : $x; }, (array) $u->roles ) ),
                'group' => $g, 'enabled' => self::enabled( $u->ID ), 'locked' => $locked,
                'perms' => self::perms_of( $u->ID ), 'last_login' => (string) get_user_meta( $u->ID, 'nsh_last_login', true ),
            );
        }
        return $out;
    }

    // TRACE: Team "save" → user id, enabled, perms, acting admin → writes the access row (whitelisted perms); returns true|WP_Error
    //        edge: only staff-group users can be switched on; admins/moderators are always on and cannot be edited
    public static function save_user( $uid, $enabled, $perms, $by = 0 ) {
        global $wpdb;
        $uid = (int) $uid;
        if ( ! get_userdata( $uid ) ) { return new \WP_Error( 'nsh_blog_user', 'That account does not exist.' ); }
        if ( nsh_plat_group( $uid ) !== 'staff' ) { return new \WP_Error( 'nsh_blog_group', 'Only staff accounts can be given blog access here.' ); }
        $perms = array_values( array_intersect( array_map( 'sanitize_key', (array) $perms ), array_keys( self::PERMS ) ) );
        $ok = $wpdb->replace( DB::t( 'access' ), array( 'user_id' => $uid, 'enabled' => $enabled ? 1 : 0, 'perms' => wp_json_encode( $perms ), 'updated_by' => (int) $by, 'updated_at' => DB::now() ), array( '%d', '%d', '%s', '%d', '%s' ) );
        self::flush();
        if ( $ok === false ) { return new \WP_Error( 'nsh_blog_db', 'Could not save access.' ); }
        Audit::log( 0, 'access', 'user ' . $uid . ' ' . ( $enabled ? 'on' : 'off' ) . ' [' . implode( ',', $perms ) . ']' );
        return true;
    }

    // TRACE: Team "add person" → username, email, display name, role (blog staff|moderator) → creates the account, switches blog access on, e-mails a set-password link → int user id | WP_Error
    //        edge: duplicate username/e-mail rejected by wp_insert_user; the account is created even if the mail fails (admin can resend)
    public static function create_member( $in, $by = 0 ) {
        $role = isset( $in['role'] ) && in_array( $in['role'], array( self::STAFF, self::MODERATOR ), true ) ? $in['role'] : self::STAFF;
        $login = sanitize_user( (string) ( isset( $in['login'] ) ? $in['login'] : '' ), true );
        $email = sanitize_email( (string) ( isset( $in['email'] ) ? $in['email'] : '' ) );
        if ( $login === '' || ! is_email( $email ) ) { return new \WP_Error( 'nsh_blog_new', 'Enter a username and a valid e-mail address.' ); }
        $id = wp_insert_user( array( 'user_login' => $login, 'user_email' => $email, 'display_name' => sanitize_text_field( (string) ( isset( $in['name'] ) ? $in['name'] : $login ) ), 'user_pass' => wp_generate_password( 24 ), 'role' => $role ) );
        if ( is_wp_error( $id ) ) { return $id; }
        self::save_user( $id, true, self::DEFAULT_PERMS, $by );
        Authors::for_user( $id, true );
        self::send_setup_email( get_userdata( $id ) );
        return (int) $id;
    }

    // TRACE: create_member / Team "resend" → user → mails a one-time set-password link + the unified sign-in address → bool
    public static function send_setup_email( $u ) {
        $key = get_password_reset_key( $u );
        if ( is_wp_error( $key ) ) { return false; }
        $link = network_site_url( 'wp-login.php?action=rp&key=' . rawurlencode( $key ) . '&login=' . rawurlencode( $u->user_login ), 'login' );
        $site = wp_specialchars_decode( get_option( 'blogname' ), ENT_QUOTES );
        $body = sprintf( "Hello %s,\n\nAn account was created for you on %s.\n\nUsername: %s\n\nSet your password (link works once and expires):\n%s\n\nThen sign in at:\n%s\n", $u->display_name, $site, $u->user_login, $link, nsh_plat_login_url() );
        return (bool) wp_mail( $u->user_email, '[' . $site . '] Your account', $body );
    }
}
