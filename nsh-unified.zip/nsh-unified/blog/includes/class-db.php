<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * DB — the blog's OWN tables. Nothing here reads or writes wp_posts, wp_terms, wp_term_relationships, wp_postmeta or the Media Library:
 * the blog is a separate publishing system that only borrows WordPress for hosting and user authentication.
 *
 *   nsh_blog_posts      articles (content blocks, layout, SEO and status)
 *   nsh_blog_terms      categories and tags
 *   nsh_blog_post_terms article ↔ term links
 *   nsh_blog_media      the blog's own media library (files live in uploads/nsh-blog/)
 *   nsh_blog_revisions  immutable snapshots + the unpublished "working copy" of a live article
 *   nsh_blog_authors    public author profiles
 *   nsh_blog_access     per-user blog switch + permissions
 *   nsh_blog_audit      append-only log
 */
final class DB {
    public const VERSION = '1.0.0';
    private const OPT = 'nsh_blog_db_version';
    public const TABLES = array( 'posts', 'terms', 'post_terms', 'media', 'revisions', 'authors', 'access', 'audit' );

    // TRACE: every repository → short name → "{$wpdb->prefix}nsh_blog_{name}" ($wpdb declared global first) → string
    public static function t( $name ) { global $wpdb; return $wpdb->prefix . 'nsh_blog_' . $name; }

    // TRACE: init → compares stored DB version → runs install() once per version bump (upgrade path with no manual step) → void
    public static function ensure() { if ( get_option( self::OPT ) !== self::VERSION ) { self::install(); } }

    // TRACE: activation/ensure → dbDelta for every table → stores the version only when all tables exist (failure retries next request) → bool
    public static function install() {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        foreach ( self::defs( $wpdb->get_charset_collate() ) as $sql ) { dbDelta( $sql ); }
        foreach ( self::TABLES as $n ) {
            if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', self::t( $n ) ) ) !== self::t( $n ) ) {
                error_log( '[NSH Blog] could not create ' . self::t( $n ) . ': ' . $wpdb->last_error );
                return false;
            }
        }
        update_option( self::OPT, self::VERSION, false );
        return true;
    }

    private static function defs( $c ) {
        $p = self::t( '' );
        return array(
"CREATE TABLE {$p}posts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  slug VARCHAR(190) NOT NULL,
  title VARCHAR(300) NOT NULL DEFAULT '',
  subtitle VARCHAR(500) NOT NULL DEFAULT '',
  intro TEXT NULL,
  blocks LONGTEXT NULL,
  layout LONGTEXT NULL,
  seo LONGTEXT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'draft',
  featured_media BIGINT UNSIGNED NOT NULL DEFAULT 0,
  author_user BIGINT UNSIGNED NOT NULL DEFAULT 0,
  category_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
  published_at DATETIME NULL,
  scheduled_at DATETIME NULL,
  version INT UNSIGNED NOT NULL DEFAULT 1,
  views BIGINT UNSIGNED NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
  updated_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  deleted_at DATETIME NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY slug (slug),
  KEY status_pub (status,published_at),
  KEY category (category_id),
  KEY author (author_user),
  KEY deleted (deleted_at)
) {$c};",
"CREATE TABLE {$p}terms (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  type VARCHAR(12) NOT NULL DEFAULT 'category',
  name VARCHAR(190) NOT NULL,
  slug VARCHAR(190) NOT NULL,
  description VARCHAR(500) NOT NULL DEFAULT '',
  sort_order INT NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY type_slug (type,slug)
) {$c};",
"CREATE TABLE {$p}post_terms (
  post_id BIGINT UNSIGNED NOT NULL,
  term_id BIGINT UNSIGNED NOT NULL,
  PRIMARY KEY  (post_id,term_id),
  KEY term (term_id)
) {$c};",
"CREATE TABLE {$p}media (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  file VARCHAR(300) NOT NULL,
  mime VARCHAR(60) NOT NULL DEFAULT '',
  width INT UNSIGNED NOT NULL DEFAULT 0,
  height INT UNSIGNED NOT NULL DEFAULT 0,
  bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
  title VARCHAR(190) NOT NULL DEFAULT '',
  alt VARCHAR(300) NOT NULL DEFAULT '',
  caption VARCHAR(500) NOT NULL DEFAULT '',
  sizes TEXT NULL,
  uploaded_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  PRIMARY KEY  (id),
  KEY created (created_at)
) {$c};",
"CREATE TABLE {$p}revisions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id BIGINT UNSIGNED NOT NULL,
  kind VARCHAR(12) NOT NULL DEFAULT 'manual',
  rev_no INT UNSIGNED NOT NULL DEFAULT 0,
  snapshot LONGTEXT NOT NULL,
  base_version INT UNSIGNED NOT NULL DEFAULT 0,
  created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  PRIMARY KEY  (id),
  KEY post_kind (post_id,kind),
  KEY post_rev (post_id,rev_no)
) {$c};",
"CREATE TABLE {$p}authors (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
  name VARCHAR(190) NOT NULL,
  slug VARCHAR(190) NOT NULL,
  job_title VARCHAR(190) NOT NULL DEFAULT '',
  bio TEXT NULL,
  avatar_media BIGINT UNSIGNED NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL,
  PRIMARY KEY  (id),
  UNIQUE KEY slug (slug),
  UNIQUE KEY user_id (user_id)
) {$c};",
"CREATE TABLE {$p}access (
  user_id BIGINT UNSIGNED NOT NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 0,
  perms TEXT NULL,
  updated_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
  updated_at DATETIME NOT NULL,
  PRIMARY KEY  (user_id),
  KEY enabled (enabled)
) {$c};",
"CREATE TABLE {$p}audit (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  post_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
  user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
  action VARCHAR(40) NOT NULL,
  detail VARCHAR(400) NOT NULL DEFAULT '',
  created_at DATETIME NOT NULL,
  PRIMARY KEY  (id),
  KEY post_time (post_id,created_at)
) {$c};",
        );
    }

    // TRACE: uninstall (only when "delete data" is on) → drops every blog table and uploaded blog file folder → void
    public static function drop() {
        global $wpdb;
        foreach ( self::TABLES as $n ) { $wpdb->query( 'DROP TABLE IF EXISTS ' . self::t( $n ) ); }
        delete_option( self::OPT );
    }

    // TRACE: writers → none → UTC "Y-m-d H:i:s" timestamp (all blog dates are stored in UTC and shown in the site timezone) → string
    public static function now() { return gmdate( 'Y-m-d H:i:s' ); }
}
