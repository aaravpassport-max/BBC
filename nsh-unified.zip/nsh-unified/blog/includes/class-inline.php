<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Inline — loads the on-page editor bundle ONLY for a signed-in account that is allowed to edit the article being viewed.
 * Visitors (and signed-in accounts without edit rights) receive neither the script, the stylesheet nor the editor nonce.
 */
final class Inline {
    public static function init() { add_action( 'nsh_blog_public_assets', array( __CLASS__, 'assets' ), 10, 2 ); }

    // TRACE: Front::render_page → edit context (null for visitors) → enqueues the editor assets and localises {ajax, nonce, post, flags}; returns without touching anything when there is no context
    public static function assets( $ctx, $meta ) {
        if ( ! is_array( $ctx ) || ! is_user_logged_in() || ! Access::can( 'edit' ) ) { return; }
        $d = NSH_DIR . 'blog/assets/';
        wp_enqueue_style( 'nsh-blog-inline', NSH_URL . 'blog/assets/blog-inline.css', array( 'nsh-blog-public' ), file_exists( $d . 'blog-inline.css' ) ? filemtime( $d . 'blog-inline.css' ) : NSH_VER );
        wp_enqueue_script( 'nsh-blog-inline', NSH_URL . 'blog/assets/blog-inline.js', array( 'nsh-blog-front' ), file_exists( $d . 'blog-inline.js' ) ? filemtime( $d . 'blog-inline.js' ) : NSH_VER, true );
        wp_localize_script( 'nsh-blog-inline', 'NSHINLINE', array(
            'ajax' => admin_url( 'admin-ajax.php' ), 'nonce' => Ajax::nonce(), 'post' => (int) $ctx['post'], 'startEdit' => ! empty( $ctx['start_edit'] ), 'preview' => ! empty( $ctx['preview'] ),
            'canPublish' => Access::can( 'publish' ), 'canMedia' => Access::can( 'media' ), 'maxUpload' => Media::MAX_BYTES,
            'fullEditor' => nsh_plat_dash_url( Access::is_admin() ? 'admin' : 'staff', nsh_plat_get( 'blog_slug' ) . '/#/edit/' . (int) $ctx['post'] ),
        ) );
    }
}
Inline::init();
