<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Settings — site-level blog options (stored as one option; edited in the Blog app → Settings, admins only). */
final class Settings {
    public const KEY = 'nsh_blog_settings';
    private static $cache = null;

    // TRACE: get() → none → defaults for every setting → array
    public static function defaults() {
        return array(
            'public_base'     => 'insights',
            'site_title'      => '',
            'tagline'         => '',
            'per_page'        => 9,
            'accent'          => '#1d4ed8',
            'footer_text'     => '',
            'nav_links'       => array(),
            'default_og_image'=> 0,
            'layout_defaults' => Blocks::layout_defaults(),
            'chrome' => array(
                'logo' => 0, 'phone' => '', 'hours' => '', 'whatsapp' => '', 'social' => array(),
                'links_title' => 'Useful Links', 'links' => array(),
                'col2_title' => 'Services', 'col2' => array(), 'col3_title' => '', 'col3' => array(),
                'subscribe_title' => 'Subscribe Now', 'subscribe_text' => '',
                'locations_title' => 'OUR LOCATIONS', 'locations' => array(), 'copyright' => '',
            ),
            'delete_on_uninstall' => 0,
        );
    }
    // TRACE: readers → key ('' = all) → stored value merged over defaults, request-cached → mixed
    public static function get( $key = '' ) {
        if ( self::$cache === null ) { $raw = get_option( self::KEY, array() ); self::$cache = array_merge( self::defaults(), is_array( $raw ) ? $raw : array() ); }
        return $key === '' ? self::$cache : ( isset( self::$cache[ $key ] ) ? self::$cache[ $key ] : null );
    }
    // TRACE: renderers → none → header/footer content with every key present (stored value merged over defaults) → array
    public static function chrome() { $d = self::defaults(); $c = self::get( 'chrome' ); return array_merge( $d['chrome'], is_array( $c ) ? $c : array() ); }
    public const SOCIAL = array( 'facebook', 'twitter', 'youtube', 'instagram', 'linkedin', 'whatsapp' );
    // TRACE: settings save → untrusted header/footer content → whitelisted: phone/hours/text trimmed, social types limited to SOCIAL, every link label+URL validated (Blocks::url), lists capped → array
    private static function clean_chrome( $c ) {
        $links = function ( $v, $max ) { $o = array(); foreach ( array_slice( is_array( $v ) ? array_values( $v ) : array(), 0, $max ) as $l ) { if ( ! is_array( $l ) ) { continue; } $lb = Blocks::txt( isset( $l['label'] ) ? $l['label'] : '', 80 ); if ( $lb !== '' ) { $o[] = array( 'label' => $lb, 'url' => Blocks::url( isset( $l['url'] ) ? $l['url'] : '' ) ); } } return $o; };
        $t = function ( $k, $n ) use ( $c ) { return Blocks::txt( isset( $c[ $k ] ) ? $c[ $k ] : '', $n ); };
        $m = isset( $c['logo'] ) ? (int) $c['logo'] : 0;
        $soc = array(); foreach ( array_slice( isset( $c['social'] ) && is_array( $c['social'] ) ? array_values( $c['social'] ) : array(), 0, 6 ) as $x ) { if ( is_array( $x ) && isset( $x['type'] ) && in_array( $x['type'], self::SOCIAL, true ) && ( $u = Blocks::url( isset( $x['url'] ) ? $x['url'] : '' ) ) !== '' ) { $soc[] = array( 'type' => $x['type'], 'url' => $u ); } }
        $loc = array(); foreach ( array_slice( isset( $c['locations'] ) && is_array( $c['locations'] ) ? array_values( $c['locations'] ) : array(), 0, 6 ) as $x ) { if ( is_array( $x ) ) { $ci = Blocks::txt( isset( $x['city'] ) ? $x['city'] : '', 80 ); $ad = Blocks::txt( isset( $x['address'] ) ? $x['address'] : '', 300 ); if ( $ci !== '' || $ad !== '' ) { $loc[] = array( 'city' => $ci, 'address' => $ad ); } } }
        $wa = preg_replace( '/[^0-9]/', '', isset( $c['whatsapp'] ) ? (string) $c['whatsapp'] : '' );
        return array( 'logo' => $m && Media::item( $m ) ? $m : 0, 'phone' => $t( 'phone', 80 ), 'hours' => $t( 'hours', 80 ), 'whatsapp' => substr( $wa, 0, 15 ), 'social' => $soc,
            'links_title' => $t( 'links_title', 60 ), 'links' => $links( isset( $c['links'] ) ? $c['links'] : array(), 10 ), 'col2_title' => $t( 'col2_title', 60 ), 'col2' => $links( isset( $c['col2'] ) ? $c['col2'] : array(), 12 ), 'col3_title' => $t( 'col3_title', 60 ), 'col3' => $links( isset( $c['col3'] ) ? $c['col3'] : array(), 12 ),
            'subscribe_title' => $t( 'subscribe_title', 60 ), 'subscribe_text' => $t( 'subscribe_text', 300 ), 'locations_title' => $t( 'locations_title', 60 ), 'locations' => $loc, 'copyright' => $t( 'copyright', 200 ) );
    }

    // TRACE: Settings screen → untrusted array → whitelisted/clamped settings; the public base must not collide with an existing WordPress page/category slug or a dashboard slug → array( ok, errors, settings )
    public static function save( $in ) {
        $cur = self::get(); $out = $cur; $err = array();
        if ( isset( $in['public_base'] ) ) {
            $b = sanitize_title( wp_unslash( (string) $in['public_base'] ) );
            $taken = array( nsh_plat_get( 'login_slug' ), nsh_plat_get( 'admin_slug' ), nsh_plat_get( 'staff_slug' ), nsh_plat_get( 'client_slug' ), 'wp-admin', 'wp-content', 'wp-includes', 'wp-json', 'feed', 'page', 'category', 'tag', 'author', 'nsh-request-submit', 'nsh-services' );
            if ( $b === '' ) { $err[] = 'The public blog address cannot be empty.'; }
            elseif ( in_array( $b, $taken, true ) ) { $err[] = '"' . $b . '" is already used by WordPress or a dashboard.'; }
            elseif ( $b !== $cur['public_base'] && ( ( $pg = get_page_by_path( $b ) ) && $pg->post_status === 'publish' || get_term_by( 'slug', $b, 'category' ) ) ) { $err[] = '"' . $b . '" is already used by a page or category on your WordPress site, so it was not changed. Choose another address.'; }
            else { $out['public_base'] = $b; }
        }
        if ( isset( $in['site_title'] ) ) { $out['site_title'] = Blocks::txt( $in['site_title'], 100 ); }
        if ( isset( $in['tagline'] ) ) { $out['tagline'] = Blocks::txt( $in['tagline'], 200 ); }
        if ( isset( $in['per_page'] ) ) { $out['per_page'] = max( 3, min( 30, (int) $in['per_page'] ) ); }
        if ( isset( $in['accent'] ) ) { $out['accent'] = preg_match( '/^#[0-9a-f]{6}$/i', (string) $in['accent'] ) ? strtolower( $in['accent'] ) : $cur['accent']; }
        if ( isset( $in['footer_text'] ) ) { $out['footer_text'] = Blocks::txt( $in['footer_text'], 300 ); }
        if ( isset( $in['nav_links'] ) ) { $out['nav_links'] = array(); foreach ( array_slice( (array) $in['nav_links'], 0, 10 ) as $l ) { $lb = Blocks::txt( isset( $l['label'] ) ? $l['label'] : '', 40 ); if ( $lb !== '' ) { $out['nav_links'][] = array( 'label' => $lb, 'url' => Blocks::url( isset( $l['url'] ) ? $l['url'] : '' ) ); } } }
        if ( isset( $in['chrome'] ) && is_array( $in['chrome'] ) ) { $out['chrome'] = self::clean_chrome( $in['chrome'] ); }
        if ( isset( $in['default_og_image'] ) ) { $m = (int) $in['default_og_image']; $out['default_og_image'] = $m && Media::item( $m ) ? $m : 0; }
        if ( isset( $in['layout_defaults'] ) ) { $out['layout_defaults'] = Blocks::sanitize_layout( $in['layout_defaults'], $cur['layout_defaults'] ); }
        if ( isset( $in['delete_on_uninstall'] ) ) { $out['delete_on_uninstall'] = $in['delete_on_uninstall'] ? 1 : 0; }
        update_option( self::KEY, $out, true );
        self::$cache = null;
        if ( $out['public_base'] !== $cur['public_base'] ) { update_option( 'nsh_flush_needed', 1 ); }
        return array( 'ok' => ! $err, 'errors' => $err, 'settings' => self::get() );
    }
}
