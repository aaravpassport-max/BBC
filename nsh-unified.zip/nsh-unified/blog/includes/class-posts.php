<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Posts — the repository for blog articles. Reads and writes ONLY nsh_blog_* tables.
 *
 * Lifecycle: draft → pending (submitted for review) → published ⇄ draft; published → archived; scheduled → published (cron / lazy check).
 * A LIVE article is never edited in place: edits go to one "working copy" (revision kind=working) that the owner previews and then publishes,
 * so visitors never see half-finished changes. Any other status is edited directly.
 */
final class Posts {
    public const STATUSES = array( 'draft' => 'Draft', 'pending' => 'Pending review', 'scheduled' => 'Scheduled', 'published' => 'Published', 'archived' => 'Archived' );
    public const RESERVED = array( 'category', 'tag', 'author', 'page', 'search', 'feed', 'sitemap', 'sitemap-xml', 'preview' );
    private const FIELDS = array( 'title', 'slug', 'subtitle', 'intro', 'blocks', 'layout', 'seo', 'featured_media', 'category_id', 'tag_ids', 'author_user' );

    // ── reading ─────────────────────────────────────────────────────────────
    private static function raw( $id ) { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . DB::t( 'posts' ) . ' WHERE id=%d', (int) $id ), ARRAY_A ); }

    // TRACE: editor/list/render → raw DB row → decoded article array (JSON columns decoded, author/category/tags/featured image attached, URLs built) → array
    public static function hydrate( $r, $overlay = null ) {
        $p = array(
            'id' => (int) $r['id'], 'slug' => $r['slug'], 'title' => $r['title'], 'subtitle' => $r['subtitle'], 'intro' => (string) $r['intro'],
            'blocks' => json_decode( (string) $r['blocks'], true ) ?: array(), 'layout' => Blocks::sanitize_layout( json_decode( (string) $r['layout'], true ) ?: array() ),
            'seo' => Blocks::sanitize_seo( json_decode( (string) $r['seo'], true ) ?: array() ), 'status' => $r['status'], 'featured_media' => (int) $r['featured_media'],
            'author_user' => (int) $r['author_user'], 'category_id' => (int) $r['category_id'], 'published_at' => $r['published_at'], 'scheduled_at' => $r['scheduled_at'],
            'version' => (int) $r['version'], 'views' => (int) $r['views'], 'created_by' => (int) $r['created_by'], 'updated_by' => (int) $r['updated_by'],
            'created_at' => $r['created_at'], 'updated_at' => $r['updated_at'], 'deleted_at' => $r['deleted_at'], 'has_working' => false,
        );
        $t = Terms::for_post( $p['id'], $p['category_id'] );
        $p['tag_ids'] = array_map( function ( $x ) { return (int) $x['id']; }, $t['tags'] );
        if ( is_array( $overlay ) ) {
            foreach ( self::FIELDS as $f ) { if ( array_key_exists( $f, $overlay ) ) { $p[ $f ] = $overlay[ $f ]; } }
            $p['has_working'] = true;
            $t = Terms::for_post( $p['id'], (int) $p['category_id'] );
            $t['tags'] = array_values( array_filter( array_map( array( Terms::class, 'get' ), (array) $p['tag_ids'] ) ) );
        }
        $p['category'] = $t['category']; $p['tags'] = $t['tags'];
        $p['featured'] = $p['featured_media'] ? Media::item( $p['featured_media'] ) : null;
        $p['author'] = Authors::card( $p['author_user'] ?: $p['created_by'] );
        $p['url'] = Front::url( 'post', $p['slug'] );
        $p['reading_minutes'] = self::reading_minutes( $p );
        return $p;
    }
    // TRACE: card/meta → article → whole minutes to read (≈220 wpm over intro + text-bearing blocks) → int
    public static function reading_minutes( $p ) {
        $txt = (string) $p['intro'];
        foreach ( (array) $p['blocks'] as $b ) { $txt .= ' ' . wp_strip_all_tags( wp_json_encode( isset( $b['data'] ) ? $b['data'] : array() ) ); }
        return max( 1, (int) ceil( str_word_count( $txt ) / 220 ) );
    }
    // TRACE: editor → id, overlay flag → article incl. unpublished working copy when asked (editors see their pending changes) → array|null
    public static function get( $id, $overlay = true ) {
        $r = self::raw( $id );
        if ( ! $r ) { return null; }
        $w = $overlay ? self::working( (int) $id ) : null;
        return self::hydrate( $r, $w ? $w['snapshot'] : null );
    }
    // TRACE: public article route → slug → the LIVE article only (published, not future-dated, not deleted); null otherwise → array|null
    public static function live_by_slug( $slug ) {
        global $wpdb;
        $r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . DB::t( 'posts' ) . " WHERE slug=%s AND status='published' AND deleted_at IS NULL AND (published_at IS NULL OR published_at<=%s)", sanitize_title( $slug ), DB::now() ), ARRAY_A );
        return $r ? self::hydrate( $r ) : null;
    }
    public static function by_slug_any( $slug ) { global $wpdb; $r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . DB::t( 'posts' ) . ' WHERE slug=%s', sanitize_title( $slug ) ), ARRAY_A ); return $r ? self::hydrate( $r, ( $w = self::working( (int) $r['id'] ) ) ? $w['snapshot'] : null ) : null; }

    // TRACE: list screens + public archives → args {status, public, q, category, tag, author, page, per, orderby, exclude, visible_to} → { items (light rows), total, pages }
    //        pre: none → post: parameterised SQL only; public=1 means published + due + not deleted → edge: staff without edit_all only see their own rows
    public static function query( $a = array() ) {
        global $wpdb;
        $p = DB::t( 'posts' ); $where = array( '1=1' ); $args = array(); $join = '';
        $public = ! empty( $a['public'] );
        if ( $public ) { $where[] = "p.status='published' AND p.deleted_at IS NULL AND (p.published_at IS NULL OR p.published_at<=%s)"; $args[] = DB::now(); }
        else {
            $st = isset( $a['status'] ) ? (string) $a['status'] : 'all';
            if ( $st === 'trash' ) { $where[] = 'p.deleted_at IS NOT NULL'; }
            else { $where[] = 'p.deleted_at IS NULL'; if ( isset( self::STATUSES[ $st ] ) ) { $where[] = 'p.status=%s'; $args[] = $st; } }
            if ( ! empty( $a['visible_to'] ) ) { list( $sql, $ar ) = Access::visibility_sql( (int) $a['visible_to'] ); if ( $sql ) { $where[] = ltrim( $sql, ' AND ' ); $args = array_merge( $args, $ar ); } }
        }
        if ( ! empty( $a['q'] ) ) { $like = '%' . $wpdb->esc_like( (string) $a['q'] ) . '%'; $where[] = '(p.title LIKE %s OR p.slug LIKE %s OR p.intro LIKE %s)'; array_push( $args, $like, $like, $like ); }
        if ( ! empty( $a['category'] ) ) { $where[] = 'p.category_id=%d'; $args[] = (int) $a['category']; }
        if ( ! empty( $a['tag'] ) ) { $join .= ' JOIN ' . DB::t( 'post_terms' ) . ' pt ON pt.post_id=p.id'; $where[] = 'pt.term_id=%d'; $args[] = (int) $a['tag']; }
        if ( ! empty( $a['author'] ) ) { $where[] = '(p.author_user=%d OR (p.author_user=0 AND p.created_by=%d))'; array_push( $args, (int) $a['author'], (int) $a['author'] ); }
        if ( ! empty( $a['exclude'] ) ) { $where[] = 'p.id<>%d'; $args[] = (int) $a['exclude']; }
        $per  = max( 1, min( 100, (int) ( isset( $a['per'] ) ? $a['per'] : 20 ) ) );
        $page = max( 1, (int) ( isset( $a['page'] ) ? $a['page'] : 1 ) );
        $ob   = array( 'updated' => 'p.updated_at DESC', 'title' => 'p.title ASC', 'published' => 'COALESCE(p.published_at,p.updated_at) DESC', 'views' => 'p.views DESC' );
        $order = isset( $ob[ isset( $a['orderby'] ) ? $a['orderby'] : '' ] ) ? $ob[ $a['orderby'] ] : ( $public ? $ob['published'] : $ob['updated'] );
        $w = implode( ' AND ', $where );
        $total = (int) ( $args ? $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT p.id) FROM $p p $join WHERE $w", $args ) ) : $wpdb->get_var( "SELECT COUNT(DISTINCT p.id) FROM $p p $join WHERE $w" ) );
        $ids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT p.id FROM $p p $join WHERE $w ORDER BY $order LIMIT %d OFFSET %d", array_merge( $args, array( $per, ( $page - 1 ) * $per ) ) ) ) ?: array();
        $items = array();
        foreach ( $ids as $id ) { $r = self::raw( $id ); if ( $r ) { $items[] = self::row_light( self::hydrate( $r, $public ? null : ( ( $wk = self::working( (int) $id ) ) ? $wk['snapshot'] : null ) ) ); } }
        return array( 'items' => $items, 'total' => $total, 'pages' => max( 1, (int) ceil( $total / $per ) ), 'page' => $page );
    }
    // TRACE: list payloads → article → the small subset a list/card needs (no blocks) → array
    public static function row_light( $p ) {
        return array( 'id' => $p['id'], 'slug' => $p['slug'], 'title' => $p['title'], 'subtitle' => $p['subtitle'], 'intro' => $p['intro'], 'status' => $p['status'], 'url' => $p['url'], 'category' => $p['category'], 'tags' => $p['tags'], 'author' => $p['author'], 'featured' => $p['featured'],
            'published_at' => $p['published_at'], 'scheduled_at' => $p['scheduled_at'], 'updated_at' => $p['updated_at'], 'views' => $p['views'], 'has_working' => $p['has_working'], 'deleted_at' => $p['deleted_at'], 'created_by' => $p['created_by'], 'reading_minutes' => $p['reading_minutes'] );
    }
    // TRACE: list tabs → visible-to user id → count per status (+ trash) for articles that user can see → array
    public static function status_counts( $uid = 0 ) {
        global $wpdb;
        $p = DB::t( 'posts' ); list( $sql, $ar ) = Access::visibility_sql( $uid );
        $q1 = "SELECT p.status, COUNT(*) c FROM $p p WHERE p.deleted_at IS NULL $sql GROUP BY p.status";
        $rows = $wpdb->get_results( $ar ? $wpdb->prepare( $q1, $ar ) : $q1, ARRAY_A ) ?: array();   // no placeholders when the viewer sees every article
        $out = array( 'all' => 0, 'trash' => 0 ); foreach ( self::STATUSES as $k => $_ ) { $out[ $k ] = 0; }
        foreach ( $rows as $r ) { $out[ $r['status'] ] = (int) $r['c']; $out['all'] += (int) $r['c']; }
        $q2 = "SELECT COUNT(*) FROM $p p WHERE p.deleted_at IS NOT NULL $sql";
        $out['trash'] = (int) $wpdb->get_var( $ar ? $wpdb->prepare( $q2, $ar ) : $q2 );
        return $out;
    }

    // ── working copy + revisions ────────────────────────────────────────────
    public static function working( $post_id ) {
        global $wpdb;
        $r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . DB::t( 'revisions' ) . " WHERE post_id=%d AND kind='working' ORDER BY id DESC LIMIT 1", (int) $post_id ), ARRAY_A );
        if ( ! $r ) { return null; }
        $r['snapshot'] = json_decode( (string) $r['snapshot'], true ) ?: array();
        return $r;
    }
    private static function snap_of( $r ) {
        $tags = $GLOBALS['wpdb']->get_col( $GLOBALS['wpdb']->prepare( 'SELECT term_id FROM ' . DB::t( 'post_terms' ) . ' WHERE post_id=%d', (int) $r['id'] ) );
        return array( 'title' => $r['title'], 'slug' => $r['slug'], 'subtitle' => $r['subtitle'], 'intro' => (string) $r['intro'], 'blocks' => json_decode( (string) $r['blocks'], true ) ?: array(), 'layout' => json_decode( (string) $r['layout'], true ) ?: array(),
            'seo' => json_decode( (string) $r['seo'], true ) ?: array(), 'featured_media' => (int) $r['featured_media'], 'category_id' => (int) $r['category_id'], 'tag_ids' => array_map( 'intval', $tags ), 'author_user' => (int) $r['author_user'] );
    }
    private static function add_revision( $post_id, $kind, $snapshot, $base_version, $uid ) {
        global $wpdb; $t = DB::t( 'revisions' );
        if ( $kind === 'working' ) { $wpdb->delete( $t, array( 'post_id' => (int) $post_id, 'kind' => 'working' ) ); }
        $no = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(MAX(rev_no),0)+1 FROM $t WHERE post_id=%d", (int) $post_id ) );
        $ok = $wpdb->insert( $t, array( 'post_id' => (int) $post_id, 'kind' => $kind, 'rev_no' => $no, 'snapshot' => wp_json_encode( $snapshot ), 'base_version' => (int) $base_version, 'created_by' => (int) $uid, 'created_at' => DB::now() ) );
        if ( $ok === false ) { error_log( '[NSH Blog] revision insert failed: ' . $wpdb->last_error ); }
        if ( $kind === 'manual' ) { $wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE post_id=%d AND kind='manual' AND id NOT IN (SELECT id FROM (SELECT id FROM $t WHERE post_id=%d AND kind='manual' ORDER BY id DESC LIMIT 30) k)", (int) $post_id, (int) $post_id ) ); }
        return $ok !== false;
    }
    // TRACE: editor "History" → post id → the saved snapshots (newest first) with who/when → array
    public static function revisions( $post_id ) {
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare( 'SELECT id,rev_no,kind,created_by,created_at FROM ' . DB::t( 'revisions' ) . " WHERE post_id=%d AND kind='manual' ORDER BY id DESC LIMIT 30", (int) $post_id ), ARRAY_A ) ?: array();
        foreach ( $rows as &$r ) { $u = get_userdata( (int) $r['created_by'] ); $r['user'] = $u ? $u->display_name : 'System'; }
        return $rows;
    }
    // TRACE: editor "Restore" → revision id → loads that snapshot as the article's new working state (through save(), so permissions, sanitising and locking all apply) → article | WP_Error
    public static function restore_revision( $rev_id, $uid ) {
        global $wpdb;
        $r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . DB::t( 'revisions' ) . " WHERE id=%d AND kind='manual'", (int) $rev_id ), ARRAY_A );
        if ( ! $r ) { return new \WP_Error( 'nsh_blog_rev', 'That version no longer exists.' ); }
        $post = self::get( (int) $r['post_id'] );
        if ( ! $post ) { return new \WP_Error( 'nsh_blog_rev', 'Article not found.' ); }
        $in = json_decode( (string) $r['snapshot'], true ) ?: array();
        $in['id'] = $post['id']; $in['version'] = $post['version'];
        return self::save( $in, $uid );
    }

    // ── writing ─────────────────────────────────────────────────────────────
    // TRACE: save() → desired slug, own id → a slug unique among ALL blog rows (incl. trashed) that is not a reserved route word → string
    public static function unique_slug( $slug, $id = 0 ) {
        global $wpdb;
        $base = sanitize_title( $slug ) ?: 'article';
        if ( in_array( $base, self::RESERVED, true ) ) { $base .= '-article'; }
        $s = $base; $n = 2;
        while ( ( $ex = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . DB::t( 'posts' ) . ' WHERE slug=%s', $s ) ) ) && (int) $ex !== (int) $id ) { $s = $base . '-' . $n++; }
        return $s;
    }
    // TRACE: save() → untrusted input + current snapshot → the fully sanitised next snapshot (only keys present in input change) → array
    private static function merge( $in, $cur ) {
        $s = $cur;
        if ( array_key_exists( 'title', $in ) )    { $s['title'] = Blocks::txt( $in['title'], 300 ); }
        if ( array_key_exists( 'subtitle', $in ) ) { $s['subtitle'] = Blocks::txt( $in['subtitle'], 500 ); }
        if ( array_key_exists( 'intro', $in ) )    { $s['intro'] = Blocks::html( $in['intro'] ); }
        if ( array_key_exists( 'blocks', $in ) )   { $s['blocks'] = Blocks::sanitize_blocks( $in['blocks'] ); }
        if ( array_key_exists( 'layout', $in ) )   { $s['layout'] = Blocks::sanitize_layout( $in['layout'], isset( $cur['layout'] ) ? $cur['layout'] : null ); }
        if ( array_key_exists( 'seo', $in ) && Access::can( 'seo' ) ) { $s['seo'] = Blocks::sanitize_seo( $in['seo'] ); }
        if ( array_key_exists( 'featured_media', $in ) ) { $m = (int) $in['featured_media']; $s['featured_media'] = ( $m && Media::item( $m ) ) ? $m : 0; }
        if ( array_key_exists( 'category_id', $in ) ) { $c = Terms::get( (int) $in['category_id'] ); $s['category_id'] = ( $c && $c['type'] === 'category' ) ? (int) $c['id'] : 0; }
        if ( array_key_exists( 'tag_ids', $in ) ) { $s['tag_ids'] = array_values( array_unique( array_map( 'intval', (array) $in['tag_ids'] ) ) ); }
        if ( array_key_exists( 'author_user', $in ) && Access::can( 'edit_all' ) ) { $a = (int) $in['author_user']; $s['author_user'] = ( $a && get_userdata( $a ) ) ? $a : 0; }
        if ( array_key_exists( 'slug', $in ) ) { $s['slug'] = sanitize_title( (string) $in['slug'] ); }
        return $s;
    }
    private static function row_from( $s ) {
        return array( 'title' => $s['title'], 'slug' => $s['slug'], 'subtitle' => $s['subtitle'], 'intro' => $s['intro'], 'blocks' => wp_json_encode( $s['blocks'] ), 'layout' => wp_json_encode( $s['layout'] ), 'seo' => wp_json_encode( $s['seo'] ),
            'featured_media' => (int) $s['featured_media'], 'category_id' => (int) $s['category_id'], 'author_user' => (int) $s['author_user'] );
    }

    // TRACE: editor "Save" / inline "Save" → input {id?, version?, ...fields}, user → creates a draft (no id) or updates: non-live articles in place, LIVE articles into their working copy
    //        pre: caller passed Access::guard; this re-checks edit rights per article → post: version incremented on in-place saves; a manual revision is recorded → returns the hydrated article | WP_Error
    //        edge: stale `version` → WP_Error code "conflict" (data = current article); empty title allowed only for drafts; new tag names in `new_tags` are created first
    public static function save( $in, $uid = 0 ) {
        global $wpdb;
        $uid = $uid ? (int) $uid : get_current_user_id();
        $id  = (int) ( isset( $in['id'] ) ? $in['id'] : 0 );
        if ( ! empty( $in['new_tags'] ) && Access::can( 'taxonomy', $uid ) || ! empty( $in['new_tags'] ) && Access::can( 'edit', $uid ) ) {
            $in['tag_ids'] = isset( $in['tag_ids'] ) ? (array) $in['tag_ids'] : array();
            foreach ( array_slice( (array) $in['new_tags'], 0, 10 ) as $nm ) { $t = Terms::save( array( 'type' => 'tag', 'name' => $nm ) ); if ( ! is_wp_error( $t ) ) { $in['tag_ids'][] = (int) $t['id']; } }
        }
        if ( ! $id ) {
            if ( ! Access::can( 'create', $uid ) ) { return new \WP_Error( 'nsh_blog_perm', 'You are not allowed to write new articles.' ); }
            $base = array( 'title' => '', 'slug' => '', 'subtitle' => '', 'intro' => '', 'blocks' => array(), 'layout' => Blocks::sanitize_layout( Settings::get( 'layout_defaults' ) ?: array() ), 'seo' => Blocks::sanitize_seo( array() ), 'featured_media' => 0, 'category_id' => 0, 'tag_ids' => array(), 'author_user' => $uid );
            $s = self::merge( $in, $base );
            $s['title'] = $s['title'] !== '' ? $s['title'] : 'Untitled article';
            $s['slug']  = self::unique_slug( $s['slug'] !== '' ? $s['slug'] : $s['title'], 0 );
            $now = DB::now();
            $row = array_merge( self::row_from( $s ), array( 'status' => 'draft', 'version' => 1, 'created_by' => $uid, 'updated_by' => $uid, 'created_at' => $now, 'updated_at' => $now ) );
            if ( $wpdb->insert( DB::t( 'posts' ), $row ) === false ) { return new \WP_Error( 'nsh_blog_db', 'Could not create the article.' ); }
            $id = (int) $wpdb->insert_id;
            Terms::set_tags( $id, $s['tag_ids'] );
            Authors::for_user( $uid, true );
            self::add_revision( $id, 'manual', $s, 1, $uid );
            Audit::log( $id, 'create', $s['slug'] );
            return self::get( $id );
        }
        $r = self::raw( $id );
        if ( ! $r || $r['deleted_at'] ) { return new \WP_Error( 'nsh_blog_missing', 'That article no longer exists.' ); }
        $cur = self::hydrate( $r );
        if ( ! Access::can_edit_post( $cur, $uid ) ) { return new \WP_Error( 'nsh_blog_perm', 'You are not allowed to edit this article.' ); }
        if ( isset( $in['version'] ) && (int) $in['version'] !== (int) $r['version'] ) { return new \WP_Error( 'conflict', 'This article was changed by someone else. Reload to see the latest version.', array( 'article' => self::get( $id ) ) ); }
        $work = self::working( $id );
        $curSnap = $work ? array_replace( self::snap_of( $r ), $work['snapshot'] ) : self::snap_of( $r );
        $s = self::merge( $in, $curSnap );
        if ( $s['title'] === '' ) { return new \WP_Error( 'nsh_blog_title', 'The title cannot be empty.' ); }
        $live = $r['status'] === 'published' && ( ! $r['published_at'] || $r['published_at'] <= DB::now() );
        if ( $s['slug'] === '' ) { $s['slug'] = $curSnap['slug']; }
        $s['slug'] = self::unique_slug( $s['slug'], $id );
        if ( $live ) {
            if ( ! self::add_revision( $id, 'working', $s, (int) $r['version'], $uid ) ) { return new \WP_Error( 'nsh_blog_db', 'Could not save your changes.' ); }
            Audit::log( $id, 'edit_working', 'unpublished changes saved' );
            return self::get( $id );
        }
        $row = array_merge( self::row_from( $s ), array( 'version' => (int) $r['version'] + 1, 'updated_by' => $uid, 'updated_at' => DB::now() ) );
        if ( $wpdb->update( DB::t( 'posts' ), $row, array( 'id' => $id ) ) === false ) { return new \WP_Error( 'nsh_blog_db', 'Could not save the article.' ); }
        Terms::set_tags( $id, $s['tag_ids'] );
        if ( $work ) { $wpdb->delete( DB::t( 'revisions' ), array( 'post_id' => $id, 'kind' => 'working' ) ); }
        self::add_revision( $id, 'manual', $s, (int) $row['version'], $uid );
        Audit::log( $id, 'edit', $s['slug'] );
        return self::get( $id );
    }

    // TRACE: transition() / publish → article id → problems that block publishing (missing title/slug/body, empty image alt on the featured image) → string[]
    public static function publish_problems( $p ) {
        $m = array();
        if ( trim( (string) $p['title'] ) === '' || $p['title'] === 'Untitled article' ) { $m[] = 'Give the article a real title.'; }
        if ( trim( (string) $p['slug'] ) === '' ) { $m[] = 'The article needs a URL slug.'; }
        if ( trim( wp_strip_all_tags( (string) $p['intro'] ) ) === '' && empty( $p['blocks'] ) ) { $m[] = 'Add an introduction or at least one section.'; }
        if ( ! empty( $p['featured'] ) && trim( (string) $p['featured']['alt'] ) === '' ) { $m[] = 'Add alt text to the featured image (Media → Edit).'; }
        return $m;
    }

    private const FLOW = array(
        'draft'     => array( 'pending', 'published', 'scheduled', 'archived' ),
        'pending'   => array( 'draft', 'published', 'scheduled', 'archived' ),
        'scheduled' => array( 'draft', 'published', 'pending' ),
        'published' => array( 'draft', 'archived' ),
        'archived'  => array( 'draft' ),
    );
    // TRACE: editor/inline/bulk status buttons → id, target status, opts {scheduled_at (UTC "Y-m-d H:i:s")}, user → validates the move against FLOW + the user's rights, applies any working copy when publishing, stamps dates, logs it → article | WP_Error
    //        edge: publishing needs "publish"; staff without it may only submit for review (draft→pending); a future date makes "published" become "scheduled"
    public static function transition( $id, $to, $opts = array(), $uid = 0 ) {
        global $wpdb;
        $uid = $uid ? (int) $uid : get_current_user_id();
        $r = self::raw( $id );
        if ( ! $r || $r['deleted_at'] ) { return new \WP_Error( 'nsh_blog_missing', 'That article no longer exists.' ); }
        $p = self::hydrate( $r );
        if ( ! Access::can_edit_post( $p, $uid ) ) { return new \WP_Error( 'nsh_blog_perm', 'You are not allowed to change this article.' ); }
        $from = $r['status'];
        if ( ! isset( self::STATUSES[ $to ] ) || ! in_array( $to, self::FLOW[ $from ] ?? array(), true ) ) { return new \WP_Error( 'nsh_blog_flow', 'This article cannot move from "' . $from . '" to "' . $to . '".' ); }
        $needs_publish = in_array( $to, array( 'published', 'scheduled' ), true ) || $from === 'published';
        if ( $needs_publish && ! Access::can( 'publish', $uid ) ) { return new \WP_Error( 'nsh_blog_perm', 'You can submit this article for review, but only a publisher can publish or unpublish it.' ); }
        $upd = array( 'status' => $to, 'updated_by' => $uid, 'updated_at' => DB::now(), 'version' => (int) $r['version'] + 1 );
        $work = self::working( $id );
        if ( $to === 'published' || $to === 'scheduled' ) {
            $eff = self::get( $id );
            $probs = self::publish_problems( $eff );
            if ( $probs ) { return new \WP_Error( 'nsh_blog_problems', implode( ' ', $probs ), array( 'problems' => $probs ) ); }
            $when = isset( $opts['scheduled_at'] ) ? (string) $opts['scheduled_at'] : '';
            if ( $to === 'scheduled' ) {
                if ( ! preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $when ) || $when <= DB::now() ) { return new \WP_Error( 'nsh_blog_date', 'Choose a date and time in the future.' ); }
                $upd['scheduled_at'] = $when; $upd['published_at'] = $when;
            } else {
                $upd['scheduled_at'] = null; $upd['published_at'] = $r['published_at'] && $from === 'published' ? $r['published_at'] : DB::now();
            }
            if ( $work || true ) { $s = $work ? array_replace( self::snap_of( $r ), $work['snapshot'] ) : self::snap_of( $r ); $s['slug'] = self::unique_slug( $s['slug'], (int) $id ); $upd = array_merge( $upd, self::row_from( $s ) ); }
        } else {
            if ( $to === 'draft' ) { $upd['scheduled_at'] = null; }
            if ( $work ) {   // unpublishing/archiving must not lose unpublished edits: they become the article's saved state
                $s = array_replace( self::snap_of( $r ), $work['snapshot'] ); $s['slug'] = self::unique_slug( $s['slug'], (int) $id );
                $upd = array_merge( $upd, self::row_from( $s ) );
            }
        }
        $ok = $wpdb->update( DB::t( 'posts' ), $upd, array( 'id' => (int) $id ) );
        if ( $ok === false ) { return new \WP_Error( 'nsh_blog_db', 'Could not change the status.' ); }
        if ( isset( $s ) ) { Terms::set_tags( $id, $s['tag_ids'] ); }
        if ( $work ) { $wpdb->delete( DB::t( 'revisions' ), array( 'post_id' => (int) $id, 'kind' => 'working' ) ); }
        Audit::log( $id, 'status', $from . ' → ' . $to );
        return self::get( $id );
    }

    // TRACE: editor "Publish changes" on a live article → id → copies the working copy over the live row (version+1) and clears it → article | WP_Error
    public static function publish_working( $id, $uid = 0 ) {
        global $wpdb;
        $uid = $uid ? (int) $uid : get_current_user_id();
        $r = self::raw( $id ); $work = self::working( $id );
        if ( ! $r || ! $work ) { return new \WP_Error( 'nsh_blog_missing', 'There are no unpublished changes.' ); }
        if ( ! Access::can( 'publish', $uid ) || ! Access::can_edit_post( self::hydrate( $r ), $uid ) ) { return new \WP_Error( 'nsh_blog_perm', 'Only a publisher can publish changes to a live article.' ); }
        $s = array_replace( self::snap_of( $r ), $work['snapshot'] );
        $probs = self::publish_problems( self::hydrate( $r, $s ) );
        if ( $probs ) { return new \WP_Error( 'nsh_blog_problems', implode( ' ', $probs ), array( 'problems' => $probs ) ); }
        $s['slug'] = self::unique_slug( $s['slug'], (int) $id );
        $row = array_merge( self::row_from( $s ), array( 'version' => (int) $r['version'] + 1, 'updated_by' => $uid, 'updated_at' => DB::now() ) );
        if ( $wpdb->update( DB::t( 'posts' ), $row, array( 'id' => (int) $id ) ) === false ) { return new \WP_Error( 'nsh_blog_db', 'Could not publish the changes.' ); }
        Terms::set_tags( $id, $s['tag_ids'] );
        $wpdb->delete( DB::t( 'revisions' ), array( 'post_id' => (int) $id, 'kind' => 'working' ) );
        self::add_revision( $id, 'manual', $s, (int) $row['version'], $uid );
        Audit::log( $id, 'publish_changes', $s['slug'] );
        return self::get( $id );
    }
    // TRACE: editor "Discard changes" → id → deletes the working copy so the live version shows again → article | WP_Error
    public static function discard_working( $id, $uid = 0 ) {
        global $wpdb;
        $r = self::raw( $id );
        if ( ! $r ) { return new \WP_Error( 'nsh_blog_missing', 'That article no longer exists.' ); }
        if ( ! Access::can_edit_post( self::hydrate( $r ), $uid ) ) { return new \WP_Error( 'nsh_blog_perm', 'You are not allowed to edit this article.' ); }
        $wpdb->delete( DB::t( 'revisions' ), array( 'post_id' => (int) $id, 'kind' => 'working' ) );
        Audit::log( $id, 'discard_working', '' );
        return self::get( $id );
    }

    // TRACE: cron + lazy public check → none → publishes every scheduled article whose time has come → number published
    public static function publish_due() {
        global $wpdb;
        $ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . DB::t( 'posts' ) . " WHERE status='scheduled' AND scheduled_at<=%s AND deleted_at IS NULL", DB::now() ) ) ?: array();
        foreach ( $ids as $id ) {
            if ( $wpdb->update( DB::t( 'posts' ), array( 'status' => 'published', 'scheduled_at' => null, 'updated_at' => DB::now() ), array( 'id' => (int) $id, 'status' => 'scheduled' ) ) ) { Audit::log( (int) $id, 'status', 'scheduled → published (auto)' ); }
        }
        return count( $ids );
    }

    // TRACE: list "Duplicate" → id → copy as a new draft owned by the user (own slug, no working copy) → article | WP_Error
    public static function duplicate( $id, $uid = 0 ) {
        $uid = $uid ? (int) $uid : get_current_user_id();
        $p = self::get( $id );
        if ( ! $p ) { return new \WP_Error( 'nsh_blog_missing', 'That article no longer exists.' ); }
        if ( ! Access::can( 'create', $uid ) || ! Access::can_edit_post( $p, $uid ) && ! Access::can( 'edit_all', $uid ) ) { return new \WP_Error( 'nsh_blog_perm', 'You are not allowed to duplicate this article.' ); }
        $in = array( 'title' => $p['title'] . ' (copy)', 'slug' => $p['slug'] . '-copy', 'subtitle' => $p['subtitle'], 'intro' => $p['intro'], 'blocks' => $p['blocks'], 'layout' => $p['layout'], 'seo' => $p['seo'], 'featured_media' => $p['featured_media'], 'category_id' => $p['category_id'], 'tag_ids' => $p['tag_ids'] );
        return self::save( $in, $uid );
    }
    // TRACE: list "Delete" → id → soft-deletes (moves to Trash, hidden everywhere, slug stays reserved); published articles must be unpublished first → true | WP_Error
    public static function trash( $id, $uid = 0 ) {
        global $wpdb;
        $uid = $uid ? (int) $uid : get_current_user_id();
        $r = self::raw( $id );
        if ( ! $r || $r['deleted_at'] ) { return new \WP_Error( 'nsh_blog_missing', 'That article no longer exists.' ); }
        if ( ! Access::can( 'delete', $uid ) || ! Access::can_edit_post( self::hydrate( $r ), $uid ) ) { return new \WP_Error( 'nsh_blog_perm', 'You are not allowed to delete this article.' ); }
        if ( $r['status'] === 'published' ) { return new \WP_Error( 'nsh_blog_live', 'Unpublish the article before deleting it.' ); }
        if ( $wpdb->update( DB::t( 'posts' ), array( 'deleted_at' => DB::now(), 'updated_by' => $uid ), array( 'id' => (int) $id ) ) === false ) { return new \WP_Error( 'nsh_blog_db', 'Could not delete.' ); }
        Audit::log( $id, 'trash', $r['slug'] );
        return true;
    }
    public static function restore( $id, $uid = 0 ) {
        global $wpdb;
        $r = self::raw( $id );
        if ( ! $r || ! $r['deleted_at'] ) { return new \WP_Error( 'nsh_blog_missing', 'That article is not in the Trash.' ); }
        if ( ! Access::can( 'delete', $uid ) || ! Access::can_edit_post( self::hydrate( $r ), $uid ) ) { return new \WP_Error( 'nsh_blog_perm', 'You are not allowed to restore this article.' ); }
        $wpdb->update( DB::t( 'posts' ), array( 'deleted_at' => null, 'status' => 'draft' ), array( 'id' => (int) $id ) );
        Audit::log( $id, 'restore', $r['slug'] );
        return self::get( $id );
    }
    // TRACE: Trash "Delete forever" → id → removes the row, its links, revisions and audit trail permanently; only for trashed articles → true | WP_Error
    public static function purge( $id, $uid = 0 ) {
        global $wpdb;
        $r = self::raw( $id );
        if ( ! $r || ! $r['deleted_at'] ) { return new \WP_Error( 'nsh_blog_missing', 'Only articles in the Trash can be deleted forever.' ); }
        if ( ! Access::can( 'delete', $uid ) || ! Access::can_edit_post( self::hydrate( $r ), $uid ) ) { return new \WP_Error( 'nsh_blog_perm', 'You are not allowed to delete this article.' ); }
        $wpdb->delete( DB::t( 'post_terms' ), array( 'post_id' => (int) $id ) );
        $wpdb->delete( DB::t( 'revisions' ), array( 'post_id' => (int) $id ) );
        $ok = $wpdb->delete( DB::t( 'posts' ), array( 'id' => (int) $id ) );
        Audit::log( $id, 'purge', $r['slug'] );
        return $ok ? true : new \WP_Error( 'nsh_blog_db', 'Could not delete.' );
    }

    // TRACE: article page "Related" → article, limit → published articles sharing the category or a tag, newest first (excluding itself) → array of light rows
    public static function related( $p, $limit = 3 ) {
        global $wpdb;
        $pt = DB::t( 'post_terms' ); $ps = DB::t( 'posts' );
        $ids = array();
        if ( ! empty( $p['tag_ids'] ) ) {
            $ph = implode( ',', array_fill( 0, count( $p['tag_ids'] ), '%d' ) );
            $ids = $wpdb->get_col( $wpdb->prepare( "SELECT DISTINCT x.post_id FROM $pt x JOIN $ps q ON q.id=x.post_id WHERE x.term_id IN ($ph) AND x.post_id<>%d AND q.status='published' AND q.deleted_at IS NULL AND (q.published_at IS NULL OR q.published_at<=%s) ORDER BY q.published_at DESC LIMIT %d", array_merge( array_map( 'intval', $p['tag_ids'] ), array( (int) $p['id'], DB::now(), (int) $limit ) ) ) ) ?: array();
        }
        $out = array(); foreach ( $ids as $i ) { $x = self::get( (int) $i, false ); if ( $x ) { $out[] = self::row_light( $x ); } }
        if ( count( $out ) < $limit ) {
            $more = self::query( array( 'public' => true, 'per' => $limit + 3, 'category' => $p['category_id'] ?: 0, 'exclude' => $p['id'] ) );
            $have = array_map( function ( $x ) { return $x['id']; }, $out );
            foreach ( $more['items'] as $m ) { if ( count( $out ) >= $limit ) { break; } if ( ! in_array( $m['id'], $have, true ) ) { $out[] = $m; } }
        }
        return array_slice( $out, 0, $limit );
    }
    // TRACE: public article view → id → +1 view (skipped for signed-in editors so previews don't inflate it) → void
    public static function hit( $id ) { global $wpdb; if ( ! is_user_logged_in() ) { $wpdb->query( $wpdb->prepare( 'UPDATE ' . DB::t( 'posts' ) . ' SET views=views+1 WHERE id=%d', (int) $id ) ); } }
}
