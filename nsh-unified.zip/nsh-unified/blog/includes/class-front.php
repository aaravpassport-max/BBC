<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Front — the public side of the blog platform: URL builder, router, SEO head, sitemap, page chrome.
 * Own address space (default /insights/…). It never reads or serves wp_posts, so existing WordPress posts and their URLs are untouched.
 */
final class Front {
    public static $edit_ctx = null; // set by dispatch for signed-in editors: array( post_id, can_publish )

    // TRACE: every link in the blog → kind (home|post|category|tag|author|sitemap), slug, page → absolute URL (pretty permalinks, or ?nsh_route=blog&nsh_blog_path= when permalinks are plain)
    public static function url( $kind, $slug = '', $page = 1 ) {
        $base = Settings::get( 'public_base' );
        $seg = '';
        switch ( $kind ) {
            case 'post':     $seg = rawurlencode( $slug ) . '/'; break;
            case 'category': $seg = 'category/' . rawurlencode( $slug ) . '/'; break;
            case 'tag':      $seg = 'tag/' . rawurlencode( $slug ) . '/'; break;
            case 'author':   $seg = 'author/' . rawurlencode( $slug ) . '/'; break;
            case 'sitemap':  $seg = 'sitemap.xml'; break;
        }
        if ( $page > 1 && in_array( $kind, array( 'home', 'category', 'tag', 'author' ), true ) ) { $seg .= 'page/' . (int) $page . '/'; }
        if ( get_option( 'permalink_structure' ) ) { return home_url( '/' . $base . '/' . $seg ); }
        return add_query_arg( array( 'nsh_route' => 'blog', 'nsh_blog_path' => '/' . $seg ), home_url( '/' ) );
    }

    // TRACE: init@5 (via nsh_plat_register_routes action) → none → registers the single rewrite rule that sends /{base}/… to the blog router
    public static function rewrite() {
        $b = preg_quote( Settings::get( 'public_base' ), '#' );
        add_rewrite_rule( '^' . $b . '(/.*)?$', 'index.php?nsh_route=blog&nsh_blog_path=$matches[1]', 'top' );
    }

    private static function css_color( $c ) { return preg_match( '/^#[0-9a-fA-F]{6}$/', (string) $c ) ? $c : '#1d4ed8'; }

    // TRACE: dispatch → request → (a) sitemap (b) archive/author (c) article / preview (d) 404; always ends in render_page() or exit
    //        pre: nsh_route=blog → post: response sent; post data never taken from wp_posts → edge: unknown path → blog-styled 404 with status 404
    public static function dispatch() {
        global $wp_query;
        if ( $wp_query ) { $wp_query->is_404 = false; $wp_query->is_home = false; }
        Posts::publish_due();
        $path = get_query_var( 'nsh_blog_path' );
        if ( ! $path && isset( $_GET['nsh_blog_path'] ) ) { $path = sanitize_text_field( wp_unslash( (string) $_GET['nsh_blog_path'] ) ); }
        $parts = array_values( array_filter( explode( '/', trim( (string) $path, '/' ) ), 'strlen' ) );
        $page = 1;
        if ( count( $parts ) >= 2 && $parts[ count( $parts ) - 2 ] === 'page' && ctype_digit( $parts[ count( $parts ) - 1 ] ) ) { $page = max( 1, (int) array_pop( $parts ) ); array_pop( $parts ); }
        $per = max( 1, (int) Settings::get( 'per_page' ) );
        $first = isset( $parts[0] ) ? $parts[0] : '';

        if ( $first === 'sitemap.xml' && count( $parts ) === 1 ) { self::sitemap(); }
        if ( ! $parts ) {
            $sq = isset( $_GET['q'] ) ? mb_substr( sanitize_text_field( wp_unslash( (string) $_GET['q'] ) ), 0, 80 ) : '';
            $res = Posts::query( array( 'public' => true, 'per' => $per, 'page' => $page, 'q' => $sq ) );
            if ( $page > $res['pages'] && $page > 1 ) { self::not_found(); }
            $t = Settings::get( 'site_title' ) !== '' ? Settings::get( 'site_title' ) : get_bloginfo( 'name' ) . ' Blog';
            self::render_page( array( 'title' => $t . ( $page > 1 ? ' – Page ' . $page : '' ), 'desc' => Settings::get( 'tagline' ), 'canon' => self::url( 'home', '', $page ), 'type' => 'website', 'noindex' => $sq !== '', 'nocache' => $sq !== '', 'prev' => $page > 1 ? self::url( 'home', '', $page - 1 ) : '', 'next' => $page < $res['pages'] ? self::url( 'home', '', $page + 1 ) : '' ), Render::archive( $sq !== '' ? 'Search results for “' . $sq . '”' : $t, $sq !== '' ? '' : (string) Settings::get( 'tagline' ), $res, 'home', '', $page ), 'archive' );
        }
        if ( ( $first === 'category' || $first === 'tag' ) && count( $parts ) === 2 ) {
            $term = Terms::by_slug( $first, $parts[1] );
            if ( ! $term ) { self::not_found(); }
            $res = Posts::query( array( 'public' => true, 'per' => $per, 'page' => $page, $first => (int) $term['id'] ) );
            if ( $page > $res['pages'] && $page > 1 ) { self::not_found(); }
            $lead = (string) $term['description'];
            self::render_page( array( 'title' => $term['name'] . ( $page > 1 ? ' – Page ' . $page : '' ), 'desc' => $lead, 'canon' => self::url( $first, $term['slug'], $page ), 'type' => 'website', 'noindex' => $res['total'] === 0 ), Render::archive( $term['name'], $lead, $res, $first, $term['slug'], $page ), 'archive' );
        }
        if ( $first === 'author' && count( $parts ) === 2 ) {
            $au = Authors::by_slug( $parts[1] );
            if ( ! $au ) { self::not_found(); }
            $res = Posts::query( array( 'public' => true, 'per' => $per, 'page' => $page, 'author' => (int) $au['user_id'] ) );
            self::render_page( array( 'title' => $au['name'], 'desc' => (string) $au['bio'], 'canon' => self::url( 'author', $au['slug'], $page ), 'type' => 'profile' ), Render::archive( $au['name'], (string) $au['bio'], $res, 'author', $au['slug'], $page ), 'archive' );
        }
        if ( count( $parts ) === 1 && $page === 1 ) { self::article_route( $parts[0] ); }
        self::not_found();
    }

    // TRACE: /{base}/{slug}/ → slug → live article page; with ?preview=1 and permission → the editor's working version (noindex, never cached); drafts/unknown → 404 (never leaks existence to visitors)
    private static function article_route( $slug ) {
        $preview = isset( $_GET['preview'] ) && $_GET['preview'] === '1' && is_user_logged_in();
        $edit = $preview && isset( $_GET['edit'] ) && $_GET['edit'] === '1';
        $p = null;
        if ( $preview ) {
            $any = Posts::by_slug_any( $slug );
            if ( $any && empty( $any['deleted_at'] ) && Access::can_see_post( $any ) ) { $p = $any; }
            else { self::not_found(); }
        } else {
            $p = Posts::live_by_slug( $slug );
            if ( ! $p ) { self::not_found(); }
            Posts::hit( $p['id'] );
        }
        $editable = is_user_logged_in() && Access::can( 'edit' ) && Access::can_edit_post( $p );
        $seo = $p['seo'];
        $img = $seo['og_image'] ? (int) $seo['og_image'] : ( $p['featured_media'] ?: (int) Settings::get( 'default_og_image' ) );
        $desc = $seo['description'] !== '' ? $seo['description'] : wp_trim_words( wp_strip_all_tags( $p['intro'] !== '' ? $p['intro'] : $p['subtitle'] ), 30, '…' );
        $meta = array(
            'title' => $seo['title'] !== '' ? $seo['title'] : $p['title'], 'desc' => $desc, 'canon' => $seo['canonical'] !== '' ? $seo['canonical'] : self::url( 'post', $p['slug'] ),
            'type' => 'article', 'og_title' => $seo['og_title'], 'og_desc' => $seo['og_description'], 'image' => $img ? Media::url( $img, 'large' ) : '', 'twitter' => $seo['twitter_card'],
            'noindex' => $preview || $seo['noindex'] || $p['status'] !== 'published', 'post' => $p, 'nocache' => $preview,
        );
        self::$edit_ctx = $editable ? array( 'post' => (int) $p['id'], 'start_edit' => $edit, 'preview' => $preview ) : null;
        $body = Render::article( $p, array( 'edit' => false ) );
        if ( $preview ) { $body = '<div class="nb-previewbar" role="status">Preview — ' . esc_html( ucfirst( $p['status'] ) ) . ( $p['has_working'] ? ' (with unpublished changes)' : '' ) . ' · only signed-in editors can see this page.</div>' . $body; }
        self::render_page( $meta, $body, 'article' );
    }

    // TRACE: unknown blog URL → none → 404 page in the blog design with a way back; sends status 404 and noindex → exits
    public static function not_found() {
        status_header( 404 );
        $body = '<div class="nb-wrap nb-empty nb-404"><h1 class="nb-title">Page not found</h1><p>The article you are looking for does not exist or is no longer available.</p><a class="nb-btn nb-btn-primary" href="' . esc_url( self::url( 'home' ) ) . '">Browse all articles</a></div>';
        self::render_page( array( 'title' => 'Page not found', 'desc' => '', 'canon' => '', 'type' => 'website', 'noindex' => true, 'nocache' => true ), $body, 'archive' );
    }

    // TRACE: /{base}/sitemap.xml → none → XML urlset of the home page and every live article (lastmod = updated_at UTC), no drafts → exits
    private static function sitemap() {
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare( 'SELECT slug, updated_at FROM ' . DB::t( 'posts' ) . " WHERE status='published' AND deleted_at IS NULL AND (published_at IS NULL OR published_at<=%s) ORDER BY updated_at DESC LIMIT 5000", DB::now() ), ARRAY_A ) ?: array();
        header( 'Content-Type: application/xml; charset=UTF-8' );
        header( 'X-Robots-Tag: noindex' );
        echo '<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"><url><loc>' . esc_url( self::url( 'home' ) ) . '</loc></url>';
        foreach ( $rows as $r ) { echo '<url><loc>' . esc_url( self::url( 'post', $r['slug'] ) ) . '</loc><lastmod>' . esc_html( gmdate( 'c', strtotime( $r['updated_at'] . ' UTC' ) ) ) . '</lastmod></url>'; }
        echo '</urlset>';
        exit;
    }

    // TRACE: render_page → meta array → the SEO <head> fragment: description, robots, canonical, prev/next, Open Graph, Twitter, JSON-LD (Article, Breadcrumb, FAQ) → string (all values escaped)
    private static function head( $m ) {
        $site = Settings::get( 'site_title' ) !== '' ? Settings::get( 'site_title' ) : get_bloginfo( 'name' );
        $h = '';
        if ( $m['desc'] !== '' ) { $h .= '<meta name="description" content="' . esc_attr( $m['desc'] ) . '">'; }
        $h .= '<meta name="robots" content="' . ( ! empty( $m['noindex'] ) ? 'noindex, nofollow' : 'index, follow, max-image-preview:large' ) . '">';
        if ( $m['canon'] !== '' ) { $h .= '<link rel="canonical" href="' . esc_url( $m['canon'] ) . '">'; }
        if ( ! empty( $m['prev'] ) ) { $h .= '<link rel="prev" href="' . esc_url( $m['prev'] ) . '">'; }
        if ( ! empty( $m['next'] ) ) { $h .= '<link rel="next" href="' . esc_url( $m['next'] ) . '">'; }
        $ogt = ! empty( $m['og_title'] ) ? $m['og_title'] : $m['title']; $ogd = ! empty( $m['og_desc'] ) ? $m['og_desc'] : $m['desc'];
        $h .= '<meta property="og:site_name" content="' . esc_attr( $site ) . '"><meta property="og:type" content="' . esc_attr( $m['type'] ) . '"><meta property="og:title" content="' . esc_attr( $ogt ) . '">';
        if ( $ogd !== '' ) { $h .= '<meta property="og:description" content="' . esc_attr( $ogd ) . '">'; }
        if ( $m['canon'] !== '' ) { $h .= '<meta property="og:url" content="' . esc_url( $m['canon'] ) . '">'; }
        if ( ! empty( $m['image'] ) ) { $h .= '<meta property="og:image" content="' . esc_url( $m['image'] ) . '">'; }
        $h .= '<meta name="twitter:card" content="' . esc_attr( ! empty( $m['image'] ) ? ( isset( $m['twitter'] ) ? $m['twitter'] : 'summary_large_image' ) : 'summary' ) . '"><meta name="twitter:title" content="' . esc_attr( $ogt ) . '">';
        if ( $ogd !== '' ) { $h .= '<meta name="twitter:description" content="' . esc_attr( $ogd ) . '">'; }
        if ( ! empty( $m['post'] ) && empty( $m['noindex'] ) ) {
            $p = $m['post'];
            $ld = array( array(
                '@context' => 'https://schema.org', '@type' => 'Article', 'headline' => $p['title'], 'description' => $m['desc'], 'mainEntityOfPage' => $m['canon'],
                'datePublished' => $p['published_at'] ? gmdate( 'c', strtotime( $p['published_at'] . ' UTC' ) ) : null, 'dateModified' => gmdate( 'c', strtotime( $p['updated_at'] . ' UTC' ) ),
                'author' => array( '@type' => 'Person', 'name' => $p['author']['name'] ), 'publisher' => array( '@type' => 'Organization', 'name' => $site ),
                'image' => ! empty( $m['image'] ) ? array( $m['image'] ) : null,
            ), array(
                '@context' => 'https://schema.org', '@type' => 'BreadcrumbList', 'itemListElement' => array(
                    array( '@type' => 'ListItem', 'position' => 1, 'name' => $site, 'item' => self::url( 'home' ) ),
                    array( '@type' => 'ListItem', 'position' => 2, 'name' => $p['title'], 'item' => $m['canon'] ),
                ),
            ) );
            $faq = array();
            foreach ( $p['blocks'] as $b ) { if ( $b['type'] === 'faq' ) { foreach ( $b['data']['items'] as $it ) { if ( $it['q'] !== '' && $it['a'] !== '' ) { $faq[] = array( '@type' => 'Question', 'name' => $it['q'], 'acceptedAnswer' => array( '@type' => 'Answer', 'text' => wp_strip_all_tags( Blocks::html( $it['a'] ) ) ) ); } } } }
            if ( $faq ) { $ld[] = array( '@context' => 'https://schema.org', '@type' => 'FAQPage', 'mainEntity' => $faq ); }
            foreach ( $ld as $obj ) { $h .= '<script type="application/ld+json">' . wp_json_encode( array_filter( $obj, function ( $v ) { return $v !== null; } ), JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE ) . '</script>'; }
        }
        return $h;
    }

    private static function social_icon( $t ) {
        $p = array(
            'facebook' => 'M14 8h2.5V5H14c-2 0-3.5 1.6-3.5 3.6V10H8.5v3h2v6h3v-6h2.2l.5-3h-2.7V8.6c0-.4.2-.6.5-.6z',
            'twitter'  => 'M19 7.2c-.5.2-1 .4-1.6.5.6-.4 1-.9 1.2-1.6-.5.3-1.1.5-1.8.7a2.8 2.8 0 0 0-4.8 2.5C9.7 9.2 7.6 8.1 6.2 6.4c-.8 1.3-.4 3 .9 3.800-.4 0-.8-.1-1.200-.3 0 1.400.9 2.500 2.300 2.800-.4.1-.8.100-1.200 0 .4 1.100 1.400 1.900 2.600 1.900A5.600 5.600 0 0 1 5 15.800 8 8 0 0 0 9.300 17c5.200 0 8-4.300 7.800-8.200.5-.4 1-.9 1.300-1.400z',
            'youtube'  => 'M10 9v6l5-3-5-3zm9.200-1.500c-.2-.7-.7-1.200-1.400-1.400C16.600 5.800 12 5.800 12 5.800s-4.600 0-5.800.3c-.7.200-1.200.7-1.400 1.400C4.500 8.700 4.500 12 4.500 12s0 3.300.3 4.500c.2.700.7 1.200 1.400 1.400 1.200.3 5.800.3 5.800.3s4.600 0 5.800-.3c.7-.2 1.200-.7 1.400-1.400.3-1.200.3-4.500.3-4.500s0-3.300-.3-4.500z',
            'instagram'=> 'M8 5h8a3 3 0 0 1 3 3v8a3 3 0 0 1-3 3H8a3 3 0 0 1-3-3V8a3 3 0 0 1 3-3zm4 3.500a3.500 3.500 0 1 0 0 7 3.500 3.500 0 0 0 0-7zm4.500-.8a.8.8 0 1 0 0 1.600.8.8 0 0 0 0-1.600z',
            'linkedin' => 'M7 9.500h2.500V18H7V9.500zM8.200 5.500a1.400 1.400 0 1 1 0 2.800 1.400 1.400 0 0 1 0-2.800zM11 9.500h2.400v1.200c.4-.7 1.300-1.400 2.600-1.400 2.600 0 3 1.700 3 3.900V18h-2.500v-4.300c0-1 0-2.300-1.400-2.300-1.400 0-1.600 1.100-1.600 2.200V18H11V9.500z',
            'whatsapp' => 'M12 5a7 7 0 0 0-6 10.600L5 19l3.500-1A7 7 0 1 0 12 5zm3.400 9.200c-.2.500-1 1-1.400 1-.4.100-.8.100-2.500-.6-2-.9-3.300-2.900-3.400-3-.1-.1-.8-1-.8-2s.5-1.400.7-1.600c.2-.2.400-.2.600-.2h.4c.1 0 .3 0 .5.400l.7 1.600c.1.100.1.300 0 .4l-.3.400-.3.300c-.1.100-.2.200-.1.400.1.200.6 1 1.300 1.600.9.800 1.600 1 1.800 1.100.2.100.4.100.5-.1l.7-.8c.2-.2.300-.2.500-.1l1.500.7c.2.100.4.200.4.300.1.200.1.600-.1 1z',
        );
        return isset( $p[ $t ] ) ? '<svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true"><path d="' . $p[ $t ] . '"/></svg>' : '';
    }

    // TRACE: render_page → none → the classic header: yellow strip (social icons, hours), white bar (logo or name, menu, phone button) → HTML
    private static function header_html() {
        $site = Settings::get( 'site_title' ) !== '' ? Settings::get( 'site_title' ) : get_bloginfo( 'name' );
        $c = Settings::chrome();
        $h = '<header class="nbc-head"><div class="nbc-strip"><div class="nbc-strip-in"><ul class="nbc-social">';
        foreach ( $c['social'] as $sc ) { $h .= '<li><a href="' . esc_url( $sc['url'] ) . '" target="_blank" rel="noopener noreferrer" aria-label="' . esc_attr( ucfirst( $sc['type'] ) ) . '">' . self::social_icon( $sc['type'] ) . '</a></li>'; }
        $h .= '</ul>' . ( $c['hours'] !== '' ? '<span class="nbc-hours"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><circle cx="12" cy="12" r="8"/><path d="M12 8v4l3 2"/></svg>' . esc_html( $c['hours'] ) . '</span>' : '' ) . '</div></div>';
        $logo = $c['logo'] ? Media::img( (int) $c['logo'], array( 'size' => 'medium', 'eager' => true, 'sizes_attr' => '200px' ) ) : '';
        $tel = preg_replace( '/[^0-9+]/', '', (string) strtok( str_replace( ',', ' ', $c['phone'] ), ' ' ) );
        $h .= '<div class="nbc-bar"><div class="nbc-bar-in"><a class="nbc-brand" href="' . esc_url( self::url( 'home' ) ) . '">' . ( $logo !== '' ? $logo : esc_html( $site ) ) . '</a><button class="nb-burger" type="button" aria-expanded="false" aria-controls="nb-nav" aria-label="Menu"><span></span><span></span><span></span></button><nav class="nbc-nav nb-nav" id="nb-nav" aria-label="Primary"><a href="' . esc_url( self::url( 'home' ) ) . '">Home</a>';
        foreach ( (array) Settings::get( 'nav_links' ) as $l ) { if ( ! empty( $l['label'] ) && ! empty( $l['url'] ) ) { $h .= '<a href="' . esc_url( $l['url'] ) . '">' . esc_html( $l['label'] ) . '</a>'; } }
        $h .= '</nav>' . ( $c['phone'] !== '' ? '<a class="nbc-phone" href="' . esc_url( 'tel:' . $tel ) . '"><svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" aria-hidden="true"><path d="M6.600 10.800a15 15 0 0 0 6.600 6.600l2.200-2.200c.3-.3.700-.4 1-.2 1.100.4 2.300.6 3.600.6.600 0 1 .4 1 1V20c0 .6-.4 1-1 1A17 17 0 0 1 3 4c0-.6.4-1 1-1h3.500c.6 0 1 .4 1 1 0 1.300.2 2.500.6 3.600.1.300 0 .7-.2 1l-2.300 2.200z"/></svg>' . esc_html( $c['phone'] ) . '</a>' : '' ) . '</div></div></header>';
        return $h;
    }

    // TRACE: render_page → none → the classic footer: blue columns (about, links, two service lists, subscribe), grey locations strip, teal copyright bar, floating WhatsApp button → HTML
    private static function footer_html() {
        $site = Settings::get( 'site_title' ) !== '' ? Settings::get( 'site_title' ) : get_bloginfo( 'name' );
        $c = Settings::chrome();
        $list = function ( $title, $items ) { if ( ! $items ) { return ''; } $o = '<nav class="nbc-fcol" aria-label="' . esc_attr( $title ) . '"><h3>' . esc_html( $title ) . '</h3><ul>'; foreach ( $items as $l ) { $o .= '<li><a href="' . esc_url( $l['url'] !== '' ? $l['url'] : '#' ) . '">' . esc_html( $l['label'] ) . '</a></li>'; } return $o . '</ul></nav>'; };
        $logo = $c['logo'] ? Media::img( (int) $c['logo'], array( 'size' => 'medium', 'sizes_attr' => '240px' ) ) : '';
        $about = Settings::get( 'footer_text' ) !== '' ? Settings::get( 'footer_text' ) : (string) Settings::get( 'tagline' );
        $h = '<footer class="nbc-foot"><div class="nbc-foot-top"><div class="nbc-foot-in"><div class="nbc-fabout">' . ( $logo !== '' ? '<span class="nbc-flogo">' . $logo . '</span>' : '<strong class="nbc-fname">' . esc_html( $site ) . '</strong>' ) . '<p>' . esc_html( $about ) . '</p></div>';
        $h .= $list( $c['links_title'], $c['links'] ) . $list( $c['col2_title'], $c['col2'] ) . $list( $c['col3_title'], $c['col3'] );
        if ( $c['subscribe_text'] !== '' || $c['subscribe_title'] !== '' ) { $h .= '<div class="nbc-fcol nbc-fsub"><h3>' . esc_html( $c['subscribe_title'] ) . '</h3><p>' . esc_html( $c['subscribe_text'] ) . '</p></div>'; }
        $h .= '</div></div>';
        if ( $c['locations'] ) {
            $h .= '<div class="nbc-locs"><div class="nbc-locs-in"><h2>' . esc_html( $c['locations_title'] ) . '</h2><div class="nbc-loclist">';
            foreach ( $c['locations'] as $l ) { $h .= '<div class="nbc-loc"><h3>' . esc_html( $l['city'] ) . '</h3><p>' . esc_html( $l['address'] ) . '</p></div>'; }
            $h .= '</div></div></div>';
        }
        $h .= '<div class="nbc-copy"><div class="nbc-copy-in">' . esc_html( $c['copyright'] !== '' ? $c['copyright'] : '© ' . gmdate( 'Y' ) . ' ' . $site . '. All rights reserved.' ) . '</div></div></footer>';
        if ( $c['whatsapp'] !== '' ) { $h .= '<a class="nbc-wa" href="' . esc_url( 'https://wa.me/' . $c['whatsapp'] ) . '" target="_blank" rel="noopener noreferrer" aria-label="Chat on WhatsApp">' . self::social_icon( 'whatsapp' ) . '</a>'; }
        return $h;
    }

    // TRACE: every blog route → meta, body HTML, kind → full document via the platform shell (public mode: indexable unless meta says otherwise, no admin-style no-cache) → exits
    //        edge: previews / 404s / editors → Cache-Control private, no-store; editor bundle is enqueued only when self::$edit_ctx is set (signed-in, permitted)
    private static function render_page( $meta, $body, $kind ) {
        $v = file_exists( NSH_DIR . 'blog/assets/blog-public.css' ) ? filemtime( NSH_DIR . 'blog/assets/blog-public.css' ) : NSH_VER;
        wp_enqueue_style( 'nsh-blog-public', NSH_URL . 'blog/assets/blog-public.css', array(), $v );
        wp_enqueue_style( 'nsh-blog-classic', NSH_URL . 'blog/assets/blog-classic.css', array( 'nsh-blog-public' ), file_exists( NSH_DIR . 'blog/assets/blog-classic.css' ) ? filemtime( NSH_DIR . 'blog/assets/blog-classic.css' ) : NSH_VER );
        wp_enqueue_script( 'nsh-blog-front', NSH_URL . 'blog/assets/blog-front.js', array(), file_exists( NSH_DIR . 'blog/assets/blog-front.js' ) ? filemtime( NSH_DIR . 'blog/assets/blog-front.js' ) : NSH_VER, true );
        do_action( 'nsh_blog_public_assets', self::$edit_ctx, $meta );
        if ( ! empty( $meta['nocache'] ) || self::$edit_ctx || is_user_logged_in() ) { nocache_headers(); }
        else { header( 'Cache-Control: public, max-age=300, s-maxage=600' ); }
        $acc = self::css_color( Settings::get( 'accent' ) );
        $head = self::head( $meta ) . '<style id="nb-vars">:root{--nb-accent:' . $acc . '}</style>';
        $page = self::header_html() . '<main id="nsh-main" class="nb-main nb-k-' . esc_attr( $kind ) . '">' . $body . '</main>' . self::footer_html();
        $page = '<div class="nb-root nbc">' . $page . '</div>';
        nsh_plat_render_shell( $meta['title'], 'blog', $page, array( 'public' => true, 'head' => $head, 'theme_color' => $acc ) );
    }
}
