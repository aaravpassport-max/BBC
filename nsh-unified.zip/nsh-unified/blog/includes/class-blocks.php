<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Blocks — the article content model. An article is an ordered list of sections ("blocks"); each has an id, a type and typed data.
 * Everything coming from a browser passes through sanitize_blocks()/sanitize_layout()/sanitize_seo() before it is stored.
 */
final class Blocks {
    public const MAX_BLOCKS = 80;
    public const MAX_ITEMS  = 40;

    // TRACE: editor "Add section" menu + renderer → none → every block type with its label and an empty-data factory → array
    public static function types() {
        return array(
            'text'         => array( 'label' => 'Text section', 'hint' => 'Heading and paragraphs' ),
            'steps'        => array( 'label' => 'Numbered steps', 'hint' => 'A process, step by step' ),
            'cards'        => array( 'label' => 'Info cards', 'hint' => 'Icon cards in a grid' ),
            'checklist'    => array( 'label' => 'Checklist', 'hint' => 'Ticked requirements' ),
            'image'        => array( 'label' => 'Image', 'hint' => 'Picture with caption and alt text' ),
            'callout'      => array( 'label' => 'Callout', 'hint' => 'Highlighted note or warning' ),
            'quote'        => array( 'label' => 'Quote', 'hint' => 'Pull quote with source' ),
            'faq'          => array( 'label' => 'FAQ', 'hint' => 'Questions and answers' ),
            'links'        => array( 'label' => 'Popular links', 'hint' => 'A list of related links' ),
            'testimonials' => array( 'label' => 'Testimonials', 'hint' => 'Customer quotes' ),
            'cta'          => array( 'label' => 'Call to action', 'hint' => 'Banner with buttons' ),
            'listcols'     => array( 'label' => 'Popular list (columns)', 'hint' => 'Names in columns with a button' ),
            'form'         => array( 'label' => 'Request form', 'hint' => 'The standalone request form, inline' ),
        );
    }

    public static function uid() { return 'b' . substr( md5( uniqid( '', true ) ), 0, 9 ); }

    // TRACE: "Add section" → type → a fresh block with friendly starter data → array|null (null for an unknown type)
    public static function make( $type ) {
        $d = array(
            'text'         => array( 'heading' => 'New section heading', 'level' => 'h2', 'body' => '<p>Write your content here.</p>' ),
            'steps'        => array( 'heading' => 'How it works', 'intro' => '', 'items' => array( array( 'title' => 'Step one', 'text' => 'Describe the first step.' ), array( 'title' => 'Step two', 'text' => 'Describe the next step.' ) ) ),
            'cards'        => array( 'heading' => 'Good to know', 'intro' => '', 'columns' => 3, 'items' => array( array( 'icon' => 'info', 'title' => 'Card title', 'text' => 'Short supporting text.' ), array( 'icon' => 'shield', 'title' => 'Card title', 'text' => 'Short supporting text.' ), array( 'icon' => 'clock', 'title' => 'Card title', 'text' => 'Short supporting text.' ) ) ),
            'checklist'    => array( 'heading' => 'What you need', 'items' => array( 'First requirement', 'Second requirement' ) ),
            'image'        => array( 'media' => 0, 'alt' => '', 'caption' => '', 'width' => 'content' ),
            'callout'      => array( 'tone' => 'info', 'title' => 'Good to know', 'text' => 'Add an important note here.' ),
            'quote'        => array( 'text' => 'A memorable line.', 'cite' => '' ),
            'faq'          => array( 'heading' => 'Frequently asked questions', 'items' => array( array( 'q' => 'Question?', 'a' => 'Answer.' ) ) ),
            'links'        => array( 'heading' => 'Popular links', 'items' => array( array( 'label' => 'Link label', 'url' => '/' ) ) ),
            'testimonials' => array( 'kicker' => '', 'heading' => 'What clients say', 'items' => array( array( 'quote' => 'Great service.', 'name' => 'Client name', 'role' => 'City' ) ) ),
            'cta'          => array( 'heading' => 'Ready to get started?', 'text' => 'Tell us what you need and we will take it from here.', 'button_label' => 'Get started', 'button_url' => '#', 'button2_label' => '', 'button2_url' => '', 'style' => 'primary' ),
            'listcols'     => array( 'heading' => 'Popular Universities', 'columns' => 3, 'items' => array( array( 'label' => 'First name', 'url' => '' ), array( 'label' => 'Second name', 'url' => '' ) ), 'button_label' => '', 'button_url' => '' ),
            'form'         => array( 'key' => 'inline', 'service' => '', 'title' => 'Get Estimated Quote Instantly' ),
        );
        return isset( $d[ $type ] ) ? array( 'id' => self::uid(), 'type' => $type, 'data' => $d[ $type ] ) : null;
    }

    // ── sanitizers ──────────────────────────────────────────────────────────
    public static function kses() {
        return array( 'p' => array(), 'br' => array(), 'strong' => array(), 'b' => array(), 'em' => array(), 'i' => array(), 'u' => array(), 'ul' => array(), 'ol' => array(), 'li' => array(), 'h3' => array(), 'h4' => array(), 'blockquote' => array(), 'code' => array(), 'a' => array( 'href' => true, 'target' => true, 'rel' => true ) );
    }
    // TRACE: any rich-text field → raw HTML → only the whitelisted inline/block tags survive; links get rel=noopener and unsafe protocols are dropped → string
    public static function html( $v ) {
        $h = wp_kses( (string) $v, self::kses(), array( 'http', 'https', 'mailto', 'tel' ) );
        return preg_replace_callback( '/<a\s[^>]*>/i', function ( $m ) {
            $t = $m[0];
            if ( stripos( $t, 'target="_blank"' ) !== false && stripos( $t, 'rel=' ) === false ) { $t = substr( $t, 0, -1 ) . ' rel="noopener noreferrer">'; }
            return $t;
        }, $h );
    }
    public static function txt( $v, $max = 300 ) { return mb_substr( sanitize_text_field( (string) $v ), 0, $max ); }
    // TRACE: any link field → URL → absolute http(s)/mailto/tel, site-relative path or #anchor kept; javascript:/data: etc. become '' → string
    public static function url( $v ) {
        $v = trim( (string) $v );
        if ( $v === '' ) { return ''; }
        if ( $v[0] === '#' ) { return '#' . sanitize_key( substr( $v, 1 ) ); }
        if ( $v[0] === '/' && ( ! isset( $v[1] ) || $v[1] !== '/' ) ) { return esc_url_raw( $v ); }
        return esc_url_raw( $v, array( 'http', 'https', 'mailto', 'tel' ) );
    }
    private static function items( $v, $fn ) {
        $out = array();
        foreach ( array_slice( is_array( $v ) ? array_values( $v ) : array(), 0, self::MAX_ITEMS ) as $it ) { $r = $fn( is_array( $it ) ? $it : array( 'text' => $it ) ); if ( $r !== null ) { $out[] = $r; } }
        return $out;
    }
    private static function one( $d, $k, $def = '' ) { return isset( $d[ $k ] ) ? $d[ $k ] : $def; }

    // TRACE: save paths → untrusted blocks array (from JSON) → at most 80 well-formed blocks with unique ids and per-type whitelisted data; unknown types are dropped → array
    public static function sanitize_blocks( $in ) {
        if ( is_string( $in ) ) { $in = json_decode( $in, true ); }
        if ( ! is_array( $in ) ) { return array(); }
        $types = self::types(); $out = array(); $ids = array();
        foreach ( array_slice( array_values( $in ), 0, self::MAX_BLOCKS ) as $b ) {
            if ( ! is_array( $b ) || empty( $b['type'] ) || ! isset( $types[ $b['type'] ] ) ) { continue; }
            $id = isset( $b['id'] ) ? preg_replace( '/[^a-z0-9_-]/i', '', (string) $b['id'] ) : '';
            if ( $id === '' || isset( $ids[ $id ] ) ) { $id = self::uid(); }
            $ids[ $id ] = 1;
            $d = isset( $b['data'] ) && is_array( $b['data'] ) ? $b['data'] : array();
            $blk = array( 'id' => $id, 'type' => $b['type'], 'data' => self::clean( $b['type'], $d ) );
            $tl = self::txt( isset( $b['toc'] ) ? $b['toc'] : '', 40 ); if ( $tl !== '' ) { $blk['toc'] = $tl; }
            $out[] = $blk;
        }
        return $out;
    }

    private static function clean( $type, $d ) {
        $t = array( __CLASS__, 'txt' );
        switch ( $type ) {
            case 'text':
                return array( 'heading' => self::txt( self::one( $d, 'heading' ), 200 ), 'level' => in_array( self::one( $d, 'level' ), array( 'h2', 'h3' ), true ) ? $d['level'] : 'h2', 'body' => self::html( self::one( $d, 'body' ) ) );
            case 'steps':
                return array( 'heading' => self::txt( self::one( $d, 'heading' ), 200 ), 'intro' => self::txt( self::one( $d, 'intro' ), 500 ), 'items' => self::items( self::one( $d, 'items', array() ), function ( $i ) { return array( 'title' => Blocks::txt( self::pick( $i, 'title' ), 200 ), 'text' => Blocks::html( self::pick( $i, 'text' ) ) ); } ) );
            case 'cards':
                return array( 'heading' => self::txt( self::one( $d, 'heading' ), 200 ), 'intro' => self::txt( self::one( $d, 'intro' ), 500 ), 'columns' => in_array( (int) self::one( $d, 'columns', 3 ), array( 2, 3, 4 ), true ) ? (int) $d['columns'] : 3, 'items' => self::items( self::one( $d, 'items', array() ), function ( $i ) { return array( 'icon' => Blocks::icon( self::pick( $i, 'icon' ) ), 'title' => Blocks::txt( self::pick( $i, 'title' ), 200 ), 'text' => Blocks::txt( self::pick( $i, 'text' ), 600 ) ); } ) );
            case 'checklist':
                return array( 'heading' => self::txt( self::one( $d, 'heading' ), 200 ), 'items' => self::items( self::one( $d, 'items', array() ), function ( $i ) { $x = Blocks::txt( isset( $i['text'] ) ? $i['text'] : '', 300 ); return $x === '' ? null : $x; } ) );
            case 'image':
                return array( 'media' => max( 0, (int) self::one( $d, 'media', 0 ) ), 'alt' => self::txt( self::one( $d, 'alt' ), 300 ), 'caption' => self::txt( self::one( $d, 'caption' ), 500 ), 'width' => in_array( self::one( $d, 'width' ), array( 'content', 'wide', 'full' ), true ) ? $d['width'] : 'content', 'link' => self::url( self::one( $d, 'link' ) ) );
            case 'callout':
                return array( 'tone' => in_array( self::one( $d, 'tone' ), array( 'info', 'success', 'warning' ), true ) ? $d['tone'] : 'info', 'title' => self::txt( self::one( $d, 'title' ), 150 ), 'text' => self::html( self::one( $d, 'text' ) ) );
            case 'quote':
                return array( 'text' => self::txt( self::one( $d, 'text' ), 600 ), 'cite' => self::txt( self::one( $d, 'cite' ), 150 ) );
            case 'faq':
                return array( 'heading' => self::txt( self::one( $d, 'heading' ), 200 ), 'items' => self::items( self::one( $d, 'items', array() ), function ( $i ) { $q = Blocks::txt( self::pick( $i, 'q' ), 300 ); return $q === '' ? null : array( 'q' => $q, 'a' => Blocks::html( self::pick( $i, 'a' ) ) ); } ) );
            case 'links':
                return array( 'heading' => self::txt( self::one( $d, 'heading' ), 200 ), 'items' => self::items( self::one( $d, 'items', array() ), function ( $i ) { $l = Blocks::txt( self::pick( $i, 'label' ), 150 ); return $l === '' ? null : array( 'label' => $l, 'url' => Blocks::url( self::pick( $i, 'url' ) ) ); } ) );
            case 'testimonials':
                return array( 'kicker' => self::txt( self::one( $d, 'kicker' ), 80 ), 'heading' => self::txt( self::one( $d, 'heading' ), 200 ), 'items' => self::items( self::one( $d, 'items', array() ), function ( $i ) { $q = Blocks::txt( self::pick( $i, 'quote' ), 600 ); return $q === '' ? null : array( 'quote' => $q, 'name' => Blocks::txt( self::pick( $i, 'name' ), 100 ), 'role' => Blocks::txt( self::pick( $i, 'role' ), 100 ) ); } ) );
            case 'listcols':
                return array( 'heading' => self::txt( self::one( $d, 'heading' ), 200 ), 'columns' => in_array( (int) self::one( $d, 'columns', 3 ), array( 2, 3, 4 ), true ) ? (int) $d['columns'] : 3, 'items' => self::items( self::one( $d, 'items', array() ), function ( $i ) { $l = Blocks::txt( self::pick( $i, 'label' ), 200 ); return $l === '' ? null : array( 'label' => $l, 'url' => Blocks::url( self::pick( $i, 'url' ) ) ); } ), 'button_label' => self::txt( self::one( $d, 'button_label' ), 60 ), 'button_url' => self::url( self::one( $d, 'button_url' ) ) );
            case 'cta':
                return array( 'heading' => self::txt( self::one( $d, 'heading' ), 200 ), 'text' => self::txt( self::one( $d, 'text' ), 500 ), 'button_label' => self::txt( self::one( $d, 'button_label' ), 60 ), 'button_url' => self::url( self::one( $d, 'button_url' ) ), 'button2_label' => self::txt( self::one( $d, 'button2_label' ), 60 ), 'button2_url' => self::url( self::one( $d, 'button2_url' ) ), 'style' => in_array( self::one( $d, 'style' ), array( 'primary', 'dark', 'soft' ), true ) ? $d['style'] : 'primary' );
            case 'form':
                return array( 'key' => 'inline', 'service' => sanitize_title( (string) self::one( $d, 'service' ) ), 'title' => self::txt( self::one( $d, 'title' ), 120 ) );
        }
        return array();
    }
    public static function pick( $i, $k ) { return isset( $i[ $k ] ) ? $i[ $k ] : ''; }
    // TRACE: card icons → name → one of the built-in icon names (unknown → "info") → string
    public static function icon( $n ) { $n = sanitize_key( (string) $n ); return isset( self::icons()[ $n ] ) ? $n : 'info'; }
    public static function icons() {
        return array(
            'info' => '<circle cx="12" cy="12" r="9"/><path d="M12 11v5M12 8h.01"/>', 'shield' => '<path d="M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z"/><path d="M9 12l2 2 4-4"/>',
            'clock' => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', 'file' => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
            'globe' => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3.4 3.6 3.4 14.4 0 18M12 3c-3.4 3.6-3.4 14.4 0 18"/>', 'card' => '<rect x="2" y="5" width="20" height="14" rx="2.4"/><path d="M2 10h20"/>',
            'check' => '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.7 2.7L16 9.5"/>', 'user' => '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
            'truck' => '<path d="M3 7h11v9H3zM14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="1.6"/><circle cx="17" cy="18" r="1.6"/>', 'star' => '<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
            'phone' => '<path d="M5 4h4l2 5-2.5 1.5a11 11 0 0 0 5 5L15 13l5 2v4a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/>', 'cap' => '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c0 1.5 2.7 3 6 3s6-1.5 6-3v-5"/>',
            'stamp' => '<path d="M5 21h14M7 17h10v-3a3 3 0 0 0-3-3h-4a3 3 0 0 0-3 3z"/><path d="M12 11V7a2.5 2.5 0 1 1 5 0"/>', 'bolt' => '<path d="M13 2L4 14h7l-1 8 9-12h-7z"/>',
        );
    }

    // ── layout (hero, trust strip, sidebar, form placements) ───────────────
    // TRACE: new article / settings → none → the default layout every article starts from (also the site-wide defaults the settings screen edits) → array
    public static function layout_defaults() {
        return array(
            'template' => 'classic',
            'hero' => array( 'heading' => '', 'keywords' => '', 'boxes' => array( array( 'title' => 'Timeline and Cost', 'items' => array() ), array( 'title' => 'Our Services', 'items' => array() ), array( 'title' => 'Documents Required', 'items' => array() ) ), 'stats' => array(), 'eyebrow' => '', 'chips' => array( 'Fast & secure', 'Expert support', 'Track online' ), 'cta1' => array( 'label' => 'Get a quote', 'url' => '#hero-form' ), 'cta2' => array( 'label' => 'How it works', 'url' => '#nb-article' ) ),
            'trust' => array( array( 'icon' => 'shield', 'text' => '100% secure & confidential' ), array( 'icon' => 'clock', 'text' => 'Quick turnaround' ), array( 'icon' => 'globe', 'text' => 'Worldwide delivery' ), array( 'icon' => 'star', 'text' => 'Trusted by thousands' ) ),
            'toc' => 1,
            'search' => array( 'show' => 1, 'title' => 'SEARCH FOR THE ARTICLES HERE', 'placeholder' => 'Search here...' ),
            'forms' => array( 'hero' => array( 'enabled' => 1, 'service' => '', 'title' => 'Get Estimated Quote Instantly' ), 'aside' => array( 'enabled' => 1, 'service' => '', 'title' => 'Get Estimated Quote Instantly' ) ),
            'why' => array( 'title' => 'Why choose us', 'items' => array() ),
            'latest' => array( 'show' => 1, 'count' => 4, 'title' => 'Blog Post' ),
        );
    }

    // TRACE: layout save → untrusted hero info boxes → at most 3 {title, items[≤8]} (boxes with neither title nor items are dropped) → array
    private static function boxes( $in ) {
        $out = array();
        foreach ( array_slice( is_array( $in ) ? array_values( $in ) : array(), 0, 3 ) as $b ) {
            if ( ! is_array( $b ) ) { continue; }
            $items = array(); foreach ( array_slice( (array) self::one( $b, 'items', array() ), 0, 8 ) as $x ) { $x = self::txt( $x, 220 ); if ( $x !== '' ) { $items[] = $x; } }
            $t = self::txt( self::one( $b, 'title' ), 80 );
            if ( $t !== '' || $items ) { $out[] = array( 'title' => $t, 'items' => $items ); }
        }
        return $out;
    }
    // TRACE: layout save → untrusted hero counters → at most 4 {value, label} with a value or label → array
    private static function stats( $in ) {
        $out = array();
        foreach ( array_slice( is_array( $in ) ? array_values( $in ) : array(), 0, 4 ) as $s ) {
            if ( ! is_array( $s ) ) { continue; }
            $v = self::txt( self::one( $s, 'value' ), 20 ); $l = self::txt( self::one( $s, 'label' ), 40 );
            if ( $v !== '' || $l !== '' ) { $out[] = array( 'value' => $v, 'label' => $l ); }
        }
        return $out;
    }

    // TRACE: save paths → untrusted layout (array or JSON) → fully populated, whitelisted layout; missing keys fall back to defaults (empty arrays are kept when explicitly sent) → array
    public static function sanitize_layout( $in, $base = null ) {
        if ( is_string( $in ) ) { $in = json_decode( $in, true ); }
        $in = is_array( $in ) ? $in : array();
        $d  = is_array( $base ) ? array_replace_recursive( self::layout_defaults(), $base ) : self::layout_defaults();
        $out = $d;
        $out['template'] = isset( $in['template'] ) && $in['template'] === 'nri' ? 'nri' : ( isset( $in['template'] ) ? 'classic' : ( isset( $d['template'] ) && $d['template'] === 'nri' ? 'nri' : 'classic' ) );
        if ( isset( $in['hero'] ) && is_array( $in['hero'] ) ) {
            $h = $in['hero'];
            $out['hero'] = array(
                'heading' => self::txt( self::one( $h, 'heading' ), 200 ),
                'keywords' => self::txt( self::one( $h, 'keywords' ), 500 ),
                'boxes'   => self::boxes( self::one( $h, 'boxes', array() ) ),
                'stats'   => self::stats( self::one( $h, 'stats', array() ) ),
                'eyebrow' => self::txt( self::one( $h, 'eyebrow' ), 80 ),
                'chips'   => array_values( array_filter( array_map( function ( $c ) { return Blocks::txt( $c, 40 ); }, array_slice( (array) self::one( $h, 'chips', array() ), 0, 6 ) ) ) ),
                'cta1'    => array( 'label' => self::txt( isset( $h['cta1']['label'] ) ? $h['cta1']['label'] : '', 40 ), 'url' => self::url( isset( $h['cta1']['url'] ) ? $h['cta1']['url'] : '' ) ),
                'cta2'    => array( 'label' => self::txt( isset( $h['cta2']['label'] ) ? $h['cta2']['label'] : '', 40 ), 'url' => self::url( isset( $h['cta2']['url'] ) ? $h['cta2']['url'] : '' ) ),
            );
        }
        if ( isset( $in['search'] ) && is_array( $in['search'] ) ) {
            $out['search'] = array( 'show' => ! empty( $in['search']['show'] ) ? 1 : 0, 'title' => self::txt( self::one( $in['search'], 'title' ), 100 ), 'placeholder' => self::txt( self::one( $in['search'], 'placeholder' ), 60 ) );
        }
        if ( isset( $in['trust'] ) && is_array( $in['trust'] ) ) {
            $out['trust'] = array();
            foreach ( array_slice( array_values( $in['trust'] ), 0, 6 ) as $t ) { $x = self::txt( is_array( $t ) ? self::one( $t, 'text' ) : $t, 80 ); if ( $x !== '' ) { $out['trust'][] = array( 'icon' => self::icon( is_array( $t ) ? self::one( $t, 'icon' ) : 'info' ), 'text' => $x ); } }
        }
        if ( array_key_exists( 'toc', $in ) ) { $out['toc'] = $in['toc'] ? 1 : 0; }
        if ( isset( $in['forms'] ) && is_array( $in['forms'] ) ) {
            foreach ( array( 'hero', 'aside' ) as $k ) {
                if ( isset( $in['forms'][ $k ] ) && is_array( $in['forms'][ $k ] ) ) {
                    $f = $in['forms'][ $k ];
                    $out['forms'][ $k ] = array( 'enabled' => ! empty( $f['enabled'] ) ? 1 : 0, 'service' => sanitize_title( (string) self::one( $f, 'service' ) ), 'title' => self::txt( self::one( $f, 'title' ), 120 ) );
                }
            }
        }
        if ( isset( $in['why'] ) && is_array( $in['why'] ) ) {
            $out['why'] = array( 'title' => self::txt( self::one( $in['why'], 'title' ), 100 ), 'items' => array() );
            foreach ( array_slice( (array) self::one( $in['why'], 'items', array() ), 0, 8 ) as $i ) { $x = self::txt( is_array( $i ) ? self::one( $i, 'text' ) : $i, 120 ); if ( $x !== '' ) { $out['why']['items'][] = array( 'icon' => 'check', 'text' => $x ); } }
        }
        if ( isset( $in['latest'] ) && is_array( $in['latest'] ) ) {
            $out['latest'] = array( 'show' => ! empty( $in['latest']['show'] ) ? 1 : 0, 'count' => max( 1, min( 6, (int) self::one( $in['latest'], 'count', 3 ) ) ), 'title' => self::txt( self::one( $in['latest'], 'title' ), 100 ) );
        }
        return $out;
    }

    // TRACE: save paths → untrusted SEO array → whitelisted SEO/social fields (title ≤ 70, description ≤ 200, canonical must be a valid http(s) URL) → array
    public static function sanitize_seo( $in ) {
        if ( is_string( $in ) ) { $in = json_decode( $in, true ); }
        $in = is_array( $in ) ? $in : array();
        $canon = isset( $in['canonical'] ) ? esc_url_raw( trim( (string) $in['canonical'] ), array( 'http', 'https' ) ) : '';
        return array(
            'title' => self::txt( self::one( $in, 'title' ), 70 ), 'description' => self::txt( self::one( $in, 'description' ), 200 ), 'canonical' => $canon,
            'og_title' => self::txt( self::one( $in, 'og_title' ), 90 ), 'og_description' => self::txt( self::one( $in, 'og_description' ), 200 ), 'og_image' => max( 0, (int) self::one( $in, 'og_image', 0 ) ),
            'twitter_card' => in_array( self::one( $in, 'twitter_card' ), array( 'summary', 'summary_large_image' ), true ) ? $in['twitter_card'] : 'summary_large_image',
            'noindex' => ! empty( $in['noindex'] ) ? 1 : 0, 'focus' => self::txt( self::one( $in, 'focus' ), 80 ),
        );
    }
}
