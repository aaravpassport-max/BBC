<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Terms — the blog's own categories and tags (separate from WordPress categories/tags). */
final class Terms {
    public const TYPES = array( 'category' => 'Category', 'tag' => 'Tag' );

    // TRACE: pickers/archives → type, public-only flag → terms ordered by sort then name, each with the count of PUBLISHED articles → array
    public static function all( $type, $public_only = false ) {
        global $wpdb;
        $t = DB::t( 'terms' ); $pt = DB::t( 'post_terms' ); $p = DB::t( 'posts' );
        $sql = "SELECT t.*, (SELECT COUNT(*) FROM $pt x JOIN $p q ON q.id=x.post_id WHERE x.term_id=t.id AND q.status='published' AND q.deleted_at IS NULL AND (q.published_at IS NULL OR q.published_at<=%s)) AS cnt FROM $t t WHERE t.type=%s ORDER BY t.sort_order, t.name";
        $rows = $wpdb->get_results( $wpdb->prepare( $sql, DB::now(), $type ), ARRAY_A ) ?: array();
        foreach ( $rows as &$r ) { $r['id'] = (int) $r['id']; $r['cnt'] = (int) $r['cnt']; }
        return $public_only ? array_values( array_filter( $rows, function ( $r ) { return $r['cnt'] > 0; } ) ) : $rows;
    }
    public static function get( $id ) { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . DB::t( 'terms' ) . ' WHERE id=%d', (int) $id ), ARRAY_A ) ?: null; }
    public static function by_slug( $type, $slug ) { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . DB::t( 'terms' ) . ' WHERE type=%s AND slug=%s', $type, sanitize_title( $slug ) ), ARRAY_A ) ?: null; }

    // TRACE: manager/editor quick-add → input {id?, type, name, slug?, description?} → creates or updates a term with a unique slug within its type → term array | WP_Error
    public static function save( $in ) {
        global $wpdb;
        $type = isset( $in['type'] ) && isset( self::TYPES[ $in['type'] ] ) ? $in['type'] : '';
        $name = sanitize_text_field( (string) ( isset( $in['name'] ) ? $in['name'] : '' ) );
        if ( $type === '' || $name === '' ) { return new \WP_Error( 'nsh_blog_term', 'A name is required.' ); }
        $id   = (int) ( isset( $in['id'] ) ? $in['id'] : 0 );
        $slug = sanitize_title( (string) ( ! empty( $in['slug'] ) ? $in['slug'] : $name ) ) ?: 'term';
        $base = $slug; $n = 2;
        while ( ( $ex = $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . DB::t( 'terms' ) . ' WHERE type=%s AND slug=%s', $type, $slug ) ) ) && (int) $ex !== $id ) { $slug = $base . '-' . $n++; }
        $row = array( 'type' => $type, 'name' => $name, 'slug' => $slug, 'description' => mb_substr( sanitize_text_field( (string) ( isset( $in['description'] ) ? $in['description'] : '' ) ), 0, 500 ) );
        if ( $id ) { $ok = $wpdb->update( DB::t( 'terms' ), $row, array( 'id' => $id ) ); }
        else { $row['created_at'] = DB::now(); $ok = $wpdb->insert( DB::t( 'terms' ), $row ); $id = (int) $wpdb->insert_id; }
        if ( $ok === false ) { return new \WP_Error( 'nsh_blog_db', 'Could not save the ' . $type . '.' ); }
        Audit::log( 0, 'term_save', $type . ':' . $slug );
        return self::get( $id );
    }
    // TRACE: manager "delete" → term id → removes the term and its article links; articles whose primary category it was fall back to none → true | WP_Error
    public static function delete( $id ) {
        global $wpdb;
        $t = self::get( $id );
        if ( ! $t ) { return new \WP_Error( 'nsh_blog_term', 'Not found.' ); }
        $wpdb->delete( DB::t( 'post_terms' ), array( 'term_id' => (int) $id ) );
        $wpdb->update( DB::t( 'posts' ), array( 'category_id' => 0 ), array( 'category_id' => (int) $id ) );
        $ok = $wpdb->delete( DB::t( 'terms' ), array( 'id' => (int) $id ) );
        if ( ! $ok ) { return new \WP_Error( 'nsh_blog_db', 'Could not delete.' ); }
        Audit::log( 0, 'term_delete', $t['type'] . ':' . $t['slug'] );
        return true;
    }
    // TRACE: article hydrate → post id → its tags and category as arrays → array( 'category' => term|null, 'tags' => term[] )
    public static function for_post( $post_id, $category_id = 0 ) {
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare( 'SELECT t.* FROM ' . DB::t( 'terms' ) . ' t JOIN ' . DB::t( 'post_terms' ) . ' x ON x.term_id=t.id WHERE x.post_id=%d ORDER BY t.name', (int) $post_id ), ARRAY_A ) ?: array();
        $tags = array_values( array_filter( $rows, function ( $r ) { return $r['type'] === 'tag'; } ) );
        return array( 'category' => $category_id ? self::get( $category_id ) : null, 'tags' => $tags );
    }
    // TRACE: article save → post id, tag ids → replaces the article's tag links with the given tags that exist (typed new names are created by the caller first) → void
    public static function set_tags( $post_id, $tag_ids ) {
        global $wpdb;
        $post_id = (int) $post_id;
        $wpdb->delete( DB::t( 'post_terms' ), array( 'post_id' => $post_id ) );
        foreach ( array_unique( array_map( 'intval', (array) $tag_ids ) ) as $tid ) {
            $t = self::get( $tid );
            if ( $t && $t['type'] === 'tag' ) { $wpdb->insert( DB::t( 'post_terms' ), array( 'post_id' => $post_id, 'term_id' => $tid ) ); }
        }
    }
}
