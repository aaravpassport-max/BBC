<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Audit — append-only record of who did what (never updated or deleted by the plugin). */
final class Audit {
    // TRACE: every write path → post id (0 = none), action key, detail → inserts one row stamped with the acting user and UTC time; a failed insert is logged, never fatal → void
    public static function log( $post_id, $action, $detail = '' ) {
        global $wpdb;
        $ok = $wpdb->insert( DB::t( 'audit' ), array( 'post_id' => (int) $post_id, 'user_id' => get_current_user_id(), 'action' => substr( sanitize_key( $action ), 0, 40 ), 'detail' => mb_substr( (string) $detail, 0, 400 ), 'created_at' => DB::now() ), array( '%d', '%d', '%s', '%s', '%s' ) );
        if ( $ok === false ) { error_log( '[NSH Blog] audit insert failed: ' . $wpdb->last_error ); }
    }
    // TRACE: editor "Activity" panel → post id → latest 50 entries with the user's display name → array
    public static function for_post( $post_id ) {
        global $wpdb;
        $rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . DB::t( 'audit' ) . ' WHERE post_id=%d ORDER BY id DESC LIMIT 50', (int) $post_id ), ARRAY_A ) ?: array();
        foreach ( $rows as &$r ) { $u = get_userdata( (int) $r['user_id'] ); $r['user'] = $u ? $u->display_name : 'System'; }
        return $rows;
    }
}
