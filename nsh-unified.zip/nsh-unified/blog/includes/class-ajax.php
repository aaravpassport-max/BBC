<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Ajax — the single authenticated endpoint (admin-ajax action "nsh_blog", logged-in only, no nopriv) for the blog CMS and the inline editor.
 * Every request: nonce "nsh_blog" → signed-in check → per-operation permission (Access::guard) → whitelisted input → JSON.
 * Operations are listed once in OPS (name => required permission), so an unknown or unpermitted op can never reach a handler.
 */
final class Ajax {
    private const OPS = array(
        'boot' => 'any', 'posts' => 'any', 'post_get' => 'any', 'post_save' => 'any', 'post_transition' => 'any', 'post_publish_working' => 'publish', 'post_discard_working' => 'any',
        'post_duplicate' => 'create', 'post_trash' => 'any', 'post_restore' => 'any', 'post_purge' => 'delete', 'post_revisions' => 'any', 'post_restore_revision' => 'any', 'post_audit' => 'any', 'bulk' => 'any',
        'terms' => 'any', 'term_save' => 'taxonomy', 'term_delete' => 'taxonomy',
        'media_list' => 'any', 'media_upload' => 'media', 'media_update' => 'media', 'media_delete' => 'media',
        'team' => 'admin', 'team_save' => 'admin', 'team_create' => 'admin', 'team_resend' => 'admin',
        'settings_get' => 'admin', 'settings_save' => 'admin', 'profile_save' => 'any', 'inline_boot' => 'any', 'inline_render' => 'any',
    );

    public static function init() { add_action( 'wp_ajax_nsh_blog', array( __CLASS__, 'handle' ) ); }

    // TRACE: nonce → one nonce for the whole blog UI, created for the signed-in user → string
    public static function nonce() { return wp_create_nonce( 'nsh_blog' ); }

    // TRACE: JSON field → request key → decoded array (max 1.5 MB, unslashed); invalid JSON → empty array
    private static function json( $key ) {
        $raw = isset( $_POST[ $key ] ) ? wp_unslash( (string) $_POST[ $key ] ) : '';
        if ( strlen( $raw ) > 1572864 ) { wp_send_json_error( array( 'message' => 'That is too much content to save at once.', 'code' => 'size' ), 413 ); }
        $d = json_decode( $raw, true );
        return is_array( $d ) ? $d : array();
    }
    private static function int( $key ) { return isset( $_POST[ $key ] ) ? absint( wp_unslash( $_POST[ $key ] ) ) : 0; }
    private static function str( $key ) { return isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( (string) $_POST[ $key ] ) ) : ''; }

    // TRACE: any op result → value | WP_Error → success JSON, or an error JSON carrying the message, code and (for conflicts) the latest article with status 409
    private static function out( $v ) {
        if ( is_wp_error( $v ) ) {
            $data = $v->get_error_data();
            wp_send_json_error( array( 'message' => $v->get_error_message(), 'code' => $v->get_error_code(), 'data' => is_array( $data ) ? $data : null ), $v->get_error_code() === 'conflict' ? 409 : 400 );
        }
        wp_send_json_success( $v );
    }

    // TRACE: admin-ajax → POST op → nonce, auth and permission gates → handler → JSON; unknown op → 400
    //        edge: nonce failure → 403 JSON "Your session expired", never a raw "-1"
    public static function handle() {
        if ( ! check_ajax_referer( 'nsh_blog', 'nonce', false ) ) { wp_send_json_error( array( 'message' => 'Your session expired. Please reload the page.', 'code' => 'nonce' ), 403 ); }
        $op = isset( $_POST['op'] ) ? sanitize_key( wp_unslash( (string) $_POST['op'] ) ) : '';
        if ( ! isset( self::OPS[ $op ] ) ) { wp_send_json_error( array( 'message' => 'Unknown request.', 'code' => 'op' ), 400 ); }
        Access::guard( self::OPS[ $op ] );
        $uid = get_current_user_id();
        self::out( self::{'op_' . $op}( $uid ) );
    }

    // ── helpers ──
    // TRACE: post-scoped ops → id → the article only if the current user may see it, else a 404-style error (never reveals other people's drafts)
    private static function visible( $id ) {
        $p = Posts::get( $id );
        if ( ! $p || ! empty( $p['deleted_at'] ) && ! Access::can( 'delete' ) && ! Access::can_edit_post( $p ) ) { return new \WP_Error( 'nsh_blog_missing', 'That article no longer exists.' ); }
        if ( ! Access::can_see_post( $p ) ) { return new \WP_Error( 'nsh_blog_missing', 'That article no longer exists.' ); }
        return $p;
    }
    private static function terms_payload() { return array( 'categories' => Terms::all( 'category' ), 'tags' => Terms::all( 'tag' ) ); }

    // TRACE: boot / inline boot → none → one freshly made default block per type (new ids are generated client-side when added) → array
    private static function catalogue() { $c = array(); foreach ( array( 'text', 'steps', 'cards', 'checklist', 'image', 'callout', 'quote', 'faq', 'links', 'testimonials', 'listcols', 'cta', 'form' ) as $t ) { $c[ $t ] = Blocks::make( $t ); } return $c; }
    // TRACE: editor payloads → article → the same article with a preview thumbnail URL on every image block (editor-only field "_url", stripped again before saving) → array
    private static function deco( $p ) {
        foreach ( $p['blocks'] as $i => $b ) { if ( $b['type'] === 'image' && ! empty( $b['data']['media'] ) ) { $p['blocks'][ $i ]['data']['_url'] = Media::url( (int) $b['data']['media'], 'thumb' ); } }
        return $p;
    }

    // TRACE: service pickers → none → active Services Hub services as {slug,name} (the standalone form's `service` attribute is a slug) → array
    private static function services() { return function_exists( 'nsh_get_services' ) ? array_map( function ( $x ) { return array( 'slug' => (string) $x->slug, 'name' => (string) $x->name ); }, (array) nsh_get_services( true ) ) : array(); }

    // ── bootstrap ──
    private static function op_boot( $uid ) {
        $u = wp_get_current_user();
        return array(
            'me' => array( 'id' => $uid, 'name' => $u->display_name, 'admin' => Access::is_admin( $uid ), 'perms' => Access::perms_of( $uid ), 'profile' => Authors::card( $uid ) ),
            'counts' => Posts::status_counts( Access::can( 'edit_all' ) ? 0 : $uid ),
            'terms' => self::terms_payload(), 'statuses' => Posts::STATUSES, 'icons' => array_keys( Blocks::icons() ),
            'catalogue' => self::catalogue(), 'layout_defaults' => Settings::get( 'layout_defaults' ), 'public_base' => Settings::get( 'public_base' ), 'home_url' => Front::url( 'home' ),
            'services' => self::services(),
        );
    }

    // ── articles ──
    private static function op_posts( $uid ) {
        $q = array( 'status' => self::str( 'status' ) ?: 'all', 'q' => self::str( 'q' ), 'category' => self::int( 'category' ), 'tag' => self::int( 'tag' ), 'page' => max( 1, self::int( 'page' ) ), 'per' => 20, 'orderby' => self::str( 'orderby' ) );
        if ( ! Access::can( 'edit_all' ) ) { $q['visible_to'] = $uid; }
        $res = Posts::query( $q );
        $res['counts'] = Posts::status_counts( Access::can( 'edit_all' ) ? 0 : $uid );
        return $res;
    }
    private static function op_post_get( $uid ) { $p = self::visible( self::int( 'id' ) ); return is_wp_error( $p ) ? $p : array( 'post' => self::deco( $p ), 'can_edit' => Access::can_edit_post( $p ), 'can_publish' => Access::can( 'publish' ) ); }
    // TRACE: editor Save / inline Save → {id?, version, fields…} → drops "seo" when the user lacks the SEO permission → Posts::save (permission, optimistic lock, working-copy rules inside) → article
    private static function op_post_save( $uid ) {
        $in = self::json( 'data' );
        if ( ! Access::can( 'seo', $uid ) ) { unset( $in['seo'] ); }
        $r = Posts::save( $in, $uid );
        return is_wp_error( $r ) ? $r : array( 'post' => self::deco( $r ), 'can_publish' => Access::can( 'publish' ) );
    }
    private static function op_post_transition( $uid ) {
        $r = Posts::transition( self::int( 'id' ), self::str( 'to' ), array( 'scheduled_at' => self::str( 'scheduled_at' ) ), $uid );
        return is_wp_error( $r ) ? $r : array( 'post' => $r );
    }
    private static function op_post_publish_working( $uid ) { $r = Posts::publish_working( self::int( 'id' ), $uid ); return is_wp_error( $r ) ? $r : array( 'post' => self::deco( $r ) ); }
    private static function op_post_discard_working( $uid ) { $r = Posts::discard_working( self::int( 'id' ), $uid ); return is_wp_error( $r ) ? $r : array( 'post' => self::deco( $r ) ); }
    private static function op_post_duplicate( $uid ) { $r = Posts::duplicate( self::int( 'id' ), $uid ); return is_wp_error( $r ) ? $r : array( 'post' => self::deco( $r ) ); }
    private static function op_post_trash( $uid ) { $r = Posts::trash( self::int( 'id' ), $uid ); return is_wp_error( $r ) ? $r : array( 'ok' => true ); }
    private static function op_post_restore( $uid ) { $r = Posts::restore( self::int( 'id' ), $uid ); return is_wp_error( $r ) ? $r : array( 'ok' => true ); }
    private static function op_post_purge( $uid ) { $r = Posts::purge( self::int( 'id' ), $uid ); return is_wp_error( $r ) ? $r : array( 'ok' => true ); }
    private static function op_post_revisions( $uid ) { $p = self::visible( self::int( 'id' ) ); return is_wp_error( $p ) ? $p : array( 'items' => Posts::revisions( $p['id'] ) ); }
    private static function op_post_restore_revision( $uid ) { $r = Posts::restore_revision( self::int( 'rev' ), $uid ); return is_wp_error( $r ) ? $r : array( 'post' => self::deco( $r ) ); }
    private static function op_post_audit( $uid ) { $p = self::visible( self::int( 'id' ) ); return is_wp_error( $p ) ? $p : array( 'items' => Audit::for_post( $p['id'] ) ); }

    // TRACE: list bulk bar → action (trash|restore|draft|pending|published|archived), ids[] (max 100) → applies each through the same permission-checked method as the single action → { done, failed[ {id,message} ] }
    private static function op_bulk( $uid ) {
        $act = self::str( 'action' ); $ids = array_slice( array_map( 'absint', (array) self::json( 'ids' ) ), 0, 100 ); $done = 0; $failed = array();
        foreach ( $ids as $id ) {
            if ( ! $id ) { continue; }
            if ( $act === 'trash' ) { $r = Posts::trash( $id, $uid ); }
            elseif ( $act === 'restore' ) { $r = Posts::restore( $id, $uid ); }
            elseif ( isset( Posts::STATUSES[ $act ] ) && $act !== 'scheduled' ) { $r = Posts::transition( $id, $act, array(), $uid ); }
            else { return new \WP_Error( 'nsh_blog_bulk', 'Choose a valid bulk action.' ); }
            if ( is_wp_error( $r ) ) { $failed[] = array( 'id' => $id, 'message' => $r->get_error_message() ); } else { $done++; }
        }
        return array( 'done' => $done, 'failed' => $failed );
    }

    // ── taxonomy ──
    private static function op_terms( $uid ) { return self::terms_payload(); }
    private static function op_term_save( $uid ) { $r = Terms::save( self::json( 'data' ) ); return is_wp_error( $r ) ? $r : array( 'term' => $r ) + self::terms_payload(); }
    private static function op_term_delete( $uid ) { $r = Terms::delete( self::int( 'id' ) ); return is_wp_error( $r ) ? $r : self::terms_payload(); }

    // ── media ──
    private static function op_media_list( $uid ) { return Media::lib( self::str( 'q' ), max( 1, self::int( 'page' ) ), 24 ); }
    private static function op_media_upload( $uid ) {
        if ( empty( $_FILES['file'] ) ) { return new \WP_Error( 'nsh_blog_up', 'Choose an image to upload.' ); }
        $r = Media::upload( $_FILES['file'], $uid ); // phpcs:ignore -- validated inside Media::upload (size, finfo MIME, pixel limit)
        return is_wp_error( $r ) ? $r : array( 'item' => $r );
    }
    private static function op_media_update( $uid ) { $r = Media::update( self::int( 'id' ), self::json( 'data' ) ); return is_wp_error( $r ) ? $r : array( 'item' => $r ); }
    private static function op_media_delete( $uid ) { $r = Media::delete( self::int( 'id' ) ); return is_wp_error( $r ) ? $r : array( 'ok' => true ); }

    // ── team & settings (admin group only) ──
    private static function op_team( $uid ) { return array( 'items' => Access::team(), 'perms' => Access::PERMS ); }
    private static function op_team_save( $uid ) { $d = self::json( 'data' ); $r = Access::save_user( isset( $d['id'] ) ? (int) $d['id'] : 0, ! empty( $d['enabled'] ), isset( $d['perms'] ) ? (array) $d['perms'] : array(), $uid ); return is_wp_error( $r ) ? $r : array( 'items' => Access::team() ); }
    private static function op_team_create( $uid ) { $r = Access::create_member( self::json( 'data' ), $uid ); return is_wp_error( $r ) ? $r : array( 'items' => Access::team(), 'created' => $r ); }
    private static function op_team_resend( $uid ) { $u = get_userdata( self::int( 'id' ) ); if ( ! $u || nsh_plat_group( $u->ID ) !== 'staff' ) { return new \WP_Error( 'nsh_blog_user', 'That staff account does not exist.' ); } return array( 'sent' => (bool) Access::send_setup_email( $u ) ); }
    private static function op_settings_get( $uid ) { return array( 'settings' => Settings::get() ); }
    private static function op_settings_save( $uid ) {
        $r = Settings::save( self::json( 'data' ) );
        if ( ! empty( $r['errors'] ) ) { return new \WP_Error( 'nsh_blog_settings', implode( ' ', $r['errors'] ), $r ); }
        return array( 'settings' => Settings::get(), 'home_url' => Front::url( 'home' ) );
    }
    private static function op_profile_save( $uid ) { $r = Authors::save_profile( $uid, self::json( 'data' ) ); return is_wp_error( $r ) ? $r : array( 'profile' => Authors::card( $uid ) ); }

    // TRACE: inline editor structural change → {id, data:{title,subtitle,intro,blocks,layout,featured_media}} (UNSAVED model) → the sanitised model rendered in edit mode (same markup visitors get, plus data-f markers); nothing is written to the database → { html, model }
    //        edge: caller must be allowed to edit that article; featured image id must exist in the blog library
    private static function op_inline_render( $uid ) {
        $p = self::visible( self::int( 'id' ) );
        if ( is_wp_error( $p ) ) { return $p; }
        if ( ! Access::can_edit_post( $p, $uid ) ) { return new \WP_Error( 'nsh_blog_perm', 'You are not allowed to edit this article.' ); }
        $in = self::json( 'data' );
        if ( array_key_exists( 'title', $in ) ) { $p['title'] = Blocks::txt( $in['title'], 300 ); }
        if ( array_key_exists( 'subtitle', $in ) ) { $p['subtitle'] = Blocks::txt( $in['subtitle'], 500 ); }
        if ( array_key_exists( 'intro', $in ) ) { $p['intro'] = Blocks::html( $in['intro'] ); }
        if ( array_key_exists( 'blocks', $in ) ) { $p['blocks'] = Blocks::sanitize_blocks( $in['blocks'] ); }
        if ( array_key_exists( 'layout', $in ) ) { $p['layout'] = Blocks::sanitize_layout( $in['layout'], $p['layout'] ); }
        if ( array_key_exists( 'featured_media', $in ) ) { $m = (int) $in['featured_media']; $p['featured_media'] = ( $m && Media::item( $m ) ) ? $m : 0; $p['featured'] = $p['featured_media'] ? Media::item( $p['featured_media'] ) : null; }
        return array( 'html' => Render::article( $p, array( 'edit' => true ) ), 'model' => array( 'title' => $p['title'], 'subtitle' => $p['subtitle'], 'intro' => $p['intro'], 'blocks' => $p['blocks'], 'layout' => $p['layout'], 'featured_media' => $p['featured_media'] ) );
    }

    // TRACE: inline editor start → article id → the editable article, the block catalogue and the editor's permissions (visitors never reach this: guarded + nonce) → array
    private static function op_inline_boot( $uid ) {
        $p = self::visible( self::int( 'id' ) );
        if ( is_wp_error( $p ) ) { return $p; }
        if ( ! Access::can_edit_post( $p, $uid ) ) { return new \WP_Error( 'nsh_blog_perm', 'You are not allowed to edit this article.' ); }
        return array( 'post' => self::deco( $p ), 'catalogue' => self::catalogue(), 'services' => self::services(), 'can_publish' => Access::can( 'publish' ), 'can_media' => Access::can( 'media' ), 'icons' => array_keys( Blocks::icons() ), 'edit_url' => nsh_plat_dash_url( Access::is_admin() ? 'admin' : 'staff', 'blog/#/edit/' . $p['id'] ) );
    }
}
Ajax::init();
