<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Authors — public author profiles for the blog (kept in the blog's own table; the WordPress user supplies only the sign-in). */
final class Authors {
    // TRACE: byline/editor → WP user id, create flag → that user's profile row; creates it on demand from the user's display name with a unique slug → array|null
    public static function for_user( $uid, $create = false ) {
        global $wpdb;
        $uid = (int) $uid;
        if ( ! $uid ) { return null; }
        $r = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . DB::t( 'authors' ) . ' WHERE user_id=%d', $uid ), ARRAY_A );
        if ( $r || ! $create ) { return $r ?: null; }
        $u = get_userdata( $uid );
        if ( ! $u ) { return null; }
        $base = sanitize_title( $u->display_name ) ?: 'author';
        $slug = $base; $n = 2;
        while ( $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . DB::t( 'authors' ) . ' WHERE slug=%s', $slug ) ) ) { $slug = $base . '-' . $n++; }
        $wpdb->insert( DB::t( 'authors' ), array( 'user_id' => $uid, 'name' => $u->display_name, 'slug' => $slug, 'created_at' => DB::now() ) );
        return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . DB::t( 'authors' ) . ' WHERE user_id=%d', $uid ), ARRAY_A ) ?: null;
    }
    // TRACE: author pages → slug → profile row or null → array|null
    public static function by_slug( $slug ) { global $wpdb; return $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . DB::t( 'authors' ) . ' WHERE slug=%s', sanitize_title( $slug ) ), ARRAY_A ) ?: null; }
    // TRACE: byline/schema → WP user id → display array {name,title,bio,slug,avatar,url} (profile if present, else the account's display name) → array
    public static function card( $uid ) {
        $a = self::for_user( $uid );
        $u = get_userdata( (int) $uid );
        $name = $a ? $a['name'] : ( $u ? $u->display_name : 'Editorial Team' );
        return array( 'name' => $name, 'title' => $a ? $a['job_title'] : '', 'bio' => $a ? (string) $a['bio'] : '', 'slug' => $a ? $a['slug'] : '', 'avatar' => $a && $a['avatar_media'] ? Media::url( (int) $a['avatar_media'], 'thumb' ) : '', 'url' => $a ? Front::url( 'author', $a['slug'] ) : '' );
    }
    // TRACE: "My profile" form → user id, input → whitelists and saves name/title/bio/avatar for that user's own profile → array|WP_Error
    public static function save_profile( $uid, $in ) {
        global $wpdb;
        $a = self::for_user( $uid, true );
        if ( ! $a ) { return new \WP_Error( 'nsh_blog_author', 'Profile not found.' ); }
        $name = sanitize_text_field( (string) ( isset( $in['name'] ) ? $in['name'] : $a['name'] ) );
        if ( $name === '' ) { return new \WP_Error( 'nsh_blog_author', 'A display name is required.' ); }
        $avatar = isset( $in['avatar_media'] ) ? (int) $in['avatar_media'] : (int) $a['avatar_media'];
        if ( $avatar && ! Media::item( $avatar ) ) { $avatar = 0; }
        $ok = $wpdb->update( DB::t( 'authors' ), array( 'name' => $name, 'job_title' => sanitize_text_field( (string) ( isset( $in['job_title'] ) ? $in['job_title'] : '' ) ), 'bio' => sanitize_textarea_field( (string) ( isset( $in['bio'] ) ? $in['bio'] : '' ) ), 'avatar_media' => $avatar ), array( 'id' => (int) $a['id'] ) );
        if ( $ok === false ) { return new \WP_Error( 'nsh_blog_db', 'Could not save the profile.' ); }
        return self::card( $uid );
    }
}
