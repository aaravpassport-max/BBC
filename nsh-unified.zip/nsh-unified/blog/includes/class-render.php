<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Render — turns articles and listings into HTML. One code path serves visitors AND the inline editor:
 * with $o['edit'] = true the same markup is emitted with data-f="…" field markers the editor uses to read changes back,
 * so what staff edit is exactly the layout visitors see.
 * Everything user-controlled is escaped (esc_html/esc_attr/esc_url) or has passed Blocks::html() on the way out.
 */
final class Render {
    /** blocks that render as full-width bands under the 3-column grid */
    public const WIDE = array( 'testimonials', 'links', 'cta', 'listcols' );

    private static function e( $s ) { return esc_html( (string) $s ); }
    // TRACE: renderers → block type, field path, edit flag → the data-f attribute string for edit mode ('' for visitors) → string
    private static function f( $o, $path, $rich = false ) { return ! empty( $o['edit'] ) ? ' data-f="' . esc_attr( $path ) . '"' . ( $rich ? ' data-rich="1"' : '' ) : ''; }
    public static function icon( $name, $cls = 'nb-ico' ) { $i = Blocks::icons(); $n = isset( $i[ $name ] ) ? $name : 'info'; return '<svg class="' . esc_attr( $cls ) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $i[ $n ] . '</svg>'; }
    private static function btn( $label, $url, $cls ) { return $label === '' ? '' : '<a class="nb-btn ' . esc_attr( $cls ) . '" href="' . esc_url( $url !== '' ? $url : '#' ) . '">' . self::e( $label ) . '</a>'; }
    // TRACE: dates everywhere → UTC "Y-m-d H:i:s" → formatted in the site's timezone/date format → string
    public static function date( $utc, $fmt = '' ) { if ( ! $utc ) { return ''; } $ts = strtotime( $utc . ' UTC' ); return $ts ? wp_date( $fmt !== '' ? $fmt : get_option( 'date_format' ), $ts ) : ''; }

    // ── blocks ──────────────────────────────────────────────────────────────
    // TRACE: article render → one block, edit flag → the block's HTML section with an anchor id and (edit mode) data-f markers → string
    public static function block( $b, $o = array() ) {
        $d = $b['data']; $id = $b['id']; $t = $b['type'];
        $edit = ! empty( $o['edit'] );
        $open = '<section class="nb-block nb-b-' . esc_attr( $t ) . '" id="s-' . esc_attr( $id ) . '" data-block="' . esc_attr( $id ) . '" data-type="' . esc_attr( $t ) . '">';
        $h = '';
        $head = function ( $key = 'heading', $lvl = 'h2' ) use ( $d, $o ) { return isset( $d[ $key ] ) && ( $d[ $key ] !== '' || ! empty( $o['edit'] ) ) ? '<' . $lvl . ' class="nb-h"' . self::f( $o, $key ) . '>' . self::e( $d[ $key ] ) . '</' . $lvl . '>' : ''; };
        switch ( $t ) {
            case 'text':
                $lvl = isset( $d['level'] ) && $d['level'] === 'h3' ? 'h3' : 'h2';
                $h = $head( 'heading', $lvl ) . '<div class="nb-rich"' . self::f( $o, 'body', true ) . '>' . Blocks::html( $d['body'] ) . '</div>';
                break;
            case 'steps':
                $h = $head() . ( $d['intro'] !== '' || $edit ? '<p class="nb-lead"' . self::f( $o, 'intro' ) . '>' . self::e( $d['intro'] ) . '</p>' : '' ) . '<ol class="nb-steps">';
                foreach ( $d['items'] as $i => $it ) { $h .= '<li data-item="' . $i . '"><span class="nb-step-n">' . ( $i + 1 ) . '</span><strong' . self::f( $o, "items.$i.title" ) . '>' . self::e( $it['title'] ) . '</strong><span class="nb-step-t"' . self::f( $o, "items.$i.text", true ) . '>' . Blocks::html( $it['text'] ) . '</span></li>'; }
                $h .= '</ol>';
                break;
            case 'cards':
                $h = $head() . ( $d['intro'] !== '' || $edit ? '<p class="nb-lead"' . self::f( $o, 'intro' ) . '>' . self::e( $d['intro'] ) . '</p>' : '' ) . '<div class="nb-cards nb-cols-' . (int) $d['columns'] . '">';
                foreach ( $d['items'] as $i => $it ) { $h .= '<div class="nb-card" data-item="' . $i . '">' . self::icon( $it['icon'], 'nb-ico nb-card-ico' ) . '<h3 class="nb-card-t"' . self::f( $o, "items.$i.title" ) . '>' . self::e( $it['title'] ) . '</h3><p' . self::f( $o, "items.$i.text" ) . '>' . self::e( $it['text'] ) . '</p></div>'; }
                $h .= '</div>';
                break;
            case 'checklist':
                $h = $head() . '<ul class="nb-check">';
                foreach ( $d['items'] as $i => $it ) { $h .= '<li data-item="' . $i . '">' . self::icon( 'check', 'nb-ico nb-tick' ) . '<span' . self::f( $o, "items.$i" ) . '>' . self::e( $it ) . '</span></li>'; }
                $h .= '</ul>';
                break;
            case 'image':
                $m = (int) $d['media'];
                $img = $m ? Media::img( $m, array( 'alt' => $d['alt'] !== '' ? $d['alt'] : null, 'size' => $d['width'] === 'content' ? 'medium' : 'large', 'sizes_attr' => $d['width'] === 'content' ? '(max-width: 800px) 100vw, 760px' : '(max-width: 1200px) 100vw, 1100px' ) ) : '';
                if ( $m && ! $d['alt'] ) { $mi = Media::item( $m ); $img = Media::img( $m, array( 'alt' => $mi ? $mi['alt'] : '', 'size' => $d['width'] === 'content' ? 'medium' : 'large' ) ); }
                if ( $img === '' ) { $img = $edit ? '<div class="nb-img-empty">Choose an image</div>' : ''; }
                if ( $img !== '' && $d['link'] !== '' ) { $img = '<a href="' . esc_url( $d['link'] ) . '">' . $img . '</a>'; }
                $cap = $d['caption'];
                if ( $cap === '' && $m ) { $mi = isset( $mi ) ? $mi : Media::item( $m ); $cap = $mi ? $mi['caption'] : ''; }
                $h = $img === '' ? '' : '<figure class="nb-fig nb-fig-' . esc_attr( $d['width'] ) . '">' . $img . ( $cap !== '' || $edit ? '<figcaption' . self::f( $o, 'caption' ) . '>' . self::e( $cap ) . '</figcaption>' : '' ) . '</figure>';
                break;
            case 'callout':
                $h = '<div class="nb-callout nb-tone-' . esc_attr( $d['tone'] ) . '"><strong' . self::f( $o, 'title' ) . '>' . self::e( $d['title'] ) . '</strong><div' . self::f( $o, 'text', true ) . '>' . Blocks::html( $d['text'] ) . '</div></div>';
                break;
            case 'quote':
                $h = '<blockquote class="nb-quote"><p' . self::f( $o, 'text' ) . '>' . self::e( $d['text'] ) . '</p>' . ( $d['cite'] !== '' || $edit ? '<cite' . self::f( $o, 'cite' ) . '>' . self::e( $d['cite'] ) . '</cite>' : '' ) . '</blockquote>';
                break;
            case 'faq':
                $h = $head() . '<div class="nb-faq">';
                foreach ( $d['items'] as $i => $it ) { $h .= '<details class="nb-q" data-item="' . $i . '"' . ( $edit ? ' open' : '' ) . '><summary' . self::f( $o, "items.$i.q" ) . '>' . self::e( $it['q'] ) . '</summary><div class="nb-a"' . self::f( $o, "items.$i.a", true ) . '>' . Blocks::html( $it['a'] ) . '</div></details>'; }
                $h .= '</div>';
                break;
            case 'links':
                $h = '<div class="nb-wrap">' . $head() . '<div class="nb-linkgrid">';
                foreach ( $d['items'] as $i => $it ) { $h .= '<a class="nb-linkcard" data-item="' . $i . '" href="' . esc_url( $it['url'] !== '' ? $it['url'] : '#' ) . '"><span' . self::f( $o, "items.$i.label" ) . '>' . self::e( $it['label'] ) . '</span>' . self::icon( 'info', 'nb-ico nb-arrow' ) . '</a>'; }
                $h .= '</div></div>';
                break;
            case 'testimonials':
                $h = '<div class="nb-wrap">' . ( $d['kicker'] !== '' || $edit ? '<p class="nb-kicker"' . self::f( $o, 'kicker' ) . '>' . self::e( $d['kicker'] ) . '</p>' : '' ) . $head() . '<div class="nb-tgrid">';
                foreach ( $d['items'] as $i => $it ) { $h .= '<figure class="nb-tcard" data-item="' . $i . '"><figcaption class="nb-tcard-hd"><span class="nb-tav" aria-hidden="true">' . self::e( mb_strtoupper( mb_substr( $it['name'] !== '' ? $it['name'] : '?', 0, 1 ) ) ) . '</span><strong' . self::f( $o, "items.$i.name" ) . '>' . self::e( $it['name'] ) . '</strong><span class="nb-trole"' . self::f( $o, "items.$i.role" ) . '>' . self::e( $it['role'] ) . '</span></figcaption><div class="nb-stars" aria-label="5 out of 5 stars">★★★★★</div><blockquote' . self::f( $o, "items.$i.quote" ) . '>' . self::e( $it['quote'] ) . '</blockquote></figure>'; }
                $h .= '</div><div class="nb-dots" aria-hidden="true"></div></div>';
                break;
            case 'listcols':
                $n = count( $d['items'] ); $cols = max( 1, (int) $d['columns'] ); $per = max( 1, (int) ceil( $n / $cols ) );
                $h = '<div class="nb-wrap">' . $head() . '<div class="nb-lcols nb-cols-' . $cols . '">';
                foreach ( array_chunk( $d['items'], $per, true ) as $chunk ) {
                    $h .= '<ul class="nb-lcol">';
                    foreach ( $chunk as $i => $it ) { $lab = '<span' . self::f( $o, "items.$i.label" ) . '>' . self::e( $it['label'] ) . '</span>'; $h .= '<li data-item="' . $i . '">' . ( $it['url'] !== '' ? '<a href="' . esc_url( $it['url'] ) . '">' . $lab . '</a>' : $lab ) . '</li>'; }
                    $h .= '</ul>';
                }
                $h .= '</div>' . ( $d['button_label'] !== '' ? '<p class="nb-lcols-more">' . self::btn( $d['button_label'], $d['button_url'], 'nb-btn-primary' ) . '</p>' : '' ) . '</div>';
                break;
            case 'cta':
                $h = '<div class="nb-wrap"><div class="nb-cta nb-cta-' . esc_attr( $d['style'] ) . '"><div><h2 class="nb-h"' . self::f( $o, 'heading' ) . '>' . self::e( $d['heading'] ) . '</h2><p' . self::f( $o, 'text' ) . '>' . self::e( $d['text'] ) . '</p></div><div class="nb-cta-btns">' . self::btn( $d['button_label'], $d['button_url'], 'nb-btn-light' ) . self::btn( $d['button2_label'], $d['button2_url'], 'nb-btn-ghost' ) . '</div></div></div>';
                break;
            case 'form':
                $h = self::form( 'in-' . $id, array( 'service' => $d['service'], 'title' => $d['title'] ), $o, 'nb-form-inline' );
                break;
        }
        return $h === '' ? '' : $open . $h . '</section>';
    }

    // TRACE: hero/sidebar/inline form slots → instance key, {service,title}, flags → the standalone request form (reused from the Services Hub, each instance with its own ids/state); in the editor a non-interactive placeholder → string
    //        edge: Services Hub function missing → short notice, never a fatal
    public static function form( $key, $conf, $o = array(), $cls = '' ) {
        if ( ! empty( $o['edit'] ) ) { return '<div class="nb-form-ph ' . esc_attr( $cls ) . '" data-form-slot="' . esc_attr( $key ) . '"><strong>Request form</strong><span>' . self::e( $conf['title'] !== '' ? $conf['title'] : 'Get Estimated Quote Instantly' ) . '</span><small>' . ( $conf['service'] ? 'Service: ' . self::e( $conf['service'] ) : 'Visitor chooses the service' ) . '</small></div>'; }
        if ( ! function_exists( 'nsh_sc_standalone_form' ) ) { return '<div class="nb-notice">The request form is unavailable.</div>'; }
        return '<div class="nb-form ' . esc_attr( $cls ) . '">' . nsh_sc_standalone_form( array( 'service' => $conf['service'], 'instance' => $key, 'title' => $conf['title'] ) ) . '</div>';
    }

    // ── article page ────────────────────────────────────────────────────────
    // TRACE: TOC → article → list of array(anchor, label) for the in-article blocks that carry a heading (plus Overview) → array
    public static function toc( $p ) {
        $out = array( array( 'nb-article', 'Overview' ) );
        foreach ( $p['blocks'] as $b ) {
            if ( in_array( $b['type'], self::WIDE, true ) ) { continue; }
            $lbl = ! empty( $b['toc'] ) ? (string) $b['toc'] : ( isset( $b['data']['heading'] ) ? trim( (string) $b['data']['heading'] ) : '' );
            if ( $lbl !== '' ) { $out[] = array( 's-' . $b['id'], $lbl ); }
        }
        return count( $out ) > 1 ? $out : array();
    }

    // TRACE: public + inline-edit page body → article (hydrated), options {edit, preview} → the hero, trust strip, 3-column grid (TOC | article | sidebar), full-width bands and latest articles → HTML string
    public static function article( $p, $o = array() ) {
        if ( isset( $p['layout']['template'] ) && $p['layout']['template'] === 'classic' ) { return self::article_classic( $p, $o ); }
        $edit = ! empty( $o['edit'] ); $L = $p['layout']; $hero = $L['hero'];
        $cat = $p['category'];
        $h  = '<section class="nb-hero"><div class="nb-hero-in"><div class="nb-hero-copy">';
        $h .= '<p class="nb-eyebrow"' . self::f( $o, 'layout.hero.eyebrow' ) . '>' . self::e( $hero['eyebrow'] !== '' ? $hero['eyebrow'] : ( $cat ? $cat['name'] : '' ) ) . '</p>';
        $h .= '<h1 class="nb-title"' . self::f( $o, 'title' ) . '>' . self::e( $p['title'] ) . '</h1>';
        $h .= '<p class="nb-sub"' . self::f( $o, 'subtitle' ) . '>' . self::e( $p['subtitle'] ) . '</p>';
        if ( $hero['chips'] || $edit ) { $h .= '<ul class="nb-chips" data-list="layout.hero.chips">'; foreach ( $hero['chips'] as $i => $c ) { $h .= '<li data-item="' . $i . '">' . self::icon( 'check', 'nb-ico nb-chip-ico' ) . '<span' . self::f( $o, "layout.hero.chips.$i" ) . '>' . self::e( $c ) . '</span></li>'; } $h .= '</ul>'; }
        $h .= '<div class="nb-hero-cta">' . self::btn( $hero['cta1']['label'], $hero['cta1']['url'], 'nb-btn-primary' ) . self::btn( $hero['cta2']['label'], $hero['cta2']['url'], 'nb-btn-outline' ) . '</div></div>';
        if ( $L['forms']['hero']['enabled'] ) { $h .= '<div class="nb-hero-form" id="hero-form" data-slot="hero">' . self::form( 'hero', $L['forms']['hero'], $o, 'nb-form-hero' ) . '</div>'; }
        $h .= '</div></section>';
        if ( $L['trust'] ) { $h .= '<section class="nb-trust" aria-label="Why trust us"><ul data-list="layout.trust">'; foreach ( $L['trust'] as $i => $t ) { $h .= '<li data-item="' . $i . '">' . self::icon( $t['icon'], 'nb-ico nb-trust-ico' ) . '<span' . self::f( $o, "layout.trust.$i.text" ) . '>' . self::e( $t['text'] ) . '</span></li>'; } $h .= '</ul></section>'; }

        $toc = $L['toc'] ? self::toc( $p ) : array();
        $h .= '<div class="nb-body' . ( $toc ? ' nb-has-toc' : '' ) . '">';
        if ( $toc ) {
            $h .= '<aside class="nb-toc" aria-label="On this page"><details open><summary>On This Page</summary><nav><ul>';
            foreach ( $toc as $i => $t ) { $h .= '<li><a href="#' . esc_attr( $t[0] ) . '"' . ( $i === 0 ? ' class="is-active"' : '' ) . '>' . self::e( $t[1] ) . '</a></li>'; }
            $h .= '</ul></nav></details></aside>';
        }
        $h .= '<article class="nb-article" id="nb-article">';
        $h .= '<nav class="nb-crumbs" aria-label="Breadcrumb"><a href="' . esc_url( Front::url( 'home' ) ) . '">' . self::e( Settings::get( 'site_title' ) !== '' ? Settings::get( 'site_title' ) : 'Blog' ) . '</a>' . ( $cat ? ' <span aria-hidden="true">›</span> <a href="' . esc_url( Front::url( 'category', $cat['slug'] ) ) . '">' . self::e( $cat['name'] ) . '</a>' : '' ) . ' <span aria-hidden="true">›</span> <span>' . self::e( $p['title'] ) . '</span></nav>';
        $a = $p['author'];
        $h .= '<div class="nb-meta">' . ( $a['avatar'] ? '<img class="nb-avatar" src="' . esc_url( $a['avatar'] ) . '" alt="" width="36" height="36">' : '' ) . '<span>By ' . ( $a['url'] ? '<a href="' . esc_url( $a['url'] ) . '">' . self::e( $a['name'] ) . '</a>' : self::e( $a['name'] ) ) . '</span>' . ( $p['published_at'] ? '<span aria-hidden="true">·</span><time datetime="' . esc_attr( gmdate( 'c', strtotime( $p['published_at'] . ' UTC' ) ) ) . '">' . self::e( self::date( $p['published_at'] ) ) . '</time>' : '' ) . '<span aria-hidden="true">·</span><span>' . (int) $p['reading_minutes'] . ' min read</span></div>';
        if ( $p['featured'] ) { $h .= '<figure class="nb-fig nb-featured" data-featured="1">' . Media::img( $p['featured_media'], array( 'size' => 'large', 'eager' => true, 'sizes_attr' => '(max-width: 1200px) 100vw, 760px' ) ) . ( $p['featured']['caption'] !== '' ? '<figcaption>' . self::e( $p['featured']['caption'] ) . '</figcaption>' : '' ) . '</figure>'; }
        elseif ( $edit ) { $h .= '<div class="nb-img-empty" data-featured-empty="1">Choose a featured image</div>'; }
        $h .= '<div class="nb-intro nb-rich"' . self::f( $o, 'intro', true ) . '>' . Blocks::html( $p['intro'] ) . '</div>';
        $wide = array();
        foreach ( $p['blocks'] as $b ) { if ( in_array( $b['type'], self::WIDE, true ) ) { $wide[] = $b; } else { $h .= self::block( $b, $o ); } }
        if ( $p['tags'] ) { $h .= '<p class="nb-tags">'; foreach ( $p['tags'] as $t ) { $h .= '<a href="' . esc_url( Front::url( 'tag', $t['slug'] ) ) . '">#' . self::e( $t['name'] ) . '</a> '; } $h .= '</p>'; }
        $h .= '</article>';
        $h .= '<aside class="nb-side"><div class="nb-sticky">';
        if ( $L['forms']['aside']['enabled'] ) { $h .= '<div class="nb-side-card nb-side-form" id="aside-form" data-slot="aside">' . self::form( 'aside', array( 'service' => $L['forms']['aside']['service'], 'title' => $L['forms']['aside']['title'] ), $o, 'nb-form-aside' ) . '</div>'; }
        if ( $L['why']['items'] ) { $h .= '<div class="nb-side-card nb-why"><h2 class="nb-side-h"' . self::f( $o, 'layout.why.title' ) . '>' . self::e( $L['why']['title'] ) . '</h2><ul data-list="layout.why.items">'; foreach ( $L['why']['items'] as $i => $it ) { $h .= '<li data-item="' . $i . '">' . self::icon( 'check', 'nb-ico nb-tick' ) . '<span' . self::f( $o, "layout.why.items.$i.text" ) . '>' . self::e( $it['text'] ) . '</span></li>'; } $h .= '</ul></div>'; }
        $h .= '</div></aside></div>';
        foreach ( $wide as $b ) { $h .= '<div class="nb-band nb-band-' . esc_attr( $b['type'] ) . '">' . self::block( $b, $o ) . '</div>'; }
        if ( $L['latest']['show'] ) {
            $latest = Posts::query( array( 'public' => true, 'per' => (int) $L['latest']['count'], 'exclude' => $p['id'] ) );
            if ( $latest['items'] ) {
                $h .= '<section class="nb-band nb-latest"><div class="nb-wrap"><div class="nb-latest-hd"><h2 class="nb-h"' . self::f( $o, 'layout.latest.title' ) . '>' . self::e( $L['latest']['title'] ) . '</h2><a class="nb-btn nb-btn-outline nb-btn-sm" href="' . esc_url( Front::url( 'home' ) ) . '">View all articles</a></div><div class="nb-grid">';
                foreach ( $latest['items'] as $c ) { $h .= self::card( $c ); }
                $h .= '</div></div></section>';
            }
        }
        return $h;
    }


    // TRACE: classic template → article (hydrated), options {edit, preview} → yellow title bar, indigo hero (heading, keywords, 3 info boxes, counters, request form), search band, then TOC | boxed article | sticky form, popular list, reviews, blog cards → HTML string
    //        edge: every optional part (boxes, counters, search, sidebar why) is skipped when empty; in edit mode the same markup carries data-f markers
    public static function article_classic( $p, $o = array() ) {
        $edit = ! empty( $o['edit'] ); $L = $p['layout']; $hero = $L['hero']; $cat = $p['category'];
        $h  = '<div class="nbc-titlebar"><h1 class="nbc-h1"' . self::f( $o, 'title' ) . '>' . self::e( $p['title'] ) . '</h1></div>';
        $h .= '<section class="nbc-hero"><div class="nbc-hero-in"><div class="nbc-hero-l">';
        if ( $hero['heading'] !== '' || $edit ) { $h .= '<h2 class="nbc-hero-h"' . self::f( $o, 'layout.hero.heading' ) . '>' . self::e( $hero['heading'] ) . '</h2>'; }
        if ( $hero['keywords'] !== '' || $edit ) { $h .= '<p class="nbc-kw"' . self::f( $o, 'layout.hero.keywords' ) . '>' . self::e( $hero['keywords'] ) . '</p>'; }
        elseif ( $p['subtitle'] !== '' ) { $h .= '<p class="nbc-kw"' . self::f( $o, 'subtitle' ) . '>' . self::e( $p['subtitle'] ) . '</p>'; }
        if ( $hero['boxes'] ) {
            $h .= '<div class="nbc-boxes">';
            foreach ( $hero['boxes'] as $bi => $bx ) {
                $h .= '<div class="nbc-box" data-item="' . $bi . '"><h3' . self::f( $o, "layout.hero.boxes.$bi.title" ) . '>' . self::e( $bx['title'] ) . '</h3><ul data-list="layout.hero.boxes.' . $bi . '.items">';
                foreach ( $bx['items'] as $ii => $x ) { $h .= '<li data-item="' . $ii . '"><span' . self::f( $o, "layout.hero.boxes.$bi.items.$ii" ) . '>' . self::e( $x ) . '</span></li>'; }
                $h .= '</ul></div>';
            }
            $h .= '</div>';
        }
        if ( $hero['stats'] ) {
            $h .= '<ul class="nbc-stats" data-list="layout.hero.stats">';
            foreach ( $hero['stats'] as $si => $st ) { $h .= '<li data-item="' . $si . '"><b' . self::f( $o, "layout.hero.stats.$si.value" ) . '>' . self::e( $st['value'] ) . '</b><span' . self::f( $o, "layout.hero.stats.$si.label" ) . '>' . self::e( $st['label'] ) . '</span></li>'; }
            $h .= '</ul>';
        }
        $h .= '</div>';
        if ( $L['forms']['hero']['enabled'] ) { $h .= '<div class="nbc-hero-form" id="hero-form" data-slot="hero">' . self::form( 'hero', $L['forms']['hero'], $o, 'nb-form-hero nbc-card' ) . '</div>'; }
        $h .= '</div></section>';
        if ( ! empty( $L['search']['show'] ) ) {
            $h .= '<section class="nbc-search"><h2' . self::f( $o, 'layout.search.title' ) . '>' . self::e( $L['search']['title'] ) . '</h2><form class="nbc-sform" role="search" method="get" action="' . esc_url( Front::url( 'home' ) ) . '">' . ( get_option( 'permalink_structure' ) ? '' : '<input type="hidden" name="nsh_route" value="blog"><input type="hidden" name="nsh_blog_path" value="">' ) . '<input type="search" name="q" placeholder="' . esc_attr( $L['search']['placeholder'] ) . '" aria-label="Search articles"><button type="submit" aria-label="Search"><svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" aria-hidden="true"><circle cx="11" cy="11" r="6.5"/><path d="M16 16l5 5"/></svg></button></form></section>';
        }
        $intro_h = $hero['heading'] !== '' ? $hero['heading'] : $p['title'];
        $toc = $L['toc'] ? self::toc( $p ) : array();
        if ( $toc ) { $toc[0] = array( 'nb-intro', 'Introduction' ); }
        $h .= '<div class="nbc-body' . ( $toc ? ' nbc-has-toc' : '' ) . '">';
        if ( $toc ) {
            $h .= '<aside class="nbc-toc" aria-label="On this page"><nav><ul>';
            foreach ( $toc as $i => $t ) { $h .= '<li><a href="#' . esc_attr( $t[0] ) . '"' . ( $i === 0 ? ' class="is-active"' : '' ) . '>' . self::e( $t[1] ) . '</a></li>'; }
            $h .= '</ul></nav></aside>';
        }
        $h .= '<article class="nbc-article" id="nb-article">';
        if ( $p['featured'] ) { $h .= '<figure class="nb-fig nb-featured" data-featured="1">' . Media::img( $p['featured_media'], array( 'size' => 'large', 'eager' => true, 'sizes_attr' => '(max-width: 1200px) 100vw, 760px' ) ) . ( $p['featured']['caption'] !== '' ? '<figcaption>' . self::e( $p['featured']['caption'] ) . '</figcaption>' : '' ) . '</figure>'; }
        elseif ( $edit ) { $h .= '<div class="nb-img-empty" data-featured-empty="1">Choose a featured image</div>'; }
        $h .= '<section class="nb-block nbc-intro" id="nb-intro"><h2 class="nb-h">' . self::e( $intro_h ) . '</h2><div class="nb-rich"' . self::f( $o, 'intro', true ) . '>' . Blocks::html( $p['intro'] ) . '</div></section>';
        $wide = array();
        foreach ( $p['blocks'] as $b ) { if ( in_array( $b['type'], self::WIDE, true ) ) { $wide[] = $b; } else { $h .= self::block( $b, $o ); } }
        if ( $p['tags'] ) { $h .= '<p class="nb-tags">'; foreach ( $p['tags'] as $t ) { $h .= '<a href="' . esc_url( Front::url( 'tag', $t['slug'] ) ) . '">#' . self::e( $t['name'] ) . '</a> '; } $h .= '</p>'; }
        $h .= '</article><aside class="nbc-side"><div class="nbc-sticky">';
        if ( $L['forms']['aside']['enabled'] ) { $h .= '<div class="nbc-side-form" id="aside-form" data-slot="aside">' . self::form( 'aside', array( 'service' => $L['forms']['aside']['service'], 'title' => $L['forms']['aside']['title'] ), $o, 'nb-form-aside nbc-card' ) . '</div>'; }
        if ( $L['why']['items'] ) { $h .= '<div class="nbc-why"><h2' . self::f( $o, 'layout.why.title' ) . '>' . self::e( $L['why']['title'] ) . '</h2><ul data-list="layout.why.items">'; foreach ( $L['why']['items'] as $i => $it ) { $h .= '<li data-item="' . $i . '"><span' . self::f( $o, "layout.why.items.$i.text" ) . '>' . self::e( $it['text'] ) . '</span></li>'; } $h .= '</ul></div>'; }
        $h .= '</div></aside></div>';
        foreach ( $wide as $b ) { $h .= '<div class="nb-band nb-band-' . esc_attr( $b['type'] ) . '">' . self::block( $b, $o ) . '</div>'; }
        if ( $L['latest']['show'] ) {
            $latest = Posts::query( array( 'public' => true, 'per' => (int) $L['latest']['count'], 'exclude' => $p['id'] ) );
            if ( $latest['items'] ) {
                $h .= '<section class="nb-band nb-latest"><div class="nb-wrap"><h2 class="nb-h"' . self::f( $o, 'layout.latest.title' ) . '>' . self::e( $L['latest']['title'] ) . '</h2><div class="nb-grid">';
                foreach ( $latest['items'] as $c ) { $h .= self::card( $c ); }
                $h .= '</div></div></section>';
            }
        }
        return $h;
    }

    // TRACE: listings/latest/related → light article row → a linked article card (image, category, date, title, excerpt) → string
    public static function card( $c ) {
        $img = $c['featured'] ? Media::img( (int) $c['featured']['id'], array( 'size' => 'medium', 'sizes_attr' => '(max-width: 640px) 100vw, 380px' ) ) : '<div class="nb-card-ph" aria-hidden="true"></div>';
        $ex = wp_trim_words( wp_strip_all_tags( $c['intro'] !== '' ? $c['intro'] : $c['subtitle'] ), 24 );
        return '<article class="nb-post"><a class="nb-post-img" href="' . esc_url( $c['url'] ) . '" tabindex="-1" aria-hidden="true">' . $img . '</a><div class="nb-post-b">' . ( $c['category'] ? '<a class="nb-post-cat" href="' . esc_url( Front::url( 'category', $c['category']['slug'] ) ) . '">' . self::e( $c['category']['name'] ) . '</a>' : '' ) . '<time class="nb-post-d" datetime="' . esc_attr( $c['published_at'] ? gmdate( 'c', strtotime( $c['published_at'] . ' UTC' ) ) : '' ) . '">' . self::e( self::date( $c['published_at'] ) ) . '</time><h3 class="nb-post-t"><a href="' . esc_url( $c['url'] ) . '">' . self::e( $c['title'] ) . '</a></h3>' . ( $ex ? '<p class="nb-post-x">' . self::e( $ex ) . '</p>' : '' ) . '<a class="nb-more" href="' . esc_url( $c['url'] ) . '">Read more →</a></div></article>';
    }

    // TRACE: archive routes → heading, intro, rows, page info, base URL builder args → listing page body with category chips and numbered pagination → string
    public static function archive( $title, $lead, $res, $kind, $slug = '', $page = 1 ) {
        $h = '<section class="nb-ahero"><div class="nb-wrap"><p class="nb-eyebrow">' . self::e( $kind === 'home' ? 'Articles & guides' : ucfirst( $kind ) ) . '</p><h1 class="nb-title">' . self::e( $title ) . '</h1>' . ( $lead !== '' ? '<p class="nb-sub">' . self::e( $lead ) . '</p>' : '' ) . '</div></section>';
        $h .= '<div class="nb-wrap nb-alist">';
        $cats = Terms::all( 'category', true );
        if ( $cats ) { $h .= '<nav class="nb-catbar" aria-label="Categories"><a href="' . esc_url( Front::url( 'home' ) ) . '"' . ( $kind === 'home' ? ' class="is-active"' : '' ) . '>All</a>'; foreach ( $cats as $c ) { $h .= '<a href="' . esc_url( Front::url( 'category', $c['slug'] ) ) . '"' . ( $kind === 'category' && $slug === $c['slug'] ? ' class="is-active"' : '' ) . '>' . self::e( $c['name'] ) . ' <small>' . (int) $c['cnt'] . '</small></a>'; } $h .= '</nav>'; }
        if ( ! $res['items'] ) { $h .= '<div class="nb-empty"><h2>Nothing published here yet</h2><p>Please check back soon.</p><a class="nb-btn nb-btn-primary" href="' . esc_url( Front::url( 'home' ) ) . '">Back to all articles</a></div>'; }
        else {
            $h .= '<div class="nb-grid">'; foreach ( $res['items'] as $c ) { $h .= self::card( $c ); } $h .= '</div>';
            if ( $res['pages'] > 1 ) {
                $h .= '<nav class="nb-pager" aria-label="Pagination">';
                for ( $i = 1; $i <= $res['pages']; $i++ ) { $h .= $i === (int) $page ? '<span class="is-active" aria-current="page">' . $i . '</span>' : '<a href="' . esc_url( Front::url( $kind, $slug, $i ) ) . '">' . $i . '</a>'; }
                $h .= '</nav>';
            }
        }
        return $h . '</div>';
    }
}
