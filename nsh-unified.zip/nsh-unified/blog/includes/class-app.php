<?php
namespace NSH\Blog;
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * App — mounts the blog CMS single-page app at /{admin|staff}-dashboard/blog/ inside the standalone shell.
 * The platform router has already required a signed-in account of the right group; this adds the blog-specific permission gate.
 */
final class App {
    // TRACE: route handler → dashboard group (admin|staff) → renders the app shell (or a 403 card for accounts without blog access) and exits
    public static function render( $group ) {
        $uid = get_current_user_id();
        if ( ! Access::enabled( $uid ) ) {
            status_header( 403 );
            $home = function_exists( 'nsh_plat_home_url' ) ? nsh_plat_home_url() : home_url( '/' );
            nsh_plat_render_shell( 'Blog access required', 'denied', '<div class="nsh-denied"><h1>Blog access required</h1><p>Your account has not been given access to the blog editor. Ask an administrator to enable it.</p><p><a class="nsh-btn" href="' . esc_url( $home ) . '">Back to my dashboard</a></p></div>' );
        }
        $dir = NSH_DIR . 'blog/assets/';
        wp_enqueue_style( 'nsh-blog-app', NSH_URL . 'blog/assets/blog-app.css', array(), file_exists( $dir . 'blog-app.css' ) ? filemtime( $dir . 'blog-app.css' ) : NSH_VER );
        wp_enqueue_script( 'nsh-blog-app', NSH_URL . 'blog/assets/blog-app.js', array(), file_exists( $dir . 'blog-app.js' ) ? filemtime( $dir . 'blog-app.js' ) : NSH_VER, true );
        $dash = nsh_plat_dash_url( $group );
        wp_localize_script( 'nsh-blog-app', 'NSHBLOG', array(
            'ajax' => admin_url( 'admin-ajax.php' ), 'nonce' => Ajax::nonce(), 'group' => $group, 'dash' => $dash, 'logout' => nsh_logout_url(),
            'base' => nsh_plat_dash_url( $group, nsh_plat_get( 'blog_slug' ) . '/' ), 'brand' => (string) nsh_plat_get( 'brand_name' ) ?: get_bloginfo( 'name' ),
            'home' => Front::url( 'home' ), 'maxUpload' => Media::MAX_BYTES,
        ) );
        $body = '<div id="nba-root" class="nba"><div class="nba-boot" role="status">Loading the blog editor…</div></div><noscript><p style="padding:24px">JavaScript is required for the blog editor.</p></noscript>';
        nsh_plat_render_shell( 'Blog editor', 'blogapp', $body );
    }
}
