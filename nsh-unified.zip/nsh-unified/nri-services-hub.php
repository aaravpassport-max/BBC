<?php
/**
 * Plugin Name:       NRI Services Hub
 * Plugin URI:        https://ayushhshharma.example
 * Description:       All-in-one NRI service request platform — request submission, tracking, quoting, payments, documents, vendor/staff management and client/admin dashboards for 50+ NRI service types (documentation, education, immigration, property, financial, legal, tax). Standalone plugin; does not require NRI Platform or Services2NRI to be installed.
 * Version:           2.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Ayushh
 * License:           Proprietary
 * Text Domain:        nri-services-hub
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! defined( 'NSH_VER' ) ) { define( 'NSH_VER', '2.0.0' ); }
if ( ! defined( 'NSH_DIR' ) ) { define( 'NSH_DIR', plugin_dir_path( __FILE__ ) ); }
if ( ! defined( 'NSH_URL' ) ) { define( 'NSH_URL', plugin_dir_url( __FILE__ ) ); }

/* ----------------------------------------------------------
 * Debug logging
 * Logging is OFF by default. The previous build appended several lines to
 * nsh-debug.log on EVERY request (and shipped a 131 MB log inside the
 * ZIP), which slows every page load and fills the disk. Enable it only
 * while diagnosing by defining NSH_DEBUG_LOG as true in wp-config.php.
 * The log lives in wp-content/uploads/nsh-logs/ (not inside the plugin
 * folder) and is truncated once it passes 1 MB.
 * -------------------------------------------------------- */
function nsh_log( $msg ) {
    // Routine progress chatter is only written in debug mode; failures and
    // SMTP verbose output (opt-in setting) are always kept so mail problems
    // stay diagnosable without turning everything on.
    $verbose = ( defined( 'NSH_DEBUG_LOG' ) && NSH_DEBUG_LOG )
        || ( function_exists( 'get_option' ) && get_option( 'nsh_smtp_debug', 0 ) );
    if ( ! $verbose && ! preg_match( '/fail|error|threw|MISSING|returned false/i', (string) $msg ) ) { return; }
    $up = function_exists( 'wp_upload_dir' ) ? wp_upload_dir( null, false ) : array();
    if ( empty( $up['basedir'] ) ) { return; }
    $dir = trailingslashit( $up['basedir'] ) . 'nsh-logs';
    if ( ! is_dir( $dir ) ) {
        if ( ! wp_mkdir_p( $dir ) ) { return; }
        @file_put_contents( $dir . '/index.php', "<?php // Silence is golden.\n" );
        @file_put_contents( $dir . '/.htaccess', "Deny from all\n" );
    }
    $log = $dir . '/nsh-debug.log';
    if ( file_exists( $log ) && filesize( $log ) > 1048576 ) { @unlink( $log ); }
    @file_put_contents( $log, date( '[Y-m-d H:i:s] ' ) . $msg . "\n", FILE_APPEND );
}

function nsh_safe_include( $name ) {
    $path = NSH_DIR . 'includes/' . $name . '.php';
    if ( ! file_exists( $path ) ) {
        nsh_log( "MISSING FILE: $path" );
        return;
    }
    nsh_log( "Loading: $name" );
    include_once $path;
    nsh_log( "Loaded OK: $name" );
}

add_action( 'plugins_loaded', 'nsh_load_all', 1 );
function nsh_load_all() {
    nsh_log( '=== plugins_loaded START ===' );
    foreach ( array(
        'helpers','document-download','schema','roles','capabilities','auth',
        'notifications','post-types','ajax','shortcodes',
        'enqueue','admin-menu','vendors','whatsapp','form-submissions',
        'migrations','email-templates','quick-replies','delivery-calculator',
        // 'smtp' defines nsh_get_smtp_settings() (used by the General
        // Settings tab's SMTP panel — admin-settings-integrated.php),
        // nsh_ajax_save_smtp_settings() (wp_ajax_nsh_save_smtp_settings —
        // the "Save SMTP Settings" button's handler) and the
        // phpmailer_init hook that actually routes wp_mail() through the
        // configured SMTP server. The file existed but was never in this
        // include list, so General Settings fatally errored on load
        // ("Call to undefined function nsh_get_smtp_settings()") and any
        // SMTP configuration silently had no effect on outgoing mail even
        // if it could somehow be saved.
        'smtp',
        'admin-settings-integrated',
        'diagnostics',
    ) as $f ) {
        nsh_safe_include( $f );
    }
    // Platform: settings, unified auth, plugin-owned routes and the standalone shell (dashboards need no page or shortcode).
    foreach ( array( 'settings', 'settings-ui', 'auth', 'routes', 'shell' ) as $f ) {
        $path = NSH_DIR . 'platform/' . $f . '.php';
        if ( file_exists( $path ) ) { include_once $path; } else { nsh_log( 'MISSING FILE: ' . $path ); }
    }
    // Blog CMS (own tables, own routes, no WordPress posts).
    if ( file_exists( NSH_DIR . 'blog/bootstrap.php' ) ) { include_once NSH_DIR . 'blog/bootstrap.php'; }
    nsh_log( '=== plugins_loaded END ===' );
    // Runtime DB migration (runs once per version bump)
    $migrated = get_option( 'nsh_db_version', '0' );
    if ( version_compare( $migrated, '4.3.1', '<' ) ) {
        global $wpdb;
        $col = $wpdb->get_results( "SHOW COLUMNS FROM {$wpdb->prefix}nsh_tickets LIKE 'updated_at'" );
        if ( empty( $col ) ) {
            $wpdb->query( "ALTER TABLE {$wpdb->prefix}nsh_tickets ADD COLUMN updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at" );
        }
        update_option( 'nsh_db_version', '4.3.1' );
    }
    // v5.1 migration: add conditions column to fields table
    if ( version_compare( get_option( 'nsh_db_version', '0' ), '5.1', '<' ) ) {
        global $wpdb;
        $cols = $wpdb->get_col( "SHOW COLUMNS FROM {$wpdb->prefix}nsh_fields" );
        if ( ! in_array( 'conditions', $cols ) ) {
            $wpdb->query( "ALTER TABLE {$wpdb->prefix}nsh_fields ADD COLUMN conditions longtext DEFAULT NULL" );
            nsh_log( 'Migration 5.1: Added conditions column to nsh_fields' );
        }
        update_option( 'nsh_db_version', '5.1' );
    }
    if ( version_compare( get_option( 'nsh_db_version', '0' ), '5.2', '<' ) ) {
        global $wpdb;
        $cols = $wpdb->get_col( "SHOW COLUMNS FROM {$wpdb->prefix}nsh_fields" );
        if ( ! in_array( 'description', $cols ) ) {
            $wpdb->query( "ALTER TABLE {$wpdb->prefix}nsh_fields ADD COLUMN description text DEFAULT NULL" );
            nsh_log( 'Migration 5.2: Added description column to nsh_fields' );
        }
        update_option( 'nsh_db_version', '5.2' );
    }
}

register_activation_hook( __FILE__, 'nsh_on_activate' );
function nsh_on_activate() {
    nsh_safe_include( 'helpers' );
    nsh_safe_include( 'schema' );
    nsh_safe_include( 'roles' );
    nsh_safe_include( 'admin-menu' );
    foreach ( array( 'settings', 'settings-ui', 'auth', 'routes', 'shell' ) as $f ) { include_once NSH_DIR . 'platform/' . $f . '.php'; }
    if ( file_exists( NSH_DIR . 'blog/bootstrap.php' ) ) { include_once NSH_DIR . 'blog/bootstrap.php'; }
    if ( function_exists( 'nsh_register_roles' ) ) { nsh_register_roles(); }
    if ( function_exists( 'nsh_create_tables' )  ) { nsh_create_tables();  }
    if ( function_exists( 'nsh_create_vendor_table' ) ) { nsh_create_vendor_table(); }
    if ( function_exists( 'nsh_create_pages' )   ) { nsh_create_pages();   }
    // DB migration: add updated_at to tickets table if missing
    global $wpdb;
    $col = $wpdb->get_results("SHOW COLUMNS FROM {$wpdb->prefix}nsh_tickets LIKE 'updated_at'");
    if ( empty( $col ) ) {
        $wpdb->query("ALTER TABLE {$wpdb->prefix}nsh_tickets ADD COLUMN updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at");
    }
    if ( function_exists( 'nsh_blog_install' ) ) { nsh_blog_install(); }
    nsh_blog_retire_legacy();
    update_option( 'nsh_flush_needed', 1 );
    if ( ! wp_next_scheduled( 'nsh_daily_cron' ) ) {
        wp_schedule_event( time(), 'daily', 'nsh_daily_cron' );
    }
    nsh_log( 'Activation complete v4.3.1' );
}

register_deactivation_hook( __FILE__, 'nsh_on_deactivate' );
function nsh_on_deactivate() {
    flush_rewrite_rules();
    wp_clear_scheduled_hook( 'nsh_daily_cron' );
}

add_action( 'nsh_daily_cron', 'nsh_cron_tick' );
function nsh_cron_tick() { /* reserved */ }
