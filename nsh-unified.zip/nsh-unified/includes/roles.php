<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function nsh_register_roles() {
    if (!get_role('nsh_client'))  add_role('nsh_client',  'NSH Client',  array('read'=>true));
    if (!get_role('nsh_manager')) add_role('nsh_manager', 'NSH Manager', array('read'=>true));
    if (!get_role('nsh_vendor'))  add_role('nsh_vendor',  'NSH Vendor',  array('read'=>true));
    if (!get_role('nsh_admin'))   add_role('nsh_admin',   'NSH Admin',   array('read'=>true));
    $all = array('read','nsh_view_all','nsh_edit_all','nsh_manage_settings','nsh_view_own','nsh_submit','nsh_message','nsh_upload');
    foreach (array('administrator','nsh_admin') as $rn) { $r=get_role($rn); if ($r) foreach($all as $c) $r->add_cap($c); }
    $r=get_role('nsh_manager'); if($r) foreach(array('read','nsh_view_all','nsh_edit_all','nsh_message','nsh_upload') as $c) $r->add_cap($c);
    $r=get_role('nsh_client');  if($r) foreach(array('read','nsh_view_own','nsh_submit','nsh_message','nsh_upload') as $c) $r->add_cap($c);
}
add_action('init','nsh_register_roles');
// Sign-in redirects, wp-admin lockdown and role → dashboard mapping live in platform/auth.php.
