<?php
/**
 * NRI Services Hub — Built-in SMTP Configuration
 * Hooks into WordPress's PHPMailer instance so all wp_mail() calls
 * (including WooCommerce, contact forms, and the NSH plugin itself)
 * route through the configured SMTP server.
 *
 * Settings are stored in wp_options under nsh_smtp_* keys.
 * The password is stored AES-256-CBC encrypted using AUTH_KEY as the key.
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// ── Encrypt / decrypt helpers ────────────────────────────────────────────────

function nsh_smtp_encrypt( $plain ) {
    if ( ! $plain ) { return ''; }
    if ( ! function_exists( 'openssl_encrypt' ) ) { return ''; }
    $key    = substr( hash( 'sha256', defined( 'AUTH_KEY' ) ? AUTH_KEY : 'nsh_fallback_key_change_me', true ), 0, 32 );
    $iv     = random_bytes( 16 );
    $cipher = openssl_encrypt( $plain, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
    return $cipher !== false ? base64_encode( $iv . $cipher ) : '';
}

function nsh_smtp_decrypt( $stored ) {
    if ( ! $stored ) { return ''; }
    if ( ! function_exists( 'openssl_decrypt' ) ) { return ''; }
    $key  = substr( hash( 'sha256', defined( 'AUTH_KEY' ) ? AUTH_KEY : 'nsh_fallback_key_change_me', true ), 0, 32 );
    $raw  = base64_decode( $stored );
    if ( strlen( $raw ) < 17 ) { return ''; }
    $iv   = substr( $raw, 0, 16 );
    $dec  = openssl_decrypt( substr( $raw, 16 ), 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
    return $dec !== false ? $dec : '';
}

// ── Get all SMTP settings ────────────────────────────────────────────────────

function nsh_get_smtp_settings() {
    return array(
        'enabled'    => (bool) get_option( 'nsh_smtp_enabled', 0 ),
        'host'       => get_option( 'nsh_smtp_host',       '' ),
        'port'       => (int)  get_option( 'nsh_smtp_port',       587 ),
        'encryption' => get_option( 'nsh_smtp_encryption', 'tls' ),   // tls | ssl | none
        'auth'       => (bool) get_option( 'nsh_smtp_auth',       1 ),
        'username'   => get_option( 'nsh_smtp_username',   '' ),
        'password'   => nsh_smtp_decrypt( get_option( 'nsh_smtp_password_enc', '' ) ),
        'from_email' => get_option( 'nsh_email_from',      get_option( 'admin_email' ) ),
        'from_name'  => get_option( 'nsh_email_name',      get_bloginfo( 'name' ) ),
    );
}

// ── Hook into PHPMailer before every wp_mail() call ─────────────────────────

add_action( 'phpmailer_init', 'nsh_configure_phpmailer' );
function nsh_configure_phpmailer( $phpmailer ) {
    $s = nsh_get_smtp_settings();

    if ( ! $s['enabled'] || ! $s['host'] ) {
        // SMTP not configured — leave WordPress default (PHP mail())
        // but still enforce the From address from our settings
        if ( $s['from_email'] && is_email( $s['from_email'] ) ) {
            $phpmailer->From     = $s['from_email'];
            $phpmailer->FromName = $s['from_name'];
        }
        return;
    }

    $phpmailer->isSMTP();
    $phpmailer->Host       = $s['host'];
    $phpmailer->Port       = $s['port'];
    $phpmailer->SMTPAuth   = $s['auth'];
    $phpmailer->Username   = $s['username'];
    $phpmailer->Password   = $s['password'];

    switch ( $s['encryption'] ) {
        case 'ssl':
            $phpmailer->SMTPSecure = 'ssl';
            break;
        case 'tls':
            $phpmailer->SMTPSecure = 'tls';
            break;
        default:
            $phpmailer->SMTPSecure = '';
            $phpmailer->SMTPAutoTLS = false;
            break;
    }

    // Sender
    if ( $s['from_email'] && is_email( $s['from_email'] ) ) {
        $phpmailer->From     = $s['from_email'];
        $phpmailer->FromName = $s['from_name'];
    }

    // Debug: write SMTP conversation to nsh-debug.log in verbose mode
    if ( get_option( 'nsh_smtp_debug', 0 ) ) {
        $phpmailer->SMTPDebug  = 2;
        $phpmailer->Debugoutput = function( $msg, $level ) {
            nsh_log( '[SMTP DEBUG L' . $level . '] ' . trim( $msg ) );
        };
    }

    nsh_log( 'nsh_configure_phpmailer: SMTP configured. Host=' . $s['host'] . ' Port=' . $s['port'] . ' Enc=' . $s['encryption'] . ' User=' . $s['username'] );
}

// ── Also hook wp_mail_from and wp_mail_from_name filters ─────────────────────
// This is where the fix that actually matters lives. WordPress core resolves
// and *validates* the From address (via PHPMailer::setFrom()) using this
// filter's return value BEFORE it ever fires the 'phpmailer_init' action
// above — so by the time nsh_configure_phpmailer() runs, PHPMailer's ->From
// property has already been set and validated (or already rejected the
// message and bailed) from whatever this filter returned. Setting
// $phpmailer->From directly in phpmailer_init is consequently a no-op for
// the actual send/validation step; this filter is the one WordPress
// actually uses.
//
// Left unconfigured (no SMTP, no custom From set in Settings), WordPress's
// own default is "wordpress@<site's-domain>" — built from whatever the
// site's URL happens to be. On a huge number of real hosts this domain
// either isn't set up to receive/send mail at all, or PHPMailer's own
// address validator rejects it outright (e.g. a site running on
// "localhost", a bare IP, or a domain PHPMailer considers malformed) —
// in which case EVERY wp_mail() call fails silently before a message is
// ever attempted, admin notifications and client confirmations alike.
// Falling back to the already-configured, already-valid admin_email
// (present on every WordPress install, never "wordpress@localhost") avoids
// this failure mode entirely without requiring SMTP to be set up first.
add_filter( 'wp_mail_from', function( $email ) {
    $from = get_option( 'nsh_email_from', '' );
    if ( $from && is_email( $from ) ) { return $from; }
    $admin_email = get_option( 'admin_email' );
    return ( $admin_email && is_email( $admin_email ) ) ? $admin_email : $email;
}, 20 );

add_filter( 'wp_mail_from_name', function( $name ) {
    $from_name = get_option( 'nsh_email_name', '' );
    if ( $from_name ) { return $from_name; }
    $platform_name = get_option( 'nsh_platform_name', '' );
    return $platform_name ? $platform_name : $name;
}, 20 );

// ── AJAX: Save SMTP settings ─────────────────────────────────────────────────

add_action( 'wp_ajax_nsh_save_smtp_settings', 'nsh_ajax_save_smtp_settings' );
function nsh_ajax_save_smtp_settings() {
    nsh_check_nonce();
    nsh_require_staff();

    $enabled    = ! empty( $_POST['nsh_smtp_enabled'] ) ? 1 : 0;
    $host       = sanitize_text_field( $_POST['nsh_smtp_host']       ?? '' );
    $port       = intval( $_POST['nsh_smtp_port']       ?? 587 );
    $encryption = sanitize_text_field( $_POST['nsh_smtp_encryption'] ?? 'tls' );
    $auth       = ! empty( $_POST['nsh_smtp_auth'] ) ? 1 : 0;
    $username   = sanitize_text_field( $_POST['nsh_smtp_username']   ?? '' );
    $password   = $_POST['nsh_smtp_password'] ?? '';          // raw — will be encrypted
    $from_email = sanitize_email( $_POST['nsh_email_from']           ?? '' );
    $from_name  = sanitize_text_field( $_POST['nsh_email_name']      ?? '' );
    $debug      = ! empty( $_POST['nsh_smtp_debug'] ) ? 1 : 0;

    if ( ! in_array( $encryption, array( 'tls', 'ssl', 'none' ), true ) ) {
        $encryption = 'tls';
    }
    if ( $port < 1 || $port > 65535 ) { $port = 587; }

    update_option( 'nsh_smtp_enabled',    $enabled );
    update_option( 'nsh_smtp_host',       $host );
    update_option( 'nsh_smtp_port',       $port );
    update_option( 'nsh_smtp_encryption', $encryption );
    update_option( 'nsh_smtp_auth',       $auth );
    update_option( 'nsh_smtp_username',   $username );
    update_option( 'nsh_smtp_debug',      $debug );
    if ( $from_email ) { update_option( 'nsh_email_from', $from_email ); }
    if ( $from_name )  { update_option( 'nsh_email_name', $from_name );  }

    // Only update password if a new one was submitted (empty = keep existing)
    if ( $password !== '' ) {
        update_option( 'nsh_smtp_password_enc', nsh_smtp_encrypt( $password ) );
    }

    nsh_log( 'SMTP settings saved by ' . wp_get_current_user()->user_login . '. Host=' . $host . ' Port=' . $port . ' Enabled=' . $enabled );
    wp_send_json_success( array( 'message' => 'SMTP settings saved.' ) );
}

// ── AJAX: Send test email ────────────────────────────────────────────────────

add_action( 'wp_ajax_nsh_smtp_test', 'nsh_ajax_smtp_test' );
function nsh_ajax_smtp_test() {
    nsh_check_nonce();
    nsh_require_staff();

    $to = sanitize_email( $_POST['test_email'] ?? '' );
    if ( ! $to || ! is_email( $to ) ) {
        wp_send_json_error( array( 'message' => 'Please enter a valid email address to send the test to.' ) );
    }

    $platform = get_option( 'nsh_platform_name', get_bloginfo( 'name' ) );
    $s        = nsh_get_smtp_settings();

    $subject = '[Test] SMTP working — ' . $platform;
    $body    = '<!DOCTYPE html><html><body style="font-family:Arial,sans-serif;padding:30px;color:#1e293b;">'
             . '<h2 style="color:#4f46e5;">✅ SMTP is working!</h2>'
             . '<p>This is a test email from <strong>' . esc_html( $platform ) . '</strong>.</p>'
             . '<table style="border-collapse:collapse;font-size:14px;margin-top:20px;">'
             . '<tr><td style="padding:6px 14px 6px 0;color:#64748b;">Sent via</td><td style="padding:6px 0;font-weight:600;">' . esc_html( $s['enabled'] && $s['host'] ? $s['host'] . ':' . $s['port'] : 'PHP mail() (no SMTP configured)' ) . '</td></tr>'
             . '<tr><td style="padding:6px 14px 6px 0;color:#64748b;">From</td><td style="padding:6px 0;">' . esc_html( $s['from_name'] . ' <' . $s['from_email'] . '>' ) . '</td></tr>'
             . '<tr><td style="padding:6px 14px 6px 0;color:#64748b;">To</td><td style="padding:6px 0;">' . esc_html( $to ) . '</td></tr>'
             . '<tr><td style="padding:6px 14px 6px 0;color:#64748b;">Time</td><td style="padding:6px 0;">' . current_time( 'd M Y, g:i a' ) . '</td></tr>'
             . '</table>'
             . '<p style="margin-top:24px;color:#64748b;font-size:13px;">If you received this email, your SMTP configuration is correct.</p>'
             . '</body></html>';

    // Enable SMTP debug for this test send
    $prev_debug = get_option( 'nsh_smtp_debug', 0 );
    update_option( 'nsh_smtp_debug', 1 );

    $sent = nsh_mail( $to, $subject, $body );

    update_option( 'nsh_smtp_debug', $prev_debug ); // restore

    if ( $sent ) {
        nsh_log( 'SMTP test email sent successfully to ' . $to );
        wp_send_json_success( array(
            'message' => 'Test email sent to ' . $to . '. Check your inbox (and spam folder). If received, SMTP is working correctly.',
        ) );
    } else {
        // Try to get PHPMailer error
        global $phpmailer;
        $err = ( isset( $phpmailer ) && is_object( $phpmailer ) && ! empty( $phpmailer->ErrorInfo ) )
             ? $phpmailer->ErrorInfo
             : 'wp_mail() returned false — check nsh-debug.log in wp-content/uploads/nsh-logs/ for SMTP conversation details.';
        nsh_log( 'SMTP test FAILED to ' . $to . '. Error: ' . $err );
        wp_send_json_error( array( 'message' => 'Failed: ' . $err ) );
    }
}

nsh_log( 'SMTP module loaded' );
