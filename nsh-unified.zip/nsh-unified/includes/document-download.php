<?php
/**
 * NRI Services Hub — Document Download Proxy
 *
 * Single secure endpoint for all document downloads.
 * Guarantees admin always receives PDF, PNG, or JPG — never AVIF or WebP —
 * regardless of what format the file was stored in after upload.
 *
 * Conversion rules:
 *   PDF   → served as-is  (PDF)
 *   JPG   → served as-is  (JPG)
 *   PNG   → served as-is  (PNG)
 *   WebP  → converted to  PNG
 *   AVIF  → converted to  PNG
 *   Other → 415 error
 */

if ( ! defined( 'ABSPATH' ) ) exit;

// ── Helper: build proxied download URL ───────────────────────────────────────
// $base_name (optional) lets a caller ask the download endpoint to serve
// this file with a different display name — e.g. a document-type-based
// name like "Passport" instead of the raw uploaded filename (see
// nsh_ajax_bulk_download_docs() in ajax.php). It's an advisory display
// string only, sanitized again server-side in nsh_ajax_download_document()
// before use — it never affects which file is actually resolved/served,
// that is always driven by $att_id alone.
function nsh_get_download_url( int $att_id, string $base_name = '' ): string {
    if ( ! $att_id ) return '';
    $args = [
        'action' => 'nsh_download_document',
        'att'    => $att_id,
        'nonce'  => wp_create_nonce( 'nsh_dl_' . $att_id ),
    ];
    if ( $base_name !== '' ) { $args['fname'] = $base_name; }
    return add_query_arg( $args, admin_url( 'admin-ajax.php' ) );
}

// ── Helper: best file path for ZIP entry ─────────────────────────────────────
function nsh_convert_doc_for_zip( int $att_id ): ?string {
    $path = get_attached_file( $att_id );
    if ( ! $path || ! file_exists( $path ) ) return null;
    $mime = ( new finfo( FILEINFO_MIME_TYPE ) )->file( $path );
    if ( in_array( $mime, [ 'application/pdf', 'image/jpeg', 'image/png' ], true ) ) {
        return $path;
    }
    return nsh_convert_to_png( $path, $mime ) ?: $path;
}

// ── Core: convert AVIF or WebP → PNG ────────────────────────────────────────
function nsh_convert_to_png( string $src_path, string $src_mime ): ?string {
    $upload_dir = wp_upload_dir();
    $out_path   = trailingslashit( $upload_dir['basedir'] )
                . 'nsh-tmp-' . md5( $src_path . filemtime( $src_path ) ) . '.png';

    if ( file_exists( $out_path ) ) return $out_path;

    // Try Imagick
    if ( extension_loaded( 'imagick' ) ) {
        try {
            $im = new Imagick( $src_path );
            if ( $im->getImageAlphaChannel() ) {
                $bg = new Imagick();
                $bg->newImage( $im->getImageWidth(), $im->getImageHeight(), new ImagickPixel( 'white' ) );
                $bg->compositeImage( $im, Imagick::COMPOSITE_OVER, 0, 0 );
                $im = $bg;
            }
            $im->setImageFormat( 'png' );
            $im->setImageCompressionQuality( 95 );
            $im->writeImage( $out_path );
            $im->clear(); $im->destroy();
            if ( file_exists( $out_path ) && filesize( $out_path ) > 0 ) {
                wp_schedule_single_event( time() + 600, 'nsh_cleanup_temp_file', [ $out_path ] );
                return $out_path;
            }
        } catch ( Throwable $e ) {
            nsh_log( 'nsh_convert_to_png Imagick: ' . $e->getMessage() );
        }
    }

    // Try GD
    $img = null;
    if ( $src_mime === 'image/webp' && function_exists( 'imagecreatefromwebp' ) ) {
        $img = @imagecreatefromwebp( $src_path );
    } elseif ( $src_mime === 'image/avif' && function_exists( 'imagecreatefromavif' ) ) {
        $img = @imagecreatefromavif( $src_path );
    }
    if ( $img ) {
        $w = imagesx( $img ); $h = imagesy( $img );
        $out = imagecreatetruecolor( $w, $h );
        imagefill( $out, 0, 0, imagecolorallocate( $out, 255, 255, 255 ) );
        imagecopy( $out, $img, 0, 0, 0, 0, $w, $h );
        $ok = imagepng( $out, $out_path, 6 );
        imagedestroy( $img ); imagedestroy( $out );
        if ( $ok && file_exists( $out_path ) && filesize( $out_path ) > 0 ) {
            wp_schedule_single_event( time() + 600, 'nsh_cleanup_temp_file', [ $out_path ] );
            return $out_path;
        }
    }

    nsh_log( 'nsh_convert_to_png failed: ' . basename( $src_path ) );
    return null;
}

// ── AJAX endpoint ─────────────────────────────────────────────────────────────
add_action( 'wp_ajax_nsh_download_document',        'nsh_ajax_download_document' );
add_action( 'wp_ajax_nopriv_nsh_download_document', 'nsh_ajax_download_document' );

function nsh_ajax_download_document(): void {

    $att_id = intval( $_GET['att'] ?? 0 );
    $nonce  = sanitize_text_field( $_GET['nonce'] ?? '' );

    if ( ! $att_id )                                         { status_header(400); wp_die('Missing attachment ID.'); }
    if ( ! wp_verify_nonce( $nonce, 'nsh_dl_' . $att_id ) ) { status_header(403); wp_die('Security check failed.'); }
    if ( ! is_user_logged_in() )                             { status_header(403); wp_die('Login required.'); }

    $att_post = get_post( $att_id );
    if ( ! $att_post || $att_post->post_type !== 'attachment' ) { status_header(404); wp_die('Document not found.'); }

    $parent_id = $att_post->post_parent;
    if ( $parent_id ) {
        $parent = get_post( $parent_id );
        if ( ! $parent || $parent->post_type !== 'nsh_request' ) { status_header(403); wp_die('Access denied.'); }
        if ( ! nsh_is_staff() && ! nsh_is_own_request( $parent_id ) ) { status_header(403); wp_die('Access denied.'); }
    } else {
        if ( ! nsh_is_staff() ) { status_header(403); wp_die('Access denied.'); }
    }

    $file_path = get_attached_file( $att_id );
    if ( ! $file_path || ! file_exists( $file_path ) ) { status_header(404); wp_die('File not found on server.'); }

    $mime_real = ( new finfo( FILEINFO_MIME_TYPE ) )->file( $file_path );

    // Decide what to serve
    $serve_path = $file_path;
    $serve_mime = $mime_real;
    $serve_ext  = '';

    switch ( $mime_real ) {
        case 'application/pdf':             $serve_ext = 'pdf'; break;
        case 'image/jpeg': case 'image/jpg': $serve_ext = 'jpg'; break;
        case 'image/png':                   $serve_ext = 'png'; break;

        case 'image/webp':
        case 'image/avif':
            // Convert to PNG — admin gets a universally viewable image
            $png = nsh_convert_to_png( $file_path, $mime_real );
            if ( $png ) {
                $serve_path = $png;
                $serve_mime = 'image/png';
                $serve_ext  = 'png';
            } else {
                // Fallback: serve raw (better than blocking)
                $serve_ext = ( $mime_real === 'image/avif' ) ? 'avif' : 'webp';
            }
            break;

        default:
            nsh_log( 'Download blocked — unsupported MIME: ' . $mime_real . ' att=' . $att_id );
            status_header(415);
            wp_die('Unsupported file type. Only PDF, JPG, and PNG are supported.');
    }

    // Optional caller-supplied display name (from nsh_get_download_url()'s
    // $base_name — see its docblock). Never touches $file_path/$serve_path
    // above: it only changes what filename the browser/fetch() sees in
    // Content-Disposition. '/' and '\' are stripped so a caller can't smuggle
    // extra path segments into the filename.
    //
    // This endpoint deliberately does NOT put a folder name + "/" into the
    // filename here (an earlier version did, to lean on Chrome/Edge's
    // habit of creating a subfolder from a "/" in Content-Disposition) —
    // that still produced a separate, visible download per file, which is
    // not "one folder, one download action". Grouping every request's
    // documents into one real folder now happens client-side via the File
    // System Access API (nshSaveFilesAsFolder() in nsh-app.js): the browser
    // fetch()es each file from this same endpoint and writes it directly
    // into one folder the person picks, so this endpoint only ever needs
    // to hand back a clean, flat filename.
    $fname_raw     = isset( $_GET['fname'] ) ? sanitize_text_field( wp_unslash( $_GET['fname'] ) ) : '';
    $base_override = $fname_raw !== '' ? sanitize_file_name( str_replace( [ '/', '\\' ], '', $fname_raw ) ) : '';

    // Clean filename: strip compound extensions like "doc.jpg" from "doc.jpg.avif"
    $raw_name = $base_override !== ''
        ? $base_override
        : pathinfo( $file_path, PATHINFO_FILENAME );
    $raw_name = preg_replace( '/\.(jpg|jpeg|png|webp|avif|pdf)$/i', '', $raw_name );
    $dl_name  = sanitize_file_name( $raw_name ) . '.' . $serve_ext;

    // Stream
    if ( ob_get_level() ) { ob_end_clean(); }
    nocache_headers();
    header( 'Content-Type: '        . $serve_mime );
    header( 'Content-Disposition: attachment; filename="' . $dl_name . '"' );
    header( 'Content-Length: '      . filesize( $serve_path ) );
    header( 'X-Content-Type-Options: nosniff' );
    header( 'Cache-Control: no-store, no-cache, must-revalidate' );
    header( 'Pragma: no-cache' );

    $fh = fopen( $serve_path, 'rb' );
    if ( $fh ) {
        while ( ! feof( $fh ) ) { echo fread( $fh, 1048576 ); flush(); }
        fclose( $fh );
    }
    exit;
}

// ── Cleanup cron ─────────────────────────────────────────────────────────────
add_action( 'nsh_cleanup_temp_file', function( string $path ): void {
    $base = wp_upload_dir()['basedir'];
    if ( $path && file_exists( $path ) && strpos( $path, $base ) === 0 ) {
        @unlink( $path );
    }
} );
