<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

add_action('admin_menu','nsh_admin_menu');
function nsh_admin_menu() {
    add_menu_page('NRI Services Hub','NRI Services Hub','read','nsh-platform','nsh_admin_overview_page','dashicons-groups',30);
}
function nsh_admin_overview_page() {
    echo '<div class="wrap"><h1>NRI Services Hub</h1><p>Everything runs on its own front-end dashboards. WordPress is used only for user accounts and sign-in.</p><p><a class="button button-primary" href="'.esc_url(nsh_plat_home_url()).'" target="_blank">Open my dashboard</a> <a class="button" href="'.esc_url(nsh_login_page_url()).'" target="_blank">Sign-in page</a></p></div>';
}
// TRACE: activation → none → creates the two PUBLIC pages that still live inside the theme (request wizard + services list); the three dashboards and the sign-in are plugin routes (platform/routes.php) and need no page
function nsh_create_pages() {
    foreach (array(
        array('Request Submit','nsh-request-submit','[nsh_request_form]'),
        array('Services','nsh-services','[nsh_services]'),
    ) as $p) {
        if (!get_page_by_path($p[1])) {
            wp_insert_post(array('post_title'=>$p[0],'post_name'=>$p[1],'post_content'=>$p[2],'post_status'=>'publish','post_type'=>'page','post_author'=>get_current_user_id()?get_current_user_id():1));
        }
    }
}
add_filter('query_vars','nsh_query_vars');
function nsh_query_vars($v) { $v[]='nsh_request_id'; return $v; }
