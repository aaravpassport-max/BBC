<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   VENDOR TABLE - create on activation
   ============================================================ */

function nsh_create_vendor_table() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $wpdb->query( "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nsh_vendors (
        id            INT          NOT NULL AUTO_INCREMENT,
        name          VARCHAR(200) NOT NULL,
        email         VARCHAR(200) NOT NULL DEFAULT '',
        phone         VARCHAR(30)  NOT NULL DEFAULT '',
        whatsapp      VARCHAR(30)  NOT NULL DEFAULT '',
        company       VARCHAR(200) NOT NULL DEFAULT '',
        work_types    TEXT         NOT NULL DEFAULT '',
        status        VARCHAR(20)  NOT NULL DEFAULT 'active',
        notes         TEXT         NOT NULL DEFAULT '',
        escalation_hours INT       NOT NULL DEFAULT 24,
        escalation_days  INT       NOT NULL DEFAULT 3,
        created_at    DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $c" );
}
add_action( 'wp_loaded', 'nsh_create_vendor_table' );

/* ============================================================
   VENDOR HELPERS
   ============================================================ */

function nsh_get_vendors( $active_only = true ) {
    global $wpdb;
    $w = $active_only ? "WHERE status='active'" : '';
    return $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}nsh_vendors $w ORDER BY name ASC" );
}

function nsh_get_vendor( $id ) {
    global $wpdb;
    return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->prefix}nsh_vendors WHERE id=%d", $id ) );
}

function nsh_get_vendor_by_post( $post_id ) {
    $vid = get_post_meta( $post_id, 'nsh_vendor_profile_id', true );
    return $vid ? nsh_get_vendor( $vid ) : null;
}

/* ============================================================
   ADMIN MENU - Vendor section inside NRI Services Hub WP admin
   ============================================================ */

add_action( 'admin_menu', 'nsh_vendor_admin_menus', 20 );
function nsh_vendor_admin_menus() {
    add_submenu_page(
        'nsh-platform',
        'Vendor Management',
        'Vendors',
        'manage_options',
        'nsh-vendors',
        'nsh_vendor_admin_page'
    );
    add_submenu_page(
        'nsh-platform',
        'WhatsApp & Automation',
        'WhatsApp / Automation',
        'manage_options',
        'nsh-whatsapp',
        'nsh_whatsapp_admin_page'
    );
}

/* ============================================================
   VENDOR ADMIN PAGE
   ============================================================ */

function nsh_vendor_admin_page() {
    global $wpdb;
    $vendors = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}nsh_vendors ORDER BY name ASC" );
    ?>
    <div class="wrap nsh-vendor-admin">
        <h1 style="display:flex;align-items:center;gap:12px;">
            <span>Vendor Management</span>
            <button class="button button-primary" id="nsh-add-vendor-btn" style="font-size:13px;">+ Add Vendor</button>
        </h1>

        <!-- Add / Edit Form (hidden by default) -->
        <div id="nsh-vendor-form-wrap" style="display:none;background:#fff;border:1px solid #ddd;border-radius:8px;padding:24px;margin:16px 0 24px;">
            <h3 id="nsh-vendor-form-title" style="margin-top:0;">Add New Vendor</h3>
            <input type="hidden" id="nsh-vf-id" value="">
            <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px;">
                <div>
                    <label style="display:block;font-weight:600;margin-bottom:4px;">Full Name *</label>
                    <input type="text" id="nsh-vf-name" class="regular-text" style="width:100%;" placeholder="Vendor Name">
                </div>
                <div>
                    <label style="display:block;font-weight:600;margin-bottom:4px;">Email</label>
                    <input type="email" id="nsh-vf-email" class="regular-text" style="width:100%;" placeholder="vendor@email.com">
                </div>
                <div>
                    <label style="display:block;font-weight:600;margin-bottom:4px;">Phone</label>
                    <input type="text" id="nsh-vf-phone" class="regular-text" style="width:100%;" placeholder="+91 9876543210">
                </div>
                <div>
                    <label style="display:block;font-weight:600;margin-bottom:4px;">WhatsApp Number</label>
                    <input type="text" id="nsh-vf-whatsapp" class="regular-text" style="width:100%;" placeholder="+919876543210 (with country code, no spaces)">
                </div>
                <div>
                    <label style="display:block;font-weight:600;margin-bottom:4px;">Company / Agency</label>
                    <input type="text" id="nsh-vf-company" class="regular-text" style="width:100%;" placeholder="Company Name">
                </div>
                <div>
                    <label style="display:block;font-weight:600;margin-bottom:4px;">Status</label>
                    <select id="nsh-vf-status" style="width:100%;">
                        <option value="active">Active</option>
                        <option value="inactive">Inactive</option>
                        <option value="suspended">Suspended</option>
                    </select>
                </div>
                <div>
                    <label style="display:block;font-weight:600;margin-bottom:4px;">Escalation (hours before 1st reminder)</label>
                    <input type="number" id="nsh-vf-esc-hrs" class="regular-text" style="width:100%;" value="24" min="1">
                </div>
                <div>
                    <label style="display:block;font-weight:600;margin-bottom:4px;">Escalation (days before admin alert)</label>
                    <input type="number" id="nsh-vf-esc-days" class="regular-text" style="width:100%;" value="3" min="1">
                </div>
                <div style="grid-column:span 3;">
                    <label style="display:block;font-weight:600;margin-bottom:4px;">Work Types / Specialisations</label>
                    <input type="text" id="nsh-vf-work-types" class="regular-text" style="width:100%;" placeholder="e.g. Transcript,Degree Certificate,Migration Certificate (comma-separated)">
                </div>
                <div style="grid-column:span 3;">
                    <label style="display:block;font-weight:600;margin-bottom:4px;">Internal Notes</label>
                    <textarea id="nsh-vf-notes" style="width:100%;height:80px;" placeholder="Internal notes about this vendor..."></textarea>
                </div>
            </div>
            <div style="margin-top:16px;display:flex;gap:10px;align-items:center;">
                <button class="button button-primary" id="nsh-vf-save">Save Vendor</button>
                <button class="button" id="nsh-vf-cancel">Cancel</button>
                <span id="nsh-vf-msg" style="font-size:13px;padding:6px 12px;border-radius:4px;display:none;"></span>
            </div>
        </div>

        <!-- Vendor Table -->
        <div style="background:#fff;border:1px solid #ddd;border-radius:8px;overflow:hidden;">
            <table class="widefat striped" style="margin:0;border:none;">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>WhatsApp</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Work Types</th>
                        <th>Escalation</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="nsh-vendors-tbody">
                <?php if ( empty($vendors) ) { ?>
                    <tr><td colspan="8" style="text-align:center;padding:30px;color:#94a3b8;">No vendors yet. Click "Add Vendor" to create one.</td></tr>
                <?php } else { foreach ( $vendors as $v ) { ?>
                    <tr id="nsh-vrow-<?php echo intval($v->id); ?>">
                        <td><strong><?php echo esc_html($v->name); ?></strong><?php if($v->company) echo '<br><small style="color:#64748b;">'.esc_html($v->company).'</small>'; ?></td>
                        <td><?php echo $v->whatsapp ? '<span style="color:#25d366;font-weight:600;">'.esc_html($v->whatsapp).'</span>' : '<span style="color:#94a3b8;">-</span>'; ?></td>
                        <td><?php echo esc_html($v->phone ?: '-'); ?></td>
                        <td><?php echo esc_html($v->email ?: '-'); ?></td>
                        <td style="font-size:12px;max-width:180px;"><?php echo esc_html($v->work_types ?: '-'); ?></td>
                        <td style="font-size:12px;"><?php echo intval($v->escalation_hours); ?>h / <?php echo intval($v->escalation_days); ?>d</td>
                        <td>
                            <?php
                            $sc = ['active'=>'#10b981','inactive'=>'#94a3b8','suspended'=>'#ef4444'];
                            $col = isset($sc[$v->status]) ? $sc[$v->status] : '#94a3b8';
                            echo '<span style="background:'.esc_attr($col).';color:#fff;padding:2px 8px;border-radius:20px;font-size:11px;font-weight:600;">'.esc_html(ucfirst($v->status)).'</span>';
                            ?>
                        </td>
                        <td>
                            <button class="button button-small nsh-vendor-edit-btn"
                                data-id="<?php echo intval($v->id); ?>"
                                data-name="<?php echo esc_attr($v->name); ?>"
                                data-email="<?php echo esc_attr($v->email); ?>"
                                data-phone="<?php echo esc_attr($v->phone); ?>"
                                data-whatsapp="<?php echo esc_attr($v->whatsapp); ?>"
                                data-company="<?php echo esc_attr($v->company); ?>"
                                data-status="<?php echo esc_attr($v->status); ?>"
                                data-work-types="<?php echo esc_attr($v->work_types); ?>"
                                data-notes="<?php echo esc_attr($v->notes); ?>"
                                data-esc-hrs="<?php echo intval($v->escalation_hours); ?>"
                                data-esc-days="<?php echo intval($v->escalation_days); ?>">
                                Edit
                            </button>
                            <button class="button button-small nsh-vendor-del-btn" data-id="<?php echo intval($v->id); ?>" style="color:#ef4444;border-color:#ef4444;">
                                Delete
                            </button>
                        </td>
                    </tr>
                <?php } } ?>
                </tbody>
            </table>
        </div>
    </div>

    <script>
    (function($){
        // Add vendor
        $('#nsh-add-vendor-btn').on('click', function(){
            $('#nsh-vendor-form-title').text('Add New Vendor');
            $('#nsh-vf-id').val('');
            $('#nsh-vf-name,#nsh-vf-email,#nsh-vf-phone,#nsh-vf-whatsapp,#nsh-vf-company,#nsh-vf-work-types,#nsh-vf-notes').val('');
            $('#nsh-vf-status').val('active');
            $('#nsh-vf-esc-hrs').val(24);
            $('#nsh-vf-esc-days').val(3);
            $('#nsh-vendor-form-wrap').slideDown(200);
        });
        $('#nsh-vf-cancel').on('click', function(){ $('#nsh-vendor-form-wrap').slideUp(200); });

        // Edit vendor
        $(document).on('click', '.nsh-vendor-edit-btn', function(){
            var $b = $(this);
            $('#nsh-vendor-form-title').text('Edit Vendor');
            $('#nsh-vf-id').val($b.data('id'));
            $('#nsh-vf-name').val($b.data('name'));
            $('#nsh-vf-email').val($b.data('email'));
            $('#nsh-vf-phone').val($b.data('phone'));
            $('#nsh-vf-whatsapp').val($b.data('whatsapp'));
            $('#nsh-vf-company').val($b.data('company'));
            $('#nsh-vf-status').val($b.data('status'));
            $('#nsh-vf-work-types').val($b.data('work-types'));
            $('#nsh-vf-notes').val($b.data('notes'));
            $('#nsh-vf-esc-hrs').val($b.data('esc-hrs'));
            $('#nsh-vf-esc-days').val($b.data('esc-days'));
            $('#nsh-vendor-form-wrap').slideDown(200);
            $('html,body').animate({scrollTop:$('#nsh-vendor-form-wrap').offset().top - 40}, 300);
        });

        // Save vendor
        $('#nsh-vf-save').on('click', function(){
            var $btn = $(this), $msg = $('#nsh-vf-msg');
            var name = $('#nsh-vf-name').val().trim();
            if (!name){ $msg.text('Name is required.').css({'background':'#fee2e2','color':'#991b1b'}).show(); return; }
            $btn.text('Saving...').prop('disabled',true);
            $.post(ajaxurl, {
                action:           'nsh_save_vendor',
                nonce:            '<?php echo wp_create_nonce("nsh_admin_nonce"); ?>',
                id:               $('#nsh-vf-id').val(),
                name:             name,
                email:            $('#nsh-vf-email').val(),
                phone:            $('#nsh-vf-phone').val(),
                whatsapp:         $('#nsh-vf-whatsapp').val(),
                company:          $('#nsh-vf-company').val(),
                status:           $('#nsh-vf-status').val(),
                work_types:       $('#nsh-vf-work-types').val(),
                notes:            $('#nsh-vf-notes').val(),
                escalation_hours: $('#nsh-vf-esc-hrs').val(),
                escalation_days:  $('#nsh-vf-esc-days').val(),
            }, function(res){
                $btn.text('Save Vendor').prop('disabled',false);
                if(res.success){
                    $msg.text('Saved!').css({'background':'#d1fae5','color':'#065f46'}).show();
                    setTimeout(function(){ location.reload(); }, 900);
                } else {
                    $msg.text(res.data && res.data.message ? res.data.message : 'Error.').css({'background':'#fee2e2','color':'#991b1b'}).show();
                }
            });
        });

        // Delete vendor
        $(document).on('click', '.nsh-vendor-del-btn', function(){
            if(!confirm('Delete this vendor? This cannot be undone.')) return;
            var id = $(this).data('id');
            $.post(ajaxurl, {action:'nsh_delete_vendor', nonce:'<?php echo wp_create_nonce("nsh_admin_nonce"); ?>', id:id}, function(res){
                if(res.success) $('#nsh-vrow-'+id).fadeOut(300, function(){ $(this).remove(); });
                else alert('Error deleting vendor.');
            });
        });
    })(jQuery);
    </script>
    <?php
}

/* ============================================================
   WHATSAPP / AUTOMATION ADMIN PAGE
   ============================================================ */

function nsh_whatsapp_admin_page() {
    // Save settings
    if ( isset($_POST['nsh_wa_save']) && check_admin_referer('nsh_wa_settings') ) {
        $fields = ['nsh_callme_api_key','nsh_callme_api_url','nsh_wa_admin_number',
                   'nsh_wa_staff_numbers','nsh_wa_assign_tpl','nsh_wa_followup_tpl',
                   'nsh_wa_escalation_tpl','nsh_wa_complete_tpl','nsh_wa_payment_tpl',
                   'nsh_wa_new_submission_tpl',
                   'nsh_wa_enabled'];
        foreach ($fields as $f) {
            update_option($f, sanitize_textarea_field(isset($_POST[$f]) ? $_POST[$f] : ''));
        }
        echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
    }
    $api_key  = get_option('nsh_callme_api_key','');
    $api_url  = get_option('nsh_callme_api_url','https://api.callmebot.com/whatsapp.php');
    $admin_no = get_option('nsh_wa_admin_number','');
    $staff_no = get_option('nsh_wa_staff_numbers','');
    $enabled  = get_option('nsh_wa_enabled','1');

    $tpl_assign    = get_option('nsh_wa_assign_tpl', " *New Job Assigned*\nClient: {client_name}\nWork: {work_type}\nPhone: {client_phone}\nRequest ID: {request_id}\nView: {request_url}");
    $tpl_followup  = get_option('nsh_wa_followup_tpl', " *Follow-Up Reminder*\nPlease update status for {client_name}.\nRequest ID: {request_id}\nPending since {days} days.\nView: {request_url}");
    $tpl_escalate  = get_option('nsh_wa_escalation_tpl', " *Vendor Delay Alert*\n{vendor_name} has not responded for {days} days.\nLead: {client_name}\nRequest ID: {request_id}\nPlease escalate immediately.");
    $tpl_complete  = get_option('nsh_wa_complete_tpl', " *Work Completed*\nVendor: {vendor_name}\nClient: {client_name}\nRequest ID: {request_id}\nStatus: Completed");
    $tpl_payment   = get_option('nsh_wa_payment_tpl', " *Payment Released*\nVendor: {vendor_name}\nClient: {client_name}\nRequest ID: {request_id}\nAmount: {amount}");
    $tpl_new_sub   = get_option('nsh_wa_new_submission_tpl', "✅ *New Application Received*\nClient : {client_name}\nPhone  : {client_phone}\nService: {work_type}\nRef    : {request_id}\nLink   : {request_url}");
    ?>
    <div class="wrap">
        <h1>WhatsApp Automation - CallMe Bot Integration</h1>
        <div style="background:#fffbeb;border:1px solid #f59e0b;border-radius:8px;padding:16px;margin-bottom:24px;">
            <strong> How it works:</strong> This system uses <a href="https://www.callmebot.com" target="_blank">CallMe Bot</a> to send WhatsApp messages.
            Each recipient must first send <code>I allow callmebot to send me messages</code> to <strong>+34 644 59 77 31</strong> on WhatsApp to activate their number.
            You will then receive an API key for each number.
        </div>

        <form method="post">
            <?php wp_nonce_field('nsh_wa_settings'); ?>
            <input type="hidden" name="nsh_wa_save" value="1">

            <div style="display:grid;grid-template-columns:1fr 1fr;gap:24px;">

                <!-- API Config -->
                <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:20px;">
                    <h3 style="margin-top:0;border-bottom:1px solid #f1f5f9;padding-bottom:10px;"> CallMe Bot API Configuration</h3>
                    <table class="form-table" style="margin:0;">
                        <tr>
                            <th style="width:140px;">Enable WA Alerts</th>
                            <td><label><input type="checkbox" name="nsh_wa_enabled" value="1" <?php checked($enabled,'1'); ?>> Enable WhatsApp Notifications</label></td>
                        </tr>
                        <tr>
                            <th>API Key</th>
                            <td><input type="text" name="nsh_callme_api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text" placeholder="Your CallMe Bot API key"></td>
                        </tr>
                        <tr>
                            <th>API URL</th>
                            <td><input type="text" name="nsh_callme_api_url" value="<?php echo esc_attr($api_url); ?>" class="regular-text" placeholder="https://api.callmebot.com/whatsapp.php"></td>
                        </tr>
                        <tr>
                            <th>Admin WA Number</th>
                            <td><input type="text" name="nsh_wa_admin_number" value="<?php echo esc_attr($admin_no); ?>" class="regular-text" placeholder="+919876543210">
                            <p class="description">Master admin number - receives all escalation alerts.</p></td>
                        </tr>
                        <tr>
                            <th>Staff WA Numbers</th>
                            <td><textarea name="nsh_wa_staff_numbers" rows="3" class="large-text" placeholder="+919876543211&#10;+919876543212"><?php echo esc_textarea($staff_no); ?></textarea>
                            <p class="description">One number per line. These receive follow-up and lead alerts.</p></td>
                        </tr>
                    </table>
                </div>

                <!-- Automation Rules -->
                <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:20px;">
                    <h3 style="margin-top:0;border-bottom:1px solid #f1f5f9;padding-bottom:10px;"> Automation Rules</h3>
                    <div style="font-size:13px;line-height:1.8;">
                    <div style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid #f1f5f9;">
                            <span style="color:#10b981;font-size:16px;"></span>
                            <span><strong>New application submitted</strong> → WhatsApp to admin &amp; staff</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid #f1f5f9;">
                            <span style="color:#10b981;font-size:16px;"></span>
                            <span><strong>Vendor Assigned</strong>  WhatsApp to vendor</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid #f1f5f9;">
                            <span style="color:#10b981;font-size:16px;"></span>
                            <span><strong>Follow-up date reached</strong>  Notify admin/staff</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid #f1f5f9;">
                            <span style="color:#f59e0b;font-size:16px;"></span>
                            <span><strong>No vendor response</strong>  Reminder after X hours (per vendor)</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid #f1f5f9;">
                            <span style="color:#ef4444;font-size:16px;"></span>
                            <span><strong>Overdue X days</strong>  Escalate to Admin + mark Delayed</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px;padding:8px 0;border-bottom:1px solid #f1f5f9;">
                            <span style="color:#10b981;font-size:16px;"></span>
                            <span><strong>Work completed</strong>  Notify admin</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:8px;padding:8px 0;">
                            <span style="color:#10b981;font-size:16px;"></span>
                            <span><strong>Payment released</strong>  Notify vendor</span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Message Templates -->
            <div style="background:#fff;border:1px solid #ddd;border-radius:8px;padding:20px;margin-top:24px;">
                <h3 style="margin-top:0;border-bottom:1px solid #f1f5f9;padding-bottom:10px;"> Message Templates</h3>
                <p style="font-size:13px;color:#64748b;margin-top:0;">
                    Available placeholders: <code>{client_name}</code> <code>{client_phone}</code> <code>{work_type}</code>
                    <code>{request_id}</code> <code>{vendor_name}</code> <code>{days}</code> <code>{amount}</code>
                    <code>{request_url}</code> <code>{status}</code>
                </p>
                <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;">
                    <?php
                    $tpls = [
                        ['nsh_wa_new_submission_tpl','✅ New Application Received (Admin/Staff)', $tpl_new_sub],
                        ['nsh_wa_assign_tpl',   ' Vendor Assignment', $tpl_assign],
                        ['nsh_wa_followup_tpl', ' Follow-Up Reminder', $tpl_followup],
                        ['nsh_wa_escalation_tpl',' Escalation Alert (Admin)', $tpl_escalate],
                        ['nsh_wa_complete_tpl', ' Work Completed', $tpl_complete],
                        ['nsh_wa_payment_tpl',  ' Payment Released', $tpl_payment],
                    ];
                    foreach ($tpls as $t) { ?>
                    <div>
                        <label style="display:block;font-weight:600;margin-bottom:6px;"><?php echo esc_html($t[1]); ?></label>
                        <textarea name="<?php echo esc_attr($t[0]); ?>" rows="5" style="width:100%;font-family:monospace;font-size:12px;"><?php echo esc_textarea($t[2]); ?></textarea>
                    </div>
                    <?php } ?>
                </div>
            </div>

            <div style="margin-top:16px;display:flex;gap:12px;align-items:center;">
                <?php submit_button('Save All Settings', 'primary', 'submit', false); ?>
                <button type="button" class="button" id="nsh-wa-test-btn">Send Test Message to Admin</button>
                <span id="nsh-wa-test-msg" style="font-size:13px;"></span>
            </div>
        </form>
    </div>

    <script>
    (function($){
        $('#nsh-wa-test-btn').on('click', function(){
            var $btn=$(this), $msg=$('#nsh-wa-test-msg');
            $btn.text('Sending...').prop('disabled',true);
            $.post(ajaxurl, {
                action:'nsh_wa_test',
                nonce:'<?php echo wp_create_nonce("nsh_admin_nonce"); ?>'
            }, function(res){
                $btn.text('Send Test Message to Admin').prop('disabled',false);
                if(res.success) $msg.text(' Test message sent!').css('color','#10b981');
                else $msg.text(' ' + (res.data && res.data.message ? res.data.message : 'Failed.')).css('color','#ef4444');
            });
        });
    })(jQuery);
    </script>
    <?php
}

/* ============================================================
   VENDOR AJAX HANDLERS
   ============================================================ */

add_action('wp_ajax_nsh_save_vendor', 'nsh_ajax_save_vendor');
function nsh_ajax_save_vendor() {
    $n = sanitize_text_field(isset($_POST['nonce']) ? $_POST['nonce'] : '');
    if (!wp_verify_nonce($n,'nsh_admin_nonce')) wp_send_json_error(['message'=>'Security check failed.'],403);
    if (!current_user_can('manage_options')) wp_send_json_error(['message'=>'Permission denied.'],403);
    global $wpdb;
    $id = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    $row = [
        'name'             => sanitize_text_field(isset($_POST['name']) ? $_POST['name'] : ''),
        'email'            => sanitize_email(isset($_POST['email']) ? $_POST['email'] : ''),
        'phone'            => sanitize_text_field(isset($_POST['phone']) ? $_POST['phone'] : ''),
        'whatsapp'         => preg_replace('/[^+0-9]/', '', isset($_POST['whatsapp']) ? $_POST['whatsapp'] : ''),
        'company'          => sanitize_text_field(isset($_POST['company']) ? $_POST['company'] : ''),
        'status'           => sanitize_text_field(isset($_POST['status']) ? $_POST['status'] : 'active'),
        'work_types'       => sanitize_text_field(isset($_POST['work_types']) ? $_POST['work_types'] : ''),
        'notes'            => sanitize_textarea_field(isset($_POST['notes']) ? $_POST['notes'] : ''),
        'escalation_hours' => max(1, intval((isset($_POST['escalation_hours']) ? $_POST['escalation_hours'] : 24))),
        'escalation_days'  => max(1, intval((isset($_POST['escalation_days']) ? $_POST['escalation_days'] : 3))),
    ];
    if (!$row['name']) wp_send_json_error(['message'=>'Name is required.']);
    if ($id) {
        $wpdb->update("{$wpdb->prefix}nsh_vendors", $row, ['id'=>$id]);
        wp_send_json_success(['id'=>$id]);
    } else {
        $wpdb->insert("{$wpdb->prefix}nsh_vendors", $row);
        wp_send_json_success(['id'=>$wpdb->insert_id]);
    }
}

add_action('wp_ajax_nsh_delete_vendor', 'nsh_ajax_delete_vendor');
function nsh_ajax_delete_vendor() {
    $n = sanitize_text_field(isset($_POST['nonce']) ? $_POST['nonce'] : '');
    if (!wp_verify_nonce($n,'nsh_admin_nonce')) wp_send_json_error(['message'=>'Security check failed.'],403);
    if (!current_user_can('manage_options')) wp_send_json_error(['message'=>'Permission denied.'],403);
    global $wpdb;
    $wpdb->delete("{$wpdb->prefix}nsh_vendors", ['id'=>intval(isset($_POST['id']) ? $_POST['id'] : 0)]);
    wp_send_json_success();
}

add_action('wp_ajax_nsh_wa_test', 'nsh_ajax_wa_test');
function nsh_ajax_wa_test() {
    $n = sanitize_text_field(isset($_POST['nonce']) ? $_POST['nonce'] : '');
    if (!wp_verify_nonce($n,'nsh_admin_nonce')) wp_send_json_error(['message'=>'Security check failed.'],403);
    $admin_no = get_option('nsh_wa_admin_number','');
    if (!$admin_no) wp_send_json_error(['message'=>'No admin WhatsApp number configured.']);
    $result = nsh_wa_send($admin_no, ' Test message from NRI Services Hub. WhatsApp automation is working!', true);
    if ($result) wp_send_json_success(['message'=>'Sent.']);
    else wp_send_json_error(['message'=>'API call failed. Check your API key and number.']);
}
