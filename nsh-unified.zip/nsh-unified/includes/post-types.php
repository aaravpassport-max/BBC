<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action('init','nsh_register_cpt');
function nsh_register_cpt() {
    register_post_type('nsh_request',array('label'=>'NSH Requests','public'=>false,'show_ui'=>true,'supports'=>array('title')));
}
