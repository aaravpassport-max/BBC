<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

// ── Core mailer (HTML) ──────────────────────────────────────────────────────
function nsh_mail( $to, $subject, $body_html ) {
    if ( ! $to || ! is_email( $to ) ) {
        nsh_log( 'nsh_mail: invalid recipient: ' . $to );
        return false;
    }

    // Always send HTML
    $headers = array( 'Content-Type: text/html; charset=UTF-8' );

    // Only add a custom From header when a valid address is explicitly configured.
    // If nsh_email_from is empty or invalid, omit the header entirely so WordPress
    // uses its own default — the same behaviour as any working WordPress email.
    $from_email = get_option( 'nsh_email_from', '' );
    $from_name  = get_option( 'nsh_email_name', get_option( 'nsh_platform_name', get_bloginfo( 'name' ) ) );
    if ( $from_email && is_email( $from_email ) ) {
        $headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
    }
    // If no valid From is set, wp_mail uses WordPress's own default (admin_email) —
    // exactly the same address that working WP emails already use.

    // Capture the REAL reason a send failed. wp_mail() itself only ever
    // returns a plain false/true — no detail — so without this, every
    // failure in the log just says "returned false" with no way to tell a
    // rejected/invalid From address, a PHPMailer/SMTP auth error, and a
    // host that has no working mail transport at all apart. WordPress
    // fires 'wp_mail_failed' with a WP_Error carrying PHPMailer's own
    // message immediately before wp_mail() returns false, so a one-shot
    // listener attached right before the call (and detached right after,
    // regardless of outcome) captures it without leaking a permanent
    // global hook.
    $captured_error = '';
    $capture = function( $wp_error ) use ( &$captured_error ) {
        $captured_error = $wp_error->get_error_message();
    };
    add_action( 'wp_mail_failed', $capture );
    $result = wp_mail( $to, $subject, $body_html, $headers );
    remove_action( 'wp_mail_failed', $capture );

    if ( ! $result ) {
        nsh_log( 'nsh_mail: wp_mail returned false. To=' . $to . ' Subject=' . $subject . ( $captured_error ? ' Reason=' . $captured_error : ' Reason=(none captured — check nsh-debug.log SMTP debug output if SMTP is enabled)' ) );
    }
    return $result;
}

// ── HTML email wrapper ───────────────────────────────────────────────────────
function nsh_html_email( $greeting, $body_paragraphs, $rid_label = '', $cta_url = '', $cta_text = '' ) {
    $platform = get_option( 'nsh_platform_name', get_bloginfo( 'name' ) );
    $color    = '#4f46e5';
    $body_content = '';
    foreach ( (array) $body_paragraphs as $p ) {
        $body_content .= '<p style="margin:0 0 14px;color:#334155;font-size:15px;line-height:1.7;">' . $p . '</p>';
    }
    $cta_block = '';
    if ( $cta_url && $cta_text ) {
        $cta_block = '<div style="text-align:center;margin:28px 0;">
            <a href="' . esc_url( $cta_url ) . '" style="background:' . $color . ';color:#fff;text-decoration:none;padding:12px 32px;border-radius:8px;font-size:15px;font-weight:600;display:inline-block;">' . esc_html( $cta_text ) . '</a></div>';
    }
    $order_badge = $rid_label ? '<div style="display:inline-block;background:#e0e7ff;color:#3730a3;padding:4px 14px;border-radius:20px;font-size:13px;font-weight:600;margin-bottom:20px;">Order #' . esc_html( $rid_label ) . '</div>' : '';
    return '<!DOCTYPE html><html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"></head>
<body style="margin:0;padding:0;background:#f1f5f9;font-family:Arial,Helvetica,sans-serif;">
<table width="100%" cellpadding="0" cellspacing="0" style="background:#f1f5f9;padding:40px 0;">
<tr><td align="center">
<table width="600" cellpadding="0" cellspacing="0" style="max-width:600px;width:100%;">
  <tr><td style="background:' . $color . ';border-radius:12px 12px 0 0;padding:28px 40px;">
    <h1 style="margin:0;color:#fff;font-size:22px;font-weight:700;">' . esc_html( $platform ) . '</h1>
  </td></tr>
  <tr><td style="background:#fff;padding:36px 40px;">
    ' . $order_badge . '
    <p style="margin:0 0 20px;color:#1e293b;font-size:17px;font-weight:600;">' . esc_html( $greeting ) . '</p>
    ' . $body_content . $cta_block . '
  </td></tr>
  <tr><td style="background:#f8fafc;border-radius:0 0 12px 12px;padding:20px 40px;border-top:1px solid #e2e8f0;">
    <p style="margin:0;color:#94a3b8;font-size:13px;">This email was sent by <strong>' . esc_html( $platform ) . '</strong>. Please do not reply directly to this email.</p>
  </td></tr>
</table>
</td></tr></table></body></html>';
}

/**
 * Every automatic notification below (new request, status change,
 * quotation, document reminder) used to build its subject/body entirely
 * inline in this file, with no connection at all to the admin-editable
 * templates under Settings -> Email Templates (email-templates.php) — so
 * an admin editing "Application Received" or "Status Update" there and
 * saving it had literally no effect on what actually got sent; this file
 * always used its own separate, hardcoded copy instead. That's the root
 * cause of "the system is still sending the old email template".
 *
 * This helper is the fix: called right before each notification's
 * existing hardcoded content would be built, it checks whether the admin
 * has actually SAVED a custom template for that notification's type
 * (nsh_get_custom_template() — true only once a Save button was clicked
 * for that specific template, never for an untouched default). If so, its
 * subject/body (already run through nsh_replace_template_variables() with
 * the caller's own variables) is what gets sent, and the hardcoded
 * builder below it never runs. If the admin has never customized that
 * particular template, this returns null and the existing hardcoded
 * email is sent completely unchanged — so a site that has never touched
 * Email Templates sees no difference at all, and a site that customizes
 * one template only affects that one notification, exactly as the admin
 * UI implies.
 *
 * Deliberately does NOT fall through to nsh_get_default_template()'s own
 * default body when there is no custom one — those defaults (visible in
 * the template editor) are written for a generic/transcript-style
 * service and are not necessarily a good match for every one of this
 * platform's services, so they're only ever used when the admin has
 * actively chosen to save them (e.g. by clicking Save without editing),
 * never silently substituted in place of the deliberately-written emails
 * already below.
 */
function nsh_custom_template_email( $type, $variables ) {
    if ( ! function_exists( 'nsh_get_custom_template' ) || ! function_exists( 'nsh_replace_template_variables' ) ) {
        return null;
    }
    $custom = nsh_get_custom_template( $type );
    if ( ! $custom || ( empty( $custom['subject'] ) && empty( $custom['body'] ) ) ) {
        return null;
    }
    return array(
        'subject' => nsh_replace_template_variables( isset( $custom['subject'] ) ? $custom['subject'] : '', $variables ),
        'body'    => nsh_replace_template_variables( isset( $custom['body'] ) ? $custom['body'] : '', $variables ),
    );
}

function nsh_client_email( $rid ) {
    $p = get_post( $rid );
    return $p ? get_the_author_meta( 'user_email', $p->post_author ) : '';
}
function nsh_admin_notification_email() {
    // Falls back to admin_email whenever "Manager Email" (Settings ->
    // General -> Notification Contact (Manager), in this plugin's own
    // admin — NOT wp-admin's core Settings -> General) isn't a genuinely
    // valid address, not merely whenever it's empty. Previously this only
    // checked truthiness — a stray space, a half-typed address, or any
    // other non-empty-but-invalid value in that setting would pass this
    // check, get handed to nsh_mail() as the definitive recipient, get
    // rejected there by is_email() (so nothing ever gets sent), and never
    // fall through to admin_email at all. That silent, total loss of
    // every admin notification (while every OTHER notification keeps
    // working fine, since a client's own address always comes from an
    // already-validated WP user account, a structurally different path)
    // is exactly what made this so easy to end up with and so hard to
    // notice: nothing ever errors loudly, the admin inbox is just quietly
    // empty forever until someone thinks to check this specific setting.
    //
    // A second, more fundamental version of the same symptom: for every
    // install prior to the "Notification Contact (Manager)" card being
    // added to admin-settings-integrated.php, nsh_manager_email could
    // never be set to ANYTHING at all — the option, this function's
    // fallback logic, and the generic nsh_save_settings AJAX handler that
    // saves it all already existed, but no <input> for it was ever
    // rendered in the admin UI on any tab, so there was no way to type a
    // Manager Email in even correctly. On any install from before that
    // fix, this always silently fell through to admin_email — so if
    // notifications are still missing after upgrading to a version with
    // the fallback fix alone, admin_email itself (wp-admin's core
    // Settings -> General -> Administration Email Address) is the address
    // to check next, or use the "Send Test Admin Notification" button
    // next to the new Manager Email field to see exactly which address
    // this function resolves to and whether nsh_mail() can actually
    // deliver to it.
    $mgr = get_option( 'nsh_manager_email', '' );
    return ( $mgr && is_email( $mgr ) ) ? $mgr : get_option( 'admin_email' );
}

// ── Message email ────────────────────────────────────────────────────────────
function nsh_send_message_email( $rid, $message, $sender_name, $sender_is_staff = false ) {
    $platform  = get_option( 'nsh_platform_name', get_bloginfo( 'name' ) );
    $rid_label = get_post_meta( $rid, 'request_id', true );
    $post      = get_post( $rid );
    $client    = $post ? get_userdata( $post->post_author ) : null;
    $client_name  = $client ? $client->display_name : 'Client';
    $client_email = $client ? $client->user_email   : '';
    $req_url   = nsh_request_url( $rid );

    if ( $sender_is_staff ) {
        if ( ! $client_email ) return;
        $subject = 'Update on Your Request — Order #' . $rid_label;
        $html    = nsh_html_email(
            'Dear ' . $client_name . ',',
            array(
                esc_html( $sender_name ) . ' has sent you a message regarding your request:',
                '<div style="background:#f8fafc;border-left:4px solid #4f46e5;padding:14px 18px;border-radius:0 8px 8px 0;color:#334155;font-size:14px;line-height:1.7;">' . nl2br( esc_html( $message ) ) . '</div>',
                'You can view your full request and respond using the button below.',
            ),
            $rid_label, $req_url, 'View Your Request'
        );
        nsh_mail( $client_email, $subject, $html );
    } else {
        $admin_email = nsh_admin_notification_email();
        $subject     = 'New Message from ' . $client_name . ' — Order #' . $rid_label;
        $html        = nsh_html_email(
            'New client message received',
            array(
                'Client: <strong>' . esc_html( $client_name ) . '</strong> &lt;' . esc_html( $client_email ) . '&gt;',
                '<div style="background:#f8fafc;border-left:4px solid #4f46e5;padding:14px 18px;border-radius:0 8px 8px 0;color:#334155;font-size:14px;line-height:1.7;">' . nl2br( esc_html( $message ) ) . '</div>',
            ),
            $rid_label, $req_url, 'View Request in Admin'
        );
        nsh_mail( $admin_email, $subject, $html );
    }
}

// ── New request (admin notification) ────────────────────────────────────────
function nsh_notify_new_request( $rid ) {
    $rid_label = get_post_meta( $rid, 'request_id', true );
    $post      = get_post( $rid );
    $client    = $post ? get_userdata( $post->post_author ) : null;
    $name      = $client ? $client->display_name : 'A new client';
    $email     = $client ? $client->user_email   : '';
    $req_url   = nsh_request_url( $rid );
    $to        = nsh_admin_notification_email();

    // Consult the admin-editable "New Request Alert (Admin)" template
    // first (see nsh_custom_template_email() above) — only used when the
    // admin has actually saved a custom version of it; otherwise the
    // hardcoded email below (unchanged from before) is sent.
    $custom = nsh_custom_template_email( 'new_request_admin', array(
        'client_name'    => $name,
        'client_email'   => $email,
        'request_id'     => $rid_label,
        'submitted_date' => current_time( 'd M Y H:i' ),
        'request_url'    => $req_url,
        'platform'       => get_option( 'nsh_platform_name', get_bloginfo( 'name' ) ),
    ) );

    if ( $custom ) {
        $subject = $custom['subject'];
        $html    = $custom['body'];
    } else {
        $subject   = 'New Request Received — Order #' . $rid_label;
        $html      = nsh_html_email(
            'New service request submitted',
            array(
                'A new application has been submitted and requires your attention.',
                '<table style="width:100%;border-collapse:collapse;font-size:14px;">
                  <tr><td style="padding:8px 0;color:#64748b;width:140px;">Client</td><td style="padding:8px 0;color:#1e293b;font-weight:600;">' . esc_html( $name ) . '</td></tr>
                  <tr><td style="padding:8px 0;color:#64748b;">Email</td><td style="padding:8px 0;color:#1e293b;">' . esc_html( $email ) . '</td></tr>
                  <tr><td style="padding:8px 0;color:#64748b;">Submitted</td><td style="padding:8px 0;color:#1e293b;">' . current_time( 'd M Y H:i' ) . '</td></tr>
                </table>',
            ),
            $rid_label, $req_url, 'View Request'
        );
    }
    // Logged explicitly (beyond nsh_mail()'s own failure logging) so
    // which address an admin notification actually went to is always
    // visible in nsh-debug.log without having to reproduce a failure —
    // useful on its own for confirming "Manager Email" (Settings ->
    // General) resolved the way it was expected to.
    $sent = nsh_mail( $to, $subject, $html );
    nsh_log( 'nsh_notify_new_request: admin notification for Order #' . $rid_label . ' to ' . $to . ' — ' . ( $sent ? 'sent' : 'FAILED (see reason above)' ) );
    return $sent;
}

// ── New request (client confirmation) ───────────────────────────────────────
// Companion to nsh_notify_new_request() above (which notifies the admin) —
// this confirms receipt to the client themselves. Previously there was no
// such email at all: a client submitting a request got nothing back
// regardless of whether the admin notification succeeded, which is exactly
// the gap reported — "admin and client both did not receive email
// notification for the form submitted". Still called from the deferred
// after-response block in ajax.php — but nsh_notify_new_request() (admin)
// no longer is; it now runs synchronously, before that block, so it fires
// in the same reliable execution context as the working "Send Test Admin
// Notification" button rather than the post-response one some hosts
// handle unreliably. See the comment at that call site in ajax.php for why.
function nsh_notify_client_new_request( $rid ) {
    $rid_label = get_post_meta( $rid, 'request_id', true );
    $post      = get_post( $rid );
    $client    = $post ? get_userdata( $post->post_author ) : null;
    if ( ! $client || ! $client->user_email ) { return false; }
    $req_url  = nsh_request_url( $rid );

    // Consult the admin-editable "Application Received" template first
    // (see nsh_custom_template_email() above) — only used once the admin
    // has actually saved a custom version; otherwise the hardcoded email
    // below (unchanged from before) is sent.
    $custom = nsh_custom_template_email( 'application_received', array(
        'customer_name' => $client->display_name,
        'request_id'    => $rid_label,
        'platform'      => get_option( 'nsh_platform_name', get_bloginfo( 'name' ) ),
    ) );

    if ( $custom ) {
        $subject = $custom['subject'];
        $html    = $custom['body'];
    } else {
        $subject  = 'We\'ve Received Your Request — Order #' . $rid_label;
        $html     = nsh_html_email(
            'Dear ' . $client->display_name . ',',
            array(
                'Thank you for submitting your request. We\'ve received it and our team will begin reviewing it shortly.',
                '<table style="width:100%;border-collapse:collapse;font-size:14px;background:#f8fafc;border-radius:8px;padding:4px;">
                  <tr><td style="padding:10px 14px;color:#64748b;width:160px;">Order ID</td><td style="padding:10px 14px;color:#1e293b;font-weight:600;">' . esc_html( $rid_label ) . '</td></tr>
                  <tr><td style="padding:10px 14px;color:#64748b;">Submitted</td><td style="padding:10px 14px;color:#1e293b;">' . current_time( 'd M Y H:i' ) . '</td></tr>
                </table>',
                'You can track the status of your request and communicate with our team anytime from your dashboard.',
            ),
            $rid_label, $req_url, 'View Your Request'
        );
    }
    return nsh_mail( $client->user_email, $subject, $html );
}

// ── Account created (client welcome) ────────────────────────────────────────
function nsh_notify_account_created( $user_id ) {
    $user     = get_userdata( $user_id );
    if ( ! $user ) return;
    $platform = get_option( 'nsh_platform_name', get_bloginfo( 'name' ) );
    $subject  = 'Welcome to ' . $platform . ' — Your Account is Ready';
    $html     = nsh_html_email(
        'Dear ' . $user->display_name . ',',
        array(
            'Greetings for the day!',
            'Your account has been successfully created on <strong>' . esc_html( $platform ) . '</strong>. You can now log in and start submitting your service requests.',
            '<table style="width:100%;border-collapse:collapse;font-size:14px;">
              <tr><td style="padding:8px 0;color:#64748b;width:120px;">Name</td><td style="padding:8px 0;color:#1e293b;font-weight:600;">' . esc_html( $user->display_name ) . '</td></tr>
              <tr><td style="padding:8px 0;color:#64748b;">Email</td><td style="padding:8px 0;color:#1e293b;">' . esc_html( $user->user_email ) . '</td></tr>
            </table>',
            'If you have any questions, feel free to contact our support team.',
        ),
        '', nsh_client_dashboard_url(), 'Go to Dashboard'
    );
    nsh_mail( $user->user_email, $subject, $html );
}
add_action( 'user_register', 'nsh_notify_account_created' );

// ── Status change (client notification) ─────────────────────────────────────
function nsh_notify_status_change( $rid, $new_status ) {
    $rid_label    = get_post_meta( $rid, 'request_id', true );
    $post         = get_post( $rid );
    $client       = $post ? get_userdata( $post->post_author ) : null;
    if ( ! $client ) return;
    $status_label = nsh_status_label( $new_status );
    $req_url      = nsh_request_url( $rid );
    $meta         = nsh_get_meta( $rid );
    $delivery     = $meta['estimated_delivery'] ? date( 'd M Y', strtotime( $meta['estimated_delivery'] ) ) : 'To be updated';
    $subject = 'Status Update: ' . $status_label . ' — Order #' . $rid_label;

    $status_messages = array(
        'under_review'         => 'Your application is currently under review by our team. We will keep you updated.',
        'ready_for_processing' => 'Great news! Your application is ready for processing. Our team will begin work shortly.',
        'approved'             => 'Your application has been approved! We are now proceeding with the next steps.',
        'processing'           => 'Your request is now being actively processed by our team.',
        'dispatched'           => 'Your documents have been dispatched. Please check your shipping details.',
        'completed'            => 'Your request has been successfully completed. Thank you for choosing us!',
        'service_not_available'=> 'We regret to inform you that the requested service is currently not available for your case. Our team will contact you with further details.',
        'rejected'             => 'Unfortunately, we were unable to process your request. Our team will contact you with further information.',
    );
    $msg = isset( $status_messages[ $new_status ] ) ? $status_messages[ $new_status ] : 'Your request status has been updated.';

    // Consult the admin-editable "Status Update" template first (see
    // nsh_custom_template_email() above) — only used once the admin has
    // actually saved a custom version; otherwise the hardcoded email below
    // (unchanged from before) is sent. STATUS_MESSAGE carries the exact
    // same per-status text computed above ($status_messages lookup), so a
    // custom template referencing {STATUS_MESSAGE} still gets accurate,
    // status-specific wording rather than a generic line.
    $custom = nsh_custom_template_email( 'status_update', array(
        'customer_name'  => $client->display_name,
        'request_id'     => $rid_label,
        'new_status'     => $status_label,
        'status_message' => $msg,
        'platform'       => get_option( 'nsh_platform_name', get_bloginfo( 'name' ) ),
    ) );

    if ( $custom ) {
        $subject = $custom['subject'];
        $html    = $custom['body'];
    } else {
        $html = nsh_html_email(
            'Dear ' . $client->display_name . ',',
            array(
                'Greetings for the day!',
                $msg,
                '<table style="width:100%;border-collapse:collapse;font-size:14px;background:#f8fafc;border-radius:8px;padding:4px;">
                  <tr><td style="padding:10px 14px;color:#64748b;width:160px;">Order ID</td><td style="padding:10px 14px;color:#1e293b;font-weight:600;">' . esc_html( $rid_label ) . '</td></tr>
                  <tr><td style="padding:10px 14px;color:#64748b;">Current Status</td><td style="padding:10px 14px;"><span style="background:#e0e7ff;color:#3730a3;padding:3px 12px;border-radius:20px;font-size:13px;font-weight:600;">' . esc_html( $status_label ) . '</span></td></tr>
                  <tr><td style="padding:10px 14px;color:#64748b;">Est. Delivery</td><td style="padding:10px 14px;color:#1e293b;">' . esc_html( $delivery ) . ' <small style="color:#94a3b8;">(working days only)</small></td></tr>
                </table>',
                'Click the button below to view your complete request details and updates.',
            ),
            $rid_label, $req_url, 'View Request'
        );
    }
    nsh_mail( $client->user_email, $subject, $html );
}

// ── Quotation email ──────────────────────────────────────────────────────────
function nsh_notify_quotation( $rid, $include_terms = false ) {
    $rid_label = get_post_meta( $rid, 'request_id', true );
    $post      = get_post( $rid );
    $client    = $post ? get_userdata( $post->post_author ) : null;
    if ( ! $client ) return false;
    $meta      = nsh_get_meta( $rid );
    $fd        = $meta['field_data'];
    $platform  = get_option( 'nsh_platform_name', get_bloginfo( 'name' ) );
    $req_url   = nsh_request_url( $rid );

    $service_amount  = $meta['quote_amount'] ? floatval( $meta['quote_amount'] ) : 0;
    $shipping        = isset( $meta['shipping_charges'] ) ? floatval( $meta['shipping_charges'] ) : 0;
    $shipping_type   = isset( $meta['shipping_type'] ) ? $meta['shipping_type'] : 'domestic';
    $total           = $service_amount + $shipping;
    $delivery        = $meta['estimated_delivery'] ? date( 'd M Y', strtotime( $meta['estimated_delivery'] ) ) : 'To be confirmed';
    $working_days    = get_post_meta( $rid, 'timeline_working_days', true );
    $timeline_str    = $working_days ? $working_days . ' Working Days' : 'To be confirmed';

    $svc = '';
    if ( ! empty( $meta['service_name'] ) )          $svc = $meta['service_name'];
    elseif ( ! empty( $fd['field_service_type'] ) )      $svc = $fd['field_service_type'];
    elseif ( ! empty( $fd['field_document_type'] ) ) $svc = $fd['field_document_type'];
    else                                              $svc = 'Document Service';

    // Also expose document type label cleanly
    $doc_type = ! empty( $meta['service_name'] ) ? $meta['service_name']
              : ( ! empty( $fd['field_document_type'] ) ? $fd['field_document_type']
              : ( ! empty( $fd['field_service_type'] ) ? $fd['field_service_type'] : 'Document Service' ) );

    $terms_block = '';
    if ( $include_terms ) {
        $terms_block = '<div style="margin-top:24px;padding:20px;background:#fafafa;border:1px solid #e2e8f0;border-radius:8px;">
            <p style="margin:0 0 12px;font-size:15px;font-weight:700;color:#1e293b;">Terms &amp; Conditions</p>
            <p style="margin:0 0 10px;font-size:13px;color:#334155;line-height:1.7;"><strong>1. Non-Refundable Clause:</strong> If the university is unable to trace the student\'s record, or if submitted documents are incorrect or incomplete, university fees are non-refundable. Accordingly, ' . esc_html($platform) . ' will also not be able to process any refund.</p>
            <p style="margin:0 0 10px;font-size:13px;color:#334155;line-height:1.7;"><strong>2. Processing Time:</strong> The estimated timeline (' . esc_html($timeline_str) . ') is indicative and may vary depending on university workload, holidays, or internal delays.</p>
            <p style="margin:0 0 10px;font-size:13px;color:#334155;line-height:1.7;"><strong>3. Transcript Format:</strong> The format of transcripts is entirely determined by the university. We do not control the format and cannot accommodate requests for specific layouts.</p>
            <p style="margin:0 0 10px;font-size:13px;color:#334155;line-height:1.7;"><strong>4. Service Disclaimer:</strong> ' . esc_html($platform) . ' is an independent service provider and is not affiliated with any university or institution.</p>
            <p style="margin:0;font-size:13px;color:#334155;line-height:1.7;"><strong>5. Validity:</strong> This quotation is valid for <strong>7 days</strong> from the date of issue. There is no obligation to proceed.</p>
        </div>';
    }

    // Consult the admin-editable "Quotation" template first (see
    // nsh_custom_template_email() above) — only used once the admin has
    // actually saved a custom version; otherwise the hardcoded email below
    // (unchanged from before) is sent. Passes the exact same computed
    // values (amounts, timeline, delivery date, terms block) the hardcoded
    // version below already uses, so a custom template referencing them
    // gets accurate, request-specific figures rather than placeholders.
    $custom = nsh_custom_template_email( 'quotation', array(
        'customer_name'       => $client->display_name,
        'student_name'        => $client->display_name,
        'request_id'          => $rid_label,
        'university_name'     => $svc,
        'course_name'         => $svc,
        'document_type'       => $doc_type,
        'quotation_amount'    => number_format( $service_amount, 2 ),
        'shipping_charges'    => number_format( $shipping, 2 ),
        'shipping_type'       => ucfirst( $shipping_type ),
        'total_amount'        => number_format( $total, 2 ),
        'timeline'            => $timeline_str,
        'delivery_date'       => $delivery,
        'terms_and_conditions'=> $terms_block,
        'platform'            => $platform,
    ) );

    if ( $custom ) {
        $subject = $custom['subject'];
        $html    = $custom['body'];
    } else {
        $subject = 'Quotation for Your Request — Order #' . $rid_label;
        $html    = nsh_html_email(
            'Dear ' . $client->display_name . ',',
            array(
                'Greetings for the day!',
                'Thank you for reaching out to us. We are pleased to share the official quotation for your service request.',
                '<table style="width:100%;border-collapse:collapse;font-size:14px;background:#f8fafc;border-radius:8px;">
                  <tr><td style="padding:10px 14px;color:#64748b;width:180px;">Order ID</td><td style="padding:10px 14px;color:#1e293b;font-weight:600;">' . esc_html($rid_label) . '</td></tr>
                  <tr><td style="padding:10px 14px;color:#64748b;">Service</td><td style="padding:10px 14px;color:#1e293b;">' . esc_html($svc) . '</td></tr>
                  <tr><td style="padding:10px 14px;color:#64748b;">Service Charges</td><td style="padding:10px 14px;color:#1e293b;font-weight:600;">INR ' . number_format($service_amount,2) . '</td></tr>
                  <tr><td style="padding:10px 14px;color:#64748b;">Shipping (' . esc_html(ucfirst($shipping_type)) . ')</td><td style="padding:10px 14px;color:#1e293b;">INR ' . number_format($shipping,2) . '</td></tr>
                  <tr style="background:#e0e7ff;"><td style="padding:12px 14px;color:#3730a3;font-weight:700;">Total Amount</td><td style="padding:12px 14px;color:#3730a3;font-weight:700;font-size:16px;">INR ' . number_format($total,2) . '</td></tr>
                  <tr><td style="padding:10px 14px;color:#64748b;">Timeline</td><td style="padding:10px 14px;color:#1e293b;">' . esc_html($timeline_str) . '<br><small style="color:#94a3b8;">Excludes Sat, Sun &amp; Govt Holidays</small></td></tr>
                  <tr><td style="padding:10px 14px;color:#64748b;">Expected by</td><td style="padding:10px 14px;color:#1e293b;font-weight:600;">' . esc_html($delivery) . '</td></tr>
                </table>',
                'Kindly review the quotation and confirm your acceptance to begin processing. You can view complete details using the button below.' . $terms_block,
            ),
            $rid_label, $req_url, 'View &amp; Accept Quotation'
        );
    }
    return nsh_mail( $client->user_email, $subject, $html );
}

// ── Document reminder email ──────────────────────────────────────────────────
function nsh_notify_document_reminder( $rid, $extra_note = '' ) {
    $rid_label = get_post_meta( $rid, 'request_id', true );
    $post      = get_post( $rid );
    $client    = $post ? get_userdata( $post->post_author ) : null;
    if ( ! $client ) return false;
    $req_url   = nsh_request_url( $rid );
    $extra     = $extra_note ? '<p style="margin:12px 0 0;font-size:14px;color:#334155;line-height:1.7;"><strong>Note from our team:</strong> ' . esc_html($extra_note) . '</p>' : '';

    // Consult the admin-editable "Document Reminder" template first (see
    // nsh_custom_template_email() above) — only used once the admin has
    // actually saved a custom version; otherwise the hardcoded email below
    // (unchanged from before) is sent. DOCUMENT_LIST carries the same
    // list + any per-request extra note the hardcoded version below builds,
    // as ready-to-insert HTML, so a custom template referencing
    // {DOCUMENT_LIST} still shows the real required documents.
    $document_list_html = '<ul style="margin:0;padding-left:18px;color:#7c3a21;font-size:14px;line-height:1.9;">
                <li>All Semester Marksheets (Properly Scanned)</li>
                <li>Degree Certificate (Properly Scanned)</li>
                <li>Any other documents as instructed by our team</li>
              </ul>' . $extra;

    $custom = nsh_custom_template_email( 'document_reminder', array(
        'customer_name' => $client->display_name,
        'request_id'    => $rid_label,
        'document_list' => $document_list_html,
        'platform'      => get_option( 'nsh_platform_name', get_bloginfo( 'name' ) ),
    ) );

    if ( $custom ) {
        $subject = $custom['subject'];
        $html    = $custom['body'];
    } else {
        $subject   = 'Documents Required — Order #' . $rid_label;
        $html      = nsh_html_email(
            'Dear ' . $client->display_name . ',',
            array(
                'Greetings for the day!',
                'We hope this message finds you well. This is a reminder that we are still awaiting some documents for your request.',
                '<div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:8px;padding:16px 20px;">
                  <p style="margin:0 0 10px;font-size:14px;font-weight:700;color:#9a3412;">Documents Required:</p>
                  ' . $document_list_html . '
                </div>',
                '<div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;padding:14px 18px;font-size:14px;color:#991b1b;font-weight:600;">&#9888; Your request cannot be processed without properly scanned documents. Please use a printer scanner — mobile photos may not be accepted.</div>',
                'Please upload your documents at the earliest to avoid delays.',
            ),
            $rid_label, $req_url, 'Upload Documents Now'
        );
    }
    return nsh_mail( $client->user_email, $subject, $html );
}
