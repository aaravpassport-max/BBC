<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

// TRACE: new account created at submission → wp_mail() the login details → returns the
//        wp_mail() boolean so the caller can tell the client honestly whether the email left
//        pre: valid $email; post: mail attempted, bool returned; edge: mail transport failure (false)
function nsh_send_welcome_email($email,$password) {
    $login = function_exists( 'nsh_login_page_url' ) ? nsh_login_page_url() : nsh_login_page_url();
    return (bool) wp_mail($email,'Your NRI Services Hub Account',"Hello,\n\nAccount created.\nEmail: $email\nPassword: $password\n\nLogin: ".$login."\n\n-- NRI Services Hub");
}
// TRACE: nsh_ajax_magic_link → user id, e-mail → stores a 30-minute one-time token and e-mails the sign-in link on the unified sign-in route → void
function nsh_send_magic_link($user_id,$email) {
    $token=wp_generate_password(32,false);
    set_transient('nsh_magic_'.$token,$user_id,30*MINUTE_IN_SECONDS);
    wp_mail($email,'NRI Services Hub Login Link',"Sign-in link (expires in 30 minutes, works once):\n".add_query_arg('token',$token,nsh_login_page_url()));
}

// TRACE: sign-in route with ?token= → token → consumes the one-time token, signs the user in and sends them to their own dashboard
//        pre: called by the platform dispatcher on the sign-in route only → post: token deleted (single use), auth cookie set → edge: unknown/expired token shows a notice on the sign-in page
function nsh_handle_magic_link() {
    $token=isset($_GET['token'])?preg_replace('/[^A-Za-z0-9]/','',(string)wp_unslash($_GET['token'])):'';
    if ($token==='') return;
    $uid=(int)get_transient('nsh_magic_'.$token);
    delete_transient('nsh_magic_'.$token);
    if (!$uid || nsh_plat_group($uid)==='') { wp_safe_redirect(add_query_arg('msg','expired',nsh_login_page_url()),303); exit; }
    wp_set_current_user($uid);
    wp_set_auth_cookie($uid,true,is_ssl());
    $u=get_userdata($uid);
    if ($u) { do_action('wp_login',$u->user_login,$u); }
    wp_safe_redirect(nsh_plat_home_url($uid),303);
    exit;
}

// ─────────────────────────────────────────────────────────────────────────
// NEVER let a page/CDN cache serve one visitor's personalized, permission-
// gated content to a different visitor.
//
// ROOT CAUSE this fixes: every page this plugin renders via a shortcode —
// the admin dashboard, the client dashboard, a single request's detail
// view, the login form, the request-submission wizard — is dynamically
// generated PER LOGGED-IN USER (different content for a client vs. staff
// vs. a logged-out visitor, all under the exact same URL). None of these
// pages ever sent a Cache-Control header, so nothing told a reverse-proxy
// or CDN cache sitting in front of the site (a very common production
// setup) that the HTML response is specific to that one request/session
// and must not be reused for the next visitor of the same URL. A CDN has
// no visibility into WordPress login cookies or role checks — it just
// caches by URL — so the FIRST visitor to load, say,
// /nsh-admin-dashboard/?tab=settings&section=services (even a logged-out
// visitor, or a client-role test account) could have their rendered HTML
// cached and then served BACK to every subsequent visitor of that exact
// URL, including a genuine administrator, who would see someone else's
// (or a lower-privilege) view under their own correct URL and login.
// That is exactly the "the URL is right but it shows the client
// dashboard" symptom this was written to eliminate.
//
// [nsh_services] is deliberately excluded — it's the one shortcode that
// renders identical, public content for every visitor, so it's safe (and
// good for performance) to let a CDN cache it normally.
add_action( 'template_redirect', 'nsh_prevent_dynamic_page_caching', 1 );
function nsh_prevent_dynamic_page_caching() {
    if ( is_admin() ) { return; }
    global $post;
    if ( ! $post || empty( $post->post_content ) ) { return; }

    $dynamic_shortcodes = array(
        'nsh_admin_dashboard',
        'nsh_client_dashboard',
        'nsh_request_view',
        'nsh_login_form',
        'nsh_login_button',
        'nsh_admin_login_button',
        'nsh_request_form',
        'nsh_standalone_form',
    );
    $is_dynamic = false;
    foreach ( $dynamic_shortcodes as $tag ) {
        if ( has_shortcode( $post->post_content, $tag ) ) { $is_dynamic = true; break; }
    }
    if ( ! $is_dynamic ) { return; }

    // Tell WordPress's own no-cache headers to go out (also clears any
    // ETag/Last-Modified that would otherwise let a shared cache validate
    // and keep serving a stale copy), then add the explicit directives a
    // CDN/reverse-proxy is most likely to actually honor: "private" so a
    // SHARED cache never stores this response at all (a browser's own
    // cache is still fine, and is per-visitor anyway), plus no-store as a
    // second, stronger signal for caches that ignore "private".
    nocache_headers();
    if ( ! headers_sent() ) {
        header( 'Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0' );
        header( 'Pragma: no-cache' );
        // Explicit for CDNs that vary caching by the presence of cookies
        // (a common CDN feature): this response's content depends on the
        // visitor's auth cookie, so it must never be shared across visitors
        // even if a cache decides to keep it anyway.
        header( 'Vary: Cookie', false );
    }
}

// ─────────────────────────────────────────────────────────────────────────
// FORCE-CORRECT PAGE ROUTING FOR THE 6 CORE NSH PAGES
//
// ROOT CAUSE this fixes: WordPress decides which page to render for a
// request in WP::parse_request(), by matching $_SERVER['REQUEST_URI']
// against the site's rewrite rules (stored in the 'rewrite_rules' option)
// to extract query vars such as `pagename`. That matching step depends on
// things entirely outside this plugin's control and easy to get out of
// sync on a live server: the webserver's rewrite/try_files configuration
// actually forwarding the request to index.php with the right info, the
// 'rewrite_rules' option being up to date (it's cached and only
// regenerated on demand — e.g. visiting Settings → Permalinks → Save, or
// certain plugin/theme changes; it is NOT automatically kept in sync with
// every page that gets created after the option was last built), and the
// site's "front page" special-casing (Settings → Reading). When ANY of
// those is even slightly off, WordPress's fallback behavior for a
// request it cannot positively match to a specific page is to serve the
// configured FRONT PAGE instead of returning a 404 — silently. That
// produces exactly the symptom reported: the browser's address bar still
// shows the correct, unchanged URL (e.g.
// /nsh-admin-dashboard/?tab=settings&section=services — the browser
// never navigated anywhere else, so of course the URL is right), but the
// HTML actually rendered is whatever page is set as the site's front
// page, because that's what WordPress's own query fell back to
// internally. This does not depend on this plugin's PHP ever running
// anything wrong — the misroute happens one layer below, in WordPress
// core's own request-to-page resolution — which is why the plugin's
// code "looks correct" under direct inspection and cannot be caught by
// checking page content, capability checks, or caching headers: those
// all run against whatever $post WordPress already (mis)resolved.
//
// The fix: stop depending on WordPress's rewrite-rule matching for these
// 6 specific, critical pages. Hook the 'request' filter — this runs
// early in WP::parse_request(), and whatever array it returns is used
// AS the resolved query vars, completely overriding whatever the rewrite
// rules did or didn't match. Read the real request path straight from
// $_SERVER['REQUEST_URI'] (which nginx/Apache always preserve as the
// original request path, regardless of any internal rewrite/try_files
// fallback), compare it directly against the plugin's own known page
// slugs, and if it matches, force `pagename` to that slug ourselves. If
// it doesn't match any of our pages, return WordPress's own resolution
// untouched so every other page/post on the site behaves exactly as
// before. This makes these 6 URLs self-correcting: even if the site's
// front page changes, the rewrite_rules option is stale, or the
// webserver's rewrite config has a gap, hitting
// /nsh-admin-dashboard/?tab=settings will always render the admin
// dashboard, never a fallback to whatever else is configured as "home".
add_filter( 'request', 'nsh_force_correct_page_routing', 1 );
function nsh_force_correct_page_routing( $query_vars ) {
    if ( is_admin() || ( defined( 'DOING_AJAX' ) && DOING_AJAX ) || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
        return $query_vars;
    }
    if ( empty( $_SERVER['REQUEST_URI'] ) ) { return $query_vars; }

    // Raw path only — strip query string, leading/trailing slashes, and
    // (defensively) the site's own subdirectory prefix if WP is installed
    // in one, so this still works whether the site lives at the domain
    // root or in a subfolder.
    $raw_path = parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH );
    if ( ! is_string( $raw_path ) || $raw_path === '' ) { return $query_vars; }

    $home_path = (string) parse_url( home_url( '/' ), PHP_URL_PATH );
    $home_path = trim( $home_path, '/' );
    $path      = trim( $raw_path, '/' );
    if ( $home_path !== '' && strpos( $path, $home_path ) === 0 ) {
        $path = trim( substr( $path, strlen( $home_path ) ), '/' );
    }

    // Only the first path segment matters — a page slug never has a
    // slash in it, and the custom '^nsh-request/([0-9]+)/?$' rewrite
    // rule (registered elsewhere, in includes/admin-menu.php) already
    // owns anything with a numeric second segment, so leave those alone.
    $first_segment = $path === '' ? '' : explode( '/', $path )[0];

    $nsh_slugs = array(
        'nsh-admin-dashboard',
        'nsh-client-dashboard',
        'nsh-login',
        'nsh-request',
        'nsh-request-submit',
        'nsh-services',
    );

    if ( ! in_array( $first_segment, $nsh_slugs, true ) ) {
        return $query_vars; // Not one of ours — leave WP's own resolution alone.
    }

    // If this is actually the '/nsh-request/123' single-request detail
    // URL, the dedicated rewrite rule in admin-menu.php owns it (it sets
    // page_id + nsh_request_id together); don't fight that one here.
    $rest_segments = $path === '' ? array() : explode( '/', $path );
    if ( $first_segment === 'nsh-request' && ! empty( $rest_segments[1] ) && ctype_digit( $rest_segments[1] ) ) {
        return $query_vars;
    }

    // Confirm the page actually exists and is published before forcing
    // WordPress onto it — never force-route to a slug with no real page
    // behind it (that would turn a legitimate 404 into a broken forced
    // match instead).
    $target = get_page_by_path( $first_segment );
    if ( ! $target || $target->post_status !== 'publish' ) {
        return $query_vars;
    }

    return array( 'pagename' => $first_segment );
}
