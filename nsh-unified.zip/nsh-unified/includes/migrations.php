<?php
/**
 * Database Migrations for v6.2.1
 * All migrations are SAFE and REVERSIBLE
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Run all v6.2.1 migrations
 */
function nsh_migrate_v6_2_1() {
    $current_version = get_option( 'nsh_db_version', '0' );
    
    if ( version_compare( $current_version, '6.2.1', '>=' ) ) {
        nsh_log( 'Database already at v6.2.1 or higher' );
        return true;
    }
    
    nsh_log( '=== Starting v6.2.1 Migration ===' );
    
    $success = true;
    
    // Migration 1: Add shipping charges columns
    if ( ! nsh_migrate_shipping_charges() ) {
        $success = false;
    }
    
    // Migration 2: Update status ENUM
    if ( ! nsh_migrate_status_enum() ) {
        $success = false;
    }
    
    // Migration 3: Create holidays table
    if ( ! nsh_migrate_holidays_table() ) {
        $success = false;
    }
    
    if ( $success ) {
        update_option( 'nsh_db_version', '6.2.1' );
        nsh_log( '=== v6.2.1 Migration Complete ===' );
    } else {
        nsh_log( '=== v6.2.1 Migration FAILED - Review errors above ===' );
    }
    
    return $success;
}

/**
 * Migration 1: Add shipping charges to tickets table
 * SAFE: Columns are optional with default values
 */
function nsh_migrate_shipping_charges() {
    global $wpdb;
    
    $table = $wpdb->prefix . 'nsh_tickets';
    
    // Safety check: ensure table exists
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
        nsh_log( 'Migration shipping_charges: Table not found' );
        return false;
    }
    
    // Check if columns already exist
    $columns = $wpdb->get_col( "SHOW COLUMNS FROM $table" );
    
    $migrations_needed = array();
    
    if ( ! in_array( 'shipping_charges', $columns ) ) {
        // NOTE: quote_amount lives on nsh_request postmeta, not as a column on
        // this tickets table, so "AFTER quote_amount" (inherited from the
        // original codebase) would fail with "Unknown column 'quote_amount'".
        // Appending the column at the end of the table is equally valid.
        $migrations_needed[] = "ADD COLUMN shipping_charges DECIMAL(10,2) DEFAULT 0";
    }
    
    if ( ! in_array( 'shipping_type', $columns ) ) {
        $migrations_needed[] = "ADD COLUMN shipping_type VARCHAR(50) DEFAULT 'domestic' AFTER shipping_charges";
    }
    
    if ( empty( $migrations_needed ) ) {
        nsh_log( 'Migration shipping_charges: Already complete' );
        return true;
    }
    
    // Apply migrations
    $query = "ALTER TABLE $table " . implode( ', ', $migrations_needed );
    
    if ( $wpdb->query( $query ) === false ) {
        nsh_log( 'Migration shipping_charges: FAILED - ' . $wpdb->last_error );
        return false;
    }
    
    nsh_log( 'Migration shipping_charges: SUCCESS' );
    return true;
}

/**
 * Migration 2: Update status ENUM to include new statuses
 * SAFE: ENUM extension preserves old values
 */
function nsh_migrate_status_enum() {
    global $wpdb;
    
    $table = $wpdb->prefix . 'nsh_tickets';
    
    // Safety check: ensure table exists
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
        nsh_log( 'Migration status_enum: Table not found' );
        return false;
    }
    
    // Check current status column definition
    $result = $wpdb->get_results( "SHOW COLUMNS FROM $table WHERE Field = 'status'" );
    if ( empty( $result ) ) {
        nsh_log( 'Migration status_enum: Status column not found' );
        return false;
    }
    
    $current_type = $result[0]->Type;
    
    // Check if new values already exist
    if ( strpos( $current_type, 'ready_for_processing' ) !== false && 
         strpos( $current_type, 'service_not_available' ) !== false ) {
        nsh_log( 'Migration status_enum: Already complete' );
        return true;
    }
    
    // Apply the ENUM update (backward compatible)
    $query = "ALTER TABLE $table 
              MODIFY COLUMN status ENUM(
                  'received',
                  'under_review',
                  'ready_for_processing',
                  'processing',
                  'dispatched',
                  'service_not_available',
                  'completed'
              ) DEFAULT 'received'";
    
    if ( $wpdb->query( $query ) === false ) {
        nsh_log( 'Migration status_enum: FAILED - ' . $wpdb->last_error );
        return false;
    }
    
    nsh_log( 'Migration status_enum: SUCCESS' );
    return true;
}

/**
 * Migration 3: Create holidays table for delivery date calculation
 * SAFE: New table only, no impact on existing data
 */
function nsh_migrate_holidays_table() {
    global $wpdb;
    
    $table = $wpdb->prefix . 'nsh_holidays';
    $charset_collate = $wpdb->get_charset_collate();
    
    // Check if table already exists
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) === $table ) {
        nsh_log( 'Migration holidays_table: Already exists' );
        return true;
    }
    
    $sql = "CREATE TABLE $table (
        id INT AUTO_INCREMENT PRIMARY KEY,
        date DATE NOT NULL,
        holiday_name VARCHAR(255),
        holiday_type ENUM('national', 'state', 'university') DEFAULT 'national',
        state_code VARCHAR(10),
        university_id INT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_holiday (date, university_id),
        KEY idx_date (date),
        KEY idx_type (holiday_type),
        KEY idx_university (university_id)
    ) $charset_collate;";
    
    require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
    dbDelta( $sql );
    
    // Verify table was created
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
        nsh_log( 'Migration holidays_table: FAILED to create' );
        return false;
    }
    
    nsh_log( 'Migration holidays_table: SUCCESS' );
    
    // Add some default Indian national holidays for 2026
    nsh_seed_default_holidays();
    
    return true;
}

/**
 * Seed default holidays for India (2026)
 */
function nsh_seed_default_holidays() {
    global $wpdb;
    
    $table = $wpdb->prefix . 'nsh_holidays';
    
    $holidays = array(
        array( '2026-01-26', 'Republic Day', 'national' ),
        array( '2026-03-08', 'Holi', 'national' ),
        array( '2026-04-02', 'Mahavir Jayanti', 'national' ),
        array( '2026-04-06', 'Ram Navami', 'national' ),
        array( '2026-08-15', 'Independence Day', 'national' ),
        array( '2026-10-02', 'Gandhi Jayanti', 'national' ),
        array( '2026-10-24', 'Dussehra', 'national' ),
        array( '2026-11-12', 'Diwali', 'national' ),
        array( '2026-11-13', 'Diwali (Second Day)', 'national' ),
        array( '2026-12-25', 'Christmas', 'national' ),
    );
    
    foreach ( $holidays as $holiday ) {
        $wpdb->insert(
            $table,
            array(
                'date' => $holiday[0],
                'holiday_name' => $holiday[1],
                'holiday_type' => $holiday[2]
            ),
            array( '%s', '%s', '%s' )
        );
    }
    
    nsh_log( 'Default holidays seeded for 2026' );
}

/**
 * Rollback function (for testing/emergency)
 * WARNING: Only use if absolutely necessary
 */
function nsh_rollback_v6_2_1() {
    if ( ! current_user_can( 'manage_options' ) ) {
        nsh_log( 'Rollback denied: insufficient permissions' );
        return false;
    }
    
    global $wpdb;
    
    nsh_log( '=== Starting v6.2.1 Rollback ===' );
    
    // Rollback 1: Remove shipping columns
    $table = $wpdb->prefix . 'nsh_tickets';
    $wpdb->query( "ALTER TABLE $table DROP COLUMN IF EXISTS shipping_charges, DROP COLUMN IF EXISTS shipping_type" );
    
    // Rollback 2: Drop holidays table
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}nsh_holidays" );
    
    // Rollback 3: Restore old status ENUM
    $wpdb->query( "ALTER TABLE $table 
                   MODIFY COLUMN status ENUM('received','under_review','processing','dispatched','completed') 
                   DEFAULT 'received'" );
    
    update_option( 'nsh_db_version', '6.2.0' );
    
    nsh_log( '=== v6.2.1 Rollback Complete ===' );
    
    return true;
}

/**
 * v6.18.0: Internal Status (CRM pipeline) table for installs that are
 * upgrading rather than freshly activating — nsh_create_tables() (schema.php)
 * only ever runs on activation, so an already-installed site would
 * otherwise never get this table just from dropping in a new plugin
 * version. SAFE: new table only, no impact on any existing data; requests
 * with no internal_status meta yet simply read as "Inquiry" (see
 * nsh_get_meta() in helpers.php) until staff explicitly change one.
 */
function nsh_migrate_v6_18_0() {
    if ( version_compare( get_option( 'nsh_db_version', '0' ), '6.18.0', '>=' ) ) {
        return true;
    }
    global $wpdb;
    $table = $wpdb->prefix . 'nsh_internal_statuses';
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table (
            id INT AUTO_INCREMENT PRIMARY KEY,
            slug VARCHAR(100) NOT NULL,
            label VARCHAR(200) NOT NULL,
            color VARCHAR(20) DEFAULT '#6b7280',
            sort_order INT DEFAULT 0,
            is_active TINYINT(1) DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uq_slug (slug)
        ) $charset_collate;";
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
            nsh_log( 'Migration v6.18.0: FAILED to create nsh_internal_statuses' );
            return false;
        }
        nsh_log( 'Migration v6.18.0: nsh_internal_statuses created' );
    }
    if ( ! $wpdb->get_var( "SELECT COUNT(*) FROM $table" ) && function_exists( 'nsh_seed_internal_statuses' ) ) {
        nsh_seed_internal_statuses();
        nsh_log( 'Migration v6.18.0: default internal statuses seeded' );
    }
    update_option( 'nsh_db_version', '6.18.0' );
    nsh_log( 'Migration v6.18.0: complete' );
    return true;
}

/**
 * v6.19.0: repair field_options rows corrupted by the old comma-delimiter
 * bug (nsh_parse_field_options, helpers.php, explains the root cause —
 * option text like "Under ₹2,000" was indistinguishable from two options
 * separated by a comma). This is a genuine DATA repair, not just a code
 * fix: every site that already ran the old seeding code has field_options
 * rows stored in the broken comma format, and switching the parser alone
 * (already done) doesn't retroactively fix rows the parser reads as its
 * comma fallback.
 *
 * Repair strategy, per row:
 *   1. If the field's field_key matches one in services-seed.json (the
 *      one place this plugin's options text is authored correctly, as a
 *      real array — see nsh_seed_services_and_fields, schema.php), take
 *      that array as ground truth and re-store it newline-joined. This
 *      recovers the CORRECT original text for every seeded field, not an
 *      approximation.
 *   2. Otherwise (a field an admin added or edited after install, so it
 *      isn't in the seed) — re-store the field's CURRENT best-effort
 *      comma-split under the new newline delimiter. This doesn't
 *      un-corrupt a comma-containing value an admin may have typed (that
 *      data loss already happened on save, before this migration exists,
 *      and can't be reconstructed), but it's no worse than what the site
 *      was already showing, and every row ends up on the same delimiter
 *      going forward.
 * SAFE: touches only the field_options column; every other column and
 * every other table is untouched.
 */
function nsh_migrate_v6_19_0() {
    if ( version_compare( get_option( 'nsh_db_version', '0' ), '6.19.0', '>=' ) ) {
        return true;
    }
    global $wpdb;
    $table = $wpdb->prefix . 'nsh_fields';
    if ( $wpdb->get_var( "SHOW TABLES LIKE '$table'" ) !== $table ) {
        update_option( 'nsh_db_version', '6.19.0' );
        return true;
    }

    // Build [service_slug][field_key] => correct options-array lookup from
    // the seed file. Scoped by service, NOT just field_key: the same
    // field_key (e.g. "budget_range", "timeline") is reused across many
    // different services with DIFFERENT option text for each, so a flat
    // field_key => options map would let the last service seen in the
    // file silently overwrite every earlier service's correct options —
    // fixing the comma-corruption bug while introducing a wrong-options
    // bug for every service but one. Scoping by service_slug avoids that.
    $seed_options = array();
    $seed_path    = NSH_DIR . 'includes/data/services-seed.json';
    if ( file_exists( $seed_path ) ) {
        $seed = json_decode( file_get_contents( $seed_path ), true );
        if ( is_array( $seed ) && ! empty( $seed['services'] ) ) {
            foreach ( $seed['services'] as $svc ) {
                if ( empty( $svc['slug'] ) ) { continue; }
                foreach ( ( $svc['fields'] ?? array() ) as $f ) {
                    if ( ! empty( $f['field_key'] ) && is_array( $f['options'] ?? null ) && $f['options'] ) {
                        $seed_options[ $svc['slug'] ][ $f['field_key'] ] = $f['options'];
                    }
                }
            }
        }
    }

    $rows = $wpdb->get_results(
        "SELECT nf.id, nf.field_key, nf.field_options, ns.slug AS service_slug
         FROM $table nf
         LEFT JOIN {$wpdb->prefix}nsh_services ns ON ns.id = nf.service_id
         WHERE nf.field_options IS NOT NULL AND nf.field_options != ''"
    );
    $fixed   = 0;
    $skipped = 0;
    foreach ( $rows as $row ) {
        // Already newline-delimited (this row was created/edited after
        // this fix shipped) — nothing to repair.
        if ( strpos( $row->field_options, "\n" ) !== false ) { $skipped++; continue; }

        if ( $row->service_slug && isset( $seed_options[ $row->service_slug ][ $row->field_key ] ) ) {
            $new_value = implode( "\n", $seed_options[ $row->service_slug ][ $row->field_key ] );
        } else {
            $new_value = implode( "\n", nsh_parse_field_options( $row->field_options ) );
        }
        if ( $new_value !== $row->field_options ) {
            $wpdb->update( $table, array( 'field_options' => $new_value ), array( 'id' => $row->id ) );
            $fixed++;
        }
    }
    nsh_log( "Migration v6.19.0: repaired $fixed field_options row(s), $skipped already OK" );
    update_option( 'nsh_db_version', '6.19.0' );
    return true;
}

/**
 * Migration v6.20.0 — repair core plugin pages whose post_content has the
 * wrong (or no) shortcode for their slug.
 *
 * ROOT CAUSE this fixes: nsh_create_pages() (includes/admin-menu.php) only
 * creates a core page — Admin Dashboard, Client Dashboard, NSH Login,
 * Request, Request Submit, Services — when NO page already exists at that
 * slug (`if ( ! get_page_by_path( $slug ) )`). It never checks or corrects
 * the CONTENT of a page that's already there. So if the page at
 * /nsh-admin-dashboard/ ever ended up holding the wrong shortcode —
 * e.g. [nsh_client_dashboard] instead of [nsh_admin_dashboard] — from an
 * accidental manual edit in the Pages screen, a page builder/theme that
 * rewrote it, a restored revision, or slugs having been created in the
 * wrong order on a very early install — every future plugin update leaves
 * that wrong content in place forever, because the "already exists, skip"
 * check has no idea the content is wrong.
 *
 * Symptom this produces, exactly as reported: the URL bar is 100% correct
 * (/nsh-admin-dashboard/?tab=settings&section=... — every settings link
 * just adds query params to this one page), but the screen shows the
 * CLIENT dashboard, because that is genuinely what the page's own
 * post_content shortcode renders. It is not a caching issue and a
 * cache-busting query param correctly makes no difference, because the
 * server is rendering the wrong content ON PURPOSE, straight from the DB —
 * there is nothing stale being served.
 *
 * FIX: for each of the 6 core slugs, if the page exists but its
 * post_content does NOT contain the shortcode tag that slug is supposed
 * to render, overwrite post_content with the correct shortcode. A slug
 * that's missing entirely is left for nsh_create_pages() to create fresh,
 * exactly as it already does.
 *
 * SAFE: only touches post_content on an exact slug match, and only when
 * the expected shortcode tag isn't already present in it (so any extra
 * text/blocks/shortcodes an admin added around the required shortcode are
 * left untouched — this only fixes an outright wrong/missing shortcode,
 * never rewrites content that's already correct).
 */
function nsh_migrate_v6_20_0() {
    if ( version_compare( get_option( 'nsh_db_version', '0' ), '6.20.0', '>=' ) ) {
        return true;
    }

    $expected = array(
        'nsh-login'           => '[nsh_login_form]',
        'nsh-request-submit'  => '[nsh_request_form]',
        'nsh-client-dashboard'=> '[nsh_client_dashboard]',
        'nsh-request'         => '[nsh_request_view]',
        'nsh-admin-dashboard' => '[nsh_admin_dashboard]',
        'nsh-services'        => '[nsh_services]',
    );

    global $wpdb;
    $fixed = array();
    foreach ( $expected as $slug => $shortcode_tag ) {
        $page = get_page_by_path( $slug );
        if ( ! $page ) { continue; } // nsh_create_pages() will create it fresh

        // Match the bare tag name, not attributes/brackets, so
        // [nsh_admin_dashboard class="x"] etc. still counts as correct.
        $tag = trim( $shortcode_tag, '[]' );
        if ( ! has_shortcode( (string) $page->post_content, $tag ) ) {
            // Write straight to the posts table rather than wp_update_post():
            // this is a one-line content swap, not a real editorial change,
            // so it deliberately skips post-save side effects (a new
            // revision row, save_post/post_updated hooks other plugins may
            // be listening on) the same way this file's other migrations
            // (e.g. v6.19.0 above) write directly via $wpdb rather than
            // going through the full post-save pipeline for a bulk/
            // maintenance-style data repair.
            $old_excerpt = wp_trim_words( (string) $page->post_content, 8 );
            $wpdb->update(
                $wpdb->posts,
                array( 'post_content' => $shortcode_tag ),
                array( 'ID' => $page->ID )
            );
            clean_post_cache( $page->ID );
            $fixed[] = $slug . ' (had: ' . $old_excerpt . ')';
        }
    }

    if ( $fixed ) {
        nsh_log( 'Migration v6.20.0: repaired wrong/missing shortcode on page(s): ' . implode( '; ', $fixed ) );
    } else {
        nsh_log( 'Migration v6.20.0: all core pages already have their correct shortcode' );
    }
    update_option( 'nsh_db_version', '6.20.0' );
    return true;
}

/**
 * v6.21.0 migration: backfill a "Contact Person Name" field onto the
 * Contact Details step of every EXISTING service.
 *
 * services-seed.json (the source every service's field set is imported
 * from — see nsh_seed_services_and_fields() in schema.php) now bakes a
 * contact_person_name field into every service's own Contact Details
 * step, but that importer only ever runs ONCE, on first activation
 * (schema.php: "if ( ! count(nsh_services) ) nsh_seed_services_and_fields()").
 * A site that was already activated before this change has 50 real
 * nsh_fields rows per service sitting in its live database, copied from
 * an OLDER version of that JSON that never had this field — so the new
 * field only reaches a fresh install "for free"; every existing install
 * needs it inserted into its live wp_nsh_fields table directly, which is
 * what this migration does.
 *
 * "The Contact Details step" isn't always step 98: most services use
 * that conventional number, but a handful (ported straight from
 * Services2NRI with their own step numbering — e.g. Affidavit Services
 * uses step 3) number their last couple of steps with small sequential
 * integers instead. Rather than assume 98, this finds — PER SERVICE —
 * whichever step number actually holds that service's own __phone /
 * __email fields (every service has at least one of the two on its
 * Contact Details step, whatever step number that happens to be) and
 * inserts the new field there, one position before the earliest existing
 * field in that same step (so it reads first, ahead of Phone/Email).
 *
 * SAFE / idempotent: skips any service that already has a
 * contact_person_name field (covers both a re-run of this exact
 * migration and a fresh install that got it from the JSON already), and
 * only ever INSERTs a new field row — never touches an existing one.
 */
function nsh_migrate_v6_21_0() {
    if ( version_compare( get_option( 'nsh_db_version', '0' ), '6.21.0', '>=' ) ) {
        return true;
    }

    global $wpdb;
    $ft = $wpdb->prefix . 'nsh_fields';
    $st = $wpdb->prefix . 'nsh_services';

    if ( $wpdb->get_var( "SHOW TABLES LIKE '$ft'" ) !== $ft ) {
        // Tables don't exist yet (very first activation, before
        // nsh_create_tables() has run) — nothing to backfill; the fresh
        // seed from services-seed.json will already include the field.
        update_option( 'nsh_db_version', '6.21.0' );
        return true;
    }

    $service_ids = $wpdb->get_col( "SELECT id FROM {$st}" );
    $added       = array();
    $skipped     = 0;

    foreach ( $service_ids as $sid ) {
        $sid = (int) $sid;
        $has = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$ft} WHERE service_id=%d AND field_key='contact_person_name' LIMIT 1",
            $sid
        ) );
        if ( $has ) { $skipped++; continue; }

        // Find this service's own Contact Details step: whichever
        // step_number holds its __phone and/or __email field(s).
        $contact_step = $wpdb->get_var( $wpdb->prepare(
            "SELECT MIN(step_number) FROM {$ft} WHERE service_id=%d AND field_key IN ('__phone','__email')",
            $sid
        ) );
        if ( $contact_step === null ) {
            // No contact step detected at all (shouldn't happen on any
            // real service, but don't guess — skip rather than insert
            // the field somewhere arbitrary).
            nsh_log( 'Migration v6.21.0: service ' . $sid . ' has no __phone/__email field — skipped' );
            continue;
        }
        $contact_step = (int) $contact_step;

        $min_sort = $wpdb->get_var( $wpdb->prepare(
            "SELECT MIN(sort_order) FROM {$ft} WHERE service_id=%d AND step_number=%d",
            $sid, $contact_step
        ) );
        $min_sort = $min_sort !== null ? (int) $min_sort : 0;

        $wpdb->insert( $ft, array(
            'field_key'   => 'contact_person_name',
            'service_id'  => $sid,
            'field_label' => 'Contact Person Name',
            'field_type'  => 'text',
            'field_options' => '',
            'placeholder' => '',
            'description' => 'The name of the person we should address / contact regarding this request (may be different from the applicant)',
            'is_required' => 1,
            'sort_order'  => $min_sort - 1,
            'is_active'   => 1,
            'step_number' => $contact_step,
        ) );
        $added[] = $sid . ' (step ' . $contact_step . ')';
    }

    if ( $added ) {
        nsh_log( 'Migration v6.21.0: added contact_person_name field to service(s): ' . implode( ', ', $added ) . ' — ' . $skipped . ' already had it' );
    } else {
        nsh_log( 'Migration v6.21.0: all services already had contact_person_name (' . $skipped . ' skipped)' );
    }

    update_option( 'nsh_db_version', '6.21.0' );
    return true;
}

/**
 * Adds the new "Gazette Name Change" service (slug: gazette-name-change,
 * 18 fields across 4 steps — service details, applicant/family details,
 * Contact Details, Documents) to the live catalog.
 *
 * services-seed.json now bakes this service in, but — same root cause as
 * nsh_migrate_v6_21_0()'s docblock explains for contact_person_name —
 * nsh_seed_services_and_fields() (schema.php) that actually inserts
 * services from that JSON only ever runs ONCE, on first activation, when
 * wp_nsh_services is completely empty. Any site already activated before
 * this change has its 50 original services sitting in the live database
 * already, so it never re-reads the JSON and never picks up the new 51st
 * one on its own — this migration does that insert directly.
 *
 * Reuses nsh_seed_services_and_fields() itself rather than duplicating
 * its insert logic: that function already skips any slug it finds
 * already in wp_nsh_services (see schema.php — "$existing = ...; if
 * ($existing) continue;"), so calling it here is safe to run on both a
 * site that already has all 50 original services (only the new
 * gazette-name-change slug is missing, so only it gets inserted) and a
 * fresh install that got all 51 already from the JSON during activation
 * (every slug already exists, so this becomes a same-day no-op) — while
 * still guarded by the usual db_version check below so it only actually
 * runs its one real DB write once per site either way.
 */
function nsh_migrate_v6_22_0() {
    if ( version_compare( get_option( 'nsh_db_version', '0' ), '6.22.0', '>=' ) ) {
        return true;
    }

    global $wpdb;
    $st = $wpdb->prefix . 'nsh_services';

    if ( $wpdb->get_var( "SHOW TABLES LIKE '$st'" ) !== $st ) {
        // Very first activation, before nsh_create_tables() has run —
        // nothing to backfill; the fresh seed from services-seed.json
        // will already include the new service.
        update_option( 'nsh_db_version', '6.22.0' );
        return true;
    }

    $existing = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$st} WHERE slug=%s", 'gazette-name-change'
    ) );

    if ( $existing ) {
        nsh_log( 'Migration v6.22.0: gazette-name-change already present (id ' . $existing . ') — nothing to do' );
    } else {
        nsh_seed_services_and_fields();
        $new_id = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$st} WHERE slug=%s", 'gazette-name-change'
        ) );
        nsh_log( 'Migration v6.22.0: added gazette-name-change service' . ( $new_id ? ' (id ' . $new_id . ')' : ' — INSERT DID NOT TAKE, check services-seed.json' ) );
    }

    update_option( 'nsh_db_version', '6.22.0' );
    return true;
}

// Auto-run migrations on plugins_loaded
add_action( 'plugins_loaded', 'nsh_migrate_v6_2_1', 20 );
add_action( 'plugins_loaded', 'nsh_migrate_v6_18_0', 21 );
add_action( 'plugins_loaded', 'nsh_migrate_v6_19_0', 22 );
add_action( 'plugins_loaded', 'nsh_migrate_v6_20_0', 23 );
add_action( 'plugins_loaded', 'nsh_migrate_v6_21_0', 24 );
add_action( 'plugins_loaded', 'nsh_migrate_v6_22_0', 25 );

nsh_log( 'Migration module loaded' );
