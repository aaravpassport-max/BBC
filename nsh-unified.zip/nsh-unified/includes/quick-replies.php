<?php
/**
 * Quick Replies / Predefined Templates System
 * Similar to WhatsApp Quick Replies
 * Version: 6.2.1
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Get all quick replies
 */
function nsh_get_quick_replies( $category = '' ) {
    $replies = get_option( 'nsh_quick_replies', array() );
    
    if ( empty( $category ) ) {
        return $replies;
    }
    
    // Filter by category
    return array_filter( $replies, function( $reply ) use ( $category ) {
        return isset( $reply['category'] ) && $reply['category'] === $category;
    });
}

/**
 * Add quick reply
 */
function nsh_add_quick_reply( $title, $content, $category = '' ) {
    if ( ! current_user_can( 'manage_options' ) ) {
        return false;
    }
    
    $replies = get_option( 'nsh_quick_replies', array() );
    
    $reply = array(
        'id' => uniqid( 'qr_' ),
        'title' => sanitize_text_field( $title ),
        'content' => wp_kses_post( $content ),
        'category' => sanitize_text_field( $category ),
        'created_at' => current_time( 'mysql' )
    );
    
    $replies[] = $reply;
    
    if ( update_option( 'nsh_quick_replies', $replies ) ) {
        nsh_log( 'Quick reply added: ' . $title );
        return $reply;
    }
    
    return false;
}

/**
 * Update quick reply
 */
function nsh_update_quick_reply( $id, $title, $content, $category = '' ) {
    if ( ! current_user_can( 'manage_options' ) ) {
        return false;
    }
    
    $replies = get_option( 'nsh_quick_replies', array() );
    
    foreach ( $replies as $key => $reply ) {
        if ( $reply['id'] === $id ) {
            $replies[$key]['title'] = sanitize_text_field( $title );
            $replies[$key]['content'] = wp_kses_post( $content );
            $replies[$key]['category'] = sanitize_text_field( $category );
            $replies[$key]['updated_at'] = current_time( 'mysql' );
            
            if ( update_option( 'nsh_quick_replies', $replies ) ) {
                nsh_log( 'Quick reply updated: ' . $id );
                return $replies[$key];
            }
        }
    }
    
    return false;
}

/**
 * Delete quick reply
 */
function nsh_delete_quick_reply( $id ) {
    if ( ! current_user_can( 'manage_options' ) ) {
        return false;
    }
    
    $replies = get_option( 'nsh_quick_replies', array() );
    
    $replies = array_filter( $replies, function( $reply ) use ( $id ) {
        return $reply['id'] !== $id;
    });
    
    $replies = array_values( $replies ); // Re-index
    
    if ( update_option( 'nsh_quick_replies', $replies ) ) {
        nsh_log( 'Quick reply deleted: ' . $id );
        return true;
    }
    
    return false;
}

// AJAX endpoint to get quick replies
add_action( 'wp_ajax_nsh_get_quick_replies', 'nsh_ajax_get_quick_replies' );
function nsh_ajax_get_quick_replies() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_send_json_error( 'Insufficient permissions' );
    }
    
    $category = isset( $_GET['category'] ) ? sanitize_text_field( $_GET['category'] ) : '';
    $replies = nsh_get_quick_replies( $category );
    
    wp_send_json_success( $replies );
}

// AJAX endpoint to add quick reply
add_action( 'wp_ajax_nsh_add_quick_reply', 'nsh_ajax_add_quick_reply' );
function nsh_ajax_add_quick_reply() {
    nsh_check_nonce();
    nsh_require_staff();
    
    $title = isset( $_POST['title'] ) ? sanitize_text_field( $_POST['title'] ) : '';
    $content = isset( $_POST['content'] ) ? wp_kses_post( $_POST['content'] ) : '';
    $category = isset( $_POST['category'] ) ? sanitize_text_field( $_POST['category'] ) : '';
    
    if ( empty( $title ) || empty( $content ) ) {
        wp_send_json_error( 'Title and content required' );
    }
    
    $result = nsh_add_quick_reply( $title, $content, $category );
    
    if ( $result ) {
        wp_send_json_success( $result );
    } else {
        wp_send_json_error( 'Failed to add quick reply' );
    }
}

// AJAX endpoint to update quick reply
add_action( 'wp_ajax_nsh_update_quick_reply', 'nsh_ajax_update_quick_reply' );
function nsh_ajax_update_quick_reply() {
    nsh_check_nonce();
    nsh_require_staff();

    // Form sends 'reply_id'; fallback to 'id' for API compatibility
    $id       = isset( $_POST['reply_id'] ) ? sanitize_text_field( $_POST['reply_id'] )
              : ( isset( $_POST['id'] ) ? sanitize_text_field( $_POST['id'] ) : '' );
    $title    = isset( $_POST['title'] )    ? sanitize_text_field( $_POST['title'] )    : '';
    $content  = isset( $_POST['content'] )  ? wp_kses_post( $_POST['content'] )         : '';
    $category = isset( $_POST['category'] ) ? sanitize_text_field( $_POST['category'] ) : '';

    if ( empty( $id ) || empty( $title ) || empty( $content ) ) {
        wp_send_json_error( 'ID, title and content required' );
    }

    $result = nsh_update_quick_reply( $id, $title, $content, $category );

    if ( $result ) {
        wp_send_json_success( $result );
    } else {
        wp_send_json_error( 'Failed to update quick reply' );
    }
}

// AJAX endpoint to delete quick reply
add_action( 'wp_ajax_nsh_delete_quick_reply', 'nsh_ajax_delete_quick_reply' );
function nsh_ajax_delete_quick_reply() {
    nsh_check_nonce();
    nsh_require_staff();
    
    $id = isset( $_POST['id'] ) ? sanitize_text_field( $_POST['id'] ) : '';
    
    if ( empty( $id ) ) {
        wp_send_json_error( 'ID required' );
    }
    
    if ( nsh_delete_quick_reply( $id ) ) {
        wp_send_json_success( 'Quick reply deleted' );
    } else {
        wp_send_json_error( 'Failed to delete quick reply' );
    }
}

/**
 * Initialize default quick replies if none exist
 */
function nsh_initialize_default_quick_replies() {
    $replies = get_option( 'nsh_quick_replies', array() );
    
    if ( empty( $replies ) ) {
        $defaults = array(
            array(
                'id' => uniqid( 'qr_' ),
                'title' => 'Documents Required',
                'content' => 'Dear {CUSTOMER_NAME},

We need the following documents to process your request:
- All semester marksheets (properly scanned)
- Degree certificate (properly scanned)
- Passport copy

Please upload these at your earliest convenience.

Best regards,
BookMyTranscript Team',
                'category' => 'Documents',
                'created_at' => current_time( 'mysql' )
            ),
            array(
                'id' => uniqid( 'qr_' ),
                'title' => 'Processing Started',
                'content' => 'Dear {CUSTOMER_NAME},

Your request is now being processed. We will keep you updated on the progress.

Expected completion: {TIMELINE} working days

Best regards,
BookMyTranscript Team',
                'category' => 'Status',
                'created_at' => current_time( 'mysql' )
            ),
            array(
                'id' => uniqid( 'qr_' ),
                'title' => 'Follow-up Required',
                'content' => 'Dear {CUSTOMER_NAME},

We are following up with the university on your request. This may take a few additional days.

We will notify you as soon as we have an update.

Best regards,
BookMyTranscript Team',
                'category' => 'Status',
                'created_at' => current_time( 'mysql' )
            )
        );
        
        update_option( 'nsh_quick_replies', $defaults );
        nsh_log( 'Default quick replies initialized' );
    }
}

// Initialize defaults on activation
add_action( 'nsh_plugin_activate', 'nsh_initialize_default_quick_replies' );

nsh_log( 'Quick replies module loaded' );
