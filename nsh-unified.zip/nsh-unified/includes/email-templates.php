<?php
/**
 * Email Template Management System
 * Version: 6.2.1
 * 
 * Provides flexible, editable email templates with variable support
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Get email template
 * 
 * @param string $template_type The type of template
 * @param array $variables Variables to replace in template
 * @return array|false The template array or false
 */
function nsh_get_email_template( $template_type, $variables = array() ) {
    // Try to get custom template from database
    $custom = nsh_get_custom_template( $template_type );
    
    if ( $custom ) {
        $template = $custom;
    } else {
        // Fall back to default template
        $template = nsh_get_default_template( $template_type );
    }
    
    if ( ! $template ) {
        return false;
    }
    
    // Replace variables in both subject and body
    if ( isset( $template['subject'] ) ) {
        $template['subject'] = nsh_replace_template_variables( $template['subject'], $variables );
    }
    if ( isset( $template['body'] ) ) {
        $template['body'] = nsh_replace_template_variables( $template['body'], $variables );
    }
    
    return $template;
}

/**
 * Get custom template from database
 */
function nsh_get_custom_template( $template_type ) {
    $option_key = 'nsh_email_template_' . sanitize_key( $template_type );
    return get_option( $option_key );
}

/**
 * Save custom template
 */
function nsh_save_custom_template( $template_type, $subject, $body ) {
    if ( ! current_user_can( 'manage_options' ) ) {
        return false;
    }
    
    $option_key = 'nsh_email_template_' . sanitize_key( $template_type );
    
    // Sanitize content
    $subject = sanitize_text_field( $subject );
    $body = wp_kses_post( $body ); // Allows safe HTML
    
    $template = array(
        'subject' => $subject,
        'body' => $body,
        'updated_at' => current_time( 'mysql' )
    );
    
    return update_option( $option_key, $template );
}

/**
 * Get default templates
 */
function nsh_get_default_template( $template_type ) {
    $templates = array(
        'quotation' => array(
            'subject' => 'Your Quotation - {UNIVERSITY_NAME} Transcript Request',
            'body' => nsh_default_quotation_template()
        ),
        'application_received' => array(
            'subject' => 'Application Received - Request ID: {REQUEST_ID}',
            'body' => nsh_default_application_received_template()
        ),
        'status_update' => array(
            'subject' => 'Request Status Update - {REQUEST_ID}',
            'body' => nsh_default_status_update_template()
        ),
        'document_reminder' => array(
            'subject' => 'Documents Required - Request ID: {REQUEST_ID}',
            'body' => nsh_default_document_reminder_template()
        ),
        'completion' => array(
            'subject' => 'Your Request is Complete - {REQUEST_ID}',
            'body' => nsh_default_completion_template()
        ),
        'dispatch' => array(
            'subject' => 'Your Documents Have Been Dispatched - {REQUEST_ID}',
            'body' => nsh_default_dispatch_template()
        ),
        'terms_conditions' => array(
            'subject' => 'Terms & Conditions - {REQUEST_ID}',
            'body' => nsh_default_terms_conditions_template()
        ),
        // Internal STAFF-facing alert (not sent to the client) — sent to
        // whichever address Settings -> General -> Notification Contact
        // (Manager) resolves to (see nsh_admin_notification_email(),
        // notifications.php) every time a new request is submitted.
        // Added so this one is admin-editable too, same as every other
        // template — previously its content was hardcoded directly in
        // nsh_notify_new_request() with no template behind it at all.
        'new_request_admin' => array(
            'subject' => 'New Request Received - Order #{REQUEST_ID}',
            'body' => nsh_default_new_request_admin_template()
        ),
    );

    return isset( $templates[ $template_type ] ) ? $templates[ $template_type ] : false;
}

/**
 * Get all registered template types (default + any custom ones stored as options)
 */
function nsh_get_all_template_types() {
    $defaults = array(
        'quotation'            => '💰 Quotation',
        'application_received' => '✅ Application Received',
        'status_update'        => '🔄 Status Update',
        'document_reminder'    => '📄 Document Reminder',
        'completion'           => '🎉 Completion',
        'dispatch'             => '📦 Dispatch',
        'terms_conditions'     => '📋 Terms & Conditions',
        'new_request_admin'    => '🔔 New Request Alert (Admin)',
    );
    // Merge in any extra custom template types the admin created
    $extras = get_option( 'nsh_custom_template_types', array() );
    return array_merge( $defaults, $extras );
}

/**
 * Default quotation template
 */
function nsh_default_quotation_template() {
    return '
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #ffffff;">
        <div style="background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
            <h1 style="color: #ffffff; margin: 0; font-size: 28px;">{PLATFORM}</h1>
            <p style="color: #e0e7ff; margin: 10px 0 0; font-size: 14px;">Your Trusted Document Partner</p>
        </div>
        
        <div style="padding: 30px; background: #ffffff;">
            <p style="font-size: 16px; color: #111827; margin: 0 0 10px;">Dear {CUSTOMER_NAME},</p>
            <p style="font-size: 14px; color: #6b7280; line-height: 1.6; margin: 0 0 20px;">Greetings for the day!</p>
            <p style="font-size: 14px; color: #6b7280; line-height: 1.6;">Thank you for reaching out to us. Here is your customized quotation for transcript services:</p>
            
            <h2 style="color: #2563eb; font-size: 18px; margin: 30px 0 15px; padding-bottom: 10px; border-bottom: 2px solid #e5e7eb;">Applicant & Course Details</h2>
            <table style="width: 100%; border-collapse: collapse; margin: 15px 0;">
                <tr style="background: #f9fafb;">
                    <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; color: #374151; width: 40%;">Student Name</td>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; color: #6b7280;">{STUDENT_NAME}</td>
                </tr>
                <tr>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; color: #374151;">University</td>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; color: #6b7280;">{UNIVERSITY_NAME}</td>
                </tr>
                <tr style="background: #f9fafb;">
                    <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Course / Degree</td>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; color: #6b7280;">{COURSE_NAME}</td>
                </tr>
                <tr>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Year of Passing</td>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; color: #6b7280;">{YEAR_OF_PASSING}</td>
                </tr>
            </table>
            
            <h2 style="color: #2563eb; font-size: 18px; margin: 30px 0 15px; padding-bottom: 10px; border-bottom: 2px solid #e5e7eb;">Scope of Services</h2>
            <p style="font-size: 14px; color: #6b7280; line-height: 1.6;">We will assist in obtaining the official Transcript from the university for WES / foreign admission purposes.</p>
            <p style="font-size: 14px; color: #6b7280; line-height: 1.6; margin: 10px 0;">Our services include end-to-end support:</p>
            <ul style="font-size: 14px; color: #6b7280; line-height: 1.8; margin: 10px 0; padding-left: 20px;">
                <li>Document verification</li>
                <li>Application drafting and submission</li>
                <li>Coordination with the university</li>
                <li>Continuous follow-up</li>
                <li>Collection and dispatch of transcripts</li>
            </ul>
            
            <h2 style="color: #2563eb; font-size: 18px; margin: 30px 0 15px; padding-bottom: 10px; border-bottom: 2px solid #e5e7eb;">Professional Fees</h2>
            <table style="width: 100%; border-collapse: collapse; margin: 15px 0;">
                <tr style="background: #f9fafb;">
                    <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Service Charges</td>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; text-align: right; color: #6b7280; font-weight: 600;">₹{QUOTATION_AMOUNT}</td>
                </tr>
                <tr>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Shipping Charges ({SHIPPING_TYPE})</td>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; text-align: right; color: #6b7280; font-weight: 600;">₹{SHIPPING_CHARGES}</td>
                </tr>
                <tr style="background: #2563eb; color: white;">
                    <td style="padding: 15px; border: 1px solid #1e40af; font-weight: 700; font-size: 16px;">Total Amount</td>
                    <td style="padding: 15px; border: 1px solid #1e40af; text-align: right; font-weight: 700; font-size: 18px;">₹{TOTAL_AMOUNT}</td>
                </tr>
            </table>
            
            <h2 style="color: #2563eb; font-size: 18px; margin: 30px 0 15px; padding-bottom: 10px; border-bottom: 2px solid #e5e7eb;">Estimated Timeline</h2>
            <div style="background: #eff6ff; padding: 15px; border-radius: 8px; border-left: 4px solid #2563eb;">
                <p style="margin: 0; font-size: 16px; color: #1e40af; font-weight: 600;">{TIMELINE} Working Days</p>
                <p style="margin: 8px 0 0; font-size: 13px; color: #6b7280;">Excludes Saturdays, Sundays, and Government Holidays</p>
                <p style="margin: 8px 0 0; font-size: 14px; color: #374151; font-weight: 600;">Expected Delivery Date: {DELIVERY_DATE}</p>
            </div>
            
            {TERMS_AND_CONDITIONS}
            
            <div style="margin-top: 30px; padding: 20px; background: #f9fafb; border-radius: 8px; text-align: center;">
                <p style="margin: 0 0 10px; font-size: 14px; color: #6b7280;">This quotation is valid for <strong>7 days</strong> from the date of issue.</p>
                <p style="margin: 0; font-size: 13px; color: #9ca3af;">If you have any questions, please feel free to contact us.</p>
            </div>
        </div>
        
        <div style="background: #1f2937; padding: 25px; text-align: center; border-radius: 0 0 10px 10px;">
            <p style="margin: 0 0 10px; color: #e5e7eb; font-size: 14px; font-weight: 600;">Best regards,</p>
            <p style="margin: 0 0 15px; color: #9ca3af; font-size: 13px;">{PLATFORM} Team</p>
            <p style="margin: 0; color: #6b7280; font-size: 12px;">
                <a href="mailto:support@bookmytranscript.com" style="color: #60a5fa; text-decoration: none;">support@bookmytranscript.com</a>
            </p>
        </div>
    </div>
    ';
}

/**
 * Default application received template
 */
function nsh_default_application_received_template() {
    return '
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #2563eb;">Application Received</h2>
        <p>Dear {CUSTOMER_NAME},</p>
        <p>Greetings for the day!</p>
        <p>We have successfully received your application (Request ID: <strong>{REQUEST_ID}</strong>).</p>
        <p>Our team will review your application and get back to you within 24-48 hours.</p>
        <p>Thank you for choosing {PLATFORM}!</p>
        <p style="margin-top: 30px;">Best regards,<br><strong>{PLATFORM} Team</strong></p>
    </div>
    ';
}

/**
 * Default status update template
 */
function nsh_default_status_update_template() {
    return '
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #2563eb;">Status Update</h2>
        <p>Dear {CUSTOMER_NAME},</p>
        <p>Greetings for the day!</p>
        <p>Your request (ID: <strong>{REQUEST_ID}</strong>) status has been updated to: <strong>{NEW_STATUS}</strong></p>
        <p>{STATUS_MESSAGE}</p>
        <p>If you have any questions, please don\'t hesitate to contact us.</p>
        <p style="margin-top: 30px;">Best regards,<br><strong>{PLATFORM} Team</strong></p>
    </div>
    ';
}

/**
 * Default document reminder template
 */
function nsh_default_document_reminder_template() {
    return '
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #ef4444;">Documents Required</h2>
        <p>Dear {CUSTOMER_NAME},</p>
        <p>Greetings for the day!</p>
        <p>We need the following documents to process your request (ID: <strong>{REQUEST_ID}</strong>):</p>
        {DOCUMENT_LIST}
        <p style="background: #fef2f2; padding: 15px; border-left: 4px solid #ef4444; margin: 20px 0;">
            <strong>Important:</strong> Please ensure all documents are <strong>properly scanned</strong> using a printer scanner. 
            Your request cannot be processed without clear, legible scanned documents.
        </p>
        <p>Please upload the documents at your earliest convenience.</p>
        <p style="margin-top: 30px;">Best regards,<br><strong>{PLATFORM} Team</strong></p>
    </div>
    ';
}

/**
 * Default completion template
 */
function nsh_default_completion_template() {
    return '
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #10b981;">Request Completed! 🎉</h2>
        <p>Dear {CUSTOMER_NAME},</p>
        <p>Greetings for the day!</p>
        <p>We are pleased to inform you that your request (ID: <strong>{REQUEST_ID}</strong>) has been completed successfully.</p>
        <p>{COMPLETION_MESSAGE}</p>
        <p>Thank you for choosing {PLATFORM}. We hope to serve you again!</p>
        <p style="margin-top: 30px;">Best regards,<br><strong>{PLATFORM} Team</strong></p>
    </div>
    ';
}

/**
 * Default dispatch template
 */
function nsh_default_dispatch_template() {
    return '
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
        <h2 style="color: #2563eb;">Documents Dispatched 📦</h2>
        <p>Dear {CUSTOMER_NAME},</p>
        <p>Greetings for the day!</p>
        <p>Your documents for request (ID: <strong>{REQUEST_ID}</strong>) have been dispatched.</p>
        <p><strong>Tracking Information:</strong><br>{TRACKING_INFO}</p>
        <p>You should receive your documents within {DELIVERY_DAYS} working days.</p>
        <p style="margin-top: 30px;">Best regards,<br><strong>{PLATFORM} Team</strong></p>
    </div>
    ';
}

/**
 * Default terms & conditions template
 */
function nsh_default_terms_conditions_template() {
    return '
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #ffffff;">
        <div style="background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
            <h1 style="color: #ffffff; margin: 0; font-size: 24px;">Terms &amp; Conditions</h1>
            <p style="color: #e0e7ff; margin: 8px 0 0; font-size: 13px;">Please read carefully before proceeding</p>
        </div>
        <div style="padding: 30px; background: #ffffff;">
            <p style="font-size: 16px; color: #111827; margin: 0 0 10px;">Dear {CUSTOMER_NAME},</p>
            <p style="font-size: 14px; color: #6b7280; line-height: 1.6;">Greetings for the day!</p>
            <p style="font-size: 14px; color: #6b7280; line-height: 1.6; margin-bottom: 20px;">Please find below the Terms &amp; Conditions for your service request (Order ID: <strong>{REQUEST_ID}</strong>).</p>

            <div style="border: 1px solid #e5e7eb; border-radius: 8px; overflow: hidden;">
                <div style="background: #f9fafb; padding: 12px 20px; border-bottom: 1px solid #e5e7eb;">
                    <strong style="color: #374151; font-size: 14px;">Document Type:</strong>
                    <span style="color: #6b7280; font-size: 14px;"> {DOCUMENT_TYPE}</span>
                </div>

                <div style="padding: 20px;">
                    <h3 style="color: #1e40af; font-size: 15px; margin: 0 0 12px;">1. Non-Refundable Clause</h3>
                    <p style="font-size: 13px; color: #374151; line-height: 1.7; margin: 0 0 16px;">If the university is unable to trace the student\'s record, or if submitted documents are incorrect or incomplete, university fees are non-refundable. Accordingly, our service fee will also not be refunded in such circumstances.</p>

                    <h3 style="color: #1e40af; font-size: 15px; margin: 0 0 12px;">2. Processing Time</h3>
                    <p style="font-size: 13px; color: #374151; line-height: 1.7; margin: 0 0 16px;">The estimated timeline ({TIMELINE} Working Days) is indicative and excludes Saturdays, Sundays, and Government holidays. Actual delivery may vary depending on university workload or internal delays.</p>

                    <h3 style="color: #1e40af; font-size: 15px; margin: 0 0 12px;">3. Transcript Format</h3>
                    <p style="font-size: 13px; color: #374151; line-height: 1.7; margin: 0 0 16px;">The format of transcripts is entirely determined by the university. We do not control the format and cannot accommodate requests for specific layouts or designs.</p>

                    <h3 style="color: #1e40af; font-size: 15px; margin: 0 0 12px;">4. Service Disclaimer</h3>
                    <p style="font-size: 13px; color: #374151; line-height: 1.7; margin: 0 0 16px;">We are an independent service provider and are not affiliated with any university or institution. Our role is to facilitate the transcript application process on your behalf.</p>

                    <h3 style="color: #1e40af; font-size: 15px; margin: 0 0 12px;">5. Quotation Validity</h3>
                    <p style="font-size: 13px; color: #374151; line-height: 1.7; margin: 0;">This quotation is valid for <strong>7 days</strong> from the date of issue. There is no obligation to proceed. Fees are payable in advance before processing begins.</p>
                </div>
            </div>

            <div style="margin-top: 20px; padding: 16px 20px; background: #eff6ff; border-radius: 8px; border-left: 4px solid #2563eb;">
                <p style="margin: 0; font-size: 14px; color: #1e40af; font-weight: 600;">By proceeding with payment, you confirm that you have read, understood, and agreed to the above terms.</p>
            </div>
        </div>
        <div style="background: #1f2937; padding: 25px; text-align: center; border-radius: 0 0 10px 10px;">
            <p style="margin: 0 0 5px; color: #e5e7eb; font-size: 14px; font-weight: 600;">Best regards,</p>
            <p style="margin: 0; color: #9ca3af; font-size: 13px;">{PLATFORM} Team</p>
        </div>
    </div>
    ';
}

/**
 * Default "New Request Received" admin alert template. STAFF-facing (see
 * nsh_notify_new_request(), notifications.php) — mirrors the layout every
 * other default template here uses, so the admin's own new-request alert
 * is just as editable as the client-facing ones instead of being the one
 * notification with no template behind it at all.
 */
function nsh_default_new_request_admin_template() {
    return '
    <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background: #ffffff;">
        <div style="background: linear-gradient(135deg, #2563eb 0%, #1e40af 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
            <h1 style="color: #ffffff; margin: 0; font-size: 24px;">New Request Received</h1>
            <p style="color: #e0e7ff; margin: 8px 0 0; font-size: 13px;">{PLATFORM}</p>
        </div>
        <div style="padding: 30px; background: #ffffff;">
            <p style="font-size: 15px; color: #111827; margin: 0 0 16px; font-weight: 600;">A new service request has been submitted and requires your attention.</p>
            <table style="width: 100%; border-collapse: collapse; margin: 15px 0;">
                <tr style="background: #f9fafb;">
                    <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; color: #374151; width: 40%;">Client</td>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; color: #6b7280;">{CLIENT_NAME}</td>
                </tr>
                <tr>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Email</td>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; color: #6b7280;">{CLIENT_EMAIL}</td>
                </tr>
                <tr style="background: #f9fafb;">
                    <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Order ID</td>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; color: #6b7280;">{REQUEST_ID}</td>
                </tr>
                <tr>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; font-weight: 600; color: #374151;">Submitted</td>
                    <td style="padding: 12px; border: 1px solid #e5e7eb; color: #6b7280;">{SUBMITTED_DATE}</td>
                </tr>
            </table>
            <div style="text-align: center; margin: 28px 0 0;">
                <a href="{REQUEST_URL}" style="background: #2563eb; color: #fff; text-decoration: none; padding: 12px 32px; border-radius: 8px; font-size: 15px; font-weight: 600; display: inline-block;">View Request</a>
            </div>
        </div>
        <div style="background: #1f2937; padding: 20px; text-align: center; border-radius: 0 0 10px 10px;">
            <p style="margin: 0; color: #9ca3af; font-size: 12px;">This is an internal notification from {PLATFORM}.</p>
        </div>
    </div>
    ';
}

/**
 * Replace template variables
 * Supported variables: {CUSTOMER_NAME}, {REQUEST_ID}, {UNIVERSITY_NAME}, {QUOTATION_AMOUNT},
 * {SHIPPING_CHARGES}, {SHIPPING_TYPE}, {TOTAL_AMOUNT}, {TIMELINE}, {DELIVERY_DATE},
 * {DOCUMENT_TYPE}, {STATUS}, {PLATFORM}, {NEW_STATUS}, {STATUS_MESSAGE}
 */
function nsh_replace_template_variables( $template, $variables = array() ) {
    // Sanitize all variables
    $safe_vars = array();
    foreach ( $variables as $key => $value ) {
        $safe_vars[ '{' . strtoupper( $key ) . '}' ] = wp_kses_post( $value );
    }

    // Replace variables
    return str_replace( array_keys( $safe_vars ), array_values( $safe_vars ), $template );
}

// ── AJAX: Save email template ────────────────────────────────────────────────
// (Also registered in ajax.php — defined here for module completeness but won't
//  double-register because add_action checks function existence)
add_action( 'wp_ajax_nsh_save_email_template',      'nsh_ajax_save_email_template_module' );
function nsh_ajax_save_email_template_module() {
    // Delegate to the handler in ajax.php if it already ran; otherwise handle here.
    if ( function_exists( 'nsh_ajax_save_email_template' ) ) {
        nsh_ajax_save_email_template();
    }
}

// ── AJAX: Duplicate email template ──────────────────────────────────────────
add_action( 'wp_ajax_nsh_duplicate_email_template', 'nsh_ajax_duplicate_email_template' );
function nsh_ajax_duplicate_email_template() {
    nsh_check_nonce();
    nsh_require_staff();

    $source_type = sanitize_key( isset( $_POST['template_type'] ) ? $_POST['template_type'] : '' );
    $new_label   = sanitize_text_field( isset( $_POST['new_label'] ) ? $_POST['new_label'] : '' );

    if ( ! $source_type || ! $new_label ) {
        wp_send_json_error( array( 'message' => 'Source template and new label are required.' ) );
    }

    // Generate a unique key from the label
    $new_key = sanitize_key( str_replace( ' ', '_', strtolower( $new_label ) ) );
    if ( strlen( $new_key ) > 40 ) $new_key = substr( $new_key, 0, 40 );
    // Avoid collision with built-in keys
    $existing = nsh_get_all_template_types();
    if ( isset( $existing[ $new_key ] ) ) {
        $new_key = $new_key . '_' . time();
    }

    // Copy template content
    $source = nsh_get_email_template( $source_type );
    if ( ! $source ) {
        wp_send_json_error( array( 'message' => 'Source template not found.' ) );
    }
    $source['subject'] = '[Copy] ' . $source['subject'];

    // Save as custom template
    update_option( 'nsh_email_template_' . $new_key, array_merge( $source, array( 'updated_at' => current_time( 'mysql' ) ) ) );

    // Register the new type in the custom types list
    $custom_types             = get_option( 'nsh_custom_template_types', array() );
    $custom_types[ $new_key ] = '📋 ' . $new_label;
    update_option( 'nsh_custom_template_types', $custom_types );

    nsh_log( 'Email template duplicated: ' . $source_type . ' → ' . $new_key );
    wp_send_json_success( array( 'new_type' => $new_key, 'label' => $new_label, 'message' => 'Template duplicated successfully.' ) );
}

// ── AJAX: Create brand-new blank template ────────────────────────────────────
add_action( 'wp_ajax_nsh_create_email_template', 'nsh_ajax_create_email_template' );
function nsh_ajax_create_email_template() {
    nsh_check_nonce();
    nsh_require_staff();

    $new_label = sanitize_text_field( isset( $_POST['new_label'] ) ? $_POST['new_label'] : '' );
    if ( ! $new_label ) {
        wp_send_json_error( array( 'message' => 'Template name is required.' ) );
    }

    $new_key = sanitize_key( str_replace( ' ', '_', strtolower( $new_label ) ) );
    if ( strlen( $new_key ) > 40 ) $new_key = substr( $new_key, 0, 40 );
    $existing = nsh_get_all_template_types();
    if ( isset( $existing[ $new_key ] ) ) {
        $new_key = $new_key . '_' . time();
    }

    $blank = array(
        'subject'    => $new_label . ' - {REQUEST_ID}',
        'body'       => '<div style="font-family:Arial,sans-serif;max-width:600px;margin:0 auto;padding:20px;">'
                      . '<p>Dear {CUSTOMER_NAME},</p>'
                      . '<p>Greetings for the day!</p>'
                      . '<p>[Your message here]</p>'
                      . '<p>Best regards,<br>{PLATFORM} Team</p>'
                      . '</div>',
        'updated_at' => current_time( 'mysql' ),
    );
    update_option( 'nsh_email_template_' . $new_key, $blank );

    $custom_types             = get_option( 'nsh_custom_template_types', array() );
    $custom_types[ $new_key ] = '📝 ' . $new_label;
    update_option( 'nsh_custom_template_types', $custom_types );

    nsh_log( 'New email template created: ' . $new_key );
    wp_send_json_success( array( 'new_type' => $new_key, 'label' => $new_label, 'message' => 'Template created successfully.' ) );
}

// ── AJAX: Delete custom template type ───────────────────────────────────────
add_action( 'wp_ajax_nsh_delete_custom_template', 'nsh_ajax_delete_custom_template' );
function nsh_ajax_delete_custom_template() {
    nsh_check_nonce();
    nsh_require_staff();

    $type = sanitize_key( isset( $_POST['template_type'] ) ? $_POST['template_type'] : '' );
    if ( ! $type ) {
        wp_send_json_error( array( 'message' => 'Template type required.' ) );
    }
    // Prevent deleting built-in types
    $builtin = array( 'quotation','application_received','status_update','document_reminder','completion','dispatch','terms_conditions','new_request_admin' );
    if ( in_array( $type, $builtin ) ) {
        wp_send_json_error( array( 'message' => 'Built-in templates cannot be deleted.' ) );
    }

    delete_option( 'nsh_email_template_' . $type );
    $custom_types = get_option( 'nsh_custom_template_types', array() );
    unset( $custom_types[ $type ] );
    update_option( 'nsh_custom_template_types', $custom_types );

    wp_send_json_success( array( 'message' => 'Template deleted.' ) );
}

// Log that email templates module loaded
nsh_log( 'Email templates module loaded' );
function nsh_send_templated_email( $to_email, $template_type, $variables = array() ) {
    // Safety checks
    if ( ! is_email( $to_email ) ) {
        nsh_log( 'Invalid email: ' . $to_email );
        return false;
    }
    
    // Get template
    $template = nsh_get_email_template( $template_type, $variables );
    if ( ! $template ) {
        nsh_log( 'Template not found: ' . $template_type );
        return false;
    }
    
    $subject = $template['subject'];
    $body = $template['body'];
    
    // Prepare headers
    $headers = array( 'Content-Type: text/html; charset=UTF-8' );
    
    // Send email
    $sent = wp_mail( $to_email, $subject, $body, $headers );
    
    if ( $sent ) {
        nsh_log( "Email sent to: $to_email (Template: $template_type)" );
    } else {
        nsh_log( "Failed to send email to: $to_email (Template: $template_type)" );
    }
    
    return $sent;
}

// Log that email templates module loaded
nsh_log( 'Email templates module loaded' );
