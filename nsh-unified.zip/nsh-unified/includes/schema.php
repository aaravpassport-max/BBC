<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function nsh_create_tables() {
    global $wpdb;
    $c = $wpdb->get_charset_collate();
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nsh_fields (id int NOT NULL AUTO_INCREMENT,field_key varchar(100) NOT NULL,field_label varchar(200) NOT NULL,field_type varchar(50) NOT NULL DEFAULT 'text',field_options text,placeholder varchar(300) DEFAULT '',description text DEFAULT NULL,is_required tinyint(1) DEFAULT 0,sort_order int DEFAULT 0,is_active tinyint(1) DEFAULT 1,step_number int DEFAULT 1,conditions longtext DEFAULT NULL,PRIMARY KEY(id),UNIQUE KEY uq_fk(field_key)) $c");
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nsh_dropdown_options (id int NOT NULL AUTO_INCREMENT,field_key varchar(100) NOT NULL,option_value varchar(500) NOT NULL,sort_order int DEFAULT 0,PRIMARY KEY(id),KEY idx_fk(field_key)) $c");
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nsh_request_types (id int NOT NULL AUTO_INCREMENT,name varchar(200) NOT NULL,description text,icon varchar(20) DEFAULT '',sort_order int DEFAULT 0,is_active tinyint(1) DEFAULT 1,PRIMARY KEY(id)) $c");
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nsh_tickets (id int NOT NULL AUTO_INCREMENT,request_id bigint unsigned DEFAULT 0,user_id bigint unsigned DEFAULT 0,type_id int DEFAULT 0,category varchar(200) DEFAULT '',status varchar(50) DEFAULT 'open',notes text,created_at datetime DEFAULT CURRENT_TIMESTAMP,updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_req(request_id)) $c");
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nsh_messages (id int NOT NULL AUTO_INCREMENT,request_id bigint unsigned DEFAULT 0,sender_id bigint unsigned DEFAULT 0,message text NOT NULL,is_email_sent tinyint(1) DEFAULT 0,created_at datetime DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),KEY idx_req(request_id)) $c");
    // Migration: add conditions column if missing
    $cols = $wpdb->get_col("SHOW COLUMNS FROM {$wpdb->prefix}nsh_fields");
    if (!in_array('conditions', $cols)) {
        $wpdb->query("ALTER TABLE {$wpdb->prefix}nsh_fields ADD COLUMN conditions longtext DEFAULT NULL");
    }
    if (!in_array('description', $cols)) {
        $wpdb->query("ALTER TABLE {$wpdb->prefix}nsh_fields ADD COLUMN description text DEFAULT NULL");
    }
    // service_id: 0 = generic/global field (support-ticket style forms);
    // >0 = belongs only to that nsh_services.id's own dynamic field set.
    // score_weight/eligibility_rule: lead-qualification scoring inputs,
    // ported from Services2NRI's per-field qualification_schema.
    if (!in_array('service_id', $cols)) {
        $wpdb->query("ALTER TABLE {$wpdb->prefix}nsh_fields ADD COLUMN service_id bigint unsigned NOT NULL DEFAULT 0 AFTER field_key");
        $wpdb->query("ALTER TABLE {$wpdb->prefix}nsh_fields ADD KEY idx_service_step (service_id, step_number, sort_order)");
    }
    if (!in_array('score_weight', $cols)) {
        $wpdb->query("ALTER TABLE {$wpdb->prefix}nsh_fields ADD COLUMN score_weight smallint DEFAULT 0");
    }
    if (!in_array('eligibility_rule', $cols)) {
        $wpdb->query("ALTER TABLE {$wpdb->prefix}nsh_fields ADD COLUMN eligibility_rule longtext DEFAULT NULL");
    }
    // The original nsh_fields.field_key had a plugin-wide UNIQUE KEY (uq_fk),
    // which is incompatible with per-service fields re-using the same key
    // across different services (e.g. "purpose" appears in many service
    // forms). Replace it with a UNIQUE KEY scoped to (service_id, field_key).
    $idx = $wpdb->get_results("SHOW INDEX FROM {$wpdb->prefix}nsh_fields WHERE Key_name='uq_fk'");
    if ($idx) {
        $wpdb->query("ALTER TABLE {$wpdb->prefix}nsh_fields DROP INDEX uq_fk");
    }
    $idx2 = $wpdb->get_results("SHOW INDEX FROM {$wpdb->prefix}nsh_fields WHERE Key_name='uq_service_fk'");
    if (!$idx2) {
        $wpdb->query("ALTER TABLE {$wpdb->prefix}nsh_fields ADD UNIQUE KEY uq_service_fk (service_id, field_key)");
    }

    // Service catalog (ported from Services2NRI's s2nri_services, trimmed to
    // the columns this plugin's quote/timeline/document workflow actually
    // uses — category/pricing/turnaround/required-doc checklist).
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nsh_services (
        id int NOT NULL AUTO_INCREMENT,
        category varchar(50) NOT NULL DEFAULT 'documentation',
        slug varchar(150) NOT NULL,
        name varchar(200) NOT NULL,
        short_desc varchar(500) DEFAULT '',
        pricing_model varchar(20) NOT NULL DEFAULT 'quote',
        base_price decimal(10,2) DEFAULT NULL,
        turnaround_days smallint DEFAULT 7,
        required_docs longtext DEFAULT NULL,
        is_active tinyint(1) DEFAULT 1,
        sort_order int DEFAULT 0,
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        PRIMARY KEY(id),
        UNIQUE KEY uq_slug(slug),
        KEY idx_cat_active(category, is_active, sort_order)
    ) $c");

    // Lightweight review table (ported from Services2NRI's s2nri_reviews).
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nsh_reviews (
        id int NOT NULL AUTO_INCREMENT,
        request_id bigint unsigned NOT NULL,
        user_id bigint unsigned NOT NULL DEFAULT 0,
        rating tinyint NOT NULL DEFAULT 5,
        review text DEFAULT NULL,
        status varchar(20) NOT NULL DEFAULT 'pending',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY(id),
        UNIQUE KEY uq_request(request_id)
    ) $c");
    // Internal Status pipeline (CRM-style staff-only workflow stages —
    // never shown to clients; see nsh_internal_status_default_rows() and
    // nsh_migrate_internal_statuses_table() in includes/migrations.php,
    // which creates this same table for installs that are upgrading
    // rather than activating fresh).
    $wpdb->query("CREATE TABLE IF NOT EXISTS {$wpdb->prefix}nsh_internal_statuses (id int NOT NULL AUTO_INCREMENT,slug varchar(100) NOT NULL,label varchar(200) NOT NULL,color varchar(20) DEFAULT '#6b7280',sort_order int DEFAULT 0,is_active tinyint(1) DEFAULT 1,created_at datetime DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(id),UNIQUE KEY uq_slug(slug)) $c");
    if ( ! $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}nsh_request_types") ) { nsh_seed_rtypes(); }
    if ( ! $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}nsh_internal_statuses") ) { nsh_seed_internal_statuses(); }
    if ( ! $wpdb->get_var("SELECT COUNT(*) FROM {$wpdb->prefix}nsh_services") ) { nsh_seed_services_and_fields(); }
}

/* ============================================================
   SERVICE CATALOG — ported from Services2NRI (50 real-world NRI
   service types across 8 categories, each with its own dynamic
   field set). Bundled as includes/data/services-seed.json and
   imported once on first activation; fully editable afterwards
   from the admin dashboard's Services / Fields tabs.
   ============================================================ */

function nsh_service_categories() {
    static $cats = null;
    if ( $cats === null ) {
        $cats = array();
        $data = nsh_load_services_seed();
        foreach ( ( $data['categories'] ?? array() ) as $c ) {
            $cats[ $c['slug'] ] = $c;
        }
    }
    return $cats;
}

function nsh_load_services_seed() {
    static $data = null;
    if ( $data === null ) {
        $path = NSH_DIR . 'includes/data/services-seed.json';
        $json = file_exists( $path ) ? file_get_contents( $path ) : '';
        $data = $json ? json_decode( $json, true ) : array();
        if ( ! is_array( $data ) ) { $data = array( 'categories' => array(), 'services' => array() ); }
    }
    return $data;
}

function nsh_seed_services_and_fields() {
    global $wpdb;
    $data = nsh_load_services_seed();
    $st   = $wpdb->prefix . 'nsh_services';
    $ft   = $wpdb->prefix . 'nsh_fields';

    $sort = 0;
    foreach ( ( $data['services'] ?? array() ) as $svc ) {
        $sort++;
        $existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$st} WHERE slug=%s", $svc['slug'] ) );
        if ( $existing ) { continue; }

        $wpdb->insert( $st, array(
            'category'        => sanitize_key( $svc['category'] ),
            'slug'             => sanitize_title( $svc['slug'] ),
            'name'             => sanitize_text_field( $svc['name'] ),
            'short_desc'       => sanitize_text_field( $svc['short_desc'] ),
            'pricing_model'    => sanitize_key( $svc['pricing_model'] ?: 'quote' ),
            'base_price'       => $svc['base_price'] !== null ? floatval( $svc['base_price'] ) : null,
            'turnaround_days'  => intval( $svc['turnaround_days'] ?: 7 ),
            'required_docs'    => wp_json_encode( $svc['required_docs'] ?: array() ),
            'is_active'        => 1,
            'sort_order'       => $sort,
        ) );
        $service_id = (int) $wpdb->insert_id;
        if ( ! $service_id ) { continue; }

        foreach ( ( $svc['fields'] ?? array() ) as $f ) {
            // Newline-joined, not comma-joined — see nsh_parse_field_options()
            // (helpers.php) for why: this domain's option text routinely
            // contains a literal comma ("Under ₹2,000"), which a comma-joined
            // column can't tell apart from the separator between options.
            $opts = ( is_array( $f['options'] ?? null ) && $f['options'] ) ? implode( "\n", $f['options'] ) : '';
            $wpdb->insert( $ft, array(
                'field_key'        => sanitize_key( $f['field_key'] ),
                'service_id'       => $service_id,
                'field_label'      => sanitize_text_field( $f['label'] ),
                'field_type'       => sanitize_key( $f['field_type'] ?: 'text' ),
                'field_options'    => $opts,
                'placeholder'      => sanitize_text_field( $f['placeholder'] ?? '' ),
                'description'      => sanitize_textarea_field( $f['help_text'] ?? '' ),
                'is_required'      => ! empty( $f['required'] ) ? 1 : 0,
                'sort_order'       => intval( $f['sort_order'] ?? 0 ),
                'is_active'        => 1,
                'step_number'      => intval( $f['step'] ?? 1 ),
                'conditions'       => ! empty( $f['conditions'] ) ? wp_json_encode( $f['conditions'] ) : null,
                'score_weight'     => intval( $f['score_weight'] ?? 0 ),
                'eligibility_rule' => ! empty( $f['eligibility_rule'] ) ? wp_json_encode( $f['eligibility_rule'] ) : null,
            ) );
        }
    }
}

function nsh_get_services( $active = true ) {
    global $wpdb;
    $w = $active ? 'WHERE is_active=1' : '';
    return $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}nsh_services $w ORDER BY category ASC, sort_order ASC, name ASC" );
}

function nsh_get_service( $id_or_slug ) {
    global $wpdb;
    $t = $wpdb->prefix . 'nsh_services';
    if ( is_numeric( $id_or_slug ) ) {
        return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE id=%d", intval( $id_or_slug ) ) );
    }
    return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$t} WHERE slug=%s", sanitize_title( $id_or_slug ) ) );
}

/**
 * Fields for one service, grouped by their step number (ascending).
 * Returns array( step_number => array( label, fields => array(field_row,...) ) ).
 * Step labels: consecutive positions get friendly generic names; the
 * conventional "contact info" (98) and "documents" (99) steps ported from
 * Services2NRI are always rendered last, in that order, regardless of how
 * many content steps a given service has.
 */
function nsh_get_service_steps( $service_id ) {
    global $wpdb;
    $fields = $wpdb->get_results( $wpdb->prepare(
        "SELECT * FROM {$wpdb->prefix}nsh_fields WHERE service_id=%d AND is_active=1 ORDER BY step_number ASC, sort_order ASC",
        intval( $service_id )
    ) );
    $steps = array();
    foreach ( $fields as $f ) {
        $steps[ (int) $f->step_number ][] = $f;
    }
    ksort( $steps );
    $labels = array();
    $pos    = 0;
    foreach ( array_keys( $steps ) as $sn ) {
        if ( $sn === 98 ) { $labels[ $sn ] = 'Contact Details'; continue; }
        if ( $sn === 99 ) { $labels[ $sn ] = 'Documents';        continue; }
        $pos++;
        $labels[ $sn ] = 'Step ' . $pos;
    }
    $out = array();
    foreach ( $steps as $sn => $rows ) {
        $out[ $sn ] = array( 'label' => $labels[ $sn ], 'fields' => $rows );
    }
    return $out;
}

// Default 21-stage internal pipeline, in recommended end-to-end workflow
// order (Inquiry → ... → Service Not Required Any More). Shared by both
// the fresh-activation path above and the upgrade-path migration in
// includes/migrations.php, so the two never drift apart.
function nsh_internal_status_default_rows() {
    return array(
        array( 'Inquiry',                                    '#64748b' ),
        array( 'Need to Work on Query',                       '#0ea5e9' ),
        array( 'High Quality Prospect',                       '#2563eb' ),
        array( 'Follow Up',                                   '#7c3aed' ),
        array( 'Under Review – For Feasibility Check',        '#8b5cf6' ),
        array( 'Feasibility Check Required',                  '#a855f7' ),
        array( 'Awaiting Client Decision – Pending',           '#d946ef' ),
        array( 'Quotation to be Sent',                         '#f59e0b' ),
        array( 'Quotation Sent',                               '#f97316' ),
        array( 'Waiting for Docs',                             '#eab308' ),
        array( 'Documents Received',                           '#84cc16' ),
        array( 'Payment Received',                             '#22c55e' ),
        array( 'PMT RECVD – Work Not Started',                 '#14b8a6' ),
        array( 'Assigned and In Progress',                     '#06b6d4' ),
        array( 'Work Completed',                               '#10b981' ),
        array( 'Delivered',                                    '#059669' ),
        array( 'No Response',                                  '#94a3b8' ),
        array( 'High Charges – Lost',                          '#ef4444' ),
        array( 'Late Response – Lost',                         '#dc2626' ),
        array( 'Not Able to Serve',                            '#b91c1c' ),
        array( 'Service Not Required Any More',                '#78716c' ),
    );
}

function nsh_seed_internal_statuses() {
    global $wpdb; $t = $wpdb->prefix . 'nsh_internal_statuses';
    foreach ( nsh_internal_status_default_rows() as $i => $row ) {
        list( $label, $color ) = $row;
        $slug = nsh_generate_internal_status_slug( $label );
        $wpdb->insert( $t, array(
            'slug'       => $slug,
            'label'      => $label,
            'color'      => $color,
            'sort_order' => ( $i + 1 ) * 10,
            'is_active'  => 1,
        ) );
    }
}

// nsh_request_types is used only to categorize free-standing support
// tickets (nsh_submit_support / the Support tab) — separate from the
// nsh_services catalog, which drives the actual request form.
function nsh_seed_rtypes() {
    global $wpdb; $t=$wpdb->prefix.'nsh_request_types';
    foreach(array('Document Query','Payment Query','Delivery / Courier Issue','Account / Login Issue','General Enquiry','Other') as $i=>$n) { $wpdb->insert($t,array('name'=>$n,'icon'=>'','sort_order'=>$i+1,'is_active'=>1)); }
}

function nsh_get_fields($active=true, $service_id=null) {
    global $wpdb;
    $where = array();
    if ($active) { $where[] = 'is_active=1'; }
    if ($service_id !== null) { $where[] = $wpdb->prepare('service_id=%d', intval($service_id)); }
    $w = $where ? ('WHERE ' . implode(' AND ', $where)) : '';
    return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}nsh_fields $w ORDER BY step_number ASC, sort_order ASC");
}

function nsh_get_dropdown_options($key,$search='') {
    global $wpdb; $key=sanitize_key($key);
    if($search) return $wpdb->get_col($wpdb->prepare("SELECT option_value FROM {$wpdb->prefix}nsh_dropdown_options WHERE field_key=%s AND option_value LIKE %s ORDER BY sort_order ASC LIMIT 300",$key,'%'.$wpdb->esc_like($search).'%'));
    return $wpdb->get_col($wpdb->prepare("SELECT option_value FROM {$wpdb->prefix}nsh_dropdown_options WHERE field_key=%s ORDER BY sort_order ASC LIMIT 300",$key));
}

function nsh_get_request_types($active=true) { global $wpdb; $w=$active?'WHERE is_active=1':''; return $wpdb->get_results("SELECT * FROM {$wpdb->prefix}nsh_request_types $w ORDER BY sort_order ASC"); }
function nsh_get_tickets($rid) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT * FROM {$wpdb->prefix}nsh_tickets WHERE request_id=%d ORDER BY created_at DESC",intval($rid))); }
function nsh_get_messages($rid) { global $wpdb; return $wpdb->get_results($wpdb->prepare("SELECT m.*,u.display_name,u.user_email FROM {$wpdb->prefix}nsh_messages m LEFT JOIN {$wpdb->prefix}users u ON m.sender_id=u.ID WHERE m.request_id=%d ORDER BY m.created_at ASC",intval($rid))); }
