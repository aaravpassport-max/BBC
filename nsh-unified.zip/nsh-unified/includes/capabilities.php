<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function nsh_is_staff() {
    return is_user_logged_in() && (current_user_can('administrator')||current_user_can('nsh_admin')||current_user_can('nsh_manager'));
}
function nsh_check_nonce() {
    $n = sanitize_text_field(isset($_POST['nonce'])?$_POST['nonce']:'');
    if ( nsh_verify_nonce_current_or_anon( $n ) ) return true;
    wp_send_json_error(array('message'=>'Security check failed. Please refresh and try again.'),403);
    exit;
}

/* A WordPress nonce is salted with the CURRENT user id at verification
   time, not just the id that was logged in when it was generated. That
   collided with the background-document-upload architecture: an
   anonymous visitor's browser holds one nonce (generated for uid=0) for
   the whole page, and nsh_ajax_create_request() logs that same browser
   into a brand-new (or existing) client account — via wp_set_auth_cookie()
   — the moment Submit succeeds. Any OTHER request that was already
   queued in the browser at that exact moment (most realistically: a
   background document upload still waiting its turn behind other
   in-flight requests on a slow/constrained connection) can end up being
   physically dispatched AFTER that identity switch, so it arrives at the
   server carrying the NEW logged-in cookies while still presenting the
   OLD (pre-login) nonce value — a nonce that verifies fine against uid=0
   but not against the now-current user, and vice versa. That showed up
   as a same-request "Security check failed" 403 on an upload that was
   otherwise entirely legitimate, for a document that had already fully
   transferred and just needed its nonce accepted.
   Trying the verification a second time as the logged-out visitor (uid 0)
   closes that gap without weakening anything: real authorization for
   these background-upload endpoints is already enforced separately, by
   matching the random per-form upload token / per-attachment ownership
   (see nsh_ajax_upload_pending_document(), nsh_ajax_attach_pending_document(),
   nsh_ajax_delete_pending_document() in ajax.php) — this nonce is anti-
   CSRF/replay hardening on top of that, and it should accept either
   identity a single physical browser session could plausibly have held
   for the SAME already-issued nonce value. */
function nsh_verify_nonce_current_or_anon( $n ) {
    $actions = array( 'nsh_admin_nonce', 'nsh_frontend_nonce', 'nsh_upload_nonce', 'nsh_login_nonce' );
    foreach ( $actions as $action ) {
        if ( wp_verify_nonce( $n, $action ) ) return true;
    }
    // wp_verify_nonce() is not just salted by the current user id — it
    // also mixes in wp_get_session_token(), which reads the 'logged_in'
    // auth cookie directly off the request, completely independent of
    // wp_set_current_user(). So a plain wp_set_current_user(0) retry
    // does NOT reproduce the original anonymous computation once this
    // request is carrying real login cookies (see the docblock above):
    // wp_get_session_token() would still return that logged-in session's
    // token, not the empty string an anonymous visitor's nonce was
    // actually generated with. The only way to correctly check "does
    // this nonce match what an anonymous visitor (uid 0, no session
    // token) would have been issued" is to reproduce wp_verify_nonce()'s
    // own hash construction by hand with uid=0 and token='' explicitly,
    // rather than trying to fake that state through the current-user API.
    if ( is_user_logged_in() && function_exists( 'wp_nonce_tick' ) ) {
        foreach ( $actions as $action ) {
            $i = wp_nonce_tick( $action );
            $expected = substr( wp_hash( $i . '|' . $action . '|0|', 'nonce' ), -12, 10 );
            if ( hash_equals( $expected, $n ) ) return true;
            $expected_prev = substr( wp_hash( ( $i - 1 ) . '|' . $action . '|0|', 'nonce' ), -12, 10 );
            if ( hash_equals( $expected_prev, $n ) ) return true;
        }
    }
    return false;
}
function nsh_require_staff() {
    if (!nsh_is_staff()) { wp_send_json_error(array('message'=>'Permission denied.'),403); exit; }
}
// Stricter gate for Internal Status *management* (add/edit/reorder/
// activate/delete a status definition) — separate from just assigning an
// existing status to a request, which any staff member (nsh_is_staff())
// can do. Matches the "authorized administrators" wording in the feature
// spec and the manage_options gate already used for the migration
// rollback in migrations.php.
function nsh_is_admin_user() {
    return is_user_logged_in() && current_user_can( 'manage_options' );
}
function nsh_require_admin() {
    if ( ! nsh_is_admin_user() ) { wp_send_json_error( array( 'message' => 'Administrator access required.' ), 403 ); exit; }
}
function nsh_is_own_request($rid) {
    if (!is_user_logged_in()) return false;
    if (nsh_is_staff()) return true;
    $p=get_post($rid);
    return $p && $p->post_type==='nsh_request' && (int)$p->post_author===get_current_user_id();
}

/**
 * Clients must never see the WordPress black admin toolbar or any of its
 * items (Profile, Logout, Dashboard, the site-name menu, ...) — the plugin
 * already has its own equivalent, purpose-built UI for exactly that
 * (nsh_client_nav()'s Dashboard/New Request/Profile/Logout bar, plus the
 * full account/password-change form in nsh_render_profile_tab()), so the
 * WP toolbar showing on top of it is redundant at best and, worse, exposes
 * a route into the WordPress backend a client was never meant to see.
 *
 * This uses WordPress's own show_admin_bar() switch rather than hiding
 * #wpadminbar with CSS: returning false here stops is_admin_bar_showing()
 * from being true at all, which means wp_admin_bar_render() never runs
 * (no toolbar markup is even output), the 'admin-bar' class never gets
 * added to <body> (so there's no leftover top-padding gap where it used
 * to sit either), and its own CSS/JS never gets enqueued. That's the
 * difference between "hidden" and "not there" — CSS-hiding individual
 * items (or the whole bar) still ships all of that to the browser and
 * leaves it one stylesheet/inspector tweak away from reappearing; this
 * way it is genuinely never rendered for a client in the first place.
 *
 * Scope: any LOGGED-IN user who isn't staff (nsh_is_staff() — admins,
 * nsh_admin, nsh_manager) has it removed everywhere on the front end, not
 * just on the plugin's own pages — a client browsing anywhere else on the
 * site while logged in shouldn't see it either. A logged-out visitor
 * already gets no admin bar by default, so this only ever narrows what's
 * shown, never widens it; staff keep their normal WordPress admin bar
 * completely untouched, including on every NSH-rendered page.
 */
add_filter( 'show_admin_bar', 'nsh_hide_admin_bar_for_clients' );
function nsh_hide_admin_bar_for_clients( $show ) {
    if ( is_user_logged_in() && ! nsh_is_staff() ) {
        return false;
    }
    return $show;
}
