<?php
if (!defined('ABSPATH')) exit;

// ── NSH Fast Attachment Metadata ────────────────────────────────────────────
// ROOT CAUSE of the reported "document upload takes quite longer than
// expected": nsh_ajax_create_request() used to call WordPress core's
// wp_generate_attachment_metadata() on every uploaded document, synchronously,
// one file at a time, before it could send the success response back to the
// browser. For an image (JPEG/PNG) that function doesn't just read the
// file's dimensions — it also renders and writes out every registered
// intermediate size (thumbnail, medium, medium_large, large, plus any sizes
// a theme/other plugin registers), each a separate GD/Imagick resize+encode
// pass. For a PDF, WordPress additionally tries to render a page-1 preview
// image via Imagick/Ghostscript, which is slower still and sometimes takes
// several seconds on its own. A service can require 2-5 documents in one
// submission, so this multiplied straight into the multi-second delay being
// reported — and it was all being paid for on every single request no
// matter what, even though NOTHING in this plugin ever uses those generated
// sizes: every place a document is shown or downloaded (admin dashboard,
// client dashboard, the ZIP/download endpoints — see nsh_get_download_url()/
// wp_get_attachment_url() call sites) links straight to the original
// uploaded file, never an intermediate size or the PDF preview image.
//
// The fix: generate only what's actually needed. For an image, the
// intermediate_image_sizes_advanced filter is used to tell WordPress not to
// render any extra crops for just this one call (still records the file's
// own width/height, which is free/instant to read) — full visual fidelity
// is unaffected since the original file is what's always served. For a PDF
// (or any other non-image document), the expensive preview-image step is
// skipped entirely; a minimal metadata array pointing at the file is stored
// instead of leaving the attachment's metadata empty, which keeps every
// core/plugin function that expects `_wp_attachment_metadata` to exist
// (e.g. get_attached_file() callers, media library listings) working
// normally. Net effect: the same files end up stored and downloadable
// exactly as before, just without the synchronous work nothing consumes.
function nsh_generate_minimal_attachment_metadata( int $att_id, string $file_path, string $mime_type ) {
    if ( strpos( $mime_type, 'image/' ) === 0 ) {
        // Skip every registered thumbnail/medium/large crop for this one
        // upload only — the filter is added and removed around this single
        // call so it never affects unrelated media library uploads (e.g. a
        // staff member uploading a real image elsewhere in wp-admin).
        $skip_sizes = function () { return array(); };
        add_filter( 'intermediate_image_sizes_advanced', $skip_sizes );
        $att_data = wp_generate_attachment_metadata( $att_id, $file_path );
        remove_filter( 'intermediate_image_sizes_advanced', $skip_sizes );
        wp_update_attachment_metadata( $att_id, $att_data );
        return;
    }

    // Non-image (PDF, etc.) — skip wp_generate_attachment_metadata()
    // entirely; for a PDF that call is what triggers the slow page-preview
    // render, and nothing here ever displays or needs it. Store the minimal
    // metadata WordPress core itself falls back to for non-image mimes it
    // has no special handling for, so the attachment record still behaves
    // normally everywhere else.
    $uploads = wp_get_upload_dir();
    $rel     = ( ! empty( $uploads['basedir'] ) && strpos( $file_path, $uploads['basedir'] ) === 0 )
        ? ltrim( substr( $file_path, strlen( $uploads['basedir'] ) ), '/' )
        : basename( $file_path );
    wp_update_attachment_metadata( $att_id, array(
        'file'    => $rel,
        'filesize'=> file_exists( $file_path ) ? filesize( $file_path ) : 0,
    ) );
}

// ── NSH Document Sanitiser ─────────────────────────────────────────────────
// Called after every document upload to ensure the stored file is always
// PDF, JPG, or PNG. If another plugin (image optimizer) converted the file
// to AVIF or WebP, this function converts it back to PNG and updates the
// WordPress attachment record so downloads always work correctly.
function nsh_sanitise_attachment( int $att_id ): void {
    if ( ! $att_id ) return;

    $file_path = get_attached_file( $att_id );
    if ( ! $file_path || ! file_exists( $file_path ) ) return;

    $finfo     = new finfo( FILEINFO_MIME_TYPE );
    $mime_real = $finfo->file( $file_path );

    // Already a safe format — nothing to do
    if ( in_array( $mime_real, [ 'application/pdf', 'image/jpeg', 'image/png' ], true ) ) return;

    // Not AVIF or WebP — not our concern
    if ( ! in_array( $mime_real, [ 'image/avif', 'image/webp' ], true ) ) return;

    nsh_log( 'nsh_sanitise_attachment: ' . $mime_real . ' detected for att ' . $att_id . ' — converting to PNG' );

    // Build path for PNG replacement (same dir, same base name, .png extension)
    $dir      = dirname( $file_path );
    $basename = preg_replace( '/\.[^.]+$/', '', basename( $file_path ) );
    // Also strip compound extensions like "doc.jpg" → "doc" from "doc.jpg.avif"
    $basename = preg_replace( '/\.(jpg|jpeg|png|webp|avif)$/i', '', $basename );
    $png_path = $dir . DIRECTORY_SEPARATOR . $basename . '.png';

    $converted = false;

    // Try Imagick
    if ( extension_loaded( 'imagick' ) ) {
        try {
            $im = new Imagick( $file_path );
            // Flatten transparency onto white background
            if ( $im->getImageAlphaChannel() ) {
                $bg = new Imagick();
                $bg->newImage( $im->getImageWidth(), $im->getImageHeight(), new ImagickPixel( 'white' ) );
                $bg->compositeImage( $im, Imagick::COMPOSITE_OVER, 0, 0 );
                $im = $bg;
            }
            $im->setImageFormat( 'png' );
            $im->setImageCompressionQuality( 95 );
            $im->writeImage( $png_path );
            $im->clear(); $im->destroy();
            if ( file_exists( $png_path ) && filesize( $png_path ) > 0 ) {
                $converted = true;
            }
        } catch ( Throwable $e ) {
            nsh_log( 'nsh_sanitise_attachment Imagick failed: ' . $e->getMessage() );
        }
    }

    // Try GD if Imagick failed
    if ( ! $converted ) {
        $img = null;
        if ( $mime_real === 'image/webp' && function_exists( 'imagecreatefromwebp' ) ) {
            $img = @imagecreatefromwebp( $file_path );
        } elseif ( $mime_real === 'image/avif' && function_exists( 'imagecreatefromavif' ) ) {
            $img = @imagecreatefromavif( $file_path );
        }
        if ( $img ) {
            $w   = imagesx( $img ); $h = imagesy( $img );
            $out = imagecreatetruecolor( $w, $h );
            imagefill( $out, 0, 0, imagecolorallocate( $out, 255, 255, 255 ) );
            imagecopy( $out, $img, 0, 0, 0, 0, $w, $h );
            if ( imagepng( $out, $png_path, 6 ) && file_exists( $png_path ) && filesize( $png_path ) > 0 ) {
                $converted = true;
            }
            imagedestroy( $img ); imagedestroy( $out );
        }
    }

    if ( ! $converted ) {
        nsh_log( 'nsh_sanitise_attachment: conversion failed for att ' . $att_id );
        return;
    }

    // Delete the AVIF/WebP file
    @unlink( $file_path );

    // Update WordPress attachment to point to the PNG
    update_attached_file( $att_id, $png_path );
    wp_update_post( [ 'ID' => $att_id, 'post_mime_type' => 'image/png' ] );

    // Regenerate metadata so WP knows about the new file
    $metadata = wp_generate_attachment_metadata( $att_id, $png_path );
    wp_update_attachment_metadata( $att_id, $metadata );

    nsh_log( 'nsh_sanitise_attachment: converted to PNG — ' . basename( $png_path ) );
}


// -----------------------------------------------------------
// AUTH — sign-in (nsh_login) and magic link (nsh_magic_link) live in platform/auth.php
// -----------------------------------------------------------
// -----------------------------------------------------------
// SEARCHABLE DROPDOWN
// -----------------------------------------------------------
add_action('wp_ajax_nopriv_nsh_search_dropdown', 'nsh_ajax_search_dropdown');
add_action('wp_ajax_nsh_search_dropdown',        'nsh_ajax_search_dropdown');
function nsh_ajax_search_dropdown() {
    $key    = sanitize_key(isset($_POST['field_key']) ? $_POST['field_key'] : '');
    $search = sanitize_text_field(isset($_POST['search']) ? $_POST['search'] : '');
    wp_send_json_success(array_values(nsh_get_dropdown_options($key, $search)));
}

// -----------------------------------------------------------
// LOAD ONE SERVICE'S WIZARD (guest + logged-in) — powers the
// service dropdown inside [nsh_standalone_form] (no service attr/param):
// instead of a grid of per-service "boxes" to click through, the visitor
// picks a service from a single <select> and this swaps the same compact
// card's body to that service's own steps/fields via nsh_render_service_wizard_html(),
// so every service uses the identical polished layout on one shortcode.
// -----------------------------------------------------------
add_action('wp_ajax_nopriv_nsh_load_service_wizard', 'nsh_ajax_load_service_wizard');
add_action('wp_ajax_nsh_load_service_wizard',        'nsh_ajax_load_service_wizard');
function nsh_ajax_load_service_wizard() {
    nsh_check_nonce();
    $service_id = intval( isset( $_POST['service_id'] ) ? $_POST['service_id'] : 0 );
    $service    = $service_id ? nsh_get_service( $service_id ) : null;
    if ( $service_id && ( ! $service || ! (int) $service->is_active ) ) {
        wp_send_json_error( array( 'message' => 'Please choose a valid service.' ) );
    }
    $sl_mode    = isset( $_POST['sl_mode'] ) ? ! empty( $_POST['sl_mode'] ) : true;
    // Set only when the swap originated inside [nsh_standalone_form]'s
    // container (see its data-standalone="1" marker and the matching
    // nshApplyWizardSwap()/prefetch calls in nsh-app.js) — keeps every
    // service the visitor switches to rendered in the same one-field-
    // per-row, placeholder-only design as the card's initial Step 1,
    // instead of silently reverting to the labeled/two-column layout
    // the moment a service is picked.
    $standalone = ! empty( $_POST['standalone'] );

    if ( ! $service ) {
        // service_id=0 (or absent) is a valid "reset to picker" state, not
        // an error — the swapped-in HTML still renders as a proper Step 1
        // wizard shell (step-dots strip + service-select field), never a
        // bare placeholder outside any step structure.
        wp_send_json_success( array(
            'html'  => nsh_render_service_picker_shell_html( null, $sl_mode, $standalone ),
            'title' => 'Get Estimated Quote Instantly',
            'slug'  => '',
        ) );
    }

    $html = nsh_render_service_wizard_html( $service, $sl_mode ? 'nsh-sl-wizard-wrap' : 'nsh-wizard-wrap', array(
        'submit_label'       => $sl_mode ? '⚡ Calculate My Quote' : 'Submit Request',
        'submit_loading'     => $sl_mode ? 'Submitting…' : 'Submitting...',
        'sl_mode'            => $sl_mode,
        'standalone'         => $standalone,
        'service_field_html' => nsh_render_service_select_field_html( $service, $standalone ),
    ) );
    wp_send_json_success( array(
        'html'  => $html,
        'title' => $service->name,
        'slug'  => $service->slug,
    ) );
}

/**
 * Returns every active service's fully rendered wizard HTML in one call, so
 * the Services field can behave like a real, instant form control instead
 * of a "loader" that fetches a new form over the network on every change.
 * nsh-app.js calls this once in the background right after the page loads
 * and caches the result; picking a service from #nsh-sl-service-select
 * then swaps in cached HTML synchronously — no request in flight, no
 * "Loading form…" placeholder, no visible fetch-then-jump. (A same-request
 * AJAX fallback via nsh_ajax_load_service_wizard() above still exists for
 * the rare case a pick happens before the prefetch has finished.)
 */
add_action('wp_ajax_nopriv_nsh_prefetch_all_wizards', 'nsh_ajax_prefetch_all_wizards');
add_action('wp_ajax_nsh_prefetch_all_wizards',        'nsh_ajax_prefetch_all_wizards');
function nsh_ajax_prefetch_all_wizards() {
    nsh_check_nonce();
    $sl_mode    = isset( $_POST['sl_mode'] ) ? ! empty( $_POST['sl_mode'] ) : true;
    // See the matching comment in nsh_ajax_load_service_wizard() above —
    // same reasoning, just for the bulk prefetch-cache path.
    $standalone = ! empty( $_POST['standalone'] );
    $services = nsh_get_services( true );
    $map      = array();
    foreach ( $services as $service ) {
        $html = nsh_render_service_wizard_html( $service, $sl_mode ? 'nsh-sl-wizard-wrap' : 'nsh-wizard-wrap', array(
            'submit_label'       => $sl_mode ? '⚡ Calculate My Quote' : 'Submit Request',
            'submit_loading'     => $sl_mode ? 'Submitting…' : 'Submitting...',
            'sl_mode'            => $sl_mode,
            'standalone'         => $standalone,
            'service_field_html' => nsh_render_service_select_field_html( $service, $standalone ),
        ) );
        $map[ intval( $service->id ) ] = array(
            'html'  => $html,
            'title' => $service->name,
            'slug'  => $service->slug,
        );
    }
    wp_send_json_success( array(
        'services' => $map,
        'picker'   => array(
            'html'  => nsh_render_service_picker_shell_html( null, $sl_mode, $standalone ),
            'title' => 'Get Estimated Quote Instantly',
            'slug'  => '',
        ),
    ) );
}

// -----------------------------------------------------------
// CREATE REQUEST (guest + logged-in)
// -----------------------------------------------------------
add_action('wp_ajax_nopriv_nsh_create_request', 'nsh_ajax_create_request');
add_action('wp_ajax_nsh_create_request',        'nsh_ajax_create_request');
function nsh_ajax_create_request() {
    // Nonce check - allows both frontend and admin nonces
    nsh_check_nonce();

    // ── Idempotency guard ────────────────────────────────────────────────
    // ROOT CAUSE of "the form shows an error even though it was actually
    // submitted": documents used to travel as raw file bytes in THIS same
    // call, so a large/slow upload could push total request time past a
    // shared host's reverse-proxy/gateway timeout even though PHP itself
    // (see set_time_limit(180) below) kept running to completion — the
    // server would finish creating the request, but the response never
    // made it back to the browser. nshUploadWithRetry() in nsh-app.js
    // treats that (xhr.status===0 / a timeout) as a network failure and
    // automatically retries the SAME call — which, without this guard,
    // would silently create a SECOND, duplicate nsh_request post for one
    // submission, and still might not "look" successful to the visitor if
    // the retry also runs long. submit_token is a random value the browser
    // generates once per Submit click and keeps identical across its own
    // automatic retries; the first successful run for a given token caches
    // its exact success response below, BEFORE doing any slow follow-up
    // work (the synchronous admin email in particular), so any retry after
    // that point returns the cached result instantly instead of
    // re-creating anything or re-sending anything.
    $submit_token = sanitize_text_field( isset( $_POST['submit_token'] ) ? $_POST['submit_token'] : '' );
    if ( $submit_token !== '' ) {
        $cached = get_transient( 'nsh_submit_' . md5( $submit_token ) );
        if ( is_array( $cached ) && ! empty( $cached['request_id'] ) ) {
            wp_send_json_success( $cached );
        }
    }

    // ── Per-FORM duplicate-submission guard ──────────────────────────────
    // submit_token above is regenerated on every Submit CLICK, so two quick
    // clicks / a double-tap / a second tab replaying the form carry two
    // DIFFERENT tokens and used to create two requests. nsh_upload_token
    // is generated once per form instance (nshEnsureUploadToken() in
    // nsh-app.js), so it identifies "this form" across clicks: (1) once a
    // request exists for it, any repeat returns that same request; (2)
    // while one submission is still running, a concurrent one is refused.
    $form_token = sanitize_text_field( isset( $_POST['nsh_upload_token'] ) ? $_POST['nsh_upload_token'] : '' );
    $form_cache_key = '';
    $form_lock_key  = '';
    if ( $form_token !== '' ) {
        $form_cache_key = 'nsh_form_' . md5( $form_token );
        $cached_form = get_transient( $form_cache_key );
        if ( is_array( $cached_form ) && ! empty( $cached_form['request_id'] ) ) {
            wp_send_json_success( $cached_form );
        }
        $form_lock_key = 'nsh_lock_' . md5( $form_token );
        // add_option() fails if the row exists, which makes it an atomic
        // test-and-set even without a persistent object cache.
        if ( ! add_option( $form_lock_key, time(), '', 'no' ) ) {
            if ( time() - (int) get_option( $form_lock_key ) > 120 ) {
                update_option( $form_lock_key, time(), false ); // stale lock from a crashed run
            } else {
                wp_send_json_error( array( 'message' => 'Your submission is already being processed. Please wait a moment — do not press Submit again.', 'code' => 'duplicate_in_progress' ) );
            }
        }
        // Always release, on success AND on every validation-error exit
        // (wp_send_json_* ends the request), so a corrected retry is never
        // blocked by our own lock.
        register_shutdown_function( function () use ( $form_lock_key ) { delete_option( $form_lock_key ); } );
    }

    // Multiple document uploads + per-file thumbnail generation
    // (wp_generate_attachment_metadata) can legitimately take longer than
    // a shared host's default 30s execution budget, especially when
    // several files arrive back-to-back on a slow mobile upload. A PHP
    // timeout here looks identical to a "connection error" on the client
    // (the connection is simply cut), so give this request more room.
    // Best-effort only — disabled on hosts that block runtime overrides.
    if ( function_exists( 'set_time_limit' ) ) {
        @set_time_limit( 180 );
    }
    if ( function_exists( 'ini_set' ) ) {
        @ini_set( 'max_execution_time', 180 );
    }

    // Human-verification (CAPTCHA) — the actual security boundary is
    // here, server-side, NOT the client-side JS check in nsh-app.js (that
    // one is only a UX nicety that fails silently for any bot that skips
    // running the page's JS and POSTs straight to admin-ajax.php).
    // nsh_captcha_verify() dispatches to whichever provider is active in
    // Settings -> Bot Protection (built-in/self-hosted by default, or
    // Cloudflare Turnstile — see the "CAPTCHA / Bot Protection" docblock
    // in helpers.php). Scoped to anonymous/first-time submitters only:
    // the widget is only ever rendered on the public
    // [nsh_standalone_form] (never the Client Dashboard's own login-
    // gated "New Request" wizard), and this same is_user_logged_in()
    // check is how the rest of this function already distinguishes "a
    // new, anonymous visitor" from "an existing logged-in client re-
    // using the shared submit endpoint" (see the wp_create_user() call
    // further down). A logged-in client re-using this endpoint never
    // sees a widget to solve, so never gate them on one here either.
    if ( ! is_user_logged_in() ) {
        $remote_ip      = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( $_SERVER['REMOTE_ADDR'] ) : '';
        $captcha_result = nsh_captcha_verify( $_POST, $remote_ip );
        if ( is_wp_error( $captcha_result ) ) {
            wp_send_json_error( array( 'message' => $captcha_result->get_error_message(), 'code' => $captcha_result->get_error_code() ) );
        }
    }

    // client_email is a legacy dedicated input name from the original
    // 4-step wizard; the Services2NRI-derived per-service forms instead
    // collect email as an ordinary dynamic field with key "__email" (part
    // of every service's "Contact Details" step), submitted as
    // field___email. Accept either so both form styles keep working.
    $email = sanitize_email( isset( $_POST['client_email'] ) ? $_POST['client_email'] : ( isset( $_POST['field___email'] ) ? $_POST['field___email'] : '' ) );
    if (!is_email($email)) {
        wp_send_json_error(array('message' => 'A valid email address is required. Please go back and enter your email.'));
    }

    // Which service was this request submitted for? Every request now
    // belongs to exactly one nsh_services row (see includes/data/services-seed.json
    // and nsh_get_service_steps()) — required-field / required-document
    // validation below is scoped to THIS service's own fields only, not
    // every field of every service in the catalog.
    global $wpdb;
    $service_id = intval( isset( $_POST['service_id'] ) ? $_POST['service_id'] : 0 );
    $service    = $service_id ? nsh_get_service( $service_id ) : null;
    if ( ! $service ) {
        wp_send_json_error( array( 'message' => 'Please choose a service before submitting.' ) );
    }

    // Server-side: enforce required file uploads (scoped to this service).
    //
    // ROOT-CAUSE FIX: this used to set one shared $files_received flag to
    // true the moment ANY single required file field had a file attached
    // (the loop below `break`s on the first match), so a service with 3
    // required documents would pass validation with only 1 of them
    // actually uploaded — an "all or nothing" check standing in for what
    // should be a PER-FIELD check. Each required file field is now
    // verified individually against its OWN field_key, and every missing
    // one (not just the first) is collected so the error response can
    // name all of them at once — the client already does this per-field
    // check (see nsh-app.js), so this brings server-side validation back
    // in line with it instead of silently accepting an incomplete
    // submission the UI would have blocked.
    // Documents are no longer sent as raw file bytes in this call at all —
    // each file started uploading in the background the instant it was
    // selected (see nsh_ajax_upload_pending_document() below), so by
    // Submit time this request only knows how many files were SELECTED for
    // each field, via pending_manifest (a small JSON object the browser
    // builds from its own upload-tracking state, e.g. {"passport_copy":1}),
    // not whether those uploads have actually finished transferring yet —
    // that's the whole point: submission must not wait on slow uploads.
    $pending_manifest = array();
    if ( isset( $_POST['pending_manifest'] ) ) {
        $decoded_manifest = json_decode( wp_unslash( $_POST['pending_manifest'] ), true );
        if ( is_array( $decoded_manifest ) ) {
            foreach ( $decoded_manifest as $pm_key => $pm_count ) {
                $pending_manifest[ sanitize_key( $pm_key ) ] = max( 0, intval( $pm_count ) );
            }
        }
    }

    $required_file_fields = $wpdb->get_results( $wpdb->prepare(
        "SELECT field_key, field_label, conditions FROM {$wpdb->prefix}nsh_fields WHERE service_id=%d AND field_type='file' AND is_required=1 AND is_active=1",
        $service_id
    ) );
    if ( ! empty( $required_file_fields ) ) {
        $missing_doc_labels = array();
        foreach ( $required_file_fields as $rff ) {
            // A required file field can itself be conditional (show_if) —
            // mirror the same evaluation used for every other required
            // field below, so a document required only when a certain
            // answer was given isn't wrongly flagged as missing when that
            // condition doesn't apply.
            if ( ! nsh_field_conditions_met( $rff->conditions, $_POST ) ) { continue; }

            $has_own_file = ! empty( $pending_manifest[ $rff->field_key ] );

            if ( ! $has_own_file ) {
                $missing_doc_labels[] = $rff->field_label;
            }
        }

        if ( ! empty( $missing_doc_labels ) ) {
            $doc_message = ( count( $missing_doc_labels ) === 1 )
                ? sprintf( 'Please upload the required document "%s" before submitting.', $missing_doc_labels[0] )
                : sprintf( 'Please upload these required documents before submitting: %s.', implode( ', ', $missing_doc_labels ) );
            wp_send_json_error( array(
                'message'      => $doc_message,
                'missing_docs' => $missing_doc_labels,
            ) );
        }
    }

    // Server-side validation: enforce ALL required fields for THIS service.
    // Also fetch every ACTIVE field (not just required) so conditional
    // ("show_if") required fields can be evaluated correctly below — a
    // field flagged required is only actually required when its own
    // show_if condition (if any) is satisfied by what was submitted,
    // mirroring nshEvalConditions() in assets/js/nsh-app.js so client-side
    // and server-side validation never disagree.
    $service_fields_all = $wpdb->get_results( $wpdb->prepare(
        "SELECT field_key, field_label, field_type, is_required, conditions, score_weight, eligibility_rule FROM {$wpdb->prefix}nsh_fields WHERE service_id=%d AND is_active=1",
        $service_id
    ) );
    foreach ( $service_fields_all as $rf ) {
        if ( ! $rf->is_required ) { continue; }
        if ( $rf->field_type === 'file' ) { continue; } // already validated above

        if ( ! nsh_field_conditions_met( $rf->conditions, $_POST ) ) { continue; }

        $field_name = 'field_' . $rf->field_key;
        $value = isset( $_POST[ $field_name ] ) ? $_POST[ $field_name ] : '';

        // For all other types (text, select, textarea, radio, etc) — check not empty
        if ( empty( $value ) || ( is_string( $value ) && trim( $value ) === '' ) ) {
            wp_send_json_error( array(
                'message' => esc_html( $rf->field_label ) . ' is required. Please complete all required fields before submitting.'
            ) );
        }

        // Additional check for select fields — ensure not default "- Select -" option
        if ( $rf->field_type === 'dropdown' || $rf->field_type === 'select' || $rf->field_type === 'searchable' ) {
            if ( $value === '' || $value === '- Select -' ) {
                wp_send_json_error( array(
                    'message' => 'Please select a value for ' . esc_html( $rf->field_label ) . '.'
                ) );
            }
        }
    }

    // ── Account association ─────────────────────────────────────────────
    // SECURITY ROOT-CAUSE FIX: this block used to call
    // wp_set_auth_cookie() for WHATEVER account owned the typed email —
    // with no password — so any anonymous visitor could type an existing
    // client's (or an administrator's) email into the public form and be
    // signed in as that person. A session is now only ever issued for an
    // account THIS request just created. For an existing account the
    // request is still attached to it (so the real owner sees it after
    // they log in), but the visitor is not signed in.
    //   created              — brand-new client account, signed in now
    //   existing_logged_in   — visitor is already signed in as the owner
    //   existing_needs_login — account exists, visitor must log in
    //   staff_on_behalf      — signed-in staff filing for a client email
    $current_id     = get_current_user_id();
    $is_new         = false;
    $account_status = '';
    $welcome_sent   = null;
    if ( $current_id && ! nsh_is_staff() ) {
        // A signed-in client always files under their OWN account,
        // regardless of what email they typed into the form.
        $uid            = $current_id;
        $account_status = 'existing_logged_in';
    } else {
        $user = get_user_by( 'email', $email );
        if ( ! $user ) {
            $pw  = wp_generate_password( 12, false );
            $uid = wp_create_user( $email, $pw, $email );
            if ( is_wp_error( $uid ) ) { wp_send_json_error( array( 'message' => 'Could not create your account. Please try again or contact support.' ) ); }
            // Root cause of the generated description later showing "The
            // applicant" instead of a real name: the display name only
            // came from field_first_name; most services collect
            // field_applicant_name instead. Try each, once, at signup.
            $disp_first = sanitize_text_field( isset( $_POST['field_first_name'] ) ? $_POST['field_first_name'] : '' );
            $disp_last  = sanitize_text_field( isset( $_POST['field_last_name'] ) ? $_POST['field_last_name'] : '' );
            $disp = trim( $disp_first . ' ' . $disp_last );
            if ( $disp === '' ) { $disp = sanitize_text_field( isset( $_POST['field_applicant_name'] ) ? $_POST['field_applicant_name'] : '' ); }
            if ( $disp === '' ) { $disp = $email; }
            wp_update_user( array( 'ID' => $uid, 'display_name' => $disp ) );
            wp_update_user( array( 'ID' => $uid, 'role' => 'nsh_client' ) );
            $welcome_sent = nsh_send_welcome_email( $email, $pw );
            $is_new = true;
            wp_set_auth_cookie( $uid, true );
            wp_set_current_user( $uid );
            $account_status = 'created';
        } else {
            $uid = $user->ID;
            if ( $current_id && (int) $current_id === (int) $uid ) {
                $account_status = 'existing_logged_in';
            } elseif ( $current_id ) {
                $account_status = 'staff_on_behalf';
            } else {
                $account_status = 'existing_needs_login';
            }
        }
    }

    $fd = array();
    foreach ($_POST as $k => $v) {
        if (strpos($k, 'field_') === 0) {
            $fd[sanitize_key($k)] = is_array($v) ? array_map('sanitize_text_field', $v) : sanitize_text_field($v);
        }
    }
    $post_id = wp_insert_post(array(
        'post_type'   => 'nsh_request',
        'post_status' => 'publish',
        'post_title'  => wp_trim_words($service->name, 8, '') . ' - ' . $email . ' - ' . date('Y-m-d'),
        'post_author' => $uid,
    ));
    if ( is_wp_error( $post_id ) || ! $post_id ) { wp_send_json_error( array( 'message' => 'We could not save your request. Please try again.' ) ); }

    // Server-side lead-qualification scoring (ported from Services2NRI's
    // BookingController::store — see nsh_compute_qualification()). Computed
    // from the raw $_POST here (before sanitizing into $fd) since it needs
    // the exact submitted values the score_weight/eligibility_rule rules
    // were written against.
    $qual = nsh_compute_qualification( $service_id, $_POST );

    $rid = nsh_generate_request_id();
    update_post_meta($post_id, 'request_id',     $rid);
    update_post_meta($post_id, 'status',         'submitted');
    update_post_meta($post_id, 'payment_status', 'pending');
    update_post_meta($post_id, 'field_data',     $fd);
    update_post_meta($post_id, 'service_id',     $service_id);
    update_post_meta($post_id, 'service_slug',   $service->slug);
    update_post_meta($post_id, 'service_name',   $service->name);
    update_post_meta($post_id, 'service_category', $service->category);
    update_post_meta($post_id, 'quote_status',   'none'); // none|pending|approved|rejected
    update_post_meta($post_id, 'qualification_score',  $qual['score']);
    update_post_meta($post_id, 'qualification_status', $qual['status']);
    if ( ! empty( $qual['warnings'] ) ) {
        update_post_meta( $post_id, 'qualification_warnings', $qual['warnings'] );
    }
    // A brand-new request should be findable immediately, not after the
    // search cache's TTL expires — see nsh_search_matching_request_ids().
    nsh_flush_request_search_cache();

    // Idempotency cache: from this point on, the request unambiguously
    // exists — cache the exact success response NOW, before any of the
    // slower work below (document association, description generation,
    // and especially the synchronous admin email further down) runs. If
    // the connection drops anywhere after this line and the browser
    // retries with the same submit_token, it gets this cached response
    // back instantly instead of a second nsh_request post being created.
    // See the matching docblock above nsh_check_nonce()'s call at the top
    // of this function.
    // Where "Okay, Go to Dashboard" should land: resolved from the real
    // published pages (nsh_page_url_for), by what this visitor can
    // actually open right now — not a hard-coded slug.
    if ( $account_status === 'staff_on_behalf' ) {
        $dest_url = nsh_admin_dashboard_url();
    } elseif ( $account_status === 'existing_needs_login' ) {
        $dest_url = nsh_login_page_url();
    } else {
        $dest_url = nsh_client_dashboard_url();
    }
    $success_payload = array(
        'redirect'        => $dest_url,
        'dashboard_url'   => $dest_url,
        'login_url'       => nsh_login_page_url(),
        'request_id'      => $rid,     // human-readable request code, for display
        'post_id'         => $post_id, // actual WP post ID — needed by nsh_ajax_attach_pending_document()
        'is_new'          => $is_new,
        'account_status'  => $account_status,
        'welcome_sent'    => $welcome_sent,
        'service_name'    => (string) $service->name,
        'email'           => $email,
        'submitted_on'    => wp_date( 'd M Y, h:i A' ),
        'turnaround_days' => isset( $service->turnaround_days ) ? intval( $service->turnaround_days ) : 0,
    );
    if ( $submit_token !== '' ) {
        set_transient( 'nsh_submit_' . md5( $submit_token ), $success_payload, HOUR_IN_SECONDS );
    }
    if ( $form_cache_key !== '' ) {
        set_transient( $form_cache_key, $success_payload, HOUR_IN_SECONDS );
    }

    // ── Associate documents uploaded in the background ─────────────────────
    // ROOT CAUSE FIX (see the "Investigate the actual cause" request this
    // whole rework addresses): documents used to arrive as raw file bytes
    // in THIS same call, which meant the final "Submit" request couldn't
    // finish until every attached document had fully uploaded AND been
    // processed (moved into place, thumbnailed, sanitised) — on a slow
    // mobile connection with a few MB of scanned documents, that easily
    // pushed total request time past a shared host's reverse-proxy/gateway
    // timeout (a different, shorter limit than PHP's own
    // max_execution_time override below), so the browser would see a
    // "connection error"/timeout even though the server went on to finish
    // the job successfully.
    //
    // Documents are now uploaded the instant they're SELECTED, independent
    // of Submit, to nsh_ajax_upload_pending_document() below — each file
    // becomes an orphan attachment (post_parent = 0) tagged with
    // $upload_token, which this form generates once per session and sends
    // as a normal (tiny) POST field here, never as file bytes. This makes
    // Submit itself fast regardless of how large or slow those uploads
    // are: any upload that has already finished by the time Submit is
    // clicked gets re-parented onto the new request right here; any upload
    // still in flight at this exact instant is picked up a few moments
    // later by nsh_ajax_attach_pending_document(), called by the browser
    // the moment THAT specific upload's own request finishes (see
    // nsh-app.js) — the request itself never waits for it.
    $upload_token = sanitize_text_field( isset( $_POST['nsh_upload_token'] ) ? $_POST['nsh_upload_token'] : '' );
    if ( $upload_token !== '' ) {
        update_post_meta( $post_id, '_nsh_upload_token', $upload_token );

        $pending_ids = get_posts( array(
            'post_type'      => 'attachment',
            'post_parent'    => 0,
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'meta_query'     => array(
                array( 'key' => '_nsh_pending_token', 'value' => $upload_token ),
            ),
        ) );

        if ( ! empty( $pending_ids ) ) {
            $documents = array();
            foreach ( $pending_ids as $att_id ) {
                $field_key = get_post_meta( $att_id, '_nsh_pending_field', true );
                $label     = get_post_meta( $att_id, '_nsh_pending_label', true );
                wp_update_post( array( 'ID' => $att_id, 'post_parent' => $post_id ) );
                delete_post_meta( $att_id, '_nsh_pending_token' );
                $documents[] = array(
                    'file'        => $att_id,
                    'field_key'   => $field_key ? $field_key : 'documents',
                    'doc_type'    => $label ? $label : 'Uploaded Document',
                    'is_provider' => 0,
                    'expiry'      => '',
                    'uploaded_at' => current_time( 'mysql' ),
                );
            }
            if ( ! empty( $documents ) ) {
                update_post_meta( $post_id, 'documents', $documents );
                nsh_add_history( $post_id, 'Documents uploaded', count( $documents ) . ' file(s) attached.' );
            }
        }
    }

    // Generate the initial Student Requirement Description from the
    // submitted fields (nsh_generate_requirement_description() in
    // helpers.php) — staff can edit or regenerate it later from the
    // request detail page (nsh_ajax_save_description /
    // nsh_ajax_regenerate_description below).
    $req_meta_for_desc = nsh_get_meta( $post_id );
    nsh_save_requirement_description( $post_id, nsh_generate_requirement_description( $post_id, $req_meta_for_desc ), false );

    nsh_add_history($post_id, 'Request submitted', $is_new ? 'New account created.' : ( $account_status === 'existing_needs_login' ? 'Filed against existing account; visitor was not signed in.' : '' ));

    // ── Admin notification: sent SYNCHRONOUSLY, not deferred ──────────────
    // Root cause this works around: on some hosts, mail sent from PHP code
    // that runs AFTER fastcgi_finish_request() (i.e. after the response has
    // already been flushed/closed back to the browser — see
    // nsh_defer_after_response() just below) is unreliable, even though
    // wp_mail()/mail() itself never reports an error and nsh_mail()'s own
    // logging shows nothing wrong. That post-response execution window is
    // the ONE structural difference between the admin "Send Test Admin
    // Notification" button (which calls nsh_mail() synchronously, mid
    // -request, and reliably arrives) and a real client submission (which
    // used to call it only from inside the deferred block below) — same
    // function, same recipient, same transport, different outcome, which
    // pointed straight at timing rather than another address/validation
    // bug. Moving the admin notification here, before the response is
    // sent, puts it in the exact same execution context as that working
    // test button. It costs the student a small delay (one mail round-trip)
    // before they see "Submitted" — worth it for the one notification that
    // actually has to reach a human reliably. Client confirmation + the
    // WhatsApp/CallMeBot calls stay deferred below: those are lower-stakes
    // (the client already sees an on-screen success state either way) and
    // WhatsApp's calls in particular are slow enough (up to 15s per staff
    // number) that they're worth keeping off the critical path.
    if ( function_exists( 'nsh_notify_new_request' ) ) {
        try {
            nsh_notify_new_request( $post_id );
        } catch ( \Throwable $e ) {
            // Never let a mail failure break the student's submission —
            // nsh_notify_new_request()/nsh_mail() already log their own
            // failure reason; this is only a last-resort net.
            if ( function_exists( 'nsh_log' ) ) {
                nsh_log( 'Synchronous admin notification threw for request ' . $post_id . ': ' . $e->getMessage() );
            }
        }
    }

    // Client confirmation + WhatsApp (CallMeBot) notifications are pure
    // side effects the student's browser doesn't need to wait for.
    // CallMeBot in particular is a third-party HTTP call with a 15s
    // timeout, made once per configured staff number (sequentially), so
    // with a few staff numbers configured this alone could add many extra
    // seconds to what the student sees as "submitting...". Defer both to
    // run AFTER the JSON response has already been sent to the browser
    // (nsh_defer_after_response() below), so submission still feels fast.
    nsh_defer_after_response( function() use ( $post_id ) {
        // Confirms receipt to the client themselves — previously missing
        // entirely (see nsh_notify_client_new_request()'s own docblock in
        // notifications.php).
        if ( function_exists( 'nsh_notify_client_new_request' ) ) {
            nsh_notify_client_new_request( $post_id );
        }
        if ( function_exists( 'nsh_wa_on_new_submission' ) ) {
            nsh_wa_on_new_submission( $post_id );
        }
    } );

    wp_send_json_success( $success_payload );
}

// TRACE: called from nsh_ajax_create_request() right before wp_send_json_success()
//        → registers a shutdown callback that (1) tries to flush/close the HTTP
//        connection back to the browser immediately (fastcgi_finish_request()
//        on PHP-FPM, else a manual ob_end_flush()+flush() best effort), then
//        (2) runs the given slow/non-critical work (email + WhatsApp calls)
//        → preconditions: must be called before any wp_die()/exit() in the
//        current request (wp_send_json_success() itself calls wp_die(), which
//        still triggers PHP's normal shutdown sequence, so registering here is
//        safe) → postconditions: the student's response is not delayed by
//        $work; $work still runs in the same request lifecycle, just after the
//        response bytes are handed off → edge cases handled: fastcgi_finish_request
//        missing (shared hosting without PHP-FPM) falls back to manual buffer
//        flushing; ignore_user_abort(true) so the student closing the tab
//        right after submit doesn't kill $work mid-flight; any throwable inside
//        $work is caught and logged so a notification failure can never surface
//        as a fatal error after the response has already gone out.
if ( ! function_exists( 'nsh_defer_after_response' ) ) {
    function nsh_defer_after_response( callable $work ) {
        register_shutdown_function( function() use ( $work ) {
            // Don't let the browser disconnecting (tab closed right after
            // submit) abort the background notification work.
            if ( function_exists( 'ignore_user_abort' ) ) {
                @ignore_user_abort( true );
            }

            // Best effort: hand the response back to the client now, before
            // doing any of the slow notification work, so the student's
            // "Submitting..." spinner clears as soon as WordPress has built
            // the response — not after CallMeBot/email round-trips.
            if ( function_exists( 'fastcgi_finish_request' ) ) {
                fastcgi_finish_request();
            } else {
                // Non-FPM fallback: flush whatever output buffers are open so
                // the already-written response is pushed to the client instead
                // of sitting in a PHP buffer until script end.
                if ( function_exists( 'session_write_close' ) && session_id() ) {
                    session_write_close();
                }
                while ( ob_get_level() > 0 ) {
                    @ob_end_flush();
                }
                @flush();
            }

            try {
                $work();
            } catch ( \Throwable $e ) {
                if ( function_exists( 'nsh_log' ) ) {
                    nsh_log( 'nsh_defer_after_response: deferred work failed — ' . $e->getMessage() );
                }
            }
        } );
    }
}

// -----------------------------------------------------------
// REQUEST TYPES
// -----------------------------------------------------------
add_action('wp_ajax_nopriv_nsh_get_request_types', 'nsh_ajax_get_request_types');
add_action('wp_ajax_nsh_get_request_types',        'nsh_ajax_get_request_types');
function nsh_ajax_get_request_types() {
    $types = nsh_get_request_types();
    $out   = array();
    foreach ($types as $t) {
        $out[] = array('id' => $t->id, 'name' => $t->name, 'icon' => $t->icon, 'description' => $t->description);
    }
    wp_send_json_success($out);
}

add_action('wp_ajax_nsh_save_request_type', 'nsh_ajax_save_request_type');
function nsh_ajax_save_request_type() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $tbl  = $wpdb->prefix . 'nsh_request_types';
    $name = sanitize_text_field(isset($_POST['name']) ? $_POST['name'] : '');
    $desc = sanitize_textarea_field(isset($_POST['description']) ? $_POST['description'] : '');
    $icon = sanitize_text_field(isset($_POST['icon']) ? $_POST['icon'] : '');
    $id   = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    if (!$name) wp_send_json_error(array('message' => 'Name required.'));
    if ($id) {
        $wpdb->update($tbl, array('name' => $name, 'description' => $desc, 'icon' => $icon), array('id' => $id));
    } else {
        $max = (int) $wpdb->get_var("SELECT MAX(sort_order) FROM $tbl") + 1;
        $wpdb->insert($tbl, array('name' => $name, 'description' => $desc, 'icon' => $icon, 'sort_order' => $max, 'is_active' => 1));
    }
    wp_send_json_success();
}

add_action('wp_ajax_nsh_delete_request_type', 'nsh_ajax_delete_request_type');
function nsh_ajax_delete_request_type() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $wpdb->delete($wpdb->prefix . 'nsh_request_types', array('id' => intval(isset($_POST['id']) ? $_POST['id'] : 0)));
    wp_send_json_success();
}

// -----------------------------------------------------------
// TICKETS
// -----------------------------------------------------------
add_action('wp_ajax_nopriv_nsh_submit_ticket', 'nsh_ajax_submit_ticket');
add_action('wp_ajax_nsh_submit_ticket',        'nsh_ajax_submit_ticket');
function nsh_ajax_submit_ticket() {
    nsh_check_nonce();
    $rid    = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    if ( $rid && ! nsh_is_own_request( $rid ) ) { $rid = 0; }
    $cat_id = intval(isset($_POST['type_id'])    ? $_POST['type_id']    : 0);
    $cat    = sanitize_text_field(isset($_POST['category']) ? $_POST['category'] : '');
    $notes  = sanitize_textarea_field(isset($_POST['notes']) ? $_POST['notes'] : '');
    $email  = sanitize_email(isset($_POST['email']) ? $_POST['email'] : '');

    // SECURITY FIX: same hole as nsh_ajax_create_request() had — an
    // anonymous visitor typing an existing account's email was signed in as
    // that account. Only a freshly created account gets a session now; an
    // existing one is just recorded as the ticket's owner.
    $ticket_uid = get_current_user_id();
    if (!is_user_logged_in() && is_email($email)) {
        $user = get_user_by('email', $email);
        if (!$user) {
            $pw  = wp_generate_password(12, false);
            $uid = wp_create_user($email, $pw, $email);
            if (!is_wp_error($uid)) {
                wp_update_user(array('ID' => $uid, 'role' => 'nsh_client'));
                nsh_send_welcome_email($email, $pw);
                wp_set_auth_cookie($uid, true);
                wp_set_current_user($uid);
                $ticket_uid = $uid;
            }
        } else {
            $ticket_uid = (int) $user->ID;
        }
    }

    global $wpdb;
    $wpdb->insert($wpdb->prefix . 'nsh_tickets', array(
        'request_id' => $rid,
        'user_id'    => $ticket_uid,
        'type_id'    => $cat_id,
        'category'   => $cat,
        'status'     => 'open',
        'notes'      => $notes,
    ));
    if ($rid) nsh_add_history($rid, 'Service request created: ' . $cat);
    wp_send_json_success(array('id' => $wpdb->insert_id, 'category' => $cat));
}

add_action('wp_ajax_nsh_delete_ticket', 'nsh_ajax_delete_ticket');
function nsh_ajax_delete_ticket() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $wpdb->delete($wpdb->prefix . 'nsh_tickets', array('id' => intval(isset($_POST['id']) ? $_POST['id'] : 0)));
    wp_send_json_success();
}

add_action('wp_ajax_nsh_update_ticket_status', 'nsh_ajax_update_ticket_status');
function nsh_ajax_update_ticket_status() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $wpdb->update(
        $wpdb->prefix . 'nsh_tickets',
        array('status' => sanitize_text_field(isset($_POST['status']) ? $_POST['status'] : 'open')),
        array('id'     => intval(isset($_POST['id']) ? $_POST['id'] : 0))
    );
    wp_send_json_success();
}

// -----------------------------------------------------------
// MESSAGES
// -----------------------------------------------------------
add_action('wp_ajax_nsh_send_message', 'nsh_ajax_send_message');
function nsh_ajax_send_message() {
    nsh_check_nonce();
    if (!is_user_logged_in()) wp_send_json_error(array('message' => 'Login required.'), 401);
    $rid        = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $msg        = sanitize_textarea_field(isset($_POST['message']) ? $_POST['message'] : '');
    $send_email = !empty($_POST['send_email']);
    if (!$msg) wp_send_json_error(array('message' => 'Message cannot be empty.'));
    if (!nsh_is_own_request($rid)) wp_send_json_error(array('message' => 'Access denied.'), 403);

    $sender   = wp_get_current_user();
    $is_staff = nsh_is_staff();

    global $wpdb;
    $wpdb->insert($wpdb->prefix . 'nsh_messages', array(
        'request_id'   => $rid,
        'sender_id'    => get_current_user_id(),
        'message'      => $msg,
        'is_email_sent'=> 0,
    ));
    $mid = $wpdb->insert_id;

    // Send email only when explicitly requested ("Send via Email" button)
    if ($send_email) {
        nsh_send_message_email($rid, $msg, $sender->display_name, $is_staff);
        $wpdb->update($wpdb->prefix . 'nsh_messages', array('is_email_sent' => 1), array('id' => $mid));
    }

    nsh_add_history($rid, 'Message sent by ' . $sender->display_name);
    wp_send_json_success(array(
        'id'           => $mid,
        'message'      => $msg,
        'time'         => current_time( 'd M Y, g:i a' ),
        'is_email_sent'=> $send_email ? 1 : 0,
        'sender_name'  => $sender->display_name,
        'sender_id'    => $sender->ID,
        'is_staff'     => $is_staff ? 1 : 0,
    ));
}

add_action('wp_ajax_nsh_delete_message', 'nsh_ajax_delete_message');
function nsh_ajax_delete_message() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $wpdb->delete($wpdb->prefix . 'nsh_messages', array('id' => intval(isset($_POST['id']) ? $_POST['id'] : 0)));
    wp_send_json_success();
}

// -----------------------------------------------------------
// DOCUMENT UPLOAD
// -----------------------------------------------------------
add_action('wp_ajax_nsh_upload_document', 'nsh_ajax_upload_doc');
function nsh_ajax_upload_doc() {
    nsh_check_nonce();
    $rid = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    if (!nsh_is_own_request($rid)) wp_send_json_error(array('message' => 'Access denied.'), 403);
    if (empty($_FILES['file'])) wp_send_json_error(array('message' => 'No file received.'));
    $file = $_FILES['file'];
    if ($file['size'] > 10 * 1024 * 1024) wp_send_json_error(array('message' => 'File exceeds 10MB.'));
    $allowed = array('application/pdf', 'image/jpeg', 'image/png');
    $finfo   = new finfo(FILEINFO_MIME_TYPE);
    $mime    = $finfo->file($file['tmp_name']);
    if (!in_array($mime, $allowed)) wp_send_json_error(array('message' => 'Only PDF/JPG/PNG allowed.'));
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';
    $att = media_handle_upload('file', $rid);
    if (is_wp_error($att)) wp_send_json_error(array('message' => 'Upload failed: ' . $att->get_error_message()));

    // Ensure document is stored as PDF/JPG/PNG, not AVIF/WebP
    nsh_sanitise_attachment( intval($att) );

    $doc_type    = sanitize_text_field(isset($_POST['doc_type']) ? $_POST['doc_type'] : 'Document');
    $is_provider = !empty($_POST['is_provider']) ? 1 : 0;
    $docs        = get_post_meta($rid, 'documents', true);
    if (!is_array($docs)) $docs = array();
    $docs[] = array('file' => $att, 'doc_type' => $doc_type, 'is_provider' => $is_provider, 'expiry' => '');
    update_post_meta($rid, 'documents', $docs);
    nsh_add_history($rid, 'Document uploaded: ' . $doc_type);
    $att_id  = intval($att);
    wp_send_json_success(array(
        'id'          => $att_id,
        'url'         => function_exists('nsh_get_download_url') ? nsh_get_download_url($att_id) : wp_get_attachment_url($att_id),
        'view_url'    => wp_get_attachment_url($att_id),
        'filename'    => basename(get_attached_file($att_id)),
        'doc_type'    => $doc_type,
        'is_provider' => $is_provider,
    ));
}

// -----------------------------------------------------------
// BACKGROUND DOCUMENT UPLOAD — decoupled from form submission
// -----------------------------------------------------------
// The request/application form (both [nsh_request_form] and
// [nsh_standalone_form] — same shared renderer and JS, see
// nsh_render_service_wizard_html()) used to send every selected document
// as raw file bytes inside the SAME call that creates the request
// (nsh_ajax_create_request() above), so Submit could only finish once
// every document had fully uploaded. These three endpoints replace that:
// a document starts uploading the INSTANT it's selected (nsh-app.js), as
// its own small, independent request, tagged with a per-form
// $upload_token (a random value the browser generates once and reuses for
// every file on that form) rather than a request id — no nsh_request post
// exists yet at file-select time. The attachment is created as an orphan
// (post_parent = 0) until it's either (a) already finished by the time
// Submit is clicked, in which case nsh_ajax_create_request() itself
// re-parents it, or (b) still uploading at that moment, in which case
// nsh_ajax_attach_pending_document() re-parents it a little later, the
// instant that one upload's own request finishes.
add_action('wp_ajax_nopriv_nsh_upload_pending_document', 'nsh_ajax_upload_pending_document');
add_action('wp_ajax_nsh_upload_pending_document',        'nsh_ajax_upload_pending_document');
function nsh_ajax_upload_pending_document() {
    nsh_check_nonce();

    $token = sanitize_text_field( isset( $_POST['token'] ) ? $_POST['token'] : '' );
    if ( $token === '' || strlen( $token ) > 100 ) {
        wp_send_json_error( array( 'message' => 'Your upload session has expired. Please refresh the page and try again.' ) );
    }
    $field_key   = sanitize_key( isset( $_POST['field_key'] ) ? $_POST['field_key'] : 'documents' );
    $field_label = sanitize_text_field( isset( $_POST['field_label'] ) ? $_POST['field_label'] : 'Document' );

    if ( empty( $_FILES['file'] ) ) {
        wp_send_json_error( array( 'message' => 'No file received.' ) );
    }
    $file = $_FILES['file'];
    if ( $file['error'] !== UPLOAD_ERR_OK ) {
        wp_send_json_error( array( 'message' => 'Upload failed. Please try again.' ) );
    }
    if ( $file['size'] > 10 * 1024 * 1024 ) {
        wp_send_json_error( array( 'message' => 'File exceeds 10MB.' ) );
    }
    $allowed_mimes = array( 'application/pdf', 'image/jpeg', 'image/png', 'image/jpg' );
    $finfo = new finfo( FILEINFO_MIME_TYPE );
    $mime  = $finfo->file( $file['tmp_name'] );
    if ( ! in_array( $mime, $allowed_mimes, true ) ) {
        wp_send_json_error( array( 'message' => 'Only PDF, JPG, or PNG files are allowed.' ) );
    }

    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $upload = wp_handle_upload( $file, array( 'test_form' => false ) );
    if ( isset( $upload['error'] ) || ! isset( $upload['file'] ) ) {
        wp_send_json_error( array( 'message' => 'Could not save file: ' . ( isset( $upload['error'] ) ? $upload['error'] : 'unknown error' ) ) );
    }

    $attachment = array(
        'post_mime_type' => $upload['type'],
        'post_title'     => sanitize_file_name( pathinfo( $file['name'], PATHINFO_FILENAME ) ),
        'post_content'   => '',
        'post_status'    => 'inherit',
        'post_parent'    => 0, // orphan until a request claims it
    );
    $att_id = wp_insert_attachment( $attachment, $upload['file'] );
    if ( is_wp_error( $att_id ) || ! $att_id ) {
        wp_send_json_error( array( 'message' => 'Could not save uploaded file.' ) );
    }

    nsh_generate_minimal_attachment_metadata( $att_id, $upload['file'], $upload['type'] );
    nsh_sanitise_attachment( $att_id );

    update_post_meta( $att_id, '_nsh_pending_token', $token );
    update_post_meta( $att_id, '_nsh_pending_field', $field_key );
    update_post_meta( $att_id, '_nsh_pending_label', $field_label );
    update_post_meta( $att_id, '_nsh_pending_time',  time() );
    if ( is_user_logged_in() ) {
        update_post_meta( $att_id, '_nsh_pending_user', get_current_user_id() );
    }

    wp_send_json_success( array(
        'attachment_id' => $att_id,
        'filename'      => basename( get_attached_file( $att_id ) ),
    ) );
}

// Lets the browser remove a file the visitor selected then changed their
// mind about, BEFORE they submit — otherwise that orphan attachment would
// just sit unused until nsh_cleanup_stale_pending_uploads() sweeps it up
// a couple of days later. Authorization here is deliberately just "you
// know this attachment's own pending token" (matched against what's
// actually stored on it) rather than a login/ownership check — there is
// no account yet at file-select time on the anonymous standalone form,
// and a still-orphan (post_parent = 0) attachment is otherwise unlinked
// from anything sensitive.
add_action('wp_ajax_nopriv_nsh_delete_pending_document', 'nsh_ajax_delete_pending_document');
add_action('wp_ajax_nsh_delete_pending_document',        'nsh_ajax_delete_pending_document');
function nsh_ajax_delete_pending_document() {
    nsh_check_nonce();
    $att_id = intval( isset( $_POST['attachment_id'] ) ? $_POST['attachment_id'] : 0 );
    $token  = sanitize_text_field( isset( $_POST['token'] ) ? $_POST['token'] : '' );
    if ( ! $att_id || $token === '' ) { wp_send_json_error( array( 'message' => 'Invalid request.' ) ); }

    $att = get_post( $att_id );
    if ( ! $att || $att->post_type !== 'attachment' || intval( $att->post_parent ) !== 0 ) {
        wp_send_json_error( array( 'message' => 'File not found.' ) );
    }
    $stored_token = get_post_meta( $att_id, '_nsh_pending_token', true );
    if ( $stored_token === '' || $stored_token !== $token ) {
        wp_send_json_error( array( 'message' => 'Access denied.' ), 403 );
    }
    wp_delete_attachment( $att_id, true );
    wp_send_json_success();
}

// Attaches a document upload that was STILL IN PROGRESS at the moment the
// request itself was created — nsh_ajax_create_request() already attaches
// everything that finished before Submit was clicked; this covers the
// remainder, called by the browser the instant each one's own upload
// request resolves (see nsh-app.js). Requires a real, already-created
// request, so the visitor is logged in by now (nsh_ajax_create_request()
// calls wp_set_auth_cookie() for a brand-new client) and nsh_is_own_request()
// applies normally.
add_action('wp_ajax_nsh_attach_pending_document', 'nsh_ajax_attach_pending_document');
function nsh_ajax_attach_pending_document() {
    nsh_check_nonce();
    $rid    = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    $att_id = intval( isset( $_POST['attachment_id'] ) ? $_POST['attachment_id'] : 0 );
    if ( ! $rid || ! $att_id ) { wp_send_json_error( array( 'message' => 'Invalid request.' ) ); }
    if ( ! nsh_is_own_request( $rid ) ) { wp_send_json_error( array( 'message' => 'Access denied.' ), 403 ); }

    $att = get_post( $att_id );
    if ( ! $att || $att->post_type !== 'attachment' ) { wp_send_json_error( array( 'message' => 'File not found.' ) ); }

    // Defense in depth: the attachment must carry the SAME upload token
    // this request was created with (_nsh_upload_token, stamped in
    // nsh_ajax_create_request()) — without this, a logged-in client could
    // attach any other visitor's still-pending attachment id to their own
    // request just by guessing/incrementing ids.
    $req_token = get_post_meta( $rid, '_nsh_upload_token', true );
    $att_token = get_post_meta( $att_id, '_nsh_pending_token', true );
    if ( $req_token === '' || $att_token === '' || $req_token !== $att_token ) {
        wp_send_json_error( array( 'message' => 'Access denied.' ), 403 );
    }

    $field_key = get_post_meta( $att_id, '_nsh_pending_field', true );
    $label     = get_post_meta( $att_id, '_nsh_pending_label', true );

    wp_update_post( array( 'ID' => $att_id, 'post_parent' => $rid ) );
    delete_post_meta( $att_id, '_nsh_pending_token' );

    $docs = get_post_meta( $rid, 'documents', true );
    if ( ! is_array( $docs ) ) { $docs = array(); }
    $docs[] = array(
        'file'        => $att_id,
        'field_key'   => $field_key ? $field_key : 'documents',
        'doc_type'    => $label ? $label : 'Uploaded Document',
        'is_provider' => 0,
        'expiry'      => '',
        'uploaded_at' => current_time( 'mysql' ),
    );
    update_post_meta( $rid, 'documents', $docs );
    nsh_add_history( $rid, 'Document uploaded', ( $label ? $label : 'Document' ) . ' attached (background upload).' );

    wp_send_json_success( array( 'attachment_id' => $att_id ) );
}

// Sweeps up orphan attachments (post_parent = 0, still carrying
// _nsh_pending_token) from forms that were started but never submitted —
// a visitor who uploaded a document then abandoned the page, closed the
// tab, or never clicked Submit. Runs once a day off the plugin's existing
// nsh_daily_cron hook (see nri-services-hub.php); a generous 48-hour
// window means a genuinely still-in-progress, very slow upload is never
// at risk of being swept mid-flight.
add_action('nsh_daily_cron', 'nsh_cleanup_stale_pending_uploads');
function nsh_cleanup_stale_pending_uploads() {
    global $wpdb;
    $cutoff = time() - 2 * DAY_IN_SECONDS;
    $ids = $wpdb->get_col( $wpdb->prepare(
        "SELECT pm1.post_id FROM {$wpdb->postmeta} pm1
         INNER JOIN {$wpdb->postmeta} pm2 ON pm2.post_id = pm1.post_id AND pm2.meta_key = '_nsh_pending_time'
         WHERE pm1.meta_key = '_nsh_pending_token' AND CAST(pm2.meta_value AS UNSIGNED) < %d",
        $cutoff
    ) );
    foreach ( (array) $ids as $id ) {
        $att = get_post( $id );
        if ( $att && $att->post_type === 'attachment' && intval( $att->post_parent ) === 0 ) {
            wp_delete_attachment( intval( $id ), true );
        }
    }
}

add_action('wp_ajax_nsh_delete_document', 'nsh_ajax_delete_doc');
function nsh_ajax_delete_doc() {
    nsh_check_nonce(); nsh_require_staff();
    $rid    = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $att_id = intval(isset($_POST['attachment_id']) ? $_POST['attachment_id'] : 0);
    $docs   = get_post_meta($rid, 'documents', true);
    if (!is_array($docs)) $docs = array();
    $new = array();
    foreach ($docs as $d) {
        if ((int) $d['file'] !== $att_id) $new[] = $d;
    }
    update_post_meta($rid, 'documents', $new);
    wp_send_json_success();
}

// -----------------------------------------------------------
// REQUEST MANAGEMENT (admin)
// -----------------------------------------------------------
add_action('wp_ajax_nsh_get_requests', 'nsh_ajax_get_requests');
function nsh_ajax_get_requests() {
    nsh_check_nonce(); nsh_require_staff();
    $status          = sanitize_text_field(isset($_POST['status']) ? $_POST['status'] : '');
    $internal_status = sanitize_key(isset($_POST['internal_status']) ? $_POST['internal_status'] : '');
    $search          = sanitize_text_field(isset($_POST['search']) ? $_POST['search'] : '');
    $paged    = max(1, intval(isset($_POST['paged']) ? $_POST['paged'] : 1));
    $per_page = 20;

    $date_filter = sanitize_key(isset($_POST['date_filter']) ? $_POST['date_filter'] : '');
    $date_from   = sanitize_text_field(isset($_POST['date_from']) ? $_POST['date_from'] : '');
    $date_to     = sanitize_text_field(isset($_POST['date_to'])   ? $_POST['date_to']   : '');
    list($date_after, $date_before) = nsh_compute_request_date_range($date_filter, $date_from, $date_to);

    if ($search === '') {
        // FAST PATH — no search term: real SQL-level pagination (LIMIT/
        // OFFSET via WP_Query's own posts_per_page/paged), exactly like
        // before the comprehensive-search feature was added. This is the
        // common case (most tab loads/page changes/status-only filters
        // carry no search term) and it must never touch more rows than the
        // one page it's about to show.
        $args = array(
            'post_type'      => 'nsh_request',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $paged,
            'orderby'        => 'date',
            'order'          => 'DESC',
        );
        $meta_query = array();
        if ($status) { $meta_query[] = array('key' => 'status', 'value' => $status); }
        if ($internal_status) {
            $ist_mq = nsh_internal_status_meta_query($internal_status);
            if ($ist_mq) { $meta_query[] = $ist_mq; }
        }
        if ($meta_query) {
            if (count($meta_query) > 1) { $meta_query['relation'] = 'AND'; }
            $args['meta_query'] = $meta_query;
        }
        $date_query = nsh_request_date_query($date_after, $date_before);
        if ($date_query) { $args['date_query'] = $date_query; }
        $q        = new WP_Query($args);
        $page_ids = wp_list_pluck($q->posts, 'ID');
        $total    = $q->found_posts;
        $pages    = $q->max_num_pages ? $q->max_num_pages : 1;
    } else {
        // SEARCH PATH — WP_Query's built-in 's' parameter only matches
        // post_title/post_content, but a request's actual submitted data
        // (applicant name, university, phone, enrollment number, etc.)
        // lives in the field_data postmeta array, and client name/email
        // live on the wp_users row — neither reachable via 's'. There is
        // no indexed column to search across the admin-configurable set of
        // submitted fields, so this path necessarily scans every
        // status-matching request's meta once per search and can't use a
        // single-query SQL LIMIT/OFFSET. Two things keep it cheap even on
        // a large table:
        //  1. 'fields' => 'ids' + WP_Query's own meta-cache priming means
        //     this is one lightweight ID query plus one batched postmeta
        //     query for the whole set — not one query per row.
        //  2. The matched-ID list for a given status+search combination is
        //     cached in a short-lived transient (45s), so paginating
        //     through search results, or the same term being searched
        //     again shortly after, don't re-scan the table — a deliberate,
        //     bounded staleness window (new/changed requests can take up
        //     to 45s to appear in *search* results specifically; the
        //     no-search fast path above is always fully live).
        list($matched_ids, $total) = nsh_search_matching_request_ids($status, $search, $date_after, $date_before, $internal_status);
        $pages    = max(1, (int) ceil($total / $per_page));
        $page_ids = array_slice($matched_ids, ($paged - 1) * $per_page, $per_page);
    }

    $out = array();
    foreach ($page_ids as $pid) {
        $p      = get_post($pid);
        $meta   = nsh_get_meta($pid);
        $author = get_userdata($p->post_author);
        $mgr    = $meta['assigned_manager'] ? get_userdata($meta['assigned_manager']) : null;
        $vendor = $meta['assigned_vendor']  ? get_userdata($meta['assigned_vendor'])  : null;
        $fd     = $meta['field_data'];
        // Every request now belongs to a real nsh_services catalog entry
        // (service_name meta, set at submission — see nsh_ajax_create_request())
        // rather than a free-text field_service_type/field_document_type
        // value from the old generic 4-step wizard; fall back to those only
        // for any pre-existing request created before this service model.
        $svc    = ! empty( $meta['service_name'] ) ? $meta['service_name']
                : ( ! empty( $fd['field_service_type'] ) ? $fd['field_service_type']
                : ( ! empty( $fd['field_document_type'] ) ? $fd['field_document_type'] : 'Request' ) );
        $out[]  = array(
            'id'           => $p->ID,
            'request_id'   => $meta['request_id'] ? $meta['request_id'] : '#' . $p->ID,
            'client'       => $author ? $author->display_name : '?',
            'email'        => $author ? $author->user_email : '',
            // Who to actually address/call about this request — the
            // dedicated Contact Person Name field every service's Contact
            // Details step now collects, with a sensible fallback chain
            // (see nsh_req_contact_person_name() in helpers.php). Shown
            // at the top of the admin request card in place of the raw
            // email address (nsh_render_admin_dashboard_js() in
            // shortcodes.php).
            'contact_person' => nsh_req_contact_person_name( $p->ID, $fd, $author ),
            'service'      => wp_trim_words($svc, 6, ''),
            'status'       => $meta['status'],
            'status_label' => nsh_status_label($meta['status']),
            'status_color' => nsh_status_color($meta['status']),
            // Staff-only CRM pipeline stage — see the "INTERNAL STATUS"
            // section in helpers.php. Deliberately kept in the same
            // response as everything above (this whole endpoint is
            // nsh_require_staff()-gated, so nothing here ever reaches a
            // client), never returned from any client-facing endpoint.
            'internal_status'       => $meta['internal_status'],
            'internal_status_label' => nsh_internal_status_label($meta['internal_status']),
            'internal_status_color' => nsh_internal_status_color($meta['internal_status']),
            'quote'        => $meta['quote_amount'] ? 'INR ' . number_format((float) $meta['quote_amount'], 2) : '-',
            'delivery'     => $meta['estimated_delivery'] ? date('d M Y', strtotime($meta['estimated_delivery'])) : '-',
            'manager'      => $mgr    ? $mgr->display_name    : 'Unassigned',
            'vendor'       => $vendor ? $vendor->display_name : 'Unassigned',
            'date'         => get_the_date('d M Y', $p->ID),
            // Whether the card's "Docs" button has anything to download —
            // avoids a click-then-error round trip when there are none.
            'has_docs'     => ! empty( nsh_get_documents( $p->ID ) ),
            // Pre-rendered, already-escaped compact summary of the
            // submitted form data (grouped Applicant/Academic/
            // Location-Delivery/Remarks lines) — see
            // nsh_render_request_card_fields() in helpers.php. Built
            // server-side so escaping and field-key fallback logic live
            // in one place instead of being duplicated in JS strings.
            'card_fields'  => nsh_render_request_card_fields( $p->ID, $meta ),
            // Plain-text Student Requirement Description for the card's
            // "Copy Description" button — see nsh_get_requirement_description()
            // in helpers.php. Lazily generated + persisted on first access
            // for any request that predates this feature.
            'description'  => nsh_get_requirement_description( $p->ID, $meta )['text'],
        );
    }
    // Internal-status filter bar data: every defined status (including
    // inactive ones already in use, so an old assignment stays labeled
    // instead of falling back to a raw slug) plus a count per slug,
    // scoped the same way as nsh_get_internal_status_counts()'s own
    // docblock explains (client status + date, not the free-text search
    // term). Sent on every list load so the pill bar can render/refresh
    // without a second round trip.
    $istatus_rows = array();
    foreach ( nsh_get_internal_statuses( false ) as $r ) {
        $istatus_rows[] = array(
            'slug'      => $r->slug,
            'label'     => $r->label,
            'color'     => $r->color ? $r->color : '#6b7280',
            'is_active' => (int) $r->is_active === 1,
        );
    }
    wp_send_json_success(array(
        'requests'               => $out,
        'total'                  => $total,
        'pages'                  => $pages,
        'internal_statuses'      => $istatus_rows,
        'internal_status_counts' => nsh_get_internal_status_counts( $status, $date_after, $date_before ),
    ));
}

// Builds a single lower-cased, whitespace-joined string containing every
// value that makes sense to search a request by: request ID, applicant
// name/email, service/document type, status label, quote, manager/vendor
// names, and — critically — every value inside the submitted field_data
// array (university, course, enrollment number, phone, remarks, etc., no
// matter what field keys this install's form is configured with). Shared
// by both the Requests tab and Form Submissions tab search so the two stay
// consistent.
function nsh_request_search_haystack($pid, $meta, $author) {
    $parts = array();
    $parts[] = isset($meta['request_id']) ? $meta['request_id'] : '';
    $parts[] = '#' . $pid;
    $parts[] = $author ? $author->display_name : '';
    $parts[] = $author ? $author->user_email : '';
    $parts[] = isset($meta['status']) ? nsh_status_label($meta['status']) : '';
    $parts[] = isset($meta['quote_amount']) ? $meta['quote_amount'] : '';
    if (!empty($meta['assigned_manager'])) { $m = get_userdata($meta['assigned_manager']); if ($m) $parts[] = $m->display_name; }
    if (!empty($meta['assigned_vendor']))  { $v = get_userdata($meta['assigned_vendor']);  if ($v) $parts[] = $v->display_name; }
    if (!empty($meta['field_data']) && is_array($meta['field_data'])) {
        foreach ($meta['field_data'] as $val) {
            if (is_array($val)) {
                foreach ($val as $vv) { if (!is_array($vv)) { $parts[] = (string) $vv; } }
            } elseif (!is_array($val)) {
                $parts[] = (string) $val;
            }
        }
    }
    $parts = array_filter($parts, function($x){ return $x !== null && $x !== ''; });
    return strtolower(implode(' | ', $parts));
}

// Runs the comprehensive multi-term meta+author search for a given
// status+search combination and returns array($matched_ids, $total),
// newest-first (matching the default 'date DESC' ordering used
// everywhere else in the admin lists). Shared by the Requests tab and
// Form Submissions tab so both get the same caching behavior.
//
// Result is cached in a 45-second transient keyed by status+search: the
// underlying scan (one ID query + one batched meta-cache-priming query,
// via 'fields' => 'ids' + WP_Query's own update_post_meta_cache) is cheap
// per call, but a user paginating through several pages of the same
// search, or re-running the same search moments later, would otherwise
// repeat it — the transient makes every page after the first free, and
// caps how often a given search re-scans the table. The tradeoff is a
// bounded staleness window (up to 45s) on SEARCH results specifically; a
// no-search list load is always fully live (see the fast path in
// nsh_ajax_get_requests()) because it never goes through this function.
function nsh_search_matching_request_ids($status, $search, $date_after = null, $date_before = null, $internal_status = '') {
    $cache_key = 'nsh_srch_' . md5($status . '|' . $search . '|' . $date_after . '|' . $date_before . '|' . $internal_status);
    $cached    = get_transient($cache_key);
    if (is_array($cached)) { return array($cached, count($cached)); }

    $id_args = array(
        'post_type'      => 'nsh_request',
        'post_status'    => 'publish',
        'posts_per_page' => -1,
        'orderby'        => 'date',
        'order'          => 'DESC',
        'fields'         => 'ids',
    );
    $meta_query = array();
    if ($status) { $meta_query[] = array('key' => 'status', 'value' => $status); }
    if ($internal_status) {
        $ist_mq = nsh_internal_status_meta_query($internal_status);
        if ($ist_mq) { $meta_query[] = $ist_mq; }
    }
    if ($meta_query) {
        if (count($meta_query) > 1) { $meta_query['relation'] = 'AND'; }
        $id_args['meta_query'] = $meta_query;
    }
    $date_query = nsh_request_date_query($date_after, $date_before);
    if ($date_query) { $id_args['date_query'] = $date_query; }
    $all_ids = get_posts($id_args);

    $search_terms = array_filter(preg_split('/\s+/', strtolower(trim($search))));
    $matched_ids  = array();
    foreach ($all_ids as $pid) {
        $meta   = nsh_get_meta($pid);
        $author = get_userdata(get_post_field('post_author', $pid));
        $hay    = nsh_request_search_haystack($pid, $meta, $author);
        $ok = true;
        foreach ($search_terms as $term) {
            if (strpos($hay, $term) === false) { $ok = false; break; }
        }
        if ($ok) { $matched_ids[] = $pid; }
    }

    set_transient($cache_key, $matched_ids, 45);
    return array($matched_ids, count($matched_ids));
}

// Clears every cached search result so the next search (any status/term
// combination) re-scans instead of serving up-to-45s-stale results — see
// nsh_search_matching_request_ids(). Called after a request is created or
// deleted (the two changes that add/remove a row from every possible
// result set); an in-place edit to an existing request's fields only
// affects that one request's presence in a *few* specific searches, so
// those are left to expire on their own via the 45s TTL rather than
// flushing the whole cache on every field/status/quote/assignment change
// across the admin UI.
function nsh_flush_request_search_cache() {
    global $wpdb;
    $wpdb->query(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_nri\_srch\_%' OR option_name LIKE '\_transient\_timeout\_nri\_srch\_%'"
    );
}

// -----------------------------------------------------------
// INTERNAL STATUS (CRM pipeline) — staff-only, never client-facing.
// See the "INTERNAL STATUS" section in helpers.php for the shared
// label/color/meta_query helpers this block builds on.
// -----------------------------------------------------------

// Assigns an internal status to one request — any staff member
// (nsh_is_staff(), not just an administrator) can do this; it's the
// day-to-day pipeline action, distinct from *defining* the status list
// below, which is admin-only. Refuses an inactive/unknown slug UNLESS
// it's the slug the request already carries (so a request already
// sitting on a status that got deactivated afterward is never silently
// blocked from having ITS status re-saved as part of some other edit —
// though the UI itself won't offer a deactivated slug as a new choice).
add_action( 'wp_ajax_nsh_set_internal_status', 'nsh_ajax_set_internal_status' );
function nsh_ajax_set_internal_status() {
    nsh_check_nonce(); nsh_require_staff();
    $rid  = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    $slug = sanitize_key( isset( $_POST['internal_status'] ) ? $_POST['internal_status'] : '' );
    if ( ! $rid || get_post_type( $rid ) !== 'nsh_request' ) {
        wp_send_json_error( array( 'message' => 'Request not found.' ) );
    }
    if ( $slug === '' ) {
        wp_send_json_error( array( 'message' => 'Missing internal status.' ) );
    }
    $current = nsh_get_meta( $rid )['internal_status'];
    $map     = nsh_get_internal_status_map( false );
    if ( ! isset( $map[ $slug ] ) ) {
        wp_send_json_error( array( 'message' => 'Unknown internal status.' ) );
    }
    if ( (int) $map[ $slug ]->is_active !== 1 && $slug !== $current ) {
        wp_send_json_error( array( 'message' => 'That status is deactivated and can no longer be newly assigned.' ) );
    }
    update_post_meta( $rid, 'internal_status', $slug );
    if ( $slug !== $current ) {
        nsh_add_history( $rid, 'internal_status_changed', nsh_internal_status_label( $current ) . ' → ' . nsh_internal_status_label( $slug ) );
    }
    wp_send_json_success( array(
        'internal_status'       => $slug,
        'internal_status_label' => nsh_internal_status_label( $slug ),
        'internal_status_color' => nsh_internal_status_color( $slug ),
    ) );
}

// Full status-definition list for the management screen (includes
// inactive rows — the admin needs to see and re-activate/delete those
// too, unlike the request-card dropdown which only offers active ones).
add_action( 'wp_ajax_nsh_admin_list_internal_statuses', 'nsh_ajax_admin_list_internal_statuses' );
function nsh_ajax_admin_list_internal_statuses() {
    nsh_check_nonce(); nsh_require_admin();
    global $wpdb;
    $rows  = nsh_get_internal_statuses( false, true );
    $out   = array();
    foreach ( $rows as $r ) {
        $out[] = array(
            'id'         => (int) $r->id,
            'slug'       => $r->slug,
            'label'      => $r->label,
            'color'      => $r->color ? $r->color : '#6b7280',
            'sort_order' => (int) $r->sort_order,
            'is_active'  => (int) $r->is_active === 1,
            // How many requests currently carry this exact slug — lets
            // the management UI warn before a delete instead of the
            // delete endpoint being the first place that's discovered.
            'in_use'     => (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = 'internal_status' AND pm.meta_value = %s AND p.post_type = 'nsh_request' AND p.post_status = 'publish'",
                $r->slug
            ) ) + ( $r->slug === 'inquiry' ? nsh_count_requests_defaulting_to_inquiry() : 0 ),
        );
    }
    wp_send_json_success( $out );
}

// Requests with NO internal_status meta row at all also count as
// "Inquiry" for display (see nsh_get_meta()'s default) — this adds those
// in for the Inquiry row's in_use count specifically, so "safe to
// delete?" reflects reality for that one stage instead of undercounting
// every request that has simply never been touched.
function nsh_count_requests_defaulting_to_inquiry() {
    global $wpdb;
    return (int) $wpdb->get_var(
        "SELECT COUNT(*) FROM {$wpdb->posts} p
         WHERE p.post_type = 'nsh_request' AND p.post_status = 'publish'
         AND NOT EXISTS (
             SELECT 1 FROM {$wpdb->postmeta} pm WHERE pm.post_id = p.ID AND pm.meta_key = 'internal_status' AND pm.meta_value <> ''
         )"
    );
}

// Create (no id) or rename (id present) a status definition. Reordering,
// activating/deactivating, and deleting each have their own endpoint
// below — this one only ever touches label/color.
add_action( 'wp_ajax_nsh_admin_save_internal_status', 'nsh_ajax_admin_save_internal_status' );
function nsh_ajax_admin_save_internal_status() {
    nsh_check_nonce(); nsh_require_admin();
    global $wpdb;
    $id    = intval( isset( $_POST['id'] ) ? $_POST['id'] : 0 );
    $label = sanitize_text_field( isset( $_POST['label'] ) ? $_POST['label'] : '' );
    $color = sanitize_hex_color( isset( $_POST['color'] ) ? $_POST['color'] : '' );
    if ( $color === null || $color === '' ) { $color = '#6b7280'; }
    if ( $label === '' ) { wp_send_json_error( array( 'message' => 'Status name is required.' ) ); }
    $table = $wpdb->prefix . 'nsh_internal_statuses';

    if ( $id ) {
        // Rename an existing status — the slug (and therefore every
        // request currently pointing at it via postmeta) is left
        // untouched on purpose: changing only the display label/color
        // means every existing assignment stays correctly labeled with
        // zero postmeta rewriting, no matter how many requests use it.
        $existing = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d", $id ) );
        if ( ! $existing ) { wp_send_json_error( array( 'message' => 'Status not found.' ) ); }
        $wpdb->update( $table, array( 'label' => $label, 'color' => $color ), array( 'id' => $id ) );
        nsh_clear_internal_status_cache();
        wp_send_json_success( array( 'id' => $id, 'slug' => $existing->slug, 'label' => $label, 'color' => $color ) );
    }

    // Create — auto-slug from the label, de-duplicated if it collides
    // with an existing slug (append -2, -3, … the same way WordPress
    // itself de-dupes post slugs).
    $base_slug = nsh_generate_internal_status_slug( $label );
    $slug      = $base_slug;
    $n         = 2;
    while ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $table WHERE slug=%s", $slug ) ) ) {
        $slug = $base_slug . '_' . $n;
        $n++;
    }
    $max_order = (int) $wpdb->get_var( "SELECT MAX(sort_order) FROM $table" );
    $wpdb->insert( $table, array(
        'slug'       => $slug,
        'label'      => $label,
        'color'      => $color,
        'sort_order' => $max_order + 10,
        'is_active'  => 1,
    ) );
    nsh_clear_internal_status_cache();
    wp_send_json_success( array( 'id' => (int) $wpdb->insert_id, 'slug' => $slug, 'label' => $label, 'color' => $color ) );
}

// Persists a new top-to-bottom order for the whole list in one call —
// $_POST['order'] is a comma-separated list of status IDs in the new
// order (matches how the management UI's up/down controls submit it).
add_action( 'wp_ajax_nsh_admin_reorder_internal_statuses', 'nsh_ajax_admin_reorder_internal_statuses' );
function nsh_ajax_admin_reorder_internal_statuses() {
    nsh_check_nonce(); nsh_require_admin();
    global $wpdb;
    $order_raw = isset( $_POST['order'] ) ? sanitize_text_field( wp_unslash( $_POST['order'] ) ) : '';
    $ids       = array_filter( array_map( 'intval', explode( ',', $order_raw ) ) );
    if ( empty( $ids ) ) { wp_send_json_error( array( 'message' => 'Nothing to reorder.' ) ); }
    $table = $wpdb->prefix . 'nsh_internal_statuses';
    $pos   = 10;
    foreach ( $ids as $id ) {
        $wpdb->update( $table, array( 'sort_order' => $pos ), array( 'id' => $id ) );
        $pos += 10;
    }
    nsh_clear_internal_status_cache();
    wp_send_json_success();
}

// Activate/deactivate — a deactivated status stops appearing as a
// choice for NEW assignments (nsh_get_internal_statuses(true) /
// nsh_ajax_set_internal_status()'s is_active check above), but every
// request already carrying it keeps that exact label/color untouched;
// nothing about existing requests changes.
// Activate/deactivate (show/hide) a service. This is the single write
// path behind the Services settings tab's toggle — nsh_get_services(true)
// (the only query both [nsh_standalone_form] and [nsh_request_form] use
// to build the Services dropdown, and what nsh_ajax_prefetch_all_wizards
// uses to build the prefetch cache) filters on is_active=1, so flipping
// this immediately controls whether the service is offered as a NEW
// choice on both forms — with no other code path to keep in sync. Existing
// data for the service (its fields, dropdown options, past requests) is
// completely untouched either way.
add_action( 'wp_ajax_nsh_admin_toggle_service', 'nsh_ajax_admin_toggle_service' );
function nsh_ajax_admin_toggle_service() {
    nsh_check_nonce(); nsh_require_admin();
    global $wpdb;
    $id     = intval( isset( $_POST['id'] ) ? $_POST['id'] : 0 );
    $active = ! empty( $_POST['active'] ) ? 1 : 0;
    if ( ! $id ) { wp_send_json_error( array( 'message' => 'Missing service id.' ) ); }
    $table   = $wpdb->prefix . 'nsh_services';
    $service = $wpdb->get_row( $wpdb->prepare( "SELECT id FROM {$table} WHERE id=%d", $id ) );
    if ( ! $service ) { wp_send_json_error( array( 'message' => 'Service not found.' ) ); }
    $wpdb->update( $table, array( 'is_active' => $active ), array( 'id' => $id ) );
    wp_send_json_success( array( 'id' => $id, 'is_active' => (bool) $active ) );
}

// Batch save for the Services settings tab's "Save Changes" button — every
// checkbox on screen is sent together in one write, only when the admin
// explicitly clicks Save (see nshSaveServicesChanges() in
// admin-settings-integrated.php). Replaces per-checkbox auto-save; the
// single-toggle handler above is left in place for any other caller but is
// no longer used by this tab.
add_action( 'wp_ajax_nsh_admin_save_services_bulk', 'nsh_ajax_admin_save_services_bulk' );
function nsh_ajax_admin_save_services_bulk() {
    nsh_check_nonce(); nsh_require_admin();
    global $wpdb;
    $table = $wpdb->prefix . 'nsh_services';
    $raw    = isset( $_POST['states'] ) ? wp_unslash( $_POST['states'] ) : '';
    $states = json_decode( $raw, true );
    if ( ! is_array( $states ) || empty( $states ) ) {
        wp_send_json_error( array( 'message' => 'No changes to save.' ) );
    }
    $updated = 0;
    foreach ( $states as $id => $active ) {
        $id     = intval( $id );
        $active = ! empty( $active ) ? 1 : 0;
        if ( ! $id ) { continue; }
        $wpdb->update( $table, array( 'is_active' => $active ), array( 'id' => $id ) );
        $updated++;
    }
    $active_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE is_active=1" );
    $total_count  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
    wp_send_json_success( array( 'updated' => $updated, 'active_count' => $active_count, 'total_count' => $total_count ) );
}

// Create a brand-new service from the Services settings tab's "Add New
// Service" panel. Mirrors nsh_seed_services_and_fields()'s own insert shape
// exactly (schema.php) so a manually-created service is indistinguishable
// from a seeded one to every other part of the plugin — the request wizard,
// the Form Fields tab, the client-facing catalog, etc. all key off
// wp_nsh_services/wp_nsh_fields alone, never the JSON seed file. A minimal
// "Contact Details" (step 98) + "Documents" (step 99) field scaffold is
// seeded automatically — same steps the Form Fields tab's own hint text
// documents as the standard convention every service ends with — so the new
// service is immediately submittable; the admin edits/adds/reorders its
// fields from there via the existing Form Fields tab exactly as with any
// other service.
add_action( 'wp_ajax_nsh_admin_create_service', 'nsh_ajax_admin_create_service' );
function nsh_ajax_admin_create_service() {
    nsh_check_nonce(); nsh_require_admin();
    global $wpdb;
    $st = $wpdb->prefix . 'nsh_services';
    $ft = $wpdb->prefix . 'nsh_fields';

    $name = sanitize_text_field( isset( $_POST['name'] ) ? $_POST['name'] : '' );
    if ( ! $name ) { wp_send_json_error( array( 'message' => 'Service name is required.' ) ); }

    $cats     = nsh_service_categories();
    $category = sanitize_key( isset( $_POST['category'] ) ? $_POST['category'] : '' );
    if ( ! $category || ! isset( $cats[ $category ] ) ) {
        wp_send_json_error( array( 'message' => 'Please choose a valid category.' ) );
    }

    $slug = sanitize_title( ( isset( $_POST['slug'] ) && $_POST['slug'] ) ? $_POST['slug'] : $name );
    if ( ! $slug ) { wp_send_json_error( array( 'message' => 'Could not derive a valid slug from that name.' ) ); }
    // De-dup against the slug's UNIQUE KEY the same way WordPress de-dupes
    // post slugs, instead of failing outright on a collision.
    $base_slug = $slug; $n = 2;
    while ( $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$st} WHERE slug=%s", $slug ) ) ) {
        $slug = $base_slug . '-' . $n; $n++;
    }

    $short_desc      = sanitize_text_field( isset( $_POST['short_desc'] ) ? $_POST['short_desc'] : '' );
    $pricing_model   = in_array( isset( $_POST['pricing_model'] ) ? $_POST['pricing_model'] : '', array( 'quote', 'fixed' ), true ) ? $_POST['pricing_model'] : 'quote';
    $base_price      = ( $pricing_model === 'fixed' && isset( $_POST['base_price'] ) && $_POST['base_price'] !== '' ) ? floatval( $_POST['base_price'] ) : null;
    $turnaround_days = intval( isset( $_POST['turnaround_days'] ) ? $_POST['turnaround_days'] : 7 );
    if ( $turnaround_days < 1 ) { $turnaround_days = 7; }
    $required_docs = nsh_parse_field_options( isset( $_POST['required_docs'] ) ? wp_unslash( $_POST['required_docs'] ) : '' );
    $is_active     = ! empty( $_POST['active'] ) ? 1 : 0;

    $max_sort = (int) $wpdb->get_var( "SELECT MAX(sort_order) FROM {$st}" );

    $ok = $wpdb->insert( $st, array(
        'category'        => $category,
        'slug'            => $slug,
        'name'            => $name,
        'short_desc'      => $short_desc,
        'pricing_model'   => $pricing_model,
        'base_price'      => $base_price,
        'turnaround_days' => $turnaround_days,
        'required_docs'   => wp_json_encode( $required_docs ),
        'is_active'       => $is_active,
        'sort_order'      => $max_sort + 1,
    ) );
    if ( ! $ok ) { wp_send_json_error( array( 'message' => 'Could not create the service. It may already exist.' ) ); }
    $service_id = (int) $wpdb->insert_id;

    // Standard Contact Details (step 98) + Documents (step 99) scaffold —
    // the same fields every other service in the catalog ends its form
    // with (see nsh_seed_services_and_fields()/services-seed.json).
    $scaffold = array(
        array( 'key' => 'contact_person_name', 'label' => 'Contact Person Name', 'type' => 'text', 'req' => 1, 'step' => 98, 'sort' => 1, 'opts' => '' ),
        array( 'key' => '__phone', 'label' => 'Phone / WhatsApp (with country code)', 'type' => 'phone', 'req' => 1, 'step' => 98, 'sort' => 2, 'opts' => '' ),
        array( 'key' => '__email', 'label' => 'Email Address', 'type' => 'email', 'req' => 1, 'step' => 98, 'sort' => 3, 'opts' => '' ),
        array( 'key' => '__country', 'label' => 'Country of Residence', 'type' => 'select', 'req' => 1, 'step' => 98, 'sort' => 4,
               'opts' => "USA\nUK\nCanada\nAustralia\nUAE\nSingapore\nGermany\nNew Zealand\nSaudi Arabia\nQatar\nKuwait\nBahrain\nOman\nNetherlands\nMalaysia\nJapan\nSouth Africa\nOther" ),
        array( 'key' => '__delivery', 'label' => 'Delivery Address (include country)', 'type' => 'textarea', 'req' => 1, 'step' => 98, 'sort' => 5, 'opts' => '' ),
        array( 'key' => 'upload_document', 'label' => 'Upload Supporting Document', 'type' => 'file', 'req' => 0, 'step' => 99, 'sort' => 1, 'opts' => '' ),
    );
    foreach ( $scaffold as $f ) {
        $wpdb->insert( $ft, array(
            'field_key'     => $f['key'],
            'service_id'    => $service_id,
            'field_label'   => $f['label'],
            'field_type'    => $f['type'],
            'field_options' => $f['opts'],
            'is_required'   => $f['req'],
            'sort_order'    => $f['sort'],
            'is_active'     => 1,
            'step_number'   => $f['step'],
        ) );
    }

    $cat_label = isset( $cats[ $category ] ) ? $cats[ $category ]['name'] : ucfirst( $category );
    $new_row   = nsh_get_service( $service_id );
    $row_html  = nsh_render_one_service_mgmt_row( $new_row, $cat_label );

    wp_send_json_success( array(
        'id'         => $service_id,
        'slug'       => $slug,
        'name'       => $name,
        'category'   => $category,
        'is_active'  => (bool) $is_active,
        'row_html'   => $row_html,
        'fields_url' => add_query_arg( array( 'tab' => 'fields', 'field_service_id' => $service_id ), nsh_admin_dashboard_url() ),
    ) );
}

add_action( 'wp_ajax_nsh_admin_toggle_internal_status', 'nsh_ajax_admin_toggle_internal_status' );
function nsh_ajax_admin_toggle_internal_status() {
    nsh_check_nonce(); nsh_require_admin();
    global $wpdb;
    $id     = intval( isset( $_POST['id'] ) ? $_POST['id'] : 0 );
    $active = ! empty( $_POST['active'] ) ? 1 : 0;
    if ( ! $id ) { wp_send_json_error( array( 'message' => 'Missing status id.' ) ); }
    $table = $wpdb->prefix . 'nsh_internal_statuses';
    $wpdb->update( $table, array( 'is_active' => $active ), array( 'id' => $id ) );
    nsh_clear_internal_status_cache();
    wp_send_json_success( array( 'id' => $id, 'is_active' => (bool) $active ) );
}

// Delete — only when SAFE, i.e. zero requests currently carry this
// slug (including the implicit "Inquiry" default for untouched
// requests — see nsh_count_requests_defaulting_to_inquiry() above).
// Otherwise refuses with a clear message instead of leaving requests
// pointing at a now-nonexistent status row; deactivating is always the
// safe alternative for a status still in use.
add_action( 'wp_ajax_nsh_admin_delete_internal_status', 'nsh_ajax_admin_delete_internal_status' );
function nsh_ajax_admin_delete_internal_status() {
    nsh_check_nonce(); nsh_require_admin();
    global $wpdb;
    $id = intval( isset( $_POST['id'] ) ? $_POST['id'] : 0 );
    if ( ! $id ) { wp_send_json_error( array( 'message' => 'Missing status id.' ) ); }
    $table = $wpdb->prefix . 'nsh_internal_statuses';
    $row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $table WHERE id=%d", $id ) );
    if ( ! $row ) { wp_send_json_error( array( 'message' => 'Status not found.' ) ); }

    $in_use = (int) $wpdb->get_var( $wpdb->prepare(
        "SELECT COUNT(*) FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id WHERE pm.meta_key = 'internal_status' AND pm.meta_value = %s AND p.post_type = 'nsh_request' AND p.post_status = 'publish'",
        $row->slug
    ) );
    if ( $row->slug === 'inquiry' ) { $in_use += nsh_count_requests_defaulting_to_inquiry(); }

    if ( $in_use > 0 ) {
        wp_send_json_error( array(
            'message' => sprintf( '%d request(s) currently use this status — deactivate it instead, or reassign those requests first.', $in_use ),
            'in_use'  => $in_use,
        ) );
    }
    $wpdb->delete( $table, array( 'id' => $id ) );
    nsh_clear_internal_status_cache();
    wp_send_json_success();
}

// -----------------------------------------------------------
// STUDENT REQUIREMENT DESCRIPTION
// -----------------------------------------------------------

// Read-only fetch (used by the request-detail page for either a staff
// member or the request's own client — both are allowed to see it,
// only staff can edit/regenerate it).
add_action( 'wp_ajax_nsh_get_requirement_description', 'nsh_ajax_get_requirement_description' );
function nsh_ajax_get_requirement_description() {
    nsh_check_nonce();
    $rid = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    if ( ! $rid || ! nsh_is_own_request( $rid ) ) {
        wp_send_json_error( array( 'message' => 'Access denied.' ) );
    }
    wp_send_json_success( nsh_get_requirement_description( $rid ) );
}

// Regenerates the description from the request's CURRENT fields. If the
// stored description was manually edited, this refuses unless the
// caller explicitly confirms with force=1 — the client-side confirm()
// dialog is the primary gate, this is the server-side backstop, so a
// manually-edited description is never silently overwritten.
add_action( 'wp_ajax_nsh_regenerate_description', 'nsh_ajax_regenerate_description' );
function nsh_ajax_regenerate_description() {
    nsh_check_nonce(); nsh_require_staff();
    $rid   = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    $force = ! empty( $_POST['force'] );
    if ( ! $rid ) { wp_send_json_error( array( 'message' => 'Invalid request.' ) ); }
    $is_manual = get_post_meta( $rid, 'requirement_description_manual', true ) === '1';
    if ( $is_manual && ! $force ) {
        wp_send_json_error( array( 'message' => 'This description was manually edited. Confirm to overwrite it.', 'needs_confirm' => true ) );
    }
    $meta = nsh_get_meta( $rid );
    $text = nsh_generate_requirement_description( $rid, $meta );
    nsh_save_requirement_description( $rid, $text, false );
    nsh_add_history( $rid, 'Requirement description regenerated' );
    wp_send_json_success( array( 'text' => $text, 'is_manual' => false, 'stale' => false ) );
}

// Saves an admin's own wording, marking it manually-edited so a later
// regenerate always asks for confirmation before replacing it.
add_action( 'wp_ajax_nsh_save_description', 'nsh_ajax_save_description' );
function nsh_ajax_save_description() {
    nsh_check_nonce(); nsh_require_staff();
    $rid  = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    $text = isset( $_POST['text'] ) ? sanitize_textarea_field( wp_unslash( $_POST['text'] ) ) : '';
    if ( ! $rid )      { wp_send_json_error( array( 'message' => 'Invalid request.' ) ); }
    if ( $text === '' ) { wp_send_json_error( array( 'message' => 'Description cannot be empty.' ) ); }
    nsh_save_requirement_description( $rid, $text, true );
    nsh_add_history( $rid, 'Requirement description edited manually' );
    wp_send_json_success( array( 'text' => $text, 'is_manual' => true, 'stale' => false ) );
}

add_action('wp_ajax_nsh_update_status', 'nsh_ajax_update_status');
function nsh_ajax_update_status() {
    nsh_check_nonce(); nsh_require_staff();
    $rid    = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $status = sanitize_text_field(isset($_POST['status']) ? $_POST['status'] : '');
    $note   = sanitize_textarea_field(isset($_POST['note']) ? $_POST['note'] : '');
    $valid  = array('submitted','under_review','ready_for_processing','approved','processing','dispatched','completed','rejected','service_not_available');
    if (!in_array($status, $valid)) wp_send_json_error(array('message' => 'Invalid status.'));
    update_post_meta($rid, 'status', $status);
    nsh_add_history($rid, 'Status updated: ' . nsh_status_label($status), $note);
    wp_send_json_success(array('status' => $status, 'label' => nsh_status_label($status)));
}

add_action('wp_ajax_nsh_set_timeline', 'nsh_ajax_set_timeline');
function nsh_ajax_set_timeline() {
    nsh_check_nonce(); nsh_require_staff();
    $rid  = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $mode = sanitize_text_field(isset($_POST['mode']) ? $_POST['mode'] : 'days');
    $note = sanitize_text_field(isset($_POST['note']) ? $_POST['note'] : '');
    if ($mode === 'days') {
        $days = intval(isset($_POST['days']) ? $_POST['days'] : 0);
        if ($days <= 0) wp_send_json_error(array('message' => 'Invalid number of days.'));
        // Use smart delivery calculator (excludes weekends + holidays)
        if (function_exists('nsh_calculate_delivery_date')) {
            $result = nsh_calculate_delivery_date($days);
            if (is_wp_error($result)) wp_send_json_error(array('message' => $result->get_error_message()));
            $date   = $result['delivery_date'];
        } else {
            $date = date('Y-m-d', strtotime('+' . $days . ' days'));
        }
    } else {
        $date = sanitize_text_field(isset($_POST['date']) ? $_POST['date'] : '');
    }
    if (!$date) wp_send_json_error(array('message' => 'Invalid date.'));
    update_post_meta($rid, 'estimated_delivery', $date);
    update_post_meta($rid, 'timeline_working_days', isset($_POST['days']) ? intval($_POST['days']) : 0);
    nsh_add_history($rid, 'Delivery date set: ' . date('d M Y', strtotime($date)) . ' (' . (isset($_POST['days']) ? intval($_POST['days']) . ' working days' : 'fixed date') . ')', $note);
    wp_send_json_success(array('formatted' => date('d M Y', strtotime($date)), 'working_days' => isset($_POST['days']) ? intval($_POST['days']) : 0));
}

add_action('wp_ajax_nsh_set_quote', 'nsh_ajax_set_quote');
function nsh_ajax_set_quote() {
    nsh_check_nonce(); nsh_require_staff();
    $rid    = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $amount = floatval(isset($_POST['amount']) ? $_POST['amount'] : 0);
    update_post_meta($rid, 'quote_amount', $amount);
    nsh_add_history($rid, 'Quote set: INR ' . number_format($amount, 2));
    wp_send_json_success();
}

add_action('wp_ajax_nsh_assign_staff', 'nsh_ajax_assign_staff');
function nsh_ajax_assign_staff() {
    nsh_check_nonce(); nsh_require_staff();
    $rid  = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $type = sanitize_text_field(isset($_POST['type']) ? $_POST['type'] : 'manager');
    $uid  = intval(isset($_POST['user_id']) ? $_POST['user_id'] : 0);
    $key  = ($type === 'vendor') ? 'assigned_vendor' : 'assigned_manager';
    update_post_meta($rid, $key, $uid);
    $u = get_userdata($uid);
    nsh_add_history($rid, ucfirst($type) . ' assigned: ' . ($u ? $u->display_name : ''));
    wp_send_json_success();
}

add_action('wp_ajax_nsh_save_note', 'nsh_ajax_save_note');
function nsh_ajax_save_note() {
    nsh_check_nonce(); nsh_require_staff();
    $rid  = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $note = sanitize_textarea_field(isset($_POST['note']) ? $_POST['note'] : '');
    update_post_meta($rid, 'internal_notes', $note);
    wp_send_json_success();
}

add_action('wp_ajax_nsh_set_secondary_status', 'nsh_ajax_set_secondary_status');
function nsh_ajax_set_secondary_status() {
    nsh_check_nonce(); nsh_require_staff();
    $rid = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $val = sanitize_text_field(isset($_POST['value']) ? $_POST['value'] : '');
    update_post_meta($rid, 'secondary_status', $val);
    wp_send_json_success();
}

// -----------------------------------------------------------
// FIELD MANAGEMENT
// -----------------------------------------------------------
add_action('wp_ajax_nsh_save_field', 'nsh_ajax_save_field');
function nsh_ajax_save_field() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $tbl  = $wpdb->prefix . 'nsh_fields';
    $id   = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    // Conditions: JSON string of conditional logic rules
    $conditions_raw = isset($_POST['conditions']) ? wp_unslash($_POST['conditions']) : '';
    $conditions_json = null;
    if ($conditions_raw) {
        $decoded = json_decode($conditions_raw, true);
        $conditions_json = (json_last_error() === JSON_ERROR_NONE && is_array($decoded)) ? wp_json_encode($decoded) : null;
    }
    // Every field belongs to exactly one service (see includes/data/services-seed.json
    // and nsh_admin_tab_fields()'s service selector) — service_id is required
    // on create, and is never changed on an edit of an existing field (the
    // field-editor UI doesn't expose moving a field to a different service).
    $service_id = intval( isset( $_POST['service_id'] ) ? $_POST['service_id'] : 0 );
    $data = array(
        'field_label'   => sanitize_text_field(isset($_POST['label'])       ? $_POST['label']       : ''),
        'field_type'    => sanitize_text_field(isset($_POST['type'])        ? $_POST['type']        : 'text'),
        // sanitize_textarea_field (not sanitize_text_field) — the latter
        // collapses/strips newlines, which would destroy the newline
        // delimiter between options the instant an admin saved the field
        // (see nsh_parse_field_options, helpers.php, for why newline and
        // not comma is the delimiter here).
        'field_options' => sanitize_textarea_field(isset($_POST['options']) ? wp_unslash($_POST['options']) : ''),
        'placeholder'   => sanitize_text_field(isset($_POST['placeholder']) ? $_POST['placeholder'] : ''),
        'description'   => sanitize_textarea_field(isset($_POST['description']) ? $_POST['description'] : ''),
        'is_required'   => intval(isset($_POST['required']) ? $_POST['required'] : 0),
        'step_number'   => intval(isset($_POST['step'])     ? $_POST['step']     : 1),
        'is_active'     => intval(isset($_POST['active'])   ? $_POST['active']   : 1),
        'conditions'    => $conditions_json,
    );
    if (!$data['field_label']) wp_send_json_error(array('message' => 'Label required.'));
    if ($id) {
        $wpdb->update($tbl, $data, array('id' => $id));
    } else {
        if ( ! $service_id || ! nsh_get_service( $service_id ) ) {
            wp_send_json_error( array( 'message' => 'Please choose a valid service before adding a field.' ) );
        }
        $key = sanitize_key(isset($_POST['key']) ? $_POST['key'] : '');
        if (!$key) wp_send_json_error(array('message' => 'Key required.'));
        $max                = (int) $wpdb->get_var( $wpdb->prepare( "SELECT MAX(sort_order) FROM $tbl WHERE service_id=%d", $service_id ) ) + 1;
        $data['field_key']  = $key;
        $data['service_id'] = $service_id;
        $data['sort_order'] = $max;
        $result = $wpdb->insert($tbl, $data);
        if (!$result) wp_send_json_error(array('message' => 'Could not save field. Key may already exist for this service.'));
        $id = $wpdb->insert_id;
    }
    wp_send_json_success(array('id' => $id));
}

add_action('wp_ajax_nsh_delete_field', 'nsh_ajax_delete_field');
function nsh_ajax_delete_field() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $wpdb->delete($wpdb->prefix . 'nsh_fields', array('id' => intval(isset($_POST['id']) ? $_POST['id'] : 0)));
    wp_send_json_success();
}

// -----------------------------------------------------------
// DROPDOWN OPTIONS CRUD
// -----------------------------------------------------------
add_action('wp_ajax_nsh_get_options_paged', 'nsh_ajax_get_options_paged');
function nsh_ajax_get_options_paged() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $key    = sanitize_key(isset($_POST['field_key']) ? $_POST['field_key'] : '');
    $search = sanitize_text_field(isset($_POST['search']) ? $_POST['search'] : '');
    $page   = max(1, intval(isset($_POST['page']) ? $_POST['page'] : 1));
    $per    = 50;
    $offset = ($page - 1) * $per;
    $tbl    = $wpdb->prefix . 'nsh_dropdown_options';
    if ($search) {
        $total = (int) $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $tbl WHERE field_key=%s AND option_value LIKE %s", $key, '%' . $wpdb->esc_like($search) . '%'
        ));
        $rows = $wpdb->get_results($wpdb->prepare(
            "SELECT id,option_value FROM $tbl WHERE field_key=%s AND option_value LIKE %s ORDER BY sort_order ASC,id ASC LIMIT %d OFFSET %d",
            $key, '%' . $wpdb->esc_like($search) . '%', $per, $offset
        ));
    } else {
        $total = (int) $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $tbl WHERE field_key=%s", $key));
        $rows  = $wpdb->get_results($wpdb->prepare(
            "SELECT id,option_value FROM $tbl WHERE field_key=%s ORDER BY sort_order ASC,id ASC LIMIT %d OFFSET %d",
            $key, $per, $offset
        ));
    }
    wp_send_json_success(array(
        'rows'  => $rows,
        'total' => $total,
        'pages' => (int) ceil($total / $per),
        'page'  => $page,
    ));
}

add_action('wp_ajax_nsh_save_option', 'nsh_ajax_save_option');
function nsh_ajax_save_option() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $tbl = $wpdb->prefix . 'nsh_dropdown_options';
    $id  = intval(isset($_POST['id']) ? $_POST['id'] : 0);
    $val = sanitize_text_field(isset($_POST['value']) ? $_POST['value'] : '');
    if (!$val) wp_send_json_error(array('message' => 'Value required.'));
    if ($id) {
        $wpdb->update($tbl, array('option_value' => $val), array('id' => $id));
    } else {
        $key = sanitize_key(isset($_POST['field_key']) ? $_POST['field_key'] : '');
        $max = (int) $wpdb->get_var($wpdb->prepare("SELECT MAX(sort_order) FROM $tbl WHERE field_key=%s", $key)) + 1;
        $wpdb->insert($tbl, array('field_key' => $key, 'option_value' => $val, 'sort_order' => $max));
        $id = $wpdb->insert_id;
    }
    wp_send_json_success(array('id' => $id, 'value' => $val));
}

add_action('wp_ajax_nsh_delete_option', 'nsh_ajax_delete_option');
function nsh_ajax_delete_option() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $wpdb->delete($wpdb->prefix . 'nsh_dropdown_options', array('id' => intval(isset($_POST['id']) ? $_POST['id'] : 0)));
    wp_send_json_success();
}

add_action('wp_ajax_nsh_bulk_delete_options', 'nsh_ajax_bulk_delete_options');
function nsh_ajax_bulk_delete_options() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $raw_ids = isset($_POST['ids']) ? (array) $_POST['ids'] : array();
    $ids     = array();
    foreach ($raw_ids as $i) {
        $i = intval($i);
        if ($i > 0) $ids[] = $i;
    }
    if (empty($ids)) wp_send_json_error(array('message' => 'No IDs provided.'));
    // Build placeholders safely without spread operator
    $placeholders = implode(',', array_fill(0, count($ids), '%d'));
    $sql  = "DELETE FROM {$wpdb->prefix}nsh_dropdown_options WHERE id IN ($placeholders)";
    $args = array_merge(array($sql), $ids);
    $wpdb->query(call_user_func_array(array($wpdb, 'prepare'), $args));
    wp_send_json_success(array('deleted' => count($ids)));
}

add_action('wp_ajax_nsh_bulk_import', 'nsh_ajax_bulk_import');
function nsh_ajax_bulk_import() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $key    = sanitize_key(isset($_POST['field_key']) ? $_POST['field_key'] : '');
    $mode   = sanitize_text_field(isset($_POST['mode'])   ? $_POST['mode']   : 'append');
    $format = sanitize_text_field(isset($_POST['format']) ? $_POST['format'] : 'lines');
    $raw    = isset($_POST['raw_data']) ? wp_unslash($_POST['raw_data']) : '';
    $values = array();

    if (!empty($_FILES['csv_file']['tmp_name'])) {
        $handle = fopen($_FILES['csv_file']['tmp_name'], 'r');
        if ($handle) {
            while (($row = fgetcsv($handle)) !== false) {
                $v = isset($row[0]) ? trim($row[0]) : '';
                if ($v) $values[] = $v;
            }
            fclose($handle);
        }
    } elseif ($raw) {
        if ($format === 'json') {
            $arr = json_decode($raw, true);
            if (is_array($arr)) {
                foreach ($arr as $v) {
                    $v = trim(strval($v));
                    if ($v) $values[] = $v;
                }
            }
        } elseif ($format === 'comma') {
            foreach (explode(',', $raw) as $v) {
                $v = trim($v);
                if ($v) $values[] = $v;
            }
        } else {
            foreach (preg_split('/\r\n|\r|\n/', $raw) as $v) {
                $v = trim($v);
                if ($v) $values[] = $v;
            }
        }
    }

    $values = array_unique($values);
    if (empty($values)) wp_send_json_error(array('message' => 'No values found.'));

    $tbl = $wpdb->prefix . 'nsh_dropdown_options';
    if ($mode === 'replace') $wpdb->delete($tbl, array('field_key' => $key));
    $max = (int) $wpdb->get_var($wpdb->prepare("SELECT MAX(sort_order) FROM $tbl WHERE field_key=%s", $key));
    foreach ($values as $v) {
        $wpdb->insert($tbl, array('field_key' => $key, 'option_value' => sanitize_text_field($v), 'sort_order' => ++$max));
    }
    wp_send_json_success(array('imported' => count($values), 'mode' => $mode));
}

// -----------------------------------------------------------
// SETTINGS
// -----------------------------------------------------------
add_action('wp_ajax_nsh_save_settings', 'nsh_ajax_save_settings');
function nsh_ajax_save_settings() {
    nsh_check_nonce(); nsh_require_staff();
    $keys = array(
        'nsh_bank_name','nsh_bank_account_name','nsh_bank_account_number',
        'nsh_bank_ifsc','nsh_bank_swift','nsh_bank_instructions',
        'nsh_platform_name','nsh_email_from','nsh_email_name','nsh_manager_name','nsh_manager_phone','nsh_manager_email',
        'nsh_disclaimer_phone',
    );
    // Email-type fields get sanitize_email(), not sanitize_text_field() —
    // the latter only strips tags/line-breaks, so a stray space or typo'd
    // address still saves as-is and silently breaks admin notifications
    // (see nsh_admin_notification_email()'s docblock in notifications.php
    // for the failure this caused). sanitize_email() actively rejects
    // anything not shaped like an address, so a bad value never gets
    // saved as though it were good in the first place.
    $email_keys = array( 'nsh_email_from', 'nsh_manager_email' );
    foreach ($keys as $k) {
        if (isset($_POST[$k])) {
            $v = in_array( $k, $email_keys, true ) ? sanitize_email( $_POST[$k] ) : sanitize_text_field( $_POST[$k] );
            update_option($k, $v);
        }
    }
    wp_send_json_success();
}

/**
 * Settings -> Bot Protection (see nsh_settings_captcha() in
 * admin-settings-integrated.php). Separate action/handler from the
 * generic nsh_save_settings above — that one's key list is a flat
 * sanitize_text_field() pass, fine for plain display strings, but the
 * secret key here is a credential (never echoed back to the page except
 * as a masked placeholder — see nsh_settings_captcha()), so it gets its
 * own small, explicit handler rather than being folded into the generic
 * one.
 */
add_action( 'wp_ajax_nsh_save_captcha_settings', 'nsh_ajax_save_captcha_settings' );
function nsh_ajax_save_captcha_settings() {
    nsh_check_nonce(); nsh_require_staff();

    // Which provider is active — 'builtin' (self-hosted, default) or
    // 'turnstile' (Cloudflare). Both providers' settings are saved
    // together below regardless of which is currently selected, so
    // switching back and forth never loses the other provider's config.
    $provider = isset( $_POST['provider'] ) && sanitize_text_field( wp_unslash( $_POST['provider'] ) ) === 'turnstile' ? 'turnstile' : 'builtin';
    update_option( 'nsh_captcha_provider', $provider );

    // Built-in provider settings.
    update_option( 'nsh_captcha_builtin_enabled', ! empty( $_POST['builtin_enabled'] ) ? 1 : 0 );
    if ( isset( $_POST['builtin_min_seconds'] ) ) {
        $min_seconds = intval( $_POST['builtin_min_seconds'] );
        if ( $min_seconds < 0 )  { $min_seconds = 0; }
        if ( $min_seconds > 60 ) { $min_seconds = 60; }
        update_option( 'nsh_captcha_builtin_min_seconds', $min_seconds );
    }

    // Cloudflare Turnstile settings.
    update_option( 'nsh_turnstile_enabled', ! empty( $_POST['enabled'] ) ? 1 : 0 );
    if ( isset( $_POST['site_key'] ) ) {
        update_option( 'nsh_turnstile_site_key', sanitize_text_field( wp_unslash( $_POST['site_key'] ) ) );
    }
    // Blank secret-key submission means "leave the existing one alone"
    // (the field is rendered blank with a masked placeholder whenever a
    // real key is already stored — see nsh_settings_captcha() — exactly
    // like the existing SMTP password field's own leave-blank-to-keep
    // convention), so only overwrite it when something was actually typed.
    if ( isset( $_POST['secret_key'] ) && trim( (string) $_POST['secret_key'] ) !== '' ) {
        update_option( 'nsh_turnstile_secret_key', sanitize_text_field( wp_unslash( $_POST['secret_key'] ) ) );
    }
    wp_send_json_success();
}

/* ============================================================
   FIELD REORDERING - Drag-and-Drop (SortableJS)
   ============================================================ */
add_action( 'wp_ajax_nsh_move_field', 'nsh_ajax_move_field' ); // kept for back-compat
function nsh_ajax_move_field() {
    nsh_check_nonce(); nsh_require_staff();
    wp_send_json_success(); // no-op; replaced by nsh_reorder_fields
}

add_action( 'wp_ajax_nsh_reorder_fields', 'nsh_ajax_reorder_fields' );
function nsh_ajax_reorder_fields() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $ids = isset( $_POST['ids'] ) ? array_map( 'intval', (array) $_POST['ids'] ) : array();
    if ( empty( $ids ) ) { wp_send_json_error( array( 'message' => 'No IDs provided.' ) ); }
    $tbl = $wpdb->prefix . 'nsh_fields';
    foreach ( $ids as $order => $id ) {
        $wpdb->update( $tbl, array( 'sort_order' => $order + 1 ), array( 'id' => $id ) );
    }
    wp_send_json_success( array( 'message' => 'Order saved.' ) );
}

/* ============================================================
   DELETE REQUEST (Admin only)
   ============================================================ */
add_action( 'wp_ajax_nsh_delete_request', 'nsh_ajax_delete_request' );
function nsh_ajax_delete_request() {
    nsh_check_nonce(); nsh_require_staff();
    $rid  = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    $hard = ! empty( $_POST['hard_delete'] );
    if ( ! $rid || ! nsh_delete_request_by_id( $rid, $hard ) ) {
        wp_send_json_error( array( 'message' => 'Could not delete this request.' ) );
    }
    wp_send_json_success();
}

/**
 * Shared delete logic for a single request (used by both the single-delete
 * and bulk-delete AJAX handlers so behavior — including cleanup of the
 * request's own tickets/messages/uploaded documents — never drifts between
 * the two entry points).
 */
function nsh_delete_request_by_id( $rid, $hard = true ) {
    global $wpdb;
    $post = get_post( $rid );
    if ( ! $post || $post->post_type !== 'nsh_request' ) { return false; }

    if ( $hard ) {
        // Remove uploaded documents (media attachments) before the post
        // itself, so nothing is left behind in the media library.
        $docs = nsh_get_documents( $rid );
        foreach ( $docs as $d ) {
            $att_id = isset( $d['file'] ) ? intval( $d['file'] ) : 0;
            if ( $att_id ) { wp_delete_attachment( $att_id, true ); }
        }
        wp_delete_post( $rid, true );
        $wpdb->delete( $wpdb->prefix . 'nsh_tickets',  array( 'request_id' => $rid ) );
        $wpdb->delete( $wpdb->prefix . 'nsh_messages', array( 'request_id' => $rid ) );
        nsh_flush_request_search_cache();
    } else {
        wp_trash_post( $rid );
        nsh_flush_request_search_cache();
    }
    return true;
}

/**
 * Bulk delete — shared by the Requests tab and the Form Submissions tab,
 * since "submissions" are the same nsh_request posts viewed differently.
 * Deletes what it can and reports back exactly which ids (if any) failed,
 * rather than silently succeeding or aborting the whole batch on one bad id.
 */
add_action( 'wp_ajax_nsh_bulk_delete_requests', 'nsh_ajax_bulk_delete_requests' );
function nsh_ajax_bulk_delete_requests() {
    nsh_check_nonce(); nsh_require_staff();
    $ids = isset( $_POST['request_ids'] ) ? (array) $_POST['request_ids'] : array();
    $ids = array_filter( array_map( 'intval', $ids ) );
    if ( empty( $ids ) ) { wp_send_json_error( array( 'message' => 'No requests selected.' ) ); }

    $deleted = array();
    $failed  = array();
    foreach ( $ids as $rid ) {
        if ( nsh_delete_request_by_id( $rid, true ) ) { $deleted[] = $rid; }
        else { $failed[] = $rid; }
    }
    wp_send_json_success( array(
        'deleted_count' => count( $deleted ),
        'failed_ids'    => $failed,
        'message'       => count( $deleted ) . ' request' . ( count( $deleted ) === 1 ? '' : 's' ) . ' deleted.' . ( $failed ? ' ' . count( $failed ) . ' could not be deleted.' : '' ),
    ) );
}

/**
 * Bulk delete support tickets. Single-ticket delete (nsh_ajax_delete_ticket,
 * above) already exists; this reuses the exact same underlying $wpdb->delete
 * call, looped, so behavior stays identical between single and bulk.
 */
add_action( 'wp_ajax_nsh_bulk_delete_tickets', 'nsh_ajax_bulk_delete_tickets' );
function nsh_ajax_bulk_delete_tickets() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $ids = isset( $_POST['ticket_ids'] ) ? (array) $_POST['ticket_ids'] : array();
    $ids = array_filter( array_map( 'intval', $ids ) );
    if ( empty( $ids ) ) { wp_send_json_error( array( 'message' => 'No tickets selected.' ) ); }

    $deleted = 0;
    foreach ( $ids as $tid ) {
        $deleted += (int) $wpdb->delete( $wpdb->prefix . 'nsh_tickets', array( 'id' => $tid ) );
    }
    wp_send_json_success( array(
        'deleted_count' => $deleted,
        'message'       => $deleted . ' ticket' . ( $deleted === 1 ? '' : 's' ) . ' deleted.',
    ) );
}

/**
 * Delete one or more uploaded documents ("Form Files") from a request:
 * removes them from the media library (so nothing is orphaned on disk)
 * AND from the request's `documents` postmeta so they stop appearing in
 * both the admin request-detail view and the Form Submissions modal.
 */
add_action( 'wp_ajax_nsh_delete_documents', 'nsh_ajax_delete_documents' );
function nsh_ajax_delete_documents() {
    nsh_check_nonce(); nsh_require_staff();
    $rid = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    $att_ids = isset( $_POST['att_ids'] ) ? (array) $_POST['att_ids'] : array();
    $att_ids = array_filter( array_map( 'intval', $att_ids ) );
    if ( ! $rid || empty( $att_ids ) ) { wp_send_json_error( array( 'message' => 'Nothing selected to delete.' ) ); }

    $post = get_post( $rid );
    if ( ! $post || $post->post_type !== 'nsh_request' ) { wp_send_json_error( array( 'message' => 'Request not found.' ) ); }

    $docs = nsh_get_documents( $rid );
    $kept = array();
    $removed = 0;
    foreach ( $docs as $d ) {
        $att_id = isset( $d['file'] ) ? intval( $d['file'] ) : 0;
        if ( $att_id && in_array( $att_id, $att_ids, true ) ) {
            wp_delete_attachment( $att_id, true );
            $removed++;
        } else {
            $kept[] = $d;
        }
    }
    update_post_meta( $rid, 'documents', $kept );
    if ( $removed ) { nsh_add_history( $rid, $removed . ' document(s) deleted by staff' ); }

    wp_send_json_success( array(
        'removed_count'   => $removed,
        'remaining_count' => count( $kept ),
        'message'         => $removed . ' file' . ( $removed === 1 ? '' : 's' ) . ' deleted.',
    ) );
}

/* ============================================================
   ADMIN DASHBOARD — SPA-STYLE TAB / DETAIL LOADING
   Lets the admin dashboard switch tabs and open a request's detail
   view without a full WordPress page reload: these handlers return
   exactly the same markup the equivalent full-page render would
   produce (by calling the very same PHP render functions), so there
   is only one source of truth for each screen's HTML.
   ============================================================ */
add_action( 'wp_ajax_nsh_admin_load_tab', 'nsh_ajax_admin_load_tab' );
function nsh_ajax_admin_load_tab() {
    nsh_check_nonce(); nsh_require_staff();
    $valid_tabs = array( 'requests', 'submissions', 'support', 'fields', 'dropdowns', 'bulk', 'types', 'settings' );
    $tab = sanitize_text_field( isset( $_POST['tab'] ) ? $_POST['tab'] : 'requests' );
    if ( ! in_array( $tab, $valid_tabs, true ) ) { $tab = 'requests'; }
    if ( ! nsh_plat_tab_allowed( $tab ) ) { wp_send_json_error( array( 'message' => 'Your account cannot open this section.' ), 403 ); }

    switch ( $tab ) {
        case 'requests':    $html = nsh_admin_tab_requests();    break;
        case 'submissions': $html = nsh_admin_tab_submissions(); break;
        case 'support':     $html = nsh_admin_tab_support();     break;
        case 'fields':      $html = nsh_admin_tab_fields();      break;
        case 'dropdowns':   $html = nsh_admin_tab_dropdowns();   break;
        case 'bulk':        $html = nsh_admin_tab_bulk();        break;
        case 'types':       $html = nsh_admin_tab_types();       break;
        case 'settings':    $html = nsh_admin_tab_settings();    break;
        default:            $html = nsh_admin_tab_requests();
    }
    // The Requests tab relies on nsh_admin_js() (loaded once on first
    // page load) for its list-loading logic, so it doesn't need its
    // script re-sent; other tabs carry their own inline <script> as
    // part of their render function already.
    wp_send_json_success( array( 'tab' => $tab, 'html' => $html ) );
}

add_action( 'wp_ajax_nsh_admin_load_request_detail', 'nsh_ajax_admin_load_request_detail' );
function nsh_ajax_admin_load_request_detail() {
    nsh_check_nonce(); nsh_require_staff();
    $rid = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    if ( ! $rid ) { wp_send_json_error( array( 'message' => 'Invalid request.' ) ); }
    $post = get_post( $rid );
    if ( ! $post || $post->post_type !== 'nsh_request' ) { wp_send_json_error( array( 'message' => 'Request not found.' ) ); }
    wp_send_json_success( array( 'html' => nsh_render_request_view( $rid, true ) ) );
}

/* ============================================================
   CLIENT DASHBOARD — SPA-STYLE TAB / DETAIL LOADING
   Same idea as the admin endpoints above (see the block comment there),
   applied to the client dashboard's own two tabs (Dashboard/Profile) and
   its request-detail view — clients get the same no-full-reload, no
   forced-scroll-jump navigation admins do. Only login is required (not
   staff); nsh_render_request_view()'s own nsh_is_own_request() check is
   still the real access-control gate for the detail view, same as it
   already was for the standalone /nsh-request/{id} page.
   ============================================================ */
add_action( 'wp_ajax_nsh_client_load_tab', 'nsh_ajax_client_load_tab' );
function nsh_ajax_client_load_tab() {
    nsh_check_nonce();
    if ( ! is_user_logged_in() ) { wp_send_json_error( array( 'message' => 'Please log in.' ), 401 ); }
    $valid_tabs = array( 'dashboard', 'profile' );
    $tab = sanitize_text_field( isset( $_POST['tab'] ) ? $_POST['tab'] : 'dashboard' );
    if ( ! in_array( $tab, $valid_tabs, true ) ) { $tab = 'dashboard'; }
    wp_send_json_success( array( 'tab' => $tab, 'html' => nsh_render_client_tab( $tab ) ) );
}

add_action( 'wp_ajax_nsh_client_load_request_detail', 'nsh_ajax_client_load_request_detail' );
function nsh_ajax_client_load_request_detail() {
    nsh_check_nonce();
    if ( ! is_user_logged_in() ) { wp_send_json_error( array( 'message' => 'Please log in.' ), 401 ); }
    $rid = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    if ( ! $rid ) { wp_send_json_error( array( 'message' => 'Invalid request.' ) ); }
    $post = get_post( $rid );
    if ( ! $post || $post->post_type !== 'nsh_request' ) { wp_send_json_error( array( 'message' => 'Request not found.' ) ); }
    // nsh_render_request_view() itself returns an "Access denied." fragment
    // (not a JSON error) for a request that isn't this user's own — same
    // behavior the standalone page always had, just reused here.
    wp_send_json_success( array( 'html' => nsh_render_request_view( $rid, true ) ) );
}

/* ============================================================
   CLIENT PROFILE UPDATE
   ============================================================ */
add_action( 'wp_ajax_nsh_update_profile', 'nsh_ajax_update_profile' );
function nsh_ajax_update_profile() {
    nsh_check_nonce();
    if ( ! is_user_logged_in() ) { wp_send_json_error( array( 'message' => 'Not logged in.' ), 401 ); }

    $uid          = get_current_user_id();
    $display_name = sanitize_text_field( isset( $_POST['display_name'] ) ? $_POST['display_name'] : '' );
    $phone        = sanitize_text_field( isset( $_POST['phone'] )        ? $_POST['phone']        : '' );
    $address      = sanitize_text_field( isset( $_POST['address'] )      ? $_POST['address']      : '' );
    $new_pass     = isset( $_POST['new_password'] )    ? $_POST['new_password']    : '';
    $confirm_pass = isset( $_POST['confirm_password'] ) ? $_POST['confirm_password'] : '';

    $data = array( 'ID' => $uid );
    if ( $display_name ) { $data['display_name'] = $display_name; }

    if ( $new_pass ) {
        if ( $new_pass !== $confirm_pass ) { wp_send_json_error( array( 'message' => 'Passwords do not match.' ) ); }
        if ( strlen( $new_pass ) < 8 )    { wp_send_json_error( array( 'message' => 'Password must be at least 8 characters.' ) ); }
        $data['user_pass'] = $new_pass;
    }

    $result = wp_update_user( $data );
    if ( is_wp_error( $result ) ) { wp_send_json_error( array( 'message' => $result->get_error_message() ) ); }

    if ( $phone )   { update_user_meta( $uid, 'nsh_phone',   $phone ); }
    if ( $address ) { update_user_meta( $uid, 'nsh_address', $address ); }

    wp_send_json_success( array( 'message' => 'Profile updated successfully.' ) );
}

/* ============================================================
   SUPPORT TICKET SUBMIT (separate from service requests)
   ============================================================ */
add_action( 'wp_ajax_nsh_submit_support',        'nsh_ajax_submit_support' );
add_action( 'wp_ajax_nopriv_nsh_submit_support', 'nsh_ajax_submit_support' );
function nsh_ajax_submit_support() {
    nsh_check_nonce();
    global $wpdb;
    $cat   = sanitize_text_field( isset( $_POST['category'] )    ? $_POST['category']    : '' );
    $desc  = sanitize_textarea_field( isset( $_POST['description'] ) ? $_POST['description'] : '' );
    $email = sanitize_email( isset( $_POST['email'] )            ? $_POST['email']        : '' );
    $uid   = get_current_user_id();

    if ( ! $cat )  { wp_send_json_error( array( 'message' => 'Please select a category.' ) ); }
    if ( ! $desc ) { wp_send_json_error( array( 'message' => 'Please describe your issue.' ) ); }

    if ( ! $uid && $email ) {
        $u = get_user_by( 'email', $email );
        if ( $u ) { $uid = $u->ID; }
    }

    $wpdb->insert( $wpdb->prefix . 'nsh_tickets', array(
        'request_id' => 0,
        'user_id'    => $uid,
        'type_id'    => 0,
        'category'   => $cat,
        'status'     => 'open',
        'notes'      => $desc,
    ) );
    $tid = $wpdb->insert_id;

    // Handle file attachment
    if ( ! empty( $_FILES['support_file']['tmp_name'] ) && $uid ) {
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        media_handle_upload( 'support_file', 0 );
    }

    wp_send_json_success( array( 'ticket_id' => $tid, 'message' => 'Support request submitted successfully.' ) );
}

/* ============================================================
   GET SUPPORT TICKETS (Admin)
   ============================================================ */
add_action( 'wp_ajax_nsh_get_support_tickets', 'nsh_ajax_get_support_tickets' );
function nsh_ajax_get_support_tickets() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $status = sanitize_text_field( isset( $_POST['status'] ) ? $_POST['status'] : '' );
    $where  = $status ? $wpdb->prepare( 'WHERE status=%s AND request_id=0', $status ) : 'WHERE request_id=0';
    $rows   = $wpdb->get_results( "SELECT t.*, u.display_name, u.user_email FROM {$wpdb->prefix}nsh_tickets t LEFT JOIN {$wpdb->prefix}users u ON t.user_id=u.ID $where ORDER BY t.created_at DESC" );
    wp_send_json_success( $rows );
}

/* ============================================================
   ASSIGN VENDOR / MANAGER - Save button + WA trigger
   ============================================================ */

// Override the existing nsh_assign_staff to also fire WA hooks
remove_action('wp_ajax_nsh_assign_staff', 'nsh_ajax_assign_staff');
add_action('wp_ajax_nsh_assign_staff', 'nsh_ajax_assign_staff_v2');
function nsh_ajax_assign_staff_v2() {
    nsh_check_nonce(); nsh_require_staff();
    $rid  = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $type = sanitize_text_field(isset($_POST['type']) ? $_POST['type'] : 'manager');
    $uid  = intval(isset($_POST['user_id']) ? $_POST['user_id'] : 0);
    $key  = ($type === 'vendor') ? 'assigned_vendor' : 'assigned_manager';
    $old  = get_post_meta($rid, $key, true);
    update_post_meta($rid, $key, $uid);
    $u    = get_userdata($uid);
    $name = $u ? $u->display_name : 'Unknown';
    nsh_add_history($rid, ucfirst($type) . ' assigned: ' . $name);

    // Fire WhatsApp hook when vendor is assigned/changed
    if ($type === 'vendor' && $uid && $uid != $old) {
        do_action('nsh_after_vendor_assigned', $rid, $uid);
    }

    wp_send_json_success(['message' => ucfirst($type) . ' assigned: ' . $name, 'name' => $name]);
}

// Trigger WA on status change
remove_action('wp_ajax_nsh_update_status', 'nsh_ajax_update_status');
add_action('wp_ajax_nsh_update_status', 'nsh_ajax_update_status_v2');
function nsh_ajax_update_status_v2() {
    nsh_check_nonce(); nsh_require_staff();
    $rid    = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $status = sanitize_text_field(isset($_POST['status']) ? $_POST['status'] : '');
    $note   = sanitize_textarea_field(isset($_POST['note']) ? $_POST['note'] : '');
    $valid  = array('submitted','under_review','ready_for_processing','approved','processing','dispatched','completed','rejected','service_not_available');
    if (!in_array($status, $valid)) wp_send_json_error(array('message' => 'Invalid status.'));
    update_post_meta($rid, 'status', $status);
    nsh_add_history($rid, 'Status updated: ' . nsh_status_label($status), $note);
    do_action('nsh_after_status_changed', $rid, $status);
    // Automated email: notify client of status change
    if (function_exists('nsh_notify_status_change')) {
        nsh_notify_status_change($rid, $status);
    }
    wp_send_json_success(array('status' => $status, 'label' => nsh_status_label($status)));
}

// Trigger WA on payment set
remove_action('wp_ajax_nsh_set_quote', 'nsh_ajax_set_quote');
add_action('wp_ajax_nsh_set_quote', 'nsh_ajax_set_quote_v2');
function nsh_ajax_set_quote_v2() {
    nsh_check_nonce(); nsh_require_staff();
    $rid    = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $amount = floatval(isset($_POST['amount']) ? $_POST['amount'] : 0);
    $notify = !empty($_POST['notify_vendor']);
    update_post_meta($rid, 'quote_amount', $amount);
    nsh_add_history($rid, 'Quote set: INR ' . number_format($amount, 2));
    if ($notify) do_action('nsh_after_payment_set', $rid);
    // Auto-send quotation email with T&C if checkbox ticked
    $send_quote_email = !empty($_POST['send_quote_email']);
    $include_terms    = !empty($_POST['include_terms']);
    if ($send_quote_email && function_exists('nsh_notify_quotation')) {
        nsh_notify_quotation($rid, $include_terms);
        nsh_add_history($rid, 'Quotation email sent to client');
    }
    wp_send_json_success();
}

// v6.2.1: Set Shipping Charges
add_action('wp_ajax_nsh_set_shipping', 'nsh_ajax_set_shipping');
function nsh_ajax_set_shipping() {
    nsh_check_nonce(); nsh_require_staff();
    $rid = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $amount = floatval(isset($_POST['amount']) ? $_POST['amount'] : 0);
    $type = sanitize_text_field(isset($_POST['type']) ? $_POST['type'] : 'domestic');
    
    if (!$rid) {
        wp_send_json_error('Invalid request ID');
    }
    
    update_post_meta($rid, 'shipping_charges', $amount);
    update_post_meta($rid, 'shipping_type', $type);
    nsh_add_history($rid, 'Shipping charges set: ₹' . number_format($amount, 2) . ' (' . ucfirst($type) . ')');
    
    wp_send_json_success(array(
        'amount' => $amount,
        'type' => $type,
        'message' => 'Shipping charges updated'
    ));
}

/* ============================================================
   VENDOR PROFILE LISTING FOR ADMIN (dropdown in request view)
   ============================================================ */

add_action('wp_ajax_nsh_get_vendors_list', 'nsh_ajax_get_vendors_list');
function nsh_ajax_get_vendors_list() {
    nsh_check_nonce(); nsh_require_staff();
    global $wpdb;
    $vendors = $wpdb->get_results("SELECT id, name, phone, whatsapp, work_types, status FROM {$wpdb->prefix}nsh_vendors WHERE status='active' ORDER BY name ASC");
    $out = [];
    foreach ($vendors as $v) {
        $out[] = [
            'id'         => $v->id,
            'name'       => $v->name,
            'phone'      => $v->phone,
            'whatsapp'   => $v->whatsapp,
            'work_types' => $v->work_types,
        ];
    }
    wp_send_json_success($out);
}

// -----------------------------------------------------------
// GET FIELD OPTIONS  used by conditional logic value selector
// -----------------------------------------------------------
add_action('wp_ajax_nsh_get_field_options',        'nsh_ajax_get_field_options');
add_action('wp_ajax_nopriv_nsh_get_field_options', 'nsh_ajax_get_field_options');
function nsh_ajax_get_field_options() {
    nsh_check_nonce();
    $key   = sanitize_key(isset($_POST['field_key']) ? $_POST['field_key'] : '');
    if (!$key) { wp_send_json_error(array('message' => 'No field key.')); return; }
    global $wpdb;
    $field = $wpdb->get_row($wpdb->prepare(
        "SELECT field_type, field_options FROM {$wpdb->prefix}nsh_fields WHERE field_key=%s LIMIT 1", $key
    ));
    $options = array();
    if ($field) {
        if (in_array($field->field_type, array('dropdown','searchable','radio'), true)) {
            // First get options from dropdown_options table
            $db_opts = nsh_get_dropdown_options($key);
            if ($db_opts) {
                $options = $db_opts;
            } elseif ($field->field_options) {
                // Fallback: field_options column, via the one shared parser
                // (nsh_parse_field_options, helpers.php) every other reader
                // of this column also uses.
                $options = nsh_parse_field_options($field->field_options);
            }
        }
    }
    wp_send_json_success(array(
        'options'    => $options,
        'field_type' => $field ? $field->field_type : '',
        'has_options'=> !empty($options),
    ));
}

// ── COMMUNICATION PANEL: Send Email ────────────────────────────────────────
add_action( 'wp_ajax_nsh_send_comm_email', 'nsh_ajax_send_comm_email' );
function nsh_ajax_send_comm_email() {
    nsh_check_nonce();
    nsh_require_staff();

    $rid         = intval( $_POST['request_id'] ?? 0 );
    $subject     = sanitize_text_field( $_POST['subject'] ?? '' );
    $body        = sanitize_textarea_field( $_POST['body'] ?? '' );
    $log_message = ! empty( $_POST['log_message'] );

    if ( ! $rid || ! $subject || ! $body ) {
        wp_send_json_error( array( 'message' => 'Subject and message are required.' ) );
    }
    if ( ! nsh_is_own_request( $rid ) ) {
        wp_send_json_error( array( 'message' => 'Access denied.' ), 403 );
    }

    $post   = get_post( $rid );
    $client = $post ? get_userdata( $post->post_author ) : null;
    if ( ! $client || ! $client->user_email ) {
        wp_send_json_error( array( 'message' => 'No recipient email found for this request.' ) );
    }

    $sender = wp_get_current_user();
    $rid_label = get_post_meta( $rid, 'request_id', true ) ?: '#' . $rid;

    // Build headers — only add custom From when a valid address is configured
    $headers = array( 'Content-Type: text/html; charset=UTF-8' );
    $from_name  = get_option( 'nsh_email_name', get_bloginfo( 'name' ) );
    $from_email = get_option( 'nsh_email_from', '' );
    if ( $from_email && is_email( $from_email ) ) {
        $headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
    }

    // Wrap body using the same branded HTML template used by all platform emails
    $req_url = nsh_request_url( $rid );

    // Split on blank lines into paragraphs; preserve single line breaks within each
    $raw_paragraphs = preg_split( '/\n{2,}/', trim( $body ) );
    $paragraphs = array();
    foreach ( $raw_paragraphs as $para ) {
        $para = trim( $para );
        if ( $para !== '' ) {
            $paragraphs[] = nl2br( esc_html( $para ) );
        }
    }
    if ( empty( $paragraphs ) ) {
        $paragraphs[] = nl2br( esc_html( trim( $body ) ) );
    }

    $html_body = nsh_html_email(
        'Dear ' . $client->display_name . ',',
        $paragraphs,
        $rid_label,
        $req_url,
        'View Your Request'
    );

    $sent = wp_mail( $client->user_email, $subject, $html_body, $headers );

    if ( ! $sent ) {
        // Capture last WordPress mail error for a more useful message
        global $phpmailer;
        $smtp_err = '';
        if ( isset( $phpmailer ) && is_object( $phpmailer ) && ! empty( $phpmailer->ErrorInfo ) ) {
            $smtp_err = ' SMTP error: ' . $phpmailer->ErrorInfo;
        }
        nsh_log( 'nsh_send_comm_email: wp_mail failed. To=' . $client->user_email . ' Subject=' . $subject . $smtp_err );
        wp_send_json_error( array(
            'message' => 'Failed to send email.' . ( $smtp_err ? $smtp_err : ' Check WordPress SMTP/mail settings.' ),
        ) );
    }

    // Optionally log message to history
    global $wpdb;
    $mid = null;
    if ( $log_message ) {
        $wpdb->insert( $wpdb->prefix . 'nsh_messages', array(
            'request_id'    => $rid,
            'sender_id'     => $sender->ID,
            'message'       => '[Email] ' . $subject . "\n\n" . $body,
            'is_email_sent' => 1,
        ) );
        $mid = $wpdb->insert_id;
    }

    nsh_add_history( $rid, 'Email sent by ' . $sender->display_name . ' to ' . $client->user_email );
    nsh_log( 'Communication email sent from ' . $sender->display_name . ' to ' . $client->user_email . ' for request ' . $rid );

    wp_send_json_success( array(
        'message'   => 'Email sent successfully to ' . $client->user_email,
        'logged'    => $log_message,
        'msg_id'    => $mid,
        'sent_time' => current_time( 'd M Y, g:i a' ),
        'sender'    => $sender->display_name,
    ) );
}

// ── COMMUNICATION PANEL: Get Email Template Body ────────────────────────────
add_action( 'wp_ajax_nsh_get_comm_template', 'nsh_ajax_get_comm_template' );
function nsh_ajax_get_comm_template() {
    nsh_check_nonce();
    nsh_require_staff();

    $rid           = intval( $_POST['request_id'] ?? 0 );
    $template_type = sanitize_key( $_POST['template_type'] ?? '' );

    if ( ! $rid || ! $template_type ) {
        wp_send_json_error( array( 'message' => 'Invalid parameters.' ) );
    }

    $post   = get_post( $rid );
    $client = $post ? get_userdata( $post->post_author ) : null;
    $meta   = nsh_get_meta( $rid );
    $fd     = $meta['field_data'];

    $client_name  = $client ? $client->display_name : 'Client';
    $rid_label    = get_post_meta( $rid, 'request_id', true ) ?: '#' . $rid;
    $platform     = get_option( 'nsh_platform_name', get_bloginfo( 'name' ) );

    // 'quotation', 'status_update' and 'document_reminder' used to have their
    // OWN separate hardcoded copies here — a THIRD, independent copy of the
    // same content that also lives in notifications.php's hardcoded builders
    // and in email-templates.php's admin-editable templates. That meant even
    // this manual "Communication Panel" compose box ignored a saved custom
    // template for those three types, same root cause as the automatic
    // notifications (see nsh_custom_template_email() in notifications.php).
    // Only 'general' stays hardcoded here — it isn't one of the Email
    // Templates types, so there's nothing in email-templates.php for it to
    // fall through to.
    $templates = array(
        'general' => array(
            'subject' => 'Update Regarding Order #' . $rid_label,
            'body'    => "Dear {CLIENT_NAME},\n\nGreetings for the day!\n\nWe are writing to you regarding your request (Order ID: {REQUEST_ID}).\n\n[Your message here]\n\nIf you have any questions or need further assistance, please feel free to contact us.\n\nWarm Regards,\n{PLATFORM}",
        ),
    );

    if ( ! isset( $templates[ $template_type ] ) ) {
        // Routes 'quotation', 'status_update', 'document_reminder', and any
        // other Email Templates type (including custom ones the admin
        // created) through the real template system: saved custom content
        // when the admin has saved one, otherwise that type's own default —
        // never a stale hardcoded copy.
        $tpl = nsh_get_email_template( $template_type, array(
            'CUSTOMER_NAME'  => $client_name,
            'REQUEST_ID'     => $rid_label,
        ) );
        if ( $tpl ) {
            wp_send_json_success( $tpl );
        }
        wp_send_json_error( array( 'message' => 'Template not found.' ) );
    }

    $tpl = $templates[ $template_type ];

    // Replace variables
    $quote    = $meta['quote_amount'] ?: 'To be updated';
    $shipping = isset( $meta['shipping_charges'] ) ? $meta['shipping_charges'] : '0';
    $timeline = '';
    if ( ! empty( $meta['estimated_delivery'] ) ) {
        $timeline = date( 'd M Y', strtotime( $meta['estimated_delivery'] ) );
    }
    $status_label = nsh_status_label( $meta['status'] );

    $replacements = array(
        '{CLIENT_NAME}'     => $client_name,
        '{REQUEST_ID}'      => $rid_label,
        '{QUOTE_AMOUNT}'    => $quote,
        '{SHIPPING}'        => $shipping,
        '{TIMELINE}'        => $timeline ?: 'To be updated',
        '{STATUS}'          => $status_label,
        '{PLATFORM}'        => $platform,
        '{DOCUMENT_TYPE}'   => ! empty( $meta['service_name'] ) ? $meta['service_name']
                             : ( ! empty( $fd['field_document_type'] ) ? $fd['field_document_type']
                             : ( ! empty( $fd['field_service_type'] ) ? $fd['field_service_type'] : 'Document Service' ) ),
        '{UNIVERSITY_NAME}' => ! empty( $fd['field_university_name'] ) ? $fd['field_university_name'] : '',
        '{CUSTOMER_NAME}'   => $client_name,
        '{DELIVERY_DATE}'   => $timeline ?: 'To be updated',
    );

    $tpl['subject'] = str_replace( array_keys( $replacements ), array_values( $replacements ), $tpl['subject'] );
    $tpl['body']    = str_replace( array_keys( $replacements ), array_values( $replacements ), $tpl['body'] );

    wp_send_json_success( $tpl );
}

// ── Quick email actions from staff panel ────────────────────────────────────
add_action('wp_ajax_nsh_send_doc_reminder', 'nsh_ajax_send_doc_reminder');
function nsh_ajax_send_doc_reminder() {
    nsh_check_nonce(); nsh_require_staff();
    $rid  = intval($_POST['request_id'] ?? 0);
    $note = sanitize_textarea_field($_POST['note'] ?? '');
    if (!$rid) wp_send_json_error(array('message' => 'Invalid request.'));
    $sent = nsh_notify_document_reminder($rid, $note);
    if ($sent) {
        nsh_add_history($rid, 'Document reminder email sent to client');
        wp_send_json_success(array('message' => 'Document reminder sent successfully.'));
    } else {
        $post   = get_post($rid);
        $client = $post ? get_userdata($post->post_author) : null;
        $to_email = $client ? $client->user_email : 'unknown';
        nsh_log('nsh_send_doc_reminder: failed. rid=' . $rid . ' recipient=' . $to_email);
        wp_send_json_error(array('message' => 'Failed to send email to ' . $to_email . '. Check WordPress SMTP / mail plugin settings.'));
    }
}

add_action('wp_ajax_nsh_send_status_email', 'nsh_ajax_send_status_email');
function nsh_ajax_send_status_email() {
    nsh_check_nonce(); nsh_require_staff();
    $rid = intval($_POST['request_id'] ?? 0);
    if (!$rid) wp_send_json_error(array('message' => 'Invalid request.'));
    $meta = nsh_get_meta($rid);
    $post   = get_post($rid);
    $client = $post ? get_userdata($post->post_author) : null;
    $to_email = $client ? $client->user_email : 'unknown';
    $sent = nsh_notify_status_change($rid, $meta['status']);
    if ($sent) {
        nsh_add_history($rid, 'Status update email manually sent to client');
        wp_send_json_success(array('message' => 'Status update email sent successfully to ' . $to_email . '.'));
    } else {
        nsh_log('nsh_send_status_email: failed. rid=' . $rid . ' recipient=' . $to_email);
        wp_send_json_error(array('message' => 'Failed to send email to ' . $to_email . '. Check WordPress SMTP / mail plugin settings.'));
    }
}

// ── Bulk Excel Export ────────────────────────────────────────────────────────
add_action('wp_ajax_nsh_bulk_export_excel', 'nsh_ajax_bulk_export_excel');
function nsh_ajax_bulk_export_excel() {
    nsh_check_nonce();
    nsh_require_staff();

    $request_ids = array_map('intval', (array)($_POST['request_ids'] ?? []));
    if (empty($request_ids)) {
        wp_send_json_error(array('message' => 'No requests selected.'));
    }
    $request_ids = array_filter($request_ids);

    global $wpdb;
    $fields_rows = $wpdb->get_results("SELECT field_key, field_label FROM {$wpdb->prefix}nsh_fields ORDER BY sort_order ASC");
    $label_map   = array();
    foreach ($fields_rows as $fr) { $label_map['field_' . $fr->field_key] = $fr->field_label; }

    // Build header row
    $all_rows   = array();
    $header_done = false;

    foreach ($request_ids as $rid) {
        $post = get_post($rid);
        if (!$post || $post->post_type !== 'nsh_request') continue;
        $meta   = nsh_get_meta($rid);
        $author = get_userdata($post->post_author);
        $fd     = $meta['field_data'];
        $req_id = $meta['request_id'] ? $meta['request_id'] : '#' . $rid;

        if (!$header_done) {
            $header = array('Order ID', 'Client Name', 'Client Email', 'Status', 'Quote', 'Shipping', 'Est. Delivery', 'Submitted');
            foreach ($fd as $k => $v) {
                $header[] = isset($label_map[$k]) ? $label_map[$k] : ucwords(str_replace(array('field_','_'),array('',' '),$k));
            }
            $all_rows[]  = $header;
            $header_done = true;
        }

        $row = array(
            $req_id,
            $author ? $author->display_name : '',
            $author ? $author->user_email   : '',
            nsh_status_label($meta['status']),
            $meta['quote_amount'] ? 'INR ' . number_format(floatval($meta['quote_amount']), 2) : '',
            isset($meta['shipping_charges']) ? 'INR ' . number_format(floatval($meta['shipping_charges']), 2) : '',
            $meta['estimated_delivery'] ? date('d M Y', strtotime($meta['estimated_delivery'])) : '',
            $post->post_date,
        );
        foreach ($fd as $k => $v) {
            $row[] = is_array($v) ? implode(', ', $v) : (string)$v;
        }
        $all_rows[] = $row;
    }

    if (count($all_rows) <= 1) {
        wp_send_json_error(array('message' => 'No valid requests found.'));
    }

    $xlsx     = nsh_build_xlsx_simple($all_rows, 'Bulk Export');
    $filename = 'bulk-export-' . date('Y-m-d') . '.xlsx';
    $uploads  = wp_upload_dir();
    $filepath = trailingslashit($uploads['basedir']) . $filename;
    file_put_contents($filepath, $xlsx);
    $url = trailingslashit($uploads['baseurl']) . $filename;

    // Schedule cleanup after 5 min
    wp_schedule_single_event(time() + 300, 'nsh_cleanup_temp_file', array($filepath));

    wp_send_json_success(array('url' => $url, 'filename' => $filename));
}
add_action('nsh_cleanup_temp_file', function($path){ if (file_exists($path)) unlink($path); });

// -----------------------------------------------------------
// EMAIL TEMPLATE SAVE / RESET / TEST (Settings panel)
// -----------------------------------------------------------
add_action('wp_ajax_nsh_save_email_template', 'nsh_ajax_save_email_template');
function nsh_ajax_save_email_template() {
    nsh_check_nonce(); nsh_require_staff();
    $type    = sanitize_key(isset($_POST['template_type']) ? $_POST['template_type'] : '');
    $subject = sanitize_text_field(isset($_POST['subject']) ? $_POST['subject'] : '');
    $body    = isset($_POST['body']) ? wp_kses_post(wp_unslash($_POST['body'])) : '';
    if (!$type || !$subject) wp_send_json_error(array('message' => 'Template type and subject are required.'));
    if (function_exists('nsh_save_custom_template')) {
        $result = nsh_save_custom_template($type, $subject, $body);
    } else {
        $result = update_option('nsh_email_template_' . $type, array('subject' => $subject, 'body' => $body, 'updated_at' => current_time('mysql')));
    }
    if ($result) {
        nsh_log('Email template saved: ' . $type);
        wp_send_json_success(array('message' => 'Template saved successfully.'));
    } else {
        wp_send_json_error(array('message' => 'Failed to save template.'));
    }
}

add_action('wp_ajax_nsh_reset_email_template', 'nsh_ajax_reset_email_template');
function nsh_ajax_reset_email_template() {
    nsh_check_nonce(); nsh_require_staff();
    $type = sanitize_key(isset($_POST['template_type']) ? $_POST['template_type'] : '');
    if (!$type) wp_send_json_error(array('message' => 'Template type required.'));
    delete_option('nsh_email_template_' . $type);
    wp_send_json_success(array('message' => 'Template reset to default.'));
}

add_action('wp_ajax_nsh_test_email', 'nsh_ajax_test_email');
function nsh_ajax_test_email() {
    nsh_check_nonce(); nsh_require_staff();
    $type  = sanitize_key(isset($_POST['template_type']) ? $_POST['template_type'] : '');
    $email = sanitize_email(isset($_POST['test_email']) ? $_POST['test_email'] : '');
    if (!$email || !is_email($email)) wp_send_json_error(array('message' => 'Valid email address required.'));
    $template = function_exists('nsh_get_email_template') ? nsh_get_email_template($type, array()) : false;
    if (!$template) wp_send_json_error(array('message' => 'Template not found.'));
    $from_name  = get_option('nsh_email_name',  get_bloginfo('name'));
    $from_email = get_option('nsh_email_from',  '');
    $headers = array('Content-Type: text/html; charset=UTF-8');
    if ( $from_email && is_email( $from_email ) ) {
        $headers[] = 'From: ' . $from_name . ' <' . $from_email . '>';
    }
    $sent = wp_mail($email, '[TEST] ' . $template['subject'], $template['body'], $headers);
    if ($sent) {
        wp_send_json_success(array('message' => 'Test email sent to ' . $email));
    } else {
        wp_send_json_error(array('message' => 'Failed to send test email. Check SMTP settings.'));
    }
}

/**
 * Proves the actual admin-notification PATH works, not just raw SMTP —
 * i.e. that nsh_admin_notification_email() resolves to a real address AND
 * nsh_mail() (this plugin's own mailer, with its wp_mail_failed capture —
 * see notifications.php) can actually deliver to it. Distinct from
 * nsh_ajax_smtp_test() (smtp.php), which only proves the SMTP transport
 * itself works against an arbitrary address the admin types in, not that
 * THIS specific resolution logic — the one that decides where every real
 * "New Request Received" email actually goes — points anywhere valid.
 *
 * 'live_manager_email', when present and a valid address, is tested
 * directly instead of re-reading the saved nsh_manager_email option — so
 * an admin can test a Manager Email they just typed into the settings
 * form before ever clicking Save, exactly like every other "Send Test"
 * button on this page tests the field it sits next to rather than
 * whatever's already in the database.
 */
add_action('wp_ajax_nsh_test_admin_notification', 'nsh_ajax_test_admin_notification');
function nsh_ajax_test_admin_notification() {
    nsh_check_nonce(); nsh_require_staff();

    $live  = sanitize_email( isset( $_POST['live_manager_email'] ) ? $_POST['live_manager_email'] : '' );
    $using_live = $live && is_email( $live );
    $to = $using_live ? $live : ( function_exists( 'nsh_admin_notification_email' ) ? nsh_admin_notification_email() : get_option( 'admin_email' ) );

    if ( ! $to || ! is_email( $to ) ) {
        wp_send_json_error( array( 'message' => 'No valid address to send to — both Manager Email and your WordPress Admin Email (Settings → General) are empty or invalid.' ) );
    }

    $platform = get_option( 'nsh_platform_name', get_bloginfo( 'name' ) );
    $subject  = '[Test] Admin notification — ' . $platform;
    $body     = function_exists( 'nsh_html_email' )
        ? nsh_html_email(
            'This is a test of your admin notification path.',
            array(
                'If you received this, admin notifications (e.g. "New Request Received" for every new service request) are reaching <strong>' . esc_html( $to ) . '</strong> correctly.',
                $using_live
                    ? 'This address was typed into the Manager Email field but not yet saved — click "Save Settings" to make it permanent.'
                    : ( get_option( 'nsh_manager_email' ) ? 'This is your saved Manager Email.' : 'No Manager Email is set, so this is your WordPress Admin Email (the fallback).' ),
            )
        )
        : '<p>Test admin notification from ' . esc_html( $platform ) . '.</p>';

    $sent = nsh_mail( $to, $subject, $body );

    if ( $sent ) {
        nsh_log( 'Test admin notification sent to ' . $to . ( $using_live ? ' (live/unsaved value)' : ' (resolved via nsh_admin_notification_email)' ) );
        wp_send_json_success( array( 'message' => 'Sent to ' . $to . '. Check that inbox (and spam folder).' ) );
    } else {
        nsh_log( 'Test admin notification FAILED to ' . $to );
        wp_send_json_error( array( 'message' => 'Failed to send to ' . $to . ' — check nsh-debug.log for the exact reason (SMTP error, rejected address, etc).' ) );
    }
}

// -----------------------------------------------------------
// COUNT broken documents (AVIF/WebP) — used by Settings > General
// -----------------------------------------------------------
function nsh_count_broken_docs(): int {
    global $wpdb;
    $posts = $wpdb->get_col(
        "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'nsh_request' AND post_status = 'publish'"
    );
    $count = 0;
    $finfo = new finfo( FILEINFO_MIME_TYPE );
    foreach ( $posts as $pid ) {
        $docs = get_post_meta( intval($pid), 'documents', true );
        if ( ! is_array( $docs ) ) continue;
        foreach ( $docs as $doc ) {
            $att_id = intval( $doc['file'] ?? 0 );
            if ( ! $att_id ) continue;
            $path = get_attached_file( $att_id );
            if ( ! $path || ! file_exists( $path ) ) continue;
            $mime = $finfo->file( $path );
            if ( in_array( $mime, [ 'image/avif', 'image/webp' ], true ) ) {
                $count++;
            }
        }
    }
    return $count;
}

add_action( 'wp_ajax_nsh_count_avif_docs', 'nsh_ajax_count_avif_docs' );
function nsh_ajax_count_avif_docs(): void {
    nsh_check_nonce();
    nsh_require_staff();
    wp_send_json_success( [ 'count' => nsh_count_broken_docs() ] );
}

// -----------------------------------------------------------
// BATCH FIX: convert all AVIF/WebP documents → PNG
// -----------------------------------------------------------
add_action( 'wp_ajax_nsh_fix_avif_docs', 'nsh_ajax_fix_avif_docs' );
function nsh_ajax_fix_avif_docs(): void {
    nsh_check_nonce();
    nsh_require_staff();

    // wp_generate_attachment_metadata (called inside nsh_sanitise_attachment) needs these
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    $batch = max( 1, min( 20, intval( $_POST['batch'] ?? 10 ) ) );
    $finfo = new finfo( FILEINFO_MIME_TYPE );

    global $wpdb;
    $posts = $wpdb->get_col(
        "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'nsh_request' AND post_status = 'publish'"
    );

    // Collect all broken attachment IDs
    $queue = [];
    foreach ( $posts as $pid ) {
        $docs = get_post_meta( intval($pid), 'documents', true );
        if ( ! is_array( $docs ) ) continue;
        foreach ( $docs as $doc ) {
            $att_id = intval( $doc['file'] ?? 0 );
            if ( ! $att_id ) continue;
            $path = get_attached_file( $att_id );
            if ( ! $path || ! file_exists( $path ) ) continue;
            $mime = $finfo->file( $path );
            if ( in_array( $mime, [ 'image/avif', 'image/webp' ], true ) ) {
                $queue[] = $att_id;
            }
        }
    }

    $remaining = max( 0, count( $queue ) - $batch );
    $to_fix    = array_slice( $queue, 0, $batch );
    $converted = 0;
    $failed    = 0;

    foreach ( $to_fix as $att_id ) {
        nsh_sanitise_attachment( $att_id );
        $path = get_attached_file( $att_id );
        if ( $path && file_exists( $path ) ) {
            $mime = $finfo->file( $path );
            if ( in_array( $mime, [ 'application/pdf', 'image/jpeg', 'image/png' ], true ) ) {
                $converted++;
            } else {
                $failed++;
                nsh_log( 'nsh_fix_avif_docs: still not converted, att=' . $att_id );
            }
        } else {
            $failed++;
        }
    }

    wp_send_json_success( [
        'converted' => $converted,
        'failed'    => $failed,
        'remaining' => $remaining,
    ] );
}

// -----------------------------------------------------------
// BULK DOCUMENT DOWNLOAD — returns every document's proxied URL + a clean
// display name, plus a single "folder" name: "[Student Complete Name] –
// [Request Number]". Never packaged into a ZIP. The client
// (nshSaveFilesAsFolder() in nsh-app.js, via the File System Access API)
// creates that one real folder and writes every file straight into it as
// a single download action, so the person gets one uncompressed folder
// with individual files inside — not a ZIP, and not several separate
// per-file downloads landing loose in their downloads folder. Browsers
// without File System Access support (Firefox, Safari, or any non-HTTPS
// context) fall back to the previous one-file-at-a-time download, which
// is the most those browsers can do without a server-side archive.
// Accessible by both staff and the request owner.
// -----------------------------------------------------------
add_action('wp_ajax_nsh_bulk_download_docs', 'nsh_ajax_bulk_download_docs');
function nsh_ajax_bulk_download_docs() {
    nsh_check_nonce();
    if (!is_user_logged_in()) {
        wp_send_json_error(array('message' => 'Login required.'), 401);
    }

    $rid     = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $att_ids = isset($_POST['att_ids']) ? array_map('intval', (array)$_POST['att_ids']) : array();
    $section = sanitize_text_field(isset($_POST['section']) ? $_POST['section'] : 'all'); // 'user', 'provider', 'all'

    if (!$rid) {
        wp_send_json_error(array('message' => 'Invalid request ID.'));
    }
    if (!nsh_is_own_request($rid)) {
        wp_send_json_error(array('message' => 'Access denied.'), 403);
    }

    // Collect documents
    $docs = nsh_get_documents($rid);
    if (empty($docs)) {
        wp_send_json_error(array('message' => 'No documents found for this request.'));
    }

    // Filter by section if needed
    if ($section === 'user') {
        $docs = array_filter($docs, function($d){ return empty($d['is_provider']); });
    } elseif ($section === 'provider') {
        $docs = array_filter($docs, function($d){ return !empty($d['is_provider']); });
    }

    // Further filter by specific attachment IDs if provided
    if (!empty($att_ids)) {
        $docs = array_filter($docs, function($d) use ($att_ids) {
            return in_array(intval($d['file']), $att_ids);
        });
    }

    $docs = array_values($docs);
    if (empty($docs)) {
        wp_send_json_error(array('message' => 'No matching documents to download.'));
    }

    // "[Student Complete Name] – [Request Number]" — the request number
    // keeps its existing format exactly as generated by
    // nsh_generate_request_id() (e.g. NSH-2026-0554); the fallback only
    // applies to the handful of legacy requests created before that field
    // existed. The en dash (–) matches the format given in the request.
    $author       = get_userdata(get_post_field('post_author', $rid));
    $student_name = $author && $author->display_name ? $author->display_name : 'Client';
    $rid_label    = get_post_meta($rid, 'request_id', true) ?: ('REQ-' . $rid);
    $folder       = trim($student_name) . ' – ' . $rid_label;

    $urls       = array();
    $used_names = array();
    foreach ($docs as $doc) {
        $att_id = intval($doc['file']);
        if (!$att_id) { continue; }

        $doc_type = isset($doc['doc_type']) && $doc['doc_type'] ? $doc['doc_type'] : '';
        if ($doc_type) {
            $base = sanitize_file_name($doc_type);
        } else {
            $fn   = basename((string) get_attached_file($att_id));
            $base = sanitize_file_name(preg_replace('/\.(jpg|jpeg|png|webp|avif|pdf)$/i', '', $fn));
        }
        if ($base === '') { $base = 'document'; }
        // Avoid two documents in the same folder colliding on name (e.g.
        // two "Passport" entries) — the download endpoint appends the
        // correct extension itself, so only the base name needs to be
        // unique here.
        if (in_array($base, $used_names, true)) {
            $base .= '-' . (count($used_names) + 1);
        }
        $used_names[] = $base;

        $dl_url = function_exists('nsh_get_download_url')
            ? nsh_get_download_url($att_id, $base)
            : wp_get_attachment_url($att_id);
        if (!$dl_url) { continue; }

        // filename here is a clean, flat base name (no folder prefix) — the
        // real extension comes from the proxied URL's Content-Disposition
        // header (nsh_ajax_download_document() decides PDF/JPG/PNG, converting
        // WebP/AVIF, so it isn't known until the response arrives). Grouping
        // every one of these into one actual folder is the client's job now
        // (nshSaveFilesAsFolder() in nsh-app.js, via the File System Access
        // API), using the 'folder' name returned below — not this endpoint.
        $urls[] = array('url' => $dl_url, 'filename' => $base);
    }

    if (empty($urls)) {
        wp_send_json_error(array('message' => 'No matching documents to download.'));
    }

    nsh_log('Bulk document download: ' . count($urls) . ' files, request ' . $rid . ', folder "' . $folder . '"');
    wp_send_json_success(array(
        'mode'   => 'sequential',
        'files'  => $urls,
        'folder' => $folder,
        'count'  => count($urls),
    ));
}

// -----------------------------------------------------------
// GET NEW MESSAGES SINCE A GIVEN MESSAGE ID (for live polling)
// -----------------------------------------------------------
add_action('wp_ajax_nsh_get_messages_since',        'nsh_ajax_get_messages_since');
add_action('wp_ajax_nopriv_nsh_get_messages_since', 'nsh_ajax_get_messages_since');
function nsh_ajax_get_messages_since() {
    nsh_check_nonce();
    if (!is_user_logged_in()) wp_send_json_error(array('message' => 'Login required.'), 401);

    $rid      = intval(isset($_POST['request_id']) ? $_POST['request_id'] : 0);
    $since_id = intval(isset($_POST['since_id'])   ? $_POST['since_id']   : 0);

    if (!$rid || !nsh_is_own_request($rid)) {
        wp_send_json_error(array('message' => 'Access denied.'), 403);
    }

    global $wpdb;
    $rows = $wpdb->get_results($wpdb->prepare(
        "SELECT m.id, m.sender_id, m.message, m.is_email_sent, m.created_at,
                u.display_name, u.user_email
         FROM {$wpdb->prefix}nsh_messages m
         LEFT JOIN {$wpdb->prefix}users u ON m.sender_id = u.ID
         WHERE m.request_id = %d
           AND m.id > %d
           AND m.message NOT LIKE '[Email] %%'
         ORDER BY m.id ASC",
        $rid, $since_id
    ));

    $is_staff   = nsh_is_staff();
    $cur_uid    = get_current_user_id();
    $out        = array();

    foreach ($rows as $m) {
        $is_mine         = ( (int) $m->sender_id === $cur_uid );
        $sender_is_staff = ( $m->user_email &&
            ( user_can( (int) $m->sender_id, 'administrator' ) ||
              user_can( (int) $m->sender_id, 'nsh_admin' )    ||
              user_can( (int) $m->sender_id, 'nsh_manager' ) ) );

        if      ( $is_mine )         { $label = 'You'; }
        elseif  ( $sender_is_staff ) { $label = $is_staff ? $m->display_name . ' (Admin)' : 'Support Team'; }
        else                         { $label = $is_staff ? $m->display_name . ' (Client)' : $m->display_name; }

        $out[] = array(
            'id'           => (int) $m->id,
            'message'      => $m->message,
            'time'         => wp_date( 'd M, g:i a', strtotime( $m->created_at ) ),
            'is_email_sent'=> (int) $m->is_email_sent,
            'sender_id'    => (int) $m->sender_id,
            'is_mine'      => $is_mine,
            'is_staff'     => $sender_is_staff,
            'label'        => $label,
            'can_delete'   => $is_staff,
        );
    }

    wp_send_json_success(array('messages' => $out));
}

// -----------------------------------------------------------
// FORM STYLING — Settings -> Form Styling. Saves the admin-chosen
// colors/sizes that nsh_form_style_inline_css() (helpers.php) turns into
// a ":root{--nsh-*:...}" override loaded after nsh-style.css (enqueue.php),
// so every form on the site (standalone card, dashboard New Request page,
// etc.) re-themes together from one place, without editing source files.
// -----------------------------------------------------------
add_action( 'wp_ajax_nsh_save_form_style', 'nsh_ajax_save_form_style' );
function nsh_ajax_save_form_style() {
    nsh_check_nonce();
    nsh_require_staff();

    $defaults = nsh_form_style_defaults();
    $clean    = array();
    foreach ( $defaults as $key => $default_val ) {
        $raw = isset( $_POST[ $key ] ) ? sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) : '';
        $raw = trim( $raw );
        // Whitelist: hex colors or a plain CSS length (px/em/rem/%) — never
        // stored (or later echoed into <style>) otherwise.
        if ( $raw !== '' && preg_match( '/^(#[0-9a-fA-F]{3,8}|[0-9]+(\.[0-9]+)?(px|em|rem|%))$/', $raw ) ) {
            $clean[ $key ] = $raw;
        } else {
            $clean[ $key ] = $default_val;
        }
    }
    update_option( 'nsh_form_style_settings', $clean );
    wp_send_json_success( array( 'message' => 'Form styling saved.' ) );
}

add_action( 'wp_ajax_nsh_reset_form_style', 'nsh_ajax_reset_form_style' );
function nsh_ajax_reset_form_style() {
    nsh_check_nonce();
    nsh_require_staff();
    delete_option( 'nsh_form_style_settings' );
    wp_send_json_success( array( 'message' => 'Form styling reset to defaults.' ) );
}
