<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * ONE reusable parser for a field's stored option list (used by radio,
 * checkbox and select/dropdown fields' field_options column) — every
 * caller across the plugin goes through this instead of its own
 * explode(), so a delimiter fix only has to happen in one place.
 *
 * Root cause this exists to fix: option text for this domain routinely
 * contains a literal comma ("Under ₹2,000", "₹2,000–4,000" — Indian
 * rupee amounts are comma-grouped), but the column used to be split on
 * ',' — indistinguishable from a comma that was meant to separate two
 * options. "Under ₹2,000" silently became two options, "Under ₹2" and
 * "000". The canonical delimiter is now a newline: an individual
 * option's own text can contain a comma freely, but never a newline, so
 * newline-splitting is unambiguous regardless of what the option text
 * says. A stored value that has no newline in it is still split on
 * comma as a fallback, purely so a row that hasn't been through the
 * v6.19.0 migration yet (nsh_migrate_v6_19_0, migrations.php) degrades
 * to its old (already-broken for comma-containing values, but at least
 * not fatal) behavior instead of rendering as one giant unsplit option.
 */
function nsh_parse_field_options( $raw ) {
    $raw = (string) $raw;
    if ( $raw === '' ) { return array(); }
    $parts = ( strpos( $raw, "\n" ) !== false ) ? explode( "\n", $raw ) : explode( ',', $raw );
    $parts = array_map( 'trim', $parts );
    return array_values( array_filter( $parts, function ( $p ) { return $p !== ''; } ) );
}

function nsh_generate_request_id() {
    global $wpdb;
    $wpdb->query( "INSERT INTO {$wpdb->options}(option_name,option_value,autoload) VALUES('nsh_counter',1,'no') ON DUPLICATE KEY UPDATE option_value=option_value+1" );
    $n = (int) $wpdb->get_var( "SELECT option_value FROM {$wpdb->options} WHERE option_name='nsh_counter'" );
    return 'NSH-' . date('Y') . '-' . str_pad( $n, 4, '0', STR_PAD_LEFT );
}

// -----------------------------------------------------------
// REQUEST DATE FILTER — shared by the Requests tab and Form Submissions
// tab (nsh_ajax_get_requests()/nsh_ajax_list_submissions() in ajax.php /
// form-submissions.php) so both filter identically against the request's
// actual submission date/time (its post_date — when it was received, not
// any other date field on the request).
// -----------------------------------------------------------

/**
 * Turns a date-filter key (+ optional date value(s) for the two
 * user-supplied cases) into a concrete [start, end] datetime range in the
 * site's configured timezone, as 'Y-m-d H:i:s' strings ready for
 * WP_Query's date_query 'after'/'before'. Either end can be null, meaning
 * "no lower/upper bound" — the caller only adds the keys it actually got
 * a value for. Returns array(null, null) for an empty/unknown/'all' filter,
 * meaning "no date filter at all".
 *
 * $from/$to are 'Y-m-d' strings from the date inputs — for 'specific_date'
 * only $from is used (the single date picker), for 'custom_range' both
 * are optional and independent (a from-only range is "on or after", a
 * to-only range is "on or before").
 */
function nsh_compute_request_date_range( $filter, $from = '', $to = '' ) {
    $filter = sanitize_key( $filter );
    $tz     = wp_timezone();
    $now    = new DateTime( 'now', $tz );
    $start  = null;
    $end    = null;

    switch ( $filter ) {
        case 'today':
            $start = ( clone $now )->setTime( 0, 0, 0 );
            $end   = ( clone $now )->setTime( 23, 59, 59 );
            break;
        case 'yesterday':
            $y     = ( clone $now )->modify( '-1 day' );
            $start = ( clone $y )->setTime( 0, 0, 0 );
            $end   = ( clone $y )->setTime( 23, 59, 59 );
            break;
        case 'this_week':
            // Monday-start week, through right now (not through Sunday —
            // "this week" shouldn't show requests that haven't happened
            // yet if today is, say, Wednesday).
            $start = ( clone $now )->modify( 'monday this week' )->setTime( 0, 0, 0 );
            $end   = ( clone $now )->setTime( 23, 59, 59 );
            break;
        case 'last_week':
            $this_monday = ( clone $now )->modify( 'monday this week' )->setTime( 0, 0, 0 );
            $start       = ( clone $this_monday )->modify( '-7 days' );
            $end         = ( clone $start )->modify( '+6 days' )->setTime( 23, 59, 59 );
            break;
        case 'this_month':
            $start = ( clone $now )->modify( 'first day of this month' )->setTime( 0, 0, 0 );
            $end   = ( clone $now )->setTime( 23, 59, 59 );
            break;
        case 'last_month':
            $start = ( clone $now )->modify( 'first day of last month' )->setTime( 0, 0, 0 );
            $end   = ( clone $now )->modify( 'last day of last month' )->setTime( 23, 59, 59 );
            break;
        case 'specific_date':
            if ( $from && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ) {
                $d = DateTime::createFromFormat( 'Y-m-d', $from, $tz );
                if ( $d ) {
                    $start = ( clone $d )->setTime( 0, 0, 0 );
                    $end   = ( clone $d )->setTime( 23, 59, 59 );
                }
            }
            break;
        case 'custom_range':
            if ( $from && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $from ) ) {
                $d1 = DateTime::createFromFormat( 'Y-m-d', $from, $tz );
                if ( $d1 ) { $start = ( clone $d1 )->setTime( 0, 0, 0 ); }
            }
            if ( $to && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $to ) ) {
                $d2 = DateTime::createFromFormat( 'Y-m-d', $to, $tz );
                if ( $d2 ) { $end = ( clone $d2 )->setTime( 23, 59, 59 ); }
            }
            break;
        default:
            // '' (All Dates) or anything unrecognized — no filter.
            return array( null, null );
    }

    return array(
        $start ? $start->format( 'Y-m-d H:i:s' ) : null,
        $end   ? $end->format( 'Y-m-d H:i:s' )   : null,
    );
}

/**
 * Given already-computed [after, before] bounds (from
 * nsh_compute_request_date_range()), returns the 'date_query' array to
 * merge into a WP_Query args array — or an empty array if both bounds are
 * null (no filter to apply). Always against post_date (submission time).
 */
function nsh_request_date_query( $after, $before ) {
    if ( ! $after && ! $before ) { return array(); }
    $dq = array( 'column' => 'post_date', 'inclusive' => true );
    if ( $after )  { $dq['after']  = $after; }
    if ( $before ) { $dq['before'] = $before; }
    // WP_Query's 'date_query' expects a flat array of clause arrays at the
    // top level (e.g. array( array('column'=>...,'after'=>...) )) — NOT an
    // extra nesting level around that. Wrapping $dq in array() ONE MORE time
    // than that here would make WP_Query treat the single clause as an
    // unkeyed sub-array with no 'column'/'after'/'before' of its own,
    // silently matching against nothing recognizable and making every date
    // filter a no-op (still returns unfiltered results, no error/warning).
    return array( $dq );
}

/**
 * Renders the date-filter <select> plus its two conditional date input
 * groups (Specific Date / Custom Range — hidden until chosen, via CSS in
 * nsh-style.css keyed off the shared .nsh-datef-group class + data-show
 * attribute, toggled by nshInitDateFilterToggle() in nsh_admin_js()).
 * $id_prefix lets the Requests tab and Form Submissions tab each get
 * their own element ids (e.g. "nsh-admin-date" -> #nsh-admin-date-f,
 * #nsh-admin-date-specific, #nsh-admin-date-from, #nsh-admin-date-to)
 * while sharing one markup/behavior implementation.
 */
function nsh_render_date_filter_controls( $id_prefix ) {
    $options = array(
        ''             => 'All Dates',
        'today'        => 'Today',
        'yesterday'    => 'Yesterday',
        'this_week'    => 'This Week',
        'last_week'    => 'Last Week',
        'this_month'   => 'This Month',
        'last_month'   => 'Last Month',
        'specific_date'=> 'Specific Date…',
        'custom_range' => 'Custom Range…',
    );
    $o  = '<select id="' . esc_attr( $id_prefix ) . '-f" class="nsh-filter-sel" title="Filter by submission date">';
    foreach ( $options as $val => $label ) {
        $o .= '<option value="' . esc_attr( $val ) . '">' . esc_html( $label ) . '</option>';
    }
    $o .= '</select>';
    // Hidden by default (nsh-style.css); shown by nshInitDateFilterToggle()
    // only when the select above is set to the matching value.
    $o .= '<span id="' . esc_attr( $id_prefix ) . '-specific-wrap" class="nsh-datef-group" style="display:none;">';
    $o .= '<input type="date" id="' . esc_attr( $id_prefix ) . '-specific" class="nsh-filter-sel">';
    $o .= '</span>';
    $o .= '<span id="' . esc_attr( $id_prefix ) . '-range-wrap" class="nsh-datef-group" style="display:none;">';
    $o .= '<input type="date" id="' . esc_attr( $id_prefix ) . '-from" class="nsh-filter-sel" title="From">';
    $o .= '<span class="nsh-datef-sep">&ndash;</span>';
    $o .= '<input type="date" id="' . esc_attr( $id_prefix ) . '-to" class="nsh-filter-sel" title="To">';
    $o .= '</span>';
    return $o;
}

function nsh_get_meta( $rid ) {
    $status  = get_post_meta( $rid, 'status', true );
    $payst   = get_post_meta( $rid, 'payment_status', true );
    $fd      = get_post_meta( $rid, 'field_data', true );
    return array(
        'request_id'         => (string) get_post_meta( $rid, 'request_id', true ),
        'status'             => $status  ? (string) $status  : 'submitted',
        'payment_status'     => $payst   ? (string) $payst   : 'pending',
        'quote_amount'       => get_post_meta( $rid, 'quote_amount', true ),
        'estimated_delivery' => (string) get_post_meta( $rid, 'estimated_delivery', true ),
        'secondary_status'   => (string) get_post_meta( $rid, 'secondary_status', true ),
        'assigned_manager'   => get_post_meta( $rid, 'assigned_manager', true ),
        'assigned_vendor'    => get_post_meta( $rid, 'assigned_vendor', true ),
        'internal_notes'     => (string) get_post_meta( $rid, 'internal_notes', true ),
        // Staff-only CRM pipeline stage — see nsh_get_internal_statuses()
        // below. Defaults to the first stage ("inquiry") when never set,
        // same pattern as 'status' defaulting to 'submitted' above. This
        // is intentionally separate from 'status' (the client-facing
        // request status) and must NEVER be exposed on any client-facing
        // page, email, or notification.
        'internal_status'    => ( $is_val = get_post_meta( $rid, 'internal_status', true ) ) ? (string) $is_val : 'inquiry',
        'field_data'         => is_array( get_post_meta( $rid, 'field_data', true ) ) ? get_post_meta( $rid, 'field_data', true ) : array(),
        'shipping_charges'   => get_post_meta( $rid, 'shipping_charges', true ),
        'shipping_type'      => (string) get_post_meta( $rid, 'shipping_type', true ),
        // Which nsh_services catalog entry this request was submitted for
        // (set once, at submission — see nsh_ajax_create_request()). Every
        // request created under the new per-service form model has these;
        // requests never carried a service before have empty strings here,
        // and callers fall back to field_data / a generic label as needed.
        'service_id'             => (int) get_post_meta( $rid, 'service_id', true ),
        'service_name'           => (string) get_post_meta( $rid, 'service_name', true ),
        'service_slug'           => (string) get_post_meta( $rid, 'service_slug', true ),
        'service_category'       => (string) get_post_meta( $rid, 'service_category', true ),
        'quote_status'           => ( $qs_val = get_post_meta( $rid, 'quote_status', true ) ) ? (string) $qs_val : 'none',
        'qualification_score'    => get_post_meta( $rid, 'qualification_score', true ),
        'qualification_status'   => (string) get_post_meta( $rid, 'qualification_status', true ),
        'qualification_warnings' => is_array( get_post_meta( $rid, 'qualification_warnings', true ) ) ? get_post_meta( $rid, 'qualification_warnings', true ) : array(),
    );
}

function nsh_add_history( $rid, $event, $note = '' ) {
    $h   = (array) get_post_meta( $rid, 'history', true );
    $h[] = array( 'event' => sanitize_text_field($event), 'note' => sanitize_textarea_field($note), 'time' => current_time('Y-m-d H:i:s') );
    update_post_meta( $rid, 'history', $h );
}

function nsh_get_history( $rid ) {
    return (array) get_post_meta( $rid, 'history', true );
}

/**
 * Returns the first non-empty value from $fd (a request's submitted
 * field_data) among a list of candidate field keys, WITHOUT the
 * 'field_' prefix (added here). Form fields are admin-configurable (see
 * the "Fields" tab / wp_nsh_fields table), so a logical field like
 * "University Name" might be stored as field_university_name on one
 * install and field_university on another — trying several plausible
 * spellings makes the compact card summary work without hardcoding one
 * exact key per site.
 */
function nsh_fd_first( $fd, $keys ) {
    if ( ! is_array( $fd ) ) { return ''; }
    foreach ( $keys as $k ) {
        if ( empty( $fd[ 'field_' . $k ] ) ) { continue; }
        $v = $fd[ 'field_' . $k ];
        if ( is_scalar( $v ) ) { return (string) $v; }
        // Checkbox-type fields submit their selections as an array
        // (e.g. field_docs_available => array('Aadhaar Card','Passport')).
        // Treat that the same as a submitted value instead of silently
        // skipping it — join the selections into one comma string.
        if ( is_array( $v ) ) {
            $parts = array_filter( array_map( function( $p ) { return is_scalar( $p ) ? trim( (string) $p ) : ''; }, $v ), function( $p ) { return $p !== ''; } );
            if ( ! empty( $parts ) ) { return implode( ', ', $parts ); }
        }
    }
    return '';
}

/**
 * Builds the compact, grouped "at a glance" summary of a request's
 * submitted form data for the admin Requests list — see the
 * "Document/Academic", "Location & Delivery", "Applicant" and
 * "Remarks" groups requested for the admin dashboard's request cards.
 * Returns ready-to-insert, already-escaped HTML (or '' if a group has
 * nothing to show), so the caller (nsh_ajax_get_requests, consumed by
 * nshLoadAdminRequests() in shortcodes.php) can drop it straight into
 * a card without re-implementing the field-key guessing or escaping.
 *
 * Only lines with at least one non-empty value are rendered; empty
 * individual fields inside a still-populated line are simply omitted
 * from that line rather than shown as blank.
 */
function nsh_render_request_card_fields( $rid, $meta = null ) {
    $meta = $meta ? $meta : nsh_get_meta( $rid );
    $fd   = $meta['field_data'];

    // pair(): builds one "Label: value" segment, or '' if the value is
    // empty — callers join non-empty segments with a " | " separator.
    $pair = function( $label, $value ) {
        $value = trim( (string) $value );
        if ( $value === '' ) { return ''; }
        return '<span class="nsh-rc-pair"><span class="nsh-rc-lbl">' . esc_html( $label ) . ':</span> <span class="nsh-rc-val" title="' . esc_attr( $value ) . '">' . esc_html( $value ) . '</span></span>';
    };
    $line = function( $parts ) {
        $parts = array_filter( $parts, function( $p ) { return $p !== ''; } );
        if ( empty( $parts ) ) { return ''; }
        return '<div class="nsh-rc-line">' . implode( '<span class="nsh-rc-sep">|</span>', $parts ) . '</div>';
    };

    $o = '';

    // 1. Applicant (submitted name/mobile — may differ from the WP
    // account name shown elsewhere, if someone submits on another
    // client's behalf).
    $first = nsh_fd_first( $fd, array( 'first_name' ) );
    $last  = nsh_fd_first( $fd, array( 'last_name' ) );
    $full_name = trim( $first . ' ' . $last );
    // Most non-education services never collect first_name/last_name at
    // all (see nsh_req_applicant_name() below) — fall back to
    // 'applicant_name' (or the deceased/owner/executor equivalent a few
    // services use under that same key) so this line isn't just silently
    // omitted for the 43 non-education services the way it used to be.
    if ( $full_name === '' ) { $full_name = nsh_fd_first( $fd, array( 'applicant_name' ) ); }
    $phone = nsh_fd_first( $fd, array( 'phone', 'mobile', 'mobile_number', '__phone' ) );
    $phone_code = nsh_fd_first( $fd, array( 'phone_code' ) );
    $o .= $line( array(
        $pair( 'Applicant', $full_name ),
        $pair( 'Mobile', $phone ? trim( $phone_code . ' ' . $phone ) : '' ),
    ) );
    // Contact Person — the dedicated Contact Details field every service
    // now collects (see nsh_migrate_v6_21_0() in migrations.php). Shown
    // only when it's someone other than the Applicant already named
    // above, same "don't repeat the same person twice" rule
    // nsh_generate_requirement_description()'s own Contact Person
    // sentence follows.
    $contact_person_line = nsh_fd_first( $fd, array( 'contact_person_name' ) );
    if ( $contact_person_line !== '' && strcasecmp( trim( $contact_person_line ), trim( $full_name ) ) !== 0 ) {
        $o .= $line( array( $pair( 'Contact Person', $contact_person_line ) ) );
    }

    // 2. Document / Academic details — several lines, grouped the way
    // an admin scans a form: what/how, then where, then when/how-long,
    // then reference numbers and why.
    $doc_type = nsh_fd_first( $fd, array( 'document_type' ) );
    $app_type = nsh_fd_first( $fd, array( 'application_type' ) );
    $o .= $line( array( $pair( 'Document', $doc_type ), $pair( 'Application', $app_type ) ) );

    $university = nsh_fd_first( $fd, array( 'university_name', 'university' ) );
    $college    = nsh_fd_first( $fd, array( 'college_name', 'college' ) );
    $o .= $line( array( $pair( 'University', $university ), $pair( 'College', $college ) ) );

    $course = nsh_fd_first( $fd, array( 'course_name', 'course' ) );
    $mode   = nsh_fd_first( $fd, array( 'mode_of_education', 'mode', 'education_mode' ) );
    $o .= $line( array( $pair( 'Course', $course ), $pair( 'Mode', $mode ) ) );

    $adm_year  = nsh_fd_first( $fd, array( 'year_admission', 'year_of_admission', 'admission_year' ) );
    $pass_year = nsh_fd_first( $fd, array( 'year_passing', 'year_of_passing', 'passing_year' ) );
    $semesters = nsh_fd_first( $fd, array( 'number_of_semesters', 'semesters', 'no_of_semesters' ) );
    $o .= $line( array( $pair( 'Admission', $adm_year ), $pair( 'Passing', $pass_year ), $pair( 'Semesters', $semesters ) ) );

    $enrollment = nsh_fd_first( $fd, array( 'enrollment_number', 'enrollment' ) );
    $purpose    = nsh_fd_first( $fd, array( 'purpose' ) );
    $o .= $line( array( $pair( 'Enrollment', $enrollment ), $pair( 'Purpose', $purpose ) ) );

    // 3. Location & Delivery — timeline is the admin-SET working-days
    // value (timeline_working_days), not a submitted form field; it's
    // whatever staff configured via the "Set Timeline" action.
    $cur_loc  = nsh_fd_first( $fd, array( 'current_location' ) );
    // Same key-name mismatch as the description engine below: only the
    // education form uses 'delivery_location' — every other service uses
    // 'delivery_addr'/'delivery_intl' or a single '__delivery' textarea.
    $del_loc  = nsh_fd_first( $fd, array( 'delivery_location', 'delivery_intl', 'delivery_addr', '__delivery' ) );
    $wd       = $meta['estimated_delivery'] ? get_post_meta( $rid, 'timeline_working_days', true ) : '';
    $timeline = $wd ? intval( $wd ) . ' Working Days' : '';
    $loc_parts = array();
    if ( $cur_loc !== '' || $del_loc !== '' ) {
        $loc_parts[] = '<span class="nsh-rc-pair"><span class="nsh-rc-lbl">Current:</span> <span class="nsh-rc-val" title="' . esc_attr( $cur_loc ) . '">' . esc_html( $cur_loc ?: '—' ) . '</span> <span class="nsh-rc-arrow">&rarr;</span> <span class="nsh-rc-lbl">Delivery:</span> <span class="nsh-rc-val" title="' . esc_attr( $del_loc ) . '">' . esc_html( $del_loc ?: '—' ) . '</span></span>';
    }
    $loc_parts[] = $pair( 'Timeline', $timeline );
    $o .= $line( $loc_parts );

    // 4. Remarks — only rendered at all when actually provided, per
    // spec; no reserved empty space otherwise.
    $remarks = nsh_fd_first( $fd, array( 'remarks', 'additional_remarks', 'notes' ) );
    if ( $remarks !== '' ) {
        $o .= '<div class="nsh-rc-line nsh-rc-remarks"><span class="nsh-rc-lbl">Remarks:</span> <span class="nsh-rc-val nsh-rc-remarks-val" title="' . esc_attr( $remarks ) . '">' . esc_html( $remarks ) . '</span></div>';
    }

    // 5. Everything else the client actually submitted, generically.
    //
    // Root cause this section fixes: groups 1-4 above only recognise a
    // fixed, hardcoded set of field KEYS (university_name, course_name,
    // enrollment_number, ...) — i.e. exactly the fields an education/
    // document-attestation service happens to use. This plugin ships
    // 50+ service types (immigration, property, financial, legal, tax,
    // birth/marriage certificates, passport support, etc.), each with
    // its OWN admin-configured field set (wp_nsh_fields, scoped by
    // service_id) using completely different keys. For any service
    // whose fields don't happen to match those hardcoded names — e.g.
    // a Birth Certificate request's applicant DOB/place-of-birth/
    // parents'-names fields — groups 1-4 render nothing for them, even
    // though the client filled the form out completely: the card just
    // looked sparse, not because data was missing, but because this
    // function didn't know those field names existed.
    //
    // Fix: after the hardcoded groups (kept as-is — they still give
    // education-type requests their nicer, purpose-grouped layout),
    // look up this request's OWN service's configured fields from the
    // database (real field_key -> field_label, in the order staff
    // arranged them) and render every one of them that (a) was actually
    // submitted with a non-empty value, (b) isn't a file upload (those
    // already have their own "Docs" button/count — repeating them here
    // as text would be noise, not new information), and (c) isn't one
    // of the keys a group above already displays by name, so nothing
    // shows twice on an education-type request that DOES use those
    // names. This makes the card complete for every service type,
    // not just the one it was originally written for.
    $service_id = isset( $meta['service_id'] ) ? (int) $meta['service_id'] : 0;
    if ( $service_id && is_array( $fd ) && ! empty( $fd ) ) {
        global $wpdb;
        $already_shown = array(
            'first_name', 'last_name', 'phone', 'mobile', 'mobile_number', 'phone_code',
            'document_type', 'application_type',
            'university_name', 'university', 'college_name', 'college',
            'course_name', 'course', 'mode_of_education', 'mode', 'education_mode',
            'year_admission', 'year_of_admission', 'admission_year',
            'year_passing', 'year_of_passing', 'passing_year',
            'number_of_semesters', 'semesters', 'no_of_semesters',
            'enrollment_number', 'enrollment', 'purpose',
            'current_location', 'delivery_location',
            'remarks', 'additional_remarks', 'notes',
        );
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT field_key, field_label, field_type FROM {$wpdb->prefix}nsh_fields WHERE service_id=%d AND is_active=1 ORDER BY step_number ASC, sort_order ASC",
            $service_id
        ) );
        $extra_pairs = array();
        foreach ( (array) $rows as $fr ) {
            if ( in_array( $fr->field_key, $already_shown, true ) || $fr->field_type === 'file' ) {
                continue;
            }
            $val = isset( $fd[ 'field_' . $fr->field_key ] ) ? $fd[ 'field_' . $fr->field_key ] : '';
            if ( is_array( $val ) ) { $val = implode( ', ', array_map( 'strval', $val ) ); }
            $val = trim( (string) $val );
            if ( $val === '' ) { continue; }
            $extra_pairs[] = $pair( $fr->field_label, $val );
        }
        // Two per line, same compact rhythm as the groups above.
        for ( $i = 0; $i < count( $extra_pairs ); $i += 2 ) {
            $o .= $line( array_slice( $extra_pairs, $i, 2 ) );
        }
    }

    return $o;
}

/* ============================================================
   STUDENT REQUIREMENT DESCRIPTION — INTERNAL INTELLIGENCE ENGINE
   ------------------------------------------------------------
   Deterministic, server-side, rule-based text generator — no
   external AI API. Turns a request's submitted fields into a
   short (2-4 sentence) natural-language explanation of what the
   student actually needs, the way a human who read the form
   would summarise it to a colleague — not a field-by-field
   concatenation. See nsh_generate_requirement_description().
   ============================================================ */

/**
 * Requirement-type knowledge library: maps recognizable phrases inside
 * a request's raw "Document Type" value to how that document should be
 * talked about in a generated description. This is an ordered array —
 * the first (most specific) match wins, so e.g. "duplicate degree" is
 * listed ahead of the plainer "degree" it also contains. Filterable so
 * new document/service types can be added later without editing this
 * file (`add_filter('nsh_req_doc_library', ...)`).
 */
function nsh_req_doc_library() {
    $lib = array(
        'duplicate degree'         => array( 'noun' => 'duplicate degree certificate' ),
        'duplicate marksheet'      => array( 'noun' => 'duplicate marksheet' ),
        'consolidated marksheet'   => array( 'noun' => 'consolidated marksheet' ),
        'final semester marksheet' => array( 'noun' => 'final semester marksheet' ),
        'final year marksheet'     => array( 'noun' => 'final year marksheet' ),
        'marksheet'                => array( 'noun' => 'marksheet' ),
        'transcript'               => array( 'noun' => 'transcript' ),
        'degree certificate'       => array( 'noun' => 'degree certificate' ),
        'degree'                   => array( 'noun' => 'degree certificate' ),
        'migration certificate'    => array( 'noun' => 'migration certificate' ),
        'migration'                => array( 'noun' => 'migration certificate' ),
        'medium of instruction'    => array( 'noun' => 'Medium of Instruction (MOI) letter' ),
        'moi'                      => array( 'noun' => 'Medium of Instruction (MOI) letter' ),
        'letter of recommendation' => array( 'noun' => 'letter of recommendation' ),
        'recommendation'           => array( 'noun' => 'letter of recommendation' ),
        'syllabus'                 => array( 'noun' => 'syllabus copy' ),
        'duplicate'                => array( 'noun' => 'duplicate copy of his/her document' ),
        'verification'             => array( 'noun' => 'document verification', 'verb' => 'needs help getting his/her documents verified' ),
        'attestation'              => array( 'noun' => 'document attestation',  'verb' => 'needs his/her documents attested' ),
        'apostille'                => array( 'noun' => 'apostille',             'verb' => 'needs an apostille done on his/her documents' ),
    );
    return apply_filters( 'nsh_req_doc_library', $lib );
}

/**
 * Matches a raw submitted "Document Type" value against the library
 * above. Falls back to using the raw value itself as the noun so an
 * unrecognised/custom document type still produces a sensible sentence
 * instead of being silently dropped.
 */
function nsh_req_match_doc( $doc_type ) {
    $doc_type_l = strtolower( trim( (string) $doc_type ) );
    if ( $doc_type_l === '' ) { return null; }
    foreach ( nsh_req_doc_library() as $needle => $rule ) {
        if ( strpos( $doc_type_l, $needle ) !== false ) { return $rule; }
    }
    return array( 'noun' => $doc_type_l );
}

/**
 * Turns a raw submitted "Purpose" value into a natural phrase for use
 * after "for" ("...for {phrase}"). Falls back to the raw value so an
 * unrecognised purpose still reads naturally instead of vanishing.
 */
function nsh_req_purpose_phrase( $purpose ) {
    $p = strtolower( trim( (string) $purpose ) );
    if ( $p === '' ) { return ''; }
    $map = array(
        'higher stud' => 'a higher-studies application abroad',
        'further stud' => 'a higher-studies application',
        'immigrat'    => 'his/her immigration process',
        'employ'      => 'an employment requirement',
        'job'         => 'a job application',
        'visa'        => 'his/her visa processing',
        'admission'   => 'a university admission',
        'scholarship' => 'a scholarship application',
        'residen'     => 'his/her residency application',
        'pr application' => 'his/her PR application',
    );
    foreach ( $map as $needle => $phrase ) {
        if ( strpos( $p, $needle ) !== false ) {
            return apply_filters( 'nsh_req_purpose_phrase', $phrase, $purpose );
        }
    }
    return apply_filters( 'nsh_req_purpose_phrase', trim( (string) $purpose ), $purpose );
}

/**
 * Joins a list of strings as natural English ("A", "A and B", "A, B and
 * C") — used wherever a narrative template lists out several submitted
 * items (documents already available, powers granted, etc.) as part of
 * a sentence rather than a bare comma-separated dump. Empty entries are
 * dropped first so a stray blank checkbox value never produces "A, ,
 * and B".
 */
/**
 * Lowercases the first letter of every word in a field label, except
 * words that are already an all-caps acronym (OCI, PAN, TDS, GST, EPF,
 * NRE, NRO, ID, POA, PF, DOB, ...) — those are left exactly as-is. Used
 * to drop a Title Case field label ("Date of Birth", "Your Full Name
 * (as in passport)") into the middle of a sentence without it reading
 * like a heading ("date of Birth" from a bare lcfirst()) or shouting an
 * acronym in lowercase ("oci card number").
 */
function nsh_label_lower( $label ) {
    $parts = preg_split( '/(\s+)/u', $label, -1, PREG_SPLIT_DELIM_CAPTURE );
    foreach ( $parts as &$w ) {
        if ( trim( $w ) === '' ) { continue; }
        if ( preg_match( '/^[A-Z]{2,}$/', $w ) ) { continue; } // acronym — keep as-is
        if ( function_exists( 'mb_substr' ) ) {
            $w = mb_strtolower( mb_substr( $w, 0, 1 ) ) . mb_substr( $w, 1 );
        } else {
            $w = lcfirst( $w );
        }
    }
    return implode( '', $parts );
}

function nsh_oxford_join( $items ) {
    $items = array_values( array_filter( array_map( 'trim', (array) $items ), function( $i ) { return $i !== ''; } ) );
    $n = count( $items );
    if ( $n === 0 ) { return ''; }
    if ( $n === 1 ) { return $items[0]; }
    $last = array_pop( $items );
    return implode( ', ', $items ) . ' and ' . $last;
}

/**
 * Resolves the actual person's name for a request, trying — in order —
 * every place this plugin might actually have collected one: the
 * education-style first_name+last_name pair, the 'applicant_name' field
 * many other services use instead, and finally the WordPress account's
 * own display name (but only when it looks like a real name rather than
 * the raw email address a name-less signup gets defaulted to — see
 * nsh_ajax_create_request() in ajax.php). Only once none of those give
 * anything does this fall back to the generic "The applicant" — which
 * used to be the ONLY thing most non-education requests ever got, since
 * their forms never ask for first_name/last_name at all.
 */
function nsh_req_applicant_name( $rid, $fd ) {
    $first = nsh_fd_first( $fd, array( 'first_name' ) );
    $last  = nsh_fd_first( $fd, array( 'last_name' ) );
    $name  = trim( $first . ' ' . $last );
    if ( $name !== '' ) { return $name; }

    $alt = nsh_fd_first( $fd, array( 'applicant_name' ) );
    if ( $alt !== '' ) { return $alt; }

    if ( $rid ) {
        $post = get_post( $rid );
        if ( $post ) {
            $user = get_userdata( $post->post_author );
            if ( $user && $user->display_name !== '' && strpos( $user->display_name, '@' ) === false ) {
                return $user->display_name;
            }
            // Last resort: this client's account has no usable display
            // name (their first-ever request happened to be on a
            // service that collects no name field at all, so it was
            // defaulted to their email — see nsh_ajax_create_request()
            // in ajax.php). If they've since submitted ANY other request
            // — on a service that DOES ask for a name — use that
            // instead of giving up. Checked newest-first, capped at 5
            // requests, so a repeat client isn't shown as "The
            // applicant" just because THIS PARTICULAR service doesn't
            // ask for one.
            if ( $user ) {
                $others = get_posts( array(
                    'post_type'      => 'nsh_request',
                    'author'         => $user->ID,
                    'post__not_in'   => array( $rid ),
                    'posts_per_page' => 5,
                    'orderby'        => 'date',
                    'order'          => 'DESC',
                    'fields'         => 'ids',
                ) );
                foreach ( $others as $other_id ) {
                    $other_fd = get_post_meta( $other_id, 'field_data', true );
                    if ( ! is_array( $other_fd ) ) { continue; }
                    $of = trim( nsh_fd_first( $other_fd, array( 'first_name' ) ) . ' ' . nsh_fd_first( $other_fd, array( 'last_name' ) ) );
                    if ( $of === '' ) { $of = nsh_fd_first( $other_fd, array( 'applicant_name' ) ); }
                    if ( $of !== '' ) { return $of; }
                }
            }
        }
    }
    return 'The applicant';
}

/**
 * The CONTACT PERSON's name — who to actually address/call about this
 * request — as distinct from nsh_req_applicant_name() above, which is
 * who the request is FOR (the applicant, deceased, student, ...). On
 * plenty of services those are two different people (a son filing a
 * Death Certificate request for a deceased parent, an agent filing a
 * Legal Notice on a client's behalf, a parent filing Marriage
 * Registration for their child), so the two are kept separate rather
 * than treating "contact person" as just another alias for
 * nsh_req_applicant_name()'s field list.
 *
 * Every service's own Contact Details step now collects a dedicated
 * 'contact_person_name' field (see nsh_migrate_v6_21_0() in
 * migrations.php for how this reached every EXISTING service, and
 * services-seed.json for new ones) — that field is always tried first.
 * Falls back, in order, to: first_name+last_name (the education
 * services' own contact-step name fields), applicant_name (used as a
 * contact name on a few older services before contact_person_name
 * existed), then the WordPress account's own display name (skipped if
 * it's just the raw email address a name-less signup defaults to — see
 * nsh_ajax_create_request() in ajax.php), and only as an absolute last
 * resort the account's email address — so the admin request list's
 * "who do I contact" line is never simply blank.
 */
function nsh_req_contact_person_name( $rid, $fd, $author = null ) {
    $cp = nsh_fd_first( $fd, array( 'contact_person_name' ) );
    if ( $cp !== '' ) { return $cp; }

    $first = nsh_fd_first( $fd, array( 'first_name' ) );
    $last  = nsh_fd_first( $fd, array( 'last_name' ) );
    $name  = trim( $first . ' ' . $last );
    if ( $name !== '' ) { return $name; }

    $alt = nsh_fd_first( $fd, array( 'applicant_name' ) );
    if ( $alt !== '' ) { return $alt; }

    if ( ! $author && $rid ) {
        $post = get_post( $rid );
        if ( $post ) { $author = get_userdata( $post->post_author ); }
    }
    if ( $author ) {
        if ( $author->display_name !== '' && strpos( $author->display_name, '@' ) === false ) {
            return $author->display_name;
        }
        if ( $author->user_email !== '' ) { return $author->user_email; }
    }
    return '';
}

/**
 * Hand-written opening narrative(s) for every non-education service —
 * the same idea as paragraphs 1-2 of the education engine above (a
 * natural sentence built from that request's MOST DEFINING fields,
 * not a mechanical list), just one dedicated template per service
 * instead of one shared set of field names, because these 43 services
 * genuinely don't share a common vocabulary (a Birth Certificate's
 * "hospital name" has nothing in common with a Green Card's "alien
 * number" or a Legal Notice's "recipient name").
 *
 * Returns array('text' => "...", 'used' => array of field_keys already
 * spoken for) — or null if $service_id isn't one of the ones below (the
 * caller's existing generic paragraph then covers the whole request).
 * 'used' keys are excluded from the generic "everything else" detail
 * paragraph that still runs after this, so nothing is ever mentioned
 * twice — and any field NOT named in a template below (every service
 * has more fields than are worth naming in an opening sentence) still
 * surfaces there, so nothing is ever silently dropped either.
 *
 * $g( 'key' ) is a small per-call shortcut for nsh_fd_first($fd,
 * array('key')) — every template below reads through it so a missing
 * field simply yields '' rather than a PHP notice, exactly like the
 * education engine's own field lookups.
 *
 * IMPORTANT: the switch below is keyed on each service's fixed CATALOG
 * POSITION (1-50, in services-seed.json's order), NOT on its raw
 * wp_nsh_services.id — see nsh_canonical_service_number() just below,
 * which is what actually resolves a live request's real DB service_id
 * to the matching case number before this function is ever called.
 * Never call this directly with a raw service_id; always go through
 * that resolver first (nsh_generate_requirement_description() already
 * does).
 */
/**
 * Resolves a REAL wp_nsh_services.id (a live request's actual
 * meta['service_id'], i.e. whatever auto-increment primary key that
 * service row happens to have in THIS site's database) to the fixed
 * catalog position (1-50) nsh_service_narrative_intro()'s switch is
 * keyed on.
 *
 * Root cause this fixes: nsh_service_narrative_intro() used to be
 * called with the raw DB service_id directly, and its switch matched
 * on that number as if it were always exactly 1-50 in
 * services-seed.json's order. That only holds on a database seeded
 * from a completely untouched, fresh activation. In the real world the
 * ids drift the moment a site's history includes anything else —
 * a service deleted and re-added (new row, new auto-increment id,
 * same slug), the catalog re-seeded after some ids were already taken
 * by other testing/data, or (on an older version of this plugin,
 * before the DB's field_key uniqueness was scoped per-service — see
 * the schema.php migration for uq_service_fk) any of several other
 * ways a services table can end up with ids that no longer line up
 * 1:1 with the JSON. On a database where they've drifted, EVERY
 * request silently fell through the switch to the one-line generic
 * fallback ("X has submitted a Y request.") instead of matching any
 * of the 43 hand-written per-service templates — the exact "still
 * very short description" symptom this resolver fixes, even though
 * every template itself was already correct and complete.
 *
 * Resolves by SLUG (wp_nsh_services.slug, stable and never touched by
 * id drift) rather than by id: looks up this service's slug from the
 * database, then finds that slug's fixed position in
 * services-seed.json (nsh_load_services_seed(), already used
 * elsewhere to seed/re-read the catalog) — a position that's baked
 * into the JSON's own service order and has nothing to do with
 * whatever ids the database assigned. Returns 0 (no match — caller's
 * existing null/generic fallback still applies) if the slug isn't
 * found in the seed at all, e.g. a service an admin created entirely
 * from scratch in the dashboard rather than from the bundled catalog.
 */
function nsh_canonical_service_number( $service_id ) {
    static $slug_to_num = null;
    if ( $slug_to_num === null ) {
        $slug_to_num = array();
        $data        = nsh_load_services_seed();
        $i           = 0;
        foreach ( ( $data['services'] ?? array() ) as $svc ) {
            $i++;
            if ( ! empty( $svc['slug'] ) ) { $slug_to_num[ $svc['slug'] ] = $i; }
        }
    }
    $service_id = (int) $service_id;
    if ( ! $service_id ) { return 0; }
    $svc = nsh_get_service( $service_id );
    if ( ! $svc || empty( $svc->slug ) ) { return 0; }
    return isset( $slug_to_num[ $svc->slug ] ) ? $slug_to_num[ $svc->slug ] : 0;
}

function nsh_service_narrative_intro( $service_id, $fd, $name ) {
    $g = function( $k ) use ( $fd ) { return nsh_fd_first( $fd, array( $k ) ); };
    // Joins non-empty parts with ', ' — used repeatedly below to build a
    // location like "Chennai, Tamil Nadu" without a stray leading/
    // trailing comma when one half is missing.
    $j = function() { return implode( ', ', array_filter( func_get_args(), function( $p ) { return trim( (string) $p ) !== ''; } ) ); };
    // Many of these radio options are written as full self-explanatory
    // sentences ("Yes — I/parent lives in birth city now"), not a bare
    // "Yes" — match on the leading word, not an exact-equals, or every
    // affirmative answer with any explanation attached would read as a
    // negative here.
    $yn = function( $v ) { return (bool) preg_match( '/^yes\b/i', trim( (string) $v ) ); };
    // Prefixes a phrase with "a "/"an " (vowel-aware) — used wherever a
    // submitted field's own value (not a fixed word this file wrote)
    // needs an article, so lcfirst()-ing it never silently drops the
    // "a"/"an" the sentence needs to stay grammatical.
    $art = function( $phrase ) { return ( preg_match( '/^(one\b|once\b|uni[cv]|us[ei]|eu[a-z])/i', $phrase ) ? 'a ' : ( preg_match( '/^[aeiou]/i', $phrase ) ? 'an ' : 'a ' ) ) . $phrase; };
    // Phrases a submitted timeline value after "needs the service " —
    // the option text is often already a full phrase like "Within 2-3
    // weeks" or "ASAP / Urgent", so this only prepends "within" when the
    // value doesn't already carry its own leading time-word (avoiding
    // "needs the service within within 2-3 weeks").
    $tl = function( $v ) { return preg_match( '/^(within|by|in|immediately|asap|urgent)/i', $v ) ? lcfirst( $v ) : 'within ' . $v; };
    // Strips a leading "Yes — "/"No — " off an option value and returns
    // just the explanation half, which is almost always already written
    // as a coherent standalone statement on its own (see the generic
    // fallback's identical technique, and Birth Certificate's
    // has_any_dob_proof handling above) — used throughout the templates
    // below so "Yes — old handwritten certificate exists" becomes "an
    // old handwritten certificate" instead of quoting the option text
    // (including its meaningless leading "Yes —") verbatim.
    $ex = function( $v ) { return preg_match( '/^(?:yes|no)\s*[—-]\s*(.+)$/iu', $v, $m ) ? trim( $m[1], " .\t" ) : $v; };
    // Joins a checkbox field's comma-separated selections into natural
    // English ("A, B and C") — nsh_fd_first() already turns a submitted
    // checkbox array into a comma string, so this just re-splits and
    // Oxford-joins it.
    $docs = function( $v ) { return $v === '' ? '' : nsh_oxford_join( array_map( 'trim', explode( ',', $v ) ) ); };
    // Generalises Birth Certificate's has_any_dob_proof handling (see
    // case 1) to any "Do you have X?" field whose Yes option explains
    // itself ("Yes — old handwritten certificate exists") — returns a
    // ready-to-append "has a/an ..." clause with the filler verb and
    // article fixed up, a "does not have ..." clause for a bare "No",
    // or '' if the value doesn't fit this shape (caller falls back to
    // $ex() instead).
    $has_clause = function( $v, $fallback_no = 'does not have this' ) use ( $art ) {
        if ( preg_match( '/^yes\s*[—-]\s*(.+)$/iu', $v, $m ) ) {
            $frag = trim( $m[1], " .\t" );
            $frag = preg_replace( '/\s+(exists|is available|available)$/i', '', $frag );
            return 'has ' . $art( $frag );
        }
        if ( preg_match( '/^no\b/i', $v ) ) { return $fallback_no; }
        return '';
    };
    // Safe lowercase-first: plain $lc() turns "I have a trusted
    // family member" into "i have a trusted family member" whenever a
    // field option happens to start with the pronoun "I" — leave a
    // leading standalone "I" alone instead of lowercasing it.
    $lc = function( $v ) {
        if ( preg_match( '/^I(\s|$)/', $v ) ) { return $v; }
        return function_exists( 'mb_strtolower' ) ? mb_strtolower( mb_substr( $v, 0, 1 ) ) . mb_substr( $v, 1 ) : lcfirst( $v );
    };

    switch ( (int) $service_id ) {

        case 1: // Birth Certificate — full hand-written narrative,
            // covering every non-contact, non-file field this service
            // collects (not just the 3-4 "headline" ones), so nothing is
            // left to the generic flowing-paragraph fallback below.
            $work    = $g('bc_work_type');
            $is_corr = stripos( $work, 'correction' ) !== false;
            $is_dup  = stripos( $work, 'duplicate' ) !== false;
            $loc     = $j( $g('birth_city'), $g('birth_state') );

            if ( $is_corr ) {
                $p = $name . ' needs a correction in their existing birth certificate' . ( $loc !== '' ? ' issued in ' . $loc : '' );
                if ( $g('correction_type') !== '' ) { $p .= ' — ' . $g('correction_type'); }
                $p .= '.';
            } elseif ( $is_dup ) {
                $p = $name . ' needs a duplicate of their birth certificate' . ( $loc !== '' ? ', originally issued in ' . $loc : '' ) . '.';
            } else {
                $p = $name . ' needs ' . ( $work !== '' ? $art( $work ) : 'a Birth Certificate' );
                $bt = $g('birth_type');
                if ( $bt !== '' ) {
                    $p .= ( stripos( $bt, 'home' ) !== false ) ? ', born at home' : ', born in hospital' . ( $g('hospital_name') !== '' ? ' at ' . $g('hospital_name') : '' );
                }
                if ( $loc !== '' ) { $p .= ' in ' . $loc; }
                $p .= '.';
            }

            // Who's applying + their age, as one natural sentence.
            $who = $g('who_applying');
            $who_phrase = ( stripos( $who, 'self' ) !== false ) ? 'the applicant themselves' : ( $who !== '' ? $lc( $who ) : '' );
            if ( $who_phrase !== '' || $g('age_of_person') !== '' ) {
                $p .= ' The application is being filed by ' . ( $who_phrase !== '' ? $who_phrase : 'the applicant' ) . ( $g('age_of_person') !== '' ? ', who is ' . $g('age_of_person') . ' years old' : '' ) . '.';
            }

            // Whether the applicant/parent is still in the birth city, and
            // whether any existing proof of the birth date exists — one
            // combined sentence, each answer turned into a plain
            // statement rather than the raw "Yes — ..." option text.
            $clauses2 = array();
            $in_city  = $g('applicant_in_birth_city');
            if ( $in_city !== '' ) { $clauses2[] = $yn( $in_city ) ? 'currently lives in their birth city' : 'no longer lives in their birth city'; }
            $dob_proof = $g('has_any_dob_proof');
            if ( $dob_proof !== '' ) {
                if ( $yn( $dob_proof ) ) {
                    // Option text is often "Yes — old handwritten birth
                    // certificate exists" — keep the explanation after the
                    // dash if the admin wrote one, otherwise a plain phrase.
                    if ( preg_match( '/[—-]\s*(.+)$/u', $dob_proof, $m ) ) {
                        $frag = trim( $m[1], " .\t" );
                        $frag = preg_replace( '/\s+(exists|is available|available)$/i', '', $frag );
                        $clauses2[] = 'has ' . $art( $frag );
                    } else {
                        $clauses2[] = 'has a document showing their date of birth';
                    }
                } else {
                    $clauses2[] = 'does not have an existing document showing their date of birth';
                }
            }
            if ( ! empty( $clauses2 ) ) { $p .= ' The applicant ' . implode( ' and ', $clauses2 ) . '.'; }

            // Documents already on hand — plain comma/and list, not a
            // "Label: value" pair.
            $docs = $g('docs_available');
            if ( $docs !== '' ) { $p .= ' They have ' . nsh_oxford_join( array_map( 'trim', explode( ',', $docs ) ) ) . ' available as supporting documents.'; }

            // Purpose, phrased around whether this is a correction/
            // duplicate/new certificate — matches how the earlier
            // sentence described the document itself.
            $purpose = $g('purpose');
            if ( $purpose !== '' ) {
                $doc_word = $is_corr ? 'corrected birth certificate' : ( $is_dup ? 'duplicate birth certificate' : 'birth certificate' );
                $p .= ' The ' . $doc_word . ' is required for ' . $art( $purpose ) . '.';
            }

            // Timeline + budget as one sentence.
            $tb = array();
            if ( $g('timeline') !== '' ) { $tb[] = 'needs the service ' . $tl( $g('timeline') ); }
            if ( $g('budget_range') !== '' ) { $tb[] = 'has an approximate budget of ' . $lc( $g('budget_range') ); }
            if ( ! empty( $tb ) ) { $p .= ' The applicant ' . implode( ' and ', $tb ) . '.'; }

            // Whether they've tried to get this themselves before.
            $prev = $g('prev_attempt');
            if ( $prev !== '' ) {
                if ( preg_match( '/^(?:no|never|first time|not yet)/i', $prev ) ) {
                    $p .= ' This is their first attempt at getting this done.';
                } else {
                    $p .= ' They have already tried to complete the process themselves' . ( preg_match( '/[—-]\s*(.+)$/u', $prev, $m2 ) ? ' but ' . $lc( trim( $m2[1], " .\t" ) ) : '' ) . '.';
                }
            }

            return array( 'text' => $p, 'used' => array( 'bc_work_type', 'correction_type', 'birth_type', 'hospital_name', 'birth_city', 'birth_state', 'who_applying', 'age_of_person', 'applicant_in_birth_city', 'has_any_dob_proof', 'docs_available', 'purpose', 'timeline', 'budget_range', 'prev_attempt' ) );

        case 2: // NABC
            $loc = $j( $g('birth_city'), $g('birth_state') );
            $p = $name . ' needs a Non-Availability of Birth Certificate';
            if ( $loc !== '' ) { $p .= ' for a birth in ' . $loc; }
            if ( $g('birth_type_nabc') !== '' ) { $p .= ' (' . $g('birth_type_nabc') . ')'; }
            if ( $g('destination_country') !== '' ) { $p .= ', required for submission in ' . $g('destination_country'); }
            $p .= '.';
            $who = $g('who_applying');
            $who_phrase = ( stripos( $who, 'self' ) !== false ) ? 'the applicant themselves' : ( $who !== '' ? $lc( $who ) : '' );
            if ( $who_phrase !== '' || $g('applicant_age') !== '' ) {
                $p .= ' The application is being filed by ' . ( $who_phrase !== '' ? $who_phrase : 'the applicant' ) . ( $g('applicant_age') !== '' ? ', who is ' . $g('applicant_age') . ' years old' : '' ) . '.';
            }
            if ( $g('registration_status') !== '' ) { $p .= ' Registration status — ' . $ex( $g('registration_status') ) . '.'; }
            $c2 = array();
            $dob = $has_clause( $g('has_any_dob_proof'), 'has no existing document showing the date of birth' );
            if ( $dob !== '' ) { $c2[] = $dob; }
            $fam = $g('family_in_india');
            if ( $fam !== '' ) { $c2[] = $lc( $ex( $fam ) ); }
            if ( ! empty( $c2 ) ) { $p .= ' The applicant ' . implode( ', and ', $c2 ) . '.'; }
            $docv = $docs( $g('docs_available') );
            if ( $docv !== '' ) { $p .= ' They have ' . $docv . ' available as supporting documents.'; }
            if ( $g('purpose') !== '' ) { $p .= ' This NABC is required for ' . $g('purpose') . '.'; }
            $tb = array();
            if ( $g('timeline') !== '' ) { $tb[] = 'needs the service ' . $tl( $g('timeline') ); }
            if ( $g('budget_range') !== '' ) { $tb[] = 'has an approximate budget of ' . $lc( $g('budget_range') ); }
            if ( ! empty( $tb ) ) { $p .= ' The applicant ' . implode( ' and ', $tb ) . '.'; }
            $prev = $g('prev_attempt');
            if ( $prev !== '' ) {
                if ( preg_match( '/^(?:no|never|first time|not yet)/i', $prev ) ) {
                    $p .= ' This is their first attempt at getting this done.';
                } else {
                    $p .= ' They have already tried to complete the process themselves' . ( preg_match( '/[—-]\s*(.+)$/u', $prev, $pm ) ? ' but ' . $lc( trim( $pm[1], " .\t" ) ) : '' ) . '.';
                }
            }
            return array( 'text' => $p, 'used' => array( 'birth_type_nabc', 'birth_city', 'birth_state', 'destination_country', 'registration_status', 'applicant_age', 'who_applying', 'has_any_dob_proof', 'family_in_india', 'docs_available', 'purpose', 'timeline', 'budget_range', 'prev_attempt' ) );

        case 11: case 12: case 14: case 15:
            // Genuinely education-document services (university transcript,
            // degree certificate, MOI, migration certificate) — these
            // collect university/college/course fields and are handled by
            // the education branch above via nsh_fd_first(), never reaches
            // here.
            return null;

        case 3: // Apostille & Attestation
            // NOT an education-document request — it apostilles ANY kind
            // of document (birth/marriage/educational/commercial/etc), so
            // it must never be routed to the education-vocabulary branch
            // just because it happens to collect a 'document_type' field.
            $p = $name . ' needs ' . ( $g('document_type') !== '' ? $art( $g('document_type') ) : 'a document' ) . ' apostilled';
            if ( $g('destination_country') !== '' ) { $p .= ' for use in ' . $g('destination_country'); }
            $p .= '.';
            $c1 = array();
            if ( $g('doc_issuing_state') !== '' ) { $c1[] = 'was issued in ' . $g('doc_issuing_state'); }
            $oa = $g('original_available');
            if ( $oa !== '' ) { $c1[] = $yn( $oa ) ? 'has the original document in hand' : 'does not currently have the original document in hand'; }
            if ( ! empty( $c1 ) ) { $p .= ' The document ' . implode( ' and ', $c1 ) . '.'; }
            $c2 = array();
            $pn = $g('pre_notarisation');
            if ( $pn !== '' ) { $c2[] = $yn( $pn ) ? 'has already been notarised' : 'has not yet been notarised'; }
            if ( $g('document_language') !== '' ) { $c2[] = 'is in ' . $lc( $g('document_language') ); }
            if ( ! empty( $c2 ) ) { $p .= ' It ' . implode( ' and ', $c2 ) . '.'; }
            if ( $g('purpose') !== '' ) { $p .= ' Purpose of the Apostille: ' . $lc( $g('purpose') ) . '.'; }
            if ( $g('doc_count') !== '' ) { $p .= ' Number of documents to be apostilled: ' . $g('doc_count') . '.'; }
            $docv = $docs( $g('docs_in_hand') );
            if ( $docv !== '' ) { $p .= ' They currently have ' . $docv . ' in hand.'; }
            $who = $g('who_applying');
            if ( $who !== '' ) { $p .= ' Filling this form: ' . ( stripos( $who, 'self' ) !== false ? 'the applicant themselves' : $lc( $who ) ) . '.'; }
            $tb = array();
            if ( $g('timeline') !== '' ) { $tb[] = 'need this ' . $tl( $g('timeline') ); }
            if ( $g('budget_range') !== '' ) { $tb[] = 'have an approximate budget of ' . $lc( $g('budget_range') ); }
            if ( ! empty( $tb ) ) { $p .= ' They ' . implode( ' and ', $tb ) . '.'; }
            $prev = $g('prev_attempt');
            if ( $prev !== '' ) {
                if ( preg_match( '/^(?:no|never|first time|not yet)/i', $prev ) ) { $p .= ' This is their first attempt at getting this done.'; }
                else { $p .= ' They have already tried to complete the process themselves' . ( preg_match( '/[—-]\s*(.+)$/u', $prev, $pm ) ? ' but ' . $lc( trim( $pm[1], " .\t" ) ) : '' ) . '.'; }
            }
            if ( $g('special_requirements') !== '' ) { $p .= ' Specific requirements or notes: ' . rtrim( $g('special_requirements'), '.' ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'document_type', 'destination_country', 'doc_issuing_state', 'original_available', 'pre_notarisation', 'document_language', 'purpose', 'doc_count', 'docs_in_hand', 'who_applying', 'timeline', 'budget_range', 'prev_attempt', 'special_requirements' ) );

        case 5: // HRD Attestation
            // Also not a generic "education-document" request in the
            // sense the education branch expects (no course selection /
            // admission-year enrollment shape) — this is a document
            // attestation service for an already-issued educational
            // certificate, so it gets its own hand-written narrative too.
            $p = $name . ' needs ' . ( $g('document_type') !== '' ? $art( $g('document_type') ) : 'an educational document' ) . ' HRD attested';
            if ( $g('university_name') !== '' ) { $p .= ' (issued by ' . $g('university_name') . ')'; }
            if ( $g('destination_country') !== '' ) { $p .= ' for use in ' . $g('destination_country'); }
            $p .= '.';
            $c1 = array();
            if ( $g('issuing_state') !== '' ) { $c1[] = 'the issuing university / board is located in ' . $g('issuing_state'); }
            $oa = $g('original_available');
            if ( $oa !== '' ) { $c1[] = $yn( $oa ) ? 'the original document is available' : 'the original document is not currently available'; }
            if ( ! empty( $c1 ) ) { $p .= ' Note that ' . implode( ' and ', $c1 ) . '.'; }
            if ( $g('course_type') !== '' ) { $p .= ' Course / programme: ' . $g('course_type') . '.'; }
            if ( $g('year_passing') !== '' ) { $p .= ' Year of passing / issue: ' . $g('year_passing') . '.'; }
            if ( $g('purpose') !== '' ) { $p .= ' Purpose: ' . $lc( $g('purpose') ) . '.'; }
            if ( $g('copies_required') !== '' ) { $p .= ' Number of attested copies required: ' . $g('copies_required') . '.'; }
            $ac = $g('attestation_chain');
            if ( $ac !== '' ) { $p .= ' ' . ( $yn( $ac ) ? 'Additional attestation is required after HRD' : 'No additional attestation is required after HRD' ) . '.'; }
            $es = $g('employer_specified');
            if ( $es !== '' ) {
                if ( $yn( $es ) ) { $p .= ' The employer / university has specified the exact attestation required' . ( preg_match( '/[—-]\s*(.+)$/u', $es, $em ) ? ': ' . $lc( trim( $em[1], " .\t" ) ) : '' ) . '.'; }
                else { $p .= ' The employer / university has not specified the exact attestation required.'; }
            }
            $tb = array();
            if ( $g('timeline') !== '' ) { $tb[] = 'need this ' . $tl( $g('timeline') ); }
            if ( $g('budget_range') !== '' ) { $tb[] = 'have an approximate budget of ' . $lc( $g('budget_range') ); }
            if ( ! empty( $tb ) ) { $p .= ' They ' . implode( ' and ', $tb ) . '.'; }
            $prev = $g('prev_attempt');
            if ( $prev !== '' ) {
                if ( preg_match( '/^(?:no|never|first time|not yet)/i', $prev ) ) { $p .= ' This is their first attempt at getting this done.'; }
                else { $p .= ' They have already tried to complete the process themselves' . ( preg_match( '/[—-]\s*(.+)$/u', $prev, $pm2 ) ? ' but ' . $lc( trim( $pm2[1], " .\t" ) ) : '' ) . '.'; }
            }
            return array( 'text' => $p, 'used' => array( 'document_type', 'university_name', 'destination_country', 'issuing_state', 'original_available', 'course_type', 'year_passing', 'purpose', 'copies_required', 'attestation_chain', 'employer_specified', 'timeline', 'budget_range', 'prev_attempt' ) );

        case 8: // Document Translation Services
            // Also not an education-document request — translates ANY
            // document type, so a 'document_type' field alone must not
            // route it into the education branch either.
            $p = $name . ' needs ' . ( $g('document_type') !== '' ? $art( $g('document_type') ) : 'a document' ) . ' translated';
            if ( $g('source_language') !== '' && $g('target_language') !== '' ) { $p .= ' from ' . $g('source_language') . ' to ' . $g('target_language'); }
            elseif ( $g('target_language') !== '' ) { $p .= ' into ' . $g('target_language'); }
            $p .= '.';
            $nc = $g('need_certified');
            if ( $nc !== '' ) { $p .= ' ' . ( $yn( $nc ) ? 'A certified / notarised translation is required' : 'A certified / notarised translation is not required' ) . '.'; }
            if ( $g('doc_count') !== '' ) { $p .= ' Number of pages / documents: ' . $g('doc_count') . '.'; }
            if ( $g('purpose') !== '' ) { $p .= ' Purpose: ' . $lc( $g('purpose') ) . '.'; }
            if ( $g('urgency') !== '' ) { $p .= ' Urgency: ' . $lc( $g('urgency') ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'document_type', 'source_language', 'target_language', 'need_certified', 'doc_count', 'purpose', 'urgency' ) );

        case 4: // Affidavit Services
            $p = $name . ' needs ' . ( $g('affidavit_type') !== '' ? $art( $g('affidavit_type') ) : 'an affidavit' );
            if ( $g('deponent_name') !== '' ) { $p .= ' for ' . $g('deponent_name') . ( $g('deponent_dob') !== '' ? ' (DOB ' . $g('deponent_dob') . ')' : '' ); }
            $p .= '.';
            $extras = array();
            if ( $g('notarisation_needed') !== '' ) { $extras[] = ( $yn( $g('notarisation_needed') ) ? 'notarisation is required' : 'notarisation is not required' ); }
            if ( $g('attestation_needed') !== '' ) { $extras[] = ( strtolower( $g('attestation_needed') ) === 'no' ? 'no apostille/attestation is needed' : $lc( $g('attestation_needed') ) . ' is also required' ); }
            if ( ! empty( $extras ) ) { $p .= ' ' . ucfirst( implode( ', and ', $extras ) ) . '.'; }
            if ( $g('purpose') !== '' ) { $p .= ' This affidavit will be used for ' . $lc( $g('purpose') ) . '.'; }
            if ( $g('special_content') !== '' ) { $p .= ' Specific wording requested: ' . rtrim( $g('special_content'), '.' ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'affidavit_type', 'deponent_name', 'deponent_dob', 'notarisation_needed', 'attestation_needed', 'purpose', 'special_content' ) );

        case 6: // Police Clearance Certificate
            $p = $name . ' needs a Police Clearance Certificate';
            if ( $g('destination_country') !== '' ) { $p .= ' for ' . $g('destination_country'); }
            if ( $g('purpose') !== '' ) { $p .= ', required for ' . $lc( $g('purpose') ); }
            $p .= '.';
            if ( $g('passport_status') !== '' ) { $p .= ' Their passport (No. ' . ( $g('passport_number') ?: 'not given' ) . ') is currently ' . $g('passport_status') . ( $g('passport_expiry') !== '' ? ', expiring ' . $g('passport_expiry') : '' ) . '.'; }
            $loc = $j( $g('indian_district'), $g('indian_state') );
            if ( $loc !== '' ) { $p .= ' Their last Indian address was in ' . $loc . ( $g('address_on_passport') !== '' ? ' (' . $ex( $g('address_on_passport') ) . ')' : '' ) . '.'; }
            if ( $g('criminal_history') !== '' ) {
                $ch = $g('criminal_history');
                $p .= ' ' . ( preg_match( '/^no\b/i', $ch ) ? 'They have never been arrested, detained, or convicted in India' : 'Regarding criminal history: ' . $lc( $ex( $ch ) ) ) . '.';
            }
            $c2 = array();
            if ( $g('nri_duration') !== '' ) { $c2[] = 'has been an NRI for ' . $lc( $g('nri_duration') ); }
            if ( $g('visa_status') !== '' ) { $c2[] = 'currently holds ' . $art( $g('visa_status') ) . ' in the destination country'; }
            if ( ! empty( $c2 ) ) { $p .= ' The applicant ' . implode( ' and ', $c2 ) . '.'; }
            $tb = array();
            if ( $g('timeline') !== '' ) { $tb[] = 'needs the service ' . $tl( $g('timeline') ); }
            if ( ! empty( $tb ) ) { $p .= ' The applicant ' . implode( ' and ', $tb ) . '.'; }
            $prev = $g('prev_attempt');
            if ( $prev !== '' ) {
                if ( preg_match( '/^(?:no|never|first time|not yet)/i', $prev ) ) {
                    $p .= ' This is their first attempt at getting this done.';
                } else {
                    $p .= ' They have already tried to complete the process themselves' . ( preg_match( '/[—-]\s*(.+)$/u', $prev, $pm ) ? ' but ' . $lc( trim( $pm[1], " .\t" ) ) : '' ) . '.';
                }
            }
            return array( 'text' => $p, 'used' => array( 'destination_country', 'purpose', 'indian_state', 'indian_district', 'criminal_history', 'passport_status', 'passport_number', 'passport_expiry', 'address_on_passport', 'nri_duration', 'visa_status', 'timeline', 'prev_attempt' ) );

        case 7: // Single Status / Bachelorhood Certificate
            $p = $name . ' needs a Single Status / Bachelorhood Certificate';
            if ( $g('destination_country') !== '' ) { $p .= ' for use in ' . $g('destination_country'); }
            $p .= '. Their current marital status is ' . ( $g('current_marital_status') !== '' ? $g('current_marital_status') : 'unspecified' ) . ( $g('passport_number') !== '' ? ' (Passport No. ' . $g('passport_number') . ')' : '' ) . '.';
            $hd = $g('has_divorce_decree');
            if ( $hd !== '' ) {
                if ( $yn( $hd ) ) { $p .= ' A court divorce decree is available.'; }
                elseif ( stripos( $hd, 'lost' ) !== false ) { $p .= ' Their divorce decree has been lost.'; }
                elseif ( $hd !== '' ) { $p .= ' ' . ucfirst( $lc( $hd ) ) . '.'; }
            }
            if ( $g('purpose') !== '' ) { $p .= ' Required for ' . $lc( $g('purpose') ) . '.'; }
            if ( $g('notarisation_needed') !== '' ) { $p .= ' Attestation required: ' . $lc( $g('notarisation_needed') ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'destination_country', 'current_marital_status', 'has_divorce_decree', 'applicant_name', 'dob', 'passport_number', 'purpose', 'notarisation_needed' ) );

        case 9: // Rent Agreement / Lease Deed
            $p = $name . ' needs a rent agreement';
            $loc = $j( $g('property_city'), $g('property_state') );
            if ( $loc !== '' ) { $p .= ' for a property in ' . $loc; }
            $p .= ', ' . ( $yn( $g('registration_needed') ) ? 'requiring Sub-Registrar registration' : 'not requiring Sub-Registrar registration' ) . '.';
            if ( $g('property_address') !== '' ) { $p .= ' Property address: ' . rtrim( $g('property_address'), '.' ) . '.'; }
            if ( $g('owner_name') !== '' || $g('tenant_name') !== '' ) {
                $p .= ' Between ' . ( $g('owner_name') ?: 'the owner' ) . ' and ' . ( $g('tenant_name') ?: 'the tenant' ) . ( $g('lease_period') !== '' ? ', for a ' . $g('lease_period') . ' term' : '' ) . ( $g('start_date') !== '' ? ' starting ' . $g('start_date') : '' ) . '.';
            }
            $money = array();
            if ( $g('monthly_rent') !== '' ) { $money[] = 'a monthly rent of ' . $g('monthly_rent'); }
            if ( $g('security_deposit') !== '' ) { $money[] = 'a security deposit of ' . $g('security_deposit'); }
            if ( ! empty( $money ) ) { $p .= ' The agreement is for ' . implode( ' and ', $money ) . ( $g('furnishing') !== '' ? ', on a ' . $lc( $g('furnishing') ) . ' basis' : '' ) . '.'; }
            elseif ( $g('furnishing') !== '' ) { $p .= ' Furnishing status: ' . $g('furnishing') . '.'; }
            return array( 'text' => $p, 'used' => array( 'registration_needed', 'property_city', 'property_state', 'owner_name', 'tenant_name', 'lease_period', 'monthly_rent', 'property_address', 'furnishing', 'start_date', 'security_deposit' ) );

        case 10: // Rent Collection Service
            $p = $name . ' needs rent collection assistance';
            $loc = $j( $g('property_city'), $g('property_state') );
            if ( $loc !== '' ) { $p .= ' for their property in ' . $loc; }
            if ( $g('property_address') !== '' ) { $p .= ' (' . rtrim( $g('property_address'), '.' ) . ')'; }
            $p .= '.';
            if ( $g('tenant_name') !== '' ) { $p .= ' The current tenant is ' . $g('tenant_name') . ( $g('monthly_rent') !== '' ? ', paying ' . $g('monthly_rent') . ' per month' : '' ) . ( $g('rent_due_date') !== '' ? ', due on the ' . $g('rent_due_date') : '' ) . '.'; }
            if ( $g('rent_arrears') !== '' ) { $p .= ' ' . ( $yn( $g('rent_arrears') ) ? 'The tenant is current on rent' : ucfirst( $lc( $ex( $g('rent_arrears') ) ) ) ) . '.'; }
            if ( $g('collection_method') !== '' ) { $p .= ' Preferred collection method: ' . $g('collection_method') . '.'; }
            $bank = $g('has_bank_account');
            if ( $bank !== '' ) {
                if ( preg_match( '/^yes\s*[—-]\s*(.+)$/iu', $bank, $bm ) ) { $p .= ' They already have ' . $art( trim( $bm[1], " .\t" ) ) . ' in India.'; }
                elseif ( stripos( $bank, 'no' ) === 0 ) { $p .= ' They do not yet have an NRE or NRO account and will need to open one.'; }
            }
            if ( $g('lease_expiry') !== '' ) { $p .= ' Current lease expires ' . $g('lease_expiry') . '.'; }
            return array( 'text' => $p, 'used' => array( 'property_city', 'property_state', 'tenant_name', 'monthly_rent', 'rent_arrears', 'collection_method', 'has_bank_account', 'rent_due_date', 'lease_expiry', 'property_address' ) );

        case 13: // Duplicate Marksheet
            $p = $name . ' needs a duplicate marksheet';
            if ( $g('institution_name') !== '' || $g('board_university') !== '' ) { $p .= ' from ' . $j( $g('institution_name'), $g('board_university') ); }
            if ( $g('year_exam') !== '' ) { $p .= ', examination year ' . $g('year_exam'); }
            if ( $g('enrollment_no') !== '' ) { $p .= ' (Roll/Enrollment No. ' . $g('enrollment_no') . ')'; }
            $p .= '.';
            if ( $g('reason_duplicate') !== '' ) { $p .= ' Reason: the original was ' . $g('reason_duplicate') . '.'; }
            $fir = $g('has_fir');
            if ( $fir !== '' ) { $p .= ' ' . ( $yn( $fir ) ? 'A police FIR has been filed for the loss.' : 'No police FIR has been filed yet.' ); }
            $aff = $g('affidavit_needed');
            if ( $aff !== '' ) { $p .= ' ' . ( $yn( $aff ) ? 'A lost-certificate affidavit needs to be prepared.' : ( stripos( $aff, 'already' ) !== false ? 'They already have a lost-certificate affidavit.' : '' ) ); }
            return array( 'text' => $p, 'used' => array( 'institution_name', 'board_university', 'year_exam', 'reason_duplicate', 'has_fir', 'affidavit_needed', 'enrollment_no' ) );

        case 16: // Character / Conduct Certificate
            $p = $name . ' needs a Character / Conduct Certificate from ' . ( $g('institution_type') !== '' ? $g('institution_type') : 'their institution' );
            if ( $g('institution_name') !== '' ) { $p .= ' (' . $g('institution_name') . ')'; }
            if ( $g('destination_country') !== '' ) { $p .= ', required for ' . $g('destination_country'); }
            $p .= '.';
            if ( $g('purpose') !== '' ) { $p .= ' Purpose: ' . $g('purpose') . '.'; }
            if ( $g('enrollment_or_emp_no') !== '' ) { $p .= ' Enrollment/Employee Number: ' . $g('enrollment_or_emp_no') . ( $g('year_attended') !== '' ? ', ' . $g('year_attended') : '' ) . '.'; }
            elseif ( $g('year_attended') !== '' ) { $p .= ' Year/period: ' . $g('year_attended') . '.'; }
            if ( $g('attestation_needed') !== '' ) { $p .= ' Attestation: ' . $g('attestation_needed') . '.'; }
            return array( 'text' => $p, 'used' => array( 'institution_type', 'institution_name', 'destination_country', 'purpose', 'enrollment_or_emp_no', 'year_attended', 'attestation_needed' ) );

        case 17: // OCI Card (New Application)
            $p = $name . ' is applying for a new OCI card, currently holding ' . ( $g('country_of_citizenship') !== '' ? $g('country_of_citizenship') . ' citizenship' : 'foreign citizenship' ) . ( $g('foreign_passport_no') !== '' ? ' (Passport No. ' . $g('foreign_passport_no') . ')' : '' ) . '.';
            $elig = $g('is_eligible');
            if ( $elig !== '' ) { $p .= ' Eligibility basis: ' . $ex( $elig ) . '.'; }
            $pak = $g('has_pakistani_citizenship');
            if ( $pak !== '' && $yn( $pak ) ) { $p .= ' They have previously held citizenship of Pakistan or Bangladesh, which affects OCI eligibility.'; }
            if ( $g('ever_held_indian_passport') !== '' && $yn( $g('ever_held_indian_passport') ) ) { $p .= ' They previously held Indian Passport No. ' . ( $g('indian_passport_no') ?: '(number not given)' ) . '.'; }
            if ( $g('consulate') !== '' ) { $p .= ' Application to be filed at ' . $g('consulate') . '.'; }
            return array( 'text' => $p, 'used' => array( 'country_of_citizenship', 'ever_held_indian_passport', 'indian_passport_no', 'consulate', 'is_eligible', 'has_pakistani_citizenship', 'foreign_passport_no' ) );

        case 18: // OCI Card Renewal
            $p = $name . ' needs their OCI card renewed';
            if ( $g('oci_card_number') !== '' ) { $p .= ' (Card No. ' . $g('oci_card_number') . ', ' . ( $g('oci_format') !== '' ? $art( $g('oci_format') ) : 'a card' ) . ')'; }
            $np = $g('has_new_passport');
            $p .= ', ' . ( $np !== '' ? $lc( $ex( $np ) ) : 'following a new foreign passport' ) . ( $g('new_passport_number') !== '' ? ' (' . $g('new_passport_number') . ', previously ' . ( $g('old_passport_number') ?: 'unspecified' ) . ')' : '' ) . '.';
            $nc = $g('name_change');
            if ( $nc !== '' && ! preg_match( '/^no\b/i', $nc ) ) { $p .= ' Their name has changed since the OCI was issued — ' . $lc( $nc ) . '.'; }
            $scans = array();
            $ps = $has_clause( $g('has_passport_scan'), '' );
            if ( $g('has_passport_scan') !== '' ) { $scans[] = $yn( $g('has_passport_scan') ) ? 'a scan of the new passport is ready' : 'the new passport still needs to be scanned'; }
            $os = $g('has_oci_scan');
            if ( $os !== '' ) { $scans[] = $yn( $os ) ? 'a scan of the current OCI card is ready' : 'the current OCI card still needs to be scanned'; }
            if ( ! empty( $scans ) ) { $p .= ' ' . ucfirst( implode( ', and ', $scans ) ) . '.'; }
            if ( $g('urgency') !== '' ) { $p .= ' Travel urgency: ' . $g('urgency') . ( $g('travel_date') !== '' ? ' (' . $g('travel_date') . ')' : '' ) . '.'; }
            $who = $g('who_applying');
            if ( $who !== '' && stripos( $who, 'self' ) === false ) { $p .= ' Filed by: ' . $lc( $who ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'oci_card_number', 'new_passport_number', 'old_passport_number', 'name_change', 'urgency', 'travel_date', 'consulate', 'has_oci', 'has_new_passport', 'oci_format', 'has_passport_scan', 'has_oci_scan', 'who_applying' ) );

        case 19: // OCI Card Update / Corrections
            $p = $name . ' needs their OCI card updated — ' . ( $g('change_type') !== '' ? $g('change_type') : 'a correction' ) . ( $g('oci_card_number') !== '' ? ' (Card No. ' . $g('oci_card_number') . ')' : '' ) . '.';
            $sup = $g('has_supporting_doc');
            if ( $sup !== '' ) { $p .= ' ' . ( $yn( $sup ) ? 'The supporting document for this change is ready.' : 'The supporting document for this change still needs to be arranged.' ); }
            if ( $g('consulate') !== '' ) { $p .= ' To be filed at ' . $g('consulate') . '.'; }
            return array( 'text' => $p, 'used' => array( 'change_type', 'oci_card_number', 'consulate', 'has_oci_card', 'has_supporting_doc' ) );

        case 20: // Indian Passport Renewal
            $p = $name . ' needs their Indian passport renewed — ' . ( $g('renewal_reason') !== '' ? $g('renewal_reason') : 'reason not specified' ) . ( $g('current_passport_no') !== '' ? ' (Passport No. ' . $g('current_passport_no') . ', expiring ' . ( $g('passport_expiry') ?: 'unspecified' ) . ')' : '' ) . '.';
            $fir = $g('has_fir');
            if ( $fir !== '' ) { $p .= ' ' . ( $yn( $fir ) ? 'A police report for the lost passport has been filed.' : 'No police report has been filed yet for the lost passport.' ); }
            if ( $g('consulate') !== '' ) { $p .= ' To be filed at ' . $g('consulate') . ' in ' . ( $g('country_residing') ?: 'their country of residence' ) . '.'; }
            if ( $g('has_oci_card') !== '' && $yn( $g('has_oci_card') ) && $g('oci_renewal_needed') !== '' ) { $p .= ' Their OCI card ' . ( $yn( $g('oci_renewal_needed') ) ? 'should also be renewed alongside the passport' : 'does not need renewal at this time' ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'renewal_reason', 'current_passport_no', 'consulate', 'country_residing', 'has_oci_card', 'oci_renewal_needed', 'has_fir', 'passport_expiry' ) );

        case 21: // India Tourist / Business e-Visa
            $p = $name . ' needs ' . ( $g('visa_type') !== '' ? $art( $g('visa_type') ) : 'a visa' ) . ' for India';
            if ( $g('travel_date') !== '' ) { $p .= ', planned travel date ' . $g('travel_date'); }
            if ( $g('duration_of_stay') !== '' ) { $p .= ', staying ' . $g('duration_of_stay'); }
            $p .= '.';
            if ( $g('nationality') !== '' ) { $p .= ' Passport/nationality: ' . $g('nationality') . ( $g('passport_number') !== '' ? ' (No. ' . $g('passport_number') . ', expiring ' . ( $g('passport_expiry') ?: 'unspecified' ) . ')' : '' ) . '.'; }
            $oci = $g('is_oci_holder');
            if ( $oci !== '' && ! preg_match( '/^no\b/i', $oci ) ) { $p .= ' ' . ucfirst( $lc( $ex( $oci ) ) ) . '.'; }
            $pv = $g('passport_validity_ok');
            if ( $pv !== '' && ! $yn( $pv ) ) { $p .= ' Their passport is NOT valid for at least 6 months beyond the travel date — this needs to be resolved first.'; }
            return array( 'text' => $p, 'used' => array( 'visa_type', 'travel_date', 'duration_of_stay', 'nationality', 'is_oci_holder', 'passport_validity_ok', 'passport_number', 'passport_expiry' ) );

        case 22: // Overseas Visa Application Assistance
            $p = $name . ' needs help applying for a ' . ( $g('visa_type') !== '' ? $g('visa_type') : 'visa' ) . ' to ' . ( $g('destination_country') ?: 'their destination country' );
            if ( $g('travel_date') !== '' ) { $p .= ', planned for ' . $g('travel_date'); }
            $p .= ( $g('passport_number') !== '' ? ' (Indian Passport No. ' . $g('passport_number') . ')' : '' ) . '.';
            if ( $g('has_previous_refusal') !== '' ) { $p .= ' ' . ( $yn( $g('has_previous_refusal') ) ? ucfirst( $lc( $ex( $g('has_previous_refusal') ) ) ) . '.' : 'They have never been refused a visa to any country.' ); }
            if ( $g('employment_status') !== '' ) { $p .= ' Current employment status: ' . $g('employment_status') . '.'; }
            $pv = $g('passport_validity_ok');
            if ( $pv !== '' && ! $yn( $pv ) ) { $p .= ' Their Indian passport is NOT currently valid for at least 6 months from the travel date.'; }
            return array( 'text' => $p, 'used' => array( 'destination_country', 'visa_type', 'travel_date', 'has_previous_refusal', 'employment_status', 'passport_validity_ok', 'passport_number' ) );

        case 23: // EAD Assistance
            $p = $name . ' needs EAD (Employment Authorization Document) assistance — current US immigration status: ' . ( $g('current_status') !== '' ? $g('current_status') : 'not specified' ) . ( $g('state') !== '' ? ', ' . $g('state') : '' ) . '.';
            $ex_ead = $g('has_existing_ead');
            if ( $ex_ead !== '' ) {
                if ( stripos( $ex_ead, 'no' ) === 0 ) { $p .= ' This is their first EAD application.'; }
                else { $p .= ' ' . ucfirst( $lc( $ex( $ex_ead ) ) ) . ( $g('ead_expiry') !== '' ? ', current EAD expiring ' . $g('ead_expiry') : '' ) . '.'; }
            }
            $rcpt = $g('uscis_receipt');
            if ( $rcpt !== '' ) { $p .= ' ' . ( $yn( $rcpt ) ? 'An active USCIS receipt is on file for the underlying case' . ( $g('uscis_receipt_no') !== '' ? ' (' . $g('uscis_receipt_no') . ')' : '' ) : ucfirst( $lc( $ex( $rcpt ) ) ) ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'current_status', 'has_existing_ead', 'ead_expiry', 'uscis_receipt', 'uscis_receipt_no', 'state' ) );

        case 24: // Green Card (Family-Based)
            $p = $name . ' needs Green Card assistance via the ' . ( $g('gc_pathway') !== '' ? $g('gc_pathway') : 'family-based' ) . ' pathway' . ( $g('petitioner_type') !== '' ? ', petitioner: ' . $g('petitioner_type') : '' ) . '.';
            $p .= ' Filing ' . ( $g('process_type') !== '' ? $g('process_type') : 'location not specified' ) . ', current US immigration status: ' . ( $g('current_status') !== '' ? $g('current_status') : 'not specified' ) . ( $g('state') !== '' ? ' (' . $g('state') . ')' : '' ) . '.';
            $ch = $g('has_criminal_history');
            if ( $ch !== '' ) { $p .= ' ' . ( stripos( $ch, 'no' ) === 0 ? 'There is no criminal history to disclose.' : 'Criminal history to disclose: ' . $lc( $ex( $ch ) ) . '.' ); }
            return array( 'text' => $p, 'used' => array( 'gc_pathway', 'petitioner_type', 'process_type', 'current_status', 'has_criminal_history', 'state' ) );

        case 25: // Green Card Renewal
            $p = $name . ' needs their Green Card renewed — ' . ( $g('reason_renewal') !== '' ? $g('reason_renewal') : 'reason not specified' ) . ( $g('gc_expiry') !== '' ? ', expiring ' . $g('gc_expiry') : '' ) . ( $g('alien_number') !== '' ? ' (A-Number ' . $g('alien_number') . ')' : '' ) . ( $g('state') !== '' ? ', ' . $g('state') : '' ) . '.';
            if ( $g('gc_expiring_soon') !== '' ) { $p .= ' ' . $g('gc_expiring_soon') . '.'; }
            if ( $g('has_police_report') !== '' && $yn( $g('has_police_report') ) ) { $p .= ' A police report for the lost/stolen card is available.'; }
            elseif ( $g('has_police_report') !== '' ) { $p .= ' No police report has been filed yet.'; }
            $cr = $g('any_criminal_record');
            if ( $cr !== '' ) { $p .= ' ' . ( stripos( $cr, 'no' ) === 0 ? 'There is no criminal record since the card was issued.' : 'Criminal record since issuance: ' . $lc( $ex( $cr ) ) . '.' ); }
            return array( 'text' => $p, 'used' => array( 'reason_renewal', 'gc_expiry', 'gc_expiring_soon', 'alien_number', 'has_police_report', 'any_criminal_record', 'state' ) );

        case 26: // US Citizenship (Naturalization)
            $p = $name . ' is applying for US Citizenship, eligible on the basis of ' . ( $g('basis_of_eligibility') !== '' ? $g('basis_of_eligibility') : 'not specified' ) . ( $g('gc_since') !== '' ? ', Green Card holder since ' . $g('gc_since') : '' ) . ( $g('alien_number') !== '' ? ' (A-Number ' . $g('alien_number') . ')' : '' ) . ( $g('state') !== '' ? ', ' . $g('state') : '' ) . '.';
            $checks = array();
            if ( $g('has_continuous_residence') !== '' ) { $checks[] = ( $yn( $g('has_continuous_residence') ) ? '' : 'not ' ) . 'maintained continuous US residence'; }
            if ( $g('has_criminal_record') !== '' ) { $checks[] = ( $yn( $g('has_criminal_record') ) ? 'has a criminal record' : 'no criminal record' ); }
            if ( ! empty( $checks ) ) { $p .= ' They have ' . implode( ' and ', $checks ) . '.'; }
            if ( $g('english_proficiency') !== '' ) { $p .= ' English proficiency: ' . $lc( $ex( $g('english_proficiency') ) ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'basis_of_eligibility', 'gc_since', 'alien_number', 'has_continuous_residence', 'has_criminal_record', 'english_proficiency', 'state' ) );

        case 27: // Complete Property Management
            $p = $name . ' needs complete property management — ' . implode( ', ', array_filter( array( $g('services_needed') ) ) );
            $loc = $j( $g('property_city'), $g('property_state') );
            if ( $loc !== '' ) { $p .= ' for a ' . ( $g('property_type') !== '' ? $g('property_type') : 'property' ) . ' in ' . $loc; }
            $p .= '.';
            if ( $g('current_status') !== '' ) { $p .= ' Current property status: ' . $g('current_status') . '.'; }
            if ( $g('has_property_documents') !== '' ) { $p .= ' Property documents: ' . $lc( $ex( $g('has_property_documents') ) ) . '.'; }
            if ( $g('expected_rent') !== '' ) { $p .= ' Expected monthly rent: ' . $g('expected_rent') . '.'; }
            return array( 'text' => $p, 'used' => array( 'services_needed', 'property_type', 'property_city', 'property_state', 'current_status', 'has_property_documents', 'expected_rent', 'property_address' ) );

        case 28: // Property Inspection Report
            $p = $name . ' needs a property inspection — ' . ( $g('inspection_purpose') !== '' ? $g('inspection_purpose') : 'reason not specified' );
            $loc = $j( $g('property_city'), $g('property_state') );
            if ( $loc !== '' ) { $p .= ' for a ' . ( $g('property_type') !== '' ? $g('property_type') : 'property' ) . ' in ' . $loc; }
            $p .= ( $g('preferred_date') !== '' ? ', preferred date ' . $g('preferred_date') : '' ) . '.';
            if ( $g('video_report_needed') !== '' ) { $p .= ' Report format: ' . $g('video_report_needed') . '.'; }
            if ( $g('areas_to_inspect') !== '' ) { $p .= ' Areas to inspect: ' . $lc( $g('areas_to_inspect') ) . '.'; }
            if ( $g('access_available') !== '' ) { $p .= ' Access arrangement: ' . $g('access_available') . '.'; }
            return array( 'text' => $p, 'used' => array( 'inspection_purpose', 'property_city', 'property_state', 'property_type', 'video_report_needed', 'access_available', 'preferred_date', 'areas_to_inspect', 'property_address' ) );

        case 29: // Tenancy Management
            $p = $name . ' needs tenancy management';
            $loc = $j( $g('property_city'), $g('property_state') );
            if ( $loc !== '' ) { $p .= ' for a ' . ( $g('property_type') !== '' ? $g('property_type') : 'property' ) . ' in ' . $loc; }
            $p .= ', current status: ' . ( $g('current_status') !== '' ? $g('current_status') : 'not specified' ) . '.';
            if ( $g('preferred_tenant') !== '' ) { $p .= ' Preferred tenant type: ' . $g('preferred_tenant') . '.'; }
            if ( $g('expected_rent') !== '' ) { $p .= ' Expected monthly rent: ' . $g('expected_rent') . ( $g('furnishing') !== '' ? ' (' . $lc( $g('furnishing') ) . ')' : '' ) . '.'; }
            elseif ( $g('furnishing') !== '' ) { $p .= ' Furnishing status: ' . $g('furnishing') . '.'; }
            return array( 'text' => $p, 'used' => array( 'property_city', 'property_state', 'property_type', 'current_status', 'preferred_tenant', 'expected_rent', 'furnishing', 'property_address' ) );

        case 30: // Encumbrance Certificate
            $p = $name . ' needs an Encumbrance Certificate — ' . ( $g('purpose') !== '' ? $g('purpose') : 'purpose not specified' );
            $loc = $j( $g('property_city'), $g('property_state') );
            if ( $loc !== '' ) { $p .= ' for a property in ' . $loc; }
            if ( $g('survey_no') !== '' ) { $p .= ' (Survey/Plot No. ' . $g('survey_no') . ')'; }
            if ( $g('period_required') !== '' ) { $p .= ', covering ' . $g('period_required'); }
            $p .= '.';
            $docv = $g('has_property_documents');
            if ( $docv !== '' ) { $p .= ' Property documents (sale deed / patta): ' . $lc( $ex( $docv ) ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'purpose', 'property_city', 'property_state', 'survey_no', 'period_required', 'has_property_documents', 'property_address' ) );

        case 31: // Property Title Search & Verification
            $p = $name . ' needs a property title search — ' . ( $g('transaction_type') !== '' ? $g('transaction_type') : 'purpose not specified' );
            $loc = $j( $g('property_city'), $g('property_state') );
            if ( $loc !== '' ) { $p .= ' for a property in ' . $loc; }
            if ( $g('years_to_check') !== '' ) { $p .= ', covering ' . $g('years_to_check'); }
            $p .= '.';
            $disp = $g('known_legal_disputes');
            if ( $disp !== '' ) { $p .= ' ' . ( $yn( $disp ) ? 'There are known disputes or claims on this property.' : ( stripos( $disp, 'not sure' ) !== false ? 'They are not sure whether there are any existing disputes on the property.' : 'To the applicant\'s knowledge, the property title is clear.' ) ); }
            return array( 'text' => $p, 'used' => array( 'transaction_type', 'property_city', 'property_state', 'years_to_check', 'known_legal_disputes', 'property_address' ) );

        case 32: // Housekeeping & Caretaking
            $p = $name . ' needs ' . ( $g('service_frequency') !== '' ? $art( $g('service_frequency') . ' housekeeping/caretaking service' ) : 'housekeeping/caretaking' );
            $loc = $j( $g('property_city'), $g('property_state') );
            if ( $loc !== '' ) { $p .= ' for a ' . ( $g('property_size') !== '' ? $g('property_size') : 'property' ) . ' in ' . $loc; }
            $p .= '.';
            if ( $g('property_vacant') !== '' ) { $p .= ' The property is currently ' . ( $yn( $g('property_vacant') ) ? 'vacant' : ( stripos( $g('property_vacant'), 'partial' ) !== false ? 'partially occupied' : 'occupied by a tenant' ) ) . '.'; }
            if ( $g('services_needed') !== '' ) { $p .= ' Services required: ' . $g('services_needed') . '.'; }
            if ( $g('access_details') !== '' ) { $p .= ' Access: ' . $g('access_details') . '.'; }
            return array( 'text' => $p, 'used' => array( 'service_frequency', 'property_city', 'property_state', 'property_vacant', 'services_needed', 'access_details', 'property_size', 'property_address' ) );

        case 33: // Financial Planning & Advisory
            $p = $name . ' needs financial planning/advisory — ' . ( $g('services_needed') ?: 'services not specified' ) . '.';
            if ( $g('investment_amount') !== '' ) { $p .= ' Approximate investment/asset value: ' . $g('investment_amount') . ', risk appetite: ' . ( $g('risk_appetite') !== '' ? $g('risk_appetite') : 'not specified' ) . '.'; }
            $pan = $g('has_pan_card');
            if ( $pan !== '' ) { $p .= ' ' . ( $yn( $pan ) ? 'They have an active PAN card.' : 'They still need to apply for a PAN card.' ); }
            $inv = $g('existing_investments');
            if ( $inv !== '' ) { $p .= ' Existing investments in India: ' . $lc( $ex( $inv ) ) . '.'; }
            if ( $g('timeline') !== '' ) { $p .= ' Investment timeline: ' . $g('timeline') . '.'; }
            if ( $g('residency_years') !== '' ) { $p .= ' They have been an NRI for ' . $lc( $g('residency_years') ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'services_needed', 'investment_amount', 'risk_appetite', 'has_pan_card', 'existing_investments', 'timeline', 'residency_years', 'country_residing' ) );

        case 34: // NRE / NRO Account Opening
            $p = $name . ' needs to open ' . ( $g('account_type') !== '' ? $art( $g('account_type') ) : 'an NRE/NRO account' ) . ( $g('preferred_bank') !== '' ? ' with ' . $g('preferred_bank') : '' ) . '.';
            if ( $g('has_existing_india_account') !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $g('has_existing_india_account') ) ) ) . '.'; }
            if ( $g('fund_source') !== '' ) { $p .= ' Primary source of funds: ' . $g('fund_source') . '.'; }
            $pan = $g('has_pan_card');
            $addr = $g('has_foreign_address_proof');
            $ready = array();
            if ( $pan !== '' ) { $ready[] = $yn( $pan ) ? 'have an active PAN card' : 'still need to apply for a PAN card'; }
            if ( $addr !== '' ) { $ready[] = $yn( $addr ) ? 'have address proof for their country of residence (' . $lc( $ex( $addr ) ) . ')' : 'still need to arrange address proof for their country of residence'; }
            if ( ! empty( $ready ) ) { $p .= ' They ' . implode( ' and ', $ready ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'account_type', 'preferred_bank', 'has_existing_india_account', 'fund_source', 'has_pan_card', 'has_foreign_address_proof', 'country_residing' ) );

        case 35: // EPF / PF Withdrawal
            $p = $name . ' needs PF withdrawal assistance — ' . ( $g('withdrawal_type') !== '' ? $g('withdrawal_type') : 'type not specified' ) . '. UAN status: ' . ( $g('uan_status') !== '' ? $g('uan_status') : 'not specified' ) . ( $g('uan_number') !== '' ? ' (' . $g('uan_number') . ')' : '' ) . '.';
            if ( $g('employer_name') !== '' ) { $p .= ' Last employer: ' . $g('employer_name') . ( $g('date_leaving') !== '' ? ', left on ' . $g('date_leaving') : '' ) . ( $g('employer_count') !== '' ? ' (' . $g('employer_count') . ' employer(s) contributed to PF in total)' : '' ) . '.'; }
            $emp = $g('currently_employed');
            if ( $emp !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $emp ) ) ) . '.'; }
            $tr = $g('transfer_needed');
            if ( $tr !== '' && $yn( $tr ) ) { $p .= ' PF from a previous employer needs to be transferred/merged into the current UAN first.'; }
            $kyc = $g('kyc_seeding');
            if ( $kyc !== '' ) { $p .= ' KYC linking: ' . $kyc . '.'; }
            $aad = $g('aadhaar_linked');
            if ( $aad !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $aad ) ) ) . '.'; }
            $docv = $docs( $g('docs_available') );
            if ( $docv !== '' ) { $p .= ' They have ' . $docv . ' available.'; }
            $tb = array();
            if ( $g('budget_range') !== '' ) { $tb[] = 'has an approximate budget of ' . $lc( $g('budget_range') ); }
            if ( ! empty( $tb ) ) { $p .= ' The applicant ' . implode( ' and ', $tb ) . '.'; }
            $prev = $g('prev_attempt');
            if ( $prev !== '' ) {
                if ( preg_match( '/^(?:no|never|first time|not yet)/i', $prev ) ) { $p .= ' This is their first attempt at getting this done.'; }
                else { $p .= ' They have already tried to complete the process themselves' . ( preg_match( '/[—-]\s*(.+)$/u', $prev, $pm ) ? ' but ' . $lc( trim( $pm[1], " .\t" ) ) : '' ) . '.'; }
            }
            return array( 'text' => $p, 'used' => array( 'withdrawal_type', 'uan_status', 'uan_number', 'employer_name', 'date_leaving', 'transfer_needed', 'employer_count', 'currently_employed', 'kys_seeding', 'kyc_seeding', 'aadhaar_linked', 'bank_account', 'ifsc', 'docs_available', 'budget_range', 'prev_attempt' ) );

        case 36: // PAN Card Services
            $apptype = $g('application_type');
            $is_new_pan = ( $apptype !== '' && stripos( $apptype, 'new pan' ) === 0 );
            $p = $name . ' needs ' . ( $apptype !== '' ? $art( $apptype ) : 'PAN card assistance' ) . ' — ' . ( $g('purpose') !== '' ? $g('purpose') : 'purpose not specified' ) . ( ! $is_new_pan && $g('existing_pan') !== '' ? ' (existing PAN ' . $g('existing_pan') . ')' : '' ) . '.';
            $addr = $g('has_india_address');
            if ( $addr !== '' ) { $p .= ' ' . ( $yn( $addr ) ? 'They have a permanent Indian address for the PAN records.' : 'They only have a foreign address on file — no Indian address for the PAN records.' ); }
            if ( $g('father_name') !== '' ) { $p .= " Father's name: " . $g('father_name') . '.'; }
            if ( $g('dob') !== '' ) { $p .= ' Date of birth: ' . $g('dob') . '.'; }
            return array( 'text' => $p, 'used' => array( 'application_type', 'purpose', 'existing_pan', 'has_india_address', 'father_name', 'country_residing', 'dob' ) );

        case 37: // Bill Payment Services
            $p = $name . ' needs recurring bill payment services — ' . ( $g('bill_types') ?: 'bill types not specified' );
            $loc = $j( $g('property_city'), $g('property_state') );
            if ( $loc !== '' ) { $p .= ' for a property in ' . $loc; }
            $p .= '.';
            if ( $g('frequency') !== '' ) { $p .= ' Payment frequency: ' . $g('frequency') . ', method: ' . ( $g('payment_method') !== '' ? $g('payment_method') : 'not specified' ) . '.'; }
            if ( $g('send_receipts') !== '' ) { $p .= ' Receipts should be sent via ' . $lc( $g('send_receipts') ) . '.'; }
            if ( $g('account_details') !== '' ) { $p .= ' Utility account numbers/consumer IDs: ' . rtrim( $g('account_details'), '.' ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'bill_types', 'frequency', 'payment_method', 'send_receipts', 'property_city', 'property_state', 'account_details', 'property_address' ) );

        case 38: // Power of Attorney
            $p = $name . ' needs ' . ( $g('poa_type') !== '' ? $art( $g('poa_type') ) : 'a Power of Attorney' ) . ' — ' . ( $g('poa_purpose') !== '' ? $g('poa_purpose') : 'purpose not specified' ) . ( $g('property_value') !== '' && $g('property_value') !== 'Not applicable' ? ', property value approximately ' . $lc( $g('property_value') ) : '' ) . '.';
            if ( $g('agent_name') !== '' ) { $p .= ' Agent: ' . $g('agent_name') . ( $g('agent_relationship') !== '' ? ' (' . $g('agent_relationship') . ')' : '' ) . ( $g('agent_in_india') !== '' ? ', currently ' . ( $yn( $g('agent_in_india') ) ? '' : 'not ' ) . 'residing in India' : '' ) . '.'; }
            if ( $g('registration_needed') !== '' ) { $p .= ' ' . ( $yn( $g('registration_needed') ) ? 'Sub-Registrar registration is required.' : $lc( $ex( $g('registration_needed') ) ) . '.' ); }
            if ( $g('attestation_method') !== '' ) { $p .= ' It will be signed and attested ' . $lc( $g('attestation_method') ) . '.'; }
            $powers = $docs( $g('powers_to_grant') );
            if ( $powers !== '' ) { $p .= ' Additional powers to include: ' . $powers . '.'; }
            return array( 'text' => $p, 'used' => array( 'poa_type', 'poa_purpose', 'agent_name', 'agent_relationship', 'agent_in_india', 'registration_needed', 'attestation_method', 'property_value', 'principal_country', 'powers_to_grant' ) );

        case 39: // Will Drafting & Registration
            $p = $name . ' needs a Will drafted' . ( $g('existing_will') !== '' && $yn( $g('existing_will') ) ? ' (an existing Will is being replaced/revoked)' : '' ) . ( $g('assets_india') !== '' ? ', covering ' . $g('assets_india') : '' ) . '.';
            if ( $g('executor_name') !== '' ) { $p .= ' Executor: ' . $g('executor_name') . '.'; }
            if ( $g('beneficiaries') !== '' ) { $p .= ' Beneficiaries: ' . rtrim( $g('beneficiaries'), '.' ) . '.'; }
            if ( $g('registration_needed') !== '' ) { $p .= ' ' . ( $yn( $g('registration_needed') ) ? 'The Will is to be registered with the Sub-Registrar.' : $lc( $ex( $g('registration_needed') ) ) . '.' ); }
            $wit = $g('witnesses_available');
            if ( $wit !== '' ) { $p .= ' ' . ( $yn( $wit ) ? 'Two Indian witnesses are available for the signing.' : 'Help is needed arranging two Indian witnesses for the signing.' ); }
            if ( $g('dob') !== '' ) { $p .= ' Date of birth: ' . $g('dob') . '.'; }
            return array( 'text' => $p, 'used' => array( 'existing_will', 'assets_india', 'executor_name', 'registration_needed', 'witnesses_available', 'beneficiaries', 'country_residing', 'dob' ) );

        case 40: // Legal Notice
            $p = $name . ' needs a legal notice sent — ' . ( $g('matter_type') !== '' ? $g('matter_type') : 'matter not specified' ) . ( $g('recipient_name') !== '' ? ', addressed to ' . $g('recipient_name') : '' ) . ( $g('recipient_address') !== '' ? ' (' . rtrim( $g('recipient_address'), '.' ) . ')' : '' ) . '.';
            if ( $g('details') !== '' ) { $p .= ' Facts of the matter: ' . rtrim( $g('details'), '.' ) . '.'; }
            if ( $g('amount_involved') !== '' ) { $p .= ' Amount/relief sought: ' . $g('amount_involved') . '.'; }
            $pc = $g('prior_communication');
            if ( $pc !== '' ) {
                if ( ! $yn( $pc ) ) {
                    $p .= ' This matter has not yet been communicated to the other party.';
                } else {
                    $pc_ex = $ex( $pc );
                    $p .= ' This matter has already been communicated to the other party' . ( $pc_ex !== $pc ? ' — ' . $lc( $pc_ex ) : '' ) . '.';
                }
            }
            $ev = $g('has_evidence');
            if ( $ev !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $ev ) ) ) . '.'; }
            if ( $g('deadline_response') !== '' ) { $p .= ' The notice should give the other party ' . $g('deadline_response') . ' to respond.'; }
            return array( 'text' => $p, 'used' => array( 'matter_type', 'recipient_name', 'recipient_address', 'amount_involved', 'prior_communication', 'deadline_response', 'details', 'sender_name', 'has_evidence' ) );

        case 41: // Legal Advisory & Consultation
            $p = $name . ' needs legal advisory on ' . ( $g('matter_type') !== '' ? $g('matter_type') : 'a matter not specified' ) . '.';
            if ( $g('brief_facts') !== '' ) { $p .= ' Summary: ' . rtrim( $g('brief_facts'), '.' ) . '.'; }
            $pla = $g('prior_legal_action');
            if ( $pla !== '' ) { $p .= ' ' . ( stripos( $pla, 'no' ) === 0 ? 'No prior legal action has been taken in this matter.' : ucfirst( $lc( $ex( $pla ) ) ) . '.' ); }
            $doc = $g('documents_available');
            if ( $doc !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $doc ) ) ) . '.'; }
            if ( $g('consultation_mode') !== '' ) { $p .= ' Preferred consultation mode: ' . $g('consultation_mode') . '.'; }
            if ( $g('urgency') !== '' ) { $p .= ' Urgency: ' . $lc( $g('urgency') ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'matter_type', 'brief_facts', 'consultation_mode', 'urgency', 'prior_legal_action', 'documents_available' ) );

        case 42: // ITR Filing for NRIs
            $p = $name . ' needs Income Tax Return filing for AY ' . ( $g('assessment_year') ?: '(not specified)' ) . ' — tax residency status: ' . ( $g('nri_status') !== '' ? $g('nri_status') : 'not specified' ) . '.';
            $docv = $docs( $g('income_sources') );
            if ( $docv !== '' ) { $p .= ' Indian income sources: ' . $docv . '.'; }
            $pan = $g('has_pan');
            if ( $pan !== '' ) { $p .= ' PAN status: ' . $lc( $ex( $pan ) ) . ( $g('pan_number') !== '' ? ' (' . $g('pan_number') . ')' : '' ) . '.'; }
            if ( $g('tds_situation') !== '' ) { $p .= ' TDS situation: ' . $g('tds_situation') . '.'; }
            if ( $g('has_form26as') !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $g('has_form26as') ) ) ) . '.'; }
            if ( $g('dtaa_benefit') !== '' ) { $p .= ' ' . ( $yn( $g('dtaa_benefit') ) ? 'DTAA benefit is to be claimed.' : $lc( $ex( $g('dtaa_benefit') ) ) . '.' ); }
            $prev = $g('prev_itr');
            if ( $prev !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $prev ) ) ) . '.'; }
            $docv2 = $docs( $g('docs_available') );
            if ( $docv2 !== '' ) { $p .= ' They have ' . $docv2 . ' available.'; }
            $tb = array();
            if ( $g('timeline') !== '' ) { $tb[] = 'needs the filing done ' . $tl( $g('timeline') ); }
            if ( $g('budget_range') !== '' ) { $tb[] = 'has an approximate budget of ' . $lc( $g('budget_range') ); }
            if ( ! empty( $tb ) ) { $p .= ' The applicant ' . implode( ' and ', $tb ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'nri_status', 'assessment_year', 'income_sources', 'has_pan', 'pan_number', 'tds_situation', 'has_form26as', 'dtaa_benefit', 'prev_itr', 'docs_available', 'timeline', 'budget_range' ) );

        case 43: // TDS Refund Claim
            $p = $name . ' needs a TDS refund claim — source: ' . ( $g('tds_source') !== '' ? $g('tds_source') : 'not specified' ) . ( $g('approx_tds') !== '' ? ', approximately ₹' . $g('approx_tds') . ' deducted' : '' ) . ( $g('assessment_year') !== '' ? ' for AY ' . $g('assessment_year') : '' ) . '.';
            if ( $g('has_form26as') !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $g('has_form26as') ) ) ) . '.'; }
            $pan = $g('has_pan');
            if ( $pan !== '' ) { $p .= ' PAN status: ' . $lc( $ex( $pan ) ) . ( $g('pan_number') !== '' ? ' (' . $g('pan_number') . ')' : '' ) . '.'; }
            if ( $g('bank_account') !== '' ) { $p .= ' Refund to be credited to account ' . $g('bank_account') . ( $g('ifsc') !== '' ? ' (IFSC ' . $g('ifsc') . ')' : '' ) . '.'; }
            if ( $g('dob') !== '' ) { $p .= ' Date of birth: ' . $g('dob') . '.'; }
            return array( 'text' => $p, 'used' => array( 'tds_source', 'approx_tds', 'assessment_year', 'has_form26as', 'has_pan', 'pan_number', 'bank_account', 'ifsc', 'dob' ) );

        case 44: // Form 15CA / 15CB (Repatriation)
            $p = $name . ' needs Form 15CA/15CB for a remittance of ' . ( $g('remittance_amount') ?: '(amount not specified)' ) . ' to ' . ( $g('destination_country') ?: '(country not specified)' ) . ', purpose: ' . ( $g('purpose_remittance') !== '' ? $g('purpose_remittance') : 'not specified' ) . '.';
            if ( $g('source_of_funds') !== '' ) { $p .= ' Source of funds: ' . $g('source_of_funds') . '.'; }
            if ( $g('above_5lakhs') !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $g('above_5lakhs') ) ) ) . '.'; }
            if ( $g('dtaa_applicable') !== '' ) { $p .= ' ' . ( $yn( $g('dtaa_applicable') ) ? 'A DTAA is applicable and will be claimed.' : $lc( $ex( $g('dtaa_applicable') ) ) . '.' ); }
            if ( $g('indian_bank') !== '' ) { $p .= ' Remitting bank: ' . $g('indian_bank') . '.'; }
            if ( $g('pan_number') !== '' ) { $p .= ' Remitter PAN: ' . $g('pan_number') . '.'; }
            return array( 'text' => $p, 'used' => array( 'above_5lakhs', 'source_of_funds', 'purpose_remittance', 'dtaa_applicable', 'destination_country', 'remittance_amount', 'pan_number', 'indian_bank', 'applicant_name' ) );

        case 45: // GST Registration & Returns
            $p = $name . ' needs GST registration/returns for a ' . ( $g('business_type') !== '' ? $g('business_type') : 'business' ) . ( $g('business_name') !== '' ? ' ("' . $g('business_name') . '")' : '' ) . ', nature of business: ' . ( $g('service_type') !== '' ? $g('service_type') : 'not specified' ) . '.';
            if ( $g('annual_turnover') !== '' ) { $p .= ' Expected annual turnover: ' . $g('annual_turnover') . '.'; }
            if ( $g('interstate_sales') !== '' ) { $p .= ' ' . ( $yn( $g('interstate_sales') ) ? 'Inter-state sales are planned.' : ucfirst( $lc( $ex( $g('interstate_sales') ) ) ) . '.' ); }
            $addr = $g('has_business_address');
            if ( $addr !== '' ) { $p .= ' ' . ( $yn( $addr ) ? ucfirst( $lc( $ex( $addr ) ) ) . '.' : 'A virtual office address still needs to be arranged.' ); }
            $pan = $g('pan_available');
            if ( $pan !== '' ) { $p .= ' ' . ( $yn( $pan ) ? 'PAN is available.' : 'PAN still needs to be applied for.' ); }
            return array( 'text' => $p, 'used' => array( 'annual_turnover', 'service_type', 'interstate_sales', 'has_business_address', 'pan_available', 'business_type', 'state', 'business_name' ) );

        case 46: // Marriage Registration
            $groom = $g('applicant_name');
            $bride = $g('mother_name');
            $p = ( $groom !== '' || $bride !== '' ? trim( $groom . ( $groom !== '' && $bride !== '' ? ' and ' : '' ) . $bride ) : $name ) . ' need' . ( $groom !== '' || $bride !== '' ? '' : 's' ) . ' ' . ( $g('marriage_type') !== '' ? $art( $g('marriage_type') ) : 'a Marriage Certificate' );
            $loc = $j( $g('birth_city'), $g('birth_state') );
            if ( $loc !== '' ) { $p .= ' for a marriage in ' . $loc; }
            if ( $g('marriage_date') !== '' ) { $p .= ' on ' . $g('marriage_date'); }
            $p .= '.';
            if ( $g('registration_status') !== '' ) { $p .= ' Current registration status: ' . $g('registration_status') . '.'; }
            if ( $g('purpose') !== '' ) { $p .= ' Certificate needed for: ' . $g('purpose') . ( $g('destination_country') !== '' ? ', for use in ' . $g('destination_country') : '' ) . '.'; }
            if ( $g('attestation_required') !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $g('attestation_required') ) ) ) . '.'; }
            $docv = $docs( $g('docs_available') );
            if ( $docv !== '' ) { $p .= ' They have ' . $docv . ' available.'; }
            if ( $g('who_applying') !== '' ) { $p .= ' Filling this form: ' . $lc( $ex( $g('who_applying') ) ) . '.'; }
            $tb = array();
            if ( $g('timeline') !== '' ) { $tb[] = 'need this ' . $tl( $g('timeline') ); }
            if ( $g('budget_range') !== '' ) { $tb[] = 'have an approximate budget of ' . $lc( $g('budget_range') ); }
            if ( ! empty( $tb ) ) { $p .= ' They ' . implode( ' and ', $tb ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'marriage_type', 'registration_status', 'marriage_date', 'birth_city', 'birth_state', 'applicant_name', 'mother_name', 'destination_country', 'attestation_required', 'who_applying', 'purpose', 'docs_available', 'timeline', 'budget_range' ) );

        case 47: // Death Certificate
            $p = $name . ' needs ' . ( $g('work_type') !== '' ? $art( $g('work_type') ) : 'a Death Certificate' ) . ' for ' . ( $g('applicant_name') ?: 'the deceased' ) . ( $g('relationship') !== '' ? ' (' . $name . "'s " . $g('relationship') . ')' : '' );
            $loc = $j( $g('birth_city'), $g('birth_state') );
            if ( $loc !== '' ) { $p .= ', death occurred in ' . $loc; }
            if ( $g('year_passing') !== '' ) { $p .= ' in ' . $g('year_passing'); }
            $p .= '.';
            if ( $g('purpose') !== '' ) { $p .= ' Certificate needed for: ' . $g('purpose') . ( $g('destination_country') !== '' ? ', for use in ' . $g('destination_country') : '' ) . '.'; }
            if ( $g('attestation_required') !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $g('attestation_required') ) ) ) . '.'; }
            $docv = $docs( $g('docs_available') );
            if ( $docv !== '' ) { $p .= ' They have ' . $docv . ' available.'; }
            $tb = array();
            if ( $g('timeline') !== '' ) { $tb[] = 'need this ' . $tl( $g('timeline') ); }
            if ( $g('budget_range') !== '' ) { $tb[] = 'have an approximate budget of ' . $lc( $g('budget_range') ); }
            if ( ! empty( $tb ) ) { $p .= ' They ' . implode( ' and ', $tb ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'work_type', 'birth_city', 'birth_state', 'year_passing', 'applicant_name', 'relationship', 'destination_country', 'attestation_required', 'purpose', 'docs_available', 'timeline', 'budget_range' ) );

        case 48: // Domicile Certificate
            $p = ( $g('applicant_name') ?: $name ) . ' needs a Domicile Certificate for ' . ( $g('state') ?: '(state not specified)' );
            if ( $g('birth_city') !== '' ) { $p .= ', permanent address in ' . $g('birth_city'); }
            $p .= '.';
            if ( $g('purpose') !== '' ) { $p .= ' Purpose: ' . $g('purpose') . '.'; }
            if ( $g('years_to_check') !== '' ) { $p .= ' Duration of residence: ' . $lc( $g('years_to_check') ) . '.'; }
            if ( $g('father_name') !== '' ) { $p .= " Father's name: " . $g('father_name') . '.'; }
            if ( $g('dob') !== '' ) { $p .= ' Date of birth: ' . $g('dob') . '.'; }
            if ( $g('attestation_required') !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $g('attestation_required') ) ) ) . '.'; }
            $docv = $docs( $g('docs_available') );
            if ( $docv !== '' ) { $p .= ' They have ' . $docv . ' available.'; }
            if ( $g('who_applying') !== '' ) { $p .= ' Filling this form: ' . $lc( $ex( $g('who_applying') ) ) . '.'; }
            $tb = array();
            if ( $g('timeline') !== '' ) { $tb[] = 'need this ' . $tl( $g('timeline') ); }
            if ( $g('budget_range') !== '' ) { $tb[] = 'have an approximate budget of ' . $lc( $g('budget_range') ); }
            if ( ! empty( $tb ) ) { $p .= ' They ' . implode( ' and ', $tb ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'state', 'purpose', 'birth_city', 'years_to_check', 'applicant_name', 'father_name', 'dob', 'attestation_required', 'who_applying', 'docs_available', 'timeline', 'budget_range' ) );

        case 49: // Succession Certificate
            $p = ( $g('applicant_name') ?: $name ) . ' needs a Succession Certificate for ' . ( $g('assets_india') !== '' ? $g('assets_india') : 'assets in India' ) . ' left by ' . ( $g('deponent_name') ?: 'the deceased' ) . ( $g('year_passing') !== '' ? ' (died ' . $g('year_passing') . ')' : '' ) . '.';
            if ( $g('relationship') !== '' ) { $p .= ' Relationship to the deceased: ' . $g('relationship') . '.'; }
            if ( $g('birth_city') !== '' ) { $p .= ' Deceased last lived / assets are held in ' . $g('birth_city') . '.'; }
            if ( $g('has_will') !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $g('has_will') ) ) ) . '.'; }
            if ( $g('beneficiaries') !== '' ) { $p .= ' Legal heirs: ' . rtrim( $g('beneficiaries'), '.' ) . '.'; }
            $court = $g('state');
            if ( $court !== '' ) { $p .= ' Jurisdiction: ' . $court . '.'; }
            $docv = $docs( $g('docs_available') );
            if ( $docv !== '' ) { $p .= ' They have ' . $docv . ' available.'; }
            $tb = array();
            if ( $g('timeline') !== '' ) { $tb[] = 'need this ' . $tl( $lc( $g('timeline') ) ); }
            if ( $g('budget_range') !== '' ) { $tb[] = 'have an approximate budget of ' . $lc( $g('budget_range') ); }
            if ( ! empty( $tb ) ) { $p .= ' They ' . implode( ' and ', $tb ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'assets_india', 'relationship', 'state', 'applicant_name', 'deponent_name', 'year_passing', 'birth_city', 'beneficiaries', 'has_will', 'docs_available', 'timeline', 'budget_range' ) );

        case 50: // Property Registration Assistance
            $p = ( $g('applicant_name') ?: $name ) . ' needs assistance registering a ' . ( $g('property_type') !== '' ? $g('property_type') : 'property' ) . ' — ' . ( $g('transaction_type') !== '' ? $g('transaction_type') : 'transaction type not specified' );
            if ( $g('state') !== '' || $g('birth_city') !== '' ) { $p .= ' in ' . $j( $g('birth_city'), $g('state') ); }
            $p .= '.';
            if ( $g('property_details') !== '' ) { $p .= ' Approximate property value: ₹' . $g('property_details') . '.'; }
            if ( $g('owner_name') !== '' ) { $p .= ' Current owner/seller: ' . $g('owner_name') . '.'; }
            if ( $g('local_contact') !== '' ) { $p .= ' Local representative in India: ' . $lc( $ex( $g('local_contact') ) ) . '.'; }
            if ( $g('has_poa') !== '' ) { $p .= ' ' . ucfirst( $lc( $ex( $g('has_poa') ) ) ) . '.'; }
            $docv = $docs( $g('docs_available') );
            if ( $docv !== '' ) { $p .= ' They have ' . $docv . ' available.'; }
            $tb = array();
            if ( $g('timeline') !== '' ) { $tb[] = 'need this ' . $tl( $lc( $g('timeline') ) ); }
            if ( $g('budget_range') !== '' ) { $tb[] = 'have an approximate budget of ' . $lc( $g('budget_range') ); }
            if ( ! empty( $tb ) ) { $p .= ' They ' . implode( ' and ', $tb ) . '.'; }
            return array( 'text' => $p, 'used' => array( 'property_type', 'transaction_type', 'state', 'birth_city', 'owner_name', 'applicant_name', 'local_contact', 'has_poa', 'property_details', 'docs_available', 'timeline', 'budget_range' ) );
    }

    return null;
}

/**
 * The engine itself. Reads a request's submitted fields (via
 * nsh_fd_first(), so admin-configurable field-key spellings are
 * handled the same way the compact card summary handles them),
 * interprets the RELATIONSHIP between them (document type + course +
 * institution + completion year + mode; current vs delivery location;
 * timeline; purpose; urgency signalled in remarks) and composes a
 * short 2-4 sentence narrative — never a field-by-field list. Any
 * field that is missing is simply omitted from the sentence rather
 * than producing an awkward gap ("... passed in [Year] ...").
 *
 * Returns plain text (no HTML) — callers that display it decide how
 * to escape/format it.
 */
function nsh_generate_requirement_description( $rid, $meta = null ) {
    $meta = $meta ? $meta : nsh_get_meta( $rid );
    $fd   = $meta['field_data'];

    // Root cause of a name showing as "The applicant" on real requests:
    // first_name/last_name is only a configured field on the EDUCATION
    // services (3,5,8,11,12,14,15) and a handful of others — most of the
    // other 43 services' Contact Details step never collects a name at
    // all (only email/phone), so nsh_fd_first() for first_name/last_name
    // legitimately finds nothing there, every time, for every request on
    // those services. Many of them collect the applicant's name under a
    // different key instead ('applicant_name' — used by OCI/passport/
    // visa/USCIS/PAN/legal/tax services, or the deceased/owner/executor
    // equivalent on a few others); nsh_req_applicant_name() below tries
    // that too, then the WordPress account's own display name IF it
    // looks like an actual name rather than the raw email address
    // wp_create_user() falls back to for a name-less signup (see
    // nsh_ajax_create_request() in ajax.php) — only after all of that
    // fails does it fall back to the generic "The applicant".
    $name = nsh_req_applicant_name( $rid, $fd );

    // Who to actually contact about this request — see
    // nsh_req_contact_person_name()'s docblock for why this is kept
    // separate from $name (who the request is FOR) rather than treated
    // as the same person: plenty of requests are filed by someone other
    // than the applicant/deceased/student the request itself is about.
    $contact_person = nsh_req_contact_person_name( $rid, $fd );

    // Resolve THIS site's real service_id (whatever auto-increment id that
    // row happens to have here) to the fixed 1-50 catalog position — see
    // nsh_canonical_service_number()'s docblock. Computed up-front (rather
    // than only inside the generic branch further down) because it is now
    // also needed to decide WHICH branch a request goes into in the first
    // place — see $has_edu_shape below.
    $service_id    = isset( $meta['service_id'] ) ? (int) $meta['service_id'] : 0;
    $canonical_num = nsh_canonical_service_number( $service_id );

    $doc_type_raw = nsh_fd_first( $fd, array( 'document_type' ) );
    $app_type     = nsh_fd_first( $fd, array( 'application_type' ) );
    $university   = nsh_fd_first( $fd, array( 'university_name', 'university' ) );
    $college      = nsh_fd_first( $fd, array( 'college_name', 'college' ) );
    $course       = nsh_fd_first( $fd, array( 'course_name', 'course' ) );
    $mode         = nsh_fd_first( $fd, array( 'mode_of_education', 'mode', 'education_mode' ) );
    $adm_year     = nsh_fd_first( $fd, array( 'year_admission', 'year_of_admission', 'admission_year' ) );
    $pass_year    = nsh_fd_first( $fd, array( 'year_passing', 'year_of_passing', 'passing_year' ) );
    $semesters    = nsh_fd_first( $fd, array( 'number_of_semesters', 'semesters', 'no_of_semesters' ) );
    $enrollment   = nsh_fd_first( $fd, array( 'enrollment_number', 'enrollment' ) );
    $purpose_raw  = nsh_fd_first( $fd, array( 'purpose' ) );
    $cur_loc      = nsh_fd_first( $fd, array( 'current_location' ) );
    // 'delivery_location' is the education-form's own key; every other
    // service's Delivery step (nsh_render_form_field's shared "delivery"
    // block) instead uses 'delivery_addr' (India) / 'delivery_intl'
    // (abroad) — or, on a handful of simpler forms, a single '__delivery'
    // textarea. Try all of them so paragraph 3 below actually finds the
    // delivery address on non-education requests instead of silently
    // staying blank.
    $del_loc      = nsh_fd_first( $fd, array( 'delivery_location', 'delivery_intl', 'delivery_addr', '__delivery' ) );
    $remarks      = nsh_fd_first( $fd, array( 'remarks', 'additional_remarks', 'notes' ) );
    $wd           = get_post_meta( $rid, 'timeline_working_days', true );
    $timeline     = $wd ? intval( $wd ) . ' working days' : '';

    // Institution: mention both university and college when both are
    // given and differ; otherwise whichever one is actually present.
    $institution = '';
    if ( $university !== '' && $college !== '' && strcasecmp( $university, $college ) !== 0 ) {
        $institution = $university . ', ' . $college;
    } elseif ( $university !== '' ) {
        $institution = $university;
    } else {
        $institution = $college;
    }

    // Root cause of "description is missing fields": everything below,
    // through paragraphs 1 and 2, only knows how to talk about an
    // EDUCATION-document request (document_type/university/college/
    // course/admission-year/etc — again, the same fixed vocabulary the
    // compact card summary above used to be limited to). For any other
    // service (Birth Certificate, immigration, property, legal, ...)
    // none of those fields exist, so the engine fell through to "Ravi
    // Kumar needs a document." — technically not blank, but effectively
    // useless, since it silently ignores every field the client actually
    // filled in. $has_edu_shape below detects whether this request even
    // HAS education-document fields; when it doesn't, paragraphs 1-2 are
    // built generically instead, from this request's OWN service's
    // configured fields (same source the card-fields fix above uses) —
    // contact details (phone/email/country/callback) and file uploads
    // are deliberately left out of this narrative, same as before.
    // Root cause of the "Apostille & Attestation" (and HRD Attestation /
    // Document Translation) short-description bug: this branch used to be
    // decided by DUCK-TYPING on field presence alone (document_type/
    // university/college/course non-empty) — but a bare 'document_type'
    // field is NOT unique to education-document requests, and even
    // 'university_name' isn't: HRD Attestation collects one too (which
    // university issued the certificate being attested), without being an
    // "apply for admission" education request in any other sense (no
    // course/admission-year/semesters/enrollment shape at all). Duck-
    // typing on fields misrouted apostille, HRD attestation, and document
    // translation into this sparse education-vocabulary branch, where the
    // fields it actually asks about don't exist — producing thin output —
    // and, worse, meant this branch never calls
    // nsh_service_narrative_intro() at all, so the hand-written narrative
    // cases written specifically for those three services (see cases 3, 5,
    // 8 above) were never reached either, however this flag was computed.
    //
    // Fixed by deciding on the service's fixed CATALOG POSITION instead of
    // guessing from field names — the four services that are genuinely
    // "apply for / obtain an education document" in shape (University
    // Transcript, Degree Certificate, MOI, Migration Certificate: catalog
    // positions 11, 12, 14, 15) are the only ones this branch should ever
    // fire for. Every other service — including the three that merely
    // process/attest/translate an already-issued document of any kind —
    // goes to the generic branch below, where it gets its own
    // hand-written narrative.
    $true_education_services = array( 11, 12, 14, 15 );
    $has_edu_shape = in_array( $canonical_num, $true_education_services, true );
    // Populated by the generic (non-education) branch below with the
    // field keys its hand-written narrative already spoke for — read by
    // paragraph 3 further down so it doesn't re-state a purpose/timeline
    // a service's own template already covered in its own words.
    $intro_used = array();

    $doc_rule   = nsh_req_match_doc( $doc_type_raw );
    $need_noun  = $doc_rule ? $doc_rule['noun'] : 'document';
    $has_verb   = $doc_rule && isset( $doc_rule['verb'] );

    // A placeholder remark value ("None", "N/A", "-", ...) means the
    // client left this blank in effect — treat it the same as an empty
    // remark rather than quoting it back as if it were real content.
    $remarks_placeholder = array( 'none', 'na', 'n/a', 'nil', 'nothing', 'no', '-', '--', 'no remarks', 'no remark' );
    if ( $remarks !== '' && in_array( strtolower( trim( $remarks, " \t\n\r\0\x0B." ) ), $remarks_placeholder, true ) ) {
        $remarks = '';
    }
    $remarks_l = strtolower( $remarks );
    $is_urgent = ( $remarks !== '' && ( strpos( $remarks_l, 'urgent' ) !== false || strpos( $remarks_l, 'asap' ) !== false || strpos( $remarks_l, 'immediately' ) !== false ) );

    // The description reads as short PARAGRAPHS (joined with a blank
    // line), not one dense block — one paragraph for what's needed, one
    // for the academic timeline/enrollment, one for location/delivery/
    // purpose, and an optional one for anything else in the remarks.
    // No gender field exists on the form, so pronouns are written as
    // "he/she" / "his/her" throughout rather than guessed at.

    // ---- Paragraph 1: what is needed, for what course, from where ----
    if ( $has_edu_shape ) {
    if ( $has_verb ) {
        // Service-style requests (verification / attestation / apostille)
        // read more naturally as "needs X done" than "needs a X".
        $p1 = $name . ' ' . $doc_rule['verb'];
    } else {
        $article = preg_match( '/^[aeiou]/i', $need_noun ) ? 'an' : 'a';
        $modifier    = '';
        $tail        = ''; // appended right after the document phrase
        $app_type_l  = strtolower( $app_type );
        $app_matched = false;
        if ( $app_type !== '' ) {
            // If the document noun already implies what the Application
            // Type says (e.g. noun "duplicate degree certificate" + type
            // "Duplicate"), it's already covered — don't also append a
            // redundant "(Duplicate application)" parenthetical below.
            foreach ( array( 'duplicate', 'fresh', 'revalidat' ) as $core ) {
                if ( strpos( $app_type_l, $core ) !== false && stripos( $need_noun, $core ) !== false ) {
                    $app_matched = true;
                    break;
                }
            }
            if ( ! $app_matched && stripos( $need_noun, 'duplicate' ) === false ) {
                if ( strpos( $app_type_l, 'duplicate' ) !== false )     { $modifier = 'a duplicate'; $app_matched = true; }
                elseif ( strpos( $app_type_l, 'fresh' ) !== false )      { $tail = ' for the first time'; $app_matched = true; }
                elseif ( strpos( $app_type_l, 'revalidat' ) !== false )  { $modifier = 'a revalidation of his/her'; $app_matched = true; }
            }
        }
        $need_phrase = trim( ( $modifier !== '' ? $modifier : $article ) . ' ' . $need_noun ) . $tail;
        // Application Type is a submitted field in its own right — if it
        // didn't match one of the known modifiers above (fresh/duplicate/
        // revalidation), still surface it rather than silently dropping
        // it, e.g. "a marksheet (Renewal application)".
        if ( $app_type !== '' && ! $app_matched ) {
            $need_phrase .= ' (' . $app_type . ' application)';
        }
        $p1 = $name . ' needs ' . $need_phrase;
    }
    if ( $course !== '' ) {
        $p1 .= ' for his/her ' . $course . ' course';
    }
    if ( $institution !== '' ) {
        $p1 .= ' from ' . $institution;
    }
    $p1 = rtrim( $p1 ) . '.';

    // ---- Paragraph 2: academic timeline (admission/passing/mode/
    // semesters) and enrollment number — kept separate from paragraph 1
    // so neither reads as one overloaded sentence. ----
    $p2 = '';
    $progress = '';
    if ( $adm_year !== '' && $pass_year !== '' ) {
        $progress = 'He/she started the course in ' . $adm_year . ' and completed it in ' . $pass_year;
    } elseif ( $pass_year !== '' ) {
        $progress = 'He/she completed the course in ' . $pass_year;
    } elseif ( $adm_year !== '' ) {
        $progress = 'He/she started the course in ' . $adm_year . ' and is currently pursuing it';
    } elseif ( $mode !== '' ) {
        $progress = 'He/she pursued the course';
    }
    if ( $progress !== '' && $mode !== '' ) {
        $progress .= ' through the ' . $mode . ' mode';
    }
    if ( $progress !== '' && $semesters !== '' ) {
        $progress .= ', covering ' . $semesters . ' semester' . ( intval( $semesters ) === 1 ? '' : 's' );
    }
    if ( $progress !== '' ) { $p2 .= rtrim( $progress ) . '.'; }
    if ( $enrollment !== '' ) {
        $p2 .= ( $p2 !== '' ? ' ' : '' ) . 'His/Her Enrollment Number is ' . $enrollment . '.';
    }
    } else {
        // Generic branch — this request's service isn't an education-
        // document type, so build paragraphs 1-2 from ITS OWN configured
        // fields (wp_nsh_fields, scoped to this request's service_id)
        // instead of the education vocabulary above. Contact details
        // (phone/email/country/callback), file uploads, and the fields
        // paragraph 3/4 already cover (purpose/remarks/location/
        // delivery) are deliberately left out here so nothing repeats.
        // $service_id / $canonical_num were already resolved near the top
        // of this function (needed there to decide $has_edu_shape itself).
        $service_name = ! empty( $meta['service_name'] ) ? $meta['service_name'] : 'service';

        // Hand-written opening narrative for this specific service (see
        // nsh_service_narrative_intro() above) — the same idea as the
        // education engine's own paragraph 1, just one template per
        // service instead of one shared field vocabulary. Falls back to
        // the plain "has submitted a ___ request" line only if this
        // service has no template yet (shouldn't normally happen — every
        // non-education service currently in the catalog has one).
        $narrative   = nsh_service_narrative_intro( $canonical_num, $fd, $name );
        $p1          = $narrative ? $narrative['text'] : trim( $name . ' has submitted a ' . $service_name . ' request.' );
        $intro_used  = $narrative ? $narrative['used'] : array();

        $p2 = '';
        if ( $service_id && is_array( $fd ) && ! empty( $fd ) ) {
            global $wpdb;
            $skip_keys = array_merge( $intro_used, array(
                // 'applicant_name' is already spent — it's exactly the field
                // nsh_req_applicant_name() reads to produce $name, which
                // every service's narrative template opens with. Without
                // this, most identity-document services (OCI/passport/visa/
                // PAN/Will/TDS/...) said the applicant's name twice: once
                // naturally in paragraph 1, then again as a raw "Your Full
                // Name (as in passport) — X" fragment down here.
                'first_name', 'last_name', 'applicant_name', 'phone', 'mobile', 'mobile_number', 'phone_code',
                '__phone', '__email', '__country', '__callback',
                // 'contact_person_name' is handled by its own dedicated
                // sentence near the top of this function (see $contact_person
                // below) rather than as a raw leftover fragment here.
                'contact_person_name',
                'purpose', 'remarks', 'additional_remarks', 'notes',
                'current_location', 'delivery_location', 'delivery_pref', 'delivery_addr', 'delivery_intl', '__delivery',
            ) );
            $rows = $wpdb->get_results( $wpdb->prepare(
                "SELECT field_key, field_label, field_type FROM {$wpdb->prefix}nsh_fields WHERE service_id=%d AND is_active=1 ORDER BY step_number ASC, sort_order ASC",
                $service_id
            ) );
            $bits = array();
            foreach ( (array) $rows as $fr ) {
                if ( in_array( $fr->field_key, $skip_keys, true ) || $fr->field_type === 'file' ) { continue; }
                $val = isset( $fd[ 'field_' . $fr->field_key ] ) ? $fd[ 'field_' . $fr->field_key ] : '';
                if ( is_array( $val ) ) { $val = implode( ', ', array_map( 'strval', $val ) ); }
                $val = trim( (string) $val );
                if ( $val === '' ) { continue; }
                // Many radio/checkbox options on this site are written as
                // their OWN complete, self-explanatory statement (e.g.
                // "Yes — I/parent lives in birth city now", not just
                // "Yes") — for those, prefixing the full question-form
                // label as well ("is the applicant OR a parent currently
                // living in the birth city — Yes — I/parent lives...")
                // is redundant and reads badly. Detect that shape (an em
                // or hyphen dash already inside the value, or the value
                // simply being long enough to be self-explanatory on its
                // own) and use the value alone as its own clause; only a
                // short, context-free value (a date, a number, a plain
                // "Yes"/"No", a single word) still gets the label
                // prefixed, since without it that clause would be
                // meaningless on its own.
                // /u (UTF-8 mode) matters here: an em dash (—) is 3 bytes
                // in UTF-8, and without /u the byte-mode [—-] character
                // class can silently fail to match it, leaving exactly
                // the "Yes — long explanation" values this check exists
                // for un-detected.
                $self_explanatory = ( preg_match( '/\s[—-]\s/u', $val ) === 1 ) || ( function_exists( 'mb_strlen' ) ? mb_strlen( $val ) : strlen( $val ) ) > 25;
                // The specific case-shape "Yes — <explanation>" / "No —
                // <explanation>" (the overwhelming majority of this site's
                // radio/select options) reads badly when dumped as-is —
                // "Yes — passport / OCI card exists, and Yes — family in
                // birth city can assist." repeats the meaningless "Yes —"
                // twice with no real subject. The admin-written explanation
                // half is almost always already a coherent standalone
                // statement on its own (the option text is written to read
                // that way), so drop the literal "Yes"/"No" and keep just
                // that — "Passport / OCI card exists, and family in birth
                // city can assist." — matching the same technique already
                // used for Birth Certificate's has_any_dob_proof field,
                // generalised here to every field on every service.
                if ( preg_match( '/^(?:yes|no)\s*[—-]\s*(.+)$/iu', $val, $ynm ) ) {
                    $bits[] = ucfirst( trim( $ynm[1], " .\t" ) );
                } elseif ( $self_explanatory ) {
                    $bits[] = rtrim( $val, '.' );
                } else {
                    $label_clean = rtrim( trim( $fr->field_label ), '?' );
                    // A very common label shape across the catalog is a
                    // literal question — "What is your deadline?", "What's
                    // your Green Card expiry date?" — which, dumped through
                    // the generic "label — value" fallback below, reads as
                    // a redundant, un-natural "what is your deadline —
                    // Within 2 weeks." Detect that shape specifically and
                    // turn it into a real declarative clause instead:
                    // "Their deadline is Within 2 weeks."
                    if ( preg_match( '/^what(?:\'s| is)\s+(?:your|the|his\/her)\s+(.+)$/i', $label_clean, $lm ) ) {
                        $bits[] = 'Their ' . nsh_label_lower( trim( $lm[1] ) ) . ' is ' . $val;
                    } elseif ( preg_match( '/^how long (?:have you|has)\s*(?:\/\s*your family)?\s*been\s+(.+)$/i', $label_clean, $lm2 ) ) {
                        $bits[] = 'They have been ' . nsh_label_lower( trim( $lm2[1] ) ) . ' for ' . lcfirst( $val );
                    } else {
                        // Most labels here are written Title Case ("Date of
                        // Birth", "Your Full Name (as in passport)") which
                        // reads oddly dropped mid-sentence even after
                        // lcfirst() only lowers the very first letter
                        // ("date of Birth — ..."). Lowercase every word
                        // except ones that are already all-caps acronyms
                        // (OCI, PAN, TDS, GST, EPF, ID, ...), which stay as-is.
                        $bits[] = nsh_label_lower( $label_clean ) . ' — ' . $val;
                    }
                }
            }
            // Two clauses per sentence, joined with "and", each sentence
            // capitalised and full-stopped — a flowing paragraph rather
            // than one long semicolon list.
            $chunks = array_chunk( $bits, 2 );
            $sent   = array();
            foreach ( $chunks as $c ) {
                $s = implode( ', and ', $c );
                $sent[] = ucfirst( $s ) . '.';
            }
            if ( ! empty( $sent ) ) {
                $p2 = implode( ' ', $sent );
            }
        }
    }

    // ---- Paragraph 3: current location, purpose, and where the
    // finished document needs to go — with timeline/urgency folded in. ----
    // A service's own narrative template (above) may already have
    // covered 'purpose' and/or 'timeline' in its own words — don't
    // re-state them here in the generic "He/she needs..." phrasing too.
    $purpose_already_said  = in_array( 'purpose', $intro_used, true );
    $timeline_already_said = in_array( 'timeline', $intro_used, true );
    $purpose_phrase = $purpose_already_said ? '' : nsh_req_purpose_phrase( $purpose_raw );
    $p3a = '';
    if ( $cur_loc !== '' && $purpose_phrase !== '' ) {
        $p3a = 'He/she is currently based in ' . $cur_loc . ', and needs the ' . ( $has_verb ? 'work done' : $need_noun ) . ' for ' . $purpose_phrase;
    } elseif ( $cur_loc !== '' ) {
        $p3a = 'He/she is currently based in ' . $cur_loc;
    } elseif ( $purpose_phrase !== '' ) {
        $p3a = 'He/she needs the ' . ( $has_verb ? 'work done' : $need_noun ) . ' for ' . $purpose_phrase;
    }
    if ( $p3a !== '' ) { $p3a = rtrim( $p3a ) . '.'; }

    $timeline_for_p3b = $timeline_already_said ? '' : $timeline;
    $p3b = '';
    if ( $del_loc !== '' ) {
        $p3b = 'The completed document needs to be sent to ' . $del_loc;
        if ( $timeline_for_p3b !== '' ) { $p3b .= ', within about ' . $timeline_for_p3b; }
        $p3b = rtrim( $p3b ) . '.';
    } elseif ( $timeline_for_p3b !== '' ) {
        $p3b = 'It is needed within about ' . $timeline_for_p3b . '.';
    }

    if ( $is_urgent ) {
        if ( $p3b !== '' )      { $p3b = rtrim( $p3b, '.' ) . ', so the requirement is urgent.'; }
        elseif ( $p3a !== '' )  { $p3a = rtrim( $p3a, '.' ) . ', so the requirement is urgent.'; }
        else                    { $p3a = 'The requirement is urgent.'; }
    }
    $p3 = trim( $p3a . ( $p3a !== '' && $p3b !== '' ? ' ' : '' ) . $p3b );

    // ---- Paragraph 4: anything else noted, when it isn't just the
    // urgency flag already folded into paragraph 3 above. ----
    $p4 = '';
    if ( $remarks !== '' && ! ( $is_urgent && trim( preg_replace( '/\burgent(ly)?\b|\basap\b|\bimmediately\b/i', '', $remarks ) ) === '' ) ) {
        $trimmed = $remarks;
        $len     = function_exists( 'mb_strlen' ) ? mb_strlen( $trimmed ) : strlen( $trimmed );
        if ( $len > 160 ) {
            $trimmed = function_exists( 'mb_substr' ) ? mb_substr( $trimmed, 0, 157 ) . '...' : substr( $trimmed, 0, 157 ) . '...';
        }
        $p4 = 'He/she also noted: ' . rtrim( $trimmed, '.' ) . '.';
    }

    // ---- Paragraph 5: the Contact Person, when that's someone other
    // than the applicant/subject $name above already names — e.g. a son
    // filing a Death Certificate request for a deceased parent, or an
    // agent filing a Legal Notice on a client's behalf. Skipped whenever
    // the two are effectively the same person (the common case: someone
    // filing a request for themselves), so this doesn't read as a
    // redundant "Contact: Ravi Kumar" directly under a paragraph that
    // already opened with "Ravi Kumar needs...". ----
    $p5 = '';
    if ( $contact_person !== '' && strcasecmp( trim( $contact_person ), trim( $name ) ) !== 0 ) {
        $p5 = 'Contact Person: ' . $contact_person . '.';
    }

    $sentences = array_values( array_filter( array( $p1, $p2, $p3, $p4, $p5 ), function( $s ) { return trim( (string) $s ) !== ''; } ) );

    if ( empty( $sentences ) ) {
        // Practically empty submission — never return a blank description.
        return trim( $name . ' has submitted a request' . ( $doc_type_raw !== '' ? ' for ' . $doc_type_raw . '.' : '.' ) );
    }

    // Single newline between paragraphs, not a blank line — a blank line
    // (the previous "\n\n" join) rendered as a double <br><br> gap on the
    // detail page (nl2br() keeps the original \n as well as adding <br>
    // before it) and as a genuinely blank line when the plain text was
    // pasted via Copy Description into WhatsApp/email. A single "\n" still
    // starts each paragraph on its own line either way, just without the
    // extra gap.
    return apply_filters( 'nsh_requirement_description', implode( "\n", $sentences ), $rid, $fd );
}

/**
 * Hash of exactly the fields the engine above reads. Lets the UI tell
 * whether a request's underlying data has drifted since its
 * description (generated or hand-written) was last saved, WITHOUT ever
 * silently regenerating/overwriting anything on its own — see
 * nsh_get_requirement_description()'s 'stale' flag.
 */
function nsh_requirement_fields_hash( $rid, $meta = null ) {
    $meta = $meta ? $meta : nsh_get_meta( $rid );
    $fd   = $meta['field_data'];
    $keys = array(
        'first_name', 'last_name', 'phone', 'mobile', 'mobile_number', 'phone_code',
        'document_type', 'application_type', 'university_name', 'university',
        'college_name', 'college', 'course_name', 'course', 'mode_of_education', 'mode',
        'education_mode', 'year_admission', 'year_of_admission', 'admission_year',
        'year_passing', 'year_of_passing', 'passing_year', 'number_of_semesters',
        'semesters', 'no_of_semesters', 'enrollment_number', 'enrollment', 'purpose',
        'current_location', 'delivery_location', 'remarks', 'additional_remarks', 'notes',
        'contact_person_name',
    );
    $snapshot = array();
    foreach ( $keys as $k ) {
        $snapshot[ $k ] = isset( $fd[ 'field_' . $k ] ) ? $fd[ 'field_' . $k ] : '';
    }
    $snapshot['timeline_working_days'] = get_post_meta( $rid, 'timeline_working_days', true );
    return md5( maybe_serialize( $snapshot ) );
}

/**
 * Persists a Student Requirement Description — used both by the
 * "generate on creation" step and by the admin regenerate/save actions.
 * $is_manual distinguishes an admin's own wording from an
 * engine-generated one (surfaced in the UI as a badge).
 */
function nsh_save_requirement_description( $rid, $text, $is_manual = false ) {
    update_post_meta( $rid, 'requirement_description', sanitize_textarea_field( $text ) );
    update_post_meta( $rid, 'requirement_description_manual', $is_manual ? '1' : '' );
    update_post_meta( $rid, 'requirement_description_hash', nsh_requirement_fields_hash( $rid ) );
    update_post_meta( $rid, 'requirement_description_updated', current_time( 'mysql' ) );
}

/**
 * Reads the Student Requirement Description.
 *
 * An admin's own manually-written wording is always honoured as-is —
 * only the 'stale' flag below tells the UI its source fields have since
 * changed; it is never regenerated or overwritten on its own.
 *
 * An AUTO-GENERATED description, however, is always recomputed live
 * from the request's current fields on every read (and the stored copy
 * quietly kept in sync) rather than trusting whatever text happened to
 * be saved earlier. This matters in practice: it's how an engine fix or
 * improvement (wording, pronouns, a previously-dropped field) shows up
 * immediately on existing requests without an admin having to click
 * "Regenerate" on each one — there is nothing an admin authored here to
 * protect, so there's nothing to go stale.
 *
 * Returns ['text'=>..., 'is_manual'=>bool, 'stale'=>bool] — 'stale' is
 * only ever true for a manual description whose source fields have
 * drifted since it was written (surfaced as a hint only; never
 * auto-applied).
 */
function nsh_get_requirement_description( $rid, $meta = null ) {
    $meta      = $meta ? $meta : nsh_get_meta( $rid );
    $is_manual = get_post_meta( $rid, 'requirement_description_manual', true ) === '1';

    if ( $is_manual ) {
        $text = get_post_meta( $rid, 'requirement_description', true );
        if ( $text === '' || $text === false ) {
            // Shouldn't normally happen (a manual flag with no text),
            // but never show a blank description.
            $text = nsh_generate_requirement_description( $rid, $meta );
            nsh_save_requirement_description( $rid, $text, false );
            $is_manual = false;
        }
    } else {
        // Computed live on every read — see the doc comment above for
        // why this deliberately does NOT persist on every call (that
        // would mean a DB write on every list/card load); the version
        // saved at creation time (nsh_ajax_create_request) and by
        // nsh_ajax_regenerate_description is only ever a point-in-time
        // record, not the source of truth for an auto description.
        $text = nsh_generate_requirement_description( $rid, $meta );
    }

    // 'stale' only has meaning for a manual description (does the
    // admin's own wording still match the current fields?) — an auto
    // description is always freshly computed above, so it can never be
    // stale relative to itself.
    $stale = false;
    if ( $is_manual ) {
        $saved_hash   = get_post_meta( $rid, 'requirement_description_hash', true );
        $current_hash = nsh_requirement_fields_hash( $rid, $meta );
        $stale        = ( $saved_hash !== '' && $saved_hash !== $current_hash );
    }
    return array(
        'text'      => $text,
        'is_manual' => $is_manual,
        'stale'     => $stale,
    );
}

function nsh_get_documents( $rid ) {
    $d = get_post_meta( $rid, 'documents', true );
    return is_array( $d ) ? $d : array();
}

function nsh_status_label( $s ) {
    // 'ready_for_processing' was missing here even though it's a real,
    // already-live client-facing status: it's offered in the staff
    // "Update Status" panel (nsh_render_staff_panel() in shortcodes.php)
    // and has its own client notification email template
    // (notifications.php) — this function just fell back to a generic
    // ucwords() for it instead of a proper label, which is how it went
    // unnoticed rather than one card dropdown simply omitting it.
    $m = array( 'submitted'=>'Received','under_review'=>'Under Review','ready_for_processing'=>'Ready for Processing','approved'=>'Approved','processing'=>'Processing','dispatched'=>'Dispatched','completed'=>'Completed','rejected'=>'Cancelled','service_not_available'=>'Service Not Available' );
    return isset($m[$s]) ? $m[$s] : ucwords( str_replace('_',' ',$s) );
}

function nsh_status_color( $s ) {
    $m = array( 'submitted'=>'#00b4d8','under_review'=>'#f59e0b','ready_for_processing'=>'#0ea5e9','approved'=>'#3b82f6','processing'=>'#8b5cf6','dispatched'=>'#f97316','completed'=>'#10b981','rejected'=>'#ef4444','service_not_available'=>'#6b7280' );
    return isset($m[$s]) ? $m[$s] : '#6b7280';
}

// ─────────────────────────────────────────────────────────────────────────
// INTERNAL STATUS (CRM pipeline) — staff-only, never client-facing.
//
// Lives in its own table (wp_nsh_internal_statuses), fully separate from
// the client-facing 'status' meta/nsh_status_label()/nsh_status_color()
// above: that pair is the small fixed enum clients see on their dashboard;
// this pipeline is an admin-configurable, reorderable, activate/
// deactivate-able list of internal workflow stages that a client must
// never see. Nothing in this section is ever called from a client-facing
// template, email, or notification — grep for "internal_status" before
// adding a new call site to make sure that stays true.
// ─────────────────────────────────────────────────────────────────────────

// Deterministic slug from a label: lower-cased, underscored, ASCII-only
// (matches the snake_case style every other meta/option key in this
// plugin already uses, e.g. 'service_not_available'). sanitize_title()
// handles the transliteration/strip-punctuation work; the '-' → '_' swap
// is just house style.
function nsh_generate_internal_status_slug( $label ) {
    $slug = str_replace( '-', '_', sanitize_title( $label ) );
    return $slug !== '' ? $slug : 'status_' . substr( md5( $label . microtime() ), 0, 8 );
}

// Every internal status row, ordered for display. Cached for the
// lifetime of the request (a single page load can ask for this many
// times — once for the filter bar, once per card badge, etc.) — a
// process-level static, not a persistent cache, so it can never go stale
// across requests. Any create/edit/reorder/activate/delete call in
// ajax.php calls nsh_clear_internal_status_cache() immediately after
// writing, so a subsequent call within the SAME request (e.g. the
// management screen re-rendering its own list right after a save) also
// sees the fresh data instead of this request's first, now-stale read.
function nsh_get_internal_statuses( $active_only = false, $force_refresh = false ) {
    static $all = null;
    if ( $all === null || $force_refresh ) {
        global $wpdb;
        $all = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}nsh_internal_statuses ORDER BY sort_order ASC, id ASC" );
        if ( ! is_array( $all ) ) { $all = array(); }
    }
    if ( ! $active_only ) { return $all; }
    return array_values( array_filter( $all, function( $r ) { return (int) $r->is_active === 1; } ) );
}

function nsh_clear_internal_status_cache() {
    nsh_get_internal_statuses( false, true );
}

// slug => row map, for O(1) label/color lookups.
function nsh_get_internal_status_map( $active_only = false ) {
    $map = array();
    foreach ( nsh_get_internal_statuses( $active_only ) as $r ) { $map[ $r->slug ] = $r; }
    return $map;
}

function nsh_internal_status_label( $slug ) {
    $map = nsh_get_internal_status_map( false );
    if ( isset( $map[ $slug ] ) ) { return $map[ $slug ]->label; }
    return $slug ? ucwords( str_replace( '_', ' ', $slug ) ) : 'Inquiry';
}

function nsh_internal_status_color( $slug ) {
    $map = nsh_get_internal_status_map( false );
    if ( isset( $map[ $slug ] ) ) { return $map[ $slug ]->color ? $map[ $slug ]->color : '#6b7280'; }
    return '#6b7280';
}

// Builds the meta_query clause(s) for filtering WP_Query/get_posts by
// internal status. Needs special handling for the pipeline's first stage
// ("inquiry"): a request that has NEVER had an internal status set has no
// 'internal_status' postmeta row at all yet (see nsh_get_meta()'s
// default-to-'inquiry' above), so filtering by "Inquiry" must match BOTH
// requests explicitly set to it AND requests where the meta key is simply
// missing or empty — otherwise every never-touched request would be
// invisible under its own correct filter.
function nsh_internal_status_meta_query( $slug ) {
    $slug = sanitize_key( $slug );
    if ( $slug === '' ) { return null; }
    if ( $slug === 'inquiry' ) {
        return array(
            'relation' => 'OR',
            array( 'key' => 'internal_status', 'value' => 'inquiry', 'compare' => '=' ),
            array( 'key' => 'internal_status', 'value' => '',        'compare' => '=' ),
            array( 'key' => 'internal_status', 'compare' => 'NOT EXISTS' ),
        );
    }
    return array( array( 'key' => 'internal_status', 'value' => $slug, 'compare' => '=' ) );
}

// Grouped counts (slug => count of requests currently in that stage),
// respecting the same client-status + date filters already applied to
// the list itself, so the pill numbers always match what filtering by
// them would actually show. Deliberately does NOT factor in the free-text
// search box — re-scanning every request's full submitted-field haystack
// (see nsh_request_search_haystack()) on every keystroke just to update
// pill counts would be real, avoidable per-keystroke DB work for a number
// that's mostly a rough orientation aid; the filter itself still works
// correctly together with a search term (see nsh_ajax_get_requests()),
// only the displayed COUNT stays scoped to status+date.
function nsh_get_internal_status_counts( $client_status = '', $date_after = null, $date_before = null ) {
    global $wpdb;
    $where  = array( "p.post_type = 'nsh_request'", "p.post_status = 'publish'" );
    $params = array();
    if ( $client_status ) {
        $where[]  = "EXISTS (SELECT 1 FROM {$wpdb->postmeta} pm2 WHERE pm2.post_id = p.ID AND pm2.meta_key = 'status' AND pm2.meta_value = %s)";
        $params[] = $client_status;
    }
    if ( $date_after )  { $where[] = 'p.post_date >= %s'; $params[] = $date_after; }
    if ( $date_before ) { $where[] = 'p.post_date <= %s'; $params[] = $date_before; }
    $sql = "SELECT COALESCE(NULLIF(pm.meta_value, ''), 'inquiry') AS ist, COUNT(*) AS cnt
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID AND pm.meta_key = 'internal_status'
            WHERE " . implode( ' AND ', $where ) . '
            GROUP BY ist';
    $sql  = $params ? $wpdb->prepare( $sql, $params ) : $sql;
    $rows = $wpdb->get_results( $sql );
    $out  = array();
    foreach ( (array) $rows as $r ) { $out[ $r->ist ] = (int) $r->cnt; }
    return $out;
}

/* ============================================================
   SERVICE-SCOPED FORM HELPERS (ported concept from Services2NRI's
   client-side condition evaluator + server-side qualification scoring —
   see src-react ServiceDetailPage.tsx / BookingController::store in the
   reference plugin). Kept in one small, well-named pair of functions so
   the server-side rule stays byte-for-byte in sync with the client-side
   one in assets/js/nsh-app.js (nshEvalCondition/nshEvalConditions).
   ============================================================ */

/**
 * Evaluates one field's `conditions` JSON (the same {"rules":[...],"action":
 * "all"|"any"} shape assets/js/nsh-app.js uses) against a $_POST-shaped
 * array of field_{key} => value submissions. Returns true when the field
 * should be treated as visible/required (i.e. no conditions, or the
 * conditions are satisfied) — false when it was conditionally hidden and
 * therefore must NOT be enforced as required server-side either.
 */
function nsh_field_conditions_met( $conditions_json, $post ) {
    if ( empty( $conditions_json ) ) { return true; }
    $cond = json_decode( $conditions_json, true );
    if ( empty( $cond['rules'] ) || ! is_array( $cond['rules'] ) ) { return true; }

    $eval_one = function ( $rule ) use ( $post ) {
        $field = isset( $rule['field'] ) ? $rule['field'] : '';
        $raw   = isset( $post[ 'field_' . $field ] ) ? $post[ 'field_' . $field ] : '';
        $val   = strtolower( trim( is_array( $raw ) ? implode( ',', $raw ) : (string) $raw ) );
        $rv    = strtolower( trim( (string) ( isset( $rule['value'] ) ? $rule['value'] : '' ) ) );
        switch ( isset( $rule['operator'] ) ? $rule['operator'] : 'equals' ) {
            case 'equals':       return $val === $rv;
            case 'not_equals':   return $val !== $rv;
            case 'contains':     return strpos( $val, $rv ) !== false;
            case 'not_contains': return strpos( $val, $rv ) === false;
            case 'starts_with':  return strpos( $val, $rv ) === 0;
            case 'ends_with':    return $rv === '' || substr( $val, -strlen( $rv ) ) === $rv;
            case 'is_empty':     return $val === '';
            case 'is_not_empty': return $val !== '';
            case 'greater_than': return (float) $val > (float) $rv;
            case 'less_than':    return (float) $val < (float) $rv;
        }
        return false;
    };

    $action = isset( $cond['action'] ) ? $cond['action'] : 'all';
    if ( $action === 'any' ) {
        foreach ( $cond['rules'] as $rule ) { if ( $eval_one( $rule ) ) { return true; } }
        return false;
    }
    foreach ( $cond['rules'] as $rule ) { if ( ! $eval_one( $rule ) ) { return false; } }
    return true;
}

/**
 * Server-side lead-qualification scoring — ported from Services2NRI's
 * BookingController::store(). Every active field on the submitted service
 * may carry a score_weight (0-100-ish points) and an optional
 * eligibility_rule {"value":"...", "message":"...", "severity":"hard"|"soft"}.
 * A "hard" rule whose value matches the submitted value forces the request
 * straight to 'not_yet_eligible' regardless of score (mirrors S2NRI's
 * disqualify_if behaviour); a "soft" rule is informational only and never
 * blocks the score.
 * Returns array( 'score' => int 0-100, 'status' => string, 'warnings' => array<string> ).
 */
function nsh_compute_qualification( $service_id, $post ) {
    global $wpdb;
    $fields = $wpdb->get_results( $wpdb->prepare(
        "SELECT field_key, score_weight, eligibility_rule, conditions FROM {$wpdb->prefix}nsh_fields WHERE service_id=%d AND is_active=1",
        intval( $service_id )
    ) );

    $total_possible = 0;
    $earned         = 0;
    $disqualified   = false;
    $warnings       = array();

    foreach ( $fields as $f ) {
        $weight = (int) $f->score_weight;
        if ( $weight <= 0 ) { continue; }
        if ( ! nsh_field_conditions_met( $f->conditions, $post ) ) { continue; } // not applicable to this path

        $total_possible += $weight;
        $raw = isset( $post[ 'field_' . $f->field_key ] ) ? $post[ 'field_' . $f->field_key ] : '';
        $val = trim( is_array( $raw ) ? implode( ',', $raw ) : (string) $raw );
        if ( $val !== '' ) { $earned += $weight; }

        if ( ! empty( $f->eligibility_rule ) ) {
            $rule = json_decode( $f->eligibility_rule, true );
            if ( is_array( $rule ) && isset( $rule['value'] ) && strtolower( $val ) === strtolower( (string) $rule['value'] ) ) {
                if ( ! empty( $rule['message'] ) ) { $warnings[] = $rule['message']; }
                if ( isset( $rule['severity'] ) && $rule['severity'] === 'hard' ) { $disqualified = true; }
            }
        }
    }

    $pct = $total_possible > 0 ? (int) round( ( $earned / $total_possible ) * 100 ) : 100;

    if ( $disqualified )   { $status = 'not_yet_eligible'; }
    elseif ( $pct >= 80 )  { $status = 'highly_qualified'; }
    elseif ( $pct >= 60 )  { $status = 'qualified'; }
    elseif ( $pct >= 40 )  { $status = 'requires_review'; }
    else                   { $status = 'incomplete'; }

    return array( 'score' => $pct, 'status' => $status, 'warnings' => $warnings );
}

function nsh_qualification_label( $status ) {
    $map = array(
        'highly_qualified' => array( 'Highly Qualified', '#059669' ),
        'qualified'        => array( 'Qualified',        '#16a34a' ),
        'requires_review'  => array( 'Needs Review',     '#d97706' ),
        'incomplete'       => array( 'Incomplete',       '#94a3b8' ),
        'not_yet_eligible' => array( 'Not Yet Eligible',  '#dc2626' ),
    );
    return isset( $map[ $status ] ) ? $map[ $status ] : array( ucfirst( str_replace( '_', ' ', $status ) ), '#64748b' );
}

/* ============================================================
   FORM STYLING SYSTEM
   One place for every color/size knob the request-form CSS (see the
   --nsh-form-* variables in nsh-style.css) reads, so admins can theme
   every form on the site from Settings -> Form Styling without ever
   touching source files. Keys here map 1:1 to CSS custom property
   names (minus the --nsh- prefix) so nsh_form_style_inline_css() can
   build the override <style> block generically.
   ============================================================ */
function nsh_form_style_defaults() {
    return array(
        'form-bg'              => '#ffffff',
        'field-bg'              => '#fafafa',
        'field-border-color'    => '#d1d5db',
        'field-border-width'    => '1px',
        'field-radius'          => '8px',
        'field-text'            => '#111827',
        'label-color'           => '#374151',
        'placeholder-color'     => '#9ca3af',
        'focus-color'           => '#4f46e5',
        'btn-bg'                => '#1a1a6e',
        'btn-bg-2'              => '#4f46e5',
        'btn-text'              => '#ffffff',
        'header-bg'             => '#1a1a6e',
        'header-bg-2'           => '#2d2db0',
        'header-text'           => '#ffffff',
        'error-color'           => '#ef4444',
        'required-color'        => '#ef4444',
        'font-size'             => '13px',
        'field-gap'             => '10px',
        'label-gap'             => '4px',
        'input-height'          => '36px',
        'btn-radius'            => '8px',
        'btn-padding-y'         => '9px',
        'btn-padding-x'         => '22px',
        'form-padding'          => '20px',
        'card-max-width'        => '520px',
        'font-size-mobile'      => '13px',
        'field-gap-mobile'      => '8px',
        'form-padding-mobile'   => '14px',
    );
}
function nsh_get_form_style_settings() {
    $saved = get_option( 'nsh_form_style_settings', array() );
    if ( ! is_array( $saved ) ) { $saved = array(); }
    return wp_parse_args( $saved, nsh_form_style_defaults() );
}
/**
 * Builds the ":root{--nsh-...}" override block enqueued after
 * nsh-style.css. Only variables that differ from the built-in
 * defaults are emitted (keeps the block small and makes it obvious,
 * on inspection, exactly what an admin has customized) — everything
 * else falls back to the defaults already baked into the stylesheet.
 */
function nsh_form_style_inline_css() {
    $settings = nsh_get_form_style_settings();
    $defaults = nsh_form_style_defaults();
    $decls    = array();
    foreach ( $settings as $key => $val ) {
        $val = trim( (string) $val );
        if ( $val === '' || $val === $defaults[ $key ] ) { continue; }
        // Values are either hex colors or CSS length strings — both safe to
        // emit as-is once restricted to this whitelist-shaped character set.
        if ( ! preg_match( '/^[#a-zA-Z0-9.\-, ()%]+$/', $val ) ) { continue; }
        $decls[] = '--nsh-' . $key . ':' . $val . ';';
    }
    if ( empty( $decls ) ) { return ''; }
    return ':root{' . implode( '', $decls ) . '}';
}

/* ============================================================
   CAPTCHA / BOT PROTECTION
   ============================================================
   Standalone-form-only ([nsh_standalone_form]) human verification, added
   right below the disclaimer/consent checkbox, above the Submit button.

   TWO interchangeable providers, picked by the 'nsh_captcha_provider'
   option ('builtin' [default] or 'turnstile') on Settings -> Bot
   Protection:

     'builtin'   — nsh_captcha_builtin_*() further below. Entirely
                   self-hosted: no external script load, no external
                   verification API call, nothing ever leaves this
                   server. A simple arithmetic question + an invisible
                   honeypot field + a minimum-time-on-form check, all
                   signed with an HMAC (WordPress's own auth salt) so no
                   server-side session/database storage is needed either
                   — pick this if you don't want ANY dependency on a
                   third-party server. Weaker against a determined,
                   custom-built bot than a managed challenge, but very
                   effective against the generic/automated spam this
                   form is actually exposed to, with zero external
                   dependency and zero recurring cost or account setup.

     'turnstile' — Cloudflare Turnstile (nsh_turnstile_*() below). A
                   managed challenge — materially harder for a generic
                   bot to defeat than the builtin option, at the cost of
                   loading Cloudflare's widget script client-side and
                   calling Cloudflare's siteverify API server-side on
                   every submission. Requires a (free) Cloudflare
                   account and API keys.

   Both providers share the exact same server-side-is-the-real-boundary
   principle: nsh_captcha_widget_html() (the dispatcher, further below)
   renders whichever provider is active, and nsh_captcha_verify()
   (also further below — called from nsh_ajax_create_request() in
   ajax.php) is the ONLY thing either provider's check actually gates
   submission on. A bot that skips this page's JavaScript entirely and
   POSTs straight to admin-ajax.php is rejected there regardless of
   provider; any client-side check is a UX nicety only.
   ============================================================ */

/**
 * Provider dispatch — reads Settings -> Bot Protection's
 * 'nsh_captcha_provider' option and calls through to whichever
 * provider's own widget-render / verify function is active. Every
 * caller (shortcodes.php's render, ajax.php's verify) goes through
 * these two functions rather than calling a specific provider directly,
 * so switching providers in Settings takes effect everywhere at once.
 */
function nsh_captcha_provider() {
    $p = get_option( 'nsh_captcha_provider', 'builtin' );
    return $p === 'turnstile' ? 'turnstile' : 'builtin';
}

function nsh_captcha_is_enabled() {
    // 'builtin' has its own separate always-on/off switch from
    // Turnstile's (nsh_captcha_builtin_enabled vs nsh_turnstile_enabled)
    // so disabling one provider while configuring the other doesn't
    // also silently disable it once switched to.
    return nsh_captcha_provider() === 'turnstile' ? nsh_turnstile_is_enabled() : nsh_captcha_builtin_is_enabled();
}

/** Renders whichever provider's widget is currently active (empty string if disabled). */
function nsh_captcha_widget_html() {
    return nsh_captcha_provider() === 'turnstile' ? nsh_turnstile_widget_html() : nsh_captcha_builtin_widget_html();
}

/**
 * Server-side verification — the actual security boundary (see this
 * section's top docblock). Called once from nsh_ajax_create_request().
 * $post is normally $_POST (a param instead of reading the superglobal
 * directly so the builtin path stays unit-testable — see the sandbox
 * test scripts used before every delivery).
 */
function nsh_captcha_verify( $post, $remote_ip = '' ) {
    if ( nsh_captcha_provider() === 'turnstile' ) {
        $token = isset( $post['cf-turnstile-response'] ) ? sanitize_text_field( wp_unslash( $post['cf-turnstile-response'] ) ) : '';
        return nsh_turnstile_verify( $token, $remote_ip );
    }
    return nsh_captcha_builtin_verify( $post );
}

define( 'NSH_TURNSTILE_TEST_SITE_KEY', '1x00000000000000000000AA' );
define( 'NSH_TURNSTILE_TEST_SECRET_KEY', '1x0000000000000000000000000000000AA' );

/**
 * Master on/off switch — checked both before enqueuing the widget script
 * (shortcodes.php) and before rendering/verifying it (below).
 */
function nsh_turnstile_is_enabled() {
    return (bool) get_option( 'nsh_turnstile_enabled', 1 );
}

function nsh_turnstile_site_key() {
    $k = get_option( 'nsh_turnstile_site_key', '' );
    return $k !== '' ? $k : NSH_TURNSTILE_TEST_SITE_KEY;
}

function nsh_turnstile_secret_key() {
    $k = get_option( 'nsh_turnstile_secret_key', '' );
    return $k !== '' ? $k : NSH_TURNSTILE_TEST_SECRET_KEY;
}

/** True while the site is still running on Cloudflare's public test keypair (no real protection yet). */
function nsh_turnstile_using_test_keys() {
    return get_option( 'nsh_turnstile_site_key', '' ) === '' || get_option( 'nsh_turnstile_secret_key', '' ) === '';
}

/**
 * Renders the widget markup itself (empty string if disabled in
 * settings). Turnstile's own script (enqueued by the caller — see
 * nsh_sc_standalone_form()) auto-discovers any element with class
 * "cf-turnstile" on the page and renders the interactive widget into it,
 * then keeps a hidden input named "cf-turnstile-response" inside that
 * same element in sync with the current (valid/expired) token — that
 * hidden input is what nsh-app.js's submit handler reads to gate
 * client-side submission, and what nsh_turnstile_verify() reads
 * server-side.
 */
function nsh_turnstile_widget_html() {
    if ( ! nsh_turnstile_is_enabled() ) { return ''; }
    $o  = '<div class="nsh-captcha-row">';
    $o .= '<div class="cf-turnstile" data-sitekey="' . esc_attr( nsh_turnstile_site_key() ) . '" data-theme="light" data-size="flexible" data-retry="auto" data-refresh-expired="auto"></div>';
    $o .= '</div>';
    return $o;
}

/**
 * Server-side verification — the actual security boundary (see this
 * section's top docblock for why client-side alone isn't trusted).
 * Called from nsh_ajax_create_request() for every submission NOT made by
 * an already-logged-in user (the standalone form is the only place the
 * widget is rendered, and it's always an anonymous/first-time visitor —
 * see nsh_ajax_create_request()'s wp_create_user() call for the same
 * "anonymous public submission" signal used elsewhere in that function).
 *
 * @return true|WP_Error true on a verified human pass; WP_Error (with a
 *   visitor-safe message) on any failure — missing token, Cloudflare
 *   rejection, or a network/transport failure talking to Cloudflare
 *   itself (fails CLOSED: if we can't confirm it's human, it's treated
 *   as not verified, same as an explicit reject).
 */
function nsh_turnstile_verify( $token, $remote_ip = '' ) {
    if ( ! nsh_turnstile_is_enabled() ) { return true; }
    $token = is_string( $token ) ? trim( $token ) : '';
    if ( $token === '' ) {
        return new WP_Error( 'nsh_turnstile_missing', 'Please complete the verification challenge before submitting.' );
    }
    $args = array(
        'secret'   => nsh_turnstile_secret_key(),
        'response' => $token,
    );
    if ( $remote_ip !== '' ) { $args['remoteip'] = $remote_ip; }

    $resp = wp_remote_post( 'https://challenges.cloudflare.com/turnstile/v0/siteverify', array(
        'timeout' => 10,
        'body'    => $args,
    ) );

    if ( is_wp_error( $resp ) ) {
        nsh_log( 'Turnstile verify: network error — ' . $resp->get_error_message() );
        return new WP_Error( 'nsh_turnstile_network', 'We could not confirm the verification challenge right now. Please try again in a moment.' );
    }
    $code = wp_remote_retrieve_response_code( $resp );
    $body = json_decode( wp_remote_retrieve_body( $resp ), true );
    if ( $code !== 200 || ! is_array( $body ) ) {
        nsh_log( 'Turnstile verify: unexpected response — HTTP ' . $code . ' — ' . wp_remote_retrieve_body( $resp ) );
        return new WP_Error( 'nsh_turnstile_bad_response', 'We could not confirm the verification challenge right now. Please try again in a moment.' );
    }
    if ( empty( $body['success'] ) ) {
        $codes = ! empty( $body['error-codes'] ) ? implode( ', ', (array) $body['error-codes'] ) : 'unknown';
        nsh_log( 'Turnstile verify: rejected — ' . $codes );
        // 'timeout-or-duplicate' is the one case worth a distinct, more
        // actionable message (the widget's token expired, or the same
        // token was already used — e.g. a double-submit) — everything
        // else collapses to one generic, visitor-safe message.
        if ( in_array( 'timeout-or-duplicate', (array) ( $body['error-codes'] ?? array() ), true ) ) {
            return new WP_Error( 'nsh_turnstile_expired', 'The verification challenge expired. Please tick the checkbox again and resubmit.' );
        }
        return new WP_Error( 'nsh_turnstile_failed', 'We could not verify that you are human. Please try again.' );
    }
    return true;
}

/* ============================================================
   CAPTCHA / BOT PROTECTION — Built-in provider (no external server)
   ============================================================
   Three layers, combined, all fully self-hosted:

     1. A simple arithmetic question ("What is 4 + 7?") — plain,
        undistorted digits (per spec: never a distorted-character
        puzzle), trivial for a human, and the whole point of layer 2/3
        below is that a bot doesn't even need to "solve" this one for
        the submission to already be caught — it mainly exists so a
        bot that DOES bother to fill every visible field still has to
        do slightly more than blind-post the form.
     2. An invisible honeypot field — a normal-looking text input
        that's positioned off-screen (never display:none, which some
        unsophisticated bots already know to skip — see the CSS,
        .nsh-hp-field), so a human never sees or fills it, but a bot
        that blindly fills every input on the page does. Its NAME is
        randomized per page render (nsh_captcha_builtin_token() below)
        rather than a fixed guessable name, so a bot can't simply learn
        to skip "the field named honeypot"/"website" etc.
     3. A minimum-elapsed-time check — a human takes at least a few
        seconds to read and fill even a single step of this form; a
        script that fetches the page and POSTs straight back cannot.

   No PHP session or database row is needed to remember the expected
   answer/honeypot name/render time between page-load and submit: all
   three are packed into one hidden field and HMAC-signed with
   wp_salt('auth') (a per-install secret WordPress already manages),
   so nsh_captcha_builtin_verify() can recompute and check everything
   from the token alone — tamper-proof (any edit to the payload breaks
   the signature) without persisting anything server-side between the
   two requests.

   SETTINGS: Settings -> Bot Protection:
     nsh_captcha_builtin_enabled    — on/off switch for this provider
     nsh_captcha_builtin_min_seconds — minimum seconds between render
                                        and submit (default: 3 — far
                                        below any real human's fill
                                        time even for a single short
                                        step, so this never bothers a
                                        genuine visitor)
   ============================================================ */

function nsh_captcha_builtin_is_enabled() {
    return (bool) get_option( 'nsh_captcha_builtin_enabled', 1 );
}

function nsh_captcha_builtin_min_seconds() {
    $v = get_option( 'nsh_captcha_builtin_min_seconds', 3 );
    $v = intval( $v );
    return $v > 0 ? $v : 3;
}

/**
 * Builds one signed, self-contained challenge: two small numbers to
 * add, a random honeypot field name, and the render timestamp — see
 * this section's top docblock for why this needs no server-side
 * storage at all.
 */
function nsh_captcha_builtin_token() {
    $a  = wp_rand( 2, 9 );
    $b  = wp_rand( 2, 9 );
    // A short random suffix, not a predictable counter — gives every
    // page render its own honeypot field name so a bot can't learn one
    // fixed name to leave blank across every visit/site.
    $hp = 'nsh_hp_' . substr( wp_generate_password( 12, false, false ), 0, 8 );
    $payload = array(
        'a'   => $a,
        'b'   => $b,
        'sum' => $a + $b,
        'hp'  => $hp,
        'ts'  => time(),
    );
    $json = wp_json_encode( $payload );
    $b64  = base64_encode( $json );
    $sig  = hash_hmac( 'sha256', $b64, wp_salt( 'auth' ) );
    return array(
        'a'     => $a,
        'b'     => $b,
        'hp'    => $hp,
        'token' => $b64 . '.' . $sig,
    );
}

/**
 * Decodes + verifies a token's HMAC signature only (no time/answer/
 * honeypot checks yet — those are separate steps in
 * nsh_captcha_builtin_verify() below so each failure gets its own
 * clear reason in the debug log). Returns the decoded payload array on
 * a valid signature, or null if the token is missing, malformed, or
 * tampered with.
 */
function nsh_captcha_builtin_decode_token( $token ) {
    if ( ! is_string( $token ) || strpos( $token, '.' ) === false ) { return null; }
    list( $b64, $sig ) = explode( '.', $token, 2 );
    $expected_sig = hash_hmac( 'sha256', $b64, wp_salt( 'auth' ) );
    if ( ! hash_equals( $expected_sig, $sig ) ) { return null; }
    $json = base64_decode( $b64, true );
    if ( $json === false ) { return null; }
    $payload = json_decode( $json, true );
    if ( ! is_array( $payload ) || ! isset( $payload['sum'], $payload['hp'], $payload['ts'] ) ) { return null; }
    return $payload;
}

/**
 * Renders the built-in widget: the question, its answer input, the
 * hidden signed token, and the honeypot field (visually hidden via the
 * .nsh-hp-field CSS class, kept in the DOM and out of the tab order via
 * tabindex="-1" + aria-hidden so it never confuses a screen-reader user
 * — see nsh-style.css).
 */
function nsh_captcha_builtin_widget_html() {
    if ( ! nsh_captcha_builtin_is_enabled() ) { return ''; }
    $c = nsh_captcha_builtin_token();
    $o  = '<div class="nsh-captcha-row nsh-captcha-builtin">';
    $o .= '<label class="nsh-captcha-builtin-label" for="nsh-captcha-answer">Quick check — what is ' . intval( $c['a'] ) . ' + ' . intval( $c['b'] ) . '?</label>';
    $o .= '<input type="text" inputmode="numeric" autocomplete="off" id="nsh-captcha-answer" name="nsh_captcha_answer" class="nsh-captcha-builtin-input nsh-captcha-answer" placeholder="Your answer">';
    $o .= '<input type="hidden" name="nsh_captcha_token" value="' . esc_attr( $c['token'] ) . '">';
    // Honeypot — deliberately has no visible label at all (a real label
    // would give a human a reason to notice and fill it).
    $o .= '<input type="text" name="' . esc_attr( $c['hp'] ) . '" class="nsh-hp-field" tabindex="-1" autocomplete="off" aria-hidden="true" value="">';
    $o .= '</div>';
    return $o;
}

/**
 * The actual verification — every layer described in this section's
 * top docblock, each with its own distinct WP_Error so the debug log
 * (and, for the time/math ones, the visitor) can tell exactly which
 * check failed. Fails CLOSED on anything malformed/missing, same as
 * the Turnstile provider.
 */
function nsh_captcha_builtin_verify( $post ) {
    if ( ! nsh_captcha_builtin_is_enabled() ) { return true; }

    $token = isset( $post['nsh_captcha_token'] ) ? (string) wp_unslash( $post['nsh_captcha_token'] ) : '';
    $payload = nsh_captcha_builtin_decode_token( $token );
    if ( $payload === null ) {
        nsh_log( 'Built-in CAPTCHA verify: missing/invalid/tampered token' );
        return new WP_Error( 'nsh_captcha_missing', 'Please complete the verification question before submitting.' );
    }

    // Token too old (visitor left the form open for hours, or is
    // reusing a stale page load) — ask them to reload rather than
    // accept an arbitrarily-old signed payload indefinitely.
    $age = time() - intval( $payload['ts'] );
    if ( $age > 2 * HOUR_IN_SECONDS ) {
        nsh_log( 'Built-in CAPTCHA verify: token expired — age ' . $age . 's' );
        return new WP_Error( 'nsh_captcha_expired', 'This page has been open a while — please refresh and try again.' );
    }

    // Honeypot: a human never sees this field (see .nsh-hp-field CSS),
    // so ANY value here — including a bot's own placeholder junk —
    // means whatever submitted this never rendered/respected the CSS,
    // a strong bot signal. Field NAME comes from the signed payload
    // (nsh_captcha_builtin_token() randomizes it per render), not a
    // fixed key, so this checks whichever field this specific page
    // load actually used.
    $hp_name = (string) $payload['hp'];
    if ( $hp_name !== '' && ! empty( $post[ $hp_name ] ) ) {
        nsh_log( 'Built-in CAPTCHA verify: honeypot field filled — bot signal' );
        return new WP_Error( 'nsh_captcha_bot', 'We could not verify that you are human. Please try again.' );
    }

    // Minimum time-on-form: a script that fetches the page and POSTs
    // straight back completes in well under a second; a genuine visitor
    // filling in even one short step never does.
    $min_seconds = nsh_captcha_builtin_min_seconds();
    if ( $age < $min_seconds ) {
        nsh_log( 'Built-in CAPTCHA verify: submitted too fast — ' . $age . 's < ' . $min_seconds . 's minimum' );
        return new WP_Error( 'nsh_captcha_too_fast', 'That was a little too quick — please try submitting again.' );
    }

    // The arithmetic answer itself.
    $answer = isset( $post['nsh_captcha_answer'] ) ? trim( (string) wp_unslash( $post['nsh_captcha_answer'] ) ) : '';
    if ( $answer === '' || ! is_numeric( $answer ) || intval( $answer ) !== intval( $payload['sum'] ) ) {
        nsh_log( 'Built-in CAPTCHA verify: wrong answer — expected ' . intval( $payload['sum'] ) . ', got "' . $answer . '"' );
        return new WP_Error( 'nsh_captcha_wrong_answer', 'That answer doesn\'t look right — please check the question above and try again.' );
    }

    return true;
}

/**
 * Form Disclaimer Phone Number — Settings -> General -> "Form Disclaimer
 * Phone Number" (admin-settings-integrated.php, nsh_settings_general()),
 * saved through the same generic nsh_save_settings AJAX handler (ajax.php)
 * as Manager Name/Phone/Email above it, under its own option key
 * (nsh_disclaimer_phone) — deliberately NOT the same option as Manager
 * Phone, since that one drives internal staff-notification routing while
 * this one is the number shown to the PUBLIC on every request form's
 * disclaimer box (shortcodes.php, nsh_render_service_wizard_html()), and
 * a site may reasonably want those to be two different numbers (e.g. a
 * personal manager phone vs. a shared front-desk/support line).
 *
 * Defaults to the number that used to be hardcoded directly into the
 * disclaimer markup, so upgrading this plugin doesn't silently change
 * what existing site visitors see — the admin only sees a difference once
 * they actually set their own value here.
 */
function nsh_disclaimer_phone_raw() {
    $v = get_option( 'nsh_disclaimer_phone', '' );
    $v = trim( (string) $v );
    return $v !== '' ? $v : '+91-9310724109';
}

/**
 * Digits only (with a leading country code digit string, no '+' or
 * separators) for the tel: href — e.g. "+91-9310724109" or
 * "+91 93107 24109" both become "919310724109". Returns '' if the saved
 * value has no digits at all, so callers can skip rendering a tel: link
 * (and the whole "you may call us" sentence) rather than link to
 * "tel:" with nothing after it.
 */
function nsh_disclaimer_phone_tel_href() {
    $digits = preg_replace( '/\D+/', '', nsh_disclaimer_phone_raw() );
    return $digits !== '' ? 'tel:+' . $digits : '';
}


/* ============================================================
   PAGE URL RESOLVERS
   ------------------------------------------------------------
   The client dashboard / admin dashboard / login pages used to be
   addressed with hard-coded home_url('/nsh-...') strings everywhere.
   Those break the moment a site owner renames a page slug, runs
   WordPress in a sub-directory with a different permalink structure,
   or moves the shortcode onto a differently-named page. These
   resolvers find the PUBLISHED page that actually carries the
   shortcode (preferring the default slug), cache its ID, and fall
   back to the legacy slug URL only if no such page exists.
   ============================================================ */

// TRACE: any caller needing the permalink of a plugin page → looks up cached page ID
//        (transient nsh_pg_<tag>), validates it is still a published page that still
//        contains the shortcode, else re-resolves via default slug, then via a
//        post_content LIKE search → returns get_permalink() or home_url('/<fallback>')
//        pre: WP loaded; post: always returns a non-empty URL string
//        edge: page deleted/unpublished/shortcode removed (cache re-resolved), no page at all (slug fallback)
function nsh_page_url_for( $shortcode_tag, $fallback_slug ) {
    static $memo = array();
    $memo_key = $shortcode_tag . '|' . $fallback_slug;
    if ( isset( $memo[ $memo_key ] ) ) { return $memo[ $memo_key ]; }

    $tkey = 'nsh_pg_' . $shortcode_tag;
    $page = null;
    $id   = (int) get_transient( $tkey );
    if ( $id ) {
        $cand = get_post( $id );
        if ( $cand && $cand->post_type === 'page' && $cand->post_status === 'publish' && has_shortcode( (string) $cand->post_content, $shortcode_tag ) ) {
            $page = $cand;
        }
    }
    if ( ! $page ) {
        $cand = get_page_by_path( $fallback_slug );
        if ( $cand && $cand->post_status === 'publish' && has_shortcode( (string) $cand->post_content, $shortcode_tag ) ) {
            $page = $cand;
        } else {
            global $wpdb;
            $found = $wpdb->get_var( $wpdb->prepare(
                "SELECT ID FROM {$wpdb->posts} WHERE post_type='page' AND post_status='publish' AND post_content LIKE %s ORDER BY ID ASC LIMIT 1",
                '%[' . $wpdb->esc_like( $shortcode_tag ) . '%'
            ) );
            if ( $found ) {
                $cand = get_post( (int) $found );
                if ( $cand && has_shortcode( (string) $cand->post_content, $shortcode_tag ) ) { $page = $cand; }
            }
        }
        if ( $page ) { set_transient( $tkey, (int) $page->ID, DAY_IN_SECONDS ); }
    }
    $url = $page ? get_permalink( $page ) : home_url( '/' . $fallback_slug );
    if ( ! $url ) { $url = home_url( '/' . $fallback_slug ); }
    return $memo[ $memo_key ] = $url;
}

// Dashboard + sign-in URLs are plugin routes now: nsh_client_dashboard_url(), nsh_admin_dashboard_url(), nsh_staff_dashboard_url(), nsh_login_page_url(), nsh_request_url() — see platform/routes.php.

// TRACE: a page is saved/trashed → drops the three cached page-ID transients so the
//        next lookup re-resolves; pre: none; post: transients absent; edge: none
add_action( 'save_post_page', 'nsh_flush_page_url_cache' );
add_action( 'trashed_post',   'nsh_flush_page_url_cache' );
function nsh_flush_page_url_cache() {
    foreach ( array( 'nsh_client_dashboard', 'nsh_admin_dashboard', 'nsh_login_form', 'nsh_request_form', 'nsh_services' ) as $tag ) {
        delete_transient( 'nsh_pg_' . $tag );
    }
}

function nsh_request_submit_url()   { return nsh_page_url_for( 'nsh_request_form',     'nsh-request-submit' ); }
function nsh_services_page_url()    { return nsh_page_url_for( 'nsh_services',         'nsh-services' ); }

