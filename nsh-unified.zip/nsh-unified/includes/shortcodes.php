<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/* ============================================================
   HELPERS
   ============================================================ */

function nsh_auth_gate() {
    if ( ! is_user_logged_in() ) {
        return '<div style="padding:40px;text-align:center;"><p>Please <a href="' . esc_url( nsh_login_page_url() ) . '">log in</a> to continue.</p></div>';
    }
    return '';
}

// TRACE: any "go to my dashboard" link → logged out: login page; client-only role: client
//        dashboard; anyone else (staff/admin): admin dashboard → URLs resolved from the real
//        published pages (nsh_page_url_for), not hard-coded slugs
//        pre: none; post: non-empty URL; edge: logged out, mixed client+administrator roles
function nsh_get_dashboard_url() {
    if ( ! is_user_logged_in() ) { return nsh_login_page_url(); }
    $roles = (array) wp_get_current_user()->roles;
    return ( in_array( 'nsh_client', $roles ) && ! in_array( 'administrator', $roles ) )
        ? nsh_client_dashboard_url()
        : nsh_admin_dashboard_url();
}

/* Returns a sticky nav bar for client pages */
function nsh_get_platform_name() {
    return get_option( 'nsh_platform_name', get_bloginfo( 'name' ) );
}

/* ============================================================
   CLIENT PORTAL — shell, sidebar and dashboard (v1.1 redesign)
   ------------------------------------------------------------
   Markup namespace: .nsh-cd-*  (client dashboard). Everything that
   nsh-app.js binds to is unchanged: #nsh-client-tab-container,
   .nsh-nav-item[data-tab], .nsh-view-request-link[data-rid],
   #nsh-new-sr-btn / #nsh-new-sr-btn2 (+ the new .nsh-open-sr).
   The admin dashboard does not use any of this.
   ============================================================ */

// TRACE: any client-portal view needing an icon → returns inline SVG markup for a known
//        icon name (stroke icons, currentColor) → unknown names fall back to a dot
//        pre: $name string; post: aria-hidden decorative <svg>; edge: unknown name
function nsh_cd_icon( $name ) {
    $p = array(
        'home'    => '<path d="M3 11l9-8 9 8"/><path d="M5 10v10h14V10"/>',
        'list'    => '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="4" cy="6" r="1"/><circle cx="4" cy="12" r="1"/><circle cx="4" cy="18" r="1"/>',
        'plus'    => '<path d="M12 5v14M5 12h14"/>',
        'grid'    => '<rect x="3" y="3" width="7" height="7" rx="1.6"/><rect x="14" y="3" width="7" height="7" rx="1.6"/><rect x="3" y="14" width="7" height="7" rx="1.6"/><rect x="14" y="14" width="7" height="7" rx="1.6"/>',
        'file'    => '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5"/>',
        'card'    => '<rect x="2" y="5" width="20" height="14" rx="2.4"/><path d="M2 10h20"/>',
        'user'    => '<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 4-6 8-6s8 2 8 6"/>',
        'help'    => '<circle cx="12" cy="12" r="9"/><path d="M9.5 9.2a2.6 2.6 0 1 1 3.6 2.4c-.8.4-1.1 1-1.1 1.8"/><circle cx="12" cy="17" r=".7" fill="currentColor"/>',
        'logout'  => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><path d="M16 17l5-5-5-5M21 12H9"/>',
        'clock'   => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
        'check'   => '<circle cx="12" cy="12" r="9"/><path d="M8 12.5l2.7 2.7L16 9.5"/>',
        'arrow'   => '<path d="M5 12h14M13 6l6 6-6 6"/>',
        'bell'    => '<path d="M18 8a6 6 0 0 0-12 0c0 7-3 8-3 8h18s-3-1-3-8"/><path d="M10 21a2 2 0 0 0 4 0"/>',
        'headset' => '<path d="M4 14v-2a8 8 0 0 1 16 0v2"/><rect x="3" y="14" width="4" height="6" rx="1.6"/><rect x="17" y="14" width="4" height="6" rx="1.6"/>',
        'route'   => '<circle cx="6" cy="19" r="2"/><circle cx="18" cy="5" r="2"/><path d="M8 19h6a3 3 0 0 0 0-6h-4a3 3 0 0 1 0-6h6"/>',
        'globe'   => '<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3.4 3.6 3.4 14.4 0 18M12 3c-3.4 3.6-3.4 14.4 0 18"/>',
        'cap'     => '<path d="M2 9l10-5 10 5-10 5z"/><path d="M6 11v5c0 1.5 2.7 3 6 3s6-1.5 6-3v-5"/>',
        'stamp'   => '<path d="M5 21h14M7 17h10v-3a3 3 0 0 0-3-3h-4a3 3 0 0 0-3 3z"/><path d="M12 11V7a2.5 2.5 0 1 1 5 0"/>',
        'pen'     => '<path d="M4 20l4-1 11-11a2.1 2.1 0 0 0-3-3L5 16z"/>',
        'download'=> '<path d="M12 4v11M7 11l5 5 5-5M5 20h14"/>',
    );
    $inner = isset( $p[ $name ] ) ? $p[ $name ] : '<circle cx="12" cy="12" r="3"/>';
    return '<svg class="nsh-cd-ico" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">' . $inner . '</svg>';
}

// TRACE: portal page renders → builds the left sidebar (desktop) / scrolling pill bar (mobile)
//        pre: logged-in client (callers gate); post: <aside> with only links that really work
//        edge: $active unknown (no item highlighted); in-page anchors fall back to full-page nav
//        when the target isn't in the DOM (handled in nsh-app.js .nsh-cd-anchor)
function nsh_client_nav( $active = '' ) {
    $platform = nsh_get_platform_name();
    $dash     = nsh_client_dashboard_url();
    $item = function ( $key, $href, $icon, $label, $extra = '', $cls_extra = '' ) use ( $active ) {
        $cls = 'nsh-cd-link' . $cls_extra . ( $active === $key ? ' active nsh-nav-active' : '' );
        return '<a class="' . $cls . '" href="' . esc_url( $href ) . '"' . ( $active === $key ? ' aria-current="page"' : '' ) . $extra . '>' . nsh_cd_icon( $icon ) . '<span>' . esc_html( $label ) . '</span></a>';
    };
    $o  = '<aside class="nsh-cd-side" aria-label="Client menu">';
    $o .= '<a class="nsh-cd-brand" href="' . esc_url( $dash ) . '"><span class="nsh-cd-brand-mark" aria-hidden="true">' . nsh_cd_icon( 'globe' ) . '</span><span class="nsh-cd-brand-name">' . esc_html( $platform ) . '</span></a>';
    $o .= '<nav class="nsh-cd-menu">';
    // Dashboard / Profile are real SPA tabs (nsh-nav-item + data-tab → swapped in place).
    $o .= $item( 'dashboard', $dash, 'home', 'Dashboard', ' data-tab="dashboard"', ' nsh-nav-item' );
    $o .= $item( 'requests', $dash . '#nsh-cd-requests', 'list', 'My Requests', ' data-cd-anchor="nsh-cd-requests"' );
    $o .= $item( 'new', nsh_request_submit_url(), 'plus', 'New Application' );
    $o .= $item( 'services', nsh_services_page_url(), 'grid', 'Other Services' );
    $o .= $item( 'documents', $dash . '#nsh-cd-documents', 'file', 'My Documents', ' data-cd-anchor="nsh-cd-documents"' );
    $o .= $item( 'payments', $dash . '#nsh-cd-payments', 'card', 'Payments', ' data-cd-anchor="nsh-cd-payments"' );
    $prof = '<a class="nsh-cd-link nsh-nav-item' . ( $active === 'profile' ? ' active nsh-nav-active' : '' ) . '" data-tab="profile" href="' . esc_url( add_query_arg( 'tab', 'profile', $dash ) ) . '"' . ( $active === 'profile' ? ' aria-current="page"' : '' ) . '>' . nsh_cd_icon( 'user' ) . '<span>Profile</span></a>';
    $o .= $prof;
    $o .= '<button type="button" class="nsh-cd-link nsh-open-sr">' . nsh_cd_icon( 'help' ) . '<span>Help &amp; Support</span></button>';
    $o .= '</nav>';
    $o .= '<a class="nsh-cd-logout" href="' . esc_url( nsh_logout_url() ) . '">' . nsh_cd_icon( 'logout' ) . '<span>Log out</span></a>';
    $o .= '</aside>';
    return $o;
}

// TRACE: portal page start/end → wraps page content in the sidebar+main shell
//        pre: none; post: balanced open/close markup; edge: none
function nsh_client_shell_open( $active = 'dashboard' ) { return '<div class="nsh-cd">' . nsh_client_nav( $active ) . '<div class="nsh-cd-main">'; }
// The support/"Other Service Request" modal lives in the shell (outside the SPA tab container)
// so Help & Support / Contact Support work on every tab and every portal page.
function nsh_client_shell_close() { return '</div>' . nsh_render_support_modal() . '</div>'; }

// TRACE: request card/status chip → maps a client-facing status to (progress 0-5, next-step text)
//        pre: $status string; post: array(stage|null, text); edge: unknown status → generic text,
//        cancelled/unavailable → null stage (no progress bar shown)
function nsh_cd_status_info( $status ) {
    $stages = array( 'submitted' => 1, 'under_review' => 2, 'ready_for_processing' => 3, 'approved' => 3, 'processing' => 4, 'dispatched' => 5, 'completed' => 5 );
    $text   = array(
        'submitted'            => 'We have received your request. Our team will review it shortly.',
        'under_review'         => 'Our team is assessing feasibility. We will contact you with the outcome.',
        'ready_for_processing' => 'Your request is queued and ready for processing.',
        'approved'             => 'Approved. Open the request to see your next steps.',
        'processing'           => 'Your request is being processed.',
        'dispatched'           => 'Your documents have been dispatched.',
        'completed'            => 'All done. Open the request to view the final details.',
        'rejected'             => 'This request was cancelled.',
        'service_not_available'=> 'We are unable to provide this service. Open the request for details.',
    );
    return array( isset( $stages[ $status ] ) ? $stages[ $status ] : null, isset( $text[ $status ] ) ? $text[ $status ] : 'Open the request to see the latest details.' );
}

// TRACE: dashboard tab renders → gathers the client's own documents across their requests
//        pre: $requests = WP_Post[] authored by the current user; post: array of
//        [name, request_no, rid, url, when, by_us] newest first, capped by caller
//        edge: missing attachment file (skipped), no documents meta (skipped)
function nsh_cd_collect_documents( $requests ) {
    $out = array(); $uploaded = 0;
    foreach ( $requests as $r ) {
        $docs = get_post_meta( $r->ID, 'documents', true );
        if ( ! is_array( $docs ) ) { continue; }
        $req_no = (string) get_post_meta( $r->ID, 'request_id', true );
        foreach ( $docs as $d ) {
            if ( empty( $d['file'] ) ) { continue; }
            $att = intval( $d['file'] );
            if ( ! $att || ! get_post( $att ) ) { continue; }
            $by_us = ! empty( $d['is_provider'] );
            if ( ! $by_us ) { $uploaded++; }
            $out[] = array(
                'name'       => isset( $d['doc_type'] ) && $d['doc_type'] !== '' ? (string) $d['doc_type'] : 'Document',
                'request_no' => $req_no !== '' ? $req_no : '#' . $r->ID,
                'rid'        => $r->ID,
                'url'        => nsh_get_download_url( $att ),
                'when'       => isset( $d['uploaded_at'] ) ? (string) $d['uploaded_at'] : '',
                'by_us'      => $by_us,
            );
        }
    }
    usort( $out, function ( $a, $b ) { return strcmp( $b['when'], $a['when'] ); } );
    return array( 'items' => $out, 'uploaded' => $uploaded );
}

// TRACE: dashboard tab renders → builds "recent updates" from request history
//        pre: $requests list; post: up to $limit [text, request_no, ts] newest first
//        edge: only client-safe events are surfaced (whitelist) — vendor/escalation/internal
//        events and free-text notes are NEVER shown; empty history → empty array
function nsh_cd_recent_updates( $requests, $limit = 6 ) {
    $out = array();
    foreach ( $requests as $r ) {
        $req_no = (string) get_post_meta( $r->ID, 'request_id', true );
        foreach ( nsh_get_history( $r->ID ) as $h ) {
            if ( empty( $h['event'] ) || empty( $h['time'] ) ) { continue; }
            if ( ! preg_match( '/^(Request submitted|Status updated|Quote set|Delivery date set|Documents? uploaded)/i', $h['event'] ) ) { continue; }
            $out[] = array( 'text' => $h['event'], 'request_no' => $req_no !== '' ? $req_no : '#' . $r->ID, 'ts' => (int) strtotime( $h['time'] ) );
        }
    }
    usort( $out, function ( $a, $b ) { return $b['ts'] - $a['ts']; } );
    return array_slice( $out, 0, $limit );
}

// Decorative hero artwork (original inline SVG; no external assets, no network).
function nsh_cd_hero_art() {
    return '<svg class="nsh-cd-art" viewBox="0 0 320 200" role="img" aria-label="" focusable="false">'
        . '<defs><linearGradient id="nshArtG1" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#6366f1"/><stop offset="1" stop-color="#22d3ee"/></linearGradient>'
        . '<linearGradient id="nshArtG2" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#eef2ff"/></linearGradient></defs>'
        . '<circle cx="168" cy="104" r="86" fill="url(#nshArtG1)" opacity=".14"/>'
        . '<circle cx="256" cy="52" r="26" fill="#fbbf24" opacity=".35" class="nsh-cd-art-float"/>'
        . '<rect x="86" y="42" width="128" height="116" rx="14" fill="url(#nshArtG2)" stroke="#c7d2fe" stroke-width="2"/>'
        . '<rect x="102" y="60" width="52" height="8" rx="4" fill="#818cf8"/><rect x="102" y="78" width="96" height="6" rx="3" fill="#e0e7ff"/><rect x="102" y="92" width="80" height="6" rx="3" fill="#e0e7ff"/><rect x="102" y="106" width="88" height="6" rx="3" fill="#e0e7ff"/>'
        . '<circle cx="198" cy="136" r="22" fill="url(#nshArtG1)"/><path d="M188 136l7 7 13-14" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>'
        . '<g class="nsh-cd-art-float2"><rect x="222" y="90" width="64" height="44" rx="10" fill="#fff" stroke="#c7d2fe" stroke-width="2"/><circle cx="240" cy="107" r="7" fill="#f59e0b"/><rect x="252" y="102" width="26" height="5" rx="2.5" fill="#c7d2fe"/><rect x="252" y="113" width="18" height="5" rx="2.5" fill="#e0e7ff"/></g>'
        . '</svg>';
}

// TRACE: client dashboard tab swap / full load → renders every dashboard section from the
//        logged-in client's OWN requests only (author = current user)
//        pre: logged in; post: markup string (no scripts); edge: zero requests (designed empty
//        states for every section), >0 requests but no docs/quotes/updates (per-section empties)
function nsh_render_client_dashboard_html( $uid, $user ) {
    $requests = get_posts( array( 'post_type' => 'nsh_request', 'post_status' => 'publish', 'posts_per_page' => -1, 'author' => $uid, 'orderby' => 'date', 'order' => 'DESC' ) );
    $total = count( $requests ); $active = 0; $done = 0;
    foreach ( $requests as $r ) {
        $s = get_post_meta( $r->ID, 'status', true );
        if ( $s === 'completed' ) { $done++; } elseif ( $s !== 'rejected' && $s !== 'service_not_available' ) { $active++; }
    }
    $docinfo = nsh_cd_collect_documents( $requests );
    $first   = trim( (string) $user->display_name );
    if ( $first === '' || strpos( $first, '@' ) !== false ) { $first = strstr( $user->user_email, '@', true ); }
    $first   = $first ? strtok( $first, ' ' ) : 'there';
    $submit  = nsh_request_submit_url();
    $dash    = nsh_client_dashboard_url();

    $o  = '<div class="nsh-cd-page">';

    // ── Hero ──
    $o .= '<section class="nsh-cd-hero" aria-labelledby="nsh-cd-welcome"><div class="nsh-cd-hero-copy">';
    $o .= '<p class="nsh-cd-eyebrow">Client dashboard</p>';
    $o .= '<h1 id="nsh-cd-welcome" class="nsh-cd-welcome">Welcome back, ' . esc_html( $first ) . ' <span class="nsh-cd-wave" aria-hidden="true">&#128075;</span></h1>';
    $o .= '<p class="nsh-cd-sub">Manage your requests, check their status, view your documents and stay updated &mdash; all in one place.</p>';
    $o .= '<div class="nsh-cd-hero-cta"><a href="' . esc_url( $submit ) . '" class="nsh-cd-btn nsh-cd-btn-primary">' . nsh_cd_icon( 'plus' ) . 'New Application Request</a>';
    $o .= '<button type="button" id="nsh-new-sr-btn" class="nsh-cd-btn nsh-cd-btn-ghost">' . nsh_cd_icon( 'headset' ) . 'Other Service Request</button></div>';
    $o .= '</div><div class="nsh-cd-hero-art">' . nsh_cd_hero_art() . '</div></section>';

    // ── Stats ──
    $stat = function ( $cls, $icon, $label, $val ) {
        return '<div class="nsh-cd-stat ' . $cls . '"><span class="nsh-cd-stat-ico">' . nsh_cd_icon( $icon ) . '</span><div><div class="nsh-cd-stat-lbl">' . esc_html( $label ) . '</div><div class="nsh-cd-stat-val" data-count="' . intval( $val ) . '">' . intval( $val ) . '</div></div></div>';
    };
    $o .= '<section class="nsh-cd-stats" aria-label="Summary">';
    $o .= $stat( 'is-indigo', 'list', 'Total Requests', $total );
    $o .= $stat( 'is-amber', 'clock', 'Active Requests', $active );
    $o .= $stat( 'is-green', 'check', 'Completed Requests', $done );
    $o .= $stat( 'is-violet', 'file', 'Documents Uploaded', $docinfo['uploaded'] );
    $o .= '</section>';

    // ── Main grid: requests + right rail ──
    $o .= '<div class="nsh-cd-grid"><section id="nsh-cd-requests" class="nsh-cd-panel nsh-cd-requests" aria-labelledby="nsh-cd-req-h">';
    $o .= '<header class="nsh-cd-panel-hd"><h2 id="nsh-cd-req-h">My Requests</h2><span class="nsh-cd-count">' . intval( $total ) . ' total</span></header>';
    if ( empty( $requests ) ) {
        $o .= '<div class="nsh-cd-empty"><span class="nsh-cd-empty-ico">' . nsh_cd_icon( 'list' ) . '</span><h3>No requests yet</h3><p>Submit your first application and it will appear here with live status updates.</p>';
        $o .= '<a href="' . esc_url( $submit ) . '" class="nsh-cd-btn nsh-cd-btn-primary">' . nsh_cd_icon( 'plus' ) . 'Start a New Application</a></div>';
    } else {
        $o .= '<div class="nsh-cd-reqlist">';
        foreach ( $requests as $req ) {
            $meta   = nsh_get_meta( $req->ID );
            $status = $meta['status'];
            $fd     = $meta['field_data'];
            if ( ! empty( $meta['service_name'] ) )          { $svc = $meta['service_name']; }
            elseif ( ! empty( $fd['field_service_type'] ) )  { $svc = $fd['field_service_type']; }
            elseif ( ! empty( $fd['field_document_type'] ) ) { $svc = $fd['field_document_type']; }
            else { $svc = 'Document Request'; }
            list( $stage, $next ) = nsh_cd_status_info( $status );
            $col = nsh_status_color( $status );
            $del = $meta['estimated_delivery'];
            $hist = nsh_get_history( $req->ID );
            $last = ! empty( $hist ) ? end( $hist ) : null;
            // nsh-view-request-link + data-rid → SPA controller opens it in place.
            $o .= '<a href="' . esc_url( nsh_request_url( $req->ID, 'client' ) ) . '" class="nsh-cd-req nsh-req-card-link-wrap nsh-view-request-link" data-rid="' . intval( $req->ID ) . '" style="--st:' . esc_attr( $col ) . ';">';
            $o .= '<div class="nsh-cd-req-top"><div class="nsh-cd-req-id"><span class="nsh-cd-req-ico">' . nsh_cd_icon( 'file' ) . '</span><div><div class="nsh-cd-req-no">' . esc_html( $meta['request_id'] ? $meta['request_id'] : '#' . $req->ID ) . '</div><div class="nsh-cd-req-svc">' . esc_html( wp_trim_words( $svc, 8, '' ) ) . '</div></div></div>';
            $o .= '<span class="nsh-cd-chip"><i aria-hidden="true"></i>' . esc_html( nsh_status_label( $status ) ) . '</span></div>';
            if ( $stage ) {
                $o .= '<div class="nsh-cd-track" role="img" aria-label="Progress: step ' . intval( $stage ) . ' of 5">';
                for ( $i = 1; $i <= 5; $i++ ) { $o .= '<span class="' . ( $i < $stage ? 'is-done' : ( $i === $stage ? 'is-now' : '' ) ) . '"></span>'; }
                $o .= '</div>';
            }
            $o .= '<p class="nsh-cd-next">' . esc_html( $next ) . '</p>';
            $o .= '<div class="nsh-cd-req-meta"><span>' . nsh_cd_icon( 'clock' ) . esc_html( get_the_date( 'd M Y', $req->ID ) ) . '</span>';
            if ( $del ) { $o .= '<span>' . nsh_cd_icon( 'route' ) . 'Est. delivery <strong>' . esc_html( date( 'd M Y', strtotime( $del ) ) ) . '</strong></span>'; }
            if ( $last && ! empty( $last['time'] ) ) { $o .= '<span>' . nsh_cd_icon( 'bell' ) . 'Updated ' . esc_html( date( 'd M', strtotime( $last['time'] ) ) ) . '</span>'; }
            $o .= '<span class="nsh-cd-req-go">View details ' . nsh_cd_icon( 'arrow' ) . '</span></div></a>';
        }
        $o .= '</div>';
    }
    $o .= '</section>';

    // Right rail
    $o .= '<aside class="nsh-cd-rail">';
    $o .= '<section class="nsh-cd-panel nsh-cd-quick"><header class="nsh-cd-panel-hd"><h2>Quick Actions</h2></header>';
    $o .= '<a class="nsh-cd-quick-row" href="' . esc_url( $submit ) . '"><span class="nsh-cd-quick-ico is-indigo">' . nsh_cd_icon( 'plus' ) . '</span><span><strong>New Application Request</strong><small>Start a new document request</small></span>' . nsh_cd_icon( 'arrow' ) . '</a>';
    $o .= '<a class="nsh-cd-quick-row" href="' . esc_url( nsh_services_page_url() ) . '"><span class="nsh-cd-quick-ico is-teal">' . nsh_cd_icon( 'grid' ) . '</span><span><strong>Browse Other Services</strong><small>Attestation, verification and more</small></span>' . nsh_cd_icon( 'arrow' ) . '</a>';
    $o .= '</section>';
    $o .= '<section class="nsh-cd-panel nsh-cd-help"><span class="nsh-cd-help-ico">' . nsh_cd_icon( 'headset' ) . '</span><h2>Need Help?</h2><p>Our support team is ready to help with your application, documents and any queries.</p>';
    $o .= '<button type="button" class="nsh-cd-btn nsh-cd-btn-ghost nsh-open-sr">Contact Support</button></section>';
    $o .= '<section class="nsh-cd-panel nsh-cd-track-card"><span class="nsh-cd-help-ico is-green">' . nsh_cd_icon( 'route' ) . '</span><h2>Track Your Request Easily</h2><p>Stay updated at every stage, from review to final delivery.</p>';
    $o .= '<a class="nsh-cd-link-arrow nsh-cd-anchor" href="' . esc_url( $dash . '#nsh-cd-requests' ) . '" data-cd-anchor="nsh-cd-requests">View my requests ' . nsh_cd_icon( 'arrow' ) . '</a></section>';
    $o .= '</aside></div>';

    // ── Our Services (data-driven; only real, active services) ──
    $services = function_exists( 'nsh_get_services' ) ? nsh_get_services( true ) : array();
    if ( ! empty( $services ) ) {
        $icons = array( 'education' => 'cap', 'legal' => 'stamp', 'documentation' => 'file', 'immigration' => 'globe' );
        $o .= '<section class="nsh-cd-panel nsh-cd-svc" aria-labelledby="nsh-cd-svc-h"><header class="nsh-cd-panel-hd"><h2 id="nsh-cd-svc-h">Our Services</h2><a class="nsh-cd-link-arrow" href="' . esc_url( nsh_services_page_url() ) . '">Explore all services ' . nsh_cd_icon( 'arrow' ) . '</a></header><div class="nsh-cd-svc-row">';
        foreach ( array_slice( $services, 0, 5 ) as $s ) {
            $ic = isset( $icons[ $s->category ] ) ? $icons[ $s->category ] : 'pen';
            $o .= '<a class="nsh-cd-svc-card" href="' . esc_url( add_query_arg( 'service', $s->slug, $submit ) ) . '"><span class="nsh-cd-svc-ico">' . nsh_cd_icon( $ic ) . '</span><span class="nsh-cd-svc-name">' . esc_html( wp_trim_words( $s->name, 5, '' ) ) . '</span></a>';
        }
        $o .= '</div></section>';
    }

    // ── Documents + Payments side by side on wide screens ──
    $o .= '<div class="nsh-cd-duo">';
    $o .= '<section id="nsh-cd-documents" class="nsh-cd-panel nsh-cd-docs" aria-labelledby="nsh-cd-doc-h"><header class="nsh-cd-panel-hd"><h2 id="nsh-cd-doc-h">My Documents</h2><span class="nsh-cd-count">' . intval( count( $docinfo['items'] ) ) . ' file' . ( count( $docinfo['items'] ) === 1 ? '' : 's' ) . '</span></header>';
    if ( empty( $docinfo['items'] ) ) {
        $o .= '<p class="nsh-cd-muted">No documents uploaded yet. Files you attach to an application will be listed here.</p>';
    } else {
        $o .= '<ul class="nsh-cd-list">';
        foreach ( array_slice( $docinfo['items'], 0, 6 ) as $d ) {
            $o .= '<li><span class="nsh-cd-list-ico">' . nsh_cd_icon( 'file' ) . '</span><div class="nsh-cd-list-main"><strong>' . esc_html( $d['name'] ) . '</strong><small>' . esc_html( $d['request_no'] ) . ( $d['by_us'] ? ' &middot; Provided by us' : ' &middot; Uploaded by you' ) . '</small></div>';
            $o .= '<a class="nsh-cd-icon-btn" href="' . esc_url( $d['url'] ) . '" aria-label="Download ' . esc_attr( $d['name'] ) . ' for request ' . esc_attr( $d['request_no'] ) . '">' . nsh_cd_icon( 'download' ) . '</a></li>';
        }
        $o .= '</ul>';
        if ( count( $docinfo['items'] ) > 6 ) { $o .= '<p class="nsh-cd-muted nsh-cd-more">Showing the latest 6. Open a request to see all of its documents.</p>'; }
    }
    $o .= '</section>';

    // ── Payments / quotations ──
    $o .= '<section id="nsh-cd-payments" class="nsh-cd-panel nsh-cd-pay" aria-labelledby="nsh-cd-pay-h"><header class="nsh-cd-panel-hd"><h2 id="nsh-cd-pay-h">Payments &amp; Quotations</h2></header>';
    $pay_rows = '';
    foreach ( $requests as $req ) {
        $q = get_post_meta( $req->ID, 'quote_amount', true );
        if ( $q === '' || floatval( $q ) <= 0 ) { continue; }
        $ps  = (string) get_post_meta( $req->ID, 'payment_status', true );
        $ps  = $ps !== '' ? $ps : 'pending';
        $no  = (string) get_post_meta( $req->ID, 'request_id', true );
        $pay_rows .= '<li><span class="nsh-cd-list-ico">' . nsh_cd_icon( 'card' ) . '</span><div class="nsh-cd-list-main"><strong>&#8377;' . esc_html( number_format( floatval( $q ), 2 ) ) . '</strong><small>' . esc_html( $no !== '' ? $no : '#' . $req->ID ) . '</small></div><span class="nsh-cd-pill is-' . esc_attr( sanitize_html_class( $ps ) ) . '">' . esc_html( ucwords( str_replace( '_', ' ', $ps ) ) ) . '</span></li>';
    }
    $o .= $pay_rows !== '' ? '<ul class="nsh-cd-list">' . $pay_rows . '</ul>' : '<p class="nsh-cd-muted">No payments or quotations yet. When we quote your request, the amount and payment status will appear here.</p>';
    $o .= '</section>';

    $o .= '</div>';

    // ── Recent updates ──
    $updates = nsh_cd_recent_updates( $requests );
    $o .= '<section class="nsh-cd-panel nsh-cd-upd" aria-labelledby="nsh-cd-upd-h"><header class="nsh-cd-panel-hd"><h2 id="nsh-cd-upd-h">Recent Updates</h2></header>';
    if ( empty( $updates ) ) {
        $o .= '<p class="nsh-cd-muted">No recent activity.</p>';
    } else {
        $o .= '<ol class="nsh-cd-timeline">';
        $now = current_time( 'timestamp' );
        foreach ( $updates as $u ) {
            $o .= '<li><span class="nsh-cd-dot" aria-hidden="true"></span><div><strong>' . esc_html( $u['text'] ) . '</strong><small>' . esc_html( $u['request_no'] ) . ' &middot; ' . esc_html( human_time_diff( $u['ts'], $now ) ) . ' ago</small></div></li>';
        }
        $o .= '</ol>';
    }
    $o .= '</section>';

    $o .= '</div>';
    return $o;
}

/* ============================================================
   SHORTCODE: LOGIN BUTTON
   ============================================================ */

add_shortcode( 'nsh_login_button', 'nsh_sc_login_button' );
function nsh_sc_login_button( $atts ) {
    $a = shortcode_atts( array( 'label' => 'Client Login', 'class' => '' ), $atts );
    if ( is_user_logged_in() ) {
        $u = wp_get_current_user();
        return '<a href="' . esc_url( nsh_get_dashboard_url() ) . '" class="nsh-btn nsh-btn-primary">' . esc_html( $u->display_name ) . ' &rarr;</a>';
    }
    return '<a href="' . esc_url( nsh_login_page_url() ) . '" class="nsh-btn nsh-btn-primary ' . esc_attr( $a['class'] ) . '">' . esc_html( $a['label'] ) . '</a>';
}

add_shortcode( 'nsh_admin_login_button', 'nsh_sc_admin_login_button' );
function nsh_sc_admin_login_button( $atts ) {
    $a   = shortcode_atts( array( 'label' => 'Staff Login' ), $atts );
    $url = is_user_logged_in() ? nsh_plat_home_url() : nsh_login_page_url();
    return '<a href="' . esc_url( $url ) . '" class="nsh-btn nsh-btn-secondary">' . esc_html( $a['label'] ) . '</a>';
}

/* ============================================================
   SHORTCODE: LOGIN FORM
   ============================================================ */

add_shortcode( 'nsh_login_form', 'nsh_sc_login_form' );
// TRACE: [nsh_login_form] and the /login/ route → atts[title] → the one sign-in card (password tab + magic-link tab) or a "signed in" card with dashboard + sign-out links
//        pre: none → post: markup holds the login nonce, honeypot, labelled fields, aria-live message areas → edge: signed-in visitor sees links, never the form; ?msg=out|expired|denied shows a notice
function nsh_sc_login_form( $atts ) {
    $a = shortcode_atts( array( 'title' => '' ), $atts );
    $title = $a['title'] !== '' ? $a['title'] : nsh_get_platform_name();
    if ( is_user_logged_in() ) {
        $u  = wp_get_current_user();
        $o  = '<div class="nsh-login-wrap"><div class="nsh-login-card nsh-text-center">';
        $o .= '<p>Signed in as <strong>' . esc_html( $u->display_name ) . '</strong></p>';
        if ( nsh_plat_group() !== '' ) { $o .= '<a href="' . esc_url( nsh_plat_home_url() ) . '" class="nsh-btn nsh-btn-primary">Go to Dashboard</a> '; }
        else { $o .= '<p class="nsh-hint">This account does not have access to a dashboard.</p>'; }
        $o .= '<a href="' . esc_url( nsh_logout_url() ) . '" class="nsh-btn nsh-btn-ghost">Sign out</a>';
        $o .= '</div></div>';
        return $o;
    }
    $msgs = array( 'out' => array( 'You have been signed out.', 'success' ), 'expired' => array( 'Your session has ended. Please sign in again.', 'error' ), 'denied' => array( 'Please sign in to continue.', 'error' ) );
    $mk   = isset( $_GET['msg'] ) ? sanitize_key( wp_unslash( (string) $_GET['msg'] ) ) : '';
    $to   = isset( $_GET['redirect_to'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( (string) $_GET['redirect_to'] ) ), '' ) : '';
    $n  = wp_create_nonce( 'nsh_login_nonce' );
    $mn = wp_create_nonce( 'nsh_frontend_nonce' );
    $o  = '<div class="nsh-login-wrap"><div class="nsh-login-card">';
    $o .= '<div class="nsh-login-logo"><div class="nsh-login-brand">' . esc_html( $title ) . '</div><div class="nsh-login-sub">Sign in to your account</div></div>';
    if ( isset( $msgs[ $mk ] ) ) { $o .= '<div class="nsh-alert nsh-alert-' . esc_attr( $msgs[ $mk ][1] ) . '" role="status">' . esc_html( $msgs[ $mk ][0] ) . '</div>'; }
    $o .= '<div class="nsh-login-tabs" role="tablist"><button type="button" class="nsh-lt active" data-lt="pw">Password</button><button type="button" class="nsh-lt" data-lt="magic">Magic Link</button></div>';
    $o .= '<div id="nsh-lt-pw" class="nsh-lt-pane active"><form id="nsh-login-form" novalidate>';
    $o .= '<input type="hidden" name="nonce" value="' . esc_attr( $n ) . '">';
    $o .= '<input type="hidden" name="redirect_to" value="' . esc_attr( $to ) . '">';
    $o .= '<div class="nsh-hp" aria-hidden="true" style="position:absolute;left:-9999px;"><label>Website<input type="text" name="nsh_website" tabindex="-1" autocomplete="off"></label></div>';
    $o .= '<div class="nsh-field"><label for="nsh-login-id">E-mail or username</label><input id="nsh-login-id" type="text" name="login" placeholder="you@example.com" required autocomplete="username" autocapitalize="none" spellcheck="false"></div>';
    $o .= '<div class="nsh-field"><label for="nsh-login-pw">Password</label><div class="nsh-pw-wrap"><input id="nsh-login-pw" type="password" name="password" placeholder="Password" required autocomplete="current-password"><button type="button" class="nsh-pw-toggle" aria-label="Show or hide password">Show</button></div></div>';
    $o .= '<label class="nsh-check"><input type="checkbox" name="remember" value="1"> <span>Keep me signed in on this device</span></label>';
    $o .= '<div id="nsh-login-err" class="nsh-alert nsh-alert-error" role="alert" aria-live="polite" style="display:none;"></div>';
    $o .= '<button type="submit" class="nsh-btn nsh-btn-primary nsh-w100"><span class="nsh-bt">Sign in</span><span class="nsh-bl" style="display:none;">Signing in...</span></button>';
    $o .= '</form><p class="nsh-login-help"><a href="' . esc_url( wp_lostpassword_url( nsh_login_page_url() ) ) . '">Forgot your password?</a></p></div>';
    $o .= '<div id="nsh-lt-magic" class="nsh-lt-pane"><p class="nsh-hint">Enter your e-mail and we will send you a one-time sign-in link.</p>';
    $o .= '<form id="nsh-magic-form" novalidate><input type="hidden" name="nonce" value="' . esc_attr( $mn ) . '">';
    $o .= '<div class="nsh-field"><label for="nsh-magic-email">E-mail</label><input id="nsh-magic-email" type="email" name="email" placeholder="you@example.com" required autocomplete="email"></div>';
    $o .= '<div id="nsh-magic-msg" role="status" aria-live="polite" style="display:none;"></div>';
    $o .= '<button type="submit" class="nsh-btn nsh-btn-primary nsh-w100">Send Login Link</button>';
    $o .= '</form></div>';
    $o .= '<div class="nsh-login-footer"><a href="' . esc_url( nsh_request_submit_url() ) . '">New client? Start a request &rarr;</a></div>';
    $o .= '</div></div>';
    return $o;
}

/* ============================================================
   SHORTCODE: MULTI-STEP REQUEST FORM
   ============================================================ */

add_shortcode( 'nsh_request_form', 'nsh_sc_request_form' );
function nsh_sc_request_form( $atts ) {
    $slug    = isset( $_GET['service'] ) ? sanitize_title( wp_unslash( $_GET['service'] ) ) : '';
    $service = $slug ? nsh_get_service( $slug ) : null;
    if ( $service && ! (int) $service->is_active ) { $service = null; }

    $o = nsh_client_shell_open( 'new' );
    $o .= '<div class="nsh-page-wrap">';
    $o .= '<div class="nsh-form-page"><div class="nsh-form-hero">';
    $o .= '<h1 id="nsh-form-hero-title">' . ( $service ? esc_html( $service->name ) : 'Submit a New Request' ) . '</h1>';
    $o .= '<p id="nsh-form-hero-sub">' . ( $service ? 'Complete all steps below. We will review and respond within 24 hours.' : 'Choose a service below to get started.' ) . '</p>';
    $o .= '</div>';
    // sl_mode reuses the exact same compact field/step/button design as the
    // standalone card [nsh_standalone_form] (approved look), instead of the
    // old larger "nsh-wizard-*" styling — so the dashboard's own New Request
    // form is just as compact and uses the same design language, field
    // components and Form Styling settings as every other form on the site.
    // nsh_render_service_field_html() is the SAME function
    // [nsh_standalone_form] calls below — the Services picker is one real
    // implementation shared by both, not a page-specific "boxes" grid.
    $o .= '<div class="nsh-wizard-page-card">';
    $o .= nsh_render_service_field_html( $service, array(
        'submit_label'   => 'Submit Request',
        'submit_loading' => 'Submitting...',
    ) );
    $o .= '</div>';
    $o .= '</div></div>';
    $o .= nsh_client_shell_close();
    return $o;
}

/**
 * Renders the Services field + the wizard it loads, as ONE shared
 * implementation used identically by [nsh_request_form] (Client Dashboard
 * "New Request") and [nsh_standalone_form]. The service picker is a plain
 * <select> inside the SAME .nsh-sl-wizard-step > .nsh-sl-fields > .nsh-field
 * markup every other step of the wizard uses — no dedicated "form loader"
 * wrapper, class, or stylesheet section exists for it, so it automatically
 * gets whatever height/width/spacing/typography/border/radius every other
 * field has (including any future change to --nsh-* Form Styling
 * variables) with zero Services-specific CSS to keep in sync. Choosing a
 * service swaps #nsh-sl-wizard-container in place via
 * nsh_ajax_load_service_wizard() (ajax.php) — see the
 * #nsh-sl-service-select change handler in nsh-app.js.
 */
function nsh_render_service_select_field_html( $service, $placeholder_mode = false ) {
    $services  = nsh_get_services( true );
    $grouped   = array();
    foreach ( $services as $s ) { $grouped[ $s->category ][] = $s; }
    $cat_names = nsh_service_categories();

    // Standalone ([nsh_standalone_form]) used to skip this field's own
    // "Choose a Service" label — see nsh_render_form_field()'s matching
    // comment for why that's been restored for every field on this form,
    // this one included, instead of folding the label into the select's
    // first option / the input's placeholder.
    $label_html = '<label>Choose a Service</label>';
    $first_opt  = '- Select a service -';
    $o  = '<div class="nsh-field nsh-field-full">' . $label_html;
    $o .= '<select id="nsh-sl-service-select" class="nsh-sl-service-select">';
    $o .= '<option value="">' . esc_html( $first_opt ) . '</option>';
    foreach ( $grouped as $cat_slug => $rows ) {
        $o .= '<optgroup label="' . esc_attr( isset( $cat_names[ $cat_slug ] ) ? $cat_names[ $cat_slug ]['name'] : ucfirst( $cat_slug ) ) . '">';
        foreach ( $rows as $s ) {
            $o .= '<option value="' . intval( $s->id ) . '"' . selected( $service && $service->id == $s->id, true, false ) . '>' . esc_html( $s->name ) . '</option>';
        }
        $o .= '</optgroup>';
    }
    $o .= '</select></div>';
    return $o;
}

/**
 * Step 1's "initial client information" fields — First/Last Name, Email,
 * Mobile Number, and a free-text "what do you need" field — shown ONLY
 * while no service has been chosen yet (rendered inside the picker shell
 * below, alongside the Services field). Once a service IS chosen, this
 * whole block is gone from the DOM — nsh_render_service_wizard_html()'s
 * Step 1 never includes it — because Email/Mobile are carried forward
 * into that service's own Contact Details step instead (same field_key,
 * __email/__phone, so it's literally the same field, not a duplicate
 * re-ask), and First Name/Last Name/the requirement text ride along as
 * hidden inputs. See nshCaptureInitialClientInfo() /
 * nshApplyInitialClientInfo() in nsh-app.js, which do the actual
 * carrying-forward right around the #nsh-sl-wizard-container swap.
 *
 * Field names deliberately reuse the exact same name attributes every
 * service's own Contact Details step already uses for email/phone
 * (field___email, field_phone_code, field___phone — see the 'phone' case
 * in nsh_render_form_field() below) so a value typed here needs no
 * translation layer to end up in the right place once the real
 * service-specific form takes over, and first/last name and the
 * requirement text use the same field_/field_data convention every other
 * field on the form already relies on (nsh_ajax_create_request() in
 * ajax.php automatically collects any POST key starting with "field_"
 * into the saved request's field_data — nothing new to wire up there).
 */
function nsh_render_initial_client_fields_html( $placeholder_mode = false ) {
    // No HTML `required` attribute — same convention as every other field
    // on the form (see the comment on $req in nsh_render_form_field()):
    // validation runs via JS against the .nsh-req star (or data-required —
    // see below), not the native browser prompt. These fields also aren't
    // inside a <form> yet at this stage (the wizard's
    // <form id="nsh-request-form"> only exists once a service is chosen),
    // so a native `required` attribute would have no submit event to
    // attach to anyway.
    //
    // Placeholder mode ([nsh_standalone_form]) used to hide these fields'
    // labels entirely and fold the label text into the placeholder instead
    // (e.g. a placeholder reading "First Name *"). That saved a little
    // vertical space but left the field with no visible name once it had
    // something typed into it — the placeholder, and with it the only clue
    // what the field was for, disappears the moment the client starts
    // typing. These now get the same short, compact <label> every other
    // field on the form uses (styled small/tight by the existing
    // .nsh-sl-fields .nsh-field label rule already in nsh-style.css — this
    // doesn't add a new, bulkier label style, just stops hiding the
    // existing compact one) — the placeholder text goes back to being an
    // actual example/hint instead of a label stand-in. That makes both
    // branches identical except for data-required (only needed in
    // placeholder/standalone mode — see below), so there's just the one
    // markup now instead of two copies to keep in sync.
    $req_attr = $placeholder_mode ? ' data-required="1"' : '';
    $o  = '<div class="nsh-field"' . $req_attr . '><label>First Name <span class="nsh-req">*</span></label><input type="text" name="field_first_name" placeholder="First name"></div>';
    $o .= '<div class="nsh-field"' . $req_attr . '><label>Last Name <span class="nsh-req">*</span></label><input type="text" name="field_last_name" placeholder="Last name"></div>';
    $o .= '<div class="nsh-field nsh-field-full"' . $req_attr . '><label>Email Address <span class="nsh-req">*</span></label><input type="email" name="field___email" placeholder="you@example.com"></div>';
    $o .= '<div class="nsh-field nsh-field-full"' . $req_attr . '>';
    $o .= '<label>Mobile Number <span class="nsh-req">*</span></label>';
    $o .= '<div class="nsh-phone-wrap" style="display:flex;gap:8px;width:100%;">';
    $o .= '<select name="field_phone_code" class="nsh-phone-code" style="flex:0 0 auto;width:110px;">';
    $codes = array( '+91' => 'IN +91', '+1' => 'US +1', '+44' => 'UK +44', '+61' => 'AU +61', '+971' => 'UAE +971', '+65' => 'SG +65', '+60' => 'MY +60', '+49' => 'DE +49' );
    foreach ( $codes as $code => $text ) { $o .= '<option value="' . esc_attr( $code ) . '">' . esc_html( $text ) . '</option>'; }
    $o .= '</select>';
    $o .= '<input type="tel" name="field___phone" placeholder="Mobile number" pattern="[0-9]{6,15}" style="flex:1;min-width:0;width:100%;">';
    $o .= '</div></div>';
    $o .= '<div class="nsh-field nsh-field-full"><label>Tell Us What You Need</label><textarea name="field_requirement" placeholder="Briefly describe what you are looking for" rows="3"></textarea></div>';
    return $o;
}

/**
 * The "no service chosen yet" state. It still LOOKS and IS structured like
 * a real wizard — a step-dots strip with a single active "Step 1" dot, and
 * a single wizard-step containing the service-select field as that step's
 * only field — instead of a bare placeholder paragraph outside any step
 * structure. This is what makes the Services field genuinely Step 1 of the
 * wizard rather than a separate pre-wizard element, even before a service
 * has been picked.
 */
function nsh_render_service_picker_shell_html( $service, $sl = true, $standalone = false ) {
    // Standalone mode ([nsh_standalone_form]): the step-dots bar is back
    // (see the matching comment in nsh_render_service_wizard_html()) with
    // its "Choose Service" dot label — repeating that same text a second
    // time as a step heading right underneath, and a THIRD time as the
    // select field's own "Choose a Service" label, is what actually read
    // as odd/duplicated, so those two (only those two) still don't render
    // here. Every other field below the select — First Name, Last Name,
    // Email, Mobile — gets its own real (compact) label now instead of
    // folding into the placeholder text, same as nsh_render_form_field()
    // everywhere else on this form.
    if ( $standalone ) {
        $o  = '<div class="nsh-sl-wizard-wrap"><div class="' . esc_attr( $sl ? 'nsh-sl-steps' : 'nsh-steps-bar' ) . '">';
        $o .= '<div class="' . ( $sl ? 'nsh-sl-step nsh-sl-step-active' : 'nsh-step nsh-step-active' ) . '" data-step="1">';
        $o .= '<div class="' . ( $sl ? 'nsh-sl-step-dot' : 'nsh-step-dot' ) . '"><span>1</span></div>';
        $o .= '<div class="' . ( $sl ? 'nsh-sl-step-lbl' : 'nsh-step-label' ) . '">Choose Service</div></div>';
        $o .= '</div>';
        $o .= '<div class="nsh-wizard-step nsh-sl-wizard-step" data-step="1">';
        $o .= '<div class="nsh-step-fields nsh-sl-fields nsh-standalone-fields">';
        $o .= nsh_render_service_select_field_html( $service, true );
        // Only present while no service is chosen yet — this whole block
        // disappears the moment a service is picked (see
        // nsh_render_initial_client_fields_html()'s docblock above for why
        // that's safe: nothing typed here is lost).
        $o .= '<div class="nsh-initial-client-fields">' . nsh_render_initial_client_fields_html( true ) . '</div>';
        $o .= '</div></div></div>';
        return $o;
    }

    $step_cls     = $sl ? 'nsh-sl-step'       : 'nsh-step';
    $step_dot_cls = $sl ? 'nsh-sl-step-dot'   : 'nsh-step-dot';
    $step_lbl_cls = $sl ? 'nsh-sl-step-lbl'   : 'nsh-step-label';
    $step_active  = $sl ? 'nsh-sl-step-active' : 'nsh-step-active';
    $bar_cls      = $sl ? 'nsh-sl-steps'      : 'nsh-steps-bar';
    $wstep_cls    = $sl ? 'nsh-wizard-step nsh-sl-wizard-step' : 'nsh-wizard-step';
    $fields_cls   = $sl ? 'nsh-step-fields nsh-sl-fields' : 'nsh-step-fields';
    $wrap_class   = $sl ? 'nsh-sl-wizard-wrap' : 'nsh-wizard-wrap';

    $o  = '<div class="' . esc_attr( $wrap_class ) . '"><div class="' . esc_attr( $bar_cls ) . '">';
    $o .= '<div class="' . $step_cls . ' ' . $step_active . '" data-step="1">';
    $o .= '<div class="' . $step_dot_cls . '"><span>1</span></div>';
    $o .= '<div class="' . $step_lbl_cls . '">Choose Service</div></div>';
    $o .= '</div>';
    $o .= '<div class="' . esc_attr( $wstep_cls ) . '" data-step="1">';
    if ( $sl ) {
        $o .= '<p class="nsh-sl-step-heading"><strong>Choose Service</strong></p>';
    } else {
        $o .= '<h3 class="nsh-step-title">Choose Service</h3>';
    }
    $o .= '<div class="' . esc_attr( $fields_cls ) . '">';
    $o .= nsh_render_service_select_field_html( $service );
    // Only present while no service is chosen yet — this whole block
    // disappears the moment a service is picked (see
    // nsh_render_initial_client_fields_html()'s docblock above for why
    // that's safe: nothing typed here is lost).
    $o .= '<div class="nsh-initial-client-fields">' . nsh_render_initial_client_fields_html() . '</div>';
    $o .= '<p class="nsh-hint" style="width:100%;margin:4px 0 0;">Select a service above to begin.</p>';
    $o .= '</div></div>';
    $o .= '</div>';
    return $o;
}

/**
 * The Services field is not a separate "Form Loader" block placed before
 * the wizard any more — #nsh-sl-wizard-container IS the sole top-level
 * structure this function returns. When a service is selected, the
 * service-select field is injected (via the 'service_field_html' opt)
 * directly into the real wizard's real Step 1, below the step-dots strip,
 * alongside that step's own configured fields. When no service is chosen
 * yet, the picker-shell above renders the same step-dots-strip-then-field
 * structure so the field is always "Step 1", never an outsider element.
 */
function nsh_render_service_field_html( $service, $submit_opts = array() ) {
    // Default sl_mode true unless explicitly disabled — every current caller
    // (client dashboard + standalone) uses the compact "sl" wizard chrome.
    $sl         = ! isset( $submit_opts['sl_mode'] ) ? true : (bool) $submit_opts['sl_mode'];
    // 'standalone' — set only by [nsh_standalone_form] — switches on the
    // one-field-per-row, placeholder-only, no-step-dots design throughout
    // the whole wizard (not just Step 1). The Client Dashboard's "New
    // Request" form never sets this, so it keeps its existing two-column,
    // labeled, step-dots look exactly as before.
    $standalone = ! empty( $submit_opts['standalone'] );

    // data-standalone lets nsh-app.js's AJAX swap/prefetch calls (which
    // otherwise have no way to know which shortcode rendered this
    // container) tell the server to keep rendering every subsequent
    // service-select swap in the same one-field-per-row/placeholder-only
    // mode this initial Step 1 was rendered in — see nsh_ajax_load_service_wizard()
    // and nsh_ajax_prefetch_all_wizards() in ajax.php.
    $o = '<div id="nsh-sl-wizard-container" class="nsh-sl-wizard-container"' . ( $standalone ? ' data-standalone="1"' : '' ) . '>';
    if ( $service ) {
        $o .= nsh_render_service_wizard_html( $service, $sl ? 'nsh-sl-wizard-wrap' : 'nsh-wizard-wrap', wp_parse_args( $submit_opts, array(
            'submit_label'      => 'Submit Request',
            'submit_loading'    => 'Submitting...',
            'sl_mode'           => $sl,
            'standalone'        => $standalone,
            'service_field_html' => nsh_render_service_select_field_html( $service, $standalone ),
        ) ) );
    } else {
        $o .= nsh_render_service_picker_shell_html( $service, $sl, $standalone );
    }
    $o .= '</div>'; // #nsh-sl-wizard-container
    return $o;
}

/**
 * Renders the category-grouped "browse services" card grid used by the
 * [nsh_services] catalog page — a deliberately different, browsable
 * presentation for a page whose whole purpose is looking through what's
 * offered. No request-form flow uses this any more (both
 * [nsh_request_form] and [nsh_standalone_form] use the single Services
 * field above instead); $target_url is where each card's "Get Started"
 * link points (with ?service= appended).
 */
function nsh_render_service_picker_html( $target_url ) {
    $services = nsh_get_services( true );
    $grouped  = array();
    foreach ( $services as $s ) { $grouped[ $s->category ][] = $s; }
    $cat_names = nsh_service_categories();

    $o = '<div class="nsh-services-wrap nsh-services-picker">';
    foreach ( $grouped as $cat_slug => $rows ) {
        $o .= '<h2 class="nsh-svc-cat-title">' . esc_html( isset( $cat_names[ $cat_slug ] ) ? $cat_names[ $cat_slug ]['name'] : ucfirst( $cat_slug ) ) . '</h2>';
        $o .= '<div class="nsh-services-grid">';
        foreach ( $rows as $s ) {
            $o .= '<div class="nsh-svc-card"><div class="nsh-svc-icon">&#128196;</div>';
            $o .= '<h3 class="nsh-svc-name">' . esc_html( $s->name ) . '</h3>';
            $o .= '<p class="nsh-svc-desc">' . esc_html( $s->short_desc ) . '</p>';
            $o .= '<p class="nsh-hint-sm">Typical turnaround: ' . intval( $s->turnaround_days ) . ' working days</p>';
            $o .= '<a href="' . esc_url( add_query_arg( 'service', $s->slug, $target_url ) ) . '" class="nsh-btn nsh-btn-primary">Get Started</a>';
            $o .= '</div>';
        }
        $o .= '</div>';
    }
    $o .= '</div>';
    return $o;
}

/**
 * Renders the full dynamic multi-step wizard <form> for one service,
 * using that service's own steps/fields from nsh_get_service_steps().
 * Shared by [nsh_request_form] and [nsh_standalone_form] so both stay
 * in sync. $wrap_class lets callers reuse their existing step-bar CSS
 * (the plain dashboard wizard vs. the compact "standalone card" wizard).
 */
function nsh_render_service_wizard_html( $service, $wrap_class = 'nsh-wizard-wrap', $opts = array() ) {
    $opts = wp_parse_args( $opts, array(
        'submit_label'       => 'Submit Request',
        'submit_loading'     => 'Submitting...',
        'sl_mode'            => false, // true = compact standalone-card markup/classes
        'standalone'         => false, // true = [nsh_standalone_form]'s one-field-per-row, no-labels, no-step-dots design
        'service_field_html' => '',    // prepended into Step 1's fields, below the step-dots strip
    ) );
    $steps = nsh_get_service_steps( $service->id );
    if ( empty( $steps ) ) {
        return '<p class="nsh-alert nsh-alert-error">This service is not fully configured yet. Please choose a different service.</p>';
    }
    $nonce      = wp_create_nonce( 'nsh_frontend_nonce' );
    $step_keys  = array_keys( $steps );
    $first_key  = $step_keys[0];
    $sl         = $opts['sl_mode'];
    $standalone = $opts['standalone'];

    // Whether to show the disclaimer + CAPTCHA box on the last step.
    // Always shown now, on every form this shared renderer builds
    // ([nsh_standalone_form] AND [nsh_request_form] alike — the Client
    // Dashboard's own "New Request" form) — same box, same wording, same
    // place, regardless of $standalone or login state. This used to be
    // conditional (standalone-only, then briefly "only when not logged
    // in"), which is what caused two different bugs in turn: a
    // not-logged-in visitor on [nsh_request_form] hit an unanswerable
    // "Please complete the verification question" error because the
    // widget wasn't rendered for them to answer it, and — once that was
    // narrowed to "logged-in-only skips it" — the box simply never
    // appeared at all for an actual logged-in client using their
    // dashboard's "New Request" link, which is the normal, expected way
    // to reach this form. Showing it unconditionally is what the
    // standalone form already does and is the simplest way to make both
    // forms behave identically. The server-side CAPTCHA check in
    // nsh_ajax_create_request() (ajax.php) still only ENFORCES the
    // answer for a submitter who isn't logged in (nsh_captcha_verify()
    // is never called at all for a logged-in client) — so a logged-in
    // client sees the same box for visual/behavioural consistency but
    // isn't blocked by it even if left blank; only a not-logged-in
    // submitter's answer is actually checked.
    $show_verification = true;

    // Cloudflare Turnstile's widget script — see the matching, more
    // detailed comment in nsh_sc_standalone_form() below. Duplicated here
    // (harmless — wp_enqueue_script() on an already-registered handle is
    // a no-op) so [nsh_request_form]'s own not-logged-in case (see
    // $show_verification above) also gets the script when Turnstile is
    // the active provider; that call site never rendered this form's
    // CAPTCHA widget before this fix, so it never needed the script.
    if ( $show_verification && nsh_captcha_provider() === 'turnstile' && nsh_turnstile_is_enabled() ) {
        wp_enqueue_script( 'nsh-turnstile', 'https://challenges.cloudflare.com/turnstile/v0/api.js', array(), null, true );
    }

    $step_cls      = $sl ? 'nsh-sl-step'      : 'nsh-step';
    $step_dot_cls  = $sl ? 'nsh-sl-step-dot'  : 'nsh-step-dot';
    $step_lbl_cls  = $sl ? 'nsh-sl-step-lbl'  : 'nsh-step-label';
    $step_line_cls = $sl ? 'nsh-sl-step-line' : 'nsh-step-line';
    $step_active   = $sl ? 'nsh-sl-step-active' : 'nsh-step-active';
    $bar_cls       = $sl ? 'nsh-sl-steps' : 'nsh-steps-bar';
    $form_cls      = $sl ? 'nsh-wizard-form nsh-sl-form' : 'nsh-wizard-form';
    $wstep_cls     = $sl ? 'nsh-wizard-step nsh-sl-wizard-step' : 'nsh-wizard-step';
    $fields_cls    = $sl ? 'nsh-step-fields nsh-sl-fields' : 'nsh-step-fields';
    if ( $standalone ) { $fields_cls .= ' nsh-standalone-fields'; }
    $nav_cls       = $sl ? 'nsh-step-nav nsh-sl-nav' : 'nsh-step-nav';
    $back_cls      = $sl ? 'nsh-sl-btn-back nsh-wizard-prev' : 'nsh-btn nsh-btn-ghost nsh-wizard-prev';
    // Next/Submit on the dashboard ([nsh_request_form]) form used to reuse
    // the generic .nsh-btn-primary class, styled from --c-primary (the
    // admin dashboard's own accent color) instead of the --nsh-btn-* "Form
    // Styling" variables the standalone form's own Next/Submit buttons
    // already used — so the "Buttons & Header" Form Styling settings had
    // no visible effect on this form's buttons at all, even though it's
    // the primary way most clients submit a request. nsh-wizard-btn-next/
    // -submit (nsh-style.css) theme from the same --nsh-btn-* variables as
    // .nsh-sl-btn-next/-submit, so both forms' buttons move together.
    $next_cls      = $sl ? 'nsh-sl-btn-next nsh-wizard-next' : 'nsh-btn nsh-wizard-btn-next nsh-wizard-next';
    $submit_cls    = $sl ? 'nsh-sl-btn-submit' : 'nsh-btn nsh-wizard-btn-submit';

    $o = '<div class="' . esc_attr( $wrap_class ) . '">';
    // Standalone ([nsh_standalone_form]) used to skip this step-dots bar
    // entirely (a single "Step X of N" text line stood in for it, to avoid
    // repeating the card header's own title) — but that read as a step
    // backward from the rest of the plugin's polish: the same compact,
    // already-small dots strip (28px dots, 9px uppercase labels — see
    // .nsh-sl-steps in nsh-style.css) is what gives the Client Dashboard's
    // "New Request" form its structured, professional feel, and the
    // standalone card is meant to feel like the same kind of complete,
    // polished application screen. Rendering the exact same bar here (no
    // separate branch/markup to keep in sync) restores that without adding
    // real bulk — it's the same handful of small pixels either way, and
    // gotoStep() in nsh-app.js already drives .nsh-sl-step-active/-done
    // generically wherever this markup appears, standalone included.
    $o .= '<div class="' . esc_attr( $bar_cls ) . '">';
    $pos = 0;
    foreach ( $steps as $sn => $step ) {
        $pos++;
        $o .= '<div class="' . $step_cls . ' ' . ( $sn === $first_key ? $step_active : '' ) . '" data-step="' . intval( $sn ) . '">';
        $o .= '<div class="' . $step_dot_cls . '"><span>' . intval( $pos ) . '</span></div>';
        $o .= '<div class="' . $step_lbl_cls . '">' . esc_html( $step['label'] ) . '</div></div>';
        if ( $pos < count( $steps ) ) { $o .= '<div class="' . $step_line_cls . '"></div>'; }
    }
    $o .= '</div>';
    $o .= '<form id="nsh-request-form" class="nsh-request-form ' . esc_attr( $form_cls ) . '" novalidate>';
    $o .= '<input type="hidden" name="nonce" value="' . esc_attr( $nonce ) . '">';
    $o .= '<input type="hidden" name="service_id" value="' . intval( $service->id ) . '">';
    $o .= '<input type="hidden" name="service_slug" value="' . esc_attr( $service->slug ) . '">';
    // Filled in by JS (nshEnsureUploadToken() in nsh-app.js) the moment
    // this form appears — a random value shared by every document upload
    // on THIS form, so background uploads that finish before Submit and
    // the request-creation call itself can both be matched back together.
    // See the "BACKGROUND DOCUMENT UPLOAD" section in includes/ajax.php.
    $o .= '<input type="hidden" name="nsh_upload_token" class="nsh-upload-token" value="">';
    foreach ( $steps as $sn => $step ) {
        $display = ( $sn !== $first_key ) ? 'style="display:none;"' : '';
        $o .= '<div class="' . esc_attr( $wstep_cls ) . '" data-step="' . intval( $sn ) . '" ' . $display . '>';
        if ( ! $standalone ) {
            if ( $sl ) {
                $o .= '<p class="nsh-sl-step-heading"><strong>' . esc_html( $step['label'] ) . '</strong></p>';
            } else {
                $o .= '<h3 class="nsh-step-title">' . esc_html( $step['label'] ) . '</h3>';
            }
        }
        $o .= '<div class="' . esc_attr( $fields_cls ) . '">';
        if ( $sn === $first_key && ! empty( $opts['service_field_html'] ) ) {
            // The Services field lives here — inside Step 1's own field
            // list, below the step-dots strip rendered above — as a
            // genuine first field of Step 1, not a separate block before
            // the wizard container.
            $o .= $opts['service_field_html'];
            // Carry forward First Name / Last Name / the "what do you
            // need" text the client already typed into Step 1 before
            // picking a service (see nsh_render_initial_client_fields_html()).
            // Email/Mobile don't need an equivalent here — every service's
            // own Contact Details step already has a field___email /
            // field___phone field, so those two are carried forward by
            // pre-filling THAT field instead (nshApplyInitialClientInfo()
            // in nsh-app.js), not duplicated. These three stay hidden
            // because there's no natural "first name" / "last name" /
            // "requirement" field anywhere else in a per-service wizard —
            // without this, that data would simply be lost the moment a
            // service is chosen.
            $o .= '<input type="hidden" name="field_first_name" class="nsh-carry-first-name">';
            $o .= '<input type="hidden" name="field_last_name" class="nsh-carry-last-name">';
            $o .= '<input type="hidden" name="field_requirement" class="nsh-carry-requirement">';
        }
        foreach ( $step['fields'] as $field ) {
            $o .= nsh_render_form_field( $field, $standalone );
        }
        // Disclaimer + mandatory consent checkbox — shown once, directly
        // below the LAST step's fields (right above the Submit button
        // that step renders below), not repeated on every step. Gated on
        // $show_verification (computed above) rather than $standalone
        // alone, so a not-logged-in visitor on [nsh_request_form] gets it
        // too — see that variable's own docblock for why.
        // #nsh-request-form's submit handler in nsh-app.js blocks
        // submission until #nsh-disclaimer-consent is checked — see the
        // 'submit' handler there.
        if ( $show_verification && $sn === end( $step_keys ) ) {
            $o .= '<div class="nsh-disclaimer-box">';
            $o .= '<p class="nsh-disclaimer-text"><strong>Please Note:</strong> We are an online service provider and are not physically located in the applicant&#8217;s city. Our services are provided remotely, and we assist clients through an online process. If you are comfortable proceeding with an online process, you may submit your request to us for assistance.</p>';
            // Phone number is configurable — Settings -> General -> "Form
            // Disclaimer Phone Number" (nsh_disclaimer_phone option, see
            // nsh_disclaimer_phone_raw()/nsh_disclaimer_phone_tel_href() in
            // helpers.php). The whole sentence is skipped, not printed with
            // a dead "tel:" link, if the admin ever clears the field down to
            // nothing but non-digit characters.
            $disclaimer_tel_href = nsh_disclaimer_phone_tel_href();
            if ( $disclaimer_tel_href !== '' ) {
                $o .= '<p class="nsh-disclaimer-text">If you would like to speak with us directly before submitting your request, you may call us at <a href="' . esc_attr( $disclaimer_tel_href ) . '">' . esc_html( nsh_disclaimer_phone_raw() ) . '</a>.</p>';
            }
            $o .= '<label class="nsh-disclaimer-consent-row"><input type="checkbox" id="nsh-disclaimer-consent" class="nsh-disclaimer-consent" name="disclaimer_consent" value="1"> <span>I have read and understood the above disclaimer and agree to proceed with the online service process.</span></label>';
            // Human-verification (CAPTCHA) — nsh_captcha_widget_html()
            // dispatches to whichever provider is active in Settings -> Bot
            // Protection (built-in / self-hosted, or Cloudflare Turnstile —
            // see the "CAPTCHA / Bot Protection" docblock in helpers.php).
            // Sits right below consent, right above Submit — same "final
            // submission section" the consent checkbox is in, per spec.
            // No-op (renders nothing) if disabled in settings.
            $o .= nsh_captcha_widget_html();
            $o .= '</div>';
        }
        $o .= '</div><div class="' . esc_attr( $nav_cls ) . '">';
        if ( $sn !== $first_key ) { $o .= '<button type="button" class="' . esc_attr( $back_cls ) . '" data-step="' . intval( $sn ) . '">&larr; Back</button>'; }
        if ( $sn !== end( $step_keys ) ) {
            $o .= '<button type="button" class="' . esc_attr( $next_cls ) . '" data-step="' . intval( $sn ) . '">Next &rarr;</button>';
        } else {
            $o .= '<button type="submit" class="' . esc_attr( $submit_cls ) . '"><span class="nsh-bt">' . esc_html( $opts['submit_label'] ) . '</span><span class="nsh-bl" style="display:none;">' . esc_html( $opts['submit_loading'] ) . '</span></button>';
        }
        $o .= '</div></div>';
    }
    // One shared upload-progress indicator for the whole form (covers all
    // file fields together), referenced by id from nsh-app.js's submit handler.
    $o .= '<div id="nsh-submit-progress" class="nsh-prog-bar nsh-submit-progress" style="display:none;margin-top:8px;"><div class="nsh-prog-fill nsh-submit-progress-fill" id="nsh-submit-progress-fill"></div></div>';
    $o .= '<p id="nsh-submit-progress-label" class="nsh-hint-sm nsh-submit-progress-label" style="display:none;"></p>';
    $o .= '<div id="nsh-form-err" class="nsh-alert nsh-alert-error nsh-form-err" style="display:none;margin-top:12px;"></div>';
    $o .= '</form>';
    // The success experience is now a modal built by nshShowSubmitSuccess()
    // in nsh-app.js (it needs the server's confirmed request number, so
    // it is created only after the request is saved) — no inline panel.
    $o .= '</div>';
    return $o;
}

function nsh_render_form_field( $field, $placeholder_mode = false ) {
    $opts     = nsh_parse_field_options( $field->field_options );
    $db_opts  = ( $field->field_type === 'dropdown' || $field->field_type === 'select' || $field->field_type === 'searchable' ) ? nsh_get_dropdown_options( $field->field_key ) : array();
    $all_opts = array_unique( array_merge( $opts, $db_opts ) );
    $req      = ''; // Validation done via JS using .nsh-req star — no HTML required attr
    $rstar    = $field->is_required ? '<span class="nsh-req">*</span>' : '';
    $ph       = esc_attr( $field->placeholder ? $field->placeholder : $field->field_label );
    // data-required carries the required flag on the wrapper regardless
    // of mode (harmless when a visible .nsh-req star is also present —
    // normal-mode forms keep working exactly as before) so
    // placeholder-mode fields — which have no .nsh-req star anywhere for
    // JS to find — still validate as required. See isReq() in nsh-app.js.
    $req_attr = $field->is_required ? ' data-required="1"' : '';
    $fname    = 'field_' . esc_attr( $field->field_key );
    $label    = esc_html( $field->field_label );
    $o        = '';

    // Conditional logic wrapper attributes
    $cond_attr = '';
    $cond_style = '';
    $cond_data = isset($field->conditions) && $field->conditions ? json_decode($field->conditions, true) : null;
    $has_cond = !empty($cond_data) && !empty($cond_data['rules']);
    if ($has_cond) {
        $cond_attr = ' data-nsh-cond="' . esc_attr(wp_json_encode($cond_data)) . '" data-nsh-field-key="' . esc_attr($field->field_key) . '"';
        $cond_style = ' style="display:none;"'; // hidden by default when conditions set; JS will show if matched
    }

    // The <label>...</label> line every field opens with. Standalone
    // ([nsh_standalone_form], $placeholder_mode=true) used to render this
    // as an empty string and fold the label text into the placeholder/
    // first-option/toggle-text instead — that made the form a little
    // shorter but meant a field's name vanished the moment it had
    // something typed/picked into it (the placeholder is gone by then).
    // The label is back for every field now, standalone included — it
    // already renders compactly here (small font, tight margin — see the
    // ".nsh-sl-fields .nsh-field label" rule in nsh-style.css, which every
    // field on this form is already wrapped by) so this restores the
    // field names without adding real bulk.
    $label_html = '<label>' . $label . ' ' . $rstar . '</label>';

    if ( $field->field_type === 'radio' ) {
        // All radio fields now render as a dropdown/select, regardless of
        // option count — same compact control as field_type=dropdown, so
        // every single-choice field on the form looks and behaves
        // identically. (The radio-pill and toggle CSS/markup stay in the
        // stylesheet in case a future field type wants them again, but
        // nothing renders them any more.)
        $o .= '<div class="nsh-field nsh-cond-field"' . $cond_attr . $cond_style . $req_attr . '>' . $label_html . '<select name="' . $fname . '" ' . $req . '><option value="">- Select -</option>';
        foreach ( $opts as $opt ) { $o .= '<option value="' . esc_attr( $opt ) . '">' . esc_html( $opt ) . '</option>'; }
        $o .= '</select></div>';
    } elseif ( $field->field_type === 'dropdown' || $field->field_type === 'select' ) {
        // 'select' is Services2NRI's name for the same admin-configurable
        // single-choice dropdown NRI Platform calls 'dropdown' — same markup.
        $o .= '<div class="nsh-field nsh-cond-field"' . $cond_attr . $cond_style . $req_attr . '>' . $label_html . '<select name="' . $fname . '" ' . $req . '><option value="">- Select -</option>';
        foreach ( $all_opts as $opt ) { $o .= '<option value="' . esc_attr( $opt ) . '">' . esc_html( $opt ) . '</option>'; }
        $o .= '</select></div>';
    } elseif ( $field->field_type === 'checkbox' ) {
        // Multi-select field. Submits as field_<key>[] so ajax.php / $fd
        // storage already handle it as an array via the existing
        // is_array($v) branch used for file inputs.
        //
        // Every checkbox field — regardless of option count — now uses the
        // ONE compact multi-select dropdown control (nsh-multiselect,
        // behavior in nsh-app.js). There used to be a second code path for
        // 4-or-fewer options that rendered plain <input type=checkbox>
        // pills under a "nsh-checkbox-group" class with NO matching CSS
        // anywhere in the stylesheet — those rendered as raw, unstyled,
        // misaligned browser checkboxes with no spacing or required-field
        // validation at all (checkbox values are always "truthy" to a
        // naive .val() check, so a required checkbox group could never
        // actually fail validation). Consolidating on one real, styled,
        // validated control fixes all of that instead of patching the
        // broken one with more CSS.
        $uid = 'ms-' . esc_attr( $field->field_key );
        $o  .= '<div class="nsh-field nsh-field-full nsh-cond-field"' . $cond_attr . $cond_style . $req_attr . '>' . $label_html;
        $o  .= '<div class="nsh-multiselect" data-field-key="' . esc_attr( $field->field_key ) . '">';
        $o  .= '<button type="button" class="nsh-ms-toggle" aria-haspopup="listbox" aria-expanded="false"><span class="nsh-ms-toggle-text">- Select -</span><span class="nsh-ms-toggle-arrow">&#9662;</span></button>';
        $o  .= '<div class="nsh-ms-panel" role="listbox" aria-multiselectable="true" style="display:none;">';
        foreach ( $opts as $opt ) {
            $o .= '<label class="nsh-ms-opt"><input type="checkbox" name="' . $fname . '[]" value="' . esc_attr( $opt ) . '"><span>' . esc_html( $opt ) . '</span></label>';
        }
        $o  .= '</div></div></div>';
    } elseif ( $field->field_type === 'date' ) {
        $o .= '<div class="nsh-field nsh-cond-field"' . $cond_attr . $cond_style . $req_attr . '>' . $label_html . '<input type="date" name="' . $fname . '" ' . $req . '></div>';
    } elseif ( $field->field_type === 'searchable' ) {
        $o .= '<div class="nsh-field nsh-cond-field"' . $cond_attr . $cond_style . $req_attr . '>' . $label_html;
        $o .= '<div class="nsh-search-field" data-key="' . esc_attr( $field->field_key ) . '">';
        $o .= '<input type="text" class="nsh-sf-input" placeholder="' . $ph . '" autocomplete="off" data-field="' . esc_attr( $field->field_key ) . '">';
        $o .= '<input type="hidden" name="' . $fname . '" class="nsh-sf-val" ' . $req . '>';
        $o .= '<div class="nsh-sf-dropdown" style="display:none;"></div></div></div>';
    } elseif ( $field->field_type === 'textarea' ) {
        $o .= '<div class="nsh-field nsh-field-full nsh-cond-field"' . $cond_attr . $cond_style . $req_attr . '>' . $label_html . '<textarea name="' . $fname . '" placeholder="' . $ph . '" rows="4" ' . $req . '></textarea></div>';
    } elseif ( $field->field_type === 'phone' ) {
        $o .= '<div class="nsh-field nsh-field-full nsh-cond-field"' . $cond_attr . $cond_style . $req_attr . '>' . $label_html;
        $o .= '<div class="nsh-phone-wrap" style="display:flex;gap:8px;width:100%;">';
        $o .= '<select name="field_phone_code" class="nsh-phone-code" style="flex:0 0 auto;width:110px;">';
        $codes = array( '+91' => 'IN +91', '+1' => 'US +1', '+44' => 'UK +44', '+61' => 'AU +61', '+971' => 'UAE +971', '+65' => 'SG +65', '+60' => 'MY +60', '+49' => 'DE +49' );
        foreach ( $codes as $code => $text ) { $o .= '<option value="' . esc_attr( $code ) . '">' . esc_html( $text ) . '</option>'; }
        $o .= '</select>';
        $o .= '<input type="tel" name="' . $fname . '" placeholder="Mobile number" ' . $req . ' pattern="[0-9]{6,15}" style="flex:1;min-width:0;width:100%;">';
        $o .= '</div></div>';
    } elseif ( $field->field_type === 'file' ) {
        // A service can have several distinct file fields (ID proof, parent's
        // ID, hospital record, existing certificate, ...) — every id here is
        // suffixed with the field_key so multiple dropzones can coexist on
        // one page without colliding (getElementById only ever finds the
        // first match, which silently broke every file field after the
        // first one when this used a single shared "nsh-file-input" id).
        // Compact single-row upload control (replaces the old large dashed
        // dropzone box, which took up a lot of vertical space especially
        // when a service has several file fields stacked on the Documents
        // step). It's still a real drop target — dragging a file anywhere
        // onto the row works — but visually it's just one slim bordered
        // row with a "Choose File" button, matching the height of every
        // other input on the form instead of standing out as an oversized
        // block. See the .nsh-dropzone CSS and the delegated 'dragover' /
        // 'dragleave' / 'drop' handlers in nsh-app.js.
        $uid = esc_attr( $field->field_key );
        $o .= '<div class="nsh-field nsh-field-full nsh-cond-field"' . $cond_attr . $cond_style . $req_attr . '>' . $label_html;
        $o .= '<div class="nsh-dropzone nsh-dz-row" id="nsh-file-drop-' . $uid . '" data-field-key="' . $uid . '" data-field-label="' . esc_attr( $field->field_label ) . '">';
        $o .= '<input type="file" name="' . $fname . '[]" multiple accept=".pdf,.jpg,.jpeg,.png" id="nsh-file-input-' . $uid . '" class="nsh-file-input" style="display:none">';
        $o .= '<div class="nsh-dz-inner">';
        $o .= '<span class="nsh-dz-icon">&#128206;</span>';
        $o .= '<button type="button" class="nsh-btn nsh-btn-outline nsh-btn-sm nsh-file-browse" data-target="nsh-file-input-' . $uid . '">Choose File</button>';
        $o .= '<span class="nsh-dz-text">or drag &amp; drop here</span>';
        $o .= '<span class="nsh-hint-sm nsh-dz-hint">PDF, JPG, PNG &middot; max 10MB each</span>';
        $o .= '</div>';
        $o .= '<div class="nsh-file-preview" data-preview-for="' . $uid . '"></div></div>';
        $o .= '</div>';
    } elseif ( $field->field_type === 'number' ) {
        $o .= '<div class="nsh-field nsh-cond-field"' . $cond_attr . $cond_style . $req_attr . '>' . $label_html . '<input type="number" name="' . $fname . '" placeholder="' . $ph . '" ' . $req . ' style="-moz-appearance:number-input;"></div>';
    } else {
        $type = ( $field->field_type === 'email' ) ? 'email' : 'text';
        $o .= '<div class="nsh-field nsh-cond-field"' . $cond_attr . $cond_style . $req_attr . '>' . $label_html . '<input type="' . $type . '" name="' . $fname . '" placeholder="' . $ph . '" ' . $req . '></div>';
    }
    // FIX 3: Append help text/description if set
    if ( !empty($field->description) ) {
        // Inject description inside the outermost nsh-field div, before closing
        $desc_html = '<p class="nsh-field-desc" style="margin:4px 0 0;font-size:12px;color:#64748b;line-height:1.5;">' . esc_html($field->description) . '</p>';
        // Insert before last </div>
        $last_div = strrpos($o, '</div>');
        if ($last_div !== false) {
            $o = substr($o, 0, $last_div) . $desc_html . substr($o, $last_div);
        }
    }
    return $o;
}


/* ============================================================
   SHORTCODE: STANDALONE REQUEST FORM  [nsh_standalone_form]
   Displays the multi-step form independently, with an attractive
   hero section, without any nav/dashboard wrapper.
   Use: [nsh_standalone_form] on any page.
   ============================================================ */

// TRACE: any markup chunk that must live on a page next to a copy of itself → HTML + instance name →
//        every id="X" becomes id="X-<inst>" and every for= / data-target= / aria-controls|labelledby|describedby=
//        that points at one of those ids is rewritten to match → returns the re-id'd HTML (unchanged when inst is '')
//        pre: none; post: no id in the chunk is shared with another instance; edge: references to ids outside the chunk are left alone
function nsh_uniquify_ids( $html, $inst ) {
    $inst = sanitize_key( (string) $inst );
    if ( $inst === '' || $html === '' ) { return $html; }
    $map = array();
    if ( preg_match_all( '/\sid="([^"]+)"/', $html, $m ) ) {
        foreach ( $m[1] as $id ) { $map[ $id ] = $id . '-' . $inst; }
    }
    if ( ! $map ) { return $html; }
    return preg_replace_callback( '/\b(id|for|data-target|aria-controls|aria-labelledby|aria-describedby)="([^"]*)"/', function ( $x ) use ( $map ) {
        return isset( $map[ $x[2] ] ) ? $x[1] . '="' . $map[ $x[2] ] . '"' : $x[0];
    }, $html );
}

add_shortcode( 'nsh_standalone_form', 'nsh_sc_standalone_form' );
// TRACE: [nsh_standalone_form service="slug" instance="name" title="…"] → renders the SAME card as before, wrapped in
//        <div class="nsh-sl-outer" data-nsh-inst="name"> with every id suffixed by the instance name → can be placed any
//        number of times on one page (blog hero + sidebar) without duplicate ids; JS state is kept per instance (nsh-app.js)
//        pre: none; post: instance names unique per request (a repeat gets -2, -3 …); edge: no instance given → f1, f2 …
function nsh_sc_standalone_form( $atts ) {
    static $used = array();
    $atts = shortcode_atts( array( 'service' => '', 'instance' => '', 'title' => '' ), $atts, 'nsh_standalone_form' );
    $inst = sanitize_key( $atts['instance'] );
    if ( $inst === '' ) { $inst = 'f' . ( count( $used ) + 1 ); }
    $base = $inst; $n = 2;
    while ( isset( $used[ $inst ] ) ) { $inst = $base . '-' . $n++; }
    $used[ $inst ] = true;
    $slug = $atts['service'] ? sanitize_title( $atts['service'] ) : ( isset( $_GET['service'] ) ? sanitize_title( wp_unslash( $_GET['service'] ) ) : '' );
    $service = $slug ? nsh_get_service( $slug ) : null;
    if ( $service && ! (int) $service->is_active ) { $service = null; }

    // Cloudflare Turnstile's widget script is only loaded when that
    // provider is the one actually selected (Settings -> Bot Protection)
    // AND enabled — the default 'builtin' provider is entirely self-
    // hosted and needs no external script at all (see the "CAPTCHA / Bot
    // Protection" docblock in helpers.php). Enqueued here (scoped to this
    // shortcode actually being on the page, rather than globally in
    // nsh_enqueue()) so a site that never embeds the standalone form — or
    // that stays on the built-in provider — never loads any third-party
    // script for this at all. Safe to call during the content loop:
    // WordPress prints the tag from whichever enqueue point is still
    // pending, same as any other late wp_enqueue_script() call.
    if ( nsh_captcha_provider() === 'turnstile' && nsh_turnstile_is_enabled() ) {
        wp_enqueue_script( 'nsh-turnstile', 'https://challenges.cloudflare.com/turnstile/v0/api.js', array(), null, true );
    }

    // One embed of this shortcode covers every service: the card carries a
    // Services field (nsh_render_service_field_html() — the SAME function
    // the Client Dashboard's New Request form uses below, not a separate
    // implementation), and choosing a service swaps the card body to that
    // service's wizard in place — so this single shortcode gives every
    // service the exact same polished, compact look on whatever page it's
    // placed on. A service= attribute/query-param still pre-selects one
    // (e.g. for a deep link from an email or ad), but the dropdown is
    // always there so the visitor can switch without leaving the page.
    $card_title = $service ? esc_html( $service->name ) : ( $atts['title'] !== '' ? esc_html( $atts['title'] ) : 'Get Estimated Quote Instantly' );

    $o  = '<div class="nsh-sl-outer" data-nsh-inst="' . esc_attr( $inst ) . '">';
    $o .= '<div class="nsh-sl-card">';
    $o .= '<div class="nsh-sl-card-hdr"><h3 class="nsh-sl-card-title" id="nsh-sl-card-title">' . $card_title . '</h3></div>';
    $o .= nsh_render_service_field_html( $service, array(
        'submit_label'   => '⚡ Calculate My Quote',
        'submit_loading' => 'Submitting…',
        'standalone'     => true,
    ) );
    $o .= '<p class="nsh-sl-card-footer">&#128274; SSL Secured &nbsp;|&nbsp; &#128203; Instant Confirmation</p>';
    $o .= '</div>'; // end card
    $o .= '</div>'; // end outer

    return nsh_uniquify_ids( $o, $inst );
}

/* ============================================================
   SHORTCODE: CLIENT DASHBOARD (with profile tab)
   ============================================================ */

add_shortcode( 'nsh_client_dashboard', 'nsh_sc_client_dashboard' );
function nsh_sc_client_dashboard( $atts ) {
    $gate = nsh_auth_gate();
    if ( $gate ) { return $gate; }

    $tab = sanitize_text_field( isset( $_GET['tab'] ) ? $_GET['tab'] : 'dashboard' );
    if ( $tab !== 'profile' ) { $tab = 'dashboard'; }

    $o  = nsh_client_shell_open( $tab === 'profile' ? 'profile' : 'dashboard' );
    // #nsh-client-tab-container is what the client-side SPA controller
    // (the "Admin Dashboard SPA Controller" block in nsh-app.js — it now
    // drives both dashboards, see detectSurface() there) swaps content
    // into via AJAX instead of a full page reload, exactly like
    // #nsh-admin-tab-container does for staff.
    $o .= '<div id="nsh-client-tab-container" class="nsh-dash-wrap nsh-portal-shell nsh-cd-container" data-current-tab="' . esc_attr( $tab ) . '">';
    $rid = is_array( $atts ) && isset( $atts['rid'] ) ? absint( $atts['rid'] ) : 0;
    $o .= $rid ? nsh_render_request_view( $rid, true ) : nsh_render_client_tab( $tab );
    $o .= '</div>';
    $o .= nsh_client_shell_close();
    return $o;
}

/**
 * Renders just the INSIDE of a client-dashboard tab (no header/nav) —
 * used both by the normal page load above and by the AJAX endpoint
 * (nsh_ajax_client_load_tab in ajax.php) that the SPA controller calls
 * on a tab switch, so there is one source of truth for each tab's markup.
 */
function nsh_render_client_tab( $tab ) {
    $uid  = get_current_user_id();
    $user = wp_get_current_user();

    if ( $tab === 'profile' ) {
        return nsh_render_profile_tab( $uid, $user );
    } else {
        return nsh_render_client_dashboard_html( $uid, $user );
    }
}

function nsh_render_profile_tab( $uid, $user ) {
    $phone   = get_user_meta( $uid, 'nsh_phone',   true );
    $address = get_user_meta( $uid, 'nsh_address', true );
    $o  = '<div class="nsh-profile-wrap nsh-portal-profile">';
    // nsh-nav-item + data-tab reuse the same tab-click delegation as the
    // main nav links (see detectSurface()/setActiveNav() in nsh-app.js) —
    // this is a plain forward tab switch (Profile → Dashboard), not a
    // "back" in the history sense, so it gets the same no-scroll-jump
    // in-place swap as any other tab click.
    $o .= '<div class="nsh-page-breadcrumb"><a href="' . esc_url( nsh_client_dashboard_url() ) . '" class="nsh-nav-item" data-tab="dashboard">&larr; Back to Dashboard</a></div>';
    $o .= '<h2 class="nsh-portal-page-title"><span class="nsh-portal-icon" aria-hidden="true">&#128100;</span> My Profile</h2>';
    $o .= '<div class="nsh-panel-card nsh-portal-panel" style="max-width:600px;">';
    $o .= '<form id="nsh-profile-form">';
    $o .= '<div class="nsh-field"><label>Display Name</label><input type="text" name="display_name" value="' . esc_attr( $user->display_name ) . '" placeholder="Your name"></div>';
    $o .= '<div class="nsh-field"><label>Email Address</label><input type="email" value="' . esc_attr( $user->user_email ) . '" disabled style="background:#f8fafc;color:#94a3b8;"><p class="nsh-hint-sm">Contact admin to change email.</p></div>';
    $o .= '<div class="nsh-field"><label>Phone Number</label>';
    $o .= '<div class="nsh-phone-wrap"><select name="phone_code" class="nsh-phone-code">';
    foreach ( array( '+91' => 'IN +91', '+1' => 'US +1', '+44' => 'UK +44', '+61' => 'AU +61', '+971' => 'UAE +971' ) as $code => $text ) {
        $o .= '<option value="' . esc_attr( $code ) . '">' . esc_html( $text ) . '</option>';
    }
    $o .= '</select><input type="tel" name="phone" value="' . esc_attr( $phone ) . '" placeholder="Mobile number" pattern="[0-9]{6,15}"></div></div>';
    $o .= '<div class="nsh-field"><label>Address</label><input type="text" name="address" value="' . esc_attr( $address ) . '" placeholder="Your address"></div>';
    $o .= '<hr style="border:none;border-top:1px solid #e2e8f0;margin:20px 0;">';
    $o .= '<h4 style="margin:0 0 12px;font-size:15px;">Change Password <span style="font-size:12px;font-weight:400;color:#94a3b8;">(leave blank to keep current)</span></h4>';
    $o .= '<div class="nsh-field"><label>New Password</label><div class="nsh-pw-wrap"><input type="password" name="new_password" placeholder="Min 8 characters" id="nsh-new-pw"><button type="button" class="nsh-pw-toggle">Show</button></div></div>';
    $o .= '<div class="nsh-field"><label>Confirm Password</label><input type="password" name="confirm_password" placeholder="Repeat password"></div>';
    $o .= '<div id="nsh-profile-msg" class="nsh-alert" style="display:none;margin-bottom:12px;"></div>';
    $o .= '<button type="submit" class="nsh-btn nsh-btn-primary">Save Profile</button>';
    $o .= '</form></div></div>';
    return $o;
}

function nsh_render_support_modal() {
    $cats = array( 'Refund', 'Shipping', 'Order Status', 'Payment Issue', 'Login / Sign Up', 'Other' );
    $o  = '<div id="nsh-sr-modal" role="dialog" aria-modal="true" aria-label="Other Service Request" style="display:none;position:fixed;inset:0;z-index:99999;align-items:center;justify-content:center;background:rgba(0,0,0,.5);">';
    $o .= '<div class="nsh-modal-box"><div class="nsh-modal-hdr"><h3>Other Service Request</h3>';
    $o .= '<button type="button" class="nsh-modal-x nsh-sr-close" aria-label="Close">&#10005;</button></div>';
    $o .= '<div class="nsh-modal-body">';
    $o .= '<form id="nsh-support-form">';
    $o .= '<div class="nsh-field"><label>Category <span class="nsh-req">*</span></label>';
    $o .= '<select name="category" id="nsh-support-cat" required class="nsh-modal-select"><option value="">-- Select Category --</option>';
    foreach ( $cats as $cat ) { $o .= '<option value="' . esc_attr( $cat ) . '">' . esc_html( $cat ) . '</option>'; }
    $o .= '</select></div>';
    if ( ! is_user_logged_in() ) {
        $o .= '<div class="nsh-field"><label>Your Email <span class="nsh-req">*</span></label><input type="email" name="email" placeholder="your@email.com" required></div>';
    }
    $o .= '<div class="nsh-field"><label>Description <span class="nsh-req">*</span></label><textarea name="description" rows="4" placeholder="Describe your issue in detail..." required></textarea></div>';
    $o .= '<div class="nsh-field"><label>Attachment <span class="nsh-hint-sm">(optional)</span></label>';
    $o .= '<input type="file" name="support_file" accept=".pdf,.jpg,.jpeg,.png" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:8px;font-size:13px;"></div>';
    $o .= '<div id="nsh-support-err" class="nsh-alert nsh-alert-error" style="display:none;margin-bottom:12px;"></div>';
    $o .= '<button type="submit" class="nsh-btn nsh-btn-primary nsh-w100">Submit Request</button>';
    $o .= '</form></div></div></div>';
    return $o;
}

/* ============================================================
   SHORTCODE: REQUEST DETAIL VIEW
   ============================================================ */

add_shortcode( 'nsh_request_view', 'nsh_sc_request_view' );
function nsh_sc_request_view( $atts ) {
    return nsh_render_request_view( 0, false );
}

/**
 * Renders the full request-detail screen. Used two ways:
 *  - $embedded = false (default): the standalone /nsh-request/{id} page —
 *    includes the site nav/breadcrumb header, exactly as before.
 *  - $embedded = true: returned as an AJAX fragment for the admin
 *    dashboard SPA (nsh_ajax_admin_load_request_detail) — the header
 *    nav/breadcrumb is swapped for a lightweight "back to list" button
 *    that the dashboard's own JS wires up, since the dashboard already
 *    has its own header/nav on screen.
 * $rid_override lets the AJAX path pass the request ID directly instead
 * of relying on the query var / URL parsing (which only make sense for
 * a real page load).
 */
function nsh_render_request_view( $rid_override = 0, $embedded = false ) {
    $rid = $rid_override ? intval( $rid_override ) : intval( get_query_var( 'nsh_request_id' ) );
    if ( ! $rid ) {
        $parts = explode( '/', trim( parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' ) );
        $idx   = array_search( 'request', $parts );
        if ( $idx !== false && isset( $parts[ $idx + 1 ] ) ) { $rid = intval( $parts[ $idx + 1 ] ); }
    }
    if ( ! $rid )                       { return '<div class="nsh-msg-card"><p>Request not found.</p></div>'; }
    if ( ! is_user_logged_in() )        { return '<div class="nsh-msg-card"><p>Please <a href="' . esc_url( nsh_login_page_url() ) . '">log in</a>.</p></div>'; }
    if ( ! nsh_is_own_request( $rid ) ) { return '<div class="nsh-msg-card"><p>Access denied.</p></div>'; }

    $meta       = nsh_get_meta( $rid );
    $status     = $meta['status'];
    $fd         = $meta['field_data'];
    $docs       = nsh_get_documents( $rid );
    $messages   = nsh_get_messages( $rid );
    $tickets    = nsh_get_tickets( $rid );
    $history    = nsh_get_history( $rid );
    $is_staff   = nsh_is_staff();
    $delivery   = $meta['estimated_delivery'];
    $quote      = $meta['quote_amount'];
    $sec        = $meta['secondary_status'] ? $meta['secondary_status'] : 'To be Updated';
    $req_post   = get_post( $rid );
    $author     = $req_post ? get_userdata( $req_post->post_author ) : null;
    $mgr_uid    = $meta['assigned_manager'];
    $mgr        = $mgr_uid ? get_userdata( $mgr_uid ) : null;
    $vnd_uid    = $meta['assigned_vendor'];
    $vnd        = $vnd_uid ? get_userdata( $vnd_uid ) : null;
    $svc        = '';
    if ( ! empty( $meta['service_name'] ) )          { $svc = $meta['service_name']; }
    elseif ( ! empty( $fd['field_service_type'] ) )  { $svc = $fd['field_service_type']; }
    elseif ( ! empty( $fd['field_document_type'] ) ) { $svc = $fd['field_document_type']; }
    else                                              { $svc = 'Document Request'; }
    $mgr_name   = $mgr ? $mgr->display_name  : get_option( 'nsh_manager_name', 'NSH Support' );
    $mgr_email  = $mgr ? $mgr->user_email    : get_option( 'nsh_manager_email', '' );
    $mgr_phone  = $mgr_uid ? get_user_meta( $mgr_uid, 'phone', true ) : get_option( 'nsh_manager_phone', '' );

    $stages     = array( 'submitted' => 'Received', 'under_review' => 'Under Review', 'ready_for_processing' => 'Ready for Processing', 'approved' => 'Approved', 'processing' => 'Processing', 'dispatched' => 'Dispatched', 'completed' => 'Completed', 'service_not_available' => 'Service Not Available' );
    $stage_keys = array_keys( $stages );
    $cur_idx    = array_search( $status, $stage_keys );
    if ( $cur_idx === false ) { $cur_idx = 0; }

    $user_docs  = array(); $prov_docs = array();
    foreach ( $docs as $d ) {
        if ( ! empty( $d['is_provider'] ) ) { $prov_docs[] = $d; } else { $user_docs[] = $d; }
    }

    $cur_uid     = get_current_user_id();
    $all_mgrs    = array_merge( get_users( array( 'role' => 'nsh_manager' ) ), get_users( array( 'role' => 'nsh_admin' ) ), get_users( array( 'role' => 'administrator' ) ) );
    $all_vendors = get_users( array( 'role' => 'nsh_vendor' ) );

    // --- Determine correct back URL ---
    $back_url = $is_staff ? nsh_plat_dash_url( nsh_plat_group() === 'staff' ? 'staff' : 'admin' ) : nsh_client_dashboard_url();
    $back_lbl = $is_staff ? '&larr; All Requests' : '&larr; Dashboard';

    if ( $embedded ) {
        // Inside the admin dashboard SPA: no second nav bar, and the
        // "back" link is a JS hook (nsh-back-to-admin-list) instead of
        // a real navigation — nsh-app.js restores the requests list
        // exactly where the admin left it (same filters/search/page)
        // rather than reloading a fresh one.
        $o  = '<div class="nsh-order-page nsh-order-page-embedded" data-nsh-rid="' . intval( $rid ) . '">';
        $o .= '<div class="nsh-page-breadcrumb"><a href="' . esc_url( $back_url ) . '" class="nsh-back-to-admin-list">' . $back_lbl . '</a></div>';
    } else {
        $o  = nsh_client_shell_open( 'dashboard' );
        $o .= '<div class="nsh-order-page nsh-portal-order-page" data-nsh-rid="' . intval( $rid ) . '">';
        $o .= '<div class="nsh-page-breadcrumb"><a href="' . esc_url( $back_url ) . '">' . $back_lbl . '</a></div>';
    }

    // Order header
    $o .= '<div class="nsh-order-hdr">';
    $o .= '<h1 class="nsh-order-num">Order #' . esc_html( $meta['request_id'] ? $meta['request_id'] : $rid ) . '</h1>';
    $o .= '<div style="display:flex;align-items:center;gap:10px;">';
    $o .= '<span class="nsh-status-chip nsh-status-lg" style="background:' . nsh_status_color( $status ) . '22;color:' . nsh_status_color( $status ) . ';">' . esc_html( nsh_status_label( $status ) ) . '</span>';
    if ( $is_staff ) {
        $o .= '<button class="nsh-btn nsh-btn-danger nsh-btn-sm nsh-delete-request" data-rid="' . intval( $rid ) . '">&#128465; Delete</button>';
    }
    $o .= '</div></div>';

    // Info row
    $o .= '<div class="nsh-info-row">';
    $o .= '<div class="nsh-info-card nsh-info-card-svc"><div class="nsh-svc-thumb">&#128218;</div><div class="nsh-svc-name">' . esc_html( wp_trim_words( $svc, 6, '' ) ) . '</div></div>';
    $o .= '<div class="nsh-info-card"><div class="nsh-info-label">Customer Details</div>';
    if ( $author ) {
        $o .= '<div class="nsh-info-name">' . esc_html( strtoupper( $author->display_name ) ) . '</div>';
        // '__phone' is the Contact Details step's field key in every
        // per-service form; 'field_phone' is kept as a legacy fallback.
        $phone_val = ! empty( $fd['field___phone'] ) ? $fd['field___phone'] : ( ! empty( $fd['field_phone'] ) ? $fd['field_phone'] : '' );
        if ( $phone_val ) {
            $code = isset( $fd['field_phone_code'] ) ? $fd['field_phone_code'] : '+91';
            $o .= '<div class="nsh-info-line">' . esc_html( $code . ' ' . $phone_val ) . '</div>';
        }
        $o .= '<div class="nsh-info-line">' . esc_html( $author->user_email ) . '</div>';
    }
    $o .= '</div>';
    $delivery_loc = isset( $fd['field_delivery_location'] ) ? $fd['field_delivery_location'] : 'NA';
    $o .= '<div class="nsh-info-card"><div class="nsh-info-label">Shipping Address</div><div class="nsh-info-val">' . esc_html( $delivery_loc ) . '</div></div>';
    $o .= '<div class="nsh-info-card nsh-info-card-mgr"><div class="nsh-info-label">Contact Order Manager</div>';
    $o .= '<div class="nsh-info-name">' . esc_html( $mgr_name ) . '</div>';
    if ( $mgr_phone ) { $o .= '<div class="nsh-info-line">Phone: ' . esc_html( $mgr_phone ) . '</div>'; }
    if ( $mgr_email ) { $o .= '<div class="nsh-info-line">Email: ' . esc_html( $mgr_email ) . '</div>'; }
    if ( $vnd )       { $o .= '<div class="nsh-info-line nsh-info-vendor">Vendor: ' . esc_html( $vnd->display_name ) . '</div>'; }
    $o .= '</div></div>';

    // Summary bar
    $o .= '<div class="nsh-summary-bar">';
    
    // v6.2.1: Show service charges and shipping charges separately
    $shipping_charges = isset($meta['shipping_charges']) ? floatval($meta['shipping_charges']) : 0;
    $service_amount = $quote ? floatval($quote) : 0;
    $total_amount = $service_amount + $shipping_charges;
    
    if ($service_amount > 0 || $shipping_charges > 0) {
        $o .= '<div class="nsh-summary-item"><span class="nsh-summary-label">Service Charges :</span><span class="nsh-summary-val">INR ' . number_format($service_amount, 2) . '</span></div>';
        $o .= '<div class="nsh-summary-sep"></div>';
        $o .= '<div class="nsh-summary-item"><span class="nsh-summary-label">Shipping Charges :</span><span class="nsh-summary-val">INR ' . number_format($shipping_charges, 2) . '</span></div>';
        $o .= '<div class="nsh-summary-sep"></div>';
        $o .= '<div class="nsh-summary-item"><span class="nsh-summary-label">Total Amount :</span><span class="nsh-summary-val" style="font-weight:700;">INR ' . number_format($total_amount, 2) . '</span></div>';
    } else {
        $o .= '<div class="nsh-summary-item"><span class="nsh-summary-label">Total Amount :</span><span class="nsh-summary-val">' . ( $quote ? 'INR ' . number_format( (float) $quote, 2 ) : 'To be Updated' ) . '</span></div>';
    }
    
    $o .= '<div class="nsh-summary-sep"></div>';
    $working_days_disp = get_post_meta( $rid, 'timeline_working_days', true );
    $delivery_val = $delivery
        ? esc_html( date( 'd M Y', strtotime( $delivery ) ) ) . ( $working_days_disp ? '<br><small style="color:#94a3b8;font-size:11px;">(' . intval($working_days_disp) . ' working days &mdash; excl. Sat, Sun &amp; Govt Holidays)</small>' : '' )
        : 'To be Updated';
    $o .= '<div class="nsh-summary-item"><span class="nsh-summary-label">Timeline :</span><span class="nsh-summary-val">' . $delivery_val . '</span></div>';
    $o .= '<div class="nsh-summary-sep"></div>';
    $o .= '<div class="nsh-summary-item"><span class="nsh-summary-label">Secondary Status :</span><span class="nsh-summary-val">' . esc_html( $sec ) . '</span></div>';
    $o .= '</div>';

    // Pipeline
    $o .= '<div class="nsh-pipeline-wrap">';
    $is_service_unavailable = ($status === 'service_not_available');
    foreach ( $stage_keys as $i => $key ) {
        // Skip showing "service_not_available" in normal flow
        if ($key === 'service_not_available') continue;
        
        $is_done = ( $i <= $cur_idx ); 
        $is_cur = ( $i === $cur_idx );
        
        // If service not available, fade everything after "Under Review"
        $is_faded = false;
        if ($is_service_unavailable && $key !== 'submitted' && $key !== 'under_review') {
            $is_faded = true;
            $is_done = false;
            $is_cur = false;
        }
        
        $cls = ( $is_done ? ' nsh-done' : '' ) . ( $is_cur ? ' nsh-current' : '' ) . ( $is_faded ? ' nsh-faded' : '' );
        $o .= '<div class="nsh-pipeline-node' . $cls . '"><div class="nsh-pipeline-circle">' . ( ( $is_done && ! $is_cur ) ? '&#10003;' : '' ) . '</div>';
        $o .= '<div class="nsh-pipeline-lbl">' . esc_html( $stages[ $key ] ) . '</div></div>';
        if ( $i < count( $stage_keys ) - 1 ) {
            $bar_done = ($i < $cur_idx && !$is_service_unavailable);
            $o .= '<div class="nsh-pipeline-bar' . ( $bar_done ? ' nsh-done' : '' ) . '"></div>';
        }
    }
    
    // If service not available, show it as a special node
    if ($is_service_unavailable) {
        $o .= '<div class="nsh-pipeline-node nsh-current nsh-service-unavailable"><div class="nsh-pipeline-circle">✗</div>';
        $o .= '<div class="nsh-pipeline-lbl">Service Not Available</div></div>';
    }
    
    $o .= '</div>';

    // Tabs — Communication tab is admin-only
    $o .= '<div class="nsh-order-tabs-wrap"><div class="nsh-order-tabs">';
    $o .= '<button class="nsh-ot active" data-ot="docs">Documents &amp; Order History</button>';
    $o .= '<button class="nsh-ot" data-ot="formdetails">Form Details &amp; Export</button>';
    $o .= '<button class="nsh-ot" data-ot="tickets">Service Request</button>';
    if ( $is_staff ) {
        $o .= '<button class="nsh-ot nsh-ot-comm" data-ot="communication">&#9993; Communication</button>';
    }
    $o .= '</div>';

    // Documents & History tab
    $o .= '<div id="nsh-ot-docs" class="nsh-ot-pane active"><div class="nsh-docs-layout"><div class="nsh-docs-left">';

    foreach ( array( array( 'user', $user_docs, 'User Documents', false ), array( 'provider', $prov_docs, 'Service Provider Documents', true ) ) as $ds ) {
        list( $key, $items, $title, $is_prov ) = $ds;
        $o .= '<div class="nsh-doc-section">';
        $o .= '<button class="nsh-doc-section-btn ' . ( $is_prov ? '' : 'nsh-ds-open' ) . '" data-ds="' . $key . '">' . esc_html( $title ) . ' <span class="nsh-ds-arrow">' . ( $is_prov ? '&#9660;' : '&#9650;' ) . '</span></button>';
        $o .= '<div class="nsh-doc-section-body" id="nsh-ds-' . $key . '" style="' . ( $is_prov ? 'display:none;' : '' ) . '">';
        if ( empty( $items ) ) {
            $o .= '<p class="nsh-hint" style="padding:12px 16px;">No documents yet.</p>';
        } else {
            // Bulk download toolbar
            $o .= '<div class="nsh-doc-bulk-bar" id="nsh-doc-bulk-bar-' . $key . '" style="display:flex;align-items:center;gap:8px;padding:8px 16px;background:#f1f5f9;border-bottom:1px solid #e2e8f0;">';
            $o .= '<label style="display:flex;align-items:center;gap:6px;font-size:13px;color:#475569;cursor:pointer;">';
            $o .= '<input type="checkbox" class="nsh-doc-select-all" data-section="' . $key . '" style="width:15px;height:15px;"> Select All';
            $o .= '</label>';
            $o .= '<button class="nsh-btn nsh-btn-sm nsh-btn-outline nsh-doc-bulk-dl" data-section="' . $key . '" style="display:none;">&#8595; Download Selected</button>';
            $o .= '<button class="nsh-btn nsh-btn-sm nsh-btn-ghost nsh-doc-dl-all" data-rid="' . intval( $rid ) . '" data-section="' . $key . '">&#8595; Download All</button>';
            $o .= '<button type="button" class="nsh-btn nsh-btn-ghost nsh-btn-sm nsh-change-save-folder" title="Documents currently save into a remembered folder. Click to choose a different one for future downloads.">&#128193; Change Folder</button>';
            $o .= '</div>';
            foreach ( $items as $doc ) {
                $att_id  = intval( $doc['file'] );
                $dl_url  = nsh_get_download_url( $att_id );
                $fn      = basename( get_attached_file( $att_id ) );
                // If file is AVIF/WebP, show .png since proxy converts it on download
                $fn_ext_chk = strtolower( pathinfo( $fn, PATHINFO_EXTENSION ) );
                if ( in_array( $fn_ext_chk, array( 'avif', 'webp' ), true ) ) {
                    $fn = pathinfo( $fn, PATHINFO_FILENAME ) . '.png';
                }
                $dname   = isset( $doc['doc_type'] ) ? $doc['doc_type'] : $fn;
                $o .= '<div class="nsh-doc-entry" data-att-id="' . $att_id . '" data-url="' . esc_attr( $dl_url ) . '" data-filename="' . esc_attr( $fn ) . '">';
                $o .= '<label style="display:flex;align-items:center;gap:8px;flex:1;cursor:pointer;min-width:0;">';
                $o .= '<input type="checkbox" class="nsh-doc-chk" data-section="' . $key . '" data-url="' . esc_attr( $dl_url ) . '" data-filename="' . esc_attr( $fn ) . '" style="width:15px;height:15px;flex-shrink:0;">';
                $o .= '<div style="min-width:0;"><div class="nsh-doc-entry-name" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' . esc_html( $dname ) . '</div>';
                $o .= '<div class="nsh-doc-entry-by">By ' . ( $is_prov ? 'System' : 'Client' ) . '</div></div>';
                $o .= '</label>';
                $o .= '<a href="' . esc_url( $dl_url ) . '" class="nsh-dl-btn" title="Download">&#8595;</a>';
                if ( $is_staff ) { $o .= '<button class="nsh-del-doc nsh-btn-icon" data-rid="' . intval( $rid ) . '" data-att="' . $att_id . '" title="Delete">&#128465;</button>'; }
                $o .= '</div>';
            }
        }
        if ( ! $is_prov || $is_staff ) {
            $o .= '<div class="nsh-doc-upload-row"><button class="nsh-btn nsh-btn-sm nsh-btn-outline" onclick="nshShowUpload(\'' . $key . '\',' . intval( $rid ) . ')">+ Upload</button></div>';
        }
        $o .= '</div></div>';
    }

    // Upload area
    $o .= '<div id="nsh-upload-area" style="display:none;padding:16px;"><div class="nsh-field"><label>Document Name</label><input type="text" id="nsh-doc-type" placeholder="e.g. Transcript"></div>';
    $o .= '<div class="nsh-dropzone-sm" id="nsh-upload-drop"><input type="file" id="nsh-doc-file" accept=".pdf,.jpg,.jpeg,.png" style="display:none">';
    $o .= '<p style="font-size:13px;padding:12px;text-align:center;">Drop here or <button type="button" class="nsh-link" onclick="document.getElementById(\'nsh-doc-file\').click()">browse</button></p></div>';
    $o .= '<div id="nsh-upload-progress" style="display:none;margin-top:8px;"><div class="nsh-prog-bar"><div class="nsh-prog-fill" id="nsh-prog-fill"></div></div></div>';
    $o .= '<input type="hidden" id="nsh-upload-rid" value="' . intval( $rid ) . '"><input type="hidden" id="nsh-upload-is-provider" value="0">';
    $o .= '<div style="display:flex;gap:8px;margin-top:10px;"><button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-do-upload">Upload</button>';
    $o .= '<button class="nsh-btn nsh-btn-ghost nsh-btn-sm" onclick="document.getElementById(\'nsh-upload-area\').style.display=\'none\'">Cancel</button></div></div>';

    $o .= '</div>';

    // History / Messages
    // Filter out comm-panel email logs ([Email] prefix) — those belong in Communication Log only
    $display_messages = array_filter( $messages, function( $m ) {
        return strpos( $m->message, '[Email] ' ) !== 0;
    });

    $o .= '<div class="nsh-docs-right">';
    $o .= '<div class="nsh-order-history-hdr" style="display:flex;justify-content:space-between;align-items:center;">&#128172; Messages<button type="button" id="nsh-refresh-msgs" data-rid="' . intval( $rid ) . '" style="font-size:11px;padding:3px 10px;background:none;border:1px solid #e2e8f0;border-radius:4px;cursor:pointer;color:#64748b;">&#8635; Refresh</button></div>';
    $o .= '<div class="nsh-messages-list" id="nsh-msgs-list">';
    if ( empty( $display_messages ) ) {
        $o .= '<p class="nsh-hint" style="text-align:center;padding:20px;color:#94a3b8;">No messages yet. Send a message below.</p>';
    } else {
        foreach ( $display_messages as $m ) {
            $is_mine     = ( (int) $m->sender_id === $cur_uid );
            $sender_is_staff_msg = ( ! empty( $m->user_email ) )
                ? user_can( (int) $m->sender_id, 'administrator' )
                  || user_can( (int) $m->sender_id, 'nsh_admin' )
                  || user_can( (int) $m->sender_id, 'nsh_manager' )
                : false;

            // Label: "You" for own messages, "Support Team" for admin messages on client view,
            // client name for admin viewing client messages
            if ( $is_mine ) {
                $label = 'You';
            } elseif ( $sender_is_staff_msg ) {
                $label = $is_staff ? esc_html( $m->display_name ) . ' (Admin)' : 'Support Team';
            } else {
                $label = $is_staff ? esc_html( $m->display_name ) . ' (Client)' : esc_html( $m->display_name );
            }

            $time_fmt = wp_date( 'd M, g:i a', strtotime( $m->created_at ) );
            $o .= '<div class="nsh-msg-item ' . ( $is_mine ? 'nsh-msg-mine' : '' ) . '" id="nrimsg-' . intval( $m->id ) . '" data-mid="' . intval( $m->id ) . '">';
            $o .= '<div class="nsh-msg-meta-top">';
            $o .= '<span style="font-weight:600;color:' . ( $is_mine ? 'inherit' : '#475569' ) . ';">' . $label . '</span>';
            $o .= '<span style="color:#94a3b8;font-size:11px;margin-left:6px;">' . esc_html( $time_fmt ) . '</span>';
            if ( $m->is_email_sent ) {
                $o .= ' <span class="nsh-email-sent-badge" title="Email notification sent">&#9993; Sent</span>';
            }
            if ( $is_staff ) {
                $o .= ' <button class="nsh-del-msg nsh-btn-icon" data-id="' . intval( $m->id ) . '" title="Delete message">&#128465;</button>';
            }
            $o .= '</div>';
            $o .= '<div class="nsh-msg-bubble">' . nl2br( esc_html( $m->message ) ) . '</div>';
            $o .= '</div>';
        }
    }
    $o .= '</div>';

    // Compose area
    $o .= '<div class="nsh-msg-input-area">';
    $o .= '<textarea id="nsh-msg-text" placeholder="Type your message here..." rows="3"></textarea>';
    $o .= '<input type="hidden" id="nsh-msg-rid" value="' . intval( $rid ) . '">';
    $o .= '<div class="nsh-msg-actions">';
    $o .= '<button id="nsh-send-msg" class="nsh-btn nsh-btn-primary nsh-btn-sm">Send</button>';
    $o .= '<button id="nsh-send-msg-email" class="nsh-btn nsh-btn-outline nsh-btn-sm">&#9993; Send via Email</button>';
    $o .= '</div>';
    $o .= '<p class="nsh-hint-sm" style="color:#94a3b8;margin-top:4px;">Send = saved to this chat. Send via Email = saved here + also sends an email notification.</p>';
    $o .= '</div>';
    $o .= '</div></div></div>';

    // Form Details & Export tab
    $o .= nsh_render_form_details_pane( $rid, $fd, $docs, $is_staff, $meta );

    // Tickets tab
    $o .= '<div id="nsh-ot-tickets" class="nsh-ot-pane" style="display:none;">';
    $o .= '<div class="nsh-tickets-toolbar"><input type="text" id="nsh-ticket-search" placeholder="Search..." class="nsh-search-input">';
    $o .= '<button id="nsh-new-ticket-btn" class="nsh-btn nsh-btn-primary nsh-btn-sm" data-rid="' . intval( $rid ) . '">&#8853; Other Service Request</button></div>';
    $o .= '<table class="nsh-tbl" id="nsh-tickets-tbl"><thead><tr><th>Ticket ID</th><th>Category</th><th>Status</th><th>Date Created</th><th>Last Updated</th>';
    if ( $is_staff ) { $o .= '<th>Action</th>'; }
    $o .= '</tr></thead><tbody>';
    if ( empty( $tickets ) ) {
        $o .= '<tr><td colspan="' . ( $is_staff ? 6 : 5 ) . '" class="nsh-tbl-empty">No service requests yet.</td></tr>';
    } else {
        foreach ( $tickets as $tk ) {
            $o .= '<tr class="nsh-ticket-row" data-ticket-id="' . intval( $tk->id ) . '">';
            $o .= '<td><strong>#T-' . str_pad( $tk->id, 4, '0', STR_PAD_LEFT ) . '</strong></td>';
            $o .= '<td>' . esc_html( $tk->category ) . '</td>';
            $o .= '<td><span class="nsh-ticket-status-chip nsh-ts-' . esc_attr( $tk->status ) . '">' . esc_html( ucfirst( $tk->status ) ) . '</span></td>';
            $o .= '<td>' . esc_html( wp_date( 'd M Y', strtotime( $tk->created_at ) ) ) . '</td>';
            $o .= '<td>' . esc_html( wp_date( 'd M Y', strtotime( $tk->updated_at ) ) ) . '</td>';
            if ( $is_staff ) {
                $o .= '<td><select class="nsh-ticket-status-sel" data-id="' . intval( $tk->id ) . '" style="font-size:12px;padding:4px;">';
                foreach ( array( 'open', 'in_progress', 'resolved', 'closed' ) as $ts ) {
                    $o .= '<option value="' . $ts . '" ' . ( $tk->status === $ts ? 'selected' : '' ) . '>' . esc_html( ucfirst( str_replace( '_', ' ', $ts ) ) ) . '</option>';
                }
                $o .= '</select><button class="nsh-btn nsh-btn-sm nsh-btn-danger nsh-del-ticket" data-id="' . intval( $tk->id ) . '" style="margin-left:6px;">Del</button></td>';
            }
            $o .= '</tr>';
        }
    }
    $o .= '</tbody></table></div></div>';

    // Communication panel — admin-only (compose + quick replies + history)
    if ( $is_staff ) {
        $comm_recipient_name  = $author ? $author->display_name : 'Client';
        $comm_recipient_email = $author ? $author->user_email   : '';
        $comm_quick_replies   = nsh_get_quick_replies();
        // Load all available email templates (built-in + any custom ones)
        $comm_all_templates = function_exists( 'nsh_get_all_template_types' )
            ? nsh_get_all_template_types()
            : array(
                'quotation'            => 'Quotation Email',
                'application_received' => 'Application Received',
                'status_update'        => 'Status Update',
                'document_reminder'    => 'Document Reminder',
                'completion'           => 'Completion',
                'dispatch'             => 'Dispatch',
                'terms_conditions'     => 'Terms & Conditions',
                'general'              => 'General Message',
            );

        $o .= '<div id="nsh-ot-communication" class="nsh-ot-pane" style="display:none;">';
        $o .= '<div class="nsh-comm-panel">';

        // Recipient card
        $o .= '<div class="nsh-comm-recipient-card">';
        $o .= '<div class="nsh-comm-recipient-icon">&#128100;</div>';
        $o .= '<div class="nsh-comm-recipient-info">';
        $o .= '<div class="nsh-comm-recipient-label">Sending to</div>';
        $o .= '<div class="nsh-comm-recipient-name">' . esc_html( strtoupper( $comm_recipient_name ) ) . '</div>';
        $o .= '<div class="nsh-comm-recipient-email">&#9993; ' . esc_html( $comm_recipient_email ) . '</div>';
        $comm_phone_val = ! empty( $fd['field___phone'] ) ? $fd['field___phone'] : ( ! empty( $fd['field_phone'] ) ? $fd['field_phone'] : '' );
        if ( $comm_phone_val ) {
            $code = isset( $fd['field_phone_code'] ) ? $fd['field_phone_code'] : '+91';
            $o .= '<div class="nsh-comm-recipient-phone">&#128222; ' . esc_html( $code . ' ' . $comm_phone_val ) . '</div>';
        }
        $o .= '</div>';
        $o .= '<div class="nsh-comm-req-badge">Order #' . esc_html( $meta['request_id'] ? $meta['request_id'] : $rid ) . '</div>';
        $o .= '</div>';

        // Compose section
        $o .= '<div class="nsh-comm-compose">';
        $o .= '<div class="nsh-comm-compose-hdr"><span class="nsh-comm-compose-title">&#9993; Compose Email</span></div>';
        $o .= '<div class="nsh-comm-toolbar">';

        // All templates dropdown
        $o .= '<div class="nsh-comm-toolbar-group">';
        $o .= '<label class="nsh-comm-toolbar-label">Email Template</label>';
        $o .= '<div style="display:flex;gap:8px;align-items:center;">';
        $o .= '<select id="nsh-comm-template-sel" class="nsh-comm-select">';
        $o .= '<option value="">-- Select Template --</option>';
        foreach ( $comm_all_templates as $tkey => $tlabel ) {
            $clean = trim( preg_replace( '/[\x{1F300}-\x{1F9FF}\x{2600}-\x{26FF}]/u', '', $tlabel ) );
            $o .= '<option value="' . esc_attr( $tkey ) . '">' . esc_html( $clean ) . '</option>';
        }
        $o .= '</select>';
        $o .= '<button class="nsh-btn nsh-btn-outline nsh-btn-sm" id="nsh-comm-load-template">Load</button>';
        $o .= '</div></div>';

        // Quick Replies
        if ( ! empty( $comm_quick_replies ) ) {
            $o .= '<div class="nsh-comm-toolbar-group nsh-comm-qr-group">';
            $o .= '<label class="nsh-comm-toolbar-label">Quick Replies</label>';
            $o .= '<div class="nsh-comm-quick-btns">';
            foreach ( $comm_quick_replies as $qr ) {
                $o .= '<button class="nsh-comm-quick-btn" data-content="' . esc_attr( $qr['content'] ) . '" title="' . esc_attr( $qr['title'] ) . '">' . esc_html( $qr['title'] ) . '</button>';
            }
            $o .= '</div></div>';
        } else {
            $qr_url = esc_url( add_query_arg( array( 'tab' => 'settings', 'section' => 'quick_replies' ), nsh_admin_dashboard_url() ) );
            $o .= '<div class="nsh-comm-toolbar-group" style="font-size:12px;color:#94a3b8;padding:4px 0;">';
            $o .= 'No quick replies yet. <a href="' . $qr_url . '" target="_blank" style="color:#3b82f6;">Add in Settings &#8599;</a>';
            $o .= '</div>';
        }
        $o .= '</div>'; // end toolbar

        $o .= '<div class="nsh-comm-field"><label class="nsh-comm-field-label">Subject</label>';
        $o .= '<input type="text" id="nsh-comm-subject" class="nsh-comm-input" placeholder="Email subject..." value="Update on Your Request - Order #' . esc_attr( $meta['request_id'] ? $meta['request_id'] : $rid ) . '"></div>';

        $o .= '<div class="nsh-comm-field"><label class="nsh-comm-field-label">Message</label>';
        $o .= '<textarea id="nsh-comm-body" class="nsh-comm-textarea" rows="10" placeholder="Type your email message here..."></textarea></div>';

        $o .= '<div class="nsh-comm-actions">';
        $o .= '<input type="hidden" id="nsh-comm-rid" value="' . intval( $rid ) . '">';
        $o .= '<input type="hidden" id="nsh-comm-to-email" value="' . esc_attr( $comm_recipient_email ) . '">';
        $o .= '<input type="hidden" id="nsh-comm-to-name" value="' . esc_attr( $comm_recipient_name ) . '">';
        $o .= '<button class="nsh-btn nsh-btn-primary" id="nsh-comm-send-email">&#9993; Send Email</button>';
        $o .= '<button class="nsh-btn nsh-btn-outline" id="nsh-comm-send-and-log">&#9993; Send &amp; Log to History</button>';
        $o .= '</div>';
        $o .= '<div id="nsh-comm-status" class="nsh-comm-status-msg" style="display:none;"></div>';
        $o .= '</div>'; // end compose

        // Communication history — full subject + body, collapsible
        $emailed_msgs = array_filter( $messages, function($m) { return $m->is_email_sent; } );
        $o .= '<div class="nsh-comm-history">';
        $o .= '<div class="nsh-comm-history-hdr">&#128203; Communication Log <span class="nsh-comm-log-count">' . count( $emailed_msgs ) . ' email(s) sent</span></div>';
        $o .= '<div class="nsh-comm-history-list">';
        if ( empty( $emailed_msgs ) ) {
            $o .= '<p class="nsh-hint" style="text-align:center;padding:20px 0;">No emails sent yet for this request.</p>';
        } else {
            foreach ( array_reverse( array_values( $emailed_msgs ) ) as $m ) {
                // Messages are stored as "[Email] Subject\n\nBody" — parse back out
                $raw   = $m->message;
                $email_subject = '';
                $email_body    = $raw;
                if ( strpos( $raw, '[Email] ' ) === 0 ) {
                    $without_prefix = substr( $raw, 8 );
                    $sep_pos        = strpos( $without_prefix, "\n\n" );
                    if ( $sep_pos !== false ) {
                        $email_subject = trim( substr( $without_prefix, 0, $sep_pos ) );
                        $email_body    = trim( substr( $without_prefix, $sep_pos + 2 ) );
                    } else {
                        $email_subject = trim( $without_prefix );
                        $email_body    = '';
                    }
                }
                $uid_log = 'nricl-' . intval( $m->id );
                $o .= '<div class="nsh-comm-log-item" style="border:1px solid #e2e8f0;border-radius:8px;margin-bottom:12px;overflow:hidden;">';
                // Header row — always visible, click to expand
                $o .= '<div class="nsh-comm-log-hdr" style="display:flex;justify-content:space-between;align-items:flex-start;padding:12px 16px;background:#f8fafc;cursor:pointer;" onclick="nshToggleCommLog(\'' . $uid_log . '\')">';
                $o .= '<div style="flex:1;min-width:0;">';
                $o .= '<div style="display:flex;align-items:center;gap:8px;">';
                $o .= '<span style="font-size:16px;">&#9993;</span>';
                $o .= '<span style="font-size:13px;color:#64748b;">Sent by <strong style="color:#1e293b;">' . esc_html( $m->display_name ) . '</strong> &mdash; ' . esc_html( wp_date( 'd M Y, g:i a', strtotime( $m->created_at ) ) ) . '</span>';
                $o .= '</div>';
                if ( $email_subject ) {
                    $o .= '<div style="margin-top:6px;padding-left:26px;font-size:13px;color:#374151;"><strong>Subject:</strong> ' . esc_html( $email_subject ) . '</div>';
                }
                $o .= '</div>';
                $o .= '<span style="font-size:11px;color:#94a3b8;white-space:nowrap;padding-left:12px;" id="' . $uid_log . '-arrow">&#9660; View</span>';
                $o .= '</div>';
                // Body — collapsible
                $o .= '<div id="' . $uid_log . '" class="nsh-comm-log-body-wrap" style="display:none;padding:16px;border-top:1px solid #e2e8f0;background:#fff;">';
                if ( $email_subject ) {
                    $o .= '<div style="margin-bottom:12px;padding:8px 12px;background:#eff6ff;border-radius:6px;font-size:13px;font-weight:600;color:#1e40af;">' . esc_html( $email_subject ) . '</div>';
                }
                if ( $email_body ) {
                    $o .= '<div style="font-size:14px;line-height:1.8;color:#374151;white-space:pre-wrap;border:1px solid #e2e8f0;border-radius:6px;padding:12px;background:#fafafa;">' . esc_html( $email_body ) . '</div>';
                } else {
                    $o .= '<p style="font-size:13px;color:#94a3b8;margin:0;">No body content stored for this email.</p>';
                }
                $o .= '</div>';
                $o .= '</div>'; // end log item
            }
        }
        $o .= '</div></div>'; // end history-list + history
        $o .= '</div></div>'; // end comm-panel + ot-pane

    } // end if ( $is_staff ) for comm panel
    // ── END COMMUNICATION PANEL ─────────────────────────────────────────────


    if ( $is_staff ) { $o .= nsh_render_staff_panel( $rid, $meta, $status, $all_mgrs, $all_vendors, $mgr_uid, $vnd_uid ); }

    // Ticket modal
    $o .= '<div id="nsh-ticket-modal" style="display:none;position:fixed;inset:0;z-index:99999;align-items:center;justify-content:center;background:rgba(0,0,0,.5);">';
    $o .= '<div class="nsh-modal-box"><div class="nsh-modal-hdr"><h3>Other Service Request</h3><button class="nsh-modal-x" id="nsh-ticket-modal-close">&#10005;</button></div>';
    $o .= '<div class="nsh-modal-body"><div class="nsh-field"><label>Category Name</label>';
    $o .= '<select id="nsh-ticket-cat" class="nsh-modal-select"><option value="">-- Select --</option></select></div>';
    if ( ! is_user_logged_in() ) { $o .= '<div class="nsh-field"><label>Email <span class="nsh-req">*</span></label><input type="email" id="nsh-ticket-email" placeholder="your@email.com" required></div>'; }
    $o .= '<div class="nsh-field"><label>Notes</label><textarea id="nsh-ticket-notes" rows="3" placeholder="Describe your request..."></textarea></div>';
    $o .= '<div id="nsh-ticket-err" class="nsh-alert nsh-alert-error" style="display:none;"></div>';
    $o .= '<button id="nsh-do-ticket" class="nsh-btn nsh-btn-primary nsh-w100" data-rid="' . intval( $rid ) . '">Submit</button></div></div></div>';

    $o .= '</div>';
    if ( ! $embedded ) { $o .= nsh_client_shell_close(); }
    return $o;
}

function nsh_render_staff_panel( $rid, $meta, $status, $all_mgrs, $all_vendors, $mgr_uid, $vnd_uid ) {
    $statuses = array( 'submitted' => 'Received', 'under_review' => 'Under Review', 'ready_for_processing' => 'Ready for Processing', 'approved' => 'Approved', 'processing' => 'Processing', 'dispatched' => 'Dispatched', 'completed' => 'Completed', 'service_not_available' => 'Service Not Available', 'rejected' => 'Cancelled' );
    $o  = '<div class="nsh-staff-panel-wrap"><div class="nsh-staff-panel-hdr" id="nsh-staff-toggle">&#9881; Staff Controls <span>&#9660;</span></div>';
    $o .= '<div class="nsh-staff-panel-body" id="nsh-staff-body"><div class="nsh-staff-grid">';
    $o .= '<div class="nsh-staff-section"><div class="nsh-staff-label">Update Status</div>';
    $o .= '<select id="nsh-status-sel" style="width:100%;margin-bottom:8px;padding:8px;border:1px solid #e2e8f0;border-radius:6px;">';
    foreach ( $statuses as $sv => $sl ) { $o .= '<option value="' . $sv . '" ' . ( $status === $sv ? 'selected' : '' ) . '>' . esc_html( $sl ) . '</option>'; }
    $o .= '</select><input type="text" id="nsh-status-note" placeholder="Note (optional)" style="width:100%;margin-bottom:8px;padding:8px;border:1px solid #e2e8f0;border-radius:6px;box-sizing:border-box;">';
    $o .= '<button class="nsh-btn nsh-btn-outline nsh-btn-sm nsh-w100" id="nsh-do-status" data-rid="' . intval( $rid ) . '">Update Status</button></div>';
    $o .= '<div class="nsh-staff-section"><div class="nsh-staff-label">Set Delivery Date</div>';
    $o .= '<div class="nsh-tl-toggle"><button class="nsh-tlt active" data-tl="days">By Days</button><button class="nsh-tlt" data-tl="date">Fixed Date</button></div>';
    $o .= '<div id="nsh-tl-days-wrap" style="display:flex;gap:8px;align-items:center;margin:8px 0;"><input type="number" id="nsh-tl-days" placeholder="30" min="1" style="width:80px;padding:8px;border:1px solid #e2e8f0;border-radius:6px;"><span style="font-size:13px;color:#64748b;"><strong>Working Days</strong><br><small style="color:#94a3b8;">(Excludes Sat, Sun, and Govt Holidays)</small></span></div>';
    $o .= '<div id="nsh-tl-date-wrap" style="display:none;margin:8px 0;"><input type="date" id="nsh-tl-date" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;box-sizing:border-box;"></div>';
    $o .= '<input type="text" id="nsh-tl-note" placeholder="Note (optional)" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;box-sizing:border-box;margin-bottom:8px;">';
    $o .= '<button class="nsh-btn nsh-btn-primary nsh-btn-sm nsh-w100" id="nsh-do-timeline" data-rid="' . intval( $rid ) . '">Set Timeline</button></div>';
    // ── Quote & Shipping section ─────────────────────────────────────────────
    $shipping_charges = isset($meta['shipping_charges']) ? floatval($meta['shipping_charges']) : 0;
    $shipping_type    = isset($meta['shipping_type'])    ? $meta['shipping_type'] : 'domestic';
    $service_amount   = floatval($meta['quote_amount']);
    $total_amount     = $service_amount + $shipping_charges;

    $o .= '<div class="nsh-staff-section">';
    $o .= '<div class="nsh-staff-label">💰 Quotation</div>';

    // Service charge row
    $o .= '<div style="margin-bottom:8px;">';
    $o .= '<label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Service Charges (INR)</label>';
    $o .= '<div style="display:flex;gap:6px;">';
    $o .= '<input type="number" id="nsh-quote-amt" placeholder="0.00" min="0" step="0.01" value="' . esc_attr( $service_amount ?: '' ) . '" style="flex:1;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">';
    $o .= '<button class="nsh-btn nsh-btn-outline nsh-btn-sm" id="nsh-do-quote" data-rid="' . intval( $rid ) . '" style="white-space:nowrap;">Save</button>';
    $o .= '</div></div>';

    // Shipping charge row
    $o .= '<div style="margin-bottom:12px;">';
    $o .= '<label style="font-size:12px;color:#64748b;display:block;margin-bottom:4px;">Shipping Charges (INR)</label>';
    $o .= '<div style="display:flex;gap:6px;">';
    $o .= '<input type="number" id="nsh-shipping-amt" placeholder="0.00" min="0" step="0.01" value="' . esc_attr( $shipping_charges ?: '' ) . '" style="flex:1;padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;">';
    $o .= '<select id="nsh-shipping-type" style="padding:8px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;">';
    $o .= '<option value="domestic"      ' . ($shipping_type === 'domestic'      ? 'selected' : '') . '>Domestic</option>';
    $o .= '<option value="international" ' . ($shipping_type === 'international' ? 'selected' : '') . '>International</option>';
    $o .= '</select>';
    $o .= '<button class="nsh-btn nsh-btn-outline nsh-btn-sm" id="nsh-do-shipping" data-rid="' . intval( $rid ) . '" style="white-space:nowrap;">Save</button>';
    $o .= '</div></div>';

    // Live total display
    $o .= '<div id="nsh-quote-total-box" style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:10px 14px;margin-bottom:14px;' . ($total_amount <= 0 ? 'display:none;' : '') . '">';
    $o .= '<div style="font-size:11px;color:#16a34a;font-weight:600;text-transform:uppercase;letter-spacing:.05em;margin-bottom:2px;">Total Amount</div>';
    $o .= '<div id="nsh-quote-total-val" style="font-size:20px;font-weight:700;color:#15803d;">₹' . number_format( $total_amount, 2 ) . '</div>';
    $o .= '<div id="nsh-quote-total-breakdown" style="font-size:11px;color:#4ade80;margin-top:2px;">Service ₹' . number_format($service_amount,2) . ' + Shipping ₹' . number_format($shipping_charges,2) . '</div>';
    $o .= '</div>';

    // Send quote email section
    $o .= '<div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:12px 14px;margin-bottom:6px;">';
    $o .= '<div style="font-size:12px;font-weight:600;color:#1e40af;margin-bottom:8px;">📧 Send Quotation Email</div>';
    $o .= '<label style="display:flex;align-items:center;gap:8px;font-size:13px;color:#374151;cursor:pointer;margin-bottom:6px;">';
    $o .= '<input type="checkbox" id="nsh-include-terms" style="width:14px;height:14px;"> Include Terms &amp; Conditions</label>';
    $o .= '<button class="nsh-btn nsh-btn-primary nsh-btn-sm nsh-w100" id="nsh-send-quote-btn" data-rid="' . intval($rid) . '">📧 Send Quotation Email to Client</button>';
    $o .= '<div id="nsh-quote-email-msg" style="margin-top:8px;font-size:12px;display:none;"></div>';
    $o .= '</div>';
    $o .= '<div class="nsh-staff-label">Secondary Status</div><div style="display:flex;gap:8px;"><input type="text" id="nsh-sec-status" placeholder="e.g. Documents pending" value="' . esc_attr( $meta['secondary_status'] ) . '" style="flex:1;padding:8px;border:1px solid #e2e8f0;border-radius:6px;"><button class="nsh-btn nsh-btn-outline nsh-btn-sm" id="nsh-do-sec-status" data-rid="' . intval( $rid ) . '">Set</button></div></div>';
    $o .= '<div class="nsh-staff-section"><div class="nsh-staff-label">Quick Email Actions</div><div style="display:flex;flex-direction:column;gap:8px;"><button class="nsh-btn nsh-btn-outline nsh-btn-sm nsh-w100" id="nsh-send-doc-reminder" data-rid="' . intval( $rid ) . '">&#128229; Send Document Reminder Email</button><button class="nsh-btn nsh-btn-outline nsh-btn-sm nsh-w100" id="nsh-send-status-email" data-rid="' . intval( $rid ) . '">&#9993; Send Status Update Email</button></div></div>';
    $o .= '<div class="nsh-staff-section"><div class="nsh-staff-label">Assign Manager</div>';
    $o .= '<div style="display:flex;gap:8px;margin-bottom:12px;"><select id="nsh-assign-mgr" data-rid="' . intval( $rid ) . '" style="flex:1;padding:8px;border:1px solid #e2e8f0;border-radius:6px;"><option value="">- Select Manager -</option>';
    foreach ( $all_mgrs as $m ) { $o .= '<option value="' . intval( $m->ID ) . '" ' . ( (int) $mgr_uid === $m->ID ? 'selected' : '' ) . '>' . esc_html( $m->display_name ) . '</option>'; }
    $o .= '</select><button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-do-assign-mgr" data-rid="' . intval( $rid ) . '">Save Manager</button></div>';
    $mgr = $mgr_uid ? get_userdata( (int) $mgr_uid ) : null;
    $current_mgr_name = $mgr ? $mgr->display_name : '-';
    $o .= '<div id="nsh-mgr-current" style="font-size:12px;color:#64748b;margin-bottom:8px;">Currently assigned: <strong>' . esc_html($current_mgr_name) . '</strong></div>';

    // Vendor dropdown from nsh_vendors table (preferred) + WP users fallback
    $o .= '<div class="nsh-staff-label">Assign Vendor</div>';
    // Get current vendor info for display
    global $wpdb;
    $vendor_profiles = $wpdb->get_results("SELECT id, name, phone, whatsapp FROM {$wpdb->prefix}nsh_vendors WHERE status='active' ORDER BY name ASC");
    $current_vendor_id   = $meta['assigned_vendor'];
    $current_vendor_name = '-';
    if ($current_vendor_id) {
        $cv = $wpdb->get_row($wpdb->prepare("SELECT name FROM {$wpdb->prefix}nsh_vendors WHERE id=%d", $current_vendor_id));
        if ($cv) $current_vendor_name = $cv->name;
        elseif ($vnd) $current_vendor_name = $vnd->display_name;
    }
    $o .= '<div style="display:flex;gap:8px;margin-bottom:6px;">';
    $o .= '<select id="nsh-assign-vendor" data-rid="' . intval( $rid ) . '" style="flex:1;padding:8px;border:1px solid #e2e8f0;border-radius:6px;">';
    $o .= '<option value="">- Select Vendor -</option>';
    if (!empty($vendor_profiles)) {
        foreach ($vendor_profiles as $vp) {
            $sel = ((string)$current_vendor_id === (string)$vp->id) ? 'selected' : '';
            $o .= '<option value="vp_' . intval($vp->id) . '" ' . $sel . '>' . esc_html($vp->name) . ($vp->phone ? ' - '.$vp->phone : '') . '</option>';
        }
    }
    // Also show WP users with vendor role as fallback
    foreach ( $all_vendors as $v ) {
        $sel = ((int)$current_vendor_id === $v->ID && !preg_match('/^vp_/', (string)$current_vendor_id)) ? 'selected' : '';
        $o .= '<option value="wp_' . intval( $v->ID ) . '" ' . $sel . '>' . esc_html( $v->display_name ) . ' (WP)</option>';
    }
    $o .= '</select>';
    $o .= '<button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-do-assign-vendor" data-rid="' . intval( $rid ) . '">Save Vendor</button></div>';
    $o .= '<div id="nsh-vendor-current" style="font-size:12px;color:#64748b;margin-bottom:4px;">Currently assigned: <strong>' . esc_html($current_vendor_name) . '</strong></div>';
    // Show WA number if available
    if ($current_vendor_id) {
        $cv_full = $wpdb->get_row($wpdb->prepare("SELECT whatsapp, phone FROM {$wpdb->prefix}nsh_vendors WHERE id=%d", $current_vendor_id));
        if ($cv_full && $cv_full->whatsapp) {
            $o .= '<div style="font-size:11px;color:#25d366;margin-bottom:8px;"> WA: ' . esc_html($cv_full->whatsapp) . '</div>';
        }
    }
    $o .= '<div id="nsh-assign-msg" style="font-size:12px;padding:4px 8px;border-radius:4px;display:none;margin-top:4px;"></div></div>';
    $o .= '<div class="nsh-staff-section nsh-staff-section-wide"><div class="nsh-staff-label">Internal Notes (not visible to client)</div>';
    $o .= '<textarea id="nsh-int-notes" rows="3" data-rid="' . intval( $rid ) . '" style="width:100%;padding:8px;border:1px solid #e2e8f0;border-radius:6px;box-sizing:border-box;">' . esc_textarea( $meta['internal_notes'] ) . '</textarea>';
    $o .= '<button class="nsh-btn nsh-btn-ghost nsh-btn-sm" id="nsh-do-save-note" data-rid="' . intval( $rid ) . '" style="margin-top:6px;">Save Note</button></div>';
    $o .= '</div></div></div>';
    return $o;
}

/* ============================================================
   SHORTCODE: ADMIN DASHBOARD
   ============================================================ */

add_shortcode( 'nsh_admin_dashboard', 'nsh_sc_admin_dashboard' );
// TRACE: /admin-dashboard/ and /staff-dashboard/ routes (and the legacy [nsh_admin_dashboard] shortcode) → atts[surface] admin|staff, atts[rid] → the staff application: header, tab nav limited to what this group may open, the active tab (or one request's detail), Blog link when the account may use it
//        pre: caller is a signed-in staff/admin account (route gate) → post: markup keeps #nsh-admin-tab-container + .nsh-nav-item[data-tab] that nsh-app.js drives → edge: tab not allowed for the group falls back to Requests; rid shows that request's detail in place of the tab
function nsh_sc_admin_dashboard( $atts ) {
    $atts    = is_array( $atts ) ? $atts : array();
    $surface = isset( $atts['surface'] ) && $atts['surface'] === 'staff' ? 'staff' : ( nsh_plat_group() === 'staff' ? 'staff' : 'admin' );
    $rid     = isset( $atts['rid'] ) ? absint( $atts['rid'] ) : 0;
    if ( ! nsh_is_staff() ) {
        if ( $surface === 'staff' && function_exists( 'nsh_plat_blog_enabled_for' ) && nsh_plat_blog_enabled_for( get_current_user_id() ) ) {
            return '<div class="nsh-admin-wrap"><div class="nsh-admin-hdr"><div><h2>Staff Dashboard</h2><p>Welcome, ' . esc_html( wp_get_current_user()->display_name ) . '</p></div><div><a href="' . esc_url( nsh_logout_url() ) . '" class="nsh-btn nsh-btn-ghost nsh-btn-sm">Sign out</a></div></div><div class="nsh-msg-card"><p><a class="nsh-btn nsh-btn-primary" href="' . esc_url( nsh_plat_dash_url( 'staff', nsh_plat_get( 'blog_slug' ) . '/' ) ) . '">Open the Blog</a></p></div></div>';
        }
        return '<div class="nsh-msg-card nsh-text-center"><p>Access denied. <a href="' . esc_url( nsh_login_page_url() ) . '">Sign in</a> with a staff account.</p></div>';
    }
    $user  = wp_get_current_user();
    $tabs  = nsh_plat_tabs_for( $surface );
    $tab   = sanitize_text_field( isset( $_GET['tab'] ) ? wp_unslash( $_GET['tab'] ) : 'requests' );
    if ( ! isset( $tabs[ $tab ] ) ) { $tab = 'requests'; }
    $base  = nsh_plat_dash_url( $surface );
    $o    = '<div class="nsh-admin-wrap"><div class="nsh-admin-hdr"><div><h2>' . ( $surface === 'staff' ? 'Staff Dashboard' : 'Admin Dashboard' ) . '</h2><p>Welcome, ' . esc_html( $user->display_name ) . '</p></div>';
    $o   .= '<div><a href="' . esc_url( nsh_logout_url() ) . '" class="nsh-btn nsh-btn-ghost nsh-btn-sm">Sign out</a></div></div>';
    $o   .= '<nav class="nsh-admin-nav" aria-label="Dashboard sections">';
    foreach ( $tabs as $key => $label ) {
        $href = $key !== 'requests' ? add_query_arg( 'tab', $key, $base ) : $base;
        // Real href kept as a fallback (no-JS, open-in-new-tab, bookmarking);
        // nsh-app.js intercepts the click to swap tabs via AJAX instead of a
        // full page reload, using data-tab as the lookup key.
        $o   .= '<a class="nsh-nav-item ' . ( $tab === $key && ! $rid ? 'active' : '' ) . '" href="' . esc_url( $href ) . '" data-tab="' . esc_attr( $key ) . '">' . esc_html( $label ) . '</a>';
    }
    if ( function_exists( 'nsh_plat_blog_enabled_for' ) && nsh_plat_blog_enabled_for( get_current_user_id() ) ) {
        $o .= '<a class="nsh-nav-ext" href="' . esc_url( nsh_plat_dash_url( $surface, nsh_plat_get( 'blog_slug' ) . '/' ) ) . '">Blog</a>';
    }
    $o .= '</nav>';
    $o .= '<div id="nsh-admin-tab-container" data-current-tab="' . esc_attr( $tab ) . '">';
    // This whole branch renders as the shortcode's direct return value —
    // i.e. page CONTENT, subject to the_content's filter chain (which can
    // include wp_kses_post()-style sanitization depending on the viewing
    // user/theme/page-builder) — unlike the AJAX tab-swap path
    // (nsh_ajax_admin_load_tab() in ajax.php), which calls these same
    // functions but sends the HTML back as JSON, never touching content
    // filters. So every tab function that carries its own inline <script>
    // gets told to route it through wp_add_inline_script() instead (see
    // nsh_output_admin_script()'s docblock in enqueue.php) — $echo_inline=false.
    if ( $rid && get_post_type( $rid ) === 'nsh_request' ) { $o .= nsh_render_request_view( $rid, true ); }
    elseif  ( $tab === 'requests' )    { $o .= nsh_admin_tab_requests(); }
    elseif  ( $tab === 'submissions' ) { $o .= nsh_admin_tab_submissions( false ); }
    elseif  ( $tab === 'support' )     { $o .= nsh_admin_tab_support(); }
    elseif  ( $tab === 'fields' )      { $o .= nsh_admin_tab_fields( false ); }
    elseif  ( $tab === 'dropdowns' )   { $o .= nsh_admin_tab_dropdowns(); }
    elseif  ( $tab === 'bulk' )        { $o .= nsh_admin_tab_bulk(); }
    elseif  ( $tab === 'types' )       { $o .= nsh_admin_tab_types(); }
    elseif  ( $tab === 'settings' )    { $o .= nsh_admin_tab_settings( false ); }
    $o .= '</div>';
    $o .= nsh_admin_js();
    // Independent safety net — see nsh_output_admin_requests_watchdog()'s
    // docblock in enqueue.php: catches the Requests tab's "Loading…"
    // placeholder if it's ever left stuck (stale cache, a conflicting
    // script elsewhere on the page, etc.) and turns it into a visible,
    // actionable Retry message instead of an indefinite spinner.
    if ( function_exists( 'nsh_output_admin_requests_watchdog' ) ) {
        nsh_output_admin_requests_watchdog();
    }
    $o .= '</div>';
    return $o;
}

function nsh_admin_tab_requests() {
    // Full 9-status set, matching the canonical list already used by the
    // staff "Update Status" panel on the request detail page
    // (nsh_render_staff_panel() below) and the client-facing pipeline
    // display (nsh_sc_request_view()) — 'ready_for_processing' and
    // 'service_not_available' were previously missing from this
    // particular array (stat cards + "All Statuses" filter dropdown +,
    // until this fix, the card's inline status selector), even though
    // both are real, already-in-use statuses elsewhere in the plugin.
    $statuses = array( 'submitted', 'under_review', 'ready_for_processing', 'approved', 'processing', 'dispatched', 'completed', 'service_not_available', 'rejected' );
    $o  = '<div class="nsh-tab-content"><div class="nsh-stats-strip">';
    foreach ( $statuses as $s ) {
        $q = new WP_Query( array( 'post_type' => 'nsh_request', 'post_status' => 'publish', 'posts_per_page' => -1, 'meta_query' => array( array( 'key' => 'status', 'value' => $s ) ) ) );
        $c = $q->found_posts; wp_reset_postdata();
        $o .= '<div class="nsh-stat-card" onclick="nshAdminFilter(\'' . esc_js( $s ) . '\')" style="border-left:4px solid ' . nsh_status_color( $s ) . ';"><div class="nsh-stat-num" style="color:' . nsh_status_color( $s ) . '">' . intval( $c ) . '</div><div class="nsh-stat-lbl">' . esc_html( nsh_status_label( $s ) ) . '</div></div>';
    }
    $o .= '</div><div class="nsh-tbl-toolbar"><input type="text" id="nsh-admin-search" placeholder="Search by name, email, university, enrollment no., phone, remarks…" class="nsh-search-input"><select id="nsh-admin-status-f" class="nsh-filter-sel"><option value="">All Statuses</option>';
    foreach ( $statuses as $s ) { $o .= '<option value="' . $s . '">' . esc_html( nsh_status_label( $s ) ) . '</option>'; }
    $o .= '</select>';
    // Date filter — filters by the request's actual submission date/time
    // (post_date, i.e. when it was received), not any other date field.
    // "Specific Date" and "Custom Range" reveal their own date input(s);
    // everything else is applied the moment it's chosen. nsh_admin_js()
    // computes nothing client-side — the filter key + any date value(s)
    // are sent to the server, and nsh_compute_request_date_range()
    // (helpers.php) is the single place the actual date-range math lives,
    // shared with the Form Submissions tab so both filter identically.
    $o .= nsh_render_date_filter_controls( 'nsh-admin-date' );
    // Explicit "Search" button alongside "Filter" — before this, the search
    // box had no button of its own (Enter, or the unrelated "Filter" button,
    // were the only ways to trigger it), which read as broken/missing.
    // Both buttons run the exact same combined search+status+date query;
    // Search is just the more discoverable, correctly-labelled entry point
    // when what the user typed is a search term rather than a filter choice.
    $o .= '<button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-admin-search-btn">&#128269; Search</button><button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-admin-filter-btn">Filter</button><button class="nsh-btn nsh-btn-ghost nsh-btn-sm" id="nsh-admin-reset-btn">Reset</button>';
    // Pagination ("49 total · Prev 1 2 3 Next") lives in this same toolbar
    // row now, pushed to the far right via .nsh-pagination-inline
    // (margin-left:auto in a flex row) instead of its own bar below the
    // list — the id (#nsh-admin-pages) and the nshBuildPager() render call
    // that fills it (see nsh_admin_js()) are unchanged, only where the
    // empty container sits in the markup has moved.
    // Lets the person pick a different folder for future Docs / Download
    // All / Download Selected saves — the folder chosen the first time is
    // otherwise remembered and reused silently forever (see
    // nshGetParentDirHandle() in nsh-app.js), so this is the only way to
    // point it somewhere else. One shared setting for the whole browser,
    // not per-request, so one control here covers every Docs button below.
    $o .= '<button type="button" class="nsh-btn nsh-btn-ghost nsh-btn-sm nsh-change-save-folder" title="Documents currently save into a remembered folder. Click to choose a different one for future downloads.">&#128193; Change Save Folder</button>';
    $o .= '<div id="nsh-admin-pages" class="nsh-pagination nsh-pagination-inline"></div>';
    $o .= '</div>';
    // Internal Status filter bar — a separate row of compact pill buttons
    // (one per staff-only CRM pipeline stage, plus "All"), populated by
    // JS from the same nsh_get_requests response that already loads the
    // list (see nsh_admin_js() below), so no extra round trip is needed
    // just to show it. Deliberately its OWN row, not squeezed into the
    // Search/Filter/Reset toolbar above: up to 21 statuses need to wrap
    // or horizontally scroll on their own without fighting the search box
    // for space, especially on a phone-width screen (see
    // .nsh-istatus-bar in nsh-style.css).
    //
    // Internal statuses are staff-only by construction: this entire tab
    // (nsh_admin_tab_requests()) only renders inside the admin dashboard,
    // which is itself gated by nsh_require_staff() on every AJAX call
    // that feeds it — nothing here is ever reachable from, or sent to,
    // any client-facing page, email, or notification.
    $o .= '<div id="nsh-istatus-bar" class="nsh-istatus-bar" aria-label="Filter by internal status"></div>';
    $o .= '<div class="nsh-bulk-toolbar" id="nsh-bulk-toolbar" style="display:none;margin-bottom:10px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:10px 14px;display:flex;gap:10px;align-items:center;">';
    $o .= '<span id="nsh-bulk-count" style="font-size:13px;font-weight:600;color:#1e40af;">0 selected</span>';
    $o .= '<button class="nsh-btn nsh-btn-outline nsh-btn-sm" id="nsh-bulk-export-excel">&#128202; Export Selected (Excel)</button>';
    $o .= '<button class="nsh-btn nsh-btn-danger nsh-btn-sm" id="nsh-bulk-delete-requests">&#128465; Delete Selected</button>';
    $o .= '<button class="nsh-btn nsh-btn-ghost nsh-btn-sm" id="nsh-bulk-deselect">Clear Selection</button>';
    $o .= '</div>';
    // Card-based list (not a <table>) — each request is a compact,
    // scannable card grouping its submitted form data (Applicant /
    // Document & Academic / Location & Delivery / Remarks) instead of
    // a wall of table columns. "Select All" lives in a small header bar
    // above the card list since there's no header row to put it in.
    $o .= '<div class="nsh-tbl-wrap"><div class="nsh-rc-listhdr"><label class="nsh-rc-selall"><input type="checkbox" id="nsh-select-all-reqs" title="Select All"> Select All</label></div>';
    $o .= '<div id="nsh-admin-tbody" class="nsh-rc-list"><div class="nsh-tbl-loading">Loading...</div></div>';
    $o .= '</div></div>';
    return $o;
}

function nsh_admin_tab_support() {
    $o  = '<div class="nsh-tab-content"><div class="nsh-tab-hdr"><h3>Support Requests</h3><div>';
    $o .= '<select id="nsh-support-status-filter" style="padding:8px 12px;border:1px solid #e2e8f0;border-radius:8px;font-size:13px;margin-right:8px;"><option value="">All Statuses</option><option value="open">Open</option><option value="in_progress">In Progress</option><option value="resolved">Resolved</option><option value="closed">Closed</option></select>';
    $o .= '<button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-load-support-btn">Load</button></div></div>';
    $o .= '<div class="nsh-bulk-toolbar" id="nsh-ticket-bulk-toolbar" style="display:none;margin-bottom:10px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:10px 14px;display:flex;gap:10px;align-items:center;">';
    $o .= '<span id="nsh-ticket-bulk-count" style="font-size:13px;font-weight:600;color:#1e40af;">0 selected</span>';
    $o .= '<button class="nsh-btn nsh-btn-danger nsh-btn-sm" id="nsh-bulk-delete-tickets">&#128465; Delete Selected</button>';
    $o .= '<button class="nsh-btn nsh-btn-ghost nsh-btn-sm" id="nsh-ticket-bulk-deselect">Clear Selection</button>';
    $o .= '</div>';
    $o .= '<div class="nsh-tbl-wrap"><table class="nsh-tbl"><thead><tr><th style="width:36px;"><input type="checkbox" id="nsh-select-all-tickets" title="Select All"></th><th>ID</th><th>Client</th><th>Category</th><th>Description</th><th>Status</th><th>Date</th><th>Action</th></tr></thead>';
    $o .= '<tbody id="nsh-support-tbody"><tr><td colspan="8" class="nsh-tbl-loading">Click Load to show tickets</td></tr></tbody></table></div></div>';
    return $o;
}

function nsh_admin_tab_fields( $echo_inline_script = true ) {
    // $echo_inline_script: see nsh_output_admin_script()'s docblock
    // (enqueue.php) — this function's trailing inline <script> is safe to
    // print raw when this HTML is an AJAX tab-swap response (ajax.php's
    // default call, unaffected by content filters), but NOT when it's
    // rendered directly as the first full page load's page content
    // (nsh_sc_admin_dashboard() passes false there), where a theme/page
    // builder's content sanitization can silently corrupt it.
    // Every service has its own field set now (840 fields across 50
    // services, ported from Services2NRI — see includes/data/services-seed.json),
    // so the table is scoped to one service at a time via this selector
    // instead of dumping all fields from every service into one unfiltered
    // list. Filtering happens client-side (nsh-app.js, by data-service-id
    // on each row) since all rows are already rendered for the admin's
    // search/reorder tooling to work against.
    $services   = nsh_get_services( false );
    $sel_svc_id = intval( isset( $_GET['field_service_id'] ) ? $_GET['field_service_id'] : ( $services ? $services[0]->id : 0 ) );
    $fields     = nsh_get_fields( false );
    $o  = '<div class="nsh-tab-content"><div class="nsh-tab-hdr"><h3>Form Fields</h3><button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-add-field-btn">+ Add Field</button></div>';
    $o .= '<div class="nsh-field" style="max-width:420px;margin-bottom:12px;"><label>Service</label><select id="nsh-fields-service-filter">';
    foreach ( $services as $s ) {
        $o .= '<option value="' . intval( $s->id ) . '"' . selected( $sel_svc_id, $s->id, false ) . '>' . esc_html( $s->name ) . '</option>';
    }
    $o .= '</select></div>';
    $o .= '<p class="nsh-hint" style="margin-bottom:12px;"><span style="font-size:16px;">&#9776;</span> Drag the handle on the left to reorder fields. Steps 98/99 are the standard "Contact Details" and "Documents" steps every service ends with.</p>';
    $o .= '<div id="nsh-add-field-panel" class="nsh-panel-card" style="display:none;margin-bottom:16px;"><h4 style="margin:0 0 14px;">Add / Edit Field</h4><input type="hidden" id="nf-id" value=""><input type="hidden" id="nf-service-id" value="' . intval( $sel_svc_id ) . '"><div class="nsh-form-grid">';
    $o .= '<div class="nsh-field"><label>Label *</label><input type="text" id="nf-label" placeholder="e.g. University Name"></div>';
    $o .= '<div class="nsh-field"><label>Key (unique within this service)</label><input type="text" id="nf-key" placeholder="e.g. university_name"></div>';
    $o .= '<div class="nsh-field"><label>Type</label><select id="nf-type"><option value="text">Text</option><option value="number">Number</option><option value="date">Date</option><option value="textarea">Textarea</option><option value="dropdown">Dropdown / Select</option><option value="checkbox">Checkbox (multi-select)</option><option value="searchable">Searchable</option><option value="radio">Radio</option><option value="file">File</option><option value="phone">Phone</option><option value="email">Email</option></select></div>';
    $o .= '<div class="nsh-field"><label>Step</label><input type="number" id="nf-step" value="1" min="1" max="99"><p class="nsh-hint-sm" style="margin:4px 0 0;">1-97 = content steps, 98 = Contact Details, 99 = Documents.</p></div>';
    $o .= '<div class="nsh-field"><label>Placeholder</label><input type="text" id="nf-placeholder" placeholder="Hint text"></div>';
    $o .= '<div class="nsh-field"><label>Required?</label><select id="nf-required"><option value="0">Optional</option><option value="1">Required</option></select></div>';
    $o .= '<div class="nsh-field"><label>Active?</label><select id="nf-active"><option value="1">Active — shown on the form</option><option value="0">Inactive — hidden from the form</option></select><p class="nsh-hint-sm" style="margin:4px 0 0;">Turning a field off hides it from new submissions without deleting it; any past submission that used it is untouched.</p></div>';
    $o .= '</div><div class="nsh-field nsh-field-full" style="margin-top:10px;"><label>Help Text / Description <span style="font-weight:400;color:#94a3b8;font-size:12px;">(shown below the field on the form)</span></label><textarea id="nf-description" rows="2" placeholder="e.g. Please upload a clear scanned copy of your document." style="width:100%;padding:8px 12px;border:1px solid #e2e8f0;border-radius:8px;font-size:13px;resize:vertical;"></textarea></div>';
    // One option per line — not comma-separated. An option's own text
    // ("Under ₹2,000") can contain a comma; it can never contain a
    // newline, so this is the one delimiter that can't be confused with
    // content. See nsh_parse_field_options() (helpers.php).
    $o .= '<div class="nsh-field nsh-field-full" id="nf-opts-wrap" style="display:none;"><label>Options (one per line)</label><textarea id="nf-opts" rows="4" placeholder="Option A&#10;Option B&#10;Under ₹2,000" style="width:100%;padding:8px 12px;border:1px solid #e2e8f0;border-radius:8px;font-size:13px;resize:vertical;"></textarea></div>';

    // --- Conditional Logic Section ---
    $o .= '<div style="margin-top:18px;border-top:1px solid #e2e8f0;padding-top:16px;">';
    $o .= '<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px;">';
    $o .= '<h5 style="margin:0;font-size:14px;font-weight:600;color:#1e293b;">&#127380; Conditional Logic</h5>';
    $o .= '<div style="display:flex;align-items:center;gap:8px;">';
    $o .= '<input type="checkbox" id="nf-cond-enabled" style="width:16px;height:16px;cursor:pointer;accent-color:#4f46e5;flex-shrink:0;">';
    $o .= '<label for="nf-cond-enabled" style="font-size:13px;color:#64748b;cursor:pointer;margin:0;">Enable conditional logic for this field</label>';
    $o .= '</div></div>';
    $o .= '<div id="nf-cond-panel" style="display:none;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;padding:16px;">';
    $o .= '<div style="display:flex;gap:10px;align-items:center;margin-bottom:14px;flex-wrap:wrap;">';
    $o .= '<span style="font-size:13px;font-weight:600;color:#475569;">Show this field if</span>';
    $o .= '<select id="nf-cond-action" style="padding:6px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;background:#fff;">';
    $o .= '<option value="all">ALL of the following match</option><option value="any">ANY of the following match</option></select></div>';
    $o .= '<div id="nf-cond-rules" style="display:flex;flex-direction:column;gap:10px;"></div>';
    $o .= '<button type="button" id="nf-cond-add-rule" class="nsh-btn nsh-btn-ghost nsh-btn-sm" style="margin-top:12px;">+ Add Condition</button>';
    $o .= '<p style="font-size:12px;color:#94a3b8;margin:8px 0 0;">Leave empty to always show this field. Conditions check field values in real time.</p>';
    $o .= '</div></div>';
    // --- End Conditional Logic Section ---

    $o .= '<div style="display:flex;gap:10px;margin-top:12px;"><button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-do-save-field">Save Field</button><button class="nsh-btn nsh-btn-ghost nsh-btn-sm" id="nsh-cancel-field">Cancel</button></div>';
    $o .= '<div id="nsh-field-msg" class="nsh-alert" style="display:none;margin-top:10px;"></div></div>';
    $o .= '<div class="nsh-tbl-wrap"><table class="nsh-tbl"><thead><tr><th style="width:36px;"></th><th>#</th><th>Label</th><th>Key</th><th>Type</th><th>Step</th><th>Req.</th><th>Help Text</th><th>Active</th><th>Conditions</th><th>Actions</th></tr></thead>';
    $o .= '<tbody id="nsh-fields-tbody">';
    $i = 1;
    foreach ( $fields as $f ) {
        $cond_data = $f->conditions ? json_decode($f->conditions, true) : null;
        $has_cond  = !empty($cond_data) && !empty($cond_data['rules']);
        $cond_icon = $has_cond ? '<span style="color:#4f46e5;font-weight:600;font-size:12px;" title="Has conditional logic">&#127380; Yes</span>' : '<span style="color:#94a3b8;font-size:12px;">-</span>';
        $o .= '<tr data-field-id="' . intval( $f->id ) . '" data-service-id="' . intval( $f->service_id ) . '"' . ( (int) $f->service_id !== $sel_svc_id ? ' style="display:none;"' : '' ) . '>';
        $o .= '<td><span class="nsh-drag-handle" title="Drag to reorder">&#9776;</span></td>';
        $o .= '<td style="color:#94a3b8;">' . intval( $i++ ) . '</td>';
        $o .= '<td>' . esc_html( $f->field_label ) . '</td>';
        $o .= '<td><code>' . esc_html( $f->field_key ) . '</code></td>';
        $o .= '<td>' . esc_html( $f->field_type ) . '</td>';
        $o .= '<td>' . intval( $f->step_number ) . '</td>';
        $o .= '<td>' . ( $f->is_required ? '<span style="color:#10b981;font-weight:600;">Yes</span>' : 'No' ) . '</td>';
        $o .= '<td>' . ( $f->is_active ? '<span style="color:#10b981;font-weight:600;">On</span>' : '<span style="color:#ef4444;">Off</span>' ) . '</td>';
        $o .= '<td style="max-width:160px;color:#64748b;font-size:12px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="' . esc_attr( isset($f->description) ? $f->description : '' ) . '">' . ( !empty($f->description) ? esc_html( mb_strimwidth($f->description, 0, 40, '…') ) : '<span style="color:#cbd5e1;">—</span>' ) . '</td>';
        $o .= '<td>' . $cond_icon . '</td>';
        $o .= '<td style="display:flex;gap:6px;">';
        $cond_json = ( $cond_data ) ? esc_attr( wp_json_encode( $cond_data ) ) : '';
        $o .= '<button class="nsh-btn nsh-btn-sm nsh-btn-outline nsh-edit-field" data-id="' . intval( $f->id ) . '" data-service-id="' . intval( $f->service_id ) . '" data-label="' . esc_attr( $f->field_label ) . '" data-key="' . esc_attr( $f->field_key ) . '" data-type="' . esc_attr( $f->field_type ) . '" data-step="' . intval( $f->step_number ) . '" data-required="' . intval( $f->is_required ) . '" data-active="' . intval( $f->is_active ) . '" data-opts="' . esc_attr( $f->field_options ) . '" data-ph="' . esc_attr( $f->placeholder ) . '" data-desc="' . esc_attr( isset($f->description) ? $f->description : '' ) . '" data-conditions="' . $cond_json . '">Edit</button>';
        $o .= '<button class="nsh-btn nsh-btn-sm nsh-btn-danger nsh-del-field" data-id="' . intval( $f->id ) . '">Del</button>';
        $o .= '</td></tr>';
    }
    $o .= '</tbody></table></div>';
    // Build a JS map of all fields and their options - embedded directly in page
    // This is used by conditional logic to populate the value dropdown
    $field_opts_map = array();
    $all_fields     = nsh_get_fields( false );
    foreach ( $all_fields as $ff ) {
        $opts = array();
        if ( in_array( $ff->field_type, array( 'dropdown', 'searchable', 'radio' ), true ) ) {
            $db_opts = nsh_get_dropdown_options( $ff->field_key );
            if ( $db_opts ) {
                $opts = $db_opts;
            } elseif ( $ff->field_options ) {
                $opts = nsh_parse_field_options( $ff->field_options );
            }
        }
        $field_opts_map[ $ff->field_key ] = array(
            'label'   => $ff->field_label,
            'type'    => $ff->field_type,
            'options' => $opts,
        );
    }
    $field_map_json = wp_json_encode( $field_opts_map );
    $js  = 'window.NSH_FIELD_MAP = ' . $field_map_json . ';';
    $js .= 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",function(){jQuery(document).trigger("nsh:fields_rendered");});}else{jQuery(document).trigger("nsh:fields_rendered");}';
    $o .= nsh_output_admin_script( $js, $echo_inline_script );
    $o .= '</div>';
    return $o;
}

function nsh_admin_tab_dropdowns() {
    global $wpdb;
    $fkeys = $wpdb->get_results( "SELECT field_key, field_label FROM {$wpdb->prefix}nsh_fields WHERE field_type IN ('dropdown','searchable') AND is_active=1" );
    $o  = '<div class="nsh-tab-content"><div class="nsh-tab-hdr"><h3>Dropdown Data Manager</h3></div>';
    $o .= '<div class="nsh-dd-controls"><select id="nsh-dd-fkey" style="padding:9px 14px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;"><option value="">- Select Field -</option>';
    foreach ( $fkeys as $fk ) { $o .= '<option value="' . esc_attr( $fk->field_key ) . '">' . esc_html( $fk->field_label ) . '</option>'; }
    $o .= '</select><input type="text" id="nsh-dd-search" placeholder="Search options..." style="padding:9px 14px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;flex:1;max-width:260px;">';
    $o .= '<div id="nsh-dd-btns" style="display:none;gap:8px;"><button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-dd-add-btn">+ Add Option</button>';
    $o .= '<button class="nsh-btn nsh-btn-danger nsh-btn-sm" id="nsh-dd-bulk-del" style="display:none;">Delete Selected</button>';
    $o .= '<span id="nsh-dd-sel-count" style="font-size:13px;color:#64748b;align-self:center;"></span></div></div>';
    $o .= '<div id="nsh-dd-form" class="nsh-panel-card" style="display:none;margin:12px 0;"><h4 id="nsh-dd-form-title" style="margin:0 0 12px;">Add Option</h4>';
    $o .= '<div style="display:flex;gap:10px;"><input type="hidden" id="nsh-dd-edit-id" value=""><input type="text" id="nsh-dd-val" placeholder="Option value" style="flex:1;padding:9px 14px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;">';
    $o .= '<button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-dd-do-save">Save</button><button class="nsh-btn nsh-btn-ghost nsh-btn-sm" id="nsh-dd-cancel">Cancel</button></div>';
    $o .= '<div id="nsh-dd-form-msg" class="nsh-alert" style="display:none;margin-top:10px;"></div></div>';
    $o .= '<div id="nsh-dd-table-wrap" class="nsh-tbl-wrap" style="display:none;"><table class="nsh-tbl"><thead><tr><th style="width:40px;"><input type="checkbox" id="nsh-dd-all"></th><th>#</th><th>Option Value</th><th style="width:160px;">Actions</th></tr></thead>';
    $o .= '<tbody id="nsh-dd-tbody"><tr><td colspan="4" class="nsh-tbl-loading">Select a field above</td></tr></tbody></table>';
    $o .= '<div id="nsh-dd-pages" class="nsh-pagination"></div></div></div>';
    return $o;
}

function nsh_admin_tab_bulk() {
    global $wpdb;
    $fkeys = $wpdb->get_results( "SELECT field_key, field_label FROM {$wpdb->prefix}nsh_fields WHERE field_type IN ('dropdown','searchable') AND is_active=1" );
    $o  = '<div class="nsh-tab-content"><div class="nsh-tab-hdr"><h3>Bulk Import</h3></div>';
    $o .= '<div class="nsh-panel-card" style="margin-bottom:16px;"><div class="nsh-form-grid">';
    $o .= '<div class="nsh-field"><label>Target Field *</label><select id="nsh-bulk-fkey" style="width:100%;padding:9px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;"><option value="">- Select -</option>';
    foreach ( $fkeys as $fk ) { $o .= '<option value="' . esc_attr( $fk->field_key ) . '">' . esc_html( $fk->field_label ) . '</option>'; }
    $o .= '</select></div><div class="nsh-field"><label>Import Mode</label><select id="nsh-bulk-mode" style="width:100%;padding:9px;border:1px solid #e2e8f0;border-radius:8px;font-size:14px;"><option value="append">Append to existing</option><option value="replace">Replace all existing</option></select></div>';
    $o .= '</div></div>';
    $o .= '<div class="nsh-bulk-tabs"><button class="nsh-bulk-tab active" data-bt="file">Upload CSV</button><button class="nsh-bulk-tab" data-bt="paste">Paste Data</button></div>';
    $o .= '<div id="nsh-bt-file" class="nsh-bulk-pane nsh-panel-card"><p style="color:#64748b;margin:0 0 16px;">Upload a CSV file - one value per row.</p>';
    $o .= '<div class="nsh-dropzone" id="nsh-csv-drop" style="cursor:pointer;" onclick="document.getElementById(\'nsh-csv-file\').click()"><input type="file" id="nsh-csv-file" accept=".csv,.txt" style="display:none">';
    $o .= '<div class="nsh-dz-inner"><div class="nsh-dz-icon">&#128202;</div><p>Drop CSV here or click to browse</p><p class="nsh-hint-sm">One value per row, no header</p></div></div>';
    $o .= '<div id="nsh-csv-preview" style="display:none;margin-top:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:14px;">';
    $o .= '<strong style="font-size:13px;">Preview</strong><span id="nsh-csv-total" style="font-size:12px;color:#94a3b8;margin-left:12px;"></span>';
    $o .= '<ul id="nsh-csv-prev-list" style="margin:8px 0;padding-left:20px;font-size:13px;color:#475569;"></ul></div>';
    $o .= '<div style="margin-top:16px;display:flex;gap:10px;"><button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-do-csv-import" disabled>Import File</button>';
    $o .= '<a href="data:text/csv;charset=utf-8,University+of+Delhi%0AUniversity+of+Mumbai%0AAnna+University" download="sample.csv" class="nsh-btn nsh-btn-ghost nsh-btn-sm">Sample CSV</a></div></div>';
    $o .= '<div id="nsh-bt-paste" class="nsh-bulk-pane nsh-panel-card" style="display:none;">';
    $o .= '<div class="nsh-format-pills"><button class="nsh-fp active" data-fmt="lines">One per line</button><button class="nsh-fp" data-fmt="comma">Comma-separated</button><button class="nsh-fp" data-fmt="json">JSON array</button></div>';
    $o .= '<div class="nsh-field" style="margin-top:12px;"><label>Paste data here:</label><textarea id="nsh-paste-data" rows="8" placeholder="University of Delhi&#10;University of Mumbai"></textarea></div>';
    $o .= '<div id="nsh-paste-preview" style="display:none;margin-bottom:12px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px;">';
    $o .= '<strong style="font-size:13px;">Parsed Preview</strong><span id="nsh-paste-count" style="font-size:12px;color:#64748b;margin-left:8px;font-weight:600;"></span>';
    $o .= '<div id="nsh-paste-prev-list" style="font-size:13px;color:#475569;max-height:100px;overflow-y:auto;margin-top:8px;"></div>';
    $o .= '<div id="nsh-paste-err" class="nsh-alert nsh-alert-error" style="display:none;margin-top:8px;"></div></div>';
    $o .= '<div style="display:flex;gap:10px;"><button class="nsh-btn nsh-btn-outline nsh-btn-sm" id="nsh-parse-paste">Parse &amp; Preview</button><button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-do-paste-import" disabled>Import</button></div></div>';
    $o .= '<div id="nsh-bulk-msg" class="nsh-alert" style="display:none;margin-top:12px;"></div></div>';
    return $o;
}

function nsh_admin_tab_types() {
    $types = nsh_get_request_types( false );
    $o  = '<div class="nsh-tab-content">';
    $o .= '<div class="nsh-tab-hdr"><h3>Service / Request Types</h3><button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-add-type-btn">+ Add Type</button></div>';
    $o .= '<p style="color:#64748b;font-size:13px;margin-bottom:16px;">These categories appear in the service request modal.</p>';

    // Add/Edit form
    $o .= '<div id="nsh-type-form" class="nsh-panel-card" style="display:none;margin-bottom:16px;">';
    $o .= '<h4 id="nsh-type-form-title" style="margin:0 0 14px;">Add Type</h4>';
    $o .= '<input type="hidden" id="nsh-type-id" value="">';
    $o .= '<div class="nsh-form-grid">';
    $o .= '<div class="nsh-field"><label>Name *</label><input type="text" id="nsh-type-name" placeholder="e.g. Transcript Request"></div>';
    $o .= '<div class="nsh-field"><label>Description</label><input type="text" id="nsh-type-desc" placeholder="Brief description"></div>';
    $o .= '</div>';
    $o .= '<div style="display:flex;gap:10px;margin-top:12px;">';
    $o .= '<button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-do-save-type">Save</button>';
    $o .= '<button class="nsh-btn nsh-btn-ghost nsh-btn-sm" id="nsh-cancel-type">Cancel</button>';
    $o .= '</div>';
    $o .= '<div id="nsh-type-msg" class="nsh-alert" style="display:none;margin-top:10px;"></div>';
    $o .= '</div>';

    // Bulk toolbar — shown when 1+ checked
    $o .= '<div id="nsh-type-bulk-bar" style="display:none;align-items:center;gap:10px;padding:10px 14px;background:#fff7ed;border:1px solid #fed7aa;border-radius:8px;margin-bottom:12px;">';
    $o .= '<span id="nsh-type-bulk-count" style="font-size:13px;color:#92400e;font-weight:600;"></span>';
    $o .= '<button class="nsh-btn nsh-btn-danger nsh-btn-sm" id="nsh-type-bulk-del">&#128465; Delete Selected</button>';
    $o .= '<button class="nsh-btn nsh-btn-ghost nsh-btn-sm" id="nsh-type-bulk-clear">Clear</button>';
    $o .= '</div>';

    $o .= '<div class="nsh-tbl-wrap"><table class="nsh-tbl"><thead><tr>';
    $o .= '<th style="width:38px;"><input type="checkbox" id="nsh-type-sel-all" title="Select all" style="width:15px;height:15px;"></th>';
    $o .= '<th>Name</th><th>Description</th><th>Active</th><th>Actions</th>';
    $o .= '</tr></thead><tbody>';
    if ( empty( $types ) ) {
        $o .= '<tr><td colspan="5" class="nsh-tbl-empty">No types found. Add one above.</td></tr>';
    } else {
        foreach ( $types as $t ) {
            $o .= '<tr class="nsh-type-row">';
            $o .= '<td><input type="checkbox" class="nsh-type-chk" data-id="' . intval( $t->id ) . '" style="width:15px;height:15px;"></td>';
            $o .= '<td><strong>' . esc_html( $t->name ) . '</strong></td>';
            $o .= '<td style="color:#64748b;font-size:13px;">' . esc_html( $t->description ) . '</td>';
            $o .= '<td>' . ( $t->is_active ? '<span style="color:#10b981;font-weight:600;">Active</span>' : '<span style="color:#ef4444;">Off</span>' ) . '</td>';
            $o .= '<td style="display:flex;gap:6px;">';
            $o .= '<button class="nsh-btn nsh-btn-sm nsh-btn-outline nsh-edit-type" data-id="' . intval( $t->id ) . '" data-name="' . esc_attr( $t->name ) . '" data-desc="' . esc_attr( $t->description ) . '">Edit</button>';
            $o .= '<button class="nsh-btn nsh-btn-sm nsh-btn-danger nsh-del-type" data-id="' . intval( $t->id ) . '">Delete</button>';
            $o .= '</td></tr>';
        }
    }
    $o .= '</tbody></table></div></div>';
    return $o;
}


function nsh_admin_js() {
    // Only ever called once, from nsh_sc_admin_dashboard()'s direct/first-
    // full-page render (never from an AJAX tab-swap — see the comment on
    // that call site) — i.e. this is ALWAYS the content-filtered path, so
    // it always goes out via wp_add_inline_script() now instead of a raw
    // <script> tag baked into page content. See the docblock on
    // nsh_output_admin_script() (enqueue.php) for why that matters.
    $o  = '';
    // Diagnostic marker — logs unconditionally the instant this script
    // actually executes, with the exact plugin version baked in server-side
    // (so a hard refresh always shows whether the BROWSER is even running
    // the current code, not a cached older copy — the single most useful
    // fact for telling "the fix isn't installed/cached yet" apart from "the
    // fix is running but still doesn't work"). If the Requests tab is ever
    // stuck again, checking the browser console (F12 → Console) for this
    // line is the fastest way to tell which of those two it is; its
    // absence means this script never ran at all (content-filter/caching/
    // conflict on that page), not a bug in the loading logic below.
    $o .= 'console.log("[NSH] admin-requests script running — plugin v' . esc_js( NSH_VER ) . '");';
    // These vars/functions are declared once, outside #nsh-admin-tab-container,
    // so an AJAX tab-swap never destroys them — nsh-app.js's SPA controller
    // calls window.nshLoadAdminRequests() again each time the Requests tab
    // is (re)shown instead of relying on this script re-executing.
    $o .= 'var _page=1,_status="",_search="",_dateFilter="",_dateFrom="",_dateTo="",_internalStatus="";';
    // Client-facing status list for the card's inline status <select> —
    // same 7 statuses already offered by the "All Statuses" filter
    // dropdown above (nsh_admin_tab_requests()), built once here from
    // nsh_status_label()/nsh_status_color() (helpers.php) so the card
    // selector can never drift out of sync with what those return.
    // Same 9-status canonical list as $statuses in nsh_admin_tab_requests()
    // above — this was the actual bug: this array (the card's inline
    // status <select>) had silently drifted to a 7-status subset, missing
    // 'ready_for_processing' and 'service_not_available', both of which
    // are real statuses already used by the staff "Update Status" panel,
    // the client-facing pipeline display, and their own notification
    // email templates.
    $client_statuses = array( 'submitted', 'under_review', 'ready_for_processing', 'approved', 'processing', 'dispatched', 'completed', 'service_not_available', 'rejected' );
    $cs_js = array();
    foreach ( $client_statuses as $cs ) { $cs_js[] = array( 'value' => $cs, 'label' => nsh_status_label( $cs ), 'color' => nsh_status_color( $cs ) ); }
    $o .= 'var _nriClientStatuses=' . wp_json_encode( $cs_js ) . ';';
    // Renders the compact Internal Status pill bar from the same response
    // that loaded the list (istatuses = full definition list including
    // inactive ones still in use; counts = slug -> count, see
    // nsh_get_internal_status_counts() in helpers.php). "All" always
    // appears first and clears the filter. Deactivated statuses only
    // render as a pill when a request in the CURRENT result set actually
    // carries them (so old data stays reachable/filterable) or when
    // they\'re the currently-active filter — otherwise they\'d clutter the
    // bar with stages staff can no longer pick anyway. Horizontal
    // scrolling on narrow screens is pure CSS (.nsh-istatus-bar in
    // nsh-style.css) — this just renders one <button> per status in a
    // row, in exactly the sort_order the admin configured.
    $o .= 'function nshRenderIStatusBar(istatuses,counts){';
    $o .= 'var bar=document.getElementById("nsh-istatus-bar");if(!bar)return;';
    $o .= 'var total=0;Object.keys(counts||{}).forEach(function(k){total+=counts[k]||0;});';
    $o .= 'var html="";';
    $o .= 'html+="<button type=button class=\'nsh-istatus-pill"+(_internalStatus===""?" active":"")+"\' onclick=\'nshFilterInternalStatus(\\"\\")\'>All <span class=nsh-istatus-count>"+total+"</span></button>";';
    $o .= '(istatuses||[]).forEach(function(s){';
    $o .= 'var c=counts&&counts[s.slug]?counts[s.slug]:0;';
    $o .= 'if(!s.is_active&&c===0&&s.slug!==_internalStatus)return;';
    $o .= 'var active=(_internalStatus===s.slug);';
    $o .= 'html+="<button type=button class=\'nsh-istatus-pill"+(active?" active":"")+(s.is_active?"":" nsh-istatus-inactive")+"\' style="+(active?"background:"+s.color+";border-color:"+s.color+";color:#fff;":"border-color:"+s.color+"55;color:"+s.color+";")+" onclick=\'nshFilterInternalStatus(\\""+s.slug+"\\")\'  title=\'"+s.label.replace(/\'/g,"")+(s.is_active?"":" (deactivated)")+"\'>"+s.label+" <span class=nsh-istatus-count>"+c+"</span></button>";';
    $o .= '});';
    $o .= 'bar.innerHTML=html;';
    $o .= '}';
    $o .= 'window.nshRenderIStatusBar=nshRenderIStatusBar;';
    $o .= 'function nshFilterInternalStatus(slug){_internalStatus=slug;_page=1;nshLoadAdminRequests(false);}';
    $o .= 'window.nshFilterInternalStatus=nshFilterInternalStatus;';
    // Inline "change internal status" from the card itself — no page
    // reload, no navigating to the request detail page. optimistic UI:
    // the badge/select updates immediately; on failure it\'s reverted and
    // the error shown, so a rejected change (e.g. a since-deactivated
    // slug) never leaves the card silently wrong.
    $o .= 'function nshChangeInternalStatus(rid,slug,selEl){';
    $o .= 'var prevIdx=selEl?selEl.getAttribute("data-prev"):null;';
    $o .= 'jQuery.post(NSH.ajax_url,{action:"nsh_set_internal_status",nonce:NSH.admin_nonce,request_id:rid,internal_status:slug},function(r){';
    $o .= 'if(!r||!r.success){alert((r&&r.data&&r.data.message)?r.data.message:"Could not update internal status.");if(selEl&&prevIdx!==null)selEl.value=prevIdx;return;}';
    $o .= 'if(selEl){selEl.setAttribute("data-prev",slug);selEl.style.borderColor=r.data.internal_status_color;selEl.style.color=r.data.internal_status_color;}';
    $o .= '});';
    $o .= '}';
    $o .= 'window.nshChangeInternalStatus=nshChangeInternalStatus;';
    // Builds the <option> list for one card\'s inline internal-status
    // <select>: every active status (in configured order) plus, if the
    // request\'s CURRENT status has since been deactivated, that one too
    // (marked "(inactive)") so the select always has a selected option
    // that actually matches the request\'s real status instead of
    // silently falling back to the first option in the list.
    $o .= 'function nshIStatusOptionsHtml(currentSlug){';
    $o .= 'var defs=window._nriIStatusDefs||[];var html="";var seenCurrent=false;';
    $o .= 'defs.forEach(function(s){';
    $o .= 'if(!s.is_active&&s.slug!==currentSlug)return;';
    $o .= 'if(s.slug===currentSlug)seenCurrent=true;';
    $o .= 'html+="<option value=\'"+s.slug+"\'"+(s.slug===currentSlug?" selected":"")+">"+s.label+(s.is_active?"":" (inactive)")+"</option>";';
    $o .= '});';
    $o .= 'if(!seenCurrent&&currentSlug){html="<option value=\'"+currentSlug+"\' selected>"+currentSlug+"</option>"+html;}';
    $o .= 'return html;';
    $o .= '}';
    $o .= 'window.nshIStatusOptionsHtml=nshIStatusOptionsHtml;';
    // Client-facing status: options builder + inline change handler,
    // mirroring the Internal Status pair above but posting to the
    // existing "nsh_update_status" endpoint (nsh_ajax_update_status_v2()
    // in ajax.php) — the SAME endpoint the request detail page already
    // uses, so a card-side change gets identical behavior: history log
    // entry, the nsh_after_status_changed hook, and the client
    // notification email, with nothing duplicated or re-implemented here.
    $o .= 'function nshClientStatusOptionsHtml(currentVal){';
    $o .= 'var html="";var seen=false;';
    $o .= '_nriClientStatuses.forEach(function(s){if(s.value===currentVal)seen=true;html+="<option value=\'"+s.value+"\'"+(s.value===currentVal?" selected":"")+">"+s.label+"</option>";});';
    $o .= 'if(!seen&&currentVal){html="<option value=\'"+currentVal+"\' selected>"+currentVal+"</option>"+html;}';
    $o .= 'return html;';
    $o .= '}';
    $o .= 'window.nshClientStatusOptionsHtml=nshClientStatusOptionsHtml;';
    // Compact progress fill for the card's sidebar — reuses the same
    // 7-stage linear pipeline order as the request-detail page's own
    // $stages array (nsh_sc_request_view() in this file), so "how far
    // along" reads consistently in both places. 'rejected' and
    // 'service_not_available' aren't points on that pipeline (they're
    // terminal off-ramps, not a further stage of it), so both render a
    // full bar in the status's own color instead of a stage fraction —
    // that reads as "this request stopped here", not "further along
    // than Completed".
    $o .= 'var NSH_PIPELINE=["submitted","under_review","ready_for_processing","approved","processing","dispatched","completed"];';
    $o .= 'function nshRcProgressPct(status){var idx=NSH_PIPELINE.indexOf(status);if(idx===-1)return 100;return Math.round(((idx+1)/NSH_PIPELINE.length)*100);}';
    $o .= 'window.nshRcProgressPct=nshRcProgressPct;';
    $o .= 'function nshChangeClientStatus(rid,slug,selEl){';
    $o .= 'var prev=selEl?selEl.getAttribute("data-prev"):null;';
    $o .= 'jQuery.post(NSH.ajax_url,{action:"nsh_update_status",nonce:NSH.admin_nonce,request_id:rid,status:slug},function(r){';
    $o .= 'if(!r||!r.success){alert((r&&r.data&&r.data.message)?r.data.message:"Could not update status.");if(selEl&&prev!==null)selEl.value=prev;return;}';
    $o .= 'if(selEl){var col=_nriClientStatuses.filter(function(s){return s.value===slug;})[0];col=col?col.color:"#6b7280";selEl.setAttribute("data-prev",slug);selEl.style.borderColor=col;selEl.style.color=col;}';
    $o .= '});';
    $o .= '}';
    $o .= 'window.nshChangeClientStatus=nshChangeClientStatus;';
    $o .= 'function nshUpdateTicketStatus(id,status){jQuery.post(NSH.ajax_url,{action:"nsh_update_ticket_status",nonce:NSH.admin_nonce,id:id,status:status});}';
    // Shows/hides the Specific Date / Custom Range input group that
    // matches whatever the date-filter <select> is currently set to (both
    // start hidden — see nsh_render_date_filter_controls() in
    // helpers.php). $prefix (e.g. "nsh-admin-date") is the same id prefix
    // passed to that PHP function, so this one JS function serves both the
    // Requests tab and the Form Submissions tab date filter.
    $o .= 'function nshInitDateFilterToggle(prefix){';
    $o .= 'var sel=document.getElementById(prefix+"-f");if(!sel)return;';
    $o .= 'var specWrap=document.getElementById(prefix+"-specific-wrap");';
    $o .= 'var rangeWrap=document.getElementById(prefix+"-range-wrap");';
    $o .= 'function sync(){';
    $o .= 'var v=sel.value;';
    $o .= 'if(specWrap)specWrap.style.display=(v==="specific_date")?"inline-flex":"none";';
    $o .= 'if(rangeWrap)rangeWrap.style.display=(v==="custom_range")?"inline-flex":"none";';
    $o .= '}';
    $o .= 'sel.addEventListener("change",sync);';
    $o .= 'sync();';
    $o .= '}';
    $o .= 'window.nshInitDateFilterToggle=nshInitDateFilterToggle;';
    // Reads the date-filter select + whichever conditional input is
    // relevant into {filter, from, to} — "specific_date" maps its single
    // date input to "from" (with "to" left empty), matching what
    // nsh_compute_request_date_range() (helpers.php) expects server-side.
    // Shared by the Requests tab and Form Submissions tab.
    $o .= 'function nshReadDateFilter(prefix){';
    $o .= 'var sel=document.getElementById(prefix+"-f");var v=sel?sel.value:"";';
    $o .= 'var from="",to="";';
    $o .= 'if(v==="specific_date"){var sp=document.getElementById(prefix+"-specific");from=sp?sp.value:"";}';
    $o .= 'else if(v==="custom_range"){var fr=document.getElementById(prefix+"-from");var t=document.getElementById(prefix+"-to");from=fr?fr.value:"";to=t?t.value:"";}';
    $o .= 'return {filter:v,from:from,to:to};';
    $o .= '}';
    $o .= 'window.nshReadDateFilter=nshReadDateFilter;';
    // The "false" argument on every call below means "don\'t restore cached
    // filter state" — see the comment on nshLoadAdminRequests() itself for
    // why this matters: every one of these already just set _status/_search/
    // _page to the value the user explicitly chose, and restoring would
    // silently throw that away again.
    $o .= 'function nshAdminFilter(s){var el=document.getElementById("nsh-admin-status-f");if(el)el.value=s;_status=s;_page=1;nshLoadAdminRequests(false);}';
    $o .= 'function nshGoPage(p){_page=p;nshLoadAdminRequests(false);}';
    $o .= 'function nshDeleteRequest(rid){if(!confirm("Delete this request? All messages and tickets on it will also be deleted."))return;';
    $o .= 'jQuery.post(NSH.ajax_url,{action:"nsh_delete_request",nonce:NSH.admin_nonce,request_id:rid,hard_delete:1},function(r){if(r.success){nshLoadAdminRequests();}else{alert("Delete failed.");}});}';
    $o .= 'window.nshDeleteRequest=nshDeleteRequest;';
    $o .= 'function nshDeleteTicket(id){if(!confirm("Delete this ticket?"))return;';
    $o .= 'jQuery.post(NSH.ajax_url,{action:"nsh_delete_ticket",nonce:NSH.admin_nonce,id:id},function(r){if(r.success){nshLoadSupportTickets();}else{alert("Delete failed.");}});}';
    $o .= 'window.nshDeleteTicket=nshDeleteTicket;';
    // Shared compact pager: renders a Prev button, a bounded page-number
    // window around the current page (with 1/last always shown + "…"
    // gaps), and a Next button — capped at a handful of buttons no matter
    // how many total pages exist. Previously every list (Requests, Form
    // Submissions) rendered ONE <button> per page with no cap, so a
    // dataset with 535 rows already produced 27 buttons, and a larger
    // install (thousands of rows) would render hundreds of DOM nodes into
    // the pagination bar on every single load/filter/search — real,
    // unbounded work that grows with total row count instead of staying
    // flat. `fn` is the goto-page function\'s name as a string (e.g.
    // "nshGoPage" or "nshSubGoPage") so this one builder serves both the
    // Requests and Form Submissions tabs.
    $o .= 'function nshBuildPager(total,pages,current,fn){';
    $o .= 'var pg="<span style=font-size:13px;color:#64748b;margin-right:8px>"+total+" total</span>";';
    $o .= 'if(pages<=1)return pg;';
    $o .= 'function btn(p,label){return "<button onclick="+fn+"("+p+") class=\'nsh-btn nsh-btn-sm "+(p===current?"nsh-btn-primary":"nsh-btn-ghost")+"\'"+(p===current?" disabled":"")+">"+(label!=null?label:p)+"</button> ";}';
    $o .= 'function ellip(){return "<span style=padding:0 6px;color:#94a3b8;font-size:13px>&#8230;</span>";}';
    $o .= 'pg+="<button onclick="+fn+"("+Math.max(1,current-1)+") class=\'nsh-btn nsh-btn-sm nsh-btn-ghost\'"+(current<=1?" disabled":"")+">&#8249; Prev</button> ";';
    $o .= 'var win=1,nums=[1];';
    $o .= 'for(var i=current-win;i<=current+win;i++){if(i>1&&i<pages)nums.push(i);}';
    $o .= 'if(pages>1)nums.push(pages);';
    $o .= 'nums=nums.filter(function(v,i,a){return a.indexOf(v)===i;}).sort(function(a,b){return a-b;});';
    $o .= 'var prev=0;nums.forEach(function(p){if(p-prev>1)pg+=ellip();pg+=btn(p);prev=p;});';
    $o .= 'pg+=" <button onclick="+fn+"("+Math.min(pages,current+1)+") class=\'nsh-btn nsh-btn-sm nsh-btn-ghost\'"+(current>=pages?" disabled":"")+">Next &#8250;</button>";';
    $o .= 'return pg;';
    $o .= '}';
    $o .= 'window.nshBuildPager=nshBuildPager;';
    // restoreState defaults to true — the ONLY callers that want that
    // default are a fresh tab-entry (the self-invoking call at the bottom
    // of this script, and nsh-app.js's renderTab() calling
    // window.nshLoadAdminRequests() again after an AJAX tab-swap). Every
    // other caller — Filter, Search, Reset, a stat-card quick-filter, or a
    // pagination click — just explicitly set _status/_search/_page to what
    // the user chose right before calling this, and passes false so that
    // choice survives. Previously this restored the LAST SAVED state
    // unconditionally on every single call, including those — so clicking
    // Filter/Search would immediately get its own new _status/_search
    // silently overwritten by the old cached values before the request
    // even went out, making filtering look broken/stuck.
    $o .= 'function nshLoadAdminRequests(restoreState){';
    $o .= 'var tbody=document.getElementById("nsh-admin-tbody");if(!tbody)return;';
    // Re-apply cached filter/search/page state (if any) before loading, so
    // switching away and back to this tab shows the same filtered view —
    // not a reset one. See nshRestoreAdminListState() in nsh-app.js.
    $o .= 'if(restoreState!==false&&window.nshRestoreAdminListState){var st=window.nshRestoreAdminListState("requests");if(st){_status=st.status||"";_search=st.search||"";_dateFilter=st.dateFilter||"";_dateFrom=st.dateFrom||"";_dateTo=st.dateTo||"";_internalStatus=st.internalStatus||"";_page=st.page||1;';
    $o .= 'var sf=document.getElementById("nsh-admin-status-f");if(sf)sf.value=_status;var se=document.getElementById("nsh-admin-search");if(se)se.value=_search;';
    $o .= 'var df=document.getElementById("nsh-admin-date-f");if(df)df.value=_dateFilter;var dsp=document.getElementById("nsh-admin-date-specific");if(dsp)dsp.value=(_dateFilter==="specific_date")?_dateFrom:"";var dfr=document.getElementById("nsh-admin-date-from");if(dfr)dfr.value=(_dateFilter==="custom_range")?_dateFrom:"";var dto=document.getElementById("nsh-admin-date-to");if(dto)dto.value=_dateTo;';
    $o .= 'if(window.nshInitDateFilterToggle)window.nshInitDateFilterToggle("nsh-admin-date");';
    $o .= '}}';
    // Only flash a "Loading..." row when the table is genuinely empty AND
    // the fetch is slow — a fast response (the common case) replaces the
    // existing rows directly, so switching filters/pages/tabs never shows
    // a visible blank-then-fill flicker.
    $o .= 'var _reqHadRows=tbody.children.length>0;';
    $o .= 'var _reqLoadTimer=_reqHadRows?null:setTimeout(function(){tbody.innerHTML="<div class=nsh-tbl-loading>Loading...</div>";},200);';
    // Same diagnostic idea as the script-load marker above, at the two
    // points that actually matter for telling apart "the request never
    // went out" / "it went out but errored" / "it came back but something
    // after that failed" — console.log costs nothing in production and
    // means the very first thing to check (the console) already has the
    // answer, instead of needing another round of guessing.
    $o .= 'console.log("[NSH] nshLoadAdminRequests: sending AJAX request…");';
    $o .= 'jQuery.ajax({url:NSH.ajax_url,type:"POST",timeout:20000,data:{action:"nsh_get_requests",nonce:NSH.admin_nonce,status:_status,search:_search,date_filter:_dateFilter,date_from:_dateFrom,date_to:_dateTo,internal_status:_internalStatus,paged:_page},';
    $o .= 'error:function(xhr,st,err){console.log("[NSH] nshLoadAdminRequests: AJAX error",st,err,xhr&&xhr.status);if(_reqLoadTimer)clearTimeout(_reqLoadTimer);tbody.innerHTML="<div class=nsh-tbl-empty style=color:#ef4444;>AJAX error: "+(err||st)+"</div>";},';
    $o .= 'success:function(r){';
    $o .= 'console.log("[NSH] nshLoadAdminRequests: AJAX success",r&&r.success,r&&r.data?r.data.requests.length:0);';
    $o .= 'if(_reqLoadTimer)clearTimeout(_reqLoadTimer);';
    $o .= 'if(!r||!r.success){tbody.innerHTML="<div class=nsh-tbl-empty style=color:#ef4444;>Error: "+(r&&r.data&&r.data.message?r.data.message:"Unknown error")+"</div>";return;}';
    $o .= 'if(window.nshSaveAdminListState)window.nshSaveAdminListState("requests",{status:_status,search:_search,dateFilter:_dateFilter,dateFrom:_dateFrom,dateTo:_dateTo,internalStatus:_internalStatus,page:_page});';
    $o .= 'window._nriIStatusDefs=r.data.internal_statuses||[];';
    $o .= 'nshRenderIStatusBar(r.data.internal_statuses,r.data.internal_status_counts);';
    $o .= 'var rows="";';
    // Description cache: rid -> plain-text Student Requirement
    // Description, so the card's "Copy Description" button can copy it
    // instantly without a round trip (see nsh-copy-desc-btn handler in
    // nsh-app.js).
    $o .= 'window._nriDescCache=window._nriDescCache||{};';
    $o .= 'r.data.requests.forEach(function(req){';
    // Compact card, not a table row. The checkbox is baked directly into
    // the card markup (not patched on afterwards) so bulk-select always
    // works on every render — first load, filter, page change, or tab
    // re-entry alike. req.card_fields is pre-rendered, already-escaped
    // HTML from nsh_render_request_card_fields() (helpers.php) — the
    // grouped Applicant / Document & Academic / Location & Delivery /
    // Remarks lines, with empty fields and empty lines already omitted.
    // Two-column card: .nsh-rc-main (left) carries the request\'s own
    // identity and submitted-form data — what the request IS. .nsh-rc-side
    // (right) carries everything ABOUT its current handling — both status
    // selects, a compact pipeline-progress fill, and the admin-operational
    // quote/delivery/manager/vendor line — so "what is this" and "how is
    // it being handled" read as two clearly separated concerns instead of
    // one long stacked column. The action buttons (Copy/Desc/Docs/Delete/
    // View) sit in their own row at the bottom of the LEFT column instead
    // — they act on the request\'s own data, not its handling state, so
    // they read as that column\'s toolbar rather than crowding the status
    // panel. Below ~780px (.nsh-req-card-admin media query in
    // nsh-style.css) the two columns stack, side below main, so this
    // still reads fine on a narrow browser window.
    $o .= 'rows+="<div class=nsh-req-card-admin data-rid="+req.id+">";';
    $o .= 'rows+="<div class=nsh-rc-main>";';
    $o .= 'rows+="<div class=nsh-rc-top><input type=checkbox class=nsh-bulk-chk value="+req.id+"><strong class=nsh-rc-title>"+req.request_id+"</strong></div>";';
    // The <small> line next to the client name shows the Contact
    // Person's Name (nsh_req_contact_person_name() in helpers.php — the
    // dedicated Contact Details field, falling back to whatever name/
    // email is available) rather than the raw email address, so the
    // most prominent identifying line on the card is a name a staff
    // member can actually use, not an address to squint at.
    $o .= 'rows+="<div class=nsh-rc-client>"+req.client+" <small>"+(req.contact_person||req.email)+"</small> <span class=nsh-rc-svc>&#8226; "+req.service+"</span></div>";';
    // Wrapped in .nsh-rc-fields so the "Copy Details" button can scope
    // its DOM read to exactly this block (Applicant/Academic/Location &
    // Delivery/Remarks) and nothing else on the card.
    $o .= 'rows+="<div class=nsh-rc-fields>"+req.card_fields+"</div>";';
    // Copy/Desc/Docs/Delete/View — one row at the bottom of the LEFT
    // column now (not the side panel): they act on the request\'s own
    // data (Applicant/Academic/Location/Remarks, the description, its
    // documents, the request itself), so they read as this column\'s
    // toolbar rather than crowding the status/handling panel on the
    // right. Plain buttons (not nsh-view-request-link) for Copy/Desc/
    // Docs so they never trip the delegated "open request detail" click
    // handler; each has its own delegated handler in nsh-app.js that
    // stops propagation.
    $o .= 'rows+="<div class=nsh-rc-actions>";';
    $o .= 'rows+="<button type=button class=\'nsh-btn nsh-btn-xs nsh-btn-outline nsh-copy-details-btn\' data-rid="+req.id+" title=\'Copy Applicant, Academic, Location and Remarks details\'>&#128203; Copy</button>";';
    $o .= 'rows+="<button type=button class=\'nsh-btn nsh-btn-xs nsh-btn-outline nsh-copy-desc-btn\' data-rid="+req.id+" title=\'Copy the Student Requirement Description\'>&#10022; Desc</button>";';
    $o .= 'rows+="<button type=button class=\'nsh-btn nsh-btn-xs nsh-btn-outline nsh-download-docs-btn\' data-rid="+req.id+" title=\'Download all documents for this request\'"+(req.has_docs?"":" disabled")+">&#8595; Docs</button>";';
    $o .= 'rows+="<button onclick=nshDeleteRequest("+req.id+") class=\'nsh-btn nsh-btn-xs nsh-btn-danger-soft\'>Delete</button>";';
    // "View" is a real link (works with no JS, middle-click, open-in-new-tab)
    // but carries nsh-view-request-link + data-rid so nsh-app.js can
    // intercept the click and open the request in-place instead of
    // navigating the whole browser tab away from the dashboard.
    // nsh-btn-primary-soft (nsh-style.css) is a muted/lighter take on
    // the usual solid primary button, per the request for "sober colors
    // instead of dark ones" on this row.
    $o .= 'rows+="<a href="+NSH.home_url+(NSH.dash_base||"/admin-dashboard")+"/request/"+req.id+" class=\'nsh-btn nsh-btn-xs nsh-btn-primary-soft nsh-view-request-link\' data-rid="+req.id+">View Full Request</a>";';
    $o .= 'rows+="</div>";'; // end .nsh-rc-actions
    $o .= 'rows+="</div>";'; // end .nsh-rc-main
    $o .= 'window._nriDescCache[req.id]=req.description||"";';
    $o .= 'rows+="<div class=nsh-rc-side>";';
    $o .= 'rows+="<div class=nsh-rc-side-top><span class=nsh-rc-date>"+req.date+"</span></div>";';
    // Client-facing status AND Internal status, each on its own labeled
    // row ("Status"/"Internal" captions — .nsh-rc-scap) now that the
    // side column is wide enough to afford the extra row without the
    // dead-space problem an earlier pass hit at the old, narrower side
    // width (confirmed by rendering both versions). Both are still
    // inline <select>s, each posting its own change immediately via
    // nshChangeClientStatus()/nshChangeInternalStatus() (defined
    // above), so staff never have to open the request detail page just
    // to move either one along. event.stopPropagation() on
    // click/mousedown keeps a click into either dropdown from also
    // triggering the card\'s own "open request detail" delegated
    // handler. Internal Status is still staff-only, shown ONLY here
    // (the admin request card) and on the management screen, never in
    // any client-facing template, email, or notification (see the
    // "INTERNAL STATUS" section of helpers.php).
    $o .= 'rows+="<div class=nsh-rc-status-group>";';
    $o .= 'rows+="<div class=nsh-rc-status-row><span class=nsh-rc-scap>Status</span><select class=nsh-status-select data-prev=\'"+req.status+"\' style=border-color:"+req.status_color+";color:"+req.status_color+"; onchange=\'nshChangeClientStatus("+req.id+",this.value,this)\' onclick=\'event.stopPropagation()\' onmousedown=\'event.stopPropagation()\'>"+nshClientStatusOptionsHtml(req.status)+"</select></div>";';
    $o .= 'rows+="<div class=nsh-rc-status-row><span class=nsh-rc-scap>Internal</span><select class=\'nsh-istatus-select nsh-istatus-select-top\' data-prev=\'"+req.internal_status+"\' title=\'Internal status (staff only)\' style=border-color:"+req.internal_status_color+";color:"+req.internal_status_color+"; onchange=\'nshChangeInternalStatus("+req.id+",this.value,this)\' onclick=\'event.stopPropagation()\' onmousedown=\'event.stopPropagation()\'>"+nshIStatusOptionsHtml(req.internal_status)+"</select></div>";';
    $o .= 'rows+="</div>";'; // end .nsh-rc-status-group
    // Compact pipeline-progress fill — a quick "how far along is this"
    // glance without opening the request, colored to match the current
    // client status (nshRcProgressPct() defined above).
    $o .= 'rows+="<div class=nsh-rc-progress title=\'Pipeline progress\'><div class=nsh-rc-progress-fill style=\'width:"+nshRcProgressPct(req.status)+"%;background:"+req.status_color+";\'></div></div>";';
    // Admin-operational meta (quote/manager/vendor/delivery) — not part
    // of the client\'s submitted form, so it lives in the side column with
    // the rest of the "handling" info rather than among the form-data
    // groups on the left. Stacked key:value lines (no "|" separators
    // needed now that each has its own row).
    $o .= 'rows+="<div class=nsh-rc-meta>";';
    $o .= 'rows+="<span class=nsh-rc-pair><span class=nsh-rc-lbl>Quote</span><span class=nsh-rc-val>"+req.quote+"</span></span>";';
    $o .= 'rows+="<span class=nsh-rc-pair><span class=nsh-rc-lbl>Delivery</span><span class=nsh-rc-val>"+req.delivery+"</span></span>";';
    $o .= 'rows+="<span class=nsh-rc-pair><span class=nsh-rc-lbl>Manager</span><span class=nsh-rc-val>"+(req.manager&&req.manager!="Unassigned"?req.manager:"—")+"</span></span>";';
    $o .= 'rows+="<span class=nsh-rc-pair><span class=nsh-rc-lbl>Vendor</span><span class=nsh-rc-val>"+(req.vendor&&req.vendor!="Unassigned"?req.vendor:"—")+"</span></span>";';
    $o .= 'rows+="</div>";'; // end .nsh-rc-meta
    $o .= 'rows+="</div>";'; // end .nsh-rc-side
    $o .= 'rows+="</div>";'; // end .nsh-req-card-admin
    $o .= '});';
    $o .= 'tbody.innerHTML=rows||"<div class=nsh-tbl-empty>No requests found.</div>";';
    $o .= 'if(window.nshResetBulkSelection)window.nshResetBulkSelection();';
    $o .= 'document.getElementById("nsh-admin-pages").innerHTML=nshBuildPager(r.data.total,r.data.pages,_page,"nshGoPage");';
    $o .= '}';
    $o .= '});';
    $o .= '}';
    $o .= 'window.nshLoadAdminRequests=nshLoadAdminRequests;';

    // Support tab loader — kept as its own function too, so the SPA
    // controller can call it directly if it wants to (e.g. re-apply a
    // cached status filter) without depending on the button existing yet.
    $o .= 'function nshLoadSupportTickets(){';
    $o .= 'var stbody=document.getElementById("nsh-support-tbody");if(!stbody)return;';
    $o .= 'var stf=document.getElementById("nsh-support-status-filter");var st=stf?stf.value:"";';
    $o .= 'var _stHadRows=stbody.children.length>0;';
    $o .= 'var _stLoadTimer=_stHadRows?null:setTimeout(function(){stbody.innerHTML="<tr><td colspan=8 class=nsh-tbl-loading>Loading...</td></tr>";},200);';
    $o .= 'jQuery.post(NSH.ajax_url,{action:"nsh_get_support_tickets",nonce:NSH.admin_nonce,status:st},function(r){';
    $o .= 'if(_stLoadTimer)clearTimeout(_stLoadTimer);';
    $o .= 'if(!r||!r.success){stbody.innerHTML="<tr><td colspan=8 class=nsh-tbl-empty style=color:#ef4444;>Could not load tickets.</td></tr>";return;}';
    $o .= 'var srows="";';
    $o .= 'r.data.forEach(function(t){';
    $o .= 'srows+="<tr data-tid="+t.id+"><td style=text-align:center><input type=checkbox class=nsh-ticket-bulk-chk value="+t.id+"></td><td><strong>#"+t.id+"</strong></td><td>"+(t.display_name||"Guest")+"</td><td>"+t.category+"</td><td>"+t.notes.substring(0,60)+"...</td>";';
    $o .= 'srows+="<td><span class=nsh-status-chip>"+t.status+"</span></td><td>"+t.created_at.substring(0,10)+"</td>";';
    $o .= 'srows+="<td><select onchange=nshUpdateTicketStatus("+t.id+",this.value) style=font-size:12px;padding:4px;><option value=open "+(t.status=="open"?"selected":"")+">Open</option><option value=in_progress "+(t.status=="in_progress"?"selected":"")+">In Progress</option><option value=resolved "+(t.status=="resolved"?"selected":"")+">Resolved</option><option value=closed "+(t.status=="closed"?"selected":"")+">Closed</option></select> <button onclick=nshDeleteTicket("+t.id+") class=nsh-btn nsh-btn-sm nsh-btn-danger style=margin-left:6px;>Del</button></td></tr>";';
    $o .= '});';
    $o .= 'stbody.innerHTML=srows||"<tr><td colspan=8 class=nsh-tbl-empty>No support tickets.</td></tr>";';
    $o .= 'if(window.nshResetTicketBulkSelection)window.nshResetTicketBulkSelection();';
    $o .= '});';
    $o .= '}';
    $o .= 'window.nshLoadSupportTickets=nshLoadSupportTickets;';

    // Delegated (not direct) bindings: survive the Requests/Support tab
    // content being destroyed and re-created by an AJAX tab-swap, because
    // delegation is registered on document once and matches by selector at
    // click-time rather than by a reference to a specific (possibly now-
    // removed) DOM node.
    //
    // All of this — the delegated bindings AND the very first data load —
    // is wrapped in a readiness-checked init function rather than run
    // immediately. Why: this whole <script> tag is printed inline, in the
    // page body, the FIRST time the admin page loads — but jquery/sortablejs
    // and nsh-app.js are enqueued with in_footer=true (see enqueue.php), so
    // on that very first load they haven't executed yet when this script
    // runs and `jQuery` doesn't exist. Calling jQuery(...) here immediately
    // used to throw a ReferenceError that killed the rest of this script
    // block — including the self-invoking nshLoadAdminRequests() call below
    // — leaving the Requests tab stuck on "Loading..." until something else
    // (an AJAX tab-swap, which runs after nsh-app.js has loaded) called
    // window.nshLoadAdminRequests() again. Deferring to DOMContentLoaded
    // guarantees jQuery/nsh-app.js (synchronous, non-deferred <script>
    // tags) have already run by the time this fires — mirroring the same
    // readyState-check pattern nsh_admin_tab_submissions() already uses.
    $o .= 'function nshInitAdminRequestsTab(){';
    // Filter and Search both apply the current status + search box
    // together (they are not two separate query modes — status alone,
    // search alone, and both combined all go through the same call), each
    // passing restoreState=false so the values just read from the DOM are
    // not immediately clobbered by nshLoadAdminRequests()\'s own cached-state
    // restore (see the comment on that function above).
    $o .= 'jQuery(document).on("click","#nsh-admin-filter-btn,#nsh-admin-search-btn",function(){_status=document.getElementById("nsh-admin-status-f").value;_search=document.getElementById("nsh-admin-search").value;var d=nshReadDateFilter("nsh-admin-date");_dateFilter=d.filter;_dateFrom=d.from;_dateTo=d.to;_page=1;nshLoadAdminRequests(false);});';
    $o .= 'jQuery(document).on("click","#nsh-admin-reset-btn",function(){document.getElementById("nsh-admin-status-f").value="";document.getElementById("nsh-admin-search").value="";var df=document.getElementById("nsh-admin-date-f");if(df)df.value="";var dsp=document.getElementById("nsh-admin-date-specific");if(dsp)dsp.value="";var dfr=document.getElementById("nsh-admin-date-from");if(dfr)dfr.value="";var dto=document.getElementById("nsh-admin-date-to");if(dto)dto.value="";if(window.nshInitDateFilterToggle)window.nshInitDateFilterToggle("nsh-admin-date");_status="";_search="";_dateFilter="";_dateFrom="";_dateTo="";_internalStatus="";_page=1;nshLoadAdminRequests(false);});';
    $o .= 'jQuery(document).on("keypress","#nsh-admin-search",function(e){if(e.which===13){jQuery("#nsh-admin-search-btn").click();}});';
    // Any date-filter choice applies immediately (no separate "apply"
    // click needed for the date filter specifically, matching how the
    // stat-card quick-filters behave) — Specific Date / Custom Range are
    // the exception: those need an actual date typed/picked first, so
    // picking them only reveals the input(s) (nshInitDateFilterToggle
    // above already handles that on its own "change" listener) and
    // doesn\'t fire a request until Filter/Search is clicked or the date
    // input itself changes.
    $o .= 'jQuery(document).on("change","#nsh-admin-date-f",function(){var v=this.value;if(v==="specific_date"||v==="custom_range")return;var d=nshReadDateFilter("nsh-admin-date");_dateFilter=d.filter;_dateFrom=d.from;_dateTo=d.to;_page=1;nshLoadAdminRequests(false);});';
    $o .= 'jQuery(document).on("change","#nsh-admin-date-specific,#nsh-admin-date-from,#nsh-admin-date-to",function(){var d=nshReadDateFilter("nsh-admin-date");if(!d.from&&!d.to)return;_dateFilter=d.filter;_dateFrom=d.from;_dateTo=d.to;_page=1;nshLoadAdminRequests(false);});';
    $o .= 'jQuery(document).on("click","#nsh-load-support-btn",function(){nshLoadSupportTickets();});';
    $o .= 'nshInitDateFilterToggle("nsh-admin-date");';
    // nshLoadAdminRequests() itself is a no-op if #nsh-admin-tbody isn\'t on
    // the page (i.e. a different tab loaded first), so this is safe to call
    // unconditionally. Subsequent tab entries are additionally driven by
    // nsh-app.js's SPA controller calling window.nshLoadAdminRequests()
    // directly (see renderTab() in nsh-app.js) — this call only covers the
    // very first full page load, and DOES want to restore cached state
    // (the default), since it\'s a tab-entry, not an explicit user action.
    $o .= 'nshLoadAdminRequests();';
    $o .= '}';
    $o .= 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",nshInitAdminRequestsTab);}else{nshInitAdminRequestsTab();}';

    nsh_output_admin_script( $o, false );
    return '';
}

/* ============================================================
   HELPER: Form Details pane (used inside nsh_sc_request_view)
   ============================================================ */
function nsh_render_form_details_pane( $rid, $fd, $docs, $is_staff, $meta ) {
    global $wpdb;
    $fields_rows = $wpdb->get_results( "SELECT field_key, field_label, field_type FROM {$wpdb->prefix}nsh_fields ORDER BY sort_order ASC" );
    $label_map   = array();
    $type_map    = array();
    foreach ( $fields_rows as $fr ) {
        $label_map[ 'field_' . $fr->field_key ] = $fr->field_label;
        $type_map[  'field_' . $fr->field_key ] = $fr->field_type;
    }

    $req_label = $meta['request_id'] ? $meta['request_id'] : '#' . $rid;

    $o  = '<div id="nsh-ot-formdetails" class="nsh-ot-pane" style="display:none;">';
    $o .= '<div class="nsh-panel-card" style="margin:0;">';

    // Download bar — uses modern nsh_export_submission handler (same as Submissions section)
    $export_base_args = array(
        'nonce'      => wp_create_nonce( 'nsh_admin_nonce' ),
        'request_id' => $rid,
    );
    $exp_pdf   = esc_url( add_query_arg( array_merge( $export_base_args, array( 'action' => 'nsh_export_submission', 'format' => 'pdf'  ) ), admin_url( 'admin-ajax.php' ) ) );
    $exp_png   = esc_url( add_query_arg( array_merge( $export_base_args, array( 'action' => 'nsh_export_submission', 'format' => 'png'  ) ), admin_url( 'admin-ajax.php' ) ) );
    $exp_docx  = esc_url( add_query_arg( array_merge( $export_base_args, array( 'action' => 'nsh_export_submission', 'format' => 'docx' ) ), admin_url( 'admin-ajax.php' ) ) );
    $exp_xlsx  = esc_url( add_query_arg( array_merge( $export_base_args, array( 'action' => 'nsh_export_submission', 'format' => 'xlsx' ) ), admin_url( 'admin-ajax.php' ) ) );

    $o .= '<div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:20px;padding:14px 16px;background:#f8fafc;border-radius:10px;border:1px solid #e2e8f0;align-items:center;">';
    $o .= '<span style="font-size:13px;font-weight:600;color:#475569;margin-right:4px;">&#8595; Download As:</span>';
    $o .= '<a href="' . $exp_pdf  . '" target="_blank" class="nsh-btn nsh-btn-primary nsh-btn-sm">&#128196; PDF</a>';
    $o .= '<a href="' . $exp_png  . '" target="_blank" class="nsh-btn nsh-btn-outline nsh-btn-sm">&#128247; PNG / Image</a>';
    if ( $is_staff ) {
        $o .= '<a href="' . $exp_docx . '" class="nsh-btn nsh-btn-outline nsh-btn-sm">&#128221; Word (.docx)</a>';
        $o .= '<a href="' . $exp_xlsx . '" class="nsh-btn nsh-btn-outline nsh-btn-sm">&#128202; Excel (.xlsx)</a>';
    }
    $o .= '</div>';

    // Student Requirement Description — the internal, deterministic
    // rule-based summary engine (nsh_generate_requirement_description()
    // in helpers.php); never an external AI call. Shown for both staff
    // and the client, but editing/regenerating is staff-only.
    $req_desc = nsh_get_requirement_description( $rid, $meta );
    $o .= '<div class="nsh-req-desc-panel" data-rid="' . intval( $rid ) . '">';
    $o .= '<div class="nsh-req-desc-hdr"><h4>&#10022; Student Requirement Description</h4>';
    $o .= '<span class="nsh-req-desc-badge ' . ( $req_desc['is_manual'] ? 'nsh-req-desc-manual' : 'nsh-req-desc-auto' ) . '">' . ( $req_desc['is_manual'] ? 'Manually Edited' : 'Auto-Generated' ) . '</span>';
    if ( $req_desc['stale'] ) {
        $o .= '<span class="nsh-req-desc-badge nsh-req-desc-stale" title="The request\'s form data has changed since this description was last generated/saved.">Source data changed</span>';
    }
    $o .= '</div>';
    $o .= '<div class="nsh-req-desc-text" id="nsh-req-desc-text-' . intval( $rid ) . '">' . nl2br( esc_html( $req_desc['text'] ) ) . '</div>';
    if ( $is_staff ) {
        $o .= '<textarea class="nsh-req-desc-edit" id="nsh-req-desc-edit-' . intval( $rid ) . '" style="display:none;">' . esc_textarea( $req_desc['text'] ) . '</textarea>';
    }
    $o .= '<div class="nsh-req-desc-actions">';
    $o .= '<button type="button" class="nsh-btn nsh-btn-sm nsh-btn-outline nsh-copy-desc-btn" data-rid="' . intval( $rid ) . '" data-desc-text="' . esc_attr( $req_desc['text'] ) . '">&#10022; Copy Description</button>';
    if ( $is_staff ) {
        $o .= '<button type="button" class="nsh-btn nsh-btn-sm nsh-btn-ghost nsh-regen-desc-btn" data-rid="' . intval( $rid ) . '" data-manual="' . ( $req_desc['is_manual'] ? '1' : '0' ) . '">&#8635; Regenerate</button>';
        $o .= '<button type="button" class="nsh-btn nsh-btn-sm nsh-btn-ghost nsh-edit-desc-btn" data-rid="' . intval( $rid ) . '">&#9998; Edit</button>';
        $o .= '<button type="button" class="nsh-btn nsh-btn-sm nsh-btn-primary nsh-save-desc-btn" data-rid="' . intval( $rid ) . '" style="display:none;">Save</button>';
        $o .= '<button type="button" class="nsh-btn nsh-btn-sm nsh-btn-ghost nsh-cancel-desc-btn" data-rid="' . intval( $rid ) . '" style="display:none;">Cancel</button>';
    }
    $o .= '</div></div>';

    // The printable content wrapper
    $o .= '<div id="nsh-formdetail-printable-' . intval( $rid ) . '">';

    // Form fields
    $o .= '<h4 style="font-size:15px;font-weight:700;color:#1e293b;margin:0 0 14px;border-bottom:2px solid #e2e8f0;padding-bottom:8px;">&#128203; Submitted Form Data</h4>';
    $o .= '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:10px;margin-bottom:24px;">';
    foreach ( $fd as $key => $val ) {
        if ( $key === 'field_documents' ) { continue; }
        $label   = isset( $label_map[ $key ] ) ? $label_map[ $key ] : ucwords( str_replace( array( 'field_', '_' ), array( '', ' ' ), $key ) );
        $display = is_array( $val ) ? implode( ', ', $val ) : (string) $val;
        if ( $display === '' ) { continue; }
        $o .= '<div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px 12px;">';
        $o .= '<div style="font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:3px;">' . esc_html( $label ) . '</div>';
        $o .= '<div style="font-size:14px;color:#1e293b;font-weight:500;">' . esc_html( $display ) . '</div>';
        $o .= '</div>';
    }
    $o .= '</div>';

    // Documents — with multiselect + bulk download
    if ( ! empty( $docs ) ) {
        $o .= '<h4 style="font-size:15px;font-weight:700;color:#1e293b;margin:0 0 10px;border-bottom:2px solid #e2e8f0;padding-bottom:8px;">&#128196; Uploaded Documents (' . count( $docs ) . ')</h4>';
        // Bulk toolbar
        $o .= '<div style="display:flex;align-items:center;gap:8px;padding:8px 12px;background:#f1f5f9;border-radius:8px;margin-bottom:10px;flex-wrap:wrap;">';
        $o .= '<label style="display:flex;align-items:center;gap:6px;font-size:13px;color:#475569;cursor:pointer;">';
        $o .= '<input type="checkbox" id="nsh-fd-sel-all" style="width:15px;height:15px;"> Select All</label>';
        $o .= '<button class="nsh-btn nsh-btn-sm nsh-btn-outline" id="nsh-fd-dl-selected" data-rid="' . intval($rid) . '" style="display:none;">&#8595; Download Selected</button>';
        $o .= '<button class="nsh-btn nsh-btn-sm nsh-btn-ghost" id="nsh-fd-dl-all" data-rid="' . intval($rid) . '">&#8595; Download All</button>';
        $o .= '<button type="button" class="nsh-btn nsh-btn-ghost nsh-btn-sm nsh-change-save-folder" title="Documents currently save into a remembered folder. Click to choose a different one for future downloads.">&#128193; Change Folder</button>';
        if ( $is_staff ) {
            $o .= '<button class="nsh-btn nsh-btn-sm nsh-btn-danger" id="nsh-fd-del-selected" data-rid="' . intval($rid) . '" style="display:none;margin-left:auto;">&#128465; Delete Selected</button>';
        }
        $o .= '</div>';
        $o .= '<div style="display:flex;flex-direction:column;gap:8px;" id="nsh-fd-docs-list">';
        foreach ( $docs as $d ) {
            $att_id  = isset( $d['file'] )     ? intval( $d['file'] ) : 0;
            $dl_url  = $att_id ? nsh_get_download_url( $att_id ) : '';
            $raw_url = $att_id ? wp_get_attachment_url( $att_id ) : '';
            $fn      = $att_id ? basename( get_attached_file( $att_id ) ) : '';
            // If file is AVIF/WebP, show .png as the display name since proxy converts it
            if ( $att_id ) {
                $fn_ext = strtolower( pathinfo( $fn, PATHINFO_EXTENSION ) );
                if ( in_array( $fn_ext, array( 'avif', 'webp' ), true ) ) {
                    $fn = pathinfo( $fn, PATHINFO_FILENAME ) . '.png';
                }
            }
            $dtype   = isset( $d['doc_type'] ) ? $d['doc_type'] : 'Document';
            $is_prov = ! empty( $d['is_provider'] );
            $mime    = $att_id ? get_post_mime_type( $att_id ) : '';
            $icon    = ( strpos( $mime, 'image' ) !== false ) ? '&#128247;' : '&#128196;';
            $badge_bg = $is_prov ? '#dbeafe' : '#dcfce7';
            $badge_c  = $is_prov ? '#1d4ed8' : '#166534';
            $badge = '<span style="font-size:10px;background:' . $badge_bg . ';color:' . $badge_c . ';padding:2px 8px;border-radius:10px;font-weight:600;">' . ( $is_prov ? 'Provider' : 'Client' ) . '</span>';
            $o .= '<div class="nsh-fd-doc-row" style="display:flex;align-items:center;gap:10px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px 14px;" data-att-id="' . $att_id . '" data-url="' . esc_attr($dl_url) . '" data-filename="' . esc_attr($fn) . '">';
            $o .= '<input type="checkbox" class="nsh-fd-doc-chk" data-att-id="' . $att_id . '" data-url="' . esc_attr($dl_url) . '" data-filename="' . esc_attr($fn) . '" style="width:15px;height:15px;flex-shrink:0;">';
            $o .= '<span style="font-size:20px;flex-shrink:0;">' . $icon . '</span>';
            $o .= '<div style="flex:1;min-width:0;"><div style="font-weight:600;font-size:13px;color:#1e293b;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' . esc_html($dtype) . '</div>';
            $o .= '<div style="font-size:12px;color:#64748b;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' . esc_html($fn) . '</div></div>';
            $o .= $badge;
            if ( $dl_url ) {
                $o .= '<a href="' . esc_url($dl_url) . '" class="nsh-btn nsh-btn-sm nsh-btn-outline" style="flex-shrink:0;" title="Download">&#8595; Download</a>';
                $o .= '<a href="' . esc_url($raw_url) . '" target="_blank" class="nsh-btn nsh-btn-sm nsh-btn-ghost" style="flex-shrink:0;" title="View in browser">&#128065;</a>';
            }
            if ( $is_staff && $att_id ) {
                $o .= '<button class="nsh-btn nsh-btn-sm nsh-btn-danger nsh-fd-doc-del" data-rid="' . intval($rid) . '" data-att-id="' . intval($att_id) . '" style="flex-shrink:0;" title="Delete this file">&#128465;</button>';
            }
            $o .= '</div>';
        }
        $o .= '</div>';
    } else {
        $o .= '<p class="nsh-hint">No documents uploaded yet.</p>';
    }

    $o .= '</div>'; // end printable
    $o .= '</div>'; // end panel-card

    // Export buttons now use direct links to nsh_export_submission (see download bar above)

    $o .= '</div>'; // end pane
    return $o;
}

/* ============================================================
   SHORTCODE: SERVICES
   ============================================================ */

add_shortcode( 'nsh_services', 'nsh_sc_services' );
function nsh_sc_services( $atts ) {
    $services = nsh_get_services( true );
    $grouped  = array();
    foreach ( $services as $s ) { $grouped[ $s->category ][] = $s; }
    $cat_names = nsh_service_categories();
    $submit    = nsh_request_submit_url();
    $count     = count( $services );

    // Visa-related services get a highlighted look: any service in the
    // "immigration" category, or whose name mentions visa.
    $is_visa = function ( $s ) { return $s->category === 'immigration' || stripos( $s->name, 'visa' ) !== false; };

    $o  = '<div class="nsh-svx">';
    $o .= '<section class="nsh-svx-hero"><div class="nsh-svx-hero-in">';
    $o .= '<p class="nsh-svx-eyebrow">Our services</p>';
    $o .= '<h1 class="nsh-svx-title">Everything you need, handled <span>end to end</span></h1>';
    $o .= '<p class="nsh-svx-sub">Choose a service, answer a few guided steps and track your request from review to delivery.</p>';
    $o .= '<ul class="nsh-svx-stats"><li><strong>' . intval( $count ) . '</strong><span>services</span></li><li><strong>' . intval( count( $grouped ) ) . '</strong><span>categories</span></li><li><strong>100%</strong><span>online process</span></li></ul>';
    $o .= '</div></section>';

    $o .= '<nav class="nsh-svx-chips" aria-label="Service categories">';
    foreach ( $grouped as $cat_slug => $rows ) {
        $nm = isset( $cat_names[ $cat_slug ] ) ? $cat_names[ $cat_slug ]['name'] : ucfirst( $cat_slug );
        $ic = isset( $cat_names[ $cat_slug ]['icon'] ) ? $cat_names[ $cat_slug ]['icon'] : '';
        $o .= '<a class="nsh-svx-chip" href="#nsh-svx-' . esc_attr( $cat_slug ) . '">' . ( $ic ? '<span aria-hidden="true">' . esc_html( $ic ) . '</span>' : '' ) . esc_html( $nm ) . '<em>' . intval( count( $rows ) ) . '</em></a>';
    }
    $o .= '</nav>';

    foreach ( $grouped as $cat_slug => $rows ) {
        $nm = isset( $cat_names[ $cat_slug ] ) ? $cat_names[ $cat_slug ]['name'] : ucfirst( $cat_slug );
        $ic = isset( $cat_names[ $cat_slug ]['icon'] ) ? $cat_names[ $cat_slug ]['icon'] : '';
        $o .= '<section class="nsh-svx-sec' . ( $cat_slug === 'immigration' ? ' is-visa' : '' ) . '" id="nsh-svx-' . esc_attr( $cat_slug ) . '" aria-labelledby="nsh-svx-h-' . esc_attr( $cat_slug ) . '">';
        $o .= '<h2 class="nsh-svx-sec-h nsh-svc-cat-title" id="nsh-svx-h-' . esc_attr( $cat_slug ) . '">' . ( $ic ? '<span class="nsh-svx-sec-ic" aria-hidden="true">' . esc_html( $ic ) . '</span>' : '' ) . esc_html( $nm ) . '</h2>';
        $o .= '<div class="nsh-svx-grid">';
        foreach ( $rows as $s ) {
            $o .= '<article class="nsh-svx-card' . ( $is_visa( $s ) ? ' is-visa' : '' ) . '">';
            $o .= '<div class="nsh-svx-card-top"><span class="nsh-svx-ic" aria-hidden="true">' . ( $ic ? esc_html( $ic ) : '&#128196;' ) . '</span>';
            if ( $is_visa( $s ) ) { $o .= '<span class="nsh-svx-badge">Visa &amp; travel</span>'; }
            $o .= '</div>';
            $o .= '<h3 class="nsh-svx-name">' . esc_html( $s->name ) . '</h3>';
            $o .= '<p class="nsh-svx-desc">' . esc_html( $s->short_desc ) . '</p>';
            $o .= '<div class="nsh-svx-foot"><span class="nsh-svx-time">&#9201; ~' . intval( $s->turnaround_days ) . ' working days</span>';
            $o .= '<a href="' . esc_url( add_query_arg( 'service', $s->slug, $submit ) ) . '" class="nsh-svx-go" aria-label="Get started with ' . esc_attr( $s->name ) . '">Get started <span aria-hidden="true">&rarr;</span></a></div>';
            $o .= '</article>';
        }
        $o .= '</div></section>';
    }
    if ( empty( $grouped ) ) { $o .= '<p class="nsh-svx-empty">Services will appear here soon.</p>'; }
    $o .= '</div>';
    return $o;
}
