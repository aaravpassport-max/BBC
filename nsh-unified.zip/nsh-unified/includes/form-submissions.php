<?php
/**
 * NRI Services Hub – Form Submissions Viewer & Exporter
 * Adds: admin tab, per-request detail modal, and download in PDF / Image / Word.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

// ─────────────────────────────────────────────────────────────────────────────
// AJAX: get full form-submission detail for one request
// ─────────────────────────────────────────────────────────────────────────────
add_action( 'wp_ajax_nsh_get_submission_detail', 'nsh_ajax_get_submission_detail' );
function nsh_ajax_get_submission_detail() {
    nsh_check_nonce();
    nsh_require_staff();

    $rid = intval( isset( $_POST['request_id'] ) ? $_POST['request_id'] : 0 );
    if ( ! $rid ) { wp_send_json_error( array( 'message' => 'Invalid request ID.' ) ); }

    $post   = get_post( $rid );
    if ( ! $post || $post->post_type !== 'nsh_request' ) {
        wp_send_json_error( array( 'message' => 'Request not found.' ) );
    }

    $meta   = nsh_get_meta( $rid );
    $author = get_userdata( $post->post_author );
    $fd     = $meta['field_data'];     // raw field_data array saved at submission time
    $docs   = nsh_get_documents( $rid );
    $history = nsh_get_history( $rid );

    // Build field labels map from the nsh_fields table so we can show human labels
    global $wpdb;
    $fields_rows = $wpdb->get_results( "SELECT field_key, field_label, field_type FROM {$wpdb->prefix}nsh_fields ORDER BY sort_order ASC" );
    $label_map   = array();
    $type_map    = array();
    foreach ( $fields_rows as $fr ) {
        $label_map[ 'field_' . $fr->field_key ] = $fr->field_label;
        $type_map[  'field_' . $fr->field_key ] = $fr->field_type;
    }

    // Build structured fields list
    $fields_out = array();
    foreach ( $fd as $key => $val ) {
        if ( $key === 'field_documents' ) { continue; } // handled separately
        $label = isset( $label_map[ $key ] ) ? $label_map[ $key ] : ucwords( str_replace( array( 'field_', '_' ), array( '', ' ' ), $key ) );
        $type  = isset( $type_map[ $key ] )  ? $type_map[ $key ]  : 'text';
        $fields_out[] = array(
            'key'   => $key,
            'label' => $label,
            'type'  => $type,
            'value' => is_array( $val ) ? implode( ', ', $val ) : (string) $val,
        );
    }

    // Build documents list
    $docs_out = array();
    foreach ( $docs as $d ) {
        $att_id  = isset( $d['file'] ) ? intval( $d['file'] ) : 0;
        // dl_url  → proxied secure download (forces Content-Disposition: attachment)
        // view_url → raw URL for in-browser viewing (PDF viewer, image preview)
        $dl_url  = $att_id && function_exists( 'nsh_get_download_url' ) ? nsh_get_download_url( $att_id ) : ( $att_id ? wp_get_attachment_url( $att_id ) : '' );
        $view_url = $att_id ? wp_get_attachment_url( $att_id ) : '';
        $fn      = $att_id ? basename( get_attached_file( $att_id ) ) : '';
        // Show .png as filename if file is AVIF/WebP — proxy converts it on download
        if ( $fn ) {
            $fn_ext = strtolower( pathinfo( $fn, PATHINFO_EXTENSION ) );
            if ( in_array( $fn_ext, array( 'avif', 'webp' ), true ) ) {
                $fn = pathinfo( $fn, PATHINFO_FILENAME ) . '.png';
            }
        }
        $mime    = $att_id ? get_post_mime_type( $att_id ) : '';
        $docs_out[] = array(
            'att_id'      => $att_id,
            'doc_type'    => isset( $d['doc_type'] )    ? $d['doc_type']    : 'Document',
            'is_provider' => isset( $d['is_provider'] ) ? $d['is_provider'] : 0,
            'url'         => $dl_url,   // proxied — used by download buttons
            'view_url'    => $view_url, // raw — used by View (open in browser) buttons
            'filename'    => $fn,
            'mime'        => $mime,
        );
    }

    // Manager / vendor info
    $mgr_uid = $meta['assigned_manager'];
    $vnd_uid = $meta['assigned_vendor'];
    $mgr     = $mgr_uid ? get_userdata( $mgr_uid ) : null;
    $vnd     = $vnd_uid ? get_userdata( $vnd_uid ) : null;

    wp_send_json_success( array(
        'post_id'        => $rid,
        'request_id'     => $meta['request_id'] ? $meta['request_id'] : '#' . $rid,
        'submitted_at'   => get_the_date( 'd M Y, g:i a', $rid ),
        'status'         => $meta['status'],
        'status_label'   => nsh_status_label( $meta['status'] ),
        'status_color'   => nsh_status_color( $meta['status'] ),
        'payment_status' => $meta['payment_status'],
        'quote_amount'   => $meta['quote_amount'] ? 'INR ' . number_format( (float) $meta['quote_amount'], 2 ) : '',
        'delivery'       => $meta['estimated_delivery'] ? date( 'd M Y', strtotime( $meta['estimated_delivery'] ) ) : '',
        'secondary_status' => $meta['secondary_status'],
        'internal_notes' => $meta['internal_notes'],
        'client_name'    => $author ? $author->display_name : 'Unknown',
        'client_email'   => $author ? $author->user_email   : '',
        'manager'        => $mgr ? $mgr->display_name : '',
        'vendor'         => $vnd ? $vnd->display_name : '',
        'fields'         => $fields_out,
        'documents'      => $docs_out,
        'history'        => array_slice( array_reverse( $history ), 0, 20 ),
    ) );
}

// ─────────────────────────────────────────────────────────────────────────────
// AJAX: list all submissions (paginated) – used by the new admin tab
// ─────────────────────────────────────────────────────────────────────────────
add_action( 'wp_ajax_nsh_list_submissions', 'nsh_ajax_list_submissions' );
function nsh_ajax_list_submissions() {
    nsh_check_nonce();
    nsh_require_staff();

    $search   = sanitize_text_field( isset( $_POST['search'] ) ? $_POST['search'] : '' );
    $paged    = max( 1, intval( isset( $_POST['paged'] ) ? $_POST['paged'] : 1 ) );
    $per_page = 25;

    $date_filter = sanitize_key( isset( $_POST['date_filter'] ) ? $_POST['date_filter'] : '' );
    $date_from   = sanitize_text_field( isset( $_POST['date_from'] ) ? $_POST['date_from'] : '' );
    $date_to     = sanitize_text_field( isset( $_POST['date_to'] )   ? $_POST['date_to']   : '' );
    list( $date_after, $date_before ) = nsh_compute_request_date_range( $date_filter, $date_from, $date_to );

    if ( $search === '' ) {
        // FAST PATH — same reasoning as nsh_ajax_get_requests()'s fast path
        // in ajax.php: real SQL-level LIMIT/OFFSET pagination via WP_Query,
        // no full-table ID fetch. This is the common case.
        $args = array(
            'post_type'      => 'nsh_request',
            'post_status'    => 'publish',
            'posts_per_page' => $per_page,
            'paged'          => $paged,
            'orderby'        => 'date',
            'order'          => 'DESC',
        );
        $date_query = nsh_request_date_query( $date_after, $date_before );
        if ( $date_query ) { $args['date_query'] = $date_query; }
        $q        = new WP_Query( $args );
        $page_ids = wp_list_pluck( $q->posts, 'ID' );
        $total    = $q->found_posts;
        $pages    = $q->max_num_pages ? $q->max_num_pages : 1;
    } else {
        // SEARCH PATH — same comprehensive, multi-term meta+author search
        // as the Requests tab, via the shared, transient-cached
        // nsh_search_matching_request_ids() (ajax.php) — WP_Query's 's'
        // parameter only matches post_title/post_content and misses the
        // submitted form data entirely, which is what "search by client or
        // service" actually needs to reach. No status filter applies on
        // this tab, so it's always called with an empty status.
        list( $matched_ids, $total ) = nsh_search_matching_request_ids( '', $search, $date_after, $date_before );
        $pages    = max( 1, (int) ceil( $total / $per_page ) );
        $page_ids = array_slice( $matched_ids, ( $paged - 1 ) * $per_page, $per_page );
    }

    $out = array();
    foreach ( $page_ids as $pid ) {
        $p      = get_post( $pid );
        $meta   = nsh_get_meta( $pid );
        $author = get_userdata( $p->post_author );
        $fd     = $meta['field_data'];
        $svc    = ! empty( $meta['service_name'] ) ? $meta['service_name']
                : ( ! empty( $fd['field_service_type']  ) ? $fd['field_service_type']
                : ( ! empty( $fd['field_document_type'] ) ? $fd['field_document_type'] : 'Request' ) );
        $docs   = nsh_get_documents( $pid );

        $out[] = array(
            'id'           => $pid,
            'request_id'   => $meta['request_id'] ? $meta['request_id'] : '#' . $pid,
            'client'       => $author ? $author->display_name : '?',
            'email'        => $author ? $author->user_email   : '',
            'service'      => wp_trim_words( $svc, 6, '' ),
            'status'       => $meta['status'],
            'status_label' => nsh_status_label( $meta['status'] ),
            'status_color' => nsh_status_color( $meta['status'] ),
            'doc_count'    => count( $docs ),
            'date'         => get_the_date( 'd M Y', $pid ),
        );
    }

    wp_send_json_success( array(
        'submissions' => $out,
        'total'       => $total,
        'pages'       => $pages,
    ) );
}

// ─────────────────────────────────────────────────────────────────────────────
// AJAX: generate a Word (.docx) export – uses a pure-PHP XML approach
// ─────────────────────────────────────────────────────────────────────────────
/* ════════════════════════════════════════════════════════════════════════════
   UNIFIED EXPORT HANDLER — supports PDF, PNG, DOCX, XLSX
   URL: /wp-admin/admin-ajax.php?action=nsh_export_submission
        &format=pdf|png|docx|xlsx&request_id=123&nonce=...
═══════════════════════════════════════════════════════════════════════════ */
add_action( 'wp_ajax_nsh_export_submission', 'nsh_ajax_export_submission' );
function nsh_ajax_export_submission() {
    $nonce = sanitize_text_field( isset( $_GET['nonce'] ) ? $_GET['nonce'] : '' );
    if ( ! wp_verify_nonce( $nonce, 'nsh_admin_nonce' ) ) { wp_die( 'Security check failed.' ); }
    if ( ! nsh_is_staff() ) { wp_die( 'Access denied.' ); }

    $rid    = intval( isset( $_GET['request_id'] ) ? $_GET['request_id'] : 0 );
    $format = sanitize_text_field( isset( $_GET['format'] ) ? $_GET['format'] : 'pdf' );
    if ( ! $rid ) { wp_die( 'Invalid request.' ); }

    $post = get_post( $rid );
    if ( ! $post || $post->post_type !== 'nsh_request' ) { wp_die( 'Request not found.' ); }

    $meta    = nsh_get_meta( $rid );
    $author  = get_userdata( $post->post_author );
    $fd      = $meta['field_data'];
    $docs    = nsh_get_documents( $rid );
    $history = nsh_get_history( $rid );

    global $wpdb;
    $fields_rows = $wpdb->get_results( "SELECT field_key, field_label FROM {$wpdb->prefix}nsh_fields ORDER BY sort_order ASC" );
    $label_map   = array();
    foreach ( $fields_rows as $fr ) { $label_map[ 'field_' . $fr->field_key ] = $fr->field_label; }

    $req_id   = $meta['request_id'] ? $meta['request_id'] : '#' . $rid;
    $filename = 'submission-' . sanitize_file_name( $req_id );

    switch ( $format ) {
        case 'docx':
            $docx = nsh_build_docx( $req_id, $meta, $author, $fd, $label_map, $docs, $history );
            header( 'Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document' );
            header( 'Content-Disposition: attachment; filename="' . $filename . '.docx"' );
            header( 'Content-Length: ' . strlen( $docx ) );
            header( 'Cache-Control: no-store' );
            echo $docx;
            exit;

        case 'xlsx':
            $xlsx = nsh_build_xlsx( $req_id, $meta, $author, $fd, $label_map, $docs, $history );
            header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
            header( 'Content-Disposition: attachment; filename="' . $filename . '.xlsx"' );
            header( 'Content-Length: ' . strlen( $xlsx ) );
            header( 'Cache-Control: no-store' );
            echo $xlsx;
            exit;

        case 'pdf':
            $html = nsh_build_submission_html( $req_id, $meta, $author, $fd, $label_map, $docs, $history );
            // Serve as HTML with print-on-load — browser prints to PDF reliably with no library
            header( 'Content-Type: text/html; charset=utf-8' );
            header( 'Cache-Control: no-store' );
            echo $html;
            exit;

        case 'png':
            $html = nsh_build_submission_html( $req_id, $meta, $author, $fd, $label_map, $docs, $history, true );
            header( 'Content-Type: text/html; charset=utf-8' );
            header( 'Cache-Control: no-store' );
            echo $html;
            exit;

        default:
            wp_die( 'Unknown format: ' . esc_html( $format ) );
    }
}

/**
 * Build a polished printable HTML page for PDF/PNG export.
 * For PDF: auto-triggers window.print() on load.
 * For PNG: shows a "Download as PNG" button using html2canvas (loaded inline).
 */
function nsh_build_submission_html( $req_id, $meta, $author, $fd, $label_map, $docs, $history, $png_mode = false ) {
    $x = function( $s ) { return htmlspecialchars( (string) $s, ENT_QUOTES, 'UTF-8' ); };

    $rows_html = '';
    foreach ( $fd as $key => $val ) {
        if ( $key === 'field_documents' ) { continue; }
        $label   = isset( $label_map[ $key ] ) ? $label_map[ $key ] : ucwords( str_replace( array( 'field_', '_' ), array( '', ' ' ), $key ) );
        $display = is_array( $val ) ? implode( ', ', $val ) : (string) $val;
        if ( $display === '' ) { $display = '—'; }
        $rows_html .= '<div class="row"><div class="lbl">' . $x( $label ) . '</div><div class="val">' . $x( $display ) . '</div></div>';
    }

    $docs_html = '';
    if ( $docs ) {
        $docs_html = '<h2>Uploaded Documents</h2><ul>';
        foreach ( $docs as $d ) {
            $att_id = isset( $d['file'] ) ? intval( $d['file'] ) : 0;
            $fn     = $att_id ? basename( get_attached_file( $att_id ) ) : 'unknown';
            $dtype  = isset( $d['doc_type'] ) ? $d['doc_type'] : 'Document';
            $by     = ! empty( $d['is_provider'] ) ? 'Provider' : 'Client';
            $docs_html .= '<li><strong>' . $x( $dtype ) . '</strong> (' . $x( $by ) . ') – ' . $x( $fn ) . '</li>';
        }
        $docs_html .= '</ul>';
    }

    $hist_html = '';
    if ( $history ) {
        $hist_html = '<h2>Activity History</h2><ul>';
        foreach ( array_slice( array_reverse( $history ), 0, 30 ) as $h ) {
            $hist_html .= '<li>[' . $x( isset( $h['time'] ) ? $h['time'] : '' ) . '] ' . $x( isset( $h['event'] ) ? $h['event'] : '' );
            if ( ! empty( $h['note'] ) ) { $hist_html .= ' – ' . $x( $h['note'] ); }
            $hist_html .= '</li>';
        }
        $hist_html .= '</ul>';
    }

    $client_name  = $author ? $author->display_name : 'N/A';
    $client_email = $author ? $author->user_email   : 'N/A';
    $status       = nsh_status_label( $meta['status'] );
    $generated    = date( 'd M Y, g:i a' );

    // Auto-print on load for PDF mode; for PNG mode, show a button to capture
    if ( $png_mode ) {
        $autoscript = '<script src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js"></script>
<script>
window.addEventListener("load",function(){
  setTimeout(function(){
    var el=document.getElementById("printable");
    html2canvas(el,{scale:2,backgroundColor:"#ffffff",useCORS:true,logging:false}).then(function(canvas){
      var link=document.createElement("a");
      link.download="submission-' . esc_js( $req_id ) . '.png";
      link.href=canvas.toDataURL("image/png");
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    });
  },400);
});
</script>';
    } else {
        $autoscript = '<script>window.addEventListener("load",function(){setTimeout(function(){window.print();},500);});</script>';
    }

    return '<!DOCTYPE html>
<html><head><meta charset="UTF-8">
<title>Submission ' . $x( $req_id ) . '</title>
<style>
* { box-sizing: border-box; }
body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Calibri, Arial, sans-serif; font-size: 13px; color: #1e293b; padding: 32px 40px; max-width: 820px; margin: 0 auto; background: #fff; line-height: 1.5; }
.header { background: linear-gradient(135deg, #4f46e5, #7c3aed); color: #fff; padding: 28px 32px; border-radius: 12px; margin-bottom: 28px; }
.header h1 { margin: 0 0 6px; font-size: 24px; font-weight: 700; }
.header .meta { font-size: 13px; opacity: .85; margin: 0; }
h2 { font-size: 16px; color: #4f46e5; margin: 28px 0 12px; padding-bottom: 8px; border-bottom: 2px solid #e2e8f0; font-weight: 700; }
.row { display: flex; gap: 16px; padding: 10px 14px; border-bottom: 1px solid #f1f5f9; }
.row:nth-child(odd) { background: #f8fafc; }
.lbl { flex: 0 0 200px; font-size: 11px; font-weight: 700; color: #64748b; text-transform: uppercase; letter-spacing: .04em; }
.val { flex: 1; font-size: 14px; color: #1e293b; word-break: break-word; }
.client-card { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 16px; }
.client-card .item { background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px 14px; }
.client-card .item .lbl { flex: none; }
.client-card .item .val { margin-top: 4px; }
ul { margin: 0; padding-left: 22px; }
li { margin-bottom: 6px; font-size: 13px; }
@media print { body { padding: 12px; } .header { box-shadow: none; -webkit-print-color-adjust: exact; print-color-adjust: exact; } }
</style>
' . $autoscript . '
</head><body>
<div id="printable">
<div class="header">
  <h1>NRI Services Hub — Form Submission</h1>
  <p class="meta">Request ID: <strong>' . $x( $req_id ) . '</strong> &nbsp;·&nbsp; Generated: ' . $x( $generated ) . '</p>
</div>

<h2>Client Information</h2>
<div class="client-card">
  <div class="item"><div class="lbl">Name</div><div class="val">' . $x( $client_name ) . '</div></div>
  <div class="item"><div class="lbl">Email</div><div class="val">' . $x( $client_email ) . '</div></div>
  <div class="item"><div class="lbl">Status</div><div class="val">' . $x( $status ) . '</div></div>
</div>

<h2>Submitted Form Data</h2>
' . $rows_html . '

' . $docs_html . '
' . $hist_html . '
</div>
</body></html>';
}

/**
 * Build a real .xlsx file (Office 2007+) using PHP ZipArchive.
 * Modern Excel/LibreOffice/Google Sheets all open this perfectly.
 */
function nsh_build_xlsx( $req_id, $meta, $author, $fd, $label_map, $docs, $history ) {
    $x = function( $s ) { return htmlspecialchars( (string) $s, ENT_XML1, 'UTF-8' ); };

    // ── Build the rows we want in the spreadsheet ─────────────────────────────
    $rows = array();
    $rows[] = array( 'Section', 'Field', 'Value' );
    $rows[] = array( 'Header',  'Request ID',     $req_id );
    $rows[] = array( 'Header',  'Generated',      date( 'd M Y, g:i a' ) );
    $rows[] = array( '',        '',               '' );
    $rows[] = array( 'Client',  'Name',           $author ? $author->display_name : 'N/A' );
    $rows[] = array( 'Client',  'Email',          $author ? $author->user_email   : 'N/A' );
    $rows[] = array( 'Client',  'Status',         nsh_status_label( $meta['status'] ) );
    if ( $meta['quote_amount'] ) {
        $rows[] = array( 'Client', 'Quote (INR)',  number_format( (float) $meta['quote_amount'], 2 ) );
    }
    if ( $meta['estimated_delivery'] ) {
        $rows[] = array( 'Client', 'Est. Delivery', date( 'd M Y', strtotime( $meta['estimated_delivery'] ) ) );
    }
    $rows[] = array( '',        '',               '' );
    $rows[] = array( 'Form',    '— Submitted Data —', '' );
    foreach ( $fd as $key => $val ) {
        if ( $key === 'field_documents' ) { continue; }
        $label   = isset( $label_map[ $key ] ) ? $label_map[ $key ] : ucwords( str_replace( array( 'field_', '_' ), array( '', ' ' ), $key ) );
        $display = is_array( $val ) ? implode( ', ', $val ) : (string) $val;
        if ( $display === '' ) { $display = '—'; }
        $rows[] = array( 'Form', $label, $display );
    }

    if ( $docs ) {
        $rows[] = array( '', '', '' );
        $rows[] = array( 'Documents', '— Uploaded Files —', '' );
        foreach ( $docs as $d ) {
            $att_id = isset( $d['file'] ) ? intval( $d['file'] ) : 0;
            $fn     = $att_id ? basename( get_attached_file( $att_id ) ) : 'unknown';
            $dtype  = isset( $d['doc_type'] ) ? $d['doc_type'] : 'Document';
            $by     = ! empty( $d['is_provider'] ) ? 'Provider' : 'Client';
            $rows[] = array( 'Documents', $dtype . ' (' . $by . ')', $fn );
        }
    }

    if ( $history ) {
        $rows[] = array( '', '', '' );
        $rows[] = array( 'History', '— Activity Log —', '' );
        foreach ( array_slice( array_reverse( $history ), 0, 30 ) as $h ) {
            $time  = isset( $h['time'] )  ? $h['time']  : '';
            $event = isset( $h['event'] ) ? $h['event'] : '';
            $note  = isset( $h['note'] )  ? $h['note']  : '';
            $rows[] = array( 'History', $time, $event . ( $note ? ' — ' . $note : '' ) );
        }
    }

    // ── Build sheet1.xml ──────────────────────────────────────────────────────
    $sheet_rows = '';
    $row_num = 1;
    foreach ( $rows as $row ) {
        $cells = '';
        $col_letters = array( 'A', 'B', 'C', 'D', 'E', 'F', 'G' );
        foreach ( $row as $i => $cell ) {
            $col = $col_letters[ $i ];
            $ref = $col . $row_num;
            // Style 2 = header row (bold), Style 3 = section labels
            $style = '';
            if ( $row_num === 1 ) {
                $style = ' s="2"';
            } elseif ( strpos( $cell, '— ' ) === 0 || strpos( $row[0], 'Header' ) === 0 ) {
                $style = ' s="3"';
            }
            // Use inlineStr to avoid sharedStrings.xml complexity
            $cells .= '<c r="' . $ref . '" t="inlineStr"' . $style . '><is><t xml:space="preserve">' . $x( $cell ) . '</t></is></c>';
        }
        $sheet_rows .= '<row r="' . $row_num . '">' . $cells . '</row>';
        $row_num++;
    }

    $sheet_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
           xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <cols>
    <col min="1" max="1" width="14" customWidth="1"/>
    <col min="2" max="2" width="32" customWidth="1"/>
    <col min="3" max="3" width="60" customWidth="1"/>
  </cols>
  <sheetData>' . $sheet_rows . '</sheetData>
</worksheet>';

    $workbook_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
          xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <sheets><sheet name="Submission" sheetId="1" r:id="rId1"/></sheets>
</workbook>';

    $workbook_rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>';

    $styles_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
  <fonts count="3">
    <font><sz val="11"/><name val="Calibri"/></font>
    <font><b/><sz val="12"/><color rgb="FFFFFFFF"/><name val="Calibri"/></font>
    <font><b/><sz val="11"/><color rgb="FF4F46E5"/><name val="Calibri"/></font>
  </fonts>
  <fills count="3">
    <fill><patternFill patternType="none"/></fill>
    <fill><patternFill patternType="gray125"/></fill>
    <fill><patternFill patternType="solid"><fgColor rgb="FF4F46E5"/><bgColor indexed="64"/></patternFill></fill>
  </fills>
  <borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>
  <cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
  <cellXfs count="4">
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
    <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/>
    <xf numFmtId="0" fontId="2" fillId="0" borderId="0" xfId="0" applyFont="1"/>
  </cellXfs>
  <cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>';

    $root_rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>';

    $content_types = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml"  ContentType="application/xml"/>
  <Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
  <Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
  <Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>
</Types>';

    // ── Pack into ZIP ─────────────────────────────────────────────────────────
    $tmp = tempnam( sys_get_temp_dir(), 'nsh_xlsx_' ) . '.xlsx';
    $zip = new ZipArchive();
    $zip->open( $tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE );
    $zip->addFromString( '[Content_Types].xml',          $content_types );
    $zip->addFromString( '_rels/.rels',                  $root_rels );
    $zip->addFromString( 'xl/workbook.xml',              $workbook_xml );
    $zip->addFromString( 'xl/_rels/workbook.xml.rels',   $workbook_rels );
    $zip->addFromString( 'xl/worksheets/sheet1.xml',     $sheet_xml );
    $zip->addFromString( 'xl/styles.xml',                $styles_xml );
    $zip->close();

    $bytes = file_get_contents( $tmp );
    @unlink( $tmp );
    return $bytes;
}

add_action( 'wp_ajax_nsh_export_docx', 'nsh_ajax_export_docx' );
function nsh_ajax_export_docx() {
    // Nonce via GET for direct-link export
    $nonce = sanitize_text_field( isset( $_GET['nonce'] ) ? $_GET['nonce'] : ( isset( $_POST['nonce'] ) ? $_POST['nonce'] : '' ) );
    if ( ! wp_verify_nonce( $nonce, 'nsh_admin_nonce' ) ) { wp_die( 'Security check failed.' ); }
    if ( ! nsh_is_staff() ) { wp_die( 'Access denied.' ); }

    $rid = intval( isset( $_GET['request_id'] ) ? $_GET['request_id'] : 0 );
    if ( ! $rid ) { wp_die( 'Invalid request.' ); }

    $post   = get_post( $rid );
    if ( ! $post || $post->post_type !== 'nsh_request' ) { wp_die( 'Request not found.' ); }

    $meta    = nsh_get_meta( $rid );
    $author  = get_userdata( $post->post_author );
    $fd      = $meta['field_data'];
    $docs    = nsh_get_documents( $rid );
    $history = nsh_get_history( $rid );

    global $wpdb;
    $fields_rows = $wpdb->get_results( "SELECT field_key, field_label FROM {$wpdb->prefix}nsh_fields ORDER BY sort_order ASC" );
    $label_map   = array();
    foreach ( $fields_rows as $fr ) { $label_map[ 'field_' . $fr->field_key ] = $fr->field_label; }

    $req_id  = $meta['request_id'] ? $meta['request_id'] : '#' . $rid;
    $docx    = nsh_build_docx( $req_id, $meta, $author, $fd, $label_map, $docs, $history );

    header( 'Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document' );
    header( 'Content-Disposition: attachment; filename="submission-' . sanitize_file_name( $req_id ) . '.docx"' );
    header( 'Content-Length: ' . strlen( $docx ) );
    header( 'Cache-Control: no-store' );
    echo $docx;
    exit;
}

/**
 * Build a minimal but complete .docx (ZIP of XML files) without any library.
 */
function nsh_build_docx( $req_id, $meta, $author, $fd, $label_map, $docs, $history ) {
    // ── helper: escape for XML ────────────────────────────────────────────────
    $x = function( $s ) { return htmlspecialchars( (string) $s, ENT_XML1, 'UTF-8' ); };

    // ── Collect paragraphs ───────────────────────────────────────────────────
    $paras = array();

    // Title
    $paras[] = array( 'text' => 'NRI Services Hub – Form Submission', 'style' => 'heading1' );
    $paras[] = array( 'text' => 'Request ID: ' . $req_id,         'style' => 'heading2' );
    $paras[] = array( 'text' => 'Generated: ' . date( 'd M Y, g:i a' ), 'style' => 'normal' );
    $paras[] = array( 'text' => '', 'style' => 'normal' );

    // Client info
    $paras[] = array( 'text' => 'Client Information', 'style' => 'heading2' );
    $paras[] = array( 'text' => 'Name:   ' . ( $author ? $author->display_name : 'N/A' ), 'style' => 'normal' );
    $paras[] = array( 'text' => 'Email:  ' . ( $author ? $author->user_email   : 'N/A' ), 'style' => 'normal' );
    $paras[] = array( 'text' => 'Status: ' . nsh_status_label( $meta['status'] ),          'style' => 'normal' );
    if ( $meta['quote_amount'] ) {
        $paras[] = array( 'text' => 'Quote:  INR ' . number_format( (float) $meta['quote_amount'], 2 ), 'style' => 'normal' );
    }
    if ( $meta['estimated_delivery'] ) {
        $paras[] = array( 'text' => 'Est. Delivery: ' . date( 'd M Y', strtotime( $meta['estimated_delivery'] ) ), 'style' => 'normal' );
    }
    $paras[] = array( 'text' => '', 'style' => 'normal' );

    // Form fields
    $paras[] = array( 'text' => 'Submitted Form Data', 'style' => 'heading2' );
    foreach ( $fd as $key => $val ) {
        if ( $key === 'field_documents' ) { continue; }
        $label   = isset( $label_map[ $key ] ) ? $label_map[ $key ] : ucwords( str_replace( array( 'field_', '_' ), array( '', ' ' ), $key ) );
        $display = is_array( $val ) ? implode( ', ', $val ) : (string) $val;
        if ( $display === '' ) { $display = '—'; }
        $paras[] = array( 'text' => $label . ': ' . $display, 'style' => 'normal' );
    }
    $paras[] = array( 'text' => '', 'style' => 'normal' );

    // Documents
    if ( $docs ) {
        $paras[] = array( 'text' => 'Uploaded Documents', 'style' => 'heading2' );
        foreach ( $docs as $d ) {
            $att_id = isset( $d['file'] ) ? intval( $d['file'] ) : 0;
            $fn     = $att_id ? basename( get_attached_file( $att_id ) ) : 'unknown';
            $dtype  = isset( $d['doc_type'] ) ? $d['doc_type'] : 'Document';
            $by     = ! empty( $d['is_provider'] ) ? 'Provider' : 'Client';
            $paras[] = array( 'text' => '• ' . $dtype . ' (' . $by . '): ' . $fn, 'style' => 'normal' );
        }
        $paras[] = array( 'text' => '', 'style' => 'normal' );
    }

    // History
    if ( $history ) {
        $paras[] = array( 'text' => 'Activity History', 'style' => 'heading2' );
        foreach ( array_slice( array_reverse( $history ), 0, 30 ) as $h ) {
            $line = '• [' . ( isset( $h['time'] ) ? $h['time'] : '' ) . '] ' . ( isset( $h['event'] ) ? $h['event'] : '' );
            if ( ! empty( $h['note'] ) ) { $line .= ' – ' . $h['note']; }
            $paras[] = array( 'text' => $line, 'style' => 'normal' );
        }
    }

    // ── Build document.xml ───────────────────────────────────────────────────
    $body = '';
    foreach ( $paras as $p ) {
        $style_id = ( $p['style'] === 'heading1' ) ? 'Heading1'
                  : ( ( $p['style'] === 'heading2' ) ? 'Heading2' : 'Normal' );
        $bold_open  = ( $p['style'] !== 'normal' ) ? '<w:b/>' : '';
        $size       = ( $p['style'] === 'heading1' ) ? '<w:sz w:val="36"/><w:szCs w:val="36"/>'
                    : ( ( $p['style'] === 'heading2' ) ? '<w:sz w:val="28"/><w:szCs w:val="28"/>' : '' );
        $color      = ( $p['style'] === 'heading1' ) ? '<w:color w:val="1e293b"/>'
                    : ( ( $p['style'] === 'heading2' ) ? '<w:color w:val="4f46e5"/>' : '' );
        $spacing    = ( $p['style'] !== 'normal' ) ? '<w:spacing w:before="240" w:after="120"/>' : '<w:spacing w:before="0" w:after="80"/>';

        $body .= '<w:p>';
        $body .= '<w:pPr><w:jc w:val="left"/>' . $spacing . '</w:pPr>';
        if ( $p['text'] !== '' ) {
            $body .= '<w:r><w:rPr>' . $bold_open . $size . $color . '<w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/></w:rPr>';
            $body .= '<w:t xml:space="preserve">' . $x( $p['text'] ) . '</w:t></w:r>';
        }
        $body .= '</w:p>';
    }

    $document_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:wpc="http://schemas.microsoft.com/office/word/2010/wordprocessingCanvas"
    xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"
    xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <w:body>' . $body . '<w:sectPr>
      <w:pgSz w:w="12240" w:h="15840"/>
      <w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/>
    </w:sectPr>
  </w:body>
</w:document>';

    $rels_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>';

    $styles_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:styleId="Normal"><w:name w:val="Normal"/>
    <w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/><w:sz w:val="22"/></w:rPr></w:style>
</w:styles>';

    $content_types_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml"  ContentType="application/xml"/>
  <Override PartName="/word/document.xml"
    ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml"
    ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>';

    $root_rels_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1"
    Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument"
    Target="word/document.xml"/>
</Relationships>';

    // ── Pack into a ZIP (DOCX) without requiring ZipArchive extension ─────────
    // ZipArchive is almost always available in WordPress hosting – use it.
    $tmp = tempnam( sys_get_temp_dir(), 'nsh_docx_' ) . '.docx';
    $zip = new ZipArchive();
    $zip->open( $tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE );
    $zip->addFromString( '[Content_Types].xml',          $content_types_xml );
    $zip->addFromString( '_rels/.rels',                  $root_rels_xml );
    $zip->addFromString( 'word/document.xml',            $document_xml );
    $zip->addFromString( 'word/styles.xml',              $styles_xml );
    $zip->addFromString( 'word/_rels/document.xml.rels', $rels_xml );
    $zip->close();

    $bytes = file_get_contents( $tmp );
    @unlink( $tmp );
    return $bytes;
}

// ─────────────────────────────────────────────────────────────────────────────
// SHORTCODE HOOK: add "Submissions" tab to admin dashboard
// We hook into shortcodes.php via the filter below
// ─────────────────────────────────────────────────────────────────────────────
add_filter( 'nsh_admin_tabs', 'nsh_add_submissions_tab' );
function nsh_add_submissions_tab( $tabs ) {
    $tabs['submissions'] = 'Form Submissions';
    return $tabs;
}

/**
 * Render the "Form Submissions" admin tab HTML.
 *
 * @param bool $echo_inline_script See nsh_output_admin_script()'s docblock
 *   (enqueue.php). true (default, used by the AJAX tab-swap response in
 *   ajax.php) prints this tab's trailing <script> raw, as before — that
 *   path is JSON, never touched by content filters. false (used only by
 *   nsh_sc_admin_dashboard()'s direct/first-full-page render, where this
 *   return value becomes page content) routes the same JS through
 *   wp_add_inline_script() instead, so it can't be corrupted by
 *   wp_kses_post()-style sanitization some themes/page builders apply to
 *   rendered content.
 */
function nsh_admin_tab_submissions( $echo_inline_script = true ) {
    $o  = '<div class="nsh-tab-content">';
    $o .= '<div class="nsh-tab-hdr"><h3>Form Submissions</h3>';
    $o .= '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;">';
    $o .= '<input type="text" id="nsh-sub-search" placeholder="Search by client or service..." class="nsh-search-input" style="width:260px;">';
    $o .= nsh_render_date_filter_controls( 'nsh-sub-date' );
    $o .= '<button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-sub-search-btn">Search</button>';
    $o .= '<button class="nsh-btn nsh-btn-ghost nsh-btn-sm" id="nsh-sub-reset-btn">Reset</button>';
    // Pagination now lives in this same header row (pushed to the far
    // right via margin-left:auto on this flex row), matching the
    // Requests tab layout, instead of its own bar below the table — id
    // (#nsh-sub-pages) and the nshBuildPager() render call that fills it
    // are unchanged.
    $o .= '<div id="nsh-sub-pages" class="nsh-pagination nsh-pagination-inline" style="margin-left:auto;"></div>';
    $o .= '</div></div>';

    $o .= '<div class="nsh-bulk-toolbar" id="nsh-sub-bulk-toolbar" style="display:none;margin-bottom:10px;background:#eff6ff;border:1px solid #bfdbfe;border-radius:8px;padding:10px 14px;display:flex;gap:10px;align-items:center;">';
    $o .= '<span id="nsh-sub-bulk-count" style="font-size:13px;font-weight:600;color:#1e40af;">0 selected</span>';
    $o .= '<button class="nsh-btn nsh-btn-danger nsh-btn-sm" id="nsh-bulk-delete-submissions">&#128465; Delete Selected</button>';
    $o .= '<button class="nsh-btn nsh-btn-ghost nsh-btn-sm" id="nsh-sub-bulk-deselect">Clear Selection</button>';
    $o .= '</div>';

    $o .= '<div class="nsh-tbl-wrap"><table class="nsh-tbl"><thead><tr>';
    $o .= '<th style="width:36px;"><input type="checkbox" id="nsh-select-all-subs" title="Select All"></th><th>Request ID</th><th>Client</th><th>Service</th><th>Status</th><th>Documents</th><th>Date</th><th>Actions</th>';
    $o .= '</tr></thead>';
    $o .= '<tbody id="nsh-sub-tbody"><tr><td colspan="8" class="nsh-tbl-loading">Loading submissions…</td></tr></tbody>';
    $o .= '</table></div>';

    // ── Detail modal ─────────────────────────────────────────────────────────
    $o .= '
<div id="nsh-sub-modal" style="display:none;position:fixed;inset:0;z-index:99999;background:rgba(15,23,42,0.55);overflow-y:auto;">
  <div style="max-width:780px;margin:40px auto 60px;background:#fff;border-radius:16px;box-shadow:0 20px 60px rgba(0,0,0,.2);overflow:hidden;">
    <div style="background:linear-gradient(135deg,#4f46e5 0%,#7c3aed 100%);padding:24px 28px;display:flex;align-items:center;justify-content:space-between;">
      <div>
        <h3 id="nsh-sub-modal-title" style="margin:0;color:#fff;font-size:20px;font-weight:700;">Submission Detail</h3>
        <p id="nsh-sub-modal-sub" style="margin:4px 0 0;color:rgba(255,255,255,.75);font-size:13px;"></p>
      </div>
      <button onclick="document.getElementById(\'nsh-sub-modal\').style.display=\'none\'" style="background:rgba(255,255,255,.15);border:none;color:#fff;font-size:20px;width:36px;height:36px;border-radius:50%;cursor:pointer;line-height:1;">&times;</button>
    </div>
    <div style="padding:24px 28px;">
      <!-- Download bar -->
      <div id="nsh-sub-dl-bar" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px;padding:14px 16px;background:#f8fafc;border-radius:10px;border:1px solid #e2e8f0;align-items:center;">
        <span style="font-size:13px;font-weight:600;color:#475569;margin-right:4px;">&#8595; Download As:</span>
        <button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-dl-pdf-btn">&#128196; PDF</button>
        <button class="nsh-btn nsh-btn-outline nsh-btn-sm" id="nsh-dl-img-btn">&#128247; Image (PNG)</button>
        <button class="nsh-btn nsh-btn-outline nsh-btn-sm" id="nsh-dl-docx-btn">&#128221; Word (.docx)</button>
        <button class="nsh-btn nsh-btn-outline nsh-btn-sm" id="nsh-dl-xlsx-btn" style="background:#dcfce7;border-color:#86efac;color:#166534;">&#128202; Excel (.xlsx)</button>
      </div>
      <div id="nsh-sub-modal-body">
        <div style="text-align:center;padding:40px;color:#94a3b8;">Loading…</div>
      </div>
    </div>
  </div>
</div>';

    // ── Inline JS for this tab ────────────────────────────────────────────────
    // Built into its own $js var (not appended straight into $o) so it can
    // be routed through nsh_output_admin_script() below — see this
    // function's docblock for why raw vs. wp_add_inline_script() depends
    // on which caller (AJAX tab-swap vs. direct full-page render) is asking.
    $js = "
(function(){
var _subPage=1,_subSearch='',_subRid=0,_subDateFilter='',_subDateFrom='',_subDateTo='';

function nshDeleteSubmission(id){
  if(!confirm('Delete this submission permanently? All messages and tickets on it will also be deleted.'))return;
  jQuery.post(NSH.ajax_url,{action:'nsh_delete_request',nonce:NSH.admin_nonce,request_id:id,hard_delete:1},function(r){
    if(r.success){nshLoadSubmissions();}else{alert('Delete failed.');}
  });
}
window.nshDeleteSubmission=nshDeleteSubmission;

function nshLoadSubmissions(){
  var tb=document.getElementById('nsh-sub-tbody');
  if(!tb)return;
  var _subHadRows=tb.children.length>0;
  var _subLoadTimer=_subHadRows?null:setTimeout(function(){tb.innerHTML='<tr><td colspan=\"8\" class=\"nsh-tbl-loading\">Loading…</td></tr>';},200);
  jQuery.post(NSH.ajax_url,{action:'nsh_list_submissions',nonce:NSH.admin_nonce,search:_subSearch,paged:_subPage,date_filter:_subDateFilter,date_from:_subDateFrom,date_to:_subDateTo},function(r){
    if(_subLoadTimer)clearTimeout(_subLoadTimer);
    if(!r||!r.success){tb.innerHTML='<tr><td colspan=\"8\" style=\"color:#ef4444;padding:14px;\">Error loading submissions.</td></tr>';return;}
    var rows='';
    r.data.submissions.forEach(function(s){
      rows+='<tr data-rid=\"'+s.id+'\">';
      rows+='<td style=\"text-align:center;\"><input type=\"checkbox\" class=\"nsh-sub-bulk-chk\" value=\"'+s.id+'\"></td>';
      rows+='<td><strong>'+s.request_id+'</strong></td>';
      rows+='<td>'+s.client+'<br><small style=\"color:#64748b;\">'+s.email+'</small></td>';
      rows+='<td>'+s.service+'</td>';
      rows+='<td><span class=\"nsh-status-chip\" style=\"background:'+s.status_color+'22;color:'+s.status_color+'\">'+s.status_label+'</span></td>';
      var docCell = s.doc_count > 0
        ? '<span style=\"background:#dbeafe;color:#1d4ed8;padding:3px 10px;border-radius:12px;font-size:12px;font-weight:600;\">&#128196; '+s.doc_count+' file'+(s.doc_count>1?'s':'')+' — <a href=\"#\" onclick=\"nshOpenSubmission('+s.id+');return false;\" style=\"color:#1d4ed8;\">View</a></span>'
        : '<span style=\"color:#94a3b8;font-size:12px;\">None</span>';
      rows+='<td>'+docCell+'</td>';
      rows+='<td style=\"color:#64748b;font-size:13px;\">'+s.date+'</td>';
      rows+='<td><button class=\"nsh-btn nsh-btn-sm nsh-btn-primary\" onclick=\"nshOpenSubmission('+s.id+')\">&#128269; View</button> <button class=\"nsh-btn nsh-btn-sm nsh-btn-danger\" onclick=\"nshDeleteSubmission('+s.id+')\" style=\"margin-left:4px;\">&#128465;</button></td>';
      rows+='</tr>';
    });
    tb.innerHTML=rows||'<tr><td colspan=\"8\" class=\"nsh-tbl-empty\">No submissions found.</td></tr>';
    document.getElementById('nsh-select-all-subs').checked=false;
    jQuery('#nsh-sub-bulk-toolbar').hide();
    jQuery('#nsh-sub-bulk-count').text('0 selected');
    // nshBuildPager() (defined once in nsh_admin_js(), shortcodes.php) caps
    // the number of page buttons rendered instead of one per page — this
    // callback only ever runs after the AJAX round trip completes, by
    // which point the rest of the page (including nsh_admin_js()'s script,
    // which prints AFTER this tab's content in document order) has always
    // already executed, so the function is guaranteed to exist here.
    document.getElementById('nsh-sub-pages').innerHTML = window.nshBuildPager
      ? window.nshBuildPager(r.data.total, r.data.pages, _subPage, 'nshSubGoPage')
      : ('<span style=\"font-size:13px;color:#64748b;\">'+r.data.total+' total</span>');
  });
}

window.nshSubGoPage=function(p){_subPage=p;nshLoadSubmissions();};

window.nshOpenSubmission=function(rid){
  _subRid=rid;
  var modal=document.getElementById('nsh-sub-modal');
  var body=document.getElementById('nsh-sub-modal-body');
  document.getElementById('nsh-sub-modal-title').textContent='Submission Detail';
  document.getElementById('nsh-sub-modal-sub').textContent='Loading…';
  body.innerHTML='<div style=\"text-align:center;padding:40px;color:#94a3b8;\">Fetching data…</div>';
  modal.style.display='block';
  jQuery.post(NSH.ajax_url,{action:'nsh_get_submission_detail',nonce:NSH.admin_nonce,request_id:rid},function(r){
    if(!r||!r.success){body.innerHTML='<p style=\"color:#ef4444;\">Could not load submission details.</p>';return;}
    var d=r.data;
    document.getElementById('nsh-sub-modal-title').textContent='Request '+d.request_id;
    document.getElementById('nsh-sub-modal-sub').textContent=d.client_name+' · '+d.client_email+' · Submitted '+d.submitted_at;
    var html='<div id=\"nsh-sub-printable\">';
    // header block
    html+='<div style=\"display:flex;gap:16px;flex-wrap:wrap;margin-bottom:20px;\">';
    html+='<div style=\"flex:1;min-width:180px;background:#f8fafc;border-radius:10px;padding:14px 16px;\"><div style=\"font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px;\">Status</div><span class=\"nsh-status-chip\" style=\"background:'+d.status_color+'22;color:'+d.status_color+'\">'+d.status_label+'</span></div>';
    if(d.quote_amount) html+='<div style=\"flex:1;min-width:180px;background:#f8fafc;border-radius:10px;padding:14px 16px;\"><div style=\"font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px;\">Quote</div><strong>'+d.quote_amount+'</strong></div>';
    if(d.delivery) html+='<div style=\"flex:1;min-width:180px;background:#f8fafc;border-radius:10px;padding:14px 16px;\"><div style=\"font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px;\">Est. Delivery</div><strong>'+d.delivery+'</strong></div>';
    if(d.manager) html+='<div style=\"flex:1;min-width:180px;background:#f8fafc;border-radius:10px;padding:14px 16px;\"><div style=\"font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:4px;\">Manager</div>'+d.manager+'</div>';
    html+='</div>';

    // Documents section FIRST (most important for admin)
    if(d.documents&&d.documents.length){
      html+='<div style=\"background:linear-gradient(135deg,#eff6ff,#dbeafe);border:1px solid #bfdbfe;border-radius:12px;padding:16px;margin-bottom:20px;\">';
      html+='<h4 style=\"font-size:15px;font-weight:700;color:#1d4ed8;margin:0 0 12px;display:flex;align-items:center;gap:8px;\">&#128196; Client Uploaded Documents <span style=\"background:#1d4ed8;color:#fff;padding:2px 8px;border-radius:10px;font-size:12px;\">'+d.documents.length+'</span></h4>';
      d.documents.forEach(function(doc){
        if(doc.is_provider) return; // skip provider docs in this block
        var icon=doc.mime&&doc.mime.indexOf('image')>=0?'&#128247;':'&#128196;';
        html+='<div style=\"display:flex;align-items:center;gap:12px;background:#fff;border:1px solid #bfdbfe;border-radius:8px;padding:10px 14px;margin-bottom:8px;\">';
        html+='<span style=\"font-size:20px;\">'+icon+'</span>';
        html+='<div style=\"flex:1;\"><div style=\"font-weight:600;font-size:13px;color:#1e293b;\">'+doc.doc_type+'</div><div style=\"font-size:12px;color:#64748b;\">'+doc.filename+'</div></div>';
        if(doc.url) html+='<a href=\"'+doc.url+'\" class=\"nsh-btn nsh-btn-sm nsh-btn-primary\">&#8595; Download</a>';
        if(doc.view_url||doc.url) html+='<a href=\"'+(doc.view_url||doc.url)+'\" target=\"_blank\" class=\"nsh-btn nsh-btn-sm nsh-btn-outline\" style=\"margin-left:6px;\">&#128065; View</a>';
        html+='</div>';
      });
      // Provider docs
      var provDocs = d.documents.filter(function(doc){return doc.is_provider;});
      if(provDocs.length){
        html+='<div style=\"margin-top:10px;padding-top:10px;border-top:1px dashed #bfdbfe;\"><p style=\"font-size:12px;font-weight:600;color:#64748b;margin:0 0 8px;\">Provider Documents</p>';
        provDocs.forEach(function(doc){
          html+='<div style=\"display:flex;align-items:center;gap:12px;background:#f0fdf4;border:1px solid #bbf7d0;border-radius:8px;padding:8px 12px;margin-bottom:6px;\">';
          html+='<span style=\"font-size:16px;\">&#128196;</span>';
          html+='<div style=\"flex:1;\"><div style=\"font-weight:600;font-size:13px;\">'+doc.doc_type+'</div><div style=\"font-size:12px;color:#64748b;\">'+doc.filename+'</div></div>';
          if(doc.url) html+='<a href=\"'+doc.url+'\" class=\"nsh-btn nsh-btn-sm nsh-btn-outline\">&#8595; Download</a>';
          if(doc.view_url||doc.url) html+='<a href=\"'+(doc.view_url||doc.url)+'\" target=\"_blank\" class=\"nsh-btn nsh-btn-sm nsh-btn-ghost\" style=\"margin-left:4px;\">&#128065; View</a>';
          html+='</div>';
        });
        html+='</div>';
      }
      html+='</div>';
    } else {
      html+='<div style=\"background:#fef9c3;border:1px solid #fde68a;border-radius:10px;padding:14px 16px;margin-bottom:20px;text-align:center;color:#92400e;font-size:13px;\">&#9888; No documents uploaded by client yet.</div>';
    }

    // Form fields section
    html+='<h4 style=\"font-size:15px;font-weight:700;color:#1e293b;margin:0 0 12px;border-bottom:2px solid #e2e8f0;padding-bottom:8px;\">&#128203; Form Details</h4>';
    html+='<div style=\"display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px;margin-bottom:20px;\">';
    d.fields.forEach(function(f){
      if(!f.value||f.value===''||f.value==='—')return;
      html+='<div style=\"background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:10px 12px;\">';
      html+='<div style=\"font-size:11px;color:#64748b;text-transform:uppercase;letter-spacing:.05em;margin-bottom:3px;\">'+f.label+'</div>';
      html+='<div style=\"font-size:14px;color:#1e293b;font-weight:500;\">'+f.value+'</div>';
      html+='</div>';
    });
    html+='</div>';

    // Documents section handled above

    // History section
    if(d.history&&d.history.length){
      html+='<h4 style=\"font-size:15px;font-weight:700;color:#1e293b;margin:0 0 12px;border-bottom:2px solid #e2e8f0;padding-bottom:8px;\">&#128336; Activity Log</h4>';
      html+='<div style=\"display:flex;flex-direction:column;gap:6px;\">';
      d.history.forEach(function(h){
        html+='<div style=\"display:flex;gap:10px;align-items:flex-start;font-size:13px;\">';
        html+='<span style=\"color:#94a3b8;flex-shrink:0;font-size:11px;padding-top:2px;\">'+h.time+'</span>';
        html+='<span style=\"color:#1e293b;\">'+h.event+(h.note?'<span style=\"color:#64748b;\"> – '+h.note+'</span>':'')+'</span>';
        html+='</div>';
      });
      html+='</div>';
    }

    html+='</div>'; // end nsh-sub-printable
    body.innerHTML=html;

    // Wire up download buttons
    document.getElementById('nsh-dl-pdf-btn').onclick=function(){nshDownloadServer('pdf', rid);};
    document.getElementById('nsh-dl-img-btn').onclick=function(){nshDownloadServer('png', rid);};
    document.getElementById('nsh-dl-docx-btn').onclick=function(){nshDownloadServer('docx', rid);};
    document.getElementById('nsh-dl-xlsx-btn').onclick=function(){nshDownloadServer('xlsx', rid);};
  });
};

// ── Unified server-side download ────────────────────────────────────────
// docx/xlsx: direct file download via <a download>
// pdf/png:   open new window — server returns HTML that auto-prints (PDF) or auto-saves canvas (PNG)
window.nshDownloadServer=function(format, rid){
  var btnMap={pdf:'nsh-dl-pdf-btn',png:'nsh-dl-img-btn',docx:'nsh-dl-docx-btn',xlsx:'nsh-dl-xlsx-btn'};
  var btn=document.getElementById(btnMap[format]);
  var origText=btn?btn.innerHTML:'';
  if(btn){btn.innerHTML='Generating…';btn.disabled=true;}

  var url=NSH.ajax_url+'?action=nsh_export_submission&format='+format+'&nonce='+NSH.admin_nonce+'&request_id='+rid;

  if(format==='pdf' || format==='png'){
    // Open in new window — auto-print or auto-download fires inside the new page
    var w=window.open(url,'_blank');
    if(!w){
      alert('Pop-up blocked. Please allow pop-ups for this site to download the file.');
    }
  } else {
    // Direct binary download
    var a=document.createElement('a');
    a.href=url;
    a.download='submission-'+rid+'.'+format;
    a.style.display='none';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  }

  setTimeout(function(){
    if(btn){btn.innerHTML=origText;btn.disabled=false;}
  },1500);
};

// Close modal on backdrop click
document.getElementById('nsh-sub-modal').addEventListener('click',function(e){
  if(e.target===this)this.style.display='none';
});

// ── Bulk select ──────────────────────────────────────────────────────────
function nshSubUpdateBulkUI(){
  var n=document.querySelectorAll('.nsh-sub-bulk-chk:checked').length;
  if(n>0){
    jQuery('#nsh-sub-bulk-toolbar').css('display','flex');
    jQuery('#nsh-sub-bulk-count').text(n+' submission'+(n>1?'s':'')+' selected');
  } else {
    jQuery('#nsh-sub-bulk-toolbar').hide();
  }
}
jQuery(document).on('change','#nsh-sub-tbody .nsh-sub-bulk-chk',function(){
  nshSubUpdateBulkUI();
  var all=document.querySelectorAll('.nsh-sub-bulk-chk').length;
  var chk=document.querySelectorAll('.nsh-sub-bulk-chk:checked').length;
  var sa=document.getElementById('nsh-select-all-subs');
  if(sa)sa.checked=(all>0 && all===chk);
});
jQuery(document).on('change','#nsh-select-all-subs',function(){
  var checked=jQuery(this).is(':checked');
  jQuery('.nsh-sub-bulk-chk').prop('checked',checked);
  nshSubUpdateBulkUI();
});
jQuery(document).on('click','#nsh-sub-bulk-deselect',function(){
  jQuery('.nsh-sub-bulk-chk, #nsh-select-all-subs').prop('checked',false);
  nshSubUpdateBulkUI();
});
jQuery(document).on('click','#nsh-bulk-delete-submissions',function(){
  var ids=[];
  jQuery('.nsh-sub-bulk-chk:checked').each(function(){ids.push(parseInt(jQuery(this).val()));});
  if(!ids.length){alert('No submissions selected.');return;}
  if(!confirm('Delete the selected '+ids.length+' submission'+(ids.length>1?'s':'')+'? This also deletes their messages, tickets and uploaded documents. This cannot be undone.'))return;
  var delBtn=jQuery(this).text('Deleting…').prop('disabled',true);
  jQuery.post(NSH.ajax_url,{action:'nsh_bulk_delete_requests',nonce:NSH.admin_nonce,request_ids:ids},function(r){
    delBtn.text('Delete Selected').prop('disabled',false);
    if(r.success){nshLoadSubmissions();}
    else{alert('Bulk delete failed: '+(r.data&&r.data.message?r.data.message:'Unknown error'));}
  }).fail(function(){delBtn.text('Delete Selected').prop('disabled',false);alert('Network error.');});
});

// Wire search/reset buttons + first load. This whole <script> block is
// re-executed every time this tab's HTML is (re)inserted — on the very
// first full page load AND on every later AJAX tab-swap alike (jQuery
// evaluates a freshly-inserted <script> tag immediately) — so a readyState
// check, not a one-shot DOMContentLoaded listener, is what makes this safe
// to run in both situations without ever double-binding or never-binding.
function nshSubReadDate(){
  if(window.nshReadDateFilter){
    var d=window.nshReadDateFilter('nsh-sub-date');
    _subDateFilter=d.filter;_subDateFrom=d.from;_subDateTo=d.to;
  }
}
function nshInitSubmissionsTab(){
  var sb=document.getElementById('nsh-sub-search-btn');
  if(sb)sb.addEventListener('click',function(){_subSearch=document.getElementById('nsh-sub-search').value;nshSubReadDate();_subPage=1;nshLoadSubmissions();});
  var rb=document.getElementById('nsh-sub-reset-btn');
  if(rb)rb.addEventListener('click',function(){
    document.getElementById('nsh-sub-search').value='';_subSearch='';
    var f=document.getElementById('nsh-sub-date-f'),sp=document.getElementById('nsh-sub-date-specific'),fr=document.getElementById('nsh-sub-date-from'),to=document.getElementById('nsh-sub-date-to');
    if(f)f.value='';if(sp)sp.value='';if(fr)fr.value='';if(to)to.value='';
    if(window.nshInitDateFilterToggle)window.nshInitDateFilterToggle('nsh-sub-date');
    _subDateFilter='';_subDateFrom='';_subDateTo='';
    _subPage=1;nshLoadSubmissions();
  });
  var se=document.getElementById('nsh-sub-search');
  if(se)se.addEventListener('keypress',function(e){if(e.which===13){jQuery('#nsh-sub-search-btn').click();}});
  var df=document.getElementById('nsh-sub-date-f');
  if(df)df.addEventListener('change',function(){
    if(window.nshInitDateFilterToggle)window.nshInitDateFilterToggle('nsh-sub-date');
    if(df.value!=='specific_date'&&df.value!=='custom_range'){nshSubReadDate();_subPage=1;nshLoadSubmissions();}
  });
  ['nsh-sub-date-specific','nsh-sub-date-from','nsh-sub-date-to'].forEach(function(id){
    var el=document.getElementById(id);
    if(el)el.addEventListener('change',function(){
      nshSubReadDate();
      if(_subDateFrom||_subDateTo){_subPage=1;nshLoadSubmissions();}
    });
  });
  // No initial toggle call needed here: the date-input wrap spans are
  // already rendered hidden by nsh_render_date_filter_controls(), and this
  // tab has no filter-state restore (unlike the Requests tab), so the
  // filter select always starts blank/All-Dates on every tab entry -- the
  // hidden-by-default markup already matches that state. Calling it here
  // would also risk running before nsh_admin_js() (which defines it) on a
  // first full page load where Submissions is the initial tab, since
  // nsh_admin_js() is emitted once, after all tab content, in shortcodes.php.
  nshLoadSubmissions();
}
if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',nshInitSubmissionsTab);}else{nshInitSubmissionsTab();}
})();
";
    $o .= nsh_output_admin_script( $js, $echo_inline_script );

    $o .= '</div>';
    return $o;
}

// ── Excel (.xlsx) Export ────────────────────────────────────────────────────
add_action( 'wp_ajax_nsh_export_excel', 'nsh_ajax_export_excel' );
function nsh_ajax_export_excel() {
    $nonce = sanitize_text_field( isset( $_GET['nonce'] ) ? $_GET['nonce'] : ( isset( $_POST['nonce'] ) ? $_POST['nonce'] : '' ) );
    if ( ! wp_verify_nonce( $nonce, 'nsh_admin_nonce' ) ) { wp_die( 'Security check failed.' ); }
    if ( ! nsh_is_staff() ) { wp_die( 'Access denied.' ); }

    $rid = intval( isset( $_GET['request_id'] ) ? $_GET['request_id'] : 0 );
    if ( ! $rid ) { wp_die( 'Invalid request.' ); }
    $post = get_post( $rid );
    if ( ! $post || $post->post_type !== 'nsh_request' ) { wp_die( 'Request not found.' ); }

    $meta   = nsh_get_meta( $rid );
    $author = get_userdata( $post->post_author );
    $fd     = $meta['field_data'];

    global $wpdb;
    $fields_rows = $wpdb->get_results( "SELECT field_key, field_label FROM {$wpdb->prefix}nsh_fields ORDER BY sort_order ASC" );
    $label_map   = array();
    foreach ( $fields_rows as $fr ) { $label_map[ 'field_' . $fr->field_key ] = $fr->field_label; }

    $req_id = $meta['request_id'] ? $meta['request_id'] : '#' . $rid;

    // Build rows: label => value
    $rows = array();
    $rows[] = array( 'Field', 'Value' ); // header
    $rows[] = array( 'Order ID',          $req_id );
    $rows[] = array( 'Client Name',       $author ? $author->display_name : '' );
    $rows[] = array( 'Client Email',      $author ? $author->user_email   : '' );
    $rows[] = array( 'Status',            nsh_status_label( $meta['status'] ) );
    $rows[] = array( 'Quote Amount',      $meta['quote_amount'] ? 'INR ' . number_format( floatval( $meta['quote_amount'] ), 2 ) : '' );
    $rows[] = array( 'Shipping Charges',  isset( $meta['shipping_charges'] ) ? 'INR ' . number_format( floatval( $meta['shipping_charges'] ), 2 ) : '' );
    $rows[] = array( 'Est. Delivery',     $meta['estimated_delivery'] ? date( 'd M Y', strtotime( $meta['estimated_delivery'] ) ) : '' );
    $rows[] = array( 'Working Days',      get_post_meta( $rid, 'timeline_working_days', true ) ?: '' );
    $rows[] = array( 'Submitted',         $post->post_date );
    $rows[] = array( '', '' ); // spacer
    $rows[] = array( '--- FORM FIELDS ---', '' );

    foreach ( $fd as $key => $val ) {
        $label = isset( $label_map[ $key ] ) ? $label_map[ $key ] : ucwords( str_replace( array( 'field_', '_' ), array( '', ' ' ), $key ) );
        if ( is_array( $val ) ) { $val = implode( ', ', $val ); }
        $rows[] = array( $label, (string) $val );
    }

    $xlsx = nsh_build_xlsx_simple( $rows, 'Request_' . $req_id );

    header( 'Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' );
    header( 'Content-Disposition: attachment; filename="submission-' . sanitize_file_name( $req_id ) . '.xlsx"' );
    header( 'Content-Length: ' . strlen( $xlsx ) );
    header( 'Cache-Control: no-store' );
    echo $xlsx;
    exit;
}

function nsh_build_xlsx_simple( $rows, $sheet_name = 'Sheet1' ) {
    $esc = function( $v ) {
        return htmlspecialchars( (string) $v, ENT_XML1 | ENT_QUOTES, 'UTF-8' );
    };

    // Build shared strings
    $strings = array();
    $str_idx = array();
    foreach ( $rows as $row ) {
        foreach ( $row as $cell ) {
            $s = (string) $cell;
            if ( ! isset( $str_idx[ $s ] ) ) {
                $str_idx[ $s ] = count( $strings );
                $strings[]     = $s;
            }
        }
    }

    // sheet data
    $sheet_rows = '';
    foreach ( $rows as $ri => $row ) {
        $cells = '';
        foreach ( $row as $ci => $cell ) {
            $col   = chr( 65 + $ci );
            $rnum  = $ri + 1;
            $sidx  = $str_idx[ (string) $cell ];
            $cells .= '<c r="' . $col . $rnum . '" t="s"><v>' . $sidx . '</v></c>';
        }
        $sheet_rows .= '<row r="' . ( $ri + 1 ) . '">' . $cells . '</row>';
    }

    $sheet_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<sheetData>' . $sheet_rows . '</sheetData>
</worksheet>';

    $sst_items = '';
    foreach ( $strings as $s ) {
        $sst_items .= '<si><t xml:space="preserve">' . $esc( $s ) . '</t></si>';
    }
    $sst_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<sst xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" count="' . count( $strings ) . '" uniqueCount="' . count( $strings ) . '">' . $sst_items . '</sst>';

    $workbook_xml = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"
          xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="' . htmlspecialchars( $sheet_name, ENT_XML1, 'UTF-8' ) . '" sheetId="1" r:id="rId1"/></sheets>
</workbook>';

    $wb_rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
<Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings" Target="sharedStrings.xml"/>
</Relationships>';

    $content_types = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
<Override PartName="/xl/sharedStrings.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml"/>
</Types>';

    $root_rels = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>';

    // Build ZIP
    $tmp = tempnam( sys_get_temp_dir(), 'nsh_xlsx_' );
    $zip = new ZipArchive();
    $zip->open( $tmp, ZipArchive::CREATE | ZipArchive::OVERWRITE );
    $zip->addFromString( '[Content_Types].xml',       $content_types );
    $zip->addFromString( '_rels/.rels',               $root_rels );
    $zip->addFromString( 'xl/workbook.xml',           $workbook_xml );
    $zip->addFromString( 'xl/_rels/workbook.xml.rels', $wb_rels );
    $zip->addFromString( 'xl/worksheets/sheet1.xml',  $sheet_xml );
    $zip->addFromString( 'xl/sharedStrings.xml',      $sst_xml );
    $zip->close();

    $data = file_get_contents( $tmp );
    unlink( $tmp );
    return $data;
}
