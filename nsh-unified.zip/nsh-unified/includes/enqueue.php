<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
add_action('wp_enqueue_scripts','nsh_enqueue');
add_action('admin_enqueue_scripts','nsh_enqueue');
function nsh_enqueue() {
    // Idempotency guard: nsh_output_admin_script() below may need to call
    // this early (before the normal 'wp_enqueue_scripts'/'admin_enqueue_scripts'
    // hook has fired) to guarantee the 'nsh-app' handle exists before it
    // hands it an inline script. If that same hook then ALSO calls this
    // normally later in the same request, running the body twice would
    // call wp_localize_script('nsh-app','NSH',...) twice — harmless
    // (identical data both times) but pointlessly duplicates the printed
    // `var NSH = {...};` line. Only run once per request either way.
    static $done = false;
    if ( $done ) { return; }
    $done = true;
    // Use filemtime as version for hard cache busting on every file edit
    $css_ver = file_exists( NSH_DIR . 'assets/css/nsh-style.css' ) ? filemtime( NSH_DIR . 'assets/css/nsh-style.css' ) : NSH_VER;
    $js_ver  = file_exists( NSH_DIR . 'assets/js/nsh-app.js' )   ? filemtime( NSH_DIR . 'assets/js/nsh-app.js' )   : NSH_VER;
    wp_enqueue_style('nsh-style',NSH_URL.'assets/css/nsh-style.css',array(),$css_ver);
    // Admin-configured Form Styling (Settings -> Form Styling) overrides —
    // loaded as inline CSS right after the stylesheet so a later :root
    // declaration of the same --nsh-* variable wins naturally, no
    // !important needed. Only variables an admin actually changed are
    // emitted (see nsh_form_style_inline_css()), everything else keeps the
    // stylesheet's built-in defaults.
    if ( function_exists( 'nsh_form_style_inline_css' ) ) {
        $form_style_css = nsh_form_style_inline_css();
        if ( $form_style_css ) { wp_add_inline_style( 'nsh-style', $form_style_css ); }
    }
    // Opt-in scroll diagnostics: only when the URL has ?nshdebug=1. Loaded in the
    // <head> (not the footer) so it can wrap the scroll APIs before any other
    // script uses them. Read-only; sends nothing anywhere. See the file header.
    if ( ! is_admin() && isset( $_GET['nshdebug'] ) ) {
        $dbg_ver = file_exists( NSH_DIR . 'assets/js/nsh-scroll-debug.js' ) ? filemtime( NSH_DIR . 'assets/js/nsh-scroll-debug.js' ) : NSH_VER;
        wp_enqueue_script( 'nsh-scroll-debug', NSH_URL . 'assets/js/nsh-scroll-debug.js', array(), $dbg_ver, false );
    }
    wp_enqueue_script('sortablejs',NSH_URL.'assets/js/Sortable.min.js',array(),'1.15.2',true);
    wp_enqueue_script('nsh-app',NSH_URL.'assets/js/nsh-app.js',array('jquery','sortablejs'),$js_ver,true);
    wp_localize_script('nsh-app','NSH',array(
        'ajax_url'     =>admin_url('admin-ajax.php'),
        'nonce'        =>wp_create_nonce('nsh_frontend_nonce'),
        'admin_nonce'  =>wp_create_nonce('nsh_admin_nonce'),
        'upload_nonce' =>wp_create_nonce('nsh_upload_nonce'),
        'home_url'     =>home_url(),
        'is_logged_in' =>is_user_logged_in()?1:0,
        'is_staff'     =>nsh_is_staff()?1:0,
        'user_id'      =>get_current_user_id(),
        'dash_base'    =>function_exists('nsh_plat_js_paths')?nsh_plat_js_paths()['dash_base']:'/admin-dashboard',
        'client_base'  =>function_exists('nsh_plat_js_paths')?nsh_plat_js_paths()['client_base']:'/client-dashboard',
    ));
}

/**
 * The admin dashboard's per-tab "control" scripts (Requests-list loader,
 * Form Fields' field-map, Form Submissions' loader, Settings' whole panel)
 * used to be printed as a raw '<script>...</script>' string baked directly
 * into the shortcode's returned HTML — fine for the AJAX tab-swap path
 * (that HTML is JSON, never touches WordPress content filters), but on the
 * FIRST full page load that same HTML is the shortcode's return value,
 * which becomes page content and goes through the_content filter chain —
 * including wp_kses_post() whenever the viewing/saving context doesn't
 * carry the unfiltered_html capability (a non-super-admin on multisite, or
 * a theme/page-builder — e.g. Elementor's Text Editor widget — that
 * explicitly re-sanitizes rendered widget output on every request
 * regardless of role). wp_kses_post() strips the <script>/</script> tags
 * themselves but — since it doesn't special-case script CONTENT — leaves
 * the JS source sitting there as plain text, AND any HTML-looking
 * fragments inside that JS source that happen to use an allowed tag name
 * (this code builds rows full of literal `<div>`, `<select>`, `<button>`
 * markup as JS string literals) get parsed by the browser as real,
 * unstyled/misplaced elements. That combination is exactly what shows up
 * as garbled code text and stray buttons/dropdowns sitting in the middle
 * of the Admin Dashboard, with the script that was supposed to load the
 * request list never actually running (so a real, already-submitted
 * client request never appears — the AJAX call that would fetch it never
 * fires).
 *
 * The fix: never let one of these control scripts be part of page CONTENT
 * at all. $echo_inline=true (the default, used by the AJAX tab-swap
 * responses in ajax.php, which is already immune) prints it exactly as
 * before. $echo_inline=false (used only by the direct/first-full-page-load
 * callers in shortcodes.php/form-submissions.php/admin-settings-integrated.php)
 * instead hands the same JS — with no wrapping <script> tags — to
 * wp_add_inline_script(), which WordPress prints itself via its own
 * script-loader output (right after nsh-app.js's own <script> tag, so
 * jQuery/nsh-app.js are already loaded by the time it runs), completely
 * outside of and immune to the_content/kses/page-builder sanitization.
 */
function nsh_output_admin_script( $js, $echo_inline = true ) {
    if ( $echo_inline ) {
        return '<script>' . $js . '</script>';
    }
    // wp_add_inline_script() is a silent no-op if the 'nsh-app' handle
    // isn't registered yet — normally true by the time a shortcode runs
    // (nsh_enqueue() hooks 'wp_enqueue_scripts', which a theme's wp_head()
    // fires before the main content loop) but NOT guaranteed: some themes/
    // page builders (Elementor among them) build page content before
    // wp_head() runs, or via a code path that never fires
    // 'wp_enqueue_scripts' at the point this shortcode executes. Rather
    // than depend on that ordering, make sure the handle exists here too —
    // nsh_enqueue() runs again later (or for the first time) exactly as
    // normal and simply re-registers/re-localizes the same handle, which
    // is harmless.
    if ( ! wp_script_is( 'nsh-app', 'registered' ) && function_exists( 'nsh_enqueue' ) ) {
        nsh_enqueue();
    }
    wp_add_inline_script( 'nsh-app', $js, 'after' );
    return '';
}

/**
 * Admin Requests-tab "stuck on Loading…" safety net.
 *
 * The Requests tab starts with a static "Loading…" placeholder
 * (#nsh-admin-tbody, see nsh_admin_tab_requests()) that nsh_admin_js()'s
 * nshLoadAdminRequests() is supposed to replace with the real list a moment
 * later. That function already has its own 20s AJAX timeout and an error
 * handler that turns a failed/slow request into a visible red error message
 * — so as long as it actually RUNS, the placeholder can never hang forever.
 * But nsh_admin_js() is one very large hand-built inline script; anything
 * that stops it from running at all on a given page load (a stale cached
 * copy of an older page still serving pre-fix markup, a host/CDN caching
 * plugin serving a stale full-page snapshot from before the JS was even
 * attached, a plugin/theme conflict elsewhere on the page throwing before
 * nsh-app.js's own <script> block finishes registering everything below
 * it) leaves that placeholder exactly where it is, indefinitely, with no
 * way for the admin to recover except a manual full reload they may not
 * think to try.
 *
 * This is a small, completely independent script — attached to WordPress's
 * own 'jquery-core' handle rather than 'nsh-app', so a problem in nsh-app's
 * own script can never take this down with it — that watches for that one
 * specific stuck state and, after a grace period, replaces it with a
 * visible "taking longer than expected" message plus a Retry button (which
 * calls the real loader if it's available, or falls back to a full page
 * reload). It never interferes with a normal, successfully-loading tab —
 * it only ever acts if the placeholder is still there, unchanged, 8 full
 * seconds after being shown, which never happens in ordinary operation.
 */
function nsh_output_admin_requests_watchdog() {
    if ( ! wp_script_is( 'jquery-core', 'registered' ) ) {
        wp_enqueue_script( 'jquery' ); // registers jquery-core as a side effect
    }
    $js = '(function(){'
        . 'console.log("[NSH] requests-tab watchdog armed — plugin v' . esc_js( NSH_VER ) . '");'
        . 'function attachWatch(tbody){'
        . 'if(!tbody||tbody.getAttribute("data-nsh-watched")==="1")return;'
        . 'tbody.setAttribute("data-nsh-watched","1");'
        . 'setTimeout(function(){'
        . 'if(!document.body||!document.body.contains(tbody))return;'
        . 'if(tbody.querySelector(".nsh-tbl-loading")){'
        . 'console.log("[NSH] watchdog: still stuck on Loading after 8s — showing Retry");'
        . 'tbody.innerHTML="<div class=\'nsh-tbl-empty\' style=\'color:#ef4444;\'>This is taking longer than expected. <button type=\'button\' class=\'nsh-btn nsh-btn-xs nsh-btn-outline\' id=\'nsh-req-watchdog-retry\'>Retry</button></div>";'
        . 'var btn=document.getElementById("nsh-req-watchdog-retry");'
        . 'if(btn){btn.addEventListener("click",function(){tbody.removeAttribute("data-nsh-watched");if(window.nshLoadAdminRequests){window.nshLoadAdminRequests();}else{location.reload();}});}'
        . '}'
        . '},8000);'
        . '}'
        . 'function scanNow(){var t=document.getElementById("nsh-admin-tbody");if(t)attachWatch(t);}'
        . 'function init(){'
        . 'scanNow();'
        . 'var container=document.getElementById("nsh-admin-tab-container");'
        . 'if(container&&window.MutationObserver){new MutationObserver(scanNow).observe(container,{childList:true,subtree:true});}'
        . 'else{setInterval(scanNow,3000);}'
        . '}'
        . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",init);}else{init();}'
        . '})();';
    wp_add_inline_script( 'jquery-core', $js, 'after' );
}
