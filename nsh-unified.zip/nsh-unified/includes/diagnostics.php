<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * NSH Diagnostics — a single wp-admin page (Tools-capability gated) that
 * dumps every fact relevant to the "admin dashboard shows client dashboard
 * content" class of bug in one place, so a live-site issue that can't be
 * reproduced in a clean dev environment can still be diagnosed remotely
 * from its output instead of one manual check at a time.
 *
 * Covers, in one pass:
 *  - The exact row(s) WordPress has for each of the 6 core page slugs —
 *    including duplicates in ANY status (trash/draft/publish), which a
 *    normal Pages-list view hides. A duplicate slug is the #1 remaining
 *    explanation for "I fixed the content but it's still wrong": the
 *    content gets corrected on one row while a completely different row
 *    is what's actually being served.
 *  - Whether a server/host-level page cache is active (advanced-cache.php,
 *    object-cache.php, LiteSpeed's .htaccess rules, cached HTML files on
 *    disk) — these sit in front of WordPress and can serve a stored
 *    snapshot without this plugin's PHP ever running for that request, so
 *    no code fix here can reach them; only a purge on the host's side can.
 *  - The exact user/role/capability state for whoever loads this page,
 *    and what nsh_is_staff() resolves to for them right now — rules out
 *    "your session isn't really an administrator" as the cause.
 *  - Active plugins, so a caching/optimization plugin is named explicitly
 *    instead of guessed at.
 */
add_action( 'admin_menu', 'nsh_diagnostics_menu' );
function nsh_diagnostics_menu() {
    add_submenu_page(
        'nsh-platform',
        'NSH Diagnostics',
        '🩺 Diagnostics',
        'manage_options',
        'nsh-diagnostics',
        'nsh_diagnostics_page'
    );
}

function nsh_diagnostics_page() {
    if ( ! current_user_can( 'manage_options' ) ) {
        wp_die( 'You need administrator access to view this page.' );
    }

    global $wpdb;
    $report = array();

    // ── 1. Core page slugs: every row, every status ──────────────────────
    $slugs = array( 'nsh-request-submit', 'nsh-services' );
    $page_rows = array();
    foreach ( $slugs as $slug ) {
        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT ID, post_status, post_type, post_content, post_date, post_modified
             FROM {$wpdb->posts}
             WHERE post_name = %s
             ORDER BY ID ASC",
            $slug
        ) );
        $page_rows[ $slug ] = $rows;
    }

    // ── 2. What get_page_by_path() / the actual URL routing resolves to ─
    $resolved = array();
    foreach ( $slugs as $slug ) {
        $p = get_page_by_path( $slug );
        $resolved[ $slug ] = $p ? array( 'ID' => $p->ID, 'post_status' => $p->post_status ) : null;
    }

    // ── 3. Current user / role / capability state ────────────────────────
    $user_info = array();
    if ( is_user_logged_in() ) {
        $u = wp_get_current_user();
        $user_info = array(
            'ID'           => $u->ID,
            'user_login'   => $u->user_login,
            'user_email'   => $u->user_email,
            'roles'        => $u->roles,
            'can_administrator' => current_user_can( 'administrator' ),
            'can_nsh_admin'     => current_user_can( 'nsh_admin' ),
            'can_nsh_manager'   => current_user_can( 'nsh_manager' ),
            'nsh_is_staff_result' => function_exists( 'nsh_is_staff' ) ? ( nsh_is_staff() ? 'true' : 'false' ) : 'function missing',
        );
    }

    // ── 4. Caching layer fingerprints ─────────────────────────────────────
    $cache_signals = array();
    $cache_signals['advanced-cache.php present'] = file_exists( WP_CONTENT_DIR . '/advanced-cache.php' );
    $cache_signals['object-cache.php present']    = file_exists( WP_CONTENT_DIR . '/object-cache.php' );
    $cache_signals['WP_CACHE constant']           = defined( 'WP_CACHE' ) ? ( WP_CACHE ? 'true' : 'false' ) : 'not defined';
    $cache_signals['SERVER_SOFTWARE']             = isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( $_SERVER['SERVER_SOFTWARE'] ) : 'unknown';

    $cache_dirs = array(
        'wp-content/cache/'              => WP_CONTENT_DIR . '/cache/',
        'wp-content/litespeed/'          => WP_CONTENT_DIR . '/litespeed/',
        'wp-content/cache/page_enhanced/'=> WP_CONTENT_DIR . '/cache/page_enhanced/',
        'wp-content/wp-rocket-cache/'    => WP_CONTENT_DIR . '/wp-rocket-cache/',
    );
    $cache_dir_status = array();
    foreach ( $cache_dirs as $label => $path ) {
        if ( is_dir( $path ) ) {
            $count = 0;
            $it = @scandir( $path );
            if ( is_array( $it ) ) { $count = max( 0, count( $it ) - 2 ); }
            $cache_dir_status[ $label ] = "EXISTS ($count entries)";
        } else {
            $cache_dir_status[ $label ] = 'not present';
        }
    }

    // .htaccess — look for known cache-plugin fingerprint blocks
    $htaccess_path = ABSPATH . '.htaccess';
    $htaccess_flags = array();
    if ( file_exists( $htaccess_path ) && is_readable( $htaccess_path ) ) {
        $content = (string) file_get_contents( $htaccess_path );
        $needles = array( 'LiteSpeed', 'WP Super Cache', 'W3TC', 'WP_CACHE', 'wp-rocket', 'litespeed-cache' );
        foreach ( $needles as $n ) {
            $htaccess_flags[ $n ] = ( stripos( $content, $n ) !== false ) ? 'found' : 'not found';
        }
    } else {
        $htaccess_flags['(file not readable)'] = 'n/a';
    }

    // ── 5. Active plugins — flag anything caching/optimization related ───
    $active_plugins = (array) get_option( 'active_plugins', array() );
    $cache_plugin_hits = array();
    $cache_keywords = array( 'cache', 'litespeed', 'rocket', 'optimi', 'speed', 'varnish', 'cdn' );
    foreach ( $active_plugins as $p ) {
        foreach ( $cache_keywords as $kw ) {
            if ( stripos( $p, $kw ) !== false ) { $cache_plugin_hits[] = $p; break; }
        }
    }

    // ── 6. Plugin's own cache-prevention hook — confirm it's registered ──
    $hook_registered = has_action( 'template_redirect', 'nsh_prevent_dynamic_page_caching' ) !== false;

    // ── 7. nsh_db_version / migration state ───────────────────────────────
    $db_version = get_option( 'nsh_db_version', '(not set)' );

    // ── Render report ──────────────────────────────────────────────────────
    echo '<div class="wrap"><h1>🩺 NSH Diagnostics</h1>';
    echo '<p>Copy everything in the box below and send it back — this is everything needed to see why a page is showing the wrong content.</p>';
    echo '<textarea readonly style="width:100%;height:80vh;font-family:monospace;font-size:12px;padding:14px;box-sizing:border-box;">';

    $out = "NSH DIAGNOSTIC REPORT — generated " . current_time( 'mysql' ) . "\n";
    $out .= "Site URL: " . site_url() . " | Home URL: " . home_url() . "\n";
    $out .= "WP version: " . get_bloginfo( 'version' ) . " | PHP version: " . PHP_VERSION . "\n";
    $out .= "nsh_db_version option: {$db_version}\n";
    $out .= "nsh_prevent_dynamic_page_caching hooked on template_redirect: " . ( $hook_registered ? 'YES' : 'NO — ⚠ this plugin file may be out of date' ) . "\n";
    $out .= "\n================ 1. CORE PAGE ROWS (ALL STATUSES) ================\n";
    foreach ( $page_rows as $slug => $rows ) {
        $out .= "\n--- slug: {$slug} ---\n";
        if ( empty( $rows ) ) {
            $out .= "  ⚠ NO ROW AT ALL for this slug (page missing)\n";
            continue;
        }
        if ( count( $rows ) > 1 ) {
            $out .= "  ⚠⚠⚠ " . count( $rows ) . " ROWS FOUND FOR THIS SLUG — DUPLICATE PAGE. This is very likely the bug.\n";
        }
        foreach ( $rows as $r ) {
            $excerpt = trim( wp_strip_all_tags( $r->post_content ) );
            $excerpt = mb_substr( $excerpt, 0, 120 );
            $out .= "  ID={$r->ID}  status={$r->post_status}  type={$r->post_type}  modified={$r->post_modified}\n";
            $out .= "    content: " . $excerpt . "\n";
        }
    }

    $out .= "\n================ 2. WHAT get_page_by_path() ACTUALLY RESOLVES TO ================\n";
    foreach ( $resolved as $slug => $r ) {
        $out .= "  {$slug} => " . ( $r ? ( 'ID=' . $r['ID'] . ' status=' . $r['post_status'] ) : 'NOT FOUND' ) . "\n";
    }

    $out .= "\n================ 3. CURRENT LOGGED-IN USER (viewing this page) ================\n";
    if ( $user_info ) {
        foreach ( $user_info as $k => $v ) {
            $out .= "  {$k}: " . ( is_array( $v ) ? implode( ',', $v ) : $v ) . "\n";
        }
    } else {
        $out .= "  Not logged in.\n";
    }

    $out .= "\n================ 4. SERVER-LEVEL CACHE SIGNALS ================\n";
    foreach ( $cache_signals as $k => $v ) { $out .= "  {$k}: " . ( is_bool( $v ) ? ( $v ? 'YES' : 'no' ) : $v ) . "\n"; }
    $out .= "\n  Cache directories on disk:\n";
    foreach ( $cache_dir_status as $k => $v ) { $out .= "    {$k}: {$v}\n"; }
    $out .= "\n  .htaccess fingerprints:\n";
    foreach ( $htaccess_flags as $k => $v ) { $out .= "    {$k}: {$v}\n"; }

    $out .= "\n================ 5. ACTIVE PLUGINS ================\n";
    foreach ( $active_plugins as $p ) { $out .= "  - {$p}" . ( in_array( $p, $cache_plugin_hits, true ) ? '   ⚠ CACHE/SPEED-RELATED' : '' ) . "\n"; }
    if ( $cache_plugin_hits ) {
        $out .= "\n  ⚠ Caching/optimization plugin(s) detected: " . implode( ', ', $cache_plugin_hits ) . "\n";
        $out .= "  If the admin dashboard is still showing wrong content, use this plugin's own\n";
        $out .= "  \"Purge All / Purge Everything\" button (not just the browser refresh).\n";
    } else {
        $out .= "\n  No caching/optimization plugin detected among active plugins (the cache, if any, is likely at the hosting/server level, not a WP plugin).\n";
    }

    $out .= "\n================ END OF REPORT ================\n";

    echo esc_textarea( $out );
    echo '</textarea></div>';
}
