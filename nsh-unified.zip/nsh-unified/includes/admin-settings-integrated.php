<?php
/**
 * Integrated Admin Settings Panel - v6.2.1
 * ALL features in one clean dashboard interface
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

// Replace the settings tab with comprehensive interface
//
// @param bool $echo_inline_script See nsh_output_admin_script()'s docblock
//   (enqueue.php) / nsh_settings_js() below. true (default, the AJAX
//   tab-swap response in ajax.php) keeps this tab's big inline <script>
//   raw, as before. false (nsh_sc_admin_dashboard()'s direct/first-full-
//   page render, where this becomes page content) routes it through
//   wp_add_inline_script() instead, immune to content-filter corruption.
function nsh_admin_tab_settings( $echo_inline_script = true ) {
    $section = isset($_GET['section']) ? sanitize_text_field($_GET['section']) : 'email_templates';
    
    $o = '<div class="nsh-tab-content">';
    
    // Settings Navigation
    $o .= '<div class="nsh-settings-nav" style="background: white; padding: 15px 20px; margin-bottom: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<div style="display: flex; gap: 10px; flex-wrap: wrap;">';
    
    $sections = array(
        'services' => '🧾 Services',
        'dashboards' => '🧭 Dashboards & Access',
        'shortcodes' => '🔗 Shortcodes',
        'email_templates' => '📧 Email Templates',
        'quick_replies' => '⚡ Quick Replies',
        'holidays' => '📅 Holidays',
        'internal_statuses' => '🏷️ Internal Statuses',
        'form_style' => '🎨 Form Styling',
        'captcha' => '🛡️ Bot Protection',
        'general' => '⚙️ General Settings'
    );

    foreach ($sections as $key => $label) {
        $active = ($section === $key) ? 'nsh-btn-primary' : 'nsh-btn-outline';
        $o .= '<a href="?tab=settings&section=' . $key . '" class="nsh-btn ' . $active . ' nsh-btn-sm">' . esc_html($label) . '</a>';
    }

    $o .= '</div></div>';

    // Content based on section
    if ($section === 'services') {
        $o .= nsh_settings_services();
    } elseif ($section === 'dashboards') {
        $o .= nsh_settings_dashboards();
    } elseif ($section === 'shortcodes') {
        $o .= nsh_settings_shortcodes();
    } elseif ($section === 'email_templates') {
        $o .= nsh_settings_email_templates();
    } elseif ($section === 'quick_replies') {
        $o .= nsh_settings_quick_replies();
    } elseif ($section === 'holidays') {
        $o .= nsh_settings_holidays();
    } elseif ($section === 'internal_statuses') {
        $o .= nsh_settings_internal_statuses();
    } elseif ($section === 'form_style') {
        $o .= nsh_settings_form_style();
    } elseif ($section === 'captcha') {
        $o .= nsh_settings_captcha();
    } else {
        $o .= nsh_settings_general();
    }
    
    $o .= '</div>';
    
    // Add inline JavaScript for this section
    $o .= nsh_settings_js( $echo_inline_script );

    return $o;
}

// EMAIL TEMPLATES SECTION
function nsh_settings_email_templates() {
    $template_type = isset($_GET['tpl']) ? sanitize_text_field($_GET['tpl']) : 'quotation';
    $template      = nsh_get_email_template($template_type);

    // Use unified list (built-in + any custom ones admin created)
    $templates = function_exists('nsh_get_all_template_types') ? nsh_get_all_template_types() : array(
        'quotation'            => '💰 Quotation',
        'application_received' => '✅ Application Received',
        'status_update'        => '🔄 Status Update',
        'document_reminder'    => '📄 Document Reminder',
        'completion'           => '🎉 Completion',
        'dispatch'             => '📦 Dispatch',
        'terms_conditions'     => '📋 Terms & Conditions',
    );

    // Built-in types (cannot be deleted)
    $builtin_types = array('quotation','application_received','status_update','document_reminder','completion','dispatch','terms_conditions','new_request_admin');

    $o = '<div class="nsh-settings-section">';
    $o .= '<h3 style="margin: 0 0 20px;">📧 Professional Email Templates</h3>';

    // Template selector tabs
    $o .= '<div style="display: flex; gap: 8px; margin-bottom: 20px; flex-wrap: wrap; align-items: center;">';
    foreach ($templates as $type => $label) {
        $active = ($type === $template_type) ? 'nsh-btn-primary' : 'nsh-btn-ghost';
        $o .= '<button class="nsh-btn ' . $active . ' nsh-btn-sm" onclick="location.href=\'?tab=settings&section=email_templates&tpl=' . $type . '\'">' . esc_html($label) . '</button>';
    }
    // New template button
    $o .= '<button class="nsh-btn nsh-btn-outline nsh-btn-sm" onclick="nshCreateNewTemplate()" style="margin-left:auto;">➕ New Template</button>';
    $o .= '</div>';

    // Template editor
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<form id="nsh-email-template-form" method="post">';
    $o .= '<input type="hidden" name="action" value="nsh_save_email_template">';
    $o .= '<input type="hidden" name="template_type" value="' . esc_attr($template_type) . '">';
    $o .= wp_nonce_field('nsh_email_template', '_nonce', true, false);

    // Subject
    $o .= '<div class="nsh-field">';
    $o .= '<label><strong>Email Subject</strong></label>';
    $o .= '<input type="text" name="subject" value="' . esc_attr($template['subject']) . '" class="nsh-input-lg" required style="width: 100%; padding: 10px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $o .= '<p class="nsh-hint" style="font-size:12px;color:#6b7280;margin:6px 0 0;">Variables: <code>{CUSTOMER_NAME}</code> <code>{REQUEST_ID}</code> <code>{DOCUMENT_TYPE}</code> <code>{UNIVERSITY_NAME}</code> <code>{QUOTATION_AMOUNT}</code> <code>{SHIPPING_CHARGES}</code> <code>{TOTAL_AMOUNT}</code> <code>{TIMELINE}</code> <code>{DELIVERY_DATE}</code> <code>{STATUS}</code> <code>{PLATFORM}</code></p>';
    $o .= '</div>';

    // Body — with rich text / HTML toggle
    $o .= '<div class="nsh-field" style="margin-top: 20px;">';
    $o .= '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">';
    $o .= '<label><strong>Email Body</strong></label>';
    $o .= '<div style="display:flex;gap:6px;">';
    $o .= '<button type="button" class="nsh-btn nsh-btn-sm nsh-btn-outline nsh-view-btn active" data-view="html" onclick="nshSwitchView(\'html\')">🖥️ HTML Source</button>';
    $o .= '<button type="button" class="nsh-btn nsh-btn-sm nsh-btn-ghost nsh-view-btn" data-view="preview" onclick="nshSwitchView(\'preview\')">👁️ Rich Preview</button>';
    $o .= '</div></div>';

    // HTML textarea (default visible)
    $o .= '<div id="nsh-html-view">';
    $o .= '<textarea name="body" id="email-body" rows="18" style="width: 100%; padding: 10px; border: 1px solid #e5e7eb; border-radius: 6px; font-family: monospace; font-size: 13px; box-sizing:border-box;">' . esc_textarea($template['body']) . '</textarea>';
    $o .= '<p class="nsh-hint" style="font-size:12px;color:#6b7280;margin:4px 0 0;">HTML formatting supported. Variables are replaced automatically when sending.</p>';
    $o .= '</div>';

    // Rich preview pane (hidden by default)
    $o .= '<div id="nsh-preview-view" style="display:none;">';
    $o .= '<div style="border:1px solid #e5e7eb;border-radius:6px;padding:10px;background:#f9fafb;margin-bottom:6px;">';
    $o .= '<p style="margin:0 0 8px;font-size:12px;color:#6b7280;">⚠️ Rich preview shows rendered HTML. Edit in HTML Source mode. Variables shown as placeholders.</p>';
    $o .= '<iframe id="nsh-preview-frame" style="width:100%;min-height:400px;border:none;border-radius:4px;background:white;" srcdoc=""></iframe>';
    $o .= '</div>';
    $o .= '</div>';
    $o .= '</div>';

    // Actions row
    $o .= '<div style="margin-top: 20px; display: flex; gap: 10px; flex-wrap: wrap; align-items:center;">';
    $o .= '<button type="button" class="nsh-btn nsh-btn-primary" onclick="nshSaveEmailTemplate()">💾 Save Template</button>';
    $o .= '<button type="button" class="nsh-btn nsh-btn-outline" onclick="nshResetEmailTemplate(\'' . $template_type . '\')">🔄 Reset to Default</button>';
    $o .= '<button type="button" class="nsh-btn nsh-btn-ghost" onclick="nshTestEmail(\'' . $template_type . '\')">📧 Send Test Email</button>';
    $o .= '<button type="button" class="nsh-btn nsh-btn-ghost" onclick="nshDuplicateTemplate(\'' . $template_type . '\')" style="margin-left:auto;">📋 Duplicate</button>';
    // Only show delete for custom (non-built-in) types
    if (!in_array($template_type, $builtin_types)) {
        $o .= '<button type="button" class="nsh-btn nsh-btn-danger nsh-btn-sm" onclick="nshDeleteCustomTemplate(\'' . $template_type . '\')">🗑️ Delete</button>';
    }
    $o .= '</div>';

    $o .= '<div id="email-template-message" style="margin-top: 15px;"></div>';
    $o .= '</form>';
    $o .= '</div>';

    // Help box
    $o .= '<div style="background: #eff6ff; padding: 15px; border: 1px solid #3b82f6; border-radius: 6px; margin-top: 20px;">';
    $o .= '<h4 style="margin: 0 0 10px;">💡 Template Variables Guide</h4>';
    $o .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:4px;font-size:13px;">';
    $vars = array(
        '{CUSTOMER_NAME}'    => 'Client\'s full name',
        '{REQUEST_ID}'       => 'Order / Request ID',
        '{DOCUMENT_TYPE}'    => 'Type of document requested (e.g. Transcript)',
        '{UNIVERSITY_NAME}'  => 'University name from form',
        '{QUOTATION_AMOUNT}' => 'Service charge amount',
        '{SHIPPING_CHARGES}' => 'Shipping charges',
        '{TOTAL_AMOUNT}'     => 'Total (service + shipping)',
        '{TIMELINE}'         => 'Working days estimate',
        '{DELIVERY_DATE}'    => 'Expected delivery date',
        '{STATUS}'           => 'Current request status',
        '{PLATFORM}'         => 'Your platform/business name',
    );
    foreach ($vars as $var => $desc) {
        $o .= '<div style="padding:3px 0;"><code style="background:#dbeafe;padding:1px 5px;border-radius:3px;font-size:12px;">' . $var . '</code> — ' . $desc . '</div>';
    }
    $o .= '</div>';
    $o .= '</div>';

    $o .= '</div>';
    return $o;
}

// QUICK REPLIES SECTION
function nsh_settings_quick_replies() {
    $replies = nsh_get_quick_replies();
    $editing = isset($_GET['edit']) ? sanitize_text_field($_GET['edit']) : null;
    $edit_reply = null;
    
    if ($editing) {
        foreach ($replies as $r) {
            if ($r['id'] === $editing) {
                $edit_reply = $r;
                break;
            }
        }
    }
    
    $o = '<div class="nsh-settings-section">';
    $o .= '<h3 style="margin: 0 0 20px;">⚡ Quick Replies (WhatsApp Style)</h3>';
    
    $o .= '<div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">';
    
    // Add/Edit Form
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<h4 style="margin: 0 0 15px;">' . ($edit_reply ? '✏️ Edit Reply' : '➕ Add New Reply') . '</h4>';
    
    $o .= '<form id="nsh-quick-reply-form">';
    if ($edit_reply) {
        $o .= '<input type="hidden" name="reply_id" value="' . esc_attr($edit_reply['id']) . '">';
    }
    
    $o .= '<div class="nsh-field">';
    $o .= '<label>Title *</label>';
    $o .= '<input type="text" name="title" value="' . ($edit_reply ? esc_attr($edit_reply['title']) : '') . '" required style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $o .= '</div>';
    
    $o .= '<div class="nsh-field">';
    $o .= '<label>Category</label>';
    $o .= '<select name="category" style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $categories = array('Documents', 'Status', 'General', 'Follow-up');
    foreach ($categories as $cat) {
        $selected = ($edit_reply && $edit_reply['category'] === $cat) ? 'selected' : '';
        $o .= '<option value="' . $cat . '" ' . $selected . '>' . $cat . '</option>';
    }
    $o .= '</select>';
    $o .= '</div>';
    
    $o .= '<div class="nsh-field">';
    $o .= '<label>Reply Content *</label>';
    $o .= '<textarea name="content" rows="8" required style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">' . ($edit_reply ? esc_textarea($edit_reply['content']) : '') . '</textarea>';
    $o .= '<p class="nsh-hint-sm">Use: {CUSTOMER_NAME}, {REQUEST_ID}, {TIMELINE}, {UNIVERSITY_NAME}</p>';
    $o .= '</div>';
    
    $o .= '<div style="display: flex; gap: 10px;">';
    if ($edit_reply) {
        $o .= '<button type="button" class="nsh-btn nsh-btn-primary nsh-btn-sm" onclick="nshUpdateQuickReply()">💾 Update</button>';
        $o .= '<a href="?tab=settings&section=quick_replies" class="nsh-btn nsh-btn-ghost nsh-btn-sm">Cancel</a>';
    } else {
        $o .= '<button type="button" class="nsh-btn nsh-btn-primary nsh-btn-sm" onclick="nshAddQuickReply()">➕ Add Reply</button>';
    }
    $o .= '</div>';
    
    $o .= '<div id="quick-reply-message" style="margin-top: 10px;"></div>';
    $o .= '</form>';
    $o .= '</div>';
    
    // Replies List
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<h4 style="margin: 0 0 15px;">📋 All Quick Replies (' . count($replies) . ')</h4>';
    
    if (empty($replies)) {
        $o .= '<p style="color: #999; text-align: center; padding: 20px;">No quick replies yet. Add your first one!</p>';
    } else {
        // Group by category
        $by_category = array();
        foreach ($replies as $reply) {
            $cat = $reply['category'] ? $reply['category'] : 'General';
            if (!isset($by_category[$cat])) {
                $by_category[$cat] = array();
            }
            $by_category[$cat][] = $reply;
        }
        
        foreach ($by_category as $category => $category_replies) {
            $o .= '<div style="margin-bottom: 15px;">';
            $o .= '<strong style="color: #2563eb;">📁 ' . esc_html($category) . '</strong>';
            
            foreach ($category_replies as $reply) {
                $o .= '<div style="border: 1px solid #e5e7eb; padding: 10px; margin-top: 5px; border-radius: 4px; background: #f9fafb;">';
                $o .= '<div style="display: flex; justify-content: space-between; align-items: start;">';
                $o .= '<div><strong style="font-size: 14px;">' . esc_html($reply['title']) . '</strong>';
                $o .= '<div style="font-size: 12px; color: #666; margin-top: 5px;">' . esc_html(wp_trim_words($reply['content'], 15)) . '</div></div>';
                $o .= '<div style="display: flex; gap: 5px;">';
                $o .= '<a href="?tab=settings&section=quick_replies&edit=' . esc_attr($reply['id']) . '" class="nsh-btn nsh-btn-sm" style="padding: 4px 8px; font-size: 12px;">✏️</a>';
                $o .= '<button onclick="nshDeleteQuickReply(\'' . esc_js($reply['id']) . '\')" class="nsh-btn nsh-btn-danger nsh-btn-sm" style="padding: 4px 8px; font-size: 12px;">🗑️</button>';
                $o .= '</div></div></div>';
            }
            
            $o .= '</div>';
        }
    }
    
    $o .= '</div>';
    
    $o .= '</div>'; // End grid
    $o .= '</div>';
    return $o;
}

// HOLIDAYS SECTION
function nsh_settings_holidays() {
    $year = isset($_GET['year']) ? intval($_GET['year']) : date('Y');
    $holidays = nsh_get_holidays($year . '-01-01', $year . '-12-31');
    
    $o = '<div class="nsh-settings-section">';
    $o .= '<h3 style="margin: 0 0 20px;">📅 Holiday Management & Delivery Calculator</h3>';
    
    $o .= '<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 20px;">';
    
    // Add Holiday Form
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<h4 style="margin: 0 0 15px;">➕ Add Holiday</h4>';
    
    $o .= '<form id="nsh-holiday-form">';
    $o .= '<div class="nsh-field">';
    $o .= '<label>Date *</label>';
    $o .= '<input type="date" name="holiday_date" required style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $o .= '</div>';
    
    $o .= '<div class="nsh-field">';
    $o .= '<label>Holiday Name *</label>';
    $o .= '<input type="text" name="holiday_name" placeholder="e.g., Republic Day" required style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $o .= '</div>';
    
    $o .= '<div class="nsh-field">';
    $o .= '<label>Type</label>';
    $o .= '<select name="holiday_type" style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $o .= '<option value="national">National Holiday</option>';
    $o .= '<option value="state">State Holiday</option>';
    $o .= '<option value="university">University Holiday</option>';
    $o .= '</select>';
    $o .= '</div>';
    
    $o .= '<button type="button" class="nsh-btn nsh-btn-primary nsh-btn-sm nsh-w100" onclick="nshAddHoliday()">➕ Add Holiday</button>';
    $o .= '<div id="holiday-message" style="margin-top: 10px;"></div>';
    $o .= '</form>';
    
    // Test Calculator
    $o .= '<hr style="margin: 20px 0;">';
    $o .= '<h4 style="margin: 0 0 10px;">🧮 Test Calculator</h4>';
    $o .= '<div class="nsh-field">';
    $o .= '<label>Working Days</label>';
    $o .= '<input type="number" id="test-days" value="30" min="1" style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;">';
    $o .= '</div>';
    $o .= '<button type="button" class="nsh-btn nsh-btn-outline nsh-btn-sm nsh-w100" onclick="nshTestCalculator()">🧮 Calculate Delivery Date</button>';
    $o .= '<div id="calculator-result" style="margin-top: 10px;"></div>';
    
    $o .= '</div>';
    
    // Holidays List
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    
    // Year navigation
    $o .= '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">';
    $o .= '<h4 style="margin: 0;">Holidays for ' . $year . ' (' . count($holidays) . ')</h4>';
    $o .= '<div style="display: flex; gap: 5px;">';
    $o .= '<a href="?tab=settings&section=holidays&year=' . ($year - 1) . '" class="nsh-btn nsh-btn-sm">◀ ' . ($year - 1) . '</a>';
    $o .= '<a href="?tab=settings&section=holidays&year=' . date('Y') . '" class="nsh-btn nsh-btn-primary nsh-btn-sm">Today</a>';
    $o .= '<a href="?tab=settings&section=holidays&year=' . ($year + 1) . '" class="nsh-btn nsh-btn-sm">' . ($year + 1) . ' ▶</a>';
    $o .= '</div></div>';
    
    if (empty($holidays)) {
        $o .= '<p style="color: #999; text-align: center; padding: 40px;">No holidays for ' . $year . '</p>';
    } else {
        $o .= '<div style="max-height: 500px; overflow-y: auto;">';
        $o .= '<table class="nsh-tbl" style="width: 100%;">';
        $o .= '<thead><tr><th>Date</th><th>Holiday</th><th>Type</th><th>Day</th><th>Action</th></tr></thead><tbody>';
        
        foreach ($holidays as $holiday) {
            $type_color = $holiday->holiday_type === 'national' ? '#10b981' : ($holiday->holiday_type === 'state' ? '#3b82f6' : '#f59e0b');
            $o .= '<tr>';
            $o .= '<td><strong>' . date('M j', strtotime($holiday->date)) . '</strong></td>';
            $o .= '<td>' . esc_html($holiday->holiday_name) . '</td>';
            $o .= '<td><span style="padding: 2px 8px; border-radius: 3px; font-size: 11px; background: ' . $type_color . '22; color: ' . $type_color . ';">' . esc_html(ucfirst($holiday->holiday_type)) . '</span></td>';
            $o .= '<td style="font-size: 12px; color: #666;">' . date('l', strtotime($holiday->date)) . '</td>';
            $o .= '<td><button onclick="nshDeleteHoliday(' . intval($holiday->id) . ')" class="nsh-btn nsh-btn-danger nsh-btn-sm" style="padding: 4px 8px; font-size: 12px;">🗑️</button></td>';
            $o .= '</tr>';
        }
        
        $o .= '</tbody></table></div>';
    }
    
    $o .= '</div>';
    
    $o .= '</div>'; // End grid
    
    // Info box
    $o .= '<div style="background: #e0f2fe; padding: 15px; border: 1px solid #0ea5e9; border-radius: 6px; margin-top: 20px;">';
    $o .= '<h4 style="margin: 0 0 10px;">ℹ️ How Working Days Calculation Works</h4>';
    $o .= '<ul style="margin: 0; padding-left: 20px; font-size: 14px;">';
    $o .= '<li>When you set a timeline (e.g., 30 working days), the system automatically excludes weekends (Sat/Sun) and all holidays listed here</li>';
    $o .= '<li>National holidays apply to all requests</li>';
    $o .= '<li>2026 Indian holidays are already pre-loaded</li>';
    $o .= '<li>Example: 30 working days starting Jan 1, 2026 = actual delivery ~40 calendar days (excluding weekends + holidays)</li>';
    $o .= '</ul>';
    $o .= '</div>';
    
    $o .= '</div>';
    return $o;
}

// INTERNAL STATUS (CRM pipeline) MANAGEMENT — admin-only. Assigning an
// existing status to a request is a staff action (the card select in the
// Requests tab); defining/reordering/retiring the status list itself is
// gated to administrators only, matching the feature spec's "authorized
// administrators" wording and nsh_require_admin() in capabilities.php.
// SERVICES — activate/deactivate (show/hide) each of the 50 services.
// This is the ONE control point for which services appear in the
// Services field's dropdown on both [nsh_standalone_form] and the
// Client Dashboard's [nsh_request_form]: both forms render that dropdown
// from nsh_get_services(true) (helpers.php / schema.php), which already
// filters to is_active=1, and the background wizard-prefetch
// (nsh_ajax_prefetch_all_wizards, ajax.php) does the same — so flipping a
// service's toggle here is immediately reflected on both forms' next load
// with no other code path to update. Deactivating never deletes a
// service's data (fields, past requests, dropdown options all stay
// intact) — it only removes it from new selections, exactly like the
// existing Internal Status and Request Type "Active" toggles below.
function nsh_settings_services() {
    if ( ! nsh_is_admin_user() ) {
        return '<div class="nsh-settings-section"><div style="background:#fef2f2;border:1px solid #fecaca;color:#991b1b;padding:16px 20px;border-radius:8px;">Administrator access is required to manage services.</div></div>';
    }
    $services  = nsh_get_services( false ); // include inactive so they can be re-enabled here
    $cat_names = nsh_service_categories();
    $grouped   = array();
    foreach ( $services as $s ) { $grouped[ $s->category ][] = $s; }
    $active_count = count( array_filter( $services, function ( $s ) { return (int) $s->is_active === 1; } ) );

    $o  = '<div class="nsh-settings-section">';
    $o .= '<h3 style="margin:0 0 6px;">🧾 Services</h3>';
    $o .= '<p style="margin:0 0 20px;color:#64748b;font-size:13px;max-width:640px;">Turn a service on or off to control whether it shows up as a choice in the Services field — on the Client Dashboard\'s "New Request" form and on the standalone quote form. Turning one off never touches its fields, dropdown data, or any request already submitted for it; it just stops appearing as a NEW choice. Changes here are only saved when you click <strong>Save Changes</strong>.</p>';

    // Unsaved-changes banner — hidden until a checkbox is toggled away from
    // its last-saved state (see nshServicesCheckDirty() below). It and the
    // Save Changes button are the ONLY way toggles reach the database now;
    // toggling a checkbox no longer fires an AJAX call or reload by itself.
    $o .= '<div id="nsh-svc-unsaved-banner" style="display:none;background:#fffbeb;border:1px solid #fde68a;color:#92400e;padding:10px 16px;border-radius:8px;font-size:13px;margin-bottom:14px;align-items:center;justify-content:space-between;">';
    $o .= '<span>⚠️ You have unsaved changes to which services are active.</span>';
    $o .= '</div>';

    $o .= '<div style="background:white;padding:16px 20px;border:1px solid #e5e7eb;border-radius:8px;">';
    $o .= '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:14px;flex-wrap:wrap;gap:10px;">';
    $o .= '<h4 style="margin:0;" id="nsh-svc-active-count">' . intval( $active_count ) . ' of ' . intval( count( $services ) ) . ' services active</h4>';
    $o .= '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">';
    $o .= '<input type="text" id="nsh-svc-search" placeholder="Search services…" style="padding:7px 12px;border:1px solid #e5e7eb;border-radius:6px;font-size:13px;min-width:220px;" oninput="nshFilterServicesTable(this.value)">';
    $o .= '<button type="button" class="nsh-btn nsh-btn-outline nsh-btn-sm" id="nsh-svc-add-new-btn" onclick="nshToggleAddServicePanel()">+ Add New Service</button>';
    $o .= '<button type="button" class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-svc-save-changes-btn" onclick="nshSaveServicesChanges()" disabled>Save Changes</button>';
    $o .= '</div></div>';

    // Add New Service panel — hidden by default, same collapsible-panel
    // pattern as the Form Fields tab's "Add / Edit Field" panel (shortcodes.php,
    // nsh_admin_tab_fields()) for a consistent admin UI.
    $o .= nsh_render_add_service_panel( $cat_names );

    $o .= '<div id="nsh-svc-mgmt-list" style="max-height:600px;overflow-y:auto;">';
    $o .= nsh_render_services_mgmt_rows( $grouped, $cat_names );
    $o .= '</div>';
    $o .= '</div></div>';
    return $o;
}

function nsh_render_add_service_panel( $cat_names ) {
    $o = '<div id="nsh-add-service-panel" class="nsh-panel-card" style="display:none;margin-bottom:16px;border:1px solid #e5e7eb;border-radius:8px;padding:16px 18px;background:#f8fafc;">';
    $o .= '<h4 style="margin:0 0 14px;">Add New Service</h4>';
    $o .= '<div class="nsh-form-grid">';
    $o .= '<div class="nsh-field"><label>Service Name *</label><input type="text" id="nsvc-name" placeholder="e.g. Power of Attorney Renewal" oninput="nshAutoSlug()"></div>';
    $o .= '<div class="nsh-field"><label>Slug <span style="font-weight:400;color:#94a3b8;font-size:12px;">(used in URLs, auto-filled)</span></label><input type="text" id="nsvc-slug" placeholder="e.g. power-of-attorney-renewal"></div>';
    $o .= '<div class="nsh-field"><label>Category *</label><select id="nsvc-category"><option value="">-- Select category --</option>';
    foreach ( $cat_names as $slug => $c ) {
        $o .= '<option value="' . esc_attr( $slug ) . '">' . esc_html( $c['name'] ) . '</option>';
    }
    $o .= '</select></div>';
    $o .= '<div class="nsh-field"><label>Turnaround (days)</label><input type="number" id="nsvc-turnaround" value="7" min="1"></div>';
    $o .= '<div class="nsh-field"><label>Pricing Model</label><select id="nsvc-pricing" onchange="document.getElementById(\'nsvc-price-wrap\').style.display=this.value===\'fixed\'?\'block\':\'none\';"><option value="quote">Custom Quote</option><option value="fixed">Fixed Price</option></select></div>';
    $o .= '<div class="nsh-field" id="nsvc-price-wrap" style="display:none;"><label>Base Price (₹)</label><input type="number" id="nsvc-price" min="0" step="0.01"></div>';
    $o .= '</div>';
    $o .= '<div class="nsh-field nsh-field-full" style="margin-top:10px;"><label>Short Description</label><textarea id="nsvc-desc" rows="2" placeholder="One line describing this service, shown on the public catalog." style="width:100%;padding:8px 12px;border:1px solid #e2e8f0;border-radius:8px;font-size:13px;resize:vertical;"></textarea></div>';
    $o .= '<div class="nsh-field nsh-field-full" style="margin-top:10px;"><label>Required Documents <span style="font-weight:400;color:#94a3b8;font-size:12px;">(one per line)</span></label><textarea id="nsvc-docs" rows="3" placeholder="Aadhaar Card&#10;Address Proof&#10;Passport Photo" style="width:100%;padding:8px 12px;border:1px solid #e2e8f0;border-radius:8px;font-size:13px;resize:vertical;"></textarea></div>';
    $o .= '<div style="margin-top:10px;"><label style="display:inline-flex;align-items:center;gap:6px;font-size:13px;cursor:pointer;"><input type="checkbox" id="nsvc-active" checked> Make this service active immediately</label></div>';
    $o .= '<p class="nsh-hint" style="margin-top:12px;">A starting "Contact Details" + "Documents" form is created automatically so the service is submittable right away. Add its own questions afterward from the <strong>Form Fields</strong> tab.</p>';
    $o .= '<div style="display:flex;gap:10px;margin-top:12px;"><button class="nsh-btn nsh-btn-primary nsh-btn-sm" id="nsh-svc-do-create" onclick="nshCreateService()">Create Service</button><button class="nsh-btn nsh-btn-ghost nsh-btn-sm" onclick="nshToggleAddServicePanel(false)">Cancel</button></div>';
    $o .= '<div id="nsh-svc-create-msg" class="nsh-alert" style="display:none;margin-top:10px;"></div>';
    $o .= '</div>';
    return $o;
}

// SHORTCODES REFERENCE — a single admin-visible source of truth for every
// shortcode this plugin registers, so the site owner has complete control
// over where each piece of the plugin appears on their site instead of the
// plugin silently deciding that for them. Purely documentation/reference —
// it registers nothing and creates nothing; placing a shortcode on any page
// (a plugin-created one or the admin's own) is always the admin's own,
// manual choice.
// nsh_settings_shortcodes() below displays literal shortcode syntax —
// "[nsh_services]", "linked from [nsh_services]", and so on — purely as
// DOCUMENTATION TEXT for the admin to read and copy, never meant to be
// executed. On a plain WordPress page, that is completely safe: the_content
// runs do_shortcode() exactly once on the page's own raw content, finds
// [nsh_admin_dashboard], calls its callback, and does not re-scan that
// callback's returned HTML for more shortcodes.
//
// But on a site where [nsh_admin_dashboard] is placed via a page builder's
// own "Shortcode" widget (Elementor's, for example) rather than as plain
// page content, some setups run do_shortcode() a SECOND time — once to
// render the widget's own shortcode, and again as part of a later content
// filter pass over the already-rendered page. WordPress's shortcode parser
// has no way to tell "the literal 8 characters [nsh_services] typed here
// as an example" apart from "an actual [nsh_services] shortcode to run" —
// on that second pass it just sees the bracket text and executes it for
// real. That is exactly what was happening: every literal shortcode
// example in this table was being replaced with that shortcode's ACTUAL
// rendered output — the whole 51-service public catalog appearing where
// "[nsh_services]" should have been plain text, and — because
// "[nsh_admin_dashboard]" itself appears further down this very table as
// an example — the entire Admin Dashboard (including this Settings page,
// including this same table) recursively re-rendering itself multiple
// times on one page.
//
// The fix used throughout this function: encode the literal [ and ]
// characters as HTML entities wherever they appear as plain
// example/reference text, so do_shortcode()'s regex — which only ever
// matches literal bracket CHARACTERS, never an entity — has nothing to
// match, on any number of processing passes.
//
// IMPORTANT: this must NOT use the decimal entities &#91; / &#93;.
// WordPress's own do_shortcode() ends every single call with
// unescape_invalid_shortcodes() (wp-includes/shortcodes.php), which runs
// strtr( $content, array( '&#91;' => '[', '&#93;' => ']' ) ) on the WHOLE
// result — that's WordPress's own mechanism for restoring
// double-bracket-escaped "[[shortcode]]" text and things like
// "<!--[if IE ]>", and it does not know or care that OUR &#91;/&#93; meant
// something different. That single built-in cleanup step silently turns
// our escaped brackets back into live, literal "[" and "]" characters
// before do_shortcode() even returns for the FIRST time — which is
// exactly the bug this function exists to prevent, just reintroduced by
// WordPress core itself one line later. The hex entities &#x5B; / &#x5D;
// render identically to the eye and to a browser's HTML parser, but
// WordPress's unescape step only ever looks for the decimal form, so they
// pass through completely untouched no matter how many times
// do_shortcode() runs.
function nsh_escape_shortcode_brackets( $text ) {
    return str_replace( array( '[', ']' ), array( '&#x5B;', '&#x5D;' ), $text );
}
// For fields rendered via esc_html() (plain text, no intentional HTML).
function nsh_sc_literal_html( $text ) {
    return nsh_escape_shortcode_brackets( esc_html( $text ) );
}
// For fields rendered via esc_attr() (HTML attribute values).
function nsh_sc_literal_attr( $text ) {
    return nsh_escape_shortcode_brackets( esc_attr( $text ) );
}
// For fields rendered via wp_kses_post() (prose that intentionally
// contains inline HTML like <code>...</code>, and may itself mention a
// literal shortcode by name).
function nsh_sc_literal_kses( $text ) {
    return nsh_escape_shortcode_brackets( wp_kses_post( $text ) );
}

function nsh_settings_shortcodes() {
    if ( ! nsh_is_admin_user() ) {
        return '<div class="nsh-settings-section"><div style="background:#fef2f2;border:1px solid #fecaca;color:#991b1b;padding:16px 20px;border-radius:8px;">Administrator access is required to view this page.</div></div>';
    }

    // Which of these live on a page the plugin itself created at activation
    // (see nsh_create_pages() in includes/admin-menu.php) — shown so it's
    // clear those are a convenience starting point, not the only place the
    // shortcode can be used; every one of them can be placed on any other
    // page, post, or template area as well.
    $rows = array(
        array(
            'code'    => '[nsh_services]',
            'purpose' => 'Public catalog of every active service, grouped by category, each linking to its request form. The entry point for a visitor browsing what the platform offers.',
            'where'   => 'Any page — typically a "Services" or "What we do" page. Already used on the plugin-created Services page.',
            'attrs'   => 'None.',
            'example' => '[nsh_services]',
            'related' => 'Services page (nsh-services) · function nsh_sc_services()',
        ),
        array(
            'code'    => '[nsh_request_form]',
            'purpose' => 'The full multi-step service request wizard — service picker, dynamic per-service fields, document upload, and submission. This is the main client-facing intake form.',
            'where'   => 'Any page. Reads ?service=&lt;slug&gt; from the URL to pre-select a service (e.g. linked from [nsh_services]).',
            'attrs'   => 'None (service selection comes from the URL, not a shortcode attribute).',
            'example' => '[nsh_request_form]',
            'related' => 'Request Submit page (nsh-request-submit) · function nsh_sc_request_form()',
        ),
        array(
            'code'    => '[nsh_standalone_form]',
            'purpose' => 'The same wizard as [nsh_request_form], but lockable to ONE specific service via a shortcode attribute — for embedding a single service\'s form on its own dedicated landing page instead of the general intake page.',
            'where'   => 'A per-service landing page, e.g. a "PAN Card Apostille" page that should only ever show that one form.',
            'attrs'   => '<code>service</code> (optional) — a service slug (see the Services tab for each service\'s slug). Falls back to ?service= in the URL if omitted.',
            'example' => '[nsh_standalone_form service="apostille"]',
            'related' => 'function nsh_sc_standalone_form()',
        ),
        array(
            'code'    => '[nsh_login_form]',
            'purpose' => 'Email/password + magic-link login form for both clients and staff. Redirects an already-logged-in visitor straight to their dashboard.',
            'where'   => 'Any page — typically a dedicated login page.',
            'attrs'   => '<code>title</code> (optional) — heading text shown above the form. Default: "Client Login".',
            'example' => '[nsh_login_form title="Sign In"]',
            'related' => 'NSH Login page (nsh-login) · function nsh_sc_login_form()',
        ),
        array(
            'code'    => '[nsh_login_button]',
            'purpose' => 'A small inline button/link — "Client Login" if logged out, or the visitor\'s own name linking straight to their dashboard if already logged in. Meant for a header, menu, or sidebar, not a full page.',
            'where'   => 'Anywhere a compact login link is needed — a header widget, a menu item block, inside other page content.',
            'attrs'   => '<code>label</code> (optional, default "Client Login"), <code>class</code> (optional) — extra CSS class(es) on the link.',
            'example' => '[nsh_login_button label="My Account"]',
            'related' => 'function nsh_sc_login_button()',
        ),
        array(
            'code'    => '[nsh_admin_login_button]',
            'purpose' => 'Same idea as [nsh_login_button], but always links to the staff/admin login or dashboard rather than the client one.',
            'where'   => 'A staff-only area of the site, an internal intranet page, or a footer link for team members.',
            'attrs'   => '<code>label</code> (optional, default "Staff Login").',
            'example' => '[nsh_admin_login_button label="Team Login"]',
            'related' => 'function nsh_sc_admin_login_button()',
        ),
        array(
            'code'    => '[nsh_client_dashboard]',
            'purpose' => 'The logged-in client\'s dashboard — their requests, documents, messages, and profile. Shows a login prompt instead if the visitor isn\'t authenticated.',
            'where'   => 'Any page — typically a dedicated "My Account" / "Dashboard" page. This is where a client lands automatically after submitting a request or logging in.',
            'attrs'   => 'None.',
            'example' => '[nsh_client_dashboard]',
            'related' => 'Client Dashboard page (nsh-client-dashboard) · function nsh_sc_client_dashboard()',
        ),
        array(
            'code'    => '[nsh_request_view]',
            'purpose' => 'The single-request detail screen (status, documents, messages, timeline) for one specific request, identified by the URL.',
            'where'   => 'The plugin-created Request page only — it relies on the /nsh-request/{id}/ rewrite rule registered specifically for that page (see nsh_rewrite_rules()). Not intended for placement on other pages.',
            'attrs'   => 'None (the request ID comes from the URL, not a shortcode attribute).',
            'example' => '[nsh_request_view]',
            'related' => 'Request page (nsh-request) · function nsh_sc_request_view()',
        ),
        array(
            'code'    => '[nsh_admin_dashboard]',
            'purpose' => 'The full staff/admin back-office console — requests, submissions, support tickets, form field editor, settings (including this page). Restricted to staff accounts; shows an access-denied message otherwise.',
            'where'   => 'The plugin-created Admin Dashboard page. Could technically be placed elsewhere, but there is normally no reason to duplicate it.',
            'attrs'   => 'None.',
            'example' => '[nsh_admin_dashboard]',
            'related' => 'Admin Dashboard page (nsh-admin-dashboard) · function nsh_sc_admin_dashboard()',
        ),
    );

    $plugin_pages = array( 'nsh-request-submit', 'nsh-services' );

    $o  = '<div class="nsh-settings-section">';
    $o .= '<h3 style="margin:0 0 6px;">🔗 Shortcodes</h3>';
    $o .= '<p style="margin:0 0 16px;color:#64748b;font-size:13px;max-width:760px;">Every shortcode this plugin makes available, in one place, so you have full control over where each one appears. This plugin does not take over your site automatically: it only creates the ' . count( $plugin_pages ) . ' public pages listed below as a convenience starting point (the sign-in page and the Client, Staff and Admin dashboards are standalone plugin addresses set under Settings → Dashboards &amp; Access, and need no page or shortcode) (each pre-filled with its matching shortcode, left as an ordinary editable WordPress page — never set as your homepage or Reading Settings), and every shortcode can also be added to any page, post, or template of your own the same way you\'d add any other shortcode.</p>';

    $o .= '<div style="background:#eff6ff;border:1px solid #bfdbfe;color:#1e40af;padding:12px 16px;border-radius:8px;font-size:12.5px;margin-bottom:20px;max-width:760px;">';
    $o .= '<strong>Plugin-created pages:</strong> ';
    $links = array();
    foreach ( $plugin_pages as $slug ) {
        $links[] = '<a href="' . esc_url( home_url( '/' . $slug . '/' ) ) . '" target="_blank" style="color:#1e40af;">/' . esc_html( $slug ) . '/</a>';
    }
    $o .= implode( ', ', $links );
    $o .= ' — each is an ordinary Page in your WordPress admin under <em>Pages</em>, so you can rename it, move it in your menu, change its slug, or delete it and re-embed its shortcode somewhere of your own choosing at any time.';
    $o .= '</div>';

    $o .= '<div style="background:white;border:1px solid #e5e7eb;border-radius:8px;overflow-x:auto;">';
    $o .= '<table class="nsh-tbl" style="width:100%;min-width:920px;">';
    $o .= '<thead><tr><th style="width:190px;">Shortcode</th><th>Purpose</th><th style="width:200px;">Where it can be used</th><th style="width:220px;">Attributes</th><th style="width:200px;">Example</th><th style="width:200px;">Related</th></tr></thead><tbody>';
    foreach ( $rows as $r ) {
        $o .= '<tr>';
        // See the "Shortcodes tab: Copy buttons" note in nsh_settings_js()
        // below for why this is a data-attribute + delegated click handler
        // rather than an inline onclick: an inline onclick containing quote
        // characters gets silently corrupted by WordPress's wptexturize()
        // filter on this page (rendered as ordinary post content), breaking
        // this row's HTML and everything after it in the table.
        $o .= '<td><code style="background:#f1f5f9;padding:3px 6px;border-radius:4px;font-size:12px;white-space:nowrap;">' . nsh_sc_literal_html( $r['code'] ) . '</code>';
        $o .= '<button type="button" class="nsh-link nsh-sc-copy-btn" data-copy="' . nsh_sc_literal_attr( $r['code'] ) . '" style="display:block;font-size:11px;margin-top:4px;">Copy</button></td>';
        $o .= '<td style="font-size:12.5px;">' . nsh_sc_literal_kses( $r['purpose'] ) . '</td>';
        $o .= '<td style="font-size:12.5px;color:#475569;">' . nsh_sc_literal_kses( $r['where'] ) . '</td>';
        $o .= '<td style="font-size:12.5px;color:#475569;">' . nsh_sc_literal_kses( $r['attrs'] ) . '</td>';
        $o .= '<td><code style="background:#f1f5f9;padding:3px 6px;border-radius:4px;font-size:11.5px;">' . nsh_sc_literal_html( $r['example'] ) . '</code></td>';
        $o .= '<td style="font-size:11.5px;color:#94a3b8;">' . esc_html( $r['related'] ) . '</td>';
        $o .= '</tr>';
    }
    $o .= '</tbody></table></div></div>';
    return $o;
}

// Shared row-renderer, same pattern as nsh_render_internal_status_mgmt_rows
// below — one source of markup for the settings page's first render.
function nsh_render_services_mgmt_rows( $grouped, $cat_names ) {
    if ( empty( $grouped ) ) { return '<p style="color:#999;text-align:center;padding:40px;">No services found.</p>'; }
    $o = '<table class="nsh-tbl" style="width:100%;" id="nsh-svc-mgmt-table">';
    $o .= '<thead><tr><th>Service</th><th style="width:140px;">Category</th><th style="width:100px;">Active</th><th style="width:140px;"></th></tr></thead><tbody>';
    foreach ( $grouped as $cat_slug => $rows ) {
        $cat_label = isset( $cat_names[ $cat_slug ] ) ? $cat_names[ $cat_slug ]['name'] : ucfirst( $cat_slug );
        foreach ( $rows as $s ) {
            $o .= nsh_render_one_service_mgmt_row( $s, $cat_label );
        }
    }
    $o .= '</tbody></table>';
    return $o;
}

// One <tr>, shared by the initial page render above and by
// nshCreateService()'s JS, which asks the server for this exact markup
// (via nsh_admin_get_service_row) so a newly created service is inserted
// into the on-screen table without a reload and without duplicating this
// HTML in JavaScript.
function nsh_render_one_service_mgmt_row( $s, $cat_label ) {
    $checked  = (int) $s->is_active === 1;
    $fields_url = add_query_arg( array( 'tab' => 'fields', 'field_service_id' => intval( $s->id ) ), nsh_admin_dashboard_url() );
    $o  = '<tr data-svc-name="' . esc_attr( strtolower( $s->name ) ) . '" data-svc-id="' . intval( $s->id ) . '">';
    $o .= '<td><strong>' . esc_html( $s->name ) . '</strong><div style="font-size:11px;color:#94a3b8;">' . esc_html( $s->slug ) . '</div></td>';
    $o .= '<td style="color:#64748b;font-size:13px;">' . esc_html( $cat_label ) . '</td>';
    // No onchange/AJAX here anymore — this checkbox is purely local UI state
    // until "Save Changes" is clicked (see nshServicesCheckDirty() /
    // nshSaveServicesChanges() in nsh_settings_js() below). data-initial
    // records the last-saved value so a toggle back to it is correctly
    // recognised as "no longer dirty".
    $o .= '<td><label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;"><input type="checkbox" class="nsh-svc-active-cb" data-id="' . intval( $s->id ) . '" data-initial="' . ( $checked ? '1' : '0' ) . '" ' . ( $checked ? 'checked' : '' ) . ' onchange="nshServicesCheckDirty()"> <span class="nsh-svc-active-label">' . ( $checked ? 'Yes' : 'No' ) . '</span></label></td>';
    $o .= '<td><a href="' . esc_url( $fields_url ) . '" class="nsh-link" style="font-size:12px;">Manage Fields &rarr;</a></td>';
    $o .= '</tr>';
    return $o;
}

function nsh_settings_internal_statuses() {
    if ( ! nsh_is_admin_user() ) {
        return '<div class="nsh-settings-section"><div style="background:#fef2f2;border:1px solid #fecaca;color:#991b1b;padding:16px 20px;border-radius:8px;">Administrator access is required to manage internal statuses.</div></div>';
    }
    $rows = nsh_get_internal_statuses( false );

    $o  = '<div class="nsh-settings-section">';
    $o .= '<h3 style="margin: 0 0 6px;">🏷️ Internal Status Pipeline</h3>';
    $o .= '<p style="margin:0 0 20px;color:#64748b;font-size:13px;max-width:640px;">Staff-only CRM workflow stages for the Requests list. These are never shown to clients anywhere — not on their dashboard, their request page, in emails, or in notifications.</p>';

    $o .= '<div style="display: grid; grid-template-columns: 1fr 2fr; gap: 20px;">';

    // Add form
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<h4 style="margin: 0 0 15px;">➕ Add Internal Status</h4>';
    $o .= '<div class="nsh-field"><label>Status Name *</label><input type="text" id="nsh-istatus-new-label" placeholder="e.g., Awaiting Bank Details" style="width: 100%; padding: 8px; border: 1px solid #e5e7eb; border-radius: 6px;"></div>';
    $o .= '<div class="nsh-field"><label>Color</label><input type="color" id="nsh-istatus-new-color" value="#6b7280" style="width: 100%; height: 38px; padding: 2px; border: 1px solid #e5e7eb; border-radius: 6px;"></div>';
    $o .= '<button type="button" class="nsh-btn nsh-btn-primary nsh-btn-sm nsh-w100" onclick="nshAddInternalStatus()">➕ Add Status</button>';
    $o .= '<div id="istatus-message" style="margin-top: 10px;"></div>';
    $o .= '<hr style="margin:20px 0;"><p style="font-size:12px;color:#94a3b8;margin:0;">Reorder with the ▲▼ arrows on each row. Deactivate a status to remove it from new selections while every request already on it keeps its label. Delete is only offered when a status is used by zero requests.</p>';
    $o .= '</div>';

    // List
    $o .= '<div style="background: white; padding: 20px; border: 1px solid #e5e7eb; border-radius: 8px;">';
    $o .= '<h4 style="margin: 0 0 15px;">Pipeline Order (' . count( $rows ) . ')</h4>';
    $o .= '<div id="nsh-istatus-mgmt-list" style="max-height:600px;overflow-y:auto;">';
    $o .= nsh_render_internal_status_mgmt_rows( $rows );
    $o .= '</div>';
    $o .= '</div>';

    $o .= '</div></div>';
    return $o;
}

// Shared row-renderer: used both for the settings page's first render and
// for the JS-side refresh after any add/rename/reorder/toggle so the two
// never have separate markup to keep in sync.
function nsh_render_internal_status_mgmt_rows( $rows ) {
    if ( empty( $rows ) ) { return '<p style="color:#999;text-align:center;padding:40px;">No internal statuses defined yet.</p>'; }
    global $wpdb;
    $o  = '<table class="nsh-tbl" style="width:100%;" id="nsh-istatus-mgmt-table">';
    $o .= '<thead><tr><th style="width:70px;">Order</th><th>Status</th><th style="width:70px;">In Use</th><th style="width:90px;">Active</th><th style="width:110px;">Action</th></tr></thead><tbody>';
    $n = count( $rows );
    foreach ( $rows as $i => $r ) {
        $in_use = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} pm INNER JOIN {$wpdb->posts} p ON p.ID=pm.post_id WHERE pm.meta_key='internal_status' AND pm.meta_value=%s AND p.post_type='nsh_request' AND p.post_status='publish'",
            $r->slug
        ) );
        if ( $r->slug === 'inquiry' ) { $in_use += nsh_count_requests_defaulting_to_inquiry(); }
        $o .= '<tr data-id="' . intval( $r->id ) . '">';
        $o .= '<td><button type="button" class="nsh-btn nsh-btn-xs nsh-btn-ghost" ' . ( $i === 0 ? 'disabled' : '' ) . ' onclick="nshMoveInternalStatus(' . intval( $r->id ) . ',-1)" title="Move up">&#9650;</button> ';
        $o .= '<button type="button" class="nsh-btn nsh-btn-xs nsh-btn-ghost" ' . ( $i === $n - 1 ? 'disabled' : '' ) . ' onclick="nshMoveInternalStatus(' . intval( $r->id ) . ',1)" title="Move down">&#9660;</button></td>';
        $o .= '<td><span style="display:inline-block;width:10px;height:10px;border-radius:50%;background:' . esc_attr( $r->color ) . ';margin-right:6px;"></span>' . esc_html( $r->label ) . '<div style="font-size:11px;color:#94a3b8;">' . esc_html( $r->slug ) . '</div></td>';
        $o .= '<td>' . intval( $in_use ) . '</td>';
        $o .= '<td><label style="display:inline-flex;align-items:center;gap:4px;cursor:pointer;"><input type="checkbox" ' . ( (int) $r->is_active === 1 ? 'checked' : '' ) . ' onchange="nshToggleInternalStatus(' . intval( $r->id ) . ',this.checked)"> ' . ( (int) $r->is_active === 1 ? 'Yes' : 'No' ) . '</label></td>';
        $o .= '<td>';
        $o .= '<button type="button" class="nsh-btn nsh-btn-xs nsh-btn-outline" onclick="nshRenameInternalStatus(' . intval( $r->id ) . ',\'' . esc_js( $r->label ) . '\',\'' . esc_js( $r->color ) . '\')" title="Rename / recolor" style="padding:4px 6px;">&#9998;</button> ';
        $o .= '<button type="button" class="nsh-btn nsh-btn-xs nsh-btn-danger" onclick="nshDeleteInternalStatus(' . intval( $r->id ) . ',' . intval( $in_use ) . ')" title="Delete" style="padding:4px 6px;">&#128465;</button>';
        $o .= '</td></tr>';
    }
    $o .= '</tbody></table>';
    return $o;
}

// FORM STYLING — theme every request/quote form site-wide without
// touching source files. Backed by nsh_get_form_style_settings() /
// nsh_form_style_defaults() (helpers.php); saved via nsh_ajax_save_form_style
// (ajax.php) into the nsh_form_style_settings option, which
// nsh_form_style_inline_css() turns into a ":root{--nsh-*}" override
// loaded right after nsh-style.css (enqueue.php).
function nsh_settings_form_style() {
    $s = nsh_get_form_style_settings();

    $o  = '<div class="nsh-settings-section">';
    $o .= '<h3 style="margin:0 0 6px;">🎨 Form Styling</h3>';
    $o .= '<p style="margin:0 0 20px;font-size:13px;color:#64748b;max-width:640px;">Controls the look of every request/quote form on the site — the standalone card, the dashboard\'s New Request page, and any other page using an NSH form shortcode. Changes apply everywhere at once, live, without editing any code.</p>';

    // group( title, [ [key,label,type], ... ] ) — type is 'color' or 'size'
    $groups = array(
        'Form & Field Colors' => array(
            array( 'form-bg',           'Form background color',        'color' ),
            array( 'field-bg',          'Field background color',       'color' ),
            array( 'field-border-color','Field border color',           'color' ),
            array( 'field-text',        'Field text color',             'color' ),
            array( 'label-color',       'Label color',                  'color' ),
            array( 'placeholder-color', 'Placeholder color',            'color' ),
            array( 'focus-color',       'Focus / active field color',   'color' ),
        ),
        'Buttons & Header' => array(
            array( 'btn-bg',        'Button background (start)',   'color' ),
            array( 'btn-bg-2',      'Button background (end)',     'color' ),
            array( 'btn-text',      'Button text color',           'color' ),
            array( 'header-bg',     'Section/header color (start)','color' ),
            array( 'header-bg-2',   'Section/header color (end)',  'color' ),
            array( 'header-text',   'Section/header text color',   'color' ),
        ),
        'Validation' => array(
            array( 'error-color',    'Error / validation color',      'color' ),
            array( 'required-color', 'Required-field indicator color','color' ),
        ),
        'Typography & Spacing' => array(
            array( 'font-size',      'Font size',              'size' ),
            array( 'field-gap',      'Field spacing / gaps',   'size' ),
            array( 'label-gap',      'Label spacing',          'size' ),
            array( 'input-height',   'Input height',           'size' ),
            array( 'field-border-width', 'Field border width', 'size' ),
            array( 'field-radius',   'Field border radius',    'size' ),
        ),
        'Buttons & Form Sizing' => array(
            array( 'btn-radius',    'Button radius',            'size' ),
            array( 'btn-padding-y', 'Button vertical padding',  'size' ),
            array( 'btn-padding-x', 'Button horizontal padding','size' ),
            array( 'form-padding',  'Overall form padding',     'size' ),
            array( 'card-max-width','Form/card max width',      'size' ),
        ),
        'Mobile-Specific Sizing' => array(
            array( 'font-size-mobile',    'Font size (mobile)',    'size' ),
            array( 'field-gap-mobile',    'Field spacing (mobile)','size' ),
            array( 'form-padding-mobile', 'Form padding (mobile)', 'size' ),
        ),
    );

    $o .= '<form id="nsh-form-style-form">';
    foreach ( $groups as $group_title => $rows ) {
        $o .= '<div style="background:white;border:1px solid #e5e7eb;border-radius:8px;padding:18px 20px;margin-bottom:16px;">';
        $o .= '<h4 style="margin:0 0 14px;font-size:14px;color:#1e293b;">' . esc_html( $group_title ) . '</h4>';
        $o .= '<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px;">';
        foreach ( $rows as $row ) {
            list( $key, $label, $type ) = $row;
            $val = esc_attr( $s[ $key ] );
            $o  .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;">' . esc_html( $label ) . '</label>';
            if ( $type === 'color' ) {
                $hex = preg_match( '/^#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})$/', $val ) ? $val : '#ffffff';
                $o  .= '<div style="display:flex;gap:8px;align-items:center;">';
                $o  .= '<input type="color" class="nsh-fs-input nsh-fs-color-swatch" data-key="' . esc_attr( $key ) . '" value="' . esc_attr( $hex ) . '" style="width:38px;height:34px;padding:2px;border:1px solid #e2e8f0;border-radius:6px;cursor:pointer;">';
                $o  .= '<input type="text" class="nsh-fs-input nsh-fs-color-text" data-key="' . esc_attr( $key ) . '" value="' . $val . '" style="flex:1;padding:7px 10px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;">';
                $o  .= '</div>';
            } else {
                $o  .= '<input type="text" class="nsh-fs-input" data-key="' . esc_attr( $key ) . '" value="' . $val . '" placeholder="e.g. 12px" style="width:100%;padding:8px 11px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;box-sizing:border-box;">';
            }
            $o  .= '</div>';
        }
        $o .= '</div></div>';
    }
    $o .= '</form>';

    $o .= '<div style="display:flex;gap:10px;align-items:center;">';
    $o .= '<button type="button" class="nsh-btn nsh-btn-primary" id="nsh-save-form-style-btn">💾 Save Form Styling</button>';
    $o .= '<button type="button" class="nsh-btn nsh-btn-outline" id="nsh-reset-form-style-btn">↺ Reset to Defaults</button>';
    $o .= '</div>';
    $o .= '<div id="nsh-form-style-msg" style="margin-top:14px;"></div>';

    $o .= '</div>'; // end section
    return $o;
}

// GENERAL SETTINGS — includes full SMTP configuration
// BOT PROTECTION (CAPTCHA) SECTION — see the "CAPTCHA / Bot Protection"
// helper block in helpers.php (nsh_turnstile_*()) for how these three
// options are actually used on the standalone form + its submit handler.
function nsh_settings_captcha() {
    $provider     = nsh_captcha_provider(); // 'builtin' | 'turnstile'
    $builtin_on   = nsh_captcha_builtin_is_enabled();
    $min_seconds  = nsh_captcha_builtin_min_seconds();
    $ts_enabled   = nsh_turnstile_is_enabled();
    $site_key     = get_option( 'nsh_turnstile_site_key', '' );
    $has_secret   = get_option( 'nsh_turnstile_secret_key', '' ) !== '';
    $using_test   = nsh_turnstile_using_test_keys();

    $o  = '<div class="nsh-settings-section">';
    $o .= '<h3 style="margin:0 0 20px;">🛡️ Bot Protection (CAPTCHA)</h3>';

    $o .= '<div style="background:white;border:1px solid #e5e7eb;border-radius:8px;padding:20px;margin-bottom:20px;">';
    // Literal shortcode text escaped the same way as nsh_settings_shortcodes()
    // below — see that function's docblock for why a literal "[shortcode]"
    // shown as plain reference text has to avoid literal bracket characters
    // on a site that runs do_shortcode() more than once (e.g. via a page
    // builder's own Shortcode widget).
    $o .= '<p style="margin:0 0 16px;font-size:13px;color:#64748b;">Human-verification on the standalone request form (<code>&#x5B;nsh_standalone_form&#x5D;</code>) — every check is verified on your server for every submission, so a bot cannot bypass it by skipping your page\'s JavaScript and posting directly. Choose which method to use:</p>';

    // ── Provider selector ────────────────────────────────────────────────
    $o .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:20px;">';

    $o .= '<label class="nsh-captcha-provider-card" style="display:block;border:2px solid ' . ( $provider === 'builtin' ? '#2563eb' : '#e2e8f0' ) . ';border-radius:8px;padding:14px;cursor:pointer;">';
    $o .= '<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;"><input type="radio" name="nsh-captcha-provider" id="nsh-captcha-provider-builtin" value="builtin" ' . ( $provider === 'builtin' ? 'checked' : '' ) . '> <strong style="font-size:13px;">🏠 Built-in (recommended)</strong></div>';
    $o .= '<p style="margin:0;font-size:12px;color:#64748b;">Fully self-hosted. No external script, no external server call, nothing ever leaves your site — a simple math question plus two invisible anti-bot checks.</p>';
    $o .= '</label>';

    $o .= '<label class="nsh-captcha-provider-card" style="display:block;border:2px solid ' . ( $provider === 'turnstile' ? '#2563eb' : '#e2e8f0' ) . ';border-radius:8px;padding:14px;cursor:pointer;">';
    $o .= '<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;"><input type="radio" name="nsh-captcha-provider" id="nsh-captcha-provider-turnstile" value="turnstile" ' . ( $provider === 'turnstile' ? 'checked' : '' ) . '> <strong style="font-size:13px;">☁️ Cloudflare Turnstile</strong></div>';
    $o .= '<p style="margin:0;font-size:12px;color:#64748b;">A managed challenge — stronger against determined/custom bots, but loads Cloudflare\'s script in visitors\' browsers and calls Cloudflare\'s server to verify. Free, but requires a Cloudflare account.</p>';
    $o .= '</label>';

    $o .= '</div>';

    // ── Built-in panel ───────────────────────────────────────────────────
    $o .= '<div id="nsh-captcha-panel-builtin" style="' . ( $provider === 'builtin' ? '' : 'display:none;' ) . 'border-top:1px solid #e2e8f0;padding-top:18px;">';
    $o .= '<label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer;margin-bottom:14px;">';
    $o .= '<input type="checkbox" id="nsh-captcha-builtin-enabled" ' . ( $builtin_on ? 'checked' : '' ) . ' style="width:16px;height:16px;"> <strong>Enable built-in verification</strong>';
    $o .= '</label>';
    $o .= '<div id="nsh-captcha-builtin-fields" style="' . ( $builtin_on ? '' : 'opacity:0.5;pointer-events:none;' ) . '">';
    $o .= '<label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">Minimum seconds before a submission is accepted</label>';
    $o .= '<input type="number" id="nsh-captcha-builtin-min-seconds" value="' . intval( $min_seconds ) . '" min="0" max="60" style="width:120px;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;">';
    $o .= '<p style="margin:6px 0 0;font-size:11px;color:#94a3b8;">Rejects a submission that arrives faster than a human plausibly could — a strong signal of a script posting directly. 3 seconds (the default) is far below any real visitor\'s fill time and will never bother a genuine submission.</p>';
    $o .= '</div>';
    $o .= '</div>';

    // ── Turnstile panel ──────────────────────────────────────────────────
    $o .= '<div id="nsh-captcha-panel-turnstile" style="' . ( $provider === 'turnstile' ? '' : 'display:none;' ) . 'border-top:1px solid #e2e8f0;padding-top:18px;">';

    if ( $using_test ) {
        $o .= '<div style="background:#fffbeb;border:1px solid #fcd34d;border-radius:6px;padding:12px 14px;margin-bottom:16px;font-size:13px;color:#78350f;">';
        $o .= '⚠️ <strong>Running on Cloudflare\'s public TEST keys — this provides NO real bot protection yet.</strong> The widget will render and forms will keep working, but every check always passes. Add your own free keys below before relying on this.';
        $o .= '</div>';
    }

    $o .= '<div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;padding:12px 14px;margin-bottom:18px;font-size:13px;color:#1e40af;">';
    $o .= '💡 Get your free Site Key + Secret Key from <a href="https://dash.cloudflare.com/?to=/:account/turnstile" target="_blank" style="color:#1d4ed8;">the Cloudflare Turnstile dashboard</a> (no paid Cloudflare plan needed — just a free account). Add this site\'s domain when creating the widget there.';
    $o .= '</div>';

    $o .= '<label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer;margin-bottom:18px;">';
    $o .= '<input type="checkbox" id="nsh-captcha-enabled" ' . ( $ts_enabled ? 'checked' : '' ) . ' style="width:16px;height:16px;"> <strong>Enable Turnstile on the standalone request form</strong>';
    $o .= '</label>';

    $o .= '<div id="nsh-captcha-fields" style="' . ( $ts_enabled ? '' : 'opacity:0.5;pointer-events:none;' ) . '">';
    $o .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:6px;">';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">Turnstile Site Key</label>';
    $o .= '<input type="text" id="nsh-captcha-site-key" value="' . esc_attr( $site_key ) . '" placeholder="' . esc_attr( NSH_TURNSTILE_TEST_SITE_KEY ) . ' (test key)" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;font-family:monospace;"></div>';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">Turnstile Secret Key</label>';
    $o .= '<input type="password" id="nsh-captcha-secret-key" placeholder="' . ( $has_secret ? '●●●●●●●●●●●●●●●● (saved — leave blank to keep)' : esc_attr( NSH_TURNSTILE_TEST_SECRET_KEY ) . ' (test key)' ) . '" autocomplete="new-password" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;font-family:monospace;"></div>';
    $o .= '</div>';
    $o .= '<p style="margin:0;font-size:11px;color:#94a3b8;">The Secret Key is never displayed once saved — this field is always shown blank; leave it blank to keep the currently-saved key.</p>';
    $o .= '</div>';
    $o .= '</div>'; // turnstile panel

    $o .= '<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-top:18px;border-top:1px solid #e2e8f0;padding-top:18px;">';
    $o .= '<button type="button" class="nsh-btn nsh-btn-primary" id="nsh-save-captcha-btn">💾 Save Bot Protection Settings</button>';
    $o .= '</div>';
    $o .= '<div id="nsh-captcha-msg" style="margin-top:14px;"></div>';

    $o .= '</div>'; // card
    $o .= '</div>'; // section

    // Provider-switch/enable toggles + Save-button click handler live in
    // nsh_settings_js() below (the "Bot Protection (CAPTCHA) Settings"
    // block) — routed through $echo_inline_script the same way every
    // other settings-tab script on this page is, so it isn't vulnerable
    // to the_content/kses stripping on a first full page load (see
    // nsh_output_admin_script()'s docblock in enqueue.php).

    return $o;
}

function nsh_settings_general() {
    $smtp = nsh_get_smtp_settings();

    // Mask stored password for display
    $pw_placeholder = get_option( 'nsh_smtp_password_enc', '' ) ? '●●●●●●●●' : '';

    $o  = '<div class="nsh-settings-section">';
    $o .= '<h3 style="margin:0 0 20px;">⚙️ General Settings</h3>';

    // ── Sender Identity ───────────────────────────────────────────────────────
    $o .= '<div style="background:white;border:1px solid #e5e7eb;border-radius:8px;padding:20px;margin-bottom:20px;">';
    $o .= '<h4 style="margin:0 0 16px;font-size:15px;color:#1e293b;">📧 Sender Identity</h4>';
    $o .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">From Name</label>';
    $o .= '<input type="text" name="nsh_email_name" id="nsh-smtp-from-name" value="' . esc_attr( $smtp['from_name'] ) . '" placeholder="Your Business Name" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">From Email</label>';
    $o .= '<input type="email" name="nsh_email_from" id="nsh-smtp-from-email" value="' . esc_attr( $smtp['from_email'] ) . '" placeholder="noreply@yourdomain.com" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '</div>';
    $o .= '<p style="margin:0;font-size:12px;color:#94a3b8;">These appear as the sender on all platform emails. The From Email <strong>must match your SMTP account</strong> or emails will be rejected/spam-filtered.</p>';
    $o .= '</div>';

    // ── Notification Contact (Manager) ──────────────────────────────────────
    // Where "New Request Received" (and every other staff-facing) email
    // actually goes. This card was previously MISSING entirely — the
    // options it saves (nsh_manager_name / nsh_manager_phone /
    // nsh_manager_email) and the fallback logic that reads
    // nsh_manager_email (nsh_admin_notification_email(), notifications.php)
    // both already existed, and so did the generic "nsh_save_settings" AJAX
    // handler + JS (#nsh-save-settings-btn / .nsh-setting-inp, further down
    // in nsh-app.js) that's meant to save it — but no actual <input> for it
    // was ever rendered anywhere in the admin, on any tab. That's why
    // "Manager Email" could never actually be set: there was no form field
    // to set it with, so nsh_manager_email has been permanently empty on
    // every install, admin notifications have always been falling through
    // to admin_email (Settings -> General -> Administration Email Address,
    // a core WordPress setting on wp-admin/options-general.php, NOT this
    // plugin's own settings), and if THAT address is wrong, unreachable, or
    // going to spam, there was no way to point admin notifications
    // somewhere else without editing the database directly. This card is
    // that missing input, plus a live read-out of which address admin
    // notifications resolve to right now and a one-click way to send a
    // real test to it — so a bad/empty setting is something you can see
    // and fix here, not something you have to infer from a quiet inbox.
    $mgr_name  = get_option( 'nsh_manager_name', '' );
    $mgr_email = get_option( 'nsh_manager_email', '' );
    $mgr_phone = get_option( 'nsh_manager_phone', '' );
    $resolved_admin_email = function_exists( 'nsh_admin_notification_email' ) ? nsh_admin_notification_email() : get_option( 'admin_email' );
    $using_fallback = ! ( $mgr_email && is_email( $mgr_email ) );

    $o .= '<div style="background:white;border:1px solid #e5e7eb;border-radius:8px;padding:20px;margin-bottom:20px;">';
    $o .= '<h4 style="margin:0 0 6px;font-size:15px;color:#1e293b;">🔔 Notification Contact (Manager)</h4>';
    $o .= '<p style="margin:0 0 16px;font-size:12px;color:#94a3b8;">Where staff-facing emails go — "New Request Received", document reminders, and any other internal notification. Leave Manager Email blank to keep using your WordPress Admin Email instead.</p>';

    $o .= '<div style="background:' . ( $using_fallback ? '#fffbeb' : '#f0fdf4' ) . ';border:1px solid ' . ( $using_fallback ? '#fcd34d' : '#bbf7d0' ) . ';border-radius:6px;padding:10px 14px;margin-bottom:16px;font-size:13px;color:' . ( $using_fallback ? '#78350f' : '#15803d' ) . ';">';
    $o .= ( $using_fallback ? '⚠️ No valid Manager Email set — ' : '✅ ' );
    $o .= 'Admin notifications currently go to <strong>' . esc_html( $resolved_admin_email ?: '(none — Admin Email is also empty/invalid, check Settings → General in wp-admin)' ) . '</strong>' . ( $using_fallback ? ' (your WordPress Admin Email)' : '' ) . '.';
    $o .= '</div>';

    $o .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-bottom:14px;">';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">Manager Name</label>';
    $o .= '<input type="text" class="nsh-setting-inp" data-key="nsh_manager_name" value="' . esc_attr( $mgr_name ) . '" placeholder="e.g. Ayushh Sharma" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">Manager Phone</label>';
    $o .= '<input type="tel" class="nsh-setting-inp" data-key="nsh_manager_phone" value="' . esc_attr( $mgr_phone ) . '" placeholder="+91 98765 43210" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '</div>';
    $o .= '<div style="margin-bottom:6px;"><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">Manager Email</label>';
    $o .= '<input type="email" class="nsh-setting-inp" data-key="nsh_manager_email" id="nsh-manager-email-inp" value="' . esc_attr( $mgr_email ) . '" placeholder="you@yourdomain.com — leave blank to use Admin Email" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '<p style="margin:0 0 16px;font-size:11px;color:#94a3b8;">Must be a real, complete address — an empty or invalid value here is ignored and admin notifications fall back to Admin Email automatically (they never silently stop sending).</p>';

    $o .= '<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">';
    $o .= '<button type="button" class="nsh-btn nsh-btn-primary" id="nsh-save-settings-btn">💾 Save Settings</button>';
    $o .= '<button type="button" class="nsh-btn nsh-btn-outline" id="nsh-test-admin-notif-btn">🔔 Send Test Admin Notification</button>';
    $o .= '</div>';
    $o .= '<div id="nsh-settings-msg" style="margin-top:14px;"></div>';
    $o .= '<div id="nsh-test-admin-notif-msg" style="margin-top:10px;"></div>';
    $o .= '</div>';

    // ── Form Disclaimer Phone Number ────────────────────────────────────────
    // The number shown to the PUBLIC in the "you may call us at ..."
    // sentence on every request form's disclaimer box (shortcodes.php,
    // nsh_render_service_wizard_html() — see nsh_disclaimer_phone_raw()/
    // nsh_disclaimer_phone_tel_href() in helpers.php). Deliberately a
    // separate option from Manager Phone above (nsh_disclaimer_phone, not
    // nsh_manager_phone) — Manager Phone is where internal staff
    // notifications get routed, this is what a customer sees and can dial,
    // and a site may want those to be two different numbers. Saved through
    // the exact same "Save Settings" button and nsh_save_settings AJAX
    // handler as the card above (just another .nsh-setting-inp), so there's
    // one Save action for all of General Settings rather than a separate
    // button per card.
    $disclaimer_phone = get_option( 'nsh_disclaimer_phone', '' );
    $o .= '<div style="background:white;border:1px solid #e5e7eb;border-radius:8px;padding:20px;margin-bottom:20px;">';
    $o .= '<h4 style="margin:0 0 6px;font-size:15px;color:#1e293b;">📞 Form Disclaimer Phone Number</h4>';
    $o .= '<p style="margin:0 0 14px;font-size:12px;color:#94a3b8;">The phone number shown to visitors in the disclaimer box at the bottom of every request form ("If you would like to speak with us directly..."). Leave blank to keep the built-in default number.</p>';
    $o .= '<div style="max-width:320px;"><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">Disclaimer Phone Number</label>';
    $o .= '<input type="tel" class="nsh-setting-inp" data-key="nsh_disclaimer_phone" value="' . esc_attr( $disclaimer_phone ) . '" placeholder="+91-9310724109" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '</div>';

    // ── SMTP Configuration ────────────────────────────────────────────────────
    $o .= '<div style="background:white;border:1px solid #e5e7eb;border-radius:8px;padding:20px;margin-bottom:20px;">';
    $o .= '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;">';
    $o .= '<h4 style="margin:0;font-size:15px;color:#1e293b;">🔌 SMTP Configuration</h4>';
    $o .= '<label style="display:flex;align-items:center;gap:8px;font-size:13px;cursor:pointer;">';
    $o .= '<input type="checkbox" id="nsh-smtp-enabled" ' . ( $smtp['enabled'] ? 'checked' : '' ) . ' style="width:16px;height:16px;"> Enable SMTP (recommended)';
    $o .= '</label></div>';

    $o .= '<div style="background:#fffbeb;border:1px solid #fcd34d;border-radius:6px;padding:12px 14px;margin-bottom:16px;font-size:13px;color:#78350f;">';
    $o .= '⚠️ <strong>Without SMTP, emails are sent via PHP mail() which is blocked or spam-filtered on most hosts.</strong> ';
    $o .= 'Configure SMTP to ensure emails reach recipients. Use Gmail, Outlook, or any transactional email service (SendGrid, Mailgun, Brevo/Sendinblue).';
    $o .= '</div>';

    $o .= '<div id="nsh-smtp-fields" style="' . ( $smtp['enabled'] ? '' : 'opacity:0.5;pointer-events:none;' ) . '">';

    // Popular presets
    $o .= '<div style="margin-bottom:14px;">';
    $o .= '<label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:6px;text-transform:uppercase;letter-spacing:.05em;">Quick Presets</label>';
    $o .= '<div style="display:flex;gap:8px;flex-wrap:wrap;">';
    $presets = array(
        'gmail'     => array( '📧 Gmail',    'smtp.gmail.com',        587, 'tls' ),
        'outlook'   => array( '📧 Outlook',  'smtp.office365.com',    587, 'tls' ),
        'yahoo'     => array( '📧 Yahoo',    'smtp.mail.yahoo.com',   587, 'tls' ),
        'brevo'     => array( '📧 Brevo',    'smtp-relay.brevo.com',  587, 'tls' ),
        'mailgun'   => array( '📧 Mailgun',  'smtp.mailgun.org',      587, 'tls' ),
        'sendgrid'  => array( '📧 SendGrid', 'smtp.sendgrid.net',     587, 'tls' ),
        'custom'    => array( '⚙️ Custom',   '',                        587, 'tls' ),
    );
    foreach ( $presets as $pk => $pv ) {
        $o .= '<button type="button" class="nsh-btn nsh-btn-ghost nsh-btn-sm nsh-smtp-preset"'
            . ' data-host="' . esc_attr($pv[1]) . '"'
            . ' data-port="' . intval($pv[2]) . '"'
            . ' data-enc="'  . esc_attr($pv[3]) . '">'
            . esc_html($pv[0]) . '</button>';
    }
    $o .= '</div></div>';

    // Host + Port + Encryption
    $o .= '<div style="display:grid;grid-template-columns:2fr 1fr 1fr;gap:12px;margin-bottom:12px;">';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">SMTP Host *</label>';
    $o .= '<input type="text" id="nsh-smtp-host" value="' . esc_attr($smtp['host']) . '" placeholder="smtp.gmail.com" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">Port *</label>';
    $o .= '<input type="number" id="nsh-smtp-port" value="' . intval($smtp['port']) . '" placeholder="587" min="1" max="65535" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">Encryption</label>';
    $o .= '<select id="nsh-smtp-encryption" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;">';
    foreach ( array( 'tls' => 'TLS (587)', 'ssl' => 'SSL (465)', 'none' => 'None' ) as $ev => $el ) {
        $o .= '<option value="' . $ev . '" ' . ( $smtp['encryption'] === $ev ? 'selected' : '' ) . '>' . $el . '</option>';
    }
    $o .= '</select></div></div>';

    // Username + Password
    $o .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:12px;">';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">SMTP Username</label>';
    $o .= '<input type="text" id="nsh-smtp-username" value="' . esc_attr($smtp['username']) . '" placeholder="your@email.com" autocomplete="username" style="width:100%;padding:9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;"></div>';
    $o .= '<div><label style="display:block;font-size:12px;font-weight:600;color:#64748b;margin-bottom:5px;text-transform:uppercase;letter-spacing:.05em;">SMTP Password / App Password</label>';
    $o .= '<div style="position:relative;">';
    $o .= '<input type="password" id="nsh-smtp-password" placeholder="' . esc_attr($pw_placeholder ?: 'Enter password') . '" autocomplete="new-password" style="width:100%;padding:9px 36px 9px 12px;border:1px solid #e2e8f0;border-radius:6px;font-size:14px;box-sizing:border-box;">';
    $o .= '<button type="button" id="nsh-smtp-pw-toggle" style="position:absolute;right:8px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:16px;color:#94a3b8;" title="Show/hide">👁</button>';
    $o .= '</div>';
    if ( $pw_placeholder ) {
        $o .= '<p style="margin:4px 0 0;font-size:11px;color:#94a3b8;">Password stored. Leave blank to keep existing.</p>';
    }
    $o .= '</div></div>';

    // Gmail notice
    $o .= '<div style="background:#eff6ff;border:1px solid #bfdbfe;border-radius:6px;padding:10px 14px;margin-bottom:12px;font-size:12px;color:#1e40af;">';
    $o .= '💡 <strong>Gmail users:</strong> Use an <a href="https://myaccount.google.com/apppasswords" target="_blank" style="color:#1d4ed8;">App Password</a> (not your regular Gmail password). ';
    $o .= 'Go to Google Account → Security → 2-Step Verification → App Passwords. Set host to smtp.gmail.com, port 587, TLS.';
    $o .= '</div>';

    $o .= '<label style="display:flex;align-items:center;gap:8px;font-size:13px;color:#64748b;cursor:pointer;margin-bottom:14px;">';
    $o .= '<input type="checkbox" id="nsh-smtp-debug" ' . ( get_option('nsh_smtp_debug',0) ? 'checked' : '' ) . ' style="width:14px;height:14px;">';
    $o .= 'Enable verbose SMTP debug logging (writes SMTP conversation to nsh-debug.log — disable after testing)';
    $o .= '</label>';

    $o .= '</div>'; // end nsh-smtp-fields

    // Actions row
    $o .= '<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">';
    $o .= '<button type="button" class="nsh-btn nsh-btn-primary" id="nsh-save-smtp-btn">💾 Save SMTP Settings</button>';
    $o .= '<button type="button" class="nsh-btn nsh-btn-outline" id="nsh-smtp-test-btn">📧 Send Test Email</button>';
    $o .= '</div>';
    $o .= '<div id="nsh-smtp-msg" style="margin-top:14px;"></div>';
    $o .= '</div>'; // end smtp card

    // ── Reference table ───────────────────────────────────────────────────────
    $o .= '<div style="background:white;border:1px solid #e5e7eb;border-radius:8px;padding:20px;">';
    $o .= '<h4 style="margin:0 0 12px;font-size:14px;color:#1e293b;">📋 Common SMTP Settings Reference</h4>';
    $o .= '<table style="width:100%;border-collapse:collapse;font-size:13px;">';
    $o .= '<thead><tr style="background:#f8fafc;">';
    foreach ( array('Provider','Host','Port','Encryption','Username','Password') as $h ) {
        $o .= '<th style="padding:8px 10px;text-align:left;border:1px solid #e2e8f0;color:#475569;font-size:11px;text-transform:uppercase;letter-spacing:.05em;">' . $h . '</th>';
    }
    $o .= '</tr></thead><tbody>';
    $refs = array(
        array('Gmail',           'smtp.gmail.com',            587, 'TLS', 'your@gmail.com',    'App Password (16 chars)'),
        array('Outlook / 365',   'smtp.office365.com',        587, 'TLS', 'your@outlook.com',  'Your password'),
        array('Yahoo Mail',      'smtp.mail.yahoo.com',       587, 'TLS', 'your@yahoo.com',    'App Password'),
        array('Brevo (Sendinblue)','smtp-relay.brevo.com',    587, 'TLS', 'Your login email',  'Brevo SMTP key'),
        array('Mailgun',         'smtp.mailgun.org',          587, 'TLS', 'postmaster@domain', 'Mailgun SMTP password'),
        array('SendGrid',        'smtp.sendgrid.net',         587, 'TLS', 'apikey',            'Your API Key'),
        array('Amazon SES',      'email-smtp.us-east-1.amazonaws.com', 587, 'TLS', 'SMTP Access Key ID', 'SMTP Secret Access Key'),
    );
    foreach ( $refs as $i => $row ) {
        $bg = $i % 2 === 0 ? '#fff' : '#f8fafc';
        $o .= '<tr style="background:' . $bg . ';">';
        foreach ( $row as $j => $cell ) {
            $o .= '<td style="padding:7px 10px;border:1px solid #e2e8f0;' . ($j===0?'font-weight:600;':'') . '">' . esc_html($cell) . '</td>';
        }
        $o .= '</tr>';
    }
    $o .= '</tbody></table>';
    $o .= '</div>';

    $o .= '</div>'; // end section

    // ── Fix Existing Documents card (count loaded via AJAX to avoid page crash) ──
    $o .= '<div style="background:white;border:1px solid #fbbf24;border-radius:8px;padding:20px;margin-top:20px;">';
    $o .= '<h4 style="margin:0 0 8px;font-size:15px;color:#92400e;">🔧 Fix Existing Documents (AVIF/WebP → PNG)</h4>';
    $o .= '<p style="margin:0 0 14px;font-size:13px;color:#64748b;">If students uploaded documents that were converted to AVIF or WebP by an image optimizer, they cannot be opened when downloaded. Click Scan to check, then Convert to fix them permanently.</p>';
    $o .= '<div id="nsh-fix-docs-status" style="background:#f1f5f9;border:1px solid #e2e8f0;border-radius:6px;padding:10px 14px;font-size:13px;color:#475569;margin-bottom:14px;">⏳ Click Scan to check your documents…</div>';
    $o .= '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">';
    $o .= '<button type="button" id="nsh-recount-docs-btn" class="nsh-btn nsh-btn-outline">🔍 Scan</button>';
    $o .= '<button type="button" id="nsh-fix-docs-btn" class="nsh-btn nsh-btn-primary" disabled>🔧 Convert to PNG</button>';
    $o .= '</div>';
    $o .= '<div id="nsh-fix-docs-progress" style="display:none;margin-top:12px;">';
    $o .= '<div style="background:#e2e8f0;border-radius:4px;height:8px;overflow:hidden;margin-bottom:8px;">';
    $o .= '<div id="nsh-fix-docs-bar" style="height:100%;background:linear-gradient(90deg,#f59e0b,#d97706);width:0%;transition:width .4s;border-radius:4px;"></div>';
    $o .= '</div>';
    $o .= '<div id="nsh-fix-docs-msg" style="font-size:13px;color:#475569;"></div>';
    $o .= '</div>';
    $o .= '</div>';

    return $o;
}

// JavaScript for settings
//
// @param bool $echo_inline_script See nsh_admin_tab_settings()'s docblock
//   above / nsh_output_admin_script()'s (enqueue.php). The <script>/
//   </script> tags this template prints are stripped back off below so
//   the inner JS can be routed the same way as every other admin tab's
//   inline script.
function nsh_settings_js( $echo_inline_script = true ) {
    ob_start();
    ?>
    <script>
    // ── View toggle: HTML Source ↔ Rich Preview ──────────────────────────────
    function nshSwitchView(view) {
        const htmlView    = document.getElementById('nsh-html-view');
        const previewView = document.getElementById('nsh-preview-view');
        document.querySelectorAll('.nsh-view-btn').forEach(b => {
            b.classList.toggle('nsh-btn-outline', b.dataset.view === view);
            b.classList.toggle('nsh-btn-ghost',   b.dataset.view !== view);
            b.classList.toggle('active',           b.dataset.view === view);
        });
        if (view === 'preview') {
            htmlView.style.display    = 'none';
            previewView.style.display = 'block';
            // Render body HTML into iframe
            const body  = document.getElementById('email-body').value;
            const frame = document.getElementById('nsh-preview-frame');
            frame.srcdoc = '<!DOCTYPE html><html><head><meta charset="UTF-8"><style>body{margin:0;padding:0;background:#f1f5f9;font-family:Arial,sans-serif;}</style></head><body>' + body + '</body></html>';
        } else {
            htmlView.style.display    = 'block';
            previewView.style.display = 'none';
        }
    }

    // ── Save email template ──────────────────────────────────────────────────
    function nshSaveEmailTemplate() {
        const form = document.getElementById('nsh-email-template-form');
        const formData = new FormData(form);
        formData.set('action', 'nsh_save_email_template');
        formData.set('nonce', NSH.admin_nonce);

        const msg = document.getElementById('email-template-message');
        msg.innerHTML = '<div class="nsh-alert" style="color:#555;background:#f1f5f9;padding:10px;border-radius:6px;">⏳ Saving…</div>';

        fetch(NSH.ajax_url, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    msg.innerHTML = '<div class="nsh-alert nsh-alert-success" style="background:#d1fae5;color:#065f46;padding:10px;border-radius:6px;">✅ Template saved successfully!</div>';
                } else {
                    const err = (data.data && data.data.message) ? data.data.message : (data.data || 'Failed to save');
                    msg.innerHTML = '<div class="nsh-alert nsh-alert-error" style="background:#fee2e2;color:#991b1b;padding:10px;border-radius:6px;">❌ Error: ' + err + '</div>';
                }
            })
            .catch(e => {
                msg.innerHTML = '<div class="nsh-alert nsh-alert-error" style="background:#fee2e2;color:#991b1b;padding:10px;border-radius:6px;">❌ Network error: ' + e.message + '</div>';
            });
    }

    // ── Reset to default ─────────────────────────────────────────────────────
    function nshResetEmailTemplate(type) {
        if (!confirm('Reset to default template? Your custom changes will be lost.')) return;
        fetch(NSH.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nsh_reset_email_template&template_type=' + encodeURIComponent(type) + '&nonce=' + NSH.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('Reset failed: ' + (data.data || 'Unknown error'));
        });
    }

    // ── Send test email ──────────────────────────────────────────────────────
    function nshTestEmail(type) {
        const email = prompt('Send test email to:', '<?php echo esc_js(wp_get_current_user()->user_email); ?>');
        if (!email) return;
        fetch(NSH.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nsh_test_email&template_type=' + encodeURIComponent(type) + '&test_email=' + encodeURIComponent(email) + '&nonce=' + NSH.admin_nonce
        }).then(r => r.json()).then(data => {
            alert(data.success ? '✅ Test email sent to ' + email : '❌ Failed: ' + (data.data && data.data.message ? data.data.message : data.data || 'Unknown error'));
        });
    }

    // ── Duplicate template ───────────────────────────────────────────────────
    function nshDuplicateTemplate(type) {
        const label = prompt('Name for the duplicated template:', 'Copy of template');
        if (!label || !label.trim()) return;
        fetch(NSH.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nsh_duplicate_email_template&template_type=' + encodeURIComponent(type) + '&new_label=' + encodeURIComponent(label.trim()) + '&nonce=' + NSH.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) {
                alert('✅ ' + data.data.message);
                location.href = '?tab=settings&section=email_templates&tpl=' + data.data.new_type;
            } else {
                alert('❌ ' + (data.data && data.data.message ? data.data.message : 'Error'));
            }
        });
    }

    // ── Create new blank template ────────────────────────────────────────────
    function nshCreateNewTemplate() {
        const label = prompt('Name for the new template (e.g. "Payment Reminder"):');
        if (!label || !label.trim()) return;
        fetch(NSH.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nsh_create_email_template&new_label=' + encodeURIComponent(label.trim()) + '&nonce=' + NSH.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) {
                alert('✅ ' + data.data.message);
                location.href = '?tab=settings&section=email_templates&tpl=' + data.data.new_type;
            } else {
                alert('❌ ' + (data.data && data.data.message ? data.data.message : 'Error'));
            }
        });
    }

    // ── Delete custom template ───────────────────────────────────────────────
    function nshDeleteCustomTemplate(type) {
        if (!confirm('Permanently delete this custom template? This cannot be undone.')) return;
        fetch(NSH.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nsh_delete_custom_template&template_type=' + encodeURIComponent(type) + '&nonce=' + NSH.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) {
                location.href = '?tab=settings&section=email_templates&tpl=quotation';
            } else {
                alert('❌ ' + (data.data && data.data.message ? data.data.message : 'Error'));
            }
        });
    }

    // ── Quick Reply Functions ────────────────────────────────────────────────
    function nshAddQuickReply() {
        const form = document.getElementById('nsh-quick-reply-form');
        const formData = new FormData(form);
        formData.append('action', 'nsh_add_quick_reply');
        formData.set('nonce', NSH.admin_nonce);

        fetch(NSH.ajax_url, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                const msg = document.getElementById('quick-reply-message');
                if (data.success) {
                    msg.innerHTML = '<div class="nsh-alert nsh-alert-success" style="background:#d1fae5;color:#065f46;padding:8px 12px;border-radius:6px;">✅ Quick reply added!</div>';
                    setTimeout(() => location.reload(), 900);
                } else {
                    msg.innerHTML = '<div class="nsh-alert nsh-alert-error" style="background:#fee2e2;color:#991b1b;padding:8px 12px;border-radius:6px;">❌ ' + (data.data || 'Error') + '</div>';
                }
            });
    }

    function nshUpdateQuickReply() {
        const form = document.getElementById('nsh-quick-reply-form');
        const formData = new FormData(form);
        formData.append('action', 'nsh_update_quick_reply');
        formData.set('nonce', NSH.admin_nonce);

        fetch(NSH.ajax_url, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    location.href = '?tab=settings&section=quick_replies';
                } else {
                    alert('❌ ' + (data.data || 'Update failed'));
                }
            });
    }

    function nshDeleteQuickReply(id) {
        if (!confirm('Delete this quick reply?')) return;
        fetch(NSH.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nsh_delete_quick_reply&id=' + encodeURIComponent(id) + '&nonce=' + NSH.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('❌ ' + (data.data || 'Delete failed'));
        });
    }

    // ── Holiday Functions ────────────────────────────────────────────────────
    function nshAddHoliday() {
        const form = document.getElementById('nsh-holiday-form');
        const formData = new FormData(form);
        formData.append('action', 'nsh_add_holiday');
        formData.set('nonce', NSH.admin_nonce);

        fetch(NSH.ajax_url, { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                const msg = document.getElementById('holiday-message');
                if (data.success) {
                    msg.innerHTML = '<div class="nsh-alert nsh-alert-success" style="background:#d1fae5;color:#065f46;padding:8px 12px;border-radius:6px;">✅ Holiday added!</div>';
                    setTimeout(() => location.reload(), 900);
                } else {
                    const err = data.data && data.data.message ? data.data.message : (data.data || 'Error');
                    msg.innerHTML = '<div class="nsh-alert nsh-alert-error" style="background:#fee2e2;color:#991b1b;padding:8px 12px;border-radius:6px;">❌ ' + err + '</div>';
                }
            });
    }

    function nshDeleteHoliday(id) {
        if (!confirm('Delete this holiday?')) return;
        fetch(NSH.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nsh_delete_holiday&id=' + id + '&nonce=' + NSH.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('❌ ' + (data.data || 'Delete failed'));
        });
    }

    // ── Internal Status (CRM pipeline) management ────────────────────────────
    // Every action here reloads the page on success — same convention as
    // the Holidays section just above — rather than re-rendering the
    // table in place, since the row markup (order arrows enabled/
    // disabled at the ends, per-row "in use" counts) is built server-side
    // in nsh_render_internal_status_mgmt_rows() and duplicating that
    // logic in JS would be one more place for the two to drift apart.
    // This is a settings/admin-configuration screen, not the fast-moving
    // Requests list itself — the "no unnecessary reloads" requirement in
    // the spec is specifically about assigning a status to a request
    // (nshChangeInternalStatus() in shortcodes.php), which never reloads.
    function nshAddInternalStatus() {
        const label = document.getElementById('nsh-istatus-new-label').value.trim();
        const color = document.getElementById('nsh-istatus-new-color').value;
        const msg = document.getElementById('istatus-message');
        if (!label) { msg.innerHTML = '<div class="nsh-alert nsh-alert-error" style="background:#fee2e2;color:#991b1b;padding:8px 12px;border-radius:6px;">❌ Enter a status name.</div>'; return; }
        fetch(NSH.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nsh_admin_save_internal_status&label=' + encodeURIComponent(label) + '&color=' + encodeURIComponent(color) + '&nonce=' + NSH.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) { msg.innerHTML = '<div class="nsh-alert nsh-alert-success" style="background:#d1fae5;color:#065f46;padding:8px 12px;border-radius:6px;">✅ Status added!</div>'; setTimeout(() => location.reload(), 700); }
            else { msg.innerHTML = '<div class="nsh-alert nsh-alert-error" style="background:#fee2e2;color:#991b1b;padding:8px 12px;border-radius:6px;">❌ ' + (data.data && data.data.message ? data.data.message : 'Error') + '</div>'; }
        });
    }
    function nshRenameInternalStatus(id, currentLabel, currentColor) {
        const label = prompt('Status name:', currentLabel);
        if (label === null) return;
        const trimmed = label.trim();
        if (!trimmed) { alert('Status name cannot be empty.'); return; }
        fetch(NSH.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nsh_admin_save_internal_status&id=' + id + '&label=' + encodeURIComponent(trimmed) + '&color=' + encodeURIComponent(currentColor || '#6b7280') + '&nonce=' + NSH.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('❌ ' + (data.data && data.data.message ? data.data.message : 'Rename failed'));
        });
    }
    function nshMoveInternalStatus(id, dir) {
        const rows = Array.from(document.querySelectorAll('#nsh-istatus-mgmt-table tbody tr'));
        const ids = rows.map(r => parseInt(r.getAttribute('data-id'), 10));
        const idx = ids.indexOf(id);
        const swapWith = idx + dir;
        if (idx < 0 || swapWith < 0 || swapWith >= ids.length) return;
        const tmp = ids[idx]; ids[idx] = ids[swapWith]; ids[swapWith] = tmp;
        fetch(NSH.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nsh_admin_reorder_internal_statuses&order=' + ids.join(',') + '&nonce=' + NSH.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('❌ Reorder failed');
        });
    }
    // ── Services tab: manual Save Changes (no auto-save, no reload) ──────────
    // Toggling a checkbox is now pure client-side state; nothing reaches the
    // server until nshSaveServicesChanges() runs, and the page never reloads
    // — the "N of M active" count, the Yes/No labels, and the unsaved banner
    // are all updated in place from the AJAX response.
    function nshServicesCheckDirty() {
        let dirty = false;
        document.querySelectorAll('.nsh-svc-active-cb').forEach(function (cb) {
            const label = cb.closest('label').querySelector('.nsh-svc-active-label');
            label.textContent = cb.checked ? 'Yes' : 'No';
            if (String(cb.checked ? 1 : 0) !== cb.getAttribute('data-initial')) { dirty = true; }
        });
        document.getElementById('nsh-svc-unsaved-banner').style.display = dirty ? 'flex' : 'none';
        document.getElementById('nsh-svc-save-changes-btn').disabled = !dirty;
    }

    function nshSaveServicesChanges() {
        const btn = document.getElementById('nsh-svc-save-changes-btn');
        const states = {};
        document.querySelectorAll('.nsh-svc-active-cb').forEach(function (cb) {
            states[cb.getAttribute('data-id')] = cb.checked ? 1 : 0;
        });
        btn.disabled = true;
        btn.textContent = 'Saving…';
        fetch(NSH.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nsh_admin_save_services_bulk&states=' + encodeURIComponent(JSON.stringify(states)) + '&nonce=' + NSH.admin_nonce
        }).then(r => r.json()).then(data => {
            btn.textContent = 'Save Changes';
            if (!data.success) {
                alert('❌ ' + ((data.data && data.data.message) ? data.data.message : 'Save failed'));
                btn.disabled = false;
                return;
            }
            // Re-baseline every checkbox to its now-saved value instead of
            // reloading, so a re-toggle back to the value just saved is
            // correctly recognised as "not dirty" again.
            document.querySelectorAll('.nsh-svc-active-cb').forEach(function (cb) {
                cb.setAttribute('data-initial', cb.checked ? '1' : '0');
            });
            document.getElementById('nsh-svc-active-count').textContent = data.data.active_count + ' of ' + data.data.total_count + ' services active';
            document.getElementById('nsh-svc-unsaved-banner').style.display = 'none';
            btn.disabled = true;
        }).catch(function () {
            btn.textContent = 'Save Changes';
            btn.disabled = false;
            alert('❌ Connection error. Please check your internet and try again.');
        });
    }

    // ── Services tab: Add New Service ─────────────────────────────────────
    let nshSlugManuallyEdited = false;
    function nshToggleAddServicePanel(show) {
        const panel = document.getElementById('nsh-add-service-panel');
        const willShow = (typeof show === 'boolean') ? show : (panel.style.display === 'none');
        panel.style.display = willShow ? 'block' : 'none';
        if (willShow) {
            panel.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        } else {
            // Clear the form on cancel so a re-open starts fresh.
            ['nsvc-name','nsvc-slug','nsvc-desc','nsvc-docs','nsvc-price'].forEach(id => { document.getElementById(id).value = ''; });
            document.getElementById('nsvc-category').value = '';
            document.getElementById('nsvc-turnaround').value = '7';
            document.getElementById('nsvc-pricing').value = 'quote';
            document.getElementById('nsvc-price-wrap').style.display = 'none';
            document.getElementById('nsvc-active').checked = true;
            document.getElementById('nsh-svc-create-msg').style.display = 'none';
            nshSlugManuallyEdited = false;
        }
    }
    document.addEventListener('DOMContentLoaded', function () {
        const slugInp = document.getElementById('nsvc-slug');
        if (slugInp) { slugInp.addEventListener('input', function () { nshSlugManuallyEdited = true; }); }
    });
    function nshAutoSlug() {
        if (nshSlugManuallyEdited) { return; }
        const name = document.getElementById('nsvc-name').value;
        document.getElementById('nsvc-slug').value = name
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, '-')
            .replace(/(^-+|-+$)/g, '');
    }

    function nshCreateService() {
        const msg = document.getElementById('nsh-svc-create-msg');
        const name = document.getElementById('nsvc-name').value.trim();
        const category = document.getElementById('nsvc-category').value;
        if (!name) { msg.className = 'nsh-alert nsh-alert-error'; msg.textContent = 'Service name is required.'; msg.style.display = 'block'; return; }
        if (!category) { msg.className = 'nsh-alert nsh-alert-error'; msg.textContent = 'Please choose a category.'; msg.style.display = 'block'; return; }
        const btn = document.getElementById('nsh-svc-do-create');
        btn.disabled = true; btn.textContent = 'Creating…';
        const body = new URLSearchParams({
            action: 'nsh_admin_create_service',
            nonce: NSH.admin_nonce,
            name: name,
            slug: document.getElementById('nsvc-slug').value.trim(),
            category: category,
            short_desc: document.getElementById('nsvc-desc').value,
            pricing_model: document.getElementById('nsvc-pricing').value,
            base_price: document.getElementById('nsvc-price').value,
            turnaround_days: document.getElementById('nsvc-turnaround').value,
            required_docs: document.getElementById('nsvc-docs').value,
            active: document.getElementById('nsvc-active').checked ? '1' : '0'
        });
        fetch(NSH.ajax_url, { method: 'POST', headers: {'Content-Type': 'application/x-www-form-urlencoded'}, body: body.toString() })
            .then(r => r.json()).then(data => {
                btn.disabled = false; btn.textContent = 'Create Service';
                if (!data.success) {
                    msg.className = 'nsh-alert nsh-alert-error';
                    msg.textContent = '❌ ' + ((data.data && data.data.message) ? data.data.message : 'Could not create service.');
                    msg.style.display = 'block';
                    return;
                }
                msg.className = 'nsh-alert nsh-alert-success';
                msg.innerHTML = '✅ "' + data.data.name + '" created. <a href="' + data.data.fields_url + '" style="font-weight:600;">Manage its form fields &rarr;</a>';
                msg.style.display = 'block';
                // Insert the new row into the table in place — no reload —
                // and update the active count, same as a manual Save does.
                // row_html is the server-rendered <tr>…</tr> for this new
                // service (nsh_render_one_service_mgmt_row(), the exact same
                // markup the initial page render uses), so the new row is
                // pixel-identical to every existing one, including its own
                // "Manage Fields →" link.
                const tbody = document.querySelector('#nsh-svc-mgmt-table tbody');
                tbody.insertAdjacentHTML('beforeend', data.data.row_html);
                const countEl = document.getElementById('nsh-svc-active-count');
                const parts = countEl.textContent.match(/(\d+) of (\d+)/);
                if (parts) {
                    const activeN = parseInt(parts[1], 10) + (data.data.is_active ? 1 : 0);
                    const totalN = parseInt(parts[2], 10) + 1;
                    countEl.textContent = activeN + ' of ' + totalN + ' services active';
                }
                nshToggleAddServicePanel(false);
                msg.style.display = 'block'; // keep success message visible after panel clears
            }).catch(function () {
                btn.disabled = false; btn.textContent = 'Create Service';
                msg.className = 'nsh-alert nsh-alert-error';
                msg.textContent = '❌ Connection error. Please check your internet and try again.';
                msg.style.display = 'block';
            });
    }

    function nshFilterServicesTable(q) {
        q = (q || '').toLowerCase();
        document.querySelectorAll('#nsh-svc-mgmt-table tbody tr').forEach(function (row) {
            row.style.display = row.getAttribute('data-svc-name').indexOf(q) !== -1 ? '' : 'none';
        });
    }
    function nshToggleInternalStatus(id, active) {
        fetch(NSH.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nsh_admin_toggle_internal_status&id=' + id + '&active=' + (active ? '1' : '0') + '&nonce=' + NSH.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('❌ Update failed');
        });
    }
    function nshDeleteInternalStatus(id, inUse) {
        if (inUse > 0) { alert(inUse + ' request(s) currently use this status. Deactivate it instead, or reassign those requests first.'); return; }
        if (!confirm('Delete this internal status? This cannot be undone.')) return;
        fetch(NSH.ajax_url, {
            method: 'POST',
            headers: {'Content-Type': 'application/x-www-form-urlencoded'},
            body: 'action=nsh_admin_delete_internal_status&id=' + id + '&nonce=' + NSH.admin_nonce
        }).then(r => r.json()).then(data => {
            if (data.success) location.reload();
            else alert('❌ ' + (data.data && data.data.message ? data.data.message : 'Delete failed'));
        });
    }

    // ── Test delivery calculator ─────────────────────────────────────────────
    function nshTestCalculator() {
        const days = document.getElementById('test-days').value;
        if (!days || parseInt(days) < 1) { alert('Enter a valid number of working days.'); return; }

        const result = document.getElementById('calculator-result');
        result.innerHTML = '<div style="color:#555;font-size:13px;">⏳ Calculating…</div>';

        fetch(NSH.ajax_url + '?action=nsh_calculate_delivery&days=' + encodeURIComponent(days) + '&nonce=' + NSH.admin_nonce)
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    const d = data.data;
                    result.innerHTML = '<div style="background:#d1fae5;color:#065f46;padding:12px;border-radius:6px;font-size:13px;">' +
                        '<strong>📅 Delivery Date: ' + d.delivery_date_formatted + '</strong><br><br>' +
                        '• Working Days: <strong>' + d.working_days + '</strong><br>' +
                        '• Total Calendar Days: ' + d.total_calendar_days + '<br>' +
                        '• Weekends Skipped: ' + d.weekends_excluded + '<br>' +
                        '• Holidays Skipped: ' + d.holidays_excluded +
                        '</div>';
                } else {
                    const err = data.data && data.data.message ? data.data.message : (data.data || 'Calculation failed');
                    result.innerHTML = '<div style="background:#fee2e2;color:#991b1b;padding:10px;border-radius:6px;">❌ ' + err + '</div>';
                }
            })
            .catch(e => {
                result.innerHTML = '<div style="background:#fee2e2;color:#991b1b;padding:10px;border-radius:6px;">❌ Network error: ' + e.message + '</div>';
            });
    }

    // ── SMTP Settings ────────────────────────────────────────────────────────
    // Everything below this point only needs to run ONCE per page session:
    // the functions above are safe to redefine (identical code every time),
    // but the document.addEventListener(...) calls below are NOT idempotent
    // — the Settings tab can now be (re)loaded via the admin dashboard's
    // AJAX tab switcher instead of always via a full page load, and without
    // this guard, visiting Settings twice would register every one of these
    // click/change handlers twice (so each click would fire its action
    // twice, three times on a third visit, and so on).
    if (!window.__nriSettingsJsInit) {
    window.__nriSettingsJsInit = true;

    // Shortcodes tab: "Copy" buttons (nsh_settings_shortcodes() in
    // admin-settings-integrated.php). Delegated + driven by a data-copy
    // attribute rather than an inline onclick containing quote characters,
    // because this whole block of HTML is rendered as ordinary WordPress
    // page content and passes through wptexturize() (the filter that turns
    // straight quotes into “smart” typographic quotes for readability in
    // post text) before it ever reaches the browser. wptexturize has no
    // concept of HTML attribute boundaries — it only sees a stream of
    // characters — so a straight " immediately followed by > (exactly the
    // shape of ...);">Copy</button>, which an inline onclick ending in
    // "1200);" produced here) reads to it like the end of a quoted phrase,
    // and it silently rewrites that closing " into a curly ” character.
    // The browser then never sees the onclick attribute end at all: it
    // keeps consuming everything after it — the "Copy" label, the
    // </button>, the </td>, the next <td>'s own attributes — as more of
    // that one broken attribute value, until it finally hits some other
    // stray straight quote further down the row. That's what was making
    // the Shortcodes admin page look like several rows' markup had been
    // mashed together with stray link text and broken cells: every row's
    // Copy button was quietly corrupting the HTML that followed it.
    // data-copy="..." has no raw quote characters in the rendered HTML at
    // all (esc_attr() turns any into the harmless entities &quot;/&#039;,
    // which wptexturize leaves alone), so there is nothing left for it to
    // mistake for a closing quote.
    document.addEventListener('click', function(e) {
        var btn = e.target.closest ? e.target.closest('.nsh-sc-copy-btn') : null;
        if (!btn) return;
        var text = btn.getAttribute('data-copy') || '';
        var restore = function () {
            btn.textContent = 'Copy';
        };
        navigator.clipboard.writeText(text).then(function () {
            btn.textContent = 'Copied!';
            setTimeout(restore, 1200);
        }).catch(function () {
            btn.textContent = 'Copy failed';
            setTimeout(restore, 1200);
        });
    });

    // Toggle fields enabled/disabled when checkbox changes
    document.addEventListener('change', function(e) {
        if (e.target && e.target.id === 'nsh-smtp-enabled') {
            var fields = document.getElementById('nsh-smtp-fields');
            if (fields) {
                fields.style.opacity       = e.target.checked ? '1'  : '0.5';
                fields.style.pointerEvents = e.target.checked ? ''   : 'none';
            }
        }
    });

    // Password show/hide toggle
    document.addEventListener('click', function(e) {
        if (e.target && e.target.id === 'nsh-smtp-pw-toggle') {
            var inp = document.getElementById('nsh-smtp-password');
            if (inp) {
                inp.type = (inp.type === 'password') ? 'text' : 'password';
                e.target.textContent = (inp.type === 'password') ? '👁' : '🙈';
            }
        }
    });

    // Quick preset buttons
    document.addEventListener('click', function(e) {
        var btn = e.target.closest ? e.target.closest('.nsh-smtp-preset') : null;
        if (!btn) return;
        var host = btn.dataset.host, port = btn.dataset.port, enc = btn.dataset.enc;
        var hEl = document.getElementById('nsh-smtp-host');
        var pEl = document.getElementById('nsh-smtp-port');
        var eEl = document.getElementById('nsh-smtp-encryption');
        if (hEl && host !== undefined) hEl.value = host;
        if (pEl && port)              pEl.value = port;
        if (eEl && enc)               eEl.value = enc;
        document.querySelectorAll('.nsh-smtp-preset').forEach(function(b){ b.classList.remove('nsh-btn-primary'); b.classList.add('nsh-btn-ghost'); });
        btn.classList.remove('nsh-btn-ghost'); btn.classList.add('nsh-btn-primary');
    });

    // Save SMTP settings
    document.addEventListener('click', function(e) {
        if (!e.target || e.target.id !== 'nsh-save-smtp-btn') return;
        var $msg = document.getElementById('nsh-smtp-msg');
        var btn  = e.target;
        btn.textContent = '⏳ Saving…'; btn.disabled = true;

        var data = new URLSearchParams();
        data.append('action',              'nsh_save_smtp_settings');
        data.append('nonce',               NSH.admin_nonce);
        data.append('nsh_smtp_enabled',    document.getElementById('nsh-smtp-enabled')    && document.getElementById('nsh-smtp-enabled').checked    ? '1' : '0');
        data.append('nsh_smtp_host',       document.getElementById('nsh-smtp-host')       ? document.getElementById('nsh-smtp-host').value       : '');
        data.append('nsh_smtp_port',       document.getElementById('nsh-smtp-port')       ? document.getElementById('nsh-smtp-port').value       : '587');
        data.append('nsh_smtp_encryption', document.getElementById('nsh-smtp-encryption') ? document.getElementById('nsh-smtp-encryption').value : 'tls');
        data.append('nsh_smtp_auth',       '1');
        data.append('nsh_smtp_username',   document.getElementById('nsh-smtp-username')   ? document.getElementById('nsh-smtp-username').value   : '');
        data.append('nsh_smtp_password',   document.getElementById('nsh-smtp-password')   ? document.getElementById('nsh-smtp-password').value   : '');
        data.append('nsh_email_from',      document.getElementById('nsh-smtp-from-email') ? document.getElementById('nsh-smtp-from-email').value : '');
        data.append('nsh_email_name',      document.getElementById('nsh-smtp-from-name')  ? document.getElementById('nsh-smtp-from-name').value  : '');
        data.append('nsh_smtp_debug',      document.getElementById('nsh-smtp-debug')      && document.getElementById('nsh-smtp-debug').checked    ? '1' : '0');

        fetch(NSH.ajax_url, { method: 'POST', body: data })
            .then(function(r){ return r.json(); })
            .then(function(d) {
                btn.textContent = '💾 Save SMTP Settings'; btn.disabled = false;
                if ($msg) {
                    $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;font-weight:600;margin-top:14px;';
                    if (d.success) {
                        $msg.style.background = '#f0fdf4'; $msg.style.color = '#16a34a'; $msg.style.border = '1px solid #bbf7d0';
                        $msg.textContent = '✅ SMTP settings saved. Use "Send Test Email" to verify delivery.';
                    } else {
                        var err = d.data && d.data.message ? d.data.message : 'Save failed';
                        $msg.style.background = '#fef2f2'; $msg.style.color = '#dc2626'; $msg.style.border = '1px solid #fecaca';
                        $msg.textContent = '❌ ' + err;
                    }
                }
            })
            .catch(function(err) {
                btn.textContent = '💾 Save SMTP Settings'; btn.disabled = false;
                if ($msg) { $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;color:#dc2626;background:#fef2f2;border:1px solid #fecaca;'; $msg.textContent = '❌ Network error: ' + err.message; }
            });
    });

    // Send test email
    document.addEventListener('click', function(e) {
        if (!e.target || e.target.id !== 'nsh-smtp-test-btn') return;
        var $msg = document.getElementById('nsh-smtp-msg');
        var to   = prompt('Send test email to:', '<?php echo esc_js( wp_get_current_user()->user_email ); ?>');
        if (!to || !to.trim()) return;
        var btn  = e.target;
        btn.textContent = '⏳ Sending…'; btn.disabled = true;
        if ($msg) { $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;background:#f1f5f9;color:#475569;margin-top:14px;'; $msg.textContent = 'Sending test email to ' + to + ' …'; }

        var data = new URLSearchParams();
        data.append('action',     'nsh_smtp_test');
        data.append('nonce',      NSH.admin_nonce);
        data.append('test_email', to.trim());

        fetch(NSH.ajax_url, { method: 'POST', body: data })
            .then(function(r){ return r.json(); })
            .then(function(d) {
                btn.textContent = '📧 Send Test Email'; btn.disabled = false;
                if ($msg) {
                    $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;font-weight:600;margin-top:14px;';
                    if (d.success) {
                        $msg.style.background = '#f0fdf4'; $msg.style.color = '#16a34a'; $msg.style.border = '1px solid #bbf7d0';
                        $msg.textContent = '✅ ' + (d.data && d.data.message ? d.data.message : 'Test sent!');
                    } else {
                        var err = d.data && d.data.message ? d.data.message : 'Test failed';
                        $msg.style.background = '#fef2f2'; $msg.style.color = '#dc2626'; $msg.style.border = '1px solid #fecaca';
                        $msg.innerHTML = '❌ ' + err + '<br><small style="font-weight:400;color:#7f1d1d;">Check nsh-debug.log in wp-content/uploads/nsh-logs/ for full SMTP details.</small>';
                    }
                }
            })
            .catch(function(err) {
                btn.textContent = '📧 Send Test Email'; btn.disabled = false;
                if ($msg) { $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;color:#dc2626;background:#fef2f2;border:1px solid #fecaca;'; $msg.textContent = '❌ Network error: ' + err.message; }
            });
    });

    // Send test ADMIN notification — proves the actual notification path
    // (nsh_admin_notification_email() -> nsh_mail()), not just raw SMTP.
    // Reads the Manager Email field LIVE from the page (not the last-saved
    // value) so a value just typed can be tested before even clicking Save.
    document.addEventListener('click', function(e) {
        if (!e.target || e.target.id !== 'nsh-test-admin-notif-btn') return;
        var $msg = document.getElementById('nsh-test-admin-notif-msg');
        var btn  = e.target;
        btn.textContent = '⏳ Sending…'; btn.disabled = true;
        if ($msg) { $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;background:#f1f5f9;color:#475569;'; $msg.textContent = 'Sending test admin notification…'; }

        var data = new URLSearchParams();
        data.append('action', 'nsh_test_admin_notification');
        data.append('nonce',  NSH.admin_nonce);
        var $liveEmail = document.getElementById('nsh-manager-email-inp');
        data.append('live_manager_email', $liveEmail ? $liveEmail.value : '');

        fetch(NSH.ajax_url, { method: 'POST', body: data })
            .then(function(r){ return r.json(); })
            .then(function(d) {
                btn.textContent = '🔔 Send Test Admin Notification'; btn.disabled = false;
                if ($msg) {
                    $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;font-weight:600;';
                    if (d.success) {
                        $msg.style.background = '#f0fdf4'; $msg.style.color = '#16a34a'; $msg.style.border = '1px solid #bbf7d0';
                        $msg.textContent = '✅ ' + (d.data && d.data.message ? d.data.message : 'Sent!');
                    } else {
                        var err = d.data && d.data.message ? d.data.message : 'Test failed';
                        $msg.style.background = '#fef2f2'; $msg.style.color = '#dc2626'; $msg.style.border = '1px solid #fecaca';
                        $msg.innerHTML = '❌ ' + err + '<br><small style="font-weight:400;color:#7f1d1d;">Check nsh-debug.log in wp-content/uploads/nsh-logs/ for the full reason.</small>';
                    }
                }
            })
            .catch(function(err) {
                btn.textContent = '🔔 Send Test Admin Notification'; btn.disabled = false;
                if ($msg) { $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;color:#dc2626;background:#fef2f2;border:1px solid #fecaca;'; $msg.textContent = '❌ Network error: ' + err.message; }
            });
    });

    // ── Bot Protection (CAPTCHA) Settings ────────────────────────────────────
    // Toggle fields enabled/disabled when checkbox changes — same pattern as
    // the SMTP enable checkbox above, kept as its own listener rather than
    // folded into that one so the two sections stay independent.
    document.addEventListener('change', function(e) {
        if (e.target && e.target.id === 'nsh-captcha-enabled') {
            var fields = document.getElementById('nsh-captcha-fields');
            if (fields) {
                fields.style.opacity       = e.target.checked ? '1'  : '0.5';
                fields.style.pointerEvents = e.target.checked ? ''   : 'none';
            }
        }
        if (e.target && e.target.id === 'nsh-captcha-builtin-enabled') {
            var bfields = document.getElementById('nsh-captcha-builtin-fields');
            if (bfields) {
                bfields.style.opacity       = e.target.checked ? '1'  : '0.5';
                bfields.style.pointerEvents = e.target.checked ? ''   : 'none';
            }
        }
        if (e.target && e.target.name === 'nsh-captcha-provider') {
            var panelBuiltin   = document.getElementById('nsh-captcha-panel-builtin');
            var panelTurnstile = document.getElementById('nsh-captcha-panel-turnstile');
            var isBuiltin      = e.target.value === 'builtin';
            if (panelBuiltin)   { panelBuiltin.style.display   = isBuiltin ? '' : 'none'; }
            if (panelTurnstile) { panelTurnstile.style.display = isBuiltin ? 'none' : ''; }
            var cards = document.querySelectorAll('.nsh-captcha-provider-card');
            cards.forEach(function(card) {
                var radio = card.querySelector('input[type="radio"]');
                if (radio) { card.style.borderColor = radio.checked ? '#2563eb' : '#e2e8f0'; }
            });
        }
    });

    // Save Bot Protection settings
    document.addEventListener('click', function(e) {
        if (!e.target || e.target.id !== 'nsh-save-captcha-btn') return;
        var $msg = document.getElementById('nsh-captcha-msg');
        var btn  = e.target;
        btn.textContent = '⏳ Saving…'; btn.disabled = true;

        var providerEl = document.querySelector('input[name="nsh-captcha-provider"]:checked');
        var provider   = providerEl ? providerEl.value : 'builtin';

        var data = new URLSearchParams();
        data.append('action',            'nsh_save_captcha_settings');
        data.append('nonce',             NSH.admin_nonce);
        data.append('provider',          provider);
        data.append('builtin_enabled',   document.getElementById('nsh-captcha-builtin-enabled')   && document.getElementById('nsh-captcha-builtin-enabled').checked ? '1' : '0');
        data.append('builtin_min_seconds', document.getElementById('nsh-captcha-builtin-min-seconds') ? document.getElementById('nsh-captcha-builtin-min-seconds').value : '3');
        data.append('enabled',    document.getElementById('nsh-captcha-enabled')    && document.getElementById('nsh-captcha-enabled').checked ? '1' : '0');
        data.append('site_key',   document.getElementById('nsh-captcha-site-key')   ? document.getElementById('nsh-captcha-site-key').value   : '');
        data.append('secret_key', document.getElementById('nsh-captcha-secret-key') ? document.getElementById('nsh-captcha-secret-key').value : '');

        fetch(NSH.ajax_url, { method: 'POST', body: data })
            .then(function(r){ return r.json(); })
            .then(function(d) {
                btn.textContent = '💾 Save Bot Protection Settings'; btn.disabled = false;
                if ($msg) {
                    $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;font-weight:600;margin-top:14px;';
                    if (d.success) {
                        $msg.style.background = '#f0fdf4'; $msg.style.color = '#16a34a'; $msg.style.border = '1px solid #bbf7d0';
                        $msg.textContent = '✅ Saved. Reload this page to confirm the new keys took effect.';
                    } else {
                        var err = d.data && d.data.message ? d.data.message : 'Save failed';
                        $msg.style.background = '#fef2f2'; $msg.style.color = '#dc2626'; $msg.style.border = '1px solid #fecaca';
                        $msg.textContent = '❌ ' + err;
                    }
                }
            })
            .catch(function(err) {
                btn.textContent = '💾 Save Bot Protection Settings'; btn.disabled = false;
                if ($msg) { $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;color:#dc2626;background:#fef2f2;border:1px solid #fecaca;'; $msg.textContent = '❌ Network error: ' + err.message; }
            });
    });

    // ── Fix Existing Documents ───────────────────────────────────────────────
    (function() {
        var fixBtn     = document.getElementById('nsh-fix-docs-btn');
        var scanBtn    = document.getElementById('nsh-recount-docs-btn');
        var statusBox  = document.getElementById('nsh-fix-docs-status');
        var fixProg    = document.getElementById('nsh-fix-docs-progress');
        var fixBar     = document.getElementById('nsh-fix-docs-bar');
        var fixMsg     = document.getElementById('nsh-fix-docs-msg');
        var totalBroken = 0;

        if (!fixBtn || !scanBtn) return; // not on general settings tab

        function nshDocPost(action, data, onOk, onErr) {
            var body = new URLSearchParams({ action: action, nonce: NSH.admin_nonce || NSH.nonce || '' });
            Object.keys(data).forEach(function(k){ body.append(k, data[k]); });
            fetch(NSH.ajax_url, { method: 'POST', body: body, headers: { 'X-Requested-With': 'XMLHttpRequest' } })
                .then(function(r){ return r.json(); })
                .then(function(r){
                    if (r && r.success) { onOk(r.data || {}); }
                    else { onErr((r && r.data && r.data.message) ? r.data.message : 'Server error'); }
                })
                .catch(function(e){ onErr('Network error: ' + e.message); });
        }

        // Scan button
        scanBtn.addEventListener('click', function() {
            scanBtn.disabled = true;
            scanBtn.textContent = '⏳ Scanning…';
            if (statusBox) statusBox.textContent = '⏳ Scanning all documents…';
            nshDocPost('nsh_count_avif_docs', {}, function(d) {
                scanBtn.disabled = false;
                scanBtn.textContent = '🔍 Scan Again';
                totalBroken = parseInt(d.count) || 0;
                if (statusBox) {
                    if (totalBroken === 0) {
                        statusBox.style.cssText = 'background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;padding:10px 14px;font-size:13px;color:#166534;margin-bottom:14px;';
                        statusBox.textContent = '✅ All documents are in PDF/JPG/PNG format. Nothing to fix.';
                    } else {
                        statusBox.style.cssText = 'background:#fef9c3;border:1px solid #fde68a;border-radius:6px;padding:10px 14px;font-size:13px;color:#78350f;margin-bottom:14px;';
                        statusBox.textContent = '⚠️ ' + totalBroken + ' document(s) found in AVIF or WebP format.';
                    }
                }
                fixBtn.disabled = (totalBroken === 0);
                fixBtn.textContent = totalBroken > 0 ? '🔧 Convert ' + totalBroken + ' Document(s) to PNG' : '🔧 Convert to PNG';
            }, function(err) {
                scanBtn.disabled = false;
                scanBtn.textContent = '🔍 Scan';
                if (statusBox) { statusBox.style.cssText = 'background:#fef2f2;border:1px solid #fecaca;border-radius:6px;padding:10px 14px;font-size:13px;color:#991b1b;margin-bottom:14px;'; statusBox.textContent = '❌ Scan failed: ' + err; }
            });
        });

        // Convert button
        fixBtn.addEventListener('click', function() {
            fixBtn.disabled = true;
            fixBtn.textContent = '⏳ Converting…';
            fixProg.style.display = 'block';
            fixBar.style.width = '2%';
            fixMsg.textContent = 'Starting conversion…';
            runBatch(0, totalBroken);
        });

        function runBatch(done, total) {
            nshDocPost('nsh_fix_avif_docs', { batch: 10 }, function(d) {
                done += parseInt(d.converted) || 0;
                var remaining = parseInt(d.remaining) || 0;
                var pct = total > 0 ? Math.min(98, Math.round((done / total) * 100)) : 50;
                fixBar.style.width = pct + '%';
                fixMsg.textContent = '✓ ' + done + ' converted'
                    + (d.failed ? ', ✗ ' + d.failed + ' failed' : '')
                    + (remaining > 0 ? ' — ' + remaining + ' remaining…' : '');

                if (remaining > 0) {
                    setTimeout(function(){ runBatch(done, total); }, 400);
                } else {
                    fixBar.style.width = '100%';
                    fixBar.style.background = '#10b981';
                    fixBtn.disabled = true;
                    fixBtn.textContent = '✅ All Done';
                    fixMsg.textContent = '🎉 ' + done + ' document(s) successfully converted to PNG.';
                    if (statusBox) { statusBox.style.cssText = 'background:#f0fdf4;border:1px solid #bbf7d0;border-radius:6px;padding:10px 14px;font-size:13px;color:#166534;margin-bottom:14px;'; statusBox.textContent = '✅ All documents are now in PDF/JPG/PNG format.'; }
                    scanBtn.textContent = '🔍 Scan Again';
                }
            }, function(err) {
                fixBtn.disabled = false;
                fixBtn.textContent = '🔧 Retry';
                fixMsg.textContent = '❌ Error: ' + err;
            });
        }
    })();
    // ── END "Fix Existing Documents" IIFE ──────────────────────────────────
    // ROOT-CAUSE FIX: everything below used to live INSIDE the IIFE above,
    // which opens with `if (!fixBtn || !scanBtn) return;` — a guard that is
    // only meant to skip the Fix-Existing-Documents feature on settings
    // sections that don't render its two buttons. But because nothing
    // closed that IIFE until the very end of this script, that same early
    // `return` was ALSO skipping every line after it — including the color
    // swatch sync listeners and, critically, the Save/Reset Form Styling
    // button click handlers below. #nsh-fix-docs-btn only exists on the
    // General settings section, so on Settings -> Form Styling (and any
    // other section) fixBtn/scanBtn were always null, the guard always
    // fired, and the Form Styling Save/Reset buttons silently never got
    // wired up at all — clicking them did nothing, which is why no value
    // ever saved, nothing ever persisted, and the frontend forms never
    // reflected any change no matter what was picked here. Moving the
    // closing `})();` up to right above this comment, and leaving the code
    // below at the outer (unguarded) scope, fixes this at its root.

    /* ── FORM STYLING — Settings -> Form Styling ───────────────────
       Keeps each color-swatch <input type=color> and its adjacent hex
       text field in sync (either one can drive the other), collects
       every .nsh-fs-input on save, and posts them all in one request. */
    document.addEventListener('input', function (e) {
            if (!e.target.classList || !e.target.classList.contains('nsh-fs-color-swatch')) return;
            var wrap = e.target.closest('div');
            var textEl = wrap && wrap.querySelector('.nsh-fs-color-text');
            if (textEl) textEl.value = e.target.value;
        });
        document.addEventListener('input', function (e) {
            if (!e.target.classList || !e.target.classList.contains('nsh-fs-color-text')) return;
            if (!/^#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})$/.test(e.target.value)) return;
            var wrap = e.target.closest('div');
            var swatchEl = wrap && wrap.querySelector('.nsh-fs-color-swatch');
            if (swatchEl) swatchEl.value = e.target.value;
        });

        function nshFormStyleMsg(text, ok) {
            var $msg = document.getElementById('nsh-form-style-msg');
            if (!$msg) return;
            $msg.style.cssText = 'padding:10px 14px;border-radius:6px;font-size:13px;font-weight:600;';
            $msg.style.background = ok ? '#f0fdf4' : '#fef2f2';
            $msg.style.color      = ok ? '#166534' : '#dc2626';
            $msg.textContent = text;
        }

        document.addEventListener('click', function (e) {
            if (!e.target || e.target.id !== 'nsh-save-form-style-btn') return;
            var btn = e.target;
            btn.textContent = '⏳ Saving…'; btn.disabled = true;
            var data = new URLSearchParams();
            data.append('action', 'nsh_save_form_style');
            data.append('nonce', NSH.admin_nonce);
            document.querySelectorAll('.nsh-fs-input[data-key]').forEach(function (el) {
                // Skip the color <input type=color> swatches — their paired
                // .nsh-fs-color-text field (kept in sync above) is the one
                // whose value actually gets submitted for that key.
                if (el.classList.contains('nsh-fs-color-swatch')) return;
                data.append(el.dataset.key, el.value);
            });
            fetch(NSH.ajax_url, { method: 'POST', body: data })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    btn.textContent = '💾 Save Form Styling'; btn.disabled = false;
                    if (d && d.success) { nshFormStyleMsg('✅ Saved — refresh any open form page to see the changes.', true); }
                    else { nshFormStyleMsg('❌ ' + ((d && d.data && d.data.message) ? d.data.message : 'Could not save.'), false); }
                })
                .catch(function () { btn.textContent = '💾 Save Form Styling'; btn.disabled = false; nshFormStyleMsg('❌ Connection error.', false); });
        });

        document.addEventListener('click', function (e) {
            if (!e.target || e.target.id !== 'nsh-reset-form-style-btn') return;
            if (!confirm('Reset all form styling to the default look?')) return;
            var btn = e.target;
            btn.textContent = '⏳ Resetting…'; btn.disabled = true;
            var data = new URLSearchParams();
            data.append('action', 'nsh_reset_form_style');
            data.append('nonce', NSH.admin_nonce);
            fetch(NSH.ajax_url, { method: 'POST', body: data })
                .then(function (r) { return r.json(); })
                .then(function () { location.reload(); })
                .catch(function () { btn.textContent = '↺ Reset to Defaults'; btn.disabled = false; nshFormStyleMsg('❌ Connection error.', false); });
        });
    } // end if (!window.__nriSettingsJsInit)
    </script>
    <?php
    $html = ob_get_clean();
    // Strip the literal <script>/</script> wrapper printed above so the
    // inner JS can go through nsh_output_admin_script() — raw (unchanged
    // behavior) for the AJAX tab-swap path, or via wp_add_inline_script()
    // for the direct/full-page-render path, where a raw <script> tag
    // baked into page content risks being silently corrupted by
    // wp_kses_post()-style content sanitization (see that function's
    // docblock, enqueue.php, for the full explanation).
    $js = preg_replace( '/^\s*<script>/', '', $html );
    $js = preg_replace( '/<\/script>\s*$/', '', $js );
    return nsh_output_admin_script( $js, $echo_inline_script );
}
