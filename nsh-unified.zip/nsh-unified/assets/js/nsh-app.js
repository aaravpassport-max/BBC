/* NSH Platform — nsh-app.js v2.0 | All code inside single jQuery closure */
(function ($) {
    'use strict';

    /* ── Helpers ─────────────────────────────────────────────── */
    function esc(s) {
        return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
    }
    function nonce() { return NSH.admin_nonce || NSH.nonce; }
    function showMsg($el, type, text) {
        $el.removeClass('nsh-alert-success nsh-alert-error').addClass('nsh-alert nsh-alert-' + type).text(text).show();
    }
    function nshPost(action, data, cb, errCb) {
        data.action = action;
        data.nonce  = nonce();
        $.post(NSH.ajax_url, data)
            .done(function(r){ if (r.success) { if(cb) cb(r.data); } else { if(errCb) errCb(r.data&&r.data.message?r.data.message:'An error occurred.'); } })
            .fail(function(){ if(errCb) errCb('Connection error. Please check your internet and try again.'); });
    }

    /* ── Mobile-network-resilient upload helpers ─────────────────
       Root cause of "Connection error" on submit: large camera photos
       (often 4-10MB each) were sent unresized over a fixed 30s AJAX
       timeout, with no retry and no compression. On slow/unstable
       mobile data that upload routinely exceeds 30s or the connection
       drops mid-transfer, and the whole request fails outright.
    ═══════════════════════════════════════════════════════════ */

    // Downscale/compress an image file client-side before upload so a
    // 6-8MB phone-camera photo becomes ~200-500KB. PDFs and files that
    // are already small are sent as-is. Falls back to the original file
    // if compression fails or the browser can't do canvas/blob work.
    function nshCompressImage(file, maxDim, quality) {
        return new Promise(function (resolve) {
            if (!/^image\/(jpeg|jpg|png)$/i.test(file.type) || typeof FileReader === 'undefined') {
                resolve(file);
                return;
            }
            // Small files aren't worth the round-trip through canvas.
            if (file.size <= 700 * 1024) {
                resolve(file);
                return;
            }
            var reader = new FileReader();
            reader.onerror = function () { resolve(file); };
            reader.onload = function (e) {
                var img = new Image();
                img.onerror = function () { resolve(file); };
                img.onload = function () {
                    try {
                        var w = img.width, h = img.height;
                        var scale = Math.min(1, maxDim / Math.max(w, h));
                        var cw = Math.max(1, Math.round(w * scale));
                        var ch = Math.max(1, Math.round(h * scale));
                        var canvas = document.createElement('canvas');
                        canvas.width = cw; canvas.height = ch;
                        var ctx = canvas.getContext('2d');
                        ctx.drawImage(img, 0, 0, cw, ch);
                        canvas.toBlob(function (blob) {
                            if (!blob || blob.size >= file.size) { resolve(file); return; }
                            var compressed;
                            try {
                                compressed = new File([blob], file.name, { type: 'image/jpeg', lastModified: Date.now() });
                            } catch (e2) {
                                // Older mobile browsers may not support the File constructor fully.
                                blob.name = file.name;
                                compressed = blob;
                            }
                            resolve(compressed);
                        }, 'image/jpeg', quality || 0.75);
                    } catch (e3) {
                        resolve(file);
                    }
                };
                img.src = e.target.result;
            };
            reader.readAsDataURL(file);
        });
    }

    function nshFormatMB(bytes) { return (bytes / (1024 * 1024)).toFixed(1) + 'MB'; }

    // Uploads FormData with: a size-aware timeout (mobile networks can be
    // very slow — a fixed 30s budget is not enough for a few MB), a live
    // progress bar, and automatic retry on true network failures (a
    // dropped connection, DNS hiccup, etc.) — but never on a normal
    // server validation response, which arrives with a real HTTP status.
    function nshUploadWithRetry(opts) {
        var attempt = 0;
        var maxAttempts = opts.maxAttempts || 3;

        function bytesOf(fd) {
            var total = 0;
            if (fd && typeof fd.entries === 'function') {
                for (var pair of fd.entries()) {
                    var v = pair[1];
                    if (v && typeof v.size === 'number') total += v.size;
                }
            }
            return total;
        }

        var totalBytes = bytesOf(opts.formData);
        // Budget generously for slow/unstable mobile data: assume as
        // little as ~60KB/s of usable throughput, plus a large fixed
        // floor for latency, retries on the server, etc.
        var dynamicTimeout = Math.max(60000, Math.ceil(totalBytes / (60 * 1024)) * 1000 + 30000);

        function doAttempt() {
            attempt++;
            if (opts.onAttempt) opts.onAttempt(attempt, maxAttempts);

            $.ajax({
                url: NSH.ajax_url,
                type: 'POST',
                data: opts.formData,
                processData: false,
                contentType: false,
                timeout: opts.timeout || dynamicTimeout,
                xhr: function () {
                    var x = $.ajaxSettings.xhr();
                    if (x.upload) {
                        x.upload.addEventListener('progress', function (e) {
                            if (e.lengthComputable && opts.onProgress) {
                                opts.onProgress(Math.round((e.loaded / e.total) * 100));
                            }
                        });
                    }
                    return x;
                },
                success: function (r) {
                    if (opts.onSuccess) opts.onSuccess(r);
                },
                error: function (xhr, status) {
                    // status 0 / readyState 0 or the jQuery statuses
                    // 'timeout'/'error' with no real HTTP status code all
                    // mean the request never reached the server (or the
                    // response never got back) — i.e. a genuine network
                    // problem, not a validation rejection. Those are
                    // worth retrying on a flaky mobile connection.
                    var isNetworkFailure = (xhr.status === 0) || status === 'timeout';
                    if (isNetworkFailure && attempt < maxAttempts) {
                        if (opts.onRetry) opts.onRetry(attempt, maxAttempts);
                        setTimeout(doAttempt, 1500 * attempt); // brief backoff
                        return;
                    }
                    if (opts.onError) opts.onError(xhr, status, attempt);
                }
            });
        }

        doAttempt();
        return { totalBytes: totalBytes, timeout: dynamicTimeout };
    }

    /* ── Persist in-progress request-form field values so a failed
       submission (network drop, closed tab, browser crash) never
       costs the client their typed-in answers. Files themselves
       can't be persisted this way, but re-selecting a file is far
       less painful than re-typing an entire multi-step form. ── */
    var NSH_DRAFT_KEY = 'nsh_request_draft_v1';

    /* ── FORM INSTANCES — the standalone form can sit on one page several
       times (blog hero + sidebar). Every instance is wrapped in an element
       carrying data-nsh-inst="<name>"; all state that used to be global
       (uploads, carried-forward answers, drafts) is kept per instance, and
       every selector that used a fixed #id now uses a class scoped to the
       instance wrapper. A form with no wrapper (the dashboard's own
       "New Request" page) has the instance name '' and behaves as before. ── */
    function nshInstOf($el) { var $w = $($el).closest('[data-nsh-inst]'); return $w.length ? String($w.attr('data-nsh-inst')) : ''; }
    function nshDraftKey(inst) { return NSH_DRAFT_KEY + (inst ? '_' + inst : ''); }
    // Re-id every element in a freshly swapped-in chunk of markup so two instances never share an id
    // (ids, plus the for= / data-target= / aria-* attributes that point at them).
    function nshUniquify($root, inst) {
        if (!inst) { return; }
        var sfx = '-' + inst, map = {};
        $root.find('[id]').each(function () {
            var id = this.id;
            if (!id || id.slice(-sfx.length) === sfx) { return; }
            map[id] = id + sfx; this.id = id + sfx;
        });
        $root.find('[for],[data-target],[aria-controls],[aria-labelledby],[aria-describedby]').each(function () {
            var el = this;
            ['for', 'data-target', 'aria-controls', 'aria-labelledby', 'aria-describedby'].forEach(function (a) {
                var v = el.getAttribute(a); if (v && map[v]) { el.setAttribute(a, map[v]); }
            });
        });
    }
    function nshSaveDraft($form) {
        var inst = nshInstOf($form);
        try {
            var data = {};
            $form.find('input, select, textarea').not('[type=file]').each(function () {
                var $el = $(this), name = $el.attr('name');
                if (!name) return;
                if ($el.attr('type') === 'radio' || $el.attr('type') === 'checkbox') {
                    if ($el.is(':checked')) data[name] = $el.val();
                } else {
                    data[name] = $el.val();
                }
            });
            sessionStorage.setItem(nshDraftKey(inst), JSON.stringify(data));
        } catch (e) { /* storage unavailable (private mode, quota) — ignore, non-critical */ }
    }
    function nshRestoreDraft($form) {
        try {
            var raw = sessionStorage.getItem(nshDraftKey(nshInstOf($form)));
            if (!raw) return;
            var data = JSON.parse(raw);
            Object.keys(data).forEach(function (name) {
                var $el = $form.find('[name="' + name.replace(/"/g, '\\"') + '"]');
                if (!$el.length) return;
                if ($el.attr('type') === 'radio' || $el.attr('type') === 'checkbox') {
                    $el.filter('[value="' + String(data[name]).replace(/"/g, '\\"') + '"]').prop('checked', true);
                } else {
                    $el.val(data[name]);
                }
            });
            nshRunConditionalLogicSafe();
        } catch (e) { /* ignore */ }
    }
    function nshClearDraft(inst) {
        try { sessionStorage.removeItem(nshDraftKey(inst || '')); } catch (e) { /* ignore */ }
    }
    // nshRunConditionalLogic is defined later in this file; this thin
    // wrapper lets the draft-restore code above (defined earlier in
    // source order) call it safely once it exists.
    function nshRunConditionalLogicSafe() {
        if (typeof nshRunConditionalLogic === 'function') nshRunConditionalLogic();
    }

    /* ═══════════════════════════════════════════════════════════
       AUTH — Login tabs, login form, magic link, pw toggle
    ═══════════════════════════════════════════════════════════ */
    $(document).on('click', '.nsh-lt', function () {
        var lt = $(this).data('lt');
        $(this).closest('.nsh-login-card').find('.nsh-lt').removeClass('active');
        $(this).closest('.nsh-login-card').find('.nsh-lt-pane').removeClass('active').hide();
        $(this).addClass('active');
        $('#nsh-lt-' + lt).addClass('active').show();
    });
    $(document).on('click', '.nsh-pw-toggle', function () {
        var $i = $(this).siblings('input');
        if ($i.attr('type') === 'password') { $i.attr('type','text'); $(this).text('Hide'); }
        else { $i.attr('type','password'); $(this).text('Show'); }
    });
    // TRACE: sign-in card submit → posts login (e-mail or username), password, remember flag, redirect_to, the login nonce and the honeypot to nsh_login
    //        → success: browser goes to the dashboard URL the server chose for the account's role; failure (incl. 403/429 JSON bodies): message shown in #nsh-login-err, button re-enabled
    //        pre: form carries name=nonce → post: no password ever stored client-side → edge: network error/timeouts show a retry message
    $(document).on('submit', '#nsh-login-form', function (e) {
        e.preventDefault();
        var $f=$(this), $btn=$f.find('[type=submit]'), $err=$f.closest('.nsh-login-card').find('#nsh-login-err');
        function fail(msg){ $err.text(msg).show(); $btn.find('.nsh-bt').show(); $btn.find('.nsh-bl').hide(); $btn.prop('disabled',false); }
        if ($btn.prop('disabled')) { return; }
        $btn.find('.nsh-bt').hide(); $btn.find('.nsh-bl').show(); $btn.prop('disabled',true); $err.hide();
        $.ajax({url:NSH.ajax_url,type:'POST',timeout:20000,dataType:'json',data:{action:'nsh_login',nonce:$f.find('[name=nonce]').val(),login:$f.find('[name=login]').val(),password:$f.find('[name=password]').val(),remember:$f.find('[name=remember]').is(':checked')?1:0,redirect_to:$f.find('[name=redirect_to]').val()||'',nsh_website:$f.find('[name=nsh_website]').val()||''},
            success:function(r){ if(r&&r.success&&r.data&&r.data.redirect){ window.location.href=r.data.redirect; } else { fail(r&&r.data&&r.data.message?r.data.message:'Login failed.'); } },
            error:function(x){ var m='Connection error. Please try again.'; try{ if(x.responseJSON&&x.responseJSON.data&&x.responseJSON.data.message){ m=x.responseJSON.data.message; } }catch(_){} fail(m); }
        });
    });
    // TRACE: magic-link form submit → posts e-mail + frontend nonce to nsh_magic_link → shows the server's (always identical) confirmation; errors show the server message
    $(document).on('submit', '#nsh-magic-form', function (e) {
        e.preventDefault();
        var $f=$(this),$btn=$f.find('[type=submit]'),$msg=$f.closest('.nsh-login-card').find('#nsh-magic-msg');
        $btn.text('Sending…').prop('disabled',true); $msg.removeClass('nsh-alert-success nsh-alert-error');
        $.ajax({url:NSH.ajax_url,type:'POST',timeout:20000,dataType:'json',data:{action:'nsh_magic_link',nonce:$f.find('[name=nonce]').val(),email:$f.find('[name=email]').val()},
            success:function(r){ var ok=r&&r.success; $msg.addClass('nsh-alert '+(ok?'nsh-alert-success':'nsh-alert-error')).text(r&&r.data&&r.data.message?r.data.message:(ok?'Sign-in link sent. Check your inbox.':'Could not send the link.')).show(); $btn.text('Resend').prop('disabled',false); },
            error:function(x){ var m='Connection error. Please try again.'; try{ if(x.responseJSON&&x.responseJSON.data&&x.responseJSON.data.message){ m=x.responseJSON.data.message; } }catch(_){} $msg.addClass('nsh-alert nsh-alert-error').text(m).show(); $btn.text('Send Login Link').prop('disabled',false); }
        });
    });

    /* ═══════════════════════════════════════════════════════════
       MULTI-STEP REQUEST FORM WIZARD
    ═══════════════════════════════════════════════════════════ */
    var _step = 1, _totalSteps = 4;

    // scrollTop (default true): moving FORWARD to a new step still scrolls
    // to the top of it, same as before — that's normal, expected wizard
    // behavior, especially on mobile, so the new step's fields are visible
    // from the start rather than wherever the previous step happened to
    // leave the scroll position. Going BACK to a previous step passes
    // false — the page just stays where it was, matching the same
    // "never force a scroll jump" rule applied to the dashboards.
    function gotoStep(n, $form, scrollTop) {
        _step = n;
        var $root = ($form && $form.length) ? $form : $(document);
        var kbOpen = false; // a text field was focused on a touch device => on-screen keyboard is probably open
        // Release focus from the control that was just tapped (Next/Back)
        // BEFORE its step is hidden — see "ROOT CAUSE" note below.
        try {
            // Blur ANY focused form control (not only one inside the step):
            // on a phone the on-screen keyboard is usually still open when
            // Next is tapped, and its dismissal resizes the viewport AFTER
            // we scroll — see nshSettleWizard() below.
            var ae = document.activeElement;
            kbOpen = !!(ae && /^(INPUT|TEXTAREA)$/.test(ae.tagName) && !/^(checkbox|radio|button|submit|file|range|color)$/i.test(ae.type || '') && nshIsCoarsePointer());
            if (ae && ae !== document.body && typeof ae.blur === 'function' && (/^(INPUT|TEXTAREA|SELECT|BUTTON)$/.test(ae.tagName) || $(ae).closest('.nsh-wizard-step').length)) { ae.blur(); }
        } catch (e) { /* ignore */ }
        // Never let the page get SHORTER in the same instant the step swaps.
        // A tall step being replaced by a shorter one collapses the document;
        // browsers (scroll clamping/anchoring) and theme scripts (smooth-scroll
        // libraries, ScrollTrigger/AOS refreshes) then re-position the page to
        // wherever the old scroll offset now points — i.e. a section further
        // down the page. A temporary spacer keeps the document height stable
        // while we scroll the form into place; it is removed once settled.
        var formEl = $form && $form[0], oldH = formEl ? formEl.offsetHeight : 0;
        $root.find('.nsh-wizard-step').hide();
        $root.find('.nsh-wizard-step[data-step="' + n + '"]').show();
        nshHoldDocHeight(formEl, oldH);
        // Update step dots — look in parent container of the form
        var $dotsRoot = ($form && $form.length) ? $form.parent() : $(document);
        $dotsRoot.find('.nsh-step').each(function(){
            var s = parseInt($(this).data('step'));
            $(this).removeClass('nsh-step-active nsh-step-done');
            if (s === n) $(this).addClass('nsh-step-active');
            else if (s < n) $(this).addClass('nsh-step-done');
        });
        $dotsRoot.find('.nsh-step-line').each(function(i){ $(this).toggleClass('nsh-step-line-done', i < n-1); });
        $dotsRoot.find('.nsh-sl-step').each(function(){
            var s = parseInt($(this).data('step'));
            $(this).removeClass('nsh-sl-step-active nsh-sl-step-done');
            if (s === n) $(this).addClass('nsh-sl-step-active');
            else if (s < n) $(this).addClass('nsh-sl-step-done');
        });
        $dotsRoot.find('.nsh-sl-step-line').each(function(i){ $(this).toggleClass('nsh-sl-line-done', i < n-1); });
        // Standalone-form mode has no step-dots bar at all (see
        // nsh_render_service_wizard_html()'s $standalone branch) — instead
        // just a single "Step X of N" line above the fields. Keep it in
        // sync with the real current step on every Next/Back click, using
        // the total step count the server already stamped onto the
        // element via data-total-steps.
        $dotsRoot.find('.nsh-standalone-progress').each(function () {
            var $p = $(this);
            var total = parseInt($p.data('total-steps'), 10);
            if (!total) {
                total = ($form && $form.length) ? $form.find('.nsh-wizard-step').length : $p.closest('.nsh-sl-wizard-wrap').find('.nsh-wizard-step').length;
            }
            $p.text('Step ' + n + ' of ' + total);
        });
        // Keep the keyboard/screen-reader context honest without moving the
        // viewport: never focus() anything here (focusing an input pops the
        // mobile keyboard, which resizes the viewport and is a classic
        // source of "the page jumped"), just announce the new step.
        nshAnnounceStep($dotsRoot, n);
        if (scrollTop !== false) {
            var $wrap = ($dotsRoot && $dotsRoot.length) ? $dotsRoot : $form;
            nshEnsureWizardInView($wrap);
            nshSettleWizard($wrap);
            // Step 1 is where people are typing: the keyboard is still open at
            // the moment of the tap, and closing it moves/resizes the viewport
            // AFTER the scroll above (the classic "Next from the first step
            // jumps elsewhere"). Wait until the viewport has stopped changing,
            // then place the form again with the final geometry.
            if (kbOpen) {
                nshWhenViewportStable(function () {
                    nshEnsureWizardInView($wrap);
                    nshSettleWizard($wrap);
                });
            }
        }
    }

    // TRACE: gotoStep (keyboard was open) -> polls visualViewport height every 50 ms ->
    //        calls cb once the height has been unchanged for 180 ms, or after 800 ms at most
    //        -> cb is skipped if the user touched/scrolled/typed meanwhile or another step
    //        change superseded this one. preconditions: cb is a function;
    //        postcondition: cb runs at most once; edge: no visualViewport => uses innerHeight
    var nshStableTok = 0;
    function nshWhenViewportStable(cb) {
        var vv = window.visualViewport, tok = ++nshStableTok, start = Date.now(), last = -1, since = Date.now(), cancelled = false, fired = false;
        function cur() { return vv ? Math.round(vv.height) : window.innerHeight; }
        function cancel() { cancelled = true; off(); }
        function off() { ['touchstart', 'wheel', 'keydown', 'mousedown'].forEach(function (t) { window.removeEventListener(t, cancel, true); }); }
        ['touchstart', 'wheel', 'keydown', 'mousedown'].forEach(function (t) { window.addEventListener(t, cancel, { capture: true, passive: true }); });
        (function tick() {
            if (cancelled || fired || tok !== nshStableTok) { off(); return; }
            var h = cur();
            if (h !== last) { last = h; since = Date.now(); }
            if (Date.now() - since >= 180 || Date.now() - start >= 800) { fired = true; off(); cb(); return; }
            setTimeout(tick, 50);
        })();
    }

    // TRACE: gotoStep -> (formEl, heightBeforeSwap) -> if the form got shorter, inserts an
    //        empty aria-hidden spacer of the difference after the card/wrapper -> removes it
    //        after 1000 ms (or at once if another step change replaces it)
    //        preconditions: formEl attached; postcondition: document height is unchanged by the
    //        swap for ~1 s, then the spacer node is gone; edge: formEl missing / not shorter => no-op
    var nshHoldSpacer = null, nshHoldTimer = null;
    function nshHoldDocHeight(formEl, oldH) {
        if (nshHoldSpacer && nshHoldSpacer.parentNode) { nshHoldSpacer.parentNode.removeChild(nshHoldSpacer); }
        nshHoldSpacer = null; clearTimeout(nshHoldTimer);
        if (!formEl || !oldH) return;
        var diff = oldH - formEl.offsetHeight;
        if (diff < 2) return;
        var anchor = $(formEl).closest('.nsh-sl-outer, .nsh-wizard-page-card')[0] || formEl.parentNode;
        var sp = document.createElement('div');
        sp.className = 'nsh-hold-spacer';
        sp.setAttribute('aria-hidden', 'true');
        sp.style.cssText = 'height:' + diff + 'px;margin:0;padding:0;pointer-events:none;';
        anchor.parentNode.insertBefore(sp, anchor.nextSibling);
        nshHoldSpacer = sp;
        nshHoldTimer = setTimeout(function () {
            // Removing the spacer shrinks the document. With scroll anchoring ON the browser
            // answers by shifting the scroll position by the removed height (it pins a node
            // BELOW the spacer) => the page jumps by that amount. Switch anchoring off for
            // the removal and give it two frames before turning it back on.
            var root = document.documentElement, had = root.classList.contains('nsh-no-anchor');
            root.classList.add('nsh-no-anchor');
            if (sp.parentNode) { sp.parentNode.removeChild(sp); }
            if (nshHoldSpacer === sp) { nshHoldSpacer = null; }
            if (!had) {
                requestAnimationFrame(function () { requestAnimationFrame(function () {
                    if (!nshSettleState) { root.classList.remove('nsh-no-anchor'); }
                }); });
            }
        }, 1000);
    }

    /* ── Hold the landing position while the page settles ───────────────
       The first scroll is correct at the instant it runs, but on a real
       phone things move AFTER it: the on-screen keyboard finishes closing
       (visual viewport grows/shifts), the browser address bar collapses,
       Chrome's scroll anchoring re-pins to some node BELOW the form (e.g.
       the next page section) when the taller step is swapped for a shorter
       one, and lazy images/fonts below the form change the layout height.
       Any of those looks exactly like "Next scrolled me to another section".
       So: for ~900 ms after a step change, switch scroll anchoring off and
       put the form back at its landed position whenever it drifts — and
       stop immediately if the user touches/scrolls/types, so we never fight
       a deliberate scroll. */
    var nshSettleState = null;
    function nshSettleWizard($wrap) {
        var el = $wrap && $wrap[0];
        if (!el) return;
        if (nshSettleState) { nshSettleState.stop(); }
        var root = document.documentElement, landed = el.getBoundingClientRect().top - nshVisible().top, userMoved = false, timers = [], done = false;
        var vv = window.visualViewport;
        root.classList.add('nsh-no-anchor');
        function hold() {
            if (done || userMoved) return;
            var top = el.getBoundingClientRect().top - nshVisible().top;
            if (Math.abs(top - landed) > 2) { nshScrollDelta(el, top - landed); }
        }
        function onUser() { userMoved = true; stop(); }
        function stop() {
            if (done) return; done = true;
            timers.forEach(clearTimeout);
            ['touchstart', 'wheel', 'keydown', 'mousedown'].forEach(function (t) { window.removeEventListener(t, onUser, true); });
            window.removeEventListener('resize', hold);
            if (vv) { vv.removeEventListener('resize', hold); vv.removeEventListener('scroll', hold); }
            root.classList.remove('nsh-no-anchor');
            if (nshSettleState && nshSettleState.stop === stop) { nshSettleState = null; }
        }
        ['touchstart', 'wheel', 'keydown', 'mousedown'].forEach(function (t) { window.addEventListener(t, onUser, { capture: true, passive: true }); });
        window.addEventListener('resize', hold);
        if (vv) { vv.addEventListener('resize', hold); vv.addEventListener('scroll', hold); }
        document.addEventListener('scroll', hold, true);
        requestAnimationFrame(hold);
        [60, 150, 300, 500, 750].forEach(function (ms) { timers.push(setTimeout(hold, ms)); });
        timers.push(setTimeout(function () { document.removeEventListener('scroll', hold, true); stop(); }, 900));
        nshSettleState = { stop: function () { document.removeEventListener('scroll', hold, true); stop(); } };
    }

    /* ── Wizard scroll helpers ─────────────────────────────────────────
       ROOT CAUSE of the mobile "Next jumps to another place / form goes
       out of view" bug (all of these combined):
       1. gotoStep() scrolled to (wrapper top - 20px). On a phone, a sticky
          portal nav (.nsh-portal-nav, ~60-110px once its links wrap) or
          the theme's own sticky/fixed header sits over exactly that
          region, so the step dots and heading landed UNDER the header and
          the form looked like it had scrolled away.
       2. It always scrolled — even when the form was already in a good
          place — and animated BOTH html and body (two competing scroll
          animations; on mobile browsers whose body is the scroller that
          doubles the motion and fights the address-bar resize).
       3. The tapped Next button (still focused) was hidden with
          display:none; focus fell to <body>, which several mobile
          browsers answer by scrolling to the top/old position.
       4. Validation used a blocking alert(), which on iOS/Android also
          re-scrolls the page when dismissed, and never told the user
          WHICH field was wrong.
       Fix: measure the real stuck header, scroll only when the form is
       actually out of the comfortable zone, do it once and instantly, and
       release focus before hiding the step. ── */
    function nshReducedMotion() {
        try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; }
    }
    function nshIsCoarsePointer() {
        try { return window.matchMedia('(pointer: coarse)').matches; } catch (e) { return false; }
    }
    // Nearest ancestor that is really the page's scroller (a theme that
    // makes <body> or a wrapper div scroll instead of the window makes
    // window.scrollTo() a silent no-op), or null for the normal window.
    // TRACE: called with a form element -> walks up parents -> returns the first
    //        overflow-y:auto/scroll ancestor with overflowing content, else null
    //        (no preconditions; returns null for detached elements)
    function nshScroller(el) {
        try {
            for (var n = el && el.parentElement; n && n !== document.documentElement; n = n.parentElement) {
                var oy = window.getComputedStyle(n).overflowY;
                if ((oy === 'auto' || oy === 'scroll') && n.scrollHeight > n.clientHeight + 1) { return n; }
            }
        } catch (e) { /* best-effort */ }
        return null;
    }
    // TRACE: called with no args -> reads window.visualViewport -> true when the visible window is
    //        panned down inside the layout viewport (offsetTop > 1px); false without the API or at offset 0
    //        postcondition: no state changed; edge: visualViewport missing/throwing => false
    function nshVVPanned() {
        try { var v = window.visualViewport; return !!(v && v.offsetTop > 1); } catch (e) { return false; }
    }
    // TRACE: called with no args -> returns {top, h}: offsetTop and height of the VISIBLE window
    //        in layout-viewport coordinates (0 / innerHeight when the API is missing)
    //        postcondition: no state changed; h > 0 whenever the page is displayed
    function nshVisible() {
        var v = window.visualViewport;
        if (v) { return { top: v.offsetTop || 0, h: v.height || window.innerHeight }; }
        return { top: 0, h: window.innerHeight || document.documentElement.clientHeight };
    }
    // Moves the page by a RELATIVE amount d (px) so that el shifts up by d.
    // Relative moves work with any scroller and never depend on
    // window.pageYOffset being the real scroll position.
    // TRACE: called with (el, d) -> picks custom scroller / Lenis / window -> scrolls
    //        instantly by d -> el.getBoundingClientRect().top decreases by ~d
    //        (d is finite; |d|<1 is ignored; Lenis smooth-scroll lib is told to jump)
    function nshScrollDelta(el, d) {
        if (!isFinite(d) || Math.abs(d) < 1) return;
        d = Math.round(d);
        // A theme's `html { scroll-behavior: smooth }` turns EVERY programmatic scroll
        // (scrollBy, scrollTop=, scrollTo without options) into a ~0.5 s animation, and
        // older mobile browsers throw on { behavior: 'instant' } so that option cannot be
        // relied on. An animated scroll is not finished when we measure/correct it, so the
        // form ends up wherever the animation happens to be. Force `auto` (= instant) on
        // the scroller for exactly this one call, then put the theme's value back.
        var sc = nshScroller(el), target = sc || document.documentElement;
        var prevInline = target.style.getPropertyValue('scroll-behavior'), prevPrio = target.style.getPropertyPriority('scroll-behavior');
        var bodyEl = document.body, prevBody = bodyEl.style.getPropertyValue('scroll-behavior'), prevBodyPrio = bodyEl.style.getPropertyPriority('scroll-behavior');
        target.style.setProperty('scroll-behavior', 'auto', 'important');
        bodyEl.style.setProperty('scroll-behavior', 'auto', 'important');
        try {
            if (sc) { sc.scrollTop = sc.scrollTop + d; }
            else if (nshVVPanned() && el && typeof el.scrollIntoView === 'function') {
                // The visible window (visual viewport) is panned inside a larger layout
                // viewport (pinch-zoom, or a page wider than the phone that makes the browser
                // enlarge the layout viewport). window.scrollBy() then moves the LAYOUT
                // viewport on top of that pan => the user lands far away from the form (and a
                // negative scrollBy at scrollY=0 does nothing). scrollIntoView() is the one
                // call that moves the visible window itself, so use it with a scroll-margin
                // that puts the element exactly where the relative move asks for.
                var vvp = window.visualViewport;
                var want = (el.getBoundingClientRect().top - vvp.offsetTop) - d;
                var prevM = el.style.getPropertyValue('scroll-margin-top'), prevMP = el.style.getPropertyPriority('scroll-margin-top');
                el.style.setProperty('scroll-margin-top', want + 'px', 'important');
                try { el.scrollIntoView(); } finally {
                    if (prevM) { el.style.setProperty('scroll-margin-top', prevM, prevMP); } else { el.style.removeProperty('scroll-margin-top'); }
                }
            }
            else if (window.lenis && typeof window.lenis.scrollTo === 'function' && typeof window.lenis.scroll === 'number') {
                try { window.lenis.scrollTo(window.lenis.scroll + d, { immediate: true, force: true }); } catch (e) { window.scrollBy(0, d); }
            } else { window.scrollBy(0, d); }
        } finally {
            if (prevInline) { target.style.setProperty('scroll-behavior', prevInline, prevPrio); } else { target.style.removeProperty('scroll-behavior'); }
            if (prevBody) { bodyEl.style.setProperty('scroll-behavior', prevBody, prevBodyPrio); } else { bodyEl.style.removeProperty('scroll-behavior'); }
        }
    }
    // Bottom edge (px from viewport top) of whatever is currently stuck to
    // the top of the screen: WP admin bar, theme header, portal nav.
    // Only meaningful once the page is scrolled far enough for sticky
    // elements to actually be stuck — callers re-measure after scrolling.
    function nshStuckTopOffset() {
        var maxBottom = 0;
        try {
            var vis = nshVisible();
            var w = window.innerWidth, vx = (window.visualViewport && window.visualViewport.offsetLeft) || 0, vw = (window.visualViewport && window.visualViewport.width) || w;
            [Math.round(vx + vw / 2), vx + 12, Math.max(vx + 12, vx + vw - 12)].forEach(function (x) {
                var els = document.elementsFromPoint ? document.elementsFromPoint(x, vis.top + 3) : [];
                for (var i = 0; i < els.length; i++) {
                    var n = els[i];
                    while (n && n !== document.body && n !== document.documentElement) {
                        var pos = window.getComputedStyle(n).position;
                        if (pos === 'fixed' || pos === 'sticky') {
                            var r = n.getBoundingClientRect();
                            var rt = r.top - vis.top, rb = r.bottom - vis.top;
                            if (r.height > 0 && rt <= 3 && rb > maxBottom && rb < vis.h * 0.45) { maxBottom = rb; }
                            break;
                        }
                        n = n.parentElement;
                    }
                }
            });
        } catch (e) { /* measurement is best-effort */ }
        return Math.ceil(maxBottom);
    }
    // Brings $el's top into the comfortable zone (just below any stuck
    // header) ONLY if it isn't already there. Returns true if it scrolled.
    function nshEnsureWizardInView($el) {
        var el = $el && $el[0];
        if (!el) return false;
        var gap = 12;
        var top = el.getBoundingClientRect().top - nshVisible().top;
        var stuck = nshStuckTopOffset();
        var vh = nshVisible().h;
        // Comfortable zone: top edge just below the header, no lower than
        // ~22% of the screen. Anywhere else, land at exactly header+gap so
        // every step change ends in the same, predictable place.
        if (top >= stuck + 2 && top <= stuck + gap + vh * 0.22) return false;
        nshScrollDelta(el, top - stuck - gap);
        // The sticky header only reports itself once we are scrolled past
        // its natural position, so verify after the move and correct once.
        var top2 = el.getBoundingClientRect().top - nshVisible().top;
        var stuck2 = nshStuckTopOffset();
        var want = stuck2 + gap;
        if (Math.abs(top2 - want) > 3) { nshScrollDelta(el, top2 - want); }
        return true;
    }
    // Brings a (possibly invalid) field fully into view only if needed.
    function nshRevealField($el) {
        var el = $el && $el[0];
        if (!el) return;
        var r = el.getBoundingClientRect(), vis = nshVisible();
        var rtop = r.top - vis.top, rbot = r.bottom - vis.top;
        var stuck = nshStuckTopOffset();
        if (rtop >= stuck + 8 && rbot <= vis.h - 8) return;
        nshScrollDelta(el, rtop - stuck - 80);
        var r2 = el.getBoundingClientRect();
        var stuck2 = nshStuckTopOffset();
        if (r2.top - nshVisible().top < stuck2 + 8) { nshScrollDelta(el, (r2.top - nshVisible().top) - stuck2 - 80); }
    }
    function nshAnnounceStep($root, n) {
        var $steps = $root.find('.nsh-wizard-step');
        var idx = 0, total = $steps.length;
        $steps.each(function (i) { if (parseInt($(this).attr('data-step'), 10) === n) idx = i + 1; });
        if (!total || !idx) return;
        var $live = $root.find('.nsh-step-live').first();
        if (!$live.length) {
            $live = $('<div class="nsh-step-live nsh-sr-only" role="status" aria-live="polite"></div>');
            $root.prepend($live);
        }
        var label = $.trim($root.find('.nsh-wizard-step[data-step="' + n + '"]').find('.nsh-sl-step-heading, .nsh-step-title').first().text());
        $live.text('Step ' + idx + ' of ' + total + (label ? ': ' + label : ''));
    }
    // Inline, non-blocking validation message placed right above the
    // Back/Next buttons — i.e. next to the finger that just tapped Next —
    // so reporting an error never needs to move the page.
    function nshStepNotice($step, msg) {
        var $n = $step.find('.nsh-step-notice').first();
        if (!$n.length) {
            $n = $('<div class="nsh-step-notice" role="alert"></div>');
            var $nav = $step.find('.nsh-step-nav').first();
            if ($nav.length) { $nav.before($n); } else { $step.append($n); }
        }
        $n.text(msg).show();
    }
    function nshClearStepNotice($step) { $step.find('.nsh-step-notice').hide().empty(); }

    // As soon as a flagged field is corrected, un-flag it, and drop the
    // step-level message once nothing in the step is flagged any more.
    $(document).on('input change', '.nsh-wizard-step .nsh-field-invalid, .nsh-wizard-step .nsh-field-invalid-outline input, .nsh-wizard-step .nsh-field-invalid-outline select', function () {
        var $t = $(this);
        if ($.trim($t.val() || '') !== '' || $t.is(':checked')) { $t.removeClass('nsh-field-invalid'); }
        $t.closest('.nsh-field-invalid-outline').removeClass('nsh-field-invalid-outline');
        var $step = $t.closest('.nsh-wizard-step');
        if (!$step.find('.nsh-field-invalid, .nsh-field-invalid-outline').length) { nshClearStepNotice($step); }
    });

    // Steps are keyed by their DB step_number, which is NOT always
    // consecutive: content steps are usually 1,2,3... but the two fixed
    // steps ported from Services2NRI — 98 = "Contact Details" and
    // 99 = "Documents" — always come last regardless of how many content
    // steps precede them (see nsh_get_service_steps() in schema.php). So a
    // service with content steps 1,2,3 has step numbers 1,2,3,98,99 — doing
    // "current step + 1" after step 3 looks for a step numbered 4, which
    // doesn't exist, gotoStep() shows nothing, and the wizard looks stuck
    // (this is what showed up as "step 4 and 5 not showing" for any service
    // using the Contact Details/Documents steps). Walk the actual rendered
    // .nsh-wizard-step elements in DOM order (PHP always emits them in
    // ascending step_number order) instead of doing arithmetic on the
    // step_number itself, so navigation follows what's really on the page.
    function siblingStepNumber($form, currentStep, dir) {
        var $root = ($form && $form.length) ? $form : $(document);
        var $steps = $root.find('.nsh-wizard-step');
        var idx = -1;
        $steps.each(function (i) { if (parseInt($(this).data('step')) === currentStep) idx = i; });
        if (idx === -1) return currentStep + dir; // shouldn't happen, safe fallback
        var targetIdx = idx + dir;
        if (targetIdx < 0 || targetIdx >= $steps.length) return currentStep; // already at an edge
        return parseInt($steps.eq(targetIdx).data('step'));
    }

    // ── NEXT button: validate only the current visible step's fields ──────────
    $(document).on('click', '.nsh-wizard-next', function () {
        var $btn  = $(this);
        var step  = parseInt($btn.data('step'));
        var $form = $btn.closest('form');
        var $step = $form.length
            ? $form.find('.nsh-wizard-step[data-step="' + step + '"]')
            : $('.nsh-wizard-step[data-step="' + step + '"]').first();

        var ok = true;
        var DEBUG = false; // Set to true to see console logs

        // Helper: is a field marked required?
        function isReq($f) {
            var $fw = $f.closest('.nsh-field');
            // Normal (labeled) fields mark required via a visible .nsh-req
            // star inside the label. Placeholder-only standalone-form
            // fields have no <label> at all, so nsh_render_form_field()
            // instead stamps data-required="1" directly on the .nsh-field
            // wrapper — check both so required-field validation still
            // works regardless of which rendering mode produced the field.
            var hasStar = $fw.find('.nsh-req').length > 0;
            var hasAttr = $fw.attr('data-required') === '1';
            if (DEBUG) console.log('isReq check:', {field: $f.attr('name'), wrapper: $fw[0], hasStar: hasStar, hasAttr: hasAttr});
            return hasStar || hasAttr;
        }
        // Helper: is a field inside a hidden conditional wrapper?
        function isCondHidden($f) {
            var $c = $f.closest('.nsh-cond-field');
            return $c.length && $c.is(':hidden');
        }

        // 1) Text, email, number, tel, select, textarea
        // (checkbox is deliberately excluded here — a checkbox's .val() is
        // its "value" attribute, which is truthy whether or not it's
        // actually checked, so this loop could never detect an empty
        // required multi-select. See the dedicated checkbox-group
        // validator below instead.)
        $step.find('input, select, textarea').each(function(){
            var $f   = $(this);
            var type = ($f.attr('type') || 'text').toLowerCase();
            if (type === 'hidden' || type === 'radio' || type === 'checkbox' || type === 'file') return;
            var req = isReq($f);
            var condHide = isCondHidden($f);
            if (!req) return;
            if (condHide) return;
            var val = $.trim($f.val());
            if (DEBUG) console.log('Validating field:', {name: $f.attr('name'), type: type, required: req, hidden: condHide, value: val});
            if (val === '') {
                $f.addClass('nsh-field-invalid');
                ok = false;
                if (DEBUG) console.log('Field FAILED validation:', $f.attr('name'));
            } else {
                $f.removeClass('nsh-field-invalid');
            }
        });

        // 2) Searchable fields — validate the visible text input
        $step.find('.nsh-search-field').each(function(){
            var $sf = $(this);
            if (isCondHidden($sf)) return;
            if (!isReq($sf)) return;
            var visVal = $.trim($sf.find('.nsh-sf-input').val());
            if (visVal === '') {
                $sf.find('.nsh-sf-input').addClass('nsh-field-invalid');
                ok = false;
            } else {
                $sf.find('.nsh-sf-input').removeClass('nsh-field-invalid');
            }
        });

        // 3) Radio groups
        var seenGroups = {};
        $step.find('input[type=radio]').each(function(){
            var name = $(this).attr('name');
            if (seenGroups[name] !== undefined) return;
            var $group = $step.find('input[type=radio][name="' + name + '"]');
            if (isCondHidden($group.first())) { seenGroups[name] = true; return; }
            if (!isReq($group.first())) { seenGroups[name] = true; return; }
            var checked = $group.filter(':checked').length > 0;
            seenGroups[name] = checked;
            if (!checked) {
                $group.first().closest('.nsh-radio-group, .nsh-toggle-group').addClass('nsh-field-invalid-outline');
                ok = false;
            } else {
                $group.first().closest('.nsh-radio-group, .nsh-toggle-group').removeClass('nsh-field-invalid-outline');
            }
        });

        // 4) Multi-select (checkbox) fields — "required" means at least one
        // option checked. Grouped by the shared .nsh-multiselect wrapper
        // rather than by input name, since every checkbox in the group
        // shares one name[] but only one wrapper needs the invalid outline.
        $step.find('.nsh-multiselect').each(function () {
            var $ms = $(this);
            if (isCondHidden($ms)) { $ms.removeClass('nsh-field-invalid-outline'); return; }
            if (!isReq($ms)) { $ms.removeClass('nsh-field-invalid-outline'); return; }
            var checked = $ms.find('.nsh-ms-panel input:checked').length > 0;
            if (!checked) {
                $ms.addClass('nsh-field-invalid-outline');
                ok = false;
            } else {
                $ms.removeClass('nsh-field-invalid-outline');
            }
        });

        if (!ok) {
            // Non-blocking, in-place message + reveal of the FIRST problem
            // field only if it isn't already on screen. No alert(), no
            // focus() on touch devices (keyboard resize = page jump).
            var nInvalid = $step.find('.nsh-field-invalid:visible, .nsh-field-invalid-outline:visible').length;
            nshStepNotice($step, nInvalid > 1
                ? 'Please complete the ' + nInvalid + ' highlighted required fields to continue.'
                : 'Please complete the highlighted required field to continue.');
            var $firstBad = $step.find('.nsh-field-invalid:visible, .nsh-field-invalid-outline:visible').first();
            var $firstWrap = $firstBad.closest('.nsh-field');
            nshRevealField($firstWrap.length ? $firstWrap : $firstBad);
            if (!nshIsCoarsePointer() && $firstBad.length && typeof $firstBad[0].focus === 'function' && $firstBad.is('input,select,textarea')) {
                try { $firstBad[0].focus({ preventScroll: true }); } catch (e) { /* ignore */ }
            }
            return;
        }
        nshClearStepNotice($step);
        gotoStep(siblingStepNumber($form, step, 1), $form);
    });

    $(document).on('click', '.nsh-wizard-prev', function () {
        var $f = $(this).closest('form');
        var step = parseInt($(this).data('step'));
        gotoStep(siblingStepNumber($f, step, -1), $f);
    });

    /* ── BACKGROUND DOCUMENT UPLOAD ────────────────────────────────────
       ROOT CAUSE FIX: documents used to travel as raw file bytes inside
       the same request that creates the application (nsh_create_request),
       so the final Submit couldn't finish until every document had fully
       uploaded — on a slow connection with a few MB of scanned documents,
       that easily outran a shared host's reverse-proxy/gateway timeout
       even though the server went on to finish the job, which is exactly
       why the form could show a "connection error" for a submission that
       had actually succeeded. A document now starts uploading the INSTANT
       it's selected, as its own small independent request
       (nsh_ajax_upload_pending_document(), ajax.php), completely
       decoupled from Submit — see nshEnsureUploadToken()/nshStartFileUpload()
       below and the matching server-side docblock. ── */
    var nshUploadsByInst = {};    // instance -> { fieldKey -> [{uid,file,status,progress,attachmentId,attached,errorMsg}] }
    function nshUp(inst) { inst = inst || ''; return nshUploadsByInst[inst] || (nshUploadsByInst[inst] = {}); }
    var nshUploadsInFlight = 0;   // count of uploads currently transferring — see the beforeunload guard below
    window.nshCreatedRequestId = null; // set once nsh_create_request succeeds — see nshShowSubmitSuccess()

    function nshGenToken() {
        if (window.crypto && window.crypto.getRandomValues) {
            var arr = new Uint8Array(16);
            window.crypto.getRandomValues(arr);
            return Array.prototype.map.call(arr, function (b) { return ('0' + b.toString(16)).slice(-2); }).join('');
        }
        return 'nsh' + Date.now().toString(36) + Math.random().toString(36).slice(2);
    }

    // One random token per form instance, shared by every document upload
    // on it — how nsh_ajax_create_request() later finds/claims whichever
    // of those uploads already finished, and how a still-in-flight one
    // finds its way back to the right request once it finishes (see
    // nsh_ajax_attach_pending_document()).
    function nshEnsureUploadToken($form) {
        var $tok = $form.find('input[name="nsh_upload_token"]');
        if (!$tok.length) return '';
        if (!$tok.val()) { $tok.val(nshGenToken()); }
        return $tok.val();
    }

    // A page navigation aborts any upload still in flight — an inherent
    // browser limitation, not something this code can work around — so
    // warn before that happens rather than silently losing a document.
    window.addEventListener('beforeunload', function (e) {
        if (nshUploadsInFlight > 0) { e.preventDefault(); e.returnValue = ''; }
    });

    function nshRenderFilePreview(fieldKey, inst) {
        inst = inst || '';
        var $scope = inst ? $('[data-nsh-inst="' + inst + '"]') : $(document);
        var $list = $scope.find('.nsh-file-preview[data-preview-for="' + fieldKey + '"]').empty();
        var items = nshUp(inst)[fieldKey] || [];
        items.forEach(function (item) {
            var $row = $('<div class="nsh-fp-item"></div>').attr('data-uid', item.uid).attr('data-field-key', fieldKey);
            var sizeTxt = Math.round(item.file.size / 1024) + 'KB';
            var statusHtml;
            if (item.status === 'uploading') {
                statusHtml = '<span style="color:#2563eb;font-size:11px;">Uploading&hellip; ' + (item.progress || 0) + '%</span>';
            } else if (item.status === 'done') {
                statusHtml = '<span style="color:#16a34a;font-size:11px;">&#10003; Uploaded</span>';
            } else if (item.status === 'error') {
                statusHtml = '<span style="color:#ef4444;font-size:11px;">' + esc(item.errorMsg || 'Upload failed') + '</span> ' +
                    '<button type="button" class="nsh-link nsh-fp-retry" style="font-size:11px;">Retry</button>';
            } else {
                statusHtml = '<span style="color:#94a3b8;font-size:11px;">Preparing&hellip;</span>';
            }
            $row.append('<span>📎 ' + esc(item.file.name) + '</span>');
            $row.append('<span style="color:#94a3b8;font-size:11px;margin:0 6px;">' + sizeTxt + '</span>');
            $row.append(statusHtml);
            $row.append('<button type="button" class="nsh-link nsh-fp-remove" style="font-size:11px;margin-left:6px;">Remove</button>');
            $list.append($row);
        });
    }

    function nshStartFileUpload(fieldKey, fieldLabel, item, $form) {
        var token = nshEnsureUploadToken($form);
        var inst = nshInstOf($form);
        item.status = 'uploading';
        item.progress = 0;
        nshRenderFilePreview(fieldKey, inst);
        nshUploadsInFlight++;

        nshCompressImage(item.file, 1920, 0.75).then(function (processed) {
            var fd = new FormData();
            fd.append('action', 'nsh_upload_pending_document');
            fd.append('nonce', NSH.nonce);
            fd.append('token', token);
            fd.append('field_key', fieldKey);
            fd.append('field_label', fieldLabel);
            fd.append('file', processed, item.file.name);

            $.ajax({
                url: NSH.ajax_url, type: 'POST', data: fd, processData: false, contentType: false,
                xhr: function () {
                    var x = $.ajaxSettings.xhr();
                    if (x.upload) {
                        x.upload.addEventListener('progress', function (e) {
                            if (e.lengthComputable) {
                                item.progress = Math.round((e.loaded / e.total) * 100);
                                nshRenderFilePreview(fieldKey, inst);
                            }
                        });
                    }
                    return x;
                },
                success: function (r) {
                    nshUploadsInFlight = Math.max(0, nshUploadsInFlight - 1);
                    if (r && r.success) {
                        item.status = 'done';
                        item.attachmentId = r.data.attachment_id;
                        nshRenderFilePreview(fieldKey, inst);
                        // The request may already exist by the time this
                        // particular upload finishes (the whole point of
                        // decoupling the two) — if so, attach it right now
                        // instead of waiting for anything else to notice.
                        if (window.nshCreatedRequestId) { nshAttachPendingUpload(item); }
                        nshUpdatePendingUploadUi();
                    } else {
                        item.status = 'error';
                        item.errorMsg = (r && r.data && r.data.message) ? r.data.message : 'Upload failed.';
                        nshRenderFilePreview(fieldKey, inst);
                        nshUpdatePendingUploadUi();
                    }
                },
                error: function () {
                    nshUploadsInFlight = Math.max(0, nshUploadsInFlight - 1);
                    item.status = 'error';
                    item.errorMsg = 'Connection error while uploading.';
                    nshRenderFilePreview(fieldKey, inst);
                    nshUpdatePendingUploadUi();
                }
            });
        }).catch(function () {
            nshUploadsInFlight = Math.max(0, nshUploadsInFlight - 1);
            item.status = 'error';
            item.errorMsg = 'Could not prepare this file.';
            nshRenderFilePreview(fieldKey, inst);
            nshUpdatePendingUploadUi();
        });
    }

    function nshAttachPendingUpload(item) {
        if (item.attached) return;
        item.attached = true;
        $.post(NSH.ajax_url, {
            action: 'nsh_attach_pending_document',
            nonce: NSH.nonce,
            request_id: window.nshCreatedRequestId,
            attachment_id: item.attachmentId
        }, function (r) {
            if (!r || !r.success) { item.attached = false; }
            nshUpdatePendingUploadUi();
        }).fail(function () { item.attached = false; nshUpdatePendingUploadUi(); });
    }

    function nshCountUnfinishedUploads() {
        var total = 0, done = 0;
        var all = nshUp(window.nshSubmitInst || '');
        Object.keys(all).forEach(function (k) {
            all[k].forEach(function (item) {
                if (item.status === 'error') return; // counted separately below
                total++;
                if (item.status === 'done' && item.attached) done++;
            });
        });
        return { total: total, done: done };
    }

    function nshFailedUploads() {
        var out = [];
        var all = nshUp(window.nshSubmitInst || '');
        Object.keys(all).forEach(function (k) {
            all[k].forEach(function (item) { if (item.status === 'error') out.push(item); });
        });
        return out;
    }

    // Keeps the post-submit success panel's "still uploading" line in sync
    // as background uploads finish — called after Submit succeeds and
    // again every time an individual upload (or its attach call) resolves.
    function nshUpdatePendingUploadUi() {
        var $pending = $('#nsh-success-pending');
        if (!$pending.length) return;
        var counts = nshCountUnfinishedUploads();
        var remaining = counts.total - counts.done;
        var failed = nshFailedUploads();
        var parts = [];
        if (remaining > 0) {
            parts.push('Finishing upload of ' + remaining + ' document' + (remaining === 1 ? '' : 's') + ' in the background — you can leave this open or wait here.');
        }
        if (failed.length) {
            parts.push(failed.length + ' document' + (failed.length === 1 ? '' : 's') + ' could not be uploaded (' +
                failed.map(function (f) { return esc(f.file.name); }).join(', ') +
                ') — please add ' + (failed.length === 1 ? 'it' : 'them') + ' from your Dashboard.');
        }
        // Always clear the old HTML when there's nothing left to report —
        // .hide() alone only sets display:none and leaves the previous
        // sentence sitting in the DOM. That stale text is masked as long as
        // display:none is respected, but it's exactly the kind of "ghost
        // row" the app must never leave behind (a screen reader, a print
        // view, or any later code path that shows this element without
        // going through this function would surface the wrong message) —
        // so an empty state means the element is both hidden AND empty.
        if (parts.length) { $pending.show().html(parts.join(' ')); } else { $pending.hide().empty(); }
    }

    // File preview in form — delegated by class so every per-field dropzone
    // (a service can have several: ID proof, parent's ID, hospital record...)
    // gets its own live preview list instead of all sharing one hardcoded id.
    // Selecting files replaces the input's entire FileList (native browser
    // behavior), so this reconciles the registry against what's now
    // selected: anything no longer present is cancelled/removed, anything
    // new starts uploading immediately.
    $(document).on('change', '.nsh-file-input', function () {
        var $dz = $(this).closest('.nsh-dropzone');
        var key = $dz.data('field-key');
        var label = $dz.data('field-label') || 'Document';
        var $form = $(this).closest('form');
        var inst = nshInstOf($form);
        var files = Array.prototype.slice.call(this.files);
        var existing = nshUp(inst)[key] || [];

        var oversized = [];
        files = files.filter(function (f) {
            if (f.size > MAX_FILE_BYTES) { oversized.push(f.name); return false; }
            return true;
        });
        if (oversized.length) {
            var $err = $form.find('.nsh-form-err').first();
            $err.text('These files exceed the 10MB limit and were not selected: ' + oversized.join(', ') + '.').show();
        }

        var next = files.map(function (f) {
            var found = existing.filter(function (it) { return it.file.name === f.name && it.file.size === f.size && it.file.lastModified === f.lastModified; })[0];
            return found || { uid: nshGenToken(), file: f, status: 'new' };
        });

        // Anything that WAS tracked but is no longer in the current
        // selection was removed by re-choosing files — cancel/clean it up.
        existing.forEach(function (it) {
            var stillThere = next.indexOf(it) !== -1;
            if (!stillThere) { nshDiscardUpload(key, it, $form); }
        });

        nshUp(inst)[key] = next;
        nshRenderFilePreview(key, inst);
        next.forEach(function (it) {
            if (it.status === 'new') { nshStartFileUpload(key, label, it, $form); }
        });
    });

    function nshDiscardUpload(fieldKey, item, $form) {
        if (item.status === 'done' && item.attachmentId && !item.attached) {
            var token = $form.find('input[name="nsh_upload_token"]').val();
            $.post(NSH.ajax_url, { action: 'nsh_delete_pending_document', nonce: NSH.nonce, attachment_id: item.attachmentId, token: token });
        }
        // An in-flight XHR for a removed file is simply left to finish in
        // the background and clean itself up (best-effort delete above
        // handles the common case); there is no reference to it here to
        // abort, and letting it finish is harmless since it was never
        // attached to anything.
    }

    $(document).on('click', '.nsh-fp-remove', function () {
        var $row = $(this).closest('.nsh-fp-item');
        var key = $row.data('field-key'), uid = $row.data('uid');
        var $form = $row.closest('form');
        var inst = nshInstOf($form);
        var items = nshUp(inst)[key] || [];
        var item = items.filter(function (it) { return it.uid === uid; })[0];
        if (item) { nshDiscardUpload(key, item, $form); }
        nshUp(inst)[key] = items.filter(function (it) { return it.uid !== uid; });
        // Also clear it from the actual <input type=file> so the required-
        // file check and the eventual pending_manifest agree with what's
        // shown — FileList can't be edited in place, so it's rebuilt via
        // DataTransfer from whatever's left in the registry.
        var $input = $form.find('.nsh-dropzone[data-field-key="' + key + '"] .nsh-file-input')[0];
        if ($input && window.DataTransfer) {
            var dt = new DataTransfer();
            (nshUp(inst)[key] || []).forEach(function (it) { dt.items.add(it.file); });
            $input.files = dt.files;
        }
        nshRenderFilePreview(key, inst);
    });

    $(document).on('click', '.nsh-fp-retry', function () {
        var $row = $(this).closest('.nsh-fp-item');
        var key = $row.data('field-key'), uid = $row.data('uid');
        var $form = $row.closest('form');
        var inst = nshInstOf($form);
        var label = $form.find('.nsh-dropzone[data-field-key="' + key + '"]').data('field-label') || 'Document';
        var items = nshUp(inst)[key] || [];
        var item = items.filter(function (it) { return it.uid === uid; })[0];
        if (item) { nshStartFileUpload(key, label, item, $form); }
    });

    $(document).on('click', '.nsh-file-browse', function () {
        var targetId = $(this).data('target');
        var el = document.getElementById(targetId);
        if (el) el.click();
    });

    // Real drag-and-drop for every per-field wizard dropzone (.nsh-dz-row).
    // The control's own text says "or drag & drop here", but until now
    // dragging a file onto it did nothing — only the Choose File button's
    // native click-to-browse worked. Delegated the same way as the file
    // preview above so it covers every file field a service has, without
    // depending on a hardcoded id. Assigning to the real <input type=file>
    // via DataTransfer (rather than reimplementing upload logic here) means
    // the existing 'change' handler above — and everything downstream of
    // it (required-field validation, the compressed-upload submit path) —
    // picks the dropped file up exactly as if the visitor had browsed to it.
    $(document).on('dragover', '.nsh-dropzone.nsh-dz-row', function (e) {
        e.preventDefault();
        $(this).addClass('dragover');
    });
    $(document).on('dragleave', '.nsh-dropzone.nsh-dz-row', function () {
        $(this).removeClass('dragover');
    });
    $(document).on('drop', '.nsh-dropzone.nsh-dz-row', function (e) {
        e.preventDefault();
        $(this).removeClass('dragover');
        var dt = e.originalEvent && e.originalEvent.dataTransfer;
        if (!dt || !dt.files || !dt.files.length) return;
        var fileInput = $(this).find('.nsh-file-input')[0];
        if (!fileInput) return;
        // Multiple-file inputs accept a DataTransfer's FileList directly —
        // this also correctly fires the input's native 'change' event.
        fileInput.files = dt.files;
        $(fileInput).trigger('change');
    });

    // Searchable dropdown in form
    var _sfTimers = {};
    $(document).on('input', '.nsh-sf-input', function () {
        var $inp=$(this), key=$inp.data('field'), $wrap=$inp.closest('.nsh-search-field'), $dd=$wrap.find('.nsh-sf-dropdown'), $val=$wrap.find('.nsh-sf-val'), q=$inp.val().trim();
        $val.val('');
        if (q.length<1){$dd.hide().empty();return;}
        clearTimeout(_sfTimers[key]);
        _sfTimers[key]=setTimeout(function(){
            $.post(NSH.ajax_url,{action:'nsh_search_dropdown',field_key:key,search:q},function(r){
                if(!r.success||!r.data.length){$dd.html('<div class="nsh-sf-item nsh-sf-empty">No results</div>').show();return;}
                var h=''; $.each(r.data,function(i,v){h+='<div class="nsh-sf-item" data-v="'+esc(v)+'">'+esc(v)+'</div>';});
                $dd.html(h).show();
            });
        },280);
    });
    $(document).on('click', '.nsh-sf-item:not(.nsh-sf-empty)', function () {
        var $wrap=$(this).closest('.nsh-search-field');
        $wrap.find('.nsh-sf-input').val($(this).data('v'));
        $wrap.find('.nsh-sf-val').val($(this).data('v'));
        $wrap.find('.nsh-sf-dropdown').hide().empty();
    });
    $(document).on('click', function(e){if(!$(e.target).closest('.nsh-search-field').length)$('.nsh-sf-dropdown').hide().empty();});

    /* ═══════════════════════════════════════════════════════════
       CONDITIONAL LOGIC ENGINE — Fluent Forms style
       Evaluates .nsh-cond-field data-nsh-cond attributes in real time
    ═══════════════════════════════════════════════════════════ */
    function nshGetFieldValue(fieldKey, $form) {
        if (!$form || !$form.length) return '';
        var name = 'field_' + fieldKey;
        // Radio
        var $radio = $form.find('input[type=radio][name="'+name+'"]:checked');
        if ($radio.length) return $radio.val();
        // Hidden (searchable)
        var $hidden = $form.find('input[type=hidden][name="'+name+'"]');
        if ($hidden.length) return $hidden.val() || '';
        // Select / Input / Textarea
        var $el = $form.find('[name="'+name+'"]').not('[type=radio]').not('[type=hidden]');
        if ($el.length) return $el.val() || '';
        return '';
    }

    function nshEvalCondition(rule, $form) {
        var val = String(nshGetFieldValue(rule.field, $form) || '').toLowerCase().trim();
        var rv  = String(rule.value || '').toLowerCase().trim();
        switch (rule.operator) {
            case 'equals':         return val === rv;
            case 'not_equals':     return val !== rv;
            case 'contains':       return val.indexOf(rv) !== -1;
            case 'not_contains':   return val.indexOf(rv) === -1;
            case 'starts_with':    return val.indexOf(rv) === 0;
            case 'ends_with':      return val.slice(-rv.length) === rv;
            case 'is_empty':       return val === '';
            case 'is_not_empty':   return val !== '';
            case 'greater_than':   return parseFloat(val) > parseFloat(rv);
            case 'less_than':      return parseFloat(val) < parseFloat(rv);
        }
        return false;
    }

    function nshEvalConditions(condData, $form) {
        if (!condData || !condData.rules || !condData.rules.length) return true;
        var action = condData.action || 'all';
        if (action === 'any') {
            for (var i=0; i<condData.rules.length; i++) {
                if (nshEvalCondition(condData.rules[i], $form)) return true;
            }
            return false;
        } else {
            for (var j=0; j<condData.rules.length; j++) {
                if (!nshEvalCondition(condData.rules[j], $form)) return false;
            }
            return true;
        }
    }

    function nshRunConditionalLogic() {
        $('.nsh-cond-field[data-nsh-cond]').each(function() {
            var $el = $(this);
            var condJson = $el.attr('data-nsh-cond');
            if (!condJson) return;
            var condData;
            try { condData = JSON.parse(condJson); } catch(e) { return; }
            var show = nshEvalConditions(condData, $el.closest('.nsh-request-form'));
            if (show) {
                $el.slideDown(150);
                // Re-enable required on hidden inputs
                $el.find('input,select,textarea').each(function(){
                    if ($(this).data('nsh-was-required')) $(this).prop('required', true);
                });
            } else {
                $el.slideUp(150);
                // Disable required so form can still submit
                $el.find('input[required],select[required],textarea[required]').each(function(){
                    $(this).data('nsh-was-required', true).prop('required', false);
                });
            }
        });
    }

    // Run on any form input change
    $(document).on('change input', '.nsh-request-form input, .nsh-request-form select, .nsh-request-form textarea', function() {
        nshRunConditionalLogic();
    });
    // Run on searchable field value change
    $(document).on('click', '.nsh-sf-item:not(.nsh-sf-empty)', function() {
        setTimeout(nshRunConditionalLogic, 50);
    });
    // Initial run
    $(document).ready(function() {
        $('.nsh-request-form').each(function () {
            nshRestoreDraft($(this));
            nshEnsureUploadToken($(this));
        });
        if ($('.nsh-request-form').length) { nshRunConditionalLogic(); }
    });

    // Keep the draft up to date as the client fills the form in, so a
    // dropped connection at submit time (or an accidental tab close)
    // doesn't cost them everything they've typed so far.
    $(document).on('change input', '.nsh-request-form', function () {
        nshSaveDraft($(this));
    });

    /* ═══════════════════════════════════════════════════════════
       SERVICES FIELD — one implementation shared by [nsh_standalone_form]
       and the Client Dashboard's "New Request" ([nsh_request_form]) page
       (both rendered by nsh_render_service_field_html() in shortcodes.php).
       Picking a service from #nsh-sl-service-select — a plain <select>
       styled exactly like every other field, not a separate widget —
       swaps #nsh-sl-wizard-container to that service's own wizard.

       A field doesn't show "Loading…" and visibly fetch-then-jump when you
       change it — a real <select>'s effect on the page is instant. So the
       per-click AJAX round trip (nsh_ajax_load_service_wizard) that used to
       run on every change, with a "Loading form…" placeholder blanking the
       container in between, is now only a fallback for the rare case where
       a pick happens before prefetch finishes. Normally: every active
       service's wizard HTML is fetched ONCE in the background right after
       the page loads (nshPrefetchAllWizards, below) and cached in
       nshWizardCache; picking a service then swaps in the cached HTML
       synchronously, with no network request in flight and no placeholder
       text — exactly like changing any other field.
       #nsh-sl-card-title only exists on the standalone card;
       #nsh-form-hero-title/-sub only exist on the dashboard page — jQuery
       no-ops on whichever id isn't present, so one handler/apply function
       updates whichever surface it's running on.
    ═══════════════════════════════════════════════════════════ */
    var nshWizardCache = null; // { services: {id: {html,title,slug}}, picker: {html,title,slug} } once prefetched

    /* ─────────────────────────────────────────────────────────
       INITIAL CLIENT INFO CARRY-FORWARD — Step 1's First Name /
       Last Name / Email / Mobile / "what do you need" fields only exist
       while no service is chosen yet (nsh_render_initial_client_fields_html()
       in shortcodes.php). The moment a service IS picked,
       #nsh-sl-wizard-container's whole content is replaced by that
       service's own wizard, so those fields are gone from the DOM — but
       whatever the client already typed must not be. This little bit of
       state keeps it alive across the swap: captured right before every
       swap (service picked OR reverted back to "no service"), then
       written back into whichever matching fields exist in the freshly
       swapped-in HTML — Email/Mobile land in that service's own Contact
       Details step (field___email/field___phone — literally the same
       field, not a re-ask), First Name/Last Name/the requirement text
       land in the hidden carry-forward inputs shortcodes.php adds to
       Step 1 once a service is selected.
    ───────────────────────────────────────────────────────── */
    var nshInitialInfoByInst = {};
    function nshInfoFor(inst) { inst = inst || ''; return nshInitialInfoByInst[inst] || (nshInitialInfoByInst[inst] = { first_name: '', last_name: '', email: '', phone_code: '', phone: '', requirement: '' }); }

    function nshCaptureInitialClientInfo($scope) {
        var $s = $scope && $scope.length ? $scope : $('.nsh-sl-wizard-container').first();
        var nshInitialClientInfo = nshInfoFor(nshInstOf($s));
        var fn = $s.find('[name="field_first_name"]').first().val();
        var ln = $s.find('[name="field_last_name"]').first().val();
        var em = $s.find('[name="field___email"]').first().val();
        var pc = $s.find('[name="field_phone_code"]').first().val();
        var ph = $s.find('[name="field___phone"]').first().val();
        var rq = $s.find('[name="field_requirement"]').first().val();
        if (fn) { nshInitialClientInfo.first_name = fn; }
        if (ln) { nshInitialClientInfo.last_name = ln; }
        if (em) { nshInitialClientInfo.email = em; }
        if (pc) { nshInitialClientInfo.phone_code = pc; }
        if (ph) { nshInitialClientInfo.phone = ph; }
        if (rq) { nshInitialClientInfo.requirement = rq; }
    }

    function nshApplyInitialClientInfo($container) {
        var d = nshInfoFor(nshInstOf($container));
        if (d.first_name) { $container.find('[name="field_first_name"]').val(d.first_name); }
        if (d.last_name)  { $container.find('[name="field_last_name"]').val(d.last_name); }
        if (d.requirement) { $container.find('[name="field_requirement"]').val(d.requirement); }
        // Email/Mobile: only pre-fill if the landed-on field is still
        // empty — never clobber a value the client is actively editing
        // directly inside a service's own Contact Details step.
        var $email = $container.find('[name="field___email"]');
        if ($email.length && !$email.val() && d.email) { $email.val(d.email); }
        var $pcode = $container.find('[name="field_phone_code"]');
        if ($pcode.length && d.phone_code) { $pcode.val(d.phone_code); }
        var $phone = $container.find('[name="field___phone"]');
        if ($phone.length && !$phone.val() && d.phone) { $phone.val(d.phone); }
    }

    // Keep capturing live as the client types, not only right before a
    // swap — covers e.g. filling in Email/Mobile, then coming back and
    // changing the already-selected service (Step 1's fields at that
    // point are the hidden carry-forward inputs + whatever the current
    // service's own Contact Details step has, both covered by the same
    // selectors).
    $(document).on('input change', '.nsh-sl-wizard-container', function (e) {
        var name = e.target && e.target.name;
        if (name === 'field_first_name' || name === 'field_last_name' || name === 'field___email' ||
            name === 'field_phone_code' || name === 'field___phone' || name === 'field_requirement') {
            nshCaptureInitialClientInfo($(this));
        }
    });

    function nshPrefetchAllWizards() {
        if (!$('.nsh-sl-service-select').length) { return; } // no Services field on this page
        // #nsh-sl-wizard-container carries data-standalone="1" only when
        // [nsh_standalone_form] rendered it (see nsh_render_service_field_html()
        // in shortcodes.php) — pass that along so every prefetched/cached
        // service wizard keeps the same one-field-per-row, placeholder-only
        // design as the card's own initial Step 1, instead of the swap
        // silently reverting to the dashboard form's labeled/two-column look.
        var standalone = $('.nsh-sl-wizard-container').first().attr('data-standalone') === '1' ? 1 : 0;
        $.post(NSH.ajax_url, {action: 'nsh_prefetch_all_wizards', nonce: NSH.nonce, sl_mode: 1, standalone: standalone}, function (r) {
            if (r && r.success) { nshWizardCache = r.data; }
        });
    }
    $(document).ready(nshPrefetchAllWizards);

    function nshApplyWizardSwap($container, sid, data) {
        $container.html(data.html);
        // A fresh service wizard means a brand-new #nsh-request-form (and a
        // brand-new set of file fields) — any uploads tracked against the
        // PREVIOUS form's fields no longer correspond to anything on the
        // page, so drop that bookkeeping and hand the new form its own
        // upload token. Any in-flight upload from before this swap is left
        // to finish on its own (its own promise still resolves and, being
        // an orphan nothing ever claims, gets swept by
        // nsh_cleanup_stale_pending_uploads() a couple of days later).
        var inst = nshInstOf($container);
        nshUploadsByInst[inst] = {};
        nshUniquify($container, inst);
        var $newForm = $container.find('.nsh-request-form');
        if ($newForm.length) { nshEnsureUploadToken($newForm); }
        var $outer = $container.closest('.nsh-sl-outer, .nsh-wizard-page-card, .nsh-form-page');
        ($outer.length ? $outer : $(document)).find('.nsh-sl-card-title').text(data.title);
        $('#nsh-form-hero-title').text(data.title);
        $('#nsh-form-hero-sub').text(sid ? 'Complete all steps below. We will review and respond within 24 hours.' : 'Choose a service below to get started.');
        // Whatever the client already typed into Step 1 (First/Last Name,
        // Email, Mobile, the requirement text) — before this swap — lands
        // back in the freshly swapped-in HTML here: pre-filled into the
        // service's own Contact Details fields (Email/Mobile) or the
        // hidden carry-forward inputs (First/Last Name/requirement) if a
        // service was just chosen, or back into the visible picker-shell
        // fields if the client reverted to "no service selected".
        nshApplyInitialClientInfo($container);
        // Keep the URL shareable/refreshable without a full page reload.
        // Only a single-form page keeps its choice in the address bar; with several forms on one page the pick
        // belongs to that form only.
        if (window.history && window.history.replaceState && $('.nsh-sl-wizard-container').length < 2) {
            var url = new URL(window.location.href);
            if (data.slug) { url.searchParams.set('service', data.slug); }
            else { url.searchParams.delete('service'); }
            window.history.replaceState(null, '', url.toString());
        }
    }

    // STALE-RESPONSE GUARD — fixes "sometimes when I select a service it
    // does not load the form" (intermittently shows the WRONG service's
    // form, or looks like the pick did nothing). Root cause: when the
    // prefetch cache (above) hasn't finished yet, each pick fires its own
    // network request, and nothing enforced that those requests resolve
    // in the same order they were sent. If a visitor changes the Services
    // dropdown twice in quick succession (scrolling through options,
    // double-clicking, or just a slow/loaded server making one response
    // land after a later, faster one), the OLDER request's response could
    // arrive AFTER the newer one and silently overwrite the whole
    // container — including the <select> itself — back to the earlier,
    // no-longer-selected service. The visitor sees either the previous
    // service's form reappear, or (since the swapped-in HTML resets the
    // dropdown's own selected option) the dropdown visibly snapping back
    // to what they'd already moved past — both read as "picking the
    // service didn't work." nshServiceSelectSeq is a simple monotonic
    // counter: every change event stamps the request it fires (or the
    // synchronous cache-swap it takes instead) with the CURRENT count,
    // and any async response checks that its stamp is still the latest
    // before touching the DOM. A superseded response is dropped — the
    // newer selection already rendered the correct form, so there's
    // nothing to recover, just nothing left to (wrongly) apply.
    var nshServiceSelectSeq = 0;

    $(document).on('change', '.nsh-sl-service-select', function () {
        var $sel  = $(this), sid = $sel.val(), $container = $sel.closest('.nsh-sl-wizard-container');
        var mySeq = ($container.data('nshSeq') || 0) + 1; $container.data('nshSeq', mySeq);
        // Capture whatever is currently typed BEFORE the swap wipes it out.
        nshCaptureInitialClientInfo($container);
        var cached = nshWizardCache ? ( sid ? nshWizardCache.services[sid] : nshWizardCache.picker ) : null;
        if (cached) {
            // Instant, synchronous swap — no request, no loading state,
            // and nothing async to race: this IS the latest pick the
            // instant it runs.
            nshApplyWizardSwap($container, sid, cached);
            return;
        }
        // Prefetch hasn't finished yet (very fast pick, or a slow
        // connection) — fall back to a same-request fetch. Still no
        // "Loading form…" placeholder blanking the container: the
        // previously visible content just stays in place, dimmed, until
        // the real content is ready to replace it in one step.
        $container.addClass('nsh-sl-wizard-busy');
        var standalone = $container.attr('data-standalone') === '1' ? 1 : 0;
        $.post(NSH.ajax_url, {action: 'nsh_load_service_wizard', nonce: NSH.nonce, service_id: sid, sl_mode: 1, standalone: standalone}, function (r) {
            // A newer selection has already resolved (sync from cache, or
            // an earlier-firing but faster fetch) since this request went
            // out — this response is stale, ignore it entirely so it
            // can't clobber what the visitor is looking at now.
            if (mySeq !== $container.data('nshSeq')) { return; }
            $container.removeClass('nsh-sl-wizard-busy');
            if (!r || !r.success) {
                $container.html('<p class="nsh-alert nsh-alert-error">' + ((r && r.data && r.data.message) ? r.data.message : 'Could not load this service\'s form.') + '</p>');
                return;
            }
            nshApplyWizardSwap($container, sid, r.data);
        }).fail(function () {
            if (mySeq !== $container.data('nshSeq')) { return; }
            $container.removeClass('nsh-sl-wizard-busy');
            $container.html('<p class="nsh-alert nsh-alert-error">Connection error — please try again.</p>');
        });
    });

    /* ═══════════════════════════════════════════════════════════
       COMPACT MULTI-SELECT DROPDOWN — the ONE control every checkbox
       (multi-select) field uses (see nsh_render_form_field() in
       shortcodes.php). Clicking the toggle button opens/closes a
       floating checkbox panel; the button label reflects what's
       selected without ever overflowing the field's single-line height;
       Escape and outside-click both close it; each option's row gets a
       distinct "selected" visual state; and required multi-selects are
       validated for real (see the dedicated required check in the
       Next-button handler below — a checkbox's raw .val() is always
       non-empty, so this can't reuse the plain input validator).
    ═══════════════════════════════════════════════════════════ */
    function nshMsUpdateLabel($ms) {
        var $text  = $ms.find('.nsh-ms-toggle-text');
        var $boxes = $ms.find('.nsh-ms-panel input:checked');
        $ms.find('.nsh-ms-opt').removeClass('nsh-ms-opt-selected');
        $boxes.closest('.nsh-ms-opt').addClass('nsh-ms-opt-selected');
        var n = $boxes.length;
        if ( ! n ) { $text.text('- Select -').removeClass('nsh-ms-has-value'); return; }
        if ( n === 1 ) {
            $text.text($boxes.first().parent().find('span').text().trim()).addClass('nsh-ms-has-value');
        } else {
            $text.text(n + ' selected').addClass('nsh-ms-has-value');
        }
    }
    function nshMsClose($panel) {
        $panel.hide();
        $panel.closest('.nsh-multiselect').find('.nsh-ms-toggle').attr('aria-expanded', 'false');
    }
    $(document).on('click', '.nsh-ms-toggle', function (e) {
        e.stopPropagation();
        var $btn   = $(this);
        var $panel = $btn.siblings('.nsh-ms-panel');
        var isOpen = $panel.is(':visible');
        $('.nsh-ms-panel:visible').each(function () { nshMsClose($(this)); });
        if (!isOpen) {
            $panel.show();
            $btn.attr('aria-expanded', 'true');
            $panel.find('input[type=checkbox]').first().trigger('focus');
        }
    });
    $(document).on('change', '.nsh-ms-panel input[type=checkbox]', function () {
        var $ms = $(this).closest('.nsh-multiselect');
        nshMsUpdateLabel($ms);
        // Selecting a value clears whatever required-field error was
        // showing — matches how every other field clears its own error
        // the moment the visitor fixes it, instead of only on next Next-click.
        $ms.removeClass('nsh-field-invalid-outline');
    });
    $(document).on('keydown', '.nsh-multiselect', function (e) {
        if (e.key === 'Escape' || e.keyCode === 27) {
            nshMsClose($(this).find('.nsh-ms-panel'));
            $(this).find('.nsh-ms-toggle').trigger('focus');
        }
    });
    $(document).on('click', function (e) {
        if ($(e.target).closest('.nsh-multiselect').length) return;
        $('.nsh-ms-panel:visible').each(function () { nshMsClose($(this)); });
    });

    var MAX_FILE_BYTES = 10 * 1024 * 1024;

    // Submit request form
    // Clear the invalid-highlight the instant the visitor checks the box,
    // rather than making them hit Submit again to see it clear.
    $(document).on('change', '.nsh-disclaimer-consent', function () {
        if ($(this).is(':checked')) { $(this).closest('.nsh-disclaimer-box').removeClass('nsh-disclaimer-invalid'); }
    });

    $(document).on('submit', '.nsh-request-form', function (e) {
        e.preventDefault();
        // Hard re-entry guard: a double-tap, an Enter key repeat or a
        // second tab-event can fire 'submit' again before the first
        // request has even left the browser. One in-flight (or already
        // successful) submission per form, full stop.
        if ($(this).data('nshBusy')) { return; }
        var $f=$(this), $btn=$f.find('[type=submit]'), $err=$f.find('.nsh-form-err').first();
        var inst = nshInstOf($f);
        window.nshSubmitInst = inst;
        var $prog = $f.find('.nsh-submit-progress'), $progFill = $f.find('.nsh-submit-progress-fill'), $progLabel = $f.find('.nsh-submit-progress-label');

        // Standalone-form disclaimer consent checkbox — only rendered on
        // [nsh_standalone_form] (see nsh_render_service_wizard_html() in
        // shortcodes.php), so this is a no-op on the Client Dashboard's own
        // "New Request" wizard where the checkbox doesn't exist at all.
        // Blocks submission outright (before any file-upload validation,
        // AJAX call, etc.) until it's checked.
        var $consent = $f.find('.nsh-disclaimer-consent');
        if ($consent.length && !$consent.is(':checked')) {
            $err.text('Please read the disclaimer and check the consent box before submitting.').show();
            $consent.closest('.nsh-disclaimer-box').addClass('nsh-disclaimer-invalid');
            nshRevealField($consent.closest('.nsh-disclaimer-box'));
            return;
        }
        if ($consent.length) { $consent.closest('.nsh-disclaimer-box').removeClass('nsh-disclaimer-invalid'); }

        // Human-verification (CAPTCHA) widget — whichever provider is
        // active. Cloudflare Turnstile keeps a hidden input named
        // "cf-turnstile-response" inside its own container in sync with
        // the current token (present once solved, cleared again if it
        // expires — see data-refresh-expired="auto" on the widget itself,
        // shortcodes.php); the built-in provider instead shows a plain
        // "what is A + B?" question in #nsh-captcha-answer. This is a UX
        // nicety only — catches the common "forgot to complete it" /
        // "it expired while filling the rest of the form" cases instantly,
        // client-side, before even starting the file-compression/upload
        // pipeline below. The REAL check is server-side
        // (nsh_captcha_verify() in helpers.php, dispatching to whichever
        // provider is configured, called from nsh_ajax_create_request())
        // — a bot that skips this page's JS entirely and posts straight
        // to admin-ajax.php is rejected there regardless of what happens
        // here.
        var $captchaRow = $f.find('.nsh-captcha-row');
        if ($captchaRow.length) {
            var $turnstileInput = $captchaRow.find('input[name="cf-turnstile-response"]');
            var $builtinAnswer  = $captchaRow.find('.nsh-captcha-answer');
            if ($turnstileInput.length) {
                // Turnstile provider.
                if (!$turnstileInput.val()) {
                    $err.text('Please complete the verification challenge before submitting.').show();
                    nshRevealField($captchaRow);
                    return;
                }
            } else if ($builtinAnswer.length) {
                // Built-in provider.
                var builtinAnswerVal = ($builtinAnswer.val() || '').toString().trim();
                if (builtinAnswerVal === '' || isNaN(builtinAnswerVal)) {
                    $err.text('Please answer the verification question before submitting.').show();
                    nshRevealField($captchaRow);
                    if (!nshIsCoarsePointer()) { try { $builtinAnswer[0].focus({ preventScroll: true }); } catch (e) {} }
                    return;
                }
            }
        }

        // Validate required file upload fields
        // Strategy: find every .nsh-field that (a) has .nsh-req star and (b) contains a .nsh-dropzone
        // Skip only if the field has conditional logic (data-nsh-cond attr) AND that condition hid it
        //
        // Collects the actual LABEL of every missing required document (not
        // just a pass/fail flag) so the error message can name exactly what
        // the visitor still needs to upload — "upload document A and B" is
        // actionable, "upload all required documents" makes them guess.
        var fileOk = true;
        var missingDocLabels = [];
        var $firstMissingDz = null;
        $f.find('.nsh-field').each(function(){
            var $fw = $(this);

            // Does this field wrap a dropzone?
            var $dz = $fw.children('.nsh-dropzone');
            if (!$dz.length) return; // not a file field

            // Is it marked required? (.nsh-req star must be in the label)
            var isRequired = $fw.find('label .nsh-req').length > 0;
            if (!isRequired) return;

            // Is it a CONDITIONAL field that is currently hidden by its condition?
            // Only skip if it explicitly has conditions AND those conditions are hiding it
            var hasCond  = typeof $fw.attr('data-nsh-cond') !== 'undefined';
            var condHide = hasCond && $fw.css('display') === 'none';
            if (condHide) return;

            // Each dropzone has its own file input now (see nsh_render_form_field()).
            var fi = $dz.find('input[type="file"]')[0];
            var hasFiles = fi && fi.files && fi.files.length > 0;

            if (!hasFiles) {
                // Read the live --nsh-error-color custom property (set by the
                // "Form Styling" admin panel's Error Color field, see
                // nsh_form_style_inline_css()) instead of a hardcoded red, so
                // a customized error color also applies to this dropzone
                // "missing required file" state, not just validation text.
                var nshErrColor = getComputedStyle(document.documentElement).getPropertyValue('--nsh-error-color').trim() || '#ef4444';
                $dz.css({'border-color': nshErrColor, 'background': '#fff5f5'});
                fileOk = false;
                // Field label text minus the trailing " *" required-star markup.
                var label = $fw.find('label').clone().find('.nsh-req').remove().end().text().trim();
                if (label) missingDocLabels.push(label);
                if (!$firstMissingDz) $firstMissingDz = $dz;
                // A small inline "Missing" tag right by the dropzone itself —
                // visible at a glance even before reading the summary message
                // above, and even if several dropzones are missing at once.
                if (!$dz.siblings('.nsh-doc-missing-tag').length) {
                    $dz.before('<p class="nsh-doc-missing-tag" style="color:' + nshErrColor + ';font-size:12px;font-weight:600;margin:0 0 4px;">&#9888; This document is required and has not been uploaded yet.</p>');
                }
            } else {
                $dz.css({'border-color': '', 'background': ''});
                $dz.siblings('.nsh-doc-missing-tag').remove();
            }
        });

        if (!fileOk) {
            var docMsg = missingDocLabels.length === 1
                ? ('Please upload the required document "' + missingDocLabels[0] + '" before submitting.')
                : ('Please upload these required documents before submitting: ' + missingDocLabels.join(', ') + '.');
            $err.html('<strong>' + esc(docMsg) + '</strong> Everything else you’ve entered has been kept — just add the missing file' + (missingDocLabels.length > 1 ? 's' : '') + ' below and submit again.').show();
            // ROOT-CAUSE FIX: step numbers are the DB's actual step_number
            // values, NOT a 1,2,3,4,5 position count — "Documents" is
            // conventionally step_number 99 (see the siblingStepNumber()
            // comment above), so a hardcoded gotoStep(4, $f) silently
            // matched nothing whenever a service didn't happen to have
            // exactly 3 content steps before it. gotoStep() would then
            // show no step at all, leaving the visitor stuck looking at
            // the error banner with steps 1-3 marked done and 4-5 never
            // actually revealed — exactly the "stuck at this stage"
            // behavior this was meant to prevent. Reading the REAL
            // data-step off the missing field's own containing step (it's
            // always on the actual rendered documents step, wherever that
            // service put it) makes this work for every service instead of
            // only the ones that happen to have step number 4.
            if ($firstMissingDz && $firstMissingDz.length) {
                var $missingStep = $firstMissingDz.closest('.nsh-wizard-step');
                var missingStepNum = $missingStep.length ? parseInt($missingStep.attr('data-step')) : NaN;
                gotoStep(isNaN(missingStepNum) ? 99 : missingStepNum, $f);
                // Bring the FIRST missing dropzone into view and focus its
                // browse button — the visitor lands exactly where the fix
                // is needed instead of having to hunt for which field the
                // red border belongs to on a long documents step.
                setTimeout(function () {
                    nshRevealField($firstMissingDz);
                    if (!nshIsCoarsePointer()) {
                        var fb = $firstMissingDz.find('.nsh-file-browse')[0];
                        if (fb) { try { fb.focus({ preventScroll: true }); } catch (e) {} }
                    }
                }, 60);
            } else {
                // Defensive fallback if no dropzone was found for some
                // reason (shouldn't happen) — 99 is the conventional
                // Documents step_number used across every service.
                gotoStep(99, $f);
            }
            return;
        }

        function resetBtn() {
            $f.data('nshBusy', false);
            $btn.find('.nsh-bt').show(); $btn.find('.nsh-bl').hide(); $btn.prop('disabled', false);
            $prog.hide(); $progLabel.hide();
            // A Turnstile token is single-use — reset the widget on any
            // failed submission attempt (server rejection, network error,
            // etc.) so a retry gets a fresh token instead of resending the
            // same already-consumed one, which Cloudflare would reject as
            // 'timeout-or-duplicate' every time. window.turnstile is only
            // defined once its script (enqueued only when the widget is
            // actually on the page) has loaded, and .reset() with no
            // widget id resets every Turnstile widget on the page — safe
            // here since this form never has more than one.
            if (window.turnstile && $captchaRow.length) {
                try { var tsEl = $captchaRow.find('.cf-turnstile')[0]; if (tsEl) { window.turnstile.reset(tsEl); } else { window.turnstile.reset(); } } catch (e) {}
            }
        }

        // Every required file field just needs a file SELECTED at this
        // point — not necessarily finished uploading (that's the whole
        // point of the background-upload architecture above: this request
        // must stay fast no matter how far along those uploads are).
        // pending_manifest tells the server how many files were selected
        // per field, since no file bytes travel in THIS call for it to
        // count directly any more (see nsh_ajax_create_request(), ajax.php).
        var $allFileInputs = $f.find('input.nsh-file-input[type="file"]');
        var pendingManifest = {};
        $allFileInputs.each(function () {
            var key = $(this).closest('.nsh-dropzone').data('field-key');
            pendingManifest[key] = this.files ? this.files.length : 0;
        });

        $f.data('nshBusy', true);
        $btn.find('.nsh-bt').hide(); $btn.find('.nsh-bl').show(); $btn.prop('disabled',true); $err.hide();
        $prog.show(); $progFill.css('width','100%'); $progLabel.show().text('Submitting…');

        // No file bytes travel in this call — documents are already
        // uploading (or finished) independently via
        // nsh_ajax_upload_pending_document(). This keeps the request tiny
        // and fast regardless of document size/connection speed, which is
        // the direct fix for "shows an error even though it was actually
        // submitted": that used to happen when a slow file upload bundled
        // into this same call pushed total request time past a reverse-
        // proxy/gateway timeout the server-side PHP timeout override below
        // never protected against.
        var fd = new FormData($f[0]);
        var fd2 = new FormData();
        for (var pair of fd.entries()) {
            if (!(pair[1] instanceof File)) fd2.append(pair[0], pair[1]);
        }
        fd2.append('action', 'nsh_create_request');
        // A fresh random value per Submit click, kept identical across this
        // one click's own automatic network-failure retries (nshUploadWithRetry
        // reuses this same fd2) — lets the server recognize and safely
        // no-op a retry of a submission that actually already succeeded,
        // instead of creating a duplicate request. See the matching
        // docblock in nsh_ajax_create_request().
        fd2.append('submit_token', nshGenToken());
        fd2.append('pending_manifest', JSON.stringify(pendingManifest));

        nshUploadWithRetry({
            formData: fd2,
            maxAttempts: 3,
            onRetry: function (attempt, max) {
                $progLabel.text('Connection interrupted — retrying (' + (attempt + 1) + '/' + max + ')…');
            },
            onSuccess: function (r) {
                // The popup is only ever shown for a request the server
                // has confirmed it SAVED — i.e. it returned both the
                // human-readable request number and the stored post id.
                if (r && r.success && r.data && r.data.request_id && r.data.post_id) {
                    nshClearDraft(inst);
                    nshShowSubmitSuccess($f, r.data);
                } else if (r && r.success) {
                    $err.text('We could not confirm that your request was saved. Please check your dashboard before submitting again.').show();
                    resetBtn();
                } else {
                    var msg = (r.data && r.data.message) ? r.data.message : 'Submission failed. Please try again.';
                    $err.text(msg).show();
                    resetBtn();
                }
            },
            onError: function (xhr, status) {
                var msg;
                if (status === 'timeout') {
                    msg = 'The server is taking longer than expected to respond. Please wait a moment and try again — if your first attempt actually went through, resubmitting is safe and will not create a duplicate application.';
                } else if (xhr.status === 0) {
                    msg = 'Connection lost while submitting. Your answers have been saved on this device — please check your connection and try again; resubmitting is safe and will not create a duplicate application.';
                } else if (xhr.status >= 500) {
                    msg = 'The server had a problem processing your request. Please try again in a moment.';
                } else {
                    msg = 'Connection error. Please try again.';
                }
                $err.text(msg).show();
                resetBtn();
            }
        });
    });

    // Builds + opens the "Application Submitted Successfully!" popup the
    // instant the server confirms the request is saved — well before any
    // documents still uploading in the background have necessarily
    // finished (Submit never waits for them). Also reconciles every tracked
    // upload against the now-known request id so anything that finished
    // uploading BEFORE Submit is marked attached here too, and anything
    // still in flight gets attached the moment it finishes (see the success
    // handler inside nshStartFileUpload()). Every value shown comes from the
    // server response and goes through esc().
    function nshSuccessMessage(d) {
        var email = d.email ? '<strong>' + esc(d.email) + '</strong>' : 'your email';
        switch (d.account_status) {
            case 'created':
                return 'Your application has been submitted successfully, and your account has been created — you are already signed in, so you can open your dashboard and track the status of your inquiry.' +
                    (d.welcome_sent === false ? ' We could not email your login details just now; next time use “Magic Link” on the login page with ' + email + '.' : ' Your login details have been emailed to ' + email + '.');
            case 'existing_logged_in':
                return 'Your application has been submitted successfully and added to your account, so you can track the status of your inquiry from your dashboard.';
            case 'existing_needs_login':
                return 'Your application has been submitted successfully. An account already exists for ' + email + ', so we have added the request to it. Please log in to open your dashboard and track the status of your inquiry.';
            case 'staff_on_behalf':
                return 'The application has been submitted successfully and filed under the client account for ' + email + '.';
            default:
                return 'Your application has been submitted successfully. You can track its status from your dashboard.';
        }
    }
    function nshShowSubmitSuccess($f, data) {
        window.nshCreatedRequestId = data.post_id;
        var $wrap = $f.parent();
        $wrap.find('.nsh-steps-bar, .nsh-sl-steps').hide();
        $f.hide();

        var dest = data.dashboard_url || data.redirect || (NSH.home_url || '/');
        var rows = [];
        if (data.service_name) { rows.push(['Service requested', esc(data.service_name)]); }
        if (data.email)        { rows.push(['Contact email', esc(data.email)]); }
        if (data.submitted_on) { rows.push(['Submitted on', esc(data.submitted_on)]); }
        rows.push(['Current status', '<span class="nsh-sm-pill">Submitted &middot; Under review</span>']);
        if (data.turnaround_days > 0) { rows.push(['Typical turnaround', esc(String(data.turnaround_days)) + ' working days (after approval)']); }

        var html = '' +
          '<div id="nsh-success-modal" class="nsh-sm-overlay" role="dialog" aria-modal="true" aria-labelledby="nsh-sm-title" aria-describedby="nsh-sm-desc">' +
            '<div class="nsh-sm-card">' +
              '<div class="nsh-sm-hero" aria-hidden="true">' +
                '<span class="nsh-sm-spark nsh-sm-spark-1"></span><span class="nsh-sm-spark nsh-sm-spark-2"></span><span class="nsh-sm-spark nsh-sm-spark-3"></span><span class="nsh-sm-spark nsh-sm-spark-4"></span>' +
                '<div class="nsh-sm-check"><svg viewBox="0 0 52 52" width="52" height="52" focusable="false"><circle class="nsh-sm-check-c" cx="26" cy="26" r="24" fill="none"/><path class="nsh-sm-check-p" fill="none" d="M14 27l8 8 16-17"/></svg></div>' +
              '</div>' +
              '<div class="nsh-sm-body">' +
                '<h2 id="nsh-sm-title" class="nsh-sm-title">Application Submitted Successfully!</h2>' +
                '<p id="nsh-sm-desc" class="nsh-sm-lead">' + nshSuccessMessage(data) + '</p>' +
                '<div class="nsh-sm-rid"><div class="nsh-sm-rid-main"><span class="nsh-sm-rid-lbl">Your request number</span><strong id="nsh-success-rid" class="nsh-sm-rid-val">' + esc(data.request_id) + '</strong></div>' +
                  '<button type="button" class="nsh-sm-copy" id="nsh-success-copy" aria-label="Copy request number ' + esc(data.request_id) + '">Copy</button></div>' +
                '<dl class="nsh-sm-details">' + rows.map(function (r) { return '<div><dt>' + r[0] + '</dt><dd>' + r[1] + '</dd></div>'; }).join('') + '</dl>' +
                '<div class="nsh-sm-next"><h3 class="nsh-sm-next-h">What happens next</h3><ol class="nsh-sm-steps">' +
                  '<li><span>1</span><div>Our relevant team reviews your request and assesses its feasibility.</div></li>' +
                  '<li><span>2</span><div>We contact you to confirm whether we can provide the requested service.</div></li>' +
                  '<li><span>3</span><div>We explain the next steps — you can follow every update from your dashboard.</div></li>' +
                '</ol></div>' +
                '<p id="nsh-success-pending" class="nsh-sm-pending" role="status" style="display:none;"></p>' +
                '<div class="nsh-sm-foot"><a href="' + esc(dest) + '" id="nsh-success-continue" class="nsh-sm-cta">Okay, Go to Dashboard</a></div>' +
              '</div>' +
            '</div>' +
          '</div>';
        $('#nsh-success-modal').remove();
        var $modal = $(html).appendTo(document.body);
        $('body').addClass('nsh-no-scroll');
        var prevFocus = document.activeElement;
        var cta = $modal.find('#nsh-success-continue')[0];
        try { cta.focus({ preventScroll: true }); } catch (e) { cta.focus(); }

        // Focus trap: only the Copy button and the CTA are focusable.
        $modal.on('keydown', function (ev) {
            if (ev.key !== 'Tab') return;
            var f = $modal.find('button, a[href]').filter(':visible').toArray();
            if (!f.length) return;
            var first = f[0], last = f[f.length - 1];
            if (ev.shiftKey && document.activeElement === first) { ev.preventDefault(); last.focus(); }
            else if (!ev.shiftKey && document.activeElement === last) { ev.preventDefault(); first.focus(); }
        });
        $modal.on('click', '#nsh-success-copy', function () {
            var btn = this, txt = data.request_id;
            function done(ok) { $(btn).text(ok ? 'Copied ✓' : 'Copy failed'); setTimeout(function () { $(btn).text('Copy'); }, 1800); }
            try {
                if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(txt).then(function () { done(true); }, function () { done(false); }); return; }
            } catch (e) { /* fall through */ }
            try {
                var ta = document.createElement('textarea'); ta.value = txt; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;top:0;left:0;opacity:0;';
                document.body.appendChild(ta); ta.select(); var ok = document.execCommand('copy'); document.body.removeChild(ta); done(ok);
            } catch (e2) { done(false); }
        });

        var upAll = nshUp(nshInstOf($f));
        Object.keys(upAll).forEach(function (k) {
            upAll[k].forEach(function (item) {
                if (item.status === 'done') { item.attached = true; }
            });
        });
        nshUpdatePendingUploadUi();

        $('#nsh-success-continue').off('click.nshWait').on('click.nshWait', function (ev) {
            // Leaving is always allowed — the application already exists
            // either way — this just warns that navigating away right now
            // may cut off a document still uploading in the background (a
            // page navigation aborts any in-flight upload request; there is
            // no way around that from here).
            var counts = nshCountUnfinishedUploads();
            if (counts.total - counts.done > 0) {
                if (!window.confirm('Some documents are still uploading. Leaving now may stop them before they finish. Continue anyway?')) { ev.preventDefault(); }
            }
        });
    }

    /* ═══════════════════════════════════════════════════════════
       CLIENT DASHBOARD — New Service Request Modal
    ═══════════════════════════════════════════════════════════ */
    function openSrModal() {
        if (!$('#nsh-sr-modal').length) { return; }
        $('#nsh-sr-modal').css('display','flex');
        $('body').addClass('nsh-no-scroll');
        $('#nsh-sr-step1').show(); $('#nsh-sr-step2').hide();
        var $cat = $('#nsh-sr-cat');
        if ($cat.length && $cat.find('option').length <= 1) {
            $.post(NSH.ajax_url,{action:'nsh_get_request_types',nonce:NSH.nonce},function(r){
                if(!r.success)return;
                var h='<option value="">-- Select Category --</option>';
                $.each(r.data,function(i,t){h+='<option value="'+t.id+'" data-name="'+esc(t.name)+'">'+esc(t.icon)+' '+esc(t.name)+'</option>';});
                $cat.html(h);
            });
        }
    }
    function closeSrModal() { $('#nsh-sr-modal').css('display','none'); $('body').removeClass('nsh-no-scroll'); }

    $(document).on('click', '#nsh-new-sr-btn, #nsh-new-sr-btn2, .nsh-open-sr', function (e) { e.preventDefault(); openSrModal(); });
    $(document).on('click', '#nsh-sr-modal', function(e){if($(e.target).is('#nsh-sr-modal'))closeSrModal();});
    // The X used to hide the modal inline WITHOUT removing body.nsh-no-scroll,
    // leaving the page scroll-locked after closing. Route it (and Esc)
    // through closeSrModal() so the lock is always released.
    $(document).on('click', '.nsh-sr-close', closeSrModal);

    // Client-portal in-page links (My Requests / My Documents / Payments).
    // If the target section is on this view, scroll to it in place; if not
    // (e.g. Profile tab, a request's detail view, another portal page) let
    // the browser follow the real href — dashboard URL + #anchor.
    $(document).on('click', '[data-cd-anchor]', function (e) {
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.which === 2) return;
        var id = $(this).attr('data-cd-anchor'), el = document.getElementById(id);
        if (!el) return;
        e.preventDefault();
        try { el.scrollIntoView({ behavior: nshReducedMotion() ? 'auto' : 'smooth', block: 'start' }); } catch (err) { el.scrollIntoView(); }
        try { history.replaceState(history.state, '', '#' + id); } catch (err2) { /* ignore */ }
    });
    $(document).on('keydown', function(e){ if (e.key === 'Escape' && $('#nsh-sr-modal').is(':visible')) { closeSrModal(); } });

    $(document).on('click', '#nsh-sr-proceed', function(){
        var $cat=$('#nsh-sr-cat'), catId=$cat.val(), catName=$cat.find('option:selected').data('name')||$cat.find('option:selected').text();
        if(!catId){alert('Please select a category.');return;}
        $('#nsh-sr-cat-name').text(catName);
        $('#nsh-sr-tid').val(catId);
        $('#nsh-sr-tname').val(catName);
        $('#nsh-sr-step1').hide(); $('#nsh-sr-step2').show();
    });
    $(document).on('click', '#nsh-sr-back', function(){ $('#nsh-sr-step2').hide(); $('#nsh-sr-step1').show(); });

    $(document).on('change', '#nsh-sr-file', function(){
        var names=[]; for(var i=0;i<this.files.length;i++) names.push(this.files[i].name);
        $('#nsh-sr-file-names').text(names.join(', '));
    });

    $(document).on('submit', '#nsh-sr-form', function(e){
        e.preventDefault();
        var $f=$(this),$btn=$f.find('[type=submit]'),$err=$('#nsh-sr-err');
        $btn.text('Submitting…').prop('disabled',true); $err.hide();
        var fd=new FormData($f[0]);
        fd.append('action','nsh_submit_ticket'); fd.append('nonce',NSH.nonce);
        var files=document.getElementById('nsh-sr-file');
        if(files&&files.files.length){for(var i=0;i<files.files.length;i++)fd.append('files[]',files.files[i]);}
        $.ajax({url:NSH.ajax_url,type:'POST',data:fd,processData:false,contentType:false,
            success:function(r){$btn.text('Submit').prop('disabled',false);if(r.success){closeSrModal();location.reload();}else{$err.text(r.data&&r.data.message?r.data.message:'Submission failed.').show();}},
            error:function(){$btn.text('Submit').prop('disabled',false);$err.text('Connection error.').show();}
        });
    });

    /* ═══════════════════════════════════════════════════════════
       REQUEST DETAIL — Tab switching
    ═══════════════════════════════════════════════════════════ */
    $(document).on('click', '.nsh-ot', function(){
        var t=$(this).data('ot');
        $('.nsh-ot').removeClass('active'); $(this).addClass('active');
        $('.nsh-ot-pane').hide(); $('#nsh-ot-'+t).show();
        if(t==='tickets') loadTicketTypes();
    });

    // Document section collapse
    $(document).on('click', '.nsh-doc-section-btn', function(){
        var ds=$(this).data('ds'), $body=$('#nsh-ds-'+ds);
        var open=$(this).hasClass('nsh-ds-open');
        if(open){$body.hide();$(this).removeClass('nsh-ds-open');$(this).find('.nsh-ds-arrow').text('▾');}
        else{$body.show();$(this).addClass('nsh-ds-open');$(this).find('.nsh-ds-arrow').text('▴');}
    });

    /* ═══════════════════════════════════════════════════════════
       DOCUMENT UPLOAD
    ═══════════════════════════════════════════════════════════ */
    function nshShowUpload(type, rid) {
        $('#nsh-upload-is-provider').val(type==='provider'?1:0);
        $('#nsh-upload-rid').val(rid);
        var $area=$('#nsh-upload-area');
        if($area.is(':visible')&&$area.data('type')===type){$area.hide();return;}
        $area.data('type',type).show();
        $('html,body').animate({scrollTop:$area.offset().top-20},200);
    }
    window.nshShowUpload = nshShowUpload; // expose for inline onclick

    $(document).on('dragover','#nsh-upload-drop',function(e){e.preventDefault();$(this).css({borderColor:'#2563eb',background:'#eff6ff'});});
    $(document).on('dragleave','#nsh-upload-drop',function(){$(this).css({borderColor:'',background:''});});
    $(document).on('drop','#nsh-upload-drop',function(e){e.preventDefault();$(this).css({borderColor:'',background:''});var f=e.originalEvent.dataTransfer.files[0];if(f)doUpload(f);});
    $(document).on('change','#nsh-doc-file',function(){if(this.files[0])doUpload(this.files[0]);});

    $(document).on('click','#nsh-do-upload',function(){
        var f=document.getElementById('nsh-doc-file').files[0];
        if(!f){alert('Please select a file.');return;}
        doUpload(f);
    });

    function doUpload(file){
        var rid=$('#nsh-upload-rid').val(), isProv=$('#nsh-upload-is-provider').val();
        if(file.size>10*1024*1024){alert('File exceeds 10MB.');return;}
        if(['application/pdf','image/jpeg','image/png'].indexOf(file.type)===-1){alert('Only PDF/JPG/PNG allowed.');return;}
        var fd=new FormData();
        fd.append('action','nsh_upload_document'); fd.append('nonce',NSH.upload_nonce||NSH.nonce);
        fd.append('request_id',rid); fd.append('file',file);
        fd.append('doc_type',$('#nsh-doc-type').val()||'Document'); fd.append('is_provider',isProv);
        $('#nsh-upload-progress').show(); $('#nsh-prog-fill').css('width','0%');
        $.ajax({url:NSH.ajax_url,type:'POST',data:fd,processData:false,contentType:false,
            xhr:function(){var x=new XMLHttpRequest();x.upload.addEventListener('progress',function(e){if(e.lengthComputable)$('#nsh-prog-fill').css('width',Math.round(e.loaded/e.total*100)+'%');});return x;},
            success:function(r){$('#nsh-upload-progress').hide();if(r.success){alert('Uploaded successfully!');location.reload();}else{alert(r.data&&r.data.message?r.data.message:'Upload failed.');}},
            error:function(){$('#nsh-upload-progress').hide();alert('Upload error. Try again.');}
        });
    }

    $(document).on('click','.nsh-del-doc',function(){
        if(!confirm('Delete this document?'))return;
        var rid=$(this).data('rid'), att=$(this).data('att');
        nshPost('nsh_delete_document',{request_id:rid,attachment_id:att},function(){location.reload();},alert);
    });


    /* MESSAGING SYSTEM
       Send      = save to chat only (no email)
       Send via Email = save to chat + email other party
       Both parties see messages updated every 4 seconds.
       Full list refresh — no pointer/deduplication complexity.
    */
    var _pollRid   = 0;
    var _pollTimer = null;

    function _buildBubble(m) {
        var cls      = m.is_mine ? 'nsh-msg-mine' : '';
        var labelCol = m.is_mine ? 'inherit' : '#475569';
        var badge    = m.is_email_sent ? ' <span class="nsh-email-sent-badge">&#9993; Sent</span>' : '';
        var delBtn   = m.can_delete ? '<button class="nsh-del-msg nsh-btn-icon" data-id="'+m.id+'" title="Delete">&#128465;</button>' : '';
        return '<div class="nsh-msg-item '+cls+'" id="nrimsg-'+m.id+'" data-mid="'+m.id+'">'
            +'<div class="nsh-msg-meta-top">'
            +'<span style="font-weight:600;color:'+labelCol+';">'+esc(m.label)+'</span>'
            +'<span style="color:#94a3b8;font-size:11px;margin-left:6px;">'+esc(m.time)+'</span>'
            +badge+' '+delBtn
            +'</div>'
            +'<div class="nsh-msg-bubble">'+esc(m.message).replace(/\n/g,'<br>')+'</div>'
            +'</div>';
    }

    function _refreshMsgList(rid, scrollToBottom) {
        $.post(NSH.ajax_url, {
            action:     'nsh_get_messages_since',
            nonce:      NSH.nonce,
            request_id: rid,
            since_id:   0
        }, function(r) {
            var $list = $('#nsh-msgs-list');
            if (!$list.length) return;
            if (!r || !r.success) {
                console.error('[NSH Messages] Refresh failed:', r);
                return;
            }
            var msgs = r.data.messages || [];
            if (msgs.length === 0) {
                if (!$list.find('.nsh-msg-item').length) {
                    $list.html('<p class="nsh-hint" style="text-align:center;padding:20px;color:#94a3b8;">No messages yet. Send a message below.</p>');
                }
                return;
            }
            var html = '';
            $.each(msgs, function(i, m) { html += _buildBubble(m); });
            $list.html(html);
            if (scrollToBottom !== false) {
                $list.scrollTop($list[0].scrollHeight);
            }
        }).fail(function(xhr) {
            console.error('[NSH Messages] AJAX error:', xhr.status, xhr.responseText);
        });
    }

    function _startPoll(rid) {
        if (_pollTimer) { clearInterval(_pollTimer); _pollTimer = null; }
        _pollRid = rid;
        if (!_pollRid) return;
        // Refresh every 4 seconds
        _pollTimer = setInterval(function() {
            _refreshMsgList(_pollRid, true);
        }, 4000);
    }

    $(document).ready(function(){
        var rid = parseInt($('#nsh-msg-rid').val()) || 0;
        if (rid) {
            _startPoll(rid);
        }
        // Auto-scroll on load
        var $m = $('#nsh-msgs-list');
        if ($m.length) { $m.scrollTop($m[0].scrollHeight); }
    });

    function sendMsg(sendEmail) {
        var msg = $('#nsh-msg-text').val().trim();
        var rid = parseInt($('#nsh-msg-rid').val()) || 0;
        if (!msg) { alert('Please type a message.'); return; }
        if (!rid)  { alert('Request ID missing.'); return; }
        var $btn     = sendEmail ? $('#nsh-send-msg-email') : $('#nsh-send-msg');
        var origText = $btn.text();
        $btn.prop('disabled', true).text('Sending...');
        $('#nsh-send-msg,#nsh-send-msg-email').prop('disabled', true);

        $.post(NSH.ajax_url, {
            action:     'nsh_send_message',
            nonce:      NSH.nonce,
            request_id: rid,
            message:    msg,
            send_email: sendEmail ? 1 : 0
        }, function(r) {
            $('#nsh-send-msg,#nsh-send-msg-email').prop('disabled', false);
            $btn.text(origText);
            if (r.success) {
                $('#nsh-msg-text').val('');
                // Immediately refresh the full list so both the sender's bubble
                // appears and any messages from the other party are visible
                _refreshMsgList(rid, true);
            } else {
                alert(r.data && r.data.message ? r.data.message : 'Send failed. Please try again.');
            }
        }).fail(function() {
            $('#nsh-send-msg,#nsh-send-msg-email').prop('disabled', false);
            $btn.text(origText);
            alert('Connection error. Please try again.');
        });
    }

    $(document).on('click','#nsh-send-msg',       function(){ sendMsg(false); });
    $(document).on('click','#nsh-send-msg-email',  function(){ sendMsg(true);  });

    // Manual refresh button
    $(document).on('click','#nsh-refresh-msgs', function(){
        var rid = parseInt($(this).data('rid') || $('#nsh-msg-rid').val()) || 0;
        if (!rid) return;
        $(this).text('Loading...');
        var $self = $(this);
        _refreshMsgList(rid, true);
        setTimeout(function(){ $self.html('&#8635; Refresh'); }, 1500);
    });


    $(document).on('click','.nsh-del-msg',function(){
        if(!confirm('Delete this message?'))return;
        nshPost('nsh_delete_message',{id:$(this).data('id')},function(){$(this).closest('.nsh-msg-item').remove();}.bind(this),alert);
    });

    // Auto-scroll messages on load
    $(document).ready(function(){
        var $m=$('#nsh-msgs-list');
        if($m.length) $m.scrollTop($m[0].scrollHeight);
    });

    /* ═══════════════════════════════════════════════════════════
       SERVICE REQUESTS (TICKETS) on request detail
    ═══════════════════════════════════════════════════════════ */
    function loadTicketTypes(){
        var $cat=$('#nsh-ticket-cat');
        if($cat.find('option').length>1)return;
        $.post(NSH.ajax_url,{action:'nsh_get_request_types',nonce:NSH.nonce},function(r){
            if(!r.success)return;
            var h='<option value="">-- Select Category --</option>';
            $.each(r.data,function(i,t){h+='<option value="'+t.id+'" data-name="'+esc(t.name)+'">'+esc(t.icon)+' '+esc(t.name)+'</option>';});
            $cat.html(h);
        });
    }

    $(document).on('click','#nsh-new-ticket-btn',function(){
        loadTicketTypes();
        $('#nsh-ticket-modal').css('display','flex'); $('body').addClass('nsh-no-scroll');
    });
    $(document).on('click','#nsh-ticket-modal-close',function(){$('#nsh-ticket-modal').css('display','none');$('body').removeClass('nsh-no-scroll');});
    $(document).on('click','#nsh-ticket-modal',function(e){if($(e.target).is('#nsh-ticket-modal')){$('#nsh-ticket-modal').css('display','none');$('body').removeClass('nsh-no-scroll');}});

    $(document).on('click','#nsh-do-ticket',function(){
        var rid=$(this).data('rid');
        var $cat=$('#nsh-ticket-cat'), tid=$cat.val(), tname=$cat.find('option:selected').data('name')||$cat.find('option:selected').text();
        var notes=$('#nsh-ticket-notes').val();
        var email=$('#nsh-ticket-email').val();
        if(!tid){alert('Please select a category.');return;}
        $(this).text('Submitting…').prop('disabled',true);
        var self=$(this);
        $.post(NSH.ajax_url,{action:'nsh_submit_ticket',nonce:NSH.nonce,request_id:rid,type_id:tid,category:tname,notes:notes,email:email},
            function(r){self.text('Submit').prop('disabled',false);if(r.success){$('#nsh-ticket-modal').css('display','none');$('body').removeClass('nsh-no-scroll');location.reload();}else{$('#nsh-ticket-err').text(r.data&&r.data.message?r.data.message:'Failed.').show();}},
            function(){self.text('Submit').prop('disabled',false);$('#nsh-ticket-err').text('Connection error.').show();}
        );
    });

    // Ticket search filter
    $(document).on('input','#nsh-ticket-search',function(){
        var q=$(this).val().toLowerCase();
        $('#nsh-tickets-tbl tbody tr.nsh-ticket-row').each(function(){$(this).toggle($(this).text().toLowerCase().indexOf(q)!==-1);});
    });

    $(document).on('change','.nsh-ticket-status-sel',function(){
        nshPost('nsh_update_ticket_status',{id:$(this).data('id'),status:$(this).val()},null,alert);
    });
    $(document).on('click','.nsh-del-ticket',function(){
        if(!confirm('Delete this ticket?'))return;
        nshPost('nsh_delete_ticket',{id:$(this).data('id')},function(){location.reload();},alert);
    });

    /* ═══════════════════════════════════════════════════════════
       STAFF CONTROLS on request detail
    ═══════════════════════════════════════════════════════════ */
    // Staff panel toggle
    $(document).on('click','#nsh-staff-toggle',function(){
        $('#nsh-staff-body').slideToggle(200);
    });

    // Timeline mode toggle
    $(document).on('click','.nsh-tlt',function(){
        var mode=$(this).data('tl');
        $(this).closest('.nsh-tl-toggle').find('.nsh-tlt').removeClass('active');
        $(this).addClass('active');
        $('#nsh-tl-days-wrap').toggle(mode==='days'); $('#nsh-tl-date-wrap').toggle(mode==='date');
    });

    // Update status
    $(document).on('click','#nsh-do-status',function(){
        var rid=$(this).data('rid'), $b=$(this);
        $b.text('Saving…').prop('disabled',true);
        nshPost('nsh_update_status',{request_id:rid,status:$('#nsh-status-sel').val(),note:$('#nsh-status-note').val()},
            function(){$b.text('Update Status').prop('disabled',false);location.reload();},
            function(msg){$b.text('Update Status').prop('disabled',false);alert(msg);}
        );
    });

    // Set timeline
    $(document).on('click','#nsh-do-timeline',function(){
        var rid=$(this).data('rid'), $b=$(this);
        var mode=$('.nsh-tlt.active').data('tl')||'days';
        var payload={request_id:rid,mode:mode,note:$('#nsh-tl-note').val()};
        if(mode==='days'){payload.days=$('#nsh-tl-days').val();if(!payload.days||parseInt(payload.days)<1){alert('Enter number of days.');return;}}
        else{payload.date=$('#nsh-tl-date').val();if(!payload.date){alert('Select a date.');return;}}
        $b.text('Saving…').prop('disabled',true);
        nshPost('nsh_set_timeline',payload,function(){$b.text('Set Timeline').prop('disabled',false);location.reload();},function(msg){$b.text('Set Timeline').prop('disabled',false);alert(msg);});
    });

    // ── Save service charges (quote amount) — updates live total display ──────
    $(document).on('click','#nsh-do-quote',function(){
        var $btn=$(this), rid=$btn.data('rid');
        var amt=parseFloat($('#nsh-quote-amt').val())||0;
        $btn.text('Saving…').prop('disabled',true);
        nshPost('nsh_set_quote',{request_id:rid,amount:amt,send_quote_email:0,include_terms:0},
            function(){
                $btn.text('Saved ✓').prop('disabled',false);
                setTimeout(function(){$btn.text('Save');},2000);
                nshRefreshQuoteTotal();
            },
            function(msg){$btn.text('Save').prop('disabled',false);alert('Error: '+msg);}
        );
    });

    // ── Save shipping charges — updates live total display ───────────────────
    $(document).on('click','#nsh-do-shipping',function(){
        var $btn=$(this), rid=$btn.data('rid');
        var amount=parseFloat($('#nsh-shipping-amt').val())||0;
        var type=$('#nsh-shipping-type').val();
        $btn.text('Saving…').prop('disabled',true);
        $.post(NSH.ajax_url,{action:'nsh_set_shipping',nonce:NSH.admin_nonce,request_id:rid,amount:amount,type:type},function(r){
            $btn.text('Saved ✓').prop('disabled',false);
            setTimeout(function(){$btn.text('Save');},2000);
            if(r.success){ nshRefreshQuoteTotal(); }
            else { alert('Error: '+(r.data&&r.data.message?r.data.message:'Unknown error')); }
        }).fail(function(){ $btn.text('Save').prop('disabled',false); alert('Network error'); });
    });

    // ── Live total refresh ────────────────────────────────────────────────────
    function nshRefreshQuoteTotal(){
        var svc  = parseFloat($('#nsh-quote-amt').val())    || 0;
        var ship = parseFloat($('#nsh-shipping-amt').val()) || 0;
        var total = svc + ship;
        var fmt  = function(n){ return n.toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2}); };
        if(total > 0){
            $('#nsh-quote-total-val').text('₹'+fmt(total));
            $('#nsh-quote-total-breakdown').text('Service ₹'+fmt(svc)+' + Shipping ₹'+fmt(ship));
            $('#nsh-quote-total-box').show();
        } else {
            $('#nsh-quote-total-box').hide();
        }
    }

    // ── Dedicated "Send Quotation Email" button ───────────────────────────────
    $(document).on('click','#nsh-send-quote-btn',function(){
        var $btn=$(this), rid=$btn.data('rid');
        var inclTerms=$('#nsh-include-terms').is(':checked')?1:0;
        var svc  = parseFloat($('#nsh-quote-amt').val())    || 0;
        var ship = parseFloat($('#nsh-shipping-amt').val()) || 0;
        if(svc <= 0 && ship <= 0){
            alert('Please set at least one charge amount before sending the quotation email.');
            return;
        }
        if(!confirm('Send the quotation email to the client now?')) return;
        $btn.text('Sending…').prop('disabled',true);
        var $msg=$('#nsh-quote-email-msg');
        // First save current amounts, then send email
        nshPost('nsh_set_quote',{request_id:rid,amount:svc,send_quote_email:1,include_terms:inclTerms,notify_vendor:0},
            function(r){
                $btn.text('📧 Send Quotation Email to Client').prop('disabled',false);
                $msg.css({display:'block',color:'#16a34a',background:'#f0fdf4',padding:'6px 10px',borderRadius:'6px'})
                    .text('✓ Quotation email sent successfully!');
                nshRefreshQuoteTotal();
                setTimeout(function(){$msg.fadeOut(function(){$msg.hide().css('display','none');});},5000);
            },
            function(msg){
                $btn.text('📧 Send Quotation Email to Client').prop('disabled',false);
                $msg.css({display:'block',color:'#dc2626',background:'#fef2f2',padding:'6px 10px',borderRadius:'6px'})
                    .text('✗ '+msg);
            }
        );
    });

    // Set secondary status
    $(document).on('click','#nsh-do-sec-status',function(){
        var rid=$(this).data('rid'), val=$('#nsh-sec-status').val();
        nshPost('nsh_set_secondary_status',{request_id:rid,value:val},function(){alert('Saved.');},alert);
    });

    // Assign manager — explicit Save button
    $(document).on('click','#nsh-do-assign-mgr',function(){
        var rid=$(this).data('rid'), uid=$('#nsh-assign-mgr').val(), $b=$(this);
        if(!uid){alert('Please select a manager.');return;}
        $b.text('Saving…').prop('disabled',true);
        nshPost('nsh_assign_staff',{request_id:rid,type:'manager',user_id:uid},function(res){
            $b.text('Saved ✓').prop('disabled',false);
            if(res.data && res.data.name) $('#nsh-mgr-current').html('Currently assigned: <strong>'+res.data.name+'</strong>');
            setTimeout(function(){$b.text('Save Manager');},2000);
        },function(){$b.text('Save Manager').prop('disabled',false);alert('Error saving manager.');});
    });

    // Assign vendor — explicit Save button, handles both vp_ (vendor table) and wp_ (WP user)
    $(document).on('click','#nsh-do-assign-vendor',function(){
        var rid=$(this).data('rid'), raw=$('#nsh-assign-vendor').val(), $b=$(this);
        var $msg=$('#nsh-assign-msg');
        if(!raw){alert('Please select a vendor.');return;}
        var type='vendor', uid=raw;
        // Parse prefix: vp_ = vendor profile ID, wp_ = WP user ID
        var actual_uid=raw;
        if(raw.indexOf('vp_')===0) actual_uid=raw.substring(3);
        else if(raw.indexOf('wp_')===0) actual_uid=raw.substring(3);
        $b.text('Saving…').prop('disabled',true);
        $msg.hide();
        nshPost('nsh_assign_staff',{request_id:rid,type:'vendor',user_id:actual_uid,id_type:raw.indexOf('vp_')===0?'vendor_profile':'wp_user'},function(res){
            $b.text('Save Vendor').prop('disabled',false);
            var name=res.data && res.data.name ? res.data.name : 'Vendor';
            $('#nsh-vendor-current').html('Currently assigned: <strong>'+name+'</strong>');
            $msg.css({'background':'#d1fae5','color':'#065f46','display':'block'}).text('✅ Vendor saved! WhatsApp notification sent.');
            setTimeout(function(){$msg.hide();},4000);
        },function(){$b.text('Save Vendor').prop('disabled',false);$msg.css({'background':'#fee2e2','color':'#991b1b','display':'block'}).text('Error saving vendor.');});
    });

    // Save internal note
    $(document).on('click','#nsh-do-save-note',function(){
        var rid=$(this).data('rid'), $b=$(this);
        $b.text('Saving…').prop('disabled',true);
        nshPost('nsh_save_note',{request_id:rid,note:$('#nsh-int-notes').val()},
            function(){$b.text('Saved ✓').prop('disabled',false);setTimeout(function(){$b.text('Save Note');},2000);},
            function(msg){$b.text('Save Note').prop('disabled',false);alert(msg);}
        );
    });

    /* ═══════════════════════════════════════════════════════════
       ADMIN: FORM FIELDS TAB
    ═══════════════════════════════════════════════════════════ */
    // Services2NRI-derived services each have their own field set (see
    // nsh_admin_tab_fields() in shortcodes.php) — this filters the already-
    // rendered table by data-service-id instead of re-querying the server,
    // and keeps the "Add Field" form scoped to whichever service is picked.
    $(document).on('change','#nsh-fields-service-filter',function(){
        var sid = $(this).val();
        $('#nf-service-id').val(sid);
        $('#nsh-fields-tbody tr').each(function(){
            $(this).toggle(String($(this).data('service-id')) === String(sid));
        });
    });

    $(document).on('click','#nsh-add-field-btn',function(){
        // Reset form
        $('#nf-id,#nf-key').val(''); $('#nf-label,#nf-placeholder,#nf-opts,#nf-description').val('');
        $('#nf-type').val('text'); $('#nf-step').val('1'); $('#nf-required').val('0'); $('#nf-active').val('1');
        $('#nf-service-id').val($('#nsh-fields-service-filter').val());
        $('#nf-opts-wrap').hide(); $('#nsh-field-msg').hide();
        // Reset conditional logic
        $('#nf-cond-enabled').prop('checked', false); $('#nf-cond-panel').hide();
        $('#nf-cond-action').val('all'); $('#nf-cond-rules').empty();
        $('#nsh-add-field-panel').slideToggle(200);
    });
    $(document).on('click','#nsh-cancel-field',function(){$('#nsh-add-field-panel').slideUp(200);});

    $(document).on('change','#nf-type',function(){
        $('#nf-opts-wrap').toggle(['dropdown','select','checkbox','radio','searchable'].indexOf($(this).val())!==-1);
    });
    // FIX 8: number field is handled like text in render, just needs correct HTML type
    $(document).on('input','#nf-label',function(){
        if(!$('#nf-id').val()) $('#nf-key').val($(this).val().toLowerCase().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,''));
    });

    // Toggle conditional logic panel - use click on the label too for safety
    $(document).on('change click','#nf-cond-enabled',function(e){
        if(e.type==='click' && $(this).is(':checkbox')) return; // let change handle it
        var checked = $(this).is(':checked');
        if(checked){
            $('#nf-cond-panel').slideDown(200);
            if(!$('#nf-cond-rules .nsh-cond-row').length) nshAddCondRule();
        } else {
            $('#nf-cond-panel').slideUp(200);
        }
    });

    // Build one condition rule row
    function nshAllFieldOptions() {
        var opts = '<option value="">-- select field --</option>';
        var seen = {};

        // PRIMARY: Use the embedded JS map (always available when fields tab is open)
        var fieldMap = window.NSH_FIELD_MAP || {};
        Object.keys(fieldMap).forEach(function(key) {
            if (!seen[key]) {
                seen[key] = true;
                var label = fieldMap[key].label || key;
                opts += '<option value="' + key + '">' + label + ' [' + key + ']</option>';
            }
        });

        // FALLBACK: scan the rendered fields table rows
        if (Object.keys(seen).length === 0) {
            $('#nsh-fields-tbody tr').each(function(){
                var $btn  = $(this).find('.nsh-edit-field');
                var key   = $btn.data('key')   || $btn.attr('data-key');
                var label = $btn.data('label') || $btn.attr('data-label') || key;
                if (key && !seen[key]) {
                    seen[key] = true;
                    opts += '<option value="' + key + '">' + label + ' [' + key + ']</option>';
                }
            });
        }
        return opts;
    }

    function nshOperatorOptions() {
        return '<option value="equals">is equal to</option>'
             + '<option value="not_equals">is not equal to</option>'
             + '<option value="contains">contains</option>'
             + '<option value="not_contains">does not contain</option>'
             + '<option value="starts_with">starts with</option>'
             + '<option value="ends_with">ends with</option>'
             + '<option value="is_empty">is empty</option>'
             + '<option value="is_not_empty">is not empty</option>'
             + '<option value="greater_than">greater than</option>'
             + '<option value="less_than">less than</option>';
    }

    function nshAddCondRule(rule) {
        rule = rule || {};
        var row = '<div class="nsh-cond-row" style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:10px;background:#fff;border:1px solid #e2e8f0;border-radius:8px;">'
            + '<select class="nsh-cr-field" style="padding:6px 10px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;min-width:160px;">'+nshAllFieldOptions()+'</select>'
            + '<select class="nsh-cr-op" style="padding:6px 10px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;">'+nshOperatorOptions()+'</select>'
            + '<span class="nsh-cr-val-wrap" style="flex:1;min-width:120px;"><input class="nsh-cr-val" type="text" placeholder="Enter value..." style="width:100%;padding:6px 10px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;"></span>'
            + '<button type="button" class="nsh-btn nsh-btn-danger nsh-btn-sm nsh-cr-del" style="flex-shrink:0;">&#10005;</button>'
            + '</div>';
        var $row = $(row);

        // Helper: update value input based on selected field
        function updateValueField(fieldKey, existingValue) {
            var $wrap = $row.find('.nsh-cr-val-wrap');
            var $op   = $row.find('.nsh-cr-op');
            if (!fieldKey) { return; }
            if (['is_empty','is_not_empty'].indexOf($op.val()) !== -1) { return; }

            // Use the embedded field map (no AJAX needed - always available)
            var fieldMap = window.NSH_FIELD_MAP || {};
            var fieldData = fieldMap[fieldKey];

            if (fieldData && fieldData.options && fieldData.options.length > 0) {
                // Field has predefined options - render a select dropdown
                var sel = '<select class="nsh-cr-val" style="width:100%;padding:8px 10px;border:1px solid #bfdbfe;border-radius:6px;font-size:13px;background:#fff;">';
                sel += '<option value="">-- Select value --</option>';
                fieldData.options.forEach(function(opt) {
                    var selected = (existingValue && existingValue === opt) ? ' selected' : '';
                    sel += '<option value="' + opt + '"' + selected + '>' + opt + '</option>';
                });
                sel += '</select>';
                $wrap.html(sel);
            } else {
                // No predefined options - text input
                var current = $wrap.find('.nsh-cr-val').val() || existingValue || '';
                $wrap.html('<input class="nsh-cr-val" type="text" placeholder="Enter value..." style="width:100%;padding:8px 10px;border:1px solid #e2e8f0;border-radius:6px;font-size:13px;" value="' + current + '">');
            }
        }

        // Set initial values
        if (rule.field) { $row.find('.nsh-cr-field').val(rule.field); }
        if (rule.operator) { $row.find('.nsh-cr-op').val(rule.operator); }

        // Load options for the pre-selected field (when editing an existing rule)
        if (rule.field) {
            updateValueField(rule.field, rule.value || '');
        } else if (rule.value) {
            $row.find('.nsh-cr-val').val(rule.value);
        }

        // When field selector changes → fetch options for newly chosen field
        $row.find('.nsh-cr-field').on('change', function() {
            updateValueField($(this).val(), '');
        });

        // When operator changes → hide/show value field
        $row.find('.nsh-cr-op').on('change', function() {
            var hide = ['is_empty','is_not_empty'].indexOf($(this).val()) !== -1;
            $row.find('.nsh-cr-val-wrap').toggle(!hide);
        }).trigger('change');

        $('#nf-cond-rules').append($row);
    }

    $(document).on('click','#nf-cond-add-rule',function(){ nshAddCondRule(); });
    $(document).on('click','.nsh-cr-del',function(){ $(this).closest('.nsh-cond-row').remove(); });

    function nshGetConditions() {
        if(!$('#nf-cond-enabled').is(':checked')) return null;
        var rules = [];
        $('#nf-cond-rules .nsh-cond-row').each(function(){
            var field = $(this).find('.nsh-cr-field').val();
            var op    = $(this).find('.nsh-cr-op').val();
            var val   = $(this).find('.nsh-cr-val').val().trim();
            if(field) rules.push({field:field, operator:op, value:val});
        });
        if(!rules.length) return null;
        return {action: $('#nf-cond-action').val(), rules: rules};
    }

    $(document).on('click','.nsh-edit-field',function(){
        var $b=$(this);
        $('#nf-id').val($b.data('id'));
        $('#nf-service-id').val($b.data('service-id'));
        $('#nf-label').val($b.data('label'));
        $('#nf-key').val($b.data('key'));
        $('#nf-type').val($b.data('type'));
        $('#nf-step').val($b.data('step'));
        $('#nf-required').val($b.data('required'));
        $('#nf-active').val($b.data('active'));
        $('#nf-placeholder').val($b.data('ph'));
        $('#nf-description').val($b.data('desc') || '');
        $('#nf-opts').val($b.data('opts'));
        $('#nf-opts-wrap').toggle(['dropdown','select','checkbox','radio','searchable'].indexOf($b.data('type'))!==-1);
        $('#nsh-field-msg').hide();
        // Load conditional logic
        $('#nf-cond-rules').empty();
        var condRaw = $b.data('conditions');
        var condData = null;
        if(condRaw) { try { condData = typeof condRaw === 'string' ? JSON.parse(condRaw) : condRaw; } catch(e){} }
        if(condData && condData.rules && condData.rules.length) {
            $('#nf-cond-enabled').prop('checked', true);
            $('#nf-cond-panel').show();
            $('#nf-cond-action').val(condData.action || 'all');
            $.each(condData.rules, function(i, rule){ nshAddCondRule(rule); });
        } else {
            $('#nf-cond-enabled').prop('checked', false);
            $('#nf-cond-panel').hide();
        }
        $('#nsh-add-field-panel').slideDown(200);
        $('html,body').animate({scrollTop:$('#nsh-add-field-panel').offset().top-20},200);
    });

    $(document).on('click','#nsh-do-save-field',function(){
        var $msg=$('#nsh-field-msg'), label=$('#nf-label').val().trim(), key=$('#nf-key').val().trim(), id=$('#nf-id').val();
        if(!label){showMsg($msg,'error','Label is required.');return;}
        if(!key&&!id){showMsg($msg,'error','Key is required.');return;}
        $msg.hide();
        var conditions = nshGetConditions();
        var data={label:label,key:key,type:$('#nf-type').val(),step:$('#nf-step').val(),required:$('#nf-required').val(),
                  options:$('#nf-opts').val(),placeholder:$('#nf-placeholder').val(),
                  description:$('#nf-description').val(),active:$('#nf-active').val(),
                  service_id:$('#nf-service-id').val(),
                  conditions: conditions ? JSON.stringify(conditions) : ''};
        if(id)data.id=id;
        nshPost('nsh_save_field',data,
            function(){showMsg($msg,'success','Saved! Reloading…');setTimeout(function(){location.reload();},1500);},
            function(msg){showMsg($msg,'error',msg);}
        );
    });

    $(document).on('click','.nsh-del-field',function(){
        if(!confirm('Delete this field permanently?'))return;
        nshPost('nsh_delete_field',{id:$(this).data('id')},function(){location.reload();},alert);
    });

    /* ═══════════════════════════════════════════════════════════
       ADMIN: DROPDOWN DATA TAB  (full CRUD with pagination)
    ═══════════════════════════════════════════════════════════ */
    var _ddKey='', _ddPage=1, _ddSearch='';

    $(document).on('change','#nsh-dd-fkey',function(){
        _ddKey=$(this).val(); _ddPage=1; _ddSearch=''; $('#nsh-dd-search').val('');
        if(!_ddKey){$('#nsh-dd-table-wrap,#nsh-dd-form,#nsh-dd-empty').hide();$('#nsh-dd-btns').css('display','none');return;}
        $('#nsh-dd-btns').css('display','flex'); $('#nsh-dd-form').hide();
        loadDdOptions();
    });
    $(document).on('input','#nsh-dd-search',function(){
        _ddSearch=$(this).val(); _ddPage=1;
        clearTimeout(window._ddSt); window._ddSt=setTimeout(loadDdOptions,300);
    });

    function loadDdOptions(){
        $('#nsh-dd-table-wrap').show(); $('#nsh-dd-empty').hide();
        var $body=$('#nsh-dd-tbody');
        $body.html('<tr><td colspan="4" class="nsh-tbl-loading">Loading…</td></tr>');
        nshPost('nsh_get_options_paged',{field_key:_ddKey,search:_ddSearch,page:_ddPage},function(d){
            if(!d.rows||!d.rows.length){
                $body.html('<tr><td colspan="4" class="nsh-tbl-empty">No options found.</td></tr>');
                $('#nsh-dd-pages').html(''); return;
            }
            var rows='';
            $.each(d.rows,function(i,o){
                rows+='<tr data-id="'+o.id+'">'
                    +'<td><input type="checkbox" class="nsh-dd-cb" value="'+o.id+'"></td>'
                    +'<td style="color:#94a3b8;font-size:12px;">'+((_ddPage-1)*50+i+1)+'</td>'
                    +'<td>'+esc(o.option_value)+'</td>'
                    +'<td><button class="nsh-btn nsh-btn-sm nsh-btn-outline nsh-dd-edit" data-id="'+o.id+'" data-val="'+esc(o.option_value)+'">Edit</button> '
                    +'<button class="nsh-btn nsh-btn-sm nsh-btn-danger nsh-dd-del" data-id="'+o.id+'">Del</button></td>'
                    +'</tr>';
            });
            $body.html(rows);
            // Pagination
            var pg='<span style="font-size:13px;color:#64748b;margin-right:8px;">'+d.total+' total</span>';
            for(var p=1;p<=d.pages;p++) pg+='<button class="nsh-btn nsh-btn-sm '+(p===_ddPage?'nsh-btn-primary':'nsh-btn-ghost')+' nsh-dd-go-pg" data-p="'+p+'">'+p+'</button> ';
            $('#nsh-dd-pages').html(pg);
            updateDdBulkCount();
        },function(msg){$body.html('<tr><td colspan="4" class="nsh-tbl-empty">Error: '+esc(msg)+'</td></tr>');});
    }

    $(document).on('click','.nsh-dd-go-pg',function(){_ddPage=parseInt($(this).data('p'));loadDdOptions();});

    // Select all
    $(document).on('change','#nsh-dd-all',function(){$('.nsh-dd-cb').prop('checked',$(this).is(':checked'));updateDdBulkCount();});
    $(document).on('change','.nsh-dd-cb',updateDdBulkCount);
    function updateDdBulkCount(){
        var n=$('.nsh-dd-cb:checked').length;
        $('#nsh-dd-sel-count').text(n>0?n+' selected':'');
        $('#nsh-dd-bulk-del').toggle(n>0);
    }

    // Add button
    $(document).on('click','#nsh-dd-add-btn',function(){
        $('#nsh-dd-edit-id').val(''); $('#nsh-dd-val').val('');
        $('#nsh-dd-form-title').text('Add Option'); $('#nsh-dd-form-msg').hide();
        $('#nsh-dd-form').slideDown(200); $('#nsh-dd-val').focus();
    });
    $(document).on('click','#nsh-dd-cancel',function(){$('#nsh-dd-form').slideUp(200);});

    // Save option
    $(document).on('click','#nsh-dd-do-save',function(){
        var val=$('#nsh-dd-val').val().trim(), editId=$('#nsh-dd-edit-id').val(), $msg=$('#nsh-dd-form-msg');
        if(!val){showMsg($msg,'error','Value required.');return;}
        $msg.hide();
        var data=editId?{id:editId,value:val}:{field_key:_ddKey,value:val};
        nshPost('nsh_save_option',data,
            function(){showMsg($msg,'success',editId?'Updated.':'Added.');$('#nsh-dd-val').val('');loadDdOptions();if(editId)setTimeout(function(){$('#nsh-dd-form').slideUp(200);},1000);},
            function(msg){showMsg($msg,'error',msg);}
        );
    });

    // Edit button
    $(document).on('click','.nsh-dd-edit',function(){
        $('#nsh-dd-edit-id').val($(this).data('id'));
        $('#nsh-dd-val').val($(this).data('val'));
        $('#nsh-dd-form-title').text('Edit Option'); $('#nsh-dd-form-msg').hide();
        $('#nsh-dd-form').slideDown(200); $('#nsh-dd-val').focus();
    });

    // Single delete
    $(document).on('click','.nsh-dd-del',function(){
        if(!confirm('Delete this option?'))return;
        nshPost('nsh_delete_option',{id:$(this).data('id')},loadDdOptions,alert);
    });

    // Bulk delete
    $(document).on('click','#nsh-dd-bulk-del',function(){
        var ids=[]; $('.nsh-dd-cb:checked').each(function(){ids.push($(this).val());});
        if(!ids.length)return;
        if(!confirm('Delete '+ids.length+' option(s)?'))return;
        nshPost('nsh_bulk_delete_options',{ids:ids},function(){$('#nsh-dd-all').prop('checked',false);loadDdOptions();},alert);
    });

    /* ═══════════════════════════════════════════════════════════
       ADMIN: BULK IMPORT TAB
    ═══════════════════════════════════════════════════════════ */
    // Method tabs
    $(document).on('click','.nsh-bulk-tab',function(){
        var bt=$(this).data('bt');
        $('.nsh-bulk-tab').removeClass('active'); $(this).addClass('active');
        $('.nsh-bulk-pane').hide(); $('#nsh-bt-'+bt).show();
        $('#nsh-bulk-msg').hide();
    });

    // CSV file
    $(document).on('dragover','#nsh-csv-drop',function(e){e.preventDefault();$(this).css({borderColor:'#2563eb',background:'#eff6ff'});});
    $(document).on('dragleave','#nsh-csv-drop',function(){$(this).css({borderColor:'',background:''});});
    $(document).on('drop','#nsh-csv-drop',function(e){e.preventDefault();$(this).css({borderColor:'',background:''});var f=e.originalEvent.dataTransfer.files[0];if(f)previewCsv(f);});
    $(document).on('change','#nsh-csv-file',function(){if(this.files[0])previewCsv(this.files[0]);});

    function previewCsv(file){
        $('#nsh-do-csv-import').prop('disabled',false);
        if(file.name.match(/\.(csv|txt)$/i)){
            var r=new FileReader(); r.onload=function(e){
                var lines=e.target.result.split(/\r\n|\r|\n/).map(function(l){return l.trim();}).filter(Boolean);
                var $list=$('#nsh-csv-prev-list').empty();
                lines.slice(0,5).forEach(function(l){$list.append('<li style="margin-bottom:3px;">'+esc(l)+'</li>');});
                if(lines.length>5)$list.append('<li style="color:#94a3b8;">…and '+(lines.length-5)+' more</li>');
                $('#nsh-csv-total').text('Total: '+lines.length+' values');
                $('#nsh-csv-preview').show();
            }; r.readAsText(file);
        }
    }

    $(document).on('click','#nsh-do-csv-import',function(){
        var key=$('#nsh-bulk-fkey').val(), mode=$('#nsh-bulk-mode').val(), file=document.getElementById('nsh-csv-file').files[0];
        if(!key){alert('Select a target field.');return;} if(!file){alert('Select a CSV file.');return;}
        var $btn=$(this),$msg=$('#nsh-bulk-msg'); $btn.text('Importing…').prop('disabled',true); $msg.hide();
        var fd=new FormData(); fd.append('action','nsh_bulk_import'); fd.append('nonce',nonce()); fd.append('field_key',key); fd.append('mode',mode); fd.append('csv_file',file);
        $.ajax({url:NSH.ajax_url,type:'POST',data:fd,processData:false,contentType:false,
            success:function(r){$btn.text('Import File').prop('disabled',false);$msg.removeClass('nsh-alert-error nsh-alert-success').addClass('nsh-alert').show();if(r.success)$msg.addClass('nsh-alert-success').text('Imported '+r.data.imported+' values ('+r.data.mode+' mode).');else$msg.addClass('nsh-alert-error').text(r.data&&r.data.message?r.data.message:'Import failed.');},
            error:function(){$btn.text('Import File').prop('disabled',false);$msg.addClass('nsh-alert nsh-alert-error').text('Connection error.').show();}
        });
    });

    // Paste format pills
    $(document).on('click','.nsh-fp',function(){
        var fmt=$(this).data('fmt');
        $('.nsh-fp').removeClass('active'); $(this).addClass('active');
        var ph={lines:'One value per line:\nUniversity of Delhi\nAnna University',comma:'Comma-separated: Value1, Value2, Value3',json:'JSON: ["Value1","Value2","Value3"]'};
        $('#nsh-paste-data').attr('placeholder',ph[fmt]||'');
        $('#nsh-paste-preview').hide(); $('#nsh-do-paste-import').prop('disabled',true);
    });

    $(document).on('click','#nsh-parse-paste',function(){
        var raw=$('#nsh-paste-data').val().trim(), fmt=$('.nsh-fp.active').data('fmt')||'lines', $err=$('#nsh-paste-err');
        $err.hide();
        if(!raw){$err.text('Paste some data first.').show();return;}
        var vals=[];
        if(fmt==='json'){try{var a=JSON.parse(raw);if(!Array.isArray(a))throw 0;$.each(a,function(i,v){if(String(v).trim())vals.push(String(v).trim());});}catch(e){$err.text('Invalid JSON. Use format: ["val1","val2"]').show();return;}}
        else if(fmt==='comma'){vals=raw.split(',').map(function(v){return v.trim();}).filter(Boolean);}
        else{vals=raw.split(/\r\n|\r|\n/).map(function(v){return v.trim();}).filter(Boolean);}
        vals=vals.filter(function(v,i,a){return a.indexOf(v)===i;});
        if(!vals.length){$err.text('No valid values found.').show();return;}
        var $list=$('#nsh-paste-prev-list').empty();
        vals.slice(0,5).forEach(function(v){$list.append('<div style="padding:2px 0;border-bottom:1px solid #f1f5f9;font-size:13px;">'+esc(v)+'</div>');});
        if(vals.length>5)$list.append('<div style="color:#94a3b8;font-size:12px;margin-top:4px;">…and '+(vals.length-5)+' more</div>');
        $('#nsh-paste-count').text(vals.length+' unique values');
        $('#nsh-paste-preview').show(); $('#nsh-do-paste-import').prop('disabled',false);
    });

    $(document).on('click','#nsh-do-paste-import',function(){
        var key=$('#nsh-bulk-fkey').val(), mode=$('#nsh-bulk-mode').val(), raw=$('#nsh-paste-data').val().trim(), fmt=$('.nsh-fp.active').data('fmt')||'lines';
        if(!key){alert('Select a target field.');return;} if(!raw){alert('Paste some data first.');return;}
        var $btn=$(this),$msg=$('#nsh-bulk-msg'); $btn.text('Importing…').prop('disabled',true); $msg.hide();
        nshPost('nsh_bulk_import',{field_key:key,mode:mode,raw_data:raw,format:fmt},
            function(d){$btn.text('Import').prop('disabled',false);showMsg($msg,'success','Imported '+d.imported+' values ('+d.mode+' mode).');},
            function(msg){$btn.text('Import').prop('disabled',false);showMsg($msg,'error',msg);}
        );
    });

    /* ═══════════════════════════════════════════════════════════
       ADMIN: REQUEST TYPES TAB
    ═══════════════════════════════════════════════════════════ */
    $(document).on('click','#nsh-add-type-btn',function(){
        $('#nsh-type-id').val(''); $('#nsh-type-name,#nsh-type-desc').val(''); $('#nsh-type-icon').val('📄');
        $('#nsh-type-form-title').text('Add Type'); $('#nsh-type-msg').hide();
        $('#nsh-type-form').slideToggle(200);
    });
    $(document).on('click','#nsh-cancel-type',function(){$('#nsh-type-form').slideUp(200);});

    $(document).on('click','.nsh-edit-type',function(){
        var $b=$(this);
        $('#nsh-type-id').val($b.data('id')); $('#nsh-type-name').val($b.data('name'));
        $('#nsh-type-icon').val($b.data('icon')); $('#nsh-type-desc').val($b.data('desc'));
        $('#nsh-type-form-title').text('Edit Type'); $('#nsh-type-msg').hide();
        $('#nsh-type-form').slideDown(200);
        $('html,body').animate({scrollTop:$('#nsh-type-form').offset().top-20},200);
    });

    $(document).on('click','#nsh-do-save-type',function(){
        var name=$('#nsh-type-name').val().trim(), $msg=$('#nsh-type-msg');
        if(!name){showMsg($msg,'error','Name required.');return;}
        $msg.hide();
        nshPost('nsh_save_request_type',{id:$('#nsh-type-id').val(),name:name,icon:$('#nsh-type-icon').val(),description:$('#nsh-type-desc').val()},
            function(){showMsg($msg,'success','Saved! Reloading…');setTimeout(function(){location.reload();},1500);},
            function(msg){showMsg($msg,'error',msg);}
        );
    });

    $(document).on('click','.nsh-del-type',function(){
        if(!confirm('Delete this request type?'))return;
        nshPost('nsh_delete_request_type',{id:$(this).data('id')},function(){location.reload();},alert);
    });

    // Services multiselect: select-all checkbox
    $(document).on('change','#nsh-type-sel-all',function(){
        var checked=$(this).is(':checked');
        $('.nsh-type-chk').prop('checked',checked);
        nshUpdateTypeToolbar();
    });
    // Services multiselect: individual checkbox
    $(document).on('change','.nsh-type-chk',function(){
        nshUpdateTypeToolbar();
        var total=$('.nsh-type-chk').length, checked=$('.nsh-type-chk:checked').length;
        $('#nsh-type-sel-all').prop('indeterminate', checked>0 && checked<total);
        $('#nsh-type-sel-all').prop('checked', checked===total && total>0);
    });
    function nshUpdateTypeToolbar(){
        var n=$('.nsh-type-chk:checked').length;
        var $bar=$('#nsh-type-bulk-bar');
        if(n>0){
            $bar.css('display','flex');
            $('#nsh-type-bulk-count').text(n+' service'+(n>1?'s':'')+' selected');
        } else {
            $bar.hide();
        }
    }
    // Bulk delete selected services
    $(document).on('click','#nsh-type-bulk-del',function(){
        var ids=[]; $('.nsh-type-chk:checked').each(function(){ids.push($(this).data('id'));});
        if(!ids.length){alert('No services selected.');return;}
        if(!confirm('Delete '+ids.length+' selected service type'+(ids.length>1?'s':'')+' permanently?'))return;
        var pending=ids.length, errors=0;
        ids.forEach(function(id){
            nshPost('nsh_delete_request_type',{id:id},function(){
                pending--;
                if(pending===0){ if(errors===0) location.reload(); else alert(errors+' deletion(s) failed.'); }
            },function(){
                errors++; pending--;
                if(pending===0) alert(errors+' deletion(s) failed.');
            });
        });
    });
    // Clear selection
    $(document).on('click','#nsh-type-bulk-clear',function(){
        $('.nsh-type-chk, #nsh-type-sel-all').prop('checked',false).prop('indeterminate',false);
        $('#nsh-type-bulk-bar').hide();
    });

    /* ═══════════════════════════════════════════════════════════
       ADMIN: SETTINGS TAB
    ═══════════════════════════════════════════════════════════ */
    /* Dashboards & Access: collects the form (inputs, checkboxes, role/tab check-lists) and posts it to nsh_plat_save; the server validates every address */
    $(document).on('click','#nsh-plat-save',function(){
        var $b=$(this), $m=$('#nsh-plat-msg'), d={};
        $('#nsh-plat-form .nsh-plat-inp').each(function(){ d[$(this).data('k')]=$(this).val(); });
        $('#nsh-plat-form .nsh-plat-chk').each(function(){ d[$(this).data('k')]=this.checked?1:0; });
        $('#nsh-plat-form fieldset[data-roles]').each(function(){ var k=$(this).data('roles'); d[k]=$(this).find('input:checked').map(function(){return this.value;}).get(); if(!d[k].length){ d[k]=['']; } });
        $b.prop('disabled',true).text('Saving…'); $m.text('').css('color','');
        nshPost('nsh_plat_save',d,function(r){
            $b.prop('disabled',false).text('Save dashboard settings'); $m.css('color','#166534').text(r.message);
            var u=r.urls||{}; var map={'sign-in':u.login,'client-dashboard':u.client,'admin-dashboard':u.admin,'staff-dashboard':u.staff};
            Object.keys(map).forEach(function(k){ var $li=$('#nsh-plat-url-'+k); if($li.length&&map[k]){ $li.find('a').attr('href',map[k]).text(map[k]); } });
        },function(msg){ $b.prop('disabled',false).text('Save dashboard settings'); $m.css('color','#b91c1c').text(msg); });
    });

    $(document).on('click','#nsh-save-settings-btn',function(){
        var data={}, $btn=$(this), $msg=$('#nsh-settings-msg');
        $('.nsh-setting-inp').each(function(){data[$(this).data('key')]=$(this).val();});
        $btn.text('Saving…').prop('disabled',true); $msg.hide();
        nshPost('nsh_save_settings',data,
            function(){showMsg($msg,'success','Settings saved!');$btn.text('Save Settings').prop('disabled',false);},
            function(msg){showMsg($msg,'error',msg);$btn.text('Save Settings').prop('disabled',false);}
        );
    });

})(jQuery);

/* ============================================================
   PROFILE FORM
   ============================================================ */
(function($){

$(document).on('submit','#nsh-profile-form',function(e){
    e.preventDefault();
    var $f=$(this),$msg=$('#nsh-profile-msg');
    $msg.hide().removeClass('nsh-alert-success nsh-alert-error');
    $.ajax({url:NSH.ajax_url,type:'POST',data:{
        action:'nsh_update_profile',nonce:NSH.nonce,
        display_name:$f.find('[name=display_name]').val(),
        phone:$f.find('[name=phone]').val(),
        address:$f.find('[name=address]').val(),
        new_password:$f.find('[name=new_password]').val(),
        confirm_password:$f.find('[name=confirm_password]').val()
    },success:function(r){
        $msg.addClass('nsh-alert '+(r.success?'nsh-alert-success':'nsh-alert-error'))
            .text(r.success?(r.data&&r.data.message?r.data.message:'Saved!'):(r.data&&r.data.message?r.data.message:'Error.')).show();
    }});
});

/* ============================================================
   SUPPORT MODAL (New Service Request on client dash)
   ============================================================ */
$(document).on('click','#nsh-new-sr-btn,#nsh-new-sr-btn2,#nsh-nav-new-req',function(){
    $('#nsh-sr-modal').css('display','flex');
    $('body').addClass('nsh-no-scroll');
});

$(document).on('submit','#nsh-support-form',function(e){
    e.preventDefault();
    var $f=$(this),$btn=$f.find('[type=submit]'),$err=$('#nsh-support-err');
    $btn.text('Submitting...').prop('disabled',true);$err.hide();
    var fd=new FormData($f[0]);
    fd.append('action','nsh_submit_support');fd.append('nonce',NSH.nonce);
    $.ajax({url:NSH.ajax_url,type:'POST',data:fd,processData:false,contentType:false,timeout:20000,
        success:function(r){
            $btn.text('Submit Request').prop('disabled',false);
            if(r.success){
                $f[0].reset();
                $err.removeClass('nsh-alert-error').addClass('nsh-alert nsh-alert-success')
                    .text('Your request has been submitted! Our team will respond shortly.').show();
                setTimeout(function(){
                    $('#nsh-sr-modal').css('display','none');
                    $('body').removeClass('nsh-no-scroll');
                    $err.hide().removeClass('nsh-alert-success');
                }, 2500);
            }else{$err.addClass('nsh-alert nsh-alert-error').text(r.data&&r.data.message?r.data.message:'Submission failed. Please try again.').show();}
        },
        error:function(xhr,status){
            $btn.text('Submit Request').prop('disabled',false);
            var msg=status==='timeout'?'Request timed out. Please try again.':'Connection error. Please try again.';
            $err.addClass('nsh-alert nsh-alert-error').text(msg).show();
        }
    });
});

/* ============================================================
   COPY REQUEST DETAILS / COPY STUDENT REQUIREMENT DESCRIPTION
   ------------------------------------------------------------
   Two compact card/detail actions: "Copy Details" copies exactly what
   the card already shows (Applicant -> Mobile -> Document/Academic ->
   Location & Delivery -> Timeline -> Remarks), read straight from the
   rendered .nsh-rc-fields block so it can never drift out of sync with
   what's on screen. "Copy Description" copies the internally-generated
   Student Requirement Description (see nsh_generate_requirement_
   description() in helpers.php — a deterministic rule engine, not an
   external AI call). Both work via AJAX/DOM only: no page reload, no
   scroll change, and no interference with the card's own "View" click.
   ============================================================ */
function nshCopyText(text){
    if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text);
    }
    return new Promise(function(resolve, reject){
        try {
            var ta = document.createElement('textarea');
            ta.value = text;
            ta.style.position = 'fixed';
            ta.style.left = '-9999px';
            ta.style.top = '-9999px';
            document.body.appendChild(ta);
            ta.focus(); ta.select();
            var ok = document.execCommand('copy');
            document.body.removeChild(ta);
            if (ok) { resolve(); } else { reject(new Error('execCommand copy failed')); }
        } catch (err) { reject(err); }
    });
}
function nshFlashCopied($btn){
    var orig = $btn.data('nsh-orig-html');
    if (orig === undefined) { orig = $btn.html(); $btn.data('nsh-orig-html', orig); }
    clearTimeout($btn.data('nsh-copy-timer'));
    $btn.html('Copied &#10003;').addClass('nsh-copied-flash');
    var t = setTimeout(function(){ $btn.html(orig).removeClass('nsh-copied-flash'); }, 1400);
    $btn.data('nsh-copy-timer', t);
}
// Builds the plain-text "Copy Details" payload from a card's rendered
// .nsh-rc-fields block — the same grouped Applicant/Document & Academic/
// Location & Delivery/Remarks HTML built server-side by
// nsh_render_request_card_fields() (helpers.php). Reading it from the
// DOM (rather than re-fetching field data) guarantees the copied text
// always matches exactly what's currently displayed on the card.
function nshBuildCopyDetailsText($scope){
    var lines = [];
    $scope.find('.nsh-rc-fields .nsh-rc-pair').each(function(){
        var $p = $(this);
        var label = $p.find('.nsh-rc-lbl').first().text().replace(/:\s*$/, '').trim();
        var val = $p.clone().find('.nsh-rc-lbl').remove().end().text().replace(/\s+/g, ' ').trim();
        if (label && val) { lines.push(label + ': ' + val); }
    });
    $scope.find('.nsh-rc-fields .nsh-rc-remarks').each(function(){
        var $r = $(this);
        var label = $r.find('.nsh-rc-lbl').first().text().replace(/:\s*$/, '').trim();
        var val = $r.find('.nsh-rc-val').first().text().trim();
        if (label && val) { lines.push(label + ': ' + val); }
    });
    return lines.join('\n');
}
$(document).on('click', '.nsh-copy-details-btn', function(e){
    e.preventDefault(); e.stopPropagation();
    var $btn = $(this);
    var $card = $btn.closest('.nsh-req-card-admin, .nsh-req-card, .nsh-order-page');
    var text = nshBuildCopyDetailsText($card.length ? $card : $(document));
    if (!text) { return; }
    nshCopyText(text).then(function(){ nshFlashCopied($btn); }).catch(function(){});
});
$(document).on('click', '.nsh-copy-desc-btn', function(e){
    e.preventDefault(); e.stopPropagation();
    var $btn = $(this);
    var rid = $btn.data('rid');
    var text = (window._nriDescCache && window._nriDescCache[rid]) || $btn.attr('data-desc-text') || '';
    if (!text) { return; }
    nshCopyText(text).then(function(){ nshFlashCopied($btn); }).catch(function(){});
});

// "Docs" — downloads every document on the request into ONE real,
// uncompressed folder named "[Student Complete Name] – [Request Number]"
// — never a ZIP, and never several separate per-file downloads. Uses
// window.nshSaveFilesAsFolder() (defined in the COMMUNICATION PANEL IIFE
// below, exposed on window specifically so this handler — a separate
// IIFE — can call it) — the File System Access API, Chrome/Edge only:
// the person picks a location once, a subfolder with the exact request
// name is created there, and every document is written straight into it.
// Browsers without that API (Firefox, Safari, or a non-HTTPS install)
// fall back to the previous one-file-at-a-time download via
// window.nshDownloadFilesSequential() — the most those browsers can do
// without going back to a server-generated ZIP. Reuses the same
// nsh_bulk_download_docs endpoint the request detail page's "Download
// All" button uses. Card-scoped: no section filter, so it covers both
// client-uploaded and provider docs.
$(document).on('click', '.nsh-download-docs-btn', function(e){
    e.preventDefault(); e.stopPropagation();
    var $btn = $(this);
    if ($btn.prop('disabled')) { return; }
    var rid = $btn.data('rid');
    var orig = $btn.html();
    $btn.prop('disabled', true).html('&#8595; ...');
    $.post(NSH.ajax_url, { action: 'nsh_bulk_download_docs', nonce: NSH.admin_nonce, request_id: rid, section: 'all', att_ids: [] }, function(r){
        if (!r || !r.success) {
            $btn.prop('disabled', false).html(orig);
            alert((r && r.data && r.data.message) ? r.data.message : 'Could not download documents.');
            return;
        }
        var files = r.data.files || [];
        if (!files.length) { $btn.prop('disabled', false).html(orig); return; }
        if (window.nshSaveFilesAsFolder) {
            window.nshSaveFilesAsFolder(r.data.folder || ('Request-' + rid), files).then(function(result){
                $btn.prop('disabled', false).html(orig);
                if (result === 'unsupported' && window.nshDownloadFilesSequential) {
                    // This browser/context has no File System Access API —
                    // fall back to individual downloads rather than leaving
                    // the click with no result at all.
                    window.nshDownloadFilesSequential(files);
                }
                // 'cancelled': the person dismissed the folder picker — do
                // nothing further, that's a deliberate no-op, not an error.
            });
            return;
        }
        $btn.prop('disabled', false).html(orig);
        if (window.nshDownloadFilesSequential) {
            window.nshDownloadFilesSequential(files);
        }
    }).fail(function(){
        $btn.prop('disabled', false).html(orig);
        alert('Network error. Please try again.');
    });
});

/* ============================================================
   STUDENT REQUIREMENT DESCRIPTION — regenerate / edit / save
   (request detail page, Form Details tab — staff only)
   ============================================================ */
$(document).on('click', '.nsh-regen-desc-btn', function(e){
    e.preventDefault();
    var $btn = $(this);
    var rid  = $btn.data('rid');
    var isManual = String($btn.data('manual')) === '1';
    if (isManual && !confirm('This description was manually edited. Regenerating will replace it with a freshly generated version. Continue?')) {
        return;
    }
    $btn.prop('disabled', true);
    $.post(NSH.ajax_url, { action: 'nsh_regenerate_description', nonce: NSH.admin_nonce, request_id: rid, force: 1 }, function(r){
        $btn.prop('disabled', false);
        if (r && r.success) {
            var html = $('<div>').text(r.data.text).html().replace(/\n/g, '<br>');
            $('#nsh-req-desc-text-' + rid).html(html);
            $('#nsh-req-desc-edit-' + rid).val(r.data.text);
            $btn.data('manual', '0');
            var $panel = $btn.closest('.nsh-req-desc-panel');
            $panel.find('.nsh-req-desc-badge').first().removeClass('nsh-req-desc-manual').addClass('nsh-req-desc-auto').text('Auto-Generated');
            $panel.find('.nsh-req-desc-stale').remove();
            $panel.find('.nsh-copy-desc-btn').attr('data-desc-text', r.data.text);
            if (window._nriDescCache) { window._nriDescCache[rid] = r.data.text; }
        } else {
            alert((r && r.data && r.data.message) ? r.data.message : 'Could not regenerate the description.');
        }
    });
});
$(document).on('click', '.nsh-edit-desc-btn', function(e){
    e.preventDefault();
    var $panel = $(this).closest('.nsh-req-desc-panel');
    var rid = $panel.data('rid');
    $('#nsh-req-desc-text-' + rid).hide();
    $('#nsh-req-desc-edit-' + rid).show().focus();
    $panel.find('.nsh-edit-desc-btn, .nsh-regen-desc-btn').hide();
    $panel.find('.nsh-save-desc-btn, .nsh-cancel-desc-btn').show();
});
$(document).on('click', '.nsh-cancel-desc-btn', function(e){
    e.preventDefault();
    var $panel = $(this).closest('.nsh-req-desc-panel');
    var rid = $panel.data('rid');
    $('#nsh-req-desc-edit-' + rid).hide();
    $('#nsh-req-desc-text-' + rid).show();
    $panel.find('.nsh-edit-desc-btn, .nsh-regen-desc-btn').show();
    $panel.find('.nsh-save-desc-btn, .nsh-cancel-desc-btn').hide();
});
$(document).on('click', '.nsh-save-desc-btn', function(e){
    e.preventDefault();
    var $btn   = $(this);
    var $panel = $btn.closest('.nsh-req-desc-panel');
    var rid    = $panel.data('rid');
    var text   = $('#nsh-req-desc-edit-' + rid).val();
    if (!text || !text.trim()) { alert('Description cannot be empty.'); return; }
    $btn.prop('disabled', true);
    $.post(NSH.ajax_url, { action: 'nsh_save_description', nonce: NSH.admin_nonce, request_id: rid, text: text }, function(r){
        $btn.prop('disabled', false);
        if (r && r.success) {
            var html = $('<div>').text(r.data.text).html().replace(/\n/g, '<br>');
            $('#nsh-req-desc-text-' + rid).html(html).show();
            $('#nsh-req-desc-edit-' + rid).val(r.data.text).hide();
            $panel.find('.nsh-edit-desc-btn, .nsh-regen-desc-btn').show();
            $panel.find('.nsh-regen-desc-btn').data('manual', '1');
            $panel.find('.nsh-save-desc-btn, .nsh-cancel-desc-btn').hide();
            $panel.find('.nsh-copy-desc-btn').attr('data-desc-text', r.data.text);
            $panel.find('.nsh-req-desc-badge').first().removeClass('nsh-req-desc-auto').addClass('nsh-req-desc-manual').text('Manually Edited');
            $panel.find('.nsh-req-desc-stale').remove();
            if (window._nriDescCache) { window._nriDescCache[rid] = r.data.text; }
        } else {
            alert((r && r.data && r.data.message) ? r.data.message : 'Could not save the description.');
        }
    });
});

/* ============================================================
   DELETE REQUEST (Admin)
   ============================================================ */
$(document).on('click','.nsh-delete-request',function(){
    var rid=$(this).data('rid');
    if(!confirm('Delete this request permanently? All messages and tickets will also be deleted.'))return;
    $.post(NSH.ajax_url,{action:'nsh_delete_request',nonce:NSH.admin_nonce,request_id:rid,hard_delete:1},function(r){
        if(r.success){
            // Inside the admin dashboard SPA (embedded detail view): go
            // back to the requests list in place instead of a full page
            // redirect. Standalone /nsh-request/{id} page: fall back to the
            // old full-navigation behavior, since there's no SPA container
            // to return to.
            if ($('.nsh-order-page-embedded').length && window.nshAdminLoadTab) {
                var s = (window.nshAdminStateGet ? window.nshAdminStateGet() : {});
                window.nshAdminLoadTab((s && s.currentTab) || 'requests');
            } else {
                window.location.href=NSH.home_url+(NSH.dash_base||'/nsh-admin-dashboard');
            }
        }
        else{alert('Delete failed.');}
    });
});

/* ============================================================
   FIELD REORDER — Drag-and-Drop (SortableJS)
   ============================================================ */
function nshInitFieldSortable() {
    var tbody = document.getElementById('nsh-fields-tbody');
    if (!tbody || typeof Sortable === 'undefined') return;
    Sortable.create(tbody, {
        handle: '.nsh-drag-handle',
        animation: 150,
        ghostClass: 'nsh-drag-ghost',
        chosenClass: 'nsh-drag-chosen',
        onEnd: function(evt) {
            var ids = [];
            tbody.querySelectorAll('tr[data-field-id]').forEach(function(tr) {
                ids.push(parseInt(tr.getAttribute('data-field-id'), 10));
            });
            $.post(NSH.ajax_url, {action: 'nsh_reorder_fields', nonce: NSH.admin_nonce, ids: ids}, function(r) {
                if (!r.success) { alert('Could not save new order.'); }
            });
        }
    });
}
$(document).on('nsh:fields_rendered', nshInitFieldSortable);

})(jQuery);

/* ============================================================
   v6.2.1: SHIPPING CHARGES HANDLER
   ============================================================ */
(function($){
    $(document).on('click', '#nsh-do-shipping', function(){
        var rid = $(this).data('rid');
        var amount = $('#nsh-shipping-amt').val();
        var type = $('#nsh-shipping-type').val();
        
        if (!amount || amount < 0) {
            alert('Please enter a valid shipping amount');
            return;
        }
        
        $(this).text('Setting...').prop('disabled', true);
        
        $.post(NSH.ajax_url, {
            action: 'nsh_set_shipping',
            nonce: NSH.nonce,
            request_id: rid,
            amount: amount,
            type: type
        }, function(r){
            $('#nsh-do-shipping').text('Set').prop('disabled', false);
            if (r.success) {
                alert('Shipping charges updated!');
                location.reload();
            } else {
                alert('Error: ' + (r.data && r.data.message ? r.data.message : 'Failed to update'));
            }
        });
    });
})(jQuery);

// ── COMMUNICATION PANEL ─────────────────────────────────────────────────────
(function($){
    if (typeof NSH === 'undefined') return;

    // Load template into compose box
    $(document).on('click', '#nsh-comm-load-template', function(){
        var ttype = $('#nsh-comm-template-sel').val();
        if (!ttype) { alert('Please select a template first.'); return; }
        var rid = $('#nsh-comm-rid').val();
        var $btn = $(this).text('Loading...').prop('disabled', true);
        $.post(NSH.ajax_url, {
            action: 'nsh_get_comm_template',
            nonce: NSH.nonce,
            request_id: rid,
            template_type: ttype
        }, function(r){
            $btn.text('Load').prop('disabled', false);
            if (r.success) {
                if (r.data.subject) $('#nsh-comm-subject').val(r.data.subject);
                if (r.data.body)    $('#nsh-comm-body').val(r.data.body);
            } else {
                alert('Could not load template: ' + (r.data && r.data.message ? r.data.message : 'Unknown error'));
            }
        });
    });

    // Quick reply: insert into textarea
    $(document).on('click', '.nsh-comm-quick-btn', function(){
        var content = $(this).data('content');
        var $ta = $('#nsh-comm-body');
        var cur = $ta.val();
        $ta.val(cur ? cur + '\n\n' + content : content);
        $ta.focus();
        // Scroll textarea to bottom
        $ta[0].scrollTop = $ta[0].scrollHeight;
    });

    // Send email only
    $(document).on('click', '#nsh-comm-send-email', function(){
        nshCommSend(false);
    });

    // Send email + log to message history
    $(document).on('click', '#nsh-comm-send-and-log', function(){
        nshCommSend(true);
    });

    function nshCommSend(logMessage) {
        var rid     = $('#nsh-comm-rid').val();
        var subject = $.trim($('#nsh-comm-subject').val());
        var body    = $.trim($('#nsh-comm-body').val());
        var $status = $('#nsh-comm-status');

        if (!subject || !body) {
            nshCommStatus('Please fill in the subject and message.', 'error');
            return;
        }

        var $btn = logMessage ? $('#nsh-comm-send-and-log') : $('#nsh-comm-send-email');
        $btn.text('Sending...').prop('disabled', true);
        $('#nsh-comm-send-email, #nsh-comm-send-and-log').prop('disabled', true);

        $.post(NSH.ajax_url, {
            action: 'nsh_send_comm_email',
            nonce: NSH.nonce,
            request_id: rid,
            subject: subject,
            body: body,
            log_message: logMessage ? 1 : 0
        }, function(r){
            $('#nsh-comm-send-email, #nsh-comm-send-and-log').prop('disabled', false).each(function(){
                $(this).text( $(this).attr('id') === 'nsh-comm-send-email' ? '✉ Send Email' : '✉ Send & Log to History' );
            });
            if (r.success) {
                nshCommStatus('&#10003; ' + r.data.message, 'success');
                $('#nsh-comm-body').val('');
                // If logged, append to communication log
                if (r.data.logged) {
                    var uid_new = 'nricl-new-' + Date.now();
                    var logHtml = '<div class="nsh-comm-log-item" style="border:1px solid #e2e8f0;border-radius:8px;margin-bottom:12px;overflow:hidden;">'
                        + '<div class="nsh-comm-log-hdr" style="display:flex;justify-content:space-between;align-items:flex-start;padding:12px 16px;background:#f8fafc;cursor:pointer;" onclick="nshToggleCommLog(\'' + uid_new + '\')" >'
                        + '<div style="flex:1;min-width:0;">'
                        + '<div style="display:flex;align-items:center;gap:8px;"><span style="font-size:16px;">&#9993;</span>'
                        + '<span style="font-size:13px;color:#64748b;">Sent by <strong style="color:#1e293b;">' + r.data.sender + '</strong> &mdash; ' + r.data.sent_time + '</span></div>'
                        + '<div style="margin-top:6px;padding-left:26px;font-size:13px;color:#374151;"><strong>Subject:</strong> ' + subject + '</div>'
                        + '</div>'
                        + '<span style="font-size:11px;color:#94a3b8;white-space:nowrap;padding-left:12px;" id="' + uid_new + '-arrow">&#9660; View</span>'
                        + '</div>'
                        + '<div id="' + uid_new + '" style="display:none;padding:16px;border-top:1px solid #e2e8f0;background:#fff;">'
                        + '<div style="margin-bottom:12px;padding:8px 12px;background:#eff6ff;border-radius:6px;font-size:13px;font-weight:600;color:#1e40af;">' + subject + '</div>'
                        + '<div style="font-size:14px;line-height:1.8;color:#374151;white-space:pre-wrap;border:1px solid #e2e8f0;border-radius:6px;padding:12px;background:#fafafa;">' + body + '</div>'
                        + '</div>'
                        + '</div>';
                    var $list = $('.nsh-comm-history-list');
                    if ($list.find('.nsh-hint').length) $list.empty();
                    $list.prepend(logHtml);
                    // Update count
                    var cur = parseInt($('.nsh-comm-log-count').text()) || 0;
                    $('.nsh-comm-log-count').text((cur + 1) + ' email(s) sent');
                }
            } else {
                nshCommStatus('&#10007; ' + (r.data && r.data.message ? r.data.message : 'Failed to send.'), 'error');
            }
        }).fail(function(){
            $('#nsh-comm-send-email, #nsh-comm-send-and-log').prop('disabled', false);
            nshCommStatus('&#10007; Network error. Please try again.', 'error');
        });
    }

    function nshCommStatus(msg, type) {
        var $s = $('#nsh-comm-status');
        $s.removeClass('nsh-comm-success nsh-comm-error')
          .addClass(type === 'success' ? 'nsh-comm-success' : 'nsh-comm-error')
          .html(msg).show();
        if (type === 'success') {
            setTimeout(function(){ $s.fadeOut(); }, 5000);
        }
    }

})(jQuery);

// ── Communication log toggle (outside jQuery wrapper for inline onclick) ─────
function nshToggleCommLog(id) {
    var el = document.getElementById(id);
    var arrow = document.getElementById(id + '-arrow');
    if (!el) return;
    if (el.style.display === 'none') {
        el.style.display = 'block';
        if (arrow) arrow.innerHTML = '&#9650; Hide';
    } else {
        el.style.display = 'none';
        if (arrow) arrow.innerHTML = '&#9660; View';
    }
}

// ── Document bulk / multiselect download ─────────────────────────────────────
(function($){
    // Individual checkbox toggles the bulk toolbar for that section
    $(document).on('change', '.nsh-doc-select-all', function(){
        var section = $(this).data('section');
        var checked = $(this).is(':checked');
        $('.nsh-doc-chk[data-section="' + section + '"]').prop('checked', checked);
        nshUpdateDocBulkBar(section);
    });
    $(document).on('change', '.nsh-doc-chk', function(){
        var section = $(this).data('section');
        nshUpdateDocBulkBar(section);
        var total   = $('.nsh-doc-chk[data-section="' + section + '"]').length;
        var checked = $('.nsh-doc-chk[data-section="' + section + '"]:checked').length;
        $('.nsh-doc-select-all[data-section="' + section + '"]')
            .prop('indeterminate', checked > 0 && checked < total)
            .prop('checked', checked === total && total > 0);
    });
    function nshUpdateDocBulkBar(section) {
        var n = $('.nsh-doc-chk[data-section="' + section + '"]:checked').length;
        var $btn = $('.nsh-doc-bulk-dl[data-section="' + section + '"]');
        if (n > 0) { $btn.show().text('\u2193 Download Selected (' + n + ')'); }
        else        { $btn.hide(); }
    }

    // Download SELECTED documents — tries server-side ZIP first, falls back to sequential
    $(document).on('click', '.nsh-doc-bulk-dl', function(){
        var $btn    = $(this);
        var section = $btn.data('section');
        var attIds  = [];
        var rid     = $('[data-nsh-rid]').data('nsh-rid') || $('#nsh-msg-rid').val() || $('#nsh-comm-rid').val() || 0;
        $('.nsh-doc-chk[data-section="' + section + '"]:checked').each(function(){
            attIds.push($(this).closest('.nsh-doc-entry').data('att-id'));
        });
        if (!attIds.length) { alert('No documents selected.'); return; }
        $btn.text('\u23f3 Preparing...').prop('disabled', true);
        nshBulkDownload(rid, section, attIds, $btn);
    });

    // Download ALL documents in a section
    $(document).on('click', '.nsh-doc-dl-all', function(){
        var $btn    = $(this);
        var section = $btn.data('section');
        var rid     = $btn.data('rid') || $('#nsh-msg-rid').val() || $('#nsh-comm-rid').val() || 0;
        $btn.text('\u23f3 Preparing...').prop('disabled', true);
        nshBulkDownload(rid, section, [], $btn);
    });

    function nshBulkDownload(rid, section, attIds, $btn) {
        var label = attIds.length ? 'Download Selected' : 'Download All';
        $.post(NSH.ajax_url, {
            action:     'nsh_bulk_download_docs',
            nonce:      NSH.nonce || NSH.admin_nonce,
            request_id: rid,
            section:    section,
            att_ids:    attIds
        }, function(r) {
            if (!r.success) {
                $btn.text('\u2193 ' + label).prop('disabled', false);
                alert('Download error: ' + (r.data && r.data.message ? r.data.message : 'Unknown error'));
                return;
            }
            var files = r.data.files || [];
            if (!files.length) { $btn.text('\u2193 ' + label).prop('disabled', false); return; }
            // Never a ZIP: one real folder ("[Student Name] \u2013 [Request Number]")
            // written straight to disk via the File System Access API where
            // the browser supports it (nshSaveFilesAsFolder(), defined
            // below), falling back to the previous one-file-at-a-time
            // download only where that API isn't available.
            if (typeof nshSaveFilesAsFolder === 'function') {
                nshSaveFilesAsFolder(r.data.folder || ('Request-' + rid), files).then(function(result){
                    $btn.text('\u2193 ' + label).prop('disabled', false);
                    if (result === 'unsupported') { nshDownloadFilesSequential(files); }
                });
                return;
            }
            $btn.text('\u2193 ' + label).prop('disabled', false);
            nshDownloadFilesSequential(files);
        }).fail(function(){
            $btn.text('\u2193 ' + label).prop('disabled', false);
            alert('Network error. Please try again.');
        });
    }

    // Sequential download: one file every 500ms so browser doesn't block them
    // all. Exposed on window so the "Docs" button handler (a separate IIFE,
    // above) can reuse this exact same download logic instead of duplicating
    // it — see the comment on window.nshDownloadFilesSequential's call site.
    function nshDownloadFilesSequential(files) {
        if (!files || !files.length) return;
        files.forEach(function(f, i){
            setTimeout(function(){
                var a = document.createElement('a');
                a.href     = f.url;
                a.download = f.filename || 'document';
                a.style.display = 'none';
                document.body.appendChild(a);
                a.click();
                setTimeout(function(){ document.body.removeChild(a); }, 1000);
            }, i * 500);
        });
    }
    window.nshDownloadFilesSequential = nshDownloadFilesSequential;

    // ── Remembered download location ────────────────────────────────────────
    // Browsers give a web page no way to "open" or navigate the OS file
    // explorer to a folder — that's not something any browser (Chrome,
    // Edge, Firefox, Safari) exposes to a website, for security reasons.
    // What we CAN do is stop asking every time: the very first time someone
    // picks a location for their documents, we remember that exact folder
    // (as a FileSystemDirectoryHandle, in IndexedDB) and reuse it silently
    // on every later download — so after the first pick, every request's
    // folder always lands inside the SAME parent folder the person already
    // knows and has open, with no picker and no re-navigating.
    var NSH_DIR_DB    = 'nsh_docs_dir_db';
    var NSH_DIR_STORE = 'handles';
    var NSH_DIR_KEY   = 'download_folder';

    function nshOpenDirDB() {
        return new Promise(function(resolve, reject) {
            if (!window.indexedDB) { reject(new Error('no indexedDB')); return; }
            var req = window.indexedDB.open(NSH_DIR_DB, 1);
            req.onupgradeneeded = function(){ req.result.createObjectStore(NSH_DIR_STORE); };
            req.onsuccess = function(){ resolve(req.result); };
            req.onerror   = function(){ reject(req.error); };
        });
    }
    function nshGetStoredDirHandle() {
        return nshOpenDirDB().then(function(db){
            return new Promise(function(resolve){
                var tx  = db.transaction(NSH_DIR_STORE, 'readonly');
                var req = tx.objectStore(NSH_DIR_STORE).get(NSH_DIR_KEY);
                req.onsuccess = function(){ resolve(req.result || null); };
                req.onerror   = function(){ resolve(null); };
            });
        })['catch'](function(){ return null; });
    }
    function nshSetStoredDirHandle(handle) {
        return nshOpenDirDB().then(function(db){
            return new Promise(function(resolve){
                var tx = db.transaction(NSH_DIR_STORE, 'readwrite');
                tx.objectStore(NSH_DIR_STORE).put(handle, NSH_DIR_KEY);
                tx.oncomplete = function(){ resolve(); };
                tx.onerror    = function(){ resolve(); };
            });
        })['catch'](function(){});
    }
    function nshClearStoredDirHandle() {
        return nshOpenDirDB().then(function(db){
            return new Promise(function(resolve){
                var tx = db.transaction(NSH_DIR_STORE, 'readwrite');
                tx.objectStore(NSH_DIR_STORE)['delete'](NSH_DIR_KEY);
                tx.oncomplete = function(){ resolve(); };
                tx.onerror    = function(){ resolve(); };
            });
        })['catch'](function(){});
    }
    // Resolves the parent folder to save into: reuses the remembered one
    // (re-confirming permission, which the browser may re-prompt for) when
    // one exists and is still usable, otherwise asks once via the native
    // folder picker and remembers the choice for every future download.
    async function nshGetParentDirHandle() {
        var stored = await nshGetStoredDirHandle();
        if (stored) {
            try {
                var perm = await stored.queryPermission({ mode: 'readwrite' });
                if (perm !== 'granted') {
                    perm = await stored.requestPermission({ mode: 'readwrite' });
                }
                if (perm === 'granted') { return stored; }
            } catch (err) {
                // Stored handle is stale (folder was moved/deleted/revoked) —
                // fall through and ask again below.
            }
        }
        var opts = { mode: 'readwrite' };
        if (stored) { try { opts.startIn = stored; } catch (e) {} }
        var handle = await window.showDirectoryPicker(opts);
        await nshSetStoredDirHandle(handle);
        return handle;
    }

    // Small, non-blocking confirmation banner — used instead of alert() so
    // a normal successful download doesn't interrupt the person with a
    // dialog they have to dismiss every single time.
    function nshShowSaveToast(message, isError) {
        try {
            var $t = jQuery('<div/>').text(message).css({
                position: 'fixed', bottom: '24px', right: '24px', zIndex: 999999,
                background: isError ? '#b91c1c' : '#1f7a3d', color: '#fff',
                padding: '10px 16px', borderRadius: '6px', fontSize: '13px',
                maxWidth: '360px', boxShadow: '0 2px 10px rgba(0,0,0,.25)'
            }).appendTo('body');
            setTimeout(function(){ $t.fadeOut(400, function(){ $t.remove(); }); }, isError ? 6000 : 4000);
        } catch (e) { /* non-critical UI, ignore */ }
    }

    // Writes every file in `files` (each {url, filename}) into ONE real,
    // uncompressed folder named `folderName` — no ZIP, and no separate
    // per-file download prompts — using the File System Access API
    // (Chrome/Edge, secure-context only). Only the FIRST download ever asks
    // where to save; every download after that reuses the same remembered
    // parent folder automatically (see nshGetParentDirHandle() above), so
    // there is never anywhere to "navigate back to" — it's always the same
    // place. A subfolder named exactly `folderName` is created (or reused)
    // inside that parent, and every document is fetched and written
    // straight into it.
    //
    // Returns a Promise resolving to:
    //   'done'      — files were written into the folder
    //   'cancelled' — the person dismissed the folder picker (not an error)
    //   'unsupported' — this browser/context has no File System Access API
    //                   (Firefox, Safari, or the page isn't served over
    //                   HTTPS) — caller should fall back to
    //                   nshDownloadFilesSequential() instead, which is the
    //                   most any of those can do without going back to a
    //                   server-generated ZIP.
    // A thrown error means the picker itself failed for a reason other
    // than the person cancelling (e.g. permission denied); caller should
    // treat that the same as 'unsupported' and fall back.
    async function nshSaveFilesAsFolder(folderName, files) {
        if (!window.showDirectoryPicker) { return 'unsupported'; }
        if (!files || !files.length) { return 'done'; }

        var parentHandle;
        try {
            parentHandle = await nshGetParentDirHandle();
        } catch (err) {
            if (err && err.name === 'AbortError') { return 'cancelled'; }
            return 'unsupported';
        }

        var subDir;
        try {
            subDir = await parentHandle.getDirectoryHandle(folderName, { create: true });
        } catch (err) {
            return 'unsupported';
        }

        var failed = [];
        for (var i = 0; i < files.length; i++) {
            var f = files[i];
            try {
                var resp = await fetch(f.url, { credentials: 'same-origin' });
                if (!resp.ok) { failed.push(f.filename || ('file ' + (i + 1))); continue; }
                // The real filename (with its correct, server-decided
                // extension — PDF/JPG/PNG, after any WebP/AVIF conversion)
                // comes from Content-Disposition, not from `f.filename`
                // (which is only a pre-fetch hint with no extension yet).
                var cd = resp.headers.get('Content-Disposition') || '';
                var m  = /filename\*?=(?:UTF-8''|")?([^";]+)"?/i.exec(cd);
                var saveName = m ? decodeURIComponent(m[1]) : ((f.filename || 'document') + '.pdf');
                var blob = await resp.blob();
                var fileHandle = await subDir.getFileHandle(saveName, { create: true });
                var writable = await fileHandle.createWritable();
                await writable.write(blob);
                await writable.close();
            } catch (err) {
                failed.push(f.filename || ('file ' + (i + 1)));
            }
        }
        var whereText = (parentHandle.name || 'chosen folder') + ' / ' + folderName;
        if (failed.length) {
            nshShowSaveToast('Saved to "' + whereText + '", but ' + failed.length + ' file(s) could not be downloaded: ' + failed.join(', '), true);
        } else {
            nshShowSaveToast('Saved to "' + whereText + '" — same folder every time, no need to look elsewhere.', false);
        }
        return 'done';
    }
    window.nshSaveFilesAsFolder = nshSaveFilesAsFolder;

    // Lets the person explicitly point future downloads at a different
    // folder — otherwise the first-ever pick is remembered and reused
    // silently forever (see nshGetParentDirHandle() above), and there was
    // previously no way back to the picker short of clearing site data.
    // Wired to every ".nsh-change-save-folder" button (Requests toolbar,
    // request-detail documents panel, Form Details documents panel).
    window.nshChangeDownloadFolder = async function () {
        await nshClearStoredDirHandle();
        if (!window.showDirectoryPicker) {
            nshShowSaveToast('This browser can\'t remember a save folder — documents download individually instead.', true);
            return;
        }
        try {
            var handle = await window.showDirectoryPicker({ mode: 'readwrite' });
            await nshSetStoredDirHandle(handle);
            nshShowSaveToast('Save folder changed to "' + handle.name + '". Future downloads will use this folder.', false);
        } catch (err) {
            if (err && err.name === 'AbortError') { return; } // cancelled — leave unset, next download will ask
            nshShowSaveToast('Could not set a new save folder.', true);
        }
    };
    $(document).on('click', '.nsh-change-save-folder', function (e) {
        e.preventDefault();
        window.nshChangeDownloadFolder();
    });
})(jQuery);
// ── END COMMUNICATION PANEL ─────────────────────────────────────────────────

// ── Quick Email Buttons (Staff Panel) ───────────────────────────────────────
(function($){
    if (typeof NSH === 'undefined') return;

    function nshShowEmailResult($btn, originalText, success, msg) {
        $btn.prop('disabled', false);
        var $row = $btn.closest('.nsh-staff-section');
        var $notice = $row.find('.nsh-email-result-notice');
        if (!$notice.length) {
            $notice = $('<div class="nsh-email-result-notice" style="margin-top:8px;padding:8px 12px;border-radius:6px;font-size:12px;font-weight:600;"></div>');
            $btn.after($notice);
        }
        if (success) {
            $btn.text('✓ Sent!');
            $notice.css({background:'#f0fdf4',color:'#16a34a',border:'1px solid #bbf7d0'}).text('✓ ' + msg).show();
            setTimeout(function(){ $btn.text(originalText); $notice.fadeOut(); }, 5000);
        } else {
            $btn.text(originalText);
            $notice.css({background:'#fef2f2',color:'#dc2626',border:'1px solid #fecaca'}).text('✗ ' + msg + ' — Check SMTP settings in WordPress.').show();
        }
    }

    $(document).on('click','#nsh-send-doc-reminder',function(){
        var $btn=$(this), rid=$btn.data('rid'), originalText=$btn.text();
        var note=prompt('Optional: Add a note to the reminder email (leave blank to send standard reminder):','');
        if (note === null) return; // user cancelled prompt
        $btn.text('Sending…').prop('disabled',true);
        $.post(NSH.ajax_url,{action:'nsh_send_doc_reminder',nonce:NSH.admin_nonce,request_id:rid,note:note||''},
            function(r){ nshShowEmailResult($btn, originalText, r.success, r.success?(r.data&&r.data.message?r.data.message:'Sent'):(r.data&&r.data.message?r.data.message:'Failed to send')); }
        ).fail(function(){ nshShowEmailResult($btn, originalText, false, 'Network error — request did not reach server'); });
    });

    $(document).on('click','#nsh-send-status-email',function(){
        var $btn=$(this), rid=$btn.data('rid'), originalText=$btn.text();
        if (!confirm('Send current status update email to the client?')) return;
        $btn.text('Sending…').prop('disabled',true);
        $.post(NSH.ajax_url,{action:'nsh_send_status_email',nonce:NSH.admin_nonce,request_id:rid},
            function(r){ nshShowEmailResult($btn, originalText, r.success, r.success?(r.data&&r.data.message?r.data.message:'Sent'):(r.data&&r.data.message?r.data.message:'Failed to send')); }
        ).fail(function(){ nshShowEmailResult($btn, originalText, false, 'Network error'); });
    });

})(jQuery);
// ── END Quick Email Buttons ─────────────────────────────────────────────────

// ── Form Details Tab: document multiselect + bulk download ───────────────────
(function($){
    if (typeof NSH === 'undefined') return;

    // Select-all checkbox
    $(document).on('change', '#nsh-fd-sel-all', function(){
        var checked = $(this).is(':checked');
        $('.nsh-fd-doc-chk').prop('checked', checked);
        nshFdUpdateBulkBar();
    });
    // Per-file checkbox
    $(document).on('change', '.nsh-fd-doc-chk', function(){
        nshFdUpdateBulkBar();
        var total   = $('.nsh-fd-doc-chk').length;
        var checked = $('.nsh-fd-doc-chk:checked').length;
        $('#nsh-fd-sel-all').prop('indeterminate', checked > 0 && checked < total).prop('checked', checked === total && total > 0);
    });
    function nshFdUpdateBulkBar(){
        var n = $('.nsh-fd-doc-chk:checked').length;
        if (n > 0) {
            $('#nsh-fd-dl-selected').show().text('↓ Download Selected (' + n + ')');
            $('#nsh-fd-del-selected').show().text('🗑 Delete Selected (' + n + ')');
        } else {
            $('#nsh-fd-dl-selected').hide();
            $('#nsh-fd-del-selected').hide();
        }
    }

    // Removes a document row from the DOM and updates the "Uploaded
    // Documents (N)" heading count — done locally rather than re-fetching
    // the whole request detail, so a delete stays fast and doesn't disturb
    // anything else the staff member has open on this screen.
    function nshFdRemoveDocRows(attIds){
        attIds.forEach(function(id){
            $('.nsh-fd-doc-row[data-att-id="' + id + '"]').remove();
        });
        var remaining = $('.nsh-fd-doc-row').length;
        var $heading = $('.nsh-ot-pane h4:contains("Uploaded Documents")').first();
        if ($heading.length) {
            $heading.html($heading.html().replace(/\(\d+\)/, '(' + remaining + ')'));
        }
        nshFdUpdateBulkBar();
        var $selAll = $('#nsh-fd-sel-all');
        if ($selAll.length) { $selAll.prop('checked', false).prop('indeterminate', false); }
    }

    // Delete selected (bulk)
    $(document).on('click', '#nsh-fd-del-selected', function(){
        var $btn = $(this), rid = $btn.data('rid');
        var attIds = [];
        $('.nsh-fd-doc-chk:checked').each(function(){ attIds.push($(this).data('att-id')); });
        if (!attIds.length) { alert('No documents selected.'); return; }
        if (!confirm('Delete the selected ' + attIds.length + ' file' + (attIds.length > 1 ? 's' : '') + '? This cannot be undone.')) return;
        var origText = $btn.text();
        $btn.text('Deleting…').prop('disabled', true);
        $.post(NSH.ajax_url, {
            action: 'nsh_delete_documents',
            nonce: NSH.admin_nonce || NSH.nonce,
            request_id: rid,
            att_ids: attIds
        }, function(r){
            $btn.text(origText).prop('disabled', false);
            if (r.success) { nshFdRemoveDocRows(attIds); }
            else { alert('Delete failed: ' + (r.data && r.data.message ? r.data.message : 'Unknown error')); }
        }).fail(function(){ $btn.text(origText).prop('disabled', false); alert('Network error.'); });
    });

    // Delete one file (per-row button)
    $(document).on('click', '.nsh-fd-doc-del', function(){
        var $btn = $(this), rid = $btn.data('rid'), attId = $btn.data('att-id');
        if (!confirm('Delete this file? This cannot be undone.')) return;
        $btn.prop('disabled', true);
        $.post(NSH.ajax_url, {
            action: 'nsh_delete_documents',
            nonce: NSH.admin_nonce || NSH.nonce,
            request_id: rid,
            att_ids: [attId]
        }, function(r){
            if (r.success) { nshFdRemoveDocRows([attId]); }
            else { $btn.prop('disabled', false); alert('Delete failed: ' + (r.data && r.data.message ? r.data.message : 'Unknown error')); }
        }).fail(function(){ $btn.prop('disabled', false); alert('Network error.'); });
    });

    // Download selected
    $(document).on('click', '#nsh-fd-dl-selected', function(){
        var $btn = $(this), rid = $btn.data('rid');
        var attIds = [];
        $('.nsh-fd-doc-chk:checked').each(function(){ attIds.push($(this).data('att-id')); });
        if (!attIds.length) { alert('No documents selected.'); return; }
        $btn.text('⏳ Preparing…').prop('disabled', true);
        nshFdBulkDownload(rid, attIds, $btn, 'Download Selected');
    });

    // Download all
    $(document).on('click', '#nsh-fd-dl-all', function(){
        var $btn = $(this), rid = $btn.data('rid');
        $btn.text('⏳ Preparing…').prop('disabled', true);
        nshFdBulkDownload(rid, [], $btn, 'Download All');
    });

    function nshFdBulkDownload(rid, attIds, $btn, label){
        $.post(NSH.ajax_url, {
            action:     'nsh_bulk_download_docs',
            nonce:      NSH.admin_nonce || NSH.nonce,
            request_id: rid,
            section:    'all',
            att_ids:    attIds
        }, function(r){
            if (!r.success) {
                $btn.text('↓ ' + label).prop('disabled', false);
                alert('Download error: ' + (r.data && r.data.message ? r.data.message : 'Unknown'));
                return;
            }
            var files = r.data.files || [];
            if (!files.length) { $btn.text('↓ ' + label).prop('disabled', false); return; }
            // Same one-real-folder behavior as the Docs button and
            // Download All/Selected elsewhere (nshSaveFilesAsFolder(),
            // defined in the COMMUNICATION PANEL IIFE below) — this entry
            // point used to fall back to per-file/ZIP downloads even after
            // that was fixed everywhere else; it now goes through the same
            // path so "Download All"/"Download Selected" here behaves
            // identically to every other download button in the plugin.
            if (typeof window.nshSaveFilesAsFolder === 'function') {
                window.nshSaveFilesAsFolder(r.data.folder || ('Request-' + rid), files).then(function(result){
                    $btn.text('↓ ' + label).prop('disabled', false);
                    if (result === 'unsupported' && window.nshDownloadFilesSequential) {
                        window.nshDownloadFilesSequential(files);
                    }
                });
                return;
            }
            $btn.text('↓ ' + label).prop('disabled', false);
            if (window.nshDownloadFilesSequential) {
                window.nshDownloadFilesSequential(files);
            }
        }).fail(function(){ $btn.text('↓ '+label).prop('disabled',false); alert('Network error.'); });
    }

})(jQuery);
// ── END Form Details multiselect ─────────────────────────────────────────────

// ── Bulk Select & Export (Admin Requests Table) ─────────────────────────────
(function($){
    if (typeof NSH === 'undefined') return;

    var selectedRids = [];

    function updateBulkUI(){
        var n = selectedRids.length;
        if(n > 0){
            $('#nsh-bulk-toolbar').css('display','flex');
            $('#nsh-bulk-count').text(n + ' request' + (n>1?'s':'') + ' selected');
        } else {
            $('#nsh-bulk-toolbar').hide();
        }
    }

    // Row checkbox: delegate since tbody is dynamically built
    $(document).on('change','#nsh-admin-tbody .nsh-bulk-chk', function(){
        var rid = parseInt($(this).val());
        if($(this).is(':checked')){
            if(selectedRids.indexOf(rid) < 0) selectedRids.push(rid);
        } else {
            selectedRids = selectedRids.filter(function(r){ return r !== rid; });
            $('#nsh-select-all-reqs').prop('checked', false);
        }
        updateBulkUI();
    });

    // Select all
    $(document).on('change','#nsh-select-all-reqs',function(){
        var checked = $(this).is(':checked');
        $('#nsh-admin-tbody .nsh-bulk-chk').prop('checked', checked);
        selectedRids = [];
        if(checked){
            $('#nsh-admin-tbody .nsh-bulk-chk').each(function(){
                selectedRids.push(parseInt($(this).val()));
            });
        }
        updateBulkUI();
    });

    // Clear selection
    $(document).on('click','#nsh-bulk-deselect',function(){
        selectedRids = [];
        $('#nsh-admin-tbody .nsh-bulk-chk, #nsh-select-all-reqs').prop('checked', false);
        updateBulkUI();
    });

    // Called by nshLoadAdminRequests() (shortcodes.php) after every re-render
    // of the table — a fresh page/filter/search means the previous
    // selection no longer corresponds to what's on screen, so it's cleared
    // rather than silently going stale.
    window.nshResetBulkSelection = function(){
        selectedRids = [];
        updateBulkUI();
    };

    // Bulk delete requests (also used for the Requests tab's own rows —
    // Form Submissions has its own bulk-delete button/handler in
    // form-submissions.php, hitting the same nsh_bulk_delete_requests
    // endpoint since a "submission" and a "request" are the same post).
    $(document).on('click','#nsh-bulk-delete-requests',function(){
        if(selectedRids.length === 0){ alert('No requests selected.'); return; }
        var n = selectedRids.length;
        if(!confirm('Delete the selected ' + n + ' request' + (n>1?'s':'') + '? This also deletes their messages, tickets and uploaded documents. This cannot be undone.')) return;
        var $btn = $(this).text('Deleting…').prop('disabled', true);
        $.post(NSH.ajax_url,{
            action: 'nsh_bulk_delete_requests',
            nonce: NSH.admin_nonce || NSH.nonce,
            request_ids: selectedRids
        }, function(r){
            $btn.text('🗑 Delete Selected').prop('disabled', false);
            if(r.success){
                selectedRids = [];
                if (window.nshLoadAdminRequests) window.nshLoadAdminRequests();
            } else {
                alert('Bulk delete failed: ' + (r.data && r.data.message ? r.data.message : 'Unknown error'));
            }
        }).fail(function(){ $btn.text('🗑 Delete Selected').prop('disabled', false); alert('Network error.'); });
    });

    // Bulk Excel export
    $(document).on('click','#nsh-bulk-export-excel',function(){
        if(selectedRids.length === 0){ alert('No requests selected.'); return; }
        var $btn = $(this).text('Exporting...').prop('disabled', true);
        $.post(NSH.ajax_url,{
            action: 'nsh_bulk_export_excel',
            nonce: NSH.nonce,
            request_ids: selectedRids
        }, function(r){
            $btn.text('📊 Export Selected (Excel)').prop('disabled', false);
            if(r.success && r.data && r.data.url){
                var a = document.createElement('a');
                a.href = r.data.url;
                a.download = r.data.filename || 'bulk-export.xlsx';
                document.body.appendChild(a); a.click(); document.body.removeChild(a);
            } else {
                alert('Export failed: ' + (r.data && r.data.message ? r.data.message : 'Unknown error'));
            }
        }).fail(function(){ $btn.text('📊 Export Selected (Excel)').prop('disabled', false); alert('Network error.'); });
    });

    // (Row checkboxes are written directly into each row's HTML by
    // nshLoadAdminRequests() in shortcodes.php, not patched on afterwards —
    // that's what actually makes the checkboxes appear on every render.)

})(jQuery);
// ── END Bulk Select ─────────────────────────────────────────────────────────

// ── Bulk Select & Delete (Admin Support Tickets Table) ──────────────────────
(function($){
    if (typeof NSH === 'undefined') return;

    var selectedTids = [];

    function updateTicketBulkUI(){
        var n = selectedTids.length;
        if(n > 0){
            $('#nsh-ticket-bulk-toolbar').css('display','flex');
            $('#nsh-ticket-bulk-count').text(n + ' ticket' + (n>1?'s':'') + ' selected');
        } else {
            $('#nsh-ticket-bulk-toolbar').hide();
        }
    }

    $(document).on('change','#nsh-support-tbody .nsh-ticket-bulk-chk', function(){
        var tid = parseInt($(this).val());
        if($(this).is(':checked')){
            if(selectedTids.indexOf(tid) < 0) selectedTids.push(tid);
        } else {
            selectedTids = selectedTids.filter(function(t){ return t !== tid; });
            $('#nsh-select-all-tickets').prop('checked', false);
        }
        updateTicketBulkUI();
    });

    $(document).on('change','#nsh-select-all-tickets',function(){
        var checked = $(this).is(':checked');
        $('#nsh-support-tbody .nsh-ticket-bulk-chk').prop('checked', checked);
        selectedTids = [];
        if(checked){
            $('#nsh-support-tbody .nsh-ticket-bulk-chk').each(function(){
                selectedTids.push(parseInt($(this).val()));
            });
        }
        updateTicketBulkUI();
    });

    $(document).on('click','#nsh-ticket-bulk-deselect',function(){
        selectedTids = [];
        $('#nsh-support-tbody .nsh-ticket-bulk-chk, #nsh-select-all-tickets').prop('checked', false);
        updateTicketBulkUI();
    });

    // Called by nshLoadSupportTickets() (shortcodes.php) after every reload.
    window.nshResetTicketBulkSelection = function(){
        selectedTids = [];
        updateTicketBulkUI();
    };

    $(document).on('click','#nsh-bulk-delete-tickets',function(){
        if(selectedTids.length === 0){ alert('No tickets selected.'); return; }
        var n = selectedTids.length;
        if(!confirm('Delete the selected ' + n + ' ticket' + (n>1?'s':'') + '? This cannot be undone.')) return;
        var $btn = $(this).text('Deleting…').prop('disabled', true);
        $.post(NSH.ajax_url,{
            action: 'nsh_bulk_delete_tickets',
            nonce: NSH.admin_nonce || NSH.nonce,
            ticket_ids: selectedTids
        }, function(r){
            $btn.text('🗑 Delete Selected').prop('disabled', false);
            if(r.success){
                selectedTids = [];
                if (window.nshLoadSupportTickets) window.nshLoadSupportTickets();
            } else {
                alert('Bulk delete failed: ' + (r.data && r.data.message ? r.data.message : 'Unknown error'));
            }
        }).fail(function(){ $btn.text('🗑 Delete Selected').prop('disabled', false); alert('Network error.'); });
    });

})(jQuery);
// ── END Ticket Bulk Select ───────────────────────────────────────────────────

// ── Admin Dashboard SPA Controller ───────────────────────────────────────────
// Fixes the "every click reloads the whole page" problem across the admin
// dashboard: switching tabs (Requests/Submissions/Support/Fields/…) and
// opening a request's "View" detail now swap content inside
// #nsh-admin-tab-container via AJAX instead of a full WordPress page
// navigation, while still keeping real, bookmarkable/shareable URLs in sync
// via the History API — so refresh, browser Back/Forward, and opening a
// link in a new tab all keep working exactly as before.
(function($){
    if (typeof NSH === 'undefined') return;

    var STATE_KEY = 'nsh_admin_state_v1';

    // This controller now drives BOTH the admin dashboard and the client
    // dashboard — they're structurally the same problem (tab-container +
    // AJAX tab/detail loading instead of full page reloads), just with
    // different containers, endpoints, and default tabs. Exactly one of
    // these containers is ever on the page at once, so detecting it once
    // up front and branching on it here is simpler and less error-prone
    // than maintaining two near-identical copies of this controller.
    function detectSurface(){
        var $a = $('#nsh-admin-tab-container');
        if ($a.length) {
            return { $el: $a, tabAction: 'nsh_admin_load_tab', detailAction: 'nsh_admin_load_request_detail', base: (NSH.dash_base || '/nsh-admin-dashboard'), defaultTab: 'requests' };
        }
        var $c = $('#nsh-client-tab-container');
        if ($c.length) {
            return { $el: $c, tabAction: 'nsh_client_load_tab', detailAction: 'nsh_client_load_request_detail', base: (NSH.client_base || '/nsh-client-dashboard'), defaultTab: 'dashboard' };
        }
        return null;
    }
    var SURFACE = detectSurface();

    // The browser's own scroll restoration fights with our AJAX content
    // swaps — it tries to restore scroll on popstate before our new
    // content (a different height than the old page) has even been
    // rendered, so the page visibly jumps once our own render finishes
    // and the layout shifts under it. Taking manual control and doing the
    // scroll restoration ourselves, AFTER the new content is in the DOM,
    // is what actually fixes the jump.
    if ('scrollRestoration' in history) { history.scrollRestoration = 'manual'; }

    // Pushes a new history entry, but first stamps the CURRENT scroll
    // position onto the entry being left — so if the user comes back to
    // it (Back button, or the "← All Requests" link, which now just
    // calls history.back()), we know exactly where to put them instead of
    // always snapping to the top.
    function pushHistoryState(state, url){
        var cur = history.state;
        if (cur) {
            var withScroll = {};
            for (var k in cur) { withScroll[k] = cur[k]; }
            withScroll.scrollY = window.scrollY;
            history.replaceState(withScroll, '', location.href);
        }
        history.pushState(state, '', url);
    }

    function stateGet(){
        try { return JSON.parse(sessionStorage.getItem(STATE_KEY)) || {}; }
        catch(e){ return {}; }
    }
    function stateSet(s){
        try { sessionStorage.setItem(STATE_KEY, JSON.stringify(s)); }
        catch(e){ /* private mode / quota — non-critical, just skip persistence */ }
    }
    window.nshAdminStateGet = stateGet;

    // Per-tab filter/search/page cache, read by nshLoadAdminRequests() (see
    // nsh_admin_js() in shortcodes.php) so leaving and returning to a tab —
    // whether via the nav, a "back to list" click, or the browser's own
    // Back button — restores the same filtered/paginated view rather than
    // silently resetting it.
    window.nshSaveAdminListState = function(tab, listState){
        var s = stateGet();
        s.listState = s.listState || {};
        s.listState[tab] = listState;
        stateSet(s);
    };
    window.nshRestoreAdminListState = function(tab){
        var s = stateGet();
        return (s.listState && s.listState[tab]) || null;
    };

    // ── Background prefetch cache ────────────────────────────────────────
    // Goal: by the time the user actually clicks a tab or a "View" link,
    // the HTML is already sitting in memory, so the switch is instant with
    // no visible fetch/loading state. Tabs are prefetched in the
    // background right after the page settles; request-detail views are
    // prefetched on hover/touch (the ~150-300ms before a click lands is
    // enough time for the request to come back on a normal connection).
    var TAB_CACHE_TTL = 20000; // ms — after this, a cached tab is served
                                 // instantly but silently re-fetched in the
                                 // background so it doesn't go stale.
    var tabCache = {};          // { tabKey: { html, ts, loading:false } }
    var detailCache = {};       // { rid: { html, ts } }
    var detailCacheOrder = [];  // simple LRU eviction order
    var DETAIL_CACHE_MAX = 25;

    // If a background prefetch for this tab is already in flight when the
    // user actually clicks it, we must NOT start a second request — but we
    // also must NOT drop the click's callback, or the click just sits
    // there indefinitely waiting on a response that will never reach it.
    // So every caller's callback is queued against the one in-flight
    // request and all of them fire together when it resolves.
    function fetchTabInto(cacheObj, tab, cb){
        var entry = cacheObj[tab] = cacheObj[tab] || {};
        if (entry.loading) {
            if (cb) { entry.pending = entry.pending || []; entry.pending.push(cb); }
            return;
        }
        entry.loading = true;
        entry.pending = cb ? [cb] : [];
        $.post(NSH.ajax_url, {
            action: SURFACE ? SURFACE.tabAction : 'nsh_admin_load_tab',
            nonce: NSH.admin_nonce || NSH.nonce,
            tab: tab
        }, function(r){
            entry.loading = false;
            var waiting = entry.pending || []; entry.pending = [];
            if (r && r.success) {
                entry.html = r.data.html;
                entry.tab = r.data.tab;
                entry.ts = Date.now();
                waiting.forEach(function(fn){ fn(r.data); });
            }
        }).fail(function(){
            entry.loading = false;
            var waiting = entry.pending || []; entry.pending = [];
            // Still flush pending callbacks (with no data) on failure, so a
            // click waiting on an in-flight prefetch — or the background
            // prefetch chain waiting to move to the next tab — doesn't
            // stall forever; each caller already handles "no data" safely
            // (nshAdminLoadTab falls back to its own error timeout, and
            // the background chain just moves on to the next tab).
            waiting.forEach(function(fn){ fn(null); });
        });
    }

    function prefetchTab(tab){
        var entry = tabCache[tab];
        var isFresh = entry && entry.html && (Date.now() - entry.ts) < TAB_CACHE_TTL;
        if (isFresh || (entry && entry.loading)) return;
        fetchTabInto(tabCache, tab);
    }
    window.nshPrefetchTab = prefetchTab;

    function prefetchRequestDetail(rid){
        if (!rid) return;
        var entry = detailCache[rid];
        var isFresh = entry && entry.html && (Date.now() - entry.ts) < TAB_CACHE_TTL;
        if (isFresh || (entry && entry.loading)) return;
        detailCache[rid] = detailCache[rid] || {};
        detailCache[rid].loading = true;
        $.post(NSH.ajax_url, {
            action: SURFACE ? SURFACE.detailAction : 'nsh_admin_load_request_detail',
            nonce: NSH.admin_nonce || NSH.nonce,
            request_id: rid
        }, function(r){
            detailCache[rid].loading = false;
            if (r && r.success) {
                detailCache[rid].html = r.data.html;
                detailCache[rid].ts = Date.now();
                var idx = detailCacheOrder.indexOf(rid);
                if (idx !== -1) detailCacheOrder.splice(idx, 1);
                detailCacheOrder.push(rid);
                while (detailCacheOrder.length > DETAIL_CACHE_MAX) {
                    delete detailCache[detailCacheOrder.shift()];
                }
            }
        }).fail(function(){ detailCache[rid].loading = false; });
    }

    // Invalidate cached tab HTML after any action that changes what a tab
    // would show (delete/bulk-delete/create/status change/etc.), so the
    // instant-from-cache path never serves stale data for long. Individual
    // handlers call this; a blanket invalidation on any AJAX POST whose
    // action name suggests a mutation is the low-maintenance fallback.
    function invalidateTabCache(tab){
        if (tab) { delete tabCache[tab]; }
        else { tabCache = {}; }
    }
    window.nshInvalidateAdminTabCache = invalidateTabCache;

    $(document).ajaxSuccess(function(event, xhr, settings){
        if (!settings || !settings.data || typeof settings.data !== 'string') return;
        if (!/nsh_(bulk_delete|delete_request|delete_documents|delete_ticket|update_status|create|submit)/.test(settings.data)) return;
        invalidateTabCache(); // simplest correct behavior: drop the whole
                               // cache so the next switch is a real fetch.
    });

    function setActiveNav(tab){
        // .nsh-nav-item is the admin dashboard's nav class; the client
        // dashboard's links carry both .nsh-nav-link (their existing
        // style) AND .nsh-nav-item (added purely so this one selector
        // works for both — see nsh_client_nav() in shortcodes.php).
        $('.nsh-nav-item').removeClass('active').removeAttr('aria-current');
        if (tab) { $('.nsh-nav-item[data-tab="' + tab + '"]').addClass('active').attr('aria-current', 'page'); }
    }

    function loadingHtml(label){
        return '<div style="padding:60px 20px;text-align:center;color:#94a3b8;">' + (label || 'Loading…') + '</div>';
    }
    function errorHtml(msg){
        return '<div style="padding:60px 20px;text-align:center;color:#ef4444;">' + (msg || 'Something went wrong. Please try again.') + '</div>';
    }

    // Loads one admin-dashboard tab's content via AJAX (reusing the exact
    // same server-side render function a full page load would use — see
    // nsh_ajax_admin_load_tab in ajax.php) and swaps it into the tab
    // container without touching the header/nav around it.
    function renderTab(data, $container, opts){
        $container.attr('data-current-tab', data.tab).html(data.html);
        setActiveNav(data.tab);
        var s = stateGet(); s.currentTab = data.tab; stateSet(s);
        if (!opts.noPush) {
            var url = NSH.home_url + SURFACE.base + (data.tab !== SURFACE.defaultTab ? '?tab=' + data.tab : '');
            pushHistoryState({ nshAdmin: true, tab: data.tab }, url);
        }
        // Tab clicks never move the scroll position on their own — the
        // page just stays exactly where it was (that's the "same state"
        // an app-like tab switch should feel like). The only time we DO
        // move it is coming BACK to a tab via popstate/"← All Requests",
        // where opts.scrollY restores exactly where the user had
        // scrolled to on that tab before leaving it.
        if (typeof opts.scrollY === 'number') { window.scrollTo(0, opts.scrollY); }
        // The Requests and Support tabs' list-loading script
        // (nsh_admin_js() in shortcodes.php) is emitted only ONCE,
        // outside #nsh-admin-tab-container, so it never re-executes on
        // an AJAX tab-swap the way each other tab's own inline <script>
        // does. Without this, returning to either tab would show an
        // empty table forever ("Loading…" with nothing to populate it).
        if (data.tab === 'requests' && window.nshLoadAdminRequests) {
            window.nshLoadAdminRequests();
        } else if (data.tab === 'support' && window.nshLoadSupportTickets) {
            window.nshLoadSupportTickets();
        }
    }

    // Switches to a tab. If it's already sitting in the prefetch cache
    // (fresh, or even slightly stale), it renders IMMEDIATELY — no spinner,
    // no visible fetch — and, if stale, quietly re-fetches in the
    // background to refresh the cache for the next switch. Only a genuine
    // cold cache (first visit to a tab this session) falls back to a
    // real-time fetch, and even that skips the "Loading…" placeholder
    // unless the response takes long enough to actually need one.
    function nshAdminLoadTab(tab, opts){
        opts = opts || {};
        if (!SURFACE) return false; // not on a SPA dashboard — nothing to do
        var $container = SURFACE.$el;

        var cached = tabCache[tab];
        if (cached && cached.html) {
            renderTab(cached, $container, opts);
            if ((Date.now() - cached.ts) >= TAB_CACHE_TTL) {
                fetchTabInto(tabCache, tab); // stale — refresh silently for next time
            }
            return true;
        }

        // Cold cache: fetch now, but only show a loading placeholder if it
        // turns out to be slow, so a quick connection never sees one.
        var showedLoading = false;
        var loadingTimer = setTimeout(function(){
            showedLoading = true;
            $container.html(loadingHtml());
        }, 200);
        fetchTabInto(tabCache, tab, function(data){
            clearTimeout(loadingTimer);
            if (data) {
                renderTab(data, $container, opts);
            } else {
                // fetch genuinely failed (data is null — see fetchTabInto's
                // .fail() handler) — show the error immediately instead of
                // waiting on the 15s fallback below.
                $container.html(errorHtml('Connection error loading this tab. Please try again.'));
            }
        });
        // Fallback in case something unexpected leaves the callback above
        // never firing at all (e.g. a genuinely hung request).
        setTimeout(function(){
            var entry = tabCache[tab];
            if (entry && !entry.loading && !entry.html && showedLoading) {
                $container.html(errorHtml('Connection error loading this tab. Please try again.'));
            }
        }, 15000);
        return true;
    }
    window.nshAdminLoadTab = nshAdminLoadTab;

    // Loads a single request's detail view via AJAX (same render function
    // the standalone /nsh-request/{id} page uses — see
    // nsh_ajax_admin_load_request_detail in ajax.php) into the tab
    // container, so "View" never has to leave the dashboard.
    function renderDetail(html, rid, $container, opts){
        setActiveNav(null); // no tab is "current" while viewing a single request
        $container.html(html);
        if (!opts.noPush) {
            pushHistoryState({ nshAdmin: true, rid: rid }, NSH.home_url + SURFACE.base + '/request/' + rid);
        }
        // Same rule as tab clicks: opening a request never forces a scroll
        // jump on its own. Coming BACK from it restores the exact
        // position via opts.scrollY (see pushHistoryState/popstate).
        if (typeof opts.scrollY === 'number') { window.scrollTo(0, opts.scrollY); }
    }

    // Same instant-from-cache approach as nshAdminLoadTab: if this request
    // was already prefetched (typically because the user hovered/touched
    // the "View" link just before clicking it — see the hover-prefetch
    // binding below), it renders with zero visible fetch time.
    function nshAdminOpenRequestDetail(rid, opts){
        opts = opts || {};
        if (!SURFACE) return false; // not embedded — let the real <a href> navigate normally
        var $container = SURFACE.$el;

        var cached = detailCache[rid];
        if (cached && cached.html) {
            renderDetail(cached.html, rid, $container, opts);
            return true;
        }

        var showedLoading = false;
        var loadingTimer = setTimeout(function(){
            showedLoading = true;
            $container.html(loadingHtml('Loading request…'));
        }, 200);
        prefetchRequestDetail(rid);
        var poll = setInterval(function(){
            var entry = detailCache[rid];
            if (entry && entry.html) {
                clearInterval(poll);
                clearTimeout(loadingTimer);
                renderDetail(entry.html, rid, $container, opts);
            } else if (entry && !entry.loading) {
                clearInterval(poll);
                clearTimeout(loadingTimer);
                if (showedLoading) { $container.html(errorHtml('Connection error. Please try again.')); }
            }
        }, 100);
        return true;
    }
    window.nshAdminOpenRequestDetail = nshAdminOpenRequestDetail;

    // Hover/touch prefetch — start fetching a tab or a request's detail
    // view the moment the pointer signals intent (mouseenter, or
    // touchstart on mobile), so by the time the click actually lands the
    // content is usually already cached and the switch is instant.
    $(document).on('mouseenter touchstart', '.nsh-nav-item[data-tab]', function(){
        prefetchTab($(this).data('tab'));
    });
    $(document).on('mouseenter touchstart', '.nsh-view-request-link', function(){
        prefetchRequestDetail($(this).data('rid'));
    });

    // Tab nav clicks — progressive enhancement: the <a href> stays real
    // (works with no JS, middle-click, "open in new tab"); a plain left
    // click is intercepted so the tab swaps in place instead.
    $(document).on('click', '.nsh-nav-item[data-tab]', function(e){
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.which === 2) return; // let modified clicks behave normally
        var handled = nshAdminLoadTab($(this).data('tab'));
        if (handled) { e.preventDefault(); }
    });

    // "View" request links — same progressive-enhancement approach.
    $(document).on('click', '.nsh-view-request-link', function(e){
        if (e.metaKey || e.ctrlKey || e.shiftKey || e.which === 2) return;
        var handled = nshAdminOpenRequestDetail($(this).data('rid'));
        if (handled) { e.preventDefault(); }
    });

    // "← All Requests" back link inside an embedded detail view — this is
    // conceptually a Back action, so it now IS one: history.back() reuses
    // the exact same popstate handling real Back/Forward use below,
    // including restoring the list's scroll position (see
    // pushHistoryState()) instead of duplicating that logic here and
    // risking it drifting out of sync.
    $(document).on('click', '.nsh-back-to-admin-list', function(e){
        if (!SURFACE) return; // standalone page — let it navigate normally
        e.preventDefault();
        if (history.state && history.state.nshAdmin) {
            history.back();
        } else {
            // No SPA history to go back to (e.g. the detail view was the
            // very first page loaded, opened via a direct link) — fall
            // back to loading the list tab fresh.
            var s = stateGet();
            nshAdminLoadTab(s.currentTab || SURFACE.defaultTab);
        }
    });

    // Browser Back/Forward — mirrors whatever nshAdminLoadTab /
    // nshAdminOpenRequestDetail last pushed, so the dashboard's own history
    // entries behave like a normal multi-page site would, without actually
    // reloading the page each time.
    window.addEventListener('popstate', function(e){
        if (!SURFACE) return;
        var st = e.state;
        // st.scrollY (stamped by pushHistoryState onto the entry being
        // left, right before navigating forward) is where THIS entry's
        // page was scrolled to when the user was last on it — restoring
        // it here is what stops the visible jump when coming back.
        var scrollOpts = (st && typeof st.scrollY === 'number') ? { scrollY: st.scrollY } : {};
        if (st && st.rid) {
            nshAdminOpenRequestDetail(st.rid, $.extend({ noPush: true }, scrollOpts));
            return;
        }
        if (st && st.tab) {
            nshAdminLoadTab(st.tab, $.extend({ noPush: true }, scrollOpts));
            return;
        }
        // No captured state (e.g. the very first history entry, from the
        // original full page load) — fall back to reading the URL itself.
        var m = window.location.pathname.match(/\/request\/(\d+)/);
        if (m) { nshAdminOpenRequestDetail(parseInt(m[1], 10), { noPush: true }); return; }
        var params = new URLSearchParams(window.location.search);
        nshAdminLoadTab(params.get('tab') || SURFACE.defaultTab, { noPush: true });
    });

    // Stamp the initial page-load history entry with the same state shape
    // the SPA controller pushes for later entries, so the first Back press
    // after a tab switch resolves via e.state rather than the URL fallback.
    $(document).ready(function(){
        if (!SURFACE) return;
        var $container = SURFACE.$el;
        var initialTab = $container.attr('data-current-tab') || SURFACE.defaultTab;
        setActiveNav(initialTab);
        var s = stateGet(); s.currentTab = initialTab; stateSet(s);
        history.replaceState({ nshAdmin: true, tab: initialTab }, '', window.location.href);

        // NOTE: there is deliberately no automatic "warm every other tab in
        // the background" step here (an earlier version of this file had
        // one). On a typical shared-hosting PHP-FPM setup with only a
        // couple of worker processes, ANY extra background request —
        // sequenced or not — can still land at the exact moment the user
        // clicks something for real and make that real click wait behind
        // it. The only prefetching left is hover/touch-triggered (see the
        // mouseenter/touchstart bindings below), which only ever fires
        // immediately before an actual click and costs nothing when the
        // user doesn't follow through.
    });

})(jQuery);
// ── END Admin Dashboard SPA Controller ───────────────────────────────────────
