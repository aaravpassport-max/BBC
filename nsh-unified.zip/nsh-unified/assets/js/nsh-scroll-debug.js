/* NSH scroll diagnostics — loaded ONLY when the page URL contains ?nshdebug=1.
 *
 * Purpose: find out, on a real phone and a real theme, exactly WHAT moves the
 * page when "Next" is tapped. It records, with timestamps:
 *   - every call to window.scrollTo/scrollBy/scroll, Element.scrollIntoView/
 *     scrollTo/scrollBy, the scrollTop setter, focus() and history changes —
 *     with the script file + function that made the call (any script, theme
 *     and other plugins included);
 *   - every scroll event and which element scrolled;
 *   - every layout shift (what moved, from where to where) and document
 *     height change;
 *   - a position snapshot right after the tap and at 50 ms … 4 s later,
 *     including WHICH SECTION of the page is on screen.
 * Nothing is sent anywhere: the report is shown in a small panel at the bottom
 * of the screen with a Copy button. It never changes page behaviour.
 */
(function () {
    'use strict';
    if (window.__nshScrollDebug) { return; }
    window.__nshScrollDebug = true;

    var t0 = performance.now(), lines = [], pre = null, armedUntil = 0, envDone = false, MAXL = 700, inLog = false, rawScrollTopSet = null;

    // TRACE: any event -> ms since script start -> integer; no preconditions; never throws
    function now() { return Math.round(performance.now() - t0); }

    // TRACE: DOM node/window/document -> short readable selector like div#id.cls1.cls2; null-safe, never throws
    function sel(n) {
        try {
            if (n === window) { return 'window'; }
            if (n === document) { return 'document'; }
            if (!n || !n.nodeType) { return String(n); }
            var s = n.tagName ? n.tagName.toLowerCase() : '#' + n.nodeName;
            if (n.id) { s += '#' + n.id; }
            else if (n.className && typeof n.className === 'string') { s += '.' + n.className.trim().split(/\s+/).slice(0, 2).join('.'); }
            return s;
        } catch (e) { return '?'; }
    }

    // TRACE: called inside a patched API -> reads Error().stack -> returns the 4 nearest caller frames
    //        reduced to "function@file.js:line" ; works for Chrome ("at") and Safari/Firefox ("fn@url") formats
    function stack() {
        try {
            var a = (new Error()).stack.split('\n');
            if (/^Error/.test(a[0])) { a.shift(); }
            a = a.slice(2, 6).map(function (l) {
                l = l.replace(/^\s*at\s+/, '');
                return l.replace(/https?:\/\/[^\s)]*\/([^\/\s)?]+)(\?[^:\s)]*)?/g, '$1');
            });
            return a.join(' < ');
        } catch (e) { return ''; }
    }

    // TRACE: -> current scroll offsets of every candidate scroller + visual viewport -> one string
    function pos() {
        try {
            var vv = window.visualViewport, de = document.documentElement, b = document.body;
            return 'y=' + Math.round(window.pageYOffset) + ' html.st=' + Math.round(de.scrollTop) + ' body.st=' + Math.round(b ? b.scrollTop : 0) +
                (vv ? ' vv(top=' + Math.round(vv.offsetTop) + ',h=' + Math.round(vv.height) + ')' : '') + ' docH=' + de.scrollHeight;
        } catch (e) { return ''; }
    }

    // TRACE: (kind, text) -> appends "[ms] kind text" (max 700 lines) -> refreshes the panel; never throws
    function log(kind, msg) {
        if (lines.length >= MAXL || inLog) { return; }
        inLog = true; // the panel's own scrolling must never be recorded (would recurse)
        try {
            lines.push('[' + now() + '] ' + kind + ' ' + msg);
            if (pre) {
                pre.textContent = lines.join('\n');
                if (rawScrollTopSet) { rawScrollTopSet.call(pre, pre.scrollHeight); } else { pre.scrollTop = pre.scrollHeight; }
            }
        } finally { inLog = false; }
    }

    // TRACE: arguments object -> compact JSON-ish string (max 70 chars); never throws
    function fmt(args) {
        try {
            return Array.prototype.map.call(args, function (x) {
                if (x && x.nodeType) { return sel(x); }
                return JSON.stringify(x);
            }).join(',').slice(0, 70);
        } catch (e) { return '?'; }
    }

    // TRACE: (object, method name, label) -> replaces obj[name] with a logging wrapper that still calls the original
    //        postcondition: behaviour identical, one log line per call; no-op if the method does not exist
    function wrap(obj, name, label) {
        var orig = obj && obj[name];
        if (typeof orig !== 'function') { return; }
        obj[name] = function () {
            log('CALL', label + '(' + fmt(arguments) + ') on ' + sel(this) + ' | ' + pos() + ' | by ' + stack());
            return orig.apply(this, arguments);
        };
    }

    // TRACE: -> installs wrappers on every API that can move the page; runs once at script start
    function patch() {
        wrap(window, 'scrollTo', 'window.scrollTo');
        wrap(window, 'scrollBy', 'window.scrollBy');
        wrap(window, 'scroll', 'window.scroll');
        wrap(Element.prototype, 'scrollIntoView', 'scrollIntoView');
        wrap(Element.prototype, 'scrollIntoViewIfNeeded', 'scrollIntoViewIfNeeded');
        wrap(Element.prototype, 'scrollTo', 'el.scrollTo');
        wrap(Element.prototype, 'scrollBy', 'el.scrollBy');
        wrap(HTMLElement.prototype, 'focus', 'focus');
        wrap(history, 'pushState', 'history.pushState');
        wrap(history, 'replaceState', 'history.replaceState');
        try {
            var d = Object.getOwnPropertyDescriptor(Element.prototype, 'scrollTop');
            if (d && d.set) {
                rawScrollTopSet = d.set;
                Object.defineProperty(Element.prototype, 'scrollTop', {
                    configurable: true, enumerable: d.enumerable, get: d.get,
                    set: function (v) { if (this === pre) { d.set.call(this, v); return; } log('SET', 'scrollTop=' + Math.round(v) + ' on ' + sel(this) + ' | ' + pos() + ' | by ' + stack()); d.set.call(this, v); }
                });
            }
        } catch (e) { /* not patchable on this browser */ }
    }

    // TRACE: -> finds the wizard wrapper on the page -> returns its element or null
    function wizard() {
        return document.querySelector('.nsh-sl-wizard-wrap, .nsh-wizard-wrap');
    }

    // TRACE: -> which page section is under the middle of the screen right now -> short selector string
    function whatIsOnScreen() {
        try {
            var el = document.elementFromPoint(Math.round(window.innerWidth / 2), Math.round(window.innerHeight / 2));
            var sec = el && el.closest('section, footer, header, main, [data-elementor-type], .elementor-section, .elementor-top-section, .et_pb_section, .wp-block-group, .vc_row, article');
            var inForm = el && el.closest('#nsh-sl-wizard-container, .nsh-wizard-page-card, .nsh-sl-card');
            return (inForm ? 'FORM' : 'NOT-FORM') + ' el=' + sel(el) + ' section=' + sel(sec);
        } catch (e) { return '?'; }
    }

    // TRACE: -> writes one SNAP line: form top, scroll offsets, doc height, section on screen
    function snap(tag) {
        var w = wizard(), r = w ? w.getBoundingClientRect() : null;
        log('SNAP', tag + ' formTop=' + (r ? Math.round(r.top) : 'none') + ' innerH=' + window.innerHeight + ' | ' + pos() + ' | ' + whatIsOnScreen());
    }

    // TRACE: -> one-time environment facts (browser, scroller styles, scroll-related libraries, duplicate script copies,
    //        click handlers bound to the wizard) -> log lines; precondition: DOM ready
    function env() {
        if (envDone) { return; }
        envDone = true;
        try {
            var de = document.documentElement, b = document.body, cs = getComputedStyle(de), cb = getComputedStyle(b);
            log('ENV', 'UA=' + navigator.userAgent);
            log('ENV', 'viewport ' + window.innerWidth + 'x' + window.innerHeight + ' dpr=' + window.devicePixelRatio + ' scrollingElement=' + sel(document.scrollingElement));
            log('ENV', 'html overflow=' + cs.overflowX + '/' + cs.overflowY + ' scroll-behavior=' + cs.scrollBehavior + ' overflow-anchor=' + cs.overflowAnchor + ' height=' + cs.height + ' position=' + cs.position);
            log('ENV', 'body overflow=' + cb.overflowX + '/' + cb.overflowY + ' scroll-behavior=' + cb.scrollBehavior + ' height=' + cb.height + ' position=' + cb.position + ' transform=' + cb.transform);
            var srcs = [].map.call(document.scripts, function (s) { return s.src; }).filter(Boolean);
            var hits = srcs.filter(function (u) { return /lenis|locomotive|smooth|scrolltrigger|gsap|aos|scrollmagic|fullpage|elementor|nsh-app|jquery\.min|wpr|astra|divi|avada|flatsome/i.test(u); });
            log('ENV', 'scripts of interest: ' + hits.map(function (u) { return u.replace(/^https?:\/\/[^\/]+/, '').split('?')[0]; }).join(' , '));
            log('ENV', 'nsh-app.js copies loaded: ' + srcs.filter(function (u) { return /nsh-app\.js/.test(u); }).length);
            var globals = ['lenis', 'Lenis', 'LocomotiveScroll', 'ScrollTrigger', 'gsap', 'AOS', 'elementorFrontend', 'ScrollSmoother', 'fullpage_api', 'Swiper'].filter(function (g) { return typeof window[g] !== 'undefined'; });
            log('ENV', 'scroll-related globals present: ' + (globals.join(', ') || 'none'));
            var fixed = [].filter.call(document.querySelectorAll('body *'), function (n) {
                var p = getComputedStyle(n).position; if (p !== 'fixed' && p !== 'sticky') { return false; }
                var r = n.getBoundingClientRect(); return r.height > 0 && r.top < 200 && r.top > -50;
            }).slice(0, 6).map(function (n) { var r = n.getBoundingClientRect(); return sel(n) + '[' + getComputedStyle(n).position + ' top=' + Math.round(r.top) + ' h=' + Math.round(r.height) + ']'; });
            log('ENV', 'fixed/sticky near top: ' + (fixed.join(' ; ') || 'none'));
            var w = wizard();
            if (w) {
                var chain = [], n = w;
                while (n && n !== document.documentElement) { chain.push(sel(n)); n = n.parentElement; }
                log('ENV', 'wizard ancestors: ' + chain.slice(0, 9).join(' < '));
                var anc = []; n = w.parentElement;
                while (n && n !== document.documentElement) {
                    var c = getComputedStyle(n);
                    if (/(auto|scroll|hidden)/.test(c.overflowY) || c.position === 'sticky' || c.transform !== 'none') { anc.push(sel(n) + '{ov=' + c.overflowY + ',pos=' + c.position + ',tf=' + (c.transform !== 'none') + '}'); }
                    n = n.parentElement;
                }
                log('ENV', 'ancestors with overflow/sticky/transform: ' + (anc.join(' ; ') || 'none'));
            } else { log('ENV', 'no wizard on the page yet (pick a service first, then tap Next)'); }
        } catch (e) { log('ENV', 'error ' + e.message); }
    }

    // TRACE: first Next/Back tap -> reads jQuery's delegated click handlers on document -> logs how many exist and which
    //        mention wizard/step/next (reveals duplicate handlers from a second copy of the plugin script); runs once
    var handlersDone = false;
    function handlersInfo() {
        if (handlersDone) { return; }
        handlersDone = true;
        try {
            var $ = window.jQuery;
            if ($ && $._data) {
                var ev = $._data(document, 'events'), cl = (ev && ev.click) || [];
                log('ENV', 'document click handlers with a selector: ' + cl.filter(function (h) { return h.selector; }).length + ' ; wizard-related: ' +
                    cl.filter(function (h) { return h.selector && /wizard|step|next/i.test(h.selector); }).map(function (h) { return h.selector; }).join(' | '));
            } else { log('ENV', 'jQuery not available'); }
        } catch (e) { log('ENV', 'handlers error ' + e.message); }
    }

    // TRACE: click anywhere (capture) -> logs the click target, arms 4.5 s recording, schedules SNAP lines
    //        at 0/50/100/200/400/700/1000/1500/2500/4000 ms -> postcondition: the report shows the page position over time
    function onClick(e) {
        if (!envDone) { env(); }
        var t = e.target, isNav = !!(t && t.closest && t.closest('.nsh-wizard-next, .nsh-wizard-prev, .nsh-sl-btn-next, .nsh-sl-btn-back'));
        if (!isNav) { return; }
        handlersInfo();
        armedUntil = Date.now() + 4500;
        log('CLICK', sel(t) + ' ("' + (t.textContent || '').trim().slice(0, 20) + '") activeElement=' + sel(document.activeElement) + ' | ' + pos());
        snap('before');
        [0, 50, 100, 200, 400, 700, 1000, 1500, 2500, 4000].forEach(function (ms) { setTimeout(function () { snap('+' + ms + 'ms'); }, ms + 1); });
    }

    // TRACE: -> registers passive listeners for scroll/focus/resize/hash/popstate and the layout-shift + ResizeObserver
    //        observers; each only logs while armed (within 4.5 s after a Next/Back tap)
    function observe() {
        var lastY = null;
        document.addEventListener('scroll', function (e) {
            if (Date.now() > armedUntil) { return; }
            if (e.target && e.target.nodeType === 1 && (e.target === pre || (e.target.closest && e.target.closest('#nsh-dbg-panel')))) { return; }
            var y = Math.round(window.pageYOffset);
            if (e.target === document && y === lastY) { return; }
            lastY = y;
            log('SCROLL', 'event on ' + sel(e.target) + ' | ' + pos());
        }, { capture: true, passive: true });
        document.addEventListener('focusin', function (e) { if (Date.now() <= armedUntil) { log('FOCUS', 'focusin ' + sel(e.target)); } }, true);
        window.addEventListener('hashchange', function () { log('HASH', 'hashchange -> ' + location.hash); });
        window.addEventListener('popstate', function () { log('HASH', 'popstate'); });
        window.addEventListener('resize', function () { if (Date.now() <= armedUntil) { log('RESIZE', 'window ' + window.innerWidth + 'x' + window.innerHeight); } });
        if (window.visualViewport) {
            window.visualViewport.addEventListener('resize', function () { if (Date.now() <= armedUntil) { log('RESIZE', 'visualViewport h=' + Math.round(window.visualViewport.height) + ' top=' + Math.round(window.visualViewport.offsetTop)); } });
        }
        try {
            new PerformanceObserver(function (list) {
                list.getEntries().forEach(function (en) {
                    if (Date.now() > armedUntil) { return; }
                    var src = (en.sources || []).slice(0, 3).map(function (s) {
                        var a = s.previousRect, c = s.currentRect;
                        return sel(s.node) + ' top ' + Math.round(a.top) + '->' + Math.round(c.top) + ' h ' + Math.round(a.height) + '->' + Math.round(c.height);
                    }).join(' ; ');
                    log('SHIFT', 'layout-shift value=' + en.value.toFixed(3) + ' recentInput=' + en.hadRecentInput + ' : ' + src);
                });
            }).observe({ type: 'layout-shift', buffered: false });
        } catch (e) { log('ENV', 'layout-shift observer not supported here'); }
        try {
            var lastH = 0;
            new ResizeObserver(function () {
                var h = document.documentElement.scrollHeight;
                if (h !== lastH && Date.now() <= armedUntil && lastH) { log('DOCH', 'document height ' + lastH + ' -> ' + h); }
                lastH = h;
            }).observe(document.documentElement);
        } catch (e) { /* optional */ }
        document.addEventListener('click', onClick, true);
    }

    // TRACE: -> builds the fixed bottom panel (report text, Copy / Clear / Hide) ; never affects page layout (position:fixed)
    function panel() {
        var box = document.createElement('div');
        box.id = 'nsh-dbg-panel';
        box.style.cssText = 'position:fixed;left:0;right:0;bottom:0;z-index:2147483647;background:rgba(10,15,25,.96);color:#b6f7c1;font:10px/1.35 monospace;max-height:34vh;display:flex;flex-direction:column;border-top:2px solid #22c55e;';
        var bar = document.createElement('div');
        bar.style.cssText = 'display:flex;gap:6px;padding:5px 6px;background:#0b1220;flex:0 0 auto;align-items:center;';
        function btn(label, fn) {
            var b = document.createElement('button');
            b.type = 'button'; b.textContent = label;
            b.style.cssText = 'font:11px sans-serif;padding:5px 10px;border-radius:6px;border:0;background:#22c55e;color:#04210f;';
            b.addEventListener('click', function (e) { e.stopPropagation(); fn(); });
            bar.appendChild(b);
        }
        var title = document.createElement('span');
        title.textContent = 'NSH scroll debug — tap Next, then Copy';
        title.style.cssText = 'color:#fff;font:11px sans-serif;flex:1;';
        bar.appendChild(title);
        btn('Copy', function () {
            var txt = window.__nshScrollDebugReport();
            if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(txt).then(function () { title.textContent = 'Copied'; }, function () { fallbackCopy(txt); }); }
            else { fallbackCopy(txt); }
        });
        btn('Clear', function () { lines = []; pre.textContent = ''; });
        btn('Hide', function () { box.style.display = 'none'; });
        function fallbackCopy(txt) {
            var ta = document.createElement('textarea'); ta.value = txt; ta.style.cssText = 'position:fixed;left:0;top:0;width:1px;height:1px;opacity:0;';
            document.body.appendChild(ta); ta.focus(); ta.select();
            try { document.execCommand('copy'); title.textContent = 'Copied'; } catch (e) { title.textContent = 'Copy failed - long-press the text'; }
            document.body.removeChild(ta);
        }
        pre = document.createElement('pre');
        pre.style.cssText = 'margin:0;padding:6px;overflow:auto;white-space:pre-wrap;word-break:break-all;flex:1 1 auto;-webkit-user-select:text;user-select:text;';
        pre.textContent = lines.join('\n');
        box.appendChild(bar); box.appendChild(pre);
        document.body.appendChild(box);
    }

    // TRACE: -> returns the whole report as one string (what Copy puts on the clipboard)
    window.__nshScrollDebugReport = function () { return lines.join('\n'); };

    patch();
    observe();
    function ready() { panel(); env(); log('INFO', 'diagnostics armed. Fill step 1, tap Next, wait 5 seconds, then tap Copy and send the text.'); }
    if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', ready); } else { ready(); }
})();
