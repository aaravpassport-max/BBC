<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Unified authentication — ONE sign-in for client, staff and admin accounts.
 * WordPress only supplies the user table, password hashing and auth cookies; everything the person sees is plugin UI.
 */

// TRACE: any role check → user id (0 = current) → 'admin' | 'staff' | 'client' | '' (no dashboard). Precedence admin > staff > client
//        edge: a user holding several roles gets the highest group; unknown roles → ''
function nsh_plat_group( $uid = 0 ) {
    $uid  = $uid ? (int) $uid : get_current_user_id();
    if ( ! $uid ) { return ''; }
    $u = get_userdata( $uid );
    if ( ! $u ) { return ''; }
    $roles = (array) $u->roles;
    $admin_roles = array_merge( array( 'administrator', 'nsh_admin' ), (array) nsh_plat_get( 'admin_roles' ) );
    if ( array_intersect( $roles, $admin_roles ) || user_can( $u, 'manage_options' ) ) { return 'admin'; }
    $staff_roles = apply_filters( 'nsh_plat_staff_roles', array_merge( array( 'nsh_manager' ), (array) nsh_plat_get( 'staff_roles' ) ) );
    if ( array_intersect( $roles, $staff_roles ) ) { return 'staff'; }
    if ( in_array( 'nsh_client', $roles, true ) ) { return 'client'; }
    return '';
}

// TRACE: dashboards → group → the configured slug of that group's dashboard → string
function nsh_plat_slug_for( $group ) {
    $map = array( 'admin' => 'admin_slug', 'staff' => 'staff_slug', 'client' => 'client_slug' );
    return isset( $map[ $group ] ) ? (string) nsh_plat_get( $map[ $group ] ) : '';
}

// TRACE: redirects after sign-in → user id (0 = current) → the URL of that user's own dashboard, or the sign-in page when the account has none → string
function nsh_plat_home_url( $uid = 0 ) {
    $g = nsh_plat_group( $uid );
    if ( $g === '' ) { return nsh_login_page_url(); }
    if ( $g === 'staff' && ! user_can( $uid ? $uid : get_current_user_id(), 'nsh_view_all' ) && function_exists( 'nsh_plat_blog_enabled_for' ) && nsh_plat_blog_enabled_for( $uid ) ) {
        return nsh_plat_dash_url( 'staff', nsh_plat_get( 'blog_slug' ) . '/' );
    }
    return nsh_plat_dash_url( $g );
}

// TRACE: signed-in link → none → nonce-protected sign-out URL on the unified sign-in route → string
function nsh_logout_url() {
    return add_query_arg( array( 'nsh_logout' => 1, '_wpnonce' => wp_create_nonce( 'nsh_logout' ) ), nsh_login_page_url() );
}

// TRACE: redirect_to validation → candidate URL, user id → candidate when it is a same-site URL inside a dashboard this user may open, else '' → string
function nsh_plat_safe_target( $candidate, $uid ) {
    $candidate = wp_validate_redirect( esc_url_raw( (string) $candidate ), '' );
    if ( $candidate === '' ) { return ''; }
    $g = nsh_plat_group( $uid );
    if ( $g === '' ) { return ''; }
    $own = nsh_plat_dash_url( $g );
    return strpos( trailingslashit( $candidate ), trailingslashit( $own ) ) === 0 ? $candidate : '';
}

/* ───────────── lockout (per client address and per typed login) ───────────── */

// TRACE: lockout buckets → none → REMOTE_ADDR only (X-Forwarded-For can be forged to dodge the limit) → IP string
function nsh_plat_ip() {
    $ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) ) : '';
    return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '0.0.0.0';
}
function nsh_plat_lock_keys( $login ) {
    return array( 'ip' => 'nsh_lk_ip_' . md5( nsh_plat_ip() ), 'user' => 'nsh_lk_u_' . md5( strtolower( (string) $login ) ) );
}
// TRACE: before checking a password → login → seconds left on the longest active lock (0 = not locked) → int
function nsh_plat_locked_for( $login ) {
    $left = 0;
    foreach ( nsh_plat_lock_keys( $login ) as $k ) {
        $c = get_transient( $k );
        if ( is_array( $c ) && (int) $c['lock'] > time() ) { $left = max( $left, (int) $c['lock'] - time() ); }
    }
    return $left;
}
// TRACE: wrong password → login → counts a failure for the address (4× the limit, shared networks) and for the login; reaching a limit locks that bucket
function nsh_plat_register_failure( $login ) {
    $max = max( 1, (int) nsh_plat_get( 'login_max_attempts' ) );
    $win = max( 1, (int) nsh_plat_get( 'login_lockout_min' ) ) * MINUTE_IN_SECONDS;
    foreach ( nsh_plat_lock_keys( $login ) as $which => $k ) {
        $limit = $which === 'ip' ? $max * 4 : $max;
        $c = get_transient( $k );
        if ( ! is_array( $c ) || (int) $c['exp'] <= time() ) { $c = array( 'n' => 0, 'exp' => time() + $win, 'lock' => 0 ); }
        $c['n']++;
        if ( $c['n'] >= $limit ) { $c['lock'] = time() + $win; $c['n'] = 0; $c['exp'] = $c['lock']; }
        set_transient( $k, $c, max( MINUTE_IN_SECONDS, (int) $c['exp'] - time() + MINUTE_IN_SECONDS ) );
    }
}
function nsh_plat_clear_failures( $login ) { $k = nsh_plat_lock_keys( $login ); delete_transient( $k['user'] ); }

/* ───────────── password sign-in (AJAX) ───────────── */

add_action( 'wp_ajax_nopriv_nsh_login', 'nsh_ajax_login' );
add_action( 'wp_ajax_nsh_login',        'nsh_ajax_login' );
// TRACE: sign-in form submit (nsh-app.js #nsh-login-form) → POST nonce, login (e-mail or username), password, remember, redirect_to, honeypot
//        → verifies nonce → honeypot → lockout → wp_authenticate → account must belong to a dashboard group → sets the auth cookie → returns the role's dashboard URL
//        pre: none → post: success = cookie set + {redirect}; failure = generic message, never says whether the account exists → edge: locked (429-style message with minutes), no-dashboard roles, empty fields
function nsh_ajax_login() {
    $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['nonce'] ) ) : '';
    if ( ! wp_verify_nonce( $nonce, 'nsh_login_nonce' ) ) {
        wp_send_json_error( array( 'message' => 'This page has expired. Please reload and try again.' ), 403 );
    }
    $login = '';
    foreach ( array( 'login', 'email' ) as $k ) { if ( ! empty( $_POST[ $k ] ) ) { $login = sanitize_text_field( wp_unslash( (string) $_POST[ $k ] ) ); break; } }
    $pass  = isset( $_POST['password'] ) ? (string) wp_unslash( $_POST['password'] ) : '';
    if ( ! empty( $_POST['nsh_website'] ) ) { nsh_plat_register_failure( $login ); wp_send_json_error( array( 'message' => 'Incorrect e-mail, username or password.' ) ); }
    if ( $login === '' || $pass === '' ) { wp_send_json_error( array( 'message' => 'Enter your e-mail or username and your password.' ) ); }
    $left = nsh_plat_locked_for( $login );
    if ( $left > 0 ) { wp_send_json_error( array( 'message' => sprintf( 'Too many failed attempts. Try again in %d minute(s).', max( 1, (int) ceil( $left / 60 ) ) ) ), 429 ); }
    $name = $login;
    if ( is_email( $login ) ) { $by = get_user_by( 'email', $login ); if ( $by ) { $name = $by->user_login; } }
    $user = wp_authenticate( $name, $pass );
    if ( is_wp_error( $user ) ) {
        nsh_plat_register_failure( $login );
        $left = nsh_plat_locked_for( $login );
        if ( $left > 0 ) { wp_send_json_error( array( 'message' => sprintf( 'Too many failed attempts. Try again in %d minute(s).', max( 1, (int) ceil( $left / 60 ) ) ) ), 429 ); }
        wp_send_json_error( array( 'message' => 'Incorrect e-mail, username or password.' ) );
    }
    if ( nsh_plat_group( $user->ID ) === '' ) {
        nsh_plat_register_failure( $login );
        wp_send_json_error( array( 'message' => 'This account does not have access to a dashboard. Contact the site administrator.' ), 403 );
    }
    nsh_plat_clear_failures( $login );
    wp_set_current_user( $user->ID );
    wp_set_auth_cookie( $user->ID, ! empty( $_POST['remember'] ), is_ssl() );
    do_action( 'wp_login', $user->user_login, $user );
    $to = isset( $_POST['redirect_to'] ) ? nsh_plat_safe_target( wp_unslash( (string) $_POST['redirect_to'] ), $user->ID ) : '';
    wp_send_json_success( array( 'redirect' => $to !== '' ? $to : nsh_plat_home_url( $user->ID ) ) );
}

add_action( 'wp_login', 'nsh_plat_record_login', 10, 2 );
// TRACE: wp_login action → login, user → stores the UTC time of the latest sign-in (shown to admins in Team) → void
function nsh_plat_record_login( $login, $user ) {
    if ( $user instanceof WP_User && nsh_plat_group( $user->ID ) !== '' ) { update_user_meta( $user->ID, 'nsh_last_login', gmdate( 'Y-m-d H:i:s' ) ); }
}

/* ───────────── magic link ───────────── */

add_action( 'wp_ajax_nopriv_nsh_magic_link', 'nsh_ajax_magic_link' );
// TRACE: magic-link form → POST nonce, e-mail → e-mails a 30-minute one-time link when the account exists and has a dashboard; the reply is identical either way
//        edge: more than 3 requests per address per 15 min are silently dropped (mail-bomb guard)
function nsh_ajax_magic_link() {
    $nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( (string) $_POST['nonce'] ) ) : '';
    if ( ! wp_verify_nonce( $nonce, 'nsh_frontend_nonce' ) ) { wp_send_json_error( array( 'message' => 'This page has expired. Please reload and try again.' ), 403 ); }
    $email = sanitize_email( isset( $_POST['email'] ) ? wp_unslash( $_POST['email'] ) : '' );
    $ok    = array( 'message' => 'If an account exists for that e-mail, a sign-in link has been sent.' );
    if ( ! is_email( $email ) ) { wp_send_json_error( array( 'message' => 'Enter a valid e-mail address.' ) ); }
    $rk = 'nsh_ml_' . md5( strtolower( $email ) );
    $n  = (int) get_transient( $rk );
    if ( $n >= 3 ) { wp_send_json_success( $ok ); }
    set_transient( $rk, $n + 1, 15 * MINUTE_IN_SECONDS );
    $user = get_user_by( 'email', $email );
    if ( $user && nsh_plat_group( $user->ID ) !== '' ) { nsh_send_magic_link( $user->ID, $email ); }
    wp_send_json_success( $ok );
}

/* ───────────── native WordPress entry points follow the same rules ───────────── */

add_filter( 'login_url', 'nsh_plat_login_url_filter', 10, 3 );
// TRACE: wp_login_url() everywhere (auth_redirect for wp-admin included) → URL, redirect, force_reauth → the unified sign-in page with redirect_to kept → string
function nsh_plat_login_url_filter( $url, $redirect = '', $force_reauth = false ) {
    $u = home_url( '/' . nsh_plat_get( 'login_slug' ) . '/' );
    return $redirect !== '' ? add_query_arg( 'redirect_to', rawurlencode( (string) $redirect ), $u ) : $u;
}

add_filter( 'logout_redirect', 'nsh_plat_logout_redirect', 10, 1 );
// TRACE: wp-login.php?action=logout → default target → the unified sign-in page with a "signed out" notice → string
function nsh_plat_logout_redirect( $to ) { return add_query_arg( 'msg', 'out', nsh_login_page_url() ); }

add_filter( 'login_redirect', 'nsh_plat_login_redirect', 10, 3 );
// TRACE: wp-login.php sign-ins → default target, requested target, user → people with a dashboard land on it unless a specific non-admin target was requested → string
function nsh_plat_login_redirect( $to, $requested, $user ) {
    if ( ! ( $user instanceof WP_User ) || is_wp_error( $user ) ) { return $to; }
    $g = nsh_plat_group( $user->ID );
    if ( $g === '' ) { return $to; }
    if ( $g === 'admin' && $requested !== '' && strpos( $requested, admin_url() ) === 0 ) { return $to; }
    return nsh_plat_home_url( $user->ID );
}

// TRACE: access lockdown → user id → true when this account must never see wp-admin / wp-login / REST (clients always; staff when "block wp-admin" is on) → bool
function nsh_plat_is_locked( $uid = 0 ) {
    $uid = $uid ? (int) $uid : get_current_user_id();
    if ( ! $uid || user_can( $uid, 'manage_options' ) ) { return false; }
    $g = nsh_plat_group( $uid );
    if ( $g === 'client' ) { return true; }
    return $g === 'staff' && (int) nsh_plat_get( 'block_wp_admin' ) === 1;
}

add_action( 'admin_init', 'nsh_plat_lock_admin', 1 );
// TRACE: admin_init (wp-admin pages, admin-post.php, admin-ajax.php) → none → locked accounts: ajax actions outside this plugin get 403 JSON, all other admin requests go back to their dashboard
function nsh_plat_lock_admin() {
    if ( ! is_user_logged_in() || ! nsh_plat_is_locked() ) { return; }
    if ( wp_doing_ajax() ) {
        $a = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( (string) $_REQUEST['action'] ) ) : '';
        $allow = apply_filters( 'nsh_plat_ajax_allowlist', array( 'heartbeat' ) );
        if ( strpos( $a, 'nsh_' ) === 0 || strpos( $a, 'sbm_' ) === 0 || in_array( $a, $allow, true ) ) { return; }
        wp_send_json_error( array( 'message' => 'This account can only use its dashboard.' ), 403 );
    }
    wp_safe_redirect( nsh_plat_home_url() );
    exit;
}

add_action( 'login_init', 'nsh_plat_lock_wp_login' );
// TRACE: login_init (wp-login.php) → none → a signed-in locked account opening wp-login.php (except logout / password reset) goes to its dashboard
function nsh_plat_lock_wp_login() {
    if ( ! is_user_logged_in() || ! nsh_plat_is_locked() ) { return; }
    $a = isset( $_REQUEST['action'] ) ? sanitize_key( wp_unslash( (string) $_REQUEST['action'] ) ) : '';
    if ( in_array( $a, array( 'logout', 'postpass', 'rp', 'resetpass' ), true ) ) { return; }
    wp_safe_redirect( nsh_plat_home_url() );
    exit;
}

add_filter( 'rest_authentication_errors', 'nsh_plat_rest_lock', 99 );
// TRACE: REST requests → previous result → locked accounts get 403 on every route (dashboards use admin-ajax only) → null | WP_Error
function nsh_plat_rest_lock( $result ) {
    if ( $result !== null ) { return $result; }
    if ( is_user_logged_in() && nsh_plat_is_locked() ) { return new WP_Error( 'nsh_rest_forbidden', 'This account can only use its dashboard.', array( 'status' => 403 ) ); }
    return $result;
}

add_filter( 'show_admin_bar', 'nsh_plat_admin_bar', 99 );
// TRACE: show_admin_bar → current flag → false for clients always, and for staff when "hide admin bar" is on → bool
function nsh_plat_admin_bar( $show ) {
    if ( ! is_user_logged_in() ) { return $show; }
    $g = nsh_plat_group();
    if ( $g === 'client' ) { return false; }
    if ( $g === 'staff' && (int) nsh_plat_get( 'hide_admin_bar' ) === 1 ) { return false; }
    return $show;
}

// TRACE: staff dashboard + tab loader → surface admin|staff → the tabs that surface may open (admins: all; staff: the "Staff can open" setting) → array key => label
function nsh_plat_tabs_for( $surface ) {
    $all = nsh_plat_all_tabs();
    if ( $surface !== 'staff' || nsh_plat_group() === 'admin' ) { return $all; }
    $allowed = (array) nsh_plat_get( 'staff_tabs' );
    return array_intersect_key( $all, array_flip( $allowed ) );
}
// TRACE: tab AJAX → tab key → true when the current account may open that tab → bool
function nsh_plat_tab_allowed( $tab ) {
    $g = nsh_plat_group();
    if ( $g === 'admin' ) { return true; }
    return $g === 'staff' && isset( nsh_plat_tabs_for( 'staff' )[ $tab ] );
}
