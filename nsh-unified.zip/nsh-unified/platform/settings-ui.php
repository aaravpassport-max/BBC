<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * "Dashboards & Access" — the administrator UI for the standalone dashboards: addresses, who may sign in where, staff tabs, lockout, redirects.
 * Rendered inside the Services Hub → Settings tab; saves through the AJAX endpoint below into nsh_plat_save() (which validates every slug server-side).
 */
add_action( 'wp_ajax_nsh_plat_save', 'nsh_ajax_plat_save' );
// TRACE: Settings "Save" → nonce + admin check → posted fields → nsh_plat_save() (reserved/duplicate/page-conflicting slugs rejected) → JSON {saved, urls}; validation errors come back as one readable message
//        edge: nothing is half-saved: when any slug is invalid none of the four addresses change, and the message names which one
function nsh_ajax_plat_save() {
    nsh_check_nonce();
    nsh_require_admin();
    $in = array();
    foreach ( array( 'login_slug', 'client_slug', 'admin_slug', 'staff_slug', 'blog_slug', 'brand_name', 'login_max_attempts', 'login_lockout_min' ) as $k ) { if ( isset( $_POST[ $k ] ) ) { $in[ $k ] = wp_unslash( (string) $_POST[ $k ] ); } }
    foreach ( array( 'legacy_redirects', 'hide_admin_bar', 'block_wp_admin' ) as $k ) { $in[ $k ] = ! empty( $_POST[ $k ] ) && $_POST[ $k ] !== '0' ? 1 : 0; }
    foreach ( array( 'staff_tabs', 'admin_roles', 'staff_roles' ) as $k ) { $in[ $k ] = isset( $_POST[ $k ] ) ? array_map( 'sanitize_key', (array) wp_unslash( $_POST[ $k ] ) ) : array(); }
    $r = nsh_plat_save( $in );
    if ( ! $r['ok'] ) { wp_send_json_error( array( 'message' => implode( ' ', $r['errors'] ) ) ); }
    wp_send_json_success( array( 'urls' => array( 'login' => nsh_plat_login_url(), 'client' => nsh_plat_dash_url( 'client' ), 'admin' => nsh_plat_dash_url( 'admin' ), 'staff' => nsh_plat_dash_url( 'staff' ) ), 'message' => 'Saved. The new addresses are live now.' ) );
}

// TRACE: Settings tab, section "dashboards" → none → the configuration form pre-filled from nsh_plat_get(); every control carries a label; the current live URLs are listed at the top → HTML string
function nsh_settings_dashboards() {
    if ( ! nsh_is_admin_user() ) { return '<div class="nsh-settings-section"><p>Administrator access is required to change dashboard settings.</p></div>'; }
    $o = nsh_plat_get();
    $e = 'esc_attr';
    $row = function ( $id, $label, $val, $hint = '', $type = 'text' ) use ( $e ) {
        return '<div class="nsh-plat-f"><label for="' . $e( $id ) . '">' . esc_html( $label ) . '</label><input type="' . $e( $type ) . '" id="' . $e( $id ) . '" class="nsh-plat-inp" data-k="' . $e( substr( $id, 9 ) ) . '" value="' . $e( $val ) . '">' . ( $hint ? '<small>' . esc_html( $hint ) . '</small>' : '' ) . '</div>';
    };
    $chk = function ( $id, $label, $val, $hint = '' ) use ( $e ) {
        return '<div class="nsh-plat-f"><label class="nsh-plat-c"><input type="checkbox" id="' . $e( $id ) . '" class="nsh-plat-chk" data-k="' . $e( substr( $id, 9 ) ) . '"' . checked( (int) $val, 1, false ) . '> <span>' . esc_html( $label ) . '</span></label>' . ( $hint ? '<small>' . esc_html( $hint ) . '</small>' : '' ) . '</div>';
    };
    $h  = '<div class="nsh-settings-section" id="nsh-plat-form">';
    $h .= '<h2 style="margin:0 0 6px">Dashboards &amp; Access</h2><p style="margin:0 0 16px;color:#64748b">Each dashboard is a complete app on its own address — no shortcode, page or theme needed. Change the addresses here; WordPress rewrite rules refresh automatically.</p>';
    $h .= '<div class="nsh-plat-urls" style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px 16px;margin-bottom:16px"><strong>Live addresses</strong><ul style="margin:8px 0 0;padding-left:18px">';
    foreach ( array( 'Sign in' => nsh_plat_login_url(), 'Client dashboard' => nsh_plat_dash_url( 'client' ), 'Admin dashboard' => nsh_plat_dash_url( 'admin' ), 'Staff dashboard' => nsh_plat_dash_url( 'staff' ) ) as $l => $u ) { $h .= '<li id="nsh-plat-url-' . $e( sanitize_title( $l ) ) . '">' . esc_html( $l ) . ': <a href="' . esc_url( $u ) . '" target="_blank" rel="noopener">' . esc_html( $u ) . '</a></li>'; }
    if ( function_exists( '\\NSH\\Blog\\Front::url' ) || class_exists( '\\NSH\\Blog\\Front' ) ) { $h .= '<li>Public blog: <a href="' . esc_url( \NSH\Blog\Front::url( 'home' ) ) . '" target="_blank" rel="noopener">' . esc_html( \NSH\Blog\Front::url( 'home' ) ) . '</a> <small>(change it in the blog editor → Blog settings)</small></li>'; }
    $h .= '</ul></div><div class="nsh-plat-grid" style="display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(240px,1fr))">';
    $h .= $row( 'nsh-plat-login_slug', 'Sign-in address', $o['login_slug'], 'One sign-in page for everyone.' ) . $row( 'nsh-plat-client_slug', 'Client dashboard address', $o['client_slug'] ) . $row( 'nsh-plat-admin_slug', 'Admin dashboard address', $o['admin_slug'] ) . $row( 'nsh-plat-staff_slug', 'Staff dashboard address', $o['staff_slug'] ) . $row( 'nsh-plat-blog_slug', 'Blog editor path (inside the admin/staff dashboards)', $o['blog_slug'], 'For example /' . $o['admin_slug'] . '/' . $o['blog_slug'] . '/' ) . $row( 'nsh-plat-brand_name', 'Brand name on sign-in and dashboards', $o['brand_name'], 'Blank uses the site name.' );
    $h .= '</div><h3 style="margin:20px 0 6px">Who can sign in where</h3><p style="margin:0 0 8px;color:#64748b">Administrators always reach the admin dashboard; clients always reach the client dashboard. Add further WordPress roles below if needed. Vendors and other roles have no dashboard.</p><div class="nsh-plat-grid" style="display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(260px,1fr))">';
    $names = wp_roles()->role_names; $skip = array( 'administrator', 'nsh_client' );
    foreach ( array( 'admin_roles' => 'Extra roles for the admin dashboard', 'staff_roles' => 'Extra roles for the staff dashboard' ) as $k => $label ) {
        $h .= '<fieldset class="nsh-plat-f" data-roles="' . $e( $k ) . '"><legend style="font-weight:700;font-size:13px">' . esc_html( $label ) . '</legend>';
        foreach ( $names as $slug => $nm ) { if ( in_array( $slug, $skip, true ) || ( $k === 'admin_roles' && $slug === 'nsh_admin' ) ) { continue; } $h .= '<label class="nsh-plat-c"><input type="checkbox" value="' . $e( $slug ) . '"' . checked( in_array( $slug, (array) $o[ $k ], true ), true, false ) . '> <span>' . esc_html( translate_user_role( $nm ) ) . '</span></label>'; }
        $h .= '</fieldset>';
    }
    $h .= '<fieldset class="nsh-plat-f" data-roles="staff_tabs"><legend style="font-weight:700;font-size:13px">Tabs visible to staff</legend>';
    foreach ( nsh_plat_all_tabs() as $slug => $nm ) { $h .= '<label class="nsh-plat-c"><input type="checkbox" value="' . $e( $slug ) . '"' . checked( in_array( $slug, (array) $o['staff_tabs'], true ), true, false ) . '> <span>' . esc_html( $nm ) . '</span></label>'; }
    $h .= '</fieldset></div><h3 style="margin:20px 0 6px">Security &amp; behaviour</h3>';
    $h .= $chk( 'nsh-plat-hide_admin_bar', 'Hide the WordPress toolbar for dashboard accounts', $o['hide_admin_bar'] ) . $chk( 'nsh-plat-block_wp_admin', 'Keep staff accounts out of wp-admin (clients are always kept out)', $o['block_wp_admin'] ) . $chk( 'nsh-plat-legacy_redirects', 'Redirect the old /nsh-… addresses to the new ones', $o['legacy_redirects'], 'Keeps bookmarks and e-mailed links working.' );
    $h .= '<div class="nsh-plat-grid" style="display:grid;gap:12px;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));margin-top:8px">' . $row( 'nsh-plat-login_max_attempts', 'Failed sign-ins before lock-out', $o['login_max_attempts'], '3 – 50', 'number' ) . $row( 'nsh-plat-login_lockout_min', 'Lock-out length (minutes)', $o['login_lockout_min'], '1 – 1440', 'number' ) . '</div>';
    $h .= '<div style="margin-top:18px;display:flex;gap:10px;align-items:center;flex-wrap:wrap"><button type="button" class="nsh-btn nsh-btn-primary" id="nsh-plat-save">Save dashboard settings</button><span id="nsh-plat-msg" role="status" aria-live="polite"></span></div></div>';
    return $h;
}
