<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Plugin-owned routing — /login/, /client-dashboard/, /admin-dashboard/, /staff-dashboard/ (slugs configurable) and their sub-routes.
 * No WordPress page or shortcode is involved; the plugin answers the URL itself and prints a complete, theme-free document.
 */

// TRACE: link builders → none → the unified sign-in URL (pretty permalink or ?nsh_route=login) → string
function nsh_plat_login_url() {
    return get_option( 'permalink_structure' ) ? home_url( '/' . nsh_plat_get( 'login_slug' ) . '/' ) : add_query_arg( 'nsh_route', 'login', home_url( '/' ) );
}
function nsh_login_page_url() { return nsh_plat_login_url(); }

// TRACE: link builders → request id, group ('' = neutral gateway that forwards after sign-in) → URL of that request inside the right dashboard → string
function nsh_request_url( $rid, $group = '' ) {
    $rid = (int) $rid;
    if ( $group === '' ) { return add_query_arg( 'open_request', $rid, nsh_plat_login_url() ); }
    return nsh_plat_dash_url( $group, 'request/' . $rid . '/' );
}

// TRACE: link builders → none → dashboard URLs of the three groups → string
function nsh_client_dashboard_url() { return nsh_plat_dash_url( 'client' ); }
function nsh_admin_dashboard_url()  { return nsh_plat_dash_url( 'admin' ); }
function nsh_staff_dashboard_url()  { return nsh_plat_dash_url( 'staff' ); }

add_filter( 'query_vars', 'nsh_plat_query_vars' );
function nsh_plat_query_vars( $v ) { return array_merge( $v, array( 'nsh_route', 'nsh_rid', 'nsh_sub', 'nsh_blog_path' ) ); }

add_action( 'init', 'nsh_plat_register_routes', 5 );
// TRACE: init → none → registers every route rule (top priority so a same-named page can never shadow a dashboard) and re-flushes the rewrite table once whenever slugs or the plugin version changed
//        edge: slug collisions are rejected earlier by nsh_plat_save(); flush is a soft flush (no .htaccess rewrite)
function nsh_plat_register_routes() {
    $o = nsh_plat_get();
    add_rewrite_rule( '^' . $o['login_slug'] . '/?$', 'index.php?nsh_route=login', 'top' );
    foreach ( array( 'admin' => $o['admin_slug'], 'staff' => $o['staff_slug'], 'client' => $o['client_slug'] ) as $g => $slug ) {
        add_rewrite_rule( '^' . $slug . '/request/([0-9]+)/?$', 'index.php?nsh_route=' . $g . '&nsh_rid=$matches[1]', 'top' );
        if ( $g !== 'client' ) {
            add_rewrite_rule( '^' . $slug . '/' . $o['blog_slug'] . '(/.*)?$', 'index.php?nsh_route=' . $g . '&nsh_sub=blog&nsh_blog_path=$matches[1]', 'top' );
        }
        add_rewrite_rule( '^' . $slug . '/?$', 'index.php?nsh_route=' . $g, 'top' );
    }
    do_action( 'nsh_plat_register_routes', $o );
    $sig = md5( wp_json_encode( array( $o['login_slug'], $o['admin_slug'], $o['staff_slug'], $o['client_slug'], $o['blog_slug'], NSH_VER, apply_filters( 'nsh_plat_route_signature', '' ) ) ) );
    if ( get_option( 'nsh_routes_sig' ) !== $sig || get_option( 'nsh_flush_needed' ) ) {
        flush_rewrite_rules( false );
        update_option( 'nsh_routes_sig', $sig, true );
        delete_option( 'nsh_flush_needed' );
    }
}

// TRACE: dashboard links → group, sub path ("request/12/" or "blog/") → absolute URL; plain-permalink sites get the ?nsh_route= form
function nsh_plat_dash_url( $group, $sub = '' ) {
    $slug = nsh_plat_slug_for( $group );
    if ( $slug === '' ) { return home_url( '/' ); }
    $sub = trim( (string) $sub, '/' );
    if ( get_option( 'permalink_structure' ) ) {
        $u = home_url( '/' . $slug . '/' );
        return $sub !== '' ? $u . $sub . '/' : $u;
    }
    $args = array( 'nsh_route' => $group );
    if ( preg_match( '#^request/(\d+)$#', $sub, $m ) ) { $args['nsh_rid'] = (int) $m[1]; }
    elseif ( $sub !== '' ) { $parts = explode( '/', $sub, 2 ); $args['nsh_sub'] = $parts[0]; if ( isset( $parts[1] ) ) { $args['nsh_blog_path'] = '/' . $parts[1]; } }
    return add_query_arg( $args, home_url( '/' ) );
}

// TRACE: shell + AJAX localisation → none → site-relative base paths of the dashboards (what nsh-app.js appends "/request/ID" to) → array
function nsh_plat_js_paths() {
    $rel = function ( $g ) { return rtrim( (string) wp_parse_url( nsh_plat_dash_url( $g ), PHP_URL_PATH ), '/' ); };
    $home = rtrim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
    $strip = function ( $p ) use ( $home ) { return $home !== '' && strpos( $p, $home ) === 0 ? substr( $p, strlen( $home ) ) : $p; };
    return array(
        'dash_base'   => $strip( $rel( nsh_plat_group() === 'staff' ? 'staff' : 'admin' ) ),
        'client_base' => $strip( $rel( 'client' ) ),
    );
}

// TRACE: a protected response → none → tells browsers, CDNs and page-cache plugins never to store it → void
function nsh_plat_nocache() {
    foreach ( array( 'DONOTCACHEPAGE', 'DONOTCACHEOBJECT', 'DONOTCACHEDB', 'DONOTMINIFY', 'DONOTCDN' ) as $c ) { if ( ! defined( $c ) ) { define( $c, true ); } }
    nocache_headers();
    if ( ! headers_sent() ) {
        header( 'Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0' );
        header( 'Vary: Cookie', false );
        header( 'X-Robots-Tag: noindex, nofollow' );
    }
}

add_action( 'template_redirect', 'nsh_plat_dispatch', 0 );
// TRACE: template_redirect@0 → request → (a) legacy /nsh-* URL → 301 to the new route; (b) one of our routes → run it and exit; (c) anything else → untouched
//        pre: WP query parsed → post: our routes never reach theme templates → edge: signed-out → sign-in with redirect_to; wrong group → 403 card with a link to the account's own dashboard
function nsh_plat_dispatch() {
    $route = get_query_var( 'nsh_route' );
    if ( ! $route && isset( $_GET['nsh_route'] ) ) { $route = sanitize_key( wp_unslash( (string) $_GET['nsh_route'] ) ); }
    if ( ! $route ) { nsh_plat_legacy_redirect(); return; }
    if ( $route === 'blog' && class_exists( '\NSH\Blog\Front' ) ) { \NSH\Blog\Front::dispatch(); return; }
    if ( ! in_array( $route, array( 'login', 'admin', 'staff', 'client' ), true ) ) { return; }
    global $wp_query;
    if ( $wp_query ) { $wp_query->is_404 = false; $wp_query->is_home = false; }
    status_header( 200 );
    nsh_plat_nocache();
    if ( $route === 'login' ) { nsh_plat_route_login(); }
    nsh_plat_route_dashboard( $route );
}

// TRACE: /login/ → query → logout (nonce-checked) | magic token | open_request gateway | already signed in → forward | sign-in card → never returns
function nsh_plat_route_login() {
    if ( isset( $_GET['nsh_logout'] ) ) {
        $n = isset( $_GET['_wpnonce'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['_wpnonce'] ) ) : '';
        if ( is_user_logged_in() && wp_verify_nonce( $n, 'nsh_logout' ) ) {
            wp_logout();
            wp_safe_redirect( add_query_arg( 'msg', 'out', nsh_plat_login_url() ), 303 );
            exit;
        }
        wp_safe_redirect( is_user_logged_in() ? nsh_plat_home_url() : nsh_plat_login_url(), 303 );
        exit;
    }
    if ( ! empty( $_GET['token'] ) && function_exists( 'nsh_handle_magic_link' ) ) { nsh_handle_magic_link(); }
    $open = isset( $_GET['open_request'] ) ? absint( $_GET['open_request'] ) : 0;
    if ( is_user_logged_in() && nsh_plat_group() !== '' && ! isset( $_GET['msg'] ) ) {
        $g = nsh_plat_group();
        wp_safe_redirect( $open ? nsh_plat_dash_url( $g, 'request/' . $open . '/' ) : nsh_plat_home_url(), 303 );
        exit;
    }
    $_GET['redirect_to'] = $open ? nsh_request_url( $open ) : ( isset( $_GET['redirect_to'] ) ? $_GET['redirect_to'] : '' );
    nsh_plat_render_shell( 'Sign in', 'login', nsh_sc_login_form( array() ) );
}

// TRACE: a dashboard URL → route group → gate (signed in, correct group) → renders the matching application inside the shell → never returns
function nsh_plat_route_dashboard( $route ) {
    if ( ! is_user_logged_in() ) {
        $here = ( is_ssl() ? 'https://' : 'http://' ) . ( isset( $_SERVER['HTTP_HOST'] ) ? wp_unslash( $_SERVER['HTTP_HOST'] ) : '' ) . ( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/' );
        wp_safe_redirect( add_query_arg( array( 'msg' => 'denied', 'redirect_to' => rawurlencode( $here ) ), nsh_plat_login_url() ), 303 );
        exit;
    }
    $g = nsh_plat_group();
    if ( $g !== $route ) {
        status_header( 403 );
        $own = $g !== '' ? '<a class="nsh-btn nsh-btn-primary" href="' . esc_url( nsh_plat_home_url() ) . '">Go to my dashboard</a> ' : '';
        $body = '<div class="nsh-login-wrap"><div class="nsh-login-card nsh-text-center"><h2>Access denied</h2><p>This area is for ' . esc_html( $route ) . ' accounts. Your account does not have access to it.</p>' . $own . '<a class="nsh-btn nsh-btn-ghost" href="' . esc_url( nsh_logout_url() ) . '">Sign out</a></div></div>';
        nsh_plat_render_shell( 'Access denied', 'denied', $body );
    }
    $rid = absint( get_query_var( 'nsh_rid' ) ? get_query_var( 'nsh_rid' ) : ( isset( $_GET['nsh_rid'] ) ? $_GET['nsh_rid'] : 0 ) );
    $sub = get_query_var( 'nsh_sub' ) ? get_query_var( 'nsh_sub' ) : ( isset( $_GET['nsh_sub'] ) ? sanitize_key( wp_unslash( (string) $_GET['nsh_sub'] ) ) : '' );
    if ( $sub === 'blog' ) {
        if ( ! function_exists( 'nsh_blog_render_app' ) ) { wp_safe_redirect( nsh_plat_home_url(), 303 ); exit; }
        nsh_blog_render_app( $route );   // prints its own shell and exits
    }
    if ( $route === 'client' ) {
        $body = nsh_sc_client_dashboard( array( 'rid' => $rid ) );
        nsh_plat_render_shell( 'My Dashboard', 'client', $body );
    }
    $body = nsh_sc_admin_dashboard( array( 'surface' => $route, 'rid' => $rid ) );
    nsh_plat_render_shell( $route === 'staff' ? 'Staff Dashboard' : 'Admin Dashboard', $route, $body );
}

// TRACE: template_redirect → old URL (/nsh-client-dashboard, /nsh-admin-dashboard, /nsh-login, /nsh-request/ID) → 301/302 to the new route, keeping the query string; only when "legacy redirects" is on
function nsh_plat_legacy_redirect() {
    if ( ! (int) nsh_plat_get( 'legacy_redirects' ) || empty( $_SERVER['REQUEST_URI'] ) ) { return; }
    $path = (string) wp_parse_url( wp_unslash( $_SERVER['REQUEST_URI'] ), PHP_URL_PATH );
    $home = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
    $p    = trim( $path, '/' );
    if ( $home !== '' && strpos( $p, $home ) === 0 ) { $p = trim( substr( $p, strlen( $home ) ), '/' ); }
    $seg  = explode( '/', $p );
    $qs   = isset( $_SERVER['QUERY_STRING'] ) ? (string) wp_unslash( $_SERVER['QUERY_STRING'] ) : '';
    $args = array(); parse_str( $qs, $args );
    $to   = '';
    switch ( $seg[0] ) {
        case 'nsh-client-dashboard': $to = nsh_client_dashboard_url(); break;
        case 'nsh-admin-dashboard':  $to = is_user_logged_in() && nsh_plat_group() === 'staff' ? nsh_staff_dashboard_url() : nsh_admin_dashboard_url(); break;
        case 'nsh-login':            $to = nsh_plat_login_url(); break;
        case 'nsh-request':
            if ( ! empty( $seg[1] ) && ctype_digit( $seg[1] ) ) { $to = nsh_request_url( (int) $seg[1] ); }
            break;
    }
    if ( $to === '' ) { return; }
    unset( $args['nsh_request_id'], $args['page_id'], $args['pagename'] );
    wp_safe_redirect( $args ? add_query_arg( $args, $to ) : $to, 301 );
    exit;
}
