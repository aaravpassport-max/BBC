<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Platform settings — where the three dashboards live, who may use them, and how sign-in behaves.
 * Stored as one array in the option "nsh_platform" and edited from Admin Dashboard → Settings → Dashboards & Access.
 */

// TRACE: any reader → none → every platform option with its default → array
function nsh_plat_defaults() {
    return array(
        'login_slug'         => 'login',
        'client_slug'        => 'client-dashboard',
        'admin_slug'         => 'admin-dashboard',
        'staff_slug'         => 'staff-dashboard',
        'blog_slug'          => 'blog',
        'legacy_redirects'   => 1,
        'staff_tabs'         => array( 'requests', 'submissions', 'support' ),
        'admin_roles'        => array( 'nsh_admin' ),
        'staff_roles'        => array( 'nsh_manager' ),
        'hide_admin_bar'     => 1,
        'block_wp_admin'     => 1,
        'login_max_attempts' => 5,
        'login_lockout_min'  => 15,
        'brand_name'         => '',
    );
}

// TRACE: nsh_plat_get() → key → stored value merged over defaults (request-cached, cleared by nsh_plat_save) → mixed
function nsh_plat_get( $key = '' ) {
    static $cache = null;
    if ( $key === '__flush' ) { $cache = null; return null; }
    if ( $cache === null ) {
        $raw   = get_option( 'nsh_platform', array() );
        $cache = array_merge( nsh_plat_defaults(), is_array( $raw ) ? $raw : array() );
    }
    return $key === '' ? $cache : ( isset( $cache[ $key ] ) ? $cache[ $key ] : null );
}

// TRACE: tab list for the admin/staff dashboards → none → every dashboard tab key => label → array
function nsh_plat_all_tabs() {
    return array( 'requests' => 'Requests', 'submissions' => 'Form Submissions', 'support' => 'Support Tickets', 'fields' => 'Form Fields', 'dropdowns' => 'Dropdown Data', 'bulk' => 'Bulk Import', 'types' => 'Request Types', 'settings' => 'Settings' );
}

// TRACE: slug validation → slug string → true when the slug may not be used because WordPress or the plugin already owns it → bool
function nsh_plat_slug_reserved( $slug ) {
    $reserved = array( 'wp-admin', 'wp-content', 'wp-includes', 'wp-json', 'wp-login', 'wp-login.php', 'feed', 'page', 'embed', 'trackback', 'comments', 'search', 'category', 'tag', 'author', 'attachment', 'admin', 'login-php', 'xmlrpc', 'sitemap', 'robots', 'nsh-request' );
    return in_array( $slug, $reserved, true );
}

// TRACE: settings form / REST of the Settings tab → untrusted array → whitelists, clamps and de-duplicates every key, writes the option, schedules a rewrite flush when a slug changed
//        → returns array( 'ok' => bool, 'errors' => string[], 'saved' => array )
//        edge: duplicate or reserved slugs reject the whole slug group (nothing half-saved); unknown roles dropped; administrator never listed as staff
function nsh_plat_save( $in ) {
    $cur    = nsh_plat_get();
    $out    = $cur;
    $errors = array();
    $slugs  = array();
    foreach ( array( 'login_slug' => 'Sign-in', 'client_slug' => 'Client dashboard', 'admin_slug' => 'Admin dashboard', 'staff_slug' => 'Staff dashboard' ) as $k => $label ) {
        $v = isset( $in[ $k ] ) ? sanitize_title( wp_unslash( (string) $in[ $k ] ) ) : $cur[ $k ];
        if ( $v === '' ) { $errors[] = $label . ' URL cannot be empty.'; continue; }
        if ( nsh_plat_slug_reserved( $v ) ) { $errors[] = $label . ' URL "' . $v . '" is reserved by WordPress.'; continue; }
        if ( in_array( $v, $slugs, true ) ) { $errors[] = $label . ' URL "' . $v . '" is already used by another dashboard.'; continue; }
        $slugs[ $k ] = $v;
        $page = get_page_by_path( $v );
        if ( $page && $page->post_status === 'publish' && $v !== $cur[ $k ] ) {
            $errors[] = $label . ' URL "' . $v . '" is already a WordPress page (' . $page->post_title . '). Rename or unpublish that page first.';
            unset( $slugs[ $k ] );
        }
    }
    if ( count( $slugs ) === 4 && ! $errors ) { foreach ( $slugs as $k => $v ) { $out[ $k ] = $v; } }
    $b = isset( $in['blog_slug'] ) ? sanitize_title( wp_unslash( (string) $in['blog_slug'] ) ) : $cur['blog_slug'];
    $out['blog_slug'] = $b !== '' ? $b : 'blog';
    foreach ( array( 'legacy_redirects', 'hide_admin_bar', 'block_wp_admin' ) as $k ) {
        if ( array_key_exists( $k, $in ) ) { $out[ $k ] = filter_var( $in[ $k ], FILTER_VALIDATE_BOOLEAN ) ? 1 : 0; }
    }
    $out['login_max_attempts'] = min( 50, max( 3, (int) ( isset( $in['login_max_attempts'] ) ? $in['login_max_attempts'] : $cur['login_max_attempts'] ) ) );
    $out['login_lockout_min']  = min( 1440, max( 1, (int) ( isset( $in['login_lockout_min'] ) ? $in['login_lockout_min'] : $cur['login_lockout_min'] ) ) );
    if ( isset( $in['brand_name'] ) ) { $out['brand_name'] = sanitize_text_field( wp_unslash( (string) $in['brand_name'] ) ); }
    if ( isset( $in['staff_tabs'] ) ) {
        $t = array_values( array_intersect( array_map( 'sanitize_key', (array) $in['staff_tabs'] ), array_keys( nsh_plat_all_tabs() ) ) );
        $out['staff_tabs'] = $t ? $t : array( 'requests' );
    }
    $roles = array_keys( wp_roles()->roles );
    foreach ( array( 'admin_roles', 'staff_roles' ) as $k ) {
        if ( isset( $in[ $k ] ) ) {
            $v = array_values( array_intersect( array_map( 'sanitize_key', (array) $in[ $k ] ), $roles ) );
            $out[ $k ] = array_values( array_diff( $v, array( 'administrator', 'nsh_client' ) ) );
        }
    }
    $out['staff_roles'] = array_values( array_diff( $out['staff_roles'], $out['admin_roles'] ) );
    $changed = false;
    foreach ( array( 'login_slug', 'client_slug', 'admin_slug', 'staff_slug', 'blog_slug' ) as $k ) { if ( $out[ $k ] !== $cur[ $k ] ) { $changed = true; } }
    update_option( 'nsh_platform', $out, true );
    nsh_plat_get( '__flush' );
    if ( $changed ) { update_option( 'nsh_flush_needed', 1 ); }
    return array( 'ok' => ! $errors, 'errors' => $errors, 'saved' => $out );
}
