<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Standalone document shell — prints a complete HTML page with ONLY this plugin's assets.
 * No theme header/footer, no page builder, no theme stylesheet: the active theme cannot restyle or break a dashboard.
 */

// TRACE: shell + AJAX localisation → none → true when a handle belongs to this plugin or is a dependency it needs → bool
function nsh_plat_asset_allowed( $handle ) {
    if ( preg_match( '/^(nsh|sbm|jquery|sortable|wp-polyfill|wp-hooks|wp-i18n|wp-dom-ready|underscore|wp-util)/', (string) $handle ) ) { return true; }
    return (bool) apply_filters( 'nsh_plat_allow_asset', false, $handle );
}

// TRACE: any route → page title, kind (login|admin|staff|client|denied|blog…), body HTML → echoes a full document and exits
//        pre: $body already built (so every enqueue/inline script it triggered is queued) → post: head prints only allowed styles/scripts; footer scripts print last → edge: assets from the theme or other plugins are removed from the queues
function nsh_plat_render_shell( $title, $kind, $body, $opts = array() ) {
    if ( function_exists( 'nsh_enqueue' ) ) { nsh_enqueue(); }
    $ver = file_exists( NSH_DIR . 'platform/assets/shell.css' ) ? filemtime( NSH_DIR . 'platform/assets/shell.css' ) : NSH_VER;
    wp_enqueue_style( 'nsh-platform', NSH_URL . 'platform/assets/shell.css', array( 'nsh-style' ), $ver );
    remove_action( 'wp_print_styles', 'print_emoji_styles' );
    do_action( 'nsh_plat_shell_assets', $kind, $opts );
    foreach ( array( wp_styles(), wp_scripts() ) as $q ) {
        $q->queue = array_values( array_filter( $q->queue, 'nsh_plat_asset_allowed' ) );
    }
    $brand = (string) nsh_plat_get( 'brand_name' );
    $site  = $brand !== '' ? $brand : get_bloginfo( 'name' );
    ob_start();
    wp_print_styles();
    wp_print_head_scripts();
    $assets = ob_get_clean();
    ob_start();
    wp_print_footer_scripts();
    $foot = ob_get_clean();
    $public = ! empty( $opts['public'] );
    if ( ! $public ) { nocache_headers(); }
    header( 'Content-Type: text/html; charset=' . get_option( 'blog_charset' ) );
    echo '<!doctype html><html ' . get_language_attributes() . ' class="nsh-shell-html">';
    echo '<head><meta charset="' . esc_attr( get_option( 'blog_charset' ) ) . '"><meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">';
    if ( ! $public ) { echo '<meta name="robots" content="noindex, nofollow">'; }
    echo '<meta name="theme-color" content="' . esc_attr( isset( $opts['theme_color'] ) ? $opts['theme_color'] : '#0f172a' ) . '">';
    echo '<title>' . esc_html( $public ? $title : $title . ' — ' . $site ) . '</title>';
    if ( ! empty( $opts['head'] ) ) { echo $opts['head']; } // phpcs:ignore -- built by the caller from escaped parts
    if ( function_exists( 'has_site_icon' ) && has_site_icon() ) { wp_site_icon(); } else { echo '<link rel="icon" href="data:,">'; }
    echo $assets . '</head>';
    echo '<body class="nsh-shell nsh-shell--' . esc_attr( $kind ) . '"><a class="nsh-skip" href="#nsh-main">Skip to content</a>';
    echo $public ? $body : '<main id="nsh-main">' . $body . '</main>';
    echo $foot . '</body></html>';
    exit;
}
