<?php
/**
 * GoodService — Global helper functions.
 * NO namespace. Loaded before autoloader so available everywhere.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! function_exists( 'gs_setting' ) ) {
    function gs_setting( string $key, mixed $default = null ): mixed {
        return \GoodService\Core\Config::get( $key, $default );
    }
}

if ( ! function_exists( 'gs_parse_feature_list' ) ) {
    /**
     * Real fix — features_list's canonical, intended storage format is
     * plain, newline-separated text: that's what the admin's own
     * textarea and its placeholder ("Unlimited listings\nPriority
     * support\n...") are built for, and what a plan created directly
     * through that form actually produces. The original seed data used
     * wp_json_encode() instead, a genuine format mismatch — opening one
     * of those seeded plans in the admin form displayed raw JSON text
     * in the box, and saving it back re-stored that JSON text as a
     * plain string; repeating that cycle is how a value can end up
     * multiply re-encoded, each pass adding another layer of escaping.
     * This function is defensive about however many layers already
     * exist in stored data — it un-wraps JSON encoding for as long as
     * the result keeps looking like an encoded array (capped so a
     * pathological value can't loop forever), then always returns a
     * clean list of plain strings.
     */
    function gs_parse_feature_list( ?string $raw ): array {
        if ( $raw === null || trim( $raw ) === '' ) { return []; }

        // Real fix — the actual corruption pattern found on a real,
        // live site: WordPress's own automatic backslash-escaping of
        // submitted form data (a compatibility behavior every plugin
        // is expected to strip with wp_unslash() before saving)
        // accumulating unchecked across repeated saves, since the save
        // handler never did that. Confirmed directly against the real
        // stored value: repeated stripslashes() resolves it to valid
        // JSON after a small, specific number of rounds — a different
        // corruption shape than "outer JSON re-encoded," which is why
        // the first version of this fix worked for one corrupted
        // plan's data shape but not another's. The decode-chain runs
        // first since it never destroys correctly-nested JSON structure;
        // stripslashes() only ever runs as a fallback, and only when the
        // very first decode attempt fails outright — which is exactly
        // what the real magic-quotes corruption looks like, since its
        // outermost layer was never valid JSON to begin with.
        $value = $raw;
        for ( $i = 0; $i < 5; $i++ ) {
            if ( ! is_string( $value ) ) { break; }
            $decoded = json_decode( $value, true );
            if ( json_last_error() !== JSON_ERROR_NONE ) { break; }
            if ( $decoded === $value ) { break; } // stopped changing — no more layers to unwrap
            $value = $decoded;
            if ( is_array( $value ) ) { break; } // reached the real array — done
        }

        if ( ! is_array( $value ) && is_string( $value ) && json_decode( $value, true ) === null ) {
            // The decode chain above made no real progress (still a
            // string, and not even valid JSON) — likely the magic-
            // quotes pattern. Fall back to repeated stripslashes(),
            // re-attempting a full JSON decode after each round.
            for ( $i = 0; $i < 10; $i++ ) {
                $decoded = json_decode( $value, true );
                if ( json_last_error() === JSON_ERROR_NONE && is_array( $decoded ) ) {
                    $value = $decoded;
                    break;
                }
                $stripped = stripslashes( $value );
                if ( $stripped === $value ) { break; } // no more backslashes left to strip
                $value = $stripped;
            }
        }
        if ( is_array( $value ) ) {
            $out = [];
            foreach ( $value as $item ) {
                $text = is_array( $item ) ? ( $item['text'] ?? '' ) : (string) $item;
                $text = trim( $text );
                if ( $text !== '' ) { $out[] = $text; }
            }
            return $out;
        }
        // Never resolved to an array — treat as the plain,
        // newline-separated text it was always meant to be.
        return array_values( array_filter( array_map( 'trim', explode( "\n", (string) $raw ) ) ) );
    }
}

if ( ! function_exists( 'gs_is_vendor' ) ) {
    function gs_is_vendor( int $uid = 0 ): bool {
        return \GoodService\Core\Roles::is_vendor( $uid );
    }
}

if ( ! function_exists( 'gs_is_admin_level' ) ) {
    function gs_is_admin_level( int $uid = 0 ): bool {
        return \GoodService\Core\Roles::is_admin_level( $uid );
    }
}

if ( ! function_exists( 'gs_get_impersonation_state' ) ) {
    /**
     * Single source of truth for "is the current session an admin viewing
     * as another user right now." Reads the same secure opaque token cookie
     * and transient already used by impersonateVendor()/adminReturnFromImpersonation()
     * in AjaxController.php — no new cookie, no new storage mechanism, just a
     * shared reader so every dashboard template (vendor, customer, staff, ...)
     * can detect this the same way instead of each re-implementing the same
     * cookie + transient lookup inline.
     */
    function gs_get_impersonation_state(): array {
        $state = [ 'active' => false, 'admin_id' => 0 ];
        if ( ! isset( $_COOKIE['gs_admin_switch'] ) ) { return $state; }
        $token  = sanitize_text_field( $_COOKIE['gs_admin_switch'] );
        $stored = $token ? get_transient( 'gs_impersonate_' . $token ) : false;
        if ( $stored && (int) $stored > 0 ) {
            $state['active']   = true;
            $state['admin_id'] = (int) $stored;
        }
        return $state;
    }
}

if ( ! function_exists( 'gs_get_vendor_profile' ) ) {
    function gs_get_vendor_profile( int $user_id = 0 ): ?\stdClass {
        try {
            return \GoodService\Repository\VendorRepository::get_by_user( $user_id ?: get_current_user_id() );
        } catch ( \Throwable $e ) {
            if ( function_exists( 'gs_write_log' ) ) {
                gs_write_log( 'gs_get_vendor_profile error: ' . $e->getMessage() );
            }
            return null;
        }
    }
}

if ( ! function_exists( 'gs_current_vendor_id' ) ) {
    function gs_current_vendor_id(): int {
        $vp = gs_get_vendor_profile();
        return $vp ? (int) $vp->id : 0;
    }
}

if ( ! function_exists( 'gs_vendor_site_email' ) ) {
    /**
     * Resolves the email address to actually notify a vendor at — their
     * listing's own email (the "vendor site" address, shown publicly on
     * their business page), not vendor_profiles.email (their account/
     * login email), which can genuinely be a different address a vendor
     * never checks day to day. Uses the exact same primary-listing
     * resolution already established elsewhere in this codebase
     * (vendor-dashboard.php's own primary-listing-URL logic) — the
     * vendor's oldest active/pending listing, featured ones preferred —
     * rather than inventing a new convention for picking "the" listing
     * among several. Falls back to vendor_profiles.email only if no
     * listing has an email set at all, so a notification never silently
     * goes nowhere just because a listing's contact field was left blank.
     */
    function gs_vendor_site_email( int $vendor_id ): string {
        if ( ! $vendor_id ) { return ''; }
        global $wpdb;
        $listing_email = $wpdb->get_var( $wpdb->prepare(
            "SELECT email FROM {$wpdb->prefix}gs_listings
             WHERE vendor_id = %d AND status IN('active','pending') AND email != ''
             ORDER BY is_featured DESC, created_at ASC LIMIT 1",
            $vendor_id
        ) );
        if ( $listing_email ) { return $listing_email; }
        return (string) ( $wpdb->get_var( $wpdb->prepare(
            "SELECT email FROM {$wpdb->prefix}gs_vendor_profiles WHERE id = %d", $vendor_id
        ) ) ?: '' );
    }
}

if ( ! function_exists( 'gs_get_active_subscription' ) ) {
    function gs_get_active_subscription( int $user_id = 0 ): ?\stdClass {
        return \GoodService\Service\SubscriptionService::get_active( $user_id ?: get_current_user_id() );
    }
}

if ( ! function_exists( 'gs_vendor_can' ) ) {
    /**
     * Check if vendor's active subscription allows a feature.
     * Feature keys map directly to gs_subscription_plans columns.
     */
    function gs_vendor_can( string $feature, int $vendor_user_id = 0 ): bool {
        $uid = $vendor_user_id ?: get_current_user_id();
        $sub = \GoodService\Service\SubscriptionService::get_active( $uid );
        if ( ! $sub ) { return false; }
        $map = [
            'analytics'        => (bool) ( $sub->show_analytics   ?? 0 ),
            'show_analytics'   => (bool) ( $sub->show_analytics   ?? 0 ),
            'seo_tools'        => (bool) ( $sub->show_seo_tools   ?? 0 ),
            'email'            => (bool) ( $sub->show_email       ?? 0 ),
            'phone'            => (bool) ( $sub->show_phone       ?? 1 ),
            'whatsapp'         => true,
            'products'         => true,  // Products enabled for all vendors by default
            'can_products'     => true,  // Products enabled for all vendors by default
            'featured'         => (bool) ( $sub->featured_badge   ?? 0 ),
            'featured_badge'   => (bool) ( $sub->featured_badge   ?? 0 ),
            'priority_listing' => (bool) ( $sub->priority_listing ?? 0 ),
            'api_access'       => (bool) ( $sub->api_access       ?? 0 ),
        ];
        return $map[ $feature ] ?? false;
    }
}

if ( ! function_exists( 'gs_module_enabled' ) ) {
    function gs_module_enabled( string $module ): bool {
        return \GoodService\Module\ModuleManager::is_enabled( $module );
    }
}

if ( ! function_exists( 'gs_get_ip' ) ) {
    /**
     * Get the real client IP address.
     *
     * H9 FIX (applied here too): HTTP_X_FORWARDED_FOR is only trusted when
     * REMOTE_ADDR is a private/loopback address — meaning the connection comes
     * from a real internal reverse proxy (Cloudflare, nginx, load balancer).
     * When REMOTE_ADDR is a public IP it IS the client — XFF cannot be trusted
     * and must be ignored to prevent rate-limit bypass via header spoofing.
     *
     * Cloudflare's CF-Connecting-IP is only used when the TCP connection comes
     * from Cloudflare's IP ranges (private proxy scenario). Direct connections
     * always use REMOTE_ADDR.
     */
    function gs_get_ip(): string {
        $remote_addr = $_SERVER['REMOTE_ADDR'] ?? '';
        $is_private  = gs_ip_is_private( $remote_addr );

        if ( $is_private ) {
            // Trust proxy headers only when behind a real internal proxy
            $proxy_headers = [
                'HTTP_CF_CONNECTING_IP',   // Cloudflare real client IP
                'HTTP_CLIENT_IP',
                'HTTP_X_FORWARDED_FOR',    // May contain a comma-separated list
            ];
            foreach ( $proxy_headers as $key ) {
                if ( ! empty( $_SERVER[ $key ] ) ) {
                    $ip = trim( explode( ',', $_SERVER[ $key ] )[0] );
                    if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
                        return sanitize_text_field( $ip );
                    }
                }
            }
        }

        // For public REMOTE_ADDR (direct connection) — always use REMOTE_ADDR
        return sanitize_text_field( $remote_addr ?: 'unknown' );
    }
}

if ( ! function_exists( 'gs_ip_is_private' ) ) {
    /** Returns true if the IP is a loopback or RFC-1918 private address. */
    function gs_ip_is_private( string $ip ): bool {
        if ( ! filter_var( $ip, FILTER_VALIDATE_IP ) ) { return false; }
        return filter_var( $ip, FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE ) === false;
    }
}

if ( ! function_exists( 'gs_format_price' ) ) {
    function gs_format_price( float $amount, bool $sym = true ): string {
        return \GoodService\Core\Helpers::format_price( $amount, $sym );
    }
}

if ( ! function_exists( 'gs_stars' ) ) {
    function gs_stars( float $rating, int $max = 5 ): string {
        return \GoodService\Core\Helpers::stars( $rating, $max );
    }
}

if ( ! function_exists( 'gs_time_ago' ) ) {
    function gs_time_ago( ?string $datetime ): string {
        return \GoodService\Core\Helpers::time_ago( $datetime );
    }
}

if ( ! function_exists( 'gs_indexnow_ping' ) ) {
    /**
     * Real feature, priority 4 (IndexNow): pings Bing/Yandex the instant a
     * URL is created, updated, or removed — rather than waiting for their
     * own crawl schedule to notice a sitemap change. Genuinely safe to
     * call from any save/delete flow: non-blocking, very short timeout,
     * and a network failure or IndexNow being down can never break the
     * operation that called it.
     */
    function gs_indexnow_ping( string $url ): void {
        try {
            $key = \GoodService\Core\Config::get( 'indexnow_key', '' );
            if ( ! $key ) {
                // Real key must be lowercase hex-safe for the rewrite rule
                // regex ([a-f0-9]{32}) to ever match it when serving the file.
                $key = substr( md5( wp_generate_password( 32, false, false ) . time() ), 0, 32 );
                \GoodService\Core\Config::set( 'indexnow_key', $key );
            }
            wp_remote_post( 'https://api.indexnow.org/indexnow', [
                'timeout'  => 3,
                'blocking' => false,
                'headers'  => [ 'Content-Type' => 'application/json; charset=utf-8' ],
                'body'     => wp_json_encode( [
                    'host'        => wp_parse_url( home_url(), PHP_URL_HOST ),
                    'key'         => $key,
                    'keyLocation' => home_url( '/' . $key . '.txt' ),
                    'urlList'     => [ $url ],
                ] ),
            ] );
        } catch ( \Throwable $e ) {
            // Never let an IndexNow failure affect the save/delete
            // operation that triggered it — this is a nice-to-have
            // signal to search engines, not a critical path.
        }
    }
}

if ( ! function_exists( 'gs_asset_url' ) ) {
    /**
     * Real feature: resolves whether to serve the minified or source
     * version of an asset based on actual file modification time — never
     * a hardcoded assumption. Directly addresses the exact risk an
     * existing code comment already warns about elsewhere in this
     * codebase: a stale .min file silently shadowing real fixes made to
     * the source. Falls back to source automatically whenever the
     * minified file is missing or older than the source, so a minified
     * file can only ever be served when it's genuinely, verifiably current.
     */
    function gs_asset_url( string $relative_path ): string {
        $source_path = GS_DIR . $relative_path;
        $ext = pathinfo( $relative_path, PATHINFO_EXTENSION );
        $min_relative = preg_replace( '/\.' . preg_quote( $ext, '/' ) . '$/', '.min.' . $ext, $relative_path );
        $min_path = GS_DIR . $min_relative;
        $use_min = file_exists( $min_path )
            && file_exists( $source_path )
            && filemtime( $min_path ) >= filemtime( $source_path );
        $final_relative = $use_min ? $min_relative : $relative_path;
        return GS_URL . $final_relative . '?v=' . GS_VERSION . '&b=731';
    }
}

if ( ! function_exists( 'gs_asset_url' ) ) {
    /**
     * Real fix, PageSpeed audit items 2.2/2.3: a genuinely safe way to use
     * the minified assets — checks the minified file is actually NEWER
     * than its real source (not just "does it exist") before using it,
     * falling back to the real, current file otherwise. Directly respects
     * the documented warning already in this codebase about a stale min
     * file silently shadowing real fixes: the min file is only ever used
     * when verifiably fresh, never blindly trusted just because it exists.
     */
    function gs_asset_url( string $real_relative_path ): string {
        $real_path = GS_DIR . $real_relative_path;
        $min_relative_path = preg_replace( '/\.(js|css)$/', '.min.$1', $real_relative_path );
        $min_path = GS_DIR . $min_relative_path;
        if (
            file_exists( $min_path ) &&
            file_exists( $real_path ) &&
            filemtime( $min_path ) >= filemtime( $real_path )
        ) {
            return GS_URL . $min_relative_path . '?v=' . GS_VERSION . '&b=731';
        }
        // Real file is newer (or min file missing) — always safe, never stale.
        return GS_URL . $real_relative_path . '?v=' . GS_VERSION . '&b=731';
    }
}

if ( ! function_exists( 'gs_pwa_manifest_url' ) ) {
    /** PHP-served platform manifest — correct application/manifest+json MIME type. */
    function gs_pwa_manifest_url( string $type = 'client' ): string {
        return add_query_arg(
            [ 'action' => 'gs_serve_manifest', 'type' => $type, 'v' => GS_VERSION ],
            admin_url( 'admin-ajax.php' )
        );
    }
}

if ( ! function_exists( 'gs_pwa_icon_url' ) ) {
    /** PHP-served PWA icon — correct image/png MIME type (REST /icon returns octet-stream on Nestify). */
    function gs_pwa_icon_url( string $slug ): string {
        return add_query_arg(
            [ 'action' => 'gs_serve_icon', 'name' => $slug, 'v' => GS_VERSION ],
            admin_url( 'admin-ajax.php' )
        );
    }
}

if ( ! function_exists( 'gs_pwa_manifest_payload' ) ) {
    /** Load platform/vendor manifest JSON with icon URLs rewritten to the REST icon route. */
    function gs_pwa_manifest_payload( string $type = 'client' ): ?array {
        $file = $type === 'vendor' ? 'goodservice-vendor.webmanifest' : 'goodservice-client.webmanifest';
        $path = GS_DIR . $file;
        if ( ! file_exists( $path ) ) {
            return null;
        }
        $manifest = json_decode( (string) file_get_contents( $path ), true );
        if ( ! is_array( $manifest ) ) {
            return null;
        }
        $filename_to_slug = [
            'client-icon-192.png' => 'client-192',
            'client-icon-512.png' => 'client-512',
            'vendor-icon-192.png' => 'vendor-192',
            'vendor-icon-512.png' => 'vendor-512',
        ];
        if ( empty( $manifest['id'] ) ) {
            $manifest['id'] = '/';
        }
        $manifest['prefer_related_applications'] = false;
        $manifest['lang']                        = 'en';
        $manifest['dir']                         = 'ltr';
        $manifest['orientation']                 = 'portrait-primary';
        $manifest['categories']                  = [ 'business', 'lifestyle' ];
        $manifest['display_override']            = [ 'standalone', 'minimal-ui', 'browser' ];
        if ( is_array( $manifest['icons'] ?? null ) ) {
            $expanded = [];
            foreach ( $manifest['icons'] as $icon ) {
                if ( str_contains( (string) ( $icon['src'] ?? '' ), 'gs_serve_icon' ) ) {
                    $icon['type'] = 'image/png';
                } else {
                    $filename = basename( parse_url( (string) ( $icon['src'] ?? '' ), PHP_URL_PATH ) ?: '' );
                    $slug     = $filename_to_slug[ $filename ] ?? ( $type === 'vendor' ? 'vendor-192' : 'client-192' );
                    if ( preg_match( '/(?:name=)(client|vendor)-(192|512)/', (string) ( $icon['src'] ?? '' ), $m ) ) {
                        $slug = $m[1] . '-' . $m[2];
                    }
                    $icon['src']  = gs_pwa_icon_url( $slug );
                    $icon['type'] = 'image/png';
                }
                // Chrome installability prefers separate any vs maskable icon entries.
                $purpose = (string) ( $icon['purpose'] ?? 'any' );
                if ( str_contains( $purpose, 'any' ) && str_contains( $purpose, 'maskable' ) ) {
                    $any_icon              = $icon;
                    $any_icon['purpose']   = 'any';
                    $mask_icon             = $icon;
                    $mask_icon['purpose']  = 'maskable';
                    $expanded[]            = $any_icon;
                    $expanded[]            = $mask_icon;
                } else {
                    $expanded[] = $icon;
                }
            }
            $manifest['icons'] = $expanded;
        }
        return $manifest;
    }
}

if ( ! function_exists( 'gs_pwa_direct_diagnostics' ) ) {
    /** Filesystem-level PWA checks — immune to Anubis/CDN blocking server HTTP probes. */
    function gs_pwa_direct_diagnostics(): array {
        $client_manifest = gs_pwa_manifest_payload( 'client' );
        $gs_js_path      = GS_DIR . 'assets/js/goodservice.js';
        $gs_js_body      = is_readable( $gs_js_path ) ? (string) file_get_contents( $gs_js_path ) : '';
        $sw_path         = ABSPATH . 'gs-client-sw.js';
        $sw_body         = is_readable( $sw_path ) ? (string) file_get_contents( $sw_path ) : '';
        $icon_path       = GS_DIR . 'assets/pwa/client-icon-192.png';
        $icon_body       = is_readable( $icon_path ) ? (string) file_get_contents( $icon_path ) : '';

        return [
            'plugin_version'              => GS_VERSION,
            'php_manifest_valid'          => is_array( $client_manifest ) && ! empty( $client_manifest['icons'] ),
            'php_manifest_has_icons'      => is_array( $client_manifest['icons'] ?? null ) && count( $client_manifest['icons'] ) > 0,
            'root_sw_file_exists'         => is_readable( $sw_path ),
            'root_sw_has_fetch_handler'   => str_contains( $sw_body, "addEventListener('fetch'" ),
            'gs_js_file_exists'           => is_readable( $gs_js_path ),
            'gs_js_has_sw_registration'   => str_contains( $gs_js_body, 'gsGetServiceWorkerUrls' ) && str_contains( $gs_js_body, "{ scope: '/' }" ),
            'icon_file_valid_png'         => str_starts_with( $icon_body, "\x89PNG\r\n\x1a\n" ),
            'root_sw_synced'              => get_option( 'gs_root_sw_synced_version', '' ) === GS_VERSION,
            'manifest_url'                => gs_pwa_manifest_url( 'client' ),
            'sw_ajax_url'                 => admin_url( 'admin-ajax.php?action=gs_serve_sw&type=client&v=' . rawurlencode( GS_VERSION ) ),
        ];
    }
}

if ( ! function_exists( 'gs_apply_rankmath_conflict_prevention' ) ) {
    /**
     * Real fix: extracted from 3 identical, duplicated copies in
     * Router.php into one shared function — same principle already
     * established for gs_render_impersonation_banner(): a single
     * implementation every call site uses, not N copies of the same
     * logic. Wires the admin's RankMath toggle (SEO settings screen) into
     * conflict-prevention code that was already confirmed working;
     * defaults to enabled, matching the previous always-on behavior
     * exactly, so this is fully backward compatible.
     */
    function gs_apply_rankmath_conflict_prevention(): void {
        $enabled = \GoodService\Core\Config::get( 'seo_rankmath_conflict_prevention', '1' ) === '1';
        if ( ! $enabled || ! function_exists( 'rank_math' ) ) { return; }
        $rm = rank_math();
        if ( isset( $rm->head ) ) {
            remove_action( 'wp_head', [ $rm->head, 'output_head' ], 1 );
            remove_action( 'wp_head', [ $rm->head, 'output_head' ], 2 );
        }
    }
}

if ( ! function_exists( 'gs_render_impersonation_banner' ) ) {
    /**
     * Renders the "Admin Mode — viewing as X" banner, generically, for any
     * dashboard. Real gap fix: this used to be hand-written HTML inline only
     * in vendor-dashboard.php, with its own copy of the cookie-detection
     * logic. Adding this to the customer dashboard, staff dashboard, or any
     * future dashboard now means calling this one function, not duplicating
     * the detection + markup a second, third, fourth time.
     *
     * @param string $target_name    Display name of the user being viewed as.
     * @param array  $quick_actions  Optional list of ['url'=>string,'label'=>string]
     *                               context-specific action buttons (e.g. vendor
     *                               dashboard shows "Create Listing"; customer
     *                               dashboard might show nothing extra at all).
     */
    function gs_render_impersonation_banner( string $target_name, array $quick_actions = [] ): void {
        $state = gs_get_impersonation_state();
        if ( ! $state['active'] ) { return; }
        ?>
        <div id="gs-admin-impersonation-bar" style="position:fixed;bottom:0;left:0;right:0;z-index:99999;background:linear-gradient(90deg,#7C3AED,#4F46E5);color:#fff;padding:11px 24px;display:flex;align-items:center;justify-content:space-between;gap:16px;box-shadow:0 -4px 20px rgba(124,58,237,.4);font-family:-apple-system,sans-serif;font-size:.87rem;font-weight:600;flex-wrap:wrap">
          <div style="display:flex;align-items:center;gap:10px">
            <span style="font-size:1.2rem">👤</span>
            <span>Admin Mode: You are viewing <strong><?php echo esc_html( $target_name ); ?></strong>'s dashboard as Admin</span>
          </div>
          <div style="display:flex;gap:10px;flex-shrink:0;flex-wrap:wrap">
            <?php foreach ( $quick_actions as $qa ): ?>
            <a href="<?php echo esc_url( $qa['url'] ); ?>" style="background:rgba(255,255,255,.2);border:1px solid rgba(255,255,255,.35);color:#fff;border-radius:7px;padding:6px 14px;font-size:.82rem;font-weight:700;text-decoration:none"><?php echo esc_html( $qa['label'] ); ?></a>
            <?php endforeach; ?>
            <button onclick="gsReturnToAdmin()" style="background:#fff;color:#7C3AED;border:none;border-radius:7px;padding:7px 18px;font-size:.84rem;font-weight:800;cursor:pointer;font-family:inherit">← Return to Admin</button>
          </div>
        </div>
        <script>
        window.gsReturnToAdmin = function() {
          var fd = new FormData();
          fd.append('action','gs_admin_return_from_impersonation');
          fd.append('nonce','<?php echo wp_create_nonce("gs_ajax"); ?>');
          fetch('<?php echo esc_js( admin_url("admin-ajax.php") ); ?>',{method:'POST',body:fd})
            .then(function(r){ return r.json(); }).then(function(d){
              if (d.success && d.data && d.data.redirect) {
                window.location.href = d.data.redirect;
              } else {
                window.location.href = '<?php echo esc_js( home_url("/admin-panel/?section=vendors") ); ?>';
              }
            }).catch(function(){
              window.location.href = '<?php echo esc_js( home_url("/admin-panel/?section=vendors") ); ?>';
            });
        };
        </script>
        <?php
    }
}

if ( ! function_exists( 'gs_currency_sym' ) ) {
    function gs_currency_sym(): string {
        return \GoodService\Core\Config::get( 'currency_symbol', '₹' );
    }
}

if ( ! function_exists( 'gs_notify' ) ) {
    function gs_notify( int $user_id, string $type, string $title, string $message = '', string $url = '' ): void {
        \GoodService\Service\NotificationService::create( $user_id, $type, $title, $message, $url );
    }
}

if ( ! function_exists( 'gs_emit' ) ) {
    /** Fire an internal platform event. */
    function gs_emit( string $event, array $data = [] ): void {
        \GoodService\Core\EventBus::emit( $event, $data );
    }
}

if ( ! function_exists( 'gs_queue_job' ) ) {
    /** Push a background job onto the queue. */
    function gs_queue_job( string $type, array $payload = [], int $delay = 0 ): void {
        \GoodService\Core\JobQueue::push( $type, $payload, $delay );
    }
}

if ( ! function_exists( 'gs_log' ) ) {
    function gs_log( string $msg, string $level = 'debug' ): void {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            $file = ( defined( 'GS_DIR' ) ? GS_DIR : WP_CONTENT_DIR . '/' ) . 'gs-debug.log';
            file_put_contents( $file, '[' . date( 'Y-m-d H:i:s' ) . '][' . strtoupper( $level ) . '] ' . $msg . PHP_EOL, FILE_APPEND | LOCK_EX );
        }
    }
}

if ( ! function_exists( 'gs_log_activity' ) ) {
    function gs_log_activity( string $action, string $object_type = '', int $object_id = 0, string $desc = '' ): void {
        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'gs_activity_log', [
            'user_id'     => get_current_user_id(),
            'action'      => $action,
            'object_type' => $object_type,
            'object_id'   => $object_id,
            'description' => $desc,
            'ip_address'  => gs_get_ip(),
            'user_agent'  => substr( $_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500 ),
            'created_at'  => current_time( 'mysql' ),
        ] );
    }
}

if ( ! function_exists( 'gs_error' ) ) {
    function gs_error( string $message, int $code = 400 ): never {
        wp_send_json_error( [ 'message' => $message ], $code );
    }
}

if ( ! function_exists( 'gs_get_listing' ) ) {
    function gs_get_listing( int $id ): ?\stdClass {
        return ( new \GoodService\Repository\ListingRepository() )->find( $id );
    }
}

if ( ! function_exists( 'gs_calculate_trust_score' ) ) {
    function gs_calculate_trust_score( int $user_id ): int {
        return \GoodService\Repository\VendorRepository::calculate_trust_score( $user_id );
    }
}

if ( ! function_exists( 'gs_user_can' ) ) {
    function gs_user_can( string $cap, int $uid = 0 ): bool {
        $u = $uid ? get_user_by('id',$uid) : wp_get_current_user();
        return $u && $u->has_cap($cap);
    }
}

// ── The following functions were duplicate declarations in the original code.
// All duplicates (lines 190–248 in original) have been removed (MAJOR FIX #1).
// The canonical, richer-signature versions above are the only declarations now.

if ( ! function_exists( 'gs_ajax_nonce' ) ) {
    function gs_ajax_nonce(): string {
        return wp_create_nonce( 'gs_ajax' );
    }
}

if ( ! function_exists( 'gs_is_manager' ) ) {
    function gs_is_manager( int $uid = 0 ): bool {
        return \GoodService\Core\Roles::is_manager( $uid );
    }
}

if ( ! function_exists( 'gs_is_moderator' ) ) {
    function gs_is_moderator( int $uid = 0 ): bool {
        return \GoodService\Core\Roles::is_moderator( $uid );
    }
}

if ( ! function_exists( 'gs_is_staff' ) ) {
    function gs_is_staff( int $uid = 0 ): bool {
        return \GoodService\Core\Roles::is_staff( $uid );
    }
}

if ( ! function_exists( 'gs_login_redirect' ) ) {
    /**
     * Returns the correct post-login redirect URL for the current (or given) user.
     */
    function gs_login_redirect( int $uid = 0 ): string {
        $u     = $uid ? get_user_by( 'id', $uid ) : wp_get_current_user();
        $roles = (array) ( $u->roles ?? [] );
        if ( in_array( 'administrator', $roles, true ) || user_can( $u, 'manage_options' ) ) {
            return home_url( '/admin-panel/' );
        }
        if ( in_array( 'gs_manager', $roles, true ) ) {
            return home_url( '/manager-panel/' );
        }
        if ( in_array( 'gs_moderator', $roles, true ) || in_array( 'gs_staff', $roles, true ) ) {
            return home_url( '/moderation/' );
        }
        // Real bug fix: this function never checked for gs_vendor or gs_customer
        // at all — every customer who logged in fell through to the vendor
        // dashboard fallback below, which correctly rejects non-vendors and
        // sends them back to /vendor/login/, which calls this exact function
        // again and gets the same wrong destination — a genuine infinite
        // redirect loop (ERR_TOO_MANY_REDIRECTS) that locked every customer
        // out of their account entirely.
        if ( in_array( 'gs_vendor', $roles, true ) ) {
            return home_url( '/vendor/dashboard/' );
        }
        if ( in_array( 'gs_regional_manager', $roles, true ) ) {
            return home_url( '/admin-panel/?section=regional_manager' );
        }
        if ( in_array( 'gs_customer', $roles, true ) ) {
            return home_url( '/my-account/' );
        }
        return home_url( '/vendor/dashboard/' );
    }
}

if ( ! function_exists( 'gs_vendor_site_url' ) ) {
    /**
     * Returns the canonical URL for a vendor's primary listing page.
     * $slug can be either a vendor_profiles.slug OR a listings.slug.
     * Always returns the clean /{listing_slug}/ URL.
     */
    function gs_vendor_site_url( string $slug ): string {
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        // Try as vendor profile slug first
        $listing_slug = $wpdb->get_var( $wpdb->prepare(
            "SELECT l.slug FROM {$pfx}listings l
             INNER JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
             WHERE vp.slug = %s AND l.status IN('active','pending')
             ORDER BY l.is_featured DESC, l.created_at ASC LIMIT 1",
            $slug
        ) );
        // If not found as vendor slug, try directly as listing slug
        if ( ! $listing_slug ) {
            $listing_slug = $wpdb->get_var( $wpdb->prepare(
                "SELECT slug FROM {$pfx}listings WHERE slug = %s AND status IN('active','pending') LIMIT 1",
                $slug
            ) );
        }
        return $listing_slug
            ? home_url( '/' . $listing_slug . '/' )
            : home_url( '/directory/' );
    }
}
