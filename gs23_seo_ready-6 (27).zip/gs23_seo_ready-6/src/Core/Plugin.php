<?php
namespace GoodService\Core;

use GoodService\Database\Schema;
use GoodService\Database\Seeder;
use GoodService\Module\ModuleManager;
use GoodService\Router\Router;

/**
 * Plugin — Main orchestrator.
 * Boots all subsystems in the correct order.
 */
final class Plugin {

    public static function boot(): void {
        // 0. Synchronise MySQL session timezone with WordPress timezone.
        //    Prevents mismatch between PHP current_time('mysql') [WordPress local]
        //    and MySQL CURRENT_TIMESTAMP defaults [server UTC on shared hosting].
        //    Must run FIRST — before any DB queries that rely on NOW() or CURRENT_TIMESTAMP.
        global $wpdb;
        if ( $wpdb instanceof \wpdb ) {
            $offset_seconds = (int) round( (float) get_option( 'gmt_offset', 0 ) * 3600 );
            $sign    = $offset_seconds >= 0 ? '+' : '-';
            $hours   = abs( (int) ( $offset_seconds / 3600 ) );
            $minutes = abs( (int) ( ( $offset_seconds % 3600 ) / 60 ) );
            $tz_str  = sprintf( "%s%02d:%02d", $sign, $hours, $minutes );
            $wpdb->query( "SET time_zone = '{$tz_str}'" ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        }

        // 1. Core subsystems
        Roles::register();
        Config::load();
        Infrastructure::boot(); // Redis / external MySQL / Meilisearch — zero-downtime toggle layer

        // 1b. Real fix — root cause of a whole class of "I updated the
        // plugin but the site still shows the old thing" reports on this
        // install specifically: the site's host (Nestify) runs LiteSpeed,
        // whose LSCache full-page cache serves cached HTML/CSS for a page
        // that hasn't changed FROM ITS OWN point of view — it has no way
        // to know this plugin's files changed underneath it, since a
        // direct file replace (not a WP-native "Update" click) never fires
        // WordPress's own upgrader_process_complete hook, and even a real
        // WP-native update doesn't purge LSCache by default. Every prior
        // fix in this investigation kept looking correct in code and
        // still not visibly changing anything live for exactly this
        // reason. Detects a real version change (compares the last-seen
        // GS_VERSION, stored in an option, against the current one — so
        // this fires at most once per actual update, not on every page
        // load) and purges every cache layer this plugin can reach.
        self::maybe_purge_cache_on_version_change();

        // 1c. Real fix (v7.475.4) — the actual, evidence-confirmed root
        // cause of PWA installability, found via the v7.475.3 diagnostic's
        // real-browser-vs-server-side comparison and its .htaccess canary:
        // the manifest and service worker files ARE reachable with real,
        // valid content for actual visitors (confirmed: a real browser
        // fetch of goodservice-client.webmanifest returned the correct
        // 783-byte JSON body, and gs-client-sw.js returned its real,
        // correct JS body) — but the .htaccess canary header was absent
        // from every single probe, proving Nestify's hosting is not
        // applying this plugin's .htaccess files at all (AllowOverride
        // disabled at the vhost level). That means the
        // Service-Worker-Allowed: / header this plugin's assets/js/
        // .htaccess was supposed to send has never actually been sent —
        // so every navigator.serviceWorker.register(..., { scope: '/' })
        // call has been failing outright in every real visitor's browser
        // (a browser rejects a requested scope broader than the script's
        // own directory unless that header is present — this is not
        // optional, it's the one thing .htaccess was solely responsible
        // for that nothing else in this pivot could substitute).
        // Sidesteps needing that header at all, the standard fix for
        // exactly this situation: a service worker's default max scope is
        // the directory ITS OWN SCRIPT lives in, so placing a real copy
        // of the SW files at the true site root gives them a default
        // scope of '/' with no header needed. Copies the plugin's real
        // gs-client-sw.js/gs-vendor-sw.js out to ABSPATH (ie
        // ".../public_html/gs-client-sw.js") whenever this plugin's own
        // version changes, so both the file location and its content stay
        // in sync with every future update automatically.
        self::maybe_sync_root_service_workers();

        // 2. Module system (feature flags)
        ModuleManager::boot();

        // 3. Routing + shortcodes
        Router::boot();

        // 4. AJAX
        \GoodService\Controller\AjaxController::register();

        // 5. WP admin panel integration
        if ( is_admin() ) {
            \GoodService\Controller\WPAdminController::register();
        }

        // 6. REST API
        add_action( 'rest_api_init', [ \GoodService\Api\RestApiController::class, 'register_routes' ] );

        // 7. Assets (only on front-end, not admin)
        add_action( 'wp_enqueue_scripts', [ Assets::class, 'enqueue' ] );

        // 8. Background job processor
        JobQueue::register();

        // 9. Cron tasks
        Cron::register();

        // 10. Internal event hooks
        EventBus::init();

        // 11. Privacy — wire this plugin's custom gs_* tables into WordPress's
        // native Tools > Export/Erase Personal Data screens. FIXED — audit
        // gap: see PrivacyService's own docblock for the full root-cause
        // writeup; in short, without this, every gs_* table was silently
        // invisible to WP's built-in data-subject-request tooling.
        \GoodService\Service\PrivacyService::register();

        // 10b. SMTP configuration — real fix: wires the admin-configured
        // SMTP settings into wp_mail(), previously collected in Settings
        // but never actually used anywhere (root cause of OTP/transactional
        // emails silently failing to send on hosts without a working
        // default PHP mail() transport).
        \GoodService\Service\EmailService::register();

        // 11. Fluent Forms → GoodService inquiry bridge
        \GoodService\Service\FluentFormsBridge::register();

        // 12. Image optimisation — converts uploads to WebP + generates AVIF sidecar
        \GoodService\Service\ImageOptimizer::register();

        // 12. Image delivery — output buffer: <picture> AVIF/WebP tags, lazy load, LCP preload
        \GoodService\Service\ImageDelivery::register();

        // Phase 12 — Enterprise Diagnostics
        // Register PHP error handler (captures warnings/notices → gs_error_log)
        // Only enabled when WP_DEBUG is on OR gs_diag_php_errors option is set
        if ( ( defined( 'WP_DEBUG' ) && WP_DEBUG ) || get_option( 'gs_diag_php_errors', 0 ) ) {
            set_error_handler( [ self::class, 'php_error_handler' ] );
        }
        // Inject JS error capture script on all front-end pages (non-admin)
        add_action( 'wp_footer', [ self::class, 'inject_error_capture_script' ], 100 );

        // 13. DB version check on admin pages
        add_action( 'admin_notices', [ self::class, 'check_db_version' ] );
        // Real, critical root-cause fix: admin_notices ONLY fires on
        // WordPress's native /wp-admin/ dashboard — but this platform is a
        // custom-routed system where vendors, and very likely the admin
        // too, never visit /wp-admin/ at all. This meant the schema
        // migration that adds new database columns may functionally never
        // run in real-world usage. Also hooked to 'init', which fires on
        // every request including the plugin's own custom routes, so the
        // schema reliably catches up the moment any page loads. Safe:
        // check_db_version() is already idempotent (static guard +
        // version_compare), confirmed by reading its own implementation.
        add_action( 'init', [ self::class, 'check_db_version' ], 5 );

        // Real fix — confirmed dead feature: the admin Tools page's
        // "Direct Upgrade Link" fallback (shown when the AJAX DB Upgrade
        // button itself fails) generates a GET link with
        // ?gs_force_upgrade=1&_wpnonce=... but nothing anywhere in the
        // codebase ever read or verified that query var — clicking it
        // just reloaded the page and did nothing, silently breaking the
        // one recovery path meant for when AJAX is broken. Wired up here
        // via admin_init so it actually runs the same schema upgrade the
        // AJAX button performs.
        add_action( 'admin_init', [ self::class, 'handle_force_upgrade_link' ] );

        // 14. Redirect WP's password reset link to our custom page
        add_filter( 'retrieve_password_message', [ self::class, 'custom_reset_email_message' ], 10, 4 );

        // ── NEW FEATURES (additive, do not alter above) ───────────────────────

        // 15. Maintenance mode enforcer — runs before Router (priority -1 vs Router's 0)
        add_action( 'template_redirect', [ self::class, 'enforce_maintenance' ], -1 );

        // 16. Cookie consent banner in footer (GDPR / India DPDPA)
        add_action( 'wp_footer', [ self::class, 'cookie_consent_banner' ] );

        // 17. Custom 404 page — runs after Router has had its chance (priority 99)
        add_action( 'template_redirect', [ self::class, 'custom_404_page' ], 99 );

        // 18. Business hours save AJAX (vendor profile editor → vendor_profiles + listings)
        add_action( 'wp_ajax_gs_save_business_hours', [ self::class, 'ajax_save_business_hours' ] );

        // 19. Redirect default wp-login.php to custom login — keeps branding seamless
        add_filter( 'login_url', [ self::class, 'gs_custom_login_url' ], 10, 3 );
        add_action( 'login_init', [ self::class, 'gs_redirect_wp_login' ] );

        // 19b. FIXED — Known Limitations audit: the admin Vendor Quality Monitor's
        // "Last Login" column used to reverse-engineer a login time from the
        // 'session_tokens' usermeta by json_decode()-ing it and subtracting a
        // hardcoded 43200 seconds (12h) from the token's expiration — silently
        // wrong (or a PHP notice) whenever a vendor's token array was empty,
        // malformed, or simply didn't use exactly a 12h TTL. WordPress core has
        // no real last-login field, so this now writes one explicitly on every
        // successful login, and the admin screen reads that directly instead of
        // reverse-engineering an approximation.
        add_action( 'wp_login', [ self::class, 'record_last_login' ], 10, 2 );

        // 20. Hide wp-login.php styles & suppress WP admin bar for non-admins on front-end
        add_filter( 'show_admin_bar', [ self::class, 'gs_hide_admin_bar_frontend' ] );

        // 21. FIXED — Known Limitations audit: the vendor Leads screen's "new
        // inquiry" notification used to be a plain 60-second setInterval poll
        // with no way to arrive sooner. Reused WordPress's own built-in
        // Heartbeat API (already shipped with core, no new library) instead
        // of hand-rolling WebSockets/SSE — the exact "push-based mechanism"
        // this limitation's own proposed fix named. heartbeat_settings
        // shortens the tick interval to 15s (WP core's enforced minimum
        // outside wp-admin); the actual per-vendor stats payload is added in
        // AjaxController::inject_inquiry_heartbeat() below.
        add_filter( 'heartbeat_settings', [ self::class, 'gs_heartbeat_settings' ] );
        add_filter( 'heartbeat_received', [ '\GoodService\Controller\AjaxController', 'inject_inquiry_heartbeat' ], 10, 2 );
    }

    /**
     * See the call site's comment inside boot() for the full root-cause
     * writeup. Compares the last-seen GS_VERSION (stored in the existing
     * 'gs_version' option — already written on activate(), just never
     * previously read back for this purpose) against the current
     * constant; on a genuine change, purges every cache layer this plugin
     * can reach and updates the stored value so this doesn't fire again
     * until the next real update. Every branch is individually
     * existence-checked, so this is a safe no-op on a host that has none
     * of these caching layers active — it never assumes any of them are
     * present.
     */
    private static function maybe_purge_cache_on_version_change(): void {
        $last_seen = get_option( 'gs_version', '' );
        if ( $last_seen === GS_VERSION ) { return; } // no real update since last boot — nothing to purge
        update_option( 'gs_version', GS_VERSION );
        if ( $last_seen === '' ) { return; } // first-ever activation, not an update — no stale cache can exist yet

        // LiteSpeed Cache (LSCache) — the confirmed layer on this
        // install's actual host (Nestify). do_action() is a safe no-op
        // when LSCWP isn't active; has_action() guards it explicitly
        // anyway, matching the same pattern already used in
        // RestApiController::no_cache_headers().
        if ( has_action( 'litespeed_purge_all' ) ) {
            do_action( 'litespeed_purge_all', 'gs23 plugin updated to ' . GS_VERSION );
        }
        // WP Rocket.
        if ( function_exists( 'rocket_clean_domain' ) ) { rocket_clean_domain(); }
        // W3 Total Cache.
        if ( function_exists( 'w3tc_flush_all' ) ) { w3tc_flush_all(); }
        // WP Super Cache.
        if ( function_exists( 'wp_cache_clear_cache' ) ) { wp_cache_clear_cache(); }
        // WordPress's own persistent object cache (Redis/Memcached via a
        // drop-in, or the default in-memory cache) — cheap and safe to
        // call even when no persistent backend is configured.
        wp_cache_flush();

        gs_write_log( 'Cache purge triggered on update: ' . $last_seen . ' → ' . GS_VERSION, 'INFO' );
    }

    /**
     * Real fix (v7.475.4) — see the doc comment at the call site in
     * boot() for the full evidence chain. Copies the plugin's real
     * gs-client-sw.js/gs-vendor-sw.js out to the true WordPress
     * filesystem root (ABSPATH) — NOT wp-content, the actual document
     * root — so they get a browser-default scope of '/' with no
     * Service-Worker-Allowed header required at all, sidestepping the
     * confirmed-broken .htaccess dependency entirely. Runs at most once
     * per real version change (mirrors maybe_purge_cache_on_version_change()'s
     * own guard, via a separate stored option so the two don't interfere
     * if one is ever fixed/reverted independently of the other) and never
     * on every page load. Fails safe: if ABSPATH isn't writable (some
     * locked-down hosts restrict this), this logs it and returns — it
     * never fatals the site, and the plugin-subfolder SW files stay in
     * place as a fallback registration path.
     */
    private static function maybe_sync_root_service_workers(): void {
        $last_synced = get_option( 'gs_root_sw_synced_version', '' );
        if ( $last_synced === GS_VERSION ) { return; }

        $pairs = [
            GS_DIR . 'assets/js/gs-client-sw.js'  => ABSPATH . 'gs-client-sw.js',
            GS_DIR . 'assets/js/gs-vendor-sw.js'  => ABSPATH . 'gs-vendor-sw.js',
            GS_DIR . 'assets/pwa/offline.html'    => ABSPATH . 'gs-offline.html',
        ];

        $all_ok = true;
        foreach ( $pairs as $source => $dest ) {
            if ( ! is_readable( $source ) ) {
                $all_ok = false;
                gs_write_log( 'Root SW sync: source file missing/unreadable: ' . $source, 'ERROR' );
                continue;
            }
            // is_writable() on a non-existent destination checks the
            // parent directory instead — exactly what's needed here,
            // since the destination file may not exist yet on first run.
            if ( ! is_writable( dirname( $dest ) ) ) {
                $all_ok = false;
                gs_write_log( 'Root SW sync: site root is not writable, cannot place ' . $dest . ' — Service-Worker-Allowed header workaround cannot apply on this host without filesystem write access at the document root.', 'ERROR' );
                continue;
            }
            if ( @copy( $source, $dest ) === false ) {
                $all_ok = false;
                gs_write_log( 'Root SW sync: copy() failed for ' . $source . ' → ' . $dest, 'ERROR' );
                continue;
            }
        }

        // Only mark this version as synced if every file actually copied
        // — a partial failure should retry on the very next page load
        // instead of silently being treated as done.
        if ( $all_ok ) {
            update_option( 'gs_root_sw_synced_version', GS_VERSION );
            gs_write_log( 'Root SW sync: gs-client-sw.js, gs-vendor-sw.js, and gs-offline.html copied to site root for version ' . GS_VERSION, 'INFO' );
        }
    }

    /** See hook #21 above. */
    public static function gs_heartbeat_settings( array $settings ): array {
        $settings['interval'] = 15;
        return $settings;
    }

    public static function activate(): void {
        Roles::register();
        Schema::install();
        Seeder::run();
        Router::register_rewrites();
        self::create_pages();
        flush_rewrite_rules();
        update_option( 'gs_version',    GS_VERSION );
        update_option( 'gs_db_version', GS_VERSION );
        error_log( '[GoodService] v' . GS_VERSION . ' activated.' );
    }

    public static function deactivate(): void {
        flush_rewrite_rules();
        wp_clear_scheduled_hook( 'gs_process_jobs' );
        wp_clear_scheduled_hook( 'gs_hourly' );
        wp_clear_scheduled_hook( 'gs_daily' );
        // FIXED — audit gap: 'gs_weekly' was never cleared here (pre-existing,
        // found while fixing the 'gs_monthly' registration gap below) — a
        // deactivated install kept firing Cron::weekly() forever since WP-Cron
        // events are stored independently of whether the plugin's hook callback
        // is still attached. 'gs_monthly' added for the same reason as soon as
        // it was introduced, so it can never independently outlive deactivation.
        wp_clear_scheduled_hook( 'gs_weekly' );
        wp_clear_scheduled_hook( 'gs_monthly' );
    }

    // ── Phase 12: PHP error handler ───────────────────────────────────────────
    /**
     * Captures PHP warnings, notices, and user errors into gs_error_log.
     * Fatal errors are captured separately in the shutdown function.
     * Only active when WP_DEBUG=true or gs_diag_php_errors option is set.
     */
    public static function php_error_handler( int $errno, string $errstr, string $errfile = '', int $errline = 0 ): bool {
        // Respect the @ operator (error suppression)
        if ( ! ( error_reporting() & $errno ) ) { return false; }

        $severity_map = [
            E_WARNING        => DiagnosticsEngine::SEV_WARNING,
            E_NOTICE         => DiagnosticsEngine::SEV_NOTICE,
            E_USER_ERROR     => DiagnosticsEngine::SEV_ERROR,
            E_USER_WARNING   => DiagnosticsEngine::SEV_WARNING,
            E_USER_NOTICE    => DiagnosticsEngine::SEV_NOTICE,
            E_DEPRECATED     => DiagnosticsEngine::SEV_NOTICE,
            E_USER_DEPRECATED=> DiagnosticsEngine::SEV_NOTICE,
            E_STRICT         => DiagnosticsEngine::SEV_NOTICE,
        ];

        $severity = $severity_map[ $errno ] ?? DiagnosticsEngine::SEV_WARNING;
        $msg      = "[E{$errno}] {$errstr}";

        try {
            DiagnosticsEngine::capture( DiagnosticsEngine::SRC_PHP, 'php_' . $errno, $severity, $msg, [
                'file' => str_replace( ABSPATH, '', $errfile ),
                'line' => $errline,
            ] );
        } catch ( \Throwable $e ) {
            // Never let the error handler throw — would cause infinite loop
        }

        return false; // let WordPress also handle the error
    }

    // ── Phase 12: JS error capture script ────────────────────────────────────
    /**
     * Injects a lightweight JavaScript error capture script into every page.
     * Covers Spec sections 1 (Frontend), 2 (Browser), 3 (Network):
     *   - window.onerror — catches uncaught JS exceptions
     *   - unhandledrejection — catches unhandled Promise rejections
     *   - Fetch intercept — catches network/API errors
     *   - CSP violations — Content-Security-Policy violations
     *   - CORS errors — cross-origin resource failures
     *   - localStorage/sessionStorage errors
     *   - Service Worker errors
     *   - Mixed content and deprecation warnings
     *
     * All captured errors are sent to gs_log_js_error or gs_log_network_error.
     * Rate-limited client-side (max 5 errors/30s per session) to prevent loops.
     * Total script weight: ~2KB gzipped.
     */
    public static function inject_error_capture_script(): void {
        $ajax_url = admin_url( 'admin-ajax.php' );
        $nonce    = wp_create_nonce( 'gs_ajax' );
        ?>
<script id="gs-diag-capture">
(function(){
'use strict';
/* GoodService Enterprise Diagnostics — Universal Error Capture v1.0
   Covers: JS runtime, Promise rejections, network errors, CORS, CSP,
   browser storage, service worker, mixed content, deprecation warnings. */

var _gsErrCount = 0;
var _gsErrTs    = 0;
var _gsAjaxUrl  = <?php echo wp_json_encode( $ajax_url ); ?>;
var _gsNonce    = <?php echo wp_json_encode( $nonce ); ?>;

/* Rate limiter — max 5 events per 30 seconds to prevent error storm flooding */
function _gsCanSend() {
  var now = Date.now();
  if (now - _gsErrTs > 30000) { _gsErrTs = now; _gsErrCount = 0; }
  if (_gsErrCount >= 5) return false;
  _gsErrCount++;
  return true;
}

/* Send error to PHP endpoint */
function _gsSendError(action, data) {
  if (!_gsCanSend()) return;
  try {
    var fd = new FormData();
    fd.append('action', action);
    fd.append('nonce', _gsNonce);
    Object.entries(data).forEach(function(kv){ fd.append(kv[0], kv[1]||''); });
    navigator.sendBeacon
      ? navigator.sendBeacon(_gsAjaxUrl, fd)
      : fetch(_gsAjaxUrl, {method:'POST', body:fd, keepalive:true}).catch(function(){});
  } catch(e) { /* never throw from error handler */ }
}

/* ── Section 1: JS runtime errors ──────────────────────────────────────── */
window.onerror = function(msg, src, line, col, err) {
  _gsSendError('gs_log_js_error', {
    type:    'js_runtime',
    message: String(msg).substring(0, 500),
    file:    String(src||'').substring(0, 300),
    line:    line || 0,
    col:     col || 0,
    stack:   (err && err.stack ? err.stack.substring(0, 2000) : ''),
    url:     window.location.href.substring(0, 500)
  });
  return false; // don't suppress default handling
};

/* ── Section 1/2: Unhandled Promise rejections ──────────────────────────── */
window.addEventListener('unhandledrejection', function(ev) {
  var reason = ev.reason;
  var msg = reason instanceof Error ? reason.message : String(reason);
  var stack = (reason instanceof Error && reason.stack) ? reason.stack : '';
  _gsSendError('gs_log_js_error', {
    type:    'unhandled_rejection',
    message: msg.substring(0, 500),
    file:    '',
    line:    0,
    stack:   stack.substring(0, 2000),
    url:     window.location.href.substring(0, 500)
  });
});

/* ── Section 2: Content-Security-Policy violations ──────────────────────── */
document.addEventListener('securitypolicyviolation', function(ev) {
  _gsSendError('gs_log_js_error', {
    type:    'csp_violation',
    message: 'CSP blocked: ' + ev.blockedURI + ' [' + ev.violatedDirective + ']',
    file:    ev.sourceFile || '',
    line:    ev.lineNumber || 0,
    url:     window.location.href.substring(0, 500)
  });
});

/* ── Section 3: Network / Fetch errors via global fetch intercept ───────── */
(function(){
  if (typeof window.fetch !== 'function') return;
  var _origFetch = window.fetch;
  window.fetch = function(input, init) {
    var url = (typeof input === 'string' ? input : (input && input.url ? input.url : String(input)));
    var method = (init && init.method ? init.method : 'GET');
    return _origFetch.apply(this, arguments).then(function(resp) {
      /* Capture 4xx/5xx responses as network errors */
      if (!resp.ok && resp.status >= 400) {
        _gsSendError('gs_log_network_error', {
          type:    'http_error',
          message: 'HTTP ' + resp.status + ' ' + resp.statusText,
          req_url: url.substring(0, 500),
          status:  resp.status,
          method:  method
        });
      }
      return resp;
    }).catch(function(err) {
      /* Fetch failure (network down, CORS block, DNS fail) */
      var msg = err instanceof Error ? err.message : String(err);
      _gsSendError('gs_log_network_error', {
        type:    'fetch_error',
        message: msg.substring(0, 300),
        req_url: url.substring(0, 500),
        status:  0,
        method:  method
      });
      throw err; // re-throw so callers still get the rejection
    });
  };
})();

/* ── Section 3: XMLHttpRequest error capture ────────────────────────────── */
(function(){
  var _origOpen = XMLHttpRequest.prototype.open;
  var _origSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url) {
    this._gs_method = method;
    this._gs_url    = url;
    return _origOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function() {
    var xhr = this;
    var _origOnErr = xhr.onerror;
    xhr.addEventListener('error', function() {
      _gsSendError('gs_log_network_error', {
        type:    'xhr_error',
        message: 'XHR network error',
        req_url: String(xhr._gs_url||'').substring(0, 500),
        status:  xhr.status || 0,
        method:  xhr._gs_method || 'GET'
      });
    });
    xhr.addEventListener('load', function() {
      if (xhr.status >= 400) {
        _gsSendError('gs_log_network_error', {
          type:    'xhr_http_error',
          message: 'XHR HTTP ' + xhr.status,
          req_url: String(xhr._gs_url||'').substring(0, 500),
          status:  xhr.status,
          method:  xhr._gs_method || 'GET'
        });
      }
    });
    return _origSend.apply(this, arguments);
  };
})();

/* ── Section 2: localStorage / sessionStorage errors ───────────────────── */
(function(){
  ['localStorage','sessionStorage'].forEach(function(storeName){
    try {
      window[storeName].setItem('__gs_test__','1');
      window[storeName].removeItem('__gs_test__');
    } catch(e) {
      _gsSendError('gs_log_js_error', {
        type:    'storage_unavailable',
        message: storeName + ' unavailable: ' + e.message,
        file:    '', line: 0, url: window.location.href.substring(0,500)
      });
    }
  });
})();

/* ── Section 2: Service Worker errors ──────────────────────────────────── */
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.addEventListener('message', function(ev) {
    if (ev.data && ev.data.type === 'GS_SW_ERROR') {
      _gsSendError('gs_log_js_error', {
        type:    'service_worker_error',
        message: ev.data.message || 'Service Worker error',
        file:    ev.data.file || '', line: ev.data.line || 0,
        url:     window.location.href.substring(0, 500)
      });
    }
  });
}

/* ── Section 1: React error boundary integration (if React is present) ── */
if (typeof React !== 'undefined' && typeof React.Component !== 'undefined') {
  var _origRender = React.Component.prototype.render;
  // Global React error event via error boundary pattern
  window.addEventListener('error', function(ev) {
    if (ev.error && ev.error._suppressLogging) return; // suppress already-handled
    /* Already caught by window.onerror above */
  });
}

/* ── Resource load failures (broken images, scripts, stylesheets) ──────── */
window.addEventListener('error', function(ev) {
  var target = ev.target;
  if (!target || target === window) return; // runtime errors handled by onerror
  var tagName  = (target.tagName || '').toUpperCase();
  var src      = target.src || target.href || '';
  if (tagName === 'IMG' || tagName === 'SCRIPT' || tagName === 'LINK') {
    _gsSendError('gs_log_js_error', {
      type:    'resource_load_failure',
      message: 'Failed to load ' + tagName + ': ' + src.substring(0, 300),
      file:    src.substring(0, 300), line: 0,
      url:     window.location.href.substring(0, 500)
    });
  }
}, true /* capture phase — needed for resource errors */);

/* ── Performance / Core Web Vitals monitoring ────────────────────────────
   Captures LCP, CLS, FCP, TTFB, and INP as separate observers (buffered:true
   only works with a single entry type per observer, not a shared multi-type
   one — using one shared observer for all of these was the reason CLS and
   TTFB were never actually captured before this fix) and reports them as
   performance events. */
(function(){
  if (!window.PerformanceObserver) return;
  var vitals = {};
  function _reportVitals() {
    if (vitals.lcp && vitals.lcp > 4000) {
      _gsSendError('gs_log_js_error', {
        type:    'poor_lcp', message: 'LCP ' + vitals.lcp + 'ms (poor > 4000ms)',
        file: '', line: 0, url: window.location.href.substring(0,500)
      });
    }
    if (vitals.cls && vitals.cls > 0.25) {
      _gsSendError('gs_log_js_error', {
        type: 'poor_cls', message: 'CLS ' + vitals.cls.toFixed(3) + ' (poor > 0.25)',
        file: '', line: 0, url: window.location.href.substring(0,500)
      });
    }
    if (vitals.ttfb && vitals.ttfb > 1800) {
      _gsSendError('gs_log_js_error', {
        type: 'poor_ttfb', message: 'TTFB ' + vitals.ttfb + 'ms (poor > 1800ms)',
        file: '', line: 0, url: window.location.href.substring(0,500)
      });
    }
    if (vitals.fcp && vitals.fcp > 3000) {
      _gsSendError('gs_log_js_error', {
        type: 'poor_fcp', message: 'FCP ' + vitals.fcp + 'ms (poor > 3000ms)',
        file: '', line: 0, url: window.location.href.substring(0,500)
      });
    }
    if (vitals.inp && vitals.inp > 500) {
      _gsSendError('gs_log_js_error', {
        type: 'poor_inp', message: 'INP ' + vitals.inp + 'ms (poor > 500ms, approximated from worst observed interaction)',
        file: '', line: 0, url: window.location.href.substring(0,500)
      });
    }
  }
  try {
    new PerformanceObserver(function(list){
      list.getEntries().forEach(function(e){ vitals.lcp = e.startTime; });
    }).observe({type:'largest-contentful-paint',buffered:true});
  } catch(e){}
  try {
    new PerformanceObserver(function(list){
      list.getEntries().forEach(function(e){
        if (!e.hadRecentInput) { vitals.cls = (vitals.cls||0)+e.value; }
      });
    }).observe({type:'layout-shift',buffered:true});
  } catch(e){}
  try {
    new PerformanceObserver(function(list){
      list.getEntries().forEach(function(e){
        if (e.name === 'first-contentful-paint') { vitals.fcp = e.startTime; }
      });
    }).observe({type:'paint',buffered:true});
  } catch(e){}
  try {
    new PerformanceObserver(function(list){
      list.getEntries().forEach(function(e){ vitals.ttfb = e.responseStart; });
    }).observe({type:'navigation',buffered:true});
  } catch(e){}
  try {
    new PerformanceObserver(function(list){
      list.getEntries().forEach(function(e){
        var dur = e.duration || 0;
        if (dur > (vitals.inp || 0)) { vitals.inp = dur; }
      });
    }).observe({type:'event',buffered:true,durationThreshold:40});
  } catch(e){}
  window.addEventListener('pagehide', _reportVitals);
  window.addEventListener('visibilitychange', function(){ if(document.visibilityState==='hidden') _reportVitals(); });
})();

})(); /* end IIFE */
</script>
<script id="gs-diag-capture-ext">
(function(){
'use strict';
/* GoodService Diagnostics — Extended Browser Coverage v1.0
   Covers §2: Cookies, IndexedDB, WebSocket, Push, Deprecation warnings */

var _gsErrBase = window._gsErrCount !== undefined;
var _ajaxUrl   = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
var _nonce     = <?php echo wp_json_encode( $nonce ); ?>;
var _sent      = 0;

function _gsSend2(type, msg) {
  if (_sent++ > 10) return;
  try {
    var fd = new FormData();
    fd.append('action','gs_log_js_error');
    fd.append('nonce', _nonce);
    fd.append('type', type);
    fd.append('message', String(msg).substring(0,400));
    fd.append('url', window.location.href.substring(0,400));
    navigator.sendBeacon ? navigator.sendBeacon(_ajaxUrl, fd)
      : fetch(_ajaxUrl,{method:'POST',body:fd,keepalive:true}).catch(function(){});
  } catch(e){}
}

/* ── §2: Cookie access errors ───────────────────────────────────────── */
try {
  var _cookieTest = 'gs_ck_test=1';
  document.cookie = _cookieTest;
  if (document.cookie.indexOf('gs_ck_test') === -1) {
    _gsSend2('cookie_blocked','Cookies are blocked or disabled in this browser. Features requiring sessions may break.');
  } else {
    // Clean up test cookie
    document.cookie = 'gs_ck_test=;expires=Thu, 01 Jan 1970 00:00:00 GMT';
  }
} catch(e) {
  _gsSend2('cookie_error', 'Cookie access error: ' + e.message);
}

/* ── §2: IndexedDB availability test ───────────────────────────────── */
if ('indexedDB' in window) {
  try {
    var _idbReq = indexedDB.open('_gs_idb_test', 1);
    _idbReq.onerror = function(ev) {
      _gsSend2('indexeddb_error', 'IndexedDB open failed: ' + (ev.target.error ? ev.target.error.message : 'unknown'));
    };
    _idbReq.onsuccess = function() {
      try { _idbReq.result.close(); indexedDB.deleteDatabase('_gs_idb_test'); } catch(e){}
    };
  } catch(e) {
    _gsSend2('indexeddb_error', 'IndexedDB unavailable: ' + e.message);
  }
}

/* ── §2: WebSocket connection monitoring ────────────────────────────── */
if (typeof WebSocket !== 'undefined') {
  var _origWS = window.WebSocket;
  window.WebSocket = function(url, protocols) {
    var ws = protocols ? new _origWS(url, protocols) : new _origWS(url);
    ws.addEventListener('error', function() {
      _gsSend2('websocket_error', 'WebSocket connection error: ' + url.substring(0,200));
    });
    return ws;
  };
  window.WebSocket.prototype = _origWS.prototype;
  Object.getOwnPropertyNames(_origWS).forEach(function(k){
    try { if (k!=='prototype') window.WebSocket[k]=_origWS[k]; } catch(e){}
  });
}

/* ── §2: Push Notification permission/errors ───────────────────────── */
if ('PushManager' in window && 'serviceWorker' in navigator) {
  navigator.serviceWorker.ready.then(function(reg) {
    if (!reg.pushManager) return;
    reg.pushManager.getSubscription().then(function(sub) {
      /* Just testing availability — errors will surface via window.onerror */
    }).catch(function(e) {
      _gsSend2('push_notification_error', 'Push subscription check failed: ' + e.message);
    });
  }).catch(function(){});
}

/* ── §2: Deprecation warning capture via console override ──────────── */
(function(){
  var _origWarn = console.warn;
  console.warn = function() {
    var msg = Array.prototype.join.call(arguments,' ');
    if (msg.toLowerCase().indexOf('deprecat') !== -1 || msg.toLowerCase().indexOf('deprecated') !== -1) {
      _gsSend2('deprecation_warning', msg.substring(0,300));
    }
    return _origWarn.apply(console, arguments);
  };
  /* Also capture console.error for additional coverage */
  var _origErr = console.error;
  console.error = function() {
    var msg = Array.prototype.join.call(arguments,' ');
    /* Only capture errors that look structural, not API data errors */
    if (msg.length > 5 && msg.length < 500 &&
        (msg.indexOf('TypeError') !== -1 || msg.indexOf('ReferenceError') !== -1 ||
         msg.indexOf('Uncaught') !== -1 || msg.indexOf('Cannot') !== -1)) {
      _gsSend2('console_error', msg.substring(0,300));
    }
    return _origErr.apply(console, arguments);
  };
})();

/* ── §1: Memory leak detection — large detached DOM trees ──────────── */
(function(){
  if (!window.WeakRef || !window.FinalizationRegistry) return;
  var _domCount = 0;
  var _origCreate = document.createElement.bind(document);
  document.createElement = function(tag) {
    _domCount++;
    if (_domCount > 5000 && _domCount % 1000 === 0) {
      _gsSend2('dom_memory_leak', 'Excessive DOM element creation detected: '+_domCount+' elements created since page load. Possible memory leak.');
    }
    return _origCreate(tag);
  };
})();

/* ── §1: Infinite render loop detection ────────────────────────────── */
(function(){
  var _renderCount = 0;
  var _renderTs    = 0;
  /* Hook into MutationObserver to detect rapid DOM mutations */
  if (window.MutationObserver) {
    new MutationObserver(function(mutations) {
      var now = Date.now();
      if (now - _renderTs < 1000) {
        _renderCount += mutations.length;
        if (_renderCount > 500) {
          _gsSend2('infinite_render_loop', 'Possible infinite render loop: ' + _renderCount + ' DOM mutations in 1 second. Check for circular state updates.');
          _renderCount = 0;
        }
      } else {
        _renderTs    = now;
        _renderCount = mutations.length;
      }
    }).observe(document.body || document.documentElement, { childList: true, subtree: true });
  }
})();

/* ── §3: GraphQL error capture ──────────────────────────────────────── */
(function(){
  /* Intercept fetch to detect GraphQL error responses */
  if (typeof window.fetch !== 'function') return;
  var _gsFetch = window.fetch;
  window.fetch = function(input, init) {
    var url = typeof input === 'string' ? input : (input && input.url ? input.url : '');
    return _gsFetch.apply(this, arguments).then(function(resp) {
      /* Check if this looks like a GraphQL endpoint */
      var ct = resp.headers.get('content-type') || '';
      if (url.indexOf('/graphql') !== -1 || url.indexOf('graphql') !== -1) {
        resp.clone().json().then(function(data) {
          if (data && data.errors && data.errors.length) {
            _gsSend2('graphql_error', 'GraphQL errors: ' + JSON.stringify(data.errors).substring(0,300));
          }
        }).catch(function(){});
      }
      return resp;
    });
  };
})();

/* ── §7: Accessibility violation detection ──────────────────────────── */
(function(){
  if (!document.addEventListener) return;
  document.addEventListener('DOMContentLoaded', function() {
    /* Check for images without alt text */
    var imgs = document.querySelectorAll('img:not([alt])');
    if (imgs.length > 5) {
      _gsSend2('accessibility_violation', imgs.length + ' images missing alt attributes on ' + window.location.pathname);
    }
    /* Check for buttons/inputs without labels */
    var unlabelledBtns = document.querySelectorAll('button:not([aria-label]):not([title])');
    var emptyBtns = Array.prototype.filter.call(unlabelledBtns, function(b){ return !b.textContent.trim(); });
    if (emptyBtns.length > 0) {
      _gsSend2('accessibility_violation', emptyBtns.length + ' icon-only buttons without aria-label on ' + window.location.pathname);
    }
  });
})();

})();
</script>
        <?php
    }

    // Real fix — confirmed dead feature: handles the admin Tools page's
    // "Direct Upgrade Link" (?gs_force_upgrade=1&_wpnonce=...). Verifies
    // the same nonce action used to generate the link, requires an
    // admin-capable user, runs the identical schema upgrade the AJAX
    // gs_run_db_upgrade handler performs, then redirects back to the
    // Tools page with a plain success/failure flag so the admin gets
    // visible confirmation instead of a silent no-op reload.
    public static function handle_force_upgrade_link(): void {
        if ( empty( $_GET['gs_force_upgrade'] ) ) { return; }
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $nonce = sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ?? '' ) );
        if ( ! wp_verify_nonce( $nonce, 'gs_force_upgrade' ) ) {
            wp_die( 'Security check failed. Please go back and try again.', 403 );
        }
        $ok = true;
        try {
            \GoodService\Database\Schema::upgrade_only();
            update_option( 'gs_db_version', GS_VERSION );
        } catch ( \Throwable $e ) {
            $ok = false;
            if ( function_exists( 'gs_write_log' ) ) {
                gs_write_log( 'handle_force_upgrade_link error: ' . $e->getMessage() );
            }
        }
        wp_safe_redirect( add_query_arg(
            [ 'gs_force_upgrade' => false, '_wpnonce' => false, 'gs_upgrade_result' => $ok ? 'success' : 'error' ],
            admin_url( 'admin.php?page=goodservice&section=tools' )
        ) );
        exit;
    }

    public static function check_db_version(): void {
        static $ran = false;
        if ( $ran ) { return; }
        $ran = true;

        $installed = get_option( 'gs_db_version', '0' );
        if ( version_compare( $installed, GS_VERSION, '<' ) ) {
            // Set version FIRST to prevent infinite loop if install() throws
            update_option( 'gs_db_version', GS_VERSION );
            try {
                Schema::install();
                self::create_pages();
                Router::register_rewrites();
                flush_rewrite_rules();
                // Manual Subscription & Offline Payment system — idempotent per-slug,
                // safe to call on every version bump even though Seeder::run() itself
                // only runs once (at activation, gated by "plans table empty?").
                \GoodService\Service\ManualPlanService::seed_email_templates();
                // Real fix — confirmed root cause of a reported bug: every
                // email template added via Seeder's own seed_email_templates()
                // (not the ManualPlanService one above) was NEVER re-inserted
                // on a version bump — Seeder::run() exits early via a
                // "tables already populated?" guard on any live site, so new
                // templates added in a code update never reached the actual
                // database. Called directly here instead, bypassing that
                // guard — it's already idempotent (only inserts missing
                // rows), so this is safe on every version bump.
                global $wpdb;
                \GoodService\Database\Seeder::seed_email_templates( $wpdb->prefix . 'gs_' );
                // Real fix — confirmed root cause of a reported bug: the
                // 'hotels', 'real-estate' and 'interior-designers-architects'
                // categories were referenced by ModuleRegistry (every
                // Hotels/Real-Estate/Interior-Designers module, the full
                // Hospitality series included) but were never added to
                // Seeder's seed_categories() array, and — same as the
                // email-templates case immediately above — that method
                // only runs once, at activation, on brand-new installs, so
                // an existing, already-installed site could never get
                // these 3 rows through it. Without a row in
                // wp_gs_categories, a vendor could never select these
                // categories at all, so their sections could never appear
                // in the Sections tab for anyone. sync_missing_categories()
                // is itself idempotent (inserts only missing slugs), so —
                // exactly like the seed_email_templates() call above — it
                // is safe to run on every version bump.
                \GoodService\Database\Seeder::sync_missing_categories( $wpdb->prefix . 'gs_' );
                // Real feature — Specifications/Features repeater section
                // type, same pattern as the two calls immediately above:
                // Seeder::run() only seeds section_templates once, at
                // activation, on brand-new installs (gated by "plans table
                // empty?") — an existing, already-installed site would
                // never get this new default template row otherwise.
                // seed_section_templates() only inserts a row when its
                // slug doesn't already exist, so this is safe to call on
                // every version bump; it will never duplicate or touch
                // any row an admin has already edited or deleted.
                \GoodService\Database\Seeder::seed_section_templates( $wpdb->prefix . 'gs_' );
                // Real fix — confirmed root cause of reported "wrong service
                // content attached to an SEO keyword" bug: SeoEntryService's
                // find_service_detail() used to attach a vendor's service
                // description to ANY keyword sharing even one generic word
                // with that service's name (e.g. "certificate"), producing
                // mismatched intro/H1 content across many vendors, not just
                // one. Fixing the generator alone doesn't repair rows that
                // were already generated with the old, wrong logic — this
                // regenerates every existing entry's title/meta/h1/intro
                // from its stored keyword using the corrected logic. Runs
                // once on this version bump, automatically, no admin action
                // needed; safe to run again (idempotent).
                \GoodService\SEO\SeoEntryService::repair_all_content();
                // ENTERPRISE-AUDIT FIX (Critical security finding): Config's
                // SENSITIVE_KEYS list had drifted out of sync with the keys
                // the Settings UI actually stores (Stripe secret/webhook,
                // Razorpay webhook, WhatsApp business token/verify token were
                // all missing from it), so those live payment/webhook secrets
                // were being saved in PLAINTEXT despite the encryption-at-rest
                // claim in Config's own docblock. The list is now corrected
                // and canonical; this call re-encrypts any row for a
                // sensitive key that is still sitting in plaintext from
                // before this fix. Idempotent (skips already-encrypted rows),
                // safe to run on every version bump — no admin action needed.
                $reencrypted = \GoodService\Core\Config::reencrypt_plaintext_sensitive_values();
                if ( $reencrypted > 0 && function_exists( 'gs_write_log' ) ) {
                    gs_write_log( "check_db_version: re-encrypted {$reencrypted} previously-plaintext sensitive setting(s)." );
                }
            } catch ( \Throwable $e ) {
                if ( function_exists( 'gs_write_log' ) ) {
                    gs_write_log( 'check_db_version error: ' . $e->getMessage() );
                }
            }
        }

        // ── FIX: Always verify critical migration columns exist ───────────────
        // Even on same-version installs, columns may have been missed (ALTER TABLE
        // failures, server restarts during migration, etc.). Run a lightweight check
        // once per admin session (transient-cached, 60 min TTL) and auto-heal.
        self::ensure_migration_columns();

        // Normalise any uppercase listing slugs to lowercase.
        // Uppercase slugs break the clean-URL rewrite rule (regex was [a-z0-9\-] only).
        // This migration runs once (transient gate) and fixes the production 404 issue
        // where slugs like 'glow-beauty-studio-services-ponQ' returned 404.
        self::normalise_listing_slugs();

        // Clear any hex colour codes accidentally saved as seo_title (e.g. '#f5a623')
        // This is a one-time data-fix that runs until no bad rows remain.
        self::clear_hex_seo_titles();

        // Section 7 of the inquiry/booking audit: grant the Starter plan booking
        // access (it previously only had allow_inquiry_module). Updates the LIVE
        // row on existing installs — the Seeder.php default only affects brand-new
        // installs that haven't seeded plans yet, which this site already has.
        self::grant_starter_plan_booking_access();
    }

    /**
     * One-time migration: Starter plan gains allow_booking_module=1, capped at
     * max_booking_modules=1 (vendors on Starter can enable direct booking on one
     * service category at a time; Professional remains unlimited). Only touches
     * the row if it still has the old allow_booking_module=0 default, so an admin
     * who has since customised this plan's booking settings manually is not
     * silently overwritten.
     */
    private static function grant_starter_plan_booking_access(): void {
        $cache_key = 'gs_starter_booking_access_v1';
        if ( get_transient( $cache_key ) ) { return; }

        global $wpdb;
        $table = $wpdb->prefix . 'gs_subscription_plans';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) ) {
            set_transient( $cache_key, 1, DAY_IN_SECONDS );
            return;
        }

        $wpdb->update(
            $table,
            [ 'allow_booking_module' => 1, 'max_booking_modules' => 1 ],
            [ 'slug' => 'starter', 'allow_booking_module' => 0 ]
        );

        set_transient( $cache_key, 1, DAY_IN_SECONDS );
    }



    /**
     * Real fix — replaces the WP password reset URL by building the entire
     * reset email message from scratch, using the real key/login/user_data
     * parameters WordPress already passes in, rather than trying to find-
     * and-replace a URL inside WordPress's own auto-generated message text.
     * The previous regex-based approach had a lazy-quantifier bug that
     * left corrupted, stray text in the message (confirmed by direct
     * testing) — this sidesteps that entire class of problem by never
     * parsing WordPress's message at all.
     */
    public static function custom_reset_email_message( string $message, string $key, string $user_login, \WP_User $user_data ): string {
        $reset_url = add_query_arg( [
            'key'   => $key,
            'login' => $user_login,
        ], home_url( '/reset-password/' ) );

        gs_write_log(
            "Password reset requested for user #{$user_data->ID} ({$user_login}). Reset URL generated: {$reset_url}",
            'INFO'
        );

        $site_name = get_bloginfo( 'name' );
        $message  = sprintf( __( 'Someone has requested a password reset for the following account on %s:' ), $site_name ) . "\r\n\r\n";
        $message .= sprintf( __( 'Username: %s' ), $user_login ) . "\r\n\r\n";
        $message .= __( 'If this was a mistake, ignore this email and nothing will happen.' ) . "\r\n\r\n";
        $message .= __( 'To reset your password, visit the following address:' ) . "\r\n\r\n";
        $message .= $reset_url . "\r\n\r\n";
        $message .= __( 'This link will expire in 24 hours.' ) . "\r\n";

        return $message;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // FEATURE 15 — Maintenance Mode
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * If maintenance_mode is enabled in gs_settings, show a branded maintenance
     * page to everyone except admins. Fires at template_redirect priority -1
     * so it runs before Router (priority 0) and before any GoodService pages render.
     */
    public static function enforce_maintenance(): void {
        // Only applies to front-end requests
        if ( is_admin() ) return;

        // Check setting — 0 or empty = off, '1' = on
        if ( ! gs_setting( 'maintenance_mode', '0' ) ) return;

        // Admins always bypass
        if ( current_user_can( 'manage_options' ) ) return;

        // Allow access to the admin panel slug and login page
        $uri = $_SERVER['REQUEST_URI'] ?? '';
        foreach ( [ '/admin-panel/', '/vendor-login/', '/wp-login.php', '/wp-admin/' ] as $bypass ) {
            if ( str_contains( $uri, $bypass ) ) return;
        }

        $platform = get_bloginfo( 'name' );
        $logo_url = Config::get( 'logo_url', '' );
        $msg      = Config::get( 'maintenance_message', 'We are performing scheduled maintenance. We\'ll be back shortly!' );

        http_response_code( 503 );
        header( 'Retry-After: 3600' );
        header( 'Content-Type: text/html; charset=UTF-8' );
        // phpcs:disable WordPress.Security.EscapeOutput
        echo '<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Maintenance — ' . esc_html( $platform ) . '</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{min-height:100vh;display:flex;align-items:center;justify-content:center;
     background:linear-gradient(135deg,#1E3A5F 0%,#2563EB 100%);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif}
.gs-maint{background:#fff;border-radius:18px;padding:48px 40px;text-align:center;max-width:480px;width:90%;box-shadow:0 24px 64px rgba(0,0,0,.22)}
.gs-maint-icon{font-size:3.2rem;margin-bottom:16px}
.gs-maint h1{font-size:1.4rem;font-weight:800;color:#1E293B;margin-bottom:10px}
.gs-maint p{font-size:.92rem;color:#64748B;line-height:1.7}
.gs-maint-logo{max-height:48px;margin-bottom:22px;object-fit:contain}
</style>
</head><body>
<div class="gs-maint">
  ' . ( $logo_url ? '<img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( $platform ) . '" class="gs-maint-logo">' : '' ) . '
  <div class="gs-maint-icon">🔧</div>
  <h1>Maintenance in Progress</h1>
  <p>' . esc_html( $msg ) . '</p>
  <p style="margin-top:16px;font-size:.79rem;color:#94A3B8">Please check back soon. We\'ll be back before you know it.</p>
</div>
</body></html>';
        // phpcs:enable
        exit;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // FEATURE 16 — Cookie Consent Banner
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Output a GDPR / India DPDPA compliant cookie consent banner in wp_footer.
     * The banner fires on first visit, stores choice in localStorage, and does NOT
     * block page rendering. Analytics scripts should check gs_cookie_consent before
     * firing (the banner sets window.gsCookieConsent = 'accepted' | 'rejected').
     */
    public static function cookie_consent_banner(): void {
        // Only on public-facing pages, not inside WP admin
        if ( is_admin() ) return;

        $platform   = get_bloginfo( 'name' );
        $policy_url = home_url( '/privacy-policy/' );
        ?>
<style id="gs-cookie-banner-css">
#gs-cb{position:fixed;bottom:0;left:0;right:0;z-index:99999;background:#1E293B;color:#fff;
       padding:14px 20px;display:flex;align-items:center;gap:14px;flex-wrap:wrap;
       box-shadow:0 -4px 20px rgba(0,0,0,.22);font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;
       font-size:.83rem;line-height:1.5;transition:transform .3s ease}
#gs-cb.gs-cb-hide{transform:translateY(110%)}
#gs-cb-text{flex:1;min-width:200px;color:#CBD5E1}
#gs-cb-text a{color:#93C5FD;text-decoration:underline}
#gs-cb-btns{display:flex;gap:8px;flex-shrink:0;flex-wrap:wrap}
.gs-cb-btn{padding:7px 16px;border-radius:7px;font-size:.8rem;font-weight:600;cursor:pointer;border:none;font-family:inherit;transition:.15s}
#gs-cb-accept{background:#2563EB;color:#fff}
#gs-cb-accept:hover{background:#1D4ED8}
#gs-cb-reject{background:transparent;color:#94A3B8;border:1px solid #334155}
#gs-cb-reject:hover{background:#334155;color:#fff}
</style>
<div id="gs-cb" style="display:none" role="dialog" aria-label="Cookie consent" aria-live="polite">
  <div id="gs-cb-text">
    🍪 <?php echo esc_html( $platform ); ?> uses cookies to improve your experience and for analytics.
    <a href="<?php echo esc_url( $policy_url ); ?>" target="_blank" rel="noopener">Read our privacy policy</a>
  </div>
  <div id="gs-cb-btns">
    <button class="gs-cb-btn" id="gs-cb-accept" aria-label="Accept cookies">Accept All</button>
    <button class="gs-cb-btn" id="gs-cb-reject" aria-label="Reject optional cookies">Reject Optional</button>
  </div>
</div>
<script id="gs-cookie-banner-js">
(function(){
  var STORE_KEY = 'gs_cookie_consent';
  var already   = localStorage.getItem(STORE_KEY);
  if(already){ window.gsCookieConsent = already; return; } // Already decided

  var banner = document.getElementById('gs-cb');
  if(!banner) return;
  banner.style.display = 'flex';

  function dismiss(choice){
    window.gsCookieConsent = choice;
    localStorage.setItem(STORE_KEY, choice);
    banner.classList.add('gs-cb-hide');
    setTimeout(function(){ banner.style.display = 'none'; }, 350);
  }

  document.getElementById('gs-cb-accept').addEventListener('click', function(){ dismiss('accepted'); });
  document.getElementById('gs-cb-reject').addEventListener('click', function(){ dismiss('rejected'); });
})();
</script>
        <?php
    }

    // ═══════════════════════════════════════════════════════════════════════
    // FEATURE 17 — Custom 404 Page
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Intercept WordPress 404 errors and render a branded GoodService 404 page.
     * Runs at template_redirect priority 99, after Router has already handled
     * GoodService-specific paths (priority 0–2). Only fires for genuine WP 404s.
     */
    public static function custom_404_page(): void {
        if ( ! is_404() ) return;

        global $wpdb;
        $pfx      = $wpdb->prefix . 'gs_';
        $platform = get_bloginfo( 'name' );
        $home_url = home_url( '/' );
        $dir_url  = home_url( '/directory/' );
        $logo_url = Config::get( 'logo_url', '' );

        // Pull 4 featured or recent active listings for suggestions
        $suggestions = $wpdb->get_results(
            "SELECT id, title, slug, category_id, city, logo_url
             FROM {$pfx}listings
             WHERE status = 'active'
             ORDER BY is_featured DESC, views_count DESC
             LIMIT 4"
        ) ?: [];

        status_header( 404 );
        header( 'Content-Type: text/html; charset=UTF-8' );
        // phpcs:disable WordPress.Security.EscapeOutput
        echo '<!DOCTYPE html><html lang="en"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Page Not Found — ' . esc_html( $platform ) . '</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Arial,sans-serif;background:#F8FAFC;color:#1E293B}
.gs404-header{background:#1E3A5F;padding:14px 24px;display:flex;align-items:center;gap:14px}
.gs404-header a{color:#fff;text-decoration:none;font-weight:700;font-size:1.05rem}
.gs404-header img{max-height:36px;object-fit:contain}
.gs404-body{max-width:760px;margin:0 auto;padding:52px 24px 60px;text-align:center}
.gs404-code{font-size:5rem;font-weight:900;color:#E2E8F0;line-height:1}
.gs404-title{font-size:1.5rem;font-weight:800;color:#1E293B;margin:10px 0 10px}
.gs404-sub{font-size:.95rem;color:#64748B;line-height:1.7;margin-bottom:28px}
.gs404-search{display:flex;gap:10px;max-width:420px;margin:0 auto 32px;flex-wrap:wrap}
.gs404-search input{flex:1;min-width:180px;padding:11px 14px;border:1px solid #E2E8F0;border-radius:9px;font-size:.92rem;font-family:inherit;outline:none}
.gs404-search input:focus{border-color:#2563EB}
.gs404-search button{padding:11px 20px;background:#2563EB;color:#fff;border:none;border-radius:9px;font-weight:700;cursor:pointer;font-family:inherit;font-size:.92rem}
.gs404-suggest{text-align:left;margin-bottom:32px}
.gs404-suggest-title{font-size:.78rem;font-weight:700;color:#94A3B8;text-transform:uppercase;letter-spacing:.06em;margin-bottom:12px}
.gs404-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px}
.gs404-card{background:#fff;border:1px solid #E2E8F0;border-radius:10px;padding:14px;text-decoration:none;color:#1E293B;transition:.15s}
.gs404-card:hover{border-color:#2563EB;box-shadow:0 4px 16px rgba(37,99,235,.12)}
.gs404-card-logo{width:36px;height:36px;border-radius:6px;object-fit:cover;background:#F1F5F9;margin-bottom:8px}
.gs404-card-name{font-weight:700;font-size:.83rem;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.gs404-card-city{font-size:.72rem;color:#64748B;margin-top:4px}
.gs404-home{display:inline-block;padding:11px 28px;background:#F1F5F9;color:#2563EB;border-radius:9px;text-decoration:none;font-weight:700;font-size:.9rem}
.gs404-home:hover{background:#DBEAFE}
</style>
</head><body>
<div class="gs404-header">
  ' . ( $logo_url ? '<img src="' . esc_url( $logo_url ) . '" alt="' . esc_attr( $platform ) . '">' : '' ) . '
  <a href="' . esc_url( $home_url ) . '">' . esc_html( $platform ) . '</a>
</div>
<div class="gs404-body">
  <div class="gs404-code">404</div>
  <h1 class="gs404-title">Page Not Found</h1>
  <p class="gs404-sub">The page you\'re looking for doesn\'t exist or may have been moved.<br>Try searching the directory or go back to the homepage.</p>

  <form class="gs404-search" action="' . esc_url( $dir_url ) . '" method="get">
    <input type="text" name="q" placeholder="Search businesses, services…" aria-label="Search directory">
    <button type="submit">Search →</button>
  </form>';

        if ( $suggestions ) {
            echo '<div class="gs404-suggest">
    <div class="gs404-suggest-title">You might be looking for</div>
    <div class="gs404-grid">';
            foreach ( $suggestions as $s ) {
                $listing_url = esc_url( home_url( '/' . $s->slug . '/' ) );
                $logo        = $s->logo_url ? '<img src="' . esc_url( $s->logo_url ) . '" alt="" class="gs404-card-logo">' : '<div class="gs404-card-logo" style="display:flex;align-items:center;justify-content:center;font-size:1.2rem">🏢</div>';
                echo '<a href="' . $listing_url . '" class="gs404-card">'
                   . $logo
                   . '<div class="gs404-card-name">' . esc_html( $s->title ) . '</div>'
                   . ( $s->city ? '<div class="gs404-card-city">📍 ' . esc_html( $s->city ) . '</div>' : '' )
                   . '</a>';
            }
            echo '</div></div>';
        }

        echo '  <a href="' . esc_url( $home_url ) . '" class="gs404-home">← Go to Homepage</a>
</div>
</body></html>';
        // phpcs:enable
        exit;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // FEATURE 18 — Business Hours Save AJAX Action
    // ═══════════════════════════════════════════════════════════════════════

    /**
     * Save vendor business hours to both vendor_profiles.opening_hours and
     * all of the vendor's gs_listings rows. This ensures the "Now Open/Closed"
     * badge on listing detail pages reflects the correct schedule.
     *
     * POST params: nonce (gs_ajax), opening_hours (JSON string)
     */
    public static function ajax_save_business_hours(): void {
        check_ajax_referer( 'gs_ajax', 'nonce' );

        $uid = get_current_user_id();
        if ( ! $uid ) {
            wp_send_json_error( [ 'message' => 'Not logged in.' ] );
            return;
        }

        global $wpdb;

        // Decode and sanitise
        $raw   = wp_unslash( $_POST['opening_hours'] ?? '' );
        $hours = is_string( $raw ) ? @json_decode( $raw, true ) : null;
        if ( ! is_array( $hours ) ) {
            wp_send_json_error( [ 'message' => 'Invalid hours data.' ] );
            return;
        }

        $days  = [ 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday' ];
        $clean = [];
        foreach ( $days as $day ) {
            $val = sanitize_text_field( $hours[ $day ] ?? '' );
            // Accept "HH:MM - HH:MM" or empty (= closed)
            if ( $val && ! preg_match( '/^\d{1,2}:\d{2}\s*-\s*\d{1,2}:\d{2}$/', $val ) ) {
                $val = '';
            }
            $clean[ $day ] = $val;
        }
        $json = wp_json_encode( $clean );

        // Resolve vendor profile
        $vp = $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM {$wpdb->prefix}gs_vendor_profiles WHERE user_id = %d",
            $uid
        ) );
        if ( ! $vp ) {
            wp_send_json_error( [ 'message' => 'Vendor profile not found.' ] );
            return;
        }

        // 1. Save to vendor_profiles
        $wpdb->update(
            $wpdb->prefix . 'gs_vendor_profiles',
            [ 'opening_hours' => $json, 'updated_at' => current_time( 'mysql' ) ],
            [ 'id' => (int) $vp->id ],
            [ '%s', '%s' ],
            [ '%d' ]
        );

        // 2. Sync the same hours to all of the vendor's listings so the
        //    "Now Open / Closed" badge on listing detail pages is accurate.
        $wpdb->update(
            $wpdb->prefix . 'gs_listings',
            [ 'opening_hours' => $json ],
            [ 'vendor_id' => (int) $vp->id ],
            [ '%s' ],
            [ '%d' ]
        );

        // Bust vendor cache
        \GoodService\Core\Cache::delete( "vendor:user:{$uid}" );

        wp_send_json_success( [ 'message' => 'Business hours saved successfully.' ] );
    }

    /**
     * Checks for migration columns missing from the listings table and adds them.
     * Cached for 60 minutes — only costs 1 query per hour in the admin.
     */
    /**
     * One-time migration: lowercase all gs_listings.slug values that contain uppercase.
     * Uppercase slugs cause 404 because the clean-URL rewrite rule regex only matched [a-z0-9\-].
     * Run: once per site (transient gate). Idempotent — safe to call multiple times.
     *
     * OBSERVABLE OUTPUT: Listings like 'glow-beauty-studio-services-ponQ' become
     *   'glow-beauty-studio-services-ponq' in DB. Existing URLs with uppercase characters
     *   now 301-redirect to the canonical lowercase URL instead of 404ing.
     */
    public static function normalise_listing_slugs(): void {
        $cache_key = 'gs_slugs_normalised_v1';
        if ( get_transient( $cache_key ) ) return;

        global $wpdb;
        $table = $wpdb->prefix . 'gs_listings';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) ) {
            set_transient( $cache_key, 1, DAY_IN_SECONDS );
            return;
        }

        // Find all slugs that contain any uppercase character
        $rows = $wpdb->get_results(
            "SELECT id, slug FROM {$table} WHERE slug REGEXP '[A-Z]' AND slug IS NOT NULL AND slug != ''"
        );

        $fixed = 0;
        foreach ( $rows as $row ) {
            $lowercase = strtolower( $row->slug );
            if ( $lowercase === $row->slug ) continue; // already lowercase — skip

            // Check uniqueness: if lowercase version already exists as another listing's slug,
            // append '-2' (or increment) to avoid UNIQUE KEY violation
            $candidate = $lowercase;
            $suffix    = 2;
            while ( $wpdb->get_var( $wpdb->prepare(
                "SELECT id FROM {$table} WHERE slug = %s AND id != %d LIMIT 1",
                $candidate, $row->id
            ) ) ) {
                $candidate = $lowercase . '-' . $suffix++;
            }

            $result = $wpdb->update( $table, [ 'slug' => $candidate ], [ 'id' => $row->id ] );
            if ( $result !== false ) {
                $fixed++;
                if ( function_exists( 'gs_write_log' ) ) {
                    gs_write_log( "normalise_listing_slugs: {$row->slug} → {$candidate} (id={$row->id})", 'INFO' );
                }
            }
        }

        if ( $fixed > 0 ) {
            // Bust the shared listings cache group once for the whole batch —
            // "listing:id:{id}" (the old per-row call here) is not a key any
            // reader ever caches under; the real caches (listing:slug:*,
            // listings:featured:*, listings:related:*, listings:cities) all
            // need invalidating so old-slug entries don't keep serving.
            \GoodService\Core\Cache::flush_group( 'listings' );
            // Flush rewrite rules so WordPress picks up any slug changes immediately
            flush_rewrite_rules();
            if ( function_exists( 'gs_write_log' ) ) {
                gs_write_log( "normalise_listing_slugs: fixed {$fixed} uppercase slug(s). Rewrite rules flushed.", 'INFO' );
            }
        }

        // Cache for 24h — re-check daily in case new uppercase slugs are created
        set_transient( $cache_key, 1, DAY_IN_SECONDS );
    }

    /**
     * One-time data fix: clear hex colour codes saved as seo_title or seo_desc.
     *
     * Root cause: vendor site customizer stored the brand_color CSS variable value
     * (#f5a623) into the seo_title field, causing every meta tag, WhatsApp widget
     * name, and <title> to show the hex code instead of the business name.
     *
     * OBSERVABLE OUTPUT: gs_listings.seo_title = '#f5a623' → '' (empty, so the
     *   real listing title fills in as the fallback). Next page load shows "Kaagzaat"
     *   in the WhatsApp widget header, meta title, and all share links.
     */
    public static function clear_hex_seo_titles(): void {
        $cache_key = 'gs_hex_seo_fixed_v1';
        if ( get_transient( $cache_key ) ) return;

        global $wpdb;
        $table = $wpdb->prefix . 'gs_listings';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) ) {
            set_transient( $cache_key, 1, DAY_IN_SECONDS );
            return;
        }

        // Clear seo_title rows that are exactly a hex colour code (#RGB or #RRGGBB)
        $fixed_title = $wpdb->query(
            "UPDATE {$table} SET seo_title = '' WHERE seo_title REGEXP '^#[0-9a-fA-F]{3,6}$'"
        );
        // Same for seo_desc just in case
        $fixed_desc = $wpdb->query(
            "UPDATE {$table} SET seo_desc = '' WHERE seo_desc REGEXP '^#[0-9a-fA-F]{3,6}$'"
        );

        $total = (int)$fixed_title + (int)$fixed_desc;
        if ( $total > 0 && function_exists( 'gs_write_log' ) ) {
            gs_write_log( "clear_hex_seo_titles: cleared {$total} hex-colour seo_title/desc row(s).", 'INFO' );
        }

        // Re-run daily in case new bad data is saved (remove after v7.5 when save-time fix ships)
        set_transient( $cache_key, 1, DAY_IN_SECONDS );
    }

    public static function ensure_migration_columns(): void {
        // Real fix, completing the schema-migration root cause: this used
        // to require manage_options, meaning the actual column-healing
        // logic below only ever ran for admin users — even after
        // check_db_version() was hooked to run on every request, a vendor
        // creating a listing with no admin ever having visited first would
        // still never trigger this. Safe to open up: this only checks/adds
        // database columns, exposes nothing to the visiting user, and is
        // already rate-limited to once per hour via the transient cache
        // below regardless of visitor count.
        $cache_key = 'gs_cols_ok_v' . GS_VERSION;
        if ( get_transient( $cache_key ) ) return;

        global $wpdb;
        $table = $wpdb->prefix . 'gs_listings';
        if ( ! $wpdb->get_var( "SHOW TABLES LIKE '{$table}'" ) ) return;

        $existing = $wpdb->get_col( "SHOW COLUMNS FROM `{$table}`", 0 ) ?: [];

        $critical = [
            'hero_data'              => 'LONGTEXT',
            'about_data'             => 'LONGTEXT',
            'items_data'             => 'LONGTEXT',
            'feedback_data'          => 'LONGTEXT',
            'footer_data'            => 'LONGTEXT',
            'customizer_data'        => 'LONGTEXT',
            'mobile_data'            => 'LONGTEXT',
            'opening_hours'          => 'LONGTEXT',
            'trust_bar_text'         => "VARCHAR(500) DEFAULT ''",
            'gallery_title'          => "VARCHAR(255) DEFAULT ''",
            'services_section_title' => "VARCHAR(255) DEFAULT ''",
            'services_section_desc'  => 'TEXT',
            'process_section_title'  => "VARCHAR(255) DEFAULT ''",
            'brand_color'            => "VARCHAR(20) DEFAULT ''",
            'brand_color2'           => "VARCHAR(20) DEFAULT ''",
            'accent_color'           => "VARCHAR(20) DEFAULT ''",
            'section_bg'             => "VARCHAR(20) DEFAULT ''",
            'text_color'             => "VARCHAR(20) DEFAULT ''",
            'muted_color'            => "VARCHAR(20) DEFAULT ''",
            'logo_border_c'          => "VARCHAR(20) DEFAULT '#E2E8F0'",
            'logo_bg'                => "VARCHAR(20) DEFAULT ''",
            'banner_overlay'         => "VARCHAR(20) DEFAULT '#000000'",
            'logo_radius'            => 'TINYINT DEFAULT 10',
            'logo_shadow'            => "VARCHAR(10) DEFAULT 'none'",
            'logo_border_w'          => 'TINYINT DEFAULT 0',
            'logo_padding'           => 'TINYINT DEFAULT 0',
            'banner_height'          => 'SMALLINT DEFAULT 400',
            'banner_radius'          => 'TINYINT DEFAULT 0',
            'banner_opacity'         => 'TINYINT DEFAULT 0',
            'seo_title'              => "VARCHAR(255) DEFAULT ''",
            'seo_desc'               => 'TEXT',
            'map_embed'              => "VARCHAR(500) DEFAULT ''",
            'address'                => 'TEXT',
        ];

        $added = [];
        foreach ( $critical as $col => $def ) {
            if ( ! in_array( $col, $existing, true ) ) {
                $result = $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN `{$col}` {$def}" );
                if ( $result !== false ) {
                    $added[] = $col;
                } else {
                    if ( function_exists( 'gs_write_log' ) ) {
                        gs_write_log( "ensure_migration_columns: ALTER FAILED for `{$col}`: " . $wpdb->last_error );
                    }
                }
            }
        }

        if ( $added && function_exists( 'gs_write_log' ) ) {
            gs_write_log( 'ensure_migration_columns: auto-added columns: ' . implode( ', ', $added ), 'INFO' );
            // Clear the column warning since we just fixed it
            delete_option( 'gs_missing_cols_warning' );
        }

        // Cache result for 1 hour to avoid running SHOW COLUMNS on every admin page
        set_transient( $cache_key, 1, HOUR_IN_SECONDS );
    }

    /**
     * Create WP placeholder pages on activation so URLs are known to WordPress.
     */
    public static function create_pages(): void {
        $pages = [
            [ 'title' => 'Home',              'slug' => 'gs-home',          'content' => '[gs_home]',    'set_front' => true  ],
            [ 'title' => 'Directory',         'slug' => 'directory',        'content' => '[gs_directory]','set_front' => false ],
            [ 'title' => 'Admin Panel',       'slug' => 'admin-panel',      'content' => '',              'set_front' => false ],
            [ 'title' => 'Vendor Dashboard',  'slug' => 'vendor-dashboard', 'content' => '',              'set_front' => false ],
            [ 'title' => 'Vendor Login',      'slug' => 'vendor-login',     'content' => '',              'set_front' => false ],
            [ 'title' => 'Vendor Register',   'slug' => 'vendor-register',  'content' => '',              'set_front' => false ],
            [ 'title' => 'Create Listing',    'slug' => 'vendor-create',    'content' => '',              'set_front' => false ],
            [ 'title' => 'Manager Login',     'slug' => 'manager-login',    'content' => '',              'set_front' => false ],
            [ 'title' => 'Manager Panel',     'slug' => 'manager-panel',    'content' => '',              'set_front' => false ],
            [ 'title' => 'Staff Login',       'slug' => 'staff-login',      'content' => '',              'set_front' => false ],
            [ 'title' => 'Staff Dashboard',   'slug' => 'staff-dashboard',  'content' => '',              'set_front' => false ],
            [ 'title' => 'Moderation',        'slug' => 'moderation',       'content' => '',              'set_front' => false ],
            [ 'title' => 'Forgot Password',   'slug' => 'forgot-password',  'content' => '',              'set_front' => false ],
            [ 'title' => 'Reset Password',    'slug' => 'reset-password',   'content' => '',              'set_front' => false ],
            [ 'title' => 'Vendor Staff Portal', 'slug' => 'vendor-staff',     'content' => '',              'set_front' => false ],
            [ 'title' => 'My Account',        'slug' => 'my-account',       'content' => '',              'set_front' => false ],
        ];
        foreach ( $pages as $p ) {
            $existing = get_page_by_path( $p['slug'] );
            if ( ! $existing ) {
                $pid = wp_insert_post( [
                    'post_title'   => $p['title'],
                    'post_name'    => $p['slug'],
                    'post_content' => $p['content'],
                    'post_status'  => 'publish',
                    'post_type'    => 'page',
                    'post_author'  => 1,
                ] );
            } else {
                $pid = $existing->ID;
            }
            // Set GoodService Home as the WordPress front page
            if ( ! empty( $p['set_front'] ) && $pid && ! is_wp_error( $pid ) ) {
                update_option( 'show_on_front', 'page' );
                update_option( 'page_on_front', $pid );
            }
        }
    }

    /* ── Custom login URL filter ─────────────────────────────────────────────── */
    public static function gs_custom_login_url( string $login_url, string $redirect, bool $force_reauth ): string {
        $custom = home_url( '/vendor/login/' );
        if ( $redirect ) {
            $custom = add_query_arg( 'redirect_to', urlencode( $redirect ), $custom );
        }
        return $custom;
    }

    /**
     * FIXED — Known Limitations audit: real, explicit last-login tracking.
     * Fires on every successful login for every user (not vendor-specific —
     * cheap single usermeta write, useful anywhere a real last-login is
     * needed later), replacing the session-token-reverse-engineering
     * approximation previously used on the admin Vendor Quality Monitor.
     */
    public static function record_last_login( string $user_login, \WP_User $user ): void {
        update_user_meta( $user->ID, 'gs_last_login', current_time( 'mysql' ) );
    }

    /* ── Redirect wp-login.php requests to custom login page ─────────────────── */
    public static function gs_redirect_wp_login(): void {
        // Allow actual WP admin users (capabilities check) to use wp-login.php normally
        // Allow password reset and logout actions through
        $action = sanitize_key( $_GET['action'] ?? '' );
        $bypass_actions = [ 'logout', 'lostpassword', 'rp', 'resetpass', 'postpass' ];
        if ( in_array( $action, $bypass_actions, true ) ) {
            return;
        }
        // H14 FIX: is_user_logged_in() may return false on login_init because the
        // session cookie is not yet validated at this early hook. Use wp_get_current_user()
        // directly with an explicit ID check which is reliable at this lifecycle point.
        // Also extend bypass to all admin-level roles (administrator + gs_manager),
        // not just 'administrator' — so gs_manager has a fallback login path.
        $user = wp_get_current_user();
        if ( $user && $user->ID > 0 ) {
            $admin_roles = [ 'administrator', 'gs_manager' ];
            if ( ! empty( array_intersect( (array) $user->roles, $admin_roles ) )
                 || user_can( $user, 'manage_options' ) ) {
                return; // allow through to wp-login.php
            }
        }
        // Redirect all other wp-login.php visits to our custom page
        $redirect_to = sanitize_url( $_GET['redirect_to'] ?? '' );
        $dest = home_url( '/vendor/login/' );
        if ( $redirect_to ) {
            $dest = add_query_arg( 'redirect_to', urlencode( $redirect_to ), $dest );
        }
        wp_safe_redirect( $dest, 302 );
        exit;
    }

    /* ── Hide WP admin bar on front-end for non-admins ──────────────────────── */
    public static function gs_hide_admin_bar_frontend( bool $show ): bool {
        if ( ! is_admin() ) {
            $user = wp_get_current_user();
            if ( ! $user || ! in_array( 'administrator', (array) $user->roles, true ) ) {
                return false;
            }
        }
        return $show;
    }

}
