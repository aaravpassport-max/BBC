<?php
namespace GoodService\Router;

use GoodService\Core\Config;
use GoodService\Core\Assets;

final class Router {

    /**
     * Set by intercept_seo_entry_url() immediately before it calls
     * render_listing_unified(), and consumed (and cleared) at the top of
     * that method. Carries the matched gs_seo_microsite_entries row so the
     * existing microsite template can layer keyword-specific title/H1/
     * meta/canonical/intro on top of the SAME listing render — never a
     * separate template or a duplicated content record.
     */
    private static ?object $active_seo_entry = null;

    public static function boot(): void {
        // IndexNow key-file verification — must run as early as possible
        // (priority 0, before rewrite rules and everything else) since it
        // needs to short-circuit the request entirely with a plain-text
        // response the instant the exact key path is hit.
        add_action( 'init', [ \GoodService\Service\IndexNowService::class, 'maybe_serve_key_file' ], 0 );
        add_action( 'init',              [ self::class, 'register_rewrites' ] );
        add_filter( 'query_vars',        [ self::class, 'add_query_vars'   ] );
        add_filter( 'robots_txt',        [ self::class, 'add_sitemap_to_robots' ], 10, 2 );
        add_action( 'template_redirect', [ self::class, 'dispatch'          ], 1 );
        add_action( 'template_redirect', [ self::class, 'intercept_homepage'], 2 );
        // Intercept WP-page-routed GS pages (e.g. /directory/ served via WP page not rewrite rule)
        add_action( 'template_redirect', [ self::class, 'intercept_gs_wp_pages'    ], 1 );
        // Bulletproof last-resort bypass: if a GS page somehow reaches template_include, return blank template
        add_filter( 'template_include',  [ self::class, 'bypass_theme_template'    ], PHP_INT_MAX );
        // Intercept vendor paths (edit, dashboard) without needing flush
        add_action( 'template_redirect', [ self::class, 'intercept_vendor_paths'   ], 0 );
        // Intercept /{microsite-slug}/{seo-keyword-slug}/ — dynamic SEO Search
        // Entry URLs. Must run before intercept_404_for_listing (single-segment
        // only, so no overlap) and needs no rewrite-rule changes at all, the
        // same pattern already used by intercept_vendor_paths/intercept_404_for_listing.
        add_action( 'template_redirect', [ self::class, 'intercept_seo_entry_url'  ], 0 );
        // Intercept 404s — check if the URL path matches a listing slug in DB
        add_action( 'template_redirect', [ self::class, 'intercept_404_for_listing' ], 0 );
        \GoodService\Controller\ShortcodeController::register();
    }

    public static function register_rewrites(): void {
        // ── Platform-reserved paths (most specific — MUST come first) ──────────────

        // Vendor one-page microsite (legacy /v/ and /vendor/site/ routes)
        add_rewrite_rule( '^v/([^/]+)/?$',           'index.php?gs_page=vendor_site&gs_vendor_slug=$matches[1]', 'top' );
        add_rewrite_rule( '^vendor/site/([^/]+)/?$', 'index.php?gs_page=vendor_site&gs_vendor_slug=$matches[1]', 'top' );

        // Legacy /listing/{slug} still works
        add_rewrite_rule( '^listing/([^/]+)/?$', 'index.php?gs_page=listing&gs_slug=$matches[1]', 'top' );

        // Directory
        add_rewrite_rule( '^directory/?$',           'index.php?gs_page=archive',                                 'top' );
        add_rewrite_rule( '^directory/([^/]+)/?$',   'index.php?gs_page=archive&gs_category=$matches[1]',         'top' );

        // Admin panel
        add_rewrite_rule( '^admin-panel/?$',         'index.php?gs_page=admin_dashboard',                         'top' );
        add_rewrite_rule( '^admin-panel/([^/]+)/?$', 'index.php?gs_page=admin_dashboard&gs_section=$matches[1]',  'top' );

        // Vendor dashboard & auth
        add_rewrite_rule( '^vendor/dashboard/?$',        'index.php?gs_page=vendor_dashboard',                        'top' );
        add_rewrite_rule( '^vendor/login/?$',            'index.php?gs_page=login',                                   'top' );
        add_rewrite_rule( '^vendor/register/?$',         'index.php?gs_page=register',                                'top' );
        add_rewrite_rule( '^vendor/create/?$',           'index.php?gs_page=create_listing',                          'top' );
        add_rewrite_rule( '^vendor/edit/([0-9]+)/?$',    'index.php?gs_page=create_listing&gs_listing_id=$matches[1]','top' );
        add_rewrite_rule( '^vendor/profile/([^/]+)/?$',  'index.php?gs_page=vendor_profile&gs_vendor_slug=$matches[1]','top' );

        // Other dashboards
        add_rewrite_rule( '^manager-panel/?$',       'index.php?gs_page=manager_dashboard',                       'top' );
        add_rewrite_rule( '^moderation/?$',          'index.php?gs_page=moderation_dashboard',                    'top' );
        add_rewrite_rule( '^my-account/?$',          'index.php?gs_page=visitor_dashboard',                       'top' );
        add_rewrite_rule( '^requirement/([0-9]+)/?$','index.php?gs_page=requirement&gs_requirement_id=$matches[1]','top' );
        add_rewrite_rule( '^gs-sitemap\\.xml$',       'index.php?gs_page=sitemap',                                  'top' );
        add_rewrite_rule( '^gs-sitemap-core\\.xml$',  'index.php?gs_page=sitemap_core',                             'top' );
        add_rewrite_rule( '^gs-sitemap-listings-([0-9]+)\\.xml$', 'index.php?gs_page=sitemap_listings&gs_sitemap_page=$matches[1]', 'top' );
        // SEO Search Entry URL sitemap — only approved, indexable,
        // sitemap_enabled entries ever appear here (Part 23).
        add_rewrite_rule( '^gs-sitemap-seo-entries-([0-9]+)\\.xml$', 'index.php?gs_page=sitemap_seo_entries&gs_sitemap_page=$matches[1]', 'top' );
        // Real feature, priority 4 (IndexNow): the protocol requires a key
        // file matching the key itself to be served at the site root as
        // proof of domain ownership before Bing/Yandex accept pings using it.
        add_rewrite_rule( '^([a-f0-9]{32})\.txt$', 'index.php?gs_page=indexnow_key&gs_indexnow_key=$matches[1]', 'top' );
        add_rewrite_rule( '^llms\\.txt$',            'index.php?gs_page=llms_txt',                                 'top' );
        // Real fix — confirmed via PageSpeed's "Agent Accessibility" audit:
        // it checks for an llms.txt scoped to the CURRENT page's own path
        // (e.g. /{listing-slug}/llms.txt), not only the site root — every
        // vendor listing page was 404ing here and failing the audit even
        // though the root /llms.txt file itself is correct. Reuses the
        // exact same slug pattern as the listing catch-all below so this
        // never drifts out of sync with what counts as a real listing slug.
        add_rewrite_rule( '^([a-zA-Z0-9][a-zA-Z0-9\-]{1,98}[a-zA-Z0-9])/llms\\.txt$', 'index.php?gs_page=llms_txt&gs_slug=$matches[1]', 'top' );
        // Real fix, the actual root cause of the PWA install prompt never
        // becoming available: these two manifest files had no rewrite rule
        // at all — the <link rel="manifest"> tag referenced a URL that was
        // genuinely unreachable, regardless of the icon-path fix inside the
        // files themselves. Matches the exact same pattern as gs-sitemap.xml
        // above.
        add_rewrite_rule( '^goodservice-client\\.webmanifest$', 'index.php?gs_page=webmanifest_client', 'top' );
        add_rewrite_rule( '^goodservice-vendor\\.webmanifest$', 'index.php?gs_page=webmanifest_vendor', 'top' );
        add_rewrite_rule( '^service/([^/]+)/([^/]+)/?$', 'index.php?gs_page=seo_location&gs_cat_slug=$matches[1]&gs_city_slug=$matches[2]', 'top' );
        // Static platform content pages — confirmed real gap: footer links
        // pointed nowhere despite a fully working admin Pages editor and
        // database table already existing for exactly this purpose.
        foreach ( [ 'about-us', 'contact-us', 'blog', 'privacy-policy', 'terms-of-service', 'cookie-policy', 'refund-policy', 'disclaimer', 'sitemap' ] as $gs_static_slug ) {
            add_rewrite_rule( "^{$gs_static_slug}/?\$", "index.php?gs_page=platform_page&gs_page_slug={$gs_static_slug}", 'top' );
        }

        // ── Dedicated login pages for each role ───────────────────────────────
        // Real fix — confirmed gap: no /admin/login/ route existed at all,
        // despite dashboard_url()/gs_login_redirect()/finalize_login_response()
        // already correctly handling administrator authentication and
        // redirecting to /admin-panel/ — an admin simply had no discoverable,
        // dedicated URL that said so. Routes into the same, already-correct
        // universal login flow rather than duplicating the login form and
        // its redirect logic a fourth time.
        add_rewrite_rule( '^admin/login/?$',         'index.php?gs_page=admin_login',                             'top' );
        add_rewrite_rule( '^manager/login/?$',       'index.php?gs_page=manager_login',                           'top' );
        add_rewrite_rule( '^staff/login/?$',         'index.php?gs_page=staff_login',                             'top' );
        add_rewrite_rule( '^staff/dashboard/?$',     'index.php?gs_page=staff_dashboard',                         'top' );
        add_rewrite_rule( '^vendor/staff/?$',        'index.php?gs_page=vendor_staff_dashboard',                  'top' );

        // ── Password management pages ─────────────────────────────────────────
        add_rewrite_rule( '^advertise/?$',           'index.php?gs_page=advertise_with_us',                       'top' );
        add_rewrite_rule( '^how-it-works/?$',        'index.php?gs_page=how_it_works',                            'top' );
        add_rewrite_rule( '^trust-safety/?$',        'index.php?gs_page=trust_safety',                            'top' );
        add_rewrite_rule( '^about-us/?$',            'index.php?gs_page=about_us',                                'top' );
        add_rewrite_rule( '^contact-us/?$',          'index.php?gs_page=contact_us',                              'top' );
        add_rewrite_rule( '^forgot-password/?$',     'index.php?gs_page=forgot_password',                         'top' );
        add_rewrite_rule( '^reset-password/?$',      'index.php?gs_page=reset_password',                          'top' );

        // ── Short-form convenience URLs (used in site header nav links) ───────
        // /login/           → vendor/all-roles login page (same as /vendor/login/)
        // /create-listing/  → create listing page (same as /vendor/create/)
        add_rewrite_rule( '^login/?$',           'index.php?gs_page=login',          'top' );
        add_rewrite_rule( '^create-listing/?$',  'index.php?gs_page=create_listing', 'top' );
        add_rewrite_rule( '^install-app/?$',    'index.php?gs_page=install_app',    'top' );

        // ── Phase 1: Bookable Inquiry Modules — public job-tracking link ───────
        // /track-job/{token}/ → job-track.php (renders the live booking stepper).
        // Token is the gs_bookings.tracking_token (random 32-char string, acts
        // as the access credential — no login required, matches gs_track_job_status
        // AJAX action's public/token-based access pattern).
        add_rewrite_rule( '^track-job/([^/]+)/?$', 'index.php?gs_page=job-track&gs_track_token=$matches[1]', 'top' );

        // ── CLEAN URL: /{listing-slug} — bottom priority catch-all ───────────────
        // Enables abc.com/my-listing-name instead of abc.com/listing/my-listing-name
        // Only serves a page if the slug matches a real listing in the DB.
        // Regex accepts both lowercase and uppercase so manually-entered slugs with
        // mixed case (e.g. glow-beauty-studio-services-ponQ) still resolve correctly.
        // The slug is lowercased in the DB query to normalise the lookup.
        add_rewrite_rule(
            '^([a-zA-Z0-9][a-zA-Z0-9\-]{1,98}[a-zA-Z0-9])/?$',
            'index.php?gs_page=listing_slug_lookup&gs_slug=$matches[1]',
            'bottom'
        );
    }

    public static function add_query_vars( array $vars ): array {
        return array_merge( $vars, [
            'gs_page', 'gs_slug', 'gs_vendor_slug', 'gs_home',
            'gs_requirement_id', 'gs_listing_id', 'gs_category', 'gs_section',
            'gs_key', 'gs_login', 'gs_track_token', 'gs_sitemap_page',
            'gs_cat_slug', 'gs_city_slug', 'gs_page_slug', 'gs_indexnow_key',
        ] );
    }

    /**
     * Appends the sitemap index location to robots.txt — confirmed via
     * research this is the standard, correct WordPress mechanism
     * (robots_txt filter), and that appending rather than overwriting
     * $output is the correct approach since other active plugins or
     * WordPress core itself may have already added real content there.
     * If the site owner has disabled search engine visibility (Settings >
     * Reading), $public is falsy and this correctly skips adding the
     * line — no point announcing a sitemap on a site that's telling every
     * crawler to stay away entirely.
     */
    public static function add_sitemap_to_robots( string $output, $public ): string {
        if ( ! $public ) { return $output; }
        $output = rtrim( $output ) . "\n\nSitemap: " . home_url( '/gs-sitemap.xml' ) . "\n";
        // Real feature, item E from the follow-up audit: admin-facing
        // custom Disallow rules — appended to the same output this
        // function already builds, only when at least one rule is
        // actually configured.
        $_custom_rules = trim( (string) \GoodService\Core\Config::get( 'seo_robots_disallow', '' ) );
        if ( $_custom_rules ) {
            $output .= "\n";
            foreach ( preg_split( '/[\r\n]+/', $_custom_rules ) as $_rule ) {
                $_rule = trim( $_rule );
                if ( $_rule && str_starts_with( $_rule, '/' ) ) {
                    $output .= "Disallow: {$_rule}\n";
                }
            }
        }
        return $output;
    }

    public static function dispatch(): void {
        $gs_page = get_query_var( 'gs_page' );
        if ( ! $gs_page ) { return; }

        if ( $gs_page === 'sitemap' ) {
            \GoodService\Controller\SitemapController::render();
            exit;
        }
        if ( $gs_page === 'sitemap_core' ) {
            \GoodService\Controller\SitemapController::render_core();
            exit;
        }
        if ( $gs_page === 'sitemap_listings' ) {
            \GoodService\Controller\SitemapController::render_listings_page( (int) get_query_var( 'gs_sitemap_page', 1 ) );
            exit;
        }
        if ( $gs_page === 'sitemap_seo_entries' ) {
            \GoodService\Controller\SitemapController::render_seo_entries_page( (int) get_query_var( 'gs_sitemap_page', 1 ) );
            exit;
        }
        if ( $gs_page === 'llms_txt' ) {
            $_llms_slug = sanitize_title( (string) get_query_var( 'gs_slug', '' ) );
            if ( $_llms_slug !== '' ) {
                \GoodService\Controller\SitemapController::render_llms_txt_for_listing( $_llms_slug );
            } else {
                \GoodService\Controller\SitemapController::render_llms_txt();
            }
            exit;
        }
        // Real feature, priority 4 (IndexNow): serves the key file only
        // when the requested key genuinely matches the site's own stored
        // key — never serves an arbitrary .txt file just because the
        // rewrite rule's regex matched.
        if ( $gs_page === 'indexnow_key' ) {
            $_requested_key = sanitize_text_field( get_query_var( 'gs_indexnow_key', '' ) );
            $_real_key = \GoodService\Core\Config::get( 'indexnow_key', '' );
            if ( $_real_key && hash_equals( $_real_key, $_requested_key ) ) {
                header( 'Content-Type: text/plain' );
                echo $_real_key;
            } else {
                status_header( 404 );
            }
            exit;
        }
        // Real fix: the actual file-serving handlers for the manifest
        // rewrite rules above — without these, the rules would match the
        // URL but nothing would render, still resulting in an empty/404
        // response. application/manifest+json is required for browsers to
        // recognize and validate a web app manifest; serving it without
        // this exact Content-Type can cause Chrome to silently ignore it.
        if ( $gs_page === 'webmanifest_client' || $gs_page === 'webmanifest_vendor' ) {
            $type     = $gs_page === 'webmanifest_client' ? 'client' : 'vendor';
            $manifest = gs_pwa_manifest_payload( $type );
            if ( ! $manifest ) {
                status_header( 404 );
                exit;
            }
            if ( ! headers_sent() ) {
                header( 'Content-Type: application/manifest+json; charset=UTF-8' );
                header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
                header( 'Pragma: no-cache' );
            }
            while ( ob_get_level() > 0 ) { ob_end_clean(); }
            echo wp_json_encode( $manifest, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
            exit;
        }

        // Vendor one-page microsite — special rendering (no platform header/footer)
        if ( $gs_page === 'vendor_site' ) {
            status_header( 200 );
            self::render_vendor_site();
            exit;
        }

        // /listing/{slug} — legacy path: 301-redirect to canonical clean URL /{slug}/
        // This ensures only ONE URL exists for each listing (the clean /{slug}/ form).
        if ( $gs_page === 'listing' ) {
            $slug = sanitize_text_field( get_query_var( 'gs_slug', '' ) );
            if ( $slug ) {
                wp_redirect( home_url( '/' . $slug . '/' ), 301 );
            } else {
                wp_redirect( home_url( '/directory/' ), 301 );
            }
            exit;
        }

        // Clean URL /{slug} lookup — check if slug matches a listing in DB
        if ( $gs_page === 'listing_slug_lookup' ) {
            global $wpdb;
            $slug = sanitize_text_field( get_query_var( 'gs_slug', '' ) );
            if ( $slug ) {
                // Normalise to lowercase — slugs should always be lowercase.
                // If the URL has mixed case (e.g. ponQ), we match case-insensitively
                // in the DB and then 301-redirect to the canonical lowercase URL.
                $slug_lower = strtolower( $slug );

                // Primary: exact match (covers correctly stored lowercase slugs)
                $row = $wpdb->get_row( $wpdb->prepare(
                    "SELECT id, slug FROM {$wpdb->prefix}gs_listings WHERE slug = %s AND status IN('active','pending','draft') LIMIT 1",
                    $slug_lower
                ) );

                // Fallback: case-insensitive match (covers uppercase legacy slugs)
                if ( ! $row && $slug !== $slug_lower ) {
                    $row = $wpdb->get_row( $wpdb->prepare(
                        "SELECT id, slug FROM {$wpdb->prefix}gs_listings WHERE LOWER(slug) = %s AND status IN('active','pending','draft') LIMIT 1",
                        $slug_lower
                    ) );
                }

                if ( $row ) {
                    // If URL slug has uppercase, 301-redirect to canonical lowercase URL
                    if ( $slug !== $row->slug ) {
                        wp_redirect( home_url( '/' . $row->slug . '/' ), 301 );
                        exit;
                    }
                    // Real bug fix: this was missing entirely. render_listing_unified()
                    // reads the slug exclusively via get_query_var('gs_slug', '') and
                    // redirects to /directory/ immediately if it's empty — which is
                    // exactly what happened every time a request was handled by this
                    // specific code path instead of the other caller of the same
                    // function (which already set this correctly).
                    set_query_var( 'gs_slug', $row->slug );
                    status_header( 200 );
                    self::render_listing_unified();
                    exit;
                }
            }
            // Not a listing — fall through to WordPress (404 or WP page)
            return;
        }

        $map = [
            'archive'              => [ \GoodService\Controller\ArchiveController::class,     'index'      ],
            'admin_dashboard'      => [ \GoodService\Controller\AdminController::class,       'dashboard'  ],
            'vendor_dashboard'     => [ \GoodService\Controller\VendorController::class,      'dashboard'  ],
            'manager_dashboard'    => [ \GoodService\Controller\ManagerController::class,     'dashboard'  ],
            'moderation_dashboard' => [ \GoodService\Controller\ModerationController::class,  'dashboard'  ],
            'visitor_dashboard'    => [ \GoodService\Controller\VisitorController::class,     'dashboard'  ],
            'staff_dashboard'          => [ \GoodService\Controller\AuthController::class,        'staff_dashboard' ],
            'vendor_staff_dashboard'   => [ \GoodService\Controller\AuthController::class,        'vendor_staff_dashboard' ],
            'vendor_profile'       => [ \GoodService\Controller\VendorController::class,      'public_profile' ],
            'create_listing'       => [ \GoodService\Controller\ListingController::class,     'create'     ],
            'login'                => [ \GoodService\Controller\AuthController::class,        'login'      ],
            'register'             => [ \GoodService\Controller\AuthController::class,        'register'   ],
            'admin_login'          => [ \GoodService\Controller\AuthController::class,        'admin_login' ],
            'manager_login'        => [ \GoodService\Controller\AuthController::class,        'manager_login' ],
            'staff_login'          => [ \GoodService\Controller\AuthController::class,        'staff_login' ],
            'advertise_with_us'    => [ \GoodService\Controller\AuthController::class,        'advertise_with_us' ],
            'how_it_works'          => [ \GoodService\Controller\AuthController::class,        'how_it_works' ],
            'trust_safety'          => [ \GoodService\Controller\AuthController::class,        'trust_safety' ],
            'about_us'              => [ \GoodService\Controller\AuthController::class,        'about_us' ],
            'contact_us'            => [ \GoodService\Controller\AuthController::class,        'contact_us' ],
            'forgot_password'      => [ \GoodService\Controller\AuthController::class,        'forgot_password' ],
            'reset_password'       => [ \GoodService\Controller\AuthController::class,        'reset_password' ],
            'requirement'          => [ \GoodService\Controller\RequirementController::class, 'show'       ],
            'customer_dashboard'   => [ \GoodService\Controller\VisitorController::class,     'dashboard'  ],
        ];

        // My Home Dashboard (Moat 5)
        if ( $gs_page === 'my_home' ) {
            status_header( 200 );
            self::render_page( 'my-home', null );
            exit;
        }
        // RWA Dashboard (Moat 3)
        if ( $gs_page === 'rwa_dashboard' ) {
            status_header( 200 );
            self::render_page( 'rwa-dashboard', null );
            exit;
        }
        // Handle SEO location pages (Part 26.1)
        if ( $gs_page === 'seo_location' ) {
            status_header( 200 );
            $cat      = sanitize_key( get_query_var( 'gs_cat_slug', '' ) );
            $city_slug = sanitize_title( get_query_var( 'gs_city_slug', '' ) );

            // The URL contains a slug (e.g. 'new-delhi') but the DB stores the
            // original city name (e.g. 'New Delhi'). Resolve via seo_location_pages
            // which stores both; fall back to ucwords slug conversion.
            global $wpdb;
            $seo_loc_tbl = $wpdb->prefix . 'gs_seo_location_pages';
            $real_city   = null;
            if ( $wpdb->get_var( "SHOW TABLES LIKE '{$seo_loc_tbl}'" ) ) {
                $real_city = $wpdb->get_var( $wpdb->prepare(
                    "SELECT city FROM {$seo_loc_tbl} WHERE category_slug = %s AND page_url LIKE %s LIMIT 1",
                    $cat, '%/' . $wpdb->esc_like( $city_slug ) . '/%'
                ) );
            }
            // If not found in the table yet, convert slug back to readable form
            if ( ! $real_city ) {
                $real_city = ucwords( str_replace( '-', ' ', $city_slug ) );
            }

            self::render_page( 'seo-location', null, [ 'category_slug' => $cat, 'city' => $real_city, 'city_slug' => $city_slug ] );
            exit;
        }
        // Static platform pages (About, Contact, Privacy, etc.) — confirmed
        // real gap: gs_pages table and its admin editor already existed
        // and worked correctly; nothing ever served a real page from it.
        if ( $gs_page === 'install_app' ) {
            status_header( 200 );
            nocache_headers();
            self::render_install_app();
            exit;
        }
        if ( $gs_page === 'platform_page' ) {
            status_header( 200 );
            $page_slug = sanitize_title( get_query_var( 'gs_page_slug', '' ) );
            self::render_page( 'platform-page', null, [ 'gs_static_slug' => $page_slug ] );
            exit;
        }
        // Handle quote-accept page (token-based, no controller needed)
        if ( $gs_page === 'quote-accept' ) {
            status_header( 200 );
            $token = sanitize_text_field( get_query_var( 'gs_quote_token', '' ) );
            self::render_page( 'quote-accept', null, [ 'token' => $token ] );
            exit;
        }
        // Handle job-track page
        if ( $gs_page === 'job-track' ) {
            status_header( 200 );
            $token = sanitize_text_field( get_query_var( 'gs_track_token', '' ) );
            self::render_page( 'job-track', null, [ 'token' => $token ] );
            exit;
        }

        [ $class, $method ] = $map[ $gs_page ] ?? [ null, null ];
        if ( ! $class || ! method_exists( $class, $method ) ) { return; }

        status_header( 200 );
        // Directory must never be served from cache — results change as listings are added.
        if ( $gs_page === 'archive' ) {
            nocache_headers();
        }
        self::render_page( $gs_page, [ new $class(), $method ] );
        exit;
    }

    // ── Intercept /vendor/edit/{id} and other vendor paths without needing flush_rewrite_rules ──
    public static function intercept_vendor_paths(): void {
        if ( is_admin() ) return;
        $gs_page = get_query_var( 'gs_page' );
        if ( $gs_page ) return; // already handled

        $request = trim( parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ) ?? '', '/' );
        $home_path = trim( parse_url( home_url(), PHP_URL_PATH ) ?? '', '/' );
        if ( $home_path && str_starts_with( $request, $home_path ) ) {
            $request = trim( substr( $request, strlen( $home_path ) ), '/' );
        }
        if ( ! $request ) return;

        // Match /vendor/edit/{id}
        // MUST use render_page() — create-listing.php has no HTML skeleton and relies
        // on render_page() to supply <!DOCTYPE html>, <head>, CSS link, and JS link.
        // Calling ListingController::create() directly here bypassed render_page()
        // and served a raw, unstyled template → white/broken screen.
        if ( preg_match( '#^vendor/edit/([0-9]+)/?$#', $request, $m ) ) {
            set_query_var( 'gs_page', 'create_listing' );
            set_query_var( 'gs_listing_id', $m[1] );
            status_header( 200 );
            self::render_page( 'create_listing', [ new \GoodService\Controller\ListingController(), 'create' ] );
            exit;
        }

        // Match /vendor/create
        if ( preg_match( '#^vendor/create/?$#', $request ) ) {
            set_query_var( 'gs_page', 'create_listing' );
            status_header( 200 );
            self::render_page( 'create_listing', [ new \GoodService\Controller\ListingController(), 'create' ] );
            exit;
        }

        // Match /vendor/dashboard
        if ( preg_match( '#^vendor/dashboard/?#', $request ) ) {
            set_query_var( 'gs_page', 'vendor_dashboard' );
            status_header( 200 );
            self::render_page( 'vendor_dashboard', [ new \GoodService\Controller\VendorController(), 'dashboard' ] );
            exit;
        }

        // Match /admin-panel
        if ( preg_match( '#^admin-panel/?#', $request ) ) {
            set_query_var( 'gs_page', 'admin_dashboard' );
            status_header( 200 );
            self::render_page( 'admin_dashboard', [ new \GoodService\Controller\AdminController(), 'dashboard' ] );
            exit;
        }

        // Match /my-account — real fix: gives the customer dashboard the same
        // explicit fast-path treatment vendor/admin already had, removing the
        // architectural asymmetry that meant this route never went through
        // render_page() at all. Using 'customer_dashboard' as the page-type
        // (not 'visitor_dashboard') also fixes a separate pre-existing bug:
        // the PWA manifest/Apple-meta-tag logic below checks specifically for
        // 'customer_dashboard', a string the old generic dispatch path for
        // this route never actually produced — so the customer dashboard was
        // never receiving its PWA manifest at all, independent of caching.
        if ( preg_match( '#^my-account/?#', $request ) ) {
            set_query_var( 'gs_page', 'customer_dashboard' );
            status_header( 200 );
            self::render_page( 'customer_dashboard', [ new \GoodService\Controller\VisitorController(), 'dashboard' ] );
            exit;
        }
    }

    // ── Intercept /{microsite-slug}/{seo-keyword-slug}/ — SEO Search Entry URLs ──
    //
    // Deliberately implemented as an early template_redirect interceptor
    // (identical pattern to intercept_vendor_paths / intercept_404_for_listing
    // above) rather than a new add_rewrite_rule(), so it needs no rewrite
    // flush and — critically — cannot collide with or reorder any existing
    // rewrite rule (Part 34, route collision protection). It only ever acts
    // on a genuine two-segment path once every reserved first segment and
    // every existing single/']multi-segment GS route has already had a
    // chance to claim the request; if nothing matches a real, approved SEO
    // entry it falls straight through, unchanged, to the existing
    // intercept_404_for_listing() / WordPress 404 behavior below.
    public static function intercept_seo_entry_url(): void {
        if ( is_admin() ) return;
        if ( get_query_var( 'gs_page' ) ) return; // already handled

        $request = trim( parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ) ?? '', '/' );
        $home_path = trim( parse_url( home_url(), PHP_URL_PATH ) ?? '', '/' );
        if ( $home_path && str_starts_with( $request, $home_path ) ) {
            $request = trim( substr( $request, strlen( $home_path ) ), '/' );
        }
        if ( ! $request ) return;

        // Must be EXACTLY two path segments — anything with more segments
        // (e.g. admin-panel/settings/foo) is not this feature's concern.
        if ( ! preg_match(
            '#^([a-zA-Z0-9][a-zA-Z0-9\-]{0,98}[a-zA-Z0-9])/([a-zA-Z0-9][a-zA-Z0-9\-]{0,98}[a-zA-Z0-9])/?$#',
            $request, $m
        ) ) return;

        $listing_slug = strtolower( $m[1] );
        $entry_slug   = strtolower( $m[2] );

        // Route collision protection (Part 34) — every existing first-segment
        // that already owns a two-segment (or deeper) route must be excluded
        // here so a vendor's SEO keyword can never shadow admin/system/vendor/
        // service routes. Mirrors the rewrite rules registered above.
        $reserved_first_segments = [
            'v', 'vendor', 'listing', 'directory', 'admin-panel', 'manager-panel',
            'moderation', 'my-account', 'requirement', 'admin', 'manager', 'staff',
            'track-job', 'service', 'wp-admin', 'wp-login', 'wp-content', 'wp-includes',
            'gs-sitemap', 'gs-sitemap-core', 'about-us', 'contact-us', 'blog',
            'privacy-policy', 'terms-of-service', 'cookie-policy', 'refund-policy',
            'disclaimer', 'sitemap', 'advertise', 'how-it-works', 'trust-safety',
            'forgot-password', 'reset-password', 'login', 'create-listing',
        ];
        if ( in_array( $listing_slug, $reserved_first_segments, true ) ) return;

        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        $listing = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, slug, vendor_id, status FROM {$pfx}listings WHERE slug = %s AND status IN('active','pending','draft') LIMIT 1",
            $listing_slug
        ) );
        if ( ! $listing ) return; // first segment isn't a microsite at all — let other routing continue

        // Confirm the SEO keyword slug genuinely belongs to THIS microsite and
        // is an approved, indexable entry (Part 33, 40 — cross-vendor URL
        // mapping is impossible by construction: the lookup is scoped to
        // this exact listing_id, never a global keyword_slug lookup).
        $entry = \GoodService\SEO\SeoEntryService::get_indexable_entry( (int) $listing->id, $entry_slug );
        if ( ! $entry ) return; // not a valid/approved SEO entry — fall through to normal 404 handling

        // Draft listings stay owner/admin-only, same rule as the primary URL.
        if ( $listing->status === 'draft' ) {
            if ( ! is_user_logged_in() ) { wp_redirect( home_url( '/vendor/login/' ) ); exit; }
            $owner_uid = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT vp.user_id FROM {$pfx}vendor_profiles vp WHERE vp.id = %d LIMIT 1", $listing->vendor_id
            ) );
            if ( $owner_uid !== get_current_user_id() && ! current_user_can( 'manage_options' ) ) {
                wp_redirect( home_url( '/directory/' ) ); exit;
            }
        }

        set_query_var( 'gs_slug', $listing->slug );
        self::$active_seo_entry = $entry;
        status_header( 200 ); // Part 7 — a valid SEO entry URL is a real 200, never a redirect
        try {
            self::render_listing_unified();
        } catch ( \Throwable $e ) {
            self::$active_seo_entry = null;
            error_log( '[GoodService] intercept_seo_entry_url render error: ' . $e->getMessage() );
            if ( current_user_can( 'manage_options' ) ) {
                echo '<div style="margin:40px;padding:20px;background:#FEF2F2;border:2px solid #DC2626;border-radius:10px;font-family:monospace;max-width:900px">'
                   . '<h3 style="color:#DC2626;margin:0 0 10px;font-family:sans-serif">🚨 SEO Entry Render Error</h3>'
                   . '<p>' . esc_html( $e->getMessage() ) . '</p></div>';
            } else {
                echo '<div style="padding:60px;text-align:center;font-family:sans-serif"><h2>Page could not be loaded</h2><p>Please try again or contact support.</p></div>';
            }
        }
        exit;
    }

    // ── Intercept 404s that are actually listing clean URLs ──────────────────────
    public static function intercept_404_for_listing(): void {
        if ( is_admin() ) return;

        // Only act on what WordPress thinks is a 404 OR a plain path with no gs_page yet
        $gs_page = get_query_var( 'gs_page' );
        if ( $gs_page ) return; // already handled by dispatch()

        // Get the raw request path
        $request = trim( parse_url( $_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH ) ?? '', '/' );
        // Strip any subdirectory prefix (when WP is in a subfolder)
        $home_path = trim( parse_url( home_url(), PHP_URL_PATH ) ?? '', '/' );
        if ( $home_path && str_starts_with( $request, $home_path ) ) {
            $request = trim( substr( $request, strlen( $home_path ) ), '/' );
        }

        if ( ! $request ) return;
        // Must look like a slug: letters (any case), numbers, hyphens
        // Accept uppercase too — we normalise to lowercase before the DB lookup
        if ( ! preg_match( '/^[a-zA-Z0-9][a-zA-Z0-9\-]{0,97}[a-zA-Z0-9]$/', $request ) ) return;

        // Real fix: this reserved-paths check now runs BEFORE the redirect
        // lookup below — a redirect accidentally or maliciously created for
        // one of these paths (e.g. "directory") could otherwise fire and
        // silently break that entire section of the platform, bypassing
        // protection that exists everywhere else in the system.
        $reserved = [ 'wp-admin','wp-login','wp-content','wp-includes','admin-panel',
                      'vendor','directory','v','listing','manager-panel','moderation',
                      'my-account','requirement','gs-sitemap' ];
        $first_segment = explode( '/', $request )[0];
        if ( in_array( $first_segment, $reserved, true ) ) return;

        // Real feature: custom redirect management — checked before the
        // listing-slug interception below so a manually-configured
        // redirect takes priority. Only queries when the request already
        // looks like a plausible path (the same validation already used
        // for listing slugs above), and only writes to the hit-count
        // columns on an actual match, not on every single request.
        global $wpdb;
        $pfx = $wpdb->prefix . 'gs_';
        $redirect_row = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, dest_url, status_code FROM {$pfx}redirects WHERE source_path = %s AND is_active = 1 LIMIT 1",
            strtolower( $request )
        ) );
        if ( $redirect_row ) {
            $wpdb->query( $wpdb->prepare(
                "UPDATE {$pfx}redirects SET hit_count = hit_count + 1, last_hit_at = NOW() WHERE id = %d",
                $redirect_row->id
            ) );
            wp_redirect( $redirect_row->dest_url, (int) $redirect_row->status_code );
            exit;
        }

        global $wpdb;
        $slug_lower = strtolower( $request );

        // Primary: lowercase match
        $listing = $wpdb->get_row( $wpdb->prepare(
            "SELECT id, slug, status, vendor_id FROM {$wpdb->prefix}gs_listings
             WHERE slug = %s AND status IN('active','pending','draft') LIMIT 1",
            $slug_lower
        ) );

        // Fallback: LOWER() match for legacy uppercase slugs in the DB
        if ( ! $listing ) {
            $listing = $wpdb->get_row( $wpdb->prepare(
                "SELECT id, slug, status, vendor_id FROM {$wpdb->prefix}gs_listings
                 WHERE LOWER(slug) = %s AND status IN('active','pending','draft') LIMIT 1",
                $slug_lower
            ) );
        }

        if ( ! $listing ) return;

        // If incoming URL has uppercase, 301-redirect to canonical lowercase slug
        if ( $request !== $listing->slug ) {
            wp_redirect( home_url( '/' . $listing->slug . '/' ), 301 );
            exit;
        }

        // Draft: only owner or admin can see
        if ( $listing->status === 'draft' ) {
            if ( ! is_user_logged_in() ) { wp_redirect( home_url( '/vendor/login/' ) ); exit; }
            // Check ownership via vendor_profiles
            $owner_uid = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT vp.user_id FROM {$wpdb->prefix}gs_vendor_profiles vp
                 WHERE vp.id = %d LIMIT 1", $listing->vendor_id
            ) );
            if ( $owner_uid !== get_current_user_id() && ! current_user_can( 'manage_options' ) ) {
                wp_redirect( home_url( '/directory/' ) ); exit;
            }
        }

        // It IS a listing — render directly (do NOT set gs_page='listing' because dispatch()
        // intercepts that value and fires a 301 redirect before render_listing_unified runs).
        set_query_var( 'gs_slug', $listing->slug );
        status_header( 200 );
        try {
            self::render_listing_unified();
        } catch ( \Throwable $e ) {
            error_log( '[GoodService] intercept_404 render error: ' . $e->getMessage() );
            if ( current_user_can( 'manage_options' ) ) {
                echo '<div style="margin:40px;padding:20px;background:#FEF2F2;border:2px solid #DC2626;border-radius:10px;font-family:monospace;max-width:900px">'
                   . '<h3 style="color:#DC2626;margin:0 0 10px;font-family:sans-serif">🚨 Listing Render Error</h3>'
                   . '<p>' . esc_html( $e->getMessage() ) . '</p>'
                   . '<pre style="font-size:.72rem;color:#334155;background:#F8FAFC;padding:12px;border-radius:6px;overflow:auto;max-height:300px">' . esc_html( $e->getTraceAsString() ) . '</pre>'
                   . '</div>';
            } else {
                echo '<div style="padding:60px;text-align:center;font-family:sans-serif"><h2>Page could not be loaded</h2><p>Please try again or contact support.</p></div>';
            }
        }
        exit;
    }

    // ── Intercept homepage before WP theme renders it ──────────────────────────
    public static function intercept_homepage(): void {
        if ( is_admin() ) return;
        if ( ! ( is_front_page() || is_home() ) ) return;

        $post = get_post();
        if ( ! $post ) return;

        // Intercept GS homepage — match by front-page assignment, slug, or shortcode
        $gs_home_page = get_page_by_path( 'gs-home' );
        $gs_home_id   = $gs_home_page ? (int) $gs_home_page->ID : 0;
        $front_id     = (int) get_option( 'page_on_front' );
        $is_gs_home   = ( $gs_home_id && (int) $post->ID === $gs_home_id )
            || ( $gs_home_id && $front_id === $gs_home_id )
            || $post->post_name === 'gs-home'
            || has_shortcode( $post->post_content, 'gs_home' )
            || str_contains( (string) $post->post_content, '[gs_home' );
        if ( $is_gs_home ) {
            // Real, authoritative fix for the confirmed "settings changes
            // have no effect" cache problem: no-cache (NOT no-store) tells
            // any standards-respecting CDN or browser it MAY still cache
            // this page, but MUST revalidate with the origin on every
            // request before serving the cached copy — full performance
            // benefit preserved when nothing changed, but a genuinely
            // current response guaranteed the instant settings are saved.
            // This fixes the problem at its actual root, unlike a
            // client-side JS workaround that can only run if it happens to
            // already be present in whatever HTML a CDN is currently
            // serving — which is exactly the scenario that made the
            // previous fix ineffective.
            if ( ! headers_sent() ) {
                header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
                header( 'Pragma: no-cache' );
                header( 'Expires: 0' );
                header( 'X-LiteSpeed-Cache-Control: no-cache' );
            }
            status_header( 200 );
            self::render_homepage();
            exit;
        }
    }

    /** Dedicated PWA install page — self-contained, works even when homepage CDN cache is stale. */
    private static function render_install_app(): void {
        $platform = Config::get( 'platform_name', 'GoodService' );
        $manifest = gs_pwa_manifest_url( 'client' );
        $sw_root  = home_url( 'gs-client-sw.js?v=' . rawurlencode( GS_VERSION ) );
        $sw_ajax  = admin_url( 'admin-ajax.php?action=gs_serve_sw&type=client&v=' . rawurlencode( GS_VERSION ) );
        $icon_url    = gs_pwa_icon_url( 'client-192' );
        $home_url    = home_url( '/' );
        $install_home = add_query_arg( [ 'pwa' => '1', 'gs_install' => '1' ], $home_url );

        nocache_headers();
        header( 'X-Robots-Tag: noindex' );
        echo '<!DOCTYPE html><html lang="en"><head>';
        echo '<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
        echo '<link rel="manifest" href="' . esc_url( $manifest ) . '">';
        echo '<meta name="theme-color" content="#2563EB">';
        echo '<meta name="mobile-web-app-capable" content="yes">';
        echo '<meta name="apple-mobile-web-app-capable" content="yes">';
        echo '<meta name="apple-mobile-web-app-title" content="' . esc_attr( $platform ) . '">';
        echo '<link rel="apple-touch-icon" href="' . esc_url( $icon_url ) . '">';
        echo '<title>Install ' . esc_html( $platform ) . ' App</title>';
        echo '<style>
          body{font-family:system-ui,-apple-system,Segoe UI,Roboto,sans-serif;margin:0;background:#F8FAFC;color:#0F172A}
          .wrap{max-width:440px;margin:0 auto;padding:28px 20px 48px;text-align:center}
          .icon{width:88px;height:88px;border-radius:22px;margin:0 auto 16px;box-shadow:0 8px 24px rgba(37,99,235,.25)}
          h1{font-size:1.35rem;margin:0 0 8px}
          .sub{color:#64748B;font-size:.9rem;line-height:1.5;margin-bottom:12px}
          .notice{background:#EFF6FF;border:1px solid #BFDBFE;border-radius:10px;padding:12px 14px;font-size:.82rem;line-height:1.5;color:#1E40AF;text-align:left;margin-bottom:20px}
          .notice b{color:#1E3A8A}
          .btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;width:100%;padding:14px 20px;border:none;border-radius:12px;background:#2563EB;color:#fff;font-size:1rem;font-weight:700;cursor:pointer;text-decoration:none}
          .btn:disabled{opacity:.55;cursor:wait}
          .btn-outline{background:#fff;color:#2563EB;border:1.5px solid #2563EB;margin-top:10px}
          .btn2{display:inline-block;margin-top:16px;color:#2563EB;font-size:.85rem;text-decoration:none}
          #status{margin-top:14px;font-size:.84rem;color:#334155;min-height:1.3em;font-weight:600}
          .diag{margin-top:18px;text-align:left;background:#fff;border:1px solid #E2E8F0;border-radius:12px;padding:14px 16px;font-size:.78rem;line-height:1.7;color:#475569}
          .diag strong{display:block;font-size:.82rem;color:#0F172A;margin-bottom:8px}
          .diag li{margin:4px 0;list-style:none;padding-left:0}
          .diag .ok{color:#15803D}.diag .fail{color:#B91C1C}.diag .wait{color:#B45309}.diag .warn{color:#B45309}
          .steps{margin-top:16px;text-align:left;background:#fff;border:1px solid #E2E8F0;border-radius:12px;padding:16px;font-size:.84rem;line-height:1.65;color:#334155}
          .steps.highlight{border-color:#2563EB;box-shadow:0 0 0 3px rgba(37,99,235,.15)}
          .steps strong{display:block;margin-bottom:8px;color:#0F172A;font-size:.9rem}
          .steps ol{margin:0;padding-left:1.2rem}
          .steps li{margin-bottom:6px}
          .chrome-mock{margin:0 0 18px;background:#fff;border:1px solid #CBD5E1;border-radius:10px;overflow:hidden;text-align:left;box-shadow:0 4px 14px rgba(15,23,42,.08)}
          .chrome-mock .bar{display:flex;align-items:center;gap:8px;padding:10px 12px;background:#F1F5F9;border-bottom:1px solid #E2E8F0;font-size:.75rem}
          .chrome-mock .dots{display:flex;gap:4px}
          .chrome-mock .dot{width:9px;height:9px;border-radius:50%;background:#CBD5E1}
          .chrome-mock .url{flex:1;background:#fff;border:1px solid #E2E8F0;border-radius:6px;padding:5px 10px;color:#64748B;overflow:hidden;white-space:nowrap}
          .chrome-mock .pulse{display:inline-flex;align-items:center;gap:4px;background:#2563EB;color:#fff;border-radius:6px;padding:4px 8px;font-weight:700;animation:gsPulse 1.4s ease-in-out infinite}
          .chrome-mock .menu{font-size:1.1rem;color:#334155;padding:0 4px}
          .chrome-mock .hint{padding:10px 12px;font-size:.78rem;color:#475569;line-height:1.5}
          @keyframes gsPulse{0%,100%{box-shadow:0 0 0 0 rgba(37,99,235,.45)}50%{box-shadow:0 0 0 6px rgba(37,99,235,0)}}
          #gs-coach{position:fixed;inset:0;z-index:9999;background:rgba(15,23,42,.55);display:none;align-items:center;justify-content:center;padding:20px}
          #gs-coach.open{display:flex}
          .coach-box{max-width:400px;width:100%;background:#fff;border-radius:16px;padding:22px 20px;text-align:left;box-shadow:0 20px 50px rgba(15,23,42,.25)}
          .coach-box h2{margin:0 0 12px;font-size:1.1rem}
          .coach-box p{margin:0 0 14px;font-size:.84rem;line-height:1.55;color:#475569}
          .coach-box .btn{margin-top:10px}
        </style>';
        echo '</head><body>';
        echo '<div class="chrome-mock" id="gs-chrome-mock" style="display:none"><div class="bar"><div class="dots"><span class="dot"></span><span class="dot"></span><span class="dot"></span></div><div class="url">goodservice.co.in</div><span class="pulse">⊕ Install</span><span class="menu">⋮</span></div><div class="hint">↑ Click <b>⊕ Install</b> in your address bar, or <b>⋮</b> menu → <b>Cast, save, and share</b> → <b>Install ' . esc_html( $platform ) . '</b>. Nothing saves to Downloads.</div></div>';
        echo '<div class="wrap">';
        echo '<img class="icon" src="' . esc_url( $icon_url ) . '" alt="' . esc_attr( $platform ) . '">';
        echo '<h1>Install ' . esc_html( $platform ) . '</h1>';
        echo '<p class="sub">Add the app to your home screen or app list for faster access and booking updates.</p>';
        echo '<div class="notice" id="gs-install-notice"><b>Android:</b> Chrome installs ' . esc_html( $platform ) . ' as a <b>real app</b> in your <b>app drawer</b> and home screen (WebAPK). No APK file goes to Downloads — the app icon appears automatically, full-screen like WhatsApp.</div>';
        echo '<button type="button" class="btn" id="gs-install-btn" disabled>⬇ Install App</button>';
        echo '<a class="btn btn-outline" id="gs-home-install-btn" href="' . esc_url( $install_home ) . '" style="display:none">Go to homepage — look for ⊕ in address bar</a>';
        echo '<button type="button" class="btn btn-outline" id="gs-retry-btn" style="display:none">Try again</button>';
        echo '<div id="status">Loading install files…</div>';
        echo '<div class="diag" id="gs-diag"><strong>Install check</strong><ul id="gs-diag-list"><li class="wait">⏳ Starting…</li></ul></div>';
        echo '<div class="steps" id="gs-manual-steps"></div>';
        echo '<a class="btn2" href="' . esc_url( $home_url ) . '">← Back to website</a>';
        echo '</div>';
        echo '<div id="gs-coach" role="dialog" aria-modal="true" aria-label="How to install"><div class="coach-box">';
        echo '<h2>Install from Chrome — not a file download</h2>';
        echo '<p>Chrome does <b>not</b> save anything to your Downloads folder. It adds <b>' . esc_html( $platform ) . '</b> to your <b>Start Menu</b> like a normal app.</p>';
        echo '<div class="chrome-mock"><div class="bar"><div class="dots"><span class="dot"></span><span class="dot"></span><span class="dot"></span></div><div class="url">goodservice.co.in</div><span class="pulse">⊕ Install</span><span class="menu">⋮</span></div></div>';
        echo '<ol style="margin:0 0 14px;padding-left:1.2rem;font-size:.84rem;line-height:1.65;color:#334155"><li>Look at the <b>top-right</b> of Chrome (address bar area).</li><li>Click <b>⊕ Install</b> <em>or</em> <b>⋮</b> → <b>Cast, save, and share</b> → <b>Install ' . esc_html( $platform ) . '</b>.</li><li>Click <b>Install</b> in the popup.</li><li>Open ' . esc_html( $platform ) . ' from your <b>Start Menu</b>.</li></ol>';
        echo '<button type="button" class="btn" id="gs-coach-home">Go to homepage (easier to find ⊕)</button>';
        echo '<button type="button" class="btn btn-outline" id="gs-coach-close">Close</button>';
        echo '</div></div><script>
(function(){
  var manifestUrl=' . wp_json_encode( $manifest ) . ';
  var swUrls=' . wp_json_encode( [ $sw_root, $sw_ajax ] ) . ';
  var iconUrl=' . wp_json_encode( $icon_url ) . ';
  var platformName=' . wp_json_encode( $platform ) . ';
  var installHomeUrl=' . wp_json_encode( $install_home ) . ';
  var deferred=null,prepDone=false;
  var btn=document.getElementById("gs-install-btn");
  var homeBtn=document.getElementById("gs-home-install-btn");
  var retryBtn=document.getElementById("gs-retry-btn");
  var coach=document.getElementById("gs-coach");
  var chromeMock=document.getElementById("gs-chrome-mock");
  var status=document.getElementById("status");
  var steps=document.getElementById("gs-manual-steps");
  var diagList=document.getElementById("gs-diag-list");
  var diagState={manifest:false,icons:false,sw:false,offline:false,prompt:false};
  window.addEventListener("beforeinstallprompt",function(e){
    e.preventDefault();deferred=e;diagState.prompt=true;renderDiag();
    if(prepDone){btn.textContent="⬇ Install App";status.textContent="Ready — tap Install App for the browser prompt.";}
  });
  if("serviceWorker"in navigator){navigator.serviceWorker.register(swUrls[0],{scope:"/"}).catch(function(){});}
  function ua(){return navigator.userAgent||"";}
  function isIOS(){return /iPhone|iPad|iPod/.test(ua())&&!window.MSStream;}
  function isAndroid(){return /Android/.test(ua());}
  function isAndroidChrome(){return isAndroid()&&/Chrome\//.test(ua())&&!/Edg\//.test(ua());}
  function isStandalone(){return window.matchMedia("(display-mode: standalone)").matches||window.navigator.standalone;}
  window.addEventListener("appinstalled",function(){
    status.textContent="Installed! Open "+platformName+" from your app drawer or home screen.";
    btn.textContent="✅ Installed";closeCoach();
  });
  function renderDiag(){
    var items=[
      {ok:diagState.manifest,label:"Manifest loaded (application/manifest+json)"},
      {ok:diagState.icons,label:"Icons valid (192px + 512px PNG)"},
      {ok:diagState.sw,label:"Service worker registered"},
      {ok:diagState.offline,label:"Offline page ready (real PWA)"},
      {ok:diagState.prompt,label:"Automatic install button (optional)",optional:true,soft:true}
    ];
    diagList.innerHTML=items.map(function(it){
      var cls=it.ok?"ok":(it.optional&&!prepDone?"wait":(it.soft?"warn":"fail"));
      var icon=it.ok?"✅":(it.optional&&!prepDone?"⏳":(it.soft?"⚠️":"❌"));
      return "<li class=\""+cls+"\">"+icon+" "+it.label+"</li>";
    }).join("");
  }
  function manualSteps(){
    if(isIOS())return "<strong>iPhone / iPad (Safari)</strong><ol><li>Tap the <b>Share</b> button (square with arrow up).</li><li>Scroll and tap <b>Add to Home Screen</b>.</li><li>Tap <b>Add</b> in the top-right.</li></ol>";
    if(isAndroidChrome())return "<strong>Install on Android (Chrome)</strong><ol><li>Use <b>Google Chrome</b> — not Facebook/Instagram in-app browser.</li><li>Tap <b>⋮</b> (top-right) → <b>Install app</b> or <b>Install "+platformName+"</b>.</li><li>Tap <b>Install</b> in the popup.</li><li>Open "+platformName+" from your <b>app drawer</b> — it runs full-screen like a native app.</li></ol><p style=\"margin:.5rem 0 0;font-size:.8rem;color:#64748B\">Chrome creates a WebAPK automatically. No file in Downloads — that is normal.</p>";
    if(isAndroid())return "<strong>Android</strong><ol><li>Open this page in <b>Google Chrome</b>.</li><li>Tap <b>⋮</b> → <b>Install app</b> or <b>Add to Home screen</b>.</li></ol>";
    return "<strong>Computer (Chrome / Edge)</strong><ol><li>Click the <b>⋮ menu</b> (top-right of the browser).</li><li>Click <b>Cast, save, and share</b> → <b>Install "+platformName+"</b>.</li><li>Or look for the <b>⊕</b> install icon at the right end of the address bar.</li><li>After installing, open "+platformName+" from your Start Menu or Applications.</li></ol>";
  }
  function showManual(msg){steps.innerHTML=msg||manualSteps();steps.classList.add("highlight");steps.scrollIntoView({behavior:"smooth",block:"nearest"});}
  function setReady(msg){btn.disabled=false;retryBtn.style.display="inline-flex";if(homeBtn)homeBtn.style.display="inline-flex";status.textContent=msg;}
  function openCoach(){if(coach){coach.classList.add("open");}if(chromeMock)chromeMock.style.display="block";}
  function closeCoach(){if(coach){coach.classList.remove("open");}}
  document.getElementById("gs-coach-close").addEventListener("click",closeCoach);
  document.getElementById("gs-coach-home").addEventListener("click",function(){window.location.href=installHomeUrl;});
  if(coach){coach.addEventListener("click",function(e){if(e.target===coach)closeCoach();});}
  function warmup(url){return new Promise(function(resolve){
    var done=false,iframe=document.createElement("iframe");
    iframe.style.cssText="position:absolute;width:1px;height:1px;opacity:0;left:-9999px;border:0";
    function finish(){if(done)return;done=true;try{iframe.remove();}catch(e){}resolve();}
    iframe.onload=finish;setTimeout(finish,6000);iframe.src=url||swUrls[0];
    (document.body||document.documentElement).appendChild(iframe);
  });}
  async function checkIcons(data){
    var icons=(data&&data.icons)||[],ok192=false,ok512=false;
    for(var i=0;i<icons.length;i++){
      var ic=icons[i],sz=String(ic.sizes||""),src=ic.src;
      if(!src)continue;
      try{
        var r=await fetch(src,{credentials:"same-origin",cache:"no-store"});
        var ct=(r.headers.get("content-type")||"").toLowerCase();
        if(r.ok&&ct.indexOf("png")!==-1){
          if(sz.indexOf("192")!==-1)ok192=true;
          if(sz.indexOf("512")!==-1)ok512=true;
        }
      }catch(e){}
    }
    diagState.icons=ok192&&ok512;renderDiag();return diagState.icons;
  }
  async function checkManifest(){
    try{
      var r=await fetch(manifestUrl,{credentials:"same-origin",cache:"no-store"});
      var ct=(r.headers.get("content-type")||"").toLowerCase();
      diagState.manifest=r.ok&&ct.indexOf("manifest")!==-1;
      if(diagState.manifest){var data=await r.json();await checkIcons(data);}
      else{diagState.icons=false;}
    }catch(e){diagState.manifest=false;diagState.icons=false;}
    renderDiag();
    return diagState.manifest;
  }
  async function registerSw(){
    if(!("serviceWorker"in navigator)){diagState.sw=false;renderDiag();return null;}
    for(var i=0;i<swUrls.length;i++){
      try{
        var reg=await navigator.serviceWorker.register(swUrls[i],{scope:"/"});
        diagState.sw=true;renderDiag();return reg;
      }catch(e){}
    }
    diagState.sw=false;renderDiag();return null;
  }
  async function checkOffline(){
    try{
      var r=await fetch("/gs-offline.html",{credentials:"same-origin",cache:"no-store"});
      diagState.offline=r.ok;renderDiag();return diagState.offline;
    }catch(e){diagState.offline=false;renderDiag();return false;}
  }
  function waitForPrompt(ms){
    if(deferred)return Promise.resolve(true);
    return new Promise(function(resolve){setTimeout(function(){resolve(!!deferred);},ms||12000);});
  }
  async function prepare(){
    btn.disabled=true;status.textContent="Loading install files…";
    renderDiag();showManual();
    if(isStandalone()){status.textContent="App is already installed — open it from your home screen or app list.";btn.textContent="✅ Already installed";prepDone=true;return;}
    if(isIOS()){setReady("Follow the steps below to add to Home Screen:");prepDone=true;renderDiag();return;}
    if(isAndroid()&&!isAndroidChrome()){
      var n=document.getElementById("gs-install-notice");
      if(n)n.innerHTML="<b>Open in Google Chrome</b> to install as an app. In-app browsers (Facebook, Instagram) cannot install PWAs.";
    }
    var swPromise=registerSw();
    var manifestPromise=checkManifest();
    var offlinePromise=checkOffline();
    try{await fetch(iconUrl,{credentials:"same-origin",cache:"no-store"});}catch(e){}
    await Promise.all([swPromise,manifestPromise,offlinePromise]);
    await waitForPrompt(12000);
    prepDone=true;renderDiag();
    if(deferred){
      btn.textContent=isAndroid()?"📲 Install on Android":"⬇ Install App";
      setReady(isAndroid()?"Tap the button — Chrome will install the app to your app drawer.":"Ready — tap Install App for the browser popup.");
    }else{
      btn.textContent=isAndroid()?"Show Android install steps":"Open Chrome install guide";
      if(chromeMock&&!isAndroid())chromeMock.style.display="block";
      setReady(isAndroid()?"Use Chrome menu steps below — app appears in your app drawer, not Downloads.":"Nothing downloads here — use the Chrome menu or the ⊕ icon (see guide).");
      if(isAndroid()){showManual();}else{setTimeout(openCoach,600);}
    }
  }
  async function runInstall(){
    if(isStandalone())return;
    if(isIOS()){showManual();status.textContent="Follow the steps below:";return;}
    if(deferred){
      try{
        await deferred.prompt();
        var choice=await deferred.userChoice;
        deferred=null;diagState.prompt=false;renderDiag();
        if(choice&&choice.outcome==="accepted"){status.textContent=isAndroid()?"Installed! Open "+platformName+" from your app drawer or home screen.":("Installed! Open "+platformName+" from your Start Menu or app list.");btn.textContent="✅ Installed";closeCoach();}
        else{status.textContent="Install cancelled — use the Chrome menu guide below.";openCoach();showManual();}
        return;
      }catch(e){deferred=null;}
    }
    openCoach();showManual();
    status.textContent="Use the Chrome ⊕ or ⋮ menu — this page cannot download a file.";
  }
  btn.addEventListener("click",runInstall);
  retryBtn.addEventListener("click",function(){
    retryBtn.disabled=true;retryBtn.textContent="Checking…";
    deferred=null;diagState.prompt=false;prepDone=false;
    prepare().finally(function(){retryBtn.disabled=false;retryBtn.textContent="Try again";});
  });
  document.addEventListener("DOMContentLoaded",prepare);
})();
</script></body></html>';
    }

    // ── Homepage — standalone full-page renderer ────────────────────────────────
    private static function render_homepage(): void {
        $platform = Config::get( 'platform_name', get_bloginfo('name') );
        $color    = Config::get( 'platform_color_primary', '#2563EB' );
        $favicon  = Config::get( 'platform_favicon_url', '' );

        ob_start();
        try {
            require GS_DIR . 'templates/pages/home.php';
        } catch ( \Throwable $e ) {
            echo self::error_html( $e );
        }
        $content = ob_get_clean();

        try { $js_config = wp_json_encode( Assets::js_config() ); }
        catch ( \Throwable $e ) { $js_config = '{}'; }

        // Real fix, closing the audit's minification gap safely: uses
        // gs_asset_url() to resolve the minified version only when it's
        // genuinely, verifiably newer than the source — the exact
        // protection the old comment on this line called for, now
        // actually implemented rather than avoiding minification entirely.
        $css_url = gs_asset_url( 'assets/css/goodservice.css' );
        $js_url  = gs_asset_url( 'assets/js/goodservice.js' );

        $_gs_html_cls = trim( (string) apply_filters( 'gs_html_class', '', 'home' ) );
        echo '<!DOCTYPE html><html lang="en"' . ( $_gs_html_cls ? ' class="' . esc_attr( $_gs_html_cls ) . '"' : '' ) . '><head>';
        echo '<!-- GS-PWA-HOME ' . esc_attr( GS_VERSION ) . ' -->';
        // Real fix — PageSpeed's "Properly defines charset" audit requires
        // the charset meta to be the very first element in <head>, before
        // any script; this used to echo the geolocation-block script
        // first, pushing charset one element too late. Order swapped,
        // nothing else changed.
        echo '<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
        echo '<script>try{if(window.navigator&&navigator.geolocation){navigator.geolocation.getCurrentPosition=function(){};navigator.geolocation.watchPosition=function(){return 0;}}}catch(e){}</script>';
        echo '<meta name="description" content="' . esc_attr( Config::get('platform_description', $platform) ) . '">';
        // Real feature, item 2 from the audit: search engine verification
        // meta tags — only output when actually configured, so this adds
        // nothing to the page for any installation that hasn't set them.
        $_seo_gsc_v = Config::get( 'seo_gsc_verification', '' );
        if ( $_seo_gsc_v ) { echo '<meta name="google-site-verification" content="' . esc_attr( $_seo_gsc_v ) . '">'; }
        $_seo_bing_v = Config::get( 'seo_bing_verification', '' );
        if ( $_seo_bing_v ) { echo '<meta name="msvalidate.01" content="' . esc_attr( $_seo_bing_v ) . '">'; }
        if ( $favicon ) { echo '<link rel="icon" href="' . esc_url($favicon) . '">'; }
        // Real fix: the homepage — the actual "platform" install entry
        // point, distinct from any single vendor's listing page — had zero
        // PWA install mechanism at all: no manifest, no service worker
        // reference, confirmed by searching this entire file and finding
        // nothing. Uses the existing, already-correct static client
        // manifest (immune to the CDN restriction that affected the
        // per-listing admin-ajax.php endpoint, since this is served as a
        // plain static file) with the already-fixed platform icon.
        // Real fix (v7.475.0): the REST API URL used here since v7.470.0
        // was confirmed, via the live diagnostic and direct browser
        // testing, to return HTTP 200 with Content-Type:
        // application/octet-stream and an EMPTY body — on this exact
        // route, in real browsers, in fresh incognito windows, across
        // devices. Three targeted fixes at that REST/WP-JSON layer
        // (Service-Worker-Allowed header, generic no-cache headers,
        // LiteSpeed-specific no-cache headers) did not change that
        // symptom, ruling out caching as the cause. Switched to the
        // REAL static file — GS_URL . 'goodservice-client.webmanifest' —
        // which sits directly in the plugin's own root folder and is
        // served straight off disk by the webserver, never touching
        // WordPress/PHP/WP-JSON at all, sidestepping whatever intercepts
        // that layer on this host. See the plugin-root .htaccess for the
        // matching MIME-type and header fixes this file needs.
        // v7.475.26: real PWA — server manifest link + immediate SW registration so Chrome
        // can evaluate installability without waiting for goodservice.js + Anubis warmup.
        // Meta kept as fallback URL for gsBootstrapManifest() to re-inject after Anubis if needed.
        $_gs_manifest = gs_pwa_manifest_url( 'client' );
        $_gs_sw_root  = home_url( 'gs-client-sw.js?v=' . rawurlencode( GS_VERSION ) );
        echo '<link rel="manifest" href="' . esc_attr( $_gs_manifest ) . '">';
        echo '<meta name="gs-pwa-manifest-url" content="' . esc_attr( $_gs_manifest ) . '">';
        echo '<meta name="mobile-web-app-capable" content="yes">';
        echo '<script>window.gsDeferredInstallPrompt=null;window.addEventListener("beforeinstallprompt",function(e){e.preventDefault();window.gsDeferredInstallPrompt=e;});if("serviceWorker"in navigator){navigator.serviceWorker.register(' . wp_json_encode( $_gs_sw_root ) . ',{scope:"/"}).catch(function(){});}</script>';
        echo '<meta name="apple-mobile-web-app-capable" content="yes">';
        echo '<meta name="apple-mobile-web-app-status-bar-style" content="default">';
        echo '<meta name="apple-mobile-web-app-title" content="' . esc_attr( $platform ) . '">';
        // Real fix: uses the PHP-served icon route with a non-file-like
        // query parameter, not a path ending in .png — a path-based .png
        // URL was ALSO confirmed intercepted by this CDN's extension-based
        // rules, even for a dynamic route.
        echo '<link rel="apple-touch-icon" href="' . esc_url( add_query_arg( 'name', 'client-192', rest_url( 'goodservice/v1/icon' ) ) ) . '">';
        echo '<title>' . esc_html( $platform ) . ' — Find Verified Local Service Providers</title>';
        echo self::critical_css( $color );
        echo '<link rel="stylesheet" href="' . esc_url($css_url) . '">';

        // Organization schema — confirmed real, previously-missing gap
        // (SEO Ceiling Plan, Part 1.2). Distinct from each vendor's own
        // LocalBusiness markup: this establishes the PLATFORM ITSELF as
        // an entity to Google. Every field below is genuinely optional
        // in the Schema.org spec, so an unconfigured platform still
        // produces valid, correct output with just the required core
        // fields — never broken, never emitting empty placeholders.
        $org_schema = [
            '@context' => 'https://schema.org',
            '@type'    => 'Organization',
            'name'     => $platform,
            'url'      => home_url( '/' ),
            'description' => Config::get( 'platform_description', $platform ),
        ];
        $org_logo = Config::get( 'logo_url', '' );
        if ( $org_logo ) { $org_schema['logo'] = $org_logo; }
        $org_email = Config::get( 'platform_email', '' );
        if ( $org_email ) { $org_schema['email'] = $org_email; }
        $org_phone = Config::get( 'platform_phone', '' );
        if ( $org_phone ) { $org_schema['telephone'] = $org_phone; }
        $org_address = Config::get( 'platform_address', '' );
        if ( $org_address ) {
            $org_schema['address'] = [ '@type' => 'PostalAddress', 'streetAddress' => $org_address ];
        }
        // sameAs — same URL-validation pattern already proven on the
        // per-listing schema (see render_listing_unified()), so a
        // malformed entry typed into Settings can't produce broken
        // JSON-LD; it's simply omitted rather than included invalid.
        $org_same_as = [];
        foreach ( [ 'platform_facebook', 'platform_instagram', 'platform_linkedin', 'platform_twitter' ] as $org_social_key ) {
            $org_social_url = Config::get( $org_social_key, '' );
            if ( $org_social_url && filter_var( $org_social_url, FILTER_VALIDATE_URL ) ) {
                $org_same_as[] = $org_social_url;
            }
        }
        if ( $org_same_as ) { $org_schema['sameAs'] = array_values( array_unique( $org_same_as ) ); }
        echo '<script type="application/ld+json">' . wp_json_encode( $org_schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>';

        // WebSite schema with SearchAction — enables Sitelinks Searchbox in Google
        $website_schema = [
            '@context'        => 'https://schema.org',
            '@type'           => 'WebSite',
            'name'            => $platform,
            'url'             => home_url( '/' ),
            'potentialAction' => [
                '@type'       => 'SearchAction',
                'target'      => [
                    '@type'       => 'EntryPoint',
                    'urlTemplate' => home_url( '/directory/?keyword={search_term_string}' ),
                ],
                'query-input' => 'required name=search_term_string',
            ],
        ];
        echo '<script type="application/ld+json">' . wp_json_encode( $website_schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>';

        // Canonical + Open Graph for homepage
        $home_url = home_url( '/' );
        $home_desc = esc_attr( Config::get( 'platform_description', $platform ) );
        $home_logo = Config::get( 'logo_url', '' ) ?: ( get_site_icon_url( 512 ) ?: '' );
        echo '<link rel="canonical" href="' . esc_url( $home_url ) . '">';
        echo '<meta property="og:type" content="website">';
        echo '<meta property="og:locale" content="en_IN">';
        echo '<meta property="og:title" content="' . esc_attr( $platform . ' — Find Verified Local Service Providers' ) . '">';
        echo '<meta property="og:description" content="' . $home_desc . '">';
        echo '<meta property="og:url" content="' . esc_url( $home_url ) . '">';
        echo '<meta property="og:site_name" content="' . esc_attr( $platform ) . '">';
        if ( $home_logo ) {
            echo '<meta property="og:image" content="' . esc_url( $home_logo ) . '">';
            echo '<meta property="og:image:alt" content="' . esc_attr( $platform ) . '">';
        }
        echo '<meta name="twitter:card" content="summary_large_image">';
        echo '<meta name="twitter:title" content="' . esc_attr( $platform . ' — Find Verified Local Service Providers' ) . '">';
        echo '<meta name="twitter:description" content="' . $home_desc . '">';

        echo apply_filters( 'gs_head_inject', '', 'home' );

        // ── Selective wp_head: loads 3rd-party plugin assets (e.g. Yellow Pencil)
        //    WITHOUT the duplicate title, charset, theme CSS, or jQuery that would
        //    conflict with GoodService's own head content.
        add_action( 'wp_head', function() {
            // Remove WP core meta/link hooks — GoodService already outputs these
            foreach ( [
                [ '_wp_render_title_tag',              1  ],
                [ 'wp_generator',                      10 ],
                [ 'feed_links',                        2  ],
                [ 'feed_links_extra',                  3  ],
                [ 'rsd_link',                          10 ],
                [ 'wlwmanifest_link',                  10 ],
                [ 'adjacent_posts_rel_link_wp_head',   10 ],
                [ 'locale_stylesheet',                 10 ],
                [ 'noindex',                           1  ],
                [ 'wp_no_robots',                      1  ],
                [ 'wp_site_icon',                      99 ],
                [ 'wp_resource_hints',                 2  ],
                [ 'rest_output_link_wp_head',          10 ],
                [ 'wp_oembed_add_discovery_links',     10 ],
                [ 'wp_shortlink_wp_head',              10 ],
                [ 'rel_canonical',                     10 ],
            ] as [ $fn, $pri ] ) {
                remove_action( 'wp_head', $fn, $pri );
            }

            // ── Suppress third-party SEO plugin duplicate output ──────────────
            if ( class_exists( 'WPSEO_Frontend' ) ) {
                $yoast = \WPSEO_Frontend::get_instance();
                foreach ( [ 'canonical', 'metadesc', 'robots', 'og_tag_title', 'twitter_title',
                             'schema', 'head', 'output_title', 'add_opengraph_namespace' ] as $method ) {
                    remove_action( 'wp_head', [ $yoast, $method ], 1 );
                    remove_action( 'wp_head', [ $yoast, $method ], 10 );
                }
            }
            // Real fix: extracted to a shared function — see
            // gs_apply_rankmath_conflict_prevention() in functions.php —
            // instead of 3 duplicated copies of this same logic.
            gs_apply_rankmath_conflict_prevention();
            if ( function_exists( 'aioseo' ) && method_exists( aioseo(), 'meta' ) ) {
                remove_action( 'wp_head', [ aioseo()->meta, 'output' ], 1 );
            }
            if ( defined( 'SEOPRESS_VERSION' ) ) {
                remove_action( 'wp_head', 'seopress_titles_hook',      0 );
                remove_action( 'wp_head', 'seopress_social_tags_hook', 1 );
                remove_action( 'wp_head', 'seopress_schemas_hook',     2 );
            }
        }, 0 );
        // Remove WP core / theme styles — keep only 3rd-party plugin styles (e.g. YP)
        add_action( 'wp_print_styles', function() {
            global $wp_styles;
            if ( ! $wp_styles instanceof \WP_Styles ) return;
            $core_prefixes = [ 'wp-', 'admin-bar', 'dashicons', 'classic-theme', 'global-styles',
                               'jquery-', 'thickbox', 'mediaelement', 'wp_mediaelement' ];
            foreach ( array_keys( $wp_styles->registered ) as $handle ) {
                foreach ( $core_prefixes as $pfx ) {
                    if ( str_starts_with( $handle, $pfx ) ) { wp_dequeue_style( $handle ); break; }
                }
                // Also skip active theme styles
                if ( get_stylesheet() && str_contains( $handle, get_stylesheet() ) ) {
                    wp_dequeue_style( $handle );
                }
            }
        }, PHP_INT_MAX );
        // Dequeue ALL scripts on vendor site except an explicit whitelist.
        // This prevents 3rd-party plugins (YellowPencil, etc.) from injecting
        // their JS (which can contain geolocation calls, alerts, etc.) into
        // the vendor site standalone page.
        add_action( 'wp_print_scripts', function() {
            global $wp_scripts;
            if ( ! $wp_scripts instanceof \WP_Scripts ) return;
            // Allow ONLY scripts explicitly needed on vendor site:
            // Fluent Forms (fluentform-*), reCAPTCHA (google-recaptcha) etc.
            // Everything else is dequeued — GS loads its own jQuery + goodservice.js directly.
            $allow_prefixes = [ 'fluentform', 'fluent-form', 'recaptcha', 'google-recaptcha' ];
            foreach ( array_keys( $wp_scripts->registered ) as $handle ) {
                $keep = false;
                foreach ( $allow_prefixes as $pfx ) {
                    if ( str_contains( $handle, $pfx ) ) { $keep = true; break; }
                }
                if ( ! $keep ) { wp_dequeue_script( $handle ); }
            }
        }, PHP_INT_MAX );
        ob_start(); wp_head(); echo ob_get_clean();
        $wp_body_classes_home = implode( ' ', get_body_class( [ 'gs-body', 'gs-page-home' ] ) );
        // FIXED — root cause of "jQuery is not available" reported live on the
        // Manual Plans screen (confirmed via an on-page diagnostic banner,
        // since browser DevTools weren't available to check directly): jQuery
        // and goodservice.js were both loaded with `defer`, meaning they only
        // execute after the ENTIRE document finishes parsing. But $content
        // (echoed further down this same function) contains plain, non-
        // deferred inline <script> tags from page templates — e.g. Manual
        // Plans' `window.MP = (function($){ ... })(jQuery)` — which the HTML
        // parser executes IMMEDIATELY, synchronously, at their position in
        // the document. A synchronous inline script always runs before any
        // deferred script, by spec, with zero exceptions — this was not an
        // intermittent timing issue, it failed 100% of the time for every
        // inline script on this render path that touches jQuery at its own
        // top level (not inside a later event-driven callback). Removing
        // `defer` here makes jQuery load and execute synchronously, in
        // document order, guaranteeing it is defined before any later inline
        // script in the page can run — matching what those inline scripts
        // already assumed.
        echo '<script src="' . includes_url('js/jquery/jquery.min.js') . '"></script>';
        echo '<script>var GS='.($js_config&&$js_config!='{}' ? $js_config : '{}').';(function(){if(!GS.ajax_url)GS.ajax_url='.wp_json_encode(admin_url('admin-ajax.php')).';if(!GS.nonce)GS.nonce='.wp_json_encode(wp_create_nonce('gs_ajax')).';if(!GS.i18n)GS.i18n={error:"Something went wrong"};})();</script>';
        // FIXED — same root cause as the jQuery tag above: goodservice.js
        // defines gsPost/gsToast/gsBtnLoading/GS_Toast etc., which page
        // templates' own inline scripts also call immediately, not just from
        // inside later event handlers — `defer` here meant those were
        // undefined too at the moment such an inline script ran.
        echo '<script src="' . esc_url($js_url) . '"></script>';
        echo '<script>window.gsOnDownloadAppClick=window.gsOnDownloadAppClick||function(){var b=(window.GS&&GS.home_url)?GS.home_url:"/";if(b.slice(-1)!=="/")b+="/";window.location.href=b+"install-app/";};</script>';
        if ( ! empty( $_GET['gs_install'] ) ) {
            echo '<style>#gs-home-install-bar{position:fixed;top:0;left:0;right:0;z-index:99999;background:#2563EB;color:#fff;padding:12px 16px;font-size:.88rem;line-height:1.45;text-align:center;box-shadow:0 4px 16px rgba(37,99,235,.35)}#gs-home-install-bar b{color:#fff}#gs-home-install-bar button{margin-left:10px;background:#fff;color:#2563EB;border:none;border-radius:6px;padding:6px 12px;font-weight:700;cursor:pointer}body.gs-install-hint{padding-top:52px}</style>';
        }
        echo '</head><body class="' . esc_attr( $wp_body_classes_home . ( ! empty( $_GET['gs_install'] ) ? ' gs-install-hint' : '' ) ) . '">';
        if ( ! empty( $_GET['gs_install'] ) ) {
            $platform_bar = Config::get( 'platform_name', 'GoodService' );
            echo '<div id="gs-home-install-bar">👆 Look at the <b>top-right of Chrome</b> — click <b>⊕ Install</b> or <b>⋮</b> → <b>Cast, save, and share</b> → <b>Install ' . esc_html( $platform_bar ) . '</b>. Nothing downloads to your Downloads folder.<button type="button" onclick="document.getElementById(\'gs-home-install-bar\').remove();document.body.classList.remove(\'gs-install-hint\')">✕</button></div>';
        }
        echo apply_filters( 'gs_body_start_inject', '', 'home' );
        echo $content;
        echo apply_filters( 'gs_body_end_inject', '', 'home' );
        ob_start(); wp_footer(); echo ob_get_clean();
        echo '</body></html>';
    }

    // ── Intercept GS pages served through WP page routing (rewrite rule fallback) ────
    //
    // Root cause: Plugin creates real WP pages (slug='directory', 'admin-panel', etc.)
    // for compatibility. Normally the GS rewrite rules (/directory/ -> gs_page=archive)
    // take priority and dispatch() handles them. But if rewrite rules are stale or WP's
    // native page rules win, WP routes /directory/ through its template system — loading
    // the active theme with the '[gs_directory]' shortcode inside it.
    //
    // This method runs at template_redirect priority 1 (same as dispatch). If gs_page
    // was NOT set by the rewrite rule but the current WP page contains a GS shortcode,
    // we detect it here and render the correct GS standalone page directly.
    //
    // Covered shortcode → page mappings mirror create_pages() in Plugin.php.
    public static function intercept_gs_wp_pages(): void {
        if ( is_admin() ) return;

        // Only fire when NO GS rewrite-rule matched (gs_page is empty)
        // If gs_page is set, dispatch() already handled it.
        if ( get_query_var( 'gs_page' ) ) return;

        // Only fire on singular WP pages
        if ( ! is_page() ) return;

        $post = get_post();
        if ( ! $post || empty( $post->post_content ) ) return;

        $content = $post->post_content;
        $slug    = $post->post_name;

        // Map: shortcode or page slug → rendering action
        // Shortcode check is primary (most reliable), slug check is fallback.
        $slug_map = [
            'directory'        => 'archive',
            'admin-panel'      => 'admin_dashboard',
            'vendor-dashboard' => 'vendor_dashboard',
            'vendor-login'     => 'login',
            'vendor-register'  => 'register',
            'manager-panel'    => 'manager_dashboard',
            'admin-login'      => 'admin_login',
            'manager-login'    => 'manager_login',
            'staff-login'      => 'staff_login',
            'staff-dashboard'  => 'staff_dashboard',
            'moderation'       => 'moderation_dashboard',
            'forgot-password'  => 'forgot_password',
            'reset-password'   => 'reset_password',
            'vendor-staff'     => 'vendor_staff_dashboard',
            'my-account'       => 'visitor_dashboard',
            'login'            => 'login',
            'create-listing'   => 'create_listing',
        ];

        $shortcode_map = [
            'gs_directory'        => 'archive',
            'gs_login'            => 'login',
            'gs_register'         => 'register',
            'gs_vendor_dashboard' => 'vendor_dashboard',
        ];

        // Determine target GS page
        $target = null;
        foreach ( $shortcode_map as $sc => $page ) {
            if ( has_shortcode( $content, $sc ) ) {
                $target = $page;
                break;
            }
        }
        if ( ! $target && isset( $slug_map[ $slug ] ) ) {
            $target = $slug_map[ $slug ];
        }

        if ( ! $target ) return;

        // Set gs_page so dispatch() can handle it identically to the rewrite-rule path
        set_query_var( 'gs_page', $target );
        status_header( 200 );
        if ( $target === 'archive' ) {
            nocache_headers();
        }

        // Render directly — avoids a second round-trip through dispatch()
        $map = [
            'archive'              => [ \GoodService\Controller\ArchiveController::class,     'index'      ],
            'admin_dashboard'      => [ \GoodService\Controller\AdminController::class,       'dashboard'  ],
            'vendor_dashboard'     => [ \GoodService\Controller\VendorController::class,      'dashboard'  ],
            'manager_dashboard'    => [ \GoodService\Controller\ManagerController::class,     'dashboard'  ],
            'moderation_dashboard' => [ \GoodService\Controller\ModerationController::class,  'dashboard'  ],
            'visitor_dashboard'    => [ \GoodService\Controller\VisitorController::class,     'dashboard'  ],
            'login'                => [ \GoodService\Controller\AuthController::class,        'login'      ],
            'register'             => [ \GoodService\Controller\AuthController::class,        'register'   ],
            'admin_login'          => [ \GoodService\Controller\AuthController::class,        'admin_login' ],
            'manager_login'        => [ \GoodService\Controller\AuthController::class,        'manager_login' ],
            'staff_login'          => [ \GoodService\Controller\AuthController::class,        'staff_login' ],
            'staff_dashboard'      => [ \GoodService\Controller\AuthController::class,        'staff_dashboard' ],
            'advertise_with_us'    => [ \GoodService\Controller\AuthController::class,        'advertise_with_us' ],
            'how_it_works'          => [ \GoodService\Controller\AuthController::class,        'how_it_works' ],
            'trust_safety'          => [ \GoodService\Controller\AuthController::class,        'trust_safety' ],
            'about_us'              => [ \GoodService\Controller\AuthController::class,        'about_us' ],
            'contact_us'            => [ \GoodService\Controller\AuthController::class,        'contact_us' ],
            'forgot_password'      => [ \GoodService\Controller\AuthController::class,        'forgot_password' ],
            'reset_password'       => [ \GoodService\Controller\AuthController::class,        'reset_password' ],
            'vendor_staff_dashboard' => [ \GoodService\Controller\AuthController::class,      'vendor_staff_dashboard' ],
            'create_listing'       => [ \GoodService\Controller\ListingController::class,      'create'     ],
        ];

        if ( isset( $map[ $target ] ) ) {
            [ $class, $method ] = $map[ $target ];
            if ( $class && method_exists( $class, $method ) ) {
                self::render_page( $target, [ new $class(), $method ] );
                exit;
            }
        }

        // Direct template pages (no controller)
        $direct = [ 'my-home', 'rwa-dashboard', 'forgot_password', 'reset_password' ];
        $tpl    = str_replace( '_', '-', $target );
        if ( in_array( $tpl, $direct, true ) ) {
            self::render_page( $tpl, null );
            exit;
        }
    }

    // ── Last-resort theme bypass via template_include ────────────────────────────
    //
    // If a GS page somehow survives template_redirect (e.g. another plugin hooked
    // into template_redirect with die() prevention), this filter intercepts the
    // template_include phase and returns a minimal blank PHP file that outputs nothing,
    // preventing any theme template from loading.
    //
    // This is the final safety net. Under normal operation dispatch() and
    // intercept_gs_wp_pages() already exit before template_include ever fires.
    public static function bypass_theme_template( string $template ): string {
        $gs_page = get_query_var( 'gs_page' );

        // If gs_page was set but render_page was called and exited, we never reach here.
        // We only reach here if:
        //   (a) gs_page is set but dispatch somehow returned without exiting, OR
        //   (b) intercept_gs_wp_pages set gs_page but also returned without exiting.
        // In both cases: render the page now and return a blank template.
        if ( $gs_page ) {
            // Known standalone pages — render and return blank template
            $standalone = [
                'archive', 'admin_dashboard', 'vendor_dashboard', 'manager_dashboard',
                'moderation_dashboard', 'visitor_dashboard', 'customer_dashboard',
                'login', 'register', 'admin_login', 'advertise_with_us', 'how_it_works', 'trust_safety', 'about_us', 'contact_us', 'manager_login', 'staff_login', 'staff_dashboard',
                'forgot_password', 'reset_password', 'vendor_staff_dashboard', 'create_listing',
                'my_home', 'rwa_dashboard', 'seo_location', 'vendor_site',
            ];
            if ( in_array( $gs_page, $standalone, true ) ) {
                // Page was meant to be rendered standalone — something went wrong upstream.
                // Log it so developers can investigate.
                gs_write_log(
                    '[Router::bypass_theme_template] gs_page="' . $gs_page . '" reached template_include. ' .
                    'dispatch() or intercept_gs_wp_pages() should have exited. Rendering now.',
                    'WARN'
                );
                // Don't try to re-render here (could double-output) — just suppress the theme.
                // Return the blank template which outputs nothing; any already-started output buffer
                // will be flushed naturally by PHP shutdown.
                return GS_DIR . 'templates/partials/blank.php';
            }
        }

        // Also intercept by page slug for the WP pages GS created
        if ( is_page() ) {
            $post = get_post();
            $gs_slugs = [
                'directory', 'admin-panel', 'vendor-dashboard', 'vendor-login',
                'vendor-register', 'manager-panel', 'manager-login', 'staff-login',
                'staff-dashboard', 'moderation', 'forgot-password', 'reset-password',
                'vendor-staff', 'my-account', 'login', 'create-listing',
            ];
            if ( $post && in_array( $post->post_name, $gs_slugs, true ) ) {
                gs_write_log(
                    '[Router::bypass_theme_template] WP page slug="' . $post->post_name . '" reached template_include. ' .
                    'Suppressing theme template.',
                    'WARN'
                );
                return GS_DIR . 'templates/partials/blank.php';
            }
        }

        return $template;
    }

    // ── Unified listing renderer — works for both /listing/{slug} and /{slug} ──
    private static function render_listing_unified(): void {
        // SEO Search Entry URL context (may be null for the primary
        // /{microsite-slug}/ URL — that path is entirely unaffected).
        // Consumed immediately so a later, unrelated request path can never
        // accidentally pick up a stale value.
        $seo_entry = self::$active_seo_entry;
        self::$active_seo_entry = null;

        // Same authoritative cache-revalidation fix as the homepage: allows
        // continued CDN caching for performance, but forces revalidation
        // with the origin on every request so genuinely current content
        // (including recent header changes) is never masked by a stale
        // cached snapshot.
        if ( ! headers_sent() ) {
            header( 'Cache-Control: no-cache, must-revalidate, max-age=0' );
            header( 'Pragma: no-cache' );
            // Real gap closed: `Cache-Control: no-cache` only asks a CDN to
            // revalidate with the origin before serving a cached copy — a
            // CDN that ignores that nuance (or overrides origin headers
            // with its own fixed edge-cache TTL, a common default on
            // several CDNs/host-level page caches) can still serve a
            // frozen HTML snapshot from before a vendor's last save,
            // exactly matching the "I saved, the DB is right, the value
            // never changes on the live page" symptom. `CDN-Cache-Control`
            // is the header several major CDNs (Cloudflare included) treat
            // as an explicit, unambiguous "do not cache this at all"
            // instruction, distinct from the softer `Cache-Control`. Same
            // header this codebase already sends for logged-in dashboard
            // views (see the render() below) — this closes the one route
            // that was missing it: the public vendor listing page itself.
            header( 'CDN-Cache-Control: no-store' );
            // Non-visual, always-on verification headers — check these in
            // any browser's Network tab (or `curl -I`) on the PLAIN listing
            // URL, no query param needed. If X-GS-Render-At stays frozen
            // across repeated reloads, something between the browser and
            // this PHP code is serving a cached copy — proof, not a guess,
            // and it works on the exact URL real visitors use.
            header( 'X-GS-Version: ' . ( defined( 'GS_VERSION' ) ? GS_VERSION : 'unknown' ) );
            header( 'X-GS-Render-At: ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC' );
        }
        global $wpdb;
        $pfx  = $wpdb->prefix . 'gs_';
        $slug = sanitize_text_field( get_query_var( 'gs_slug', '' ) );
        if ( ! $slug ) { wp_redirect( home_url( '/directory/' ) ); exit; }

        // Load listing — explicit column list, deliberately excluding the
        // five heaviest, fully-optional "premium" sections (team/clients/
        // pricing/portfolio/testimonials). Most vendors never fill these
        // in at all; pulling their full saved content on every single
        // visit just to find out whether they're empty was the real
        // weight on this page. The navigation menu built right below only
        // ever needed a yes/no per section — answered cheaply via
        // emptiness_check below — not the actual saved content, which is
        // only fetched later, and only for sections that genuinely have
        // something in them (see fetch_premium_section_content below).
        // Allow active + pending for public; also allow draft for logged-in owner/admin (preview mode)
        // Real feature — safe query caching for the main listing fetch,
        // using the platform's existing three-tier Cache class (L1 memory
        // + Redis/object-cache + transient fallback, with group-versioned
        // bulk invalidation) rather than a separate ad-hoc mechanism. Uses
        // the exact "listing:slug:X" key pattern that saveListing(),
        // approveListing(), and submitListing() already invalidate on
        // every edit/status-change — meaning this cache is automatically
        // kept fresh by invalidation code that already existed, with no
        // new invalidation logic needed for those paths. Deliberately
        // narrow: only ever caches when the fetched status is 'active'
        // (never draft/pending, which are owner-preview-only). Short 60s
        // TTL as a safety net against any invalidation path not covered.
        // Real fix — this caching layer only provides genuine benefit when
        // a fast object cache (Redis/Memcached) is actually active. Without
        // one, Cache::get()/set() fall back to database-backed transients,
        // meaning every cache MISS costs extra DB round-trips (a version
        // lookup, the cache-check itself, then the original query, then a
        // cache-write) for a benefit — a repeat view of the same listing
        // within the 60s TTL — that's rare on typical traffic. This was a
        // genuine, measured-in-hindsight regression: skip the cache layer
        // entirely when no object cache is detected, falling through to
        // the exact original single query with zero added overhead.
        $_use_listing_cache = function_exists( 'wp_using_ext_object_cache' ) && wp_using_ext_object_cache();
        $_listing_cache_key = "listing:slug:{$slug}";
        $listing = $_use_listing_cache ? \GoodService\Core\Cache::get( $_listing_cache_key ) : null;
        if ( $listing === null ) {
        $listing = $wpdb->get_row( $wpdb->prepare(
            "SELECT l.id, l.listing_uid, l.vendor_id, l.listing_type, l.title, l.slug, l.tagline, l.short_desc, l.full_desc,
                    l.category_id, l.subcategory_id, l.tags, l.price_min, l.price_max, l.price_unit,
                    l.city, l.state, l.pincode, l.address, l.map_embed, l.service_cities, l.lat, l.lng,
                    l.phone, l.whatsapp, l.email, l.website, l.banner_url, l.logo_url, l.gallery, l.video_url,
                    l.services_data, l.products_data, l.process_data, l.faq_data, l.why_choose_data, l.stats_data,
                    l.service_categories, l.product_categories,
                    l.highlights, l.certifications, l.awards, l.established_year, l.team_size, l.opening_hours,
                    l.layout_id, l.form_data, l.hero_data, l.about_data, l.items_data, l.feedback_data, l.footer_data,
                    l.customizer_data, l.mobile_data, l.trust_bar_text,
                    vp.social_links,
                    l.inquiry_modules_data, l.sections_visible_data,
                    l.swiper_enabled, l.swiper_settings, l.hero_layout,
                    l.seo_title, l.seo_desc, l.seo_keywords, l.seo_focus_keyword, l.og_image, l.seo_robots,
                    l.status, l.rejection_reason, l.is_featured, l.is_verified, l.is_claimed,
                    l.views_count, l.leads_count, l.avg_rating, l.review_count, l.expires_at,
                    l.custom_css, l.created_at, l.updated_at,
                    l.highlights_data, l.amenities_data, l.facilities_data, l.awards_data, l.languages_data,
                    l.packages_data, l.memberships_data, l.certifications_data, l.warranty_data, l.terms_data,
                    c.name AS cat_name, c.slug AS cat_slug, c.icon_emoji AS cat_icon,
                    vp.id AS vp_id,
                    vp.slug AS vendor_slug, vp.user_id AS vendor_user_id,
                    vp.verification_status, vp.trust_score, vp.is_active AS vendor_is_active,
                    sc.name AS subcat_name
             FROM {$pfx}listings l
             LEFT JOIN {$pfx}categories c ON c.id = l.category_id
             LEFT JOIN {$pfx}categories sc ON sc.id = l.subcategory_id
             LEFT JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
             WHERE l.slug = %s AND l.status IN('active','pending','draft')", $slug
        ) );
        // Only cache genuinely active, fully-public listings — never a
        // draft or pending one being previewed by its owner — and only
        // when a real object cache makes this worthwhile.
        if ( $_use_listing_cache && $listing && isset( $listing->status ) && $listing->status === 'active' ) {
            \GoodService\Core\Cache::set( $_listing_cache_key, $listing, 60 );
        }
        }

        if ( ! $listing ) { wp_redirect( home_url( '/directory/' ) ); exit; }

        // Real gap fix: suspendVendor() sets vendor_profiles.is_active=0, and
        // searchListings() already respects this (vp.is_active=1 in its WHERE),
        // but this direct listing URL had zero check for it — a suspended
        // vendor's listing remained fully live and bookable via any old shared
        // link, bookmark, or previously-indexed search result. No owner-preview
        // exception here (unlike the draft-status check below) since suspension
        // is a trust-and-safety enforcement action, not an in-progress draft.
        if ( isset( $listing->vendor_is_active ) && (int) $listing->vendor_is_active === 0 ) {
            wp_redirect( home_url( '/directory/' ) ); exit;
        }

        // ── Premium-section emptiness check — five small numbers, not five
        //    blocks of saved content. A value of 2 or less (NULL, '', '[]',
        //    or '{}') means "genuinely empty" — confirmed directly:
        //    json_encode([]) === '[]' (2 chars), json_encode((object)[]) ===
        //    '{}' (2 chars) — so this threshold correctly treats every real
        //    "nothing saved here" form as empty without ever transferring
        //    the actual (potentially large) content for sections nobody
        //    filled in.
        $premium_lengths = $wpdb->get_row( $wpdb->prepare(
            "SELECT LENGTH(team_data) AS l_team, LENGTH(clients_data) AS l_clients,
                    LENGTH(pricing_data) AS l_pricing, LENGTH(portfolio_data) AS l_portfolio,
                    LENGTH(testimonials_data) AS l_testimonials
             FROM {$pfx}listings WHERE id = %d", $listing->id
        ) );
        $premium_has_content = [
            'team_data'         => $premium_lengths && (int) $premium_lengths->l_team > 2,
            'clients_data'      => $premium_lengths && (int) $premium_lengths->l_clients > 2,
            'pricing_data'      => $premium_lengths && (int) $premium_lengths->l_pricing > 2,
            'portfolio_data'    => $premium_lengths && (int) $premium_lengths->l_portfolio > 2,
            'testimonials_data' => $premium_lengths && (int) $premium_lengths->l_testimonials > 2,
        ];
        // Always set these to an empty array on $listing for now — they'll
        // be filled in with the REAL content (only for sections that are
        // actually non-empty) right before the page draws them, much
        // further down this same template. Anything checking
        // !empty($listing->team_data) etc. between here and that point
        // would incorrectly see "empty" even for a genuinely filled-in
        // section — fetch_premium_section_content() below is what actually
        // resolves this correctly when it's needed.
        foreach ( $premium_has_content as $field => $has_content ) {
            $listing->$field = [];
        }
        $listing->_premium_has_content = $premium_has_content; // used by vendor-site.php to decide what to fetch and when

        // Draft listings: only visible to owner or admin — redirect others
        if ( $listing->status === 'draft' ) {
            if ( ! is_user_logged_in() ) { wp_redirect( home_url( '/vendor/login/' ) ); exit; }
            $current_uid = get_current_user_id();
            $is_owner    = ( (int)( $listing->vendor_user_id ?? 0 ) === $current_uid );
            $is_admin    = current_user_can( 'manage_options' );
            if ( ! $is_owner && ! $is_admin ) { wp_redirect( home_url( '/directory/' ) ); exit; }
        }

        // Decode all JSON fields from the LISTING only (no vendor data overrides)
        $json_fields = [
            'gallery','services_data','products_data','process_data','faq_data',
            'why_choose_data','stats_data','hero_data','about_data','items_data',
            'feedback_data','footer_data','service_cities','opening_hours',
            'customizer_data','mobile_data',
            'team_data','clients_data','pricing_data','portfolio_data','testimonials_data',
        ];
        foreach ( $json_fields as $f ) {
            if ( isset( $listing->$f ) && is_string( $listing->$f ) ) {
                $listing->$f = json_decode( $listing->$f ?? '[]', true ) ?: [];
            } elseif ( ! isset( $listing->$f ) ) {
                $listing->$f = [];
            }
        }

        // Build $vendor object ONLY from listing fields (strict Listing-first architecture)
        // The user/vendor identity is NEVER surfaced on the listing frontend
        $vendor = new \stdClass();
        $vendor->id                  = $listing->vp_id ?? $listing->vendor_id ?? 0;
        $vendor->business_name       = $listing->title; // Listing name, NOT user/vendor name
        $vendor->slug                = $listing->vendor_slug ?? '';
        $vendor->logo_url            = $listing->logo_url ?? '';
        $vendor->cover_url           = $listing->banner_url ?? '';
        $vendor->phone               = $listing->phone ?? '';
        $vendor->whatsapp            = $listing->whatsapp ?? '';
        $vendor->email               = $listing->email ?? '';
        $vendor->website             = $listing->website ?? '';
        $vendor->bio                 = $listing->full_desc ?: ( $listing->short_desc ?? '' );
        $vendor->city                = $listing->city ?? '';
        $vendor->state               = $listing->state ?? '';
        $vendor->address             = $listing->address ?? '';
        $vendor->verification_status = $listing->verification_status ?? 'unverified';
        $vendor->trust_score         = $listing->trust_score ?? 0;
        $vendor->user_id             = $listing->vendor_user_id ?? 0;
        // Social from listing only
        $vendor->social_links = [];
        if ( ! empty( $listing->social_links ) ) {
            $sl = is_string( $listing->social_links )
                ? ( json_decode( $listing->social_links, true ) ?: [] )
                : $listing->social_links;
            if ( is_array( $sl ) ) $vendor->social_links = $sl;
        }
        $vendor->profile_data = [];

        // vendor-site.php expects $listings array and $primary
        $listings = [ $listing ];
        $primary  = $listing;

        // Real performance fix: reviews are queried unconditionally on
        // every page load below, regardless of whether the Reviews
        // section is even visible — confirmed as a real, wasted query
        // via a deep audit request. Gating this safely is less trivial
        // than the premium-section fetches (Team/Clients/Pricing/etc,
        // fixed directly in vendor-site.php): $_sec_show() itself is
        // defined INSIDE vendor-site.php using data not yet available
        // here, and this query's result feeds THREE independent
        // consumers, not one — the Reviews section itself, the SEO
        // aggregateRating schema built later in this method, AND the
        // About section's own small "Avg Rating" stat badge (confirmed
        // by checking every reference to $review_avg directly, not
        // assumed — About reads it independently at
        // vendor-site.php:4127, in a completely different render
        // callback from the Reviews section's own). Gating on Reviews'
        // visibility alone would have silently broken About's rating
        // badge for any vendor who hides only the Reviews section while
        // keeping About visible — a real regression, caught by tracing
        // every consumer before shipping this, not after. The query now
        // runs if EITHER Reviews or About is visible; skipped only when
        // a vendor has hidden both (About is close to universally
        // visible in practice, so this remains a real, if narrower,
        // optimization for the case it correctly covers, without ever
        // changing behavior for the common case).
        $_reviews_svd = json_decode( (string) ( $listing->sections_visible_data ?? '{}' ), true ) ?: [];
        $_reviews_cd  = json_decode( (string) ( $listing->customizer_data ?? '{}' ), true ) ?: [];
        $_reviews_legacy_visible = is_array( $_reviews_cd['sections_visible'] ?? null ) ? $_reviews_cd['sections_visible'] : [];
        $_resolve_sec_visible = function ( string $key ) use ( $_reviews_svd, $_reviews_legacy_visible ): bool {
            if ( array_key_exists( $key, $_reviews_svd ) ) { return (bool) $_reviews_svd[ $key ]; }
            return isset( $_reviews_legacy_visible[ $key ] ) ? (bool) $_reviews_legacy_visible[ $key ] : true;
        };
        $_reviews_data_needed = $_resolve_sec_visible( 'reviews' ) || $_resolve_sec_visible( 'about' );

        // Real feature, page-speed priority 1: transient-caches the two
        // most expensive, least-frequently-changing queries on this page
        // — reviews and the average rating — with a short TTL as a safety
        // net, and real, precise invalidation the moment a review is
        // actually approved (see approveReview() in AjaxController.php).
        // Safer than combining these into the main listing JOIN, which
        // was deliberately avoided due to real risk of duplicate rows
        // from a one-to-many join breaking other logic that expects
        // $listing to stay a single row.
        if ( ! $_reviews_data_needed ) {
            $reviews = [];
            $review_avg = 0.0;
        } else {
        $_reviews_cache_key = 'gs_listing_reviews_' . $listing->id;
        $_cached_reviews = get_transient( $_reviews_cache_key );
        if ( $_cached_reviews !== false && is_array( $_cached_reviews ) ) {
            $reviews = $_cached_reviews['reviews'];
            $review_avg = $_cached_reviews['avg'];
        } else {
            $reviews = $wpdb->get_results( $wpdb->prepare(
                "SELECT r.*, u.display_name as wp_name
                 FROM {$pfx}reviews r
                 LEFT JOIN {$wpdb->prefix}users u ON u.ID = r.user_id
                 WHERE r.listing_id = %d AND r.status = 'approved'
                 ORDER BY r.helpful_count DESC, r.created_at DESC LIMIT 12",
                $listing->id
            ) );
            $review_avg = (float) $wpdb->get_var( $wpdb->prepare(
                "SELECT AVG(rating) FROM {$pfx}reviews WHERE listing_id = %d AND status = 'approved'",
                $listing->id
            ) );
            set_transient( $_reviews_cache_key, [ 'reviews' => $reviews, 'avg' => $review_avg ], 15 * MINUTE_IN_SECONDS );
        }
        }

        // Track view
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$pfx}listings SET views_count = views_count + 1 WHERE id = %d", $listing->id
        ) );

        $color   = Config::get( 'platform_color_primary', '#2563EB' );
        // $brand = listing title → vendor business_name → platform name → hardcoded literal
        // (never empty, never a hex color — every layer re-validated, including the
        // final fallback, which was previously unguarded).
        $is_hex_color = fn( string $s ): bool => (bool) preg_match( '/^#[0-9a-fA-F]{3,6}$/i', trim( $s ) );
        $raw_brand = trim( $listing->title ?? '' );
        if ( empty( $raw_brand ) || $is_hex_color( $raw_brand ) ) {
            // Fetch vendor business_name as fallback
            $fallback_vp = $wpdb->get_row( $wpdb->prepare(
                "SELECT business_name FROM {$pfx}vendor_profiles WHERE id = %d LIMIT 1",
                $listing->vendor_id ?? 0
            ) );
            $raw_brand = trim( $fallback_vp->business_name ?? '' );
        }
        if ( empty( $raw_brand ) || $is_hex_color( $raw_brand ) ) {
            $raw_brand = trim( (string) Config::get( 'platform_name', 'GoodService' ) );
        }
        // Real fix: this final check was missing entirely — if platform_name
        // itself were ever a hex color (e.g. through the exact class of bug
        // that corrupted this listing's title), nothing downstream would
        // have caught it. The ultimate fallback is a hardcoded literal,
        // which by construction cannot match the hex-color pattern.
        if ( empty( $raw_brand ) || $is_hex_color( $raw_brand ) ) {
            $raw_brand = 'GoodService';
        }
        $brand   = $raw_brand;
        // Real fix, the actual comprehensive correction: this is the
        // single point every consumer of $brand reads from afterward —
        // including vendor-site.php's WhatsApp popup, sticky bottom bar,
        // and breadcrumb (included ~170 lines below, with its entire
        // output captured into a buffer at that point — meaning a guard
        // placed only later, right before the <title> tag, would never
        // have covered any of those, since by then vendor-site.php had
        // already rendered using whatever $brand held at THIS point).
        // Placing it here means every downstream consumer, without
        // exception, sees the corrected value.
        $_last_chance_hex_check = fn( string $s ): bool => (bool) preg_match( '/^#[0-9a-fA-F]{3,6}$/i', trim( $s ) );
        if ( $_last_chance_hex_check( (string) $brand ) ) {
            $_ll_fallback = trim( (string) ( $listing->title ?? '' ) );
            if ( $_ll_fallback === '' || $_last_chance_hex_check( $_ll_fallback ) ) {
                $_ll_vp2 = $wpdb->get_row( $wpdb->prepare(
                    "SELECT business_name FROM {$pfx}vendor_profiles WHERE id = %d LIMIT 1",
                    $listing->vendor_id ?? 0
                ) );
                $_ll_fallback = trim( (string) ( $_ll_vp2->business_name ?? '' ) );
            }
            if ( $_ll_fallback === '' || $_last_chance_hex_check( $_ll_fallback ) ) {
                $_ll_fallback = trim( (string) Config::get( 'platform_name', 'GoodService' ) );
            }
            if ( $_ll_fallback === '' || $_last_chance_hex_check( $_ll_fallback ) ) {
                $_ll_fallback = 'GoodService';
            }
            $brand = $_ll_fallback;
        }
        $logo    = $listing->logo_url ?? '';
        $cover   = $listing->banner_url ?? '';
        $phone   = $listing->phone ?? '';
        $wa      = $listing->whatsapp ?? '';
        $email   = $listing->email ?? '';
        $city    = $listing->city ?? '';
        $address = $listing->address ?? '';

        // ── STABLE SYNTHETIC WP_POST FOR YELLOW PENCIL / CSS TOOLS ───────────────
        // Yellow Pencil and similar CSS tools scope their saved CSS to a post ID.
        // ── YELLOW PENCIL / CSS TOOL SCOPE SELECTOR ────────────────────────────────
        // Admin can choose between two CSS scopes while editing a vendor site:
        //
        //   "Vendor Site Template" (default) — all vendor sites share one synthetic
        //   post ID (gs_vendor_site_yp_id).  CSS applied here affects EVERY vendor site.
        //
        //   "Individual Vendor" — uses the real listing ID.  CSS applied here affects
        //   ONLY this vendor site.
        //
        // The choice is stored in cookie gs_yp_scope (set by the toggle button injected
        // into the page footer for logged-in admins).  Non-admins always get template scope
        // (no cookie is set, so the default branch runs).
        //
        // Yellow Pencil reads the post ID from WordPress globals during PHP render,
        // so the cookie must be read server-side here — a JS toggle alone cannot work.
        // ─────────────────────────────────────────────────────────────────────────────
        $gs_is_admin_editing = current_user_can( 'manage_options' );
        $gs_yp_scope = $gs_is_admin_editing
            ? sanitize_key( $_COOKIE['gs_yp_scope'] ?? 'template' )
            : 'template';
        // Only allow valid values — anything else falls back to template
        if ( ! in_array( $gs_yp_scope, [ 'template', 'individual' ], true ) ) {
            $gs_yp_scope = 'template';
        }

        if ( $gs_yp_scope === 'individual' ) {
            // ── INDIVIDUAL mode: use real listing ID ──────────────────────────────
            // YP scopes CSS to this specific listing only.
            // We build a minimal WP_Post from the listing data so YP can read its title
            // for the "editing: Kaagzaat Services" label in the pencil UI.
            $ind_post = new \WP_Post( (object) [
                'ID'             => (int) $listing->id,
                'post_type'      => 'page',
                'post_status'    => 'publish',
                'post_name'      => $listing->slug,
                'post_title'     => $listing->title,
                'post_content'   => '',
                'post_author'    => (int) ( $listing->vendor_user_id ?? 0 ),
                'post_date'      => $listing->created_at ?? current_time( 'mysql' ),
                'post_modified'  => $listing->updated_at ?? current_time( 'mysql' ),
                'comment_status' => 'closed',
                'ping_status'    => 'closed',
                'filter'         => 'raw',
            ] );
            wp_cache_set( (int) $listing->id, $ind_post, 'posts' );
            global $wp_query, $post;
            $wp_query->post              = $ind_post;
            $wp_query->posts             = [ $ind_post ];
            $wp_query->queried_object    = $ind_post;
            $wp_query->queried_object_id = (int) $listing->id;
            $wp_query->is_page           = true;
            $wp_query->is_singular       = true;
            $wp_query->is_home           = false;
            $wp_query->is_archive        = false;
            $wp_query->is_404            = false;
            $post = $ind_post;
            setup_postdata( $ind_post );
        } else {
            // ── TEMPLATE mode (default): shared synthetic post ID ─────────────────
            // All vendor sites share this one ID — CSS saved here applies everywhere.
            $vs_yp_id = (int) get_option( 'gs_vendor_site_yp_id', 0 );
            if ( ! $vs_yp_id ) {
                $vs_yp_id = 890001 + ( abs( crc32( get_site_url() . '-vs' ) ) % 9999 );
                update_option( 'gs_vendor_site_yp_id', $vs_yp_id, false );
            }
            $vs_synthetic = new \WP_Post( (object) [
                'ID'             => $vs_yp_id,
                'post_type'      => 'page',
                'post_status'    => 'publish',
                'post_name'      => 'vendor-site-template',
                'post_title'     => 'Vendor Site Template',
                'post_content'   => '',
                'post_author'    => 0,
                'post_date'      => current_time( 'mysql' ),
                'post_modified'  => current_time( 'mysql' ),
                'comment_status' => 'closed',
                'ping_status'    => 'closed',
                'filter'         => 'raw',
            ] );
            wp_cache_set( $vs_yp_id, $vs_synthetic, 'posts' );
            global $wp_query, $post;
            $wp_query->post              = $vs_synthetic;
            $wp_query->posts             = [ $vs_synthetic ];
            $wp_query->queried_object    = $vs_synthetic;
            $wp_query->queried_object_id = $vs_yp_id;
            $wp_query->is_page           = true;
            $wp_query->is_singular       = true;
            $wp_query->is_home           = false;
            $wp_query->is_archive        = false;
            $wp_query->is_404            = false;
            $post = $vs_synthetic;
            setup_postdata( $vs_synthetic );
        }

        // ── Add YP scope selector to the WP admin bar (admins only) ───────────────
        // Lives inside the existing black WP admin bar at the top — NOT a floating
        // overlay on the page content. Admin bar is already rendered via
        // $wp_admin_bar->render() below; we add our node before that call fires.
        // Cookie gs_yp_scope is read server-side (above) to set the WP_Post ID
        // so Yellow Pencil gets the correct scope on every page load.
        if ( $gs_is_admin_editing && $show_admin_bar ) {
            $gs_toggle_scope         = $gs_yp_scope;
            $gs_toggle_title         = $listing->title ?? 'This Vendor';
            add_action( 'admin_bar_menu', function( \WP_Admin_Bar $bar ) use ( $gs_toggle_scope, $gs_toggle_title ): void {
                $is_template  = ( $gs_toggle_scope === 'template' );
                $switch_mode  = $is_template ? 'individual' : 'template';
                $current_lbl  = $is_template ? '🌐 All Vendor Sites' : '👤 ' . $gs_toggle_title;
                $switch_lbl   = $is_template ? 'Switch to: This Vendor Only' : 'Switch to: All Vendor Sites';

                // Parent node — shows current scope label in the admin bar
                $bar->add_node( [
                    'id'    => 'gs-yp-scope',
                    'title' => '<span style="font-size:11px;color:#a0a5aa;margin-right:4px">YP:</span>'
                             . '<span style="color:#f0c040;font-weight:700">' . esc_html( $current_lbl ) . '</span>',
                    'href'  => '#',
                    'meta'  => [ 'onclick' => 'return false;' ],
                ] );

                // Child node — the switch link
                $bar->add_node( [
                    'parent' => 'gs-yp-scope',
                    'id'     => 'gs-yp-scope-switch',
                    'title'  => esc_html( $switch_lbl ),
                    'href'   => '#',
                    'meta'   => [
                        'onclick' => "document.cookie='gs_yp_scope={$switch_mode};path=/;max-age=86400;SameSite=Lax';location.reload();return false;",
                    ],
                ] );
            }, 999 );
        }

        // Real performance fix: this query previously ran unconditionally
        // on every page load, even when the Related Listings section is
        // hidden. Confirmed safe to gate directly (unlike Reviews just
        // above, which needed a wider check) — $related_listings has
        // exactly one consumer anywhere in the codebase, the Related
        // Listings section's own render, checked directly rather than
        // assumed. Same minimal $_sec_show() replica pattern as Reviews.
        $_related_svd = json_decode( (string) ( $listing->sections_visible_data ?? '{}' ), true ) ?: [];
        $_related_cd  = json_decode( (string) ( $listing->customizer_data ?? '{}' ), true ) ?: [];
        $_related_legacy_visible = is_array( $_related_cd['sections_visible'] ?? null ) ? $_related_cd['sections_visible'] : [];
        $_related_section_visible = array_key_exists( 'related_listings', $_related_svd )
            ? (bool) $_related_svd['related_listings']
            : ( isset( $_related_legacy_visible['related_listings'] ) ? (bool) $_related_legacy_visible['related_listings'] : true );

        // Real feature, priority 2 (internal linking): related/similar
        // listings — same category and/or city, excluding this listing.
        // Genuinely cacheable and low-risk since it's a completely
        // separate, additive query, not touching the main listing fetch.
        if ( ! $_related_section_visible ) {
            $related_listings = [];
        } else {
        $_related_cache_key = 'gs_related_listings_' . $listing->id;
        $related_listings = get_transient( $_related_cache_key );
        if ( $related_listings === false ) {
            $related_listings = $wpdb->get_results( $wpdb->prepare(
                "SELECT id, listing_uid, title, slug, city, logo_url, avg_rating, review_count, category_id
                 FROM {$pfx}listings
                 WHERE status = 'active' AND id != %d
                 AND ( category_id = %d OR city = %s )
                 ORDER BY ( category_id = %d AND city = %s ) DESC, avg_rating DESC, review_count DESC
                 LIMIT 6",
                $listing->id, (int) $listing->category_id, $listing->city ?? '',
                (int) $listing->category_id, $listing->city ?? ''
            ) );
            set_transient( $_related_cache_key, $related_listings, 30 * MINUTE_IN_SECONDS );
        }
        }

        // ── Allow plugins (Fluent Forms, etc.) to register their assets ──────────
        // This must happen BEFORE the page content is captured, so that shortcodes
        // like [fluentform] can enqueue their CSS/JS during render.
        try { do_action( 'wp_enqueue_scripts' ); } catch ( \Throwable $e ) { /* ignore plugin hook errors */ }

        ob_start();
        try {
            include GS_DIR . 'templates/pages/vendor-site.php';
        } catch ( \Throwable $e ) {
            echo self::error_html( $e );
        }
        $content = ob_get_clean();

        // ── Collect plugin-enqueued styles (Fluent Forms CSS etc.) for <head> ──
        ob_start();
        try { wp_print_styles(); } catch ( \Throwable $e ) {}
        $plugin_styles = ob_get_clean();

        // ── Collect plugin-enqueued scripts for before </body> ─────────────────
        // wp_print_scripts() = head-group scripts; wp_print_footer_scripts() = footer-group scripts.
        // We need both because plugins (inc. Fluent Forms) may register in either group.
        // Combining them and placing after jQuery ensures all dependencies are met.
        // Prevent duplicate jQuery — we load it manually; strip WP's copy from queue
        try {
            wp_dequeue_script( 'jquery' );
            wp_dequeue_script( 'jquery-core' );
            wp_dequeue_script( 'jquery-migrate' );
        } catch ( \Throwable $e ) {}

        ob_start();
        try { wp_print_footer_scripts(); } catch ( \Throwable $e ) {}    // footer scripts (Fluent Forms JS etc.)
        $plugin_scripts = ob_get_clean();

        // Real fix, closing the audit's minification gap safely: uses
        // gs_asset_url() to resolve the minified version only when it's
        // genuinely, verifiably newer than the source — the exact
        // protection the old comment on this line called for, now
        // actually implemented rather than avoiding minification entirely.
        $css_url = gs_asset_url( 'assets/css/goodservice.css' );
        $js_url  = gs_asset_url( 'assets/js/goodservice.js' );
        try { $js_config = wp_json_encode( Assets::js_config() ); }
        catch ( \Throwable $e ) { $js_config = '{}'; }

        // Guard: if seo_title was accidentally set to a hex colour code (e.g. '#f5a623'),
        // treat it as empty so the title falls back to the real listing title ($brand).
        // Real fix, the actual confirmed root cause of a long investigation: the
        // original guard only matched seo_title being PURELY a hex code
        // (anchored ^...$). If seo_title was ever persisted as the full,
        // already-broken SENTENCE — e.g. "Best Legal & Finance in DELHI — #2563EB",
        // not just the bare color — the anchored pattern never matched at
        // all, and that entire broken string was used verbatim as the
        // page title, completely bypassing $brand regardless of how clean
        // listing.title itself was. Checks for the platform's ACTUAL
        // configured color specifically (not any generic hex-shaped
        // substring, which would false-positive on legitimate titles like
        // "Room #123 Available Now" — verified directly against that
        // exact case before landing on this narrower check).
        $raw_seo_title = $listing->seo_title ?? '';
        $_platform_color_check = Config::get( 'platform_color_primary', '#2563EB' );
        if ( empty( $_platform_color_check ) ) { $_platform_color_check = '#2563EB'; } // Real fix: Config::get()'s default only applies to null, not empty string
        if ( preg_match( '/^#[0-9a-fA-F]{3,6}$/i', trim( $raw_seo_title ) )
            || ( $_platform_color_check && stripos( $raw_seo_title, $_platform_color_check ) !== false ) ) {
            $raw_seo_title = '';
        }
        $intent_category = $listing->subcat_name ?? $listing->cat_name ?? '';
        $intent_phrase   = \GoodService\Core\Helpers::intent_phrase( $intent_category, $city );
        if ( $raw_seo_title ) {
            // User-entered title — apply pixel trimming so it doesn't overflow Google's
            // SERP truncation limit even if the vendor typed past the form's counter.
            $seo_title = gs_enh_trim_to_pixel_width( $raw_seo_title, 580 );
        } else {
            // Real feature, item 2 from the audit: an optional,
            // admin-configurable title template — only actually used when
            // an admin has explicitly set a non-empty custom template.
            // When empty (the default), falls through completely
            // unchanged to the existing, already-sophisticated
            // intent_phrase-based fallback below — zero behavior change
            // for any installation that hasn't explicitly opted in.
            $_seo_tpl = trim( (string) \GoodService\Core\Config::get( 'seo_title_template', '' ) );
            if ( $_seo_tpl ) {
                $_seo_tpl_platform = \GoodService\Core\Config::get( 'platform_name', get_bloginfo( 'name' ) );
                $seo_title = gs_enh_trim_to_pixel_width( str_replace(
                    [ '{title}', '{city}', '{category}', '{platform}' ],
                    [ $brand, $city ?: '', $intent_category ?: '', $_seo_tpl_platform ],
                    $_seo_tpl
                ), 580 );
            } elseif ( $intent_phrase ) {
            $seo_title = gs_enh_trim_to_pixel_width( "{$intent_phrase} — {$brand}", 580 );
        } else {
            $seo_title = gs_enh_trim_to_pixel_width(
                $brand . ' — ' . ( $listing->tagline ?: $intent_category ) . ( $city ? ' in ' . $city : '' ),
                580
            );
            }
        }
        // Guard: if seo_desc was accidentally set to a hex colour code, use listing description
        $raw_seo_desc = $listing->seo_desc ?? '';
        if ( preg_match( '/^#[0-9a-fA-F]{3,6}$/i', trim( $raw_seo_desc ) ) ) { $raw_seo_desc = ''; }
        // wp_strip_all_tags on the short_desc fallback path — short_desc is saved via
        // sanitize_textarea_field but historical records may contain encoded HTML.
        // Stripping here ensures the meta description content attr is always plain text.
        $seo_desc = $raw_seo_desc
            ?: ( $listing->short_desc
                ? substr( wp_strip_all_tags( $listing->short_desc ), 0, 160 )
                : $brand );

        // ── Send no-cache headers so page caches never serve stale listing data ─
        nocache_headers();

        $_gs_html_cls = trim( (string) apply_filters( 'gs_html_class', '', 'listing' ) );
        echo '<!DOCTYPE html><html lang="en"' . ( $_gs_html_cls ? ' class="' . esc_attr( $_gs_html_cls ) . '"' : '' ) . '><head>';
        // Real fix — PageSpeed's "Properly defines charset" audit requires
        // the charset meta to be the very first element in <head>, before
        // any script; this used to echo the geolocation-block script
        // first, pushing charset one element too late. Order swapped,
        // nothing else changed.
        echo '<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
        echo '<script>try{if(window.navigator&&navigator.geolocation){navigator.geolocation.getCurrentPosition=function(){};navigator.geolocation.watchPosition=function(){return 0;}}}catch(e){}</script>';
        if ( $logo ) echo '<link rel="icon" href="' . esc_url( $logo ) . '">';
        // Real fix, per direct clarification: every "Download App" click —
        // including from a vendor listing page — should install the single,
        // shared GoodService platform app, not a separate per-vendor
        // mini-app. Uses the same shared platform manifest already used
        // correctly on the homepage, so installing from anywhere
        // consistently produces the same app.
        // Real fix: uses the REST API URL, not the rewrite-rule-based one —
        // eliminates the dependency on a rewrite-rules flush having
        // actually happened for this exact deployed version.
        // Real fix (v7.475.0): same REST-route-returns-empty-body issue
        // and same static-file fix as the homepage <link> above.
        echo '<meta name="gs-pwa-manifest-url" content="' . esc_attr( gs_pwa_manifest_url( 'client' ) ) . '">';
        echo '<meta name="apple-mobile-web-app-capable" content="yes">';
        echo '<meta name="apple-mobile-web-app-status-bar-style" content="default">';
        echo '<meta name="apple-mobile-web-app-title" content="GoodService">';
        // Real consistency fix: with the manifest and app name now correctly
        // set to the shared GoodService platform (not per-vendor), the
        // Apple touch icon must match — otherwise iOS users would see the
        // vendor's own logo paired with the name "GoodService" on their
        // home screen, a confusing mismatch for what installs as one app.
        // Real fix: uses the PHP-served icon route with a non-file-like
        // query parameter, not a path ending in .png — a path-based .png
        // URL was ALSO confirmed intercepted by this CDN's extension-based
        // rules, even for a dynamic route.
        echo '<link rel="apple-touch-icon" href="' . esc_url( add_query_arg( 'name', 'client-192', rest_url( 'goodservice/v1/icon' ) ) ) . '">';
        echo '<meta name="theme-color" content="#2563EB">';
        // Real fix: gated behind an admin-only debug flag rather than
        // shipping unconditionally on every page view — the diagnostic
        // capability that resolved this investigation stays available
        // for future use, but regular visitors and search engines never
        // see it, addressing the legitimate concern that leaving this on
        // forever adds bytes and exposes internal state on every page.
        if ( isset( $_GET['gs_debug'] ) && current_user_can( 'manage_options' ) ) {
            echo '<!-- GS-ROUTER-MARKER v' . esc_html( defined( 'GS_VERSION' ) ? GS_VERSION : 'unknown' ) . ' -->';
        }
        // Real fix, correcting a genuine bug found directly from this
        // investigation's own evidence: the previous version of this
        // check only matched $seo_title being PURELY a hex code
        // (anchored ^...$) — but it's a full sentence containing one
        // ("...— #2563EB"), so that pattern silently never fired. This
        // is the exact same class of mistake already found and fixed
        // once before in the original seo_title guard, reintroduced
        // here by an earlier simplification. Checks whether the
        // platform's actual configured color appears ANYWHERE in the
        // value now, and rebuilds every downstream value fresh — placed
        // at the one location in this file directly proven, via the
        // marker itself, to run the current code.
        $_platform_color_lc = Config::get( 'platform_color_primary', '#2563EB' );
        if ( empty( $_platform_color_lc ) ) { $_platform_color_lc = '#2563EB'; } // Real fix: Config::get()'s default only applies to null, not empty string
        $_is_corrupted = fn( $v ) => $v !== null && $v !== '' && $_platform_color_lc && stripos( (string) $v, $_platform_color_lc ) !== false;
        if ( $_is_corrupted( $brand ) || $_is_corrupted( $seo_title ) || $_is_corrupted( $seo_desc ?? '' ) ) {
            $_lc_fallback = trim( (string) ( $listing->title ?? '' ) );
            if ( $_lc_fallback === '' || $_is_corrupted( $_lc_fallback ) ) {
                $_lc_vp = $wpdb->get_row( $wpdb->prepare(
                    "SELECT business_name FROM {$pfx}vendor_profiles WHERE id = %d LIMIT 1",
                    $listing->vendor_id ?? 0
                ) );
                $_lc_fallback = trim( (string) ( $_lc_vp->business_name ?? '' ) );
            }
            if ( $_lc_fallback === '' || $_is_corrupted( $_lc_fallback ) ) {
                $_lc_fallback = trim( (string) Config::get( 'platform_name', 'GoodService' ) );
            }
            if ( $_lc_fallback === '' || $_is_corrupted( $_lc_fallback ) ) {
                $_lc_fallback = 'GoodService';
            }
            $brand = $_lc_fallback;
            $seo_title = $intent_phrase ? gs_enh_trim_to_pixel_width( "{$intent_phrase} — {$brand}", 580 ) : $brand;
            $seo_desc  = $brand . ( $listing->tagline ? ' — ' . $listing->tagline : '' ) . ( $city ? ' in ' . $city : '' );
        }
        // SEO Search Entry URL: use the keyword-specific title/description
        // generated by SeoEntryService instead of the primary microsite's —
        // this is what makes /{slug}/{keyword}/ a genuine, differentiated
        // entry point rather than a copy of /{slug}/ with a different URL
        // (Part 16, 18, 28).
        if ( $seo_entry ) {
            if ( ! empty( $seo_entry->title ) )            { $seo_title = $seo_entry->title; }
            if ( ! empty( $seo_entry->meta_description ) ) { $seo_desc  = $seo_entry->meta_description; }
        }
        echo '<title>' . esc_html( $seo_title ) . '</title>';
        echo '<meta name="description" content="' . esc_attr( $seo_desc ) . '">';
        // ── Enhanced SEO meta tags ─────────────────────────────────────────────
        if ( ! empty( $listing->seo_keywords ) ) {
            echo '<meta name="keywords" content="' . esc_attr( $listing->seo_keywords ) . '">';
        } else {
            // Auto-generate keywords from listing data
            $auto_kw = array_filter( [ $brand, $listing->cat_name??'', $city, $listing->state??'', $listing->tags??'' ] );
            echo '<meta name="keywords" content="' . esc_attr( implode( ', ', $auto_kw ) ) . '">';
        }
        $robots = $listing->seo_robots ?? 'index,follow';
        echo '<meta name="robots" content="' . esc_attr( $robots ) . '">';
        // OG tags
        // Gallery-aware image selection: the listing's own featured (or
        // first) gallery photo now wins over the generic banner when no
        // explicit og_image override is set — a more relevant "share photo"
        // for platforms that use it (banner/logo remain the fallback when
        // there's no gallery at all).
        $_og_gallery = [];
        if ( ! empty( $listing->gallery ) ) {
            $_og_gallery_raw = is_array( $listing->gallery ) ? $listing->gallery : json_decode( (string) $listing->gallery, true );
            if ( is_array( $_og_gallery_raw ) ) {
                // Featured image first, then the rest in their saved order.
                usort( $_og_gallery_raw, function( $a, $b ) {
                    $af = is_array( $a ) ? ! empty( $a['featured'] ) : false;
                    $bf = is_array( $b ) ? ! empty( $b['featured'] ) : false;
                    return ( $bf ? 1 : 0 ) <=> ( $af ? 1 : 0 );
                } );
                foreach ( $_og_gallery_raw as $_og_g ) {
                    $_og_gurl = is_array( $_og_g ) ? ( $_og_g['url'] ?? '' ) : $_og_g;
                    if ( $_og_gurl ) { $_og_gallery[] = $_og_gurl; }
                }
            }
        }
        $og_img = ! empty( $listing->og_image )
            ? $listing->og_image
            : ( $_og_gallery[0] ?? ( $cover ?: $logo ?: ( \GoodService\Core\Config::get( 'seo_default_og_image', '' ) ?: get_site_icon_url( 512 ) ?: '' ) ) );
        echo '<meta property="og:type" content="website">';
        echo '<meta property="og:locale" content="en_IN">';
        echo '<meta property="og:title" content="' . esc_attr( $seo_title ) . '">';
        echo '<meta property="og:description" content="' . esc_attr( $seo_desc ) . '">';
        if ( $og_img ) {
            echo '<meta property="og:image" content="' . esc_url( $og_img ) . '">';
            echo '<meta property="og:image:alt" content="' . esc_attr( $brand ) . '">';
            // Real feature, item 8 from the audit: og:image width/height —
            // cached via transient (long TTL; image dimensions essentially
            // never change once uploaded) so the actual remote
            // getimagesize() fetch only ever happens once per image, not
            // on every single page view of this high-traffic page. Fails
            // silently if the fetch doesn't succeed — no broken tag, no
            // blocking the rest of the page.
            $_og_dim_cache_key = 'gs_og_dim_' . md5( $og_img );
            $_og_dim = get_transient( $_og_dim_cache_key );
            if ( $_og_dim === false ) {
                $_og_dim = @getimagesize( $og_img ) ?: [ 0, 0 ];
                set_transient( $_og_dim_cache_key, $_og_dim, 30 * DAY_IN_SECONDS );
            }
            if ( ! empty( $_og_dim[0] ) && ! empty( $_og_dim[1] ) ) {
                echo '<meta property="og:image:width" content="' . (int) $_og_dim[0] . '">';
                echo '<meta property="og:image:height" content="' . (int) $_og_dim[1] . '">';
            }
            // Extra og:image tags (up to 3 more gallery photos). IMPORTANT,
            // and explained to the user directly: this is NOT a slider —
            // no chat app (WhatsApp, Telegram, iMessage) supports a
            // multi-image carousel from a single shared link; each only
            // ever renders the FIRST og:image. These extra tags are picked
            // up only by the platforms that do use them (Facebook's own
            // "create post from link" photo picker, Slack/Discord
            // unfurls sometimes offer them), as a bonus with zero downside
            // for platforms that ignore them.
            $_og_extra = array_slice( array_diff( $_og_gallery, [ $og_img ] ), 0, 3 );
            foreach ( $_og_extra as $_og_extra_img ) {
                echo '<meta property="og:image" content="' . esc_url( $_og_extra_img ) . '">';
            }
        }
        // Self-referencing canonical (Part 15): a genuine SEO Search Entry
        // URL canonicalizes to ITSELF, never automatically to the primary
        // microsite — /{slug}/ keeps its own separate self-referencing
        // canonical below, completely unaffected by this branch.
        $canonical = ( $seo_entry && ! empty( $seo_entry->canonical_url ) )
            ? $seo_entry->canonical_url
            : home_url( '/' . ltrim( $listing->slug, '/' ) . '/' );
        // Safety guard: Facebook (and several other crawlers) treat og:url as
        // the ACTUAL destination a click lands on — not just a label — so a
        // bad value here (a stale DB row, an admin paste-error into an SEO
        // override field, a caching bug) silently hijacks every future click
        // on anything already shared, even though the visible share buttons
        // themselves are correct. og:url must always be our own domain;
        // if it somehow isn't, fall back to the safe self-built URL instead
        // of ever publishing an off-site (e.g. wa.me/WhatsApp) address here.
        $_home_host = parse_url( home_url(), PHP_URL_HOST );
        $_can_host  = parse_url( (string) $canonical, PHP_URL_HOST );
        if ( ! $_can_host || strcasecmp( $_can_host, (string) $_home_host ) !== 0 ) {
            $canonical = home_url( '/' . ltrim( $listing->slug, '/' ) . '/' );
        }
        echo '<meta property="og:url" content="' . esc_url( $canonical ) . '">';
        echo '<meta property="og:site_name" content="' . esc_attr( Config::get('platform_name','GoodService') ) . '">';
        // Twitter Card
        echo '<meta name="twitter:card" content="summary_large_image">';
        echo '<meta name="twitter:title" content="' . esc_attr( $seo_title ) . '">';
        echo '<meta name="twitter:description" content="' . esc_attr( $seo_desc ) . '">';
        if ( $og_img ) {
            echo '<meta name="twitter:image" content="' . esc_url( $og_img ) . '">';
            echo '<meta name="twitter:image:alt" content="' . esc_attr( $brand ) . '">';
        }
        // JSON-LD LocalBusiness schema
        // Map category to a specific schema.org LocalBusiness subtype where one
        // exists — Google explicitly states more specific types improve rich result
        // eligibility. Falls back to LocalBusiness for unmapped categories.
        $cat_slug_lc  = strtolower( $listing->cat_slug ?? $listing->cat_name ?? '' );
        $schema_type_map = [
            'plumber'             => 'Plumber',
            'plumbing'            => 'Plumber',
            'electrician'         => 'Electrician',
            'electrical'          => 'Electrician',
            'locksmith'           => 'Locksmith',
            'lawyer'              => 'LegalService',
            'legal'               => 'LegalService',
            'advocate'            => 'LegalService',
            'ca'                  => 'AccountingService',
            'accountant'          => 'AccountingService',
            'accounting'          => 'AccountingService',
            'doctor'              => 'Physician',
            'physician'           => 'Physician',
            'dentist'             => 'Dentist',
            'dental'              => 'Dentist',
            'hospital'            => 'Hospital',
            'clinic'              => 'MedicalClinic',
            'veterinarian'        => 'Veterinarian',
            'vet'                 => 'Veterinarian',
            'architect'           => 'ProfessionalService',
            'interior'            => 'HomeAndConstructionBusiness',
            'interior-designer'   => 'HomeAndConstructionBusiness',
            'construction'        => 'HomeAndConstructionBusiness',
            'contractor'          => 'HomeAndConstructionBusiness',
            'painter'             => 'HomeAndConstructionBusiness',
            'carpentry'           => 'HomeAndConstructionBusiness',
            'carpenter'           => 'HomeAndConstructionBusiness',
            'pest-control'        => 'HomeAndConstructionBusiness',
            'cleaning'            => 'HomeAndConstructionBusiness',
            'salon'               => 'HairSalon',
            'hair'                => 'HairSalon',
            'beauty'              => 'BeautySalon',
            'spa'                 => 'DaySpa',
            'gym'                 => 'ExerciseGym',
            'fitness'             => 'ExerciseGym',
            'yoga'                => 'SportsActivityLocation',
            'restaurant'          => 'Restaurant',
            'food'                => 'FoodEstablishment',
            'catering'            => 'FoodEstablishment',
            'bakery'              => 'Bakery',
            'travel'              => 'TravelAgency',
            'tour'                => 'TouristInformationCenter',
            'school'              => 'School',
            'coaching'            => 'EducationalOrganization',
            'tutor'               => 'EducationalOrganization',
            'bank'                => 'BankOrCreditUnion',
            'insurance'           => 'InsuranceAgency',
            'real-estate'         => 'RealEstateAgent',
            'property'            => 'RealEstateAgent',
            'car'                 => 'AutoDealer',
            'auto'                => 'AutomotiveBusiness',
            'garage'              => 'AutoRepair',
            'mechanic'            => 'AutoRepair',
            'hospital'            => 'Hospital',
            'pharmacy'            => 'Pharmacy',
            'hotel'               => 'LodgingBusiness',
            'photographer'        => 'ProfessionalService',
            'photography'         => 'ProfessionalService',
            'it'                  => 'ProfessionalService',
            'software'            => 'ProfessionalService',
            'digital-marketing'   => 'ProfessionalService',
        ];
        $lb_type = 'LocalBusiness';
        foreach ( $schema_type_map as $pattern => $type ) {
            if ( str_contains( $cat_slug_lc, $pattern ) ) {
                $lb_type = $type;
                break;
            }
        }
        $schema = [
            '@context'    => 'https://schema.org',
            '@type'       => $lb_type,
            'name'        => $brand,
            'description' => $seo_desc,
            'url'         => $canonical,
            '@id'         => $canonical,
        ];
        if ( $phone )   $schema['telephone'] = $phone;
        if ( $email )   $schema['email']     = $email;
        if ( $address ) {
            $postal_addr = [
                '@type'          => 'PostalAddress',
                'streetAddress'  => $address,
                'addressLocality'=> $city,
                'addressRegion'  => $listing->state ?? '',
                'addressCountry' => 'IN',
            ];
            if ( ! empty( $listing->pincode ) ) {
                $postal_addr['postalCode'] = $listing->pincode;
            }
            $schema['address'] = $postal_addr;
        }
        if ( ! empty( $listing->lat ) && ! empty( $listing->lng ) ) {
            $schema['geo'] = [ '@type' => 'GeoCoordinates', 'latitude' => (float) $listing->lat, 'longitude' => (float) $listing->lng ];
        }
        // Opening hours — handles both real DECODED data shapes in this
        // codebase (confirmed via vendor-site.php's own comment):
        // create-listing.php saves {"monday":{"open":"09:00","close":"18:00",
        // "closed":false}}, vendor-dashboard.php saves
        // {"monday":"09:00 - 18:00"}. $listing->opening_hours is already a
        // decoded PHP array by this point (an earlier loop in this same
        // function handles that) — the is_string() check below is
        // defensive only, for a case that can't currently occur here.
        // Using openingHoursSpecification (Google's documented, preferred
        // format) rather than the plain-text openingHours property, since
        // it's more reliable for AI assistants and "is it open now" queries.
        $oh_raw = is_string( $listing->opening_hours ?? null ) ? json_decode( $listing->opening_hours, true ) : ( $listing->opening_hours ?? null );
        if ( is_array( $oh_raw ) ) {
            $day_names = [ 'monday'=>'Monday','tuesday'=>'Tuesday','wednesday'=>'Wednesday','thursday'=>'Thursday','friday'=>'Friday','saturday'=>'Saturday','sunday'=>'Sunday' ];
            $oh_spec = [];
            foreach ( $day_names as $key => $name ) {
                $day_val = $oh_raw[ $key ] ?? null;
                if ( ! $day_val ) { continue; }
                $opens = $closes = null;
                if ( is_array( $day_val ) ) {
                    if ( ! empty( $day_val['closed'] ) ) { continue; }
                    $opens  = $day_val['open']  ?? null;
                    $closes = $day_val['close'] ?? null;
                } elseif ( is_string( $day_val ) && preg_match( '/(\d{1,2}:\d{2})\s*-\s*(\d{1,2}:\d{2})/', $day_val, $m ) ) {
                    $opens  = $m[1];
                    $closes = $m[2];
                }
                if ( $opens && $closes ) {
                    $oh_spec[] = [ '@type' => 'OpeningHoursSpecification', 'dayOfWeek' => $name, 'opens' => $opens, 'closes' => $closes ];
                }
            }
            if ( $oh_spec ) { $schema['openingHoursSpecification'] = $oh_spec; }
        } // end if ( is_array( $oh_raw ) )

        // Real feature, item 5 from the audit: Product/Offer schema for
        // listings that actually sell products — only queried and only
        // added for listing_type 'product' or 'both', so service-only
        // listings (the majority) incur zero additional query cost and
        // zero schema change.
        try {
            if ( in_array( $listing->listing_type ?? 'service', [ 'product', 'both' ], true ) ) {
                $_products = $wpdb->get_results( $wpdb->prepare(
                    "SELECT name, description, price, price_type, image_url, stock FROM {$pfx}products
                     WHERE listing_id = %d AND is_active = 1 ORDER BY sort_order ASC LIMIT 50",
                    $listing->id
                ) );
                if ( $_products ) {
                    $schema['hasOfferCatalog'] = [
                        '@type' => 'OfferCatalog',
                        'name'  => 'Products & Services',
                        'itemListElement' => array_map( function( $p ) {
                            $offer = [
                                '@type' => 'Offer',
                                'itemOffered' => [ '@type' => 'Product', 'name' => $p->name ?: 'Product' ]
                                    + ( $p->description ? [ 'description' => wp_strip_all_tags( $p->description ) ] : [] )
                                    + ( $p->image_url ? [ 'image' => $p->image_url ] : [] ),
                                'availability' => ( (int) $p->stock === 0 ) ? 'https://schema.org/OutOfStock' : 'https://schema.org/InStock',
                            ];
                            if ( $p->price && (float) $p->price > 0 ) {
                                $offer['price'] = (string) round( (float) $p->price, 2 );
                                $offer['priceCurrency'] = 'INR';
                            }
                            return $offer;
                        }, $_products ),
                    ];
                }
            }
        } catch ( \Throwable $e ) {
            // Never let a product-schema failure break the rest of the
            // page's SEO output, which is more valuable than this one
            // addition — the same defensive posture already used for the
            // FAQ/breadcrumb schema blocks elsewhere in this function.
        }

        // Real feature, item C from the follow-up audit: VideoObject
        // schema for listings with a video set, using the real,
        // already-queried listing-level video_url field.
        try {
            $_video_url = trim( (string) ( $listing->video_url ?? '' ) );
            if ( $_video_url ) {
                $_video_schema = [
                    '@type' => 'VideoObject',
                    'name'  => ( $listing->title ?? 'Business' ) . ' — Video',
                    'description' => wp_strip_all_tags( $listing->tagline ?: $listing->short_desc ?: ( $listing->title ?? '' ) ),
                    'uploadDate' => date( 'c', strtotime( $listing->created_at ?? 'now' ) ),
                ];
                // YouTube/Vimeo links are third-party-hosted — schema.org's
                // own guidance is embedUrl for these, contentUrl for a
                // direct video file. A thumbnailUrl is required by Google's
                // rich-result guidelines; YouTube's own thumbnail CDN gives
                // us one for free without an extra API call.
                if ( preg_match( '#youtube\.com/watch\?v=([\w\-]+)#', $_video_url, $_ytm ) || preg_match( '#youtu\.be/([\w\-]+)#', $_video_url, $_ytm ) ) {
                    $_video_schema['embedUrl'] = 'https://www.youtube.com/embed/' . $_ytm[1];
                    $_video_schema['thumbnailUrl'] = [ 'https://i.ytimg.com/vi/' . $_ytm[1] . '/hqdefault.jpg' ];
                } elseif ( preg_match( '#vimeo\.com/(\d+)#', $_video_url, $_vim ) ) {
                    $_video_schema['embedUrl'] = 'https://player.vimeo.com/video/' . $_vim[1];
                    $_video_schema['thumbnailUrl'] = [ $og_img ?: $listing->logo_url ?? '' ];
                } else {
                    $_video_schema['contentUrl'] = $_video_url;
                    $_video_schema['thumbnailUrl'] = [ $og_img ?: $listing->logo_url ?? '' ];
                }
                if ( ! empty( $_video_schema['thumbnailUrl'][0] ) ) {
                    $schema['video'] = $_video_schema;
                }
            }
        } catch ( \Throwable $e ) {
            // Same defensive posture as the product schema block above —
            // never let this break the rest of the page's SEO output.
        }

        // sameAs — runs for every listing regardless of whether opening hours
        // data exists. Was previously inside the opening hours if block (bug:
        // listings with no hours data never got sameAs even with social links).
        $sl = is_array( $vendor->social_links ?? null ) ? $vendor->social_links : [];
        $same_as = [];
        foreach ( [ 'facebook','fb','instagram','linkedin','twitter','x','youtube' ] as $net ) {
            if ( ! empty( $sl[ $net ] ) && filter_var( $sl[ $net ], FILTER_VALIDATE_URL ) ) {
                $same_as[] = $sl[ $net ];
            }
        }
        if ( $same_as ) { $schema['sameAs'] = array_values( array_unique( $same_as ) ); }

        if ( $logo )    $schema['image']     = $logo;
        if ( $listing->established_year??null ) $schema['foundingDate'] = $listing->established_year;
        if ( $review_avg > 0 && count($reviews) > 0 ) {
            // reviewCount must reflect the TOTAL number of approved reviews,
            // not count($reviews) which is capped at LIMIT 12 in the query.
            // $listing->review_count is the denormalised total stored on the
            // listing row — already fetched and accurate.
            $total_review_count = max( (int)( $listing->review_count ?? 0 ), count( $reviews ) );
            $schema['aggregateRating'] = [ '@type'=>'AggregateRating','ratingValue'=>round($review_avg,1),'reviewCount'=>$total_review_count,'bestRating'=>5,'worstRating'=>1 ];
            // Part 26.3 — Review rich snippets (top 3 approved reviews)
            $schema['review'] = [];
            foreach ( array_slice( $reviews, 0, 3 ) as $rv ) {
                $schema['review'][] = [
                    '@type'         => 'Review',
                    'author'        => [ '@type' => 'Person', 'name' => esc_html( $rv->name ?? 'Customer' ) ],
                    'datePublished' => date( 'Y-m-d', strtotime( $rv->created_at ?? 'now' ) ),
                    'reviewRating'  => [ '@type' => 'Rating', 'ratingValue' => (int)( $rv->rating ?? 5 ), 'bestRating' => 5, 'worstRating' => 1 ],
                    'reviewBody'    => esc_html( wp_strip_all_tags( $rv->comment ?? '' ) ),
                ];
            }
        }
        // FAQPage schema if FAQ data exists
        if ( ! empty( $listing->faq_data ) ) {
            $faq_schema = [ '@context'=>'https://schema.org', '@type'=>'FAQPage', 'mainEntity'=>[] ];
            foreach ( $listing->faq_data as $fq ) {
                if ( empty($fq['question']) ) continue;
                $faq_schema['mainEntity'][] = [ '@type'=>'Question','name'=>$fq['question'],'acceptedAnswer'=>['@type'=>'Answer','text'=>wp_strip_all_tags($fq['answer']??'')] ];
            }
            if ( ! empty($faq_schema['mainEntity']) ) {
                echo '<script type="application/ld+json">' . wp_json_encode($faq_schema, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) . '</script>';
            }
        }
        // Real feature, item 5 from the audit: Product schema for
        // product-type listings. Deliberately no Offer/price sub-schema —
        // no price field exists anywhere in the listings data model
        // (confirmed directly), and Google's rich-result eligibility
        // specifically requires a real price, not a placeholder one. This
        // is still valid, spec-compliant markup — "offers" is optional per
        // the base schema.org Product spec — adding real value without
        // fabricating data that doesn't exist.
        if ( in_array( $listing->listing_type ?? '', [ 'product', 'both' ], true ) ) {
            $product_schema = [
                '@context'    => 'https://schema.org',
                '@type'       => 'Product',
                'name'        => $brand,
                'description' => $seo_desc,
            ];
            if ( $og_img ) { $product_schema['image'] = $og_img; }
            if ( ! empty( $listing->avg_rating ) && ! empty( $total_review_count ) ) {
                $product_schema['aggregateRating'] = [
                    '@type' => 'AggregateRating',
                    'ratingValue' => round( (float) $listing->avg_rating, 1 ),
                    'reviewCount' => (int) $total_review_count,
                    'bestRating'  => 5, 'worstRating' => 1,
                ];
            }
            echo '<script type="application/ld+json">' . wp_json_encode( $product_schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>';
        }
        echo '<script type="application/ld+json">' . wp_json_encode($schema, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) . '</script>';
        // BreadcrumbList — same pattern already confirmed working on
        // templates/pages/seo-location.php, just missing here. Shows the
        // Home > Directory > Category > Business path directly under the
        // search result in Google — a real, documented visual enhancement.
        $bc_items = [
            [ '@type'=>'ListItem', 'position'=>1, 'name'=>'Home',      'item'=>home_url('/') ],
            [ '@type'=>'ListItem', 'position'=>2, 'name'=>'Directory', 'item'=>home_url('/directory/') ],
        ];
        if ( ! empty( $listing->cat_name ) ) {
            $cat_url = ! empty( $listing->cat_slug )
                ? home_url( '/directory/?category=' . urlencode( $listing->cat_slug ) )
                : home_url( '/directory/?category_id=' . (int)( $listing->category_id ?? 0 ) );
            $bc_items[] = [ '@type'=>'ListItem', 'position'=>3, 'name'=>$listing->cat_name, 'item'=>$cat_url ];
        }
        $bc_items[] = [ '@type'=>'ListItem', 'position'=>count($bc_items)+1, 'name'=>$brand ];
        $bc_schema = [ '@context'=>'https://schema.org', '@type'=>'BreadcrumbList', 'itemListElement'=>$bc_items ];
        echo '<script type="application/ld+json">' . wp_json_encode($bc_schema, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES) . '</script>';
        // Canonical URL uses clean listing slug format
        echo '<link rel="canonical" href="' . esc_url( $canonical ) . '">';
        echo self::vendor_critical_css( $color );
        echo '<link rel="stylesheet" href="' . esc_url( $css_url ) . '">';
        // Output plugin styles (Fluent Forms CSS etc.) — scoped inside our page
        if ( $plugin_styles ) echo $plugin_styles;
        echo apply_filters( 'gs_head_inject', '', 'listing' );

        // ── Selective wp_head: loads 3rd-party plugin assets (e.g. Yellow Pencil)
        //    WITHOUT the duplicate title, charset, theme CSS, or jQuery that would
        //    conflict with GoodService's own head content.
        add_action( 'wp_head', function() {
            // Remove WP core meta/link hooks — GoodService already outputs these
            foreach ( [
                [ '_wp_render_title_tag',              1  ],
                [ 'wp_generator',                      10 ],
                [ 'feed_links',                        2  ],
                [ 'feed_links_extra',                  3  ],
                [ 'rsd_link',                          10 ],
                [ 'wlwmanifest_link',                  10 ],
                [ 'adjacent_posts_rel_link_wp_head',   10 ],
                [ 'locale_stylesheet',                 10 ],
                [ 'noindex',                           1  ],
                [ 'wp_no_robots',                      1  ],
                [ 'wp_site_icon',                      99 ],
                [ 'wp_resource_hints',                 2  ],
                [ 'rest_output_link_wp_head',          10 ],
                [ 'wp_oembed_add_discovery_links',     10 ],
                [ 'wp_shortlink_wp_head',              10 ],
                [ 'rel_canonical',                     10 ],
            ] as [ $fn, $pri ] ) {
                remove_action( 'wp_head', $fn, $pri );
            }

            // ── Suppress third-party SEO plugin duplicate output ──────────────
            if ( class_exists( 'WPSEO_Frontend' ) ) {
                $yoast = \WPSEO_Frontend::get_instance();
                foreach ( [ 'canonical', 'metadesc', 'robots', 'og_tag_title', 'twitter_title',
                             'schema', 'head', 'output_title', 'add_opengraph_namespace' ] as $method ) {
                    remove_action( 'wp_head', [ $yoast, $method ], 1 );
                    remove_action( 'wp_head', [ $yoast, $method ], 10 );
                }
            }
            // Real fix: extracted to a shared function — see
            // gs_apply_rankmath_conflict_prevention() in functions.php —
            // instead of 3 duplicated copies of this same logic.
            gs_apply_rankmath_conflict_prevention();
            if ( function_exists( 'aioseo' ) && method_exists( aioseo(), 'meta' ) ) {
                remove_action( 'wp_head', [ aioseo()->meta, 'output' ], 1 );
            }
            if ( defined( 'SEOPRESS_VERSION' ) ) {
                remove_action( 'wp_head', 'seopress_titles_hook',      0 );
                remove_action( 'wp_head', 'seopress_social_tags_hook', 1 );
                remove_action( 'wp_head', 'seopress_schemas_hook',     2 );
            }
        }, 0 );
        // Remove WP core / theme styles — keep only 3rd-party plugin styles (e.g. YP)
        add_action( 'wp_print_styles', function() {
            global $wp_styles;
            if ( ! $wp_styles instanceof \WP_Styles ) return;
            $core_prefixes = [ 'wp-', 'admin-bar', 'dashicons', 'classic-theme', 'global-styles',
                               'jquery-', 'thickbox', 'mediaelement', 'wp_mediaelement' ];
            foreach ( array_keys( $wp_styles->registered ) as $handle ) {
                foreach ( $core_prefixes as $pfx ) {
                    if ( str_starts_with( $handle, $pfx ) ) { wp_dequeue_style( $handle ); break; }
                }
                // Also skip active theme styles
                if ( get_stylesheet() && str_contains( $handle, get_stylesheet() ) ) {
                    wp_dequeue_style( $handle );
                }
            }
        }, PHP_INT_MAX );
        // Remove WP core / theme scripts — keep only 3rd-party plugin scripts (e.g. YP)
        add_action( 'wp_print_scripts', function() {
            global $wp_scripts;
            if ( ! $wp_scripts instanceof \WP_Scripts ) return;
            $core_handles = [ 'jquery', 'jquery-core', 'jquery-migrate', 'wp-polyfill',
                              'wp-hooks', 'wp-i18n', 'regenerator-runtime', 'wp-block-library',
                              'underscore', 'backbone', 'wp-util', 'wp-backbone',
                              'heartbeat', 'thickbox', 'admin-bar', 'dashicons',
                              'wp-api-fetch', 'wp-url', 'wp-element' ];
            foreach ( $core_handles as $h ) { wp_dequeue_script( $h ); }
        }, PHP_INT_MAX );
        ob_start(); wp_head(); echo ob_get_clean();
        $wp_body_classes_lu = implode( ' ', get_body_class( [ 'gs-body', 'gs-vendor-site-body' ] ) );
        // jQuery first — all plugin scripts depend on it
        // FIXED — same root cause as the home-page render path above (see its
        // comment): jQuery was `defer`red while $content's own inline
        // template scripts run synchronously and unconditionally need it
        // immediately, not deferred. Removing `defer` guarantees jQuery is
        // defined before any later inline script in the page executes.
        echo '<script src="' . includes_url( 'js/jquery/jquery.min.js' ) . '"></script>';
        // Fluent Forms needs wp_ajax_url and nonce exposed globally
        echo '<script>window.fluent_forms_global_var=window.fluent_forms_global_var||{};';
        echo 'window.fluent_forms_global_var.ajaxUrl=' . wp_json_encode( admin_url('admin-ajax.php') ) . ';';
        echo 'window.fluent_forms_global_var.nonce=' . wp_json_encode( wp_create_nonce('fluentform-public') ) . ';';
        echo '</script>';
        echo '<script>var GS='.($js_config&&$js_config!='{}' ? $js_config : '{}').';(function(){if(!GS.ajax_url)GS.ajax_url='.wp_json_encode(admin_url('admin-ajax.php')).';if(!GS.nonce)GS.nonce='.wp_json_encode(wp_create_nonce('gs_ajax')).';if(!GS.i18n)GS.i18n={error:"Something went wrong"};})();</script>';
        // FIXED — same root cause as the jQuery tag above: goodservice.js
        // defines gsPost/gsToast/gsBtnLoading/GS_Toast etc., which page
        // templates' own inline scripts also call immediately, not just from
        // inside later event handlers — `defer` here meant those were
        // undefined too at the moment such an inline script ran.
        echo '<script src="' . esc_url( $js_url ) . '"></script>';
        echo '<script>window.gsOnDownloadAppClick=window.gsOnDownloadAppClick||function(){var b=(window.GS&&GS.home_url)?GS.home_url:"/";if(b.slice(-1)!=="/")b+="/";window.location.href=b+"install-app/";};</script>';
        // Real feature — structured data (JSON-LD), the highest-priority
        // verified gap from the enterprise audit. $listing is already
        // fully assembled by this point in the request; render_listing_schema()
        // makes zero additional queries except its own small, indexed
        // review sample. Emits nothing (returns '') if the listing lacks
        // even a title, so this is safe to echo unconditionally.
        echo \GoodService\Service\SchemaGenerator::render_listing_schema( $listing );
        // Real feature — FAQPage schema, closing a confirmed gap: FAQ
        // content was documented elsewhere in this codebase as eligible
        // for Google's FAQ rich results, but no schema was ever actually
        // generated. Emits nothing if there's no FAQ content, so safe to
        // echo unconditionally, matching the pattern directly above.
        echo \GoodService\Service\SchemaGenerator::render_faq_schema( $listing );
        echo '</head><body class="' . esc_attr( $wp_body_classes_lu ) . '">';
        echo apply_filters( 'gs_body_start_inject', '', 'listing' );
        echo $content;
        // Output plugin footer scripts (Fluent Forms JS etc.)
        if ( $plugin_scripts ) echo $plugin_scripts;
        echo apply_filters( 'gs_body_end_inject', '', 'listing' );
        ob_start(); wp_footer(); echo ob_get_clean();
        echo '</body></html>';
    }

    // ── Vendor one-page microsite renderer ─────────────────────────────────────
    // The /v/{vendor_slug}/ route is a legacy path. We 301-redirect it to the
    // vendor's primary listing clean URL (/{listing_slug}/) so that only one
    // canonical URL exists for each listing page and /v/ never appears anywhere.
    private static function render_vendor_site(): void {
        global $wpdb;
        $pfx  = $wpdb->prefix . 'gs_';
        $slug = sanitize_text_field( get_query_var( 'gs_vendor_slug', '' ) );

        if ( ! $slug ) { wp_redirect( home_url( '/directory/' ), 301 ); exit; }

        // Resolve vendor profile slug → primary listing slug
        $listing_slug = $wpdb->get_var( $wpdb->prepare(
            "SELECT l.slug FROM {$pfx}listings l
             INNER JOIN {$pfx}vendor_profiles vp ON vp.id = l.vendor_id
             WHERE vp.slug = %s AND l.status IN('active','pending')
             ORDER BY l.is_featured DESC, l.created_at ASC LIMIT 1",
            $slug
        ) );

        if ( $listing_slug ) {
            // 301 redirect to the canonical clean listing URL
            wp_redirect( home_url( '/' . $listing_slug . '/' ), 301 );
            exit;
        }

        // No active listing found — check if vendor profile even exists
        $vendor_exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$pfx}vendor_profiles WHERE slug = %s AND is_active = 1 LIMIT 1",
            $slug
        ) );
        if ( ! $vendor_exists ) { wp_redirect( home_url( '/directory/' ), 301 ); exit; }

        // Vendor exists but has no active listing — redirect to directory
        wp_redirect( home_url( '/directory/' ), 301 ); exit;

        // L5 FIX: Dead code removed — this function always 301-redirects
        // before reaching any rendering logic. See render_listing_unified()
        // which is the live path for all vendor listing pages.
    }

    private static function vendor_critical_css( string $color ): string {
        return '<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --gs-font:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
  --gs-primary:' . esc_attr( $color ) . ';
  --gs-navy:#1E3A5F;--gs-green:#059669;--gs-orange:#D97706;--gs-red:#DC2626;
  --gs-text:#0F172A;--gs-text-2:#334155;--gs-text-3:#64748B;--gs-text-4:#94A3B8;
  --gs-border:#E2E8F0;--gs-bg:#F8FAFC;--gs-white:#FFFFFF;
  --gs-shadow:0 4px 6px rgba(15,23,42,.07);
  --gs-shadow-md:0 8px 16px rgba(15,23,42,.08);
  --gs-radius:12px;--gs-radius-sm:8px;--gs-transition:all .2s ease;
}
html,body{background:#fff;color:var(--gs-text);font-family:var(--gs-font);-webkit-font-smoothing:antialiased;line-height:1.6}
a{text-decoration:none;color:var(--gs-primary)}
img{max-width:100%;display:block}
/* WordPress emoji-replacement images — constrain to inline text size site-wide */
img.emoji{display:inline!important;border:none!important;box-shadow:none!important;height:1em!important;width:1em!important;margin:0 .07em!important;vertical-align:-.1em!important;background:none!important;padding:0!important;max-width:none!important}
/* Admin bar: shown for logged-in admins/editors — Yellow Pencil needs it */
html.admin-bar .gs-vs-nav{top:32px!important}
@media screen and (max-width:782px){html.admin-bar .gs-vs-nav{top:46px!important}}
.gs-vs-container{max-width:1100px;margin:0 auto;padding:0 20px}
html{scroll-behavior:smooth}
</style>';
    }

    private static function render_page( string $page, ?callable $content_callback = null, array $extra_vars = [] ): void {
        $platform = Config::get( 'platform_name', 'GoodService' );
        $color    = Config::get( 'platform_color_primary', '#2563EB' );
        $favicon  = Config::get( 'platform_favicon_url', '' );

        $titles = [
            'archive'            => 'Find Services — ' . $platform,
            'admin_dashboard'    => 'Admin Panel — ' . $platform,
            'vendor_dashboard'   => 'My Dashboard — ' . $platform,
            'manager_dashboard'  => 'Manager Panel — ' . $platform,
            'login'              => 'Login — ' . $platform,
            'register'           => 'Register — ' . $platform,
            'create_listing'     => 'Create Listing — ' . $platform,
            'vendor_profile'     => 'Vendor Profile — ' . $platform,
        ];
        $title = $titles[ $page ] ?? $platform;

        // Platform pages (About, Contact, Privacy, etc.) need their own
        // real, specific, dynamic title from gs_pages — the static array
        // above can't express this, since it's one fixed title per page
        // TYPE, not per individual page.
        if ( $page === 'platform-page' && ! empty( $extra_vars['gs_static_slug'] ) ) {
            global $wpdb;
            $pp_row = $wpdb->get_row( $wpdb->prepare(
                "SELECT title, meta_title, meta_desc FROM {$wpdb->prefix}gs_pages WHERE slug = %s AND is_active = 1 LIMIT 1",
                $extra_vars['gs_static_slug']
            ) );
            $title = $pp_row ? ( $pp_row->meta_title ?: $pp_row->title . ' — ' . $platform ) : "Page Not Found — {$platform}";
        }

        // ── Synthetic WP post for directory — standalone, no DB pages created ──────
        // Yellow Pencil uses get_the_ID() to identify which page it's saving CSS for.
        // The directory has no real WP post so get_the_ID() returns 0 and YP silently
        // rejects saves (most versions reject post_id=0).
        //
        // STANDALONE FIX: create an in-memory WP_Post object with a stable synthetic
        // ID (generated from site URL, stored in option, never written to wp_posts).
        // Set it as the global post + WP_Query queried object so get_the_ID() returns
        // the synthetic ID and get_body_class() adds page-id-{id} to the body class.
        //
        // The adminbar plugin intercepts update_post_metadata / get_post_metadata for
        // this synthetic ID and redirects them to wp_options storage so YP can save
        // and reload CSS without the ID needing to exist in the posts table.
        if ( $page === 'archive' ) {
            $dir_yp_id = (int) get_option( 'gs_directory_yp_id', 0 );
            if ( ! $dir_yp_id ) {
                // Deterministic ID in range 900001–989999, extremely unlikely to
                // collide with real posts and still fits in a signed 32-bit int.
                $dir_yp_id = 900001 + ( abs( crc32( get_site_url() ) ) % 89999 );
                update_option( 'gs_directory_yp_id', $dir_yp_id, false );
            }
            // Build in-memory WP_Post — never touches the database
            $dir_synthetic = new \WP_Post( (object) [
                'ID'             => $dir_yp_id,
                'post_type'      => 'page',
                'post_status'    => 'publish',
                'post_name'      => 'directory',
                'post_title'     => 'Directory',
                'post_content'   => '',
                'post_author'    => 0,
                'post_date'      => current_time( 'mysql' ),
                'post_modified'  => current_time( 'mysql' ),
                'comment_status' => 'closed',
                'ping_status'    => 'closed',
                'filter'         => 'raw',
            ] );
            // Populate WP object cache so get_post( $dir_yp_id ) works everywhere
            wp_cache_set( $dir_yp_id, $dir_synthetic, 'posts' );
            // Set WP global query state
            global $wp_query, $post;
            $wp_query->post              = $dir_synthetic;
            $wp_query->posts             = [ $dir_synthetic ];
            $wp_query->queried_object    = $dir_synthetic;
            $wp_query->queried_object_id = $dir_yp_id;
            $wp_query->is_page           = true;
            $wp_query->is_singular       = true;
            $wp_query->is_home           = false;
            $wp_query->is_archive        = false;
            $wp_query->is_404            = false;
            $post                        = $dir_synthetic;
            setup_postdata( $dir_synthetic );
        }

        // Allow plugins (Yellow Pencil, Fluent Forms, etc.) to register their assets.
        // render_vendor_site() does this too — without it YP editor never loads on
        // non-vendor pages (directory, dashboards, create-listing, etc.).
        try { do_action( 'wp_enqueue_scripts' ); } catch ( \Throwable $e ) {}

        ob_start();
        try {
            if ( $content_callback !== null ) {
                call_user_func( $content_callback );
            } else {
                // Direct template rendering (used by quote-accept, job-track, etc.)
                $page_slug = str_replace( '-', '_', $page );
                $tpl_file  = GS_DIR . 'templates/pages/' . $page . '.php';
                if ( file_exists( $tpl_file ) ) {
                    if ( ! empty( $extra_vars ) ) { extract( $extra_vars, EXTR_SKIP ); }
                    require $tpl_file;
                } else {
                    echo '<div style="padding:40px;text-align:center;color:#94A3B8">Page not found: ' . esc_html( $page ) . '</div>';
                }
            }
        }
        catch ( \Throwable $e ) { echo self::error_html( $e ); }
        $content = ob_get_clean();

        // Dequeue GoodService's own assets — we load them manually below.
        // Without this, Assets::enqueue() (hooked to wp_enqueue_scripts above)
        // puts goodservice.css + goodservice.js into WP's queues, so they'd be
        // output TWICE: once by wp_print_styles/footer_scripts, and again by our
        // manual echo statements.  Double-loading causes duplicate event handlers,
        // GS object overwrites, and GS.is_admin inconsistency.
        try {
            wp_dequeue_style(  'goodservice' );
            wp_dequeue_script( 'goodservice' );
            // Also remove from the "done" list so wp_print_footer_scripts
            // cannot output it even if it was marked done in a prior hook.
            global $wp_styles, $wp_scripts;
            if ( $wp_styles  instanceof \WP_Styles  ) { unset( $wp_styles->done[  array_search( 'goodservice', $wp_styles->done  ?: [] ) ] ); }
            if ( $wp_scripts instanceof \WP_Scripts ) {
                $wp_scripts->done = array_values( array_filter( $wp_scripts->done ?: [], fn($h) => $h !== 'goodservice' ) );
            }
        } catch ( \Throwable $e ) {}

        // Collect plugin-enqueued styles (Yellow Pencil editor CSS, Fluent Forms, etc.)
        ob_start();
        try { wp_print_styles(); } catch ( \Throwable $e ) {}
        $plugin_styles_page = ob_get_clean();

        // Collect plugin footer scripts — dequeue jQuery first so our manual copy wins
        try {
            wp_dequeue_script( 'jquery' );
            wp_dequeue_script( 'jquery-core' );
            wp_dequeue_script( 'jquery-migrate' );
        } catch ( \Throwable $e ) {}
        ob_start();
        try { wp_print_footer_scripts(); } catch ( \Throwable $e ) {}
        $plugin_scripts_page = ob_get_clean();

        try { $js_config = wp_json_encode( Assets::js_config() ); }
        catch ( \Throwable $e ) { $js_config = '{}'; }

        // Real fix, closing the audit's minification gap safely: uses
        // gs_asset_url() to resolve the minified version only when it's
        // genuinely, verifiably newer than the source — the exact
        // protection the old comment on this line called for, now
        // actually implemented rather than avoiding minification entirely.
        $css_url = gs_asset_url( 'assets/css/goodservice.css' );
        $js_url  = gs_asset_url( 'assets/js/goodservice.js' );

        // ── Admin bar — CRITICAL for Yellow Pencil ──────────────────────────────
        // render_vendor_site() renders the real WP admin bar HTML into the DOM so
        // Yellow Pencil's frontend JS can find #wpadminbar and attach its editor
        // activation handler.  Without it YP's editor never activates regardless
        // of whether its scripts are enqueued.  render_page() was missing this —
        // that is why YP worked on vendor-site but not on directory/dashboards.
        // The gsab plugin hides the real bar and shows its own; both coexist safely.
        $show_admin_bar = function_exists( 'is_admin_bar_showing' ) && is_admin_bar_showing();
        $admin_bar_html = '';
        $admin_bar_css  = '';
        if ( $show_admin_bar ) {
            global $wp_admin_bar;
            $admin_bar_css = '<link rel="stylesheet" href="' . esc_url( includes_url( 'css/admin-bar.min.css' ) ) . '">';
            if ( $wp_admin_bar instanceof \WP_Admin_Bar ) {
                ob_start();
                try { $wp_admin_bar->render(); } catch ( \Throwable $e ) {}
                $admin_bar_html = ob_get_clean();
            }
        }

        // Real fix for confirmed CDN-caching bug (see BaseController::view()
        // for the matching fix on the other real render path). This function
        // serves the vendor and admin dashboards — personalized, logged-in
        // content that must never be cached by a CDN or browser, but never
        // sent any cache-control headers before this fix.
        if ( is_user_logged_in() && ! headers_sent() ) {
            nocache_headers();
            header( 'Cache-Control: private, no-store, no-cache, must-revalidate, max-age=0' );
            header( 'CDN-Cache-Control: no-store' );
            header( 'Pragma: no-cache' );
        }
        $_gs_html_cls = trim( (string) apply_filters( 'gs_html_class', $show_admin_bar ? 'admin-bar' : '', $page ) );
        echo '<!DOCTYPE html><html lang="en"' . ( $_gs_html_cls ? ' class="' . esc_attr( $_gs_html_cls ) . '"' : '' ) . '><head>';
        // Real fix — PageSpeed's "Properly defines charset" audit requires
        // the charset meta to be the very first element in <head>, before
        // any script; this used to echo the geolocation-block script
        // first, pushing charset one element too late. Order swapped,
        // nothing else changed.
        echo '<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">';
        echo '<script>try{if(window.navigator&&navigator.geolocation){navigator.geolocation.getCurrentPosition=function(){};navigator.geolocation.watchPosition=function(){return 0;}}}catch(e){}</script>';
        if ( $favicon ) { echo '<link rel="icon" href="' . esc_url( $favicon ) . '">'; }
        // Part 2.1 / 3.1 — PWA manifest and Apple meta tags for dashboard pages
        // Real fix — confirmed root cause of "Install" never firing the
        // browser's native prompt on these dashboards (always falling back
        // to the manual "look for an install icon" message instead): this
        // used to link the old rewrite-rule-served static manifest files
        // and a direct static .png icon path — both confirmed unreliable
        // elsewhere in this codebase (rewrite rules need an explicit flush;
        // the CDN's WebP conversion intercepts direct static .png URLs).
        // Chrome silently disables the install prompt if the manifest or
        // its icons don't load — no visible error, it just never fires.
        // Now uses the same REST-API manifest/icon routes already fixed
        // for the homepage and vendor listing pages.
        if ( in_array( $page, [ 'vendor_dashboard', 'customer_dashboard', 'manager_dashboard' ], true ) ) {
            $is_customer = $page === 'customer_dashboard';
            // Real fix (v7.475.0): same REST-route-returns-empty-body issue
            // confirmed live (200 OK, application/octet-stream, empty
            // body) and the same static-file fix as the homepage/listing
            // <link> tags above — goodservice-client.webmanifest and
            // goodservice-vendor.webmanifest are real files in the plugin
            // root, served straight off disk, never touching WP-JSON.
            $manifest = gs_pwa_manifest_url( $is_customer ? 'client' : 'vendor' );
            $icon_192 = add_query_arg( 'name', $is_customer ? 'client-192' : 'vendor-192', rest_url( 'goodservice/v1/icon' ) );
            echo '<meta name="gs-pwa-manifest-url" content="' . esc_attr( $manifest ) . '">';
            echo '<meta name="apple-mobile-web-app-capable" content="yes">';
            echo '<meta name="apple-mobile-web-app-status-bar-style" content="default">';
            echo '<meta name="apple-mobile-web-app-title" content="GS ' . ( $is_customer ? 'Client' : 'Vendor' ) . '">';
            echo '<link rel="apple-touch-icon" href="' . esc_url( $icon_192 ) . '">';
            echo '<meta name="theme-color" content="#2563EB">';
        }

        // Real fix — the <title> tag was previously echoed here, BEFORE the
        // per-page block below that recomputes $title for archive/category
        // and seo_location pages (category+city specific). That meant the
        // <title> tag always showed the generic per-page-type title even
        // when a more specific one was computed a few lines later — it was
        // only ever used for og:title/twitter:title, never the actual
        // <title> tag search engines read. Moving the echo to run AFTER
        // the per-page block (which still runs in the same position
        // relative to everything else) fixes this without duplicating any
        // of that block's title-computation logic.
        // ── Per-page SEO: canonical, meta description, OG, robots, schema ──────
        if ( $page === 'archive' ) {
            // Real fix, item A from the follow-up audit — the executive
            // summary's own flagged gap: "inconsistent per-page-type meta
            // coverage... category-only archive views without a
            // location." Previously $dir_desc/$dir_url ignored any active
            // filter entirely, even though the canonical tag already
            // correctly reflected it (built separately in archive.php) —
            // meaning social shares and search snippets for a filtered
            // view showed the generic platform description, and og:url
            // didn't even match the page's own canonical. Falls back to
            // the exact original generic values when no filter is active.
            global $wpdb;
            $_dir_cat_slug = sanitize_text_field( $_GET['category'] ?? '' );
            $_dir_city_val = sanitize_text_field( $_GET['city'] ?? '' );
            $_dir_cat_name = '';
            if ( $_dir_cat_slug ) {
                $_dir_cat_name = $wpdb->get_var( $wpdb->prepare(
                    "SELECT name FROM {$wpdb->prefix}gs_categories WHERE slug = %s", $_dir_cat_slug
                ) );
            }
            if ( $_dir_cat_name && $_dir_city_val ) {
                $dir_desc = "Find verified {$_dir_cat_name} professionals in {$_dir_city_val}. Compare quotes, read reviews, book instantly.";
            } elseif ( $_dir_cat_name ) {
                $dir_desc = "Find verified {$_dir_cat_name} professionals. Compare quotes, read reviews, book instantly.";
            } elseif ( $_dir_city_val ) {
                $dir_desc = "Find verified local service providers in {$_dir_city_val}. Compare quotes, read reviews, book instantly.";
            } else {
                $dir_desc = Config::get( 'platform_description', 'Find verified local service providers. Compare quotes, read reviews, book instantly.' );
            }
            $_dir_url_params = array_filter( [ 'category' => $_dir_cat_slug, 'city' => $_dir_city_val ] );
            $dir_url = $_dir_url_params ? home_url( '/directory/?' . http_build_query( $_dir_url_params ) ) : home_url( '/directory/' );
            if ( $_dir_cat_name || $_dir_city_val ) {
                $title = trim( ( $_dir_cat_name ?: 'Services' ) . ( $_dir_city_val ? " in {$_dir_city_val}" : '' ) . ' | ' . $platform );
            }
            echo '<meta name="description" content="' . esc_attr( $dir_desc ) . '">';
            echo '<meta name="robots" content="index,follow">';
            // Canonical is output dynamically by gs_head_inject filter in archive.php
            // so filtered views get the correct filtered URL, not always /directory/
            echo '<meta property="og:type" content="website">';
            echo '<meta property="og:locale" content="en_IN">';
            echo '<meta property="og:title" content="' . esc_attr( $title ) . '">';
            echo '<meta property="og:description" content="' . esc_attr( $dir_desc ) . '">';
            echo '<meta property="og:url" content="' . esc_url( $dir_url ) . '">';
            echo '<meta property="og:site_name" content="' . esc_attr( $platform ) . '">';
            echo '<meta name="twitter:card" content="summary">';
            echo '<meta name="twitter:title" content="' . esc_attr( $title ) . '">';
            echo '<meta name="twitter:description" content="' . esc_attr( $dir_desc ) . '">';
            echo '<script type="application/ld+json">' . wp_json_encode( [
                '@context'   => 'https://schema.org',
                '@type'      => 'CollectionPage',
                'name'       => $title,
                'description'=> $dir_desc,
                'url'        => $dir_url,
                'isPartOf'   => [ '@type' => 'WebSite', 'name' => $platform, 'url' => home_url( '/' ) ],
                'breadcrumb' => [
                    '@type'           => 'BreadcrumbList',
                    'itemListElement' => [
                        [ '@type' => 'ListItem', 'position' => 1, 'name' => 'Home',      'item' => home_url( '/' ) ],
                        [ '@type' => 'ListItem', 'position' => 2, 'name' => 'Directory', 'item' => $dir_url ],
                    ],
                ],
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>';

        } elseif ( $page === 'seo_location' && ! empty( $extra_vars['category_slug'] ) ) {
            // The seo-location template outputs its own body-level JSON-LD;
            // we add the <head> meta it was missing.
            $sl_cat  = sanitize_text_field( $extra_vars['category_slug'] );
            $sl_city = sanitize_text_field( $extra_vars['city'] ?? '' );
            $sl_url  = home_url( '/service/' . $sl_cat . '/' . sanitize_title( $sl_city ) . '/' );
            $sl_desc = $sl_city
                ? "Find verified {$sl_cat} professionals in {$sl_city}. Compare quotes, read reviews, get free quotes."
                : "Find verified {$sl_cat} professionals. Compare quotes, read reviews, get free quotes.";
            // Real fix — this page previously had no page-specific <title>
            // at all (fell through to the generic $titles[$page] value).
            // Mirrors the same "Trusted {category} in {city}" phrasing the
            // template itself uses for $page_title/H1, so <title> and H1
            // agree instead of showing unrelated text to users and crawlers.
            $_sl_cat_label = ucwords( str_replace( [ '-', '_' ], ' ', $sl_cat ) );
            $title = $sl_city
                ? "Trusted {$_sl_cat_label} in {$sl_city} — Get Free Quotes | {$platform}"
                : "Trusted {$_sl_cat_label} — Get Free Quotes | {$platform}";
            echo '<meta name="description" content="' . esc_attr( $sl_desc ) . '">';
            echo '<meta name="robots" content="index,follow">';
            echo '<link rel="canonical" href="' . esc_url( $sl_url ) . '">';
            echo '<meta property="og:type" content="website">';
            echo '<meta property="og:locale" content="en_IN">';
            echo '<meta property="og:title" content="' . esc_attr( $title ) . '">';
            echo '<meta property="og:description" content="' . esc_attr( $sl_desc ) . '">';
            echo '<meta property="og:url" content="' . esc_url( $sl_url ) . '">';
            echo '<meta property="og:site_name" content="' . esc_attr( $platform ) . '">';

        } elseif ( in_array( $page, [
            'admin_dashboard', 'vendor_dashboard', 'manager_dashboard', 'login', 'register', 'create_listing', 'vendor_profile',
            // Real fix — these page types reached render_page() but matched
            // none of the branches above, so they got NO robots meta tag at
            // all, which defaults to indexable. Several of these are
            // private account areas or carry a one-time access token
            // directly in the URL (job-track, quote-accept) — exactly the
            // kind of page that must never be indexed or followed.
            // Adding them here only adds a <meta> tag; nothing about the
            // page itself changes.
            'customer_dashboard', 'staff_dashboard', 'admin_login', 'manager_login', 'staff_login',
            'forgot_password', 'reset_password', 'my_home', 'my-home', 'rwa_dashboard', 'rwa-dashboard',
            'quote-accept', 'job-track', 'moderation_dashboard', 'visitor_dashboard', 'vendor_staff_dashboard',
        ], true ) ) {
            // Dashboard and auth pages: noindex — no reason to crawl these
            echo '<meta name="robots" content="noindex,nofollow">';

        } elseif ( $page === 'platform-page' && ! empty( $pp_row ) ) {
            $pp_slug = $extra_vars['gs_static_slug'];
            if ( ! empty( $pp_row->meta_desc ) ) {
                echo '<meta name="description" content="' . esc_attr( $pp_row->meta_desc ) . '">';
            }
            echo '<link rel="canonical" href="' . esc_url( home_url( '/' . $pp_slug . '/' ) ) . '">';
            echo '<script type="application/ld+json">' . wp_json_encode( [
                '@context'    => 'https://schema.org',
                '@type'       => 'WebPage',
                'name'        => $pp_row->title,
                'url'         => home_url( '/' . $pp_slug . '/' ),
                'description' => $pp_row->meta_desc ?: $pp_row->title,
                'isPartOf'    => [ '@type' => 'WebSite', 'name' => $platform, 'url' => home_url( '/' ) ],
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>';
            echo '<script type="application/ld+json">' . wp_json_encode( [
                '@context' => 'https://schema.org',
                '@type'    => 'BreadcrumbList',
                'itemListElement' => [
                    [ '@type' => 'ListItem', 'position' => 1, 'name' => 'Home', 'item' => home_url( '/' ) ],
                    [ '@type' => 'ListItem', 'position' => 2, 'name' => $pp_row->title ],
                ],
            ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . '</script>';
        }
        echo '<title>' . esc_html( $title ) . '</title>';
        if ( $admin_bar_css ) echo $admin_bar_css; // WP admin-bar.min.css (needed for YP editor UI)
        echo self::critical_css( $color );
        echo '<link rel="stylesheet" href="' . esc_url( $css_url ) . '">';
        if ( $plugin_styles_page ) echo $plugin_styles_page; // YP editor styles, Fluent Forms CSS, etc.
        echo apply_filters( 'gs_head_inject', '', $page );

        // ── Selective wp_head: loads 3rd-party plugin assets (e.g. Yellow Pencil)
        //    WITHOUT the duplicate title, charset, theme CSS, or jQuery that would
        //    conflict with GoodService's own head content.
        add_action( 'wp_head', function() {
            // Remove WP core meta/link hooks — GoodService already outputs these
            foreach ( [
                [ '_wp_render_title_tag',              1  ],
                [ 'wp_generator',                      10 ],
                [ 'feed_links',                        2  ],
                [ 'feed_links_extra',                  3  ],
                [ 'rsd_link',                          10 ],
                [ 'wlwmanifest_link',                  10 ],
                [ 'adjacent_posts_rel_link_wp_head',   10 ],
                [ 'locale_stylesheet',                 10 ],
                [ 'noindex',                           1  ],
                [ 'wp_no_robots',                      1  ],
                [ 'wp_site_icon',                      99 ],
                [ 'wp_resource_hints',                 2  ],
                [ 'rest_output_link_wp_head',          10 ],
                [ 'wp_oembed_add_discovery_links',     10 ],
                [ 'wp_shortlink_wp_head',              10 ],
                [ 'rel_canonical',                     10 ],
            ] as [ $fn, $pri ] ) {
                remove_action( 'wp_head', $fn, $pri );
            }

            // ── Suppress third-party SEO plugin duplicate output ──────────────
            if ( class_exists( 'WPSEO_Frontend' ) ) {
                $yoast = \WPSEO_Frontend::get_instance();
                foreach ( [ 'canonical', 'metadesc', 'robots', 'og_tag_title', 'twitter_title',
                             'schema', 'head', 'output_title', 'add_opengraph_namespace' ] as $method ) {
                    remove_action( 'wp_head', [ $yoast, $method ], 1 );
                    remove_action( 'wp_head', [ $yoast, $method ], 10 );
                }
            }
            // Real fix: extracted to a shared function — see
            // gs_apply_rankmath_conflict_prevention() in functions.php —
            // instead of 3 duplicated copies of this same logic.
            gs_apply_rankmath_conflict_prevention();
            if ( function_exists( 'aioseo' ) && method_exists( aioseo(), 'meta' ) ) {
                remove_action( 'wp_head', [ aioseo()->meta, 'output' ], 1 );
            }
            if ( defined( 'SEOPRESS_VERSION' ) ) {
                remove_action( 'wp_head', 'seopress_titles_hook',      0 );
                remove_action( 'wp_head', 'seopress_social_tags_hook', 1 );
                remove_action( 'wp_head', 'seopress_schemas_hook',     2 );
            }
        }, 0 );
        // Remove WP core / theme styles — keep only 3rd-party plugin styles (e.g. YP)
        add_action( 'wp_print_styles', function() {
            global $wp_styles;
            if ( ! $wp_styles instanceof \WP_Styles ) return;
            $core_prefixes = [ 'wp-', 'admin-bar', 'dashicons', 'classic-theme', 'global-styles',
                               'jquery-', 'thickbox', 'mediaelement', 'wp_mediaelement' ];
            foreach ( array_keys( $wp_styles->registered ) as $handle ) {
                foreach ( $core_prefixes as $pfx ) {
                    if ( str_starts_with( $handle, $pfx ) ) { wp_dequeue_style( $handle ); break; }
                }
                // Also skip active theme styles
                if ( get_stylesheet() && str_contains( $handle, get_stylesheet() ) ) {
                    wp_dequeue_style( $handle );
                }
            }
        }, PHP_INT_MAX );
        // Remove WP core / theme scripts — keep only 3rd-party plugin scripts (e.g. YP)
        add_action( 'wp_print_scripts', function() {
            global $wp_scripts;
            if ( ! $wp_scripts instanceof \WP_Scripts ) return;
            $core_handles = [ 'jquery', 'jquery-core', 'jquery-migrate', 'wp-polyfill',
                              'wp-hooks', 'wp-i18n', 'regenerator-runtime', 'wp-block-library',
                              'underscore', 'backbone', 'wp-util', 'wp-backbone',
                              'heartbeat', 'thickbox', 'admin-bar', 'dashicons',
                              'wp-api-fetch', 'wp-url', 'wp-element' ];
            foreach ( $core_handles as $h ) { wp_dequeue_script( $h ); }
        }, PHP_INT_MAX );
        ob_start(); wp_head(); echo ob_get_clean();
        // Add WordPress body classes so plugins like Yellow Pencil can scope CSS.
        // YP saves CSS with selectors like .page-id-N .element{...}.  Without the
        // matching page-id-* class on <body>, those selectors never fire after edit.
        // For GoodService pages with no real WP post (directory, dashboards, etc.),
        // get_queried_object_id() returns 0.  WordPress's get_body_class() only adds
        // page-id-* for real posts/pages, so we add page-id-0 manually here so that
        // YP's .page-id-0 scoped selectors match on these pages.
        $extra_body = [ 'gs-body', 'gs-page-' . $page ];
        if ( (int) get_queried_object_id() === 0 ) {
            $extra_body[] = 'page-id-0';
        }
        $wp_body_classes = implode( ' ', get_body_class( $extra_body ) );
        // FIXED — same root cause as the home-page render path above (see its
        // comment): jQuery was `defer`red while $content's own inline
        // template scripts run synchronously and unconditionally need it
        // immediately, not deferred. Removing `defer` guarantees jQuery is
        // defined before any later inline script in the page executes.
        echo '<script src="' . includes_url( 'js/jquery/jquery.min.js' ) . '"></script>';
        echo '<script>var GS='.($js_config&&$js_config!='{}' ? $js_config : '{}').';(function(){if(!GS.ajax_url)GS.ajax_url='.wp_json_encode(admin_url('admin-ajax.php')).';if(!GS.nonce)GS.nonce='.wp_json_encode(wp_create_nonce('gs_ajax')).';if(!GS.i18n)GS.i18n={error:"Something went wrong"};})();</script>';
        // FIXED — same root cause as the jQuery tag above: goodservice.js
        // defines gsPost/gsToast/gsBtnLoading/GS_Toast etc., which page
        // templates' own inline scripts also call immediately, not just from
        // inside later event handlers — `defer` here meant those were
        // undefined too at the moment such an inline script ran.
        echo '<script src="' . esc_url( $js_url ) . '"></script>';
        echo '<script>window.gsOnDownloadAppClick=window.gsOnDownloadAppClick||function(){var b=(window.GS&&GS.home_url)?GS.home_url:"/";if(b.slice(-1)!=="/")b+="/";window.location.href=b+"install-app/";};</script>';
        if ( $show_admin_bar ) echo '<script src="' . esc_url( includes_url( 'js/admin-bar.min.js' ) ) . '"></script>';
        echo '</head><body class="' . esc_attr( $wp_body_classes ) . '">';
        echo apply_filters( 'gs_body_start_inject', '', $page );
        if ( $admin_bar_html ) echo $admin_bar_html; // Real WP admin bar (hidden by gsab CSS, needed for YP JS hooks)
        echo $content;
        if ( $plugin_scripts_page ) echo $plugin_scripts_page; // YP editor JS, etc. — loads after jQuery
        echo apply_filters( 'gs_body_end_inject', '', $page );
        ob_start(); wp_footer(); echo ob_get_clean();
        echo '</body></html>';
    }

    private static function error_html( \Throwable $e ): string {
        if ( function_exists( 'gs_write_log' ) ) {
            gs_write_log( get_class($e).': '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine() );
        }
        error_log( '[GoodService] '.get_class($e).': '.$e->getMessage().' in '.$e->getFile().':'.$e->getLine() );

        if ( current_user_can( 'manage_options' ) ) {
            return '<div style="margin:40px;padding:24px;background:#FEF2F2;border:2px solid #DC2626;border-radius:10px;font-family:monospace;max-width:900px">'
                . '<h3 style="color:#DC2626;margin:0 0 12px;font-family:sans-serif">🚨 '.esc_html(get_class($e)).'</h3>'
                . '<p style="font-size:1rem;margin-bottom:12px;color:#7F1D1D">'.esc_html($e->getMessage()).'</p>'
                . '<p style="font-size:.82rem;color:#94A3B8;margin-bottom:12px">'.esc_html(str_replace(ABSPATH,'',$e->getFile())).':'.esc_html((string)$e->getLine()).'</p>'
                . '<pre style="font-size:.75rem;color:#334155;background:#F8FAFC;padding:14px;border-radius:6px;overflow:auto;max-height:320px">'.esc_html($e->getTraceAsString()).'</pre>'
                . '</div>';
        }
        return '<div style="padding:60px;text-align:center;font-family:sans-serif;">'
            . '<h2 style="color:#DC2626">Something went wrong</h2>'
            . '<p>Please try again or contact support.</p>'
            . '</div>';
    }

    private static function critical_css( string $color ): string {
        return '<style>
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{
  --gs-font:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;
  --gs-primary:' . esc_attr( $color ) . ';--gs-primary-d:#1E40AF;--gs-primary-l:#EFF6FF;
  --gs-navy:#1E3A5F;--gs-green:#059669;--gs-orange:#D97706;--gs-red:#DC2626;
  --gs-gold:#F59E0B;--gs-purple:#7C3AED;
  --gs-text:#0F172A;--gs-text-2:#334155;--gs-text-3:#64748B;--gs-text-4:#94A3B8;
  --gs-border:#E2E8F0;--gs-bg:#F8FAFC;--gs-bg-2:#F1F5F9;--gs-white:#FFFFFF;
  --gs-shadow:0 4px 6px rgba(15,23,42,.07),0 2px 4px rgba(15,23,42,.04);
  --gs-shadow-md:0 8px 16px rgba(15,23,42,.08);
  --gs-shadow-lg:0 16px 32px rgba(15,23,42,.10);
  --gs-radius:12px;--gs-radius-sm:8px;--gs-radius-lg:18px;--gs-radius-xl:24px;--gs-radius-full:9999px;
  --gs-transition:all .2s cubic-bezier(.4,0,.2,1);
  --gs-sidebar-w:280px;--gs-header-h:64px;
}
html,body{height:100%;background:var(--gs-bg);color:var(--gs-text);font-family:var(--gs-font);-webkit-font-smoothing:antialiased;line-height:1.5}
a{text-decoration:none;color:var(--gs-primary)}
img{max-width:100%;display:block}
button,input,textarea,select{font-family:var(--gs-font)}
/* WordPress emoji-replacement images — constrain to inline text size site-wide */
img.emoji{display:inline!important;border:none!important;box-shadow:none!important;height:1em!important;width:1em!important;margin:0 .07em!important;vertical-align:-.1em!important;background:none!important;padding:0!important;max-width:none!important}
/* admin bar handled by render_vendor_site — no suppression needed */
</style>';
    }
}
