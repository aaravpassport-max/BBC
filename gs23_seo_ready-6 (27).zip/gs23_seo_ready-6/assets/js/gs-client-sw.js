/**
 * GoodService Client Service Worker — PWA with offline navigation support.
 */
const CACHE_NAME   = 'gs-client-v3';
const OFFLINE_URL  = '/gs-offline.html';
const SYNC_TAG     = 'gs-booking-retry';
const IDB_DB       = 'gs-offline-queue';
const IDB_STORE    = 'pending-bookings';
const PRECACHE_URLS = [ OFFLINE_URL ];

self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => Promise.all(PRECACHE_URLS.map(url => cache.add(url).catch(() => {}))))
            .then(() => self.skipWaiting())
    );
});

self.addEventListener('activate', event => {
    event.waitUntil(
        caches.keys()
            .then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))))
            .then(() => self.clients.claim())
    );
});

self.addEventListener('fetch', event => {
    const req = event.request;
    if (req.method !== 'GET') { return; }

    const url = new URL(req.url);
    if (url.pathname.includes('admin-ajax.php')) { return; }

    if (req.mode === 'navigate') {
        event.respondWith(
            fetch(req)
                .then(res => {
                    const clone = res.clone();
                    caches.open(CACHE_NAME).then(c => c.put(req, clone));
                    return res;
                })
                .catch(() => caches.match(req).then(cached => cached || caches.match(OFFLINE_URL)))
        );
        return;
    }

    if (['style', 'script', 'image', 'font'].includes(req.destination)) {
        event.respondWith(
            caches.match(req).then(cached => cached ||
                fetch(req).then(res => {
                    const clone = res.clone();
                    caches.open(CACHE_NAME).then(c => c.put(req, clone));
                    return res;
                })
            )
        );
    }
});

self.addEventListener('sync', event => {
    if (event.tag === SYNC_TAG) {
        event.waitUntil(retryPendingBookings());
    }
});

async function retryPendingBookings() {
    const db      = await openIDB();
    const pending = await getAllPending(db);
    let succeeded = 0;
    for (const entry of pending) {
        try {
            const fd = new FormData();
            for (const [k, v] of Object.entries(entry.payload || {})) fd.append(k, v);
            const res  = await fetch(entry.url, { method: 'POST', body: fd });
            const json = await res.json();
            if (json && json.success) {
                await deletePending(db, entry.id);
                succeeded++;
            }
        } catch { /* network still down */ }
    }
    if (succeeded > 0) {
        const clients = await self.clients.matchAll({ type: 'window' });
        clients.forEach(c => c.postMessage({ type: 'GS_BOOKING_SYNCED', count: succeeded }));
    }
}

self.addEventListener('message', async event => {
    if (event.data && event.data.type === 'GS_QUEUE_BOOKING') {
        const db = await openIDB();
        await addPending(db, {
            id:       Date.now().toString(),
            url:      event.data.url,
            payload:  event.data.payload,
            queuedAt: new Date().toISOString(),
        });
        if ('sync' in self.registration) {
            await self.registration.sync.register(SYNC_TAG);
        }
        if (event.ports && event.ports[0]) event.ports[0].postMessage({ queued: true });
    }
});

self.addEventListener('push', event => {
    if (!event.data) return;
    let data;
    try { data = event.data.json(); } catch { data = { title: 'GoodService', body: event.data.text() }; }
    event.waitUntil(
        self.registration.showNotification(data.title || 'GoodService', {
            body: data.body || '',
            icon: '/wp-content/plugins/gs23_seo_ready-6/assets/pwa/client-icon-192.png',
            tag: data.tag || 'gs-notification',
            data: { url: data.url || '/' },
        })
    );
});

self.addEventListener('notificationclick', event => {
    event.notification.close();
    const url = event.notification.data && event.notification.data.url || '/';
    event.waitUntil(clients.openWindow(url));
});

function openIDB() {
    return new Promise(function(resolve, reject) {
        const req = indexedDB.open(IDB_DB, 1);
        req.onupgradeneeded = function(e) { e.target.result.createObjectStore(IDB_STORE, { keyPath: 'id' }); };
        req.onsuccess = function(e) { resolve(e.target.result); };
        req.onerror   = function(e) { reject(e.target.error); };
    });
}
function getAllPending(db) {
    return new Promise(function(resolve, reject) {
        const req = db.transaction(IDB_STORE, 'readonly').objectStore(IDB_STORE).getAll();
        req.onsuccess = function(e) { resolve(e.target.result || []); };
        req.onerror   = function(e) { reject(e.target.error); };
    });
}
function addPending(db, entry) {
    return new Promise(function(resolve, reject) {
        const req = db.transaction(IDB_STORE, 'readwrite').objectStore(IDB_STORE).add(entry);
        req.onsuccess = function() { resolve(); };
        req.onerror   = function(e) { reject(e.target.error); };
    });
}
function deletePending(db, id) {
    return new Promise(function(resolve, reject) {
        const req = db.transaction(IDB_STORE, 'readwrite').objectStore(IDB_STORE).delete(id);
        req.onsuccess = function() { resolve(); };
        req.onerror   = function(e) { reject(e.target.error); };
    });
}
