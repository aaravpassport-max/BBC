# Generated audit index
Generated: 2026-10-05T15:53:32+00:00

## Routes
| `/` | `HomePage.tsx` | page_type `homepage` |
| `/services` | `ServicesPage.tsx` | page_type `directory` |
| `/service/:slug` | `ServiceDetailPage.tsx` | page_type `direct_url` |
| `/about` | `index.tsx AboutPage` | page_type `page` |
| `/contact` | `index.tsx ContactPage` | page_type `page` |
| `/faq` | `index.tsx FAQPage` | page_type `page` |
| `/pricing` | `index.tsx PricingPage` | page_type `page` |
| `/blog` | `BlogListPage.tsx` | page_type `blog` |
| `/blog/:slug` | `BlogDetailPage.tsx` | page_type `blog` |
| `/dashboard` | `customer/index.tsx` | page_type `portal` |
| `/admin` | `admin/index.tsx` | page_type `portal` |

## Design asset bundles
- `platform-mobile-app.css` (12187 bytes)
- `portal-experience.css` (3099 bytes)
- `public-contrast-system.css` (6013 bytes)
- `public-design-system.css` (7196 bytes)
- `public-home-sections.css` (33856 bytes)
- `public-marketing-pages.css` (25289 bytes)
- `public-marketing-sections.css` (1246 bytes)
- `public-mobile-experience.css` (5473 bytes)
- `public-page-utilities.css` (1475 bytes)
- `public-pages-layout.css` (5952 bytes)
- `public-platform-experience.css` (13726 bytes)
- `public-service-detail.css` (23592 bytes)
- `public-service-experience.css` (6863 bytes)
- `public-services-directory.css` (6811 bytes)
- `public-site-chrome.css` (1845 bytes)
- `public-width-layout.css` (3733 bytes)
